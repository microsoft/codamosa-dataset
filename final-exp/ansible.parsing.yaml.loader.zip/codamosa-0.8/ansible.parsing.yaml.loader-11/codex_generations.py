

# Generated at 2022-06-11 09:25:43.670247
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    from ansible.compat.tests.mock import patch, MagicMock

    # Test AnsibleLoader()
    with patch.object(AnsibleLoader, '__init__', return_value=None) as mock_init:
        test = AnsibleLoader(None)
        mock_init.assert_called_with(None)
        assert test.stream is None
        assert test.file_name is None
        assert test.vault_secrets is None

    # Test AnsibleLoader.__init__()
    with patch.object(Scanner, '__init__', return_value=None) as mock_init:
        test = AnsibleLoader(None)
        mock_init.assert_called_with(test)

    # Test AnsibleLoader.dispose()

# Generated at 2022-06-11 09:25:44.542561
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader('')

# Generated at 2022-06-11 09:25:53.059879
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    assert loader.get_real_file_name('/etc/ansible/hosts') == '/etc/ansible/hosts'
    assert loader.get_real_file_name('/etc/ansible/hosts', use_exact_file_name=True) == '/etc/ansible/hosts'
    assert loader.get_real_file_name('/etc/ansible/hosts', follow=False) == '/etc/ansible/hosts'
    assert loader.get_real_file_name('/etc/ansible/hosts', use_exact_file_name=True, follow=False) == '/etc/ansible/hosts'
    # Be aware that os.path.realpath() might cause different result from

# Generated at 2022-06-11 09:26:05.476702
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleMapping, AnsibleSequence
    from ansible.parsing.vault import VaultLib, VaultSecret

    vault = VaultLib([VaultSecret('secret')])

    doc = """
    foo: !vault |
            $ANSIBLE_VAULT;1.1;AES256
            64376334613866616134613161353265316663396333356366323966306361643834636238636361
            613361386231633861653235316662653032333135316600000000

    bar:
      baz: 123
    """


# Generated at 2022-06-11 09:26:07.366162
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream='{"name": "test"}')
    assert loader.data == {"name": "test"}

# Generated at 2022-06-11 09:26:17.882280
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_input = """---
- hosts: localhost
  gather_facts: false
  connection: local
  tasks:
    - name: This is a test
      ping:
      delegate_to: localhost
      register: out_ping
    - name: This is another test
      file:
        path: /tmp/foo
        state: touch"""

    answer = {'tasks': [{'register': 'out_ping', 'delegate_to': 'localhost', 'ping': {}, 'name': u'This is a test'},
                         {'state': 'touch', 'name': u'This is another test', 'file': {'path': '/tmp/foo'}}],
              'gather_facts': False,
              'connection': 'local',
              'hosts': 'localhost'}


# Generated at 2022-06-11 09:26:31.874597
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    import types

    # Test that the default loader is actually the class we want
    # This is not always the case when testing with older versions
    # of python.
    assert sys.version_info[0:3] < (3,3) or \
        types.ModuleType.__dict__['_get_module_details'].__defaults__[5] == AnsibleLoader

    class TestStream(io.IOBase):

        def __init__(self):
            self.closed = False

        def close(self):
            self.closed = True

        def readable(self):
            return True

    class TestFile(object):

        def __init__(self, filename, mode, stream=None):
            self.name = filename
            self.mode = mode
            self.closed = False
            self._stream

# Generated at 2022-06-11 09:26:33.063085
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # this is a dummy test
    assert True

# Generated at 2022-06-11 09:26:37.089441
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(stream=None, file_name='/etc/ansible/hosts', vault_secrets=None)

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-11 09:26:38.525132
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader(stream=None)


# Generated at 2022-06-11 09:26:45.059502
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    stream = """
    - hosts: localhost
      tasks:
        - name: blah
          command: echo hi
    """

    loader = AnsibleLoader(stream)
    assert loader.construct_yaml_map()['hosts'] == 'localhost'

# Generated at 2022-06-11 09:26:45.778285
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:26:50.647577
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=no-member
    assert AnsibleLoader.yaml_constructors is not None
    assert AnsibleLoader.yaml_multi_constructors is not None
    assert AnsibleLoader.yaml_multi_constructors_glue is not None

# Generated at 2022-06-11 09:27:01.479261
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = """
--- # a dict
baz:
    - 1
    - 3
    - 5
    - 7
foo:
    - bar
    - baz
...
--- # a list
- one
- two
- three
...
"""

    data_loader = AnsibleLoader(stream)

    # Verify that we have 2 documents
    data = []
    for data_doc in data_loader:
        data.append(data_doc)

    assert len(data) == 2
    assert data[0]['foo'][1] == 'baz'
    assert data[1][2] == 'three'


if __name__ == '__main__':
    # Run test_AnsibleLoader
    test_AnsibleLoader()

# Generated at 2022-06-11 09:27:14.210594
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import json

    loader = AnsibleLoader('1')
    assert loader.get_value() == 1

    # ---
    # hosts: localhost
    # tasks:
    #   - name: fail
    #     fail:
    #       msg: not a real task
    #       blah: what?
    #       type: "{{ type }}"
    #       when: 1
    #       changed_when: 2
    #       failed_when: 3
    #       always_run: True
    #       no_log: True
    #       register: "{{ register }}"
    #       local_action: 4
    #
    #       ...
    # ---

# Generated at 2022-06-11 09:27:21.932184
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

    stream = io.BytesIO(b"""
        ---
        data:
          - '{ a: 3 }'
          - '{ a: 3 }'
          - '{ a: 3 }'
          - '{ a: 3 }'
          - '{ a: 3 }'
    """)

    loader = AnsibleLoader(stream)
    data = loader.get_data()
    assert data == dict(data=[dict(a=3), dict(a=3), dict(a=3), dict(a=3), dict(a=3)])

# Generated at 2022-06-11 09:27:25.459416
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    a = AnsibleLoader('')
    assert a.file_name is None
    assert a.vault_secrets is None

# Generated at 2022-06-11 09:27:27.288905
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, '__init__')

# Generated at 2022-06-11 09:27:29.061968
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    output = AnsibleLoader('')
    assert isinstance(output, AnsibleLoader)


# Generated at 2022-06-11 09:27:32.244743
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader('{')

# vim: set expandtab shiftwidth=4 tabstop=4 softtabstop=4

# Generated at 2022-06-11 09:27:49.362605
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os

    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.playbook.attribute import Attribute, FieldAttribute

    class TestLoader(AnsibleConstructor):
        @classmethod
        def add_constructor(cls, tag, constructor):
            pass

    x = TestLoader(file_name='/a/b/c.yml')
    assert isinstance(x.get_attr('_file_name'), Attribute)
    assert isinstance(x.get_attr('_file_name'), FieldAttribute)
    if sys.version_info >= (2, 7):
        assert x._file_name.fset is not None

    assert isinstance(x.get_attr('_vault_secrets'), Attribute)

# Generated at 2022-06-11 09:27:50.726934
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    instance = AnsibleLoader(None)
    assert isinstance(instance, AnsibleLoader)

# Generated at 2022-06-11 09:28:03.841587
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader

    class MyYAMLObject(AnsibleBaseYAMLObject):
        pass

    loader = AnsibleLoader("---\nan_object")
    loader.add_constructor("!myobj",
                           AnsibleConstructor.construct_yaml_map)
    loader.add_multi_constructor("!myobj",
                                 AnsibleConstructor.multi_constructor)

    obj = loader.get_single_data()
    assert obj == {"an_object": MyYAMLObject}
    assert isinstance(obj["an_object"], MyYAMLObject)

# Generated at 2022-06-11 09:28:15.196852
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import textwrap
    import unittest

    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestLoader(unittest.TestCase):
        '''Unit test for `AnsibleLoader`'''
        def setUp(self):
            self.loader = AnsibleLoader

        def test_ansible_mapping_class(self):
            '''test if it uses AnsibleMapping for a mapping'''
            yaml_str = textwrap.dedent("""
            test_mapping:
                key1: val1
                key2: val2
            """)
            ds = self.loader(yaml_str).get_single_data()

# Generated at 2022-06-11 09:28:17.299028
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, '__init__')

# Generated at 2022-06-11 09:28:19.695786
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.add_constructor('!include', AnsibleConstructor.include, Loader=AnsibleLoader)

# Generated at 2022-06-11 09:28:31.745311
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import os
    import tempfile
    import time
    import unittest

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    class TestAnsibleLoader(unittest.TestCase):
        def setUp(self):
            self.mock_vault_secrets = [b'testsecret', b'testfake']

        def tearDown(self):
            pass

        def test_init(self):
            stream = io.StringIO()
            AnsibleLoader(stream)

        def test_init_with_vault_secrets(self):
            stream = io.StringIO()

# Generated at 2022-06-11 09:28:42.976978
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, "construct_yaml_str")
    assert hasattr(AnsibleLoader, "construct_undefined")
    assert hasattr(AnsibleLoader, "construct_yaml_str")
    assert hasattr(AnsibleLoader, "construct_yaml_seq")
    assert hasattr(AnsibleLoader, "construct_yaml_map")
    assert hasattr(AnsibleLoader, "construct_yaml_omap")
    assert hasattr(AnsibleLoader, "construct_yaml_set")
    assert hasattr(AnsibleLoader, "construct_yaml_pairs")
    assert hasattr(AnsibleLoader, "construct_yaml_int")
    assert hasattr(AnsibleLoader, "construct_yaml_float")

# Generated at 2022-06-11 09:28:52.675325
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml_str = """
    - {host1: "1.1.1.1"}
    - {host2: "2.2.2.2"}
    - {host3: "3.3.3.3"}
    - {host4: "4.4.4.4"}
    """
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert type(data) == list
    assert data == [{'host1': '1.1.1.1'}, {'host2': '2.2.2.2'}, {'host3': '3.3.3.3'}, {'host4': '4.4.4.4'}]

# Generated at 2022-06-11 09:29:03.749677
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader

    stream = '''---
- name: testhost
  gather_facts: False
  tasks:
    - name: testnop
      debug:
        msg: hello
'''

    stream2 = '''
    - name: testnop
      debug:
        msg: hello
'''

    # get defaults
    assert DataLoader().get_basedir() == '.'

    # test file name tracking
    loader = DataLoader()
    loader.set_basedir('/foo')
    assert loader.get_basedir() == '/foo'

    # test constructors and loading
    loader = DataLoader()
    assert loader.get_basedir() == '/'
    ds = loader.load(stream)

    # test that DataLoader will use AnsibleLoader to construct

# Generated at 2022-06-11 09:29:26.389402
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """AnsibleLoader constructor test.

    Test that the AnsibleLoader class can be instantiated.
    The AnsibleLoader class is used in various modules throughout
    Ansible, so it is important that it functions properly.
    """

    # Setup the yaml string
    yaml_string = """
---
- hosts: localhost
  vars:
    var1: example variable
    var2: example variable 2
  tasks:
    - name: Test1
      debug: msg="example message 1"
    - name: Test2
      debug: msg="example message 2"
    - name: Test3
      debug: msg="example message 3"
    - name: Test4
      debug: msg="example message 4"
"""

    # Instantiate the AnsibleLoader class object
    loader = AnsibleLoader(yaml_string)

    # Verify

# Generated at 2022-06-11 09:29:37.268764
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    assert isinstance(AnsibleLoader({'foo': 'bar'}).get_single_data(), dict)
    assert isinstance(AnsibleLoader('foo: bar').get_single_data(), dict)
    assert isinstance(AnsibleLoader('[foo]').get_single_data(), list)
    assert isinstance(AnsibleLoader('foo').get_single_data(), AnsibleUnicode)

# Generated at 2022-06-11 09:29:43.434950
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultSecrets
    from ansible.parsing.vault import VaultSecret
    obj = VaultSecrets()
    obj.secrets = {
        'sandbox': VaultSecret('$1$J6aO4LZJ$qf3qJ4QzfKFJ7VxQ8J.w7/'),
        'prod': VaultSecret('$1$J6aO4LZJ$qf3qJ4QzfKFJ7VxQ8J.w7/'),
        'test': VaultSecret('$1$J6aO4LZJ$qf3qJ4QzfKFJ7VxQ8J.w7/'),
    }

# Generated at 2022-06-11 09:29:55.816309
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    contents = """
one:
    host1:
        name: foo
    host2:
        name: bar
two:
    - { role: common, other: thing }
    - role: webservers
"""

    loader = AnsibleLoader(contents)
    x = loader.get_single_data()

    assert type(x) == AnsibleMapping
    assert len(x.items()) == 2
    assert type(x['one']) == AnsibleMapping
    assert len(x['one'].items()) == 2
    assert type(x['one']['host1']) == AnsibleMapping
    assert type(x['one']['host2']) == AnsibleMapping

# Generated at 2022-06-11 09:30:06.950158
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        import StringIO
    else:
        from io import StringIO

    # input example

# Generated at 2022-06-11 09:30:15.339178
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # verify the class has the required methods
    methods = ('get_single_data', 'get_many_data')
    for method in methods:
        assert hasattr(loader, method), 'DataLoader is missing required method: %s' % method

    # Use the constructor of class AnsibleLoader
    load = AnsibleLoader(None)

    # Check the object can be constructed
    assert load is not None, 'Failed to construct AnsibleLoader'
    assert isinstance(load, AnsibleLoader), 'AnsibleLoader is not an instance of AnsibleLoader'

    # Check the yaml.composer.Composer() is an instance of Ans

# Generated at 2022-06-11 09:30:27.105541
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    if not HAS_LIBYAML:
        return
    import os, tempfile, ansible.constants as C
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode,AnsibleUnsafeText

    tmp = tempfile.mktemp()

# Generated at 2022-06-11 09:30:33.766225
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO

    def check_val(val):
        assert val == 42

    # pylint: disable=unused-variable
    # pylint can't tell that the class is being used above.
    class AnsibleLoaderTester(AnsibleLoader):
        def construct_yaml_int(self, node):
            check_val(node.value)

    loader = AnsibleLoaderTester(StringIO(u'42'))
    loader.get_single_data()

# Generated at 2022-06-11 09:30:41.705603
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from collections import Mapping, Sequence
    import io
    import unittest

    class AnsibleLoaderTest(unittest.TestCase):
        def setUp(self):
            class Loader(AnsibleLoader):
                def __init__(self):
                    stream = io.StringIO(u'{ foo: {bar: baz}}')
                    AnsibleLoader.__init__(self, stream)

            self.loader = Loader()
        def tearDown(self):
            self.loader = None

        def test_AnsibleLoader__new__(self):
            self.assertTrue(isinstance(self.loader._root, AnsibleMapping))

# Generated at 2022-06-11 09:30:43.361810
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, (Parser, AnsibleConstructor, Resolver))

# Generated at 2022-06-11 09:31:03.882732
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader('[1, 2]')

# Generated at 2022-06-11 09:31:13.910284
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleMapping
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    # Set vault secret to be used by AnsibleLoaders
    vault_secrets = dict(vault_password='myvaultpassword')

# Generated at 2022-06-11 09:31:20.518443
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.module_utils.common.yaml.constructor import AnsibleConstructor
    from ansible.plugins.loader import vault_loader

    loader = AnsibleLoader(file_name="test_file")
    assert isinstance(loader, AnsibleConstructor)

    loader = AnsibleLoader(stream="stream")
    assert isinstance(loader, AnsibleConstructor)

    loader = AnsibleLoader(stream="stream",file_name="file")
    assert isinstance(loader, AnsibleConstructor)


# Generated at 2022-06-11 09:31:23.509423
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)  # pylint: disable=no-value-for-parameter,unexpected-keyword-arg

# Generated at 2022-06-11 09:31:25.334826
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_constuct = AnsibleLoader.__init__(stream)
    assert test_constuct == None

# Generated at 2022-06-11 09:31:37.047331
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    encrypted = AnsibleVaultEncryptedUnicode("this is a test", vault_secret="secret123")

    # test python 2.7+ behaviour
    try:
        assert str(encrypted)
    except UnicodeDecodeError:
        # python 2.6
        assert unicode(encrypted)

    # test python 2.6 behaviour
    try:
        assert unicode(encrypted)
    except NameError:
        # python 2.7+
        assert str(encrypted)

    # test python 2.x behaviour
    try:
        assert bytes(encrypted)
    except NameError:
        # python 3.x
        assert str(encrypted)

    # test python 3.x behaviour

# Generated at 2022-06-11 09:31:46.805290
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import AnsibleLoader
    from ansible.module_utils.common.yaml import HAS_LIBYAML

    data = """
---
hosts:
  - test00
"""
    loader = AnsibleLoader(data)
    if HAS_LIBYAML:
        assert loader.stream is None  # Parser will set it to None
    else:
        assert loader.stream == '\n\n'  # Reader will set it to '\n\n'
    assert loader._file_name is None
    assert loader._vault is None
    assert loader._vault_secrets is None
    assert loader._vault_password_files == []
    assert loader.descend_resolver is None
    assert loader.compat_loader is None
    assert loader.construct_yaml

# Generated at 2022-06-11 09:31:49.782551
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from os.path import dirname, join, abspath
    test_file = join(dirname(abspath(__file__)), 'yaml-loader-constructor-test.yml')

    loader = AnsibleLoader(open(test_file, 'r'), file_name=test_file, vault_secrets=None)
    loader.get_single_data()

# Generated at 2022-06-11 09:31:50.990820
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_loader = AnsibleLoader(stream=None)
    assert isinstance(test_loader, AnsibleLoader)

# Generated at 2022-06-11 09:31:51.450645
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:32:36.779411
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = """
        ---
        - block:
            - debug:
                msg: '{{ one }} is less than {{ five }}'
            when: one < five
            loop: ''
          until: false
          with_sequence:
            - one
            - five
        - set_fact:
            a: 123
        - name: "{{ a }}"
    """
    loader = AnsibleLoader(yaml_str)
    loader.get_single_data()

# Generated at 2022-06-11 09:32:40.939787
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader(stream='stream', file_name='file_name', vault_secrets='vault_secrets')
    assert obj.stream == 'stream'
    assert obj.file_name == 'file_name'
    assert obj.vault_secrets == 'vault_secrets'

# Generated at 2022-06-11 09:32:41.931867
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader


# Generated at 2022-06-11 09:32:43.253326
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    assert(AnsibleLoader is not None)

    #TODO: Write better unit tests

# Generated at 2022-06-11 09:32:44.228758
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader(None)

# Generated at 2022-06-11 09:32:51.789596
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import unittest

    class TestAnsibleLoader(unittest.TestCase):

        def setUp(self):
            self.data = '''
            ---
            foo_variable: 123
            '''

        def test_loader(self):
            yaml_data = AnsibleLoader(self.data).get_single_data()
            self.assertEqual(yaml_data, {'foo_variable': 123})

        def tearDown(self):
            pass
    module_path = os.path.join(sys.path[0], 'ansible')
    if module_path not in sys.path:
        sys.path.append(module_path)
    unittest.main()

# Generated at 2022-06-11 09:32:53.825601
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # create an instance of AnsibleLoader class
    my_instance = AnsibleLoader('my_instance')
    # check if the instance of AnsibleLoader is created properly or not
    assert isinstance(my_instance, AnsibleLoader)

# Generated at 2022-06-11 09:32:56.680807
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import doctest
    results = doctest.testmod(AnsibleLoader, options=doctest.ELLIPSIS)
    assert results.failed == 0

# Generated at 2022-06-11 09:33:04.598952
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import get_single_data

    loader = AnsibleLoader("test")

    assert loader is not None
    assert isinstance(loader, AnsibleConstructor)
    assert hasattr(loader, "get_single_data")
    assert loader.get_single_data is get_single_data

    data = loader.get_single_data('example')

    assert data == {'key': 'value'}

# Generated at 2022-06-11 09:33:05.264750
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:34:29.961050
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Assertion Error if class without instantiating object
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    loader = AnsibleLoader('')
    assert AnsibleVaultEncryptedUnicode is loader.construct_yaml_str

# Generated at 2022-06-11 09:34:33.491953
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
---
a: 123
b: "{{ c }}"
'''
    loader = AnsibleLoader(data)
    loader.get_single_data()

# Generated at 2022-06-11 09:34:37.135206
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestAnsibleLoader(AnsibleLoader):
        def __init__(self, stream, file_name=None, vault_secrets=None):
            super(TestAnsibleLoader, self).__init__(stream, file_name=file_name, vault_secrets=vault_secrets)

# Generated at 2022-06-11 09:34:41.572640
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    file_name = 'hosts'
    vault_secrets = 'test_passwd'
    stream = 'test'
    ansibleLoader = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)
    assert ansibleLoader.file_name == file_name
    assert ansibleLoader.vault_secrets == vault_secrets
    assert ansibleLoader.stream == stream

# Generated at 2022-06-11 09:34:42.134849
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:34:51.973768
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    expected_keys = [
        'task_includes', 'roles', 'data', 'tasks', 'handlers', 'meta'
    ]
    x = AnsibleLoader(
        '''
- include: myplay.yml
- include: myplay.yml
  with_items:
    - item1
    - item2
- include: myplay.yml
  with_items:
    - item3
    - item4
- hosts: all
  vars:
    var1: value1
    var2: value2
- hosts: all
  tasks:
  - debug: var=hostvars[inventory_hostname]['var1']
  - debug: var=hostvars[inventory_hostname]['var2']
- foo: bar
''')
    assert isinstance(x, AnsibleLoader)


# Generated at 2022-06-11 09:34:59.978317
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader, variables={})
    play_context = PlayContext()

    # Test constructor with a normal base object
    AnsibleLoader({})

    # Test constructor with a base object that has a __getstate__ method
    AnsibleLoader(Host())

    # Test constructor with a base object that has a __setstate__ method
    AnsibleLoader(Templar(loader=loader, variables={}))

    # Test constructor with a base object that has a __getstate__ and __setstate__ method
    AnsibleLoader(PlayContext())

# Generated at 2022-06-11 09:35:09.039425
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io

    data = '''
        - hosts: localhost
          gather_facts: no
          tasks:
            - name: "Configure the system hostname"
              hostname:
                name: "{{ ansible_hostname }}"
    '''

    class MyStream(object):
        def __init__(self, data, file_name=None, vault_secrets=None):
            self.data = data
            self.line = 0
        def readline(self):
            self.line += 1
            if self.line > len(self.data.split('\n')):
                return ''
            return self.data.split('\n')[self.line - 1] + '\n'

    if HAS_LIBYAML:
        loader = AnsibleLoader(MyStream(data))
   

# Generated at 2022-06-11 09:35:10.441368
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:35:12.126962
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    This test is not really a unittest, but is for future
    development of the code which instantiates the class.
    '''
    pass