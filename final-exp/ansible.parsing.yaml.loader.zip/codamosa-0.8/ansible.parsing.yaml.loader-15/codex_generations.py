

# Generated at 2022-06-11 09:25:29.974519
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader

# Generated at 2022-06-11 09:25:30.855587
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.load(r'')

# Generated at 2022-06-11 09:25:35.101725
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    data = str('a')
    loader = AnsibleLoader(data)
    ansible_unicode = loader.construct_object(data)

    assert isinstance(ansible_unicode, AnsibleUnicode)
    assert ansible_unicode == str(data)

# Generated at 2022-06-11 09:25:36.461135
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, None)
    assert loader

# Generated at 2022-06-11 09:25:45.856212
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from sys import version_info

    data = b"string_key: string\nlist_key:\n  - item1\n  - item2"
    stream = AnsibleLoader(data)

    assert stream.get_single_data() == dict(string_key="string", list_key=AnsibleSequence(["item1","item2"]))
    assert "string" == type(stream.get_single_data()['string_key'])
    if version_info[0] < 3:
        assert "unicode" == type(stream.get_single_data()['string_key'])
    else:
        assert "str" == type(stream.get_single_data()['string_key'])

# Generated at 2022-06-11 09:25:54.026015
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=too-many-locals,too-many-branches,unused-argument
    import base64
    import binascii
    import os
    import sys
    import unittest
    from io import BytesIO

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.constructor import AnsibleConvertYAMLtoJSONError, AnsibleConstructorError
    from ansible.utils.unicode import to_unicode

    class MyUnicode(AnsibleBaseYAMLObject):
        def __init__(self, value):
            self.value

# Generated at 2022-06-11 09:26:03.816033
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = (
        '---\n'
        '# Part 1\n'
        'hostname: {{ ansible_hostname }}\n'
        'ip: {{ ansible_default_ipv4.address }}\n'
        '# Part 2\n'
        '{{ p }} is not a variable\n'
    )
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == {
        'hostname': '{{ ansible_hostname }}',
        'ip': '{{ ansible_default_ipv4.address }}',
        '{{ p }} is not a variable': None,
    }

# Generated at 2022-06-11 09:26:08.630186
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(None, None, None)
    assert isinstance(ansible_loader, Resolver)
    assert isinstance(ansible_loader, AnsibleConstructor)
    if HAS_LIBYAML:
        assert isinstance(ansible_loader, Parser)

# Generated at 2022-06-11 09:26:16.035335
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import yaml

    stream = io.StringIO("""\
    - hosts:
        - foo
    - hosts:
        - bar
    """)

    result = yaml.load(stream, Loader=AnsibleLoader)
    assert result == [{
        'hosts': ['foo'],
        '__ansible_pos__': 2  # default file and line numbering
    }, {
        'hosts': ['bar'],
        '__ansible_pos__': 6  # default file and line numbering
    }]

# Generated at 2022-06-11 09:26:23.061768
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import os
    import signal
    import sys
    import tempfile
    import time
    import types

    import ansible.parsing.yaml.objects
    from units.mock.loader import DictDataLoader

    a_file_name = "AnsibleLoader"
    a_string = "{stringy: yaml}"
    a_bytes = b"{binary: data}"
    a_unicode = u'{µ: €}'
    a_namespace = ansible.parsing.yaml.objects.AnsibleNamespace()
    a_loader = DictDataLoader({'a_file_name': [a_bytes]})

    # __init__
    loader_obj = AnsibleLoader(a_string)

    assert isinstance(loader_obj, types.GeneratorType)
    assert loader_obj

# Generated at 2022-06-11 09:26:38.886230
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.errors import AnsibleParserError

    class ArbitraryException(Exception):
        pass

    def bad_constructor(loader, node):
        raise ArbitraryException('bad constructor')

    def bad_representer(dumper, data):
        raise ArbitraryException('bad representer')

    AnsibleLoader.add_constructor(None, bad_constructor)
    AnsibleLoader.add_representer(None, bad_representer)

    stream = '{ bad : bad }'

    # Verify that the error message is improved when the Exception contains
    # a message.

# Generated at 2022-06-11 09:26:41.560852
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class NewLoader(AnsibleLoader):
        pass
    assert NewLoader.__bases__ == (
        Reader, Scanner, Parser, Composer, AnsibleConstructor, Resolver)

# Generated at 2022-06-11 09:26:48.486729
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # This function is used for unit test for class AnsibleLoader. When
    # libyaml is not installed, AnsibleLoader will not be loaded and
    # this function won't be called.

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from .vars.hostvars import AnsibleHostVars

    assert AnsibleLoader
    assert AnsibleHostVars
    assert AnsibleVaultEncryptedUnicode
    assert AnsibleUnsafeText


# Generated at 2022-06-11 09:26:58.608626
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert AnsibleConstructor in loader.__class__.__bases__
    assert Resolver in loader.__class__.__bases__

    if HAS_LIBYAML:
        assert Parser in loader.__class__.__bases__
    else:
        assert Reader in loader.__class__.__bases__
        assert Scanner in loader.__class__.__bases__
        assert Parser in loader.__class__.__bases__
        assert Composer in loader.__class__.__bases__

# Generated at 2022-06-11 09:26:58.992649
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:26:59.829256
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None, None)

# Generated at 2022-06-11 09:27:04.433061
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    empty = '{}'
    AnsibleLoader(empty)
    emp_list = '- test'
    AnsibleLoader(emp_list)
    emp_dict = 'a: b'
    AnsibleLoader(emp_dict)
    doc_sep = '---'
    AnsibleLoader(doc_sep)

# Generated at 2022-06-11 09:27:14.964580
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import wrap_var
    code = """foo: bar
    baz: blah
    stuff:
      - { name: one }
      - { name: two }
      - { name: three }"""

    data = AnsibleLoader(code, None).get_single_data()
    assert data['foo'] == 'bar'

    # the constructor wraps unsafe values in an AnsibleUnsafeText
    assert wrap_var(data['stuff'][0]['name']) == wrap_var('one')

# Generated at 2022-06-11 09:27:20.678508
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    loader = AnsibleLoader(None)
    vault_secret = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256; VaultSecret \n')
    assert vault_secret.get_unencrypted_text() == '$ANSIBLE_VAULT;1.2;AES256; VaultSecret \n'

# Generated at 2022-06-11 09:27:31.837367
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    test_file = os.path.join(os.path.dirname(__file__), 'loader_test.yml')
    with open(test_file) as f:
        loader = AnsibleLoader(f, file_name=test_file)
    data = loader.get_single_data()
    assert 'test_list' in data
    assert data['test_list'] == [42, 'foobar', {'key': 'value'}]
    assert 'test_vault_id' in data
    assert data['test_vault_id'] == ['foo', 'bar']
    assert 'test_vault_id_trailing_space' in data
    assert data['test_vault_id_trailing_space'] == ['foo', 'bar']
    # vault_secret does not get set until get_

# Generated at 2022-06-11 09:27:48.734425
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_instance = AnsibleLoader(stream=None)
    assert AnsibleLoader.__bases__ == (Parser.__bases__[0], AnsibleConstructor, Resolver)
    assert ansible_loader_instance.construct_object.__func__.__code__.co_filename == AnsibleConstructor.construct_object.__func__.__code__.co_filename
    assert ansible_loader_instance.construct_object.__func__.__code__.co_firstlineno == AnsibleConstructor.construct_object.__func__.__code__.co_firstlineno
    assert ansible_loader_instance.construct_object.__func__.__code__.co_varnames == AnsibleConstructor.construct_object.__func__.__code__.co_varnames

# Generated at 2022-06-11 09:27:49.776492
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader



# Generated at 2022-06-11 09:27:57.206748
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_unicode

    data = b'''
    vault_password_file: /path/to/ansible.vault_password_file
    vault_password_file: /path/to/ansible.vault_password_file
    vars:
      vault_password_file: /path/to/ansible.vault_password_file
      var1:
        vault_password_file: /path/to/ansible.vault_password_file
        var2:
          vault_password_file: /path/to/ansible.vault_password_file
          var3:
            vault_password_file: /path/to/ansible.vault_password_file
    '''

# Generated at 2022-06-11 09:28:10.480764
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    d = AnsibleLoader(
        "name: 'test'\n"
        "value: 1234",
        vault_secrets={},
    )
    assert isinstance(d.get_data(), dict)
    assert d.get_data()['name'] == 'test'
    assert d.get_data()['value'] == 1234
    d = AnsibleLoader(
        '''
        ---
        name: 'test'
        value: 1234
        ''',
        vault_secrets={},
    )
    assert isinstance(d.get_data(), dict)
    assert d.get_data()['name'] == 'test'
    assert d.get_data()['value'] == 1234

# Generated at 2022-06-11 09:28:19.188227
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader

    def test_map():
        raw = 'key: value'
        yaml = AnsibleLoader(raw).get_single_data()
        assert yaml == {'key': 'value'}

    def test_block_literal():
        raw = '|\n    value1\n    value2'
        yaml = AnsibleLoader(raw).get_single_data()
        assert yaml == 'value1\nvalue2'

    def test_block_folded():
        raw = '>\n    value1\n    value2'
        yaml = AnsibleLoader(raw).get_single_data()
        assert yaml == 'value1value2'

    def test_unquoted_string():
        raw = 'a string'
       

# Generated at 2022-06-11 09:28:21.980593
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''Make sure AnsibleLoader is callable'''
    assert callable(AnsibleLoader)

# Generated at 2022-06-11 09:28:33.373177
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    import io
    import sys


# Generated at 2022-06-11 09:28:44.121455
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    :type ansible_loader: ansible.parsing.yaml.loader.AnsibleLoader
    :return: None
    """
    import io
    import sys
    import unittest
    from ansible.parsing.yaml.constructor import AnsibleConstructorError

    # Test for
    # (1) AnsibleConstructorError for str constructor
    # (2) AnsibleConstructorError for datetime constructor
    # (3) TypeError for wrong constructor arguments


# Generated at 2022-06-11 09:28:50.205105
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    data = '''
    ---
    - hosts: local
      gather_facts: no
      tasks:
        - name: ansible loader test
          ping:
            data: 'pong'
    '''

    fake_loader = AnsibleLoader(data)
    data = fake_loader.get_single_data()

    assert isinstance(data, list)
    assert data[0]['hosts'] == 'local'



# Generated at 2022-06-11 09:29:01.626507
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.constructor import BaseConstructor
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.data import AnsibleUnicode

    a_dict = {u'a':2, u'b':3, u'c':4}
    a_list = [1, 2, 3, 4, 5]

    stream = '---\n- 1\n- 2\n- 3\n- 4\n- 5\n'
    # stream = u'---\n- 1\n- 2\n- 3\n- 4\n- 5\n'
    # stream = b'---\n- 1\n- 2\n- 3\n- 4\n- 5\n'


# Generated at 2022-06-11 09:29:14.689019
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Create an instance of AnsibleLoader
    loader = AnsibleLoader(stream=None)

    # Test the object instance
    assert isinstance(loader, AnsibleLoader)


# Generated at 2022-06-11 09:29:15.612299
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-11 09:29:19.546611
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = 'test'
    file_name = 'test'
    vault_secrets = 'test'
    AnsibleLoader(stream, file_name, vault_secrets)

# Generated at 2022-06-11 09:29:28.641334
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-11 09:29:31.206191
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '---\n- hosts: localhost\n'
    AnsibleLoader(stream)

# Generated at 2022-06-11 09:29:32.525119
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# Generated at 2022-06-11 09:29:34.098650
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    x = AnsibleLoader(None)

# Generated at 2022-06-11 09:29:34.736904
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-11 09:29:43.891476
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import yaml


# Generated at 2022-06-11 09:29:56.323538
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    loader = AnsibleLoader(stream=None, file_name=None, vault_secrets=['secret1', 'secret2'])
    assert loader.vault_secrets == ['secret1', 'secret2']

    vault = VaultLib(['secret1', 'secret2'])
    result = loader.construct_object(node=None, deep=True)
    assert result is None

    vault_text = vault.encrypt('text')
    result = loader.construct_object(node=vault_text, deep=True)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 09:30:18.126658
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_yaml_str(None), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_seq(None), AnsibleSequence)

# Generated at 2022-06-11 09:30:24.121200
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """ this is a unit test for `AnsibleLoader` class """

    # test a basic yaml file
    test_yaml = """
---
  username: ansible
  password: ansible
"""
    yaml_obj = AnsibleLoader(test_yaml).get_single_data()
    assert yaml_obj['username'] == 'ansible'
    assert yaml_obj['password'] == 'ansible'

# Generated at 2022-06-11 09:30:36.157236
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-11 09:30:46.037273
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, '__init__')
    assert hasattr(AnsibleLoader, 'construct_mapping')
    assert hasattr(AnsibleLoader, 'construct_scalar')
    assert hasattr(AnsibleLoader, '_yaml_base_loader_for_module')
    assert hasattr(AnsibleLoader, '_yaml_base_loader_for_data')
    assert hasattr(AnsibleLoader, '_yaml_base_loader')
    assert hasattr(AnsibleLoader, '_create_constructor')
    assert hasattr(AnsibleLoader, '_create_resolver')


# Generated at 2022-06-11 09:30:46.664892
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-11 09:30:56.943156
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.vault import VaultLib
    import yaml

    vault_secrets = VaultLib(['mYsECr3t'])

# Generated at 2022-06-11 09:30:58.382963
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Test when vault secrets is provided

    # Test when vault secrets is provided
    pass

# Generated at 2022-06-11 09:31:06.375153
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = AnsibleLoader('''
    -	foo:
            bar: baz
        quux:
            -	quuz:
                    corge:	grault
                waldo:	fred
            -	garply:
                    waldo:	fred
                    plugh:	xyzzy
                fred:	waldo
        ''')
    assert( len(data.get_data()) == 1 )
    assert( data.get_data()[0]['quux'][1]['garply']['plugh'] == 'xyzzy')

# Generated at 2022-06-11 09:31:15.701050
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.errors import AnsibleError

    # Test verbatim string
    data = AnsibleLoader("|\n  test").get_single_data()
    assert data == "test"

    # Test verbatim string with special chars
    data = AnsibleLoader("|\n  test\ntest").get_single_data()
    assert data == "test\ntest"

    # Test string with special chars
    data = AnsibleLoader("test\ntest").get_single_data()
    assert data == "test\ntest"

    # Test verbatim unicode
    data = AnsibleLoader("|\n  test\u20ac").get_single_data()
    assert data == "test\u20ac"

    # Test verbatim boolean
    data = AnsibleLoader("|\n  yes").get_single

# Generated at 2022-06-11 09:31:22.703784
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml import objects
    import yaml

    data = '''
validate_certs: False
'''

    loader = AnsibleLoader(data, vault_secrets=None)
    loader.compose_document()

    assert isinstance(loader.get_single_data(), objects.AnsibleVaultEncryptedUnicode) is True

# Generated at 2022-06-11 09:32:04.584771
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    # create an instance of AnsibleLoader to test
    # the basic behaviour of '__init__'
    file_name = 'test_file'
    vault_secrets = []
    loader = AnsibleLoader(None, file_name=file_name, vault_secrets=vault_secrets)

    assert loader.file_name == file_name
    assert loader.vault_secrets == vault_secrets

    # create an AnsibleMapping to test the basic behaviour of 'construct_object'
    test_node = AnsibleMapping()
    result = loader.construct_object(test_node)

# Generated at 2022-06-11 09:32:07.330549
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ''' this is just a test stub to allow testing of the constructor
        of the AnsibleLoader class which is used to implement vault logic
        in the yaml frontend.
    '''
    pass

# Generated at 2022-06-11 09:32:10.545701
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '---\n- name: Gainsborough Software Systems\n  num_employees: 25\n'
    loader = AnsibleLoader(stream)
    assert loader.get_single_data() == [{'name': 'Gainsborough Software Systems', 'num_employees': 25}]

# Generated at 2022-06-11 09:32:12.359716
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader(): # pylint: disable=unused-argument

    stream = '---'
    loader = AnsibleLoader(stream)
    assert loader is not None

# Generated at 2022-06-11 09:32:23.300035
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys

    if __name__ == '__main__':
        lib_path = os.path.abspath('../lib')
        sys.path.append(lib_path)

    yaml_test_data = '''
    # basic list
    - hosts:
        - host1
        - host2
    tasks:
    - shell: echo hello

    # basic list
    - hosts:
      - host1
      - host2
    tasks:
    - shell: echo hello

    # basic hash
    - hosts:
      - host1
      - host2
    tasks:
    - shell: echo hello
    '''

    # Use AnsibleLoader to load the yaml (check for the absence of constructor error)
    AnsibleLoader(yaml_test_data).get_single_data()

    #

# Generated at 2022-06-11 09:32:24.316552
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader


# Generated at 2022-06-11 09:32:31.610712
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_python_str(None), AnsibleUnicode)
    assert loader.construct_python_str(None) == ''
    assert isinstance(loader.construct_python_str('foo'), AnsibleUnicode)
    assert loader.construct_python_str('foo') == 'foo'
    assert isinstance(loader.construct_python_str(u'foo'), AnsibleUnicode)
    assert loader.construct_python_str(u'foo') == u'foo'
    assert isinstance(loader.construct_yaml_str(None), AnsibleUnicode)
    assert loader.construct_yaml_str(None) == ''

# Generated at 2022-06-11 09:32:39.369422
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_file_name = "test_file_name"
    test_stream = '{"test_key": "test_value"}'
    test_vault_secrets = "vault_test_value"
    ansible_loader = AnsibleLoader(stream=test_stream, file_name=test_file_name, vault_secrets=test_vault_secrets)
    assert isinstance(ansible_loader, AnsibleLoader)
    assert ansible_loader.stream == test_stream
    assert ansible_loader.file_name == test_file_name
    assert ansible_loader.vault_secrets == test_vault_secrets

# Generated at 2022-06-11 09:32:40.249873
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:32:49.495355
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from io import BytesIO as StringIO  # pylint: disable=redefined-builtin


# Generated at 2022-06-11 09:34:12.220973
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    loader = AnsibleLoader('', file_name='sample.yml')

    # Test the when_constructor for different values
    loader.when_constructor('a:b')
    assert loader.previous_event[1][0]['a'] == u'b'

    loader.when_constructor('a: {}')
    assert loader.previous_event[1][0]['a'] == {}

    loader.when_constructor('a: []')
    assert loader.previous_event[1][0]['a'] == []

    loader.when_constructor('a: 1')
    assert loader.previous_event[1][0]['a'] == 1

# Generated at 2022-06-11 09:34:22.624042
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.reader import ReaderError
    from ansible.parsing.vault import VaultLib
    import io
    import os
    import six


# Generated at 2022-06-11 09:34:26.442495
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    data = dict(a=1, b=2)
    stream = "a: 1\nb: 2\n"

    loader = AnsibleLoader(stream, file_name=None, vault_secrets=None)
    item = loader.get_single_data()

    assert item == data

# Generated at 2022-06-11 09:34:33.590237
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Tests constructor of AnsibleLoader
    # Test file contains yaml with vault encrypted string
    # This test is to test if the isinstance() check fails when loading the yaml file
    # with vault encrypted string in it.
    # This used to always fail with libyaml before the fix.
    with open("test/unit/parsing/yaml/vault_test_data.yml", "r") as vault_file:
        AnsibleLoader(vault_file)

# Generated at 2022-06-11 09:34:35.226845
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(None, None, None)
    assert ansible_loader is not None

# Generated at 2022-06-11 09:34:36.478313
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    loader.__init__('')

# Generated at 2022-06-11 09:34:38.020322
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    load = AnsibleLoader(None, file_name=None, vault_secrets=None)
    assert load.file_name == None

# Generated at 2022-06-11 09:34:41.320344
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    s = AnsibleLoader("foo: {{bar}}")
    assert [s.get_event(), s.get_event()] == [u'STREAM-START', u'DOCUMENT-START']
    assert s.compose_document() == {u'foo': u'bar'}

# Generated at 2022-06-11 09:34:51.185130
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # test_AnsibleLoader_lookup_files
    stream = '''
    name: hello
    lookup_file: "{{fname}}"
    '''.strip()
    loader = AnsibleLoader(stream, file_name='test_AnsibleLoader_lookup_files')
    res = loader.get_single_data()
    assert res == dict(
        name="hello",
        lookup_file=dict(
            _lookup_plugin='file',
            _lookup_terms='{{fname}}',
            _file='./test_AnsibleLoader_lookup_files',
        )
    )

    # test_AnsibleLoader_lookup_file
    stream = '''
    name: hello
    lookup_file: "{{fname}}"
    '''.strip()
    loader = AnsibleLoader

# Generated at 2022-06-11 09:34:51.721397
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader