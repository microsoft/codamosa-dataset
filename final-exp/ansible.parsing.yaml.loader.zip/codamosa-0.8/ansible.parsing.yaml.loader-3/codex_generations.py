

# Generated at 2022-06-11 09:25:43.711554
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.nodes import MappingNode
    from yaml.representer import ScalarNode
    import yaml

    for filename in ["test/ansible_loader.yml", "test/ansible_loader_single_quote.yml"]:
        fh = open(filename)
        sca_node = ScalarNode('tag:yaml.org,2002:str', 'key')
        map_node = MappingNode('tag:yaml.org,2002:map', [], False)
        map_node.insert(0, sca_node)
        map_node.insert(1, sca_node)
        data = yaml.round_trip_load(fh, AnsibleLoader)
        assert map_node in data
        fh.close()

# Generated at 2022-06-11 09:25:51.520384
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    loader = AnsibleLoader(stream=None)
    # make sure AnsibleConstructor is loaded
    assert isinstance(loader.construct_yaml_str("!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3634333935653439633564343163356233313661326535663733613164343835333238353730623739\n          353064343035633231323064666333386233353562"), AnsibleVaultEncryptedUnicode)
    assert not hasattr(loader, 'vault_errors_found')

# Generated at 2022-06-11 09:25:55.133081
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(file_name="/etc/ansible/roles/foobar/meta/main.yml")
    assert loader.file_name == "/etc/ansible/roles/foobar/meta/main.yml"

# Generated at 2022-06-11 09:26:03.113821
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    class FakeStream(object):
        def __init__(self, data):
            self.data = data

        def read(self):
            return self.data

    data = '''
    ---
    - name: Test
      hosts: localhost
      become_user: root
      tasks:
      - name: test
        shell: echo "test"
    '''

    stream = FakeStream(data)

    loader = AnsibleLoader(stream)
    result = loader.get_single_data()

    assert result is not None

# Generated at 2022-06-11 09:26:04.754000
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    assert AnsibleLoader
 

# Generated at 2022-06-11 09:26:08.168422
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Ensure AnsibleLoader is defined and can be instantiated with a stream
    '''
    try:
        AnsibleLoader('')
        assert True
    except NameError:
        assert False

# Generated at 2022-06-11 09:26:09.521463
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader('')
    assert obj

# Generated at 2022-06-11 09:26:13.160776
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    al = AnsibleLoader([], {}, {}, {}, {})
    assert al.file_name == ''
    assert al.vault_secrets == []

# Generated at 2022-06-11 09:26:15.676753
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: need to assert something in this test
    loader = AnsibleLoader(open(__file__, 'rb'))
    loader.get_single_data()

# Generated at 2022-06-11 09:26:16.253991
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:26:19.377305
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader([])
    assert loader

# Generated at 2022-06-11 09:26:33.314247
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        AnsibleLoader(file_name='static/test_loader.yml')
    except ValueError:
        pass
    try:
        AnsibleLoader(file_name='static/test_loader_dict_object.yml')
    except ValueError:
        pass
    try:
        AnsibleLoader(file_name='static/test_loader_non_dict_object.yml')
    except ValueError:
        pass
    try:
        AnsibleLoader(file_name='static/test_loader_dict_list.yml')
    except ValueError:
        pass
    try:
        AnsibleLoader(file_name='static/test_loader_non_dict_list.yml')
    except ValueError:
        pass
test_AnsibleLoader()

# Generated at 2022-06-11 09:26:34.407145
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader(stream='foo')


# Generated at 2022-06-11 09:26:45.697764
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import tempfile
    import yaml
    extvars = {
        'strvar': 'str value',
        'listvar': ['item1', 'item2'],
        'dictvar': {
            'key1': 'val1',
            'key2': 'val2'
        }
    }
    with tempfile.NamedTemporaryFile('w') as f:
        f.write('''
        ---
        {% for k,v in str(play_hosts) | list %}
        - {{ k }}:
            {% for k2, v2 in v.items() %}
            {{ k2 }}: "{{ v2 }}"
            {% endfor %}
        {% endfor %}
        ''')
        f.flush()


# Generated at 2022-06-11 09:26:59.061452
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils.common.collections import ImmutableDict
    yaml = YAML(typ='safe')
    yaml.default_flow_style = False
    yaml.indent(sequence=4, offset=2)
    yaml.register_class(ImmutableDict)
    yaml.register_class(AnsibleLoader)
    yaml.register_class(AnsibleDumper)
    if HAS_LIBYAML:
        yaml.explicit_start = True
        yaml.explicit_end = True

# Generated at 2022-06-11 09:27:10.413806
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Make sure AnsibleLoader class can be created
    '''
    from ansible import constants as C
    from ansible.parsing.yaml.loader import AnsibleLoader

    #Read in test yaml file
    with open("test/unit/parsing/yaml/test_vault.yml") as yaml_fileobj:
        test_loader = AnsibleLoader(yaml_fileobj, vault_secrets=['file1', 'file2'], file_name='/some/file')

    #Encrypt a vault secret
    x = test_loader.encrypt_secret('secret_value')

# Generated at 2022-06-11 09:27:17.175734
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None)
    assert hasattr(loader, 'ansible_version')
    assert hasattr(loader, 'file_name')
    assert hasattr(loader, 'vault_secrets')
    assert isinstance(loader, Resolver)
    assert loader.ansible_version == 'dev'
    assert loader.file_name is None
    assert loader.vault_secrets is None

# Generated at 2022-06-11 09:27:20.264717
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader

    class TestAnsibleLoader(AnsibleLoader):
        pass

    loader = TestAnsibleLoader(None)


# Generated at 2022-06-11 09:27:31.542214
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    data = """
    ---
    - src: /srv/myfiles/foo.txt
      dest: /etc/foo.txt
      owner: foo
      group: foo
      mode: 0644
      backup: yes
      force: no
      encoding: latin-1
      remote_src: no
      validate: /usr/sbin/validate_file --argument1 --argument2

    - src: /srv/myfiles/bar.txt
      dest: /etc/bar.txt
      owner: bar
      group: bar
      mode: 0644
      state: link
      force: yes
      remote_src: yes
      accept_hostkey: yes
      validate: /root/bin/validate_file --argument1 --argument2
    """

    fake_file_name = '/foo/bar'

    loader = Ans

# Generated at 2022-06-11 09:27:42.999701
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        from yaml import CLoader as Loader
    except ImportError:
        from yaml import Loader

    data = '''
            - hosts: localhost
              gather_facts: no
              tasks:
                  - setup:
                    become_user: bob
                    become_method: sudo
    '''
    dataloader = Loader(data)

    obj1 = [{'tasks': [{'setup': {'become_method': 'sudo', 'become_user': 'bob'}}], 'gather_facts': 'no', 'hosts': 'localhost'}]
    obj2 = AnsibleLoader(dataloader)

    assert obj1 == obj2.get_single_data()

# Generated at 2022-06-11 09:27:49.453528
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = "foo: !!str 'bar'"
    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-11 09:28:00.750452
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    # test_data = b'\x02\x00'
    string_contents = b'''
    - 
      - 
        - 1
        - 2
      - 3
      - 4
    '''
    # string_contents = string_contents.decode('utf-8')
    # print(string_contents)
    # exit(0)
    # print(string_contents)
    # exit(0)
    from io import BytesIO
    stream = BytesIO(string_contents)
    loader = yaml.loader.AnsibleLoader(stream)
    # print(loader)
    # exit(0)
    for data in loader:
        print(data)
    exit(0)
    # data = yaml.load(stream, Loader=Ans

# Generated at 2022-06-11 09:28:03.394395
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:28:14.850709
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.vars import combine_vars

    yaml_data = AnsibleLoader('''
        ---
        foo: bar
        baz:
          - one
          - two
          - 3

        bar:
          bar1:
            - one
            - two
          bar2: "two"
    ''')
    data = yaml_data.get_single_data()

    assert isinstance(data.get('foo'), AnsibleUnicode)
    assert isinstance(data.get('baz'), list)
    assert isinstance(data.get('bar'), dict)

# Generated at 2022-06-11 09:28:22.370482
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
a: 1
b:
  c: 3
  d: 4
'''
    data_result = {u'a': 1, u'b': {u'c': 3, u'd': 4}}

    ansible_loader = AnsibleLoader(data)
    (data_loaded,) = ansible_loader.get_single_data()
    assert (data_loaded == data_result)

# Generated at 2022-06-11 09:28:27.044226
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open('constructor_test.yml', 'r')
    ansible_loader = AnsibleLoader(stream)
    ansible_loader.get_data()
    stream.close()

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-11 09:28:30.118461
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, file_name='fake.yaml')
    assert loader.file_name == 'fake.yaml'
    loader.file_name = None
    assert loader.file_name == None

# Generated at 2022-06-11 09:28:35.805439
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
    - hosts: localhost
      tasks:
        - command: /bin/false
          register: result
          ignore_errors: yes
        - command: /bin/false
          when: result.rc == 5
          register: result2
    '''
    loader = AnsibleLoader(stream)
    for item in loader:
        pass
    assert loader is not None

# Generated at 2022-06-11 09:28:38.455698
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # import pdb; pdb.set_trace()
    s = """
        ---
        # This is a list
        - "This is a string in a list"
        - 2343
        - {'foo': 'bar'}
        -
            - "This is another string in a list"
            - [12, 'bar', {'foo': 'baz'}]
    """
    loader = AnsibleLoader(s)
    loader.get_single_data()

# Generated at 2022-06-11 09:28:46.922868
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=too-many-locals
    loader = AnsibleLoader(None, 'dummy')
    # The following can't be tested because they are private
    #assert loader.resolver._yaml_implicit_resolvers ==  {}
    #assert loader.resolver._tag_classes == {}
    assert loader.resolver._path_cache == {}
    assert loader.resolver._path_cache_all_exact_key == {}
    assert loader.resolver._path_cache_all_inexact_key == {}
    assert loader.resolver._path_cache_value == {}
    #assert loader.resolver._cache_version == -1
    #assert loader.resolver._key_version == -1
    assert loader.resolver._cache_misses == 0
    #assert loader.resolver._cache

# Generated at 2022-06-11 09:29:05.659053
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yamlstr = u"""
        # example
        name:
            # details
            family: Smith   # very common
            given: Alice    # one of the siblings
        """
    loader = AnsibleLoader(yamlstr)
    data = loader.get_single_data()
    if not data.get('name'):
        print('data = %s' % data)
        raise AssertionError
    if not data['name'].get('given'):
        print('data = %s' % data)
        raise AssertionError
    if not data['name']['given'] == 'Alice':
        print('data = %s' % data)
        raise AssertionError

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:29:10.989664
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    raw_doc = b'---\na: 1\nb: 2\n'
    loader = AnsibleLoader(yaml.CSafeLoader(raw_doc))
    data = loader.get_single_data()
    assert issubclass(type(data), AnsibleBaseYAMLObject)
    assert data.a == 1
    assert data.b == 2

# Generated at 2022-06-11 09:29:19.314970
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    file_name = '/etc/ansible/hosts'
    vault_secrets = ['123', '456']
    stream = '{ ansible: ansible }'
    loader = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)
    assert loader.file_name is file_name
    assert loader.vault_secrets is vault_secrets

# Generated at 2022-06-11 09:29:25.594887
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """Test the AnsibleLoader class"""
    '''
    # We currently have no way to test this Class, as it's mostly an alias for
    # other classes in the yaml library.
    stream = StringIO()
    file_name = 'test'
    vault_secrets = {'foo':'bar'}
    loader = AnsibleLoader(stream, file_name, vault_secrets)
    '''
    pass

# Generated at 2022-06-11 09:29:27.317877
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader  # silence pyflakes

# Generated at 2022-06-11 09:29:40.418306
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = """
    host1:
        vars:
            var_x: "var_x"
            var_y: "var_y"
            var_z: "var_z"
    host2:
        vars:
            var_x: "var_x"
            var_y: "var_y"
            var_z: "var_z"
    """
    data = AnsibleLoader(yaml_str).get_single_data()

# Generated at 2022-06-11 09:29:46.108669
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert (hasattr(AnsibleLoader, '__init__') and
            callable(AnsibleLoader.__init__)), 'AnsibleLoader.__init__ is not a method'
    assert (hasattr(AnsibleLoader, 'construct_yaml_map') and
            callable(AnsibleLoader.construct_yaml_map)), 'AnsibleLoader.construct_yaml_map is not a method'
    assert (hasattr(AnsibleLoader, 'construct_yaml_seq') and
            callable(AnsibleLoader.construct_yaml_seq)), 'AnsibleLoader.construct_yaml_seq is not a method'

# Generated at 2022-06-11 09:29:48.189342
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from .test_loader import verify_class_api
    verify_class_api(AnsibleLoader)

# Generated at 2022-06-11 09:29:58.078604
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        from io import BytesIO
    except ImportError:
        from StringIO import StringIO as BytesIO

    ansible_yaml = """
        - hosts:
            - localhost
          tasks:
            - debug:
                msg: foo
    """
    stream = BytesIO(ansible_yaml)
    file_name = "test.yml"
    vault_secrets = "test"
    loader = AnsibleLoader(stream,file_name,vault_secrets)
    print(loader)

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:29:58.723161
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:30:16.330668
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, 'construct_yaml_map')

# Generated at 2022-06-11 09:30:27.002644
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
host_a:
  - group: group_1
  - group: group_2
host_b:
   - group: group_1
   - group: group_3
"""
    stream = AnsibleLoader(data, file_name='/somefile')
    result = stream.get_single_data()

    assert result.get('host_a')[0].get('group') == 'group_1'
    assert result.get('host_a')[1].get('group') == 'group_2'
    assert result.get('host_b')[0].get('group') == 'group_1'
    assert result.get('host_b')[1].get('group') == 'group_3'

# Generated at 2022-06-11 09:30:29.937403
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    def test_AnsibleLoader_init(self):
        # This should not throw an exception
        AnsibleLoader(None, file_name=None, vault_secrets=None)

# Generated at 2022-06-11 09:30:37.165959
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''---
a: 1 b:   2
c:
  - d
  - e
f:
- g
- h
'''
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == {'a': '1 b', 'c': ['d', 'e'], 'f': ['g', 'h']}
    assert loader.get_single_data() == {'a': '1 b', 'c': ['d', 'e'], 'f': ['g', 'h']}


# Generated at 2022-06-11 09:30:39.085449
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-11 09:30:40.310018
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ""
    loader = AnsibleLoader(stream)
    assert loader.stream == stream

# Generated at 2022-06-11 09:30:52.623049
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import time
    #from ansible.parsing.yaml import AnsibleLoader
    import textwrap

    # We test the __init__ method of AnsibleLoader class
    # Create an object with a file
    file_name = './test.yaml'
    with open(file_name, 'w') as output_file:
        output_file.write(textwrap.dedent("""
        ---
        - hosts: localhost
          tasks:
            - shell: echo "Hello world"
        """))
    stream = open(file_name, 'r')
    ansible_loader = AnsibleLoader(stream)
    # ansible_loader.__init__() does not return anything
    # so we test the attributes of the class
    assert ansible_loader.file_name == file_name
    assert ansible

# Generated at 2022-06-11 09:30:53.054579
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:30:56.650684
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader_bytes = AnsibleLoader(b'')
    assert(vars(loader_bytes) == vars(AnsibleLoader(b'')))
    loader_str = AnsibleLoader(u'')
    assert(vars(loader_str) == vars(AnsibleLoader(u'')))
    assert(vars(loader_str) == vars(AnsibleLoader('')))

# Generated at 2022-06-11 09:31:08.158488
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedBytes


# Generated at 2022-06-11 09:31:47.560807
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    input_string = """
        # test
        - name: foobar
        with_items: [1,2,3]
    """
    input_stream = open("test.yml", "w")
    input_stream.write(input_string)
    input_stream.close()

    test_loader = AnsibleLoader(input_stream)
    loaded_data = test_loader.get_single_data()

    assert loaded_data == [{'with_items': [1, 2, 3], 'name': 'foobar'}]

# Generated at 2022-06-11 09:31:54.458844
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import datetime
    from io import BytesIO
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping

    input_list = [
        "---",
        "stuff:",
        "  - things",
        "  - and: things",
    ]

    input_string = "\n".join(input_list)

    if sys.version_info < (3,):
        input_string = unicode(input_string)

    stream = BytesIO(input_string.encode('utf-8'))

    data = AnsibleLoader(stream, "test").get_data()

    assert isinstance(data, type(dict()))
    assert ('stuff' in data)

    stuff = data["stuff"]
    assert isinstance(stuff, AnsibleSequence)


# Generated at 2022-06-11 09:31:58.524797
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.loader
    assert issubclass(ansible.parsing.yaml.loader.AnsibleLoader, Parser)
    assert issubclass(ansible.parsing.yaml.loader.AnsibleLoader, AnsibleConstructor)
    #assert issubclass(ansible.parsing.yaml.loader.AnsibleLoader, Resolver)

# Generated at 2022-06-11 09:31:59.091069
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:32:04.671839
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test 1:
    # File name exists and is valid
    # vault_secrets is valid
    file_name = '/Users/ansible/ansible-2.1-beta2/test/sanity/targets/test_constructor.txt'
    vault_secrets = '#!vault |$ANSIBLE_VAULT;1.1;AES256;ansible\n32376638333136633836333538373730393939383733353034656236643935383635343465663661\n3532343430383465353939393065653932333135313531353135313531353135313531353135313531\n313531353135313531353135313531353135\n'
    loader = Ans

# Generated at 2022-06-11 09:32:08.659086
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.loader
    assert(ansible.parsing.yaml.loader.AnsibleLoader)
    #assert(object, ansible.parsing.yaml.loader.AnsibleLoader)


# Generated at 2022-06-11 09:32:11.143706
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''[a,b,c]'''
    loader = AnsibleLoader(data)
    value = loader.get_single_data()
    assert value == ['a', 'b', 'c']

# Generated at 2022-06-11 09:32:20.657225
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    yaml_str = '''
    roles:
    - role: myrole
      tasks_from: mytask
    '''

    from ansible.parsing.yaml.objects import AnsibleUnicode

    fake_filename = 'fake_filename'
    fake_vault_secrets = ['fake_vault_secret']

    # create an instance to test
    ansibleLoader = AnsibleLoader(yaml_str, fake_filename, fake_vault_secrets)

    assert isinstance(ansibleLoader.file_name, AnsibleUnicode)
    assert ansibleLoader.file_name == fake_filename
    assert ansibleLoader.vault_secrets == fake_vault_secrets

# Generated at 2022-06-11 09:32:21.336632
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:32:29.987138
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''Unit test for the AnsibleLoader constructor'''
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString
    from ansible.parsing.vault import VaultLib

    loader = AnsibleLoader
    if HAS_LIBYAML:
        libyaml_loader = Parser
        assert(loader.__bases__[0] is libyaml_loader)
    else:
        pyyaml_reader = Reader
        pyyaml_scanner = Scanner
        pyyaml_parser = Parser
        pyyaml_composer = Composer
        assert(loader.__bases__[0] is pyyaml_reader)

# Generated at 2022-06-11 09:33:39.705338
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  # check default and empty constructor
  l = AnsibleLoader(None)
  assert l.lines == None
  assert l.file_name == None
  assert l.vault_secrets == None

# Generated at 2022-06-11 09:33:40.291331
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Constructing an AnsibleLoader
    AnsibleLoader(None)

# Generated at 2022-06-11 09:33:44.179020
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        from StringIO import StringIO
    except:
        from io import StringIO

    loader = AnsibleLoader(StringIO(''))

    assert isinstance(loader, dict)

# Make sure that the module works with `python -m`
if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:33:52.662071
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Note: AnsibleLoader is just a wrapper around yaml.constructors.SafeConstructor and yaml.resolver.Resolver
    #       to customize the behaviour of loading yaml objects.
    #       It basically replaces the SafeConstructor part of yaml loading
    #       with a custom constructor that can handle the ansible specific tags.
    #       The resolver part is to add the ansible specific tag prefixes to the resolver
    #       so that it is able to detect and load such objects.

    # The test for the custom constructor is tested in test_AnsibleConstructor
    # The test for the custom resolver is tested in test_AnsibleResolver

    pass

# Generated at 2022-06-11 09:34:02.878285
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import BytesIO
    from yaml import load
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.yaml import _load_yaml_from_bytes, _load_yaml_from_bytes_with_ordered_dicts

    # assert that the class AnsibleLoader was created and inherited properly
    assert issubclass(AnsibleLoader, object)
    assert issubclass(AnsibleLoader, Reader)
    assert issubclass(AnsibleLoader, Scanner)
    assert issubclass(AnsibleLoader, Parser)
    assert issubclass(AnsibleLoader, Composer)
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert issubclass(AnsibleLoader, Resolver)

    # assert that unencrypted yaml

# Generated at 2022-06-11 09:34:04.672059
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert(hasattr(loader, 'FileName'))

# Generated at 2022-06-11 09:34:07.159135
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class MockLoader(AnsibleLoader):
        pass
    loader = MockLoader.from_string('{% foo %}')
    assert MockLoader == type(loader)

# Generated at 2022-06-11 09:34:07.724040
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:34:09.319331
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

    yaml = io.StringIO("")
    AnsibleLoader(yaml)

# Generated at 2022-06-11 09:34:10.942785
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    if HAS_LIBYAML:
        assert True
    else:
        assert True
