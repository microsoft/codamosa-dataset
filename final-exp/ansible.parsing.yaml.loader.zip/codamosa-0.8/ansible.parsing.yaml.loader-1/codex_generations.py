

# Generated at 2022-06-11 09:25:42.489848
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Ensures that the modules load
    '''
    assert hasattr(AnsibleLoader, '_filename')
    assert hasattr(AnsibleLoader, '_vault_secrets')
    assert hasattr(AnsibleLoader, "construct_yaml_map")
    assert hasattr(AnsibleLoader, "construct_yaml_seq")
    assert hasattr(AnsibleLoader, "construct_undefined")
    assert hasattr(AnsibleLoader, "get_single_data")
    assert hasattr(AnsibleLoader, 'compose_node')
    assert hasattr(AnsibleLoader, 'construct_sequence')
    assert hasattr(AnsibleLoader, 'construct_mapping')

# Generated at 2022-06-11 09:25:44.424462
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, '__init__')
    assert callable(AnsibleLoader.__init__)



# Generated at 2022-06-11 09:25:49.342566
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader

    a = AnsibleLoader(file_name='/dev/null')
    assert hasattr(a, '_reader')
    assert hasattr(a, '_scanner')
    assert hasattr(a, '_parser')
    assert hasattr(a, '_composer')
    assert hasattr(a, '_resolver')

# Generated at 2022-06-11 09:25:51.033144
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-11 09:26:02.731793
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    import unittest

    class TestAnsibleLoader(unittest.TestCase):
        def setUp(self):
            self.loader = AnsibleLoader('')

            # This is needed because when get_mark() is called the Reader object
            # is not yet initialized thus returning a None mark instead of a
            # Mark object.
            class ReaderMockObj(object):
                def __init__(self):
                    self.line = -1
                    self.column = -1

                def get_mark(self):
                    return ReaderMockObj()

            self.loader.reader = ReaderMockObj()

        def test_anchor_duplication(self):
            test_

# Generated at 2022-06-11 09:26:08.521585
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
---
foo:
- bar:
  - baz:
    - 1
  - 2
  - 3
- 4
'''
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == {'foo': [[{'baz': [1]}, 2, 3], 4]}

# Generated at 2022-06-11 09:26:18.339586
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert isinstance(loader, AnsibleConstructor)
    assert isinstance(loader.constructor.add_constructor('', None), basestring)
    assert isinstance(loader.constructor.add_multi_constructor('', None), basestring)
    assert isinstance(loader.constructor.add_multi_representer('', None), basestring)
    assert isinstance(loader.constructor.add_representer('', None), basestring)
    assert not loader.constructor.safe_constructors
    assert not loader.constructor.safe_constructors_types
    assert not loader.constructor.safe_multidicts
    assert not loader.constructor.safe_representers
    assert not loader.constructor.safe_representers_types

# Generated at 2022-06-11 09:26:32.306518
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    data = u'[{"foo": "bar"}, {"foo": "baz"}]'
    loader = AnsibleLoader(data, file_name='(none)')
    obj = loader.get_single_data()
    assert isinstance(obj[0]['foo'], AnsibleUnicode)

    data = u'{"foo": "bar"}'
    loader = AnsibleLoader(data, file_name='(none)')
    obj = loader.get_single_data()
    assert isinstance(obj['foo'], AnsibleUnicode)


# Generated at 2022-06-11 09:26:41.355553
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml

    # Successfully create an instance
    ansible_loader = AnsibleLoader(None)
    assert isinstance(ansible_loader, yaml.Loader)

    # Successfully create an instance with a vault file passed in
    ansible_loader = AnsibleLoader(None, vault_secrets=[])
    assert isinstance(ansible_loader, yaml.Loader)

    # Successfully create an instance with a vault file passed in
    ansible_loader = AnsibleLoader(None, vault_secrets=[], file_name="")
    assert isinstance(ansible_loader, yaml.Loader)

# Generated at 2022-06-11 09:26:50.250810
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    import sys

    source = """
string: "string"
literal_string: 'string'
integer: 1
float: 1.1
exponent: 3.14e10
true_boolean: True
false_boolean: False
none: null
array:
- 1
- 2
- 3
- false
- true
complex:
  -
  - 1
  - 2
  - 3
  - false
  - true
  - string
  - string
hash:
  key1: string
  key2: string
  key3:
    - 1
    - 2
    - 3
  key4:
    subhash:
      key1: value1
      key2: value2
"""
    loader = AnsibleLoader(source)

# Generated at 2022-06-11 09:26:58.168946
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    test_text = vault.encrypt('test')
    data = AnsibleLoader('').get_single_data(test_text)
    assert data == 'test'

# Generated at 2022-06-11 09:27:00.709712
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import yaml
    stream = io.BytesIO(b"""
        ---
        foo: 1
        bar: 2
        baz: 3
    """)
    yaml.load(stream, Loader=AnsibleLoader)

# Generated at 2022-06-11 09:27:02.109922
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    fd = open('examples/sample.yml')
    AnsibleLoader(fd)

# Generated at 2022-06-11 09:27:04.077144
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader(stream=None)
    assert isinstance(obj, AnsibleLoader)

# Generated at 2022-06-11 09:27:16.914637
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import re
    import yaml

    stream = '''\
- {a: 01, b: 02}
- {a: 11, b: 12}
'''

    loader = AnsibleLoader(stream)
    assert loader.get_single_data() == [{u'a': 1, u'b': 2}, {u'a': 11, u'b': 12}]

    stream = '''\
- {a: 01, b: 02}
- {a: 11, b: 12}
'''

    loader = AnsibleLoader(stream, vault_secrets=[b'a'], file_name='example_inventory.yml')

# Generated at 2022-06-11 09:27:17.495072
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:27:29.528152
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import cStringIO
    test_data = '''
    test_data:
        key1: value1
        key2:
            - foo
            - bar
            - baz
        key3: somevar
    test_hosts:
        host1:
            key1: value11
            key2: value12
            key3: value13
        host2:
            key1: value21
            key2: value22
            key3: value23
    '''
    test_stream = cStringIO.StringIO()
    test_stream.write(test_data)
    test_stream.seek(0)
    test_file_name = 'test_file'
    test_vault_secrets = 'test_secrets'
    # Storing the reference for AnsibleLoader() constructor for class AnsibleLoader
    ans

# Generated at 2022-06-11 09:27:30.042316
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:27:32.657470
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # should accept a yaml stream
    loader = AnsibleLoader('')
    assert loader.stream

# Generated at 2022-06-11 09:27:45.539454
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import BytesIO, StringIO
    import yaml.error
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.modules.system.ping import check_ping
    from ansible.module_utils.six import string_types

    # This doesn't have to be unicode, but if so check for output being unicode
    ansible_loader = AnsibleLoader(u"")
    assert isinstance(ansible_loader.get_single_data(), AnsibleUnicode)

    # This doesn't have to be unicode, but if so check for output being unicode
    ansible_loader = AnsibleLoader(b"")

# Generated at 2022-06-11 09:27:49.896911
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  # Assert that __init__ is the same for PyYAML>=4.1.0 and PythonYAML<4.1.0
  assert repr(AnsibleLoader.__init__) == repr(Resolver.__init__)

# Generated at 2022-06-11 09:28:00.822546
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from os.path import abspath, dirname, join
    from sys import version_info

    sample_yaml = abspath(join(dirname(__file__), 'module_unittests', 'sample.yml'))

    if version_info[0] >= 3:
        from io import StringIO
        from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
        stream = StringIO(AnsibleVaultEncryptedUnicode.from_plaintext(open(sample_yaml, 'rb').read()))
    else:
        from StringIO import StringIO
        stream = StringIO(open(sample_yaml, 'rb').read())

    loader = AnsibleLoader(stream)
    assert loader is not None

# Generated at 2022-06-11 09:28:03.891916
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        my_loader = AnsibleLoader('')
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-11 09:28:15.240554
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-11 09:28:22.575200
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # We only do a simple unit test here because other tests need to rely on
    # yaml.load(..., AnsibleLoader)
    # and the AnsibleLoader class needs to be defined before that.
    yaml_obj = AnsibleLoader('{ a: b }').get_single_data()
    assert 'a' in yaml_obj
    assert yaml_obj['a'] == 'b'

# Generated at 2022-06-11 09:28:26.181662
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, file_name="test_filename.yaml")
    assert loader._file_name == "test_filename.yaml"
    assert loader._vault_secrets == None


# Generated at 2022-06-11 09:28:31.788765
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = 'string'
    file_name = 'file_name'
    vault_secrets = 'vault_secrets'

    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)
    assert stream == ansible_loader.stream
    assert file_name == ansible_loader.file_name
    assert vault_secrets == ansible_loader.vault_secrets

# Generated at 2022-06-11 09:28:38.755931
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.module_utils.common.yaml import Parser
    from ansible.parsing.yaml.loader import AnsibleLoader

    assert issubclass(AnsibleLoader, Parser)
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert issubclass(AnsibleLoader, Resolver)

# Generated at 2022-06-11 09:28:40.604625
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader
    assert AnsibleLoader.__doc__

# Generated at 2022-06-11 09:28:44.827887
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open(os.path.dirname(__file__) + '/../../lib/ansible/playbooks/test_playbook.yml', 'r')
    loader = AnsibleLoader(stream)

    # Check instance variables of class AnsibleLoader
    assert hasattr(loader, '_extended_mark_globals')
    assert hasattr(loader, '_base_mark_globals')
    assert hasattr(loader, '_base_loader')
    assert hasattr(loader, '_file_name')

# Generated at 2022-06-11 09:28:51.033750
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader



# Generated at 2022-06-11 09:28:55.704415
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Create the loader
    loader = AnsibleLoader(stream='{"a": "b"}', file_name=None, vault_secrets=None)

    # Load the YAML data
    data = loader.get_single_data()
    assert type(data) is dict
    assert data == {'a': 'b'}

# Generated at 2022-06-11 09:28:57.923342
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    d = AnsibleLoader(None, file_name='test').get_single_data()
    assert isinstance(d, AnsibleConstructor)

# Generated at 2022-06-11 09:29:05.535129
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    file_name = "filename"
    vault_secrets = "vault_secrets"
    stream = open(r'ansible\parsing\yaml\dumper.py')
    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)
    print(vars(ansible_loader))
    print(ansible_loader.get_single_data())

if __name__ == '__main__':
    print('test AnsibleLoader')
    test_AnsibleLoader()

# Generated at 2022-06-11 09:29:13.849516
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansibleloader = AnsibleLoader('[{foo: 2}, 5, 2]', 'test_AnsibleLoader')
    if not isinstance(ansibleloader, (Parser, AnsibleConstructor, Resolver)):
        raise AssertionError("AnsibleLoader should be a Parser, AnsibleConstructor, Resolver")
    ansibleloader.get_single_data()
    if not isinstance(ansibleloader._yaml_base_reader, Reader):
        raise AssertionError("AnsibleLoader._yaml_base_reader should be a Reader")
    if not isinstance(ansibleloader.dispatcher, Composer):
        raise AssertionError("AnsibleLoader.dispatcher should be a Composer")
    ansibleloader.compose_node("null", "null")
    ansibleloader.compose_list

# Generated at 2022-06-11 09:29:14.745110
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:29:19.442511
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    assert issubclass(AnsibleLoader, DataLoader)

# Generated at 2022-06-11 09:29:21.225418
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(stream=None, file_name=None, vault_secrets=None)

# Generated at 2022-06-11 09:29:28.694761
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO

    test_string = """
    ---
    - hosts: localhost
      vars:
        var1: "This is a Variable"
      tasks:
        - name: test print
          debug: msg="This is a test."
    """
    result = AnsibleLoader(StringIO(test_string)).get_single_data()
    assert result[0]['hosts'] == 'localhost'
    assert result[0]['vars']['var1'] == 'This is a Variable'
    assert result[0]['tasks'][0]['name'] == 'test print'
    assert result[0]['tasks'][0]['debug']['msg'] == 'This is a test.'

# Generated at 2022-06-11 09:29:37.941170
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
    - { role: common, when: ansible_distribution == 'Ubuntu' }
    - role: specific_for_{{ ansible_distribution }}
    '''
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert isinstance(data, list)
    assert data[0]['role'] == 'common'
    assert data[1]['role'] == 'specific_for_{{ ansible_distribution }}'


# Generated at 2022-06-11 09:29:59.863999
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import EthicalYamlScanner

    # this test might fail for different Python versions due to different unicode representations
    # for example, Python2 uses 'u' prefix and Python3 does not
    stream = u'[b\u00f6\u00f6]\n{c: d}'
    assert stream[0] == u'['
    assert stream[3] == u'\u00f6'

    # stream used as argument to constructor
    loader = AnsibleLoader(stream)
    loader.get_single_data()

    # stream not used as argument to constructor
    loader = AnsibleLoader(None)


# Generated at 2022-06-11 09:30:01.126226
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None)

# Generated at 2022-06-11 09:30:11.313001
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import time
    import os
    import sys
    import io

    if sys.version_info[0] >= 3:
        from io import StringIO as StringIO
    else:
        from io import BytesIO as StringIO

    filename = os.path.normpath(os.path.join(os.getcwd(), __file__))

    res = AnsibleLoader(StringIO(), __file__).get_single_data()
    assert res == None

    res = AnsibleLoader(StringIO(), __file__).get_single_data()
    assert res == None

    res = AnsibleLoader(StringIO("{}"), __file__).get_single_data()
    assert res == {}

    res = AnsibleLoader(StringIO("---\n- hosts: all"), __file__).get_single_data()

# Generated at 2022-06-11 09:30:12.641135
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, Parser)
    assert isinstance(loader, AnsibleConstructor)
    assert isinstance(loader, Resolver)

# Generated at 2022-06-11 09:30:13.645912
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:30:23.331662
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing import vault
    import yaml
    yl = AnsibleLoader(yaml.load('---\n[vault]\npassword: test'), vault_secrets=vault.VaultSecret())
    data = yl.get_single_data()
    assert data == {'[vault]': {'password': 'test'}}


# Temporary workaround to deal with the fact that resolver is an old-style class
from yaml.constructor import ConstructorError
from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
from ansible.parsing.yaml.dumper import AnsibleDumper
from ansible.parsing.yaml.objects import AnsibleSequence, AnsiBleUnicode


# Generated at 2022-06-11 09:30:31.435458
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
    - hosts: all
      tasks:
      - name: install ntp
        apt: name=ntp state=latest
    '''

    from StringIO import StringIO
    loader = AnsibleLoader(StringIO(stream))
    data = loader.get_single_data()

    assert isinstance(data, list)
    assert len(data) == 1

    play = data[0]
    assert 'hosts' in play
    assert 'tasks' in play

# Generated at 2022-06-11 09:30:40.630566
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import get_file_vault_secret
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-11 09:30:52.957218
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Load empty yaml file to class AnsibleLoader
    r = AnsibleLoader(open(__file__.split('.')[0] + '.yml'))
    y = r.get_single_data()
    assert y['data'] == 123

    # Load yaml file with vault secret
    r = AnsibleLoader(open(__file__.split('.')[0] + '.yml'), vault_secrets=[('vault', 'password')])
    y = r.get_single_data()
    assert y['data'] == 'password'

    # Load yaml file with vault secret
    r = AnsibleLoader(open(__file__.split('.')[0] + '.yml'), vault_secrets=[('vault', 'password')])
    y = r.get_single_data()

# Generated at 2022-06-11 09:30:57.793994
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    y = '''- hosts: all
  tasks:
  - debug: msg="System {{ inventory_hostname }} has uuid {{ ansible_product_uuid }}"'''
    loader = AnsibleLoader(y)
    res = loader.get_single_data()
    assert (res[0]['tasks'][0]['debug']['msg'] == "System {{ inventory_hostname }} has uuid {{ ansible_product_uuid }}")


# Generated at 2022-06-11 09:31:21.609646
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.module_utils.common.yaml import HAS_LIBYAML
    if not HAS_LIBYAML:
        return

    class C(AnsibleLoader):
        pass

    c = C('[]')
    assert c.get_single_data() is None

# Generated at 2022-06-11 09:31:25.985643
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader
    with open("C:\\Users\\vinay.v\\Desktop\\Project\\ansible-practice\\inventory\\hosts", "r") as mystream:
        loader = AnsibleLoader(mystream)
        data = loader.get_single_data()
        print(data)

# Generated at 2022-06-11 09:31:26.593802
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:31:38.172986
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-11 09:31:39.196985
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    a = AnsibleLoader()
    assert a is not None

# Generated at 2022-06-11 09:31:44.097175
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml_str = """
- debug:
    msg: "System {{ inventory_hostname }} has uuid {{ansible_product_uuid}}"
"""

    # This test doesn't actually test anything
    yaml.load(yaml_str, Loader=AnsibleLoader)

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-11 09:31:45.047226
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# Generated at 2022-06-11 09:31:51.090877
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from sys import exc_info
    from io import StringIO
    from traceback import extract_tb

    yaml_test_data = u'''
    - hosts: localhost
      tasks:
        - name: first task
          debug: msg="{{ look_at_me | quote }}"
          tags: [one,two,three]
    '''

    try:
        AnsibleLoader(StringIO(yaml_test_data)).get_single_data()
    except NotImplementedError:
        raise AssertionError(extract_tb(exc_info()[2]))


# Generated at 2022-06-11 09:31:52.583417
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None)
    assert isinstance(loader, Parser)
    assert isinstance(loader, AnsibleConstructor)

# Generated at 2022-06-11 09:31:57.971528
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=unused-variable
    data = '''
    blocks:
        -
            block1: val1
        - block2: val2
        - { block3:'val3' }
    '''

    data_loaded = AnsibleLoader(data).get_data()
    assert data_loaded['blocks'][0]['block1'] == 'val1'
    assert data_loaded['blocks'][1]['block2'] == 'val2'
    assert data_loaded['blocks'][2]['block3'] == 'val3'


# Generated at 2022-06-11 09:32:40.480669
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from StringIO import StringIO
    from yaml.error import YAMLError
    try:
        AnsibleLoader(StringIO(u"---\n- 1\n- 2\n- 3\n"))
    except YAMLError:
        assert False

# Generated at 2022-06-11 09:32:49.688227
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-11 09:32:53.283850
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # AnsibleLoader class test
    stream = '''
     a: [ 1, 2 ]
     b:
       c: 3
    '''
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {
        'a': [1, 2],
        'b': {
            'c': 3
        }
    }

# Generated at 2022-06-11 09:32:54.427176
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# Generated at 2022-06-11 09:33:08.214245
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import BytesIO as BytesIO
    from yaml.composer import Composer
    from yaml.constructor import ConstructorError
    from yaml.reader import Reader
    from yaml.resolver import Resolver
    from yaml.scanner import Scanner
    import ansible.parsing.yaml.objects

    class MockReader(Reader):
        def __init__(self, stream):
            Reader.__init__(self, stream)
    class MockScanner(Scanner):
        def __init__(self):
            Scanner.__init__(self)
    class MockComposer(Composer):
        def __init__(self):
            Composer.__init

# Generated at 2022-06-11 09:33:09.377530
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:33:12.396608
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    d = dict(a=1, b=2, c=3)
    yaml = AnsibleLoader(d)
    assert yaml is not None

# Generated at 2022-06-11 09:33:14.927792
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open("data/files/test_yaml.yml")
    loader = AnsibleLoader(stream)
    assert(loader is not None)

# Generated at 2022-06-11 09:33:16.064136
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-11 09:33:20.901668
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
    a: 1
    b:
      - 1
      - 2
      - 3
    c:
      d:
      - 4
      - 5
      - 6
    '''

    parser = AnsibleLoader(stream)
    assert parser is not None
    assert parser.file_name is None
    assert parser.vault_secrets is None

    # Test the __iter__ method
    for yaml in parser:
        assert yaml is not None
        assert yaml == {'a': 1, 'b': [1, 2, 3], 'c': {'d': [4, 5, 6]}}

# Generated at 2022-06-11 09:34:44.416143
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

    stream = io.StringIO(u"""
---
a:
  b: false
  c: foo
  # this is a comment
   - '{{ my_var }}'
   - '{% include "my_include" %}'
   - foo
  d:
    e:
      - yes
    f:
      - no
""")

    AnsibleLoader(stream)

# Generated at 2022-06-11 09:34:45.055593
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:34:54.360948
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret


# Generated at 2022-06-11 09:34:56.147023
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("---test")
    assert isinstance(loader, AnsibleConstructor)

# Generated at 2022-06-11 09:35:03.719964
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    documents = '''
1) a scalar
2) a list:
   - item1
   - item 2
3) a dict:
   k1: a
   k2: b
'''
    documents = [doc for doc in documents.split('\n') if doc]
    stream = '\n'.join(documents)

    data = AnsibleLoader(stream).get_data()

    assert data[0] == 1
    assert data[1] == ['a scalar', 'a list:']
    assert data[2] == ['item1', 'item 2']
    assert data[3] == 'a dict:'
    assert data[4] == {'k1': 'a', 'k2': 'b'}

    # The main purpose of this test case is to check whether the
    # AnsibleConstructor correctly instantiates a

# Generated at 2022-06-11 09:35:06.066139
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    doc = AnsibleLoader(stream=None, file_name=None, vault_secrets=None).get_single_data()
    assert doc == {}

# Generated at 2022-06-11 09:35:13.965234
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml import objects
    import ansible.parsing.yaml.objects
    import sys

    if sys.version_info >= (3,):
        unicode = str

    class TestVarsModule(object):
        def __init__(self, values=None):
            if values is None:
                values = {}
            self._values = values

        def get_vars(self, loader, path, entities):
            results = []
            for entity in entities:
                if entity in self._values:
                    results.append(self._values[entity])
                else:
                    results.append(None)
            return results

    # Tests for AnsibleConstructor.construct_python_str

# Generated at 2022-06-11 09:35:17.969444
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, None, None)
    assert loader.__class__.__name__ == 'AnsibleLoader'
    assert loader.__module__ == 'ansible.parsing.yaml.objects'
    assert loader.file_name == None
    assert loader.vault_secrets == None

# Generated at 2022-06-11 09:35:25.168560
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import YAML
    import io
    from collections import OrderedDict

    yaml = YAML(typ='safe')
    yaml.Loader = AnsibleLoader
    assert issubclass(yaml.Loader, Reader)
    assert issubclass(yaml.Loader, Scanner)
    assert issubclass(yaml.Loader, Parser)
    assert issubclass(yaml.Loader, Composer)
    assert issubclass(yaml.Loader, AnsibleConstructor)
    assert issubclass(yaml.Loader, Resolver)


# Generated at 2022-06-11 09:35:26.047358
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader