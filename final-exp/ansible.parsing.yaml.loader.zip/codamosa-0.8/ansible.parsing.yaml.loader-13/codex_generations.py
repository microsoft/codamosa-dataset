

# Generated at 2022-06-11 09:25:44.053091
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    data = """
    foo: 1
    bar:
      - baz
      -
        - hello
        - world
      - {hi: there}
    """

    loader = AnsibleLoader(data)
    datastructure = loader.get_single_data()
    assert type(datastructure) == dict
    assert type(datastructure['foo']) == int
    assert type(datastructure['bar']) == list
    assert type(datastructure['bar'][0]) == AnsibleUnicode
    assert type(datastructure['bar'][1]) == list
    assert type(datastructure['bar'][2]) == dict

# Generated at 2022-06-11 09:25:45.274639
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.AnsibleLoader = AnsibleLoader

# Generated at 2022-06-11 09:25:53.636903
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.utils.vars import combine_vars

    # Prepare

# Generated at 2022-06-11 09:25:54.232043
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:26:00.806510
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert not HAS_LIBYAML
    lines = [
        '- { a: 1 }',
        '- { b: 2 }',
    ]

    stream = '\n'.join(lines)
    import StringIO
    f = StringIO.StringIO(stream)
    ansible_loader = AnsibleLoader(stream=f)
    print(repr(ansible_loader))
    #assert False, 'Test AnsibleLoader is not implemented'

# Generated at 2022-06-11 09:26:05.198773
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import StringIO # pylint: disable=import-error
    stream = StringIO.StringIO(u"---\n{}")
    loader = AnsibleLoader(stream)
    assert loader is not None

# Generated at 2022-06-11 09:26:16.178972
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.utils.vars import combine_vars
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault_secret = '$ANSIBLE_VAULT;1.1;AES256'
    vault_data = u'\nhello world\n'
    vault_secret_string = vault_secret + '\n' + vault_data

    # class AnsibleVaultEncryptedUnicode
    assert str(AnsibleVaultEncryptedUnicode(u'hello world', vault_secret)) == 'hello world'

    loader = AnsibleLoader(vault_secret_string)

# Generated at 2022-06-11 09:26:17.553925
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  assert hasattr(AnsibleLoader, '__init__')


# Generated at 2022-06-11 09:26:30.012658
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    loader = AnsibleLoader('')
    assert isinstance(loader, AnsibleLoader)

# class AnsibleLoader:
#     def __init__(self, stream):
#         self._root = None
#         self._current = None
#         self._stream = stream
#         self.deserialize()
#
#     def deserialize(self):
#         for data in yaml.load_all(self._stream):
#             if self._root is None:
#                 self._root = data
#             else:
#                 self._root.update(data)
#
#     @classmethod
#     def load(cls, stream):
#         return cls(stream)._root

# Generated at 2022-06-11 09:26:31.299211
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader


# Generated at 2022-06-11 09:26:45.295953
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import from_yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    contents = """
    a: 1
    b:
      - 2
      - 2
      - 2
      - 2
      - 2
      - 2
      - 2
      - 2
      - 2
      - 2
      - 2
      - 2
      - 2
      - 2
      - 2
      - 2
      - 2
      - 2
      - 2
      - 2
    c: 3
    """

    # Append some encrypted data
    vault = VaultLib([])
    vault_password = "secret"


# Generated at 2022-06-11 09:26:58.667832
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Test the __init__ method.
    # Pass invalid values for stream.
    try:
        AnsibleLoader(None)
    except Exception as e:
        assert isinstance(e.__context__, TypeError)

    try:
        AnsibleLoader(stream='not a stream')
    except Exception as e:
        assert isinstance(e.__context__, TypeError)

    # Pass valid values.
    AnsibleLoader(stream=open('test/test.yml'))
    AnsibleLoader(stream=open('test/test.yml'), file_name='test/test.yml')
    AnsibleLoader(stream=open('test/test.yml'), file_name='test/test.yml', vault_secrets='vault_secret')

    # Test the _construct_mapping method.
    # Pass invalid values

# Generated at 2022-06-11 09:27:00.775245
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test invarid
    assert AnsibleLoader("") == AnsibleLoader("")
    # Test valid
    assert AnsibleLoader("") != AnsibleLoader("A")

# Generated at 2022-06-11 09:27:10.341383
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    class TestFile(str):
        name = 'test.yml'

    loader = AnsibleLoader(TestFile('test'))
    assert loader.file_name == 'test.yml'
    assert loader.vault_secrets is None

    loader = AnsibleLoader(TestFile('test'), 'test2.yml')
    assert loader.file_name == 'test2.yml'

    loader = AnsibleLoader(TestFile('test'), 'test2.yml', vault_secrets='secrets')
    assert loader.file_name == 'test2.yml'
    assert loader.vault_secrets == 'secrets'

# Generated at 2022-06-11 09:27:12.433625
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    fake_stream = ""
    assert AnsibleLoader(fake_stream)

# Generated at 2022-06-11 09:27:14.211561
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-11 09:27:25.814841
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_string = """
- hosts: localhost
  gather_facts: no
  vars:
    var1: value1

  tasks:
  - name: ping
    ping:
"""
    from ruamel.yaml.comments import CommentedMap
    ds = AnsibleLoader(yaml_string).get_single_data()
    assert isinstance(ds, CommentedMap)
    assert 'hosts' in ds
    assert ds['gather_facts'] == False
    assert 'vars' in ds
    assert 'var1' in ds['vars']
    assert 'tasks' in ds
    assert isinstance(ds['tasks'], list)
    assert ds['tasks'][0]['name'] == 'ping'

# Generated at 2022-06-11 09:27:29.061994
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    yaml_loader = AnsibleLoader(None, vault_secrets=None)

# Run module directly, for local testing
if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:27:33.132903
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
    a: 1
    b: 2
    '''
    loader = AnsibleLoader(data)
    assert loader.get_data() == {'a': 1, 'b': 2}

# Generated at 2022-06-11 09:27:45.795397
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    import sys
    import io

    class MockFile(object):
        def __init__(self, name, data):
            self.name = name
            self.data = data

        def read(self):
            return self.data

    data = '''
- { name: foo, value: bar }
- { name: bam, value: baz }
    '''
    fobj = MockFile(__file__, data)
    loader = AnsibleLoader(fobj)
    obj = list(loader.get_single_data())
    assert isinstance(obj, list)
    assert len(obj) == 2
    assert isinstance(obj[0], AnsibleMapping)

# Generated at 2022-06-11 09:27:51.479763
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.AnsibleLoader = AnsibleLoader

# Generated at 2022-06-11 09:27:55.526258
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import doctest
    failed, tests = doctest.testmod(
                        AnsibleLoader,
                        optionflags=doctest.NORMALIZE_WHITESPACE
    )
    assert tests > 0
    assert failed == 0

# Generated at 2022-06-11 09:28:09.205771
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml import dumper as yaml_dumper

    test_file = '''---
name: That's a typo
'''

    test_object = {
        "name": AnsibleUnicode("That's a typo"),
    }

    # Missing vault_secrets argument to AnsibleLoader should not raise exception
    AnsibleLoader(test_file)
    loader = AnsibleLoader(test_file)
    assert loader.get_single_data() == test_object

    # Missing vault_secrets argument to AnsibleDumper should not raise exception
    yaml_dumper.AnsibleDumper()

    # Check AnsibleLoader.construct_python_unicode()

# Generated at 2022-06-11 09:28:18.546878
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.module_utils.common.yaml import HAS_LIBYAML
    from ansible.module_utils.six import PY3

    if HAS_LIBYAML:
        from yaml.constructor import ConstructorError
    else:
        from yaml.composer import ComposerError as ConstructorError
    from yaml.scanner import ScannerError
    from yaml.parser import ParserError

    loader = AnsibleLoader(None)

    # test 'convert_pairs' method
    assert list(loader.convert_pairs([('a', 1), ('b', 2), ('c', 3)])) == [('a', 1), ('b', 2), ('c', 3)]

# Generated at 2022-06-11 09:28:29.270890
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_yaml_str = '''
    block:
      - other_stuff:
        thing:
          - 1
          - 2
          - 3
          - 4
          - 5
          - 6
          - 7
          - 8
          - 9
          - 10
      - other_thing: stuff
    '''
    loader = AnsibleLoader(test_yaml_str, 'somefile', None)
    try:
        loader = loader.get_single_data()
    except AttributeError:
        pass

    assert loader['block'][0]['other_stuff']['thing'] == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-11 09:28:30.574023
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert not AnsibleLoader is None

# unit test for constructor of class AnsibleConstructor

# Generated at 2022-06-11 09:28:32.931360
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    temp = AnsibleLoader(None)
    return True

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:28:34.468714
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert getattr(AnsibleLoader, '__init__')

# Generated at 2022-06-11 09:28:41.221013
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    src = '''---\n- name: test\n  remote_user: test\n  hosts: localhost\n  gather_facts: yes\n  tasks:\n    - name: debug test\n      debug:\n        msg: "{{ inventory }}"\n'''

    loader = AnsibleLoader(src)
    loader.get_single_data()

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:28:47.502807
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultSecret

    file_name = "filename"
    vault_secrets = []
    for vault_secret in [VaultSecret('vault_secret_1'), VaultSecret('vault_secret_2')]:
        vault_secrets.append(vault_secret)
    loader = AnsibleLoader(b'', file_name=file_name, vault_secrets=vault_secrets)

    assert loader.file_name == file_name
    assert VariableManager(loader=loader, vault_secrets=vault_secrets).vault_secrets == vault_secrets

# Generated at 2022-06-11 09:29:02.293473
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import StringIO

    stream = StringIO("---\n- hosts: localhost")
    data = AnsibleLoader(stream)
    assert data is not None

# Generated at 2022-06-11 09:29:03.378670
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Can't call class, no __init__
    pass

# Generated at 2022-06-11 09:29:12.534309
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    from ansible.parsing.yaml.loader import construct_yaml_map_with_start_comment
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    file_name = 'test_AnsibleLoader.yaml'

    file_path = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(file_path, file_name)

    if not os.path.exists(file_path):
        raise Exception("could not find the test file")

    with open(file_path) as f:
        loader = Ans

# Generated at 2022-06-11 09:29:25.952086
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.utils import context_objects as co
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    def object_wrapper(orig_class, vault_secrets):
        class wrapper(orig_class):
            def __init__(self, value, vault_secrets=None, file_name=None):
                co.set(vault_secrets=vault_secrets)
                super(wrapper, self).__init__(value, file_name=file_name)
                co.remove(vault_secrets=vault_secrets)
        return wrapper


# Generated at 2022-06-11 09:29:34.628846
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # The AnsibleLoader extends Reader, Scanner, Parser, Composer and Resolver
    # pylint: disable=too-many-ancestors
    assert issubclass(AnsibleLoader, Reader)
    assert issubclass(AnsibleLoader, Scanner)
    assert issubclass(AnsibleLoader, Parser)
    assert issubclass(AnsibleLoader, Composer)
    assert issubclass(AnsibleLoader, Resolver)

# Generated at 2022-06-11 09:29:38.044442
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    l = AnsibleLoader(None)
    assert AnsibleConstructor in l.__class__.__bases__
    assert Resolver in l.__class__.__bases__

# Generated at 2022-06-11 09:29:42.795232
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    This test is to ensure that if the AnsibleLoader will raise an error if
    multiple constructors are passed in. This is important because the order
    of import will determine which constructor will be used.
    '''
    class TestLoader(Loader):
        pass

    try:
        AnsibleLoader.add_constructor('', TestLoader.constructor)
    except ValueError as e:
        assert 'not overwriting existing constructor' in str(e)

# Generated at 2022-06-11 09:29:55.036397
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import tempfile

    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-11 09:29:58.561238
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:29:59.238350
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-11 09:30:20.963394
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO

    stream = StringIO(u"")
    loader = AnsibleLoader(stream, vault_secrets=None)
    assert loader.stream == stream

# Generated at 2022-06-11 09:30:25.548085
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # AnsibleLoader(stream)
    AnsibleLoader(stream)

    # AnsibleLoader(stream, file_name=None, vault_secrets=None)
    AnsibleLoader(stream, file_name=None, vault_secrets=None)

# Generated at 2022-06-11 09:30:28.045490
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# vim: set expandtab tabstop=4 shiftwidth=4 autoindent:

# Generated at 2022-06-11 09:30:28.685344
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-11 09:30:33.190607
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    AnsibleLoader class constructor test
    """
    stream = ' '
    stream_name = None
    vault_secrets = None

    # AnsibleLoader(stream, file_name=None, vault_secrets=None):
    AnsibleLoader(stream, stream_name, vault_secrets)

# Generated at 2022-06-11 09:30:41.501126
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleConstructor)

    value = loader.construct_yaml_str(None, '#!vault |')
    assert isinstance(value, AnsibleVaultEncryptedUnicode)

    value = loader.construct_yaml_str(None, '#!vault |\nmy secret value')
    assert isinstance(value, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-11 09:30:48.790684
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Usage:
    python -m ansible.parsing.yaml.loader.test_AnsibleLoader
    '''
    from ansible.compat.tests import unittest

    class TestAnsibleLoader(unittest.TestCase):

        def test_constructor(self):
            loader = AnsibleLoader(None, 'dummyfile', { None: None })
            self.assertEqual(loader.instance_class, AnsibleConstructor)

# Generated at 2022-06-11 09:30:50.451960
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-11 09:30:58.868475
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class MyYAMLObject(AnsibleBaseYAMLObject):
        # Used in AnsibleLoader to identify custom classes
        yaml_loader = AnsibleLoader
        yaml_dumper = AnsibleDumper
        yaml_tag = u'!py/myobj'

    loader = AnsibleLoader(None)
    loader.add_constructor(MyYAMLObject.yaml_tag, MyYAMLObject)
    myobj = loader.get_single_data()
    assert(type(myobj) == MyYAMLObject)
    assert(type(myobj.__yaml_loader__) == AnsibleLoader)

# Generated at 2022-06-11 09:31:03.987329
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    doc = """
    - hosts: localhost
      vars:
        hash_behaviour: merge

    - include: '{{ foo }}.yml'
    """
    loader = AnsibleLoader(doc)
    assert loader is not None

    for x in loader:
        assert x is not None

# Generated at 2022-06-11 09:31:48.420360
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence

    data = '''
    {% vault |
    foo: baz
    %}
    '''

    loader = AnsibleLoader(data, vault_secrets=dict(vault_password='password'))
    assert data == loader.get_data()
    assert isinstance(loader.get_single_data(), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 09:31:49.157324
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader("something")
    assert True

# Generated at 2022-06-11 09:31:49.599552
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-11 09:31:56.586279
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import yaml

    yam_in = '''
---
# comment
- hosts: localhost
  remote_user: root
- hosts: server
  user: admin
  sudo: no
  roles:
  - web
  - db
'''
    stream = io.StringIO(yam_in)
    loader = yaml.Loader(stream)
    loader.AnsibleConstructor.cls = yaml.SafeLoader
    ansible_data = yaml.load(stream, Loader=loader.AnsibleLoader)

    assert len(ansible_data) == 3
    assert 'hosts' in ansible_data[0] and ansible_data[0]['hosts'] == 'localhost'

# Generated at 2022-06-11 09:31:57.348123
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None, "test")

# Generated at 2022-06-11 09:32:03.709220
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping, AnsibleUnicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    yaml = AnsibleLoader(file_name="example_group_vars.yml")
    assert isinstance(yaml.get_single_data(), AnsibleMapping)
    for k, v in yaml.get_single_data().items():
        assert isinstance(k, AnsibleUnicode)
        assert isinstance(v, (AnsibleSequence, AnsibleMapping, AnsibleUnicode, AnsibleUnsafeText))

# Generated at 2022-06-11 09:32:11.631272
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    text = u'''
test:
  -  foo:
     - 1
     - 2
  -  bar: 3
'''
    data = AnsibleLoader(text).get_single_data()
    assert isinstance(data, dict)
    assert len(data['test']) == 2
    assert isinstance(data['test'][0], dict)
    assert len(data['test'][0]['foo']) == 2
    assert isinstance(data['test'][0]['foo'][0], int)
    assert isinstance(data['test'][0]['foo'][1], int)
    assert isinstance(data['test'][1]['bar'], int)

# Generated at 2022-06-11 09:32:22.427723
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import tempfile
    import os
    import sys

    if '__loader__' not in globals():
        module = sys.modules[__name__]  # pylint: disable=no-member
    else:
        module = __loader__  # pylint: disable=undefined-variable

    loader = module.AnsibleLoader(open(os.path.join(os.path.dirname(__file__), "data/test_loader.yml")))
    assert loader.file_name == os.path.join(os.path.dirname(__file__), "data/test_loader.yml")
    print(loader.get_single_data())
    assert loader.get_single_data() == {'parent': {'child': True}}
    assert len(loader.get_data()) == 1
    assert loader

# Generated at 2022-06-11 09:32:23.601437
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-11 09:32:25.775716
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestAnsibleLoader(AnsibleLoader):
        pass

    loader = TestAnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-11 09:33:55.085594
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import shutil

    class DummyVaultSecret:
        def __init__(self, filename):
            self._filename = filename

        def load(self, filename):
            return "Hello World!"

    # Create a temporary file with the test content
    test_content = '''---
- nop:
    msg: "{{ a_secret }}"
'''
    filename = 'ansible_constructor_test.yml'
    tmp_path = os.path.join('/tmp', filename)
    with open(tmp_path, 'w') as f:
        f.write(test_content)

    # Replace the old constructor with AnsibleConstructor
    import yaml
    yaml.Loader = AnsibleLoader

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:34:00.546366
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import yaml

    with io.StringIO('---\n- randoID: UNIQUEID') as stream:
        loader = AnsibleLoader(stream)
        data = yaml.load(stream, Loader=loader)
    assert isinstance(data, list)
    assert isinstance(data[0], dict)
    assert data[0]['randoID'] == 'UNIQUEID'

# Generated at 2022-06-11 09:34:06.374434
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.six import StringIO

    file_name = "fileName"
    stream = StringIO("")

    loader = AnsibleLoader(stream, file_name)

    assert loader.reader == stream
    assert loader.scanner == stream
    assert loader._parser == stream
    assert loader.composer == stream
    # check that the default_flow_style for AnsibleConstructor is turned off
    assert not loader.default_flow_style

# Generated at 2022-06-11 09:34:06.987443
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:34:15.972164
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=unsubscriptable-object

    # pylint: disable=all
    assert_equal = AnsibleLoader('- a\n- b\n').get_data() == ['a', 'b']
    assert_equal = AnsibleLoader('[a, b]').get_data() == ['a', 'b']
    assert_equal = AnsibleLoader('{a: b}').get_data() == {'a': 'b'}
    assert_equal = AnsibleLoader('', file_name='./my_file.yml').file_name == './my_file.yml'


# Make sure the AnsibleLoader class can be pickled. This is required for the
# multiprocessing module to work, which is used to enable concurrency support.

# Generated at 2022-06-11 09:34:16.596966
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-11 09:34:27.051322
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Unit test case to cover the condition in constructor,
    # when the stream is None and file_name is also None
    loader._stream = None
    loader._file_name = None
    assert loader._stream is None
    assert loader._file_name is None
    loader.load_from_file()
    assert loader._stream is None
    assert loader._file_name is None

    # Unit test case to cover the condition in constructor,
    # when the stream is None and file_name is not None
    loader._stream = None
    loader._file_name = '/etc/ansible/hosts'
    assert loader._stream is None
    assert loader._file_name == '/etc/ansible/hosts'
    loader.load_from_

# Generated at 2022-06-11 09:34:37.382325
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    from ansible.module_utils.six import StringIO

    stream = StringIO()
    stream.write("---\n")
    stream.write("foo: bar\n")
    stream.write("a: !vault |\n")
    stream.write(" $ANSIBLE_VAULT;1.1;AES256\n")
    stream.write(" 34323962396430663964333035356162366666331313564346536643630356465663331366531623666\n")
    stream.write(" 336366366364433132383831393362373261333361626537306666353465666535303636313236320a62\n")

# Generated at 2022-06-11 09:34:46.556561
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.vault import VaultLib

    stream = StringIO(u"--- \n- name: test\n  foo: bar\n  baz: !!vault |\n      $ANSIBLE_VAULT;1.1;AES256\n      63633137636530396431633434636234343362333763613338616262346161626533356234346130\n      3330383266\n")
    loader = AnsibleLoader(stream, vault_secrets=VaultLib({'password': None}))
    data = loader.get_single_data()

# Generated at 2022-06-11 09:34:53.075125
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Initialize AnsibleLoader class
    ansibleLoader = AnsibleLoader(None, "", None)
    # Test repr function
    assert repr(ansibleLoader) == '<ansible.parsing.yaml.loader.AnsibleLoader object>'
    # Test copy method
    assert isinstance(ansibleLoader.copy(), AnsibleLoader)
    # Test __iter__ method
    with open("test.yml") as f:
        assert isinstance(ansibleLoader.__iter__(f), AnsibleLoader)
