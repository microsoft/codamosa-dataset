

# Generated at 2022-06-11 09:25:31.526916
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream="hello")
    assert loader.version is not None

# Generated at 2022-06-11 09:25:33.060577
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import ansible.parsing.yaml.loader

    ansible.parsing.yaml.loader.AnsibleLoader

# Generated at 2022-06-11 09:25:36.226924
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    stream = '''
    key: 'value'
    '''

    data = AnsibleLoader(stream)
    assert data.get_single_data() == dict(key='value')

# Generated at 2022-06-11 09:25:45.657839
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-11 09:25:53.912272
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = """
# samples taken from http://yaml.org/spec/1.2/spec.html
---
canonical: 12345
decimal: +12,345
sexagecimal: 3:25:45
octal: 014
hexadecimal: 0xC
binary: 0b110011

flow:
  canonical: 12345
  decimal: +12,345
  sexagecimal: 3:25:45
  octal: 014
  hexadecimal: 0xC
  binary: 0b110011

map:
  canonical: 12345
  decimal: +12,345
  sexagecimal: 3:25:45
  octal: 014
  hexadecimal: 0xc
  binary: 0b110011

...
"""

# Generated at 2022-06-11 09:26:06.424879
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test for loading hash where keys are int
    loader = AnsibleLoader("{0: 'a'}")
    data = loader.get_single_data()
    assert data == {'0': 'a'}

    # Test for loading hash where keys are unicode
    loader = AnsibleLoader("{'0': 'a'}")
    data = loader.get_single_data()
    assert data == {'0': 'a'}

    # Test for loading hash where keys are AnsibleUnicode (python3)
    loader = AnsibleLoader("{!ansible_unicode '0': 'a'}")
    data = loader.get_single_data()

# Generated at 2022-06-11 09:26:17.114874
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString
    from ansible.module_utils._text import to_text

    # Create an instance of AnsibleLoader class
    loader = AnsibleLoader(None, file_name="", vault_secrets=[])

    # Create an encrypted string and make sure the object of the AnsibleVaultEncryptedString class is returned
    ansible_vault_encrypted_string = AnsibleVaultEncryptedString("test vault secret")
    assert type(loader.construct_yaml_str(ansible_vault_encrypted_string)) is AnsibleVaultEncryptedString

    # A string that is not encrypted is returned as an object of the AnsibleUnsafeText class

# Generated at 2022-06-11 09:26:31.064962
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
---
-
  ansible_connection: local
  block:
    - action: a
      args:
        b:
          c: 1
  other:
    d: e
    f: g
-
  ansible_connection: ssh
  host: 127.0.0.1
"""
    loader = AnsibleLoader(data)
    task_blocks = loader.get_single_data()

# Generated at 2022-06-11 09:26:38.318426
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ''
    file_name = 'test_AnsibleLoader'
    vault_secrets = 'test_vault_secrets'
    test_class = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)
    assert test_class.stream == stream
    assert test_class.file_name == file_name
    assert test_class.vault_secrets == vault_secrets

# Generated at 2022-06-11 09:26:39.690806
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    v = '''
list: [1, 2, 3]
dict: {a: 1, b: 2}
dollars: $3000
'''

    d = AnsibleLoader(v, file_name="/etc/ansible/foobar.yml")
    assert d != None

# Generated at 2022-06-11 09:26:43.741500
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(stream=None, file_name=None, vault_secrets=None)

# Generated at 2022-06-11 09:26:50.828291
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    loader = AnsibleLoader("!vault |\n          $ANSIBLE_VAULT;1.2;AES256;user\n          6331666364643834376135646462626536384377247049337664d454e304a684776623372477a7a\n          4d6d68655155557054316977344b6c59326e566d6a7531473d", vault_secrets=[('user', 'pass')])
    data = loader.get_single_data()
    assert not isinstance(data, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 09:26:59.716715
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml_str = """---
        - hosts: all
          tasks:
            - debug:
                msg: hello, world!
          roles:
            - web
          vars:
            - var1: "value1"
          pre_tasks:
            - meta: clear_host_errors
            - name: fake task
              foobar: "{{ foo }}"
    """
    # This will fail at the line "foobar: "{{ foo }}"" without patch
    data = yaml.load(yaml_str, AnsibleLoader)

# Generated at 2022-06-11 09:27:03.055817
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, None)
    assert hasattr(loader, 'construct_yaml_str')
    assert hasattr(loader, 'construct_yaml_map')
    assert hasattr(loader, 'construct_yaml_seq')

# Generated at 2022-06-11 09:27:15.908396
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import io
    import os

    here = os.path.dirname(__file__)
    test_file = os.path.join(here, '../../../test/unit/parsing/yaml/vault-test.yml')
    vault_file = os.path.join(here, '../../../lib/ansible/parsing/vault/test_vault.txt')

    vault_secrets = [
        {'secret': 'hunter42', 'vault_id': 'test-vault'}
    ]
    loader = AnsibleLoader(open(test_file, "r"), vault_secrets=vault_secrets)

   

# Generated at 2022-06-11 09:27:16.542735
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-11 09:27:28.658942
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Test to verify if the class exists
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader) == True

    # Test to verify if the function 'add_multi_constructor' exists
    add_multi_constructor = getattr(loader, 'add_multi_constructor')
    assert callable(add_multi_constructor)

    # Test to verify if the function 'add_constructor' exists
    add_constructor = getattr(loader, 'add_constructor')
    assert callable(add_constructor)

    # Test to verify if the function 'add_implicit_resolver' exists
    add_implicit_resolver = getattr(loader, 'add_implicit_resolver')
    assert callable(add_implicit_resolver)


# Generated at 2022-06-11 09:27:29.438062
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-11 09:27:42.846753
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import json
    import yaml
    from collections import namedtuple

    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    filename = '%s/../playbooks/test_playbook.yml' % os.path.dirname(os.path.realpath(__file__))
    with open(filename) as f:
        # Loader returns an object tree which implements the mapping protocol
        # so it's possible to get values using `ansible_key`
        ansible_obj = yaml.load(f, Loader=AnsibleLoader)

    assert ansible_obj['hosts'] == 'localhost', 'The object tree generated by AnsibleLoader does not match the original object'

# Generated at 2022-06-11 09:27:48.142860
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.common.yaml import dict_constructor as yaml_dict_constructor

    # Create an instance of AnsibleLoader
    ansible_loader = AnsibleLoader(None)

    # Make sure we correctly handle identity during construction
    assert ansible_loader.yaml_constructors[u'tag:yaml.org,2002:map'] == yaml_dict_constructor

    # Make sure the vault secret is correctly set
    vault_secrets = [b'$ANSIBLE_VAULT;1.1;AES256']
    ansible_loader = AnsibleLoader(None, vault_secrets=vault_secrets)
    assert ansible_loader.vault_secrets == vault_secrets

    # Make sure we

# Generated at 2022-06-11 09:28:03.680992
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from collections import namedtuple
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-11 09:28:04.348574
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:28:08.354325
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.load('[1,2,3]', Loader=AnsibleLoader)
    yaml.load('{a: 1, b: 2, c: 3}', Loader=AnsibleLoader)

# Generated at 2022-06-11 09:28:18.050843
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible import constants as C
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    input_yaml = u"""
    - hosts: localhost
      pre_tasks:
        - name: Add a boot file
          copy: src=/usr/local/bootfile.sh dest=/etc/bootfile.sh
          notify:
            - restart httpd

    - hosts: webservers
      tasks:
        - include: tasks/webservers.yml

      handlers:
        - include: handlers/webservers.yml
    """

    # create list of vault secrets
    vault_secrets = [{'vault_id': u'vault_secret', 'password': u'password'}]

# Generated at 2022-06-11 09:28:30.306745
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import os.path
    import sys
    import tempfile
    import yaml

    # Ensure we're using our constructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml.SafeLoader = AnsibleLoader

    # Set up a vault secret
    secret = 'bacon is delicious'
    ansible_vault_password_file = os.path.join(tempfile.gettempdir(), 'ansible_vault_password')
    fh = open(ansible_vault_password_file, 'w')
    fh.write(secret)
    fh.close()

    # Set up a file to construct
    (fd, file_name) = tempfile.mkstemp()
    stream = os.fdopen(fd, 'w')

# Generated at 2022-06-11 09:28:41.727234
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # unit test for AnsibleLoader, pulling in constructor from above
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class TestLoader(AnsibleLoader):
        pass


# Generated at 2022-06-11 09:28:48.473852
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import re

    # pylint: disable=no-member
    # pylint: disable=protected-access

    try:
        from yaml import CLoader as L
    except ImportError:
        from yaml import Loader as L

    loader = AnsibleLoader(stream=None)

    yaml_list = """
    - one
    - two
    - three
    """
    assert loader.construct_yaml_list(node=L(yaml_list).get_node()) == ['one', 'two', 'three']

    yaml_dict = """
    one: 1
    two: 2
    three: 3
    """
    assert loader.construct_yaml_map(node=L(yaml_dict).get_node()) == dict(
        one=1, two=2, three=3
    )



# Generated at 2022-06-11 09:29:00.098643
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    simple_loader = AnsibleLoader(None)
    assert isinstance(simple_loader.construct_yaml_null(), type(None))
    assert simple_loader.construct_yaml_null() is None
    assert isinstance(simple_loader.construct_yaml_bool(True), bool)
    assert simple_loader.construct_yaml_bool(True) is True
    assert isinstance(simple_loader.construct_yaml_int('42'), int)
    assert simple_loader.construct_yaml_int('42') == 42
    assert isinstance(simple_loader.construct_yaml_float('3.14'), float)
    assert simple_loader.construct_yaml_float('3.14') == 3.14

# Generated at 2022-06-11 09:29:07.762879
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream="{}", file_name="test1.yaml", vault_secrets=[])
    assert loader.get_single_data() == {}

    loader = AnsibleLoader(stream="foo", file_name="test2.yaml", vault_secrets=[])
    assert loader.get_single_data() == "foo"

    loader = AnsibleLoader(stream="foo\n", file_name="test3.yaml", vault_secrets=[])
    assert loader.get_single_data() == "foo"



# Generated at 2022-06-11 09:29:15.028862
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import StringIO
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping, AnsibleVaultEncryptedUnicode

    array = [1, 'a']
    map = {'a': 1, 'b': 'a'}
    vstruct = AnsibleVaultEncryptedUnicode('abc')
    vstruct.vault_id = '123'
    struct = { 'a': array, 'b': map, 'c': vstruct }

    data = StringIO.StringIO("%s" % struct)
    sys.stdin = data

    loader = AnsibleLoader(data)
    obj = loader.get_single_data()

    assert isinstance(obj, AnsibleMapping)

# Generated at 2022-06-11 09:29:27.279156
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    yaml = """
#example
name:
  - { foo: 1, bar: 2 }
  - { foo: 3, bar: 4 }
    """

    data = AnsibleLoader(yaml).get_single_data()
    assert data.get('name') == [{'foo': 1, 'bar': 2}, {'foo': 3, 'bar': 4}]

    output = AnsibleDumper().dump(data, Dumper=AnsibleDumper)
    assert yaml == output

# Generated at 2022-06-11 09:29:28.100108
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-11 09:29:31.894804
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from .loader_fixture import fixture

    assert(AnsibleLoader)

    loader = AnsibleLoader(fixture)

    assert(AnsibleLoader)
    assert(loader)

# Generated at 2022-06-11 09:29:34.989012
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    my_loader = AnsibleLoader(None)
    assert my_loader.__class__.__name__ == "AnsibleLoader"

# Generated at 2022-06-11 09:29:40.790336
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    input = """
    - hosts:
    - all
    tasks:
    - debug:
        var: myvar
    """
    ansible_loader_obj = AnsibleLoader(input)
    data = ansible_loader_obj.get_single_data()

    assert data == ({'hosts': ['all'], 'tasks': [{'debug': {'var': 'myvar'}}]}, None)

# Generated at 2022-06-11 09:29:42.993979
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Test class AnsibleLoader
    '''
    AnsibleLoader(None, None)

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-11 09:29:47.518634
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    (data, errors) = yaml.load('''
        foo:
          - 1
          - {'bar': 'baz'}
        '''
    )
    assert not errors
    assert data == {'foo': [1, {'bar': 'baz'}]}

# Generated at 2022-06-11 09:29:48.191180
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:30:00.924783
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

    class FakeStream(io.BytesIO):
        def __init__(self, value):
            io.BytesIO.__init__(self, bytes(value))

        def read(self, length):
            return io.BytesIO.read(self, length)

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Basic test with plaintext string
    stream = FakeStream(b"plain_string: 'ansible'")
    loader = AnsibleLoader(stream)
    obj = loader.get_single_data()
    assert obj == {"plain_string": "ansible"}, obj

    # Test vault-encrypted string

# Generated at 2022-06-11 09:30:11.147339
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import shutil
    sys.path.append('.')
    import ansible.parsing.yaml.objects

    # making some variables
    vars = {
        'gid': 1000,
        'groups': 'wheel',
        'uid': 1000
    }

    # making a fake user file
    try:
        temp = open('/tmp/test-user', 'w')
        with open('test/test-user', 'r') as f:
            temp.write(f.read())
        temp.close()
    except IOError:
        pass

    output = ansible.parsing.yaml.objects.AnsibleUnicode.__repr__(AnsibleLoader(file='/tmp/test-user').get_single_data())

# Generated at 2022-06-11 09:30:21.445255
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:30:22.648462
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("")

# Generated at 2022-06-11 09:30:34.960304
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from yaml import load, dump

    yaml_str = '''
    hosts:
        - local1:
            ansible_connection: local
        - local2:
            ansible_connection: local
        - local3:
            ansible_host: localhost
            ansible_connection: local
        - local4:
            ansible_host: localhost
            ansible_connection: local
            ansible_python_interpreter: python
    '''

    data = load(yaml_str, Loader=AnsibleLoader)

    def count_local_connections(data):
        count = 0
        for host in data['hosts']:
            if next(iter(host.values()))['ansible_connection'] == 'local':
                count += 1
        return count


# Generated at 2022-06-11 09:30:46.246506
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    from collections import namedtuple

    class FakeStream:
        def __init__(self, data):
            self.data = data
            self.pos = 0

        def read(self, num_bytes):
            chunk = self.data[self.pos:self.pos + num_bytes]
            self.pos += num_bytes
            return chunk

    class FakeVaultSecret:
        def __init__(self, content):
            self.content = content

        def get_decrypted_bytes(self, secret):
            return self.content

    FakeSecret = namedtuple('Secret', ['token', 'vault_id'])
    with open('/tmp/vault.yml', 'w+') as f:
        f.write('secret: mysecret\n')


# Generated at 2022-06-11 09:30:50.726408
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Loader __init__ has not parameters
    # Parameter file_name is not used in __init__
    # Parameter vault_secrets is not used in __init__
    assert AnsibleLoader(None).__init__(None) is None

# Generated at 2022-06-11 09:30:58.980521
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=unused-variable
    # pylint: disable=unused-variable,unused-argument
    import yaml
    yaml_str = '''
    foo: "{{ testvar }}"
    '''

    class MyLoader(AnsibleConstructor, Resolver):
        def __init__(self, stream, file_name=None, vault_secrets=None):
            AnsibleConstructor.__init__(self, file_name=file_name, vault_secrets=vault_secrets)
            Resolver.__init__(self)

    MyLoader.add_constructor(
        u'tag:yaml.org,2002:str',
        AnsibleConstructor.construct_yaml_str
    )

# Generated at 2022-06-11 09:31:00.090685
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-11 09:31:08.262882
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    yaml_str = '''
- foo: [bar, baz]
- foobar:
  - 1
  - 2
  - 3
'''

    loader = AnsibleLoader(yaml_str)
    data = loader.get_single_data()

    assert isinstance(data, list)
    assert len(data) == 2
    assert data[0] == {'foo': ['bar', 'baz']}
    assert data[1] == {'foobar': [1, 2, 3]}


# Generated at 2022-06-11 09:31:09.311871
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader


# Generated at 2022-06-11 09:31:11.766665
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    x = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    assert "AnsibleLoader" == x.__class__.__name__

# Generated at 2022-06-11 09:31:41.671345
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.nodes import AnsibleScalarNode


# Generated at 2022-06-11 09:31:50.345297
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    class TestLoader(AnsibleLoader):
        def vault_loaded(self, vault_secrets):
            pass

    vault_text = u'$ANSIBLE_VAULT;1.1;AES256\ntest data'
    vault_text_bytes = u'$ANSIBLE_VAULT;1.1;AES256\ntest data'.encode('utf-8')
    vault_text_bytes_no_header = u'test data'.encode('utf-8')
    vault_text_bytes_unicode = u'test data with unicode 😊'.encode('utf-8')

# Generated at 2022-06-11 09:31:57.279133
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
        ---
        - hosts: localhost
          tasks:
            - name: get a list of packages
              yum:
                name: "{{ packages }}"
                state: present
              vars:
                packages:
                - PyYAML
                - python-jinja2
                - python-paramiko
                - python-setuptools
                - sshpass
                - python-babel
                - python-httplib2
                - python-six
    '''
    loader = AnsibleLoader(data, '?')
    data = loader.get_single_data()
    assert data, "AnsibleLoader with data did not return data"
    assert 'tasks' in data[0], "AnsibleLoader with data did not return expected data"

# Generated at 2022-06-11 09:32:03.752766
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader

    with open('/tmp/test_AnsibleLoader.yaml', 'w') as f:
        f.write('''
            - hosts: all
              tasks:
              - name: test_debug
                debug:
                  msg: '{{inventory_hostname}}'
        ''')

    stream = open('/tmp/test_AnsibleLoader.yaml')
    data = AnsibleLoader(stream, '/tmp/test_AnsibleLoader.yaml').get_single_data()
    assert 'hosts' in data
    assert 'all' in data['hosts']

    stream = open('/tmp/test_AnsibleLoader.yaml')

# Generated at 2022-06-11 09:32:09.319372
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    a = AnsibleLoader(None)
    a = AnsibleLoader("test")
    a = AnsibleLoader("test", None)
    a = AnsibleLoader("test", file_name="test")
    a = AnsibleLoader("test", file_name="test", vault_secrets=None)
    a = AnsibleLoader("test", file_name="test", vault_secrets=["foo"])

# Generated at 2022-06-11 09:32:19.671362
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.yaml import HAS_LIBYAML
    if not HAS_LIBYAML:
        from yaml.composer import Composer
        from yaml.reader import Reader
        from yaml.scanner import Scanner
        from yaml.parser import Parser
        assert issubclass(AnsibleLoader, Reader)
        assert issubclass(AnsibleLoader, Scanner)
        assert issubclass(AnsibleLoader, Parser)
        assert issubclass(AnsibleLoader, Composer)
    else:
        from ansible.module_utils.common.yaml import Parser

# Generated at 2022-06-11 09:32:28.902739
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import json
    import emojify.emoji_matcher
    data = """---
a:
  b:
    c: d
  e:
    - f
    - g
    - h
  i:
    j:
      k: l
...
"""
    class Args(object):
        def __init__(self, module_name):
            self.module_name = module_name
    module_name = 'json'
    args = Args(module_name)
    sys.argv = [module_name]
    module_args = ''
    loader = AnsibleLoader(data)
    q = json.loads(loader.get_single_data())

# Generated at 2022-06-11 09:32:36.645932
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.json import json
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault_secret = json.dumps("vault_pass").strip("\"")
    loader = AnsibleLoader("encrypted: !vault |\n          $ANSIBLE_VAULT;1.1;" + vault_secret + ";\n          " + vault_secret + "\n          " + vault_secret + "=$ANSIBLE_VAULT")
    loader.get_single_data()
    assert isinstance(loader.get_single_data(), AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-11 09:32:37.956996
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # AnsibleLoader is a base class, so it's not tested
    pass

# Generated at 2022-06-11 09:32:47.718045
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultSecret
    import io
    from ansible.parsing.vault import VaultLib
    from ansible.errors import AnsibleParserError
    import os
    import sys
    import yaml

    # Test Loader with no vault secrets
    loader = AnsibleLoader(stream=None)
    assert loader.vault_secrets == []

    # Test Loader with one vault secret
    vault_secret = AnsibleVaultSecret('$ANSIBLE_VAULT;1.1;AES256')
    loader = AnsibleLoader(stream=None, vault_secrets=[vault_secret])
    assert loader.vault_secrets[0].data == vault_secret.data

    # Test load a yaml stream with no vault secret

# Generated at 2022-06-11 09:33:37.537008
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    class TestAnsibleLoader(AnsibleLoader):
        pass

    stream = open('/tmp/test_AnsibleLoader', 'w')
    stream.write('key: value\n')
    stream.close()
    stream = open('/tmp/test_AnsibleLoader', 'r')
    loader = TestAnsibleLoader(stream, file_name=None, vault_secrets=None)
    data = loader.get_single_data()
    assert data == {'key': 'value'}
    loader = TestAnsibleLoader(stream, file_name=None, vault_secrets=None)
    data = loader.get_single_data()
    assert data == {'key': 'value'}
    stream.close()

# Generated at 2022-06-11 09:33:46.182024
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_data = """
    ---
    - hosts: localhost
      gather_facts: false
      tasks:
        - shell: echo "hello!"
          register: output

        - assert: { that:
            - "'hello!' in output.stdout"
          }

        - shell: echo "hello!"
          when: False
          register: output
    """

    loader = AnsibleLoader(yaml_data)
    assert loader.get_single_data() == {
        'tasks': [
            {'assert': {'that': ["'hello!' in output.stdout"]}, 'shell': 'echo "hello!"'},
            {'register': 'output', 'shell': 'echo "hello!"', 'when': False}
        ],
        'hosts': 'localhost',
        'gather_facts': False
    }

# Generated at 2022-06-11 09:33:46.786752
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:33:47.407729
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-11 09:33:48.042335
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-11 09:33:57.747797
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        AnsibleLoader(None)
    except TypeError:
        pass  # this is what we expect


if HAS_LIBYAML:
    # Unit test for constructor of class AnsibleLoader
    def test_AnsibleLoader_init():
        AnsibleLoader(None)  # stream is converted to None in Parser


AnsibleLoader.add_constructor(
    u'tag:yaml.org,2002:python/unicode',
    AnsibleLoader.construct_python_unicode,
)

AnsibleLoader.add_constructor(
    u'tag:yaml.org,2002:bool',
    AnsibleLoader.construct_yaml_bool,
)


# Generated at 2022-06-11 09:34:07.928430
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    string = '''---
                a: 1
                b: 2
                c: 3
                ...
             '''
    data = AnsibleLoader(string).get_single_data()
    assert len(data) == 3
    assert isinstance(data, dict)
    assert isinstance(data['a'], int)
    assert isinstance(data['b'], int)
    assert isinstance(data['c'], int)

    string = '''---
                a: 1
                b: 2
                c: 3
                d:
                  e: 4
                  f: 5
                  g: 6
                  ...
             '''
    data = AnsibleLoader(string).get_single_data()
    assert len(data) == 4

# Generated at 2022-06-11 09:34:08.795578
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-11 09:34:11.820034
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    load = AnsibleLoader(None)
    assert hasattr(load, 'construct_yaml_map')
    assert hasattr(load, 'construct_yaml_seq')
    assert hasattr(load, 'construct_yaml_set')

# Generated at 2022-06-11 09:34:18.386971
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys, os
    sys.path.insert(0, os.path.dirname(__file__) + "/../../lib" )
    from components.parsing.yaml.constructor import AnsibleConstructor

    stream = '---\n---\nansible_ssh_host: 0.0.0.0\n...'
    file_name = '__none__'
    stream_loader = AnsibleLoader(stream, file_name=file_name)
    
test_AnsibleLoader()