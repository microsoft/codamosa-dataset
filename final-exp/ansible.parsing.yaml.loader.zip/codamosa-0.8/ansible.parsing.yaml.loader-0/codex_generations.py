

# Generated at 2022-06-11 09:25:38.514609
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import from_yaml

    data = '''
    ---
    foo:
      bar:
        - "a"
        - "b"
        - { c: "d" }
      baz:
        - "1"
        - "2"
        - "3"
    '''
    assert from_yaml(data) == {'foo': {'bar': ['a', 'b', {'c': 'd'}], 'baz': ['1', '2', '3']}}

# Generated at 2022-06-11 09:25:42.438825
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    ansible_loader_1 = AnsibleLoader(stream, file_name, vault_secrets)
    ansible_loader_2 = AnsibleLoader(stream, file_name, vault_secrets)

    assert ansible_loader_1 == ansible_loader_2

# Generated at 2022-06-11 09:25:44.396873
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
     test_AnsibleLoader = AnsibleLoader('')
     assert test_AnsibleLoader.__class__ is AnsibleLoader

# Generated at 2022-06-11 09:25:52.971596
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Basic test of class AnsibleLoader
    import yaml
    yaml.add_constructor(u'!include', AnsibleLoader.include)
    yaml.add_constructor(u'!include_dir', AnsibleLoader.include_dir)
    yaml.add_constructor(u'!include_role', AnsibleLoader.include_role)
    yaml.add_constructor(u'!include_tasks', AnsibleLoader.include_tasks)
    yaml.add_constructor(u'!import_playbook', AnsibleLoader.import_playbook)
    yaml.add_constructor(u'!import_tasks', AnsibleLoader.import_tasks)

    assert issubclass(yaml.Composer, object)

# Generated at 2022-06-11 09:26:01.764675
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping

    try:
        from yaml.cyaml import CSafeLoader as YamlLoader, CSafeDumper as YamlDumper
    except ImportError:
        from yaml import SafeLoader as YamlLoader, SafeDumper as YamlDumper

    stream = YamlLoader('''
---
config:
  name: foo
''')
    data = AnsibleLoader(stream)
    assert isinstance(data, AnsibleMapping)

    assert isinstance(YamlDumper.represent_dict(data, AnsibleLoader), AnsibleMapping)

# Generated at 2022-06-11 09:26:13.973157
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io
    import os
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    sys.path.append(os.path.dirname(__file__) + '/../vars')
    sys.path.append(os.path.dirname(__file__) + '/../inventory')


# Generated at 2022-06-11 09:26:14.536936
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:26:15.117002
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-11 09:26:22.595666
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from io import StringIO

    vault_pw = 'testpass'


# Generated at 2022-06-11 09:26:26.530987
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert issubclass(AnsibleLoader, Parser)
    assert issubclass(AnsibleLoader, Resolver)

# Generated at 2022-06-11 09:26:41.305041
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.compat.tests import unittest

    class TestAnsibleLoader(unittest.TestCase):

        longMessage = True

        def _assert_is_equivalent(self, a, b):
            self.assertTrue(AnsibleLoader(a).get_single_data(), b)

        def test_map_with_list_value(self):
            self._assert_is_equivalent("{a: [1, 2] }", {"a": [1, 2]})

        def test_map_with_keys_containing_dots(self):
            self._assert_is_equivalent("{'a.b': c}", {"a.b": "c"})


# Generated at 2022-06-11 09:26:43.574998
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=too-several-public-methods
    # TODO: add a real unit test
    assert AnsibleLoader

# Generated at 2022-06-11 09:26:44.194884
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# Generated at 2022-06-11 09:26:45.921985
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader(None)  # An object of class AnsibleLoader
    assert obj is not None

# Generated at 2022-06-11 09:26:52.341083
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    yaml_str = """
---
hostname: "host_one"
ip: "192.168.1.1"
os: "Linux"
distribution: "CentOS"
"""
    ansibleloader_obj = AnsibleLoader(yaml_str)
    data = ansibleloader_obj.get_single_data()
    assert data['hostname'] == 'host_one'

# Generated at 2022-06-11 09:27:02.787891
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.collections import ImmutableDict

    data = """
    a_string: hello
    another_string: world
    """
    loader = AnsibleLoader(data)
    assert isinstance(loader, AnsibleLoader)
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    assert isinstance(loader.get_single_data()['a_string'], AnsibleUnicode)
    assert isinstance(loader.get_single_data()['another_string'], AnsibleUnicode)

    data = """
    a_string:
      - hello
      - world
    """



# Generated at 2022-06-11 09:27:08.592218
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_yaml_seq(loader.construct_mapping(None)), AnsibleSequence)
    assert isinstance(loader.construct_yaml_str(loader.construct_mapping(None)), AnsibleUnicode)

# Generated at 2022-06-11 09:27:14.518783
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import StringIO

    yaml_str = StringIO.StringIO(
        """
        a:
        - b
        - c
        - d
        """
    )

    # pylint: disable=unused-variable
    data = AnsibleLoader(yaml_str).get_single_data()

# Generated at 2022-06-11 09:27:16.749034
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, file_name='myfile')
    assert loader.file_name == 'myfile'

# Generated at 2022-06-11 09:27:28.841846
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping, AnsibleUnicode
    test_string = " - hosts: {% if foo %}bar{% else %}baz{% endif %}\nanother"
    test_list = ["hosts", {'foo':'bar'}, "another"]

    fake_file = 'foo'

    my_module = AnsibleLoader(test_string, file_name=fake_file)

    assert isinstance(my_module.get_data(), AnsibleSequence)

    ansible_seq = my_module.get_data()
    assert ansible_seq[0] == test_list[0]
    assert isinstance(ansible_seq[1], AnsibleMapping)

    ansible_map = ansible_seq[1]

# Generated at 2022-06-11 09:27:44.737265
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    assert isinstance(AnsibleLoader, type)
    assert isinstance(AnsibleLoader, AnsibleConstructor)
    assert '__init__' in dir(AnsibleLoader)
    # load_yaml(self, data, Loader=yaml.BaseLoader):
    assert 'load_yaml' in dir(AnsibleLoader)
    # yaml_to_dict(self, data, file_name=''):
    assert 'yaml_to_dict' in dir(AnsibleLoader)
    # ensure_object(self, value):
    assert 'ensure_object' in dir(AnsibleLoader)

# Generated at 2022-06-11 09:27:54.504713
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml import  DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    l = DataLoader()
    #l = AnsibleLoader()
    l.set_vault_secrets([])

# Generated at 2022-06-11 09:28:08.224613
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# pylint: disable=wrong-import-position,wrong-import-order
from ansible.module_utils.six.moves.urllib.parse import urlsplit
from ansible.module_utils.six import PY3
from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnsafeText, AnsibleSequence

if HAS_LIBYAML:
    import yaml as yaml_base
else:
    # LibYAML has been removed and PyYAML is now the only option.
    # For those using PyYAML <5.1 the PyYAML class objects need to
    # be imported.
    from yaml import SafeLoader as yaml_base

# pylint: disable=too-many-public-method

# Generated at 2022-06-11 09:28:15.597027
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml = """
        - include: foo.yml
        - include: bar.yml
        - include: baz.yml
    """
    loader = AnsibleLoader(yaml)
    data = loader.get_single_data()
    assert data == [ {'include': 'foo.yml'}, {'include': 'bar.yml'}, {'include': 'baz.yml'} ]

if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-11 09:28:18.124727
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    d = AnsibleLoader(sys.stdin)
    assert type(d) == AnsibleLoader

# Generated at 2022-06-11 09:28:18.752336
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:28:22.511749
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    content = b'''
foo:
- bar
- baz
'''

    loader = AnsibleLoader(content)
    data = loader.get_single_data()

    assert data

# Generated at 2022-06-11 09:28:23.192768
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass # TODO

# Generated at 2022-06-11 09:28:34.468955
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import datetime


# Generated at 2022-06-11 09:28:41.590190
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test_AnsibleLoader: create a AnsibleLoader with a string
    # expect: ansible_loader created successfully
    ansible_loader = AnsibleLoader("---\n- hosts: all")

if __name__ == "__main__":
    try:
        # unit test for AnsibleLoader
        test_AnsibleLoader()
    except Exception as e:
        print("unittests failed: %s" % e)
    else:
        print("unittests passed")

# Generated at 2022-06-11 09:29:01.885257
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test regex for implicit FQCN regex
    assert not AnsibleLoader.implicit_fqcn_regexp.match(None)
    assert AnsibleLoader.implicit_fqcn_regexp.match('org.acme.Foo')
    assert AnsibleLoader.implicit_fqcn_regexp.match('Foo')
    assert AnsibleLoader.implicit_fqcn_regexp.match('Foo.Bar.Baz')

    # Test regex for list of FQCNs
    assert not AnsibleLoader.implicit_fqcn_list_regexp.match(None)
    assert not AnsibleLoader.implicit_fqcn_list_regexp.match('org.acme.Foo')
    assert AnsibleLoader.implicit_fqcn_list_regexp

# Generated at 2022-06-11 09:29:05.864925
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Constructor needs to accept one or file_name or vault_secrets.
    # Only file_name is used in __init__
    AnsibleLoader(None, None, None)
    AnsibleLoader(None, None, None)
    AnsibleLoader(None, file_name="test")

# Generated at 2022-06-11 09:29:07.714463
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open(file_name, 'r')
    yam = AnsibleLoader(stream)
    print(yam)

# Generated at 2022-06-11 09:29:14.981732
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    import io

    original_stdout = sys.stdout
    sys.stdout = io.StringIO()

    x = '''
        # comment
        - hosts:
            - one
            - two
        tasks:
            - shell: echo hello
    '''

    # construction
    data = AnsibleLoader(x).get_single_data()
    assert type(data) == list

    # data conversion
    print(AnsibleDumper(indent=4, default_flow_style=False).dump(data))
    assert sys.stdout.getvalue() == '''\
- hosts:
  - one
  - two
tasks:
  - shell: echo hello
'''

    # reset
    sys.std

# Generated at 2022-06-11 09:29:16.880875
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader

# Generated at 2022-06-11 09:29:27.310694
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader(): # pylint: disable=too-many-locals
    import sys
    import os
    import os.path
    import tempfile

    fd, fname = tempfile.mkstemp()
    fh = os.fdopen(fd)
    fh.close()

    pstr = "var1: value1"
    with open(fname, "w") as f:
        f.write(pstr)

    try:
        loader = AnsibleLoader(sys.stdin, file_name=fname)
        loader.update_console_stream()
    finally:
        os.remove(fname)

    assert loader.stream is sys.stdin
    assert loader.file_name == fname
    assert loader._routed_yaml_data is sys.stdin

# Generated at 2022-06-11 09:29:39.751948
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''---
- hosts: localhost
  gather_facts: False
  tasks:
    - name: this is a task
      shell: /bin/false
    - name: this is also a task
      command: /bin/false
'''

    data = AnsibleLoader(stream).get_single_data()
    assert data == [
        {
            'hosts': 'localhost',
            'gather_facts': False,
            'tasks': [
                {
                    'name': 'this is a task',
                    'shell': '/bin/false',
                },
                {
                    'name': 'this is also a task',
                    'command': '/bin/false',
                }
            ]
        }
    ]

# Generated at 2022-06-11 09:29:49.668935
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    vault_secrets = [
        VaultLib.VaultSecret('password1', 'token1'),
        VaultLib.VaultSecret('password2', 'token2'),
    ]

# Generated at 2022-06-11 09:29:50.343354
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:29:55.115128
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=missing-docstring
    content = '{"test": "1"}'
    loader = AnsibleLoader(content)
    assert loader.get_single_data() == {'test': '1'}


# Generated at 2022-06-11 09:30:14.019840
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass



# Generated at 2022-06-11 09:30:16.014956
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert 'AnsibleLoader' in globals()
    assert AnsibleConstructor in globals()
    assert Parser in globals()

# Generated at 2022-06-11 09:30:27.937227
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class Loader(AnsibleLoader):
        def __init__(self, stream):
            self.stream = stream
            super(Loader, self).__init__(stream)

        def get_single_data(self):
            return AnsibleConstructor.get_single_data(self)

    class FakeVaultSecret(object):
        def __init__(self, tokens):
            self.tokens = tokens

        def get_decrypted_text(self):
            return "decrypted:%s" % self.tokens


# Generated at 2022-06-11 09:30:34.909554
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """mock up data to test AnsibleLoader"""
    content = '''---
    - hosts: all
      tasks:
      - name: some task
        setup:
          filter: ansible_distribution
        register: result
      - name: dump task results
        debug: var=result
    '''
    from io import StringIO
    from ansible.errors import AnsibleParserError
    try:
        AnsibleLoader(StringIO(content), vault_secrets=None)
    except AnsibleParserError:
        pass

# Generated at 2022-06-11 09:30:35.568462
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:30:38.865668
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader=AnsibleLoader(stream='---\na: 123\n')
    assert loader.file_name is None
    assert loader.vault_secrets is None

# Generated at 2022-06-11 09:30:50.796607
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from io import StringIO

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # Test unicode
    buf = u'{ foo: bar }'
    stream = StringIO(buf)
    loader = AnsibleLoader(stream)
    d = loader.get_single_data()
    assert isinstance(d, dict)
    assert isinstance(d, AnsibleBaseYAMLObject)
    assert d.foo == 'bar'

    # Test integer
    buf = u'{ foo: 12345 }'
    stream = StringIO(buf)
    loader = AnsibleLoader(stream)
    d = loader.get_single_data()
    assert isinstance(d, dict)
    assert isinstance(d, AnsibleBaseYAMLObject)
    assert d.foo == 12345

   

# Generated at 2022-06-11 09:30:55.924720
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        import yaml
    except ImportError:
        print("no libyaml available, skipping construct_yaml_map test")
        assert True
        return

    ans_yaml_dump = b'foo: {bar: { baz: hello } }'
    ans_yaml_load = yaml.load(ans_yaml_dump)
    assert ans_yaml_load['foo']['bar']['baz'] == 'hello'

# Generated at 2022-06-11 09:31:02.173348
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    import os
    file_name = os.path.join(os.path.dirname(__file__), '../../../test/units/module_utils/common/test_ansible_constructor.yml')
    loader.file_name = file_name
    loader.vault_secrets = [{'token': 'a_test_vault_password'}]
    loader.get_single_data()

# Generated at 2022-06-11 09:31:12.772469
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.errors import AnsibleParserError
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unicode import to_unicode

    def assert_parsed(s, e):
        """
        Assert that the string s parses to the dict e, and that the
        resulting dict can be turned back into a string equivalent to s.
        """
        s = to_unicode(s)
        assert AnsibleLoader(s).get_data() == e
        assert s == to_unicode(AnsibleLoader(s).get_single_data())

    assert_parsed("test: value\n",
                  {u'test': u'value'})

# Generated at 2022-06-11 09:31:54.518187
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader

    # If no data is provided, we should get back an empty data structure
    ansible_loader = AnsibleLoader(None)
    data = ansible_loader.get_single_data()
    assert data == None

    # If a scalar is provided, we should get back that scalar
    data = """
    hello
    """
    ansible_loader = AnsibleLoader(data)
    data = ansible_loader.get_single_data()
    assert data == "hello"

    # If a list is provided, we should get back that list
    data = """
    - hello
    - world
    """
    ansible_loader = AnsibleLoader(data)
    data = ansible_loader.get_single_data()

# Generated at 2022-06-11 09:32:01.004840
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class Stream(object):
        def __init__(self, stream=None):
            self.stream = stream
            self.name = None

        def read(self):
            return self.stream

    class Stream2(object):
        def __init__(self, stream=None, name=None):
            self.stream = stream
            self.name = name

        def read(self):
            return self.stream

    # If HAS_LIBYAML is True, we call Parser __init__, so we need
    # to mock stream
    stream = Stream('xxx')
    try:
        AnsibleLoader(stream)
    except TypeError:
        assert False, "AnsibleLoader can't be initiated, please check __init__"

    # If HAS_LIBYAML is False, we call Reader __init__, so we need to

# Generated at 2022-06-11 09:32:02.378975
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    class TestAnsibleLoader(AnsibleLoader):
        pass

    parser = TestAnsibleLoader('hello')

# Generated at 2022-06-11 09:32:05.837282
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    s = yaml.load(open('test.yml', 'r'), Loader=AnsibleLoader)
    print(str(s))

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:32:07.328970
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, '__init__')

# Generated at 2022-06-11 09:32:14.044504
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.module_utils.common.yaml import ansible_loader

    input_yaml = b'\n'.join([b'# Test Comment', b'a1:', b'  b1:', b'    d1: Hello', b'    d2: World', b'  b2:', b'    - 1', b'  b3:', b'    "2"', b'a2:', b'a3:'])
    result = ansible_loader.load(input_yaml)

    assert isinstance(result, dict)
    assert len(result.keys()) == 3


# Generated at 2022-06-11 09:32:14.828942
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:32:25.139936
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    basic_str = b'hello world'
    basic_unicode = u'hello world'
    basic_dict = {'key1': 'value1', 'key2': 'value2'}
    basic_list = ['element 1', 'element 2']
    stream = basic_str
    file_name = 'file'
    vault_secrets = ['vault_secret']
    ansible_loader = AnsibleLoader(
        stream=stream,
        file_name=file_name,
        vault_secrets=vault_secrets
    )
    assert ansible_loader.stream == stream
    assert ansible_loader.file_name == file_name
    assert ansible_loader.vault_secrets == vault_secrets
    assert ansible_loader.get_single_data() == basic_str
    ansible_loader

# Generated at 2022-06-11 09:32:25.743504
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:32:35.400159
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    test_data_path = os.path.join(os.path.dirname(__file__), "..", "..", "test", "unit", "parsing", "yaml",)
    with open(os.path.join(test_data_path, "yaml_constructor_pass.yml")) as f:
        test_data = loader.load(f)

# Generated at 2022-06-11 09:33:57.934916
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    l = AnsibleLoader(b'hello: world\n')
    assert l.get_single_data() == {'hello': 'world'}

    l = AnsibleLoader(u'hello: world\n')
    assert l.get_single_data() == {'hello': 'world'}

    l = AnsibleLoader(b'hello: "world\n"\n')
    assert l.get_single_data() == {'hello': 'world\n'}

    l = AnsibleLoader(u'hello: "world\n"\n')
    assert l.get_single_data() == {'hello': 'world\n'}

    l = AnsibleLoader(u'hello: !binary "\n"\n')
    assert l

# Generated at 2022-06-11 09:34:00.634918
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    from ansible.module_utils.common.yaml import HAS_LIBYAML

# Generated at 2022-06-11 09:34:03.033903
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''Return an instance of AnsibleLoader'''
    loader = AnsibleLoader('foo')
    assert type(loader) == AnsibleLoader

# Generated at 2022-06-11 09:34:04.812233
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, file_name="test")
    assert loader.file_name == "test"

# Generated at 2022-06-11 09:34:06.487721
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    dummy_stream = None
    loader = AnsibleLoader(dummy_stream)
    assert loader != None

# Generated at 2022-06-11 09:34:15.819204
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.data import AnsibleMapping
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    assert issubclass(AnsibleLoader, Parser)
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert issubclass(AnsibleLoader, Resolver)

    loader = AnsibleLoader([], vault_secrets=None)

# Generated at 2022-06-11 09:34:26.246508
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    output = None
    if HAS_LIBYAML:
        loader = AnsibleLoader(None, 'test')
    else:
        from yaml.reader import Reader
        from yaml.scanner import Scanner
        from yaml.parser import Parser
        from yaml.composer import Composer
        from yaml.resolver import Resolver
        loader = AnsibleLoader(Reader(), Scanner(), Parser(), Composer(), Resolver())
    assert isinstance(loader, AnsibleLoader)
    assert hasattr(loader, 'resolve')
    assert hasattr(loader, 'construct_yaml_bool')
    assert hasattr(loader, 'construct_yaml_int')
    assert hasattr(loader, 'decrypt_text')
    assert hasattr(loader, 'decrypt_bytes')

# Generated at 2022-06-11 09:34:36.885304
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # These bugs have already been fixed, but are here for regression
    # testing.
    data = {
        '0': {
            'dict1': {
                'key1': u'val1',
                'key2': u'val2'
            },
            'list1': [
                u'val1',
                u'val2'
            ],
            'str1': u'value'
        }
    }
    import io
    import sys

    class FakeStream(io.TextIOBase):
        def __init__(self, stream):
            self.stream = stream

        def read(self, n=None):
            return self.stream.read(n)

        def readline(self, limit=-1):
            return self.stream.readline(limit)

        def __iter__(self):
            return self

# Generated at 2022-06-11 09:34:39.037873
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.AnsibleLoader = AnsibleLoader
    yaml.load("---\n- hosts: all\n  remote_user: root\n...\n", Loader=AnsibleLoader)

# Generated at 2022-06-11 09:34:48.661831
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    class TestClass(object):
        pass
    test = TestClass()
    test.a_dict = {'name': 'Joe', 'age': 30}
    test.a_list = ['one', 2, 'three']
    test.a_str = 'test'
    test.another_dict = {'name': 'Victor', 'age': 31}

    data = {'a_dict': test.a_dict,
            'a_list': test.a_list,
            'a_str': test.a_str,
            'another_dict': test.another_dict}

    # Generate YAML
    dumper = AnsibleDumper()
    dumper.ignore_aliases = lambda self, data: True
    output = d