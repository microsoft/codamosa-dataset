

# Generated at 2022-06-11 09:25:44.094105
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import unittest
    import yaml

    class TestAnsibleLoader(unittest.TestCase):
        yaml_text = """
        key: !!python/object/apply:os.system ["echo test"]
        list:
          - !!python/object/apply:os.system ["echo test"]
        """

        def test_construct_yaml_map_with_python_object_in_key(self):
            print("key: !!python/object/apply:os.system ['echo test']")
            yaml_obj = yaml.load(self.yaml_text, Loader=AnsibleLoader)
            self.assertTrue(isinstance(yaml_obj, dict))
            self.assertTrue(isinstance(yaml_obj['key'], list))


# Generated at 2022-06-11 09:25:45.020119
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader('/path/to/file')

# Generated at 2022-06-11 09:25:45.953879
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader

# Generated at 2022-06-11 09:25:54.078544
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-11 09:25:54.698893
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:26:06.425506
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert hasattr(loader, '_load_python_2_unicode')
    assert hasattr(loader, '_load_python_object')
    assert hasattr(loader, '_load_python_object_with_file_name')
    assert hasattr(loader, '_construct_python_object')
    assert hasattr(loader, '_construct_python_sequence')
    assert hasattr(loader, '_construct_python_str')
    assert hasattr(loader, '_decrypt_text')
    assert hasattr(loader, '_construct_mapping')
    assert hasattr(loader, '_construct_yaml_map')

# Generated at 2022-06-11 09:26:07.052628
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:26:08.688638
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(None)
    assert ansible_loader

# Generated at 2022-06-11 09:26:18.741530
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import os

    # we should have a nice error if we have no yaml
    try:
        import yaml
    except ImportError:
        yaml = None
    if yaml is None:
        try:
            from ansible.parsing.yaml.loader import AnsibleLoader
            yaml = AnsibleLoader
        except ImportError:
            pass
    assert yaml is not None

    class MockStream(io.IOBase):
        def write(self, s):
            pass

    thisdir = os.path.dirname(__file__)
    f = open(os.path.join(thisdir, 'test_loader.yml'))
    data_list = yaml.load(f)
    f.close()

    assert type(data_list) == list

# Generated at 2022-06-11 09:26:27.683081
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from StringIO import StringIO
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    loader = AnsibleLoader(StringIO('[foo, bar]'))   # type: AnsibleLoader
    assert isinstance(loader.get_single_data(), AnsibleSequence)
    loader = AnsibleLoader(StringIO('{"key": "value"}'))    # type: AnsibleLoader
    assert isinstance(loader.get_single_data(), AnsibleMapping)

# Generated at 2022-06-11 09:26:42.326559
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime, sys
    cl = AnsibleLoader('')


# Generated at 2022-06-11 09:26:50.759151
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_file = 'tests/liner.yaml'
    loader = AnsibleLoader(open(test_file), file_name=test_file)
    data = loader.get_single_data()
    assert data.strip() == 'a line of data'

    test_file = 'tests/literals.yaml'
    loader = AnsibleLoader(open(test_file), file_name=test_file)
    data = loader.get_single_data()
    assert data.strip() == '|-\na line of data'

    test_file = 'tests/indented.yaml'
    loader = AnsibleLoader(open(test_file), file_name=test_file)
    data = loader.get_single_data()

# Generated at 2022-06-11 09:26:52.920239
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    instance = AnsibleLoader('- 1\n- 2\n- 3')
    assert isinstance(instance, AnsibleLoader)

# Generated at 2022-06-11 09:26:58.764172
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("---\n"
                           ":foo: 1\n"
                           ":bar: 1\n"
                           ":baz: 1")
    assert loader.get_single_data() == { 'foo': 1, 'bar': 1, 'baz': 1 }


# Generated at 2022-06-11 09:27:09.918873
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    vault_secret = VaultSecret('secret', VaultAES256('password'))
    vault_secrets = [vault_secret]
    vault = VaultLib(vault_secrets)

# Generated at 2022-06-11 09:27:11.229494
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, Resolver)

# Generated at 2022-06-11 09:27:17.998292
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open("test/test_loader.yml", 'r')
    result1 = AnsibleLoader(stream).get_single_data()
    result2 = AnsibleLoader(stream).get_single_data()
    assert result1 != result2
    assert result1 != {}
    assert result2 != {}

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])
    print('No errors')

# Generated at 2022-06-11 09:27:29.856122
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

if HAS_LIBYAML:
    # Unit test for class AnsibleLoader
    def test_parse():
        from ansible.parsing.vault import VaultLib
        key = 'test'
        vault = VaultLib([key])

# Generated at 2022-06-11 09:27:43.303029
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.composer import Composer
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser

    if not HAS_LIBYAML:
        assert issubclass(AnsibleLoader, Reader), "AnsibleLoader: Reader not found"
        assert issubclass(AnsibleLoader, Scanner), "AnsibleLoader: Scanner not found"
        assert issubclass(AnsibleLoader, Parser), "AnsibleLoader: Parser not found"
        assert issubclass(AnsibleLoader, Composer), "AnsibleLoader: Composer not found"
    else:
        assert issubclass(AnsibleLoader, Parser), "AnsibleLoader: Reader not found"

# Generated at 2022-06-11 09:27:43.920489
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-11 09:27:51.821124
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Test AnsibleLoader.
    '''

    # Parsing the empty string should raise an exception
    try:
        AnsibleLoader('')
        assert False
    except TypeError:
        pass

# Generated at 2022-06-11 09:27:58.053003
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys

    sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))
    from lib.parser.yaml.loader import AnsibleLoader
    from lib.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    with open('./test/units/modules/system/facter/facter.yml') as f:
        data = f.read()

    loader = AnsibleLoader(data, file_name='', vault_secrets=[{'vault_id': 'test'}])
    data = loader.get_single_data()
    assert isinstance(data['test'], AnsibleVaultEncryptedUnicode)
    assert data['test'].vault_identifier == 'test'

# Generated at 2022-06-11 09:28:00.153218
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    a = AnsibleLoader(None)
    assert isinstance(a, AnsibleLoader)

# Generated at 2022-06-11 09:28:12.809511
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unicode import to_bytes

    (fd, fname) = tempfile.mkstemp()

# Generated at 2022-06-11 09:28:19.532798
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, Resolver)
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert issubclass(AnsibleLoader, Parser)
    if not HAS_LIBYAML:
        assert issubclass(AnsibleLoader, Composer)
        assert issubclass(AnsibleLoader, Reader)
        assert issubclass(AnsibleLoader, Scanner)

# Generated at 2022-06-11 09:28:23.245504
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.RoundTripLoader = AnsibleLoader

# noinspection PyStatementEffect,PyUnresolvedReferences
test_AnsibleLoader()

# Generated at 2022-06-11 09:28:23.885402
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:28:27.251374
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    tc = AnsibleLoader(stream='', file_name='', vault_secrets='')
    assert isinstance(tc, AnsibleLoader)


# Generated at 2022-06-11 09:28:30.257912
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_file = open("/etc/ansible/hosts_test__init__")
    yaml_obj = yaml.load(yaml_file)
    yaml_file.close()

# Generated at 2022-06-11 09:28:31.609427
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    instance = AnsibleLoader("foo bar")
    assert "foo bar" == instance.stream

# Generated at 2022-06-11 09:28:42.233300
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader.get_single_data() is None

# Generated at 2022-06-11 09:28:42.927546
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)


# Generated at 2022-06-11 09:28:53.458788
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    script = AnsibleLoader(file_name='hosts')
    script.construct_yaml_map('name')
    script.construct_yaml_str('ansible')
    host = script.construct_yaml_map(script.gen_yaml_anchor())
    host['hostname'] = 'test-01'
    host['ip'] = '1.1.1.1'
    host['port'] = '22'
    script.append(host)
    script.construct_yaml_map('patterns')
    script.construct_yaml_seq(None)
    script.construct_yaml_map('test-*')
    script.construct_yaml_map('name')
    script.construct_yaml_str('all server')
    script.construct_yaml_map('hosts')
    script.construct

# Generated at 2022-06-11 09:29:04.453315
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Can't do anything if we're missing yaml or yaml libs
    try:
        from yaml import CSafeLoader as AnsibleLoader
    except ImportError:
        try:
            from yaml import SafeLoader as AnsibleLoader
        except ImportError:
            return

    # pylint: disable=unused-variable
    class AnsibleConstructor(AnsibleLoader):
        _instance = None

        def __new__(cls, stream):
            if cls._instance is None:
                cls._instance = super(AnsibleConstructor, cls).__new__(cls, stream)
            return cls._instance

    instance = AnsibleConstructor(None)


# Generated at 2022-06-11 09:29:06.377182
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
---
- hosts: all
  gather_facts: True
  tasks:
  - debug:
      msg: "Hello world!"
    register: test_result
  - assert:
      that:
        - test_result.stdout == "Hello world!"
'''
    loader = AnsibleLoader(data)
    for item in loader:
        print(item)

# Generated at 2022-06-11 09:29:08.201314
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

if __name__ == '__main__':
	test_AnsibleLoader()

# Generated at 2022-06-11 09:29:11.102470
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml import objects

    class TestAnsibleLoader(AnsibleLoader):
        pass

    assert isinstance(TestAnsibleLoader(None), objects.AnsibleBaseYAMLObject)

# Generated at 2022-06-11 09:29:25.148728
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import time
    import tempfile
    import shutil
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.errors import AnsibleParserError

    tmpdir = tempfile.mkdtemp()
    vault_password_file = os.path.join(tmpdir, 'test_vault_password')
    with open(vault_password_file, 'wb') as f:
        f.write('testpass')

    datadir = os.path.join(os.path.dirname(__file__), 'loader_data')
    path = os.path.join(datadir, 'test_loader.yml')
    stream = file(path, 'r')
    data

# Generated at 2022-06-11 09:29:28.174095
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    r = AnsibleLoader(None)
    if r is not None:
        assert True
    else:
        assert False

# Generated at 2022-06-11 09:29:35.494392
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml

    yaml.Loader = AnsibleLoader

    result = yaml.load("""
---
groups:
  - unix
  - windows
  - mac

tasks:
  - ping:
""")
    assert result['groups'] == ['unix', 'windows', 'mac']
    assert result['tasks'][0]['ping'] is None

# Generated at 2022-06-11 09:29:56.270510
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None, None, None)

# Generated at 2022-06-11 09:29:58.124413
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''Unit test for constructor of class AnsibleLoader'''
    loader = AnsibleLoader("foo")

# Generated at 2022-06-11 09:29:58.776915
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:30:09.474943
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.utils.unicode import to_bytes


# Generated at 2022-06-11 09:30:16.816373
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.module_utils.common.yaml import AnsibleUnicode
    import sys

    # Note: This test will only work for a subset of yaml files to test the
    #       Ansible-specific constructor.

    # Setup
    fh = open('../../test/yaml_loader/ansible_constructor_test.yml', 'r')
    stream = fh.read()
    test_loader = AnsibleLoader(stream)

    # Test
    test_loader.get_single_data()

    # Assert
    # Verify that the python2 specific unicode-based string constructor is not
    # called for in python3
    if sys.version_info[0] != 2:
        assert AnsibleUnic

# Generated at 2022-06-11 09:30:22.700598
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    file_name = "/path/to/file.yaml"
    stream = "vault_id: this_is_a_secret"
    vault_secrets = {"vault_id": "secret_password"}
    loader = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)

    assert loader.vault_secrets == vault_secrets
    assert loader.file_name == file_name

# Generated at 2022-06-11 09:30:25.458615
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None)
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-11 09:30:36.806049
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from binascii import hexlify

    t = 'test string'
    c = AnsibleVaultEncryptedUnicode.from_plaintext(t)
    cc = yaml.safe_load(c)
    assert hexlify(cc) == hexlify(t)
    assert str(cc) != hexlify(t)
    assert str(cc) == str(t)
    assert hexlify(t) != hexlify(str(cc))

    loader = AnsibleLoader(None, vault_secrets=[u'foo']) # FIXME: vault_secrets=None crashes on python 2.6
    t = u'vault(%s)' % hexlify(t)
    c

# Generated at 2022-06-11 09:30:48.837976
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import tests.utils as utils

    datavars = dict(
        yamlfile="blank.yml",
        yamlin = '',
        yamlex = {},
        yamlout = '{}',
    )
    utils.run_yaml_module_test(datavars, AnsibleLoader, AnsibleDumper)


# Generated at 2022-06-11 09:30:51.468673
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    reader = AnsibleLoader({'a': 1, 'b': 2})

    for key in reader:
        print(key)

# Generated at 2022-06-11 09:31:31.362313
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  pass

# Generated at 2022-06-11 09:31:32.770541
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader


# Generated at 2022-06-11 09:31:42.947851
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import HAS_LIBYAML

    if HAS_LIBYAML:
        from ansible.parsing.yaml.loader import AnsibleLoader
        from yaml.resolver import Resolver
        from ansible.parsing.yaml.constructor import AnsibleConstructor
        from ansible.module_utils.common.yaml import Parser
        assert issubclass(AnsibleLoader, AnsibleConstructor)
        assert issubclass(AnsibleLoader, Resolver)
        assert issubclass(AnsibleLoader, Parser)
    else:
        from ansible.parsing.yaml.loader import AnsibleLoader
        from yaml.resolver import Resolver
        from yaml.composer import Composer
        from yaml.reader import Reader
       

# Generated at 2022-06-11 09:31:43.961450
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-11 09:31:51.829987
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    def compare_to_dict(loader, load_string):
        source = load_string
        data = loader.get_single_data(source)
        return data

    resolve_data_string = ('[1, 2, 3, 4, 6]', '{a: {b: {c: {d: hello}}}}', '{a: b, c: d}', '{a: [1, 2]}',
                           '{a: {b: {c: {d: hello, e: there}}}}', '{a: {b: {c: {d: hello, e: there, f: again}}}}')
    loader = AnsibleLoader(None, vault_secrets={'test': "secret"})
    for data in resolve_data_string:
        loader.get_single_data(data)

# Generated at 2022-06-11 09:31:54.706285
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class_attrs = set(dir(AnsibleLoader))
    # Make sure that the super class constructor attributes are not in the
    # attributes of class AnsibleLoader
    base_attrs = set(dir(Parser)) & set(dir(Resolver))
    assert base_attrs.issubset(class_attrs)

# Generated at 2022-06-11 09:32:02.042807
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import datetime
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # test vault encrypted literal string

# Generated at 2022-06-11 09:32:11.449348
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-11 09:32:11.975691
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:32:22.793243
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.loader import BaseDatastructureLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = 'expand: true\n'
    loader = AnsibleLoader(yaml_str)
    data = loader.get_single_data()

    # Make sure YAML is parsed into AnsibleMapping object
    assert isinstance(data, AnsibleMapping)

    # Make sure AnsibleMapping object is parsed correctly
    assert data.expand

    yaml_str = '- test\n'
    loader = AnsibleLoader(yaml_str)
    data = loader.get_single_data()

    # Make sure YAML is

# Generated at 2022-06-11 09:33:54.449364
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    x = AnsibleLoader("""
    ---
    key: !unsafe
    - value A
    - value B
    """).get_data()
    assert x == {'key': [AnsibleUnsafeText('value A'), AnsibleUnsafeText('value B')]}

    x = AnsibleLoader("""
    ---
    key: !foo
    - value A
    - value B
    """).get_data()
    assert x == {'key': [AnsibleUnsafeText('!foo'), '-', 'value', 'A', '-', 'value', 'B']}

# Generated at 2022-06-11 09:34:04.766697
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str="""
- hosts: all
  gather_facts: no
  tasks:
  - name: test1
    ping:
  - name: test2
    setup:
      filter: ansible_virtualization_type
    debug:
      var: ansible_virtualization_type
"""
    # Must use a string as input not a file object
    loader = AnsibleLoader(yaml_str)
    data = loader.get_single_data()
    # print data
    assert data[0]['hosts'] == 'all'
    assert data[0]['tasks'][0] == {'name': 'test1', 'ping':''}

# Generated at 2022-06-11 09:34:08.919513
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    a_str = """
    ---
    x: true
    y: 123
    z:
    - x
    - y
    """
    a_dict = {'x': True, 'y': 123, 'z': ['x', 'y']}
    assert a_dict == yaml.load(a_str, Loader=AnsibleLoader)

# Generated at 2022-06-11 09:34:13.661928
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """This is unit test for AnsibleLoader class constructor."""
    yaml_stream = "some_string"
    file_name = "some_filename"
    ansible_loader_object = AnsibleLoader(yaml_stream, file_name)
    assert isinstance(ansible_loader_object, AnsibleLoader)
    assert "some_string" == str(ansible_loader_object.stream)

# Generated at 2022-06-11 09:34:18.039563
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # fake test for loader's class initializer
    # because it calls super() and python2 does not like that
    # it would be interesting to see if this will catch any errors
    # in case the initializer of super() changes and this class
    # is not updated accordingly
    AnsibleLoader(stream=None)



# Generated at 2022-06-11 09:34:19.969788
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, 'myfile')
    assert loader.file_name == 'myfile'

# Generated at 2022-06-11 09:34:30.210667
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # import below is required to move AnsibleLoader class in the current namespace
    # because of the following import lines in the ansible module
    # import ansible.parsing.yaml.loader
    # from ansible.parsing.yaml.loader import AnsibleLoader
    import ansible.parsing.yaml.loader
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import wrap_var
    import ansible.vars.unsafe_proxy

    # Create a VaultSecrets for use in testing
    vault_secrets = ['foo', 'bar']

    class FakeVaultSecret:

        def __init__(self, value):
            self.value = value


# Generated at 2022-06-11 09:34:31.435162
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    assert AnsibleLoader

# Generated at 2022-06-11 09:34:39.524415
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import sys
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    import ansible.parsing.yaml.objects

    yaml_str = '''
- hosts: localhost
  remote_user: root
  gather_facts: False
  tasks:
  - name: setting up a user
    template: src=templates/user.j2 dest=/etc/passwd owner=root group=root mode=0644 validate='/usr/sbin/pwck -rq %s'
    notify:
    - restart ssh
    - restart postfix
'''
#yaml_str = read_file(file_name)

    from ansible.parsing.yaml.loader import AnsibleLoader

# Generated at 2022-06-11 09:34:49.215313
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    ansible_loader = AnsibleLoader(None)
    assert isinstance(ansible_loader.construct_yaml_str(None, None), AnsibleUnicode)
    assert isinstance(ansible_loader.construct_yaml_str(None, ''), AnsibleUnicode)
    assert isinstance(ansible_loader.construct_yaml_str(None, 'test'), AnsibleUnicode)
    assert isinstance(ansible_loader.construct_yaml_str(None, b'test'), AnsibleUnicode)
    assert isinstance(ansible_loader.construct_yaml_str(None, u'test'), AnsibleUnicode)