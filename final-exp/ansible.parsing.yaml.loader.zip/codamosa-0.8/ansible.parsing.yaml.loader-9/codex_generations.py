

# Generated at 2022-06-11 09:25:36.693444
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
    test:
      nested:
        list: [ 1, 2, 3 ]
        dict: { a: 1, b: 2, c: 3 }
    '''
    loader = AnsibleLoader(data)
    parsed = loader.get_single_data()
    assert parsed == {'test': {'nested': {'list': [1, 2, 3], 'dict': {'a': 1, 'b': 2, 'c': 3}}}}, parsed

# Generated at 2022-06-11 09:25:42.653211
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(open('test/yaml/ansible_loader_test.yml', 'rb'))
    data = loader.get_single_data()
    assert data == {'regular': {'key1': 'value1', 'key2': 'value2'},
                    'special': {'key3': 'value3', 'key4': 'value4'},
                    'offending': {'key5': 'value5', 'key6': '{{ value6 }}'}}

# Generated at 2022-06-11 09:25:44.590662
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml = AnsibleLoader(open('../../../test/examples/inventory/hosts'))
    print(yaml)

# Generated at 2022-06-11 09:25:45.487450
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader



# Generated at 2022-06-11 09:25:48.389457
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None
    assert loader.file_name is None
    assert loader.vault_secrets is None

    loader2 = AnsibleLoa

# Generated at 2022-06-11 09:25:53.699162
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml_str = '''
- debug: msg="{{ salt['network.ipaddrs']()[0] }}"
- command: echo "{{ groups['aws'] }}"
'''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    func1 = data[0]['debug']['msg']
    func2 = data[1]['command']['echo']
    assert func1.startswith('{{ salt[')
    assert func2.startswith('{{ groups[')

# Generated at 2022-06-11 09:26:02.364226
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # make sure references are detected properly
    data = """---
        global1:
          - &global_var1 var1a
        global2:
          - *global_var1
        global3:
          - &global_var2 var2
          - *global_var2
        """

    loader = AnsibleLoader(data)
    loader = loader.get_single_data()

    assert loader.get('global1') == ['var1a']
    assert loader.get('global2') == ['var1a']
    assert loader.get('global3') == ['var2', 'var2']

# Generated at 2022-06-11 09:26:14.352194
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import tempfile
    import yaml

    datadir = os.path.join(os.path.dirname(__file__), 'data')
    test_yaml = os.path.join(datadir, 'long_seq.yaml')

    with open(test_yaml) as yaml_file:
        stream = yaml_file.read()
        stream += '\n'

    with tempfile.NamedTemporaryFile() as file_name:
        loader = AnsibleLoader(stream, file_name=file_name)
        data = list(loader.get_single_data())
        assert len(data) == 1

    with open(test_yaml) as yaml_file:
        stream = yaml_file.read()
        stream += '\n'


# Generated at 2022-06-11 09:26:22.183826
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    # Simple test
    stream = 'key: value'
    AnsibleLoader(stream)
    # Test with vault file

# Generated at 2022-06-11 09:26:30.227459
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    input_strings = [
        u'{ "test_key": "test_value" }',
        u'[ "test_value_1", "test_value_2" ]'
    ]

    for input_string in input_strings:
        loader = AnsibleLoader(input_string)
        data = loader.get_single_data()
        repr(data)
        loader.dispose()

# Generated at 2022-06-11 09:26:33.861986
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """Test AnsibleLoader class constructor"""
    assert AnsibleLoader

# Generated at 2022-06-11 09:26:35.250908
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    a = AnsibleLoader
    assert a is not None

# Generated at 2022-06-11 09:26:38.885588
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, Resolver)


if __name__  == "__main__":
    import pytest
    pytest.main([__file__,'-v'])

# Generated at 2022-06-11 09:26:48.637109
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.module_utils.common.vault.util import is_encrypted_file

    encrypted_vault_file = VaultEditor(VaultLib(password='password'), "tests/vault_test.yml").encrypt_file()
    # check if file is encrypted using vault
    assert is_encrypted_file(encrypted_vault_file) == True

    with open(encrypted_vault_file.name, 'r') as stream:
        yaml_content = AnsibleLoader(stream, file_name=encrypted_vault_file.name, vault_secrets={'vault_password': 'password'}).get_single_data()
    # check if vault secret name is decrypted
    assert yaml

# Generated at 2022-06-11 09:26:51.557054
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.module_utils.common.yaml
    ansible.module_utils.common.yaml.AnsibleLoader

# Generated at 2022-06-11 09:26:52.765151
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader("","")

# Generated at 2022-06-11 09:26:54.516225
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert HAS_LIBYAML

# Generated at 2022-06-11 09:26:57.561808
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    loader = AnsibleLoader(yaml.compose(u""))
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-11 09:27:01.551208
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # This is a workaround until that becomes a test.
    # Maybe this will be a unit test of another class.
    assert AnsibleLoader

if HAS_LIBYAML:
    def test_AnsibleLoader_is_a_Parser():
        assert isinstance(AnsibleLoader(stream=None), Parser)


# Generated at 2022-06-11 09:27:02.165102
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:27:09.235806
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Just function test. Do not care about stream, file_name, vault_secrets
    AnsibleLoader(None, None, None)

# Generated at 2022-06-11 09:27:14.518182
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = '''
ok: [host] => {
    "msg": "hello world"
}
'''

    a = AnsibleLoader(yaml_str)
    p = a.get_single_data()
    assert p['ok'] == ['host']

# Generated at 2022-06-11 09:27:16.396320
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader('','')
    assert isinstance(ansible_loader, Resolver)

# Generated at 2022-06-11 09:27:28.516505
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml
    import io


# Generated at 2022-06-11 09:27:42.033295
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible import errors
    from ansible.parsing.vault import VaultLib

    vault_pass = "password"
    vault = VaultLib([])
    vault.read_vault_password_file(None)
    vault.update_password(vault_pass)


# Generated at 2022-06-11 09:27:43.103563
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader is not None

# Generated at 2022-06-11 09:27:49.070949
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)
    assert isinstance(loader, Resolver)
    assert loader.vault_secrets is None

    # Confirming load_all is not implemented for AnsibleLoader
    try:
        loader.load_all()
    except NotImplementedError:
        pass
    else:
        assert False, "Exception not thrown"

# Generated at 2022-06-11 09:27:56.861825
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import os
    import tempfile
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.encrypt import do_encrypt

    stream = io.StringIO("normal_var: my_value\n")

    my_loader = AnsibleLoader(stream)
    assert my_loader.get_single_data() == {"normal_var": "my_value"}


# Generated at 2022-06-11 09:28:04.120273
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    stream = io.BytesIO('value: !include test.txt')
    loader = AnsibleLoader(stream)
    assert isinstance(loader, AnsibleLoader)
    assert loader.get_single_data() == {'value': 'I am the test file'}

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:28:05.815146
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml_text = """
        - include: otherfile.yml
           name: template {{ template_name }}
           owner: root
           backup: True

        - file:
           owner: root
           path: /etc/filename
           state: directory
           mode: 0644
    """
    loader = yaml.loader.Loader(yaml_text)


# Generated at 2022-06-11 09:28:17.492755
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    file_name = os.path.join(os.path.dirname(__file__), 'data', 'sample.yaml')
    with open(file_name, 'r') as f:
        yaml_obj = AnsibleLoader(f.read()).get_single_data()
        assert not yaml_obj

# Generated at 2022-06-11 09:28:18.449333
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(stream={}, file_name="filename")

# Generated at 2022-06-11 09:28:30.676423
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    class FakeStream(object):
        pass
    stream = FakeStream()
    file_name = 'foobar'
    fake_vault_secrets = 'fake_vault_secrets'

    loader = AnsibleLoader(stream, file_name=file_name, vault_secrets=fake_vault_secrets)

    # Ensure AnsibleConstructor.__init__ is called
    assert loader.file_name == file_name
    assert loader.vault_secrets == fake_vault_secrets
    assert loader.vars == {}
    assert loader.templates == []
    assert loader.hashes == {}
    assert loader.blocks == []
    assert loader.has_vault is False
    assert loader.vault_version is None

    # Ensure Resolver.__init__ is called
    assert loader.yaml_impl

# Generated at 2022-06-11 09:28:35.646784
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    from ansible.module_utils.common.yaml import load

    data = '''
    foo:
      - bar
      - bam
    '''

    results = load(data)
    assert isinstance(results, dict)

# Generated at 2022-06-11 09:28:38.754773
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.constructor

    obj = ansible.parsing.yaml.constructor.AnsibleLoader(None)

    assert obj is not None

# Generated at 2022-06-11 09:28:47.036730
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import imp
    import os
    import sys
    import tempfile

    if sys.version < '2.7':
        import unittest2 as unittest
    else:
        import unittest

    TEST_PATH = os.path.dirname(os.path.abspath(__file__))
    FIXTURE_PATH = os.path.normpath(os.path.join(TEST_PATH, '../fixtures/'))

    class TestAnsibleLoader(unittest.TestCase):

        def setUp(self):
            self.loader = AnsibleLoader

        def tearDown(self):
            pass

        def _load_fixture(self, fixture_file):
            fixture_data = open(fixture_file).read()
            return fixture_data

        # Added by Shinichi NAKAMURA.

# Generated at 2022-06-11 09:28:58.756507
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml import objects
    import re

    loader = AnsibleLoader(None)
    assert(isinstance(loader.construct_yaml_undefined(), objects.AnsibleUnicode))
    assert(isinstance(loader.construct_yaml_null(), objects.AnsibleUnicode))
    assert(isinstance(loader.construct_yaml_str('blah'), objects.AnsibleUnicode))
    assert(isinstance(loader.construct_yaml_seq('blah'), objects.AnsibleSequence))
    assert(isinstance(loader.construct_yaml_map('blah'), objects.AnsibleMapping))

    # demonstrates the regex magic in the AnsibleLoader constructor

# Generated at 2022-06-11 09:28:59.340805
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:29:03.742718
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    data = AnsibleLoader(b"unicode_str: 'abc'").get_single_data()
    assert data == {'unicode_str': AnsibleUnicode(u'abc')}

# Generated at 2022-06-11 09:29:12.766869
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class Check(object):  # pylint: disable=too-few-public-methods
        def __init__(self, *args, **kwargs):
            for name, value in kwargs.items():
                setattr(self, name, value)

        def __eq__(self, other):
            # Assume we only want to compare Check instances
            assert isinstance(other, self.__class__)
            return self.__dict__ == other.__dict__
    loader = AnsibleLoader('')
    check_compare = Check(
        resolver=loader.resolver,
        loader_name='AnsibleLoader',
        vault_secrets=None,
        file_name=None)
    check_compare.constructor = loader.constructor

# Generated at 2022-06-11 09:29:41.072493
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class AnsibleLoaderTester(AnsibleLoader):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            super(AnsibleLoaderTester, self).__init__(*args, **kwargs)

    class AnsibleLoaderTester2(AnsibleLoaderTester):
        pass

    loader = AnsibleLoaderTester('stream', file_name='file', vault_secrets=None)
    assert loader.args[0] == 'stream'
    assert loader.kwargs['file_name'] == 'file'
    assert loader.kwargs['vault_secrets'] is None

    loader = AnsibleLoaderTester2('stream', file_name='file', vault_secrets=None)
    assert loader.args[0] == 'stream'


# Generated at 2022-06-11 09:29:50.975627
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    module = '''
- name: testing hostvars
  hosts: localhost
  vars:
    logfile: "{{ lookup('env','HOME') }}/.ansible.log"
    hostfile: "{{ lookup('env','HOME') }}/.ansible/hosts"
  tasks:
    - debug: msg="{{ logfile }} {{ hostfile }}"
'''
    ansible_loader = AnsibleLoader(module, file_name='test.yaml')
    data = ansible_loader.get_single_data()
    assert data['tasks'][0]['debug']['msg'] == '{{ lookup(\'env\',\'HOME\') }}/.ansible.log {{ lookup(\'env\',\'HOME\') }}/.ansible/hosts'

# Generated at 2022-06-11 09:30:03.270651
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import AnsibleLoader

    # Test a simple mapping with AnsibleLoader
    text = ('{ key1: value1, key2: value2, key3: value3, key4: value4, '
            'key5: value5, key6: [value6, value7, value8] }')
    loader = AnsibleLoader(text)
    data = loader.get_single_data()
    assert isinstance(data, dict)
    assert len(data) == 6
    assert data['key1'] == 'value1'
    assert data['key2'] == 'value2'
    assert data['key3'] == 'value3'
    assert data['key4'] == 'value4'
    assert data['key5'] == 'value5'

# Generated at 2022-06-11 09:30:05.104330
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import base64
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode,AnsibleVaultEncryptedUnicode
    AnsibleLoader('')
    AnsibleLoader(base64.b64decode(''))
    AnsibleLoader('',vault_secrets=[])
    AnsibleLoader(base64.b64decode(''),vault_secrets=[])

# Generated at 2022-06-11 09:30:06.586634
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, Ansibleloader)

# Generated at 2022-06-11 09:30:13.437087
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Compose string with valid YAML
    stream = "---\n- name: test host\n  foo: bar"
    # Parse string with YAML
    data = AnsibleLoader(stream).get_single_data()
    # Check parsing
    assert isinstance(data, list)

    # Compose string with valid YAML and variable interpolation
    stream = "---\n- name: test host\n  foo: {{ bar }}"
    # Parse string with YAML
    data = AnsibleLoader(stream).get_single_data()
    # Check parsing
    assert isinstance(data, list)

# Generated at 2022-06-11 09:30:19.354555
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '- host: anyhost\n  connection: local\n  gather_facts: False\n  tasks:\n  - name: test_name\n    ping: {}\n'
    loader = AnsibleLoader(stream)
    assert loader.get_single_data() == [{'host': 'anyhost', 'connection': 'local', 'gather_facts': False, 'tasks': [{'name': 'test_name', 'ping': {}}]}]

# Generated at 2022-06-11 09:30:31.774339
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    if sys.version_info >= (2, 7):
        try:
            from unittest import TestCase
        except ImportError:
            from unittest2 import TestCase
    else:
        from unittest2 import TestCase

    class TestAnsibleLoader(TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_dumper(self):
            dumper = AnsibleDumper()
            self.assertIn(dumper.__class__.__name__, ('SafeDumper', 'AnsibleSafeDumper'))

    module = type(sys)('ansible_collections.testns.test_col.tests.loader')
    module.__dict__

# Generated at 2022-06-11 09:30:40.814549
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.yaml.parser import AnsibleParserError
    import sys

    # Create the loader
    loader = AnsibleLoader(None)

    # Create the dict data
    dict_data = dict()
    dict_data['key1'] = 'dict_value1'
    dict_data['key2'] = 'dict_value2'
    dict_data['key3'] = 'dict_value3'

    # Create the list data
    list_data = list()
    list_data.append('list_value1')
    list_data.append('list_value2')
    list_data.append('list_value3')

    # Test

# Generated at 2022-06-11 09:30:50.948839
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class AnsibleLoader1(AnsibleLoader):
        pass
    # pylint: disable=too-few-public-methods

    class AnsibleDumper:
        pass
    # pylint: disable=too-few-public-methods

    if HAS_LIBYAML:
        from ansible.module_utils.common.yaml import Loader, Dumper
        assert issubclass(AnsibleLoader1, Loader)
        assert not issubclass(AnsibleLoader1, Dumper)
        assert not issubclass(AnsibleDumper, Loader)
        assert not issubclass(AnsibleDumper, Dumper)

# Generated at 2022-06-11 09:31:23.839305
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert callable(AnsibleLoader)

# Generated at 2022-06-11 09:31:24.869197
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(stream=None)

# Generated at 2022-06-11 09:31:25.469900
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-11 09:31:37.050151
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.loader.vault.vault_secrets import VaultSecrets

    loader = AnsibleLoader(None)
    assert loader is not None
    assert loader.file_name is None

    loader = AnsibleLoader(None, 'test_file_name')
    assert loader.file_name == 'test_file_name'

    vault_secrets = VaultSecrets()
    loader = AnsibleLoader(None, None, vault_secrets)
    assert loader.vault_secrets is vault_secrets

    loader = AnsibleLoader(None, None, vault_secrets)
    assert loader.vault_secrets is vault_secrets

    loader = AnsibleLoader('string: value')
    assert loader.get_

# Generated at 2022-06-11 09:31:46.805696
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-11 09:31:48.268723
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # FIXME: write test for AnsibleLoader

# Generated at 2022-06-11 09:31:52.338810
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.module_utils.common.yaml import Loader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    a = AnsibleLoader("__test_data__: 1")
    assert isinstance(a.get_single_data(), dict)



# Generated at 2022-06-11 09:31:53.416074
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, Resolver)

# Generated at 2022-06-11 09:31:59.131013
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys

    if sys.version_info.major < 3:
        # This test only works in Python 3 because Python 2 has no __qualname__ attribute.
        return

    l = AnsibleLoader("f:\n- a\n- b\n- c")

    expected = "<unknown># AnsibleLoader"

    assert l.__class__.__qualname__ == expected
    assert l._Reader__reader.__class__.__qualname__ == expected
    assert l._Composer__parser.__class__.__qualname__ == expected
    assert l._Parser__constructor.__class__.__qualname__ == expected

# Generated at 2022-06-11 09:32:04.702379
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.config.manager import ConfigManager
    from ansible.parsing.dataloader import DataLoader
    yaml = """
        ---
        - hosts: localhost
          tasks:
          - name: Test debug
            debug:
              msg: Test ok
    """

    config = ConfigManager()
    config.set('defaults', 'host_key_checking', 'False')
    config.set('defaults', 'nocows', '1')

    loader = DataLoader(config=config)
    result = loader.load(yaml)

    assert result[0]["hosts"] == "localhost"
    assert result[0]["tasks"][0]["name"] == "Test debug"
    assert result[0]["tasks"][0]["debug"]["msg"] == "Test ok"

# Generated at 2022-06-11 09:33:18.878589
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import io
    import unittest


# Generated at 2022-06-11 09:33:31.699738
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=redefined-outer-name
    import io
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-11 09:33:35.923275
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader(None)
    def swap_data(self, data):
        return data
    obj._reader.data = swap_data
    d = obj.get_single_data()
    assert isinstance(d, dict)
    obj._reader.peek()

# Generated at 2022-06-11 09:33:37.396085
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''Test AnsibleLoader with no arguments'''
    assert AnsibleLoader(None)

# Generated at 2022-06-11 09:33:42.579370
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    data = """
example: 1
"""

    if HAS_LIBYAML:
        data = data.encode('utf-8')
    loader = DataLoader()
    content = loader.load(data, file_name="<string>")
    assert isinstance(content, dict)
    assert content.get('example') == 1


# Generated at 2022-06-11 09:33:43.711392
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# AnsibleLoader class resolve method

# Generated at 2022-06-11 09:33:49.567613
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import BytesIO
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleLoader(unittest.TestCase):
        ''' testing class AnsibleLoader '''

        def setUp(self):
            self.loader = AnsibleLoader(None)

        def tearDown(self):
            self.loader = None

        def test_ansible_unicode(self):
            ''' test ansible_unicode method '''

# Generated at 2022-06-11 09:33:50.912531
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert(issubclass(AnsibleLoader, Resolver))



# Generated at 2022-06-11 09:34:00.544481
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    text = """
    - hosts: all
      roles:
        - common
        - web
        - db
      tasks:
        - command: /usr/bin/foo
          register: foo_result
          changed_when: foo_result.rc != 5
          failed_when: foo_result.rc > 5
          ignore_errors: True
        - block:
            - include: stuff.yml
              args:
                somevar: foo
          rescue:
            - include: rescue.yml
          always:
            - include: always.yml
      handlers:
        - include: handlers.yml

    - hosts: otherhosts
    """
    result = yaml.load(text, Loader=AnsibleLoader)
    assert result is not None

import yaml

# Generated at 2022-06-11 09:34:04.904350
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(file_name='test', vault_secrets={'_ansible_vault_password': 'test'})
    loader

    assert AnsibleConstructor.template._file_name == 'test'

if __name__ == '__main__':
    test_AnsibleLoader()