

# Generated at 2022-06-11 09:25:34.149245
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open('/home/clement/Workspace/ansible/lib/ansible/playbook/play_data.yml','r')
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    print(data)

if __name__=='__main__':
    test_Ansi

# Generated at 2022-06-11 09:25:39.893871
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, file_name='myhost')
    assert loader.file_name == 'myhost'
    assert not hasattr(loader, 'vault_secrets')

    loader = AnsibleLoader(None, file_name='myhost', vault_secrets=['vault'])
    assert loader.file_name == 'myhost'
    assert loader.vault_secrets == ['vault']

# Generated at 2022-06-11 09:25:49.013761
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import tempfile
    import shutil
    import stat
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.plugins.loader import get_all_plugin_loaders

    def create_playbook_yaml_file(content):
        tmpdir = tempfile.mkdtemp(prefix='ansible_test_playbook_yaml')
        tmpfile = os.path.join(tmpdir, 'playbook.yml')
        open(tmpfile, 'w').write(content)
        return tmpfile

    def remove_temp_files(tmpfile, tmpdir):
        os.unlink(tmpfile)
        os.rmdir(tmpdir)


# Generated at 2022-06-11 09:25:55.459432
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    stream = StringIO("""\
a: 1
b:
  - 2
  - 3
""")

    obj = AnsibleLoader(stream).get_single_data()
    assert obj == {'a': 1, 'b': [2, 3]}

# Generated at 2022-06-11 09:25:59.900389
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # don't use import statement beacuase class is AnsibleLoader is not a direct base class
    assert (issubclass(AnsibleLoader, Parser) and
            issubclass(AnsibleLoader, Resolver) and
            issubclass(AnsibleLoader, AnsibleConstructor))

# Generated at 2022-06-11 09:26:12.472964
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import StringIO
    stream = StringIO.StringIO('''
    - name: test
      tags:
        - tag1
      host: a
      tasks:
      - name: task1
        local_action: copy src=a dest=b
      - name: task2
        local_action: copy src=a dest=b
    ''')
    loader = AnsibleLoader(stream)
    for x in range(0, 15):
        loader.get_data()

# Generated at 2022-06-11 09:26:21.005080
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    loader = AnsibleLoader(None, file_name='hello')
    assert loader.file_name == 'hello'


# Generated at 2022-06-11 09:26:33.320297
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    class TestAnsibleLoader(AnsibleLoader):
        def __init__(self, stream, file_name='<string>'):
            AnsibleLoader.__init__(self, stream, file_name=file_name)

    # Test that AnsibleLoader set custom '__ansible_parsed_output'
    data = '''
        ---
        - hosts: localhost
          gather_facts: no
          tasks:
            - name: test
              ping:
    '''
    data = TestAnsibleLoader(data).get_single_data()
    assert isinstance(data, dict)
    assert data['__ansible_parsed_output'] is True

# Generated at 2022-06-11 09:26:34.404989
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: add unit tests for AnsibleLoader
    assert True

# Generated at 2022-06-11 09:26:36.124116
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert type(AnsibleLoader(None, None))

# Generated at 2022-06-11 09:26:47.643384
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = "astring"
    file_name = "a_file"
    vault_secrets = "vault_secrets"
    loader = AnsibleLoader(stream, file_name, vault_secrets)
    assert loader.file_name == file_name
    assert loader.stream == stream
    assert loader.vault_secrets == vault_secrets
    assert loader.data == {}
    stream = "astring"
    file_name = None
    vault_secrets = None
    loader = AnsibleLoader(stream)
    assert loader.file_name == file_name
    assert loader.stream == stream
    assert loader.vault_secrets == vault_secrets
    assert loader.data == {}

# Generated at 2022-06-11 09:26:59.719789
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
    ---
    - hosts: localhost
      tasks:
        - name: task1
          debug:
            msg: value1
        - name: task2
          debug:
            msg: value2
    """
    loader = AnsibleLoader(data)

# Generated at 2022-06-11 09:27:06.380727
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    streaming = False

    if HAS_LIBYAML:
        import StringIO

        content = StringIO.StringIO("{% raw %}normal text{% endraw %}")
        loader = AnsibleLoader(content)
        assert loader.get_data() == "normal text"
    else:
        import io

        content = io.StringIO("{% raw %}normal text{% endraw %}")
        loader = AnsibleLoader(content)
        assert loader.get_data() == "normal text"

# Generated at 2022-06-11 09:27:07.362726
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-11 09:27:20.264852
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    def check(data, expect):
        loader = AnsibleLoader(data)
        assert loader.get_single_data() == expect

    def check_exception(data, exc):
        loader = AnsibleLoader(data)
        try:
            loader.get_single_data()
        except exc as e:
            assert str(e) == 'while scanning a simple key'
        else:
            raise AssertionError('Expected {} exception not thrown'.format(type(exc).__name__))

    # Test AnsibleLoader.construct_yaml_map
    # -------------------------------------
    # When a simple key exists with following content
    # Correct:
    #   key: string
    #   key:
    #     key: value
    # Incorrect:
    #   key:
    #   - list
    #   - list
   

# Generated at 2022-06-11 09:27:24.751932
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    doc = AnsibleLoader("adoc").get_single_data()
    ansible_obj = AnsibleLoader("---\nadoc\n").get_single_data()
    assert doc == ansible_obj


# Generated at 2022-06-11 09:27:28.886183
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    config = """
    ansible_host: 10.0.0.1
    """
    data = AnsibleLoader(config).get_single_data()
    assert data['ansible_host'] == '10.0.0.1'

# Generated at 2022-06-11 09:27:30.689447
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """Class AnsibleLoader should be initialized without a problem."""
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-11 09:27:43.103895
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml

    yaml_stuff = """
        foo: 1
        bar: 2
        bam:
          baz: 3
          bur: 4
        goldfish: 1
        items:
          - item:
              1: one
          - item:
              2: two
          - item:
              3: three
        block: >
            This is a block
            with multiple lines
        literal: | # not very literal :(
            This is also a block
            with multiple lines
        """

    ansible_loader = AnsibleLoader(yaml_stuff)
    ansible_data = ansible_loader.get_single_data()

    assert ansible_data == yaml.load(yaml_stuff, Loader=yaml.Loader)

# Generated at 2022-06-11 09:27:53.400378
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from yaml.serializer import Serializer

    class MyAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            return 'str/constructor'

        def construct_yaml_map(self, node):
            return 'map/constructor'

        def construct_yaml_seq(self, node):
            return 'seq/constructor'

        def construct_undefined(self, node):
            return "undefined/constructor"

    class MyAnsibleDumper(AnsibleDumper, Serializer):
        def represent_str_str(self, data):
            return 'str/representor'

        def represent_str_map(self, data):
            return 'map/representor'



# Generated at 2022-06-11 09:28:11.714132
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play_context import PlayContext
    import StringIO
    loader_string = StringIO.StringIO("""
                       - yamltest:
                         - yamltest_sub:
                             - hello: world
                             - { foo: bar }
                         - foo: bar
                       - hello: world
                     """)

    loader = AnsibleLoader(loader_string)
    data = loader.get_single_data()
    assert isinstance(data, list)
    assert isinstance(data[0], AnsibleBaseYAMLObject)
    assert data[0].keys()[0] == 'yamltest'

# Generated at 2022-06-11 09:28:17.564492
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  file_name = "AnsibleLoader.test.file"
  data = b'---\n- hosts: localhost\nmyvariable: somevalue\n'
  stream = open(file_name, "wb")
  stream.write(data)
  stream.close()
  stream = open(file_name, "rb")

  loader = AnsibleLoader(stream)
  data = loader.get_single_data()
  #print(data)
  assert data['myvariable'] == "somevalue"

# Generated at 2022-06-11 09:28:26.939386
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    from ansible.errors import AnsibleParserError
    import sys

    x = '''
a: 1
b:
  c: 3
  d: 4
'''

    try:
        AnsibleLoader(x).get_single_data()
    except AnsibleParserError as e:
        if sys.version_info >= (3, 0):
            assert type(e.message) is str
        else:
            assert type(e.message) is unicode
        assert type(e.wrap_info) is dict

# Generated at 2022-06-11 09:28:29.223972
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  parser = AnsibleLoader(None)
  assert parser.__class__ == AnsibleLoader
  assert parser.__doc__ == Loader.__doc__

# Generated at 2022-06-11 09:28:30.214183
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader("samplefile")

# Generated at 2022-06-11 09:28:39.291438
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Functional tests of Ansible YAML loading.
    '''

    import yaml

    assert issubclass(AnsibleLoader, yaml.parser.Parser)
    assert issubclass(AnsibleLoader, yaml.constructor.Constructor)

    yaml_str = '''# This is a sample YAML document.
    - a: 1
    - b:
        - 2
        - 3
    '''

    results = yaml.load(yaml_str, Loader=AnsibleLoader)

    assert results == [{'a': 1}, {'b': [2, 3]}]

# Generated at 2022-06-11 09:28:40.667611
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, Resolver)

# Generated at 2022-06-11 09:28:42.336542
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    the_loader = AnsibleLoader(u'[1, 2, 3]')
    assert the_loader is not None

# Generated at 2022-06-11 09:28:52.519475
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Make sure we aren't breaking with those crazy yaml files
    """
    yaml_data = '''
- hosts: all
  vars:
    var1: "{{ 'var1' }}"
    var2: "{{ 'var2' }}"
    var3: "{{ 'var3' }}"
  remote_user: root

  tasks:
  - name: Ensure {{ var3 }} package is installed
    package:
      name: "{{ var1 }}"
      state: installed

  - name: Ensure {{ var3 }} can be started
    command: /usr/sbin/service "{{ var2 }}" start
    ignore_errors: yes
    '''

     # This is a list of tasks, not a dict
    loader = AnsibleLoader(yaml_data)
    data = loader.get_single_data

# Generated at 2022-06-11 09:29:00.825703
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
        404:
          msg: Sorry, but the page you requested was not found.
        503:
          msg: Sorry, but too many people are accessing the website right now. We're working on this problem. Please try again later.
    """
    try:
        loader = AnsibleLoader(data)
        loader.get_single_data()
    except NotImplementedError:
        assert False, "NotImplementedError exception not expected"
    except AssertionError:
        assert False, "AssertionError exception not expected"
    except Exception:
        assert False, "AnsibleLoader constructor did not initialize properly"

# Generated at 2022-06-11 09:29:25.250004
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import BytesIO
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib, VaultSecret

    def make_vault_secret(password):
        tmp = ''
        for char in password:
            tmp += '{:02x}'.format(ord(char))
        return VaultSecret(None, unicode('$ANSIBLE_VAULT;1.1;AES256;' + tmp + '\r\n'))


# Generated at 2022-06-11 09:29:27.018634
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: implement
    pass

# Generated at 2022-06-11 09:29:28.410354
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None, None)

# Generated at 2022-06-11 09:29:29.227567
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-11 09:29:41.427667
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader

    raw_yaml = '''
    - hosts: localhost
      tasks:
        - name: print current working directory
          command: pwd
    '''

    if HAS_LIBYAML:
        from yaml import CSafeLoader
        from io import BytesIO
        from ansible.module_utils.six import PY3

        # Create stream:
        if PY3:
            raw_yaml = bytes(raw_yaml, 'utf-8')
        stream = BytesIO(raw_yaml)

        # Load yaml:
        loader = CSafeLoader(stream)
        data = loader.get_single_data()

    else:
        from yaml import SafeLoader
        from StringIO import StringIO

        # Create stream:


# Generated at 2022-06-11 09:29:52.529626
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-11 09:30:04.695031
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-11 09:30:09.896980
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    loader = AnsibleLoader(None, file_name="../test/units/module_utils/test_ansible_module.py")
    loader.vault_secrets = ['password1', 'password2']

    data = loader.get_single_data()

    assert isinstance(data, dict)

# Generated at 2022-06-11 09:30:16.071503
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml

    yaml_str = """
hacker: true
name:
  - Mort
  - Derrick
age: 25
foo: >
  Hello World!
bar:
  - John
  - [Dick, Gary]


"""

    constructor = AnsibleLoader(yaml_str)
    data = constructor.get_single_data()

    assert data['hacker'] is True
    assert data['name'] == ['Mort', 'Derrick']
    assert data['age'] == 25
    assert data['foo'] == "Hello World!\n"
    assert data['bar'] == ['John', ['Dick', 'Gary']]



# Generated at 2022-06-11 09:30:17.691764
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=invalid-name
    assert isinstance(AnsibleLoader, type)


# Generated at 2022-06-11 09:30:42.001066
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
    {% foo %}
    {% bar %}
     BAZ!
    {% endbar %}
    '''
    al = AnsibleLoader(data)
    al.construct_document()
    assert al.get_data() == 'BAZ!'

# Generated at 2022-06-11 09:30:53.952190
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import os
    import ansible.constants as C
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # read sample yaml file
    module_path = os.path.dirname(os.path.abspath(__file__))
    sample_yaml_file = module_path + os.sep + 'sample_vault_file.yml'
    handle = open(sample_yaml_file, 'r')
    sample_yaml_string = handle.read()

    # encrypt yaml string
    vault_secret = "vaultsecret"
    vault_id = "samplevault"

# Generated at 2022-06-11 09:31:04.094626
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_file_vault_secret
    import tempfile

    #
    # Vault stuff
    #

    (fd, vault_password_file) = tempfile.mkstemp()
    os.write(fd, b"my secret\n")
    os.close(fd)

    vault_id = "testvaultid"
    vault_password = "my secret"

    vault = VaultLib([get_file_vault_secret(vault_password_file)])
    vault_secret = vault._search_candidate_secrets([], vault_id)

    #
    # Actual code to be tested
    #

    from io import StringIO


# Generated at 2022-06-11 09:31:09.616406
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    text = u'''
list:
  - one: 1
  - two: 2
'''
    data = AnsibleLoader(text).get_single_data()
    assert data == {u'list': [{u'one': 1}, {u'two': 2}]}


if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:31:17.631159
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-11 09:31:24.482773
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
    foo: &foo
      bar: 10
      baz: *foo
    """

    loader = AnsibleLoader(data)
    loaded = loader.get_single_data()

    assert loaded['foo']['bar'] == 10
    assert loaded['foo']['baz']['bar'] == 10
    assert loaded['foo']['baz']['baz']['bar'] == 10

# Generated at 2022-06-11 09:31:29.358627
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    resolver = Resolver()
    unittest_loader = AnsibleLoader('')
    assert isinstance(unittest_loader, (Parser, Reader, Scanner, Parser, Composer))
    assert isinstance(unittest_loader, (AnsibleConstructor, Resolver))

# Generated at 2022-06-11 09:31:40.223018
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader

# Generated at 2022-06-11 09:31:43.260807
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = None
    file_name = None
    vault_secrets = None
    loader = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)

# Generated at 2022-06-11 09:31:51.374448
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.objects
    from ansible.parsing.yaml.strings import do_strip_quotes


# Generated at 2022-06-11 09:32:43.164036
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    import os

    file_name = os.path.join(os.path.dirname(__file__), 'vault_test.yml')
    test_phrase = 'foo'
    vault_secrets = [VaultLib(test_phrase).encrypt(test_phrase)]

    # Try vault-encrypted unicode string

# Generated at 2022-06-11 09:32:51.614279
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import yaml

    if sys.version_info[0] < 3:
        from io import BytesIO as IO
    else:
        from io import StringIO as IO

    test_yaml = """---
- hosts: localhost
  vars:
    var_key:
      - var_value_1
      - var_value_2
  tasks:
  - shell: echo "{{ var_key }}"
"""

    if sys.version_info[0] < 3:
        data = yaml.load(IO(test_yaml), Loader=AnsibleLoader)
    else:
        data = yaml.load(IO(test_yaml), Loader=AnsibleLoader)


# Generated at 2022-06-11 09:32:52.331304
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# Generated at 2022-06-11 09:32:56.399520
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    line = '---\n- hosts: localhost\n\n'
    yaml_data = AnsibleLoader(line).get_single_data()
    assert yaml_data == [{'hosts': 'localhost'}], yaml_data

# Generated at 2022-06-11 09:33:10.825415
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
- hosts:
    - all
  vars:
    a: my
    b: 7
  tasks:
  - name: task1
    command: mycommand
    sudo: yes
    sudo_user: bob
    sudo_password: "{{ lookup('password', '/path/to/file/bob_password foo={{ a }}') }}"
    with_items: "{{ somelist }}"
    # this is a comment
    when: ansible_os_family == "RedHat"
  - name: task2
    command: myothercommand
    when: ansible_os_family == "Debian"
    # another comment
    with_items: "{{ [1,2,3] }}"
'''
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()


# Generated at 2022-06-11 09:33:13.115285
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    load = AnsibleLoader(open('/dev/null', 'r'))
    assert load is not None


# Generated at 2022-06-11 09:33:15.319371
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # AnsibleLoader(stream, file_name=None, vault_secrets=None)
    # TODO: testing
    pass

# Generated at 2022-06-11 09:33:21.313979
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnicode
    import io
    import unittest

    class TestAnsibleLoader(unittest.TestCase):

        def test_vault_encrypted_string_constructor(self):
            '''
            Tests the vault encrypted string constructor in AnsibleLoader
            '''

# Generated at 2022-06-11 09:33:28.557707
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    input_stream = '''
    - hosts: localhost
      gather_facts: False
      conn_id: default
      tasks:
      - debug:
          msg: "Hello World!"
    '''
    data = AnsibleLoader(input_stream)

    # The exact form of the data is not important for our purposes,
    # the fact that this doesn't raise an exception is enough
    assert(data is not None)

# Generated at 2022-06-11 09:33:32.136498
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """ AnsibleLoader has the correct ancestors """
    assert issubclass(AnsibleLoader, Parser)
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert issubclass(AnsibleLoader, Resolver)

# Generated at 2022-06-11 09:35:11.152503
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.six import PY3
    from unit.mock.loader import DictDataLoader

    data = b"""
a: 1
b:
  c: 3
d: [4, 5]
e: !!str 6
f: !!python/unicode 7
g: !!python/str 8
h: !!python/name:datetime.datetime year=2012, month=11, day=19, hour=8, minute=23, second=48, microsecond=12345
"""

# Generated at 2022-06-11 09:35:12.954383
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('{"a": "b"}')
    assert loader.get_single_data() == {'a': 'b'}

# Generated at 2022-06-11 09:35:14.440627
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert isinstance(AnsibleLoader, object)


# Generated at 2022-06-11 09:35:22.728252
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Test ansible custom constructor.
    """

    from ansible.parsing.yaml.objects import AnsibleUnicode
    import collections

    yaml_str = u"""
        foo: !!python/name:collections.OrderedDict
            bar: baz
        bam: !!python/name:collections.OrderedDict
            baz:
                - !!python/name:collections.OrderedDict
                    one: two
                - !!python/name:collections.OrderedDict
                    two: three
    """

    first_expected = collections.OrderedDict({'bar': 'baz'})
    first_expected.yaml_set_anchor(None, 'foo')

# Generated at 2022-06-11 09:35:30.336445
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=protected-access
    stream = """
---
- hosts: localhost
  tasks:
    - name: Basic print
      debug:
        msg: "hello world"
"""
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()

    assert 'hosts' == data[0][0]
    assert isinstance(data, list)
    assert isinstance(data[0], list)
    assert isinstance(data[0][1], dict)
    assert 'tasks' == data[0][1]['tasks'][0]


# TODO: unit tests?
# Unit tests for class AnsibleLoader, function compose_document