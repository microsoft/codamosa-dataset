

# Generated at 2022-06-11 09:25:35.528767
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    valid_yaml = """
    ---
    - hosts: all
      gather_facts: false
      tasks:
      - name: test
        ping:
    """

    AnsibleLoader(valid_yaml)

# Generated at 2022-06-11 09:25:45.020812
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    sample_yaml = """
    ---
    foo: ok
    bar:
      baz:
        - 5
        - 4
        - 3
    ...
    """

    loader = AnsibleLoader(sample_yaml)
    the_doc = loader.get_single_data()
    assert the_doc == {'foo': 'ok', 'bar': {'baz': [5, 4, 3]}}

    sample_yaml = """
    ---
    foo: ok
    bar:
      baz:
        - 5
        - 4
        - 3
    ...
    """

    loader = AnsibleLoader(sample_yaml, vault_secrets=['secret'])
    the_doc = loader.get_single_data()

# Generated at 2022-06-11 09:25:53.446447
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import shutil
    import tempfile
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor

    # Create temporary file
    fd, temp_file = tempfile.mkstemp()
    # Open temporary file

# Generated at 2022-06-11 09:26:01.984977
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml_str = """
- hosts: localhost
  tasks:
  - debug:
      msg: AnsibleLoader test
    tags: test
    when: 1 == 1
    """
    print("### test AnsibleLoader()")
    stream = yaml.load(yaml_str, Loader=AnsibleLoader)
    print("type: %s" % type(stream))
    print("stream: %s" % stream)
    print("")

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:26:14.113020
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser
    from yaml.composer import Composer

    class AnsibleDummy(Reader, Scanner, Parser, Composer):
        def __init__(self, stream):
            Reader.__init__(self, stream)
            Scanner.__init__(self)
            Parser.__init__(self)
            Composer.__init__(self)

    ad = AnsibleDummy(None)
    assert len(ad.__dict__.keys()) == 7
    assert len(AnsibleDummy.__bases__) == 4

    assert len(AnsibleLoader.__bases__) == 6
    al = AnsibleLoader(None)

# Generated at 2022-06-11 09:26:16.173054
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test that the class can be loaded and does not raise exceptions
    AnsibleLoader(file_name='foobar', vault_secrets=None)

# Generated at 2022-06-11 09:26:17.118262
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader


# Generated at 2022-06-11 09:26:18.435555
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader


# Generated at 2022-06-11 09:26:32.420910
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.compat.tests.mock import patch, MagicMock

    my_data = {
        'spam': 'eggs',
        'foo': {
            'bar': 'baz'
        }
    }

    # Read in some test yaml
    yaml_str = '''
---
spam: eggs
foo:
  bar: baz
'''

    with patch('__main__.AnsibleDumper', MagicMock(spec=AnsibleDumper)):
        # Create an AnsibleLoader instance
        dummy_file_name = 'dummy'
        loader = AnsibleLoader(yaml_str, file_name=dummy_file_name)

        # Convert loaded data to a Python dictionary
        parsed

# Generated at 2022-06-11 09:26:33.525691
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None, None, None)

# Generated at 2022-06-11 09:26:46.537382
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class TestAnsibleLoader(unittest.TestCase):
        def test_loader(self):
            stream = open(os.path.join("lib", "ansible", "parsing", "yaml", "tests", "test1.yaml"))
            data = AnsibleLoader(stream).get_single_data()
            self.assertEqual(['foo', 'bar', 'baz'], data)
            # verify that the vault object is created
            self.assertIsInstance(data[0], AnsibleVaultEncryptedUnicode)

       

# Generated at 2022-06-11 09:26:47.514429
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader


# Generated at 2022-06-11 09:26:59.272081
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    s = """
    foo:
    - bar: baz
      baz: foo
    - bar: foo
    - bar: blah
      blah: blah
    foobar: foo
    """
    loader = AnsibleLoader(None, vault_secrets=dict(v='vualt_value'))
    assert loader.vault_secrets == dict(v='vualt_value')
    res = loader.get_single_data(s)
    assert res == dict(foo=[dict(bar='baz', baz='foo'), dict(bar='foo'), dict(bar='blah', blah='blah')], foobar='foo') # pylint: disable=line-too-long

# Generated at 2022-06-11 09:27:05.161965
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.six import PY3, text_type
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-11 09:27:12.941154
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader(): # pylint: disable=unused-variable
    from ansible.parsing.vault import VaultLib

    vault_secrets = VaultLib(["vault_password"])
    data = """
    vault_password: secret
    """
    loader = AnsibleLoader(data, vault_secrets=vault_secrets)
    inventory = loader.get_single_data()
    assert inventory['vault_password'] == 'secret'

# Generated at 2022-06-11 09:27:14.362913
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader


# Generated at 2022-06-11 09:27:16.351034
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:27:18.229065
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # We can't really test this due to how AnsibleLoader inherits from Resolver
    assert True


# Generated at 2022-06-11 09:27:20.400098
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=no-member
    test_load = Parser.from_yaml
    assert isinstance(test_load, type(Parser))

# Generated at 2022-06-11 09:27:30.466179
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    s = """
        ---
        - { 'name': 'foo', 'age': 10 }
        - { 'name': 'bar', 'age': 20 }
        - { 'name': 'baz', 'age': 30 }
        """
    d = yaml.load(s, AnsibleLoader)
    assert isinstance(d, list)
    assert len(d) == 3
    assert d[0] == {u'name': u'foo', u'age': 10}
    assert d[1] == {u'name': u'bar', u'age': 20}
    assert d[2] == {u'name': u'baz', u'age': 30}

# Generated at 2022-06-11 09:27:38.789877
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, Parser)
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert issubclass(AnsibleLoader, Resolver)

# Generated at 2022-06-11 09:27:50.448944
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import itertools
    import sys
    import os

    import pytest
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    stream = open(os.path.join(os.path.dirname(__file__), 'loader_tests.data'), 'rb')
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    print(data)

    assert isinstance(data, dict)
    stream.close()

    stream = open('/tmp/loader_tests.data', 'wb')
    stream.write(b'---\n- key: value\n')
    stream.close()

    stream = open('/tmp/loader_tests.data', 'rb')

# Generated at 2022-06-11 09:27:51.053256
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-11 09:27:53.663715
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import pytest

    # This test is designed to fail, we need to check that class was initialized correctly
    # when loading any Ansible YAML file
    with pytest.raises(Exception):
        AnsibleLoader('')

# Generated at 2022-06-11 09:27:56.499670
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
- debug:
    msg: hello world
- debug:
    msg: this is a test
'''
    AnsibleLoader(stream)

# Generated at 2022-06-11 09:27:59.088449
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    This is a placeholder that will be removed when tests are added.
    """
    pass

# Generated at 2022-06-11 09:28:11.966433
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=too-many-locals
    try:
        import yaml
    except ImportError:
        raise AssertionError("you must install the PyYAML module to use this class")

    # The class is initialized with a stream and optional file_name and vault_secrets
    load = AnsibleLoader(stream='---\na: 1\n')
    assert type(load).__name__ == 'AnsibleLoader'
    assert load._vault_secrets == None
    assert load.file_name == None

    load = AnsibleLoader(stream='---\na: 1\n', file_name='testyaml')
    assert type(load).__name__ == 'AnsibleLoader'
    assert load.file_name == 'testyaml'

    # The class AnsibleLoader contains the methods 'set_v

# Generated at 2022-06-11 09:28:19.796373
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import codecs
    #from ansible.parsing.yaml.constructor import AnsibleConstructor
    #from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    yaml = '''
a: 5
b:
  - 1
  - 2
'''
    yaml_unicode = u'''
a: 5
b:
  - 1
  - 2
'''
    # test yaml and then test yaml with unicode
    for y in [yaml, yaml_unicode]:
        # test yaml load from string
        #print("START")
        #print("\n")
        ansible_constructor = AnsibleConstructor(None)

# Generated at 2022-06-11 09:28:23.024623
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    This is used to test import of AnsibleLoader object
    '''
    print('yaml loader is imported successfully')
    return True

# Generated at 2022-06-11 09:28:25.276528
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Ensure constructor can be called (this is a regression test for #9603)
    AnsibleLoader(None, '')

# Generated at 2022-06-11 09:28:35.521493
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:28:40.719889
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    string = u'{"a": "abc"}\n'
    loader = AnsibleLoader(string)
    data = loader.get_single_data()
    assert data['a'] == 'abc'
    assert type(data['a']) is AnsibleUnicode

# Generated at 2022-06-11 09:28:46.054008
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os.path
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    dir_name = os.path.dirname(__file__)
    data = loader.load_from_file(os.path.join(dir_name, 'test.yml'))
    assert data is not None
    assert data[0] == "spam"
    assert data[1]['spam'] is True
    assert data[2] == "spam and eggs"

# Generated at 2022-06-11 09:28:48.200071
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    al = AnsibleLoader("foo") # pylint: disable=redefined-variable-type
    assert al.stream == "foo"

# Generated at 2022-06-11 09:28:59.835877
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # As the class AnsibleLoader depends on external modules, it can't be
    # tested here.
    loader = AnsibleLoader('{}', file_name=None, vault_secrets=None)

    assert hasattr(loader, 'get_data')
    assert hasattr(loader, 'construct_mapping')
    assert hasattr(loader, 'construct_yaml_map')
    assert hasattr(loader, 'construct_yaml_seq')
    assert hasattr(loader, 'construct_yaml_str')
    assert hasattr(loader, 'construct_undefined')
    assert hasattr(loader, 'construct_yaml_int')
    assert hasattr(loader, 'construct_yaml_bool')
    assert hasattr(loader, 'construct_yaml_omap')

# Generated at 2022-06-11 09:29:02.997267
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = None
    file_name = 'test'
    vault_secrets = None

    assert AnsibleLoader(stream, file_name, vault_secrets)

# Generated at 2022-06-11 09:29:04.852932
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = file('/dev/null', 'r')
    loader = AnsibleLoader(stream)
    assert loader is not None

# Generated at 2022-06-11 09:29:05.863968
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader

# Generated at 2022-06-11 09:29:06.906787
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-11 09:29:14.576500
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import pytest  # pylint: disable=import-error

    loader = AnsibleLoader(None, vault_secrets=['vault_secret'])
    assert loader.vault_secrets == ['vault_secret']
    assert not HAS_LIBYAML or loader.encoding == 'utf-8'

    # if no file name given, file_name sould be None
    assert loader.file_name is None

    # if file name given, file_name should be the given file name
    file_name = 'foo.yml'
    loader = AnsibleLoader(None, file_name=file_name, vault_secrets=['vault_secret'])
    assert loader.file_name == file_name

if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-11 09:29:43.443452
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:29:45.615536
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ''' unit testing for AnsibleLoader class via constructor '''
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-11 09:29:46.231195
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:29:48.750589
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, 'construct_object')
    assert callable(AnsibleLoader.construct_object)


# Generated at 2022-06-11 09:29:52.421782
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = [ u'foo: bar' ]
    loader = AnsibleLoader(stream)
    loader.get_single_data()
    assert not hasattr(loader, 'version')


# Generated at 2022-06-11 09:30:04.585497
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    from ansible.module_utils.common.yaml import variants
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    yaml_snippet = u"""
        - hash_key1:
            - key: value
            - key: value
        - key:
          - subkey:
              - subsubkey: value
          - key: value
          - subkey: value
          - key: value
        - hash_key2:
            - key: value
            - key: value
        """

    yaml_data = variants.PyYAML().load(yaml_snippet)
    loader = AnsibleLoader(yaml_snippet)
    parsed_data = loader.get_single

# Generated at 2022-06-11 09:30:13.852286
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert hasattr(AnsibleLoader, '__init__')

AnsibleLoader.add_constructor('', AnsibleConstructor.construct_yaml_map)
AnsibleLoader.add_constructor('tag:yaml.org,2002:map', AnsibleConstructor.construct_yaml_map)
AnsibleLoader.add_constructor('tag:yaml.org,2002:omap', AnsibleConstructor.construct_yaml_map)

AnsibleLoader.add_constructor('tag:yaml.org,2002:str', AnsibleConstructor.construct_yaml_str)
AnsibleLoader.add_constructor('tag:yaml.org,2002:binary', AnsibleConstructor.construct_yaml_str)
Ansible

# Generated at 2022-06-11 09:30:24.175204
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import ansible.parsing.yaml.objects

    class TestAnsibleLoader(AnsibleLoader):
        pass

    yaml_str = '''
    - hosts: all
      gather_facts: no
      tasks:
        - name: test_dict
          test_dict:
            key1: value1
            key2: value2
        - name: test_list
          test_list:
            - list_element_1
            - list_element_2
    '''

    data = TestAnsibleLoader(yaml_str).get_single_data()

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    assert isinstance(data, AnsibleSequence)
    assert len(data) == 1

# Generated at 2022-06-11 09:30:26.635470
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # This should not raise an exception
    AnsibleLoader("[1,2,3]")

# Generated at 2022-06-11 09:30:27.384853
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader()

# Generated at 2022-06-11 09:31:15.120892
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    # test scalar parsing
    data = '''
{"a": {"b": 1}, "c": [1,2,3]}
'''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_data(), AnsibleMapping)

    # test true scalar
    data = '''
{"a": {"b": true}, "c": [true,true,true]}
'''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_data(), AnsibleMapping)

    # test false scalar
    data = '''
{"a": {"b": false}, "c": [false,false,false]}
'''
    loader = AnsibleLoader(data)

# Generated at 2022-06-11 09:31:22.603401
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    simple = """
        test: 1
        list:
            - Hello
            - World
        dict:
            Hello: World
            Foo: Bar
    """

    aloader = AnsibleLoader(stream=simple)

    assert aloader.get_single_data() == {'dict': {'Hello': 'World', 'Foo': 'Bar'}, 'list': ['Hello', 'World'], 'test': 1}

# Generated at 2022-06-11 09:31:34.245894
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    data = '''
    # A comment
    --- # Another comment
    - nfs:  # yet another comment
        server: foo.bar.invalid
        path: /srv/nfs/user
        state: present
        fstype: nfs
        options:
            - rw
            - hard
            - intr
            - noatime
    ... # final comment
    '''

    loader = AnsibleLoader(data)
    target = loader.get_single_data()

    assert type(target) is list
    assert len(target) == 1
    nfs_task = target[0]
    assert type(nfs_task) is dict
    assert nfs_task.keys() == ['nfs']
    nfs_args = nfs_task['nfs']
    assert 'path' in nfs_args

# Generated at 2022-06-11 09:31:39.706790
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
{% raw %}
---
key1 : value1
key2 : value2
{% endraw %}
'''
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert dict == type(data)
    assert data['key1'] == 'value1'
    assert data['key2'] == 'value2'


# Generated at 2022-06-11 09:31:40.639625
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)



# Generated at 2022-06-11 09:31:44.419610
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestClass(object):
        loader = AnsibleLoader(None)
        return_value = loader.construct_yaml_str(None)
        assert return_value is None


if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:31:46.761133
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_loader = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    assert( test_loader.file_name == None )

# Generated at 2022-06-11 09:31:47.094044
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# Generated at 2022-06-11 09:31:52.092609
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    test_data = """
---
- hosts: localhost
  vars:
    action: setup
  tasks:
  - name: Get some facts
    setup:
"""

    # Read the data using AnsibleLoader
    data = AnsibleLoader(test_data).get_single_data()

    # Check if the data is correctly loaded
    assert data['hosts'] == 'localhost'
    assert data['vars']['action'] == 'setup'
    assert data['tasks'][0]['name'] == 'Get some facts'
    assert data['tasks'][0]['setup'] is None

# Generated at 2022-06-11 09:31:58.918783
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    import yaml
    test_dict = dict(a=dict(b=[1, 2, 3]))
    test_yaml = yaml.dump(test_dict)
    test_yaml_bytestring = bytes(test_yaml, 'utf-8')
    test_yaml_stream = StringIO(test_yaml)

    assert isinstance(AnsibleLoader(test_yaml), yaml.composer.Composer)
    assert isinstance(AnsibleLoader(test_yaml_bytestring), yaml.composer.Composer)
    assert isinstance(AnsibleLoader(test_yaml_stream), yaml.composer.Composer)

# Generated at 2022-06-11 09:33:29.255444
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.vars.unsafe_proxy import UnsafeProxy

    stream = """---
- hosts: localhost
  gather_facts: no
  pre_tasks:
    - debug: msg="This is an unsafe task"
      delegate_to: 127.0.0.1
"""
    loader = AnsibleLoader(stream, file_name='<string>')
    inventory = loader.get_single_data()
    assert 'pre_tasks' in inventory[0], "Got %s" % inventory
    assert isinstance(inventory[0]['pre_tasks'][0], UnsafeProxy), "Got %s" % inventory

# Generated at 2022-06-11 09:33:35.647477
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=too-many-function-args
    loader = AnsibleLoader('{}')
    assert loader
    assert not loader.stream

    # pylint: disable=too-many-function-args
    loader = AnsibleLoader(stream='{}')
    assert loader
    assert loader.stream

if __name__ == '__main__':
    AnsLoader = test_AnsibleLoader()
    AnsLoader

# Generated at 2022-06-11 09:33:37.151606
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleConstructor)

# Generated at 2022-06-11 09:33:40.911058
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import StringIO

    def test_method(loader, node):
        print(loader, node)

    loader = AnsibleLoader(StringIO.StringIO())
    loader.add_constructor('!dump', test_method)
    loader.load('--- !dump\nfoo: bar')

# Generated at 2022-06-11 09:33:41.529387
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-11 09:33:45.777885
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    d = b'''
    - hosts: localhost
      tasks:
        - name: test
          ping:
    '''
    # io.StringIO() expects unicode so we need to decode from utf-8 to unicode
    d = io.StringIO(str(d.decode('utf-8')))
    c = AnsibleLoader(d)
    for data in c:
        pass


# Generated at 2022-06-11 09:33:55.582047
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open("tests/yaml_loader/simple.yml", "r")
    loader = AnsibleLoader(stream)
    data = loader.get_data()
    assert 'one' in data
    assert data['one'] == '1'
    assert 'two' in data
    assert data['two'] == '2'
    assert 'three' in data
    assert data['three'] == '3'
    assert 'four' in data
    assert data['four'] == '4'
    assert 'five' in data
    assert data['five'] == '5'
    assert 'six' in data
    assert data['six'] == '6'
    assert 'seven' in data
    assert data['seven'] == '7'
    assert 'eight' in data
    assert data['eight'] == '8'

# Generated at 2022-06-11 09:34:05.923322
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import json

    directory = os.path.dirname(os.path.realpath(__file__))
    tmp_directory = os.path.join(directory, "..", "..", "tmp")

    if not os.path.exists(tmp_directory):
        os.makedirs(tmp_directory)

    tmp_file = os.path.join(tmp_directory, "ansible_loader.yaml")

    # write a temp file
    with open(tmp_file, "w") as fd:
        fd.write("foo: ['bar', 'baz']\n")

    # create an instance of AnsibleLoader
    ansible_loader = AnsibleLoader(open(tmp_file))

    # read and load the file
    data = ansible_loader.get_single_data

# Generated at 2022-06-11 09:34:07.967491
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert (loader.__class__.__name__ == 'AnsibleLoader')

# Generated at 2022-06-11 09:34:11.647963
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    # test constructor
    x = AnsibleLoader(file_name=None, vault_secrets=None, stream=io.StringIO("key: {}"))
    # test 'construct_mapping' method
    y = x.construct_mapping(node=None)
    assert y == {'key': {}}