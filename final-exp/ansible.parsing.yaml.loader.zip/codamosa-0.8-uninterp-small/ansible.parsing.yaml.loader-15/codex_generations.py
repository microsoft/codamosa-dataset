

# Generated at 2022-06-25 04:32:09.558753
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xc5\x83\xc5\x9e)\\\xdf\xaa\x19\x1a\n\x8e'
    ansible_loader_0 = AnsibleLoader(bytes_0)
# verify that the instance is correct
    assert isinstance(ansible_loader_0, AnsibleLoader)

# unit tests for ansible.parsing.yaml.objects.AnsibleMapping

# Generated at 2022-06-25 04:32:16.942468
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(string_0)
    # assert type(ansible_loader_0) == AnsibleLoader
    # assert ansible_loader_0 == ansible_loader_0
    # assert ansible_loader_0 != ansible_loader_1
    # assert hash(ansible_loader_0) != hash(ansible_loader_1)


# Generated at 2022-06-25 04:32:23.111457
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ""
    file_name = None
    vault_secrets = None
    obj = AnsibleLoader(stream, file_name, vault_secrets)
    assert obj.file_name == None
    assert obj.vault_secrets == None
    assert obj.line_number == 0


# Generated at 2022-06-25 04:32:25.156124
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'{a: 1, b: 2}'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    ansible_loader_0.construct_object()

# Generated at 2022-06-25 04:32:35.133382
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # class Test1(AnsibleLoader):
    #     def __init__(self, a0, a1, a2):
    #         super(Test1, self).__init__(a0, a1, a2)
    #         self.a0 = a0
    #         self.a1 = a1
    #         self.a2 = a2
    #
    # a = Test1('a', 'b', 'c')
    #
    # assert a.a0 == 'a'
    # assert a.a1 == 'b'
    # assert a.a2 == 'c'

    class Test2(AnsibleLoader):
        def __init__(self, a0, a1, a2):
            super(Test2, self).__init__(a0, a1, a2)

   

# Generated at 2022-06-25 04:32:36.884753
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:32:45.542115
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\x0c&\x14\xa5\xcb\xe5\xfd\x9d\xe5\x9b"\xad\x1dK\x12\x10\xdb\x8b\xc2\x1dy\xdey\xbe\xde\x98\xea\x03\x0f\x1e\x9a'
    ansible_loader_0 = AnsibleLoader(bytes_0)

# Generated at 2022-06-25 04:32:56.215105
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_1 = b'\xf2\x8c\x12\x9c\xde\xad*\x96\x80\xad\xbe\xef8\xa2-\x95\xac\xbe\x82\xec\x91\xb2'
    str_0 = 'This is a test'
    file_name_0 = b'/etc/ansible/ansible.cfg'
    file_name_1 = '/etc/ansible/ansible.cfg'
    ansible_loader_0 = AnsibleLoader(bytes_1)
    ansible_loader_1 = AnsibleLoader(str_0)
    ansible_loader_2 = AnsibleLoader(file_name_0)
    ansible_loader_3 = AnsibleLoader(file_name_1)


# Generated at 2022-06-25 04:33:03.040495
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\x9d\x9a\x05\x00\x8c.\x1a\x0e\xca\x8a\xec\xa0\x1e\x8a'
    file_name_0 = '\x8d\x8d\x9b\x09\xec\x1d?\xf3\x12\xc6\x0e\xca\x88\xa0\x1e\x8a'
    vault_secrets_0 = dict()
    ansible_loader_0 = AnsibleLoader(bytes_0, file_name_0, vault_secrets_0)



# Generated at 2022-06-25 04:33:09.295334
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # A fresh instance of AnsibleLoader is created
    ansible_loader_0 = AnsibleLoader()

    # The docs and __init__ of AnsibleLoader are being tested.
    import inspect  # pylint: disable=unused-import
    member = inspect.getmembers(ansible_loader_0, predicate = inspect.ismethod)

if __name__ == '__main__':
    import pytest
    pytest.main(['-q', __file__])
    #
    # print('--- Begin unit tests ---')
    # test_AnsibleLoader()
    # print('--- End unit tests ---')

# Generated at 2022-06-25 04:33:18.568246
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO pass vault_secrets to __init__()
    vault_secrets = '*chop,chop*'
    ansible_loader_0 = AnsibleLoader(Nones, Nones, vault_secrets)
    assert (not isinstance(vault_secrets, basestring))
    assert (vault_secrets is not None)
    assert (isinstance(vault_secrets, dict))
    assert (isinstance(ansible_loader_0, AnsibleLoader))
    expected = False
    got = isinstance(ansible_loader_0._root, Parser)
    assert expected == got


# Generated at 2022-06-25 04:33:22.227735
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # AnsibleLoader() constructor does not take any argument
    with pytest.raises(TypeError) as excinfo:
        ansible_loader_object = AnsibleLoader()



# Generated at 2022-06-25 04:33:32.985878
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(None)
    assert (not ansible_loader_0.anchors)
    assert (not ansible_loader_0.constructed_objects)
    assert (not ansible_loader_0.cached_nodes)
    assert (not ansible_loader_0.constructed_object_map)
    assert (not ansible_loader_0.stream)
    assert (not ansible_loader_0.compiled_patterns)
    assert (not ansible_loader_0.shared_state)
    assert (not ansible_loader_0.anchor_id)
    assert (not ansible_loader_0.constructed_object_id)
    assert (not ansible_loader_0.shared_state_id)

# Generated at 2022-06-25 04:33:39.784908
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:33:43.573744
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # ansible_loader_0 is an instance of AnsibleLoader
    # str_0 is an instance of str
    # ansible_loader_1 is an instance of AnsibleLoader
    ansible_loader_0 = AnsibleLoader((str_0, ))
    assert isinstance(ansible_loader_0, AnsibleLoader)


# Generated at 2022-06-25 04:33:45.220407
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert isinstance(AnsibleLoader, object)

    # test for AnsibleLoader.__init__()
    assert callable(AnsibleLoader.__init__)

# Generated at 2022-06-25 04:33:54.377365
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # initializing stream with empty bytes
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    # initializing file_name with 'file'
    file_name_0 = 'file'
    # initializing vault_secrets with empty dictionary
    vault_secrets_0 = {}

# Generated at 2022-06-25 04:34:00.261507
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'y\x8d\x93\xae\x14\x1f\xb9\xb9\xcc\xf4\x0e\xbe\x94\x12K\x1fA\xba'
    file_name_0 = '=\xc7\xbe\x02\x0f\xe1\xfe\xdc2\xa0\x14\x15-\x9f'
    ansible_loader_0 = AnsibleLoader(bytes_0, file_name_0)

# Generated at 2022-06-25 04:34:10.741440
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:34:18.709636
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import types
    import builtins
    import collections
    import yaml
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser
    from yaml.composer import Composer
    from yaml.constructor import Constructor
    from yaml.resolver import Resolver
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    ansible_loader_0 = AnsibleLoader("a", "b", "c")

    if not isinstance(ansible_loader_0, types.ModuleType):
        raise Exception("ansible_loader_0 is not an instance of types.ModuleType.")


# Generated at 2022-06-25 04:34:24.576121
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(None)

# Generated at 2022-06-25 04:34:28.084678
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'=\xc7\xbe\x02\x0f\xe1\xfe\xdc2\xa0\x14\x15-\x9f'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    # Check instantiation
    assert isinstance(ansible_loader_0, AnsibleLoader)

# Generated at 2022-06-25 04:34:34.763535
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\x01\x08\x85\xc8\x0c\xeb\xfc\x0f\xe0\xf7\xbdN\x9a'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    bytes_1 = b'\x00\x94\x02\xfa\x0c\xeb\xfc\x0f\xe0\xf7\xbdN\x9a'
    ansible_loader_0 = AnsibleLoader(bytes_1)


# Generated at 2022-06-25 04:34:41.907453
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'[\xf7\x04\x9f\x9e\x90\xe3\xb3\xf8\x1b\x02\xcf\x11\x89\x1a\xa4\x82\x12\x04\x8b\xb0\x1c'
    ansible_loader_0 = AnsibleLoader(bytes_0, 'file_name_0')
    bytes_1 = b'\t\x9f\xed\x1a\x04\xb8\x08h\x1e\xca\x13\x8c\xeb\xdd\rn.z\x1c'
    ansible_loader_1 = AnsibleLoader(bytes_1, file_name='file_name_1')
    str_0 = ansible_loader

# Generated at 2022-06-25 04:34:45.842457
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(b'\xfe\xd1\x14')
    assert ansible_loader_0.vault_secrets == None and ansible_loader_0.file_name == None

if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:34:52.834202
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:34:55.076004
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    stream = None
    file_name = None
    vault_secrets = None
    AnsibleLoader(stream, file_name, vault_secrets)

# Generated at 2022-06-25 04:34:58.291904
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert callable(AnsibleLoader)

# Generated at 2022-06-25 04:34:59.088296
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True == True


# Generated at 2022-06-25 04:35:00.698631
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert (AnsibleLoader)


# Generated at 2022-06-25 04:35:15.734548
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\x99lJ\x8b\xda~\xa0\x9a\x8a\xad\xf6\xf4\xdd\x1b\x1f\x9e'
    ansible_loader_0 = AnsibleLoader(bytes_0, file_name=str(), vault_secrets=str())
    bytes_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    ansible_loader_1

# Generated at 2022-06-25 04:35:24.503673
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.module_utils.common.yaml import Parser
    from ansible.parsing.yaml import AnsibleLoader

    # Test using byte string as arg
    bytes_0 = b'\x00\x01\x02\x03'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert ansible_loader_0.file_name is None
    assert ansible_loader_0.vault_secrets is None

    # Test using non-byte string as arg
    string_0 = '\x00\x01\x02\x03'
    try:
        ansible_loader_0 = AnsibleLoader(string_0)
    except TypeError:
        pass
    else:
        raise

# Generated at 2022-06-25 04:35:33.550076
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:35:38.557907
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\x0c\xbf\x8a\x1c\x95\xc6\xcb\xe5\x0f\xee\x9bM\xf1\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert ansible_loader_0.get_single_data() == b'\x0c\xbf\x8a\x1c\x95\xc6\xcb\xe5\x0f\xee\x9bM\xf1\x0f'


# Generated at 2022-06-25 04:35:40.520314
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(b'#@')
    assert ansible_loader_0
    assert isinstance(ansible_loader_0, AnsibleLoader)

# Generated at 2022-06-25 04:35:50.672210
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream_0 = b'=\xc7\xbe\x02\x0f\xe1\xfe\xdc2\xa0\x14\x15-\x9f'
    file_name_0 = '=\xc7\xbe\x02\x0f\xe1\xfe\xdc2\xa0\x14\x15-\x9f'
    vault_secrets_0 = '=\xc7\xbe\x02\x0f\xe1\xfe\xdc2\xa0\x14\x15-\x9f'
    ansible_loader_0 = AnsibleLoader(stream_0, file_name=file_name_0, vault_secrets=vault_secrets_0)
    ansible_loader_0.get_single_data()


# Generated at 2022-06-25 04:35:58.346807
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:36:00.406422
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:36:10.032015
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(None)
    # Verify that the class AnsibleLoader is an instance of the class AnsibleConstructor
    assert isinstance(ansible_loader_0, AnsibleConstructor)
    # Verify that the class AnsibleLoader is an instance of the class Resolver
    assert isinstance(ansible_loader_0, Resolver)
    # Verify that the class AnsibleLoader is an instance of the class Parser
    assert isinstance(ansible_loader_0, Parser)
    # Verify that the class AnsibleLoader is an instance of the class Reader
    assert isinstance(ansible_loader_0, Reader)
    # Verify that the class AnsibleLoader is an instance of the class Scanner
    assert isinstance(ansible_loader_0, Scanner)
    # Verify that the class AnsibleLoader is an instance

# Generated at 2022-06-25 04:36:20.613406
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # 1 test
    bytes_0 = b'#\x0c\xe7\x85 \x99\x1d\x1f\x03\xc5;\xf7>\xfb\xd0\xde\x0c'
    ansible_loader_0 = AnsibleLoader(bytes_0)

    # 2 test
    bytes_0 = b'\xf1m\xb1\xe3\xc7;\x947\xd7\x04\xac\xd1[\xdd\xfc\xd1\x80'
    ansible_loader_0 = AnsibleLoader(bytes_0)

    # 3 test

# Generated at 2022-06-25 04:36:49.576600
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = bytes('')
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert_equal(ansible_loader_0.stream.__class__.__name__, 'Stream')
    assert_equal(ansible_loader_0.reader.__class__.__name__, 'Reader')
    assert_equal(ansible_loader_0.scanner.__class__.__name__, 'Scanner')
    assert_equal(ansible_loader_0.composer.__class__.__name__, 'Composer')
    assert_equal(ansible_loader_0.parser.__class__.__name__, 'Parser')
    assert_equal(ansible_loader_0.constructor.__class__.__name__, 'AnsibleConstructor')

# Generated at 2022-06-25 04:37:00.369091
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test for type of argument stream
    bytes_0 = b'\xfc\xf9\x1bY\xb5\xf2'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert isinstance(ansible_loader_0, Parser) == True # instance of
    assert isinstance(ansible_loader_0, AnsibleConstructor) == True # instance of
    assert isinstance(ansible_loader_0, Resolver) == True # instance of
    # Test for type of argument file_name
    bytes_0 = b'\xfc\xf9\x1bY\xb5\xf2'
    ansible_loader_0 = AnsibleLoader(bytes_0, 'bolstered')
    assert isinstance(ansible_loader_0, Parser) == True # instance of

# Generated at 2022-06-25 04:37:01.846481
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(bytes_0)


# Generated at 2022-06-25 04:37:10.368645
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:37:19.930818
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:37:28.619932
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'=\xc7\xbe\x02\x0f\xe1\xfe\xdc2\xa0\x14\x15-\x9f'
    file_name_0 = '4@$\xd8\xf3#\xa3\x1d\x9bA\xe1\x1e\xba'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert (type(ansible_loader_0) == AnsibleLoader)

# Generated at 2022-06-25 04:37:32.683145
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader('G')
    try:
        ansible_loader_0.get_init_value('test')
    except Exception as exception_instance_0:
        print(str(exception_instance_0))
    try:
        ansible_loader_0.get_init_value('test')
    except Exception as exception_instance_1:
        print(str(exception_instance_1))
    if ansible_loader_0: # TODO: fix bug with PyYAML where 'if <PyYAML instance>' evaluates to False even when it is not empty
        ansible_loader_0.get_init_value('test')
        ansible_loader_0.__delitem__('test')
    else:
        pass

# Generated at 2022-06-25 04:37:41.105293
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xa4\xd2\x14\x17\x92\x01\xb4\x14\x87\x9b\x07\xeb\xad\x94\x1c\xad\xdb\x19\xe3\x93\x8b\xaf\x0c\x85\x93\x1b\x16\x1d\x18\x8c'
    ansible_loader_0 = AnsibleLoader(bytes_0)

# Generated at 2022-06-25 04:37:42.331905
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Testing empty arguments
    ansible_loader_0 = AnsibleLoader()


# Generated at 2022-06-25 04:37:47.733749
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert(not AnsibleLoader(None))
    assert(not AnsibleLoader(None, None))
    assert(not AnsibleLoader(None, None, None))
    assert(not AnsibleLoader(None, None, None, None))

# Generated at 2022-06-25 04:38:42.591770
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        bytes_0 = b'=\xc7\xbe\x02\x0f\xe1\xfe\xdc2\xa0\x14\x15-\x9f'
        ansible_loader_0 = AnsibleLoader(bytes_0)
    except Exception:
        raise Exception("Failed to create instance of class AnsibleLoader")

# Generated at 2022-06-25 04:38:46.760868
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  # a = AnsibleLoader(yaml, file_name=None, vault_secrets=None)
  # yaml can be any str or bytes-like object
  # file_name is the filename of the file being parsed (optional)
  print("Testing of class AnsibleLoader is not implemented")


# Generated at 2022-06-25 04:38:54.889429
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # test case 1
    #assert(False) # No such file or directory
    try:
        file_name_1 = 'test/fixtures/hello_world.yml'
        f_1 = open(file_name_1, 'r')
    except:
        f_1 = None

    ansible_loader_1 = AnsibleLoader(f_1)
    data_1 = ansible_loader_1.get_single_data()
    assert(data_1 == {'hello': 'world'})

# Generated at 2022-06-25 04:39:05.600204
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    file_name_0 = None

# Generated at 2022-06-25 04:39:13.969541
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    file_name_0 = "./test.yml"
    vault_secrets_0 = [{u'password': b'gAAAAABeoUPohxoHq3in4-LKjy8ypnNKKluxBpbhIbFlvsYgZjKxQ2QPnE-JT7v1jWL_JQlCKFnn80X7Vu8Zf71xJz-L6AaU6A=='}]

# Generated at 2022-06-25 04:39:16.178037
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'p\x05\x8b\xaa\xae\xcf\x9c\x0b\xca\xfd\x1f\x01\xb9'
    ansible_loader_0 = AnsibleLoader(bytes_0)


# Generated at 2022-06-25 04:39:21.467381
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xff\xdc\xb7'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    bytes_1 = b'\xff\xdc\xb7'
    ansible_loader_1 = AnsibleLoader(bytes_1)
    assert ansible_loader_1.stream is not ansible_loader_0.stream
    int_0 = ansible_loader_0.update_anchor_map()
    int_1 = ansible_loader_1.update_anchor_map()
    bytes_2 = b'\x0f\x0b\x06\x80'
    ansible_loader_2 = AnsibleLoader(bytes_2)
    bytes_3 = b'\x0f\x0b\x06\x80'
    ansible_loader_3

# Generated at 2022-06-25 04:39:27.381682
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = bytearray(3)
    bytes_0[0] = 100
    bytes_0[2] = 100
    bytes_0[1] = 100
    ansible_loader_0 = AnsibleLoader(bytes_0)
    ansible_loader_1 = AnsibleLoader(bytes_0)
    del ansible_loader_0
    del ansible_loader_1
    return bytes_0


# Generated at 2022-06-25 04:39:32.475625
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'=\xc7\xbe\x02\x0f\xe1\xfe\xdc2\xa0\x14\x15-\x9f'
    ansible_loader_0 = AnsibleLoader(bytes_0)

    assert ansible_loader_0 is not None

# Generated at 2022-06-25 04:39:41.848043
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream_0 = "1"
    file_name_0 = "H:v\x8fW"
    ansible_loader_0 = AnsibleLoader(stream_0, file_name=file_name_0)
    stream_1 = b"r"
    file_name_1 = "=\xdd\x1e?\xe6\xfa\xad\x9b\x9d)\x87\x17\x1d\xe13RV\x12\xa1\x95\xc3\x9d\xe4"
    ansible_loader_1 = AnsibleLoader(stream_1, file_name=file_name_1)
    stream_2 = "81"
    ansible_loader_2 = AnsibleLoader(stream_2)
    stream_3 = "\\"
    ansible

# Generated at 2022-06-25 04:41:19.434299
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, 'defaults')
    assert hasattr(AnsibleLoader, 'constructor_yaml_resources')
    assert hasattr(AnsibleLoader, 'construct_python_str')
    assert hasattr(AnsibleLoader, 'add_constructor')
    assert hasattr(AnsibleLoader, 'add_multi_constructor')
    assert hasattr(AnsibleLoader, 'add_implicit_resolver')
    assert hasattr(AnsibleLoader, '_init_constructor')
    assert hasattr(AnsibleLoader, '_init_resolver')
    assert hasattr(AnsibleLoader, '_init_composer')
    assert hasattr(AnsibleLoader, '_init_parser')
    assert hasattr(AnsibleLoader, '_init_scanner')


# Generated at 2022-06-25 04:41:21.259349
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_string = "string"
    ansible_loader = AnsibleLoader(yaml_string)
    assert yaml_string == ansible_loader.stream

# Generated at 2022-06-25 04:41:22.278524
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        AnsibleLoader()
    except TypeError:
        pass

# Generated at 2022-06-25 04:41:26.380428
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = b'=\xc7\xbe\x02\x0f\xe1\xfe\xdc2\xa0\x14\x15-\x9f'
    file_name = '_file_name'
    vault_secrets = '_vault_secrets'
    obj = AnsibleLoader(stream, file_name, vault_secrets)
    assert isinstance(obj, AnsibleLoader)
    assert not isinstance(obj, Parser)
    assert isinstance(obj, Resolver)

# Generated at 2022-06-25 04:41:31.832547
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader

    from ansible.module_utils.common.yaml import HAS_LIBYAML
    if HAS_LIBYAML:
        from ansible.module_utils.common.yaml import Parser, Reader, Scanner, Resolver
    else:
        from yaml.composer import Composer
        from yaml.reader import Reader
        from yaml.scanner import Scanner
        from yaml.resolver import Resolver

    bytes_0 = b'=\xc7\xbe\x02\x0f\xe1\xfe\xdc2\xa0\x14\x15-\x9f'
    ansible_loader_0 = AnsibleLoader

# Generated at 2022-06-25 04:41:39.420061
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data_0 = {'c': {}}
    data_0['c']['name'] = 'test_node'
    data_0['c']['name_2'] = 'test_node_2'

    file_name_0 = 'test_file'
    vault_secrets_0 = {'name': 'test_name', 'name_2': 'test_name_2'}
    ansible_loader_0 = AnsibleLoader(data_0, file_name_0, vault_secrets_0)
    data_1 = ansible_loader_0.get_single_data()
    assert data_1 == data_0

# Generated at 2022-06-25 04:41:40.222082
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-25 04:41:48.182523
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

    bytes_0 = b'\x1e\x1a\x10\xcb\x8d\xa4\xfe\xf4\xab\x88\xa7\xc5\xee\xb9\x15\xa1\x0f'

    file_name_0 = b'\xad\xa2\x18\xe1c\x0f\x05\xe7\x8f\x1a\xdc\xf1\x10'


# Generated at 2022-06-25 04:41:49.859162
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()


if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-25 04:41:50.463074
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

