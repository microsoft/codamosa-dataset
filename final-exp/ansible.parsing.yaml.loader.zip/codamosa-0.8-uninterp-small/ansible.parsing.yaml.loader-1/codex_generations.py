

# Generated at 2022-06-25 04:32:06.638927
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert not hasattr(AnsibleLoader, 'construct_yaml_seq')
    assert not hasattr(AnsibleLoader, 'construct_yaml_map')
    assert not hasattr(AnsibleLoader, 'load')
    assert not hasattr(AnsibleLoader, 'add_constructor')



# Generated at 2022-06-25 04:32:10.955386
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    if HAS_LIBYAML:
        assert isinstance(AnsibleLoader(0), object)
        assert isinstance(AnsibleLoader(0, None), object)
        assert isinstance(AnsibleLoader(0, file_name=None), object)
    else:
        assert isinstance(AnsibleLoader(0), object)
        assert isinstance(AnsibleLoader(0, None), object)
        assert isinstance(AnsibleLoader(0, file_name=None), object)

# Generated at 2022-06-25 04:32:11.982177
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:32:13.829920
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)
    int_0 = -75
    ansible_loader_0.top()
    ansible_loader_0.compose(int_0)

# Generated at 2022-06-25 04:32:17.351894
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-25 04:32:26.846114
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # As it stands, this is the test for AnsibleLoader which (at the time of writing)
    # does not have any other test available.
    # The goal is to provide a test to cover every line in AnsibleLoader.
    # Once all lines are covered, a proper test will be created for this class

    float_0 = float(89)
    float_1 = float(8)
    float_2 = float(3)

    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_0.__init__(float_0)
    ansible_loader_0.dispose()
    ansible_loader_0.get_event()
    ansible_loader_0.get_mark()
    ansible_loader_0.get_node(float_0)
    ansible_loader_0.get

# Generated at 2022-06-25 04:32:32.439428
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import yaml

    document = '''
        - hosts: all
          gather_facts: False
          tasks:
          - debug: var=hostvars["localhost"]
    '''

    ansible_loader = AnsibleLoader(yaml.load(document))
    yaml_object = ansible_loader.get_single_data()

    assert isinstance(yaml_object, list)
    assert yaml_object[0]['hosts'] == 'all'
    assert yaml_object[0]['gather_facts'] is False
    assert (yaml_object[0]['tasks'][0]['debug']['var'] ==
            'hostvars["localhost"]')

# Generated at 2022-06-25 04:32:37.727578
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Creating an instance
    ansible_loader_0 = AnsibleLoader(None)
    assert ansible_loader_0 is not None
    assert isinstance(ansible_loader_0, AnsibleLoader)

# Generated at 2022-06-25 04:32:39.879236
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:32:42.003479
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -381.0
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_0.__init__(float_0)

# Generated at 2022-06-25 04:32:54.510463
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '\n        - hosts: all\n          gather_facts: False\n          tasks:\n          - debug: var=hostvars["localhost"]\n    '
    # Create an instance of class AnsibleLoader
    AnsibleLoader_instance_0 = AnsibleLoader(str_0)
    # Assert the value of attribute file_name is equal to str_0
    assert AnsibleLoader_instance_0.file_name == str_0
    # Assert the type class of attribute file_name is str
    assert isinstance(AnsibleLoader_instance_0.file_name, str)
    # Assert the value of attribute vault_secrets is equal to None
    assert AnsibleLoader_instance_0.vault_secrets == None
    # Assert the type class of attribute vault_secrets is NoneType

# Generated at 2022-06-25 04:32:56.732668
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: complete unit test
    pass

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-25 04:33:07.746164
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_1 = '\n        - hosts: all\n          gather_facts: False\n          tasks:\n          - debug: var=hostvars["localhost"]\n    '
    str_2 = '\n\x07test:\n\x07 - localhost\n'
    str_3 = '\n- name: play 1\n  hosts: all\n  tasks:\n  - name: copy the template file\n    copy:\n      content: test1\n      dest: /etc/ansible/template_test1\n  - name: copy the template file\n    copy:\n      content: test2\n      dest: /etc/ansible/template_test2\n'

# Generated at 2022-06-25 04:33:13.659017
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '\n        - hosts: all\n          gather_facts: False\n          tasks:\n          - debug: var=hostvars["localhost"]\n    '
    obj = AnsibleLoader(str_0, None)
    str_1 = obj.get_single_data()
    str_2 = str_1['tasks'][0]['debug']['var']
    assert cmp(str_2, "hostvars[\'localhost\']") == 0
    obj.dispose()

# Generated at 2022-06-25 04:33:14.670550
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = test_case_0.__annotations__['return']
    obj = AnsibleLoader(data)

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-25 04:33:24.465752
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # test case #0
    if HAS_LIBYAML:
        str_0 = '\n        - hosts: all\n          gather_facts: False\n          tasks:\n          - debug: var=hostvars["localhost"]\n    '
    else:
        str_0 = '\n        - hosts: all\n          gather_facts: False\n          tasks:\n          - debug: var=hostvars["localhost"]\n    '
    stream_0 = str_0
    vault_secrets_0 = None
    file_name_0 = 'ansible/playbooks/test_data/validate_vars_data.yml'
    ansibleloader_0 = AnsibleLoader(stream_0, file_name_0, vault_secrets_0)

    # test case #1

# Generated at 2022-06-25 04:33:29.319052
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_1 = '\n        - hosts: all\n          gather_facts: False\n          tasks:\n          - debug: var=hostvars["localhost"]\n    '

    # Call test if class AnsibleLoader has method constructor
    x = AnsibleLoader(str_1)
    assert hasattr(x, 'constructor')

    # Verify test if method constructor of class AnsibleLoader works as expected
    y = AnsibleLoader(str_1)
    assert x.constructor == y.constructor


# Generated at 2022-06-25 04:33:39.507081
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '\n        - hosts: all\n          gather_facts: False\n          tasks:\n          - debug: var=hostvars["localhost"]\n    '
    stream = str_0
    file_name = 'test_file'
    vault_secrets = {'key': 'value'}
    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)
    assert ansible_loader.file_name == 'test_file'
    assert ansible_loader.vault_secrets == {'key': 'value'}
    assert ansible_loader.stream == str_0
    assert ansible_loader.reader == str_0
    assert ansible_loader.scanner == str_0
    assert ansible_loader.parser == str_0
    assert ansible_loader.com

# Generated at 2022-06-25 04:33:45.774620
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # SUT:
    # AnsibleLoader(stream, file_name=None, vault_secrets=None)
    str_0 = '\n        - hosts: all\n          gather_facts: False\n          tasks:\n          - debug: var=hostvars["localhost"]\n    '
    ansibleloader_obj_0 = AnsibleLoader(str_0, None, None)
    ansibleloader_obj_0.__init__(str_0, None, None)
    assert len(ansibleloader_obj_0.yaml_constructors) == 5
    # due to the way AnsibleLoader is initialized, the first element of
    # yaml_constructors will be a dict, the second will be the dict used in
    # the class, the third element will be the dict defined in
    # ansible/parsing/

# Generated at 2022-06-25 04:33:53.666583
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # multiple calls to yaml.load() should all use the same loader class again and
    # again.
    str_0 = '\n        - hosts: all\n          gather_facts: False\n          tasks:\n          - debug: var=hostvars["localhost"]\n    '
    assert isinstance(str_0, str)
    str_1 = '\n        - hosts: all\n          gather_facts: False\n          tasks:\n          - debug: var=hostvars["localhost"]\n    '
    assert isinstance(str_1, str)
    str_2 = '\n        - hosts: all\n          gather_facts: False\n          tasks:\n          - debug: var=hostvars["localhost"]\n    '
    assert isinstance(str_2, str)

# Generated at 2022-06-25 04:34:02.997171
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = 908.0
    ansible_loader_1 = AnsibleLoader(stream)
    float_0 = 0.97
    ansible_loader_0 = AnsibleLoader(stream, float_0)
    ansible_loader_2 = AnsibleLoader(stream)
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_3 = AnsibleLoader(stream)
    ansible_loader_3 = AnsibleLoader(float_0)
    ansible_loader_0 = AnsibleLoader(stream, float_0)
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_0 = AnsibleLoader(stream, float_0)
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:34:05.582440
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)


# Generated at 2022-06-25 04:34:11.813824
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # initialize an instance of AnsibleLoader class
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_0.Resolver.__init__()
    ansible_loader_0.AnsibleConstructor.__init__()
    ansible_loader_0.Parser.__init__()

# Generated at 2022-06-25 04:34:14.982804
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:34:23.773202
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import StringIO

    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_0.add_multi_constructor(u'!', lambda node: u'!', None)
    ansible_loader_0.add_multi_constructor(u'http://libyaml.org/wiki/PyYAML', lambda node: u'http://libyaml.org/wiki/PyYAML', None)
    ansible_loader_0.add_multi_constructor(u'!include', lambda node: u'!include', None)
    ansible_loader_0.add_multi_constructor(u'!include_role', lambda node: u'!include_role', None)
    ansible_loader_0.add_multi_

# Generated at 2022-06-25 04:34:24.650373
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader()

# Generated at 2022-06-25 04:34:27.743493
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test without the argument --stream
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)

    # test with the argument --stream
    ansible_loader_1 = AnsibleLoader(float_0, float_0, float_0)

# Generated at 2022-06-25 04:34:30.477313
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)


# Generated at 2022-06-25 04:34:33.842926
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)
    assert ansible_loader_0 is not None
    assert ansible_loader_0.file_name is None
    assert ansible_loader_0.vault_secrets is None


# Generated at 2022-06-25 04:34:38.318078
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(float_0)
    assert(ansible_loader_0.vault_secrets is None)

    ansible_loader_1 = AnsibleLoader(float_0, file_name = None, vault_secrets = None)
    assert(ansible_loader_1.vault_secrets is None)
    assert(ansible_loader_1.file_name is None)

test_case_0()

# Generated at 2022-06-25 04:34:45.282687
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)
    # ansible_loader_0.add_multi_document_flag()



# Generated at 2022-06-25 04:34:51.238582
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)
    list_0 = list()
    stream_0 = str()
    ansible_loader_0 = AnsibleLoader(list_0, stream_0)
    ansible_loader_0 = AnsibleLoader()
    ansible_loader_0 = AnsibleLoader()
    ansible_loader_0 = AnsibleLoader()
    ansible_loader_0 = AnsibleLoader()



# Generated at 2022-06-25 04:34:55.513979
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:35:02.957238
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print("test_AnsibleLoader START")
    stream=None
    file_name=None
    vault_secrets=None
    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)
    assert ansible_loader_0.get_root_node() is None
    assert ansible_loader_0.get_leading_documents() is None
    print("test_AnsibleLoader FINISH")

# Generated at 2022-06-25 04:35:04.348699
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:35:06.051483
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert isinstance(AnsibleLoader, type)


# Assert that the type is the same as the constructor

# Generated at 2022-06-25 04:35:07.914978
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:35:15.788669
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(int_0)
    float_0 = -908.0
    ansible_loader_1 = AnsibleLoader(float_0)
    assert isinstance(ansible_loader_0, AnsibleLoader)
    assert isinstance(ansible_loader_1, AnsibleLoader)
    str_0 = '97b028a'
    ansible_loader_2 = AnsibleLoader(str_0)
    assert isinstance(ansible_loader_2, AnsibleLoader)

# Generated at 2022-06-25 04:35:22.877648
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Note: This test is written to run only with libyaml. We may look into
    #       adding a dummy class for PyYAML in the future, but for now we'll
    #       just skip this test in that case.
    try:
        from yaml.scanner import Scanner
    except ImportError:
        import sys
        import pytest
        sys.exit(pytest.main(["-rsx", __file__]))
    else:
        test_case_0()

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-25 04:35:32.538281
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test type of instance of class AnsibleLoader
    ansible_loader_0 = AnsibleLoader(float_0)
    assert isinstance(ansible_loader_0, AnsibleLoader)
    assert not isinstance(ansible_loader_0, Parser)
    ansible_loader_1 = AnsibleLoader(float_0)
    assert isinstance(ansible_loader_1, AnsibleLoader)
    assert not isinstance(ansible_loader_1, Parser)
    ansible_loader_2 = AnsibleLoader(float_0)
    assert isinstance(ansible_loader_2, AnsibleLoader)
    assert not isinstance(ansible_loader_2, Parser)


# Generated at 2022-06-25 04:35:50.692208
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''test constructor of class AnsibleLoader'''
    float_0 = 724.8431438453625
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_0.add_implicit_resolver('!', 'unicode', None)
    float_1 = -508.0617465027336
    ansible_loader_0.add_implicit_resolver('!', 'str', float_1)
    ansible_loader_0.add_implicit_resolver('!', '', None)
    ansible_loader_0.add_implicit_resolver('!', 'float', None)
    ansible_loader_0.add_implicit_resolver('!', 'int', None)

# Generated at 2022-06-25 04:35:58.365182
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_0._reader
    ansible_loader_0._scanner
    ansible_loader_0._parser
    ansible_loader_0._composer
    ansible_loader_0.dispose()
    ansible_loader_0._anchors
    ansible_loader_0._file_name
    ansible_loader_0._vault_secrets
    ansible_loader_0._vault_secrets.load_yaml(ansible_loader_0, ansible_loader_0._file_name)
    ansible_loader_0._vault_secrets.load_yaml_from_string(ansible_loader_0, ansible_loader_0._file_name)

# Generated at 2022-06-25 04:36:01.211656
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: add test cases
    # test_case_0()
    pass

# Generated at 2022-06-25 04:36:03.300748
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Checking the constructor of AnsibleLoader
    test_case_0()

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-25 04:36:07.170212
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test first constructor of class AnsibleLoader
    test_case_0()

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-25 04:36:14.660487
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_1 = -487.0
    float_2 = -463.0
    float_3 = -851.0
    float_4 = -258.0
    ansible_loader_1 = AnsibleLoader(float_1)
    ansible_loader_2 = AnsibleLoader(float_2)
    ansible_loader_3 = AnsibleLoader(float_3)
    ansible_loader_4 = AnsibleLoader(float_4)


# Generated at 2022-06-25 04:36:17.967335
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(float_0)

# Generated at 2022-06-25 04:36:22.749206
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -834.0
    ansible_loader_0 = AnsibleLoader(float_0)
    return_value_1 = type(ansible_loader_0)
    return return_value_1



# Generated at 2022-06-25 04:36:26.077070
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert callable(AnsibleLoader)
    assert callable(AnsibleLoader)




# Generated at 2022-06-25 04:36:27.955774
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:36:50.077584
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Create an instance of AnsibleLoader
    ansible_loader_0 = AnsibleLoader(-5.7)
    ansible_loader_0 = AnsibleLoader(-4.9)
    ansible_loader_0 = AnsibleLoader(7.5)



# Generated at 2022-06-25 04:37:00.069515
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = 1.0
    ansible_loader_0 = AnsibleLoader(stream)
    ansible_loader_0.get_single_data()
    ansible_loader_0.construct_sequence()
    ansible_loader_0.construct_yaml_seq()
    ansible_loader_0.construct_yaml_map()
    ansible_loader_0.construct_mapping()
    ansible_loader_0.construct_yaml_str()
    ansible_loader_0.get_data()
    ansible_loader_0.construct_yaml_null()
    ansible_loader_0.construct_yaml_timestamp()

# Generated at 2022-06-25 04:37:09.787699
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -5423.6
    ansible_loader_0 = AnsibleLoader(float_0)
    assert isinstance(ansible_loader_0, AnsibleLoader) and isinstance(ansible_loader_0, Parser) and isinstance(ansible_loader_0, AnsibleConstructor) and isinstance(ansible_loader_0, Resolver)
    # constructor of class AnsibleLoader
    float_0 = 949.0
    ansible_loader_0 = AnsibleLoader(float_0)
    assert isinstance(ansible_loader_0, AnsibleLoader) and isinstance(ansible_loader_0, Parser) and isinstance(ansible_loader_0, AnsibleConstructor) and isinstance(ansible_loader_0, Resolver)
    float_0 = -897.06
    ans

# Generated at 2022-06-25 04:37:10.606374
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True == True

test_case_0()

# Generated at 2022-06-25 04:37:11.451149
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert ansible_loader_0 is not None

# Generated at 2022-06-25 04:37:20.142037
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print ("THREAD ID:", threading.current_thread())

    # Create an instance of class AnsibleLoader
    ansible_loader_1 = AnsibleLoader(ansible_loader_0)
    print ("ANSIBLE:", ansible_loader_1.construct_yaml_str(ansible_loader_0))

    # Check if yaml.reader.Reader is a parent of ansible_loader_1
    verify(ansible_loader_1, "yaml.reader.Reader")

    # Check if yaml.scanner.Scanner is a parent of ansible_loader_1
    verify(ansible_loader_1, "yaml.scanner.Scanner")

    # Check if yaml.parser.Parser is a parent of ansible_loader_1
    verify(ansible_loader_1, "yaml.parser.Parser")

# Generated at 2022-06-25 04:37:26.707145
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader("/tmp", "file_name")
    assert "AnsibleLoader" == ansible_loader_0.__class__.__name__
    assert "/tmp" == ansible_loader_0.stream
    assert "file_name" == ansible_loader_0.file_name

# Generated at 2022-06-25 04:37:32.594945
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = None # TODO: implement setUp()
    file_name = None # TODO: implement setUp()
    vault_secrets = None # TODO: implement setUp()
    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)
    return ansible_loader


# Generated at 2022-06-25 04:37:40.160692
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)

    # Test method __init__()
    # Test with float_0 = -908.0
    assert isinstance(ansible_loader_0, AnsibleLoader)
    assert isinstance(ansible_loader_0, Reader)
    assert isinstance(ansible_loader_0, Scanner)
    assert isinstance(ansible_loader_0, Parser)
    assert isinstance(ansible_loader_0, Composer)
    assert isinstance(ansible_loader_0, AnsibleConstructor)
    assert isinstance(ansible_loader_0, Resolver)

# Generated at 2022-06-25 04:37:41.603213
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test_case_0
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:38:27.196200
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -839.0
    ansible_loader_0 = AnsibleLoader(float_0)
    assert ansible_loader_0.__init__(float_0)

# Generated at 2022-06-25 04:38:29.238680
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)

if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:38:32.077033
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:38:35.364865
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: Implement unit tests for this class
    assert True


# Generated at 2022-06-25 04:38:42.269076
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream_0 = "test_string"
    file_name_0 = "test_file_path"
    vault_secrets_0 = "test_vault_secret_path"
    ansible_loader_0 = AnsibleLoader(stream_0, file_name_0, vault_secrets_0)
    stream_1 = "test_string"
    file_name_1 = "test_file_path"
    vault_secrets_1 = "test_vault_secret_path"
    ansible_loader_1 = AnsibleLoader(stream_1, file_name_1, vault_secrets_1)
    stream_2 = "test_string"
    ansible_loader_2 = AnsibleLoader(stream_2)
    stream_3 = "test_string"

# Generated at 2022-06-25 04:38:44.491567
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test_case_0
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:38:45.846574
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    for i in range(1000):
        test_case_0()

# Generated at 2022-06-25 04:38:47.508281
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)


# Generated at 2022-06-25 04:38:51.360355
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)



# Generated at 2022-06-25 04:38:54.055758
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader()

# Generated at 2022-06-25 04:40:09.643284
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    with open('./test/ansible_loader.yml', 'r') as stream:
        ansible_loader = AnsibleLoader(stream)
    ansible_loader.get_data()


# Generated at 2022-06-25 04:40:12.729309
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = 1
    file_name = 2
    vault_secrets = 3
    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)
    # check that float is converted to string
    assert ansible_loader_0.file_name is file_name

# Generated at 2022-06-25 04:40:13.508138
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -908.0
    ansibl

# Generated at 2022-06-25 04:40:15.386724
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 7.96364791489
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:40:16.649506
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = -908.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:40:20.356861
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Using the constructor
    try:
        ansible_loader_0 = AnsibleLoader()
    except:
        assert False


# Generated at 2022-06-25 04:40:22.294902
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    file_name_0 = 'test.yml'
    stream_0 = 'var1: var2'
    ansible_loader_0 = AnsibleLoader(stream_0, file_name=file_name_0)


# Generated at 2022-06-25 04:40:29.075249
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    assert(hasattr(AnsibleLoader, '__init__'))
    assert(AnsibleLoader.__init__.__doc__ == None)
    assert(AnsibleLoader.__init__.__defaults__ == (None,))
    assert(AnsibleLoader.__init__.__code__.co_varnames == ('self', 'stream', 'file_name'))
    assert(AnsibleLoader.__init__.__code__.co_argcount == 2)

# Generated at 2022-06-25 04:40:39.229176
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Constructing a instance of AnsibleLoader with wrong number of arguments
    # TypeError exception is raised.
    with pytest.raises(TypeError) as e:
        ansible_loader_0 = AnsibleLoader()
    assert "__init__()" in str(e.value)

    # Constructing a instance of AnsibleLoader with wrong number of arguments
    # TypeError exception is raised.
    with pytest.raises(TypeError) as e:
        ansible_loader_0 = AnsibleLoader(float(), str())
    assert "__init__()" in str(e.value)

    # Constructing a instance of AnsibleLoader with wrong number of arguments
    # TypeError exception is raised.
    with pytest.raises(TypeError) as e:
        ansible_loader_0 = AnsibleLoader(float())

# Generated at 2022-06-25 04:40:47.916066
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # mock data
    float_0 = 3.2
    float_1 = -908.0
    float_2 = -7.2
    float_3 = 4.0
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_1 = AnsibleLoader(float_1)
    ansible_loader_2 = AnsibleLoader(float_2)
    ansible_loader_3 = AnsibleLoader(float_3)
    ansible_loader_3.set_vault_secrets('/home/kali/.ansible/vault/vault_password')
    ansible_loader_3.set_file_name('/etc/ansible/playbook')
    ansible_loader_4 = AnsibleLoader(float_1)
    ansible_loader_4.set_vault