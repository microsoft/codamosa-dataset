

# Generated at 2022-06-25 04:32:03.931485
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert callable(AnsibleLoader)

if __name__ == '__main__':
    test_AnsibleLoader()
    test_case_0()

# Generated at 2022-06-25 04:32:05.112396
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:32:07.269300
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:32:10.355294
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)
    bool_0 = None
    bool_1 = None
    ansible_loader_1 = AnsibleLoader(bool_0, bool_1)
    bool_0 = None
    bool_1 = None
    bool_2 = None
    ansible_loader_2 = AnsibleLoader(bool_0, bool_1, bool_2)

# Generated at 2022-06-25 04:32:11.693649
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)

    assert True

# Generated at 2022-06-25 04:32:17.373531
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Input params
    bool_0 = None

    ansible_loader_0 = AnsibleLoader(bool_0)

    # Input params
    bool_0 = None

    bool_0 = None

    ansible_loader_0 = AnsibleLoader(bool_0, bool_0)


# Generated at 2022-06-25 04:32:21.044411
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass
# unit test for method for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:32:22.676221
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)

# Generated at 2022-06-25 04:32:26.017300
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-25 04:32:33.373522
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = None
    file_name = None
    vault_secrets = None

    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)

    assert ansible_loader.constructor == ansible_loader
    assert ansible_loader.constructor_loader == ansible_loader
    assert ansible_loader.constructor_safe == ansible_loader
    assert ansible_loader.constructor_unsafe == ansible_loader
    assert ansible_loader.constructor_arg == ansible_loader
    assert ansible_loader.resolver == ansible_loader

# Generated at 2022-06-25 04:32:37.506031
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 04:32:38.020421
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:32:46.572614
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)
    ansible_loader_0
    AnsibleLoader
    ansible_loader_0.file_name = 'file_name'
    ansible_loader_0.vault_secrets = 'vault_secrets'
    ansible_loader_0.locations = [None]
    ansible_loader_0.cur_name = 'cur_name'
    ansible_loader_0.cur_value = None
    ansible_loader_0.set_vault_secrets(None)
    ansible_loader_0.set_vault_secrets(None)
    ansible_loader_0.set_vault_secrets(None)
    ansible_loader_0.set_vault_secrets(None)

# Generated at 2022-06-25 04:32:57.435232
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)

    assert isinstance(ansible_loader_0, AnsibleLoader)
    ansible_loader_0.set_vault_secrets(bool_0)
    ansible_loader_0.set_vault_password(bool_0)
    ansible_loader_0.set_file_name(bool_0)
    ansible_loader_0.set_position(bool_0)
    ansible_loader_0.get_position()
    ansible_loader_0.set_data(bool_0)
    ansible_loader_0.get_data()
    ansible_loader_0.get_single_data()
    ansible_loader_0.get_encoding()
    ansible_loader_0.pre

# Generated at 2022-06-25 04:32:58.215764
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader()

# Generated at 2022-06-25 04:33:02.906173
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    params = [1, False]
    result = True
    try:
        AnsibleLoader(params[0], params[1])
    except:
        result = False

    assert result == True


# Generated at 2022-06-25 04:33:06.011533
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = None
    ansible_loader_0 = AnsibleLoader(stream)
    ansible_loader_1 = AnsibleLoader(stream)
    assert ansible_loader_0.stream == ansible_loader_1.stream


# Generated at 2022-06-25 04:33:07.122630
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # AnsibleLoader()
    ansible_loader = AnsibleLoader()


# Generated at 2022-06-25 04:33:10.976823
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    ansible_loader_0 = AnsibleLoader()
    assert ansible_loader_0 is not None

    ansible_loader_1 = AnsibleLoader(None)
    assert ansible_loader_1 is not None

    ansible_loader_2 = AnsibleLoader(None, 'file-name', None)
    assert ansible_loader_2 is not None

    ansible_loader_3 = AnsibleLoader(None, 'file-name', [])
    assert ansible_loader_3 is not None

# Generated at 2022-06-25 04:33:15.092160
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader_instance = AnsibleLoader('@')
    assert loader_instance._vault_secrets is None
    vault_secrets_instance = dict()
    loader_instance = AnsibleLoader('@',vault_secrets=vault_secrets_instance)
    assert loader_instance._vault_secrets is vault_secrets_instance

# Generated at 2022-06-25 04:33:21.209438
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)  #pass


# Generated at 2022-06-25 04:33:22.258505
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(None)

# Generated at 2022-06-25 04:33:30.310064
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Try to set a read-only property
    ansible_loader_0 = AnsibleLoader(None)
    with pytest.raises(AttributeError):
        setattr(ansible_loader_0, 'file_name', 'ansible_loader_file_name')
    with pytest.raises(AttributeError):
        setattr(ansible_loader_0, 'vault_secrets', 'ansible_loader_vault_secrets')



# Generated at 2022-06-25 04:33:33.554938
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    with pytest.raises(TypeError) as excinfo:
        ansible_loader_0 = AnsibleLoader()
    assert 'missing 1 required positional argument' in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ansible_loader_0 = AnsibleLoader(None)
    assert 'missing 1 required positional argument' in str(excinfo.value)

# Generated at 2022-06-25 04:33:34.227835
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass # FIXME: construct object and perform tests

# Generated at 2022-06-25 04:33:35.388962
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = "something"
    ansible_loader_0 = AnsibleLoader(stream)


# Generated at 2022-06-25 04:33:40.914667
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)
    assert ansible_loader_0.vault_secrets is None
    assert ansible_loader_0.provider_spec is None
    assert ansible_loader_0.file_name == '<string>'
    assert ansible_loader_0.construct_scalar == AnsibleConstructor.construct_scalar
    assert ansible_loader_0.is_vault_encrypted_file == AnsibleConstructor.is_vault_encrypted_file
    assert ansible_loader_0.is_vault_encrypted_file == AnsibleConstructor.is_vault_encrypted_file

# Generated at 2022-06-25 04:33:45.425885
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # ansible_loader_0 = AnsibleLoader(bool_0)
    # assert ansible_loader_0 is not None
    pass

# Generated at 2022-06-25 04:33:50.223251
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)
    assert isinstance(ansible_loader_0, AnsibleLoader)

# Generated at 2022-06-25 04:33:56.404039
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)
    assert ansible_loader_0._yaml_get_documents_0.__code__.co_argcount == 1
    assert ansible_loader_0._yaml_get_documents_0.__code__.co_varnames == ('self',)

# Generated at 2022-06-25 04:34:08.888942
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)
    assert ansible_loader_0 is not None


# Generated at 2022-06-25 04:34:10.807470
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)

# Generated at 2022-06-25 04:34:14.840339
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)

# Generated at 2022-06-25 04:34:21.431755
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)
    assert ansible_loader_0 is not None
    # verify of the type of 'ansible_loader_0'
    assert isinstance(ansible_loader_0, AnsibleLoader)
    ansible_loader_0 = AnsibleLoader(bool_0)
    assert ansible_loader_0 is not None
    # verify of the type of 'ansible_loader_0'
    assert isinstance(ansible_loader_0, AnsibleLoader)
    ansible_loader_0 = AnsibleLoader(bool_0)
    assert ansible_loader_0 is not None
    # verify of the type of 'ansible_loader_0'
    assert isinstance(ansible_loader_0, AnsibleLoader)
    ansible_loader_

# Generated at 2022-06-25 04:34:23.049388
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_1 = AnsibleLoader(None)
    assert ansible_loader_1 is not None

# Generated at 2022-06-25 04:34:25.049284
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(bool_0)
    assert type(ansible_loader_0) == AnsibleLoader

# Generated at 2022-06-25 04:34:34.216735
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Loading a YAML file with a password
    dict_0 = dict()
    dict_0['vault_password_file'] = '~/ansible/PasswordFile'
    ansible_loader_0 = AnsibleLoader('~/ansible/sampleVaultFile.yml', vault_secrets=dict_0)

    # Loading a YAML file without a password
    ansible_loader_1 = AnsibleLoader('~/ansible/nestedVault.yml')

    # Loading a YAML object
    dict_2 = dict()
    dict_2['items'] = ['Linux', 'Python', 'Ansible']
    dict_2['group'] = 'network_team'
    dict_2['owners'] = ['{name: jenkins, age:32}, {name: dave, age:43}']


# Generated at 2022-06-25 04:34:35.763072
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)

# Generated at 2022-06-25 04:34:42.096177
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)
    ansible_loader_0.set_parser(ansible_loader_0)
    ansible_loader_0.get_single_data()
    ansible_loader_0.get_data()
    ansible_loader_0.compose_document()
    ansible_loader_0.resolve()


# Generated at 2022-06-25 04:34:44.245479
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # from ansible/parsing/yaml/loader.py Line: ??
    ansible_loader_0 = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    assert ansible_loader_0 != None


# Generated at 2022-06-25 04:35:07.647902
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test the availability of constructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    # Create an object of class AnsibleLoader
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)
    ansible_loader_0.dispose()
    # Test the availability of methods
    assert hasattr(ansible_loader_0, "dispose")
    # Destroy the object
    ansible_loader_0 = None

# Generated at 2022-06-25 04:35:12.303273
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = None
    file_name = None
    vault_secrets = None
    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)

# Generated at 2022-06-25 04:35:16.597904
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True


# Generated at 2022-06-25 04:35:17.463135
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader()


# Generated at 2022-06-25 04:35:25.747785
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader('jV7e/b')
    ansible_loader_1 = AnsibleLoader(u'pPJ')
    ansible_loader_2 = AnsibleLoader(u'\\')
    ansible_loader_3 = AnsibleLoader('m')
    ansible_loader_4 = AnsibleLoader('4H')
    ansible_loader_5 = AnsibleLoader(u'fcf')
    ansible_loader_6 = AnsibleLoader('>')
    ansible_loader_7 = AnsibleLoader(u'H')
    ansible_loader_8 = AnsibleLoader(u'\\')
    ansible_loader_9 = AnsibleLoader('\\')
    ansible_loader_10 = AnsibleLoader(u'f\\')

# Generated at 2022-06-25 04:35:27.660717
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)

# Generated at 2022-06-25 04:35:35.531221
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)
    bool_1 = False
    ansible_loader_1 = AnsibleLoader(bool_0, vault_secrets=bool_1)
    bool_2 = False
    ansible_loader_2 = AnsibleLoader(bool_0, file_name=bool_2)
    bool_3 = False
    ansible_loader_3 = AnsibleLoader(bool_0, vault_secrets=bool_1, file_name=bool_2)
    # Assertions for instance attributes of class 'AnsibleLoader'
    assert ansible_loader_0._mapping_tag_reserved_map is None
    assert ansible_loader_1._mapping_tag_reserved_map is None
    assert ansible_loader_2._m

# Generated at 2022-06-25 04:35:39.839338
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader()
    ansible_loader_1 = AnsibleLoader('False')

# Test method AnsibleLoader.construct_yaml_map()

# Generated at 2022-06-25 04:35:45.320678
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Setup:
    # Exercise:
    # Verify:
    assert True


# Generated at 2022-06-25 04:35:49.752789
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)
    assert ansible_loader_0 is not None


# Generated at 2022-06-25 04:36:28.259550
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Retrieval of the data stream to parse
    # Configuration of the loader parser
    yaml_stream = open('/home/travis/build/ansible/ansible/lib/ansible/parsing/yaml/Dumper.yml')
    ansible_loader_0 = AnsibleLoader(yaml_stream)

if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:36:39.225197
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)
    ansible_loader_0.construct_document()
    ansible_loader_0.construct_mapping()
    ansible_loader_0.construct_sequence()
    bool_0 = False
    ansible_loader_0.construct_yaml_bool(bool_0)
    int_0 = 0
    ansible_loader_0.construct_yaml_int(int_0)
    str_0 = '"  "'
    ansible_loader_0.construct_yaml_str(str_0)
    str_0 = ''
    ansible_loader_0.construct_yaml_str(str_0)
    str_0 = '"'

# Generated at 2022-06-25 04:36:49.120782
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(bool_0)
    ansible_loader_1 = AnsibleLoader(bool_0)
    assert ansible_loader_0.loader_id == ansible_loader_1.loader_id
    assert ansible_loader_0.loader_id == ansible_loader_1.loader_id
    assert ansible_loader_0.stream == ansible_loader_1.stream
    assert ansible_loader_0.stream == ansible_loader_1.stream
    assert ansible_loader_1.USED_FILE_NAME == ansible_loader_1.file_name
    # ansible_loader_1.USED_FILE_NAME = bool_0
    # assert not ansible_loader_1.USED_FILE_NAME
    # assert ansible_loader_0.stream ==

# Generated at 2022-06-25 04:36:51.864495
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_1 = None
    # AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    ansible_loader_1 = AnsibleLoader(bool_1)


# Generated at 2022-06-25 04:36:56.586428
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Unit test for constructor of class AnsibleLoader
    '''
    bool_0 = False
    ansible_loader_0 = AnsibleLoader(bool_0)


# Generated at 2022-06-25 04:37:02.133278
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader()
    if not isinstance(obj, AnsibleLoader):
        raise ValueError
    if isinstance(obj, Resolver):
        raise ValueError
    if not isinstance(obj, Parser):
        raise ValueError
    if isinstance(obj, Reader):
        raise ValueError
    if isinstance(obj, Scanner):
        raise ValueError
    if isinstance(obj, Composer):
        raise ValueError
    if not isinstance(obj, AnsibleConstructor):
        raise ValueError

# Generated at 2022-06-25 04:37:10.610536
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)
    # Ensure AnsibleLoader constructor.

    assert(ansible_loader_0.file_name is None)

    assert(ansible_loader_0.vault_secrets is None)
    # Ensure AnsibleLoader constructor have vault_secrets.

    assert(ansible_loader_0.stream is None)
    # Ensure AnsibleLoader constructor have stream.
    assert(ansible_loader_0.loader is None)

# Generated at 2022-06-25 04:37:12.231999
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)


# Generated at 2022-06-25 04:37:17.732674
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream_0 = None
    file_name_0 = None
    vault_secrets_0 = None
    ansible_loader_0 = AnsibleLoader(stream_0, file_name_0, vault_secrets_0)

# Generated at 2022-06-25 04:37:25.222846
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    #ansible_loader_0 = AnsibleLoader(bool_0)
    #assert ansible_loader_0.data() == ''

    ansible_loader_0 = AnsibleLoader("")
    assert ansible_loader_0.data() == ''

    ansible_loader_0 = AnsibleLoader("---\nhola: 1")
    assert ansible_loader_0.data() == {'hola': 1}

    ansible_loader_0 = AnsibleLoader("---\nhola: 1\n")
    assert ansible_loader_0.data() == {'hola': 1}

    ansible_loader_0 = AnsibleLoader("---\nhola: 1\n\n")
    assert ansible_loader_0.data() == {'hola': 1}

    ans

# Generated at 2022-06-25 04:38:39.643223
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)
    ansible_loader_1 = AnsibleLoader(bool_0)
    ansible_loader_2 = AnsibleLoader(bool_0)
    ansible_loader_3 = AnsibleLoader(bool_0)



# Generated at 2022-06-25 04:38:45.900289
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)
    assert ansible_loader_0.expect_block_end() == 1
    assert ansible_loader_0.compose_node() == 1
    assert ansible_loader_0.compose_mapping_node() == 1
    assert ansible_loader_0.compose_sequence_node() == None
    assert ansible_loader_0.compose_document() == 1
    ansible_loader_0.compose_scalar_node()
    assert ansible_loader_0.load() == 1
    assert ansible_loader_0.load_all() == 1
    ansible_loader_0.add_constructor("tag:yaml.org,2002:null", int)

# Generated at 2022-06-25 04:38:49.577484
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        bool_0 = None
        ansible_loader_0 = AnsibleLoader(bool_0)
        print("Testing constructor of class AnsibleLoader")
    except NameError:
        print("Constructor of class AnsibleLoader not found")
    except:
        print("Unable to test constructor of class AnsibleLoader")

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-25 04:39:00.099529
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)
    bool_1 = None
    ansible_loader_1 = AnsibleLoader(bool_1)
    # bool_2 = None
    # ansible_loader_2 = AnsibleLoader(bool_2)
    # ansible_loader_2.add_path_resolver()
    # bool_3 = None
    # ansible_loader_3 = AnsibleLoader(bool_3)
    # ansible_loader_3.add_constructor()
    bool_4 = None
    ansible_loader_4 = AnsibleLoader(bool_4)
    # bool_5 = None
    # ansible_loader_5 = AnsibleLoader(bool_5)
    # ansible_loader_5.add_multi_constructor()


# Generated at 2022-06-25 04:39:01.270868
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_1 = None
    ansible_loader_1 = AnsibleLoader(bool_1)

# Generated at 2022-06-25 04:39:02.223250
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test of the default constructor
    test_case_0()

# Generated at 2022-06-25 04:39:05.935024
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Test case for AnsibleLoader.__init__
    test_case_0()

# Generated at 2022-06-25 04:39:12.491618
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    input=open('../helpers/test.yaml', 'r')
    # file_name=open('../helpers/test.yaml', 'r')
    ansible_loader_0 = AnsibleLoader(input)
    ansible_loader_0.process()
    ansible_loader_0.construct()
    ansible_loader_0.compose()
    ansible_loader_0.parse()
    # ansible_loader_0.resolve()
    input.close()

# test_AnsibleLoader()
# test_case_0()

# Generated at 2022-06-25 04:39:16.002080
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)

# Generated at 2022-06-25 04:39:18.506416
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print("In AnsibleLoader")
    test_case_0()

# Generated at 2022-06-25 04:41:46.494369
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.resolver import Resolver
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    # Test for AnsibleLoader
    bool_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0)
    assert isinstance(ansible_loader_0, Reader)
    assert isinstance(ansible_loader_0, Scanner)
    assert isinstance(ansible_loader_0, Parser)
    assert isinstance(ansible_loader_0, Composer)
    assert isinstance(ansible_loader_0, AnsibleConstructor)
    assert isinstance(ansible_loader_0, Resolver)

# Generated at 2022-06-25 04:41:57.141845
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        import yaml
    except ImportError:
        print("No yaml module available, skipping some tests")
        return

    # Variables used in tests
    bool_0 = None
    bool_1 = True
    bool_2 = False

    # Testing of method __init__
    assert test_case_0() is None

    # Testing of method from_string
    assert AnsibleLoader.from_string(bool_0) == yaml.load(bool_0)

    # Testing of method from_file

    # Testing of method from_list
    assert AnsibleLoader.from_list(bool_0) == yaml.load(bool_0)

    # Testing of method full_load
    assert AnsibleLoader.full_load(bool_0) == yaml.load(bool_0)

    # Testing of method get_

# Generated at 2022-06-25 04:42:02.102299
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream_0 = None
    vault_secrets_0 = None
    ansible_loader_0 = AnsibleLoader(stream_0, vault_secrets=vault_secrets_0)
    ansible_loader_0.get_single_data()
