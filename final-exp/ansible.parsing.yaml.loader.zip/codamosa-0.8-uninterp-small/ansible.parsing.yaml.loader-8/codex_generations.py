

# Generated at 2022-06-25 04:32:08.829138
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_1 = AnsibleLoader(str_0)
    str_1 = 'h#-_p'
    ansible_loader_2 = AnsibleLoader(str_0, file_name=str_1)
    ansible_loader_3 = AnsibleLoader(str_0, file_name=str_1)
    ansible_loader_4 = AnsibleLoader(str_0, file_name=str_1, vault_secrets=str_1)
    ansible_loader_5 = AnsibleLoader(str_0, file_name=str_1, vault_secrets=str_1)

# Generated at 2022-06-25 04:32:16.195918
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'uI7VX9'
    ansible_loader_0 = AnsibleLoader(str_0)
    str_1 = 'P#4jyH'
    ansible_loader_1 = AnsibleLoader(str_1)
    str_2 = '5`%c:>'
    ansible_loader_2 = AnsibleLoader(str_2)
    str_3 = '_B1Iq~'
    ansible_loader_3 = AnsibleLoader(str_3)
    str_4 = 'u!7VX9'
    ansible_loader_4 = AnsibleLoader(str_4)
    str_5 = 'l2uVX9'
    ansible_loader_5 = AnsibleLoader(str_5)
    str_6 = 'A$Iq~'


# Generated at 2022-06-25 04:32:18.616474
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  pass

if __name__ == "__main__":
  pdb.set_trace()
  test_AnsibleLoader()

# Generated at 2022-06-25 04:32:26.246847
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '/JcY'
    str_1 = 'qnZ'
    str_2 = 'nbm'
    ansible_loader_0 = AnsibleLoader(str_2)
    result = ansible_loader_0.get_single_data()
    assert result is not None
    result = ansible_loader_0.get_single_data()
    assert result is not None
    result = ansible_loader_0.get_single_data()
    assert result is not None
    result = ansible_loader_0.reset_data()
    assert result is None
    result = ansible_loader_0.get_data()
    assert result is not None
    result = ansible_loader_0.reset_data()
    assert result is None
    result = ansible_loader_0.get_data()

# Generated at 2022-06-25 04:32:29.670153
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '*D2'
    Int_0 = 1
    # test_AnsibleLoader_0
    ansible_loader_0 = AnsibleLoader(str_0, Int_0)

# Generated at 2022-06-25 04:32:39.683972
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)
    assert ansible_loader_0
    assert isinstance(ansible_loader_0, AnsibleLoader)
    # Test with inventory and variables.
    inventory_manager_0 = InventoryManager(loader=DataLoader())
    variable_manager_0 = VariableManager(loader=DataLoader(), inventory=inventory_manager_0)
    ansible_loader_1 = AnsibleLoader(str_0, variable_manager=variable_manager_0, inventory=inventory_manager_0)
    # Test with vault secrets.

# Generated at 2022-06-25 04:32:40.866873
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('ABC')
    assert loader is not None

# Generated at 2022-06-25 04:32:42.431144
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)

# Generated at 2022-06-25 04:32:46.934883
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)
    assert ansible_loader_0 is not None


# Generated at 2022-06-25 04:32:51.362592
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)

    assert ansible_loader_0.file_name == None
    assert ansible_loader_0.vault_secrets == None

# Generated at 2022-06-25 04:33:02.646285
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_0.stream = str_0
    ansible_loader_0.last_line = 0
    ansible_loader_0.last_column = 0
    ansible_loader_0.last_byte = 0
    ansible_loader_0.line = 0
    ansible_loader_0.column = 0
    ansible_loader_0.pointer = 0
    ansible_loader_0.buffer = ''
    ansible_loader_0.index = 0
    ansible_loader_0.tokens = []
    ansible_loader_0.states = []
    ansible_loader_0.simple_keys = []
    ansible_loader_0.marks = []


# Generated at 2022-06-25 04:33:04.389406
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'O*'
    ansible_loader_0 = AnsibleLoader(str_0)

# Generated at 2022-06-25 04:33:06.411481
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test for method __init__
    test_case_0()

# Generated at 2022-06-25 04:33:11.696391
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = "foo:\n- this is a\n- multiline string\n"

    ansible_loader_0 = AnsibleLoader(str_0)
    assert ansible_loader_0.get_single_data() == {'foo': ['this is a', 'multiline string']}

    ansible_loader_1 = AnsibleLoader(str_0, file_name='file_name')
    assert ansible_loader_1.file_name == 'file_name'

# Generated at 2022-06-25 04:33:16.460564
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import StringIO
    my_fake_stdin = StringIO.StringIO()
    sys.stdin = my_fake_stdin
    my_fake_stdin.write('P#4jyH')
    print("fake input stdin = P#4jyH")
    ansible_loader = AnsibleLoader(sys.stdin)
    sys.stdin = sys.__stdin__

# Generated at 2022-06-25 04:33:17.539513
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader('P#4jyH')

# Generated at 2022-06-25 04:33:20.149278
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_1 = 'P#4jyH'
    str_2 = 'P#4jyH'
    ansible_loader_1 = AnsibleLoader(str_1, str_2)

test_case_0()
test_AnsibleLoader()

# Generated at 2022-06-25 04:33:28.326756
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Verify that parsing a string containing a variable evaluates to the variable's value.
    variable_text = 'bar'
    variable_name = 'foo'
    variable_value = 'bar'
    variable = '{{%s}}' % variable_name
    variable_file = 'test_variable_file'
    variable_dict = {variable_name: variable_value}
    variable_loader = AnsibleLoader(variable, variable_file)
    variable_loaded = variable_loader.get_single_data()
    assert variable_loaded == variable_value
    # Verify that parsing a file containing a variable evaluates to the variable's value.
    variable_dict_text = '%s' % variable_dict
    variable_file_object = open(variable_file, 'w+')
    variable_file_object.write(variable_dict_text)
    variable

# Generated at 2022-06-25 04:33:28.757829
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_1 = AnsibleLoader()

# Generated at 2022-06-25 04:33:39.097907
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_1 = 'Hello World'
    ansible_loader_1 = AnsibleLoader(str_1)
    str_2 = 'P@$$w0rd'
    ansible_loader_2 = AnsibleLoader(str_2)
    str_3 = '12345678'
    ansible_loader_3 = AnsibleLoader(str_3)
    int_1 = hash(str_1) % 2**32
    int_2 = hash(str_2) % 2**32
    int_3 = hash(str_3) % 2**32
    int_4 = hash(ansible_loader_1) % 2**32
    assert int_1 != int_2 != int_3 != int_4
    test_case_0()
    test_case_1()
    test_case_2()
    test_case

# Generated at 2022-06-25 04:34:15.259280
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'AGYzY+'
    ansible_loader_0 = AnsibleLoader(str_0)
    str_1 = 'mv#@]V'
    ansible_loader_1 = AnsibleLoader(str_1)
    str_2 = 'd5P5"{'
    ansible_loader_2 = AnsibleLoader(str_2)
    str_3 = 'AGYzY+'
    ansible_loader_3 = AnsibleLoader(str_3)
    str_4 = 'yL'
    ansible_loader_4 = AnsibleLoader(str_4)
    str_5 = 'Q"*nFoo'
    ansible_loader_5 = AnsibleLoader(str_5)
    ansible_loader_4 = AnsibleLoader(str_4)
    str

# Generated at 2022-06-25 04:34:17.899380
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)

    assert ansible_loader_0.stream == str_0


# Generated at 2022-06-25 04:34:19.989606
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)

# Generated at 2022-06-25 04:34:22.727208
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = None
    file_name=None
    vault_secrets=None
    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)

# Generated at 2022-06-25 04:34:24.650938
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # AnsibleLoader constructor should have a single parameter
    # str_0 = 'P#4jyH'
    # ansible_loader_0 = AnsibleLoader(str_0)
    # should work fine
    assert True

# Generated at 2022-06-25 04:34:25.495973
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert callable(AnsibleLoader)


# Generated at 2022-06-25 04:34:34.956580
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader()

    assert "AnsibleLoader" == ansible_loader_0.__class__.__name__
    assert ansible_loader_0._file_name is None
    assert ansible_loader_0._data_stack == []
    assert ansible_loader_0._cur_doc_stack == []
    assert ansible_loader_0._cur_key_stack == []
    assert ansible_loader_0._previous_key == None
    assert ansible_loader_0._previous_indentation is None
    assert ansible_loader_0._current_indentation is None
    assert ansible_loader_0._force_pairs is False
    assert ansible_loader_0._current_index is None
    assert ansible_loader_0._file_vars == {}


# Generated at 2022-06-25 04:34:38.598494
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    str_1 = 'P#4jyH'
    str_2 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_1 = AnsibleLoader(str_1)
    ansible_loader_2 = AnsibleLoader(str_2)

# Generated at 2022-06-25 04:34:40.729008
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)

# Generated at 2022-06-25 04:34:46.238140
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_0.set_domain_id('6kS')
    ansible_loader_0.set_bgn_date('3qwhh')
    ansible_loader_0.set_proc_status('D')
    ansible_loader_0.set_region_name('Mk')
    ansible_loader_0.set_data_source_cd('38')
    ansible_loader_0.set_created_by('q3')
    ansible_loader_0.set_update_date('8')
    ansible_loader_0.set_eff_date('S')
    ansible_loader_0.set_created_date('AV')
    ansible_loader

# Generated at 2022-06-25 04:35:00.220920
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

if __name__ == "__main__":
    # test_AnsibleLoader()
    # test_case_0()
    pass

# Generated at 2022-06-25 04:35:07.617611
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test with these parameters.
    stream = 'P#4jyH'
    file_name = 'test_file'
    vault_secrets = 'test_password'
    # Now instantiate the class.
    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)
    # Verify that the constructor throws an error for object of class AnsibleLoader as it is an abstract class.
    try:
        ansible_loader_0.__init__(stream, file_name, vault_secrets)
    except TypeError as err:
        assert (type(err) == TypeError)



# Generated at 2022-06-25 04:35:08.434293
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass # Could not parse test case

# Generated at 2022-06-25 04:35:14.544896
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'

# Generated at 2022-06-25 04:35:16.724737
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = 'string'
    ansible_loader_0 = AnsibleLoader(data)



# Generated at 2022-06-25 04:35:25.104659
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    if HAS_LIBYAML:
        str_0 = 'P#4jyH'
    else:
        str_0 = 'username: "admin"\n'

    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_1 = AnsibleLoader(str_0, '/etc/timezone')
    ansible_loader_2 = AnsibleLoader(str_0, '/etc/localtime', vault_secrets=None)

    # Asserts
    if HAS_LIBYAML:
        assert ansible_loader_0.file_name == None
        assert ansible_loader_1.file_name == '/etc/timezone'
        assert ansible_loader_2.file_name == '/etc/localtime'

# Generated at 2022-06-25 04:35:26.040894
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:35:34.366536
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader
    # This line causes a segfault, so it is commented out for now.
    #ansible_loader_0 = AnsibleLoader()
    ansible_loader_1 = AnsibleLoader('gUbXG')
    ansible_loader_2 = AnsibleLoader('P#4jyH')
    ansible_loader_3 = AnsibleLoader('p_Mn')
    ansible_loader_4 = AnsibleLoader('HheZ')
    ansible_loader_5 = AnsibleLoader('yBa5')
    ansible_loader_6 = AnsibleLoader('P#4jyH')
    ansible_loader_7 = AnsibleLoader('gUbXG')
    ansible_loader_8 = AnsibleLoader('P#4jyH')
    ansible_loader_9 = AnsibleLoader

# Generated at 2022-06-25 04:35:41.455697
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)
    # AssertionError: assert isinstance(value, str) or isinstance(value, int) or isinstance(value, float) or isinstance(value, list) or isinstance(value, dict) or isinstance(value, bool)

# Generated at 2022-06-25 04:35:46.114908
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '0ok4U9'
    file_name_0 = '/etc/ansible/ansible.cfg'
    ansible_loader_0 = AnsibleLoader(str_0, file_name_0)
    str_1 = 'C;'
    file_name_1 = '/usr/local/bin/ansible-galaxy'
    ansible_loader_1 = AnsibleLoader(str_1, file_name_1)
    str_2 = 'EsrF%'
    file_name_2 = '~/.ansible/logs/ansible.log'
    ansible_loader_2 = AnsibleLoader(str_2, file_name_2)

# Generated at 2022-06-25 04:36:07.184807
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:36:17.020753
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)

    assert isinstance(ansible_loader_0, Scanner)
    assert isinstance(ansible_loader_0, Parser)
    assert isinstance(ansible_loader_0, AnsibleConstructor)
    assert isinstance(ansible_loader_0, Resolver)
    assert ansible_loader_0.file_name == None
    assert ansible_loader_0.cur_line_index == 0

    str_1 = 'OQ2t'
    ansible_loader_1 = AnsibleLoader(str_1, str_0)

    assert isinstance(ansible_loader_1, Scanner)
    assert isinstance(ansible_loader_1, Parser)

# Generated at 2022-06-25 04:36:19.214960
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = 'P#4jyH' 
    file_name = 'P#4jyH'
    vault_secrets = 'P#4jyH'
    # call the constructor
    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)

# Generated at 2022-06-25 04:36:24.143004
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_0.resolve()
    ansible_loader_0.compose_node(None, None)
    ansible_loader_0.check_event(None)
    ansible_loader_0.get_token()
    ansible_loader_0.peek_token()
    ansible_loader_0.compose_document(None)
    ansible_loader_0.compose_mapping_node(None, None, None)
    ansible_loader_0.compose_sequence_node(None, None, None)
    ansible_loader_0.construct_object(None, None)
    ansible_loader_0.construct_yaml_map(None)


# Generated at 2022-06-25 04:36:26.449960
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test if the constructor works
    try:
        test_case_0()
        return True
    except AttributeError:
        return False

# Generated at 2022-06-25 04:36:28.079462
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader
    # Test if the constructor is instantiable
    try:
        ansible_loader_0()
    except:
        pass

# Generated at 2022-06-25 04:36:30.938275
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)


# Generated at 2022-06-25 04:36:37.686290
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.parser import Parser
    from yaml.resolver import Resolver
    from ansible.module_utils.common.yaml import Parser

    ansible_loader_0 = AnsibleLoader(str_0)

    # Assert for method __init__
    assert(assert_0)

# Generated at 2022-06-25 04:36:45.394525
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.resolver import Resolver
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.module_utils.common.yaml import HAS_LIBYAML, Parser
    if HAS_LIBYAML:
        class AnsibleLoader(Parser, AnsibleConstructor, Resolver):
            def __init__(self, stream, file_name=None, vault_secrets=None):
                Parser.__init__(self, stream)  # pylint: disable=non-parent-init-called
                AnsibleConstructor.__init__(self, file_name=file_name, vault_secrets=vault_secrets)
                Resolver.__init__(self)
    else:
        from yaml.composer import Composer

# Generated at 2022-06-25 04:36:48.481515
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert test_case_0() == 0

# Generated at 2022-06-25 04:37:31.408621
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)


# Generated at 2022-06-25 04:37:36.518275
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  stream_0 = 'P#4jyH'
  ansible_loader_0 = AnsibleLoader(stream_0)
  stream_1 = 'P#4jyH'
  ansible_loader_1 = AnsibleLoader(stream_1)


# Generated at 2022-06-25 04:37:42.543844
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_1 = 'Nb7CfZ'
    file_name_1 = 'GiyfW8'
    vault_secrets_1 = 'HxE1h'
    ansible_loader_1 = AnsibleLoader(str_1, file_name_1, vault_secrets_1)
    assert ansible_loader_1.stream is str_1
    assert ansible_loader_1.file_name is file_name_1
    assert ansible_loader_1.vault_secrets is vault_secrets_1
    assert ansible_loader_1.vault_lookup_plugins is not None

    str_2 = 'WOaUZc'
    file_name_2 = 'W8gHN1'
    vault_secrets_2 = '8NUSG'
    ansible

# Generated at 2022-06-25 04:37:45.187116
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)

    ansible_loader_0.compose_node(ansible_loader_0.get_node(), deep=True)

    ansible_loader_0.get_single_data()

# Generated at 2022-06-25 04:37:54.605137
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Get stream
    stream = get_stream()

    # Initialize
    ansible_loader_0 = AnsibleLoader(stream)
    ansible_loader_0.constructor.add_constructor(u'tag:yaml.org,2002:map', type(dict))

    # AssertionError: expected <class 'yaml.composer.Composer'> but found <class 'ansible.parsing.yaml.constructor.AnsibleConstructor'>
    file_name = 'test_file'
    ansible_loader_1 = AnsibleLoader(stream, file_name=file_name)
    assert ansible_loader_1.constructor.add_constructor(u'tag:yaml.org,2002:map', type(int))

# Generated at 2022-06-25 04:37:58.235379
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        test_case_0()
    except Exception as ex:
        msg = traceback.format_exc()
        print("test_AnsibleLoader Exception: " + msg)
        assert False


# Generated at 2022-06-25 04:38:03.325048
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_0_file_name = ansible_loader_0.file_name
    str_1 = 'Yf5uV'
    ansible_loader_0.set_file_name(str_1)
    ansible_loader_0_file_name_1 = ansible_loader_0.file_name
    assert (ansible_loader_0_file_name != ansible_loader_0_file_name_1)


# Generated at 2022-06-25 04:38:04.584309
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # get a loader from AnsibleLoader
    AnsibleLoader(str())

# Generated at 2022-06-25 04:38:07.465775
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)
    assert ansible_loader_0.stream == str_0
    assert ansible_loader_0.file_name == None
    assert ansible_loader_0.vault_secrets == None

# Generated at 2022-06-25 04:38:13.193501
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = str
    str_1 = str
    str_2 = str
    ansible_loader_0 = AnsibleLoader(str_0, str_1, str_2)
    ansible_loader_0 = AnsibleLoader(str_2, str_0, str_1)
    ansible_loader_0 = AnsibleLoader(str_1, str_2, str_0)

# Generated at 2022-06-25 04:39:42.976653
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str = 'P#4jyH'
    ansible_loader = AnsibleLoader(str)
    # here is how we extract the content information if we want it
    # ansible_loader.get_single_data()

    assert(True)
    return

# Generated at 2022-06-25 04:39:48.961310
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Try to create an instance of AnsibleLoader class
    str = 'P#4jyH'
    ansible_loader = AnsibleLoader(str)

    # Try to create an instance of AnsibleLoader class with two parameters
    str_0 = 'P#4jyH'
    str_1 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0, str_1)


# Generated at 2022-06-25 04:39:57.116831
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = 'lW8x5'
    ansible_loader_1 = AnsibleLoader(ansible_loader_0)
    ansible_loader_2 = AnsibleLoader(ansible_loader_0)
    ansible_loader_3 = 'D7IJ8'
    ansible_loader_4 = '1iU6R'
    ansible_loader_5 = 'T#2s1'
    ansible_loader_6 = '-4lkl'
    ansible_loader_7 = 'z4S$S'
    ansible_loader_8 = 'p#4jy'
    ansible_loader_9 = 'mwh$a'
    ansible_loader_10 = '9Pp$N'
    ansible_loader_11 = '-1I2C'
    ans

# Generated at 2022-06-25 04:39:59.370713
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(str_0)

# Generated at 2022-06-25 04:40:01.791607
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)


if __name__ == '__main__':
    from __main__ import test_case_0
    test_case_0()

# Generated at 2022-06-25 04:40:07.403029
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    file_name_0 = '~0'
    vault_secrets_0 = {'V7': True, 'N': '7', '+qI': '7U', 'v': 'W6', 'C<<': {'I': 16.30563230528981, 'R': 'C78', '(': '4)4', '3': 'w'}, '_': 59, 'T': '-', '*': 'Dt'}

    ansible_loader_0 = AnsibleLoader(str_0)
    print(ansible_loader_0.store)
    ansible_loader_1 = AnsibleLoader(str_0, file_name_0)
    print(ansible_loader_1.file_name)
    ansible_loader_2 = Ans

# Generated at 2022-06-25 04:40:09.713469
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    s = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(s)
    assert ansible_loader_0.stream == 'P#4jyH'

# Generated at 2022-06-25 04:40:11.350937
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'P#4jyH'
    ansible_loader_0 = AnsibleLoader(str_0)

# Generated at 2022-06-25 04:40:18.427111
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'jfQF<i'
    str_1 = '6rPv6-'
    str_2 = '-b!Yp4'

    # Verify the if elseif and else conditions of the if elseif and else statement
    if hasattr(AnsibleLoader, str_0):
        str_3 = 'BaseLoader'
        str_4 = 'yaml.constructor.BaseConstructor'

        # Verify the type of a variable
        assert isinstance(getattr(AnsibleLoader, str_3), type)

        # Verify the type of a variable
        assert isinstance(getattr(AnsibleLoader, str_0), type)

        # Verify the value of a variable
        assert getattr(AnsibleLoader, str_3) is getattr(AnsibleLoader, str_0)

    el

# Generated at 2022-06-25 04:40:19.380954
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(None)
    assert ansible_loader