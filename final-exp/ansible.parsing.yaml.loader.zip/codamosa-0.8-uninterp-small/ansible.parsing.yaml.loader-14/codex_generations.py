

# Generated at 2022-06-25 04:32:11.811583
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        assert AnsibleLoader
    except NameError:
        assert False, "Unable to find AnsibleLoader class"

    ansible_loader_0 = AnsibleLoader(float_0)
    try:
        assert ansible_loader_0
    except NameError:
        assert False, "Unable to determine whether AnsibleLoader instantiation was successful"

    try:
        assert type(ansible_loader_0) is AnsibleLoader
    except NameError:
        assert False, "Unable to determine if ansible_loader_0 is an instance of AnsibleLoader"

    try:
        assert callable(ansible_loader_0)
    except NameError:
        assert False, "Unable to determine if ansible_loader_0 is callable"


# Generated at 2022-06-25 04:32:20.748226
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = 1154

# Generated at 2022-06-25 04:32:21.280733
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-25 04:32:22.968271
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader()
    assert ansible_loader_0.__class__ == AnsibleLoader


# Generated at 2022-06-25 04:32:26.901387
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:32:32.962053
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # answer
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.reader import AnsibleReader
    from ansible.parsing.yaml.scanner import AnsibleScanner
    from ansible.parsing.yaml.constructor import ConstructorError
    # answer end

    # test_AnsibleLoader
    # ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_0 = AnsibleLoader(None)
    # test_AnsibleLoader end

    # answer
    # float_0 = 1579.0
    float_0 = None
    # ansible_loader_0 = AnsibleLoader(float_

# Generated at 2022-06-25 04:32:34.462415
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:32:37.153669
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_2 = 3.0
    ansible_loader_2 = AnsibleLoader(float_2)


# Generated at 2022-06-25 04:32:38.694495
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # call function
    test_case_0()


# Generated at 2022-06-25 04:32:46.822705
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10 = float()
    float_11 = float()
    float_12 = float()
    float_13 = float()
    float_14 = float()
    float_15 = float()
    list_8 = list()
    list_9 = list()
    list_10 = list()
    list_11 = list()
    list_12 = list()
    list_13 = list()
    list_14 = list()
    list_15 = list()
    list_16 = list()

# Generated at 2022-06-25 04:32:51.915059
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_0)
    try:
        ansible_loader_0.check_data()
    except TypeError:
        pass

# Generated at 2022-06-25 04:32:58.388490
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = ""
    with pytest.raises(Exception) as excinfo:
        ansible_loader_0 = AnsibleLoader(data)
    assert "YAML Syntax Error" in str(excinfo.value)

from ansible.parsing.yaml.objects import AnsibleUnicode
from ansible.parsing.yaml.objects import AnsibleSequence
from ansible.parsing.yaml.objects import AnsibleMapping
from ansible.parsing.yaml.objects import AnsibleUnicode


# Generated at 2022-06-25 04:33:00.851580
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: add other assertion tests
    assert True == True

# Generated at 2022-06-25 04:33:02.906478
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Test case for method __init__
    test_case_0()

# Generated at 2022-06-25 04:33:07.622278
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader()
    assert obj.get_single_data() == None
    assert obj.get_root_node_id() == None
    assert obj.set_root_object() == None


# Generated at 2022-06-25 04:33:09.940896
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # check constructor
    ansible_loader_0 = AnsibleLoader(None)

    return ansible_loader_0

# test with args

test_AnsibleLoader()

# Generated at 2022-06-25 04:33:11.475292
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:33:13.412204
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_1 = 1579.0
    ansible_loader_1 = AnsibleLoader(float_1)

# Generated at 2022-06-25 04:33:17.609371
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 1343.0
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_1 = AnsibleLoader(float_0)
    assert ansible_loader_0 == ansible_loader_1
    ansible_loader_2 = AnsibleLoader(float_0)
    assert ansible_loader_0 != ansible_loader_2


# Generated at 2022-06-25 04:33:25.524134
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 2720.0
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_1 = AnsibleLoader(float_0)
    assert ansible_loader_0.stream is ansible_loader_1.stream
    assert ansible_loader_0.file_name is ansible_loader_1.file_name
    assert not ansible_loader_0.vault_secrets is ansible_loader_1.vault_secrets
    ansible_loader_0.create_data_node(2720.0, 2720.0)
    # assert ansible_loader_0.file_name is ansible_loader_1.file_name
    # assert not ansible_loader_0.vault_secrets is ansible_loader_1.vault_secrets
    ans

# Generated at 2022-06-25 04:33:34.609012
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert not hasattr(AnsibleLoader, "test_case_0")

# Generated at 2022-06-25 04:33:35.310686
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:33:37.216669
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Call test 0
    test_case_0()

if __name__ == '__main__':
    # Unit test for constructor of class AnsibleLoader
    test_AnsibleLoader()

# Generated at 2022-06-25 04:33:46.788860
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # testcase 1
    float_0 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_0)

    # testcase 2
    ansible_loader_1 = AnsibleLoader(float_0)
    ansible_loader_1.__init__(float_0)

    # testcase 3
    ansible_loader_2 = AnsibleLoader(float_0)
    ansible_loader_2.__init__(float_0)
    ansible_loader_2.__init__(float_0)

    # testcase 4
    ansible_loader_3 = AnsibleLoader(float_0)
    ansible_loader_3.__init__(float_0)
    ansible_loader_3.__init__(float_0)

# Generated at 2022-06-25 04:33:49.219502
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:33:53.415510
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_0)
    assert ansible_loader_0 is not None


# Generated at 2022-06-25 04:33:55.536531
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 164.51
    ansible_loader_0 = AnsibleLoader(float_0)


# Generated at 2022-06-25 04:33:57.384304
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:34:03.201020
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    file_name_0 = '1'
    vault_secrets_0 = 1.0
    ansible_loader_0 = AnsibleLoader(file_name=file_name_0, vault_secrets=vault_secrets_0)
    ansible_loader_0.file_name
    ansible_loader_0.vault_secrets
    ansible_loader_0.vault_secrets
    ansible_loader_0.vault_secrets
    ansible_loader_0.vault_secrets
    ansible_loader_0.vault_secrets
    ansible_loader_0.vault_secrets
    ansible_loader_0.vault_secrets
    ansible_loader_0.vault_secrets
    ansible_loader_0.vault_secrets

#

# Generated at 2022-06-25 04:34:06.677989
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = 'n'
    file_name = 'file_name'
    vault_secrets = 'vault_secrets'
    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)
    assert ansible_loader_0.stream

# Generated at 2022-06-25 04:34:17.397921
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream_0 = dict()
    ansible_loader_0 = AnsibleLoader(stream_0)
    assert ansible_loader_0.__class__.__name__ == "AnsibleLoader"

# Generated at 2022-06-25 04:34:21.961261
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print("start of test case: test_AnsibleLoader")
    # Test case 0:
    float_0 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_0)
    print("end of test case: test_AnsibleLoader")


# Generated at 2022-06-25 04:34:31.571050
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
   stream = ""
   file_name = ""
   vault_secrets = ""
   ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)
   assert ansible_loader_0.construct_yaml_map("string") == {}
   assert ansible_loader_0.construct_yaml_seq("string") == []
   assert ansible_loader_0.construct_mapping() == {}
   assert ansible_loader_0.construct_sequence() == []
   assert ansible_loader_0.construct_object("a", "b") == {}
   assert ansible_loader_0.construct_python_str("string") == []
   assert ansible_loader_0.construct_yaml_str("string") == []

# Generated at 2022-06-25 04:34:39.235518
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # float_0
    float_0 = 1579.0
    # ansible_loader_0
    ansible_loader_0 = AnsibleLoader(float_0)
    # ansible_loader_1
    ansible_loader_1 = AnsibleLoader(float_0)
    # string_0
    string_0 = "hi"
    # string_1
    string_1 = AnsibleLoader(string_0)
    # ansible_loader_2
    ansible_loader_2 = AnsibleLoader(string_0)
    # float_1
    float_1 = AnsibleLoader(float_0, string_0)
    # float_2
    float_2 = AnsibleLoader(float_0, string_0, string_0)
    # ansible_loader_3
    ansible_loader_3 = Ans

# Generated at 2022-06-25 04:34:40.081842
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:34:43.714165
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test the constructor with float
    float_0 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_0)
    # Test the constructor with bytes
    bytes_0 = b'$'
    ansible_loader_1 = AnsibleLoader(bytes_0)
    # Test the constructor with string
    string_0 = 'm'
    ansible_loader_2 = AnsibleLoader(string_0)

# Generated at 2022-06-25 04:34:49.417483
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    float_1 = 508.0
    ansible_loader_1 = AnsibleLoader(float_1)

    stream_1 = ""
    ansible_loader_1.scan(stream_1)

    ansible_loader_1.dispose()

# Generated at 2022-06-25 04:35:00.677521
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = float(); float_1 = float(); float_2 = float()
    float_3 = float(); float_4 = float(); float_5 = float()
    float_6 = float(); float_7 = float(); float_8 = float()
    float_9 = float(); float_10 = float(); float_11 = float()
    float_12 = float(); float_13 = float(); float_14 = float()
    float_15 = float(); float_16 = float(); float_17 = float()
    float_18 = float(); float_19 = float(); float_20 = float()
    float_21 = float(); float_22 = float(); float_23 = float()
    float_24 = float(); float_25 = float(); float_26 = float()
    float_27 = float(); float_28 = float(); float_29 = float()

# Generated at 2022-06-25 04:35:02.537674
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_0)
# Test full functionality of class AnsibleLoader

# Generated at 2022-06-25 04:35:06.421403
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    file_name = "file_name"
    vault_secrets = "vault_secrets"
    ansible_loader_0 = AnsibleLoader(file_name, vault_secrets)
    assert ansible_loader_0.file_name == file_name
    assert ansible_loader_0.vault_secrets == vault_secrets

# Generated at 2022-06-25 04:35:33.362832
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    # test loading with no vault secrets
    test_load = loader.load("""
     ---
     - name: test_vault_include
       hosts: all
       tasks:
        - include_vars: "test_vault_include.yml"
     """)

    # test loading with vault secrets
    vault_secrets = {'vault.yml': {'vault_pass': '12345'}}
    test_load = loader.load("""
     ---
     - name: test_vault_include
       hosts: all
       tasks:
        - include_vars: "test_vault_include.yml"
     """, vault_secrets=vault_secrets)

    # test loading with no

# Generated at 2022-06-25 04:35:33.758333
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:35:44.610866
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 1579.0
    assert isinstance(AnsibleLoader(float_0), AnsibleLoader)
    assert isinstance(AnsibleLoader(float_0), Resolver)
    assert isinstance(AnsibleLoader(float_0), AnsibleConstructor)
    assert isinstance(AnsibleLoader(float_0), Parser)
    assert isinstance(AnsibleLoader(float_0), Reader)
    assert isinstance(AnsibleLoader(float_0), Scanner)
    assert isinstance(AnsibleLoader(float_0), Composer)
    assert isinstance(AnsibleLoader(float_0), AnsibleLoader)
    float_1 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_1)
    assert isinstance(ansible_loader_0, Parser)

# Generated at 2022-06-25 04:35:47.266015
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # It should pass when loading from a file string
    ansible_loader_0 = AnsibleLoader('my_file')
    # It should pass when loading from a stream
    ansible_loader_1 = AnsibleLoader('')


# Generated at 2022-06-25 04:35:52.006311
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Get the parent's class
    parent = AnsibleLoader.__base__

    # Make sure the parent's class is not AnsibleLoader itself
    assert parent.__name__ != 'AnsibleLoader'

    # Make sure the parent's class is not named object
    assert parent.__name__ != 'object'

    # Make sure the parent's class is named Reader
    assert parent.__name__ == 'Reader'

# Generated at 2022-06-25 04:35:53.721493
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 2556.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:36:01.682081
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 105.0
    double_0 = 5.0
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_0.add_implicit_resolver("14.0", "float" , "float_", double_0)
    ansible_loader_0.add_implicit_resolver("0.0", "double", "double_", double_0)



# Generated at 2022-06-25 04:36:02.231352
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:36:06.646255
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:36:10.784744
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-25 04:36:48.408784
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_Sysout0 = 1579.0
    float_Sysout1 = 1579.0
    float_Sysout2 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_Sysout0)
    ansible_loader_0.get_single_data()
    ansible_loader_0.check_data()

# Generated at 2022-06-25 04:36:50.772755
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print("Test the constructor of class AnsibleLoader")
    float_0 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_0)


# Generated at 2022-06-25 04:36:57.641001
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_1 = AnsibleLoader(float_0)
    ansible_loader_2 = AnsibleLoader(float_0)
    ansible_loader_3 = AnsibleLoader(float_0)
    ansible_loader_4 = AnsibleLoader(float_0)


# Generated at 2022-06-25 04:36:59.456201
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:37:09.937198
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_0)
    # Check that types are correct
    assert(type(ansible_loader_0.SafeLoader) is type)
    assert(type(ansible_loader_0.CLoader) is type)
    assert(type(ansible_loader_0.AnsibleDumper) is type)
    assert(type(ansible_loader_0.AnsibleUnsafeLoader) is type)
    assert(type(ansible_loader_0.AnsibleUnsafeDumper) is type)
    assert(type(ansible_loader_0.construct_mapping) is type(AnsibleLoader.construct_mapping))

# Generated at 2022-06-25 04:37:15.331018
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #TODO: fix this test
    return
    for float_0 in range(1, 10):
        try:
            ansible_loader_0 = AnsibleLoader(float_0)
        except TypeError:
            pass
        else:
            raise AssertionError("Not raise TypeError")

# Generated at 2022-06-25 04:37:17.385426
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_0.reader = '|' # non-compliant code, property not defined


# Generated at 2022-06-25 04:37:18.316910
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert 1 == 1


# Generated at 2022-06-25 04:37:19.524920
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(None)

# Generated at 2022-06-25 04:37:30.637434
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    ansible_loader_0 = AnsibleLoader(None)
    ansible_loader_0 = AnsibleLoader(None, None)
    ansible_loader_0 = AnsibleLoader(None, None, None)
    ansible_loader_0 = AnsibleLoader(None, None, None, None)
    ansible_loader_0 = AnsibleLoader(None, None, None, None, None)
    ansible_loader_0 = AnsibleLoader(None, None, None, None, None, None)
    ansible_loader_0 = AnsibleLoader(None, None, None, None, None, None, None)
    ansible_loader_0 = AnsibleLoader(None, None, None, None, None, None, None, None)

# Generated at 2022-06-25 04:38:51.360590
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_0)
    assert ansible_loader_0 is not None

# Generated at 2022-06-25 04:39:01.400281
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = float(76.89)
    ansible_loader_0 = AnsibleLoader(float_0)
    assert ansible_loader_0.__init__(float_0) == None
    assert ansible_loader_0.get_data() == None
    assert ansible_loader_0.get_single_data() == None
    float_1 = float(76.89)
    ansible_loader_0 = AnsibleLoader(float_1)
    assert ansible_loader_0.get_mark() == None
    assert ansible_loader_0.get_single_data() == None
    assert ansible_loader_0.process_anchor('Resolver') == None
    assert ansible_loader_0.process_directive('get_mark') == None
    assert ansible_loader_0.process_sc

# Generated at 2022-06-25 04:39:02.842283
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Note: This test is the same as test_case_0, so if this compiles, the test will pass
    float_0 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:39:06.897822
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader({'some': 'data'})
    assert loader.get_single_data() == {'some': 'data'}

# Generated at 2022-06-25 04:39:15.274962
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader()
    ansible_loader_0.add_multi_constructor('!SomeTag', 'some_func')
    ansible_loader_0.dispose()
    ansible_loader_0.get_single_data()
    ansible_loader_0.process_tag(None, None, None)
    ansible_loader_0.scan_tag(None, None)
    ansible_loader_0.tag_constructor(None, None, None)
    ansible_loader_0.tag_constructor_safe(None, None, None)

    test_case_0()

# Generated at 2022-06-25 04:39:16.036132
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
   s = AnsibleLoader()

# Generated at 2022-06-25 04:39:21.194779
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 1010.0
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_0.add_constructor('!includevars', AnsibleConstructor.construct_yaml_ini)
    ansible_loader_0.add_constructor(u'!include', AnsibleConstructor.construct_yaml_include)
    ansible_loader_0.add_constructor(u'!include', AnsibleConstructor.construct_yaml_include)
    ansible_loader_0.add_constructor('!includevars', AnsibleConstructor.construct_yaml_ini)
    ansible_loader_0.add_constructor(u'!include', AnsibleConstructor.construct_yaml_include)


# Generated at 2022-06-25 04:39:22.706901
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    params = [""]
    ansible_loader_0 = AnsibleLoader(params[0])
    assert ansible_loader_0


# Generated at 2022-06-25 04:39:25.174403
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 1579.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:39:35.271682
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # testing some basic objects
    if HAS_LIBYAML:
        loader = AnsibleLoader("[1,2,3]")
    else:
        loader = AnsibleLoader("[1,2,3]".encode('utf-8'))
    result = loader.get_single_data()
    assert result == [1,2,3]

    # testing a load of a scalar object
    _ = AnsibleLoader("1")
    result = loader.get_single_data()
    assert result == 1

    # a more complex load
    test_data_0 = {'foo': 'bar'}
    ansible_loader_0 = AnsibleLoader(test_data_0)
    test_data_1 = '123.0'
    ansible_loader_1 = AnsibleLoader(test_data_1)
   