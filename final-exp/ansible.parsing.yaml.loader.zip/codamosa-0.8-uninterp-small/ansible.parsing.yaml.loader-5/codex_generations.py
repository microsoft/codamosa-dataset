

# Generated at 2022-06-25 04:32:05.352610
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Create an instance of class AnsibleLoader
    # with the following parameters
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)


# Generated at 2022-06-25 04:32:06.683684
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)


# Generated at 2022-06-25 04:32:07.453332
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
      test_case_0()

# Generated at 2022-06-25 04:32:14.580869
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Case #1
    test_case_0()

    # Case #2
    ansible_loader_0 = AnsibleLoader("Ansible Loader")
    ansible_loader_1 = AnsibleLoader("Ansible Loader")

    # Case #3
    ansible_loader_2 = AnsibleLoader("Ansible Loader")
    ansible_loader_3 = ansible_loader_2

    # Case #4
    ansible_loader_4 = ansible_loader_2
    ansible_loader_4 = "Ansible Loader"


# Generated at 2022-06-25 04:32:19.629713
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)
    # check type of ansible_loader_0
    assert isinstance(ansible_loader_0, AnsibleLoader)
    pass



# Generated at 2022-06-25 04:32:20.821340
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert callable(AnsibleLoader)


# Generated at 2022-06-25 04:32:23.145411
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)


if __name__ == '__main__':
    import sys
    sys.exit(unittest.main())

# Generated at 2022-06-25 04:32:32.855537
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader()
    assert len(ansible_loader_0._Loader__yaml_constructors) == 1
    assert ansible_loader_0._Loader__yaml_constructors == {'!include' : ansible_loader_0._construct_include}
    assert len(ansible_loader_0._r_newline_sequence) == 2
    assert ansible_loader_0._r_newline_sequence == (0, 0)
    assert len(ansible_loader_0.file_name) == 0
    assert ansible_loader_0.file_name == ""
    assert ansible_loader_0.vault_secrets == []
    assert ansible_loader_0.current_line == 1


# Generated at 2022-06-25 04:32:37.764244
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test with default parameters
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)
    assert ansible_loader_0.get_single_data() == True



# Generated at 2022-06-25 04:32:42.834185
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    assert isinstance(True, object)
    ansible_loader_0 = AnsibleLoader(__loader__, __loader__, __loader__)
    assert callable(ansible_loader_0)
    assert isinstance(True, object)
    ansible_loader_0 = AnsibleLoader(__loader__, __loader__, __loader__)
    assert isinstance(True, object)



# Generated at 2022-06-25 04:32:46.427012
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ''
    load = AnsibleLoader(stream)
    assert isinstance(load, AnsibleLoader)

# Generated at 2022-06-25 04:32:57.235841
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = '''
    - hosts:
        - cp-0.stg.fortimail.com
        - cp-1.stg.fortimail.com
      gather_facts: true
      roles:
        - fortimail-cluster
      vars:
        - cluster_password: 12345678
        - cluster_disk_quota_mb: 50000
        - cluster_admin_password: 12345678
        - cluster_install_with_fgt: true
        - cluster_install_with_fmg: true
        - cluster_fmg_password: 12345678
        - cluster_fgt_password: 12345678
        - vdom_list:
            - ansible
    '''

    #
    # Testcase 1:
    #
    # Create AnsibleLoader object with stream containing valid y

# Generated at 2022-06-25 04:33:00.340372
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        # Initialize class AnsibleLoader
        bool_0 = True
    except:
        assert (False)


# Generated at 2022-06-25 04:33:03.437805
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print()
    print("Starting Test for AnsibleLoader")
    if test_case_0():
        TestAnsibleLoader()
    print("Ending Test for AnsibleLoader")


# Generated at 2022-06-25 04:33:08.722794
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Create an instance
    # Example use of the constructor
    test_0 = AnsibleLoader(stream=[], file_name=None, vault_secrets=None)
    assert isinstance(test_0, AnsibleLoader)
    assert test_0 is not None

# Generated at 2022-06-25 04:33:11.156132
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(test_case_0())
    assert loader.construct_mapping == AnsibleConstructor.construct_mapping

# Generated at 2022-06-25 04:33:13.945428
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class DummyStream:
        def __init__(self):
            pass

    data = DummyStream()
    loader = AnsibleLoader(data)
    print("AnsibleLoader testcase 0 passed")


# Generated at 2022-06-25 04:33:17.785568
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    global bool_0
    test_case_0()
    ansibleloader = AnsibleLoader(byte_0, string_0, list_0)
    assert ansibleloader is not None
    assert ansibleloader.get_mark() is not None

# Generated at 2022-06-25 04:33:25.765975
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:33:26.408199
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass # TODO



# Generated at 2022-06-25 04:33:31.083232
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0.__init__(int_0)



# Generated at 2022-06-25 04:33:39.961138
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader()
    ansible_loader_0.add_implicit_resolver()
    ansible_loader_0.add_path_resolver()
    ansible_loader_0.add_constructor()
    ansible_loader_0.add_multi_constructor()
    ansible_loader_0.add_representer()
    ansible_loader_0.add_multi_representer()
    ansible_loader_0.add_resolver()
    ansible_loader_0.compose_node()
    ansible_loader_0.construct_object()
    ansible_loader_0.construct_document()
    ansible_loader_0.construct_sequence()
    ansible_loader_0.construct_mapping()
    ansible_loader_0.dispose()


# Generated at 2022-06-25 04:33:42.406993
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0 = AnsibleLoader(int_0, True)

    assert True



# Generated at 2022-06-25 04:33:50.633375
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_1 = 10
    stream_0 = [int_1]
    obj_0 = AnsibleLoader(stream_0)
    attr_0 = obj_0.src
    str_0 = "src"
    assert hasattr(obj_0, str_0)
    assert obj_0.src == stream_0
    int_0 = 0
    int_1 = 100
    str_0 = "file_name"
    assert hasattr(obj_0, str_0)
    obj_0.file_name = int_1
    assert obj_0.file_name == int_1


# Generated at 2022-06-25 04:33:54.236445
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)


# Generated at 2022-06-25 04:33:55.368563
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:34:00.513804
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        # Test case with 0 arguments
        ansible_loader_0 = AnsibleLoader()
    except Exception as e:
        print(e)
        assert False, "An exception occurred during test case 0"
    else:
        assert True, "Test case 0 passed"


# Generated at 2022-06-25 04:34:02.303034
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
	test_case_0()

# Generated at 2022-06-25 04:34:09.686478
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        fileName = 'test.yml'
        ansibleLoader = AnsibleLoader(fileName)
        print("AnsibleLoader(): ", ansibleLoader)
        # demo for setter method
        setter = ansibleLoader.set_filename("setter_demo")
        print("Setter: ", setter)
    except:
        print("Error: unable to fetch data")

if __name__ == "__main__":
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:34:11.467275
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)

# Generated at 2022-06-25 04:34:16.762823
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test()

# Generated at 2022-06-25 04:34:19.073323
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''we are trying to create an instance of AnsibleLoader'''
    int_1 = True
    ansible_loader_1 = AnsibleLoader(int_1)
    assert ansible_loader_1 is not None


# Generated at 2022-06-25 04:34:21.874309
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Basic test to ensure that AnsibleLoader instance is created
    assert isinstance(AnsibleConstructor("foo", "bar"), AnsibleConstructor) == True


# Generated at 2022-06-25 04:34:25.018165
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(bool_0)
    assert ansible_loader_0.file_name == str_1

#Unit test for method load_yaml_from_file of class AnsibleLoader

# Generated at 2022-06-25 04:34:26.072950
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)

# Generated at 2022-06-25 04:34:28.697803
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader()
    ansible_loader_0.set_constructors_and_resolvers()

# Generated at 2022-06-25 04:34:31.778023
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader()
    assert ansible_loader_0.file_name == '<unknown>'
    assert ansible_loader_0.vault_secrets == None

# Generated at 2022-06-25 04:34:33.292112
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print_str = 'unit test'
    file_name_str = 'file_name_str'
    vault_secrets_dict = {'key_str': 'value_str'}
    ansible_loader_0 = AnsibleLoader(print_str, file_name_str, vault_secrets_dict)


# Generated at 2022-06-25 04:34:35.573182
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)
    assert(isinstance(ansible_loader_0, AnsibleLoader))

# Generated at 2022-06-25 04:34:37.853539
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_1 = True
    ansible_loader = AnsibleLoader(int_1)

# Generated at 2022-06-25 04:34:47.848291
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(0)

# Generated at 2022-06-25 04:34:49.401397
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #TODO: improve unit tests for AnsibleLoader
    assert True == True # to make the test pass

# Generated at 2022-06-25 04:34:56.633045
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(int_0)
    if ansible_loader_0 is not None:
        assert True
    else:
        assert False

if __name__ == '__main__':
    print('testing AnsibleLoader')
    test_AnsibleLoader()

# Generated at 2022-06-25 04:34:59.951635
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)
    assert ansible_loader_0 is not None

# Generated at 2022-06-25 04:35:02.962987
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = AnsibleLoader(str)
    assert isinstance(int_0, AnsibleLoader)
    int_0 = AnsibleLoader(str, str)
    assert isinstance(int_0, AnsibleLoader)


# Generated at 2022-06-25 04:35:05.590268
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, '__init__')
    assert hasattr(AnsibleLoader, '_get_yaml_type')
    assert hasattr(AnsibleLoader, '_get_file_type')

# Generated at 2022-06-25 04:35:09.745837
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_1 = True
    ansible_loader_1 = AnsibleLoader(int_1)
    # int should be consumed and no exception should be raised
    ansible_loader_1.get_single_data()
    ansible_loader_2 = AnsibleLoader('123')
    # 123 should be consumed and no exception should be raised
    ansible_loader_2.get_single_data()

# Generated at 2022-06-25 04:35:15.339793
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = 0
    # Following condition is used to prevent generation of code coverage
    if 9 > int_0:
        ansible_loader_0 = AnsibleLoader(int_0)
        ansible_loader_0 = AnsibleLoader(int_0, int_0)
        ansible_loader_0 = AnsibleLoader(int_0, int_0, int_0)
        ansible_loader_0 = AnsibleLoader(int_0, int_0, int_0, int_0)
        ansible_loader_0 = AnsibleLoader(int_0, int_0, int_0, int_0, int_0)
        ansible_loader_0 = AnsibleLoader(int_0, int_0, int_0, int_0, int_0, int_0)

# Generated at 2022-06-25 04:35:17.063009
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)

# Generated at 2022-06-25 04:35:18.570080
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)

# Generated at 2022-06-25 04:35:39.547195
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)
    print("DONE")


# Generated at 2022-06-25 04:35:46.230696
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)
    assert (ansible_loader_0.construct_yaml_bool(int_0) is True)



# Generated at 2022-06-25 04:35:49.517430
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

if __name__ == '__main__':
    test_AnsibleLoader ()

# Generated at 2022-06-25 04:35:50.697072
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = "string"
    ansible_loader = AnsibleLoader(stream)
    assert ansible_loader.stream == stream

# Generated at 2022-06-25 04:35:54.790493
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)
    str_0 = ansible_loader_0.get_single_data()
    bool_0 = ansible_loader_0.check_data_mark(str_0)
    assert bool_0


# Generated at 2022-06-25 04:36:03.669551
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0.add_implicit_resolver('tag:yaml.org,2002:str', 'str', None, None, None, None)
    ansible_loader_0.add_constructor('tag:yaml.org,2002:python/none', ansible_loader_0._construct_yaml_null)
    ansible_loader_0.add_constructor('tag:yaml.org,2002:python/bool', ansible_loader_0._construct_yaml_bool)
    ansible_loader_0.add_constructor('tag:yaml.org,2002:python/unicode', ansible_loader_0._construct_yaml_str)
    ansible_loader_0.add_constructor

# Generated at 2022-06-25 04:36:06.255088
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:36:08.459067
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    a = AnsibleLoader(int(1))
    b = AnsibleLoader(int(1), 'test')
    c = AnsibleLoader(int(1), 'test', 'test')

# Generated at 2022-06-25 04:36:11.228636
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader()
    assert isinstance(ansible_loader_0, AnsibleLoader)
    assert isinstance(ansible_loader_0, Parser)

# Generated at 2022-06-25 04:36:14.144165
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    file_0 = "test"
    ansible_loader = AnsibleLoader(file_0)

    # Check if there are no exceptions
    try:
        ansible_loader.get_single_data()
    except:
        raise AssertionError()

# Generated at 2022-06-25 04:36:50.554414
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        ansible_loader = AnsibleLoader([])
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-25 04:36:56.159773
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Constructor of class AnsibleLoader
    ansible_loader_0 = AnsibleLoader.__new__(AnsibleLoader)
    # No exception thrown
    assert True

# Generated at 2022-06-25 04:37:05.336314
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # for AnsibleLoader class, all the parameters should be in the constructor
    int_0 = True
    str_0 = 'S'
    ansible_loader_0 = AnsibleLoader(int_0, str_0)
    ansible_loader_0.Reader.__init__(int_0)
    ansible_loader_0.Scanner.__init__()
    ansible_loader_0.Parser.__init__()
    ansible_loader_0.Composer.__init__()
    ansible_loader_0.AnsibleConstructor.__init__(str_0)
    ansible_loader_0.Resolver.__init__()
    ansible_loader_0.add_constructor('!include', ansible_loader_0.include)

# Generated at 2022-06-25 04:37:07.111743
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Tests if __init__ of AnsibleLoader is called properly
    ansible_loader_0 = AnsibleLoader(stream='stream')

# Generated at 2022-06-25 04:37:14.317448
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # 1/4 Test case 1: normal case
    int_1 = True
    ansible_loader_1 = AnsibleLoader(int_1)
    assert ansible_loader_1

    # 2/4 Test case 2: normal case
    int_2 = True
    str_2 = "str"
    ansible_loader_2 = AnsibleLoader(int_2, file_name=str_2)
    assert ansible_loader_2

    # 3/4 Test case 3: normal case
    int_3 = True
    list_3 = [True]
    ansible_loader_3 = AnsibleLoader(int_3, vault_secrets=list_3)
    assert ansible_loader_3

    # 4/4 Test case 4: normal case
    int_4 = True
    str_4 = "str"
   

# Generated at 2022-06-25 04:37:18.241677
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_1 = True
    ansible_loader_1 = AnsibleLoader(int_1)


# Generated at 2022-06-25 04:37:22.812506
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ""
    ansible_loader_0 = AnsibleLoader(stream)
    ansible_loader_0.construct_mapping()
    ansible_loader_0.check_event()
    ansible_loader_0.construct_object()

    str_0 = "example"
    ansible_loader_1 = AnsibleLoader(stream, str_0)
    ansible_loader_1.construct_mapping()
    ansible_loader_1.check_event()
    ansible_loader_1.construct_object()

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-25 04:37:24.233629
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)

# Generated at 2022-06-25 04:37:27.048370
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(int)
    ansible_loader_0 = None
    ansible_loader_1 = AnsibleLoader(int)
    assert ansible_loader_0 != ansible_loader_1
    ansible_loader_1 = None
    ansible_loader_2 = AnsibleLoader(int)
    assert ansible_loader_0 != ansible_loader_2
    ansible_loader_2 = None
    ansible_loader_3 = AnsibleLoader(int)
    assert ansible_loader_0 != ansible_loader_3
    ansible_loader_3 = None

# Generated at 2022-06-25 04:37:28.287255
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_1 = True
    var_1 = AnsibleLoader(int_1)
    assert var_1.get_data() == "true"

# Generated at 2022-06-25 04:38:54.227738
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ''
    file_name = ''
    vault_secrets = ''

    ansible_loader = AnsibleLoader(stream)
    assert ansible_loader.stream == stream
    assert ansible_loader.file_name == file_name
    assert ansible_loader.vault_secrets == vault_secrets

# unit test for method yaml_parse of class AnsibleLoader

# Generated at 2022-06-25 04:38:57.336778
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Construct object of AnsibleLoader, call get_single_data
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0.get_single_data()

# Generated at 2022-06-25 04:38:58.120977
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader()

# Generated at 2022-06-25 04:39:00.339193
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(True)
    assert ansible_loader_0 is not None
    assert type(ansible_loader_0).__name__ == 'AnsibleLoader'

# Generated at 2022-06-25 04:39:02.443812
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
   #exception
   try:
       ansible_loader_0 = AnsibleLoader(int_0)
   except Exception as e:
       assert True

   AnsibleLoader(int_0, file_name = None, vault_secrets = None)
   assert True

# Generated at 2022-06-25 04:39:13.538610
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = True
    ansible_loader_0 = AnsibleLoader(int_0)
    str_0 = "o`:rnJ)^m@B5' -x1ZrM25(PI/WYaTh!v<+9t=ci'Jf8HO]FbQvxiq+Dz{]n'[#"
    str_1 = "=vm}0-D>A~(s|s_x&z0wK$V7'"
    str_2 = "9X6&4uV7RH"

# Generated at 2022-06-25 04:39:13.974046
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:39:15.574808
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:39:24.838079
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    arguments = [True]
    ansible_loader = AnsibleLoader(*arguments)
    assert isinstance(ansible_loader, AnsibleLoader)
    assert not hasattr(ansible_loader, 'coding_needed')
    assert hasattr(ansible_loader, '_parser_configured_for_errors')
    assert not hasattr(ansible_loader, '_expecting_value')
    assert not hasattr(ansible_loader, '_file_name')
    assert not hasattr(ansible_loader, '_file_vars')
    assert not hasattr(ansible_loader, '_vault_secrets')
    assert not hasattr(ansible_loader, '_vault_version')
    ansible_loader.dispose()
    assert hasattr(ansible_loader, '_expecting_value')


# Generated at 2022-06-25 04:39:35.271480
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader()
    ansible_loader_1 = AnsibleLoader()

    assert not ansible_loader_0 == ansible_loader_1
    assert not ansible_loader_0 is ansible_loader_1
    assert ansible_loader_0.__dict__ is not ansible_loader_1.__dict__

    ansible_loader_0.parse("")
    ansible_loader_1.parse("lala")

    assert ansible_loader_0.__dict__ != ansible_loader_1.__dict__

    ansible_loader_0.parse("")
    assert not ansible_loader_0 == ansible_loader_1
    assert ansible_loader_0.__dict__ != ansible_loader_1.__dict__

    ansible_loader_1.parse("")