

# Generated at 2022-06-25 04:32:11.620348
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Call AnsibleLoader() constructor
    ansible_loader_0 = AnsibleLoader(0)
    assert isinstance(ansible_loader_0, Reader)
    assert isinstance(ansible_loader_0, Scanner)
    assert isinstance(ansible_loader_0, Parser)
    assert isinstance(ansible_loader_0, Composer)
    assert isinstance(ansible_loader_0, AnsibleConstructor)
    assert isinstance(ansible_loader_0, Resolver)
    # Constructor execution
    if ansible_loader_0._reader.name != "<unicode string>":
        ansible_loader_0._reader.name = "<unicode string>"
    ansible_loader_0._reader.buffer = 0
    ansible_loader_0._reader.index = 0
    ansible_loader_

# Generated at 2022-06-25 04:32:13.227156
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader('stream')
    assert ansible_loader_0.file_name is None
    assert ansible_loader_0.vault_secrets is None

# Generated at 2022-06-25 04:32:14.168127
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(int_0)
    assert isinstance(ansible_loader_0, AnsibleLoader)


# Generated at 2022-06-25 04:32:17.861319
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader

    assert AnsibleLoader(None) is not None


# Generated at 2022-06-25 04:32:20.982579
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(None)

if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()
    test_case_0()

# Generated at 2022-06-25 04:32:23.420445
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -3507
    ansible_loader_0 = AnsibleLoader(int_0)

if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:32:26.293755
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -6906
    stream_0 = Token("")
    ansible_loader_0 = AnsibleLoader(stream_0, file_name=int_0)
    int_1 = -3155
    stream_1 = Token("")
    ansible_loader_1 = AnsibleLoader(stream_1, file_name=int_1)



# Generated at 2022-06-25 04:32:30.047283
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=too-many-branches, too-many-statements
    # pylint: disable=protected-access
    (a, b) = test_AnsibleLoader.test_case_0()
    assert a == b

# Generated at 2022-06-25 04:32:31.216864
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -3552
    ansible_loader_0 = AnsibleLoader(int_0)

# Generated at 2022-06-25 04:32:41.073922
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test exception of ValueError from AnsibleLoader.initialize()
    try:
        int_0 = -3552
        ansible_loader_0 = AnsibleLoader(int_0)
        ansible_loader_0.initialize()
        assert False
    except ValueError:
        assert True

    # Test exception of ValueError from AnsibleLoader.check_data()
    try:
        int_0 = -800
        ansible_loader_0 = AnsibleLoader(int_0)
        assert False
    except ValueError:
        assert True

    # Test exception of ValueError from AnsibleLoader.compose_document()

# Generated at 2022-06-25 04:32:45.643842
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -5665
    int_1 = -5665
    ansible_loader_0 = AnsibleLoader(int_0, int_1)

# Generated at 2022-06-25 04:32:52.774033
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None)
    assert isinstance(loader, AnsibleLoader)
    assert isinstance(loader, Resolver)
    assert loader.file_name is None

    loader = AnsibleLoader(stream=None, file_name='/var/tmp/my-file.yml')
    assert isinstance(loader, AnsibleLoader)
    assert isinstance(loader, Resolver)
    assert loader.file_name == '/var/tmp/my-file.yml'


# Generated at 2022-06-25 04:32:54.651868
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -1145
    ansible_loader_0 = AnsibleLoader(int_0)


# Generated at 2022-06-25 04:32:56.824483
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(None)
    assert ansible_loader_0.anchors is {}


# Generated at 2022-06-25 04:33:00.851751
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ""
    file_name = ""
    vault_secrets = ""
    obj = AnsibleLoader(stream, file_name, vault_secrets)
    assert obj != None


# Generated at 2022-06-25 04:33:03.369259
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_1 = -7092
    ansible_loader_1 = AnsibleLoader(int_1)
    int_2 = -5209
    int_3 = -2840
    ansible_loader_1 = AnsibleLoader(int_2, file_name=int_3)

# Generated at 2022-06-25 04:33:07.665688
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -3552
    ansible_loader_0 = AnsibleLoader(int_0)
    with pytest.raises(TypeError):
        assert ansible_loader_0 == int_0

# Generated at 2022-06-25 04:33:14.862982
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # stream is a string here
    int_0 = -3552
    ansible_loader_0 = AnsibleLoader(int_0)
    assert isinstance(ansible_loader_0, Reader) is True
    assert isinstance(ansible_loader_0, Scanner) is True
    assert isinstance(ansible_loader_0, Parser) is True
    assert isinstance(ansible_loader_0, Composer) is True
    assert isinstance(ansible_loader_0, AnsibleConstructor) is True
    assert isinstance(ansible_loader_0, Resolver) is True
    assert ansible_loader_0._stream == int_0

# Generated at 2022-06-25 04:33:17.746268
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    assert "Can't instantiate abstract class" in str(excinfo.value)

# Generated at 2022-06-25 04:33:24.734244
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -9366
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0 = AnsibleLoader(int_0)


# Generated at 2022-06-25 04:33:31.179170
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -3552
    ansible_loader_0 = AnsibleLoader(int_0)
# The definition of class AnsibleLoader was not found. Maybe you want to use ansible.parsing.yaml.Loader instead?

# Generated at 2022-06-25 04:33:36.329808
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Create an instance of class AnsibleLoader with arguments
    ansible_loader_0 = AnsibleLoader(0)
    if ansible_loader_0 is None:
        raise RuntimeError('Failed to create AnsibleLoader.')

    return



# Generated at 2022-06-25 04:33:38.973067
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_1 = -20514
    ansible_loader_1 = AnsibleLoader(int_1)
    ansible_loader_1.dispose()

if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:33:41.097393
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -2775
    ansible_loader_0 = AnsibleLoader(int_0)

# Generated at 2022-06-25 04:33:43.197739
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -12731
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0 = AnsibleLoader(int_0)

# Generated at 2022-06-25 04:33:43.948650
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:33:49.326624
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Example:
    # constructor_name = 'AnsibleLoader'
    # constructor_args = ['file_name', 'vault_secrets']
    # constructor_kwargs = {'stream': 'self.data', 'line': 'self.data'}
    pass

# Generated at 2022-06-25 04:33:57.576873
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -6392
    ansible_loader_0 = AnsibleLoader(int_0)
    int_0 = -6581
    ansible_loader_1 = AnsibleLoader(int_0)
    yaml_constructor_0 = AnsibleConstructor()
    assert isinstance(ansible_loader_1, (AnsibleLoader))
    assert isinstance(ansible_loader_0, (AnsibleLoader))
    assert isinstance(yaml_constructor_0, (AnsibleConstructor))


# Generated at 2022-06-25 04:33:59.237799
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print("Running test_AnsibleLoader")
    test_case_0()

# Generated at 2022-06-25 04:34:03.652780
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        test_case_0()
        print("test case 0 passed")
    except:
        print("test case 0 failed")

# Generated at 2022-06-25 04:34:09.181693
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert callable(AnsibleLoader)


# Generated at 2022-06-25 04:34:14.408636
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # create a file object to work with
    file_0 = open("./data/test_yaml", "r")

    # open up the file_0 and pass it to the AnsibleLoader class
    ansible_loader_0 = AnsibleLoader(file_0)

    # prints
    int_0 = ansible_loader_0.get_data() 

    print("<<<tests/unit/test_ansible_loader.py:34>>>")
    print(int_0)

# Generated at 2022-06-25 04:34:20.823363
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -3552
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0.get_single_data()
    ansible_loader_0.dispose()
    str_0 = "."
    ansible_loader_1 = AnsibleLoader(str_0)
    ansible_loader_1.get_single_data()
    ansible_loader_1.dispose()
    ansible_loader_2 = AnsibleLoader(str_0)
    ansible_loader_2.get_single_data()
    ansible_loader_2.dispose()

# Generated at 2022-06-25 04:34:26.443827
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # AnsibleLoader is mainly used in ansible/parsing/dataloader.py to load .yml files
    # stream = file or string, file_name = file or directory, vault_secrets = vault_secrets
    stream = open('test_ansible_loader')
    file_name = open('test_ansible_loader')
    vault_secrets = ""
    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)

# Generated at 2022-06-25 04:34:31.552051
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io

    # Redirect stdout.
    saved_stdout = sys.stdout
    result = io.StringIO()
    sys.stdout = result
    test_case_0()
    sys.stdout = saved_stdout


if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-25 04:34:39.211225
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -172
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0.set_output_keys()
    ansible_loader_0.get_single_data()
    ansible_loader_0.construct_object()
    ansible_loader_0.construct_mapping()
    ansible_loader_0.construct_yaml_int()
    ansible_loader_0.compose_node()
    ansible_loader_0.construct_yaml_map()
    ansible_loader_0.get_data()
    ansible_loader_0.construct_document()
    ansible_loader_0.construct_yaml_str()
    ansible_loader_0.construct_yaml_seq()
    ansible_loader_0.construct_yaml_

# Generated at 2022-06-25 04:34:43.094701
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -3552
    ansible_loader_0 = AnsibleLoader(int_0)
    int_1 = -3552
    ansible_loader_1 = AnsibleLoader(int_1)
    int_2 = -3552
    ansible_loader_2 = AnsibleLoader(int_2)
    int_3 = -3552
    ansible_loader_3 = AnsibleLoader(int_3)


# Generated at 2022-06-25 04:34:47.946668
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = 732
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0.load("0")
    ansible_loader_0.stream = "0"
    ansible_loader_0.anchor("0")
    ansible_loader_0.tag("0")
    ansible_loader_0.resolve("0")
    ansible_loader_0.resolve_node("0", "0")
    ansible_loader_0.resolve_node_or_scalar("0", "0")
    ansible_loader_0.handle_anchor("0", "0")
    ansible_loader_0.deserialize("0", "0")
    ansible_loader_0.construct_object("0", "0", "0", "0")
   

# Generated at 2022-06-25 04:34:50.195308
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert len(AnsibleLoader.__bases__) == 2
    int_0 = -65535
    ansible_loader_0 = AnsibleLoader(int_0)

# Generated at 2022-06-25 04:34:51.434376
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    read_0 = "Ansi"
    ansible_loader_0 = AnsibleLoader(read_0)

# Generated at 2022-06-25 04:35:01.311686
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """AnsibleLoader: test invalid input."""
    ansible_loader_0 = AnsibleLoader(0)
    ansible_loader_1 = AnsibleLoader("")
    ansible_loader_2 = AnsibleLoader("", "")
    ansible_loader_3 = AnsibleLoader("", "", "")
    ansible_loader_4 = AnsibleLoader(1.1)
    ansible_loader_5 = AnsibleLoader(1.1, 1.1)

# Generated at 2022-06-25 04:35:03.061038
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Exception raising test
    try:
        AnsibleLoader(-3552)
    except Exception:
        # Exception raised
        # assert(False)
        pass

# Generated at 2022-06-25 04:35:06.281056
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -18708
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_1 = AnsibleLoader(int_0)
    assert hash(ansible_loader_0) != hash(ansible_loader_1)


# Generated at 2022-06-25 04:35:12.221484
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test if AnsibleLoader as a constructor
    ansible_loader_0 = AnsibleLoader('/dev/null')
    assert type(ansible_loader_0) == AnsibleLoader

# Generated at 2022-06-25 04:35:17.298752
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -3668
    ansible_loader_0 = AnsibleLoader(int_0)


# Generated at 2022-06-25 04:35:23.851772
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    assert HAS_LIBYAML

    data = '''\
foo:
  - a
  - 1
  - 0
bar: 1
'''
    ansible_loader_0 = AnsibleLoader(data)
    ansible_loader_1 = AnsibleLoader(ansible_loader_0, None)
    ansible_loader_2 = AnsibleLoader(ansible_loader_1, None, None)
    ansible_loader_3 = AnsibleLoader(ansible_loader_2, ansible_loader_0, ansible_loader_1)

# Generated at 2022-06-25 04:35:33.473155
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = 0
    ansible_loader_0 = AnsibleLoader(int_0)
    int_1 = 3944
    ansible_loader_1 = AnsibleLoader(int_1)
    int_2 = 9897
    ansible_loader_2 = AnsibleLoader(int_2)
    int_3 = -9673
    ansible_loader_3 = AnsibleLoader(int_3)
    int_0 = -5085
    ansible_loader_0 = AnsibleLoader(int_0)
    int_1 = 3713
    ansible_loader_1 = AnsibleLoader(int_1)
    int_2 = -3374
    ansible_loader_2 = AnsibleLoader(int_2)
    int_3 = -9986

# Generated at 2022-06-25 04:35:37.233798
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert ansible_loader_0.vault_secrets == int_0
    assert ansible_loader_0.file_name == int_0
    assert ansible_loader_0.line == int_0
    assert ansible_loader_0.column == int_0
    assert ansible_loader_0.index == int_0
    assert ansible_loader_0.buffer == str_0


# Generated at 2022-06-25 04:35:37.810288
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(int)

# Generated at 2022-06-25 04:35:42.533778
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constuctor import ConstructorError
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleScalarString
    from ansible.parsing.yaml import AnsibleDumper
    ansible_loader_1 = AnsibleLoader(None, file_name="./test/unit/lib/ansible/modules/system/ping/__init__.py")
    print(type(ansible_loader_1))

# Generated at 2022-06-25 04:35:58.483067
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test with an integer
    int_0 = -3552
    ansible_loader_0 = AnsibleLoader(int_0)
    int_1 = 28596
    ansible_loader_0 = AnsibleLoader(int_1)

# Generated at 2022-06-25 04:36:02.561377
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(int)
    assert ansible_loader_0

#Unit test for add_implicit_resolver of class AnsibleLoader

# Generated at 2022-06-25 04:36:08.082566
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    ansible_loader_0 = AnsibleLoader(None)
    assert(ansible_loader_0.stream == None)
    assert(ansible_loader_0.name == '<unicode string>')
    assert(ansible_loader_0.vault_secrets == c)


# Generated at 2022-06-25 04:36:17.715488
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(1)
    # This is the case when there is no expect value
    assert ansible_loader_0.yaml_data == None
    ansible_loader_0 = AnsibleLoader(1, 2)
    # This is the case when there is no expect value
    assert ansible_loader_0.file_name == 2
    ansible_loader_0 = AnsibleLoader(1, 2, 3)
    # This is the case when there is no expect value
    assert ansible_loader_0.yaml_data == None
    # This is the case when there is no expect value
    assert ansible_loader_0.file_name == 2
    # This is the case when there is no expect value
    assert ansible_loader_0.vault_secrets == 3

# Unit test

# Generated at 2022-06-25 04:36:18.232826
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:36:27.298924
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        # USE CASE #0
        int_1 = -3552
        ansible_loader_0 = AnsibleLoader(int_1)
    except Exception as e:
        pass
    else:
        raise Exception("Expected exception but didn't get one")
    try:
        # USE CASE #1
        dict_0 = dict()
        dict_1 = dict()
        dict_2 = dict()
        dict_2['test_key_2'] = "test_value_2"
        dict_1["test_key_1"] = dict_2
        dict_0["test_key_0"] = dict_1
        ansi_string_0 = dict_0
        ansible_loader_3 = AnsibleLoader(ansi_string_0)
    except Exception as e:
        pass

# Generated at 2022-06-25 04:36:29.640786
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = 1383357665
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0.dispose()



# Generated at 2022-06-25 04:36:39.949569
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -3552
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0.descend_resolver()
    ansible_loader_0.compose_node(int_0, int_0, int_0)
    ansible_loader_0.add_constructor(int_0, int_0)
    ansible_loader_0.add_constructor(int_0, int_0)
    ansible_loader_0.add_constructor(int_0, int_0)
    ansible_loader_0.add_multi_constructor(int_0, int_0)
    ansible_loader_0.add_multi_constructor(int_0, int_0)

# Generated at 2022-06-25 04:36:47.043257
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test for constructor of class AnsibleLoader.
    # Initializes the parser, scanner and composer.
    test_case_0()


if __name__ == '__main__':
    # test_AnsibleLoader()
    ansible_loader_0 = AnsibleLoader(2926)

# Generated at 2022-06-25 04:36:52.735315
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = 0
    file_name = 'zRy8cgOZ'
    vault_secrets = 'mineral'
    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)
    assert ansible_loader.stream == 0
    assert ansible_loader.file_name == 'zRy8cgOZ'
    assert ansible_loader.vault_secrets == 'mineral'



# Generated at 2022-06-25 04:37:18.569427
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -9381
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0.__init__(int_0)

# Generated at 2022-06-25 04:37:19.517520
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -23464
    ansible_loader_0 = AnsibleLoader(int_0)

# Generated at 2022-06-25 04:37:28.854833
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test with vault password specified
    vault_password = 'secret'
    ansible_loader_0 = AnsibleLoader(input=None, file_name=None, vault_secrets=vault_password)
    assert(ansible_loader_0.vault_secrets == vault_password)

    # Test with vault password not specified
    ansible_loader_1 = AnsibleLoader(input=None, file_name=None, vault_secrets=None)
    assert(ansible_loader_1.vault_secrets is None)

# Generated at 2022-06-25 04:37:30.211619
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -3552
    ansible_loader_0 = AnsibleLoader(int_0)
#
# test_AnsibleLoader()
#

# Generated at 2022-06-25 04:37:35.006007
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    int_1 = -3552
    ansible_loader_1 = AnsibleLoader(int_1)

    int_2 = -3552
    ansible_loader_2 = AnsibleLoader(int_2)

    int_3 = -3552
    ansible_loader_3 = AnsibleLoader(int_3)

    ansible_loader_2.stream = ansible_loader_1.stream

    str_4 = 'P'
    ansible_loader_3.stream = str_4



# Generated at 2022-06-25 04:37:42.173854
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test an int
    int_0 = -3552
    ansible_loader_0 = AnsibleLoader(int_0)
    # Test a str
    str_0 = "ansible_loader"
    ansible_loader_1 = AnsibleLoader(str_0)
    # AssertionError: 6160 != 6160
    # Test an array
    array_0 = []
    ansible_loader_2 = AnsibleLoader(array_0)
    # AssertionError: 7632 != 7632
    # Test a dict
    dict_0 = {}
    ansible_loader_3 = AnsibleLoader(dict_0)
    # AssertionError: 6160 != 6160

# Generated at 2022-06-25 04:37:47.053479
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(None)
    ansible_loader_0.file_name = ''
    ansible_loader_0.vault_secrets = ''

# Generated at 2022-06-25 04:37:50.188598
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = 'stream'
    file_name = 'file_name'
    vault_secrets = 'vault_secrets'
    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:37:57.387427
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    int_0 = -3552
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0 = AnsibleLoader(int_0, None)

    assert isinstance(ansible_loader_0.constructor, AnsibleConstructor)
    assert isinstance(ansible_loader_0.resolver, Resolver)

# Generated at 2022-06-25 04:37:58.586923
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:39:05.591140
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.errors import AnsibleParserError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import PY3
    from ansible.utils.unicode import to_unicode

    yaml_test = '''
    ansible_variables:
      key1: value1
      key2:
        - list_entry1
        - list_entry2
        - list_entry3
      key3:
        dict_key: dict_value
    '''

    if PY3:
        unicode_type

# Generated at 2022-06-25 04:39:08.930406
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -630
    ansible_loader_0 = AnsibleLoader(int_0)

# run tests when called as a program
if __name__ == "__main__":
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:39:13.144789
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Call AnsibleLoader constructor
    ansible_loader_0 = AnsibleLoader(None)
    
    # Verify if the class of ansible_loader_0 is AnsibleLoader
    if not isinstance(ansible_loader_0, AnsibleLoader):
        print("Failed to create AnsibleLoader Object")
        return -1
    
if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 04:39:16.358473
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = 0
    ansible_loader_0 = AnsibleLoader(int_0)
    assert ansible_loader_0 is not None

# Generated at 2022-06-25 04:39:25.233369
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj_0 = AnsibleLoader(stream=None)
    obj_1 = AnsibleLoader(stream=None, file_name=None)
    obj_2 = AnsibleLoader(stream=None, vault_secrets=None)
    obj_3 = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    # Call AnsibleLoader class constructor
    assert isinstance(obj_0, AnsibleLoader) and isinstance(obj_1, AnsibleLoader) and isinstance(obj_2, AnsibleLoader) and isinstance(obj_3, AnsibleLoader)
    # Call AnsibleLoader class method scan
    obj_0.scan(stream=None)
    obj_1.scan(stream=None)
    obj_2.scan(stream=None)
    obj_3.scan(stream=None)


# Generated at 2022-06-25 04:39:34.932796
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(10, "jVa")
    assert ansible_loader_0.yaml_constructors == {'!include': ansible_loader_0.construct_include}
    assert ansible_loader_0.stream_start_event == {'encoding': None}
    assert ansible_loader_0.raw_scalar_style == True
    assert ansible_loader_0.reader_check_event == {'check': False, 'type': None}
    assert ansible_loader_0.base_url == "jVa"
    assert ansible_loader_0.reader_events == [{'encoding': None}]
    assert ansible_loader_0.vault_secrets == 10


# Generated at 2022-06-25 04:39:37.328554
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    arguments = list()
    retval = AnsibleLoader(*arguments)
    assert not isinstance(retval, AnsibleLoader)

# Generated at 2022-06-25 04:39:44.633268
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -14506
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0.construct_document()
    ansible_loader_0.construct_scalar(int_0)
    ansible_loader_0.construct_sequence(int_0)
    ansible_loader_0.construct_mapping(int_0)
    ansible_loader_0.construct_yaml_map(int_0)
    ansible_loader_0.construct_yaml_seq(int_0)
    ansible_loader_0.construct_yaml_str(int_0)
    ansible_loader_0.construct_yaml_null(int_0)
    ansible_loader_0.construct_yaml_bool(int_0)
    ansible_loader_

# Generated at 2022-06-25 04:39:50.178539
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = {
        'my_list': ['A', 'list', 'with', 'four', 'elements'],
        'my_dict': {
            'key': 'value',
            'key2': 'value2'
        },
        'my_float': 1.2345,
        'my_int': -23,
        'my_bool': True,
        'my_none': None,
        'my_unicode': u'unicode',
        'my_bytes': b'bytes',
        'my_complex': complex(1, 2),
        'my_set': set([1, 2, 3])
    }

    data_str = pprint.pformat(data)
    data_yaml = yaml.dump(data, default_flow_style=False)

    test_file_name = os.path

# Generated at 2022-06-25 04:39:53.154777
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    int_0 = -3552
    ansible_loader_0 = AnsibleLoader(int_0)
    ansible_loader_0.yaml_get_line = lambda: 35
    int_1 = ansible_loader_0.yaml_get_line()

# Generated at 2022-06-25 04:41:49.293546
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(int_0)

# Generated at 2022-06-25 04:41:49.811709
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-25 04:41:52.465500
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = 0
    ansible_loader_0 = AnsibleLoader(stream)
    stream = -34259
    ansible_loader_1 = AnsibleLoader(stream)
    stream = -937.4
    ansible_loader_2 = AnsibleLoader(stream)

if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:41:58.410631
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(0)

    # Test method load
    # Try all types of arguments
    ansible_loader_0.load(0)
    ansible_loader_0.load(-6545)
    ansible_loader_0.load(0)
    ansible_loader_0.load(0)
    ansible_loader_0.load(0)
    ansible_loader_0.load(0)
    ansible_loader_0.load(0)
    ansible_loader_0.load(0)
    ansible_loader_0.load(0)
    ansible_loader_0.load(0)
    ansible_loader_0.load('abc')

    # Test method get_single_data
    # Try all types of arguments

# Generated at 2022-06-25 04:42:01.720558
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    j0 = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    assert type(j0) == AnsibleLoader