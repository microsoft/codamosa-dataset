

# Generated at 2022-06-25 04:32:04.580501
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    input_0 = ansible_loader_0.get_single_data()
    assert input_0 is None


# Generated at 2022-06-25 04:32:11.844288
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.yaml import Parser

    bytes_0 = b'red\x00\x01'
    ansible_loader_0 = AnsibleLoader(bytes_0)

    status, key = ansible_loader_0.reader.check_token()
    assert key == b'red\x00\x01'
    assert status == Parser.construct_yaml_str(ansible_loader_0)

    key = ansible_loader_0.reader.peek_token()
    assert key == b'\x00\x01'

    key = ansible_loader_0.reader.get_token()

# Generated at 2022-06-25 04:32:20.770800
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Given arguments for AnsibleLoader: 'stream=[in_1]', 'file_name=[in_2]', and 'vault_secrets=[in_3]'
    where_1 = b'foo'
    where_2 = b'bar'
    where_3 = b'baz'
    in_2 = b'foo.yml'
    in_3 = b'bar.yml'
    bytes_1 = b'\xd9\x0f'
    bytes_2 = b'\x89\xf0'
    bytes_3 = b'\xd9\x0f'
    # When ansible_loader_1 instantiated as AnsibleLoader with arguments 'stream=[in_1]', 'file_name=[in_2]', and 'vault_secrets=[in_3]'
    ansible_loader_1

# Generated at 2022-06-25 04:32:22.746859
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)

# Generated at 2022-06-25 04:32:23.539174
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    argument = AnsibleLoader(bytes_0)

# Generated at 2022-06-25 04:32:24.878865
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)

# Generated at 2022-06-25 04:32:34.820374
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b'
    ansible_loader_0 = AnsibleLoader( bytes_0 )
   

# Generated at 2022-06-25 04:32:39.478248
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert isinstance (AnsibleLoader, type)
    assert hasattr (AnsibleLoader, '__init__')
    assert callable (AnsibleLoader.__init__)
    assert hasattr (AnsibleLoader, '__doc__')
    assert AnsibleLoader.__doc__

# Generated at 2022-06-25 04:32:41.918505
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)


if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-25 04:32:44.865270
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'^\xd1j\x07\xef\xa3\x83\xa9\x9c\xcd\xf2/\x0b'
    ansible_loader_0 = AnsibleLoader(bytes_0)

# Generated at 2022-06-25 04:32:58.132495
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\x0c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    dict_0 = ansible_loader_0.get_single_data()
    assert isinstance(dict_0, dict)
    assert dict_0.get("@b64".encode("utf-8")) == "\x00".encode("utf-8")

    ansible_loader_0 = AnsibleLoader("\x7f\x00".encode("utf-8"))
    list_0 = ansible_loader_0.get_single_data()

# Generated at 2022-06-25 04:33:08.800542
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Create an instance of class AnsibleLoader with stream=bytes_0
    ansible_loader_0 = AnsibleLoader(bytes_0)

    # Check instance attributes
    assert ansible_loader_0.stream == bytes_0
    assert ansible_loader_0.name == '<unicode string>'
    assert ansible_loader_0.vault_secrets == None

    # Check instance methods
    ansible_loader_0.dispose()
    ansible_loader_0.check_event(None)
    ansible_loader_0.peek_event()
    ansible_loader_0.get_event()
    ansible_loader_0.check_node()
    ansible_loader_0.get_node()
    ansible_loader_0.compose_document()

# Generated at 2022-06-25 04:33:10.920878
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    s = 'AnsibleLoader'
    assert s == 'AnsibleLoader'


# Generated at 2022-06-25 04:33:13.110960
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test for constructor
    obj = AnsibleLoader(None)
    assert isinstance(obj, AnsibleLoader)


# Generated at 2022-06-25 04:33:20.603494
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    bytes_1 = b'\x00'
    ansible_loader_1 = AnsibleLoader(bytes_1)
    bytes_2 = b'\x00'
    ansible_loader_2 = AnsibleLoader(bytes_2)
    bytes_3 = b'\x00'
    ansible_loader_3 = AnsibleLoader(bytes_3)
    bytes_4 = b'\x00'
    ansible_loader_4 = AnsibleLoader(bytes_4)
    bytes_5 = b'\x00'
    ansible_loader_5 = AnsibleLoader(bytes_5)
    bytes_6 = b'\x00'
    ansible_loader_6 = Ans

# Generated at 2022-06-25 04:33:22.699503
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test for method __init__(self, stream, file_name=None, vault_secrets=None)
    test_case_0()

# Generated at 2022-06-25 04:33:33.036194
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = 'test string'
    # test for 'yaml.composer.Composer'
    ansible_loader = AnsibleLoader(data)
    # test for 'yaml.reader.Reader'
    ansible_loader.peek()
    ansible_loader.prefix(6)
    ansible_loader.forward(6)
    ansible_loader.get_mark()
    # test for 'yaml.scanner.Scanner'
    ansible_loader.check_token()
    ansible_loader.peek_token()
    ansible_loader.get_token()
    # test for 'yaml.parser.Parser'
    ansible_loader.check_event(None)
    ansible_loader.peek_event()
    ansible_loader.get_event()
    # test for 'yaml

# Generated at 2022-06-25 04:33:35.093012
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert ansible_loader_0 is not None
    assert ansible_loader_0.file_name is None
    assert ansible_loader_0.vault_secrets is None
    assert ansible_loader_0.stream is bytes_0

# Generated at 2022-06-25 04:33:38.579036
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        with open('my_file.yaml', 'r') as f:
            bytes_0 = f.read()
        ansible_loader_0 = AnsibleLoader(bytes_0)
        ansible_loader_0.get_single_data()
        ansible_loader_0.get_single_data()
    except:
        pass


# Generated at 2022-06-25 04:33:45.219061
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser
    from yaml.composer import Composer
    from yaml.resolver import Resolver
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    a1 = AnsibleLoader(['a'])
    a2 = Reader(['a'])
    a3 = Scanner()
    a4 = Parser()  # pylint: disable=no-value-for-parameter
    a5 = Composer()
    a6 = Resolver()
    a7 = AnsibleConstructor()

    assert a1.stream == ['a']
    assert a2.stream == ['a']
    assert a1.reader == a2
    assert a1.scanner == a3
   

# Generated at 2022-06-25 04:33:58.495042
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'AnsibleLoader'
    file_name_0 = 'AnsibleLoader'
    vault_secrets_0 = 'AnsibleLoader'
    ansible_loader_0 = AnsibleLoader(str_0, file_name_0, vault_secrets_0)
    str_1 = 'AnsibleLoader'
    ansible_loader_0 = AnsibleLoader(str_1)
    str_2 = 'AnsibleLoader'
    file_name_1 = 'AnsibleLoader'
    ansible_loader_0 = AnsibleLoader(str_2, file_name_1)
    ansible_loader_0 = AnsibleLoader(str_2)


# Generated at 2022-06-25 04:34:05.580663
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Constructor with arguments
    try:
        test_AnsibleLoader_0 = AnsibleLoader('stream', 'file_name=None', 'vault_secrets=None')
    except Exception as err:
        assert()


# Generated at 2022-06-25 04:34:14.251779
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #Testing the case
    str_0 = 'AnsibleLoader'
    stream = str_0
    file_name = str_0
    vault_secrets = str_0
    ansible_loader = AnsibleLoader(stream=stream, file_name=file_name, vault_secrets=vault_secrets)
    #Testing the case
    str_0 = 'AnsibleLoader'
    stream = str_0
    file_name = str_0
    vault_secrets = str_0
    ansible_loader = AnsibleLoader(stream=stream, file_name=file_name, vault_secrets=vault_secrets)

# Generated at 2022-06-25 04:34:18.210840
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'AnsibleLoader'
    file_name_0 = 'AnsibleLoader'
    vault_secrets_0 = 'AnsibleLoader'
    ansible_loader_0 = AnsibleLoader(str_0, file_name_0, vault_secrets_0)

# Generated at 2022-06-25 04:34:26.683123
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # int str list dict
    str_0 = 'AnsibleLoader'
    # str_0 -> stream

    # int str list dict
    str_1 = 'AnsibleLoader'
    # str_1 -> file_name

    # int str list dict
    str_2 = 'AnsibleLoader'
    # str_2 -> stream

    # str_2 -> vault_secrets


    # Tests for AnsibleConstructor
    # int str list dict
    str_3 = 'AnsibleConstructor'
    # str_3 -> file_name

    # str_2 -> vault_secrets

    # Tests for Resolver
    # int str list dict
    str_4 = 'Resolver'

# Generated at 2022-06-25 04:34:27.556119
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:34:31.230872
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'AnsibleLoader'
    obj_0 = AnsibleLoader(str_0)
    assert_equal(obj_0.file_name, None)
    assert_equal(obj_0.vault_secrets, None)

# Generated at 2022-06-25 04:34:35.030323
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'AnsibleLoader'
    stream_0 = str_0
    file_name_0 = str_0
    vault_secrets_0 = str_0
    ansibleloader_0 = AnsibleLoader(stream_0, file_name_0, vault_secrets_0)
    ansibleloader_0.load()

# Generated at 2022-06-25 04:34:42.172442
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    src = """
a: 1
b: 2
c:
  - 3
  - 4
"""
    ansible_loader = AnsibleLoader(src, vault_secrets=[])
    data0 = ansible_loader.get_single_data()

    assert data0['a'] == 1
    assert data0['b'] == 2
    assert data0['c'] == [3, 4]

    src = """
a: 1
b:
  c: 2
  d: 3
"""
    ansible_loader = AnsibleLoader(src, vault_secrets=[])
    data1 = ansible_loader.get_single_data()

    assert data1['a'] == 1
    assert data1['b'] == {'c': 2, 'd': 3}


# Generated at 2022-06-25 04:34:47.488316
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Create an instance of AnsibleLoader
    # ansible_loader_instance = AnsibleLoader()
    pass

if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:34:55.438468
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)

# Mock of method AnsibleLoader.dispose for tests

# Generated at 2022-06-25 04:35:02.951549
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # testing default constructor
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert (isinstance(ansible_loader_0, AnsibleLoader))

    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert (isinstance(ansible_loader_0, AnsibleLoader))

# Generated at 2022-06-25 04:35:09.814794
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test with valid input
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)

    # Test that constructor raises exception with invalid input
    try:
        bytes_1 = '\xd9\x0f'
        ansible_loader_1 = AnsibleLoader(bytes_1)
        assert False, "AnsibleLoader() constructor should raise error with non-bytes input"
    except TypeError:
        assert True
    except Exception as e:
        assert False, "AnsibleLoader() constructor raised unexpected error with non-bytes input: " + repr(e)

# Generated at 2022-06-25 04:35:10.952306
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml = AnsibleLoader(b'{ foo: bar }')
    data = yaml.get_data()
    assert data == {"foo": "bar"}

# Generated at 2022-06-25 04:35:21.985082
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser
    from yaml.composer import Composer
    from yaml.constructor import BaseConstructor
    from yaml.resolver import Resolver
    stream = b'\xd9\x0f'

    ansible_loader_0 = AnsibleLoader(stream)
    assert ansible_loader_0.__class__ == AnsibleLoader
    assert Reader.__init__(ansible_loader_0, stream) == None
    assert Scanner.__init__(ansible_loader_0) == None
    assert Parser.__init__(ansible_loader_0) == None
    assert Composer.__init__(ansible_loader_0) == None

# Generated at 2022-06-25 04:35:30.939968
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xdf\x16'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    ansible_loader_0.stream = bytes_0
    ansible_loader_0.line_col = (0, 0)
    ansible_loader_0.line_indent = [0, 0, 0]
    ansible_loader_0.line_comment = ['', '', '', '', '', '', '', '', '', '']
    ansible_loader_0.line_exp_indent = 0

# Generated at 2022-06-25 04:35:31.472742
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert callable(AnsibleLoader)

# Generated at 2022-06-25 04:35:38.528458
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    ansible_loader_0 = AnsibleLoader(None)
    assert(ansible_loader_0.file_name is None)
    assert(ansible_loader_0.vault_secrets is None)

    ansible_loader_0 = AnsibleLoader(None, file_name="file_name", vault_secrets=None)
    assert(ansible_loader_0.file_name == "file_name")
    assert(ansible_loader_0.vault_secrets is None)

    ansible_loader_0 = AnsibleLoader(None, file_name="file_name", vault_secrets=None)
    assert(ansible_loader_0.file_name == "file_name")
    assert(ansible_loader_0.vault_secrets is None)

    ansible_loader_0 = Ansible

# Generated at 2022-06-25 04:35:39.668361
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)

# Generated at 2022-06-25 04:35:46.545101
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = b'\x0123\x12'
    file_name = 'test'
    vault_secrets = '12345'
    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)

# Generated at 2022-06-25 04:35:54.673716
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# vim: set expandtab tabstop=4 softtabstop=4 shiftwidth=4:

# Generated at 2022-06-25 04:36:03.651339
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Bypass __init__ method of AnsibleLoader
    ansible_loader_0 = AnsibleLoader.__base__.__init__

    # Bypass __init__ method of AnsibleConstructor
    ansible_constructor_0 = AnsibleConstructor.__base__.__init__

    # Bypass __init__ method of Resolver
    resolver_0 = Resolver.__base__.__init__

    vault_secrets_0 = dict()
    vault_secrets_0['asdf'] = 'ghjk'
    vault_secrets_0['qwerty'] = '1234'
    vault_secrets_0['zxcv'] = '5678'
    file_name_0 = 'vault.yml'

# Generated at 2022-06-25 04:36:13.256203
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:36:15.315806
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    AnsibleLoader test case.
    """
    test_case_0()
    print("AnsibleLoader test case passed!")

# Execute
test_AnsibleLoader()

# Generated at 2022-06-25 04:36:18.270770
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = AnsibleLoader()
    assert stream.__class__ is AnsibleLoader

# Generated at 2022-06-25 04:36:27.296393
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    bytes_1 = b'\xd9\x0f'
    bytes_2 = b'\xd9\x0f'
    bytes_3 = b'\xd9\x0f'
    bytes_4 = b'\xd9\x0f'
    bytes_5 = b'd9'
    bytes_6 = b'd9'
    bytes_7 = b'd9'
    bytes_8 = b'd9'
    bytes_9 = b'd9'
    bytes_10 = b'd9'
    bytes_11 = b'd9'
    bytes_12 = b'\xd9\x0f'
    bytes_13 = b'\xd9\x0f'
    bytes_14 = b'\xd9\x0f'
   

# Generated at 2022-06-25 04:36:30.498513
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'?\xed\x90\x00\x13'
    file_name_0 = '&P[oGnS\x1a'
    ansible_loader_0 = AnsibleLoader(bytes_0, file_name_0)


# Generated at 2022-06-25 04:36:33.961779
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    with open('test/test.yaml') as f:
        bytes_0 = f.read()
        ansible_loader_0 = AnsibleLoader(bytes_0)
        ansible_loader_0_result = ansible_loader_0.get_single_data()
        assert(ansible_loader_0_result == "ok")

# Generated at 2022-06-25 04:36:42.631340
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    bytes_1 = b'\x13\xce\xcc\x0f\xe8\xb3'
    ansible_loader_1 = AnsibleLoader(bytes_1)
    bytes_2 = b'\xe9\xef\x81\xf6\x8c\x82'
    ansible_loader_2 = AnsibleLoader(bytes_2)
    bytes_3 = b'\x8e\xec\x84\xed\x06\x0a'
    ansible_loader_3 = AnsibleLoader(bytes_3)
    bytes_4 = b'\xf1\xdb\x0a\x0f\x12\x14'
   

# Generated at 2022-06-25 04:36:49.431982
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    ansible_loader_1 = AnsibleLoader(bytes_0)

    try:
        assert ansible_loader_0.file_name is None
    except AssertionError:
        pass

    try:
        assert ansible_loader_1.file_name is None
    except AssertionError:
        pass

# Generated at 2022-06-25 04:37:10.118817
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert isinstance(ansible_loader_0._document, list) == False
    assert ansible_loader_0._curr_event is None
    assert isinstance(ansible_loader_0._file_name, str) == False
    assert isinstance(ansible_loader_0._resolver, AnsibleLoader) == True
    assert isinstance(ansible_loader_0._vault_secrets, dict) == False
    assert isinstance(ansible_loader_0._yaml_constructor_loader, AnsibleConstructor) == True
    assert isinstance(ansible_loader_0._yaml_loader, AnsibleLoader) == True

# Generated at 2022-06-25 04:37:14.307817
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test with default constructor
    ansible_loader_0 = AnsibleLoader(b'\xd9\x0f')



# Generated at 2022-06-25 04:37:20.678834
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_3 = b'\x88m\x80g\xa5version\xa17.1\x83'
    file_name_0 = 'a'
    ansible_loader_0 = AnsibleLoader(bytes_3, file_name_0)
    pass


# Generated at 2022-06-25 04:37:25.599557
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  ansible_loader = AnsibleLoader()
  ansible_loader.__init__(stream, file_name=None, vault_secrets=None)

# Generated at 2022-06-25 04:37:30.919005
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    ansible_loader_0.pop()

    # AnsibleLoader.__init__():
    # Now AnsibleLoader._items is a list
    # assert type(ansible_loader_0._items) == list

    # AnsibleLoader.get_single_data()
    ansible_loader_0._items = []
    ansible_loader_0._items = [{'azure_rm': {'auth_source': 'environment'}}, '\n']
    ansible_loader_0.get_single_data()

# Generated at 2022-06-25 04:37:41.006928
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert ansible_loader_0.yaml_add_constructor('!ref', AnsibleLoader.add_yaml_multi_constructor, Loader=AnsibleLoader) == None
    assert ansible_loader_0.yaml_add_constructor('!ref-1', AnsibleLoader.add_yaml_multi_constructor, Loader=AnsibleLoader) == None
    assert ansible_loader_0.yaml_add_constructor('!ref-2', AnsibleLoader.add_yaml_multi_constructor, Loader=AnsibleLoader) == None

# Generated at 2022-06-25 04:37:41.770811
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True == True


# Generated at 2022-06-25 04:37:47.317230
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x01'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert ansible_loader_0.get_single_data() == (b'\x00\x00\x00\x00\x00\x00\x00\x00', {'tag': 'tag:yaml.org,2002:str', 'value': '\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000'})


# Generated at 2022-06-25 04:37:50.463375
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(stream)
    assert not hasattr(ansible_loader_0, 'file_name')
    assert not hasattr(ansible_loader_0, 'vault_secrets')


# Generated at 2022-06-25 04:37:52.938414
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert(AnsibleLoader)
    pass  # commented out as can't pass argument to AnsibleLoader

# Generated at 2022-06-25 04:38:27.827839
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:38:36.531949
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:38:39.706139
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    case_0 = AnsibleLoader()
    case_1 = AnsibleLoader(bytes_0)
    case_2 = AnsibleLoader(bytes_0, file_name=True)
    case_3 = AnsibleLoader(bytes_0, file_name=True, vault_secrets=test_case_0)


# Generated at 2022-06-25 04:38:41.230890
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)


# Generated at 2022-06-25 04:38:46.107519
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print('\nConstructor test: ')
    stream = bytes([0x99, 0xaa])
    file_name = __file__
    vault_secrets = {'key': 'secret'}
    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)
    ansible_loader_0.dispose()

# Generated at 2022-06-25 04:38:51.063581
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test with illegal encoded bytes.
    with pytest.raises(AttributeError):
        test_case_0()

# Generated at 2022-06-25 04:39:01.373157
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    ansible_loader_0.width = 0
    ansible_loader_0.width = 0
    ansible_loader_0.marks = None
    ansible_loader_0.index = 0
    ansible_loader_0.index = 0
    ansible_loader_0.line = 0
    ansible_loader_0.line = 0
    ansible_loader_0.stream = None
    ansible_loader_0.stream = None
    ansible_loader_0.name = None
    ansible_loader_0.name = None
    ansible_loader_0.opened = None
    ansible_loader_0.opened = None
    ansible_loader_0.anchors

# Generated at 2022-06-25 04:39:02.459831
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd8\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)

# Generated at 2022-06-25 04:39:08.623884
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test values from yaml/loader.py
    bytes_1 = b'\xd9\x0f'
    ansible_loader_1 = AnsibleLoader(bytes_1)
    ansible_loader_1.__init__(bytes_1)


# Generated at 2022-06-25 04:39:16.355259
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:40:14.900339
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    bytes_1 = b'\xd9\x0f'
    bytes_2 = b'\xd9\x0f'
    bytes_3 = b'\xd9\x0f'
    bytes_4 = b'\xd9\x0f'
    bytes_5 = b'\xd9\x0f'
    bytes_6 = b'\xd9\x0f'
    bytes_7 = b'\xd9\x0f'
    bytes_8 = b'\xd9\x0f'
    bytes_9 = b'\xd9\x0f'
    bytes_10 = b'\xd9\x0f'
    bytes_11 = b'\xd9\x0f'
    ansible_loader_0

# Generated at 2022-06-25 04:40:15.629434
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:40:21.166569
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert ansible_loader_0 is not None
    assert isinstance(ansible_loader_0, AnsibleLoader)



# Generated at 2022-06-25 04:40:31.399447
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:40:40.217452
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    # Test if file_name is set correctly
    assert ansible_loader_0.file_name == None
    # Test if vault_secrets is set correctly
    assert ansible_loader_0.vault_secrets == None
    assert bytes_0 == b'\xd9\x0f'
    bytes_1 = b'\x69\x70\x5f\x66\x69\x6c\x65\x73_6'
    ansible_loader_1 = AnsibleLoader(bytes_1)
    # Test if file_name is set correctly
    assert ansible_loader_1.file_name == None
    # Test if vault_secrets is set correctly

# Generated at 2022-06-25 04:40:45.166306
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    input_0 = 'cj#Y'
    ansible_loader_0 = AnsibleLoader(input_0)
    assert ansible_loader_0.path[0] is None

if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:40:50.046836
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    ansible_loader_0.batch_reset()

# Generated at 2022-06-25 04:40:56.457110
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # This class is not a test case, because it's a utility class for
    # yaml parsing.
    return
    # Test case for no arguments
    ansible_loader_0 = AnsibleLoader()
    assert ansible_loader_0.get_single_data() == []

    # Test case for just stream
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert ansible_loader_0.get_single_data() == [b'\xd9\x0f']

    # Test case for stream, file_name and vault_secrets
    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert ansible_loader_0.get_single_data

# Generated at 2022-06-25 04:41:06.266015
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    FAKE_MODULE = "mymodule"
    FAKE_PATH = "./mymodule"

    bytes_0 = b'\xd9\x0f'
    ansible_loader_0 = AnsibleLoader(bytes_0)

    # Test with vault encrypted file

# Generated at 2022-06-25 04:41:17.582952
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    for index in range(4):
        if index == 0:
            bytes_0 = b'\xd9\x0f'
            ansible_loader_0 = AnsibleLoader(bytes_0, None)
            bytes_1 = ansible_loader_0.stream
            assert bytes_1 == bytes_0
            ansible_constructor_0 = ansible_loader_0.constructor
            ansible_constructor_1 = ansible_loader_0.constructor
            assert ansible_constructor_0 == ansible_constructor_1
            ansible_loader_1 = AnsibleLoader(bytes_0, str())
            bytes_2 = ansible_loader_1.stream
            assert bytes_2 == bytes_0
            ansible_loader_2 = AnsibleLoader(bytes_0)
            bytes_3 = ansible_