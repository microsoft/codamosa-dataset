

# Generated at 2022-06-25 04:32:03.851927
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)

# Generated at 2022-06-25 04:32:06.034162
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)


# Generated at 2022-06-25 04:32:10.708359
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '\x00\x00'
    ansible_loader_0 = AnsibleLoader(str_0)

    # Tests the AnsibleConstructor constructor
    assert ansible_loader_0.file_name == None
    assert ansible_loader_0.vault_secrets == None

    ansible_loader_1 = AnsibleLoader(str_0, file_name='test')
    assert ansible_loader_1.file_name == 'test'
    assert ansible_loader_0.vault_secrets == None

# Generated at 2022-06-25 04:32:16.817419
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        test_case_0()
    except Exception as err:
        print("Test Failed - ERROR Message:" + str(err))
    else:
        print("Test Passed")
        
# Collect all test cases in this class
test_list = [test_AnsibleLoader]


# Generated at 2022-06-25 04:32:20.973951
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert test_case_0() == 0

# Generated at 2022-06-25 04:32:21.478778
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-25 04:32:26.174989
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:32:30.762335
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader('tB&!P(|*_\u4fc4\u4c60s]')
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_1 = AnsibleLoader(str_0)

# Generated at 2022-06-25 04:32:37.456051
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream_0 = '<string>'
    file_name_0 = '<string>'
    vault_secrets_0 = '<string>'

    ansible_loader_0 = AnsibleLoader(stream_0, file_name_0, vault_secrets_0)

    assert ansible_loader_0.stream == stream_0
    assert ansible_loader_0.file_name == file_name_0
    assert ansible_loader_0.vault_secrets == vault_secrets_0




# Generated at 2022-06-25 04:32:45.712343
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = "3]|-%TGx;fM=_Q{$"
    file_name = "test.yaml"
    vault_secrets = None
    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)
    ansible_loader_0.get_data()
    ansible_loader_0.stream = "ZWPz&"
    ansible_loader_0.get_data()
    ansible_loader_0.stream = "o/P_$"
    ansible_loader_0.get_data()
    ansible_loader_0.stream = "3]|-%TGx;fM=_Q{$"
    ansible_loader_0.get_data()


# Generated at 2022-06-25 04:32:55.381088
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'w|%c1By~S6E0<-_F{6'
    ansible_loader_0 = AnsibleLoader(str_0)
    str_1 = 'p?bF{sTfE:.)+}'
    ansible_loader_1 = AnsibleLoader(str_1)
    str_2 = 'oUm]z!Z_R&)1}'
    ansible_loader_2 = AnsibleLoader(str_2)
    str_3 = 'Q0m0+!_o/?9!4}'
    ansible_loader_3 = AnsibleLoader(str_3)
    str_4 = '#vIY+6_4U6!<$w}'
    ansible_loader_4 = AnsibleLoader(str_4)
    str_5

# Generated at 2022-06-25 04:33:03.391538
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test with stream_0
    stream_0 = "3]|-%TGx;fM=_Q{$"
    ansible_loader_0 = AnsibleLoader(stream_0)
    assert ansible_loader_0.stream == stream_0

    # Test with stream_1
    stream_1 = "lBKs_sP|#!b,T&wWm(U"
    ansible_loader_1 = AnsibleLoader(stream_1)
    assert ansible_loader_1.stream == stream_1

    # Test with stream_2
    stream_2 = "`z{)l,2_7PIq%H8uA7"
    ansible_loader_2 = AnsibleLoader(stream_2)
    assert ansible_loader_2.stream == stream_2

    # Test with

# Generated at 2022-06-25 04:33:14.025475
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Creation of instance AnsibleConstructor
    assert isinstance(AnsibleConstructor(), AnsibleConstructor) , "Should be able to create an instance of class AnsibleConstructor"

    # Creation of instance Resolver
    assert isinstance(Resolver(), AnsibleConstructor) , "Should be able to create an instance of class Resolver"

    # Creation of instance AnsibleLoader
    test_case_0()
    assert isinstance(AnsibleLoader(str), AnsibleLoader) , "Should be able to create an instance of class AnsibleLoader"

    # Creation of instance Reader
    assert isinstance(Reader(str), Reader) , "Should be able to create an instance of class Reader"

    # Creation of instance Scanner
    assert isinstance(Scanner(str), Scanner) , "Should be able to create an instance of class Scanner"

    # Creation

# Generated at 2022-06-25 04:33:22.932316
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)

    # Test __init__ method in class 'AnsibleLoader'
    assert not hasattr(ansible_loader_0, '_AnsibleLoader__file_name')
    assert not hasattr(ansible_loader_0, '_AnsibleLoader__vault_secrets')

    # Test 'file_name' attribute in class 'AnsibleLoader'
    assert ansible_loader_0.file_name is None

    # Test 'vault_secrets' attribute in class 'AnsibleLoader'
    assert ansible_loader_0.vault_secrets is None


# Generated at 2022-06-25 04:33:30.317078
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '<TfT{Wt'
    str_1 = 'o4>n4'
    str_2 = 'Z'
    str_3 = '#c%B_='
    str_4 = '$^:.8@'
    str_5 = 'p*i'
    str_6 = 'L)'
    str_7 = 'b5@9o5'
    str_8 = '#'
    str_9 = '$~e'
    str_10 = 'X9pHc%'
    str_11 = 'v'
    str_12 = '4+!'
    str_13 = 'Q'
    str_14 = 'q'
    str_15 = 'W'
    str_16 = 't@`'
    str_17 = '#'
   

# Generated at 2022-06-25 04:33:37.660086
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    vault_secrets_0 = {}
    ansible_loader_0 = AnsibleLoader(str_0, vault_secrets=vault_secrets_0)
    ansible_loader_1 = AnsibleLoader(str_0)


if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:33:40.940673
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(str_0)
    assert ansible_loader_0 is not None

# Generated at 2022-06-25 04:33:49.460639
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str = '3]|-%TGx;fM=_Q{$'
    ansible_loader = AnsibleLoader(str)
    # print("ansible_loader.construct_mapping: ", ansible_loader.construct_mapping(None))
    print("ansible_loader.construct_sequence: ", ansible_loader.construct_sequence(None))
    # print("ansible_loader.construct_sequence: ", ansible_loader.construct_sequence(None))
    # print("ansible_loader.construct_yaml_seq: ", ansible_loader.construct_yaml_seq(None))
    # print("ansible_loader.construct_yaml_str: ", ansible_loader.construct_yaml_str(None))
    # print("ansible_loader.construct_yaml_mapping: ", ansible_loader

# Generated at 2022-06-25 04:33:53.525986
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)

# Generated at 2022-06-25 04:34:02.846055
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #str_0 = '3]|-%TGx;fM=_Q{$'
    str_0 = """\
- hosts: all
  gather_facts: False
  tasks:
  - name: Test with_items with_subelements
    debug:
      msg: "{{ item }}"
    with_items:
    - "{{ lookup('file', '../arista_vlans.txt') }}"
    with_subelements:
    - "{{ lookup('file', '../arista_vlans.txt') }}"
    - vlan
    when: item.vlan != 888\
"""
    ansible_loader_0 = AnsibleLoader(str_0)
    str_1 = ansible_loader_0.get_single_data()
    print(str_1)

# Generated at 2022-06-25 04:34:10.673482
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    def try_close():
        try:
            ansible_loader_0.close()
        except:
            pass
        print("pass")
    try_close()

# Generated at 2022-06-25 04:34:17.572039
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)
    str_0.decode('utf-8')
    str_0.encode('utf-8')
    str_0.startswith('3]|-%TGx;fM=_Q{$')
    str_0.endswith('3]|-%TGx;fM=_Q{$')
    str_0.split('3]|-%TGx;fM=_Q{$')
    str_0.__str__()
    str_0.__repr__()

# Generated at 2022-06-25 04:34:20.934671
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    try:
        str_0 = '3]|-%TGx;fM=_Q{$'
        ansible_loader_0 = AnsibleLoader(str_0)
    except Exception as inst:
        print('Exception in test_AnsibleLoader(). xfail for now')
        

if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:34:23.554847
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Test for method __init__ with default paramaters
    ansible_loader_0 = AnsibleLoader()
    ansible_loader_0.__init__()
    assert True

# Generated at 2022-06-25 04:34:24.199015
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-25 04:34:30.191754
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)
    if HAS_LIBYAML:
        str_1 = '=O-%s+_x(x\x11f^\xa2'
    else:
        str_1 = '=O-%s+_x(x\x11f^'
    ansible_loader_1 = AnsibleLoader(str_1)


# Generated at 2022-06-25 04:34:32.330871
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:34:39.983327
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    
    # Call constructor of AnsibleLoader with stream='3]|-%TGx;fM=_Q{$' and vault_secrets=None
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~
# ~~~ Closing tests
# ~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


if __name__ == '__main__':
    import os
    import pytest
    from ansible.module_utils._text import to_bytes

    fd, path = tempfile.mkstemp()

# Generated at 2022-06-25 04:34:42.981348
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)

if __name__ == '__main__':
    test_case_0()

    # Unit test for constructor of class AnsibleLoader
    test_AnsibleLoader()

# Generated at 2022-06-25 04:34:45.180044
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_1 = '@QTO;(%c?H/KZ'
    ansible_loader_1 = AnsibleLoader(str_1)


# Generated at 2022-06-25 04:34:57.004511
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader('3]|-%TGx;fM=_Q{$')

# Make sure that the 'self' argument is not used in the signature of class AnsibleLoader

# Generated at 2022-06-25 04:35:00.006594
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)

    assert ansible_loader_0.get_single_data() == '3]|-%TGx;fM=_Q{$'



# Generated at 2022-06-25 04:35:04.237253
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    file_name_0 = 'yq.Ck2JV<r'
    # sansible_loader_0 = AnsibleLoader(str_0, file_name_0)
    # ansible_loader_1 = AnsibleLoader(str_0)



# Generated at 2022-06-25 04:35:05.936407
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()


if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-25 04:35:13.190575
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    vault_secrets_0 = ['DEFAULT','list of vault secrets']
    ansible_loader_0 = AnsibleLoader(str_0, vault_secrets=vault_secrets_0)
    assert ansible_loader_0._file_name is None
    assert ansible_loader_0._vault_secrets == ['DEFAULT','list of vault secrets']

    str_1 = '3]|-%TGx;fM=_Q{$'
    file_name_0 = os.path.join(os.path.expanduser('~'), '.ansible/tmp')
    vault_secrets_1 = ['DEFAULT','list of vault secrets']

# Generated at 2022-06-25 04:35:17.951193
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data_0 = 'kISSk1 bDy'
    ansible_loader_0 = AnsibleLoader(data_0)


# Generated at 2022-06-25 04:35:25.987991
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '+'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_1 = AnsibleLoader(str_0)
    ansible_loader_2 = AnsibleLoader(str_0)
    ansible_loader_3 = AnsibleLoader(str_0)
    ansible_loader_4 = AnsibleLoader(str_0)
    ansible_loader_5 = AnsibleLoader(str_0)
    ansible_loader_6 = AnsibleLoader(str_0)
    ansible_loader_7 = AnsibleLoader(str_0)
    ansible_loader_8 = AnsibleLoader(str_0)
    ansible_loader_9 = AnsibleLoader(str_0)
    ansible_loader_10 = AnsibleLoader(str_0)
    ansible

# Generated at 2022-06-25 04:35:34.331395
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'xgZ"~1E'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_0.reader
    ansible_loader_0.scanner
    ansible_loader_0.parser
    ansible_loader_0.composer
    ansible_loader_0.construct_document
    ansible_loader_0.construct_mapping
    ansible_loader_0.construct_yaml_map
    ansible_loader_0.construct_yaml_str
    ansible_loader_0.construct_yaml_seq
    ansible_loader_0.construct_yaml_set
    ansible_loader_0.construct_yaml_int
    ansible_loader_0.construct_yaml_float
    ansible_loader_0.construct

# Generated at 2022-06-25 04:35:44.753407
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)

    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)

    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)

    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)

    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)

# Generated at 2022-06-25 04:35:46.873059
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)

# Generated at 2022-06-25 04:36:07.858173
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print('Test constructor')
    try:
        test_case_0()
    except Exception as e:
        print('Exception:', e)
        exit(1)
    else:
        print('No exception raised')



# Generated at 2022-06-25 04:36:17.085798
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    fout = open('/tmp/ansible-test-results.yml', 'w')
    fout.write('[')
    counter = 0
    test_cases = [
        ['0', '3]|-%TGx;fM=_Q{$'],
        ['1', '''Pyw}Ib:PH2-yBF~U6`lx6[9B6_jv|M@Rf8G;*w''']
    ]
    for test_case in test_cases:
        str_num = test_case[0]
        str = test_case[1]
        ansible_loader_0 = AnsibleLoader(str)
        fout.write(str(ansible_loader_0))
        fout.write(',')


    fout.write(']')
    f

# Generated at 2022-06-25 04:36:18.530932
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)


# Generated at 2022-06-25 04:36:22.750612
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = 'GJbN-SGhZ'
    with pytest.raises(AttributeError) as excinfo:
        ansible_loader_1 = AnsibleLoader(stream)

# Generated at 2022-06-25 04:36:31.945086
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '/-tao(aV`$=yG^uBM7'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_0.instance = ansible_loader_0
    ansible_loader_0.instance.substitution_defs = {}
    ansible_loader_0.instance.substitution_defs['octal'] = {}
    ansible_loader_0.instance.substitution_defs['octal']['pattern'] = '0[0-7_]+'
    ansible_loader_0.instance.substitution_defs['octal']['replace'] = 'int("0o\g<value>", 8)'
    ansible_loader_0.instance.substitution_defs['hexadecimal'] = {}
   

# Generated at 2022-06-25 04:36:42.218057
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:36:44.974228
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 04:36:54.706824
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)
    assert type(ansible_loader_0.reader) == type('')
    assert type(ansible_loader_0.stream) == type('')
    assert type(ansible_loader_0.peek_token()) == type('')
    assert type(ansible_loader_0.get_token()) == type('')
    assert type(ansible_loader_0.check_token(str_0)) == bool
    assert type(ansible_loader_0.tokens) == type('')
    assert type(ansible_loader_0.current_document()) == type('')

# Generated at 2022-06-25 04:37:01.208222
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)
    str_1 = 'RjGR*0)Q$(*vA9E>_8D45{'
    ansible_loader_0.append(str_1)

    ansible_loader_0.dispose()

    ansible_loader_0.check_printable(ansible_loader_0)
    ansible_loader_0.update(ansible_loader_0, str_1)

    ansible_loader_0.copy()

    assert (ansible_loader_0 == ansible_loader_0) is False

# Generated at 2022-06-25 04:37:10.118661
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #No parametrized constructor
    #Test with stream = '3]|-%TGx;fM=_Q{$'
    str_2 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_2)
    #Test with stream = '3]|-%TGx;fM=_Q{$' and file_name = 'TQ7~-?aG'
    str_1 = 'TQ7~-?aG'
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_1 = AnsibleLoader(str_0,str_1)

if __name__== "__main__":
    test_case_0()
    test_AnsibleLoader

# Generated at 2022-06-25 04:37:51.059230
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)
    # Test for case: 0
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_1 = AnsibleLoader(str_0)

# Generated at 2022-06-25 04:37:52.009278
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:37:54.960703
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '}2f^Wb`mGqHr\'V7v'
    ansible_loader_0 = AnsibleLoader(str_0)
    assert ansible_loader_0 is not None


# Generated at 2022-06-25 04:37:58.351418
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)


# Generated at 2022-06-25 04:38:02.086578
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Check the creation
    # Test with user defined value
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_0.constructor.add_constructor(
        u'tag:yaml.org,2002:str',
        AnsibleLoader.construct_yaml_str)

# Generated at 2022-06-25 04:38:06.336615
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'l|:c4)pm#1<J'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_0 = AnsibleLoader(str_0, 'aX??[=3@L-7}', 'l?uK8V:W$Jw')
# Function that returns an instance of AnsibleLoader

# Generated at 2022-06-25 04:38:13.155182
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader('<stdin>')
    str_0 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_1 = AnsibleLoader(str_0)
    ansible_loader_2 = AnsibleLoader(str_0, '<unknown>')
    ansible_loader_3 = AnsibleLoader(str_0, '<unknown>', '3]|-%TGx;fM=_Q{$')

# Generated at 2022-06-25 04:38:16.613644
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader('')
    ansible_loader_0


# Generated at 2022-06-25 04:38:23.994335
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    file_name_0 = 'Qt)-iW"OvQ'

# Generated at 2022-06-25 04:38:31.634436
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Constructor of class AnsibleLoader with stream and file_name parameters
    str_0 = '\x04\x7f\x18\x05-\x1f\x7f\x81\x0c'
    ansible_loader_0 = AnsibleLoader(str_0, file_name='lX<h"aJb)tNS+x')

    # Constructor of class AnsibleLoader with stream, file_name and vault_secrets parameters

# Generated at 2022-06-25 04:39:53.909355
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    #testing the stream parameter type
    try:
        ansible_loader_0 = AnsibleLoader(2)
    except TypeError as e:
        assert 1
    else:
        assert 0

    #testing the stream parameter type
    try:
        ansible_loader_0 = AnsibleLoader([])
    except TypeError as e:
        assert 1
    else:
        assert 0

    #testing the stream parameter type
    try:
        ansible_loader_0 = AnsibleLoader({})
    except TypeError as e:
        assert 1
    else:
        assert 0

    #testing the stream parameter type
    try:
        ansible_loader_0 = AnsibleLoader(1.0)
    except TypeError as e:
        assert 1
    else:
        assert 0

    #testing the stream parameter type

# Generated at 2022-06-25 04:40:00.898162
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '){Q?_mec:6z`O6~mX7F;%B-uV7$'
    ansible_loader_0 = AnsibleLoader(str_0)

    # testing of 'ansible_loader_0.construct_yaml_map'
    ansible_loader_0.construct_yaml_map(node=None)

    # testing of 'ansible_loader_0.construct_yaml_seq'
    ansible_loader_0.construct_yaml_seq(node=None)


# Generated at 2022-06-25 04:40:02.064169
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test instantiation of class AnsibleLoader
    assert AnsibleLoader('t=4i!')

# Generated at 2022-06-25 04:40:06.492097
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '\rFwOSdqz:mU<*@U)m\n'
    ansible_loader_0 = AnsibleLoader(str_0, './test/test')
    assert_equals(ansible_loader_0._file_name, './test/test')
    assert_equals(ansible_loader_0.loader.__class__.__name__, 'CLoader')
    ansible_loader_1 = AnsibleLoader(str_0)
    assert_equals(ansible_loader_1._file_name, '<unicode string>')


# Generated at 2022-06-25 04:40:10.339484
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '3]|-%TGx;fM=_Q{$'
    str_1 = '3]|-%TGx;fM=_Q{$'
    ansible_loader_0 = AnsibleLoader(str_0, str_1)


# Generated at 2022-06-25 04:40:11.387359
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:40:16.529493
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '72Uo/jFU{+/c4}1'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_1 = AnsibleLoader(str_0, vault_secrets=None)
    ansible_loader_2 = AnsibleLoader(str_0, file_name='83TzTleWCu')
    ansible_loader_3 = AnsibleLoader(str_0, file_name='83TzTleWCu', vault_secrets=None)



# Generated at 2022-06-25 04:40:22.783239
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_1 = '$msg = $msg_pretend_fail'
    ansible_loader_1 = AnsibleLoader(str_1)

    str_3 = '$msg = $msg_fail'
    ansible_loader_3 = AnsibleLoader(str_3)

    str_7 = '$msg = $msg_pretend_success'
    ansible_loader_7 = AnsibleLoader(str_7)

if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:40:28.895798
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = 'foo'
    file_name = 'bar'
    vault_secrets = 'foobar'

    ansible_loader_0 = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)
    assert ansible_loader_0.stream == stream
    assert ansible_loader_0.file_name == file_name
    assert ansible_loader_0.vault_secrets == vault_secrets

# Generated at 2022-06-25 04:40:39.209150
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test with and without stream:
    with pytest.raises(TypeError):
        AnsibleLoader()
    # Test with stream
    AnsibleLoader(stream=None)

    # Test with vault_secrets, file_name, vaults_version, loader_name
    AnsibleLoader(vault_secrets=[], file_name=None, vaults_version=None, loader_name=1)  # vault_secrets=None
    # Test with vault_secrets, file_name, vaults_version, loader_name
    AnsibleLoader(vault_secrets=None, file_name=None, vaults_version=None, loader_name=1)  # vault_secrets=None

    # Test with vault_secrets, file_name, vaults_version, loader_name