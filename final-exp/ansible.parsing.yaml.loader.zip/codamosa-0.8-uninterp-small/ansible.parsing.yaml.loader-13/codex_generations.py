

# Generated at 2022-06-25 04:32:06.917874
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # construct with str arg
    str_0 = '{}'
    ansible_loader_0 = AnsibleLoader(str_0)

    # construct with file arg
    ansible_loader_1 = AnsibleLoader(open('./test_file.yml'))

    assert isinstance(ansible_loader_0, Reader)
    assert isinstance(ansible_loader_1, Reader)


# Generated at 2022-06-25 04:32:07.996893
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'Y'
    ansible_loader_0 = AnsibleLoader(str_0)

# Generated at 2022-06-25 04:32:13.340207
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, '__init__')
    failure = False
    for x in range(100):
        try:
            test_case_0()
        except:
            failure = True
            break
    if failure:
        raise RuntimeError("__init__ failed to build an object")

# Generated at 2022-06-25 04:32:16.491525
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True


# Generated at 2022-06-25 04:32:17.374328
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print('Test AnsibleLoader constructor')
    test_case_0()

# Generated at 2022-06-25 04:32:21.978727
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ""
    file_name = ""
    vault_secrets = ""
    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)

# Generated at 2022-06-25 04:32:32.332487
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'O\x95A\x03\xbd\x0e\x86Z\xf9\xff\x8b\xbf\x1c\x95D'
    ansible_loader_0 = AnsibleLoader(str_0)
    assert(ansible_loader_0.stream == str_0)
    dict_0 = dict()
    dict_0['parsed'] = ansible_loader_0.get_single_data()
    dict_0['rest'] = ansible_loader_0.compose_node(None, None)
    dict_0['name'] = ansible_loader_0.anchors.keys()
    dict_0['rest'] = ansible_loader_0.construct_object(None, None)
    dict_0['node'] = ansible_loader_0.anch

# Generated at 2022-06-25 04:32:42.322173
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test cases (str)
    str_0 = '(hnG^J'
    str_1 = 'oD'
    str_2 = 'M'
    str_3 = 'X'
    str_4 = 'oD'
    str_5 = 'M'
    str_6 = 'X'
    str_7 = 'oD'
    str_8 = 'M'
    str_9 = 'X'
    str_10 = 'oD'
    str_11 = 'M'
    str_12 = 'X'
    str_13 = 'oD'
    str_14 = 'M'
    str_15 = 'X'
    str_16 = 'oD'
    str_17 = 'M'
    str_18 = 'X'
    str_19 = 'oD'
   

# Generated at 2022-06-25 04:32:45.601348
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# Generated at 2022-06-25 04:32:47.005545
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader('')

    assert ansible_loader_0 is not None

# Generated at 2022-06-25 04:32:58.859698
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = None
    file_name = 'test'
    vault_secrets = None

    # Test with stream as None
    ansible_loader_0 = AnsibleLoader(stream)

    # Test with stream as not None
    ansible_loader_1 = AnsibleLoader(stream, file_name, vault_secrets)

    # Test return of construct() method
    str_0 = ''
    construct_0 = ansible_loader_0.construct(str_0)

    # Test return of construct_yaml_int() method
    str_1 = '01'
    construct_yaml_int_0 = ansible_loader_0.construct_yaml_int(str_1)

    # Test return of construct_yaml_float() method
    str_2 = '0.01'
    construct_yaml_float_0

# Generated at 2022-06-25 04:33:04.212746
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test object creation
    stream = 'value_0'
    file_name = 'value_1'
    vault_secrets = 'value_2'

    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)

    assert ansible_loader_0 is not None

# Generated at 2022-06-25 04:33:14.157277
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    if HAS_LIBYAML:
        # yaml.composer or yaml.constructor.Composer
        stream = 'abc'
        file_name = 'abc'
        vault_secrets = 'abc'
        ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)
        assert ansible_loader_0
        assert ansible_loader_0.stream == stream
        assert ansible_loader_0.file_name == file_name
        assert ansible_loader_0.vault_secrets == vault_secrets
        assert ansible_loader_0.file_vars.get('_ansible_no_log', False) == False
    else:
        stream = 'abc'
        file_name = 'abc'
        vault_secrets = 'abc'
        ans

# Generated at 2022-06-25 04:33:23.320209
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream_0 = 'a'
    file_name_0 = 'n+'
    stream_1 = 'n+'
    file_name_1 = 'a'
    stream_2 = 'a'
    file_name_2 = 'n+'
    stream_3 = 'n+'
    file_name_3 = 'a'
    obj = AnsibleLoader(stream_0, file_name_0, stream_1)
    assert not obj.file_name == file_name_1
    assert not obj.vault_secrets == file_name_2
    obj = AnsibleLoader(stream_3, file_name_3, stream_2)
    assert not obj.file_name == file_name_3
    assert obj.vault_secrets == file_name_2

# Generated at 2022-06-25 04:33:33.034316
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '=/-p*O5vHrh'
    ansible_loader_2 = AnsibleLoader(str_0)
    str_1 = '{f/]H<FjYtv'
    str_2 = ';-v"BX}t`#4'
    ansible_loader_3 = AnsibleLoader(str_1, str_2)
    str_3 = 'jZ4I:E0s4`o'
    ansible_loader_4 = AnsibleLoader(str_3, str_3)
    str_4 = '~{hJ<M!_G?o'
    str_5 = 'O1@$Zz\'C*dN'
    ansible_loader_5 = AnsibleLoader(str_5, str_5, str_4)
    str_6

# Generated at 2022-06-25 04:33:35.865237
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '_woo,FkfQO&7'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_0.add_constructor('', )
    ansible_loader_0.add_constructor_dir('')
    ansible_loader_0.add_path_resolver('', '')


# Generated at 2022-06-25 04:33:46.693430
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '^B'
    file_name_0 = 'h'
    vault_secrets_0 = False
    ansible_loader_0 = AnsibleLoader(str_0, file_name=file_name_0, vault_secrets=vault_secrets_0)
    ansible_loader_0.pinned = [ansible_loader_0.pinned[0], ansible_loader_0.pinned[0]]
    ansible_loader_0.get_mark()
    ansible_loader_0.reset_allowed()
    ansible_loader_0.pinned = [ansible_loader_0.pinned[0], ansible_loader_0.pinned[0]]

# Generated at 2022-06-25 04:33:48.688806
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(None)
    assert ansible_loader is not None

# Generated at 2022-06-25 04:33:51.358544
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '(hnG^J'
    ansible_loader_0 = AnsibleLoader(str_0)

# Generated at 2022-06-25 04:34:00.840748
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #
    # pylint: disable=maybe-no-member,no-member
    str_0 = '(hnG^J'
    ansible_loader_0 = AnsibleLoader(str_0)
    str_1 = 'ghftQW\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 04:34:14.434517
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    filename = "playbooks/inventory/test_inventory.yml"

    stream = open(filename, 'rb')
    ansible_loader = AnsibleLoader(stream)
    data = ansible_loader.get_single_data()

    assert data[0]["app1"] != None
    assert data[0]["app2"] != None
    assert data[0]["app3"] != None
    assert data[0]["app4"] != None
    assert data[0]["app5"] != None
    assert data[0]["app6"] != None
    assert data[0]["app7"] != None
    assert data[0]["app8"] != N

# Generated at 2022-06-25 04:34:23.279540
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    str_0 = '\x7f\x00\x00\x01\x01\x00\x00\x00\x00'
    str_1 = '\x04\x00\x00\x00\x00\x00\x00\x00'
    str_2 = '\x10\x00\x00\x00\x00\x00\x00\x00'
    str_3 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 04:34:24.279551
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: Add your unit test here
    assert True

# Generated at 2022-06-25 04:34:27.524749
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    ################################################################################
    #
    # Test for constructor of class AnsibleLoader
    #
    ################################################################################

    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_1 = AnsibleLoader(str_0)



# Generated at 2022-06-25 04:34:28.236816
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:34:29.043087
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(str(''))

# Generated at 2022-06-25 04:34:31.479135
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_1 = '(hnG^J'
    ansible_loader_1 = AnsibleLoader(str_1)



# Generated at 2022-06-25 04:34:32.245138
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-25 04:34:33.624305
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test 1, test_case_0
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True

# Generated at 2022-06-25 04:34:37.285368
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """Test the constructor of class AnsibleLoader
    
    """
    v_0 = AnsibleLoader()
    assert isinstance(v_0, AnsibleLoader)
    assert isinstance(v_0, Parser)
    assert isinstance(v_0, AnsibleConstructor)
    assert isinstance(v_0, Resolver)


# Generated at 2022-06-25 04:34:51.289085
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    with open('test/loader_test.yml', 'r') as f:
        ansible_loader = AnsibleLoader(f, 'test/loader_test.yml')
        data = ansible_loader.get_single_data()
        assert data['a_dict']['key_4'] == 'value_4'
        assert data['a_dict']['key_5'] == 'value_5'
        assert data['an_array'] == ['value_1', 'value_2', 'value_3']

# Generated at 2022-06-25 04:34:53.304052
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        str_0 = '(hnG^J'
        ansible_loader_0 = AnsibleLoader(str_0)
    except Exception:
        assert False
    else:
        assert True

test_AnsibleLoader()

# Generated at 2022-06-25 04:34:56.742662
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # try:
    #     test_case_0()
    #     print("Unit test success!")
    # except Exception as e:
    #     print("Unit test failed!")
    #     print("Error: " + str(e))
    assert True

# Generated at 2022-06-25 04:34:57.546337
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:34:59.751310
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = ''
    file_name_0 = 'file_name_0'
    ansible_loader_0 = AnsibleLoader(str_0, file_name=file_name_0)



# Generated at 2022-06-25 04:35:01.298245
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '(hnG^J'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_1 = AnsibleLoader(str_0)

test_case_0()
test_AnsibleLoader()

# Generated at 2022-06-25 04:35:02.734751
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '""'
    ansible_loader_0 = AnsibleLoader(str_0)


# Generated at 2022-06-25 04:35:09.377404
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # clear_all_except
    d = {'a': 1, 'b': 2, 'c': 3}
    ansible_loader_0 = AnsibleLoader(None)

    ansible_loader_0.clear_all_except(d, ['a'])
    assert d == {'a': 1}

    ansible_loader_0.clear_all_except(d, ['b'])
    assert d == {'b': 2}

    ansible_loader_0.clear_all_except(d, ['c'])
    assert d == {'c': 3}


# Generated at 2022-06-25 04:35:10.243797
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str1 = '-.^0~a'
    ansible_loader_1 = AnsibleLoader(str1)

# Generated at 2022-06-25 04:35:20.814524
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '(hnG^J'
    ansible_loader_0 = AnsibleLoader(str_0)
    assert (ansible_loader_0.file_name is None)
    assert (ansible_loader_0.vault_secrets is None)
    str_1 = '33g77q3q'
    ansible_loader_1 = AnsibleLoader(str_0, file_name=str_1)
    assert (ansible_loader_1.anchor is None)
    assert (ansible_loader_1.file_name == str_1)
    assert (ansible_loader_1.vault_secrets is None)
    ansible_loader_1 = AnsibleLoader(str_0, vault_secrets='f0rzw8Pc')

# Generated at 2022-06-25 04:35:45.482266
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'n]D'
    str_1 = 'ArV)Ny&?3=V7(C1@<f]prx.c%`4^`zk'
    str_2 = 'XQS('
    str_3 = '7K<@'
    str_4 = 'P|dV>'
    str_5 = '_I]jSC'
    str_6 = 'o[}4'
    ansible_loader_0 = AnsibleLoader(str_0, str_1, str_2)
    str_7 = 'Yz@'
    str_8 = 'e5`'
    str_9 = 'C'
    str_10 = ')N'
    str_11 = '9h6g)'
    str_12 = 'v'
    str_

# Generated at 2022-06-25 04:35:48.585703
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-25 04:35:50.363119
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader
    assert Parser
    if HAS_LIBYAML:
        test_case_0()
    else:
        test_case_0()


# Generated at 2022-06-25 04:35:52.776831
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Variables
    ansible_loader_0 = AnsibleLoader()

    ansible_loader_1 = AnsibleLoader()

    ansible_loader_2 = AnsibleLoader()


# Generated at 2022-06-25 04:35:53.591233
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:35:57.471100
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = ''
    fname_0 = ''
    vault_secrets_0 = dict()
    ansible_loader_0 = AnsibleLoader(str_0, fname_0, vault_secrets_0)
    str_0 = '\'A&0o'
    ansible_loader_0 = AnsibleLoader(str_0)


# Generated at 2022-06-25 04:36:07.566407
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream_str = '(hnG^J'
    vault_secrets = {'ansible_vault_password_file': 'test_file_path'}
    test_obj = AnsibleLoader(stream_str, vault_secrets = vault_secrets)
    assert test_obj.stream == stream_str
    assert test_obj.file_name == None
    assert test_obj.vault_secrets == vault_secrets

    stream_str = '(hnG^J'
    file_name = 'test_file_name'
    vault_secrets = {'ansible_vault_password_file': 'test_file_path'}
    test_obj = AnsibleLoader(stream_str, file_name = file_name, vault_secrets = vault_secrets)
    assert test_obj.stream == stream_str

# Generated at 2022-06-25 04:36:10.688340
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:36:17.647962
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Constructor with no args should pass
    str_0 = 'role_vars'
    str_1 = 'group_vars'
    str_2 = 'include'
    str_3 = 'include_role'
    str_4 = 'import_role'
    ansible_loader_0 = AnsibleLoader(str_0)
    assert ansible_loader_0._construct_yaml_str(str_0) == str_0

    assert ansible_loader_0._construct_yaml_str(str_1) == str_1

    assert ansible_loader_0._construct_yaml_str(str_2) == str_2

    assert ansible_loader_0._construct_yaml_str(str_3) == str_3


# Generated at 2022-06-25 04:36:21.092980
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'lN9A9'
    ansible_loader_0 = AnsibleLoader(str_0)


# Generated at 2022-06-25 04:37:03.690860
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '(hnG^J'
    ansible_loader_0 = AnsibleLoader(str_0)
    assert ansible_loader_0.file_name is None


# Generated at 2022-06-25 04:37:12.886976
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '[f_Z'
    ansible_loader_0 = AnsibleLoader(str_0)
    stream_0 = ansible_loader_0.stream
    assert stream_0 == str_0
    str_1 = '$@"Qk/S)wI]\x0b'
    ansible_loader_1 = AnsibleLoader(str_1, 'rp$1\x0cJgw')
    file_name_0 = ansible_loader_1.file_name
    assert file_name_0 == 'rp$1\x0cJgw'
    str_2 = '?3;A{}D#u\x18]Ip\x1e4<'

# Generated at 2022-06-25 04:37:13.253821
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:37:18.971464
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test if the demo code can pass the test
    test_case_0()

    # testing when we create a AnsibleLoader with none input
    str_1 = None
    ansible_loader_1 = AnsibleLoader(str_1)

    # testing when we create a AnsibleLoader with a string
    str_2 = u'abc'
    ansible_loader_2 = AnsibleLoader(str_2)

    # testing when we create a AnsibleLoader with a set
    set_3 = set('a', 'b', 'c')
    ansible_loader_3 = AnsibleLoader(set_3)

print(__name__)
if __name__ == '__main__':
    test_AnsibleLoader()
    print('Test completed')

# Generated at 2022-06-25 04:37:25.067874
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '(hnG^J'
    ansible_loader_0 = AnsibleLoader(str_0)


# Generated at 2022-06-25 04:37:29.800203
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:37:31.906782
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'Ie^7'
    ansible_loader_0 = AnsibleLoader(str_0)


# Generated at 2022-06-25 04:37:37.612524
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        print('HAS_LIBYAML: %s' % HAS_LIBYAML)

        # make sure we arn't getting a recursion error
        test_case_0()
        print('Recursion test for class AnsibleLoader passed')

    except RecursionError:
        print('Recursion test for class AnsibleLoader failed')


if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-25 04:37:39.241398
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '(hnG^J'
    ansible_loader_0 = AnsibleLoader(str_0)

# Generated at 2022-06-25 04:37:44.555354
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print("Unit test for constructor of class AnsibleLoader")
    ansible_loader_0 = AnsibleLoader("stream")
    assert ansible_loader_0.__class__.__name__ == 'AnsibleLoader'
    print("AnsibleLoader is ok")


if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:39:16.370245
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'null'
    str_1 = 'string'
    str_2 = 'int'
    str_3 = 'float'
    dict_0 = dict()
    dict_0['Hello'] = 'World'
    dict_1 = dict()
    dict_1['init'] = 'test'
    ansible_constructor_0 = AnsibleConstructor(stream=dict_1, file_name=str_3, vault_secrets=dict_1)
    ansible_loader_0 = AnsibleLoader(stream=dict_0, file_name=str_1, vault_secrets=str_2)
    ansible_loader_0.get_single_data()
    ansible_loader_0.check_data_unknown_marker(node=str_0)
    ansible_loader_0.construct_

# Generated at 2022-06-25 04:39:21.510022
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = input()
    file_name = input()
    vault_secrets = input()
    obj = AnsibleLoader(stream, file_name, vault_secrets)
    assert obj.get_data() is False

# Generated at 2022-06-25 04:39:30.653376
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'gW{4<'
    file_name_0 = 'm8W'
    ansible_loader_0 = AnsibleLoader(str_0, file_name=file_name_0)
    ansible_loader_0.dispose()

    str_1 = '\n->:v'
    file_name_1 = 'a\x13'
    vault_secrets_0 = 'N\x1f\x1f'
    ansible_loader_1 = AnsibleLoader(str_1, file_name=file_name_1, vault_secrets=vault_secrets_0)
    ansible_loader_1.dispose()


# Generated at 2022-06-25 04:39:37.622848
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '1 libyaml is not installed'
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()



# Generated at 2022-06-25 04:39:44.891961
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_1 = '(A\\Y\x01\x1d'
    ansible_loader_1 = AnsibleLoader(str_1)

# Generated at 2022-06-25 04:39:46.598571
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'Z0QYJ0,S|S\x0c'
    ansible_loader_0 = AnsibleLoader(str_0)


# Generated at 2022-06-25 04:39:48.513678
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '(hnG^J'
    ansible_loader_0 = AnsibleLoader(str_0)



if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:39:56.838933
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '`'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_0 = AnsibleLoader(str_0, str_0)
    ansible_loader_0 = AnsibleLoader(str_0, str_0, str_0)
    ansible_loader_0.get_single_data()
    ansible_loader_0.get_data()
    ansible_loader_0.get_mark()
    ansible_loader_0.check_data()
    ansible_loader_0.dispose()
    ansible_loader_0.compose_document()
    ansible_loader_0.compose_node(str_0)
    ansible_loader_0.construct_document()
    ansible_loader_0.construct_sequence()
    ansible

# Generated at 2022-06-25 04:40:04.790426
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Test existence of class attribute '_yaml_version'
    assert '_yaml_version' in dir(AnsibleLoader)

    # Test existence of class attribute '_ansible_version'
    assert '_ansible_version' in dir(AnsibleLoader)

    # Test existence of class attribute '_yaml_impl'
    assert '_yaml_impl' in dir(AnsibleLoader)

    # Test existence of class attribute '_yaml_base_loader_name'
    assert '_yaml_base_loader_name' in dir(AnsibleLoader)

    # Test existence of class attribute '_yaml_base_loader'
    assert '_yaml_base_loader' in dir(AnsibleLoader)

    # Test existence of class attribute '_ansible_yaml_extensions'

# Generated at 2022-06-25 04:40:07.531011
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    (str_1, str_2) = (None, None)
    ansible_loader_1 = AnsibleLoader(str_1, str_2)