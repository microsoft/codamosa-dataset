

# Generated at 2022-06-25 04:32:10.422601
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ""
    file_name = ""
    vault_secrets = ""
    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)
    ansible_loader_0.add_implicit_resolver('tag:yaml.org,2002:float', '<float>', float_constructor)
    ansible_loader_0.add_implicit_resolver('tag:yaml.org,2002:float', '<float>', float_constructor)
    ansible_loader_0.add_constructor('tag:yaml.org,2002:python/object/apply:time.struct_time', '<python/object/apply:time.struct_time>', yaml_object_apply_time_struct_time)

# Generated at 2022-06-25 04:32:16.323298
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_1 = AnsibleLoader(float_0)
    assert isinstance(ansible_loader_1, AnsibleLoader)

# Generated at 2022-06-25 04:32:25.185262
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Initialize object
    with open('test/unit/parsing/yaml/fixtures/loader1.yml', 'r') as stream:
        ansible_loader = AnsibleLoader(stream)
    assert ansible_loader is not None
    ansible_loader.get_single_data()
    ansible_loader.get_mark()
    ansible_loader.peek_token()
    ansible_loader.check_event()
    ansible_loader.check_events()
    ansible_loader.check_events_with_name_in()
    ansible_loader.check_token()
    ansible_loader.check_type()
    ansible_loader.check_version()
    ansible_loader.compose_node()
    ansible_loader.decrement_indent()
    ansible_loader

# Generated at 2022-06-25 04:32:27.716423
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_1 = 0.1
    ansible_loader_1 = AnsibleLoader(float_1)


# Generated at 2022-06-25 04:32:28.232996
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-25 04:32:30.322493
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:32:31.988701
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:32:33.824434
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_0.test()

# Generated at 2022-06-25 04:32:38.767059
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(4)
    ansible_loader_1 = AnsibleLoader(4, vault_secrets=4)
    assert type(ansible_loader_1) == AnsibleLoader
    assert type(ansible_loader_0) == AnsibleLoader

# Generated at 2022-06-25 04:32:41.162641
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-25 04:32:43.721638
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True



# Generated at 2022-06-25 04:32:46.249840
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:32:49.703001
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(float_0)
    stream = float_0
    ansible_loader_1 = AnsibleLoader(float_0, float_0)

# Generated at 2022-06-25 04:32:54.892028
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert not HAS_LIBYAML
    assert isinstance(AnsibleLoader(0.1), AnsibleLoader)
    assert isinstance(AnsibleLoader(0.1), Reader)
    assert isinstance(AnsibleLoader(0.1), Scanner)
    assert isinstance(AnsibleLoader(0.1), Parser)
    assert isinstance(AnsibleLoader(0.1), Composer)
    assert isinstance(AnsibleLoader(0.1), AnsibleConstructor)
    assert isinstance(AnsibleLoader(0.1), Resolver)

# Generated at 2022-06-25 04:33:03.165346
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import pytest
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test try-except statement
    ansible_loader_0 = AnsibleLoader(float(2), os.path.abspath("foo"))

    # Test try-except statement
    # // ValueError raised
    with pytest.raises(ValueError):
        ansible_loader_1 = AnsibleLoader(float(1))

    ansible_loader_2 = AnsibleLoader(str("test_str"))
    ansible_loader_3 = AnsibleLoader(str("test_str"), str("test_str"))

    # // ValueError raised
    with pytest.raises(ValueError):
        ansible_loader_4 = AnsibleLoader(str("test_str"), int(111))

    # Test

# Generated at 2022-06-25 04:33:10.519898
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)
    float_1 = 0.1
    ansible_loader_1 = AnsibleLoader(float_1)
    ansible_loader_0.dispatch(float_1)
    float_2 = 0.1
    ansible_loader_2 = AnsibleLoader(float_1)
    ansible_loader_2.construct_yaml_seq(float_2)
    ansible_loader_3 = AnsibleLoader(float_2)
    float_3 = 0.1
    ansible_loader_4 = AnsibleLoader(float_1)
    float_4 = 0.1
    ansible_loader_5 = AnsibleLoader(float_4)

# Generated at 2022-06-25 04:33:18.200464
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_0.construct_document()
    ansible_loader_0.dispose()
    ansible_loader_0.check_data()
    ansible_loader_0.get_node()
    ansible_loader_0.resolve()
    ansible_loader_0.safe_construct()
    ansible_loader_0.safe_construct_mapping()
    ansible_loader_0.construct_sequence()
    ansible_loader_0.construct_scalar()
    ansible_loader_0.construct_undefined()
    ansible_loader_0.construct_mapping()


# Generated at 2022-06-25 04:33:21.052414
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(float_0)


# Generated at 2022-06-25 04:33:23.488646
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: Assert that AnsibleLoader(float_0) fails
    try:
        assert test_case_0() == None
    except:
        return False
    return True

# Generated at 2022-06-25 04:33:30.721626
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = float(0)
    float_1 = float(1)
    float_2 = float(2)
    float_3 = float(3)
    float_4 = float(4)
    float_5 = float(5)
    float_6 = float(6)
    float_7 = float(7)
    float_8 = float(8)
    float_9 = float(9)
    float_10 = float(10)
    float_11 = float(11)
    float_12 = float(12)
    ansible_loader_0 = AnsibleLoader(float_0, float_1)
    ansible_loader_1 = AnsibleLoader(float_2, float_3)
    ansible_loader_2 = AnsibleLoader(float_4, float_5)
    ansible_loader_

# Generated at 2022-06-25 04:33:41.080874
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import random
    import string
    import tempfile
    import unittest
    import sys

    # Change test type based on Python version
    if sys.version_info > (2, 6):
        class TestAnsibleLoader(unittest.TestCase):

            def test_constructor(self):
                float_1 = 0.1
                ansible_loader_1 = AnsibleLoader(float_1)

            # Unit test for method load_from_file()
            def test_load_from_file(self):
                float_2 = 0.1
                ansible_loader_2 = AnsibleLoader(float_2)
                str_1 = ''.join(random.choice(string.ascii_letters) for _ in range(4))

# Generated at 2022-06-25 04:33:43.471706
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_1 = AnsibleLoader(float_0, float_0)


# Generated at 2022-06-25 04:33:49.154350
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=too-many-arguments
    ansible_loader_0 = AnsibleLoader('stream', 'file_name', 'vault_secrets')
    assert isinstance(ansible_loader_0.stream, str)
    assert ansible_loader_0.file_name is not None
    assert ansible_loader_0.vault_secrets is not None
    assert isinstance(ansible_loader_0.file_name, str)
    assert isinstance(ansible_loader_0.vault_secrets, str)
    assert isinstance(ansible_loader_0.file_vars, dict)
    assert isinstance(ansible_loader_0.mainframe, dict)
    assert isinstance(ansible_loader_0.rst_cache, dict)
    float_0 = 0.1

# Generated at 2022-06-25 04:33:52.956218
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test using float parameter
    float_1 = 0.1
    ansible_loader_1 = AnsibleLoader(float_1)


# Generated at 2022-06-25 04:33:55.398483
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)

# Basic test for function AnsibleLoader

# Generated at 2022-06-25 04:33:57.169821
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)
    assert ansible_loader_0 is not None

# Generated at 2022-06-25 04:33:59.389088
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    with open('../test/yaml/inventory.yml', 'rb') as stream:
        ansib_loader = AnsibleLoader(stream)

# Generated at 2022-06-25 04:34:03.093109
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert 1 == 1  # TODO: implement your test here


# Generated at 2022-06-25 04:34:10.317769
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)
    float_1 = 0.1
    ansible_loader_1 = AnsibleLoader(float_1)
    float_2 = 0.1
    ansible_loader_2 = AnsibleLoader(float_2)
    float_3 = 0.1
    ansible_loader_3 = AnsibleLoader(float_3)
    float_4 = 0.1
    ansible_loader_4 = AnsibleLoader(float_4)

# Generated at 2022-06-25 04:34:13.073686
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = None
    file_name = None
    vault_secrets = None
    # Initialize AnsibleLoader with stream, file_name, vault_secrets
    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)

# Generated at 2022-06-25 04:34:28.845497
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_0.add_constructor('', AnsibleLoader.__init__)
    ansible_loader_0.add_multi_constructor('!include', AnsibleLoader.__init__)
    ansible_loader_0.add_multi_constructor('!include_vars', AnsibleLoader.__init__)
    ansible_loader_0.add_multi_constructor('!vault', AnsibleLoader.__init__)
    ansible_loader_0.add_implicit_resolver('', AnsibleLoader.__init__, None)
    ansible_loader_0.add_path_resolver('tag:yaml.org,2002:', AnsibleLoader.__init__)
    ansible

# Generated at 2022-06-25 04:34:37.605260
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import json
    import yaml

    b = 'this is a text file we are going to read\n'
    b += 'called foo\n'

    # b : byte stream
    stream_handle = open('foo', 'wb')
    stream_handle.write(b)
    stream_handle.flush()
    stream_handle.close()

    # r : reading stream
    stream_handle = open('foo', 'rb')
    data = stream_handle.read()
    stream_handle.close()

    data_json = json.dumps(data)
    print(data_json)

    data_yaml = yaml.dump(data, default_flow_style=False)
    print(data_yaml)

    # r : reading stream
    stream_handle = open('foo', 'rb')
    ans

# Generated at 2022-06-25 04:34:39.327091
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)


# Generated at 2022-06-25 04:34:41.263461
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)
    assert ansible_loader_0.get_single_data() == None

# Generated at 2022-06-25 04:34:42.477655
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    loader_0 = AnsibleLoader(float_0)
    

# Generated at 2022-06-25 04:34:50.243027
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)
    assert len(ansible_loader_0.constructed_objects) == 0
    ansible_loader_0.add_constructor(float_0,float_0)
    ansible_loader_0.get_single_data()
    ansible_loader_0.dispose()
    assert len(ansible_loader_0.constructed_objects) == 0
    ansible_loader_0.get_data()
    ansible_loader_0.construct_object(None,None)
    ansible_loader_0.construct_yaml_map(None)
    ansible_loader_0.construct_yaml_seq(None)
    ansible_loader_0.construct_undefined(None)


# Unit test

# Generated at 2022-06-25 04:34:55.401381
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = None
    file_name = None
    vault_secrets = None
    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)
    if hasattr(ansible_loader, "stream") and ansible_loader.stream is None:
        assert True
    else:
        assert False

    if hasattr(ansible_loader, "file_name") and ansible_loader.file_name is None:
        assert True
    else:
        assert False

    if hasattr(ansible_loader, "vault_secrets") and ansible_loader.vault_secrets is None:
        assert True
    else:
        assert False


# Generated at 2022-06-25 04:34:58.922036
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:35:01.290844
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:35:04.237077
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)
    # ValueError: could not determine a constructor for the tag !!python/float '0.1'
    assert ansible_loader_0 == False


# Generated at 2022-06-25 04:35:24.860052
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_1 = AnsibleLoader()
    ansible_loader_2 = AnsibleLoader()
    ansible_loader_3 = AnsibleLoader()
    float_1 = 0.1
    ansible_loader_4 = AnsibleLoader(float_1)
    ansible_loader_5 = AnsibleLoader(float_1, float_1)
    ansible_loader_6 = AnsibleLoader(float_1, float_1)
    ansible_loader_7 = AnsibleLoader(float_1, float_1)
    ansible_loader_8 = AnsibleLoader(float_1, float_1)
    ansible_loader_9 = AnsibleLoader(float_1, float_1)
    ansible_loader_10 = AnsibleLoader(float_1, float_1)

# Generated at 2022-06-25 04:35:29.199034
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import StringIO

    stream = StringIO.StringIO()
    assert not AnsibleLoader(stream)
    stream = StringIO.StringIO()
    assert not AnsibleLoader(stream, None)
    stream = StringIO.StringIO()
    assert not AnsibleLoader(stream, None, None)


# Generated at 2022-06-25 04:35:31.647548
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)
    assert ansible_loader.file_name == file_name
    assert ansible_loader.vault_secrets == vault_secrets

# Generated at 2022-06-25 04:35:32.675240
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:35:43.165315
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # load with string
    ansible_loader_0 = AnsibleLoader('test')
    assert ansible_loader_0.stream == 'test'
    assert ansible_loader_0.line == 0
    assert ansible_loader_0.column == 0
    assert ansible_loader_0.index == 0
    assert ansible_loader_0.buffer == 'test'
    assert ansible_loader_0.pointer == 0

    # load with io (file)
    ansible_loader_1 = AnsibleLoader(file('test'))
    assert ansible_loader_1.stream == file('test')
    assert ansible_loader_1.line == 0
    assert ansible_loader_1.column == 0
    assert ansible_loader_1.index == 0
    assert ansible_loader_1.buffer == ''
   

# Generated at 2022-06-25 04:35:50.404252
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # float_2 = float(float_0)
    float_2 = 0.1
    ansible_loader_0 = AnsibleLoader(float_2)
    float_1 = 0.1
    ansible_loader_0 = AnsibleLoader(float_1)
    # ansible_loader_1 = (float_2, float_0)
    ansible_loader_1 = (0.1, 0.1)
    ansible_loader_0 = AnsibleLoader(ansible_loader_1)
    float_3 = float(0.1)
    ansible_loader_0 = AnsibleLoader(float_3)
    float_4 = float(0.1)
    ansible_loader_2 = AnsibleLoader(float_4)

# Generated at 2022-06-25 04:35:51.708321
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:35:58.952300
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(None)

    try:
        ansible_loader_0.add_multi_document
    except AttributeError:
        pass
    else:
        assert False, "expected AttributeError"
    try:
        ansible_loader_0.check_data
    except AttributeError:
        pass
    else:
        assert False, "expected AttributeError"
    try:
        ansible_loader_0.compose_document
    except AttributeError:
        pass
    else:
        assert False, "expected AttributeError"
    try:
        ansible_loader_0.compose_node
    except AttributeError:
        pass
    else:
        assert False, "expected AttributeError"

# Generated at 2022-06-25 04:36:02.654009
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_1 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:36:13.196374
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert 'composer' in dir(AnsibleLoader)
    assert 'construct_yaml_map' in dir(AnsibleLoader)
    assert 'constructor' in dir(AnsibleLoader)
    assert 'constructor_dispatcher' in dir(AnsibleLoader)
    assert 'default_flow_style' in dir(AnsibleLoader)
    assert 'document_start_event' in dir(AnsibleLoader)
    assert 'emit_event' in dir(AnsibleLoader)
    assert 'file_name' in dir(AnsibleLoader)
    assert 'flatten_mapping' in dir(AnsibleLoader)
    assert 'get_data' in dir(AnsibleLoader)
    assert 'get_event' in dir(AnsibleLoader)
    assert 'get_single_data' in dir

# Generated at 2022-06-25 04:36:46.749901
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = None
    file_name = None
    vault_secrets = None
    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)
    # TODO: implement functionality


# Generated at 2022-06-25 04:36:49.407692
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Creating an object of class AnsibleLoader
    ansible_loader = AnsibleLoader()



# Generated at 2022-06-25 04:36:54.182756
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:36:59.738763
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    reader_0 = Reader()
    scanner_0 = Scanner()
    parser_0 = Parser()  # pylint: disable=non-parent-init-called
    composer_0 = Composer()
    ansible_constructor_0 = AnsibleConstructor()
    resolver_0 = Resolver()
    ansible_loader_0 = AnsibleLoader(reader_0, scanner_0, parser_0, composer_0, ansible_constructor_0, resolver_0)

# Generated at 2022-06-25 04:37:01.132288
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = float('float_0')
    ansible_loader_0 = AnsibleLoader(float_0)


# Generated at 2022-06-25 04:37:01.693408
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:37:05.326021
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = "hi"
    loader = AnsibleLoader(data)

    assert loader

    return True

if __name__ == '__main__':
    from ansible.utils.color import stringc
    from pytest import main
    main([__file__])

# Generated at 2022-06-25 04:37:12.981812
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    # Create an instance of AnsibleLoader
    ansible_loader_0 = AnsibleLoader(float_0)
    # Assert the attributes are defined
    assert hasattr(ansible_loader_0, '_AnsibleLoader__node_stack')
    assert hasattr(ansible_loader_0, '_AnsibleConstructor__clients')
    assert hasattr(ansible_loader_0, '_AnsibleConstructor__file_name')
    assert hasattr(ansible_loader_0, '_AnsibleConstructor__vault_secrets')
    assert hasattr(ansible_loader_0, '_AnsibleConstructor__funcs')
    assert hasattr(ansible_loader_0, '_AnsibleConstructor__resource_cache')

# Generated at 2022-06-25 04:37:19.071662
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    ansible_loader_0 = AnsibleLoader(1.1)

    assert ansible_loader_0.value == '1.1'
    assert ansible_loader_0.line_number == 1
    assert ansible_loader_0.column == 1
    assert ansible_loader_0.name_line_number is None
    assert ansible_loader_0.name_column is None
    assert ansible_loader_0.parser is None

    # test __init__
    ansible_loader_0 = AnsibleLoader(1.1)
    ansible_loader_0.parser = 'abc'
    ansible_loader_0.parsed = 'abc'
    ansible_loader_0.__init__(1.1)
    assert ansible_loader_0.value == '1.1'
    assert ansible

# Generated at 2022-06-25 04:37:30.636651
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible import constants as C
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.inventory.host import Host
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.inventory.group import Group
    from ansible.plugins.loader import lookup_loader
    from ansible.vars import VariableManager

    # Make sure the constructor doesn't throw an exception
    AnsibleLoader(None)

    # Make sure that AnsibleLoader.get_single_data doesn't throw an exception
    ansible_loader_1 = AnsibleLoader(None)
    ansible_loader_1.get_single_data()

    # Check initialization of ansible_loader_2
    ansible_loader_2 = AnsibleLoader(None)

# Generated at 2022-06-25 04:38:43.651213
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(None)
    assert ansible_loader is not None

# Generated at 2022-06-25 04:38:46.460800
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # float_0 = float(1.25)
    float_0 = float(1.25)
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:38:56.322845
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:39:01.715743
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_1 = 0.1
    ansible_loader_1 = AnsibleLoader(float_1)
    test_case_0()

test_AnsibleLoader()

# Generated at 2022-06-25 04:39:03.239101
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)
    assert ansible_loader_0


# Generated at 2022-06-25 04:39:07.521428
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)
    assert ansible_loader_0.stream == float_0

# Generated at 2022-06-25 04:39:11.536749
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    with pytest.raises(SystemExit) as exc_info:
        test_case_0()
    assert exc_info.value.code == 1

# Generated at 2022-06-25 04:39:15.209768
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    my_file_name = 'test_case_0'
    ansible_loader_0 = None
    try:
        ansible_loader_0 = AnsibleLoader(file_name=my_file_name)
    except TypeError:
        pass

    # Instantiation of class AnsibleLoader with params (file_name=my_file_name)
    ansible_loader_1 = AnsibleLoader(file_name=my_file_name)

# Generated at 2022-06-25 04:39:19.432306
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    bool_0 = bool(0)
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_0.get_single_data()


# Generated at 2022-06-25 04:39:20.226390
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    c = AnsibleLoader()

# Generated at 2022-06-25 04:41:47.620440
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test for default construction of class AnsibleLoader
    ansible_loader_0 = AnsibleLoader()
    # Test for construction of class AnsibleLoader
    stream = 0.1
    ansible_loader_1 = AnsibleLoader(stream)
    # Test for construction of class AnsibleLoader
    stream = 0.1
    file_name = ""
    ansible_loader_2 = AnsibleLoader(stream, file_name)
    # Test for construction of class AnsibleLoader
    stream = 0.1
    file_name = ""
    vault_secrets = []
    ansible_loader_3 = AnsibleLoader(stream, file_name, vault_secrets)

# Generated at 2022-06-25 04:41:50.848645
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_1 = 0.1
    ansible_loader_0 = AnsibleLoader(float_1)
    # This test makes sure that the class AnsibleLoader is correctly loaded
    ansible_loader_1 = AnsibleLoader()
    ansible_loader_1.get_single_data()

# Generated at 2022-06-25 04:41:53.557868
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:41:55.276763
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:41:56.718716
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 1.0
    ansible_loader_0 = AnsibleLoader(float_0)
    assert ansible_loader_0 is not None

# Generated at 2022-06-25 04:42:01.302096
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.1
    ansible_loader_0 = AnsibleLoader(float_0)
    assert ansible_loader_0.file_name is None
    assert ansible_loader_0.vault_secrets is None