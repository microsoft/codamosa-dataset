

# Generated at 2022-06-25 04:32:05.389816
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert ansible_loader_0._ansible_get_line() == 1

# Generated at 2022-06-25 04:32:06.426534
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert(False), "Unit tests for AnsibleLoader not implemented."

# Generated at 2022-06-25 04:32:07.997084
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)

# Generated at 2022-06-25 04:32:13.865834
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(b'\x00e\x9a\x90=\xdc')
    ansible_loader_1 = AnsibleLoader(b'\x00e\x9a\x90=\xdc')
    #assert ansible_loader_0.file_name == 'i\x07y\x9a\x03\x1d\xde'
    #assert ansible_loader_1.file_name == 'i\x07y\x9a\x03\x1d\xde'
    byte_0 = '\x00e\x9a\x90=\xdc'
    ansible_loader_2 = AnsibleLoader(byte_0)

# Generated at 2022-06-25 04:32:22.357751
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\x1f\x8b\x08\x00P\x8fZ\xdd\x02\xff\x1b\x0c\x00\x03\xf3\x8a\x84\x0c\x9c\x7f\x00\x00\x00'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    dict_0 = ansible_loader_0.get_single_data()
    for element in dict_0.keys():
        if element == 'changed':
            assert dict_0[element]
        if element == 'msg':
            assert dict_0[element]
    ansible_loader_1 = AnsibleLoader(bytes_0)
    dict_1 = ansible_loader_1.get_single_data()


# Generated at 2022-06-25 04:32:26.618707
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = ''
    file_name_0 = ''
    vault_secrets_0 = None
    ansible_loader_0 = AnsibleLoader(bytes_0, file_name_0, vault_secrets_0)
    ansible_loader_0.stream
    ansible_loader_0.version
    ansible_loader_0.check_version
    ansible_loader_0.tags
    ansible_loader_0.anchors
    ansible_loader_0.file_name


# Generated at 2022-06-25 04:32:36.730926
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml

    # AnsibleLoader object
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    r = repr(ansible_loader_0)
    assert r == "AnsibleLoader(stream=<_io.BytesIO object at 0x7fc4b829a3d0>)"

    # AnsibleLoader object as context manager
    bytes_1 = b'OI\x18\xd6M\x04'
    ansible_loader_1 = AnsibleLoader(bytes_1)
    with ansible_loader_1 as ansible_loader_1:
        r = repr(ansible_loader_1)

# Generated at 2022-06-25 04:32:37.908684
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert callable(AnsibleLoader)


# Generated at 2022-06-25 04:32:40.659864
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b''

    # Testing constructor AnsibleLoader
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert ansible_loader_0 is not None

# Generated at 2022-06-25 04:32:49.992981
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:33:01.447604
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:33:02.389995
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True == True


# Generated at 2022-06-25 04:33:07.010993
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(None)
    ansible_loader_1 = AnsibleLoader(None, file_name='config.cfg')
    ansible_loader_2 = AnsibleLoader(None, file_name='config.cfg', vault_secrets=[])
    ansible_loader_3 = AnsibleLoader(None, vault_secrets=[])


# Generated at 2022-06-25 04:33:17.971740
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    (bytes_0, ) = (b'^5\xbc\x18\xd6M\x04', )
    (yaml_obj_0, ) = (None, )
    (ansible_loader_0, ) = (None, )
    ansible_loader_0 = AnsibleLoader(bytes_0)
    ansible_loader_0.get_single_data()
    yaml_obj_0 = AnsibleLoader.construct_object(ansible_loader_0, ansible_loader_0.root_node)
    assert yaml_obj_0 == None
    #assert ansible_loader_0.anchors == {}
    #assert ansible_loader_0.block_seq_indent == 0
    #assert ansible_loader_0.block_map_indent == 0
    #assert ansible_loader

# Generated at 2022-06-25 04:33:25.628595
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:33:31.370577
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # First test case
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    return ansible_loader_0

import runpy
runpy.run_module('ansible.modules.extras.cloud.openstack.os_server_group')

# Generated at 2022-06-25 04:33:32.944320
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Scenario 1
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)

# Generated at 2022-06-25 04:33:33.874602
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert callable(AnsibleLoader)



# Generated at 2022-06-25 04:33:35.783508
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)

    assert 1 == 1


# Generated at 2022-06-25 04:33:46.694334
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print("Test constructor of class AnsibleLoader:\n")
    ansible_loader_1 = AnsibleLoader([])
    assert len(ansible_loader_1.stream) == 0
    print("Test instance with empty stream: Ok (no exception is thrown) \n")

    ansible_loader_2 = AnsibleLoader([[]])
    assert len(ansible_loader_2.stream) == 1
    print("Test instance with not empty stream: Ok (no exception is thrown) \n")

    ansible_loader_3 = AnsibleLoader([1])
    assert len(ansible_loader_3.stream) == 1
    print("Test instance with not empty stream: Ok (no exception is thrown) \n")

    ansible_loader_4 = AnsibleLoader(1)
    assert ansible_loader_4.stream == 1
    print

# Generated at 2022-06-25 04:34:00.652297
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    # test get_single_data
    bytes_1 = b"\x01"
    data_1 = ansible_loader_0.get_single_data(bytes_1)
    assert data_1 == "\x01"
    # test get_data
    data_2 = ansible_loader_0.get_data()
    assert data_2 == {}
    # test check_data
    # assert ansible_loader_0.check_data() == None
    # test check_data_empty
    # assert ansible_loader_0.check_data_empty() == None
    # test compose_node
    # assert ansible_loader_0.compose_node(

# Generated at 2022-06-25 04:34:06.621252
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    ansible_loader_0 = AnsibleLoader(bytes_0)


# Generated at 2022-06-25 04:34:16.474855
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    ansible_loader_0.check_event("check_event")
    ansible_loader_0.get_data("get_data")
    ansible_loader_0.process_scalar("process_scalar")
    ansible_loader_0.construct_object("construct_object")
    ansible_loader_0.get_single_data("get_single_data")
    ansible_loader_0.compose("compose")
    ansible_loader_0.dispose("dispose")
    ansible_loader_0.construct_mapping("construct_mapping")

# Generated at 2022-06-25 04:34:25.728600
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Create a new AnsibleLoader object
    ansible_loader = AnsibleLoader()

    # Try to load a byte string and the corresponding object
    byte_string = b'OI\x18\xd6M\x04'
    try:
        ansible_loader.load(byte_string)
    except:
        pass

    # Try to load a string and the corresponding object
    string = 'OI\x18\xd6M\x04'
    try:
        ansible_loader.load(string)
    except:
        pass

# Call the test
if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-25 04:34:30.191764
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert ansible_loader_0

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-25 04:34:38.122213
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    c = AnsibleLoader(None)
    c.anchors = {}
    c.compose_node(None, None, None)
    c.construct_mapping(None, None, deep=False)
    c.construct_sequence(None, None, deep=False)
    c.construct_yaml_map(None)
    c.construct_yaml_seq(None)
    c.get_data()
    c.get_single_data()
    c.get_undefined_constructor(None)
    c.resolve(None, None, value=None)
    c.resolver_exception(None, None, None, None, None, None)
    c.resolver_implicit_resolve(None, None, None)
    c.resolver_list_all(None, None)
    c.res

# Generated at 2022-06-25 04:34:39.396598
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Test case for AnsibleLoader.__init__()

# Generated at 2022-06-25 04:34:41.368258
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)


# Generated at 2022-06-25 04:34:46.969254
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    bytes_1 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_1)
    bytes_2 = b'OI\x18\xd6M\x04'
    ansible_loader_2 = AnsibleLoader(bytes_2)


if __name__ == '__main__':
    test_AnsibleLoader()
    test_case_0()

# Generated at 2022-06-25 04:34:50.862464
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'OI\x18\xd6M\x04'
    file_name_0 = b'\x80'
    vault_secrets_0 = b'\x80'
    ansible_loader_0 = AnsibleLoader(bytes_0, file_name_0, vault_secrets_0)

# Generated at 2022-06-25 04:35:00.536382
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert callable(AnsibleLoader)


# Generated at 2022-06-25 04:35:03.024523
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    with open("tests/test_constructor.yml", 'rb') as bytes_0:
        ansible_loader_0 = AnsibleLoader(bytes_0)
        assert ansible_loader_0 is not None


# Generated at 2022-06-25 04:35:11.159682
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(bytes(0))
    ansible_loader.add_constructor(
        u'tag:yaml.org,2002:null',
        AnsibleConstructor.construct_yaml_null
    )
    ansible_loader.add_constructor(
        u'tag:yaml.org,2002:bool',
        AnsibleConstructor.construct_yaml_bool
    )
    ansible_loader.add_constructor(
        u'tag:yaml.org,2002:int',
        AnsibleConstructor.construct_yaml_int
    )
    ansible_loader.add_constructor(
        u'tag:yaml.org,2002:str',
        AnsibleConstructor.construct_yaml_str
    )

# Generated at 2022-06-25 04:35:11.839869
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# Generated at 2022-06-25 04:35:17.546483
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'C\xa0\x04\x03'
    ansible_loader_0 = AnsibleLoader(bytes_0)



# Generated at 2022-06-25 04:35:21.960697
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    ansible_loader_1 = AnsibleLoader(bytes_0, file_name='')

# Generated at 2022-06-25 04:35:25.234851
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:35:33.730692
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:35:36.750913
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = None
    file_name = 'ansible/parsing/yaml/constructor.py'
    vault_secrets = None
    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)
    assert ansible_loader is not None


# Generated at 2022-06-25 04:35:42.936452
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    bytes_1 = b'WG\xa6\xd4\x90'
    ansible_loader_1 = AnsibleLoader(bytes_1)
    bytes_2 = b'\xd0\xeb\xc5\x1f'
    ansible_loader_2 = AnsibleLoader(bytes_2)
    bytes_3 = b'Z\x98\xdf\x94\xe2'
    ansible_loader_3 = AnsibleLoader(bytes_3)
    bytes_4 = b'\x04\x06\x17\x0f\x18'
    ansible_loader_4 = AnsibleLoader(bytes_4)
    bytes_5

# Generated at 2022-06-25 04:36:07.228996
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # initialization
    ansible_loader_0 = AnsibleLoader(b'OI\x18\xd6M\x04')
    # default return value is empty dict
    assert ansible_loader_0 == {}
    # initialization with dict
    ansible_loader_1 = AnsibleLoader({'I am test dict'})
    # default return value is empty dict
    assert ansible_loader_1 == {}

# Generated at 2022-06-25 04:36:08.180733
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    res_0 = AnsibleLoader()

# Generated at 2022-06-25 04:36:17.761621
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Constructor of class AnsibleLoader.

    """
    if HAS_LIBYAML:
        import yaml
        bytes_1 = b'OI\x18\xd6M\x04'
        ansible_loader_1 = AnsibleLoader(bytes_1)
    else:
        import sys
        if sys.version_info[:2] < (2, 7):
            import warnings
            warnings.warn("yaml python lib loader is broken in py26 and cannot be tested with unit tests")
            return

        import yaml

        stream_2 = sys.stdin
        ansible_loader_2 = AnsibleLoader(stream_2)
        bytes_3 = b'OI\x18\xd6M\x04'
        ansible_loader_3 = AnsibleLoader(bytes_3)
        bytes_

# Generated at 2022-06-25 04:36:18.272406
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-25 04:36:22.786415
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert type(ansible_loader_0) is AnsibleLoader

# Generated at 2022-06-25 04:36:28.440270
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = -1
    file_name = -1
    vault_secrets = -1
    ansible_loader_obj = AnsibleLoader(stream, file_name, vault_secrets)

    assert isinstance(ansible_loader_obj, AnsibleLoader)

# Generated at 2022-06-25 04:36:34.655603
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

if __name__ == '__main__':
    import sys, os, pytest
    try:
        pytest.main(sys.argv[1:])
    except:
        # raise SystemExit(str(e))
        sys.exit(1)
    sys.exit(0)

# Generated at 2022-06-25 04:36:43.413656
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    ansible_loader_0.Name = "class AnsibleLoader::AnsibleLoader"
    ansible_loader_0.stream = bytes_0
    ansible_loader_0.vault_secrets = {}
    ansible_loader_0.file_name = None
    ansible_loader_0.indent = 2
    ansible_loader_0.index = 0
    ansible_loader_0.line = 1
    ansible_loader_0.buffer = []
    ansible_loader_0.pointer = 0
    ansible_loader_0.raw_buffer = b'OI\x18\xd6M\x04'
    ansible_loader_

# Generated at 2022-06-25 04:36:53.150710
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:36:55.062605
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert loader.ansible_imports == {}


# Generated at 2022-06-25 04:37:34.614214
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Example for AnsibleLoader (constructor)
    ansible_loader_0 = AnsibleLoader(None)

# Generated at 2022-06-25 04:37:35.124896
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-25 04:37:38.688219
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    ansible_loader_0.get_single_data()

# Generated at 2022-06-25 04:37:48.776992
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    tup = ansible_loader_0._reader.peek()
    assert tup[1] == 4
    assert tup[0] == '\x18'
    assert ansible_loader_0._anchors == {}
    assert ansible_loader_0._file_name == None
    assert ansible_loader_0._vault_secrets == None

    ansible_loader_1 = AnsibleLoader(bytes_0, 'path')
    assert ansible_loader_1._reader.peek()[0] is None
    assert ansible_loader_1._file_name == 'path'
    assert ansible_loader_1._vault_secrets == None



# Generated at 2022-06-25 04:37:55.143519
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'OI\x18\xd6M\x04'
    yaml_loader_0 = AnsibleLoader(bytes_0)
    assert yaml_loader_0.stream == bytes_0
    assert yaml_loader_0.vault_secrets == None
    assert yaml_loader_0.file_name == None
    assert yaml_loader_0.vault_secrets == None
    vault_secrets_0 = dict()
    yaml_loader_0 = AnsibleLoader(bytes_0, vault_secrets=vault_secrets_0)
    assert yaml_loader_0.stream == bytes_0
    assert yaml_loader_0.vault_secrets == vault_secrets_0
    assert yaml_loader_0.file_name == None
    assert yaml

# Generated at 2022-06-25 04:38:00.532481
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    stream  = "fake_stream"
    vault_secrets = "fake_vault_secrets"

    ansible_loader = AnsibleLoader(stream, vault_secrets=vault_secrets)

    assert ansible_loader._constructor.vault_secrets == "fake_vault_secrets"
    assert ansible_loader.vault_secrets == "fake_vault_secrets"

# Generated at 2022-06-25 04:38:01.516347
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    assert callable(AnsibleLoader)

# Generated at 2022-06-25 04:38:08.829534
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert callable(AnsibleLoader)
    bytes_0 = b'c\x1d\x02\x06\n\x04\x07\x03\x01d\x01b\x01f\x01\x02\x06\n\x04\x07\x03\x01d\x01b\x01f\x01\x02\x06\n\x04\x07\x03\x01d\x01b\x01f\x01\x02\x06\n\x04\x07\x03\x01d\x01b\x01f\x01\x02\x06\n\x04\x07\x03\x01d\x01b\x01f\x01'

# Generated at 2022-06-25 04:38:12.282859
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    ansible_loader_0.n

# Generated at 2022-06-25 04:38:13.914090
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(mock_0_str)

mock_0_str = "example\n"

# Generated at 2022-06-25 04:39:33.904227
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert callable(AnsibleLoader), "class AnsibleLoader is not callable"

# Generated at 2022-06-25 04:39:42.559549
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:39:48.525830
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"---"
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert isinstance(ansible_loader_0, AnsibleLoader) == True

    bytes_1 = b'OI\x18\xd6M\x04'
    ansible_loader_1 = AnsibleLoader(bytes_1)
    assert isinstance(ansible_loader_1, AnsibleLoader) == True

# Generated at 2022-06-25 04:39:56.838530
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:40:04.751380
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert isinstance(AnsibleLoader, type)
    assert isinstance(AnsibleConstructor, type)
    assert isinstance(Parser, type)
    assert isinstance(Resolver, type)
    assert hasattr(AnsibleLoader, "__init__")

    # Constructor call argument types
    # AnsibleLoader(stream, file_name=None, vault_secrets=None)
    #
    # The constructor should take a stream object as a parameter
    # which should be an instance of type bytes.
    # If the file name is not known, it should default to None.

    # First test case: Write the input bytes directly into a file,
    # then open a stream to it to verify that the constructor
    # accepts the parameter properly and does not encounter
    # an error.


# Generated at 2022-06-25 04:40:11.860530
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Load a string
    ansible_loader_0 = AnsibleLoader(b'OI\x18\xd6M\x04')
    assert_equal(
        ansible_loader_0.get_result(),
        [19, 49, 72, 86, 111, 114]
    )
    # Load a file
    ansible_loader_1 = AnsibleLoader(open('/urandom', 'rb'))
    assert_equal(
        ansible_loader_1.get_result(),
        [19, 49, 72, 86, 111, 114]
    )

# Generated at 2022-06-25 04:40:14.171347
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert ansible_loader_0 is not None

# Generated at 2022-06-25 04:40:23.005821
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing import vars_loader
    bytes_0 = b'OI\x18\xd6M\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    dict_1 = dict(vars_loader.VarsModule().run(ansible_loader_0))
    list_0 = list()
    list_0.append(dict_1)

# Generated at 2022-06-25 04:40:24.705843
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    
    ansible_loader = AnsibleLoader(None)
    ansible_loader_0 = AnsibleLoader(None)
    ansible_loader_0.set_root_node(None)



# Generated at 2022-06-25 04:40:26.305319
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test with file_name and vault_secrets
    AnsibleLoader('stream', 'file_name', 'vault_secrets')
    # test with file_name
    AnsibleLoader('stream', 'file_name')