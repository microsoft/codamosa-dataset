

# Generated at 2022-06-25 04:32:09.222236
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"\x04'\xd8"
    vault_secrets_0 = 1181
    ansible_loader_0 = AnsibleLoader(bytes_0)
    ansible_loader_1 = AnsibleLoader(bytes_0)
    file_name_0 = "/etc/passwd"
    ansible_loader_2 = AnsibleLoader(bytes_0, file_name_0)
    ansible_loader_3 = AnsibleLoader(bytes_0, file_name_0)
    ansible_loader_4 = AnsibleLoader(bytes_0, file_name_0, vault_secrets_0)
    ansible_loader_5 = AnsibleLoader(bytes_0, file_name_0, vault_secrets_0)


# Generated at 2022-06-25 04:32:13.919409
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert callable(getattr(AnsibleLoader, '__init__'))

if HAS_LIBYAML:
    # Test instantiation of class AnsibleLoader
    def test_instantiation_AnsibleLoader_0():
        try:
            AnsibleLoader('/dev/null')
        except:
            assert False

# Test instantiation of class AnsibleLoader

# Generated at 2022-06-25 04:32:23.579582
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Uncomment below line to test with LBYAML
    #ansible_loader_0 = AnsibleLoader(None)
    # Verify that the class of the object is AnsibleLoader
    assert(isinstance(ansible_loader_0, AnsibleLoader))
    # Verify that the init function has been called
    assert(isinstance(ansible_loader_0.stream, type(None)))
    # Verify that the init function has been called
    assert(isinstance(ansible_loader_0.file_name, type(None)))
    # Verify that the init function has been called
    assert(isinstance(ansible_loader_0.vault_secrets, type(None)))

# Generated at 2022-06-25 04:32:33.042277
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Constructor for class AnsibleConstructor
    ansible_constructor_0 = ansible_loader_0.AnsibleConstructor()

    # Constructor for class Resolver
    resolver_0 = ansible_loader_0.Resolver()

    # Constructor for class Parser
    parser_0 = ansible_loader_0.Parser(bytes_0)

    # Constructor for class Reader
    reader_0 = ansible_loader_0.Reader(bytes_0)

    # Constructor for class Scanner
    scanner_0 = ansible_loader_0.Scanner()


# Generated at 2022-06-25 04:32:38.770538
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"\x04'\xd8"
    ansible_loader_0 = AnsibleLoader(bytes_0)
    ansible_loader_0.add_implicit_resolver(__Anon_3f1b, None, None)
    ansible_loader_0.add_implicit_resolver(__Anon_7c94, None, None)


# Generated at 2022-06-25 04:32:46.893706
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"\x04'\xd8"
    bytes_1 = b"\x14"
    str_0 = "]@\x82f\xf8\xb8\xea\xbe\xbb\x9e\xaa\x87\x15\xec\x03\x01\x87\x10 \x9a\x9b\x99f\x00\x00\x00\x00\x00\x00\x1e"
    int_0 = 0
    ansible_loader_0 = AnsibleLoader(bytes_0)
    ansible_loader_0.get_event()
    ansible_loader_0.get_event()
    ansible_loader_0.get_event()
    ansible_loader_0.get_event()
    ansible_

# Generated at 2022-06-25 04:32:57.748479
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\x03 \x01'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    bytes_1 = b'\x01"'
    ansible_loader_1 = AnsibleLoader(bytes_1)
    str_0 = ansible_loader_1.get_single_data()
    ansible_loader_1 = AnsibleLoader(b'\x01"')
    str_1 = ansible_loader_1.get_single_data()
    bytes_2 = b'\x01"'
    ansible_loader_2 = AnsibleLoader(bytes_2)
    str_2 = ansible_loader_2.get_single_data()
    ansible_loader_2 = AnsibleLoader(b'\x01"')

# Generated at 2022-06-25 04:33:08.470985
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #
    # The AnsibleLoader class makes no use of the stream parameter.  Ensure
    # it never calls getvalue() on the stream to prevent stream from being
    # consumed.
    #
    from io import BytesIO
    from ansible.module_utils.common.yaml import HAS_LIBYAML
    if HAS_LIBYAML:
        from ansible.parsing.yaml.constructor import AnsibleConstructor
    else:
        from ansible.parsing.yaml.constructor import AnsibleConstructor as AnsibleConstructorFallback

    stream = BytesIO(b'{foo: 0}')
    obj = AnsibleLoader(stream)
    stream.seek(0)
    data = stream.read(1)
    assert obj.get_single_data() == {'foo': 0}
   

# Generated at 2022-06-25 04:33:11.008489
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Setup
    bytes_0 = b"\x04'\xd8"

    # Exercise
    ansible_loader_0 = AnsibleLoader(bytes_0)

    # Verify
    assert True



# Generated at 2022-06-25 04:33:13.194575
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"\x04'\xd8"
    ansible_loader_0 = AnsibleLoader(bytes_0)

# Generated at 2022-06-25 04:33:20.040813
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '__init__'
    file_name = '__init__'
    vault_secrets = '__init__'
    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)
    str_1 = '__init__'

if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(['-s', __file__]))

# Generated at 2022-06-25 04:33:23.645885
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print('')
    print('############# Testing AnsibleLoader ###############')
    print('Creating a Loader object')
    ansible_loader_0 = AnsibleLoader('__init__')
    print('Loading an AnsiblePlaybook')
    ansible_loader_0.get_single_data()

# Generated at 2022-06-25 04:33:24.472172
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()


# Generated at 2022-06-25 04:33:31.199694
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')

if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1:
        testcase = sys.argv[1]
    else:
        testcase = 'test_case_0'
    print('Testing AnsibleLoader.py ...')
    testcase = eval(testcase)
    testcase()
    print('%s passed' % testcase.__name__)

# Generated at 2022-06-25 04:33:35.417761
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:33:36.419695
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ldr = AnsibleLoader(None)
    assert type(ldr) == AnsibleLoader

# Generated at 2022-06-25 04:33:38.893595
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '__init__'
    stream_0 = str_0
    file_name_0 = str_0
    vault_secrets_0 = str_0
    ansible_loader_0 = AnsibleLoader(stream_0, file_name_0, vault_secrets_0)


# Generated at 2022-06-25 04:33:41.212493
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'str_0'
    str_1 = 'str_1'
    str_2 = 'str_2'
    v_0 = AnsibleLoader(str_0, str_1, str_2)
    assert v_0.file_name == str_1

# Generated at 2022-06-25 04:33:42.533665
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    inst_AnsibleLoader = AnsibleLoader()
    assert inst_AnsibleLoader is not None


# Generated at 2022-06-25 04:33:48.700862
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # !!! ATTENTION !!!
    # This is far from complete and accurate. Need to test more functions of the class.
    str_0 = '__init__'
    str_1 = 'construct_object'
    str_2 = 'construct_mapping'
    str_3 = 'construct_yaml_undefined'
    str_4 = 'construct_yaml_null'
    str_5 = 'construct_yaml_bool'
    str_6 = 'construct_yaml_int'
    str_7 = 'construct_yaml_float'
    str_8 = 'construct_yaml_binary'
    str_9 = 'construct_yaml_timestamp'
    str_10 = 'construct_yaml_omap'
    str_11 = 'construct_yaml_pairs'

# Generated at 2022-06-25 04:33:53.983228
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(str_0, file_name=None, vault_secrets=None)

# Generated at 2022-06-25 04:33:58.082890
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '__init__'
    str_1 = 'file_name'

    # This test should be expanded to test the full functionality of the constructor
    # verify that the object is instantiated correctly
    assert hasattr(AnsibleLoader, str_0)
    assert hasattr(AnsibleLoader, str_1)

# Generated at 2022-06-25 04:34:00.914219
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    w_stream = test_case_0()
    w_file_name = test_case_0()
    w_vault_secrets = test_case_0()
    AnsibleLoader(w_stream, w_file_name, w_vault_secrets)

# Generated at 2022-06-25 04:34:02.453423
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:34:06.033952
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = [None]
    file_name = [None]
    vault_secrets = [None]
    test_AnsibleLoader = AnsibleLoader(stream[0], file_name[0], vault_secrets[0])


# Generated at 2022-06-25 04:34:09.613353
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    strea ="Hello World"
    test_case_0()
    ansibleLoader = AnsibleLoader(strea)
    


# Generated at 2022-06-25 04:34:10.795409
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# Generated at 2022-06-25 04:34:17.349867
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_ansible_loader = AnsibleLoader(test_case_0())
    str_vault_secrets = ' '
    str_ansible_loader.set_vault_secrets(str_vault_secrets)


# Generated at 2022-06-25 04:34:18.102426
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(str_0)

# Generated at 2022-06-25 04:34:26.673003
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml.resolver import AnsibleUnsafeLoader
    import io

    str_1 = '__init__'

    ansible_loader = AnsibleLoader(io.StringIO(str_1), 'test')
    assert ansible_loader.constructor.file_name == 'test'
    assert not hasattr(ansible_loader.constructor, 'vault_secrets')

    ansible_unsafe_loader = AnsibleUnsafeLoader(io.StringIO(str_1), 'test')
    assert ansible_unsafe_loader.constructor.file_name == 'test'
    assert not hasattr(ansible_unsafe_loader.constructor, 'vault_secrets')

# Generated at 2022-06-25 04:34:33.099398
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = b"\x04'\xd8"
    file_name = "ansible_loader_file_name"
    vault_secrets = "ansible_loader_vault_secrets"
    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)

# Generated at 2022-06-25 04:34:35.378615
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test 1
    bytes_0 = b"\x04'\xd8"
    ansible_loader_0 = AnsibleLoader(bytes_0)


# Generated at 2022-06-25 04:34:42.394771
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"\x04'\xd8"
    ansible_loader_0 = AnsibleLoader(bytes_0)
    bytes_1 = b"\x04'\xd8"
    ansible_loader_1 = AnsibleLoader(bytes_1)
    assert ansible_loader_0 == ansible_loader_1
    assert ansible_loader_0 == ansible_loader_1
    assert ansible_loader_0 == ansible_loader_1
    assert ansible_loader_0 == ansible_loader_1
    assert ansible_loader_0 == ansible_loader_1
    assert ansible_loader_0 == ansible_loader_1
    assert ansible_loader_0 == ansible_loader_1
    assert ansible_loader_0 == ansible_loader_1
    assert ansible_

# Generated at 2022-06-25 04:34:47.409556
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    parser = Parser()  # pylint: disable=too-few-public-methods
    ansible_constructor = AnsibleConstructor()  # pylint: disable=too-few-public-methods
    bytes_0 = b"\x04'\xd8"
    ansible_loader_0 = AnsibleLoader(bytes_0)
    ansible_loader_0.check_event(parser.VersionDirectiveEvent)
    ansible_loader_0.check_event(parser.TagDirectiveEvent)
    ansible_loader_0.check_event(parser.DocumentStartEvent)
    parser.get_event()
    ansible_loader_0.check_event(parser.DocumentEndEvent)
    parser.get_event()
    ansible_loader_0.check_event(parser.StreamEndEvent)
   

# Generated at 2022-06-25 04:34:53.249843
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"\x04'\xd8"
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert isinstance(ansible_loader_0, object)
    assert isinstance(ansible_loader_0, Reader)
    assert isinstance(ansible_loader_0, Scanner)
    assert isinstance(ansible_loader_0, Parser)
    assert isinstance(ansible_loader_0, Composer)
    assert isinstance(ansible_loader_0, AnsibleConstructor)
    assert isinstance(ansible_loader_0, Resolver)


# Generated at 2022-06-25 04:34:57.182846
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b": - on\n"
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert ansible_loader_0 is not None, "Ansible loader class constructor invocation is failed."

# unit test for loadAll of class AnsibleLoader

# Generated at 2022-06-25 04:35:01.550761
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = b"\x04'\xd8"
    o = AnsibleLoader.__new__(AnsibleLoader, stream)
    assert isinstance(o, AnsibleLoader)
    assert isinstance(o, Parser)
    assert isinstance(o, AnsibleConstructor)
    assert isinstance(o, Resolver)
    assert type(o) is AnsibleLoader
    assert type(o) is not Parser
    assert type(o) is not AnsibleConstructor
    assert type(o) is not Resolver

# Unit tests for __new__ method of class AnsibleLoader

# Generated at 2022-06-25 04:35:03.889442
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\x04'
    file_name_0 = 'w]1/4 !'
    ansible_loader_0 = AnsibleLoader(bytes_0, file_name_0)

# Generated at 2022-06-25 04:35:06.206631
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert isinstance(AnsibleLoader, object)

if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:35:08.648389
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"\x04'\xd8"
    ansible_loader_0 = AnsibleLoader(bytes_0)

# vim: AnsibleConstructor: expandtab

# Generated at 2022-06-25 04:35:16.319292
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Object instantiation operation
    ansible_loader = AnsibleLoader(None)


# Generated at 2022-06-25 04:35:24.780779
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    source = b'''
---
- hosts: all
  tasks:
    - name: test
      debug:
        msg: 1
...
'''
    loader = AnsibleLoader(source)
    for entry in loader:
        assert entry['tasks'][0]['debug']['msg'] == "1"
    assert loader._file_name is None  # pylint: disable=protected-access

    # Now check with a file_name 2nd arg
    loader = AnsibleLoader(source, file_name="foo/bar.yml")
    assert loader._file_name == "foo/bar.yml"  # pylint: disable=protected-access
    loader = AnsibleLoader(source, file_name=None)
    assert loader._file_name is None  # pylint: disable=protected-access


#

# Generated at 2022-06-25 04:35:28.466931
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    with open("test/test_constructor.yaml", 'rb') as stream:

        ansible_loader_0 = AnsibleLoader(stream)
        ansible_loader_0._stream()
        ansible_loader_0.compose_node(None, None)
        ansible_loader_0.construct_document(None)
        ansible_loader_0.construct_mapping(None)

        output = open("test/test_constructor_output.yaml", 'w+')
        output.write(str(ansible_loader_0))
        output.close()

# Generated at 2022-06-25 04:35:36.246345
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # test case for constructor

    # test case for non-ascii byte stream
    bytes_0 = b"\x04\x04\x04\x04"
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert ansible_loader_0._parser is None

    # test case for unicode stream
    unicode_0 = u"\x04\x04\x04\x04"
    ansible_loader_1 = AnsibleLoader(unicode_0)
    assert ansible_loader_1._parser is None

    # test case for byte stream
    byte_stream_0 = [u'basic']
    ansible_loader_2 = AnsibleLoader(byte_stream_0)
    assert ansible_loader_2._parser is None

    # test case for empty string
    unicode_1

# Generated at 2022-06-25 04:35:43.166691
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader()
    assert isinstance(ansible_loader_0, AnsibleLoader)
    assert isinstance(ansible_loader_0, Reader)
    assert isinstance(ansible_loader_0, Scanner)
    assert isinstance(ansible_loader_0, Parser)
    assert isinstance(ansible_loader_0, Composer)
    assert isinstance(ansible_loader_0, AnsibleConstructor)
    assert isinstance(ansible_loader_0, Resolver)



# Generated at 2022-06-25 04:35:50.777923
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"\xa0\x04'\xd8"
    ansible_loader_0 = AnsibleLoader(bytes_0)

    # Test for exceptions raised in AnsibleLoader.__init__
    # Test for exception hasattr in AnsibleConstructor.__init__
    try:
        ansible_loader_0.set_file_name("file_path_0")
    except (AttributeError) as exception_0:
        assert(exception_0.args[0] == "'AnsibleLoader' object has no attribute '_AnsibleConstructor__file_name'")
        assert(str(exception_0) == "'AnsibleLoader' object has no attribute '_AnsibleConstructor__file_name'")
    # Test for exception hasattr in AnsibleConstructor.__init__

# Generated at 2022-06-25 04:35:53.318524
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_2 = AnsibleLoader(None, file_name=None, vault_secrets=None)
    assert True
    assert isinstance(ansible_loader_2, AnsibleLoader)



# Generated at 2022-06-25 04:35:56.178342
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"\x04'\xd8"
    ansible_loader_0 = AnsibleLoader(bytes_0)
    ansible_loader_1 = AnsibleLoader(bytes_0)

# Generated at 2022-06-25 04:35:57.929930
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"\x04'\xd8"
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert type(ansible_loader_0) == AnsibleLoader

# Generated at 2022-06-25 04:35:58.431414
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-25 04:36:18.142151
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"\x04'\xd8"
    ansible_loader_0 = AnsibleLoader(stream=bytes_0)
    assert not ansible_loader_0.check_data()
    assert not ansible_loader_0.compose_node()
    assert not ansible_loader_0.construct_document()
    assert ansible_loader_0.construct_mapping()
    assert not ansible_loader_0.construct_object(node=bytes_0)
    assert not ansible_loader_0.construct_pairs()
    assert not ansible_loader_0.construct_scalar()
    assert not ansible_loader_0.construct_sequence()
    assert not ansible_loader_0.compose_document()
    assert not ansible_loader_0.compose_node()

# Generated at 2022-06-25 04:36:27.204976
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert isinstance(AnsibleLoader, type)
    ansible_loader_0 = AnsibleLoader()
    ansible_loader_0 = AnsibleLoader(stream=bytes())
    ansible_loader_0 = AnsibleLoader(stream=b'\x04\r\r\n')
    ansible_loader_0 = AnsibleLoader(stream=None)
    ansible_loader_0 = AnsibleLoader(stream=1)
    ansible_loader_0 = AnsibleLoader(stream=b'')
    ansible_loader_0 = AnsibleLoader(stream=b'\x03')
    ansible_loader_0 = AnsibleLoader(stream=b'\x00')
    ansible_loader_0 = AnsibleLoader(stream=b'\x02')

# Generated at 2022-06-25 04:36:28.499911
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # constructor_0 = AnsibleLoader()
    pass


# Generated at 2022-06-25 04:36:30.662700
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"\x04'\xd8"

    # Call to AnsibleLoader()
    ansible_loader_0 = AnsibleLoader(bytes_0)

    # Call to AnsibleLoader()
    ansible_loader_0 = AnsibleLoader(bytes_0)

# Generated at 2022-06-25 04:36:40.336269
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:36:43.852550
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:36:48.640371
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_1 = b'\x04\'\xd8'
    ansible_loader_1 = AnsibleLoader(bytes_1)
    # Testing if ansible_loader_1 was successfully created
    assert ansible_loader_1 is not None

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-25 04:36:59.776415
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"\x00\x00\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\x00\x15\x00\x00\x00\x01\x00\x00\x00"
    ansible_loader_0 = AnsibleLoader(bytes_0)
    bytes_0 = b'    role: [ test1"'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    bytes_0 = b"\x00\x00\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\x00\x0f\x00\x00\x00\x00\x00\x00\x00"
    ansible_loader_0

# Generated at 2022-06-25 04:37:08.504986
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"\x04'\x7f\xf2"
    ansible_loader_0 = AnsibleLoader(bytes_0)
    ansible_loader_0_2 = AnsibleLoader(bytes_0)
    str_1 = str(ansible_loader_0_2)
    assert str_1 == '<ansible.parsing.yaml.loader.AnsibleLoader object at 0x7fee21ca80f0>'
    ansible_loader_0_3 = AnsibleLoader(bytes_0)
    dict_0 = dict(ansible_loader_0_3)
    str_2 = str(dict_0)
    assert str_2 == "{}"
    ansible_loader_0_4 = AnsibleLoader(bytes_0)

# Generated at 2022-06-25 04:37:14.779800
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # This test is a simple example of subclassing AnsibleLoader
    # Any subclass should use the same constructor, but they
    # also need to call this constructor as part of the initialization
    stream = b"{ foo: bar }"
    file_name = "foobar.yml"
    vault_secrets = {'secrets': 'vault'}
    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)
    ansible_loader_0.get_single_data()
    ansible_loader_0.get_single_data()
    ansible_loader_0.get_single_data()
    ansible_loader_0.get_single_data()
    ansible_loader_0.get_single_data()
    ansible_loader_0.get_single_data()

# Generated at 2022-06-25 04:37:43.816708
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:37:47.018184
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"\x04'\xd8"
    ansible_loader_0 = AnsibleLoader(bytes_0)


# Generated at 2022-06-25 04:37:48.666290
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    assert(AnsibleLoader)
    # test_case_0()

test_AnsibleLoader()


# Generated at 2022-06-25 04:37:52.857361
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        bytes_0 = b"\x04'\xd8"
        ansible_loader_0 = AnsibleLoader(bytes_0)
    except Exception as e:
        assert "Could not find expected ':' while scanning a simple key at line 1 column 3" in str(e)
        assert "could not find expected ':' while scanning a simple key" in str(e)
        assert "line 1, column 3:" in str(e)
    else:
        assert False

# Generated at 2022-06-25 04:37:53.931589
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # stubbed
    pass


# Generated at 2022-06-25 04:38:02.434596
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_1 = AnsibleLoader(None)

    ansible_loader_2 = AnsibleLoader({})

    ansible_loader_3 = AnsibleLoader([])

    ansible_loader_4 = AnsibleLoader(set())

    ansible_loader_5 = AnsibleLoader(frozenset())

    ansible_loader_6 = AnsibleLoader(1)

    ansible_loader_7 = AnsibleLoader(1.0)

    ansible_loader_8 = AnsibleLoader(1.1)

    ansible_loader_9 = AnsibleLoader(complex('1+1j'))

    ansible_loader_10 = AnsibleLoader(1>2)

    ansible_loader_11 = AnsibleLoader(1<2)

    ansible_loader_12 = AnsibleLoader(1!=2)

   

# Generated at 2022-06-25 04:38:04.233737
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"\x03"
    ansible_loader_0 = AnsibleLoader(bytes_0)

# Generated at 2022-06-25 04:38:07.291260
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_1 = b"\x04'\xd8"
    ansible_loader_1 = AnsibleLoader(bytes_1)
    ansible_loader_2 = AnsibleLoader(bytes_1)

    assert ansible_loader_1 == ansible_loader_2
    assert ansible_loader_1 != bytes_1

# Generated at 2022-06-25 04:38:11.281253
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'\x04'
    ansible_loader_0 = AnsibleLoader(bytes_0)
    bytes_1 = b'0\x04'
    ansible_loader_1 = AnsibleLoader(bytes_1)

# Generated at 2022-06-25 04:38:14.530474
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"\x04'\xd8"
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert ansible_loader_0

# unit test for method AnsibleLoader.get_single_data of class AnsibleLoader
# Get a single YAML document from a stream and produce the corresponding Python object.

# Generated at 2022-06-25 04:39:05.636154
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

test_AnsibleLoader()
test_case_0()

# Generated at 2022-06-25 04:39:06.207150
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-25 04:39:11.664543
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Code form JSON1:
    bytes_0 = b"\x04'\xd8"
    ansible_loader_0 = AnsibleLoader(bytes_0)

    # Code form JSON2:
    bytes_1 = b'\x04\'\xd8'
    ansible_loader_1 = AnsibleLoader(bytes_1)

    # Code form JSON3:
    bytes_2 = b"\x04'\xd8"
    ansible_loader_2 = AnsibleLoa

# Generated at 2022-06-25 04:39:16.857557
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(None)

    # Testing for exceptions raised in AnsibleLoader.__init__
    # No exception should be raised


# Generated at 2022-06-25 04:39:20.553047
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"\x04'\xd8"
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert(ansible_loader_0 is not None)

# Generated at 2022-06-25 04:39:21.031785
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True == True

# Generated at 2022-06-25 04:39:30.881132
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(
        stream=Parser(
            stream=Scanner(
                stream=Reader(stream=b"\x04'\xd8"))))
    ansible_loader_1 = AnsibleLoader(
        stream=Parser(
            stream={
                'foo': {
                    'bar': {
                        'baz': 0,
                        'buzz': (0, 0, 1),
                        'bing': {}}},
                'baz': 'string'}))
    ansible_loader_2 = AnsibleLoader(
        stream=Parser(
            stream=Scanner(
                stream=Reader(
                    stream=b"\x04'\xd8"))))

# Generated at 2022-06-25 04:39:33.464227
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True


# Generated at 2022-06-25 04:39:36.768719
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader("\x04'\xd8")
    assert ansible_loader_0.file_name is None, "AnsibleLoader's file_name not match"

# Generated at 2022-06-25 04:39:39.004952
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"'\xd8"
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert hasattr(ansible_loader_0, "resolver")



# Generated at 2022-06-25 04:41:26.378558
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test no.1
    # This test, test the case when all the parameters are undefined.
    # This should lead to a ValueError exception.
    ansible_loader_0 = AnsibleLoader(None, file_name=None)
    # Test no.2
    # This test, test the case when all the parameters are defined.
    # No exception should be raised by this.
    ansible_loader_0 = AnsibleLoader(None, file_name="71b0o7VjeC")
    # Test no.3
    # This test, test the case when all the parameters are undefined.
    # This should lead to a ValueError exception.
    ansible_loader_0 = AnsibleLoader(None)
    # Test no.4
    # This test, test the case when all the parameters are defined.
    # No exception should be raised by

# Generated at 2022-06-25 04:41:30.528133
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream_0 = b'\x06\x00\x02\x0a\x00\x06\x03\x02'
    file_name_0 = '\x02'
    vault_secrets_0 = b'\x03'
    ansible_loader_0 = AnsibleLoader(stream_0, file_name_0, vault_secrets_0)
    bytes_0 = b'\x02'
    ansible_loader_0 = AnsibleLoader(bytes_0)


# Generated at 2022-06-25 04:41:40.950122
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b'foo: bar\nbaz: 42\n'
    file_name_0 = 'test_data/ansible_file.yaml'
    ansible_loader_0 = AnsibleLoader(bytes_0, file_name=file_name_0)
    ansible_loader_1 = AnsibleLoader(bytes_0, file_name=file_name_0)
    ansible_loader_1.constructed_objects = ansible_loader_0.constructed_objects
    ansible_loader_2 = AnsibleLoader(bytes_0, file_name=file_name_0)
    ansible_loader_3 = AnsibleLoader(bytes_0, file_name=file_name_0)
    ansible_loader_3.constructed_objects = ansible_loader_2.constructed_objects
   

# Generated at 2022-06-25 04:41:43.373581
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  ansible_loader_0 = AnsibleLoader('abc')
  print(ansible_loader_0)


# Generated at 2022-06-25 04:41:49.380520
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_1 = b"\x00\x00\x00\x00\x00\x0a\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00"
    file_name_1 = "c:\\cygwin\\tmp\\ansible_module_12345.ps1"
    ansible_loader_1 = AnsibleLoader(bytes_1, file_name=file_name_1)

    file_name_2 = "c:\\cygwin\\tmp\\ansible_module_54321.ps1"
    ansible_loader_2 = AnsibleLoader(bytes_1, file_name=file_name_2)

    assert ansible_loader_1 == ansible_loader_2

# Generated at 2022-06-25 04:41:50.477545
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader
    assert ansible_loader_0 != None

# Generated at 2022-06-25 04:41:53.126811
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_0 = b"\x04'\xd8"
    ansible_loader_0 = AnsibleLoader(bytes_0)
    assert (ansible_loader_0.file_name == None), 'AnsibleLoader.file_name != None'
    assert (ansible_loader_0.vault_secrets == None), 'AnsibleLoader.vault_secrets != None'

# Generated at 2022-06-25 04:41:56.136505
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bytes_1 = b"\x04'\xd8"
    ansible_loader_0 = AnsibleLoader(bytes_1)
    ansible_loader_0.construct_yaml_int(1)



# Generated at 2022-06-25 04:42:06.186491
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        io_0 = io.BytesIO()
        ansible_loader_0 = AnsibleLoader(io_0)
    except TypeError as err:
        assert(str(err) == "io_0: expected bytes-like object, not _io.BytesIO")
    else:
        raise Exception("ExpectedTypeError")
