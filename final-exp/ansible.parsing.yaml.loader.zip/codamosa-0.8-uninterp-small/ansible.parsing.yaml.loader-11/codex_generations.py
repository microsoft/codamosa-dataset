

# Generated at 2022-06-25 04:32:04.204805
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Setup
    stream = True
    ansible_loader = AnsibleLoader(stream)

    # Verify
    assert isinstance(ansible_loader, AnsibleLoader)

# Generated at 2022-06-25 04:32:14.463086
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # set up object
    ansible_loader_0 = AnsibleLoader('file_name:')

    bool_0 = bool(ansible_loader_0)
    assert bool_0 is True

    # test __init__
    ansible_loader_0 = AnsibleLoader(None)
    ansible_loader_1 = AnsibleLoader('file_name:')
    ansible_loader_2 = AnsibleLoader('stream')

    # test __iter__
    ansible_loader_0 = AnsibleLoader(None)
    ansible_loader_1 = AnsibleLoader('file_name:')
    ansible_loader_2 = AnsibleLoader('stream')

    # test __next__
    ansible_loader_0 = AnsibleLoader(None)
    ansible_loader_1 = AnsibleLoader('file_name:')
    ans

# Generated at 2022-06-25 04:32:18.373225
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader('/etc/ansible/hosts')

#Unit test for method AnsibleLoader.get_single_data()

# Generated at 2022-06-25 04:32:25.325360
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Tests when the first param stream is set to different values.
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)
    str_0 = 'Hi!'
    ansible_loader_1 = AnsibleLoader(str_0)
    str_1 = 'Hi!'
    ansible_loader_2 = AnsibleLoader(str_1)
    str_2 = 'Hi!'
    ansible_loader_3 = AnsibleLoader(str_2)
    str_3 = 'Hi!'
    ansible_loader_4 = AnsibleLoader(str_3)

# Generated at 2022-06-25 04:32:35.284627
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:32:39.315144
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream_0 = open('../../test_data/generated/ansible-loader-data-0.yaml')
    ansible_loader_0 = AnsibleLoader(stream_0)
    stream_0.close()

# Generated at 2022-06-25 04:32:47.186693
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)

    # Test method add_constructor
    # Test arguments: (1)
    ansible_loader_0.add_constructor(bool_0)

    # Test method add_multi_constructor
    # Test arguments: (1)
    ansible_loader_0.add_multi_constructor(bool_0)

    # Test method check_data
    # Test arguments: None
    ansible_loader_0.check_data()

    # Test method compose_node
    # Test arguments: (1)
    ansible_loader_0.compose_node(bool_0)

    # Test method compose_mapping_node
    # Test arguments: (1)

# Generated at 2022-06-25 04:32:58.058119
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test 1.
    stream_0 = 0
    file_name_0 = None
    vault_secrets_0 = None
    ansible_loader_0 = AnsibleLoader(stream_0, file_name=file_name_0, vault_secrets=vault_secrets_0)
    assert isinstance(ansible_loader_0, Reader)
    assert isinstance(ansible_loader_0, Scanner)
    assert isinstance(ansible_loader_0, Parser)
    assert isinstance(ansible_loader_0, Composer)
    assert isinstance(ansible_loader_0, AnsibleConstructor)
    assert isinstance(ansible_loader_0, Resolver)

    # Test 2.
    stream_1 = 2
    file_name_1 = ''

# Generated at 2022-06-25 04:33:00.240971
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# Generated at 2022-06-25 04:33:02.789372
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = [('Stream')]
    file_name = ('File name')
    vault_secrets = [('Vault Secrets')]
    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)

# Generated at 2022-06-25 04:33:08.062285
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    # Check if class is constructed by the parent class
    assert issubclass(AnsibleLoader, AnsibleConstructor)

# Generated at 2022-06-25 04:33:13.619832
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Case 1
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)

    # Case 2
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)

    # Case 3
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)

    # Case 4
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)

# Generated at 2022-06-25 04:33:15.999290
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # No Exception raised in the test case.
    # If exception raised, fail the test case.
    test_case_0()


if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-25 04:33:18.497953
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)
    ansible_loader_0._get_ref_node_from_collection('content')
    ansible_loader_0._check_dependencies('value')

# Generated at 2022-06-25 04:33:22.778564
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)
    ansible_loader_0.add_multi_constructor('', '')
    ansible_loader_0.add_multi_path_constructor('', '')
    ansible_loader_0.get_single_data()
    ansible_loader_0.dispose()


# Generated at 2022-06-25 04:33:24.551221
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(AnsibleConstructor)
    ansible_loader_1 = AnsibleLoader(Resolver)

# Generated at 2022-06-25 04:33:27.485045
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)
    assert ansible_loader_0.filename == None
    assert ansible_loader_0.vault_secrets == None

# Verify that an exception is raised for invalid parameters

# Generated at 2022-06-25 04:33:28.224558
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader()

# Generated at 2022-06-25 04:33:30.463459
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)
    ansible_loader_0.dispose()

# Generated at 2022-06-25 04:33:39.869803
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    with open("test.yaml") as f:
        ansible_loader_1 = AnsibleLoader(f)
        result = ansible_loader_1.get_single_data()
        print(result)
        assert result['bool_var']
        assert result['list_var'][0] == 'item1'
        assert result['list_var'][1] == 'item2'
        assert result['int_var'] == 1234
        assert result['string_var'] == 'foobar'
        assert result['dict_var']['dict_var1'] == 'dict_var1'
        assert result['dict_var']['dict_var2'] == 'dict_var2'
        assert result['dict_var']['dict_var3']['dict_var4'] == 'dict_var4'
        assert result

# Generated at 2022-06-25 04:33:44.732723
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(None)


# Generated at 2022-06-25 04:33:47.257961
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)


# Generated at 2022-06-25 04:33:53.913174
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = True
    file_name_0 = None
    vault_secrets_0 = None
    ansible_loader_0 = AnsibleLoader(bool_0, file_name_0, vault_secrets_0)
    expected = True
    actual = bool_0
    if expected != actual:
        print("Failed test case 0")


# Generated at 2022-06-25 04:33:55.705306
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # verify class exists
    assert hasattr(Parser, 'load')


# Generated at 2022-06-25 04:33:58.475440
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader()
# test_case_0()

# Generated at 2022-06-25 04:34:05.581576
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = False
    ansible_loader_0 = AnsibleLoader(bool_0)

#print(test_case_0())
#print(test_AnsibleLoader())
test_AnsibleLoader()

# Generated at 2022-06-25 04:34:15.683097
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream_0 = None
    file_name_0 = None
    vault_secrets_0 = None

    ansible_loader_0 = AnsibleLoader(stream_0, file_name_0, vault_secrets_0)
    assert not isinstance(ansible_loader_0, bool)
    assert not isinstance(ansible_loader_0, int)
    assert not isinstance(ansible_loader_0, float)
    assert not isinstance(ansible_loader_0, dict)
    assert not isinstance(ansible_loader_0, list)
    assert not isinstance(ansible_loader_0, str)
    assert not isinstance(ansible_loader_0, set)
    assert not isinstance(ansible_loader_0, tuple)

# Generated at 2022-06-25 04:34:21.966704
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)
    ansible_loader_0.set_anchor
    ansible_loader_0.add_implicit_resolver
    ansible_loader_0.set_value_from_object
    ansible_loader_0.process_node(bool_0)
    ansible_loader_0.prevent_duplicates(bool_0)
    ansible_loader_0.add_constructor
    ansible_loader_0.process_scalar(bool_0)
    ansible_loader_0.process_anchor(bool_0)
    ansible_loader_0.add_constructor_resolver(bool_0, bool_0)

# Generated at 2022-06-25 04:34:26.606112
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
    ---
    - hosts: all
      tasks:
       - name: install packages
         yum:
           name: "{{ packages }}"
           state: latest
    """
    ansible_loader_0 = AnsibleLoader(data)
    print(ansible_loader_0)


if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:34:33.072221
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    d = dict(
        FOO='bar'
    )
    ansible_loader_0 = AnsibleLoader(d)
    ansible_loader_0.set_decrypt_callback(dict())
    ansible_loader_1 = AnsibleLoader(d)
    ansible_loader_1.set_file_name(str())
    ansible_loader_2 = AnsibleLoader(d)
    ansible_loader_2.set_vault_secrets(['A', 'B'])

# Generated at 2022-06-25 04:34:45.348500
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    bool_1 = True
    ansible_loader_0 = AnsibleLoader(bool_1)
    bool_2 = False
    bool_3 = False
    dict_0 = {bool_2: bool_3}
    ansible_loader_1 = AnsibleLoader(bool_1, dict_0)

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-25 04:34:52.321231
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # TODO - this should really be reworked to mock out the
    #        the vault secrets, but for now the test just makes sure that
    #        vault secrets are passed

    secrets = ['test1', 'test2']
    file_name = 'test1'

    # _AnsibleLoader will be created with class name AnsibleLoader
    _AnsibleLoader = type('AnsibleLoader', (AnsibleLoader,), dict())
    _AnsibleLoader(file_name=file_name, vault_secrets=secrets)

    # verify that vault secrets are passed
    assert secrets[0] == 'test1'
    assert secrets[1] == 'test2'
    assert file_name == 'test1'

# Generated at 2022-06-25 04:34:58.368350
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_1 = True
    ansible_loader_0 = AnsibleLoader(bool_1)
    bool_2 = True
    ansible_loader_1 = AnsibleLoader(bool_2, 'file_name_0')
    bool_3 = False
    ansible_loader_2 = AnsibleLoader(bool_3, 'file_name_1', 'vault_secrets_0')
    bool_4 = True
    ansible_loader_3 = AnsibleLoader(bool_4)
    bool_5 = True
    ansible_loader_4 = AnsibleLoader(bool_5, 'file_name_2')
    bool_6 = True
    ansible_loader_5 = AnsibleLoader(bool_6, 'file_name_3', 'vault_secrets_1')

# Generated at 2022-06-25 04:34:59.160757
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test case 0
    test_case_0()

# Generated at 2022-06-25 04:35:06.871779
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    simple_dict = {'a': 1, 'b': 2, 'c': 3}
    # Using the 'ansible' load function
    ansible_loader = AnsibleLoader(yaml.load("{a: 1, b: 2, c: 3}"), file_name="somefile")
    assert ansible_loader == simple_dict

# Generated at 2022-06-25 04:35:11.098882
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = 2
    ansible_loader_0 = AnsibleLoader(bool_0)
    ansible_loader_0.add_implicit_resolver("tag:yaml.org,2002:float", "^(?:[-+]?(?:[0-9][0-9_]*)\\.[0-9_]*(?:[eE][-+]?[0-9]+)?|\\.[0-9_]+(?:[eE][-+][0-9]+)?|[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\\.[0-9_]*|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$", list())
    ansible_loader_0.add_implicit_

# Generated at 2022-06-25 04:35:11.668670
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:35:21.804396
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = False
    ansible_loader_0 = AnsibleLoader(bool_0)
    assert not isinstance(ansible_loader_0, AnsibleLoader)
    assert not isinstance(ansible_loader_0, Resolver)
    assert not isinstance(ansible_loader_0, Composer)
    assert not isinstance(ansible_loader_0, Parser)
    assert not isinstance(ansible_loader_0, Scanner)
    assert not isinstance(ansible_loader_0, Reader)
    assert not isinstance(ansible_loader_0, AnsibleConstructor)
test_AnsibleLoader()    
    
# Function test for class AnsibleLoader

# Generated at 2022-06-25 04:35:33.295949
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Case 1
    foo = [
        '---',
        'name: foo',
        'hosts: localhost',
        'tasks:',
        '- debug:',
        '    msg: "{{ foo }}"',
    ]
    loader = AnsibleLoader(foo)
    (real, err) = next(loader)
    assert real is not None
    assert "foo" == real['tasks'][0]['debug']['msg']
    # Case 2
    foo = [
        '---',
        'name: foo',
        'hosts: localhost',
        'tasks:',
        '- name: test',
        '  debug:',
        '    msg: "{{ foo }}"',
        '  when: false',
    ]
    loader = AnsibleLoader(foo)

# Generated at 2022-06-25 04:35:34.613362
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)

# Generated at 2022-06-25 04:35:56.288704
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    myreader = Reader()
    myscanner = Scanner()
    myparser = Parser(myscanner,myreader)
    mycomposer = Composer(myparser)
    ansibleloader = AnsibleLoader(mycomposer)

# Instantiate an AnsibleLoader object
myloader = AnsibleLoader()


# Generated at 2022-06-25 04:35:57.793617
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)


# Generated at 2022-06-25 04:36:08.112839
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)
    ansible_loader_1 = AnsibleLoader(bool_0)

# Generated at 2022-06-25 04:36:16.346701
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Insure that int and float are not converted if they are in a
    # hash key.
    stream_0 = "1234.5678: abcd"
    ansible_loader_0 = AnsibleLoader(stream_0)
    stream_1 = "abcd: 1234.5678"
    ansible_loader_1 = AnsibleLoader(stream_1)

    # Check for correct exception on integer overflow
    stream_2 = "!int 18446744073709551616"
    ansible_loader_2 = AnsibleLoader(stream_2)



# Generated at 2022-06-25 04:36:18.381170
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True # TODO: implement your test here

# class

# Generated at 2022-06-25 04:36:24.515494
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test File
    from tests.unit.parsing.yaml.test_constructor import YamlTest1
    t1 = YamlTest1("yaml")
    t1.setUp()

    with open("tests/unit/parsing/yaml/test_data.yml") as of:
        ansible_loader = AnsibleLoader(of)
        ansible_loader.get_single_data()

# Generated at 2022-06-25 04:36:32.602137
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=too-many-statements
    # TODO: Cover this unit test with other unit tests
    # pylint: disable=too-many-branches
    # pylint: disable=unused-argument
    def test_case_1(self, arg, arg_1):
        test_case_0()
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-arguments
    # pylint: disable=too-many-return-statements



# Generated at 2022-06-25 04:36:35.740191
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:36:38.993461
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)
    print(ansible_loader_0)

if __name__ == "__main__":
    # Unit test for constructor of class AnsibleLoader
    test_AnsibleLoader()

# Generated at 2022-06-25 04:36:42.120394
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open('constructor_ansible_loader.yaml')
    ansible_loader = AnsibleLoader(stream)
    assert ansible_loader.file_name == 'constructor_ansible_loader.yaml'

# Generated at 2022-06-25 04:37:17.863049
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Instance creation of class AnsibleLoader with parameter ansible_loader_0
    ansible_loader_0 = AnsibleLoader(bool_0)
    assert type(ansible_loader_0) == AnsibleLoader

# Generated at 2022-06-25 04:37:22.180498
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = False
    ansible_loader_0 = AnsibleLoader(bool_0)
    bool_1 = True
    ansible_loader_1 = AnsibleLoader(bool_1)
    bool_2 = False
    ansible_loader_2 = AnsibleLoader(bool_2)

if __name__ == "__main__":
    import pytest
    pytest.main(args=['-s', '-x', __file__])

# Generated at 2022-06-25 04:37:30.844170
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = False
    AnsibleLoader_instance = AnsibleLoader(bool_0)

# class AnsibleLoader():
#     '''
#     classdocs
#     '''

#     # class NullLoader(Reader, Scanner, Parser, Composer, AnsibleConstructor,
#     # Resolver):
#     #     def __init__(self, stream, file_name=None, vault_secrets=None):
#     #         Reader.__init__(self, stream)
#     #         Scanner.__init__(self)
#     #         Parser.__init__(self)  # pylint: disable=non-parent-init-called
#     #         Composer.__init__(self)
#     #         AnsibleConstructor.__init__(
#     #             self, file_

# Generated at 2022-06-25 04:37:40.692826
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = True
    bool_1 = False
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    int_5 = 5
    str_0 = "test_loader"
    str_1 = "ansible_loader"
    list_0 = []
    list_1 = [bool_1]
    list_2 = [bool_0, bool_1]
    list_3 = [int_0, int_1, int_2]
    list_4 = [int_3, int_4, int_5]
    list_5 = [str_0, str_1]
    tuple_0 = (bool_1,)
    tuple_1 = (bool_0, bool_1)

# Generated at 2022-06-25 04:37:41.425137
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:37:47.443056
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader()
    ansible_loader_0.__init__()

if __name__ == "__main__":
    import sys, os
    sys.path.append(os.path.dirname(os.path.realpath(__file__)) + '/../../')
    from lib.yaml.constructor import AnsibleConstructor
    from lib.yaml.parser import Parser

    if HAS_LIBYAML and sys.version_info >= (2, 7):
        from lib.yaml.dumper import AnsibleDumper
        from lib.yaml.emitter import Emitter
        from lib.yaml.resolver import Resolver
    from yaml.constructor import Constructor

    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:37:48.844145
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)

# Generated at 2022-06-25 04:37:49.678236
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# Generated at 2022-06-25 04:37:55.714101
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    ansible_loader_0 = AnsibleLoader(None)
    int_0 = 1
    str_0 = AnsibleUnicode('bar')
    dict_0 = {'foo': 1}
    ansible_loader_0.add_constructor(int_0, None)
    ansible_loader_0.add_constructor(int_0, None)
    ansible_loader_0.add_multi_constructor(str_0, str_0)
    ansible_loader_0.add_multi_constructor(str_0, AnsibleSequence)
    ansible_loader_0.add_multi_constructor(str_0, AnsibleMapping)
    ansible_loader_0

# Generated at 2022-06-25 04:37:57.835463
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)


# Generated at 2022-06-25 04:39:15.632626
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream_0 = False
    file_name_0 = None
    vault_secrets_0 = True
    ansible_loader_0 = AnsibleLoader(stream_0)
    ansible_loader_0 = AnsibleLoader(stream_0, file_name_0)
    ansible_loader_0 = AnsibleLoader(stream_0, vault_secrets=vault_secrets_0)
    ansible_loader_0 = AnsibleLoader(stream_0, file_name_0, vault_secrets=vault_secrets_0)
    ansible_loader_0 = AnsibleLoader(stream_0, file_name_0)

# Generated at 2022-06-25 04:39:18.691823
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_1 = True
    bool_0 = bool_1
    bool_1 = False
    bool_2 = bool_1
    ansible_loader_0 = AnsibleLoader(bool_0)
    ansible_loader_1 = AnsibleLoader(bool_0, bool_2)
    ansible_loader_2 = AnsibleLoader(bool_0, bool_2, bool_1)



# Generated at 2022-06-25 04:39:21.688192
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)

# Generated at 2022-06-25 04:39:31.330534
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = False
    file_name = False
    vault_secrets = False
    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)
    assert isinstance(ansible_loader_0, AnsibleLoader) is True
    assert isinstance(ansible_loader_0, Resolver) is True
    assert hasattr(ansible_loader_0, 'dispatch') is True
    assert hasattr(ansible_loader_0, 'check_data_section') is True
    assert hasattr(ansible_loader_0, '_compose_document') is True
    assert hasattr(ansible_loader_0, '_construct_mapping') is True
    assert hasattr(ansible_loader_0, '_construct_sequence') is True

# Generated at 2022-06-25 04:39:34.349738
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)

# Generated at 2022-06-25 04:39:35.960252
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)

# Generated at 2022-06-25 04:39:43.897238
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  #
  # Prepare data
  #

  from ansible.parsing.yaml.constructor import AnsibleConstructor
  from ansible.module_utils.common.yaml import HAS_LIBYAML
  from ansible.parsing.vault import VaultLib
  from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
  from ansible.module_utils._text import to_native
  from ansible.parsing.yaml.constructor import SafeConstructor
  from ansible.parsing.yaml.loader import AnsibleLoader


  vault_secrets = {'v1': VaultLib({'password': 'foo'}), 'v2': VaultLib({'password': 'bar'})}

# Generated at 2022-06-25 04:39:45.062172
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    bool_0 = True
    ansible_loader_0 = AnsibleLoader(bool_0)


# Generated at 2022-06-25 04:39:51.965105
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:39:52.969930
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()
    test_case_1()
