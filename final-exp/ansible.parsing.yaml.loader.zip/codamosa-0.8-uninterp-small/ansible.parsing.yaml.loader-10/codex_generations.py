

# Generated at 2022-06-25 04:32:10.538592
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:32:16.109784
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  str_0 = 'Bo89xT!4Q4poz:6dd'
  ansible_loader = AnsibleLoader(str_0)


# pylint: disable=no-member

# Generated at 2022-06-25 04:32:23.117027
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader('KztFyI')
    assert not isinstance(ansible_loader_0, Resolver)
    assert not isinstance(ansible_loader_0, AnsibleConstructor)
    assert not isinstance(ansible_loader_0, Reader)
    assert not isinstance(ansible_loader_0, Scanner)
    assert not isinstance(ansible_loader_0, Parser)
    assert not isinstance(ansible_loader_0, Composer)


# Generated at 2022-06-25 04:32:32.854856
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'Bo89xT!4Q4poz:6dd'
    ansible_loader_0 = AnsibleLoader(str_0)
    bool_0 = ansible_loader_0.check_data()
    if bool_0:
        bool_1 = ansible_loader_0.check_plain()
    if bool_0:
        bool_2 = ansible_loader_0.check_plain()
    if bool_1:
        bool_3 = ansible_loader_0.check_plain()
    if bool_1:
        bool_4 = ansible_loader_0.check_plain()

if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:32:35.284646
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'Bo89xT!4Q4poz:6dd'
    ansible_loader_0 = AnsibleLoader(str_0)
    assert ansible_loader_0.dispose()  ==  None

# Generated at 2022-06-25 04:32:44.936194
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    r"""
    AnsibleLoader class constructor test
    """
    # Input parameters and expected results
    str_0 = ''
    ansible_loader_0 = AnsibleLoader(str_0)
    
    str_1 = 'TPz8sa7W'
    ansible_loader_1 = AnsibleLoader(str_1)
    
    str_2 = '5Hn7MxRxnP5gXc'
    ansible_loader_2 = AnsibleLoader(str_2)
    
    str_3 = '5Hn7MxRxnP5gXc'
    ansible_loader_3 = AnsibleLoader(str_3)
    
    str_4 = 'KWyO2C'
    ansible_loader_4 = AnsibleLoader(str_4)
    
    str

# Generated at 2022-06-25 04:32:47.196400
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'XT($IjZ'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_1 = AnsibleLoader(ansible_loader_0)

# Generated at 2022-06-25 04:32:58.058107
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
        Class: AnsibleLoader
        AnsibleLoader.__init__(self, stream, file_name=None, vault_secrets=None)
        AnsibleLoader.__init__(self)
    """
    str_77 = 'P5B5VYp5C:y7VuBGH'
    ansible_loader_77 = AnsibleLoader(str_77)
#   assert ansible_loader_77.__init__(self)
#   assert ansible_loader_77.__init__(self, str_77)
    str_11 = 'F%P9oD&h157p1W'
    vault_secrets_11 = ansible_loader_77
    ansible_loader_11 = AnsibleLoader(str_11, vault_secrets_11)

# Generated at 2022-06-25 04:33:08.735686
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = "[1]"
    file_name = None
    vault_secrets = None
    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)
    assert ansible_loader.get_single_data() == [1]
    
    stream = "{'a': 'b', 'c': 'd'}"
    file_name = None
    vault_secrets = None
    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)
    assert ansible_loader.get_single_data() == {'a': 'b', 'c': 'd'}
    
    stream = "{'a': 'b', 'c': 'd'}"
    file_name = 'PleaseWork'
    vault_secrets = 'NotUsedHere'
    ansible_loader = AnsibleLoader

# Generated at 2022-06-25 04:33:11.562560
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = ''
    stream_0 = ''
    file_name_0 = AnsibleLoader(str_0, stream_0)
    test_case_0()

# Generated at 2022-06-25 04:33:20.481364
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'e_E?K~'
    ansible_loader_0 = AnsibleLoader(str_0)
    str_1 = 'L@G0EjH'
    ansible_loader_1 = AnsibleLoader(str_1)
    str_2 = 'cK`|B'
    ansible_loader_2 = AnsibleLoader(str_2)


# Generated at 2022-06-25 04:33:20.976573
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-25 04:33:27.699100
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_1 = """foo
: bar
baz:
- quux
- blah
-
  test: yes
-
  - 1
  - 2
-
  -
    - 3
    - 4
  -
    - 5
    - 6"""
    ansible_loader_1 = AnsibleLoader(str_1)
    ansible_loader_1._get_pipeline()
    assert ansible_loader_1.documents[0] == {'foo': 'bar', 'baz': [u'quux', u'blah', {'test': 'yes'}, [1, 2], [[3, 4], [5, 6]]]}

# Generated at 2022-06-25 04:33:32.802398
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'Bo89xT!4Q4poz:6dd'
    ansible_loader_0 = AnsibleLoader(str_0, file_name=None)
    assert isinstance(ansible_loader_0, AnsibleLoader)

if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-25 04:33:33.227537
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    assert True

# Generated at 2022-06-25 04:33:34.758941
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'Bo89xT!4Q4poz:6dd'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_0.get_single_data()
    ansible_loader_0.compose_node()

# Generated at 2022-06-25 04:33:35.845000
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert isinstance(AnsibleLoader, Resolver)

# Generated at 2022-06-25 04:33:43.590186
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    string = 'Bo89xT!4Q4poz:6dd'
    ansible_loader = AnsibleLoader(string)
    assert ansible_loader.file_name == None
    assert ansible_loader.vault_secrets == None
    assert ansible_loader.line == 0
    assert ansible_loader.column == 0
    assert ansible_loader.is_debug == False

# Generated at 2022-06-25 04:33:45.644007
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # from ansible.parsing.yaml.constructor import AnsibleConstructor
    str_0 = 'Bo89xT!4Q4poz:6dd'
    ansible_loader_0 = AnsibleLoader(str_0)

# Generated at 2022-06-25 04:33:50.602131
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'Bo89xT!4Q4poz:6dd'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_0 = AnsibleLoader(str_0)

# Generated at 2022-06-25 04:33:54.954244
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass # There is no such test for this constructor

# Generated at 2022-06-25 04:34:02.527899
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'WY '
    vault_secrets_0 = {'booleans': 'false', 'h0z!F': '0XKPd4)Q4uq', 'dicts': {'yzKjC6U5': '', 'numbers': 99, 'bJgVOIam': '', 'true': True, 'false': False, 'nonetype': None}}
    file_name_0 = '\\Kjz(A'
    ansible_loader_0 = AnsibleLoader(str_0, vault_secrets=vault_secrets_0, file_name=file_name_0)


if __name__ == '__main__':

    test_AnsibleLoader()

# Generated at 2022-06-25 04:34:06.389980
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # AnsibleLoader is a subclass of Parser, AnsibleConstructor and Resolver.
    ansible_loader_0 = AnsibleLoader(str)
    assert isinstance(ansible_loader_0, AnsibleConstructor)
    assert isinstance(ansible_loader_0, Resolver)

# Generated at 2022-06-25 04:34:10.714851
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'dJ@;#+<g2B%L+Y'
    ansible_loader_0 = AnsibleLoader(str_0)
    assert ansible_loader_0 is not None



# Generated at 2022-06-25 04:34:11.585371
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass



# Generated at 2022-06-25 04:34:12.737211
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert(hasattr(AnsibleLoader, 'AnsibleConstructor'))

# Generated at 2022-06-25 04:34:19.395251
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    with pytest.raises(TypeError) as excinfo:
        ansible_loader_0 = AnsibleLoader('')
    assert excinfo.value.args[0] == "\'str\' object is not callable"

    with pytest.raises(TypeError) as excinfo:
        ansible_loader_0 = AnsibleLoader('', file_name='l2mdfy7ovjml2ag')
    assert excinfo.value.args[0] == "\'str\' object is not callable"

    assert ansible_loader_0.stream == 'Bo89xT!4Q4poz:6dd'
    assert ansible_loader_0.file_name == None


# Generated at 2022-06-25 04:34:27.192938
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Base properties test
    check = True
 
    stream = "test"
    vault_secrets = "namespace"
    file_name = "./tests/test_data/test.yml"
    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)

    # Check that the object is properly constructed
    if (ansible_loader.stream != stream): check = False
    if (ansible_loader.file_name != file_name): check = False
    if (ansible_loader.vault_secrets != vault_secrets): check = False

    # Check the properties properly copied from Parser
    if (ansible_loader.name != None): check = False
    if (ansible_loader.resolver != None): check = False

    assert check == True

test_case_0()


# Generated at 2022-06-25 04:34:30.233256
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    global ansible_loader
    ansible_loader = AnsibleLoader()
    global str
    str = 'test string'
    ansible_loader.construct_yaml_str(str)

# Generated at 2022-06-25 04:34:38.157354
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'Bo89xT!4Q4poz:6dd'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_0.add_constructor('!x-foo', 'B')
    ansible_loader_0.add_constructor('!y-baz', 'C')
    ansible_loader_0.add_constructor('!x-foo', 'A')
    ansible_loader_0.add_constructor('!y-bar', 'D')
    ansible_loader_0.add_constructor('!x-foo', 'E')
    ansible_loader_0.add_constructor('!x-foo', 'F')
    ansible_loader_0.add_constructor('!y-baz', 'Y')
    ansible_loader

# Generated at 2022-06-25 04:34:47.928841
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-25 04:34:52.046788
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '@pwe6(nU6z)'
    file_name_0 = 'YmY*F`pS'
    ansible_loader_0 = AnsibleLoader(str_0, file_name=file_name_0)
    ansible_loader_0.check_data()
    ansible_loader_0.get_data()
    str_1 = 'zuV7)/Q'
    file_name_1 = '$Tc%uJy^'
    ansible_loader_1 = AnsibleLoader(str_1, file_name=file_name_1)
    ansible_loader_1.check_data()
    ansible_loader_1.get_data()
    str_2 = 'a5^P(5O'

# Generated at 2022-06-25 04:34:53.604140
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    assert True
    return

# Generated at 2022-06-25 04:34:54.776471
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:34:58.254770
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:35:00.796342
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    file_name = "default"
    ansible_loader = AnsibleLoader(file_name)
    assert ansible_loader.file_name == "default"

# Generated at 2022-06-25 04:35:02.244949
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        str_0 = 'Bo89xT!4Q4poz:6dd'
        ansible_loader_0 = AnsibleLoader(str_0)
        assert True
    except:
        assert False

# Generated at 2022-06-25 04:35:08.065531
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'zr:3q3YVKtIb\t'
    str_1 = 'J^8P'
    ansible_loader_0 = AnsibleLoader(str_0, None)
    ansible_loader_0.set_list_of_vault_secrets(str_1)
    assert ansible_loader_0.get_filename() is None
    assert ansible_loader_0.get_list_of_vault_secrets() == [str_1]



# Generated at 2022-06-25 04:35:10.456071
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Tests for an instance of AnsibleLoader
    # assert_is_instance(AnsibleLoader(), "")

    # Tests for AnsibleConstructor

    # Tests for Resolver
    # assert_is_instance(Resolver(), "")
    pass



# Generated at 2022-06-25 04:35:12.811130
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  try:
    str_0 = 'Bo89xT!4Q4poz:6dd'
    ansible_loader_0 = AnsibleLoader(str_0)
  except Exception:
    assert False


# Generated at 2022-06-25 04:35:25.961266
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader('test')

# Generated at 2022-06-25 04:35:30.155737
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader('b%cp}/ezZ')
    ansible_loader_0.file_name = ':h'
    ansible_loader_0.vault_secrets = 'RYe'
    ansible_loader_0.check_data_length('S!}KH')


# Generated at 2022-06-25 04:35:37.913434
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print(AnsibleLoader.__doc__)
    print(AnsibleLoader.__init__.__doc__)
    obj = AnsibleLoader('stream', 'file_name', 'vault_secrets')
    assert 'AnsibleLoader' == obj.__class__.__name__
    assert 'stream' == obj.stream
    assert 'file_name' == obj.file_name
    obj = AnsibleLoader('stream', 'file_name')
    assert 'AnsibleLoader' == obj.__class__.__name__
    assert 'stream' == obj.stream
    assert 'file_name' == obj.file_name
    obj = AnsibleLoader('stream')
    assert 'AnsibleLoader' == obj.__class__.__name__
    assert 'stream' == obj.stream
    obj = AnsibleLoader()

# Generated at 2022-06-25 04:35:41.778475
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # h_0 = unicode('/tmp/test_file_0', encoding='UTF-8')
    # ansible_loader_0 = AnsibleLoader(None, file_name=h_0)
    # print(ansible_loader_0)
    try:
        test_case_0()
    except:
        # print(ansible_loader_0)
        print('test_AnsibleLoader: Failed')
        raise
    else:
        # print(ansible_loader_0)
        print('test_AnsibleLoader: Passed')
        pass


if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-25 04:35:44.761208
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(str)

# Generated at 2022-06-25 04:35:51.032779
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'sO#oY-p9(P7g;3a3'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_0.add_constructor('', '', '', [])
    ansible_loader_0.add_constructor('', '', '', [])
    ansible_loader_0.add_multi_constructor('!', '!', '', '', [])
    ansible_loader_0.add_multi_constructor('!', '!', '', '', [])
    ansible_loader_0.add_multi_constructor('!', '!', '', '', [])
    ansible_loader_0.add_multi_constructor('!', '!', '', '', [])

# Generated at 2022-06-25 04:35:58.594730
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    str_0 = '1Mx4z!sG.T'
    ansible_loader_0 = AnsibleLoader(str_0)
    str_1 = 'i)n(pYF$7'
    file_name_0 = 'test_case_0'
    dict_0 = {}
    vault_secrets_0 = {}
    ansible_loader_0 = AnsibleLoader(str_1, file_name_0, vault_secrets_0)

    str_2 = '><r'
    file_name_1 = 'test_case_1'
    dict_1 = {'a': 1}
    vault_secrets_1 = {'a': 1}
    ansible_loader_0 = AnsibleLoader(str_2, file_name_1, vault_secrets_1)


# Unit

# Generated at 2022-06-25 04:36:03.540501
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    with open('test_cases/ansible_loader.yml', 'r') as f:
        str_0 = f.read()
    ansible_loader_0 = AnsibleLoader(str_0, 'test_cases/ansible_loader.yml', {})
    

# Generated at 2022-06-25 04:36:14.271734
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test: attributes initialized when instantiated
    stream = 'Bo89xT!4Q4poz:6dd'
    obj = AnsibleLoader(stream)
    assert hasattr(obj, '_AnsibleConstructor__attributes')
    assert hasattr(obj, '_AnsibleConstructor__data_stack')
    assert hasattr(obj, '_AnsibleConstructor__included_file')
    assert hasattr(obj, '_AnsibleConstructor__node')
    assert hasattr(obj, '_AnsibleConstructor__tag_data')
    assert hasattr(obj, '_AnsibleConstructor__use_deprecated_aliases_exception')
    assert hasattr(obj, '_AnsibleConstructor__vault_secrets')

# Generated at 2022-06-25 04:36:16.864406
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert(loader is not None)


# Generated at 2022-06-25 04:36:52.951437
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = 'Bo89xT!4Q4poz:6dd'
    file_name = None
    vault_secrets = None
    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)
    ansible_loader_0.anchors = {}
    ansible_loader_0.data = {'x': 'z'}
    ansible_loader_0.file_name = ''
    ansible_loader_0.labels = ['Z1 %s' % str('Z2')]
    ansible_loader_0.load_all(stream)
    ansible_loader_0.vault_secrets = '3E[=@kp>vS8m|WJ^'


# Generated at 2022-06-25 04:37:00.248325
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    try:
        stream = open('./test_cases/test_case_0.yml')
        file_name = 'test_case_0.yml'
        vault_secrets = []
        ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)
    except Exception as ex:
        template = "An exception of type {0} occured. Arguments:\n{1!r}"
        message = template.format(type(ex).__name__, ex.args)
        print(message)

if __name__ == '__main__':
    test_AnsibleLoader()
    test_case_0()

# Generated at 2022-06-25 04:37:03.124958
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'cNWH9XyI!1!@Rk.Y?c'
    ansible_loader_0 = AnsibleLoader(str_0)
    str_1 = 'Hc%Q@6;)+0-g5'
    ansible_loader_1 = AnsibleLoader(str_1)

# Generated at 2022-06-25 04:37:09.648380
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'Bo89xT!4Q4poz:6dd'
    vault_secrets_0 = ''
    file_name_0 = 'eo6gRzw&$H@IW^'
    ansible_loader_0 = AnsibleLoader(str_0, file_name=file_name_0, vault_secrets=vault_secrets_0)

# Generated at 2022-06-25 04:37:14.443179
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print('Testing constructor of AnsibleLoader class')
    test_case_0()
    print('AnsibleLoader constructor passed all tests')


if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-25 04:37:18.639328
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = "---\n- name: Configure NTP\n  service: name=ntpd state=started\n"
    file_name = '/etc/ansible/roles/common/tasks/main.yml'
    vault_secrets = None
    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)
    assert ansible_loader._vault_id is None
    assert ansible_loader._file_vault_secrets is vault_secrets
    assert ansible_loader._vault_secrets is vault_secrets


# Generated at 2022-06-25 04:37:21.876753
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    _file_name = 'test_file_name'
    _vault_secrets = "test_vault_secrets"
    ansible_loader_0 = AnsibleLoader(None, _file_name, _vault_secrets)
    assert ansible_loader_0.file_name is _file_name
    assert ansible_loader_0.vault_secrets is _vault_secrets

# Generated at 2022-06-25 04:37:23.079567
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:37:29.849534
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_1 = 'M'
    ansible_loader_1 = AnsibleLoader(str_1)
    assert isinstance(ansible_loader_1, AnsibleLoader)
    assert isinstance(ansible_loader_1, Reader)
    assert isinstance(ansible_loader_1, Scanner)
    assert isinstance(ansible_loader_1, Parser)
    assert isinstance(ansible_loader_1, Composer)
    assert isinstance(ansible_loader_1, AnsibleConstructor)
    assert isinstance(ansible_loader_1, Resolver)

# Generated at 2022-06-25 04:37:33.593919
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'Bo89xT!4Q4poz:6dd'
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_0 = AnsibleLoader(str_0)

if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:38:35.115927
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'Bo89xT!4Q4poz:6dd'
    ansible_loader_0 = AnsibleLoader(str_0)

# Generated at 2022-06-25 04:38:40.965475
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'thisisastring'
    ansible_loader_0 = AnsibleLoader(str_0)

    # Variable file_name has type string
    file_name = "thisisastring"

    # Variable vault_secrets has type dict
    vault_secrets = {}

    # Variable ansible_loader_0 has type AnsibleLoader
    ansible_loader_0 = AnsibleLoader(str_0, file_name, vault_secrets)
    str_1 = 'I_2XZ8:$:r^3`wFM'
    ansible_loader_1 = AnsibleLoader(str_1)


# Generated at 2022-06-25 04:38:46.044174
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=too-few-public-methods
    class TestObject:
        def __init__(self):
            self.str_0 = 'bo89xT!4Q4poz:6dd'
            self.ansible_loader_0 = AnsibleLoader(self.str_0)
    test_object_0 = TestObject()

# Generated at 2022-06-25 04:38:46.878049
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: implement function
    pass

# Generated at 2022-06-25 04:38:51.528216
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'Bo89xT!4Q4poz:6dd'
    ansible_loader_0 = AnsibleLoader(str_0)



# Generated at 2022-06-25 04:38:53.810104
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(str_0, str_1, str_2)


# Generated at 2022-06-25 04:38:58.121190
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    file_name_0 = 'file'
    str_0 = 'pa$$w0rd'
    dict_0 = dict()
    dict_0['file_name'] = file_name_0
    dict_0['vault_secrets'] = str_0
    ansible_loader_0 = AnsibleLoader('', **dict_0)

# Generated at 2022-06-25 04:38:59.823685
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = '7x*yfBcGT,_XUzQ'
    ansible_loader_0 = AnsibleLoader(str_0)

# Generated at 2022-06-25 04:39:05.477408
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Generate object of class AnsibleLoader with parameter str_0
    str_0 = 'Bo89xT!4Q4poz:6dd'
    ansible_loader_0 = AnsibleLoader(str_0)

    # Generate object of class AnsibleLoader with parameter str_1
    str_1 = 'Bo89xT!4Q4poz:6dd'
    ansible_loader_1 = AnsibleLoader(str_1)

# Generated at 2022-06-25 04:39:11.149088
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader('stream', 'file_name')
    assert ansible_loader_0.constructor == AnsibleConstructor
    assert ansible_loader_0.resolver == Resolver
    ansible_loader_1 = AnsibleLoader(None)
    ansible_loader_2 = AnsibleLoader(None)
    ansible_loader_3 = AnsibleLoader(None, True)
    ansible_loader_4 = AnsibleLoader(None)


# Generated at 2022-06-25 04:41:09.563616
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_1 = 'LcwDF_d8W$pZzv4'
    ansible_loader_1 = AnsibleLoader(str_1)

    # __init__(self, stream, file_name=None, vault_secrets=None)
    # self.stream = stream
    # self.file_name = file_name
    # self.vault_secrets = vault_secrets
    # self.update_anchor_map()
    ## AnsibleConstructor.__init__(self, file_name=file_name, vault_secrets=vault_secrets)
    ## self.file_name = file_name
    ## self.vault_secrets = vault_secrets
    ## self.add_constructor(u'tag:yaml.org,2002:map', type(self).construct_y

# Generated at 2022-06-25 04:41:18.300431
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test the constructor with the following requirements:
    # 1) It tests the constructor with no parameters
    # 2) It tests the constructor with stream set to "stream"
    # 3) It tests the constructor with file_name set to "file_name"
    # 4) It tests the constructor with vault_secrets set to "vault_secrets"
    # 5) It tests the constructor with stream set to "stream", file_name set to "file_name", and vault_secrets set to "vault_secrets"
    ansible_loader_0 = AnsibleLoader()
    ansible_loader_1 = AnsibleLoader(stream = "stream")
    ansible_loader_2 = AnsibleLoader(file_name = "file_name")

# Generated at 2022-06-25 04:41:20.485021
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True == True

# Generated at 2022-06-25 04:41:26.930352
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'bo89xT!4Q4poz:dd'
    ansible_loader_0 = AnsibleLoader(str_0)
    # yaml.composer.Composer.get_single_node()
    # yaml.composer.Composer.get_single_data()
    # yaml.composer.Composer.get_node()
    # yaml.composer.Composer.get_data()
    # yaml.parser.Parser.check_event()
    # yaml.parser.Parser.get_event()
    # yaml.parser.Parser._parse_flow_sequence_entry()
    # yaml.parser.Parser._parse_block_sequence_entry()
    # yaml.parser.Parser.peek_token()
    # yaml.parser.

# Generated at 2022-06-25 04:41:37.352590
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    vault_secrets_0 = [
        57,
        57,
        57
    ]
    ansible_loader_0 = AnsibleLoader(';kWw:&nJ+@', vault_secrets=vault_secrets_0)


from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
from ansible.parsing.yaml.dumper import AnsibleDumper
from ansible.module_utils.common.yaml import HAS_LIBYAML, Dumper

if HAS_LIBYAML:

    class AnsibleDumper(Dumper, AnsibleDumper):
        def __init__(self, data, stream=None, **kwargs):
            # Python 2.6 and 3.x compatible
            if stream is None:
                stream = BytesIO()


# Generated at 2022-06-25 04:41:40.738208
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'Bo89xT!4Q4poz:6dd'
    ansible_loader_0 = AnsibleLoader(str_0)


if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:41:42.090630
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-25 04:41:44.461297
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_1 = '?L@3(}d!3PA9{tt;F$'
    ansible_loader_0 = AnsibleLoader(str_1)


# Generated at 2022-06-25 04:41:50.128552
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    str_0 = 'Bo89xT!4Q4poz:6dd'
    str_1 = "vault'ed string"
    str_2 = "vault'ed string"
    stream_0 = 'wWd;8$v_td(Ry&5j'
    stream_1 = 'wWd;8$v_td(Ry&5j'
    stream_2 = 'wWd;8$v_td(Ry&5j'
    stream_3 = 'wWd;8$v_td(Ry&5j'
    stream_4 = 'wWd;8$v_td(Ry&5j'
    stream_5 = 'wWd;8$v_td(Ry&5j'

# Generated at 2022-06-25 04:41:55.363208
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
   # Test 1
    str_0 = 'Bo89xT!4Q4poz:6dd'
    ansible_loader_0 = AnsibleLoader(str_0)
    assert(ansible_loader_0.check_plain() == True)
    assert(ansible_loader_0.check_double() == False)
    assert(ansible_loader_0.check_single() == False)

   # Test 2
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_0.check_plain()
    assert(ansible_loader_0.check_plain() == False)

   # Test 3
    ansible_loader_0 = AnsibleLoader(str_0)
    ansible_loader_0.check_plain()