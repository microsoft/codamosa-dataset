

# Generated at 2022-06-25 04:32:09.895871
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)

    float_1 = 428.0
    ansible_loader_1 = AnsibleLoader(float_1)

    float_2 = 923.0
    ansible_loader_2 = AnsibleLoader(float_2)

    float_3 = 2450.0
    ansible_loader_3 = AnsibleLoader(float_3)

    float_4 = 91.0
    ansible_loader_4 = AnsibleLoader(float_4)

    float_5 = 4060.0
    ansible_loader_5 = AnsibleLoader(float_5)

    float_6 = 3694.0
    ansible_loader_6 = AnsibleLoader(float_6)

    float_7 = 8550.0
    ans

# Generated at 2022-06-25 04:32:14.296688
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 7478.0
    ansible_loader_0 = AnsibleLoader(float_0)
    assert ansible_loader_0.get_single_data() == float_0
    bool_0 = ansible_loader_0.check_data()
    assert bool_0 == False
    bool_0 = ansible_loader_0.check_data()
    assert bool_0 == False
    ansible_loader_0.get_data()
    assert ansible_loader_0.get_use_raw() == False
    ansible_loader_0.get_reader()
    ansible_loader_0.get_mark()
    ansible_loader_0.get_parser()
    ansible_loader_0.get_composer()
    ansible_loader_0.get_constructor()
    ansible

# Generated at 2022-06-25 04:32:22.010296
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(float)

    ansible_loader_0 = AnsibleLoader()
    ansible_loader_0.add_path('path')
    ansible_loader_1 = AnsibleLoader(False)

    # Exception raised as "stream" input type is not valid
    ansible_loader_0 = AnsibleLoader(dict)

    # Exception raised as "stream" input type is not valid
    ansible_loader_0 = AnsibleLoader(list)

# Generated at 2022-06-25 04:32:27.848189
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.0
    object_0 = object()
    ansible_loader_0 = AnsibleLoader(float_0, object_0)

# Generated at 2022-06-25 04:32:30.999406
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print("test_AnsibleLoader: Start")
    test_case_0()
    print("test_AnsibleLoader: End")

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-25 04:32:40.867374
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Unit test 1: Testing ansible_loader_0
    ansible_loader_0 = AnsibleLoader('"software://git@github.com/ansible/ansible.git#egg=ansible"')
    assert ansible_loader_0 is not None

    # Unit test 2: Testing ansible_loader_1
    ansible_loader_1 = AnsibleLoader('"software://git@github.com/ansible/ansible.git#egg=ansible"')
    assert ansible_loader_1 is not None

    # Unit test 3: Testing ansible_loader_2
    ansible_loader_2 = AnsibleLoader('"software://git@github.com/ansible/ansible.git#egg=ansible"')
    assert ansible_loader_2 is not None

    # Unit test 4: Testing ansible_loader_3

# Generated at 2022-06-25 04:32:41.673669
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:32:46.350937
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)


# Generated at 2022-06-25 04:32:54.839616
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    float_0 = 3149.0
    stream_0 = float_0

    # Testing of '__init__(self, stream)'
    test_case_0()
    ansible_loader_0 = AnsibleLoader(stream_0)
    assert isinstance(ansible_loader_0, AnsibleLoader) == True
    assert isinstance(ansible_loader_0, Parser) == True
    assert isinstance(ansible_loader_0, AnsibleConstructor) == True
    assert isinstance(ansible_loader_0, Resolver) == True
    assert isinstance(ansible_loader_0, object) == True

# Generated at 2022-06-25 04:33:03.151449
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_1 = AnsibleLoader(float_0)
    res_0 = ansible_loader_1.check_data()
    assert res_0 == None
    str_0 = ansible_loader_1.get_data()
    assert str_0 == "{'{7,3149.0}'}"
    str_1 = ansible_loader_1.get_single_data()
    assert str_1 == "{'{7,3149.0}'}"
    ansible_loader_1 = AnsibleLoader(float_0)
    file_name_0 = ansible_loader_1.get_filename()
    assert file_name_0 == None
    ansible_loader_1 = AnsibleLoader(float_0)
    res_1 = ansible_loader_1.has_data()
    assert res

# Generated at 2022-06-25 04:33:08.860660
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(3.0)
    ansible_loader_0 = AnsibleLoader(3)
    ansible_loader_0 = AnsibleLoader("name")
    ansible_loader_0 = AnsibleLoader([3, 0])

# Generated at 2022-06-25 04:33:18.699154
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.989987092
    ansible_loader_0 = AnsibleLoader(float_0)
    assert not ansible_loader_0.file_name is None
    assert  ansible_loader_0.vault_secrets is None
    int_0 = 0
    ansible_loader_1 = AnsibleLoader(int_0, 1)
    assert  ansible_loader_1.file_name == 1
    assert ansible_loader_1.vault_secrets is None
    ansible_loader_2 = AnsibleLoader(int_0, 1, 2)
    assert ansible_loader_2.file_name == 1
    assert ansible_loader_2.vault_secrets == 2



# Generated at 2022-06-25 04:33:20.659524
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader()


# Generated at 2022-06-25 04:33:25.290789
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)
    string_0 = "AnsibleLoader(stream=3149.0)"
    assert string_0 == str(ansible_loader_0)
    ansible_loader_0 = AnsibleLoader(float_0)
    assert isinstance(ansible_loader_0, object) == True

# Generated at 2022-06-25 04:33:34.328526
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)
    assert_equal(ansible_loader_0.stream, float_0)
    assert_equal(ansible_loader_0.scanner, undefined)
    assert_equal(ansible_loader_0.composer, undefined)
    assert_equal(ansible_loader_0.resolver, undefined)
    assert_equal(ansible_loader_0.constructor, undefined)
    assert_equal(ansible_loader_0.file_name, None)
    assert_equal(ansible_loader_0.vault_secrets, undefined)
    ansible_loader_0.to_yaml()
    ansible_loader_0.from_yaml()
    ansible_loader_0.compose_node

# Generated at 2022-06-25 04:33:34.988177
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader('hash_0')


# Generated at 2022-06-25 04:33:36.255451
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(0) # TypeError (must be str, int, buffer or list)

# Generated at 2022-06-25 04:33:36.698076
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-25 04:33:40.861213
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 15.0
    ansible_loader_0 = AnsibleLoader(float_0)


# Generated at 2022-06-25 04:33:47.113049
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Testing valid case for AnsibleLoader
    ansible_loader_0 = AnsibleLoader("stream")
    assert ansible_loader_0 is not None
    
    # Testing invalid case for AnsibleLoader
    try:
        ansible_loader_1 = AnsibleLoader('1')
    except:
        ansible_loader_1 = None
    assert ansible_loader_1 is None

# Generated at 2022-06-25 04:33:54.816387
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader("GXuVCqV1J")
    ansible_loader_0.add_constructor("!vault", "FXbr8Z9XU")

# Generated at 2022-06-25 04:34:04.659447
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

  # Test File parsing
  file_0 = '/home/bharath/ansible/test/test_yaml/test_constructor.yml'
  ansible_loader_0 = AnsibleLoader(file_0)
  ansible_loader_0.compose_node()
  ansible_loader_0.construct_document(ansible_loader_0.get_node())
  ansible_loader_0.compose_node()
  ansible_loader_0.construct_document(ansible_loader_0.get_node())
  ansible_loader_0.compose_node()
  ansible_loader_0.construct_document(ansible_loader_0.get_node())
  ansible_loader_0.compose_node()

# Generated at 2022-06-25 04:34:15.259871
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '{a:b}'
    file_name = 'my_file'
    vault_secrets = 'my_secrets'
    ansible_loader = AnsibleLoader(stream=stream, file_name=file_name, vault_secrets=vault_secrets)

    assert ansible_loader._file_name == file_name
    assert ansible_loader.vault_secrets == vault_secrets
    assert ansible_loader._yaml_reader._stream.name == stream
    assert ansible_loader._yaml_reader._stream.closed == False
    assert ansible_loader._yaml_reader._stream.readable() == True
    assert ansible_loader._yaml_reader._stream.writable() == False
    assert ansible_loader.compose_node(None, None, None) == None
   

# Generated at 2022-06-25 04:34:16.993550
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-25 04:34:21.658773
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)

    print("Test AnsibleLoader class")
    print(ansible_loader_0.get_single_data())
    print(ansible_loader_0.get_yaml_data())
    print(ansible_loader_0.get_mark())
    print(ansible_loader_0.get_data())
    print(ansible_loader_0.get_encoding())
    print(ansible_loader_0.get_parser())
    print(ansible_loader_0.get_composer())


# Generated at 2022-06-25 04:34:27.765791
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(float_0)
    float_0 = float_0 - float_0
    ansible_loader_1 = AnsibleLoader(float_0)
    float_0 = float_0 - float_0
    ansible_loader_2 = AnsibleLoader(float_0)
    float_0 = float_0 - float_0
    ansible_loader_3 = AnsibleLoader(float_0)
    float_0 = float_0 - float_0
    ansible_loader_4 = AnsibleLoader(float_0)



# Generated at 2022-06-25 04:34:29.133416
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print(__name__)
    test_case_0()

# Generated at 2022-06-25 04:34:33.291291
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = 3149.0
    ansible_loader_0 = AnsibleLoader(stream)
    assert hasattr(ansible_loader_0, 'scanner') is True
    assert hasattr(ansible_loader_0, 'parser') is True
    assert hasattr(ansible_loader_0, 'composer') is True


# Generated at 2022-06-25 04:34:35.265557
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        test_case_0()
        print('unit test passed')
    except:
        print('unit test failed')

# Generated at 2022-06-25 04:34:36.714040
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:34:49.574390
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)
    if ((hasattr(ansible_loader_0, 'scanner') == 0) or (hasattr(ansible_loader_0, '__init__') == 0)):
        return False
    else:
        return True

# Generated at 2022-06-25 04:34:52.324965
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)
    assert isinstance(ansible_loader_0, AnsibleLoader)
    assert isinstance(ansible_loader_0, Parser)



# Generated at 2022-06-25 04:34:58.821226
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(5.78)
    ansible_loader_0.get_single_data()
    ansible_loader_1 = AnsibleLoader(28.19)
    ansible_loader_1.get_single_data()
    ansible_loader_2 = AnsibleLoader(53.93)
    ansible_loader_2.get_single_data()
    ansible_loader_3 = AnsibleLoader(6.93)
    ansible_loader_3.get_single_data()


# Generated at 2022-06-25 04:35:08.363807
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    stream = {"name": "World"}
    file_name = "file.yaml"
    vault_secrets = {"name": "World"}

    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)
    value = ansible_loader_0.get_single_data()
    assert value == {"name": "World"}

    stream = "name: World"
    ansible_loader_0 = AnsibleLoader(stream)
    value = ansible_loader_0.get_single_data()
    assert value == {"name": "World"}

    stream = "name: World\n"
    ansible_loader_0 = AnsibleLoader(stream)
    value = ansible_loader_0.get_single_data()
    assert value == {"name": "World"}



# Generated at 2022-06-25 04:35:11.857247
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:35:17.254364
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

if __name__ == '__main__':
    test_case_0()
    test_AnsibleLoader()

# Generated at 2022-06-25 04:35:25.805248
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    string_0 = 'int'
    string_1 = 'int'
    ansible_loader_0 = AnsibleLoader(string_1)
    assert ansible_loader_0.get_event_type() == string_0
    assert ansible_loader_0.get_token_type() == string_0
    float_0 = 0.0
    ansible_loader_1 = AnsibleLoader(float_0)
    string_1 = 'int'
    string_2 = 'int'
    ansible_loader_2 = AnsibleLoader(string_2)
    assert ansible_loader_2.get_event_type() == string_1
    assert ansible_loader_2.get_token_type() == string_1
    float_0 = 3149.0

# Generated at 2022-06-25 04:35:29.646831
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Setup a stream in place of a file
    float_0 = 3149.0
    str_0 = "Usage: ansible-doc [options] module_name"
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_1 = AnsibleLoader(float_0, str_0)

# Generated at 2022-06-25 04:35:33.665603
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 7430.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:35:36.176599
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_0.add_constructor(None, 0)
    ansible_loader_0.add_constructor(None, 0)

# Generated at 2022-06-25 04:35:52.529636
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:35:54.938799
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)


# Generated at 2022-06-25 04:36:03.667827
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_0.constructor.add_constructor('!include', lambda loader, node: loader.construct_scalar(node))
    ansible_loader_0.constructor.add_constructor('!include_vars', lambda loader, node: loader.construct_yaml_str(node))
    assert ansible_loader_0.ansible_loader_0
    assert ansible_loader_0.ansible_loader_0.constructor.add_constructor('!include', lambda loader, node: loader.construct_scalar(node)) and ansible_loader_0.ansible_loader_0.constructor.add_constructor('!include_vars', lambda loader, node: loader.construct_yaml_str(node))
    
# Unit

# Generated at 2022-06-25 04:36:06.496870
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 42.0
    AnsibleLoader.__init__(float_0)

# Generated at 2022-06-25 04:36:16.820020
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_1 = AnsibleLoader(float_0)
    assert ansible_loader_0 == ansible_loader_1
    ansible_loader_2 = AnsibleLoader(float_0)
    ansible_loader_2 = ansible_loader_2.detect_encoding(float_0)
    assert ansible_loader_0 == ansible_loader_2
    ansible_loader_2 = ansible_loader_2.dispatch('<', '<')
    assert ansible_loader_0 == ansible_loader_2
    ansible_loader_2 = ansible_loader_2.scan_to('\0')
    assert ansible_loader_0 == ansible_loader_2
   

# Generated at 2022-06-25 04:36:19.064632
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:36:23.346825
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    stream = float_0
    file_name = None
    vault_secrets = None
    ansible_loader_0 = AnsibleLoader(stream, file_name, vault_secrets)


# Generated at 2022-06-25 04:36:28.259749
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader(float())
    assert ansible_loader_0 is not None
    #assert ansible_loader_0.__dict__ == ansible_loader_1.__dict__


# Generated at 2022-06-25 04:36:32.262919
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    class MyClass0(AnsibleLoader):
        def my_method_0(self):
            return True

    my_class0 = MyClass0(None)
    my_class0.my_method_0()

# Generated at 2022-06-25 04:36:35.129688
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)


# Generated at 2022-06-25 04:37:04.414416
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader("Hello world!")
    ansible_loader_1 = AnsibleLoader("Hello world!", "file_name.yml")
    ansible_loader_2 = AnsibleLoader("Hello world!", "file_name.yml", "vault_secret")

# Generated at 2022-06-25 04:37:07.046814
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)


# Generated at 2022-06-25 04:37:10.589069
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)
    assert ansible_loader_0.stream == float_0
    assert ansible_loader_0.file_name == None
    assert ansible_loader_0.vault_secrets == None

# Generated at 2022-06-25 04:37:14.448607
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-25 04:37:15.900244
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 15859.0
    ansible_loader_0 = AnsibleLoader(float_0)


# Generated at 2022-06-25 04:37:22.460611
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_0 = AnsibleLoader('a')
    ansible_loader_1 = AnsibleLoader('d')
    ansible_loader_2 = AnsibleLoader('d')
    ansible_loader_3 = AnsibleLoader(1)
    ansible_loader_4 = AnsibleLoader('a')
    ansible_loader_5 = AnsibleLoader('a')
    ansible_loader_6 = AnsibleLoader(1)
    ansible_loader_7 = AnsibleLoader('a')
    ansible_loader_8 = AnsibleLoader(1)
    ansible_loader_9 = AnsibleLoader(1)
    ansible_loader_10 = AnsibleLoader('a')
    ansible_loader_11 = AnsibleLoader('a')
    ansible_loader_12 = AnsibleLoader('a')
    ansible_

# Generated at 2022-06-25 04:37:27.613839
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Configuring invalid arguments
    # pylint: disable=no-value-for-parameter
    # pylint: disable=too-many-function-args
    with pytest.raises(TypeError) as excinfo:
        AnsibleLoader()
    assert '' in str(excinfo.value)


# Generated at 2022-06-25 04:37:28.089446
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True


# Generated at 2022-06-25 04:37:34.480852
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  stream = 0
  file_name = 0
  vault_secrets = 0
  ansible_loader_0 = AnsibleLoader(stream,file_name,vault_secrets)
  assert ansible_loader_0.vault_secrets == 0
  stream = 10
  file_name = 4
  vault_secrets = 10
  ansible_loader_0 = AnsibleLoader(stream,file_name,vault_secrets)
  assert ansible_loader_0.vault_secrets == 10



# Generated at 2022-06-25 04:37:35.002744
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:38:38.300016
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


if __name__ == "__main__":
    import sys
    from tests.lib.testcase_utils import run_ansible_module_unit_tests

    sys.argv.pop(0)
    results = run_ansible_module_unit_tests(AnsibleLoader, sys.argv)
    exit(0 if results.wasSuccessful() else -1)

# Generated at 2022-06-25 04:38:41.068197
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # data = AnsibleLoader(stream["data"], file_name=stream.name, vault_secrets=self._vault_secrets)
    a = AnsibleLoader(stream={"data"}, file_name=None, vault_secrets=None)
    assert a != None


# Generated at 2022-06-25 04:38:42.683944
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Check that no exception raised
    AnsibleLoader(float)


# Generated at 2022-06-25 04:38:44.478481
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    if HAS_LIBYAML:
        test_case_0()

# Generated at 2022-06-25 04:38:45.511235
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_case_0()

# Generated at 2022-06-25 04:38:46.909925
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 14.0
    ansible_loader_0 = AnsibleLoader(float_0)


# Generated at 2022-06-25 04:38:56.381876
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = 3149.0
    ansible_loader_0 = AnsibleLoader(stream)
    assert ansible_loader_0.stream == stream
    assert ansible_loader_0.file_name == None
    assert ansible_loader_0.vault_secrets == None
    assert ansible_loader_0.marks == []
    assert ansible_loader_0.token == None
    assert ansible_loader_0.tokens == []
    assert ansible_loader_0.indents == [0]
    assert ansible_loader_0.state == 'stream-start'
    assert ansible_loader_0.pairs == []
    assert ansible_loader_0.flow_level == 0
    assert ansible_loader_0.strict == True

# Generated at 2022-06-25 04:39:05.663849
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Instantiate the AnsibleLoader
    # constructor for class AnsibleLoader is not implement.
    # Pass the correct parameters and do not get an error.
    # ansible_loader_1 = AnsibleLoader(float)

    # Pass unexpected parameters and do not get an error.
    ansible_loader_2 = AnsibleLoader(float)

    # Pass and get attribute of class AnsibleLoader.
    float_0 = float
    ansible_loader_3 = AnsibleLoader(float_0)
    ansible_loader_3.file_name = 'dir/file'
    ansible_loader_3.file_path = 'dir/file'
    if hasattr(ansible_loader_3, 'vault_secrets'):
        ansible_loader_3.vault_secrets = ansible_loader_3.vault_sec

# Generated at 2022-06-25 04:39:14.022354
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = 3149.0
    file_name = 3149.0
    vault_secrets = 3149
    assert not isinstance(AnsibleLoader, object)
    assert issubclass(AnsibleLoader, object)
    assert not issubclass(AnsibleLoader, type)
    assert not issubclass(AnsibleLoader, (str,))
    assert not issubclass(AnsibleLoader, [3149])
    assert not issubclass(AnsibleLoader, (str, dict))
    assert not issubclass(AnsibleLoader, dict)
    assert issubclass(AnsibleLoader, (Reader,))
    assert not issubclass(AnsibleLoader, (float,))
    assert issubclass(AnsibleLoader, (float, str))

# Generated at 2022-06-25 04:39:15.031350
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_loader_0 = AnsibleLoader("")
    assert yaml_loader_0.file_name == None

# Generated at 2022-06-25 04:41:09.538532
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = [0.75]
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_1 = AnsibleLoader(float_0)

    # Test case for comparing 2 objects
    assert ansible_loader_0 == ansible_loader_1
    assert ansible_loader_0 is not ansible_loader_1
    assert hash(ansible_loader_0) == hash(ansible_loader_1)

    # Test case for the evaluate function
    ansible_loader_0.evaluate(ansible_loader_1)
    assert ansible_loader_1 is not ansible_loader_0
    assert hash(ansible_loader_0) == hash(ansible_loader_1)

    # Test case for the get_single_data function
    ansible_loader_0.get_single

# Generated at 2022-06-25 04:41:11.126480
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert callable(AnsibleLoader)

# Generated at 2022-06-25 04:41:18.680626
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    s = 'Hello nlj'
    ansible_loader_0 = AnsibleLoader(s)
    assert ansible_loader_0.construct_yaml_str.__name__ == 'construct_yaml_str'
    assert ansible_loader_0.construct_yaml_float.__name__ == 'construct_yaml_float'
    assert ansible_loader_0.construct_yaml_mapping.__name__ == 'construct_yaml_mapping'
    assert ansible_loader_0.construct_yaml_seq.__name__ == 'construct_yaml_seq'
    assert ansible_loader_0.construct_yaml_int.__name__ == 'construct_yaml_int'

# Generated at 2022-06-25 04:41:20.901480
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 0.6475603950890003
    ansible_loader_0 = AnsibleLoader(float_0)
    # ansible_loader_0.load()



# Generated at 2022-06-25 04:41:22.278820
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:41:22.728238
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-25 04:41:24.117264
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)
    assert ansible_loader_0 is not None

# Generated at 2022-06-25 04:41:29.200419
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    f2 = 3149.0
    f3 = {'bac':'1', 'la':'2'}
    f1 = AnsibleLoader(f2,vault_secrets=f3)

# Generated at 2022-06-25 04:41:29.959362
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)

# Generated at 2022-06-25 04:41:33.639296
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    float_0 = 3149.0
    ansible_loader_0 = AnsibleLoader(float_0)
    ansible_loader_0.decode()
