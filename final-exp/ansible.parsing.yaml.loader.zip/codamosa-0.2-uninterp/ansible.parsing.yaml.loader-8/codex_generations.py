

# Generated at 2022-06-17 06:43:46.766687
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    foo: 1
    bar:
      baz: 3
    """

    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), dict)
    assert isinstance(loader.get_single_data()['foo'], int)
    assert isinstance(loader.get_single_data()['bar']['baz'], int)

    data = """
    foo: 1
    bar:
      baz: 3
    """

    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), dict)

# Generated at 2022-06-17 06:43:58.169486
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            return AnsibleUnicode(self.construct_scalar(node))

    class TestDumper(AnsibleDumper):
        def represent_data(self, data):
            return self.represent_scalar(u'tag:yaml.org,2002:str', data)

    data = u'unicode string'
    stream = TestLoader(data)
    assert stream.get_single_data() == data

    data = u'unicode string'
    stream = TestLoader(data)
    assert stream.get_single_data() == data

   

# Generated at 2022-06-17 06:44:09.094669
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - hosts:
        - localhost
      tasks:
        - name: test
          debug:
            msg: "{{ test_var }}"
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert isinstance(data, AnsibleSequence)
    assert len(data) == 1
    assert isinstance(data[0], AnsibleMapping)

# Generated at 2022-06-17 06:44:20.613282
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    if sys.version_info >= (3, 0):
        unicode = str
    data = '''
    foo: 1
    bar:
      baz: 3
      qux:
        - 1
        - 2
        - 3
    '''
    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert isinstance(data, dict)
    assert isinstance(data['foo'], int)
    assert isinstance(data['bar'], dict)
    assert isinstance(data['bar']['baz'], int)
    assert isinstance(data['bar']['qux'], list)

# Generated at 2022-06-17 06:44:29.766713
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleLoader(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_constructor(self):
            ''' test constructor '''
            stream = '''
            - hosts: all
              gather_facts: no
              tasks:
              - name: test
                debug: msg="hello world"
            '''
            loader = Ans

# Generated at 2022-06-17 06:44:40.744255
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test AnsibleLoader with a string
    data = '''
    - hosts: localhost
      tasks:
        - name: test
          debug:
            msg: hello
    '''
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == {'hosts': 'localhost', 'tasks': [{'debug': {'msg': 'hello'}, 'name': 'test'}]}

    # Test AnsibleLoader with a file
    loader = AnsibleLoader(open('test/unit/parsing/yaml/test_loader.yml'))
    assert loader.get_single_data() == {'hosts': 'localhost', 'tasks': [{'debug': {'msg': 'hello'}, 'name': 'test'}]}

# Generated at 2022-06-17 06:44:50.531036
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO as StringIO
    else:
        from io import StringIO

    stream = StringIO(u'---\n- hosts: localhost\n  tasks:\n    - name: test\n      debug: msg="{{ ansible_date_time.iso8601 }}"\n')
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {'hosts': 'localhost', 'tasks': [{'name': 'test', 'debug': {'msg': '{{ ansible_date_time.iso8601 }}'}}]}

# Generated at 2022-06-17 06:45:02.694268
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY3

    if PY3:
        unicode = str

    vault_password = '$6$foobar'
    vault = VaultLib(vault_password)
    data = {'foo': 'bar', 'baz': 'qux'}
    encrypted_data = vault.encrypt(unicode(AnsibleDumper(None, default_flow_style=False).encode(data)))
    stream = AnsibleVaultEncryptedUnicode(encrypted_data).data

# Generated at 2022-06-17 06:45:15.338942
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor
    data = '''
    foo:
      bar:
        baz:
          - 1
          - 2
          - 3
    '''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), dict)
    assert isinstance(loader.get_single_data()['foo']['bar']['baz'][0], AnsibleUnicode)
    assert isinstance(loader.get_single_data()['foo']['bar']['baz'][1], AnsibleUnicode)

# Generated at 2022-06-17 06:45:28.039037
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:45:41.933318
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-17 06:45:53.464503
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:46:05.057652
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    if PY3:
        unicode = str

    data = u"""
    foo: 1
    bar:
      baz: 3
      bam: [ a, b, c ]
    """

    stream = StringIO(data)
    loader = AnsibleLoader(stream)

# Generated at 2022-06-17 06:46:12.121441
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    stream = StringIO(u"---\n- hosts: localhost\n  tasks:\n  - debug: msg='hello world'\n")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == [{u'hosts': u'localhost', u'tasks': [{u'debug': {u'msg': u'hello world'}}]}]

# Generated at 2022-06-17 06:46:26.367267
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test that the AnsibleLoader class is working properly
    data = '''
    foo:
      - bar: baz
      - bam: bop
    '''

    data_out = AnsibleLoader(data).get_single_data()
    assert data_out == {'foo': [{'bar': 'baz'}, {'bam': 'bop'}]}

    # Test that the AnsibleLoader class is working properly with a vault secret

# Generated at 2022-06-17 06:46:36.740774
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB


# Generated at 2022-06-17 06:46:47.058334
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor

# Generated at 2022-06-17 06:46:54.252243
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
    foo:
      - bar
      - baz
    '''

    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), dict)
    assert isinstance(loader.get_single_data()['foo'], list)
    assert isinstance(loader.get_single_data()['foo'][0], AnsibleUnicode)
    assert isinstance(loader.get_single_data()['foo'][1], AnsibleUnicode)

# Generated at 2022-06-17 06:47:05.405563
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:47:13.908837
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    stream = StringIO(u"---\n- hosts: all\n  tasks:\n  - name: test\n    debug: msg=\"{{ '{' }} ansible_facts.distribution {{ '}' }}\n")
    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-17 06:47:28.049806
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVault

# Generated at 2022-06-17 06:47:40.047553
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test with a string
    data = '''
    - hosts: localhost
      tasks:
        - name: test
          ping:
    '''
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == [{'hosts': 'localhost', 'tasks': [{'name': 'test', 'ping': None}]}]

    # Test with a file
    import os
    import tempfile
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        f.write(data)
    loader = AnsibleLoader(path)
    assert loader.get_single_data() == [{'hosts': 'localhost', 'tasks': [{'name': 'test', 'ping': None}]}]
    os.remove(path)

# Generated at 2022-06-17 06:47:49.662520
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes

    vault_password = '$ecret'
    vault = VaultLib(vault_password)
    vault_data = vault.encrypt(b'$ecret')
    vault_data = to_bytes(vault_data)
    vault_data = vault_data.decode('utf-8')
    vault_data = AnsibleVaultEncryptedUnicode(vault_data)


# Generated at 2022-06-17 06:48:02.442344
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('test').get_single_data(), AnsibleUnicode)

    # Test AnsibleSequence
    assert isinstance(AnsibleLoader('- test').get_single_data(), AnsibleSequence)

    # Test AnsibleMapping
    assert isinstance(AnsibleLoader('test: test').get_single_data(), AnsibleMapping)

    # Test AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:48:13.514065
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test AnsibleLoader
    data = '''
    ---
    - hosts: all
      gather_facts: no
      tasks:
      - name: test
        debug: msg="{{ 'test' }}"
    '''
    loader = AnsibleLoader(data)
    result = loader.get_single_data()

# Generated at 2022-06-17 06:48:26.997024
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:48:32.353645
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

    data = '''
    foo: 1
    bar:
      baz: 3
    '''

    data2 = '''
    foo: 1
    bar:
      baz: 3
    '''

    data3 = '''
    foo: 1
    bar:
      baz: 3
    '''


# Generated at 2022-06-17 06:48:39.204375
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
    foo:
      - 1
      - 2
      - 3
    '''

    data_out = '''foo: [1, 2, 3]\n'''

    # test the constructor
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == {'foo': [1, 2, 3]}

    # test the dumper
    dumper = AnsibleDumper()
    assert dumper.dump(loader.get_single_data()) == data_out

    # test the round trip

# Generated at 2022-06-17 06:48:48.311154
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

    data = '''
    foo: bar
    baz:
      - 1
      - 2
      - 3
    '''

    data_expected = {
        'foo': 'bar',
        'baz': [1, 2, 3]
    }

    data_returned = yaml.load(data, Loader=TestAnsibleLoader)

    assert data_expected == data

# Generated at 2022-06-17 06:49:07.011624
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    import unittest

    from ansible.parsing.yaml.objects import AnsibleUnicode

    class TestAnsibleLoader(unittest.TestCase):

        def setUp(self):
            self.loader = AnsibleLoader(None)

        def tearDown(self):
            self.loader = None

        def test_construct_yaml_str(self):
            node = self.loader.construct_yaml_str(None)
            self.assertIsInstance(node, AnsibleUnicode)

        def test_construct_yaml_seq(self):
            node = self.loader.construct_yaml_seq(None)
            self.assertIsInstance(node, list)

        def test_construct_yaml_map(self):
            node = self.loader.construct_y

# Generated at 2022-06-17 06:49:29.127955
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB

# Generated at 2022-06-17 06:49:41.503782
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleScalar

    # Test for AnsibleUnicode
    assert isinstance(AnsibleUnicode('test'), AnsibleUnicode)
    assert isinstance(AnsibleUnicode(u'test'), AnsibleUnicode)
    assert isinstance(AnsibleUnicode(b'test'), AnsibleUnicode)

# Generated at 2022-06-17 06:49:51.350182
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:49:59.328346
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))


# Generated at 2022-06-17 06:50:07.515765
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

    data = '''
    foo: 1
    bar:
      baz: 3
    '''

    # Test round-trip for unicode handling
    data2 = AnsibleDumper(None, default_flow_style=False).dump(TestAnsibleLoader(data).get_single_data())
    assert data == data2

# Generated at 2022-06-17 06:50:16.717136
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    if sys.version_info >= (3, 0):
        unicode = str

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return self.construct_scalar(node)

        def construct_undefined(self, node):
            raise Exception('Undefined constructor called')

    data = '''
    foo: 1
    bar:
      baz: 3
    '''

    # test loading
    t = TestAnsibleLoader(data)
    d = t.get_single_data()

# Generated at 2022-06-17 06:50:26.963546
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)
    assert isinstance(loader, Parser)
    assert isinstance(loader, AnsibleConstructor)
    assert isinstance(loader, Resolver)

    # Test the AnsibleConstructor
    assert loader.get_single_data() is None
    assert loader.get_constructor('tag:yaml.org,2002:str') is AnsibleConstructor.construct_yaml_str
    assert loader.get_constructor('tag:yaml.org,2002:map') is AnsibleConstructor.construct_yaml_map

# Generated at 2022-06-17 06:50:32.433553
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # test AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

    # test AnsibleSequence
    assert isinstance(AnsibleLoader('').construct_yaml_seq(''), AnsibleSequence)

    # test AnsibleMapping
    assert isinstance(AnsibleLoader('').construct_yaml_map(''), AnsibleMapping)

    # test AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:50:41.290641
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    foo:
      - bar:
          baz: 1
      - bar:
          baz: 2
    '''

    data = AnsibleLoader(yaml_str).get_single_data()
    assert data == {'foo': [{'bar': {'baz': 1}}, {'bar': {'baz': 2}}]}

    # Check that the data is still a AnsibleUnicode object
    assert isinstance(data['foo'][0]['bar']['baz'], AnsibleUnicode)

    # Check that the data is still a AnsibleUnicode object after dumping and loading it
    data

# Generated at 2022-06-17 06:50:53.121470
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars import combine_vars
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM

# Generated at 2022-06-17 06:51:20.015270
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-17 06:51:29.260614
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.yaml import Parser
    from ansible.module_utils.common.yaml import HAS_LIBYAML
    from yaml.resolver import Resolver

    if HAS_LIBYAML:
        assert issubclass(AnsibleLoader, Parser)
        assert issubclass(AnsibleLoader, AnsibleConstructor)
        assert issubclass(AnsibleLoader, Resolver)
    else:
        from yaml.composer import Composer
        from yaml.reader import Reader
        from yaml.scanner import Scanner
        from yaml.parser import Parser


# Generated at 2022-06-17 06:51:40.517380
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secrets = [VaultSecret('secret', 'password')]
    vault = VaultLib(vault_secrets)
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)

    # test AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:51:52.503850
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleLoader with a simple string
    data = '''
    foo: bar
    '''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    assert loader.get_single_data() == {'foo': 'bar'}

    # Test AnsibleLoader with a simple list
    data = '''
    - foo
    - bar
    '''
    loader = AnsibleLoader(data)

# Generated at 2022-06-17 06:52:01.014571
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secrets = [VaultSecret('secret1', 'password1', 1), VaultSecret('secret2', 'password2', 2)]
    vault = VaultLib(vault_secrets)

    # test AnsibleLoader

# Generated at 2022-06-17 06:52:10.758526
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence


# Generated at 2022-06-17 06:52:18.849096
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar
      - baz
    '''

    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleUnicode)

    dumper = AnsibleDumper()
    assert dumper.represent_data(loader.get_single_data()) == data

# Generated at 2022-06-17 06:52:29.319283
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode
    from ansible.parsing.yaml.nodes import AnsibleMappingNode

# Generated at 2022-06-17 06:52:39.315691
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    if sys.version_info >= (3, 0):
        unicode = str

    # Test the constructor
    data = """
    foo: 1
    bar:
      baz: 3
      boo: [ 4, 5, 6 ]
    """

    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), dict)
    assert loader.get_single_data() == {'foo': 1, 'bar': {'baz': 3, 'boo': [4, 5, 6]}}

    # Test the constructor with a file name

# Generated at 2022-06-17 06:52:45.124881
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - foo: bar
    - baz:
        - 1
        - 2
        - 3
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()

    assert isinstance(data, AnsibleSequence)
    assert len(data) == 2

    assert isinstance(data[0], AnsibleMapping)
    assert isinstance(data[0]['foo'], AnsibleUnicode)

# Generated at 2022-06-17 06:53:27.810442
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    if sys.version_info >= (3, 0):
        unicode = str

    data = """
    foo: 1
    bar:
      baz: 3
      boo: [ "a", "b", "c" ]
    """

    data2 = """
    foo: 1
    bar:
      baz: 3
      boo: [ "a", "b", "c" ]
    """

    data3 = """
    foo: 1
    bar:
      baz: 3
      boo: [ "a", "b", "c" ]
    """

   

# Generated at 2022-06-17 06:53:39.588361
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    ---
    - hosts: localhost
      tasks:
      - name: test
        debug:
          msg: "{{ '{{' }} foo {{ '}}' }}"
    '''

    loader = AnsibleLoader(data)
    dumper = AnsibleDumper()
    result = dumper.dump(loader.get_single_data())
    assert result == data

    data = '''
    ---
    - hosts: localhost
      tasks:
      - name: test
        debug:
          msg: "{{ '{{' }} foo {{ '}}' }}"
    '''

    loader = AnsibleLoader(data)