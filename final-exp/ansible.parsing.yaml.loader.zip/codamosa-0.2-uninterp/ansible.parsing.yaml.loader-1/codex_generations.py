

# Generated at 2022-06-17 06:43:46.273980
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:43:58.082271
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:44:09.022058
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:44:20.571313
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:44:21.093386
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-17 06:44:27.788502
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:44:39.535749
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:44:51.006480
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUn

# Generated at 2022-06-17 06:45:02.737863
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedYaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedJson
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedText

# Generated at 2022-06-17 06:45:11.651423
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar:
          baz: 1
      - bar:
          baz: 2
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert isinstance(data['foo'][0]['bar']['baz'], AnsibleUnicode)
    assert isinstance(data['foo'][1]['bar']['baz'], AnsibleUnicode)

    dumper = AnsibleDumper()
    assert dumper.represent_scalar('tag:yaml.org,2002:str', '1') == '1'

# Generated at 2022-06-17 06:45:27.819176
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import tempfile
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    yaml_file = os.path.join(tmpdir, "test.yaml")
    with open(yaml_file, "w") as f:
        f.write("""
---
- hosts: localhost
  tasks:
  - name: test
    debug:
      msg: "{{ test_var }}"
""")

    # Create a temporary file to store the vault password
    vault_password_file = os.path.join(tmpdir, "vault_password")
    with open(vault_password_file, "w") as f:
        f.write("vault_password")

    #

# Generated at 2022-06-17 06:45:40.155139
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    import yaml

    # Create a vault password file
    vault_password_file = os.path.join(os.path.dirname(__file__), 'vault_password')
    with open(vault_password_file, 'wb') as f:
        f.write('ansible')

    # Create a vault secrets object
    vault_secrets = [VaultLib(vault_password_file)]

    # Create a loader
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)

    # Create a dumper
    dumper = AnsibleDumper

# Generated at 2022-06-17 06:45:52.298219
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test for AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

    # Test for AnsibleSequence

# Generated at 2022-06-17 06:45:59.233027
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.yaml import HAS_LIBYAML

    if HAS_LIBYAML:
        from yaml.constructor import ConstructorError
    else:
        from yaml.composer import ComposerError as ConstructorError

    # Test AnsibleLoader.construct_yaml_str
    assert isinstance(AnsibleLoader('').construct_yaml_str(None), AnsibleUnicode)
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)
    assert isinstance(AnsibleLoader('').construct_yaml_str('foo'), AnsibleUnicode)

# Generated at 2022-06-17 06:46:10.280441
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with vault_secrets

# Generated at 2022-06-17 06:46:18.906495
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString

# Generated at 2022-06-17 06:46:28.310383
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes

    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt(to_bytes('test'))

    data = """
    test: !vault |
          $ANSIBLE_VAULT;1.1;AES256
          %s
          """ % vault_text

    loader = AnsibleLoader(data)
    loader.vault_secrets = vault_password
    result = loader.get_single_data()

# Generated at 2022-06-17 06:46:37.193244
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleUnsafeBytes
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    from ansible.parsing.yaml.objects import AnsibleScalar
    from ansible.parsing.yaml.objects import AnsibleScalarBoolean
    from ansible.parsing.yaml.objects import Ansible

# Generated at 2022-06-17 06:46:43.630174
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedBytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedMapping

# Generated at 2022-06-17 06:46:44.059523
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-17 06:46:52.573706
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (2, 7):
        from io import StringIO
    else:
        from StringIO import StringIO

    stream = StringIO(u'{ foo: bar }')
    loader = AnsibleLoader(stream)
    assert loader.get_single_data() == {u'foo': u'bar'}

# Generated at 2022-06-17 06:46:54.617466
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-17 06:47:05.835920
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import PY3

    if PY3:
        unicode = str

    class MyDumper(AnsibleDumper):
        pass

    class MyLoader(AnsibleLoader):
        pass


# Generated at 2022-06-17 06:47:18.184524
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from io import StringIO

    vault_password = '$ecret'
    vault = VaultLib(vault_password)
    vault_data = vault.encrypt('$ecret')
    vault_data = vault_data.decode('utf-8')
    vault_data = vault_data.replace('\n', '')
    vault_data = vault_data.replace('\r', '')
    vault_data = vault_data.replace('\\', '\\\\')
    vault_data = vault_data.replace('"', '\\"')

# Generated at 2022-06-17 06:47:27.314445
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:47:39.116807
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    loader = AnsibleLoader(None)

    assert isinstance(loader.construct_yaml_str(None), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_seq(None), AnsibleSequence)
    assert isinstance(loader.construct_yaml_map(None), AnsibleMapping)
    assert isinstance(loader.construct_yaml_str(None), AnsibleUnicode)

# Generated at 2022-06-17 06:47:49.639082
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test that AnsibleLoader can load a string
    loader = AnsibleLoader("---\nfoo: bar")
    data = loader.get_single_data()
    assert data == {'foo': 'bar'}

    # Test that AnsibleLoader can load a string with a vault string

# Generated at 2022-06-17 06:48:01.041325
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test the constructor of class AnsibleLoader
    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_yaml_str(None), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_seq(None), AnsibleSequence)
    assert isinstance(loader.construct_yaml_map(None), AnsibleMapping)
    assert isinstance(loader.construct_yaml_omap(None), AnsibleMapping)

# Generated at 2022-06-17 06:48:06.765409
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO

    stream = BytesIO(b"---\n- hosts: localhost\n  tasks:\n  - debug: msg='hello world'\n")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {'hosts': 'localhost', 'tasks': [{'debug': {'msg': 'hello world'}}]}

# Generated at 2022-06-17 06:48:17.571942
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleLoader.construct_yaml_map
    # Test AnsibleLoader.construct_yaml_seq
    # Test AnsibleLoader.construct_yaml_str
    # Test AnsibleLoader.construct_yaml_int
    # Test AnsibleLoader.construct

# Generated at 2022-06-17 06:48:40.014133
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib

    # Create a VaultLib object to encrypt and decrypt the data
    vault_password = '$ecret'
    vault = VaultLib(vault_password)

    # Create a AnsibleLoader object to load the data
    loader = AnsibleLoader(None, vault_secrets=vault.secrets)

    # Create a AnsibleDumper object to dump the data
    dumper = AnsibleDumper()

    # Create a AnsibleVaultEncryptedUnicode object to encrypt the data
    encrypted_data = AnsibleVaultEncryptedUnicode(u'$ecret', vault)

    #

# Generated at 2022-06-17 06:48:52.660291
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar
      - baz
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert isinstance(data['foo'][0], AnsibleUnicode)
    assert isinstance(data['foo'][1], AnsibleUnicode)

    dumper = AnsibleDumper()
    output = dumper.dump(data)
    assert output == data

# Generated at 2022-06-17 06:49:09.725102
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import tempfile
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    yaml_file = os.path.join(tmpdir, "test.yml")
    with open(yaml_file, 'w') as f:
        f.write("""
        ---
        - hosts: localhost
          tasks:
            - name: test
              debug:
                msg: "{{ lookup('env', 'HOME') }}"
        """)

    # Create a vault password file
    vault_password_file = os.path.join(tmpdir, "vault_password")
    with open(vault_password_file, 'w') as f:
        f.write("vaultpassword")



# Generated at 2022-06-17 06:49:15.600744
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
   

# Generated at 2022-06-17 06:49:23.820649
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        import __builtin__ as builtins
    else:
        import builtins
    builtins.__dict__['__ansible_module__'] = 'setup'
    loader = AnsibleLoader(None)
    assert loader.__dict__['_file_name'] == 'setup'

# Generated at 2022-06-17 06:49:30.809184
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test for AnsibleLoader.construct_yaml_map
    def test_construct_yaml_map():
        from ansible.parsing.yaml.objects import AnsibleMapping

# Generated at 2022-06-17 06:49:38.424654
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test the constructor

# Generated at 2022-06-17 06:49:47.732402
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secrets = [VaultSecret('secret', 'password')]
    vault = VaultLib(vault_secrets)

    data = {'foo': 'bar', 'baz': 'qux'}
    encrypted_data = vault.encrypt(data)

    loader = AnsibleLoader(encrypted_data, vault_secrets=vault_secrets)
    decrypted_data = loader.get_single_data()

    assert decrypted_data == data

    # Test that the vault secrets are not stored in the loader


# Generated at 2022-06-17 06:49:57.295208
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    if sys.version_info >= (3, 0):
        unicode = str

    # Test AnsibleLoader.construct_yaml_map
    yaml_str = '''
        foo:
          bar: 1
          baz:
            - 2
            - 3
        '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['foo'], AnsibleMapping)


# Generated at 2022-06-17 06:50:06.967220
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
   

# Generated at 2022-06-17 06:50:35.859143
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
   

# Generated at 2022-06-17 06:50:45.006480
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    import io

    stream = io.StringIO(u"---\n- hosts: localhost\n  tasks:\n  - name: test\n    debug: msg=\"{{ '{{' }} foo {{ '}}' }}\"\n")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data[0]['tasks'][0]['debug']['msg'] == AnsibleUnicode("{{ foo }}")


# Generated at 2022-06-17 06:50:55.913125
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB

# Generated at 2022-06-17 06:51:07.684506
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:51:17.241517
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test constructor of class AnsibleLoader
    #
    # Expected:
    #   - AnsibleLoader object is created
    #   - AnsibleLoader object has attribute '_mapping_tag'
    #   - AnsibleLoader object has attribute '_sequence_tag'
    #   - AnsibleLoader object has attribute '_file_name'
    #   - AnsibleLoader object has attribute '_vault_secrets'
    #   - AnsibleLoader object has attribute '_vault'
    #   - AnsibleLoader object has attribute '_vault_password'
    #   - AnsibleLoader object has attribute '_vault_version'
    #

# Generated at 2022-06-17 06:51:25.931363
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256SIV
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:51:33.897394
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-17 06:51:43.172295
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import tempfile
    import unittest

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class TestAnsibleLoader(unittest.TestCase):
        def setUp(self):
            self.loader = AnsibleLoader(None)

        def tearDown(self):
            pass


# Generated at 2022-06-17 06:51:49.352953
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test constructor of class Ans

# Generated at 2022-06-17 06:51:57.665509
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar:
          baz: qux
      - bar:
          baz: qux
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert data['foo'][0]['bar']['baz'] == 'qux'
    assert data['foo'][1]['bar']['baz'] == 'qux'

    # test the dumper
    dumper = AnsibleDumper()
    dumper.ignore_aliases = lambda *args: True

# Generated at 2022-06-17 06:52:51.469604
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault_secret = VaultSecret('vault_secret')
    vault_lib = VaultLib([vault_secret])
    vault_text = vault_lib.encrypt('hello')

    loader = AnsibleLoader(None, vault_secrets=[vault_secret])
    data = loader.construct_yaml_str(vault_text)
    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    assert data.vault_secret == vault_secret

# Generated at 2022-06-17 06:53:02.443577
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor
    loader = AnsibleLoader(None)
    assert loader.file_name is None
    assert loader.vault_secrets is None
    assert loader.vault is None
    assert loader.vault_password is None
    assert loader.vault_version == 1
    assert loader.vault_ids == []
    assert loader.vault_support_v1 is True
    assert loader.vault_support_v2 is True
    assert loader.vault_prompt is None
    assert loader.vault_only_if_encrypted is False
    assert loader.vault_marker is None
    assert loader.vault_allow

# Generated at 2022-06-17 06:53:03.172442
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-17 06:53:14.505159
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
   

# Generated at 2022-06-17 06:53:18.934074
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.loader
    assert ansible.parsing.yaml.loader.AnsibleLoader

# Generated at 2022-06-17 06:53:27.070209
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    data = AnsibleUnicode('test')
    assert data == 'test'
    assert isinstance(data, AnsibleUnicode)

    # Test AnsibleSequence
    data = AnsibleSequence([])
    assert data == []
    assert isinstance(data, AnsibleSequence)

    # Test AnsibleMapping
    data = AnsibleMapping({})
    assert data == {}
    assert isinstance(data, AnsibleMapping)



# Generated at 2022-06-17 06:53:38.524973
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleLoader
    data = '''
    foo:
      - 1
      - 2
      - 3
    bar:
      baz: foobar
    '''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    assert isinstance(loader.get_single_data()['foo'], AnsibleSequence)