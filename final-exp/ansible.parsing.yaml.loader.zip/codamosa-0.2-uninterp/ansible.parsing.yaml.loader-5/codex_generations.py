

# Generated at 2022-06-17 06:43:55.791162
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC

    # Create a vault secret
    vault_secret = VaultSecret(password='ansible')

    # Create a vault password
    vault_password = VaultPassword(vault_secret)

    # Create a vault AES256
    vault_aes256 = VaultAES256(vault_password)

    # Create a vault AES256

# Generated at 2022-06-17 06:44:07.141073
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:44:19.229592
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test the AnsibleLoader class
    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_yaml_str(None), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_seq(None), AnsibleSequence)
    assert isinstance(loader.construct_yaml_map(None), AnsibleMapping)
    assert isinstance(loader.construct_yaml_str(None), AnsibleUnicode)

# Generated at 2022-06-17 06:44:26.848045
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

    data = '''
    foo:
      - bar: baz
      - bam: baz
    '''

    stream = TestAnsibleLoader(data)
    data = stream.get_single_data()
    assert isinstance(data['foo'][0]['bar'], AnsibleUnicode)

# Generated at 2022-06-17 06:44:27.592795
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-17 06:44:37.909272
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar
      - baz
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert isinstance(data['foo'][0], AnsibleUnicode)
    assert isinstance(data['foo'][1], AnsibleUnicode)

    dumper = AnsibleDumper()
    data = dumper.represent_data(data)
    assert data == 'foo:\n- bar\n- baz\n'

# Generated at 2022-06-17 06:44:49.018939
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

    stream = '''
    - foo: bar
      bam:
        - 1
        - 2
        - 3
    - foo: baz
      bam:
        - 4
        - 5
        - 6
    '''

    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert isinstance(data, AnsibleSequence)
    assert len(data) == 2
    assert isinstance(data[0], AnsibleMapping)
    assert isinstance(data[1], AnsibleMapping)

# Generated at 2022-06-17 06:44:56.531461
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:45:07.325212
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import StringIO

    data = """
    foo: 1
    bar:
      baz: 3
      qux:
        - 1
        - 2
        - 3
    """

    stream = StringIO(data)
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()

    assert isinstance(data, dict)
    assert isinstance(data['foo'], int)
    assert isinstance(data['bar'], dict)
    assert isinstance(data['bar']['baz'], int)

# Generated at 2022-06-17 06:45:19.656068
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB


# Generated at 2022-06-17 06:45:29.017944
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - hosts: all
      gather_facts: no
      tasks:
      - name: test
        debug:
          msg: "{{ '{{' }} foo {{ '}}' }}"
    '''

    loader = AnsibleLoader(data)
    dumper = AnsibleDumper()
    dumper.ignore_aliases = lambda *args: True
    result = dumper.dump(loader.get_single_data())
    assert result == data


# Generated at 2022-06-17 06:45:40.802879
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    vault_password = '$6$foobar'
    vault = VaultLib(vault_password)
    encrypted_data = vault.encrypt(b'foo')
    encrypted_data = encrypted_data.decode('utf-8')
    data = dict(foo=encrypted_data)
    data = AnsibleDumper(None, None, None).represent_dict(data)
    data = AnsibleLoader(data, vault_secrets=dict(vault_password=vault_password)).get_single_data()

# Generated at 2022-06-17 06:45:52.678407
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes

    if PY3:
        unicode_type = str
    else:
        unicode_type = unicode

    data = """
    foo: 1
    bar:
      baz: 3
      boo: [ "a", "b", "c" ]
    """

    data2 = """
    foo: 1
    bar:
      baz: 3
      boo: [ "a", "b", "c" ]
    """


# Generated at 2022-06-17 06:46:02.451735
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    stream = StringIO(u"---\n- hosts: localhost\n  tasks:\n  - name: test\n    debug: msg=\"hello world\"\n")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == [{u'hosts': u'localhost', u'tasks': [{u'name': u'test', u'debug': {u'msg': u'hello world'}}]}]

# Generated at 2022-06-17 06:46:11.924320
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    import unittest

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class TestAnsibleLoader(unittest.TestCase):
        def setUp(self):
            self.loader = AnsibleLoader(None)

        def tearDown(self):
            pass

        def test_construct_yaml_str(self):
            node = self.loader.construct_yaml_str(u'foo')
            self.assertEqual(node, u'foo')


# Generated at 2022-06-17 06:46:26.301883
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    stream = '''
    ---
    - hosts: all
      gather_facts: false
      tasks:
        - name: test
          debug:
            msg: "{{ '{{' }} ansible_env.HOME {{ '}}' }}"
    '''

    loader = AnsibleLoader(stream)
    data = loader.get_single_data()

# Generated at 2022-06-17 06:46:34.552907
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    assert AnsibleUnicode('foo') == 'foo'
    assert AnsibleUnicode('foo') != 'bar'
    assert AnsibleUnicode('foo') != 'Foo'
    assert AnsibleUnicode('foo') != 'FOO'
    assert AnsibleUnicode('foo') != 'Foo'
    assert AnsibleUnic

# Generated at 2022-06-17 06:46:45.484552
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import tempfile
    import shutil
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temp directory
    fd, vault_password_file = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write a password to the vault password file
    f = open(vault_password_file, 'wb')
    f.write('password' + os.linesep)
    f.close()

    # Create a vault password file environment variable
    os.environ['ANSIBLE_VAULT_PASSWORD_FILE'] = vault

# Generated at 2022-06-17 06:46:54.468054
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_password = '$6$foobar'
    vault_secrets = [VaultSecret(vault_password, 0)]
    vault = VaultLib(vault_secrets)


# Generated at 2022-06-17 06:47:05.670156
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

    # Test AnsibleSequence
    assert isinstance(AnsibleLoader('').construct_yaml_seq(''), AnsibleSequence)

    # Test AnsibleMapping
    assert isinstance(AnsibleLoader('').construct_yaml_map(''), AnsibleMapping)

    # Test AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:47:16.814104
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:47:27.103179
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test for vault_secrets
    vault_secrets = [
        {'secret': 'secret', 'secret_type': 'password'},
        {'secret': 'secret', 'secret_type': 'ssh_key'},
        {'secret': 'secret', 'secret_type': 'ssh_key_unlock'},
    ]
    vault_secrets_obj = VaultLib(vault_secrets)
    vault_secrets_obj.start_decryption()
    vault_secrets_obj.stop_decryption()

    # Test for file_name
    file_name = 'test_file_name'

    # Test for

# Generated at 2022-06-17 06:47:38.619082
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:47:49.592634
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    if sys.version_info >= (3, 0):
        unicode = str
    data = '''
    foo:
      bar: 1
      baz:
        - 1
        - 2
        - 3
    '''
    data = unicode(data)
    loader = AnsibleLoader(data)
    dumper = AnsibleDumper()
    data = loader.get_single_data()
    assert isinstance(data, dict)
    assert isinstance(data['foo'], dict)
    assert isinstance(data['foo']['bar'], int)
    assert isinstance(data['foo']['baz'], list)


# Generated at 2022-06-17 06:47:56.017501
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:48:00.937374
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS

# Generated at 2022-06-17 06:48:08.942201
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode

    vault_secrets = {'vault_password_file': 'vault_password_file'}
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)

    assert loader.vault_secrets == vault_secrets
    assert loader.file_name is None

    assert loader.construct_yaml_str('foo') == AnsibleUnsafeText('foo')
    assert loader

# Generated at 2022-06-17 06:48:17.761892
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import tempfile
    import yaml

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Write some YAML to the temporary file
    with open(path, 'w') as f:
        f.write("""
        ---
        - hosts: localhost
          tasks:
          - name: test
            debug:
              msg: "{{ 'Hello World' }}"
        """)

    # Read the YAML from the temporary file
    with open(path, 'r') as f:
        data = yaml.load(f, Loader=AnsibleLoader)

    # Remove the temporary file
    os.remove(path)

    # Assert that the YAML was read correctly

# Generated at 2022-06-17 06:48:28.215345
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
   

# Generated at 2022-06-17 06:48:40.167702
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:48:59.002000
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=protected-access
    assert AnsibleLoader._construct_mapping is AnsibleConstructor._construct_mapping
    assert AnsibleLoader._construct_yaml_map is AnsibleConstructor._construct_yaml_map
    assert AnsibleLoader._construct_yaml_seq is AnsibleConstructor._construct_yaml_seq
    assert AnsibleLoader._construct_yaml_str is AnsibleConstructor._construct_yaml_str
    assert AnsibleLoader._construct_yaml_int is AnsibleConstructor._construct_yaml_int
    assert AnsibleLoader._construct_yaml_float is AnsibleConstructor._construct_yaml_float
    assert AnsibleLoader._construct_yaml_bool is AnsibleConstructor._construct_yaml_bool
    assert AnsibleLoader._construct_yaml_null is AnsibleConstruct

# Generated at 2022-06-17 06:49:11.514797
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB

# Generated at 2022-06-17 06:49:28.695786
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test the constructor

# Generated at 2022-06-17 06:49:40.909751
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:49:51.296602
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - hosts: localhost
      tasks:
      - name: test
        debug:
          msg: "{{ '{{' }} foo {{ '}}' }}"
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert data[0]['tasks'][0]['debug']['msg'] == AnsibleUnicode('{{ foo }}')

    dumper = AnsibleDumper()
    data = dumper.represent_data(data)

# Generated at 2022-06-17 06:50:02.558845
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.nodes import AnsibleMappingNode
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode
    from ansible.parsing.yaml.nodes import AnsibleScalarNode
    from ansible.parsing.yaml.nodes import AnsibleAliasNode

    # test_construct_mapping
    loader = AnsibleLoader(None)
    node = AnsibleMappingNode(None, None, True, None, None)
    data = loader.construct_mapping(node)
    assert isinstance(data, dict)
    assert data == {}

    # test_construct_sequence

# Generated at 2022-06-17 06:50:15.053746
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml
    import os


# Generated at 2022-06-17 06:50:20.265271
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.yaml import HAS_LIBYAML

    if HAS_LIBYAML:
        from yaml.constructor import ConstructorError
    else:
        from yaml.composer import ComposerError as ConstructorError

    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class Ansible

# Generated at 2022-06-17 06:50:29.414161
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.yaml import HAS_LIBYAML

    if HAS_LIBYAML:
        from ansible.module_utils.common.yaml import Parser
        assert issubclass(AnsibleLoader, Parser)
    else:
        from yaml.composer import Composer
        from yaml.reader import Reader
        from yaml.scanner import Scanner
        from yaml.parser import Parser
        assert issubclass(AnsibleLoader, Reader)
        assert issubclass(AnsibleLoader, Scanner)
        assert issubclass(AnsibleLoader, Parser)

# Generated at 2022-06-17 06:50:38.058752
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from io import StringIO
    import yaml

    vault_password = '$6$foobar'
    vault = VaultLib([VaultSecret(vault_password)])

    # test that the vault secret is used

# Generated at 2022-06-17 06:51:10.199144
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.yaml import HAS_LIBYAML

    if HAS_LIBYAML:
        from ansible.parsing.yaml.objects import AnsibleSequence
        from ansible.parsing.yaml.objects import AnsibleMapping
    else:
        from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping

    data = '''
    - hosts: all
      gather_facts: False
      tasks:
      - name: test
        debug:
          msg: "{{ ansible_distribution }}"
    '''

    loader = AnsibleLoader(data)
    assert isinstance

# Generated at 2022-06-17 06:51:18.529545
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo: 1
    bar:
      baz: 3
      boo: [ "a", "b", "c" ]
    '''

    loader = AnsibleLoader(data)
    datastructure = loader.get_single_data()

    assert datastructure == dict(foo=1, bar=dict(baz=3, boo=["a", "b", "c"]))
    assert isinstance(datastructure['bar']['boo'][0], AnsibleUnicode)

    dumper = AnsibleDumper()
    output = dumper.dump(datastructure, Dumper=AnsibleDumper)
    assert output

# Generated at 2022-06-17 06:51:27.454105
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)
    assert isinstance(AnsibleLoader('').construct_yaml_str(None), AnsibleUnicode)

    # Test AnsibleSequence
    assert isinstance(AnsibleLoader('').construct_yaml_seq(''), AnsibleSequence)

# Generated at 2022-06-17 06:51:38.493119
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:51:46.425616
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:51:57.405680
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    foo:
      - 1
      - 2
      - 3
    bar:
      baz: hello
    """

    # Test round trip
    obj = AnsibleLoader(data).get_single_data()
    assert isinstance(obj, AnsibleMapping)
    assert isinstance(obj['foo'], AnsibleSequence)
    assert isinstance(obj['bar'], AnsibleMapping)
    assert obj['bar']['baz'] == 'hello'
    assert AnsibleDumper().dump(obj) == data

    # Test round trip with

# Generated at 2022-06-17 06:52:01.425094
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    import unittest

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleScalar

    class TestAnsibleLoader(unittest.TestCase):

        def setUp(self):
            self.loader = AnsibleLoader(None)

        def tearDown(self):
            pass

        def test_construct_yaml_str(self):
            node

# Generated at 2022-06-17 06:52:07.736026
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

    # Test AnsibleSequence
    assert isinstance(AnsibleLoader('').construct_yaml_seq(''), AnsibleSequence)

# Generated at 2022-06-17 06:52:13.968327
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor
    data = '''
    ---
    foo: bar
    baz:
      - 1
      - 2
      - 3
    '''
    stream = io.StringIO(data)
    loader = AnsibleLoader(stream)
    assert loader.get_single_data() == {'foo': 'bar', 'baz': [1, 2, 3]}

    # Test the vault constructor

# Generated at 2022-06-17 06:52:27.457639
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secret = VaultSecret('secret')
    vault_password = VaultLib([vault_secret])

    # Test AnsibleLoader

# Generated at 2022-06-17 06:53:25.909678
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleUnic

# Generated at 2022-06-17 06:53:37.602557
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB

# Generated at 2022-06-17 06:53:43.598890
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
    - hosts: all
      gather_facts: no
      tasks:
      - name: test
        debug:
          msg: "{{ ansible_env.HOME }}"
    '''

    loader = AnsibleLoader(data)
    for item in loader:
        assert isinstance(item, dict)
        assert isinstance(item['tasks'][0]['debug']['msg'], AnsibleUnicode)