

# Generated at 2022-06-17 06:43:47.398259
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('test').get_single_data(), AnsibleUnicode)

    # Test AnsibleSequence
    assert isinstance(AnsibleLoader('[test]').get_single_data(), AnsibleSequence)

    # Test AnsibleMapping
    assert isinstance(AnsibleLoader('{test: test}').get_single_data(), AnsibleMapping)

    # Test AnsibleVaultEncryptedUnicode


# Generated at 2022-06-17 06:43:58.253733
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultVersionedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultVersionedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultVersionedUnicode

# Generated at 2022-06-17 06:44:04.752582
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_yaml_str(None), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_seq(None), AnsibleSequence)
    assert isinstance(loader.construct_yaml_map(None), AnsibleMapping)
    assert isinstance(loader.construct_yaml_str(None), AnsibleUnicode)

# Generated at 2022-06-17 06:44:05.251311
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-17 06:44:17.909746
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB


# Generated at 2022-06-17 06:44:29.140292
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test AnsibleLoader.construct_yaml_str
    data = 'foo: bar'
    loader = AnsibleLoader(data)
    loader.get_single_data()
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    assert loader.get_single_data() == {'foo': 'bar'}

    # Test AnsibleLoader.construct_yaml_seq
    data = '- foo\n- bar'
    loader = AnsibleLoader(data)

# Generated at 2022-06-17 06:44:40.586107
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-17 06:44:51.895967
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)

    # Write to the file
    os.write(fd, b'---\n')
    os.write(fd, b'foo: bar\n')
    os.write(fd, b'...\n')

    # Close the file
    os.close(fd)

    # Load the file
    loader = AnsibleLoader(open(path, 'r'))

    # Check the file
    assert loader.get_single_data() == {'foo': 'bar'}

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 06:45:03.464261
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-17 06:45:05.178294
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-17 06:45:19.770825
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:45:27.300454
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.reader import AnsibleReader
    from ansible.parsing.yaml.scanner import AnsibleScanner
    from ansible.parsing.yaml.parser import AnsibleParser
    from ansible.parsing.yaml.composer import AnsibleComposer
   

# Generated at 2022-06-17 06:45:33.814980
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    stream = StringIO(u'{ foo: bar }')
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {u'foo': u'bar'}

# Generated at 2022-06-17 06:45:43.478628
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test that AnsibleLoader can load an encrypted string

# Generated at 2022-06-17 06:45:54.562348
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.nodes import AnsibleScalarNode
    from ansible.parsing.yaml.representer import AnsibleRepresenter
    from ansible.parsing.yaml.serializer import AnsibleSerializer
    from ansible.parsing.yaml.emitter import AnsibleEmitter
    from ansible.parsing.yaml.constructor import AnsibleConstructor

# Generated at 2022-06-17 06:46:05.791208
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = dict(
        a=1,
        b=dict(
            ba=dict(
                baa=1,
                bab=2,
            ),
            bb=dict(
                bba=1,
                bbb=2,
            ),
        ),
        c=dict(
            ca=dict(
                caa=1,
                cab=2,
            ),
            cb=dict(
                cba=1,
                cbb=2,
            ),
        ),
    )


# Generated at 2022-06-17 06:46:16.534169
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test that AnsibleLoader is a subclass of yaml.Loader
    assert issubclass(AnsibleLoader, yaml.Loader)

    # Test that AnsibleLoader is a subclass of AnsibleConstructor
    assert issubclass(AnsibleLoader, AnsibleConstructor)

    # Test that AnsibleLoader is a subclass of yaml.Resolver
    assert issubclass(AnsibleLoader, yaml.Resolver)

    # Test that AnsibleLoader is a subclass of yaml.BaseLoader
    assert issubclass(AnsibleLoader, yaml.BaseLoader)

    # Test that Ans

# Generated at 2022-06-17 06:46:27.551545
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar
      - baz
    '''

    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), dict)
    assert isinstance(loader.get_single_data()['foo'][0], AnsibleUnicode)
    assert loader.get_single_data()['foo'][0] == 'bar'
    assert isinstance(loader.get_single_data()['foo'][1], AnsibleUnicode)
    assert loader.get_single_data()['foo'][1] == 'baz'

    dumper = AnsibleDumper()

# Generated at 2022-06-17 06:46:37.133847
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CTR
   

# Generated at 2022-06-17 06:46:43.507479
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:46:55.144701
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleLoader with a string
    loader = AnsibleLoader('[1, 2, 3]')
    assert isinstance(loader.get_single_data(), AnsibleSequence)

    # Test AnsibleLoader with a file
    import os
    import tempfile
    (fd, path) = tempfile.mkstemp()
    os.write(fd, b'[1, 2, 3]')
    os.close(fd)
    loader = AnsibleLoader(open(path))


# Generated at 2022-06-17 06:47:00.102600
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
    - hosts: localhost
      tasks:
        - name: test
          debug: msg="{{ '{{' }}"
    '''
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data['tasks'][0]['debug']['msg'] == '{{'

# Generated at 2022-06-17 06:47:10.652923
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import Ansible

# Generated at 2022-06-17 06:47:19.454591
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-17 06:47:29.108911
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.nodes import AnsibleScalarNode
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode
    from ansible.parsing.yaml.nodes import AnsibleMappingNode
    from ansible.parsing.yaml.nodes import AnsibleUnicode
    from ansible.parsing.yaml.nodes import AnsibleVaultEncryptedUnicodeNode

# Generated at 2022-06-17 06:47:34.867842
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO
    stream = BytesIO(b'{test: test}')
    loader = AnsibleLoader(stream)
    assert loader.get_single_data() == {'test': 'test'}

# Generated at 2022-06-17 06:47:45.295396
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    import io
    import yaml

    class MyLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return class unicode.  This example
            # also shows how to access the data represented by the
            # yaml node.
            return AnsibleUnicode(self.construct_scalar(node))


# Generated at 2022-06-17 06:47:54.823101
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    import yaml


# Generated at 2022-06-17 06:48:05.544572
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault_secrets = [{'vault_password': 'secret'}]
    vault = VaultLib(vault_secrets)
    data = vault.encrypt('test')
    assert isinstance(data, AnsibleVaultEncryptedUnicode)

    data = {'test': data}
    stream = AnsibleDumper(data, Dumper=AnsibleDumper).get_single_data()
    loader = AnsibleLoader(stream, vault_secrets=vault_secrets)
    data = loader.get_single_data()

# Generated at 2022-06-17 06:48:17.434768
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
   

# Generated at 2022-06-17 06:48:32.094497
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Create a vault secret
    vault_secret = VaultSecret('secret')
    vault_secret.update('password')

    # Create a vault lib
    vault_lib = VaultLib(vault_secret)

    # Create an encrypted string
    encrypted_string = vault_lib.encrypt('test')

    # Create a loader
    loader = AnsibleLoader(None, vault_secrets=[vault_secret])

    # Create a dumper
    dumper = AnsibleDumper()

    # Test the constructor

# Generated at 2022-06-17 06:48:38.991779
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

    data = '''
        foo: 1
        bar:
          baz: 3
          qux:
            - 1
            - 2
            - 3
    '''

    # Load the data
    stream = TestAnsibleLoader(data)
    data = stream.get_single_data()

    # Dump the data
    stream = AnsibleDumper()

# Generated at 2022-06-17 06:48:48.125113
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode, AnsibleMappingNode

    # Test for AnsibleLoader
    # Test for AnsibleLoader.construct_yaml_map
    # Test for AnsibleLoader.construct_yaml_seq
    # Test for AnsibleLoader.construct_undefined
    # Test for AnsibleLoader.construct_yaml_str
    # Test for AnsibleLoader.construct_yaml_int
    # Test for Ans

# Generated at 2022-06-17 06:48:48.573315
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-17 06:48:55.460584
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:49:08.167195
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    yaml_str = """
    - hosts: localhost
      tasks:
        - name: test
          debug:
            msg: "{{ '{ \"a\": 1 }' | from_json }}"
    """

    stream = StringIO(yaml_str)
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data['tasks'][0]['debug']['msg']['a'] == 1

# Generated at 2022-06-17 06:49:14.964078
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(AnsibleLoader):
        pass

    data = '''
    foo: 1
    bar:
      baz: 2
    '''
    loader = TestAnsibleLoader(data)
    data = loader.get_single_data()
    assert data['foo'] == 1
    assert data['bar']['baz'] == 2
    assert isinstance(data['bar']['baz'], AnsibleUnicode)
    assert isinstance(data['bar'], AnsibleUnicode)
    assert isinstance(data, AnsibleUnicode)

    dumper = AnsibleDumper()
    assert dumper.represent_

# Generated at 2022-06-17 06:49:29.078232
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test that AnsibleLoader can decrypt an encrypted string
    # and AnsibleDumper can encrypt a string
    # and AnsibleLoader can decrypt the encrypted string
    # and AnsibleDumper can encrypt the decrypted string
    # and AnsibleLoader can decrypt the encrypted string
    # and AnsibleDumper can encrypt the decrypted string
    # and AnsibleLoader can decrypt the encrypted string
    # and AnsibleDumper can encrypt the decrypted string
    # and AnsibleLoader can decrypt the encrypted string
    # and AnsibleDumper can encrypt the decrypted string
    # and AnsibleLoader can decrypt the encrypted string
    # and AnsibleDumper can encrypt the decrypted string


# Generated at 2022-06-17 06:49:41.456514
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('foo').get_single_data(), AnsibleUnicode)
    assert isinstance(AnsibleLoader('foo: bar').get_single_data(), AnsibleMapping)
    assert isinstance(AnsibleLoader('- foo').get_single_data(), AnsibleSequence)

    # Test AnsibleMapping
    assert isinstance(AnsibleLoader('{foo: bar}').get_single_data(), AnsibleMapping)

# Generated at 2022-06-17 06:49:51.323842
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    # Test AnsibleLoader with vault_secrets
    vault_secrets = [{'vault_id': 'secret1', 'vault_password': 'secret1'}]
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)
    assert loader.vault_secrets == vault_secrets

    # Test AnsibleLoader with vault_secrets and file_name
    file_name = 'test_file_name'

# Generated at 2022-06-17 06:50:18.964215
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    class TestVaultSecret:
        def __init__(self, secret):
            self.secret = secret

        def __eq__(self, other):
            return self.secret == other.secret


# Generated at 2022-06-17 06:50:28.913353
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-17 06:50:40.048145
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys

    if sys.version_info >= (3, 0):
        unicode = str

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return unicode(self.construct_scalar(node))

        def construct_yaml_seq(self, node):
            # Override the default list handling function
            # to always return list objects
            return list(self.construct_sequence(node))


# Generated at 2022-06-17 06:50:46.951686
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeBytes
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    from ansible.parsing.yaml.objects import AnsibleScalar
    from ansible.parsing.yaml.objects import AnsibleScalarBoolean
    from ansible.parsing.yaml.objects import Ansible

# Generated at 2022-06-17 06:50:56.971800
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
    foo: bar
    baz:
      - 1
      - 2
      - 3
    '''

    # Test loading
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == {'foo': 'bar', 'baz': [1, 2, 3]}

    # Test dumping
    dumper = AnsibleDumper()
    assert dumper.represent_dict({'foo': 'bar', 'baz': [1, 2, 3]}) == data

    # Test round-tripping

# Generated at 2022-06-17 06:51:09.101277
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test vaulted data

# Generated at 2022-06-17 06:51:17.761908
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR

# Generated at 2022-06-17 06:51:20.204197
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader

    assert issubclass(AnsibleLoader, AnsibleConstructor)

# Generated at 2022-06-17 06:51:28.836597
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import VaultSecret

    vault_secrets = [VaultSecret('secret', 'password')]
    vault = VaultLib(vault_secrets)


# Generated at 2022-06-17 06:51:40.023105
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:52:27.911408
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
   

# Generated at 2022-06-17 06:52:38.895548
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:52:47.956235
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=protected-access
    loader = AnsibleLoader(None)
    assert loader._construct_mapping is AnsibleConstructor._construct_mapping
    assert loader._construct_yaml_map is AnsibleConstructor._construct_yaml_map
    assert loader._construct_yaml_seq is AnsibleConstructor._construct_yaml_seq
    assert loader._construct_yaml_str is AnsibleConstructor._construct_yaml_str
    assert loader._construct_yaml_int is AnsibleConstructor._construct_yaml_int
    assert loader._construct_yaml_float is AnsibleConstructor._construct_yaml_float
    assert loader._construct_yaml_bool is AnsibleConstructor._construct_yaml_bool
    assert loader._construct_yaml_omap is AnsibleConstructor._construct_y

# Generated at 2022-06-17 06:52:55.950508
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - foo:
        - bar
        - baz
    - foo:
        - bar
        - baz
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()

    assert isinstance(data, AnsibleSequence)
    assert isinstance(data[0], AnsibleMapping)
    assert isinstance(data[0]['foo'], AnsibleSequence)

# Generated at 2022-06-17 06:53:02.734006
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(AnsibleLoader):
        pass

    data = '''
    foo:
      - bar
      - baz
    '''

    loader = TestAnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleUnicode)

    dumper = AnsibleDumper()
    assert dumper.represent_scalar('tag:yaml.org,2002:str', 'foo') == 'foo'
    assert dumper.represent_scalar('tag:yaml.org,2002:str', 'foo\nbar') == '"foo\\nbar"'
    assert dumper.represent_scalar

# Generated at 2022-06-17 06:53:14.226354
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:53:25.805108
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_yaml_str(None), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(u'foo'), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(b'foo'), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(u'foo'), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(b'foo'), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(u'foo'), AnsibleUnicode)

# Generated at 2022-06-17 06:53:37.530212
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib

    # Test the constructor