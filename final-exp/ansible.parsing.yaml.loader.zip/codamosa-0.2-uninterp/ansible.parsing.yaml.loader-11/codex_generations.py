

# Generated at 2022-06-17 06:43:46.544663
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
   

# Generated at 2022-06-17 06:43:58.126652
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES

# Generated at 2022-06-17 06:44:09.058692
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultA

# Generated at 2022-06-17 06:44:15.105154
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO

    data = b'{"a": "b"}'
    stream = BytesIO(data)
    loader = AnsibleLoader(stream)
    assert loader.get_single_data() == {'a': 'b'}

# Generated at 2022-06-17 06:44:24.210151
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.reader import AnsibleReader
    from ansible.parsing.yaml.scanner import AnsibleScanner
    from ansible.parsing.yaml.parser import AnsibleParser
    from ansible.parsing.yaml.composer import AnsibleComposer
   

# Generated at 2022-06-17 06:44:36.288981
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:44:44.952097
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor
    data = AnsibleLoader(None).get_single_data()
    assert isinstance(data, AnsibleMapping)

    # Test the dumper
    dumper = AnsibleDumper()
    assert dumper.represent_data(data) == '{}\n...\n'

# Generated at 2022-06-17 06:44:53.298383
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar
      - baz
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert isinstance(data['foo'][0], AnsibleUnicode)
    assert isinstance(data['foo'][1], AnsibleUnicode)

    dumper = AnsibleDumper()
    data = dumper.represent_data(data)
    assert isinstance(data, str)
    assert data == '{foo: [bar, baz]}\n'

# Generated at 2022-06-17 06:45:04.573615
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test with a string
    test_string = '''
    - hosts: all
      gather_facts: no
      tasks:
        - name: test
          debug:
            msg: "{{ '{' }}foo{'}' }}{'}' }}"
    '''
    loader = AnsibleLoader(test_string)
    assert loader.get_single_data() == [{'hosts': 'all', 'gather_facts': 'no', 'tasks': [{'name': 'test', 'debug': {'msg': '{{ foo}}'}}]}]

    # Test with a file
    loader = AnsibleLoader(open('test/sanity/code-smell/yaml-with-jinja.yml'))

# Generated at 2022-06-17 06:45:16.725243
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    vault_password = '$6$salt$password'
    vault = VaultLib(vault_password)

# Generated at 2022-06-17 06:45:26.199279
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
   

# Generated at 2022-06-17 06:45:38.651679
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
   

# Generated at 2022-06-17 06:45:45.052159
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword

    # Test the AnsibleLoader class

# Generated at 2022-06-17 06:45:55.431087
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB

# Generated at 2022-06-17 06:46:07.875428
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-17 06:46:16.964192
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile

    # Test for AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

    # Test for AnsibleSequence
    assert isinstance(AnsibleLoader('').construct_yaml_seq(''), AnsibleSequence)

    # Test for AnsibleMapping

# Generated at 2022-06-17 06:46:25.080241
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

        def construct_yaml_seq(self, node):
            # Override the default list handling function
            # to always return list objects
            return self.construct_sequence(node)

        def construct_yaml_map(self, node):
            # Override the default dict handling function
            # to always return dict objects
            return self.construct_mapping(node)


# Generated at 2022-06-17 06:46:34.467979
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword

    vault_secrets = [VaultSecret('secret0', VaultPassword('password0', False)),
                     VaultSecret('secret1', VaultPassword('password1', True))]
    vault_password = VaultPassword('password', True)
    vault_secrets.append(VaultSecret('secret2', vault_password))
    vault_secrets.append(VaultSecret('secret3', VaultPassword('password3', False)))

# Generated at 2022-06-17 06:46:45.442245
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    import unittest

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class TestAnsibleLoader(unittest.TestCase):

        def setUp(self):
            self.loader = AnsibleLoader(None)

        def tearDown(self):
            self.loader = None


# Generated at 2022-06-17 06:46:54.446598
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
   

# Generated at 2022-06-17 06:47:10.092873
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from io import StringIO

    vault_password = '$ecret'
    vault = VaultLib(vault_password)
    plaintext = '$ecret'
    ciphertext = vault.encrypt(plaintext)

    # test AnsibleLoader
    stream = StringIO(ciphertext)
    loader = AnsibleLoader(stream, vault_secrets=[vault])
    data = loader.get_single_data()
    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    assert data

# Generated at 2022-06-17 06:47:19.110916
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:47:28.842700
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, yaml_file = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write some YAML into the file
    with open(yaml_file, 'w') as f:
        f.write("""
---
- hosts: localhost
  tasks:
    - name: test
      debug: msg="Hello World"
""")

    # Create a loader
    loader = AnsibleLoader(open(yaml_file))

    # Load the YAML into a data structure
    data = loader.get_single_data()

    # Clean up

# Generated at 2022-06-17 06:47:40.869994
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleLoader.construct_yaml_str
    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_yaml_str(u'foo'), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(u'foo'), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(u'foo'), AnsibleUnicode)

# Generated at 2022-06-17 06:47:49.696144
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:48:02.487810
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:48:03.073796
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-17 06:48:10.243822
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CTR


# Generated at 2022-06-17 06:48:18.427520
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:48:28.964631
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleLoader.construct_yaml_map
    data = '''
    foo: bar
    baz:
      - 1
      - 2
      - 3
    '''
    loader = AnsibleLoader(data)
    loader.get_single_data()
    assert isinstance(loader.get_single_data(), AnsibleMapping)

# Generated at 2022-06-17 06:48:52.104993
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

    # Test AnsibleSequence
    assert isinstance(AnsibleLoader('').construct_yaml_seq(''), AnsibleSequence)

    # Test AnsibleMapping
    assert isinstance(AnsibleLoader('').construct_yaml_map(''), AnsibleMapping)

    # Test AnsibleDumper

# Generated at 2022-06-17 06:49:00.003360
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test the constructor of class AnsibleLoader
    stream = '''
    - hosts: localhost
      tasks:
        - name: test
          debug:
            msg: "{{ '{}' }}"
    '''
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == [{'hosts': 'localhost', 'tasks': [{'debug': {'msg': '{}'}, 'name': 'test'}]}]

    # Test the constructor of class AnsibleDumper
    dumper = AnsibleDumper()
    output

# Generated at 2022-06-17 06:49:11.601432
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # test unicode
    data = u'foo: bar'
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    assert isinstance(loader.get_single_data()[u'foo'], AnsibleUnicode)
    assert loader.get_single_data()[u'foo'] == u'bar'

    # test list
    data = u'- foo\n- bar'
    loader = AnsibleLoader(data)

# Generated at 2022-06-17 06:49:28.728902
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (2, 7):
        import unittest
        from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping

        class TestAnsibleLoader(unittest.TestCase):
            def test_constructor(self):
                loader = AnsibleLoader(None)
                self.assertIsInstance(loader.construct_yaml_str(None), AnsibleUnicode)
                self.assertIsInstance(loader.construct_yaml_seq(None), AnsibleSequence)
                self.assertIsInstance(loader.construct_yaml_map(None), AnsibleMapping)
                self.assertIsInstance(loader.construct_yaml_omap(None), AnsibleMapping)


# Generated at 2022-06-17 06:49:40.948226
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import tempfile
    import textwrap
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Create the data to dump

# Generated at 2022-06-17 06:49:51.296369
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
    foo: 1
    bar:
      baz: 3
      boo: [ "a", "b", "c" ]
    '''

    data2 = '''
    foo: 1
    bar:
      baz: 3
      boo: [ "a", "b", "c" ]
    '''

    data3 = '''
    foo: 1
    bar:
      baz: 3
      boo: [ "a", "b", "c" ]
    '''


# Generated at 2022-06-17 06:50:02.563031
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:50:12.770066
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    yaml_str = u"""
    - hosts: localhost
      tasks:
        - name: test
          debug:
            msg: "{{ '{' }}foo{'}' }}"
    """

    stream = StringIO(yaml_str)
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data['tasks'][0]['debug']['msg'] == '{foo}'

# Generated at 2022-06-17 06:50:24.109726
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    stream = StringIO(u'[1, 2, 3]')
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == [1, 2, 3]

    stream = StringIO(u'[1, 2, 3]')
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == [1, 2, 3]

# Generated at 2022-06-17 06:50:34.705515
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
   

# Generated at 2022-06-17 06:51:05.844947
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:51:07.856626
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=unused-variable
    loader = AnsibleLoader(None)

# Generated at 2022-06-17 06:51:17.341379
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor of class AnsibleLoader
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

    # Test the constructor of class AnsibleDumper
    dumper = AnsibleDumper(None)
    assert isinstance(dumper, AnsibleDumper)

    # Test the constructor of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:51:26.430605
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:51:36.733964
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword

    # Create a vault secret
    vault_secret = VaultSecret(VaultPassword('secret'))

    # Create a vault object
    vault = VaultLib([vault_secret])

    # Create a loader
    loader = AnsibleLoader(None, vault_secrets=[vault_secret])

    # Create a dumper
    dumper = AnsibleDumper()

    # Create an encrypted string
    encrypted_string = vault.encrypt('test string')

    # Create an

# Generated at 2022-06-17 06:51:45.956950
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import BytesIO
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:51:52.422105
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO
    stream = StringIO(u"---\n- hosts: localhost\n  tasks:\n  - debug: msg='hello world'\n")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {u'hosts': u'localhost', u'tasks': [{u'debug': {u'msg': u'hello world'}}]}

# Generated at 2022-06-17 06:52:00.975344
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:52:07.832713
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

    # Test AnsibleSequence
    assert isinstance(AnsibleLoader('').construct_yaml_seq(''), AnsibleSequence)

    # Test AnsibleMapping
    assert isinstance(AnsibleLoader('').construct_yaml_map(''), AnsibleMapping)

    # Test AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:52:13.994451
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    import yaml

    vault_password = '$6$TESTING'
    vault = VaultLib(vault_password)
    vault_data = vault.encrypt('test')

    data = {'test': vault_data}
    data_yaml = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)

    loader = AnsibleLoader(data_yaml, vault_secrets=vault_password)
    data_loaded = loader.get_single_data

# Generated at 2022-06-17 06:53:12.178720
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import yaml

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Create a temporary file to use for testing
    (fd, path) = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the temporary file
    f = open(path, 'w')

# Generated at 2022-06-17 06:53:26.016462
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:53:37.747410
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor of AnsibleLoader
    #
    # The following test cases are covered:
    #
    # 1. Test the constructor of AnsibleLoader
    # 2. Test the constructor of AnsibleLoader with vault_secrets
    # 3. Test the constructor of AnsibleLoader with vault_secrets and file_name
    # 4. Test the constructor of AnsibleLoader with vault_secrets and file_name
