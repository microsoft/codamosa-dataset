

# Generated at 2022-06-17 06:43:53.986749
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

    data = '''
    foo: bar
    baz: !!str 123
    '''

    # Test round-trip for unicode objects
    loader = TestAnsibleLoader(data)
    output = loader.get_single_data()
    assert isinstance(output['foo'], AnsibleUnicode)
    assert isinstance(output['baz'], AnsibleUnicode)


# Generated at 2022-06-17 06:43:58.200942
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    stream = StringIO("""
---
- hosts: localhost
  tasks:
    - debug:
        msg: '{{ ansible_distribution }}'
""")
    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-17 06:44:04.714742
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

    # Test AnsibleSequence
    assert isinstance(AnsibleLoader('').construct_yaml_seq(''), AnsibleSequence)

    # Test AnsibleMapping
    assert isinstance(AnsibleLoader('').construct_yaml_map(''), AnsibleMapping)

    # Test AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:44:17.262919
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    # Test AnsibleLoader
    data = '''
    - hosts: localhost
      tasks:
      - name: test
        debug:
          msg: "{{ '{{' }} foo {{ '}}' }}"
    '''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    assert isinstance(loader.get_single_data()['tasks'], AnsibleSequence)

# Generated at 2022-06-17 06:44:28.877208
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret


# Generated at 2022-06-17 06:44:40.447402
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    if PY3:
        unicode = str


# Generated at 2022-06-17 06:44:51.813608
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    ---
    - hosts: all
      gather_facts: no
      tasks:
      - name: test
        debug:
          msg: "{{ '{0}' }}"
    '''

    loader = AnsibleLoader(data)
    dumper = AnsibleDumper()

    for task in loader.get_single_data().get('tasks'):
        assert isinstance(task['name'], AnsibleUnicode)
        assert isinstance(task['debug']['msg'], AnsibleUnicode)

        dumped_task = dumper.represent_data(task)

# Generated at 2022-06-17 06:45:03.384557
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test for AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

    # Test for AnsibleSequence
    assert isinstance(AnsibleLoader('').construct_yaml_seq(''), AnsibleSequence)

    # Test for AnsibleMapping
    assert isinstance(AnsibleLoader('').construct_yaml_map(''), AnsibleMapping)

    # Test for AnsibleV

# Generated at 2022-06-17 06:45:15.942346
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

    data = '''
    foo:
      - bar
      - baz
    '''

    stream = TestAnsibleLoader(data)
    data = stream.get_single_data()
    assert isinstance(data['foo'][0], AnsibleUnicode)
    assert isinstance(data['foo'][1], AnsibleUnicode)

    # Test that the dumper also

# Generated at 2022-06-17 06:45:28.242445
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret


# Generated at 2022-06-17 06:45:41.688715
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleScalarBoolean
    from ansible.parsing.yaml.objects import AnsibleScalarFloat
    from ansible.parsing.yaml.objects import AnsibleScalarInteger
    from ansible.parsing.yaml.objects import AnsibleScalarNull

# Generated at 2022-06-17 06:45:50.862334
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    stream = StringIO(u"---\n- hosts: localhost\n  tasks:\n  - name: test\n    debug: msg=\"hello world\"\n")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == [{'hosts': 'localhost', 'tasks': [{'debug': {'msg': 'hello world'}, 'name': 'test'}]}]

# Generated at 2022-06-17 06:45:58.572047
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC

# Generated at 2022-06-17 06:46:09.732849
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test that AnsibleLoader can load an encrypted string

# Generated at 2022-06-17 06:46:18.409870
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml


# Generated at 2022-06-17 06:46:28.232533
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:46:37.193862
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the AnsibleLoader class
    data = """
a: 1
b:
  - 2
  - 3
c:
  key: value
"""
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    assert isinstance(loader.get_single_data()['a'], int)

# Generated at 2022-06-17 06:46:43.992724
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    stream = io.StringIO(u"""
        ---
        - hosts: localhost
          tasks:
            - name: test
              debug:
                msg: hello world
    """)
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data['hosts'] == 'localhost'
    assert data['tasks'][0]['name'] == 'test'
    assert data['tasks'][0]['debug']['msg'] == 'hello world'

# Generated at 2022-06-17 06:46:50.194039
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO
    stream = BytesIO(b"---\n- hosts: localhost\n  tasks:\n  - name: test\n    debug: msg=\"hello world\"\n")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {'hosts': 'localhost', 'tasks': [{'debug': {'msg': 'hello world'}, 'name': 'test'}]}

# Generated at 2022-06-17 06:46:58.535450
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test constructor
    loader = AnsibleLoader(None)
    assert loader.file_name is None
    assert loader.vault_secrets is None

    # Test vault_secrets
    loader = AnsibleLoader(None, vault_secrets=['secret1', 'secret2'])
    assert loader.vault_secrets == ['secret1', 'secret2']

    # Test file_name
    loader = AnsibleLoader(None, file_name='/path/to/file')
    assert loader.file_name == '/path/to/file'

    # Test vault_secrets and file_name

# Generated at 2022-06-17 06:47:11.157065
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    foo: 1
    bar:
      baz: 3
    """

    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), dict)
    assert loader.get_single_data() == {'foo': 1, 'bar': {'baz': 3}}

    dumper = AnsibleDumper()
    assert dumper.represent_data(loader.get_single_data()) == data

    # test unicode string
    data = u"\u2713"
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleUnicode)

# Generated at 2022-06-17 06:47:25.496224
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB

# Generated at 2022-06-17 06:47:38.284178
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:47:47.962445
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:47:53.695624
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
   

# Generated at 2022-06-17 06:48:04.855935
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

    # Test AnsibleSequence
    assert isinstance(AnsibleLoader('').construct_yaml_seq(''), AnsibleSequence)

    # Test AnsibleMapping

# Generated at 2022-06-17 06:48:12.582815
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO

    stream = BytesIO(b'---\n- hosts: localhost\n  tasks:\n  - name: test\n    debug:\n      msg: hello world')
    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-17 06:48:26.841360
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo: 1
    bar:
      baz: 3
      boo: [ "a", "b", "c" ]
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()

    assert isinstance(data, dict)
    assert isinstance(data['foo'], int)
    assert isinstance(data['bar'], dict)
    assert isinstance(data['bar']['baz'], int)
    assert isinstance(data['bar']['boo'], list)
    assert isinstance(data['bar']['boo'][0], AnsibleUnicode)

   

# Generated at 2022-06-17 06:48:32.250321
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=protected-access
    loader = AnsibleLoader(None)
    assert loader._construct_mapping is AnsibleConstructor._construct_mapping
    assert loader._construct_yaml_map is AnsibleConstructor._construct_yaml_map
    assert loader._construct_yaml_seq is AnsibleConstructor._construct_yaml_seq
    assert loader._construct_yaml_str is AnsibleConstructor._construct_yaml_str
    assert loader._construct_yaml_int is AnsibleConstructor._construct_yaml_int
    assert loader._construct_yaml_float is AnsibleConstructor._construct_yaml_float
    assert loader._construct_yaml_bool is AnsibleConstructor._construct_yaml_bool
    assert loader._construct_yaml_null is AnsibleConstructor._construct_yaml

# Generated at 2022-06-17 06:48:43.339716
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword

    vault_password = VaultPassword('secret')
    vault_secrets = [VaultSecret('secret', vault_password)]
    vault = VaultLib(vault_secrets)

    # Test AnsibleLoader with vault_secrets
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)
    assert isinstance(loader.vault, VaultLib)
    assert loader.vault.secrets == vault_secrets

    # Test AnsibleLoader with vault
    loader = AnsibleLoader(None, vault=vault)

# Generated at 2022-06-17 06:48:50.910570
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=unused-variable
    loader = AnsibleLoader(None)

# Generated at 2022-06-17 06:49:09.567710
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultVersionedUnicode

    # Test AnsibleLoader.construct_yaml_map
    data = '''
    a: 1
    b:
      c: 3
      d: 4
    '''
    loader = AnsibleLoader(data)
    loader

# Generated at 2022-06-17 06:49:18.810822
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:49:25.877532
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:49:38.931097
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secrets = [VaultSecret('secret', 'password')]
    vault = VaultLib(vault_secrets)

# Generated at 2022-06-17 06:49:48.035947
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor of AnsibleLoader
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)
    assert isinstance(loader, Resolver)
    assert isinstance(loader, Parser)
    assert isinstance(loader, AnsibleConstructor)

    # Test the constructor of AnsibleDumper
    dumper = AnsibleDumper(None)
    assert isinstance(dumper, AnsibleDumper)

    # Test the constructor of AnsibleVaultEncryptedUnicode
    encrypted_unicode = AnsibleVaultEncryptedUnicode(None, None)

# Generated at 2022-06-17 06:49:57.585128
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleLoader(unittest.TestCase):

        def setUp(self):
            self.loader = AnsibleLoader(None)

        def tearDown(self):
            pass

        def test_construct_yaml_str(self):
            node = self.loader.construct_yaml_str(None)
            self.assertIsInstance(node, str)

        def test_construct_yaml_seq(self):
            node = self.loader.construct

# Generated at 2022-06-17 06:50:07.191547
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-17 06:50:16.451763
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

    from ansible.parsing.yaml.dumper import AnsibleDumper

    from ansible.parsing.yaml.loader import AnsibleLoader

    from ansible.parsing.yaml.utils import yaml_load
    from ansible.parsing.yaml.utils import yaml_dump

    from ansible.parsing.vault import VaultLib

    from ansible.module_utils.six import text_type

    from io import StringIO

    vault_pass

# Generated at 2022-06-17 06:50:26.943856
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secrets = [VaultSecret('secret', 'password')]
    vault = VaultLib(vault_secrets)

    # Test with vault_secrets

# Generated at 2022-06-17 06:50:46.936031
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedYAML
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedJSON

# Generated at 2022-06-17 06:50:56.942718
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test loading of a vault-encrypted string

# Generated at 2022-06-17 06:51:09.102810
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # test unicode
    data = AnsibleLoader(u"foo: bar").get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert isinstance(data[u'foo'], AnsibleUnicode)
    assert data[u'foo'] == u'bar'
    assert AnsibleDumper().dump(data) == u"{foo: bar}\n...\n"

    # test list
    data = AnsibleLoader(u"- foo\n- bar").get_single_

# Generated at 2022-06-17 06:51:13.780726
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    vault_password = '$6$foobar'
    vault = VaultLib(vault_password)
    data = vault.encrypt(b'foo')
    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    loader = AnsibleLoader(data, vault_secrets=[vault])
    assert loader.get_single_data() == b'foo'

# Generated at 2022-06-17 06:51:20.782588
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB

# Generated at 2022-06-17 06:51:28.866574
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    # Test AnsibleLoader
    data = '''
    - hosts:
        - localhost
      tasks:
        - name: test
          debug: msg="hello world"
    '''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    assert isinstance(loader.get_single_data()['hosts'], AnsibleSequence)

# Generated at 2022-06-17 06:51:35.461657
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO
    stream = BytesIO(b"{% raw %}foo{% endraw %}")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == 'foo'

# Generated at 2022-06-17 06:51:44.607141
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from io import StringIO
    from ansible.module_utils._text import to_bytes, to_text

    vault_password = '$ecret'
    vault = VaultLib(vault_password)
    data = {'foo': 'bar', 'baz': 'quux', 'blah': [1, 2, 3]}
    stream = StringIO()
    AnsibleDumper(stream, None, Dumper=AnsibleDumper).dump(data)
    stream.seek(0)
    encrypted_data

# Generated at 2022-06-17 06:51:54.352640
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES

# Generated at 2022-06-17 06:52:00.781342
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO

    data = b'{ "test": "data" }'
    stream = BytesIO(data)
    loader = AnsibleLoader(stream)
    assert loader.get_single_data() == {u'test': u'data'}

# Generated at 2022-06-17 06:52:32.311422
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

    #

# Generated at 2022-06-17 06:52:41.678911
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO
    # test for AnsibleUnicode
    stream = BytesIO(b"foo: bar\n")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['foo'], AnsibleUnicode)
    assert data['foo']

# Generated at 2022-06-17 06:52:50.774277
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:52:56.105699
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleLoader
    data = """
    foo:
      - bar
      - baz
    """
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    assert isinstance(loader.get_single_data()['foo'], AnsibleSequence)

# Generated at 2022-06-17 06:53:04.006390
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    ---
    - hosts: localhost
      gather_facts: no
      tasks:
        - name: test
          debug:
            msg: "{{ '{\"a\": 1, \"b\": [1, 2, 3]}' | from_json }}"
    '''

    loader = AnsibleLoader(data)
    dumper = AnsibleDumper()

    obj = loader.get_single_data()
    assert isinstance(obj, AnsibleSequence)

# Generated at 2022-06-17 06:53:15.073499
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
        bar:
            baz: hello
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert data['foo']['bar']['baz'] == 'hello'

    dumper = AnsibleDumper()
    data = dumper.represent_data(data)
    assert data == 'foo:\n  bar:\n    baz: hello\n'

    data = '''
    foo:
        bar:
            baz: hello
    '''


# Generated at 2022-06-17 06:53:26.016919
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo: 1
    bar:
      baz: 2
    '''

    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), dict)
    assert isinstance(loader.get_single_data()['foo'], int)
    assert isinstance(loader.get_single_data()['bar']['baz'], int)

    # test the dumper
    dumper = AnsibleDumper()
    assert isinstance(dumper.represent_data(loader.get_single_data()), AnsibleUnicode)

# Generated at 2022-06-17 06:53:37.746976
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

    data = '''
    foo: bar
    baz:
      - 1
      - 2
      - 3
    '''

    loader = TestLoader(data)
    data = loader.get_single_data()

    assert data['foo'] == 'bar'
    assert data['baz'] == [1, 2, 3]

    dumper = AnsibleDumper()

# Generated at 2022-06-17 06:53:49.135248
# Unit test for constructor of class AnsibleLoader