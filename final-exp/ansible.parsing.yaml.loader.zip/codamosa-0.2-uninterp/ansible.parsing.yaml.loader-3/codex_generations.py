

# Generated at 2022-06-17 06:43:54.041240
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:44:01.218949
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

    data = '''
    foo:
      - bar: baz
      - bam: baz
    '''

    stream = io.StringIO(data)
    loader = TestAnsibleLoader(stream)
    result = loader.get_single_data()

    assert isinstance(result, dict)
    assert isinstance(result['foo'], list)

# Generated at 2022-06-17 06:44:10.826880
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

    # Test the AnsibleConstructor
    assert loader.file_name is None
    assert loader.vault_secrets is None
    assert loader.vault is None
    assert loader.vault_password is None
    assert loader.vault_version is None
    assert loader.vault_id is None
    assert loader.vault_ids is None
    assert loader.vault_prompt is None
    assert loader.vault_only_if_changed is False
    assert loader.vault_marker is None

# Generated at 2022-06-17 06:44:21.688298
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:44:28.140381
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.nodes import AnsibleScalarNode
    import sys
    import io
    import yaml

    class MyLoader(AnsibleLoader):
        def __init__(self, stream):
            AnsibleLoader.__init__(self, stream)

    class MyDumper(AnsibleDumper):
        def __init__(self, stream):
            AnsibleDumper.__init__(self, stream)

    # Test AnsibleLoader


# Generated at 2022-06-17 06:44:39.845424
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor
    loader = AnsibleLoader(None)
    assert loader.file_name is None
    assert loader.vault_secrets is None
    assert loader.get_constructor('tag:yaml.org,2002:str') == AnsibleConstructor.construct_scalar
    assert loader.get_constructor('tag:yaml.org,2002:python/unicode') == AnsibleConstructor.construct_yaml_str
    assert loader.get_constructor('tag:yaml.org,2002:python/str') == AnsibleConstructor.construct_yaml_str

# Generated at 2022-06-17 06:44:51.435325
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test with vault_secrets
    vault_secrets = {'vault_password': 'secret'}
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)
    assert loader.vault_secrets == vault_secrets

    # Test with file_name
    file_name = 'test.yml'

# Generated at 2022-06-17 06:44:57.827123
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleMapping

# Generated at 2022-06-17 06:45:07.955344
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

    # Test AnsibleSequence
    assert isinstance(AnsibleLoader('').construct_yaml_seq(''), AnsibleSequence)

    # Test AnsibleMapping
    assert isinstance(AnsibleLoader('').construct_yaml_map(''), AnsibleMapping)

    # Test AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:45:19.878101
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.loader import AnsibleLoaderError
    from ansible.parsing.yaml.utils import yaml_load
    from ansible.parsing.yaml.utils import yaml_dump


# Generated at 2022-06-17 06:45:29.016437
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    import unittest

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    class TestAnsibleLoader(unittest.TestCase):
        def test_construct_yaml_str(self):
            loader = AnsibleLoader(None)

# Generated at 2022-06-17 06:45:30.244558
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-17 06:45:31.968334
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=too-many-function-args
    AnsibleLoader(None, None, None)

# Generated at 2022-06-17 06:45:42.960724
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)
    assert isinstance(loader, Resolver)
    assert isinstance(loader, AnsibleConstructor)
    assert isinstance(loader, Parser)

    # test AnsibleConstructor
    assert loader.file_name is None
    assert loader.vault_secrets is None
    assert loader.vault is None
    assert loader.vault_password is None
    assert loader.vault_version == 1
    assert loader.vault_ids is None
    assert loader.vault_support_v1 is True

# Generated at 2022-06-17 06:45:54.173593
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

    data = '''
    foo: bar
    baz:
      - 1
      - 2
      - 3
    '''

    # Test with AnsibleLoader
    loader = TestAnsibleLoader(data)
    result = loader.get_single_data()
    assert result['foo'] == 'bar'
    assert result['baz'] == [1, 2, 3]

    #

# Generated at 2022-06-17 06:46:05.518496
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils.six import PY3
    import sys

    if PY3:
        unicode = str

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return self.construct_scalar(node)

        def construct_undefined(self, node):
            raise Exception('Undefined construction: %s' % node.id)

    data = '''
    foo: 1
    bar:
      baz: 3
    '''

    stream = TestAnsibleLoader(data)
   

# Generated at 2022-06-17 06:46:14.682979
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:46:27.070613
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader


# Generated at 2022-06-17 06:46:36.944666
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256SIV
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OCB

# Generated at 2022-06-17 06:46:42.490717
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO

    stream = BytesIO(b'{ "foo": "bar" }')
    loader = AnsibleLoader(stream)
    assert loader.get_single_data() == {u'foo': u'bar'}

# Generated at 2022-06-17 06:46:55.091953
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:47:06.358374
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-17 06:47:18.555437
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-17 06:47:28.338941
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleScalar

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import Ans

# Generated at 2022-06-17 06:47:40.322400
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test that AnsibleLoader can load a vault encrypted string

# Generated at 2022-06-17 06:47:49.677481
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    import unittest
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedString
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(unittest.TestCase):

        def setUp(self):
            self.loader = AnsibleLoader(None)

        def tearDown(self):
            pass

        def test_construct_yaml_str(self):
            node = self.loader.construct_yaml_str(None)
            self.assertEqual(node, '')

        def test_construct_yaml_seq(self):
            node = self.loader.construct_yaml_seq(None)
            self.assertEqual(node, [])



# Generated at 2022-06-17 06:48:02.441724
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:48:10.168780
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:48:17.295433
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode


# Generated at 2022-06-17 06:48:27.655948
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import tempfile
    import shutil
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, yaml_file = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create the YAML file
    with open(yaml_file, "w") as f:
        f.write("""
        ---
        - hosts: localhost
          tasks:
          - name: test
            debug:
              msg: "Hello World!"
        """)

    # Create the JSON file
    json_file = yaml_file + ".json"

# Generated at 2022-06-17 06:48:49.894150
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

    # Test AnsibleSequence
    assert isinstance(AnsibleLoader('').construct_yaml_seq(''), AnsibleSequence)

    # Test AnsibleMapping
    assert isinstance(AnsibleLoader('').construct_yaml_map(''), AnsibleMapping)

    # Test AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:49:08.309646
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-17 06:49:18.738154
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader("test").get_single_data(), AnsibleUnicode)

    # Test AnsibleSequence
    assert isinstance(AnsibleLoader("- test").get_single_data(), AnsibleSequence)

    # Test AnsibleMapping

# Generated at 2022-06-17 06:49:25.828303
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC

    # Test with vault_secrets

# Generated at 2022-06-17 06:49:38.931263
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:49:48.678586
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor
    data = {'foo': 'bar'}
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == data

    # Test the constructor with a vault secret
    data = {'foo': 'bar'}
    loader = AnsibleLoader(data, vault_secrets=['secret'])
    assert loader.get_single_data() == data

    # Test the constructor with a vault secret
    data = {'foo': 'bar'}
    loader = AnsibleLoader(data, vault_secrets=['secret'])
    assert loader.get_single_data() == data

    # Test the constructor with

# Generated at 2022-06-17 06:49:55.830828
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (2, 7):
        from io import StringIO
    else:
        from StringIO import StringIO

    stream = StringIO(u'---\n- hosts: localhost\n  gather_facts: false\n  tasks:\n    - debug: msg="Hello World!"\n')
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {'hosts': 'localhost', 'gather_facts': False, 'tasks': [{'debug': {'msg': 'Hello World!'}}]}

# Generated at 2022-06-17 06:50:05.439182
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:50:12.430825
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    data = """
    ---
    - hosts: localhost
      gather_facts: no
      tasks:
        - name: test
          debug:
            msg: "{{ '{0}' | to_nice_yaml }}"
    """

    stream = StringIO(data)
    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-17 06:50:26.112940
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import BytesIO
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:50:54.702647
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB

# Generated at 2022-06-17 06:51:06.357957
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import io
    import sys
    import yaml

    class UnicodeConstructor(AnsibleLoader):
        def construct_yaml_str(self, node):
            return AnsibleUnicode(self.construct_scalar(node))

    class UnicodeRepresenter(AnsibleDumper):
        def represent_unicode(self, data):
            return self.represent_scalar(u'tag:yaml.org,2002:str', data)

    yaml.add_constructor(u'tag:yaml.org,2002:str', UnicodeConstructor.construct_yaml_str)

# Generated at 2022-06-17 06:51:16.356876
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY3

    if PY3:
        unicode = str

    vault_secrets = [{'vault_password': 'secret'}]
    vault = VaultLib(vault_secrets)


# Generated at 2022-06-17 06:51:29.124117
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo: 1
    bar:
      baz: 3
      '''

    loader = AnsibleLoader(data)
    assert loader.get_single_data() == {'foo': 1, 'bar': {'baz': 3}}
    assert isinstance(loader.get_single_data()['foo'], int)
    assert isinstance(loader.get_single_data()['bar'], dict)
    assert isinstance(loader.get_single_data()['bar']['baz'], int)

    dumper = AnsibleDumper()
    assert dumper.represent_data(loader.get_single_data()) == data

   

# Generated at 2022-06-17 06:51:40.357340
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_yaml_str(None), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(u'foo'), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(u'foo'), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(u'foo'), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(u'foo'), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(u'foo'), AnsibleUnicode)

# Generated at 2022-06-17 06:51:52.420552
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleMapping
    data = AnsibleMapping()
    data['key1'] = 'value1'
    data['key2'] = 'value2'
    assert data['key1'] == 'value1'
    assert data['key2'] == 'value2'

# Generated at 2022-06-17 06:51:56.571458
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO

    stream = BytesIO(b'{"a": "b"}')
    loader = AnsibleLoader(stream)
    assert loader.get_single_data() == {'a': 'b'}

# Generated at 2022-06-17 06:52:01.601422
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    import io

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleLoader(unittest.TestCase):

        def setUp(self):
            self.loader = AnsibleLoader
            self.dumper = AnsibleDumper

        def test_constructor(self):
            stream = io.StringIO(u"---\n- hosts: localhost\n  tasks:\n  - name: test\n    debug: msg=\"hello world\"\n")
           

# Generated at 2022-06-17 06:52:08.218927
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test the AnsibleLoader class
    data = """
    ---
    - hosts: localhost
      tasks:
      - debug: msg="hello world"
    """

    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    assert isinstance(loader.get_single_data()['hosts'], AnsibleUnicode)

# Generated at 2022-06-17 06:52:14.071454
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB


# Generated at 2022-06-17 06:53:01.707366
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:53:11.387418
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar
      - baz
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert isinstance(data['foo'][0], AnsibleUnicode)
    assert isinstance(data['foo'][1], AnsibleUnicode)

    dumper = AnsibleDumper()
    assert dumper.represent_data(data) == '{foo: [bar, baz]}\n'

# Generated at 2022-06-17 06:53:16.709516
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:53:25.795259
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
   

# Generated at 2022-06-17 06:53:33.230143
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    import yaml

    vault_password = '$6$foobar'
    vault = VaultLib(vault_password)
    data = {'foo': 'bar', 'baz': 'qux'}
    encrypted_data = vault.encrypt(yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False))
    stream = yaml.load(encrypted_data, Loader=AnsibleLoader)
    assert isinstance(stream, dict)

# Generated at 2022-06-17 06:53:40.917596
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
