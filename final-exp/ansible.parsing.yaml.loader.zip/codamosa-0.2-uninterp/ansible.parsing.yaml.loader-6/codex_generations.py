

# Generated at 2022-06-17 06:43:49.798146
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleLoader(unittest.TestCase):
        def test_constructor(self):
            loader = AnsibleLoader(None)
            self.assertIsInstance(loader, AnsibleLoader)

    unittest.main()

# Generated at 2022-06-17 06:44:00.610834
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (2, 7):
        from unittest import TestCase
    else:
        from unittest2 import TestCase

    class TestAnsibleLoader(TestCase):
        def test_constructor(self):
            loader = AnsibleLoader(None)
            self.assertIsInstance(loader, AnsibleLoader)
            self.assertIsInstance(loader, Reader)
            self.assertIsInstance(loader, Scanner)
            self.assertIsInstance(loader, Parser)
            self.assertIsInstance(loader, Composer)
            self.assertIsInstance(loader, AnsibleConstructor)
            self.assertIsInstance(loader, Resolver)

    test_case = TestAnsibleLoader()
    test_case.test_constructor()

# Generated at 2022-06-17 06:44:10.059029
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from io import StringIO
    import yaml

    vault_password = '$6$foobar'
    vault = VaultLib(vault_password)
    data = dict(foo='bar', baz='qux', vault=vault.encrypt('my secret'))
    stream = StringIO()
    yaml.dump(data, stream, Dumper=AnsibleDumper, default_flow_style=False)
    stream.seek(0)

# Generated at 2022-06-17 06:44:21.168745
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

    vault_password = '$6$foobar'
    vault = VaultLib(vault_password)

    # Test AnsibleLoader with vault_secrets

# Generated at 2022-06-17 06:44:27.833216
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVault

# Generated at 2022-06-17 06:44:38.141353
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar
      - baz
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert isinstance(data['foo'][0], AnsibleUnicode)
    assert isinstance(data['foo'][1], AnsibleUnicode)

    dumper = AnsibleDumper()
    assert dumper.represent_data(data) == '''foo:\n- bar\n- baz\n'''

# Generated at 2022-06-17 06:44:49.359526
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import StringIO

    stream = StringIO(u"---\n- hosts: localhost\n  tasks:\n  - name: test\n    debug:\n      msg: '{{ ansible_env.HOME }}'\n")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert isinstance(data[0]['tasks'][0]['debug']['msg'], AnsibleUnicode)

# Generated at 2022-06-17 06:45:01.648366
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

    # Test AnsibleSequence
    assert isinstance(AnsibleLoader('').construct_yaml_seq(''), AnsibleSequence)

    # Test AnsibleMapping
    assert isinstance(AnsibleLoader('').construct_yaml_map(''), AnsibleMapping)

    # Test AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:45:15.096095
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CTR

# Generated at 2022-06-17 06:45:27.931875
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultSecretStdin

    vault_secrets = [
        VaultSecret('secret0', 'password0'),
        VaultSecret('secret1', VaultPassword('password1')),
        VaultSecret('secret2', VaultSecretStdin('password2')),
        VaultSecret('secret3', VaultSecretStdin('password3')),
        VaultSecret('secret4', VaultSecretStdin('password4')),
    ]


# Generated at 2022-06-17 06:45:41.899425
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:45:53.432372
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleUnsafeBytes
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    from ansible.parsing.yaml.objects import AnsibleScalarBoolean
    from ansible.parsing.yaml.objects import AnsibleScalarFloat
    from ansible.parsing.yaml.objects import Ans

# Generated at 2022-06-17 06:46:03.007766
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar
      - baz
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert isinstance(data['foo'][0], AnsibleUnicode)
    assert isinstance(data['foo'][1], AnsibleUnicode)

    dumper = AnsibleDumper()
    output = dumper.dump(data)
    assert output == data

# Generated at 2022-06-17 06:46:13.519303
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode, AnsibleMappingNode

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(None), AnsibleUnicode)

    # Test AnsibleSequence
    assert isinstance(AnsibleLoader('').construct_yaml_seq(None), AnsibleSequence)
    assert isinstance(AnsibleLoader('').construct_yaml_seq(AnsibleSequenceNode()), AnsibleSequence)

# Generated at 2022-06-17 06:46:25.113037
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar:
          baz: 1
      - bar:
          baz: 2
    '''

    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleUnicode)
    assert loader.get_single_data() == data

    dumper = AnsibleDumper()
    assert dumper.represent_data(loader.get_single_data()) == data

# Generated at 2022-06-17 06:46:34.468708
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES

# Generated at 2022-06-17 06:46:45.400125
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    ---
    - hosts: localhost
      gather_facts: no
      tasks:
        - debug:
            msg: "System {{ inventory_hostname }} has uuid {{ ansible_product_uuid }}"
    '''

    loader = AnsibleLoader(data)
    datastructure = loader.get_single_data()

    assert isinstance(datastructure[0]['hosts'], AnsibleUnicode)
    assert isinstance(datastructure[0]['tasks'][0]['debug']['msg'], AnsibleUnicode)

    dumper = AnsibleDumper()

# Generated at 2022-06-17 06:46:54.401933
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword

    vault_secret = VaultSecret('secret', 'password')
    vault_password = VaultPassword(vault_secret)
    vault_secrets = [vault_password]
    vault_lib = VaultLib(vault_secrets)


# Generated at 2022-06-17 06:47:01.474446
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (2, 7):
        from unittest import TestCase
    else:
        from unittest2 import TestCase

    class TestAnsibleLoader(TestCase):
        def test_AnsibleLoader(self):
            from ansible.parsing.yaml.objects import AnsibleUnicode
            from ansible.parsing.yaml.loader import AnsibleLoader
            from ansible.parsing.yaml.dumper import AnsibleDumper

            data = '''
            foo:
                bar:
                    baz: hello
            '''

            data2 = '''
            foo:
                bar:
                    baz: hello
            '''

            data3 = '''
            foo:
                bar:
                    baz: hello
            '''

            data

# Generated at 2022-06-17 06:47:11.156798
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor of AnsibleLoader
    # Test the constructor of AnsibleConstructor
    # Test the constructor of AnsibleUnicode
    # Test the constructor of AnsibleSequence
    # Test the constructor of AnsibleMapping
    # Test the constructor of AnsibleDumper
    loader = AnsibleLoader(None)
    assert loader is not None
    assert loader.file_name is None
    assert loader.vault_secrets is None
    assert loader.stream is None
    assert loader.index is 0


# Generated at 2022-06-17 06:47:26.551694
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test AnsibleLoader.construct_yaml_map
    data = """
    foo: bar
    baz:
      - 1
      - 2
      - 3
    """
    loader = AnsibleLoader(data)
    loader.get_single_data()
    assert isinstance(loader.get_single_data(), AnsibleMapping)

# Generated at 2022-06-17 06:47:38.423507
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    if sys.version_info >= (3, 0):
        unicode = str
    data = """
    foo: 1
    bar:
      baz: 3
      qux: 4
    """
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    assert isinstance(loader.get_single_data()['foo'], int)

# Generated at 2022-06-17 06:47:48.103597
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY3
    import sys

    if PY3:
        unicode = str


# Generated at 2022-06-17 06:47:55.306960
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    import unittest

    class TestAnsibleLoader(unittest.TestCase):
        def setUp(self):
            self.yaml_str = """
            - hosts: localhost
              tasks:
              - name: test
                debug:
                  msg: "{{ test_var }}"
                vars:
                  test_var: "{{ test_var }}"
            """
            self.yaml_str_2 = """
            - hosts: localhost
              tasks:
              - name: test
                debug:
                  msg: "{{ test_var }}"
                vars:
                  test_var: "{{ test_var }}"
            """

# Generated at 2022-06-17 06:48:05.850933
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    # Test AnsibleLoader
    data = '''
    - hosts: localhost
      tasks:
      - name: test
        debug:
          msg: "{{ test_var }}"
    '''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleMapping)

# Generated at 2022-06-17 06:48:15.220785
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=protected-access
    assert AnsibleLoader._construct_yaml_str == AnsibleConstructor._construct_yaml_str
    assert AnsibleLoader._construct_yaml_seq == AnsibleConstructor._construct_yaml_seq
    assert AnsibleLoader._construct_yaml_map == AnsibleConstructor._construct_yaml_map
    assert AnsibleLoader._construct_yaml_omap == AnsibleConstructor._construct_yaml_omap
    assert AnsibleLoader._construct_yaml_set == AnsibleConstructor._construct_yaml_set
    assert AnsibleLoader._construct_yaml_pairs == AnsibleConstructor._construct_yaml_pairs
    assert AnsibleLoader._construct_yaml_int == AnsibleConstructor._construct_yaml_int
    assert AnsibleLoader._construct_

# Generated at 2022-06-17 06:48:27.237585
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test for AnsibleUnicode
    assert isinstance(AnsibleLoader('foo').get_single_data(), AnsibleUnicode)

    # Test for AnsibleSequence
    assert isinstance(AnsibleLoader('[foo, bar]').get_single_data(), AnsibleSequence)

    # Test for AnsibleMapping

# Generated at 2022-06-17 06:48:32.480570
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

    data = '''
    foo: 1
    bar:
      baz: 3
    '''

    stream = TestAnsibleLoader(data)
    data = stream.get_single_data()

    assert isinstance(data['foo'], AnsibleUnicode)
    assert isinstance(data['bar']['baz'], AnsibleUnicode)

    # Test that Ans

# Generated at 2022-06-17 06:48:43.429881
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib

    # Create the vault object
    vault_password = 'secret'
    vault = VaultLib(vault_password)

    # Create the loader object
    loader = AnsibleLoader(None, vault_secrets=vault)

    # Create the dumper object
    dumper = AnsibleDumper()

    # Create the encrypted string
    encrypted_string = vault.encrypt('test')

    # Create the encrypted object
    encrypted_object = AnsibleVaultEncryptedUnicode(encrypted_string)

    # Dump the encrypted object

# Generated at 2022-06-17 06:48:52.514435
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeBytes
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    from ansible.parsing.yaml.objects import AnsibleScalar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # Test AnsibleBaseYAMLObject
    assert issubclass

# Generated at 2022-06-17 06:49:12.027307
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test for AnsibleUnicode
    data = b'foo: bar'
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleUnicode)

    # Test for AnsibleSequence
    data = b'- foo\n- bar'
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleSequence)

    # Test for AnsibleMapping

# Generated at 2022-06-17 06:49:28.730586
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:49:40.899461
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test AnsibleLoader.construct_yaml_map

# Generated at 2022-06-17 06:49:49.099580
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:49:58.215810
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

    # Test AnsibleSequence
    assert isinstance(AnsibleLoader('').construct_yaml_seq(''), AnsibleSequence)

    # Test AnsibleMapping
    assert isinstance(AnsibleLoader('').construct_yaml_map(''), AnsibleMapping)

    # Test AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:50:07.254688
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test for AnsibleUnicode
    stream = u'foo'
    loader = AnsibleLoader(stream)
    assert isinstance(loader.get_single_data(), AnsibleUnicode)

    # Test for AnsibleSequence
    stream = u'[foo, bar]'
    loader = AnsibleLoader(stream)
    assert isinstance(loader.get_single_data(), AnsibleSequence)

    # Test for AnsibleMapping
    stream = u'{foo: bar}'

# Generated at 2022-06-17 06:50:16.528161
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-17 06:50:26.945265
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # test AnsibleLoader.construct_yaml_map
    loader = AnsibleLoader(None)
    data = loader.construct_yaml_map(None)
    assert isinstance(data, AnsibleMapping)

    # test AnsibleLoader.construct_yaml_seq
    loader = AnsibleLoader(None)
    data = loader.construct

# Generated at 2022-06-17 06:50:31.897907
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    foo: 1
    bar:
      baz: 3
    """

    loader = AnsibleLoader(data)
    data = loader.get_single_data()

    assert data['foo'] == 1
    assert data['bar']['baz'] == 3

    dumper = AnsibleDumper()
    output = dumper.dump(data, Dumper=AnsibleDumper)

    assert output == data

# Generated at 2022-06-17 06:50:41.809151
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:51:11.016796
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    import yaml
    import sys
    import os

    # create a vault secret
    vault_secret = VaultSecret('secret')

    # create a vault object
    vault = VaultLib([vault_secret])

    # create a vault encrypted string
    vault_encrypted_string = vault.encrypt('test')

    # create a vault encrypted string with newlines
    vault_encrypted_string_with_newlines = vault.encrypt('test\ntest')

    # create a vault encrypted string with newlines and spaces
    vault_encrypted_

# Generated at 2022-06-17 06:51:19.069698
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB


# Generated at 2022-06-17 06:51:27.950878
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
    foo:
      - bar: baz
      - bam: bop
      - bam:
          bop: bap
    '''

    data2 = '''
    foo:
      - bar: baz
      - bam: bop
      - bam:
          bop: bap
    '''

    data3 = '''
    foo:
      - bar: baz
      - bam: bop
      - bam:
          bop: bap
    '''


# Generated at 2022-06-17 06:51:39.475792
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedBytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedMapping

# Generated at 2022-06-17 06:51:47.066653
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

    data = '''
    foo: 1
    bar:
      baz: 3
      boo: [ "a", "b", "c" ]
    '''

    # Test with file name
    loader = TestAnsibleLoader(data, file_name='test_file')
    data = loader.get_single_data()

# Generated at 2022-06-17 06:51:52.591429
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB

# Generated at 2022-06-17 06:52:01.052343
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.loader import AnsibleLoaderException
    from ansible.parsing.yaml.loader import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:52:07.849098
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

    data = '''
    - foo: bar
      bam: [1, 2, 3]
    - foo: bar
      bam: [4, 5, 6]
    '''

    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleSequence)
    assert isinstance(loader.get_single_data()[0], AnsibleMapping)
    assert isinstance(loader.get_single_data()[0]['foo'], AnsibleUnicode)

# Generated at 2022-06-17 06:52:13.994208
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:52:27.457428
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:53:18.951420
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    import io
    import yaml

    class UnicodeOnly(AnsibleUnicode):
        pass

    class UnicodeOnlyLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return self.construct_scalar(node)


# Generated at 2022-06-17 06:53:27.091406
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-17 06:53:36.551066
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO
    stream = BytesIO(b"---\n- hosts: localhost\n  tasks:\n  - name: test\n    debug: msg=\"hello world\"\n")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {'hosts': 'localhost', 'tasks': [{'debug': {'msg': 'hello world'}, 'name': 'test'}]}

# Generated at 2022-06-17 06:53:43.412362
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    stream = StringIO(u"---\n- hosts: localhost\n  tasks:\n  - name: test\n    debug: msg=\"hello world\"\n")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == [{u'hosts': u'localhost', u'tasks': [{u'name': u'test', u'debug': {u'msg': u'hello world'}}]}]