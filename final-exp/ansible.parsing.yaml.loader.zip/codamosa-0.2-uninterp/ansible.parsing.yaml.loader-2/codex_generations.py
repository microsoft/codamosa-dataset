

# Generated at 2022-06-17 06:43:46.051624
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar
      - baz
    '''

    data2 = '''
    foo:
      - bar
      - baz
    '''

    data3 = '''
    foo:
      - bar
      - baz
    '''

    data4 = '''
    foo:
      - bar
      - baz
    '''

    data5 = '''
    foo:
      - bar
      - baz
    '''


# Generated at 2022-06-17 06:43:57.815800
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Create a vault password file
    fd, vault_password_file = tempfile.mkstemp()
    os.close(fd)

    # Write vault password to file
    with open(vault_password_file, 'wb') as f:
        f.write('password')

    # Create a vault encrypted file
    fd, vault_encrypted_file = tempfile.mkstemp()
    os.close(fd)

    # Write vault encrypted data to file


# Generated at 2022-06-17 06:44:08.803909
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestLoader(AnsibleLoader):
        pass

    class TestDumper(AnsibleDumper):
        pass

    data = '''
    foo:
      - bar
      - baz
    '''

    stream = TestLoader(data)
    data = stream.get_single_data()
    assert data == {'foo': ['bar', 'baz']}

    stream = TestLoader(data)
    data = stream.get_single_data()
    assert data == {'foo': ['bar', 'baz']}

    stream = TestLoader(data)
    data = stream.get_single_data()

# Generated at 2022-06-17 06:44:20.403306
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor of class AnsibleLoader
    #
    # AnsibleLoader is a subclass of yaml.composer.Composer,
    # yaml.reader.Reader, yaml.scanner.Scanner, yaml.parser.Parser,
    # ansible.parsing.yaml.constructor.AnsibleConstructor,
    # yaml.resolver.Resolver.
    #
    # The constructor of class AnsibleLoader calls the constructor of
    # its superclass.
    #
    # The constructor of class AnsibleConstructor calls the constructor
    # of its superclass.
    #
    # The constructor of class Parser calls the constructor of

# Generated at 2022-06-17 06:44:23.718175
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB

# Generated at 2022-06-17 06:44:29.247675
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:44:40.319505
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test with a string
    stream = '''
    - hosts: localhost
      tasks:
      - name: test
        debug:
          msg: "hello world"
    '''
    loader = AnsibleLoader(stream)
    assert loader.get_single_data() == {'hosts': 'localhost', 'tasks': [{'name': 'test', 'debug': {'msg': 'hello world'}}]}

    # Test with a file
    stream = open('../../test/sanity/playbooks/test.yml')
    loader = AnsibleLoader(stream)
    assert loader.get_single_data() == {'hosts': 'localhost', 'tasks': [{'name': 'test', 'debug': {'msg': 'hello world'}}]}

# Generated at 2022-06-17 06:44:48.508696
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    stream = StringIO(u"---\n- {a: 1, b: 2}\n- {c: 3, d: 4}\n")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == [{u'a': 1, u'b': 2}, {u'c': 3, u'd': 4}]

# Generated at 2022-06-17 06:44:56.286237
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - 1
      - 2
      - 3
    bar:
      baz: quux
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()

    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['foo'], AnsibleSequence)
    assert isinstance(data['bar'], AnsibleMapping)

# Generated at 2022-06-17 06:45:03.299635
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
---
- hosts: localhost
  tasks:
    - name: test
      debug:
        msg: "{{ '{' }} foo: bar {'}' }}"
'''
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {'hosts': 'localhost', 'tasks': [{'name': 'test', 'debug': {'msg': '{ foo: bar }'}}]}

# Generated at 2022-06-17 06:45:18.647210
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test the AnsibleLoader class
    assert issubclass(AnsibleLoader, Parser)
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert issubclass(AnsibleLoader, Resolver)

    # Test the AnsibleConstructor class
    assert issubclass(AnsibleConstructor, AnsibleLoader)

    # Test the AnsibleDumper class
    assert issub

# Generated at 2022-06-17 06:45:25.755444
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    import unittest
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString

    class TestAnsibleLoader(unittest.TestCase):
        def setUp(self):
            self.loader = AnsibleLoader(None)

        def test_construct_yaml_str(self):
            node = self.loader.construct_yaml_str(None)
            self.assertEqual(node, '')

        def test_construct_yaml_seq(self):
            node = self.loader.construct_yaml_seq(None)
            self.assertEqual(node, [])


# Generated at 2022-06-17 06:45:37.809330
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:45:44.808816
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleScalarBoolean
    from ansible.parsing.yaml.objects import AnsibleScalarFloat
    from ansible.parsing.yaml.objects import AnsibleScalarInteger
    from ansible.parsing.yaml.objects import AnsibleScalarNull

# Generated at 2022-06-17 06:45:53.463604
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    data = StringIO("""
    ---
    - hosts: localhost
      gather_facts: no
      tasks:
      - name: test
        debug:
          msg: "{{ '{ \"a\": 1 }' | from_json }}"
    """)

    loader = AnsibleLoader(data)
    for item in loader:
        print(item)

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-17 06:46:05.057598
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:46:14.272781
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    # Test with a string
    data = u'{ foo: bar }'
    if PY3:
        data = data.encode('utf-8')
    stream = StringIO(data)
    loader = AnsibleLoader(stream)
    assert isinstance(loader.get_single_data(), AnsibleUnicode)

    # Test with a unicode string
    data = u'{ foo: bar }'
    stream = StringIO(data)
    loader = AnsibleLoader(stream)

# Generated at 2022-06-17 06:46:26.988442
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    if sys.version_info >= (3, 0):
        unicode = str
    data = '''
    foo: 1
    bar:
      baz: 3
      boo: [ "a", "b", "c" ]
    '''
    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert isinstance(data, dict)
    assert isinstance(data['foo'], int)
    assert isinstance(data['bar'], dict)
    assert isinstance(data['bar']['baz'], int)
    assert isinstance(data['bar']['boo'], list)
   

# Generated at 2022-06-17 06:46:36.920527
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    import yaml

    vault_password = '$1$JJsvHslK$fPV5Xe8a6crBz2onWxyac.'
    vault = VaultLib(vault_password)
    data = {'foo': 'bar', 'baz': 'qux', 'bam': {'baz': 'qux'}}
    encrypted_data = vault.encrypt(yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False))

# Generated at 2022-06-17 06:46:47.096570
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secrets = [VaultSecret('secret', 'password')]
    vault = VaultLib(vault_secrets)

# Generated at 2022-06-17 06:47:03.423750
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    stream = StringIO(u"""
    ---
    - hosts: all
      gather_facts: no
      tasks:
      - name: test
        shell: echo "{{ ansible_managed }}"
        args:
          executable: /bin/bash
    """)
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert isinstance(data[0]['tasks'][0]['name'], AnsibleUnicode)
    assert isinstance(data[0]['tasks'][0]['shell'], AnsibleUnicode)

# Generated at 2022-06-17 06:47:11.455490
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
   

# Generated at 2022-06-17 06:47:25.524337
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=protected-access
    loader = AnsibleLoader(None)
    assert loader._construct_mapping == AnsibleConstructor._construct_mapping
    assert loader._construct_sequence == AnsibleConstructor._construct_sequence
    assert loader._construct_yaml_map == AnsibleConstructor._construct_yaml_map
    assert loader._construct_yaml_seq == AnsibleConstructor._construct_yaml_seq
    assert loader._construct_yaml_str == AnsibleConstructor._construct_yaml_str
    assert loader._construct_yaml_int == AnsibleConstructor._construct_yaml_int
    assert loader._construct_yaml_float == AnsibleConstructor._construct_yaml_float
    assert loader._construct_yaml_bool == AnsibleConstructor._construct_yaml_bool
    assert loader

# Generated at 2022-06-17 06:47:38.293607
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    import yaml

    vault_password = '$6$foobar'
    vault = VaultLib(vault_password)

    # test loading of vault-encrypted strings
    data = dict(
        foo=dict(
            bar=vault.encrypt('test string'),
        ),
    )
    data_yaml = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-17 06:47:47.996874
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:47:59.912936
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import tempfile
    import unittest

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class TestAnsibleLoader(unittest.TestCase):

        def setUp(self):
            self.vault_password = '$1$JJsvHslK$fMV9aLZkKnLcGmFchTcqR1'
            self.vault_secrets = dict(vault_password=self.vault_password)

        def tearDown(self):
            pass

        def test_vault_constructor(self):
            '''
            Test vault constructor
            '''

# Generated at 2022-06-17 06:48:04.911450
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO
    loader = AnsibleLoader(StringIO(u"---\n- hosts: localhost\n  tasks:\n  - debug: msg='hello world'"))
    assert loader.get_single_data() == {u'hosts': u'localhost', u'tasks': [{u'debug': {u'msg': u'hello world'}}]}

# Generated at 2022-06-17 06:48:14.791569
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo: 1
    bar:
      baz: hello
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert data['foo'] == 1
    assert data['bar']['baz'] == 'hello'

    dumper = AnsibleDumper()
    output = dumper.dump(data)
    assert output == data

    data = '''
    foo: 1
    bar:
      baz: hello
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert data['foo'] == 1

# Generated at 2022-06-17 06:48:27.116091
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM

# Generated at 2022-06-17 06:48:34.863220
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    stream = StringIO(u'---\n- hosts: localhost\n  tasks:\n  - name: test\n    debug: msg="{{ ansible_distribution }}"\n')
    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-17 06:48:56.467483
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test the AnsibleLoader class
    # Test the AnsibleUnicode class
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

# Generated at 2022-06-17 06:49:05.779128
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO

    stream = BytesIO(b'{ "foo": "bar" }')
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {'foo': 'bar'}

# Generated at 2022-06-17 06:49:15.279598
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (2, 7):
        from io import StringIO
    else:
        from StringIO import StringIO

    stream = StringIO("""
---
- hosts: localhost
  tasks:
    - name: test
      debug: msg="hello world"
""")

    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-17 06:49:29.127994
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    vault_secrets = [VaultLib.VaultSecret('secret', 'password')]
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)
    assert loader.vault_secrets == vault_secrets
    assert loader.vault is not None

# Generated at 2022-06-17 06:49:36.367216
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    stream = StringIO("""
        ---
        - hosts: all
          tasks:
            - name: test
              debug:
                msg: "{{ 'hello world' | b64decode }}"
    """)

    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-17 06:49:46.507097
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    foo: 1
    bar:
      baz: 3
    """

    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), dict)
    assert isinstance(loader.get_single_data()['foo'], int)
    assert isinstance(loader.get_single_data()['bar']['baz'], int)

    data = """
    foo: 1
    bar:
      baz: 3
    """

    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), dict)

# Generated at 2022-06-17 06:49:57.186977
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:50:02.446263
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_yaml_str(None), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(u'foo'), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(u'foo'), AnsibleUnicode)

# Generated at 2022-06-17 06:50:15.053753
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test for AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:50:22.570939
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-17 06:50:46.901380
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-17 06:50:55.092303
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    ---
    - hosts: localhost
      tasks:
        - name: test
          debug:
            msg: "{{ '{{' }} foo {{ '}}' }}"
    '''

    loader = AnsibleLoader(data)
    dumper = AnsibleDumper()

    result = loader.get_single_data()
    assert result == dumper.represent_data(result)

# Generated at 2022-06-17 06:51:03.495896
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_yaml_str(None), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_seq(None), AnsibleSequence)
    assert isinstance(loader.construct_yaml_map(None), AnsibleMapping)

# Generated at 2022-06-17 06:51:13.986041
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

    data = '''
    foo: bar
    baz:
      - 1
      - 2
      - 3
    '''

    # Load the data
    loader = TestAnsibleLoader(data)
    data = loader.get_single_data()

    # Dump the data
    dumper = AnsibleDumper()

# Generated at 2022-06-17 06:51:21.558110
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.module_utils.common.yaml import Parser
    from yaml.resolver import Resolver

    class TestAnsibleLoader(Parser, AnsibleConstructor, Resolver):
        def __init__(self, stream, file_name=None, vault_secrets=None):
            Parser.__init__(self, stream)
            AnsibleConstructor.__init__(self, file_name=file_name, vault_secrets=vault_secrets)
            Resolver.__init__(self)

    assert TestAnsibleLoader

# Generated at 2022-06-17 06:51:29.316816
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(AnsibleLoader):
        pass

    class TestAnsibleDumper(AnsibleDumper):
        pass

    data = '''
    ---
    foo: bar
    baz:
      - 1
      - 2
      - 3
    '''

    loader = TestAnsibleLoader(data)
    dumper = TestAnsibleDumper()

    data = loader.get_single_data()
    assert isinstance(data, dict)
    assert isinstance(data['foo'], AnsibleUnicode)
    assert isinstance(data['baz'], list)

# Generated at 2022-06-17 06:51:40.236037
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    ---
    - hosts: all
      gather_facts: False
      tasks:
        - name: test
          debug:
            msg: "{{ '{{' }} foo {{ '}}' }}"
    '''

    loader = AnsibleLoader(data)
    results = loader.get_single_data()

    assert results['tasks'][0]['debug']['msg'] == AnsibleUnicode('{{ foo }}')

    dumper = AnsibleDumper()
    output = dumper.dump(results, Dumper=AnsibleDumper)

    assert output == data

# Generated at 2022-06-17 06:51:52.420481
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    import unittest
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(unittest.TestCase):

        def setUp(self):
            self.loader = AnsibleLoader(None)

        def tearDown(self):
            pass

        def test_construct_yaml_str(self):
            node = self.loader.construct_yaml_str(None)
            self.assertEqual(node, '')

        def test_construct_yaml_seq(self):
            node = self.loader.construct_yaml_seq(None)
            self.assertEqual(node, [])


# Generated at 2022-06-17 06:51:59.061671
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    stream = StringIO(u'---\n- hosts: localhost\n  tasks:\n  - name: test\n    debug: msg="{{ ansible_distribution }}"\n')
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {'hosts': 'localhost', 'tasks': [{'debug': {'msg': '{{ ansible_distribution }}'}, 'name': 'test'}]}

# Generated at 2022-06-17 06:52:07.226501
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:52:54.014617
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

    # Test the AnsibleConstructor
    assert isinstance(loader.construct_yaml_str(None), str)
    assert isinstance(loader.construct_yaml_seq(None), list)
    assert isinstance(loader.construct_yaml_map(None), dict)
    assert isinstance(loader.construct_yaml_omap(None), list)
    assert isinstance(loader.construct_yaml_set(None), set)
    assert isinstance(loader.construct_yaml_pairs(None), list)

# Generated at 2022-06-17 06:53:00.409686
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:53:12.695872
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:53:26.073259
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    import io

    class UnicodeIO(io.TextIOBase):
        def write(self, s):
            if isinstance(s, str):
                s = s.decode('utf-8')
            return io.TextIOBase.write(self, s)

    sys.stdout = UnicodeIO()

    data = """
    - hosts: all
      gather_facts: no
      tasks:
      - debug:
          msg: "System {{ inventory_hostname }} has uuid {{ ansible_product_uuid }}"
    """

    # Create a loader for the input Y

# Generated at 2022-06-17 06:53:38.137549
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    - hosts: all
      gather_facts: no
      tasks:
      - name: test
        debug: msg="hello world"
    """

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert isinstance(data, AnsibleSequence)
    assert len(data) == 1
    assert isinstance(data[0], AnsibleMapping)
    assert isinstance(data[0]['hosts'], AnsibleUnicode)
   

# Generated at 2022-06-17 06:53:45.217792
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleScalar
    from ansible.parsing.yaml.objects import AnsibleScalarUndefined
    from ansible.parsing.yaml.objects import AnsibleScalarBoolean
    from ansible.parsing.yaml.objects import AnsibleScalarFloat