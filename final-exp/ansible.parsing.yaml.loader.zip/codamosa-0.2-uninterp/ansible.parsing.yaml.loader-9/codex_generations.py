

# Generated at 2022-06-17 06:43:47.260264
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)
    assert isinstance(loader, Parser)
    assert isinstance(loader, AnsibleConstructor)
    assert isinstance(loader, Resolver)

    if HAS_LIBYAML:
        assert isinstance(loader, Parser)
    else:
        assert isinstance(loader, Reader)
        assert isinstance(loader, Scanner)
        assert isinstance(loader, Parser)
        assert isinstance(loader, Composer)

    # test AnsibleConstructor
    assert loader.file_name == None
    assert loader.vault_secrets == None


# Generated at 2022-06-17 06:43:58.211968
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from io import StringIO


# Generated at 2022-06-17 06:44:09.093666
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.loader import AnsibleUnsafeLoader
    from ansible.parsing.yaml.loader import AnsibleSafeLoader
    from ansible.parsing.yaml.loader import Ansible

# Generated at 2022-06-17 06:44:20.613294
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:44:29.767229
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleScalarBoolean
    from ansible.parsing.yaml.objects import AnsibleScalarFloat
    from ansible.parsing.yaml.objects import AnsibleScalarInteger
    from ansible.parsing.yaml.objects import AnsibleScalarNull

# Generated at 2022-06-17 06:44:41.070529
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestVaultSecret:
        def __init__(self, secret):
            self.secret = secret

        def load(self, id):
            return self.secret

    vault_secrets = [TestVaultSecret('mysecret')]

# Generated at 2022-06-17 06:44:42.636990
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-17 06:44:53.114095
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.nodes import AnsibleScalarNode
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode
    from ansible.parsing.yaml.nodes import AnsibleMappingNode
    from ansible.parsing.yaml.nodes import AnsibleVaultEncryptedUnicodeNode

# Generated at 2022-06-17 06:45:04.439140
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:45:16.648707
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test if AnsibleLoader.construct_yaml_str() works
    # Test if AnsibleLoader.construct_yaml_seq() works
    # Test if AnsibleLoader.construct_yaml_map() works
    # Test if AnsibleLoader.construct_yaml_omap() works
    # Test if AnsibleLoader.construct_yaml_set() works
    # Test if AnsibleLoader.construct_undefined() works
    # Test if AnsibleLoader.construct_yaml_null() works
    # Test if AnsibleLoader.construct_yaml_bool() works
    # Test if AnsibleLoader.construct_yaml_int() works
    # Test if AnsibleLoader

# Generated at 2022-06-17 06:45:26.074314
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode, AnsibleMappingNode
    from ansible.parsing.yaml.nodes import AnsibleScalarNode
    from ansible.module_utils.six import string_types

    # test AnsibleLoader.construct_yaml_map
    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_map(self, node):
            data = AnsibleMapping()
            yield

# Generated at 2022-06-17 06:45:38.503056
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_yaml_str(None), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_seq(None), list)
    assert isinstance(loader.construct_yaml_map(None), dict)
    assert isinstance(loader.construct_yaml_omap(None), list)
    assert isinstance(loader.construct_yaml_set(None), set)
    assert isinstance(loader.construct_yaml_pairs(None), list)
    assert isinstance(loader.construct_yaml_int(None), int)
    assert isinstance(loader.construct_yaml_float(None), float)

# Generated at 2022-06-17 06:45:45.019838
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.loader import AnsibleUnsafeLoader
    from ansible.parsing.yaml.loader import AnsibleUnsafeTextLoader
    from ansible.parsing.yaml.loader import AnsibleUnsafeDumper
    from ansible.parsing.yaml.loader import AnsibleUn

# Generated at 2022-06-17 06:45:55.432633
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import tempfile
    import yaml

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Write some YAML to the temporary file
    with open(path, 'w') as f:
        f.write('---\n')
        f.write('- hosts: localhost\n')
        f.write('  tasks:\n')
        f.write('    - debug: msg="Hello, World!"\n')

    # Read the YAML from the temporary file
    with open(path, 'r') as f:
        data = yaml.load(f, Loader=AnsibleLoader)

    # Remove the temporary file
    os.remove(path)

    # Assert that the YAML was parsed correctly
   

# Generated at 2022-06-17 06:46:07.876992
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    data = '''
    ---
    foo: bar
    baz:
      - 1
      - 2
      - 3
    '''

    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    assert isinstance(loader.get_single_data()['foo'], AnsibleUnicode)
    assert isinstance(loader.get_single_data()['baz'], AnsibleSequence)

# Generated at 2022-06-17 06:46:16.328382
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor of AnsibleLoader
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

    # Test the constructor of AnsibleVaultEncryptedUnicode
    vault_obj = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n')
    assert isinstance(vault_obj, AnsibleVaultEncryptedUnicode)

    # Test the constructor of AnsibleDumper
    dumper = AnsibleDumper(None)
    assert isinstance(dumper, AnsibleDumper)

# Generated at 2022-06-17 06:46:27.497521
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB

# Generated at 2022-06-17 06:46:37.111692
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeBytes
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    from ansible.parsing.yaml.objects import AnsibleScalar
    from ansible.parsing.yaml.objects import AnsibleScalarBoolean
    from ansible.parsing.yaml.objects import Ansible

# Generated at 2022-06-17 06:46:41.026895
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:46:51.451307
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:47:07.587606
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor of AnsibleLoader
    # Test the constructor of AnsibleLoader with a string
    data = '''
    - hosts: all
      gather_facts: no
      tasks:
        - name: test
          debug: msg="{{ ansible_date_time.iso8601 }}"
    '''
    loader = AnsibleLoader(data)
    assert isinstance(loader, AnsibleLoader)
    assert isinstance(loader.construct_yaml_seq(), AnsibleSequence)
    assert isinstance

# Generated at 2022-06-17 06:47:13.712568
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:47:25.892520
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleLoader with a simple string
    stream = 'foo'
    loader = AnsibleLoader(stream)
    assert loader.get_single_data() == 'foo'

    # Test AnsibleLoader with a simple list
    stream = '- foo\n- bar'
    loader = AnsibleLoader(stream)
    assert isinstance(loader.get_single_data(), AnsibleSequence)
    assert loader.get_single_data() == ['foo', 'bar']

    # Test Ans

# Generated at 2022-06-17 06:47:38.333540
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import tempfile
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, yaml_file = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create the YAML
    yaml_str = """
    - hosts: localhost
      tasks:
      - name: test
        debug: msg="Hello World!"
    """

    # Write the YAML to the temporary file
    with open(yaml_file, 'w') as f:
        f.write(yaml_str)

    # Load the YAML

# Generated at 2022-06-17 06:47:47.435979
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar
      - baz
    '''

    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleUnicode)
    assert loader.get_single_data() == 'foo:\n  - bar\n  - baz\n'

    dumper = AnsibleDumper()
    assert dumper.represent_scalar(u'tag:yaml.org,2002:str', loader.get_single_data()) == 'foo:\n  - bar\n  - baz\n'

# Generated at 2022-06-17 06:47:55.016598
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('foo').get_single_data(), AnsibleUnicode)
    assert isinstance(AnsibleLoader('foo: bar').get_single_data(), AnsibleMapping)
    assert isinstance(AnsibleLoader('- foo').get_single_data(), AnsibleSequence)

    # Test AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:48:05.695934
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import tempfile
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, yaml_file = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create the YAML
    yaml_str = """
    ---
    - hosts: localhost
      tasks:
      - name: test
        command: /bin/false
        register: result
        failed_when: result.rc != 0
    """

    # Write the YAML to the temporary file
    with open(yaml_file, 'w') as f:
        f.write(yaml_str)

    # Load the YAML

# Generated at 2022-06-17 06:48:17.505297
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_password = '$6$salt$password'
    vault = VaultLib([VaultSecret(vault_password)])

# Generated at 2022-06-17 06:48:27.904757
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:48:40.062321
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    if sys.version_info >= (3, 0):
        unicode = str

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return self.construct_scalar(node)

        def construct_yaml_seq(self, node):
            # Override the default list handling function
            # to always return list objects
            return self.construct_sequence(node)


# Generated at 2022-06-17 06:49:08.215795
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode
    from ansible.parsing.yaml.nodes import AnsibleMappingNode
    from ansible.parsing.yaml.nodes import AnsibleScalarNode
    from ansible.parsing.yaml.nodes import AnsibleUnicodeNode
    from ansible.parsing.yaml.nodes import AnsibleAliasNode

# Generated at 2022-06-17 06:49:14.988670
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    # test with vault secret
    vault_secret = '$ANSIBLE_VAULT;1.1;AES256\n'
    vault_secret += '633262366339623163346231396331623232396332323231633232323263323232323232323\n'
    vault_secret += '232323232323232323232323232323232323232323232323232323232323232323232323232\n'

# Generated at 2022-06-17 06:49:29.090432
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
    foo:
      - bar
      - baz
    '''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), dict)
    assert isinstance(loader.get_single_data()['foo'], list)
    assert isinstance(loader.get_single_data()['foo'][0], AnsibleUnicode)
    assert isinstance(loader.get_single_data()['foo'][1], AnsibleUnicode)

    dumper = AnsibleDumper()

# Generated at 2022-06-17 06:49:41.456618
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:49:51.323978
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleLoader with a simple YAML file
    data = '''
    ---
    - hosts: localhost
      tasks:
        - name: test
          command: /bin/false
    '''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    assert isinstance(loader.get_single_data()['hosts'], AnsibleUnicode)

# Generated at 2022-06-17 06:49:55.991823
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import yaml

    # Test the constructor of class AnsibleLoader
    stream = io.StringIO("""
    ---
    - hosts: localhost
      tasks:
      - debug:
          msg: hello world
    """)
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == yaml.load(stream)

# Generated at 2022-06-17 06:50:05.463636
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test for AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

    # Test for AnsibleSequence
    assert isinstance(AnsibleLoader('').construct_yaml_seq(''), AnsibleSequence)

    # Test for AnsibleMapping
    assert isinstance(AnsibleLoader('').construct_yaml_map(''), AnsibleMapping)

    # Test for AnsibleV

# Generated at 2022-06-17 06:50:11.040199
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    # Test with vault_secrets

# Generated at 2022-06-17 06:50:19.237644
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret


# Generated at 2022-06-17 06:50:29.005308
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test for AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:50:57.254020
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secret = VaultSecret('vaultpassword')
    vault_secret.start()
    vault_secret.is_started = True
    vault_secret.is_encrypted = True
    vault_secret.is_unlocked = True
    vault_secret.is_locked = False
    vault_secret.is_failed = False
    vault_secret.is_finished = False
    vault_secret.is_aborted = False
    vault_secret.is_cancelled = False
    vault_secret.is_empty = False

    vault_

# Generated at 2022-06-17 06:51:09.206063
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test for AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

# Generated at 2022-06-17 06:51:14.788191
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    data = '''
    ---
    - hosts: localhost
      gather_facts: no
      tasks:
        - name: test
          debug:
            msg: "{{ '{}' }}"
    '''
    stream = StringIO(data)
    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-17 06:51:23.749024
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    import unittest

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class TestAnsibleLoader(unittest.TestCase):
        def setUp(self):
            self.loader = AnsibleLoader(None)

        def tearDown(self):
            pass

        def test_construct_yaml_str(self):
            node = self.loader.construct_yaml_str(u'foo')
            self.assertEqual(node, u'foo')


# Generated at 2022-06-17 06:51:32.516993
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleLoader.construct_yaml_map
    assert AnsibleLoader.construct_yaml_map(None, None) == AnsibleMapping()

    # Test AnsibleLoader.construct_yaml_seq
    assert Ans

# Generated at 2022-06-17 06:51:42.242012
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from io import StringIO
    import yaml

    vault_password = '$6$TESTING$pQW/Z8XvZGXf0M9X/pf/R8jz8p4YUZbHt1jQ/8qYX3.XSJQ9tB8DGz7Zk7T1LJ5F'
    vault = VaultLib(vault_password)

    # Test that AnsibleLoader can load a vault encrypted string

# Generated at 2022-06-17 06:51:53.423459
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY3


# Generated at 2022-06-17 06:52:04.609660
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:52:13.141561
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    import io

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return self.construct_scalar(node)

        def construct_yaml_seq(self, node):
            # Override the default list handling function
            # to always return lists
            return self.construct_sequence(node)


# Generated at 2022-06-17 06:52:27.007550
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import PY3

    if PY3:
        unicode = str

    data = '''
    foo: 1
    bar:
      baz: 3
      qux:
        - 1
        - 2
        - 3
    '''

    # Test loading
    loader = AnsibleLoader(data)
    result = loader.get_single_data()
    assert result == {'foo': 1, 'bar': {'baz': 3, 'qux': [1, 2, 3]}}

# Generated at 2022-06-17 06:53:18.970731
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    import os
    import sys
    import yaml

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest


# Generated at 2022-06-17 06:53:27.696787
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode
    from ansible.parsing.yaml.nodes import AnsibleMappingNode

    # Test AnsibleLoader
    data = '''
    - 1
    - 2
    - 3
    '''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleSequence)
    assert loader

# Generated at 2022-06-17 06:53:39.487235
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)