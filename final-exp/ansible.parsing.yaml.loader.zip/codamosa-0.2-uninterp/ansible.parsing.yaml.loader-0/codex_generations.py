

# Generated at 2022-06-17 06:43:46.199444
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-17 06:43:57.626350
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar: baz
      - bam: baz
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert isinstance(data['foo'][0]['bar'], AnsibleUnicode)
    assert isinstance(data['foo'][1]['bam'], AnsibleUnicode)

    dumper = AnsibleDumper()
    data = dumper.represent_data(data)
    assert isinstance(data, str)

# Generated at 2022-06-17 06:44:08.643481
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from io import StringIO

    vault_secrets = [VaultSecret('secret1', 'password1'), VaultSecret('secret2', 'password2')]
    vault = VaultLib(vault_secrets)

    # Test the constructor

# Generated at 2022-06-17 06:44:20.403015
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:44:27.372088
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC

# Generated at 2022-06-17 06:44:39.178806
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test the AnsibleLoader class
    # Test the AnsibleLoader class
    data = '''
    ---
    - hosts: all
      vars:
        var1: value1
        var2: value2
      tasks:
      - name: task1
        debug: msg="{{ var1 }}"
      - name: task2
        debug: msg="{{ var2 }}"
    '''
   

# Generated at 2022-06-17 06:44:50.620146
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('foo').get_single_data(), AnsibleUnicode)
    assert isinstance(AnsibleLoader('foo').get_single_data(), str)

    # Test AnsibleSequence
    assert isinstance(AnsibleLoader('[foo, bar]').get_single_data(), AnsibleSequence)
    assert isinstance(AnsibleLoader('[foo, bar]').get_single_data(), list)

    # Test AnsibleMapping

# Generated at 2022-06-17 06:45:01.955364
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    foo: 1
    bar:
      baz: 3
    """

    loader = AnsibleLoader(data)
    data = loader.get_single_data()

    assert isinstance(data, dict)
    assert isinstance(data['foo'], int)
    assert isinstance(data['bar'], dict)
    assert isinstance(data['bar']['baz'], int)

    dumper = AnsibleDumper()
    data = dumper.represent_data(data)

    assert isinstance(data, AnsibleUnicode)

# Generated at 2022-06-17 06:45:15.150929
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # test for AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

    # test for AnsibleSequence
    assert isinstance(AnsibleLoader('').construct_yaml_seq(''), AnsibleSequence)

    # test for AnsibleMapping
    assert isinstance(AnsibleLoader('').construct_yaml_map(''), AnsibleMapping)

    # test for AnsibleV

# Generated at 2022-06-17 06:45:27.969503
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
   

# Generated at 2022-06-17 06:45:41.830800
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile

    # Test AnsibleUnicode
    assert AnsibleUnicode('test') == 'test'
    assert AnsibleUnicode('test') == u'test'
    assert AnsibleUnicode('test') == b'test'
    assert AnsibleUnicode('test') == b'test'
    assert Ans

# Generated at 2022-06-17 06:45:53.380814
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-17 06:46:01.702216
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO

    data = b'''
    - hosts: localhost
      tasks:
      - name: test
        debug:
          msg: "{{ '{' }}foo{'}' }"
    '''

    stream = BytesIO(data)
    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-17 06:46:11.672484
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

    data = '''
    foo: bar
    baz:
      - 1
      - 2
      - 3
    '''

    data = TestAnsibleLoader(data).get_single_data()
    assert isinstance(data['foo'], AnsibleUnicode)
    assert isinstance(data['baz'][0], AnsibleUnicode)

    #

# Generated at 2022-06-17 06:46:21.350183
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword

    # Create a vault secret
    vault_secret = VaultSecret('secret')

    # Create a vault password
    vault_password = VaultPassword(vault_secret, 'password')

    # Create a vault lib
    vault_lib = VaultLib(vault_password)

    # Create a vault encrypted string
    vault_encrypted_string = vault_lib.encrypt('test')

    # Create a vault encrypted unicode
    vault_encrypted_unicode = AnsibleVaultEnc

# Generated at 2022-06-17 06:46:21.841983
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-17 06:46:29.729393
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor
    data = '''
    foo:
      - bar
      - baz
    '''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), dict)
    assert loader.get_single_data() == {'foo': ['bar', 'baz']}

    # Test the dumper
    dumper = AnsibleDumper()
    assert dumper.represent_data(loader.get_single_data()) == data

    # Test the unicode class
    assert isinstance(AnsibleUnicode('foo'), AnsibleUnicode)

# Generated at 2022-06-17 06:46:37.289818
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar:
          baz: hello
          world: 1
      - bar:
          baz: goodbye
          world: 2
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()

    assert isinstance(data['foo'][0]['bar']['baz'], AnsibleUnicode)
    assert isinstance(data['foo'][0]['bar']['world'], int)

    dumper = AnsibleDumper()
    output = dumper.dump(data, Dumper=AnsibleDumper)
    assert output == data

# Generated at 2022-06-17 06:46:47.169483
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:46:55.775487
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    import yaml


# Generated at 2022-06-17 06:47:10.469446
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    import io
    import os
    import tempfile
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, yaml_file = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create the YAML
    yaml_str = u'''
    - hosts: all
      gather_facts: False
      tasks:
        - name: test
          debug:
            msg: "{{ '{0}' }}"
    '''.format(yaml_file)

    # Write the

# Generated at 2022-06-17 06:47:14.884148
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    stream = StringIO(u'{"foo": "bar"}')
    loader = AnsibleLoader(stream)
    assert loader.get_single_data() == {u'foo': u'bar'}

# Generated at 2022-06-17 06:47:16.196337
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-17 06:47:26.667693
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleLoader(unittest.TestCase):

        def setUp(self):
            self.loader = AnsibleLoader(None)

        def tearDown(self):
            pass

        def test_construct_yaml_str(self):
            node = self.loader.construct_yaml_str(None)
            self.assertIsInstance(node, AnsibleUnicode)


# Generated at 2022-06-17 06:47:33.470994
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode, AnsibleMappingNode

    # Test AnsibleLoader.construct_yaml_map
    assert isinstance(AnsibleLoader('').construct_yaml_map(None), AnsibleMapping)
    assert isinstance(AnsibleLoader('').construct_yaml_map(AnsibleMappingNode(None, None)), AnsibleMapping)

    # Test AnsibleLoader.construct_yaml_seq

# Generated at 2022-06-17 06:47:43.948135
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test AnsibleLoader
    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_yaml_str(None), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_seq(None), AnsibleSequence)
    assert isinstance(loader.construct_yaml_map(None), AnsibleMapping)

# Generated at 2022-06-17 06:47:51.699151
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedYAML
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedJSON

# Generated at 2022-06-17 06:48:04.053247
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return self.construct_scalar(node)

    data = '''
    foo: bar
    baz:
      - 1
      - 2
      - 3
    '''

    stream = StringIO(data)
    loader = TestAnsibleLoader(stream)
    result = loader.get_single_data()

    assert isinstance(result, dict)

# Generated at 2022-06-17 06:48:13.351169
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

    data = '''
    foo: 1
    bar:
      baz: 3
      '''

    stream = TestAnsibleLoader(data)
    data = stream.get_single_data()
    assert isinstance(data['foo'], int)
    assert isinstance(data['bar']['baz'], int)

    stream = TestAnsibleLoader(data)
   

# Generated at 2022-06-17 06:48:26.966339
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB


# Generated at 2022-06-17 06:48:49.296166
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

    data = '''
    foo: 1
    bar:
      baz: 3
    '''

    stream = TestAnsibleLoader(data)
    data = stream.get_single_data()
    assert isinstance(data['foo'], AnsibleUnicode)
    assert isinstance(data['bar']['baz'], AnsibleUnicode)

    # Make sure the

# Generated at 2022-06-17 06:48:58.016399
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:49:11.140298
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret


# Generated at 2022-06-17 06:49:20.593614
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader(u'foo').get_single_data(), AnsibleUnicode)

    # Test AnsibleMapping
    assert isinstance(AnsibleLoader(u'{foo: bar}').get_single_data(), AnsibleMapping)

   

# Generated at 2022-06-17 06:49:26.917514
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.nodes import AnsibleScalarNode
    from ansible.parsing.yaml.reader import AnsibleReader
    from ansible.parsing.yaml.scanner import AnsibleScanner
    from ansible.parsing.yaml.parser import AnsibleParser
    from ansible.parsing.yaml.composer import AnsibleComposer
    from ansible.parsing.yaml.resolver import AnsibleResolver
    from ansible.module_utils.common.yaml import Parser



# Generated at 2022-06-17 06:49:39.377055
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from io import StringIO

    vault_secrets = [VaultSecret('secret', 'password')]
    vault = VaultLib(vault_secrets)

# Generated at 2022-06-17 06:49:48.291797
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-17 06:49:57.686215
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:50:07.215027
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor
    loader = AnsibleLoader(None)
    assert loader.file_name is None
    assert loader.vault_secrets is None

    # Test the constructor with file_name and vault_secrets
    loader = AnsibleLoader(None, file_name='foo', vault_secrets=['bar'])
    assert loader.file_name == 'foo'
    assert loader.vault_secrets == ['bar']

    # Test the constructor with vault_secrets
    loader = AnsibleLoader(None, vault_secrets=['bar'])
    assert loader.file_name is None

# Generated at 2022-06-17 06:50:16.488543
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import PY3
    import sys

    if PY3:
        unicode = str

    class MyDumper(AnsibleDumper):
        def increase_indent(self, flow=False, indentless=False):
            return super(MyDumper, self).increase_indent(flow, False)

    data = '''
    foo: 1
    bar:
      baz: 2
    '''

    if PY3:
        data = data.encode('utf-8')

    loader = AnsibleLoader(data)
   

# Generated at 2022-06-17 06:50:41.261797
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test for AnsibleUnicode
    assert isinstance(AnsibleUnicode('test'), AnsibleUnicode)

    # Test for AnsibleSequence
    assert isinstance(AnsibleSequence(['test']), AnsibleSequence)

    # Test for AnsibleMapping

# Generated at 2022-06-17 06:50:53.028810
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with vault_secrets
    vault_secrets = {'vault_password': 'secret'}
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)
    assert loader.vault_secrets == vault_secrets

    # Test with vault_secrets
    vault_secrets = {'vault_password': 'secret'}
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)
    assert loader.vault_secrets == vault_secrets

    # Test with vault_secrets and file_name

# Generated at 2022-06-17 06:51:05.892168
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

    stream = '''
    - foo: bar
    - baz:
        - 1
        - 2
        - 3
    '''

    loader = AnsibleLoader(stream)
    data = loader.get_single_data()

    assert isinstance(data, AnsibleSequence)
    assert len(data) == 2

    assert isinstance(data[0], AnsibleMapping)
    assert data[0]['foo'] == 'bar'

    assert isinstance(data[1], AnsibleMapping)
    assert isinstance(data[1]['baz'], AnsibleSequence)

# Generated at 2022-06-17 06:51:13.396339
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault_password = '$6$rL0Y20zC1R.7u$QQV3L/OI9fBJq1d5UO8CZDd0.L0aMV0b6XVyD.x.9mRKcXzsEbRXA7M6NbWUTJf8QnASbOCkZ6vDcAZWtXVy0'
    vault = VaultLib(vault_password)


# Generated at 2022-06-17 06:51:22.338379
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secrets = [VaultSecret('secret1', 'password1'), VaultSecret('secret2', 'password2')]
    vault_password = 'password'
    vault = VaultLib(vault_secrets)

    # Test the constructor of AnsibleLoader

# Generated at 2022-06-17 06:51:31.618978
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secrets = [VaultSecret('secret1', 'password1'), VaultSecret('secret2', 'password2')]
    vault = VaultLib(vault_secrets)

# Generated at 2022-06-17 06:51:40.817960
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with vault_secrets
    loader = AnsibleLoader(None, vault_secrets=['secret1', 'secret2'])
    assert loader.vault_secrets == ['secret1', 'secret2']

    # Test with vault_secrets and file_name
    loader = AnsibleLoader(None, file_name='/tmp/foo', vault_secrets=['secret1', 'secret2'])
    assert loader.vault_secrets == ['secret1', 'secret2']
    assert loader.file_name == '/tmp/foo'

    # Test with vault_secrets and file_name and dumper

# Generated at 2022-06-17 06:51:52.800949
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar:
          baz: 1
      - bar:
          baz: 2
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert data['foo'][0]['bar']['baz'] == 1
    assert data['foo'][1]['bar']['baz'] == 2

    dumper = AnsibleDumper()
    data = dumper.represent_data(data)

# Generated at 2022-06-17 06:51:58.875382
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    import yaml
    import os

    # Create a vault password file
    vault_password_file = os.path.join(os.path.dirname(__file__), "vault_password_file")
    with open(vault_password_file, 'wb') as f:
        f.write("vault_password")

    # Create a vault encrypted file
    vault_file = os.path.join(os.path.dirname(__file__), "vault_file")

# Generated at 2022-06-17 06:52:07.203664
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (2, 7):
        import unittest
        from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
        from ansible.parsing.yaml.dumper import AnsibleDumper

        class TestAnsibleLoader(unittest.TestCase):
            def setUp(self):
                self.loader = AnsibleLoader(None)

            def tearDown(self):
                pass

            def test_construct_yaml_str(self):
                node = self.loader.construct_yaml_str(None)
                self.assertEqual(node, '')

            def test_construct_yaml_seq(self):
                node = self.loader.construct_yaml_seq(None)

# Generated at 2022-06-17 06:52:51.839310
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleLoader with vault_secrets
    vault_secrets = [{'password': 'secret'}]
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)
    assert loader.vault_secrets == vault_secrets

    # Test AnsibleLoader with vault_secrets = None
    loader = AnsibleLoader(None)
    assert loader.vault_sec

# Generated at 2022-06-17 06:53:00.709343
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    if sys.version_info >= (3, 0):
        unicode = str

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

    data = '''
    foo: 1
    bar: !!str "2"
    bam: !!str 3
    baz: !!str
      quux
    '''


# Generated at 2022-06-17 06:53:09.443413
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    stream = StringIO(u"---\n- hosts: localhost\n  tasks:\n  - debug: msg=\"Hello World\"\n")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {u'hosts': u'localhost', u'tasks': [{u'debug': {u'msg': u'Hello World'}}]}

# Generated at 2022-06-17 06:53:17.190344
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
    foo:
      - bar:
          bam:
            - 1
            - 2
            - 3
      - baz:
          - 4
          - 5
          - 6
    '''

    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleUnicode)
    assert isinstance(loader.get_single_data()[0], AnsibleUnicode)
    assert isinstance(loader.get_single_data()[0]['bar'], AnsibleUnicode)
    assert isinstance(loader.get_single_data()[0]['bar']['bam'], list)

# Generated at 2022-06-17 06:53:26.302058
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import tempfile
    import unittest

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString

    class TestAnsibleLoader(unittest.TestCase):
        def setUp(self):
            self.vault_password = '$6$salt$password'
            self.vault_secrets = dict(vault_password=self.vault_password)
            self.stream = None
            self.tmpfile = None

        def tearDown(self):
            if self.stream:
                self.stream.close()
            if self.tmpfile:
                os.unlink(self.tmpfile)


# Generated at 2022-06-17 06:53:37.452470
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    foo: 1
    bar:
      baz: 3
      boo: [ "a", "b", "c" ]
    """

    loader = AnsibleLoader(data)
    data = loader.get_single_data()

    assert data['foo'] == 1
    assert data['bar']['baz'] == 3
    assert data['bar']['boo'] == ["a", "b", "c"]

    dumper = AnsibleDumper()
    output = dumper.dump(data, Dumper=AnsibleDumper)
    assert output == data