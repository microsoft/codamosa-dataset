

# Generated at 2022-06-17 06:43:48.462469
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-17 06:43:59.574503
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:44:09.549115
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with vault_secrets
    vault_secrets = [{'vault_id': 'secret1', 'password': 'secret1'}, {'vault_id': 'secret2', 'password': 'secret2'}]

# Generated at 2022-06-17 06:44:20.782153
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secrets = [VaultSecret('secret', 'password')]
    vault_password = VaultLib(vault_secrets)._get_vault_password('secret')


# Generated at 2022-06-17 06:44:30.063595
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:44:41.266144
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # test AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)



# Generated at 2022-06-17 06:44:52.016059
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:45:03.581567
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_yaml_str(None), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(u'foo'), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(u'foo'), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(u'foo'), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(u'foo'), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(u'foo'), AnsibleUnicode)

# Generated at 2022-06-17 06:45:15.756324
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - hosts: all
      gather_facts: no
      tasks:
      - name: test
        debug:
          msg: "{{ '{{' }} foo {{ '}}' }}"
    '''

    loader = AnsibleLoader(data)
    dumper = AnsibleDumper()

    result = loader.get_single_data()
    assert result == {'hosts': 'all', 'gather_facts': False, 'tasks': [{'name': 'test', 'debug': {'msg': '{{ foo }}'}}]}

    result = dumper.dump(result)
    assert result == data

# Generated at 2022-06-17 06:45:25.973531
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    stream = StringIO(u"---\n- hosts: localhost\n  tasks:\n  - name: test\n    debug: msg=\"hello world\"")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {'hosts': 'localhost', 'tasks': [{'name': 'test', 'debug': {'msg': 'hello world'}}]}

# Generated at 2022-06-17 06:45:40.367062
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestVaultSecret(object):
        def __init__(self, secret):
            self.secret = secret

        def decrypt(self, data):
            return data

    vault_secret = TestVaultSecret('secret')
    loader = AnsibleLoader(None, vault_secrets=[vault_secret])
    assert loader.vault_secrets == [vault_secret]

    # Test AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:45:52.442182
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleLoader with a string
    data = '''
    ---
    - hosts: all
      gather_facts: no
      tasks:
        - name: test
          debug: msg="hello world"
    '''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    assert isinstance(loader.get_single_data()['tasks'], AnsibleSequence)

# Generated at 2022-06-17 06:46:04.308109
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=too-many-function-args,too-many-locals
    # pylint: disable=too-many-branches,too-many-statements
    # pylint: disable=too-many-nested-blocks
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.utils import yaml_objects_equal
    from ansible.parsing.yaml.utils import get_yaml_loader

# Generated at 2022-06-17 06:46:13.228331
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(AnsibleLoader):
        pass

    data = '''
    ---
    - hosts: localhost
      gather_facts: no
      tasks:
      - name: test
        debug:
          msg: "{{ '{{' }}"
    '''

    loader = TestAnsibleLoader(data)
    data = loader.get_single_data()
    assert isinstance(data[0]['tasks'][0]['debug']['msg'], AnsibleUnicode)

    dumper = AnsibleDumper()
    data = dumper.represent_data(data)

# Generated at 2022-06-17 06:46:16.301039
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=too-many-function-args
    AnsibleLoader(None, None, None)

# Generated at 2022-06-17 06:46:27.478907
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class

# Generated at 2022-06-17 06:46:37.111467
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    import io

    # Test for AnsibleUnicode
    stream = io.StringIO(u"foo: bar")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['foo'], AnsibleUnicode)
    assert data['foo'] == u'bar'

    # Test for AnsibleSequence

# Generated at 2022-06-17 06:46:41.095159
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:46:51.542395
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleLoader
    data = '''
    ---
    - hosts:
        - localhost
    '''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleMapping)

# Generated at 2022-06-17 06:46:59.454049
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test the constructor of AnsibleLoader
    # AnsibleLoader is a subclass of Reader, Scanner, Parser, Composer, AnsibleConstructor, Resolver
    # AnsibleConstructor is a subclass of BaseConstructor
    # BaseConstructor is a subclass of Constructor
    # Constructor is a subclass of BaseConstructor
    # Constructor is a subclass of BaseConstructor
    # Constructor is a subclass of BaseConstructor
    # Constructor is a subclass of BaseConstructor
    # Constructor is

# Generated at 2022-06-17 06:47:11.768503
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:47:25.551699
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:47:32.720144
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # test vaulted string

# Generated at 2022-06-17 06:47:43.348662
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:47:51.357910
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import tempfile
    import unittest

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-17 06:48:03.885810
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR


# Generated at 2022-06-17 06:48:04.387610
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-17 06:48:13.908284
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secrets = [VaultSecret('secret', 'password')]
    vault = VaultLib(vault_secrets)

    # Test with vault_secrets

# Generated at 2022-06-17 06:48:27.088206
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.nodes import AnsibleScalarNode
    from ansible.parsing.yaml.reader import AnsibleReader
    from ansible.parsing.yaml.scanner import AnsibleScanner
    from ansible.parsing.yaml.parser import AnsibleParser
    from ansible.parsing.yaml.composer import AnsibleComposer
    from ansible.parsing.yaml.resolver import Ansible

# Generated at 2022-06-17 06:48:39.821886
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    import yaml

    vault_password = '$6$foobar'
    vault = VaultLib(vault_password)
    data = {'foo': 'bar', 'baz': 'qux', 'corge': 'grault', 'waldo': 'fred', 'plugh': 'xyzzy', 'thud': 'wibble'}
    encrypted_data = vault.encrypt(yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False))

# Generated at 2022-06-17 06:48:54.329734
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar
      - baz
    '''

    loader = AnsibleLoader(data)
    result = loader.get_single_data()

    assert isinstance(result, dict)
    assert isinstance(result['foo'], list)
    assert isinstance(result['foo'][0], AnsibleUnicode)
    assert isinstance(result['foo'][1], AnsibleUnicode)

    dumper = AnsibleDumper()
    output = dumper.dump(result)
    assert data == output

# Generated at 2022-06-17 06:49:10.177333
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    ---
    - hosts: localhost
      tasks:
      - name: test
        debug:
          msg: "{{ '{{' }} foo {{ '}}' }}"
    '''

    loader = AnsibleLoader(data)
    dumper = AnsibleDumper()

    assert isinstance(loader.get_single_data(), list)
    assert isinstance(loader.get_single_data()[0], dict)
    assert isinstance(loader.get_single_data()[0]['tasks'][0]['debug']['msg'], AnsibleUnicode)

# Generated at 2022-06-17 06:49:18.826370
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - hosts: all
      gather_facts: no
      tasks:
      - name: test
        debug:
          msg: "{{ '{{' }} foo {{ '}}' }}"
    '''

    loader = AnsibleLoader(data)
    dumper = AnsibleDumper()
    for task in loader.get_single_data().get('tasks'):
        assert isinstance(task['debug']['msg'], AnsibleUnicode)
        assert task['debug']['msg'] == '{{ foo }}'
        assert dumper.represent_data(task['debug']['msg']) == '{{ foo }}'

# Generated at 2022-06-17 06:49:25.901251
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with vault_secrets
    vault_secrets = [
        {'id': 'secret1', 'password': 'secret1'},
        {'id': 'secret2', 'password': 'secret2'},
    ]
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)
    assert loader.vault_secrets == vault_secrets

    # Test with vault_secrets and file_name
    loader = AnsibleLoader(None, file_name='/path/to/file', vault_secrets=vault_secrets)
    assert loader.file_name == '/path/to/file'

    #

# Generated at 2022-06-17 06:49:38.931198
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:49:48.035638
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Create a vault secret
    vault_secret = VaultSecret('ansible')

    # Create a vault object
    vault = VaultLib([vault_secret])

    # Create a YAML string

# Generated at 2022-06-17 06:49:57.585472
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB

# Generated at 2022-06-17 06:50:07.186224
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
    - hosts: localhost
      tasks:
        - debug:
            msg: "Hello world"
    '''
    data = AnsibleLoader(data).get_single_data()
    assert data[0]['hosts'] == 'localhost'
    assert data[0]['tasks'][0]['debug']['msg'] == 'Hello world'
    assert isinstance(data[0]['hosts'], AnsibleUnicode)

# Generated at 2022-06-17 06:50:16.453273
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:50:26.944316
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar:
          baz: qux
      - bar:
          baz: qux
    '''

    data2 = '''
    foo:
      - bar:
          baz: qux
      - bar:
          baz: qux
    '''

    data3 = '''
    foo:
      - bar:
          baz: qux
      - bar:
          baz: qux
    '''


# Generated at 2022-06-17 06:50:55.095609
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUn

# Generated at 2022-06-17 06:51:06.695789
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword

    vault_password = VaultPassword('secret')
    vault_secrets = [VaultSecret('$ANSIBLE_VAULT;1.1;AES256', vault_password)]
    vault_lib = VaultLib(vault_secrets)


# Generated at 2022-06-17 06:51:16.667164
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC


# Generated at 2022-06-17 06:51:27.100364
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO

    data = '''
    ---
    - hosts: localhost
      tasks:
      - name: test
        debug:
          msg: "{{ '{' }} foo {{ '}' }}"
    '''

    stream = BytesIO(data.encode('utf-8'))
    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-17 06:51:36.731568
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    data = '''
a: 1
b:
  - 2
  - 3
'''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['a'], AnsibleUnicode)

# Generated at 2022-06-17 06:51:45.956718
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

    data = '''
    foo: 1
    bar:
      baz: 3
      qux:
        - 1
        - 2
        - 3
    '''

    stream = TestAnsibleLoader(data)
    data = stream.get_single_data()
    assert isinstance(data['foo'], AnsibleUnicode)

# Generated at 2022-06-17 06:51:53.398293
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader("foo").get_single_data(), AnsibleUnicode)

    # Test AnsibleSequence
    assert isinstance(AnsibleLoader("- foo").get_single_data(), AnsibleSequence)

    # Test AnsibleMapping
    assert isinstance(AnsibleLoader("foo: bar").get_single_data(), AnsibleMapping)

    # Test AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:52:03.171026
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    foo: bar
    baz:
      - 1
      - 2
      - 3
    """
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == {'foo': 'bar', 'baz': [1, 2, 3]}
    assert isinstance(loader.get_single_data()['foo'], AnsibleUnicode)
    assert isinstance(loader.get_single_data()['baz'][0], int)

# Generated at 2022-06-17 06:52:12.567655
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUn

# Generated at 2022-06-17 06:52:14.432250
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: Write unit test
    pass

# Generated at 2022-06-17 06:53:03.395296
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    import io

    # Test with a simple string
    data = '''
    - hosts: all
      gather_facts: no
      tasks:
        - name: test
          command: /bin/true
    '''
    stream = io.StringIO(data)
    loader = AnsibleLoader(stream)
    for x in loader:
        assert isinstance(x, dict)
        assert isinstance(x['tasks'][0]['name'], AnsibleUnicode)

# Generated at 2022-06-17 06:53:14.678679
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:53:25.837692
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test AnsibleLoader with a simple string
    data = '''
    foo: bar
    '''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    assert loader.get_single_data() == {'foo': 'bar'}

    # Test AnsibleLoader with a simple list
    data = '''
    - foo
    - bar
    '''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleSequence)
    assert loader.get_single_

# Generated at 2022-06-17 06:53:37.566560
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.reader import AnsibleReader
    from ansible.parsing.yaml.scanner import AnsibleScanner
    from ansible.parsing.yaml.parser import AnsibleParser
    from ansible.parsing.yaml.composer import AnsibleComposer
   