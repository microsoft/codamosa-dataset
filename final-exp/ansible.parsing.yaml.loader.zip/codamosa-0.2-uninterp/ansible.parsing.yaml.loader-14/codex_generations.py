

# Generated at 2022-06-17 06:43:49.169673
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
   

# Generated at 2022-06-17 06:44:00.280794
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import tempfile
    import yaml

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Write some YAML to it
    with open(path, 'w') as f:
        f.write("""
        ---
        - hosts: localhost
          tasks:
          - name: test
            debug:
              msg: "Hello, world!"
        """)

    # Read it back in and make sure it looks right
    with open(path, 'r') as f:
        data = yaml.load(f, Loader=AnsibleLoader)
        assert data[0]['hosts'] == 'localhost'
        assert data[0]['tasks'][0]['name'] == 'test'

# Generated at 2022-06-17 06:44:09.915751
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:44:21.052267
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class UnicodeIO(io.TextIOBase):
        def write(self, s):
            if not isinstance(s, AnsibleUnicode):
                s = AnsibleUnicode(s)
            return super(UnicodeIO, self).write(s)

    sys.stdout = UnicodeIO(sys.stdout)

    # Test with a simple string
    data = AnsibleLoader(u"foo: bar").get_single_data()
    assert data == {u'foo': u'bar'}

    # Test with a simple list
    data = AnsibleLoader(u"- foo\n- bar").get_single_data()

# Generated at 2022-06-17 06:44:30.361186
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import PY3

    if PY3:
        unicode = str

    class MyDumper(AnsibleDumper):
        pass

    class MyLoader(AnsibleLoader):
        pass

    data = {'a': 1, 'b': 'foo', 'c': [1, 2, 3], 'd': {'e': 'f'}}
    yaml_data = '''a: 1
b: foo
c: [1, 2, 3]
d: {e: f}
'''

    # Test dump
    assert yaml

# Generated at 2022-06-17 06:44:35.326597
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:44:45.931019
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:44:54.810001
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:45:06.026682
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    vault_secrets = [{'vault_password': VaultLib.VaultSecret('vault_password', 'vault_password')}]
    loader = AnsibleLoader(sys.stdin, vault_secrets=vault_secrets)

# Generated at 2022-06-17 06:45:18.825174
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    import yaml

    vault_password = '$6$HXdlMJqcV8LZ1DIF$LCXVxmaI/ySqNtLI6ZTtZ4Vpm7eM/PbXA0V.O.K.JjVbKcBbTQ9W1LxLNxIhd1Ey7mKH.T0F.K/PbZ5X26mC1'
    vault = VaultLib(vault_password)

    data

# Generated at 2022-06-17 06:45:30.020712
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secret = VaultSecret('secret')
    vault_secret.load()
    vault_secret.start()

    vault_password = VaultLib(vault_secret)
    vault_password.load()

    data = dict(
        password=AnsibleVaultEncryptedUnicode(vault_password, 'mypassword'),
        foo='bar',
    )

    stream = AnsibleDumper(data, Dumper=AnsibleDumper).dump(data)

# Generated at 2022-06-17 06:45:39.756369
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    data = """
    - hosts: all
      tasks:
      - name: test
        debug:
          msg: "{{ '{{' }} foo {{ '}}' }}"
    """
    stream = StringIO(data)
    loader = AnsibleLoader(stream)
    assert loader.get_single_data() == [{'hosts': 'all', 'tasks': [{'debug': {'msg': '{{ foo }}'}, 'name': 'test'}]}]

# Generated at 2022-06-17 06:45:51.932534
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import tempfile

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Write some data to it
    with open(temp_path, 'w') as f:
        f.write("""
        ---
        - hosts: localhost
          tasks:
            - name: test
              command: /bin/false
        """)

    # Load the data
    with open(temp_path, 'r') as stream:
        loader = AnsibleLoader(stream)
        data = loader.get_single_data()

    # Remove the temporary file
    os.unlink(temp_path)

    # Assert that the data is correct

# Generated at 2022-06-17 06:45:59.099040
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
   

# Generated at 2022-06-17 06:46:10.279281
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar: 1
      - baz: 2
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['foo'], AnsibleSequence)
    assert isinstance(data['foo'][0], AnsibleMapping)
    assert isinstance(data['foo'][1], AnsibleMapping)
    assert data['foo'][0]['bar'] == 1
    assert data['foo'][1]['baz'] == 2

    dumper = AnsibleDumper()


# Generated at 2022-06-17 06:46:18.906671
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test with a string
    data = '''
    - hosts: localhost
      gather_facts: no
      tasks:
        - debug: msg="Hello World"
    '''
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == {'hosts': 'localhost', 'gather_facts': 'no', 'tasks': [{'debug': {'msg': 'Hello World'}}]}

    # Test with a file
    import os
    import tempfile
    fd, path = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write(data)
    f.close()
    loader = AnsibleLoader(path)

# Generated at 2022-06-17 06:46:26.537259
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    stream = StringIO(u'---\n- hosts: localhost\n  tasks:\n  - name: test\n    debug: msg="{{ ansible_os_family }}"\n')
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data['tasks'][0]['debug']['msg'] == '{{ ansible_os_family }}'

# Generated at 2022-06-17 06:46:36.741103
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:46:47.057209
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with a vault encrypted string

# Generated at 2022-06-17 06:46:55.658718
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    foo: 1
    bar:
      baz: 3
      qux: 4
    """

    loader = AnsibleLoader(data)
    data = loader.get_single_data()

    assert isinstance(data['foo'], int)
    assert isinstance(data['bar']['baz'], int)
    assert isinstance(data['bar']['qux'], int)

    dumper = AnsibleDumper()
    data = dumper.represent_data(data)

    assert isinstance(data, AnsibleUnicode)

# Generated at 2022-06-17 06:47:11.247098
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault_secrets = [VaultSecret('secret', 'password')]
    vault = VaultLib(vault_secrets)

    # test vaulted string

# Generated at 2022-06-17 06:47:25.495465
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test for AnsibleLoader
    data = '''
    - hosts:
        - localhost
      tasks:
        - name: test
          debug:
            msg: "{{ '{{' }}"
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert data[0]['tasks'][0]['debug']['msg'] == AnsibleUnicode('{{')

    # Test for AnsibleDumper
    dumper = AnsibleDumper()
    data = dumper.represent_data(data)

# Generated at 2022-06-17 06:47:34.568691
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO

    stream = BytesIO(b"---\n- hosts: localhost\n  tasks:\n  - debug: msg=\"hello world\"\n")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {'hosts': 'localhost', 'tasks': [{'debug': {'msg': 'hello world'}}]}

# Generated at 2022-06-17 06:47:41.964229
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO
    stream = StringIO(u"---\n- hosts: localhost\n  tasks:\n  - name: test\n    ping:")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == [{u'hosts': u'localhost', u'tasks': [{u'name': u'test', u'ping': u''}]}]

# Generated at 2022-06-17 06:47:50.373436
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:48:03.119696
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar: 1
      - baz: 2
    '''

    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), dict)
    assert isinstance(loader.get_single_data()['foo'], list)
    assert isinstance(loader.get_single_data()['foo'][0], dict)
    assert isinstance(loader.get_single_data()['foo'][0]['bar'], AnsibleUnicode)

# Generated at 2022-06-17 06:48:13.573608
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
    - hosts: localhost
      tasks:
      - name: test
        debug:
          msg: "{{ '{0}' }}"
    '''

    data = AnsibleLoader(data).get_single_data()
    assert isinstance(data[0]['tasks'][0]['debug']['msg'], AnsibleUnicode)
    assert data[0]['tasks'][0]['debug']['msg'] == '{0}'


# Generated at 2022-06-17 06:48:17.089372
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-17 06:48:27.395280
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with a simple string
    data = 'string'
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleUnicode)

    # Test with a simple list
    data = '''
    - item1
    - item2
    '''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleSequence)

    # Test with a simple dict

# Generated at 2022-06-17 06:48:39.870291
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

    # Test AnsibleSequence
    assert isinstance(AnsibleLoader('').construct_yaml_seq(''), AnsibleSequence)

    # Test AnsibleMapping
    assert isinstance(AnsibleLoader('').construct_yaml_map(''), AnsibleMapping)

    # Test AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:49:08.456005
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import tempfile

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Write some data to it
    with open(temp_path, 'w') as f:
        f.write("""
---
- hosts: localhost
  tasks:
    - name: test
      debug:
        msg: "Hello world"
""")

    # Load the data
    with open(temp_path, 'r') as f:
        data = AnsibleLoader(f).get_single_data()

    # Remove the temporary file
    os.remove(temp_path)

    # Assert that the data is correct

# Generated at 2022-06-17 06:49:12.789044
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    data = '''
    ---
    - hosts: localhost
      tasks:
      - name: test
        debug: msg="hello"
    '''

    stream = StringIO(data)
    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-17 06:49:28.791708
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a simple string
    data = 'string'
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == data

    # Test with a simple list
    data = ['item1', 'item2']
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == data

    # Test with a simple dictionary
    data = {'key1': 'value1', 'key2': 'value2'}
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == data

    # Test with a simple dictionary with a unicode key

# Generated at 2022-06-17 06:49:34.983701
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (2, 7):
        from unittest import TestCase
    else:
        from unittest2 import TestCase

    class TestAnsibleLoader(TestCase):
        def test_AnsibleLoader(self):
            loader = AnsibleLoader(None)
            self.assertIsInstance(loader, AnsibleLoader)

# Generated at 2022-06-17 06:49:45.678014
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleUnsafeBytes
    from ansible.parsing.yaml.objects import AnsibleUnsafeString
    from ansible.parsing.yaml.objects import AnsibleUnsafeDict

# Generated at 2022-06-17 06:49:57.112184
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib

    vault_password = '$6$HXdlMJqcV8LZ1DIF$LCXVxmaI/ySqRjnMTH1yDZ5HX2bqkZ5gYMf7soYG1vD2NkEVgNBKzT1LI0zr6LZkWKBjv1eP.HtGci1mXA.H0'
    vault = VaultLib(vault_password)

# Generated at 2022-06-17 06:50:05.512620
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-17 06:50:16.022018
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB

# Generated at 2022-06-17 06:50:26.712032
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo: 1
    bar:
      baz: 3
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()

    assert isinstance(data, dict)
    assert isinstance(data['foo'], int)
    assert isinstance(data['bar'], dict)
    assert isinstance(data['bar']['baz'], int)

    dumper = AnsibleDumper()
    data = dumper.represent_data(data)
    assert data == 'foo: 1\nbar:\n  baz: 3\n'

# Generated at 2022-06-17 06:50:34.899080
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor of AnsibleLoader
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

    # Test the constructor of AnsibleDumper
    dumper = AnsibleDumper(None)
    assert isinstance(dumper, AnsibleDumper)

    # Test the constructor of AnsibleVaultEncryptedUnicode
    encrypted_unicode = AnsibleVaultEncryptedUnicode(None)
    assert isinstance(encrypted_unicode, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-17 06:51:06.829071
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import StringIO

    stream = StringIO(u"---\n- hosts: localhost\n  tasks:\n  - name: test\n    debug:\n      msg: '{{ ansible_env.HOME }}'\n")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()

# Generated at 2022-06-17 06:51:16.740346
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    - hosts: all
      gather_facts: no
      tasks:
        - name: test
          debug:
            msg: "{{ '{{' }} ansible_hostname {{ '}}' }}"
    '''

    data = AnsibleLoader(yaml_str).get_single_data()
    assert data == {'hosts': 'all', 'gather_facts': 'no', 'tasks': [{'name': 'test', 'debug': {'msg': "{{ ansible_hostname }}"}}]}

    assert AnsibleDumper(None, default_flow_style=False).dump(data) == yaml_str



# Generated at 2022-06-17 06:51:17.278114
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-17 06:51:25.933158
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:51:31.864487
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    stream = StringIO(u"---\n- hosts: localhost\n  tasks:\n  - debug: msg='hello world'\n")
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == [{'hosts': 'localhost', 'tasks': [{'debug': {'msg': 'hello world'}}]}]

# Generated at 2022-06-17 06:51:40.832317
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
   

# Generated at 2022-06-17 06:51:52.800814
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleUnicode
    assert isinstance(AnsibleLoader('').construct_yaml_str(''), AnsibleUnicode)

    # Test AnsibleSequence
    assert isinstance(AnsibleLoader('').construct_yaml_seq(''), AnsibleSequence)

    # Test AnsibleMapping
    assert isinstance(AnsibleLoader('').construct_yaml_map(''), AnsibleMapping)

    # Test AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:51:53.288838
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-17 06:52:04.574543
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test for vault encrypted string

# Generated at 2022-06-17 06:52:13.114521
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:53:13.498573
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:53:25.552671
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSet
    from ansible.parsing.yaml.objects import AnsibleScalarBoolean
    from ansible.parsing.yaml.objects import AnsibleScalarFloat
    from ansible.parsing.yaml.objects import AnsibleScalarInteger
    from ansible.parsing.yaml.objects import Ans

# Generated at 2022-06-17 06:53:37.452172
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUn

# Generated at 2022-06-17 06:53:48.803666
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test AnsibleLoader.construct_yaml_map
    data = '''
    foo: bar
    baz:
      - 1
      - 2
      - 3
    '''
    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)