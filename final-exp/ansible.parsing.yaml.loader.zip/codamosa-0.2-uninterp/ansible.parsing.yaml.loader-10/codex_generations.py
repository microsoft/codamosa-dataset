

# Generated at 2022-06-17 06:43:53.896011
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB

# Generated at 2022-06-17 06:44:05.473900
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class AnsibleLoader
    # Test the constructor of class Ansible

# Generated at 2022-06-17 06:44:18.229305
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-17 06:44:28.354863
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor of AnsibleLoader
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

    # Test the constructor of AnsibleDumper
    dumper = AnsibleDumper(None)
    assert isinstance(dumper, AnsibleDumper)

    # Test the constructor of AnsibleVaultEncryptedUnicode
    encrypted_unicode = AnsibleVaultEncryptedUnicode(None)
    assert isinstance(encrypted_unicode, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-17 06:44:40.066657
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleScalar

    # Test AnsibleLoader.construct_yaml_str
    assert isinstance(AnsibleLoader(None).construct_yaml_str(None), AnsibleUnsafeText)
    assert isinstance(AnsibleLoader(None).construct_yaml_str(None, True), AnsibleUnicode)

# Generated at 2022-06-17 06:44:51.648556
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeBytes

    # Test AnsibleLoader.construct_yaml_map
    assert isinstance(AnsibleLoader.construct_yaml_map(None, None), AnsibleMapping)

    # Test AnsibleLoader.construct_yaml_seq

# Generated at 2022-06-17 06:45:03.257075
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar
      - baz
    '''

    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleUnicode)
    assert loader.get_single_data() == 'foo:\n  - bar\n  - baz\n'

    loader = AnsibleLoader(data, file_name='/tmp/foo.yml')
    assert isinstance(loader.get_single_data(), AnsibleUnicode)
    assert loader.get_single_data() == 'foo:\n  - bar\n  - baz\n'

    dumper = AnsibleDumper

# Generated at 2022-06-17 06:45:15.805528
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    import io
    import yaml

    # Test for AnsibleLoader
    class TestAnsibleLoader(AnsibleLoader):
        def __init__(self, stream):
            AnsibleLoader.__init__(self, stream)

    # Test for AnsibleDumper
    class TestAnsibleDumper(AnsibleDumper):
        def __init__(self, stream):
            AnsibleDumper.__init__(self, stream)

    # Test for AnsibleUnicode
    class TestAnsibleUnicode(AnsibleUnicode):
        def __init__(self, value):
            AnsibleUnicode.__init

# Generated at 2022-06-17 06:45:28.177216
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB

# Generated at 2022-06-17 06:45:40.450759
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:45:53.940256
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test AnsibleUnicode
    assert AnsibleUnicode('foo') == 'foo'
    assert AnsibleUnicode('foo') == u'foo'
    assert AnsibleUnicode(u'foo') == 'foo'

# Generated at 2022-06-17 06:46:03.120284
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    stream = StringIO(u'---\n- hosts: localhost\n  tasks:\n    - name: test\n      debug: msg="{{ ansible_date_time.epoch }}"')
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data['tasks'][0]['debug']['msg'] == '{{ ansible_date_time.epoch }}'

# Generated at 2022-06-17 06:46:13.647722
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import StringIO

    data = u'{ foo: bar }'
    stream = StringIO(data)
    loader = AnsibleLoader(stream)
    assert isinstance(loader.get_single_data(), AnsibleUnicode)
    assert loader.get_single_data() == u'{ foo: bar }'

    data = u'{ foo: bar }'
    stream = StringIO(data)
    loader = AnsibleLoader(stream)
    assert isinstance(loader.get_single_data(), AnsibleUnicode)
    assert loader.get

# Generated at 2022-06-17 06:46:18.162711
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    data = u"""
    - hosts: localhost
      tasks:
        - name: test
          debug:
            msg: hello world
    """

    stream = StringIO(data)
    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-17 06:46:24.839440
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    stream = StringIO(u'{ foo: bar }')
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {'foo': 'bar'}

# Generated at 2022-06-17 06:46:34.438461
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    if sys.version_info >= (3, 0):
        unicode = str

    # Test the constructor
    data = '''
    foo:
      - 1
      - 2
      - 3
    '''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), dict)
    assert isinstance(loader.get_single_data()['foo'], list)
    assert loader.get_single_data()['foo'][0] == 1
    assert loader.get_single_data()['foo'][1] == 2
    assert loader.get_single_data()['foo'][2] == 3



# Generated at 2022-06-17 06:46:45.398938
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from io import BytesIO

    vault_password = '$6$foobar'
    vault = VaultLib(vault_password)

    # Test the constructor of AnsibleLoader

# Generated at 2022-06-17 06:46:54.401602
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib

    vault_password = '$ecret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('$ecret')
    vault_text = vault_text.replace('$ANSIBLE_VAULT;', '$ANSIBLE_VAULT;1.1;AES256')
    vault_text = vault_text.replace('\n', '\r\n')
    vault_text = vault_text.replace('\r\r\n', '\r\n')

    loader = AnsibleLoader(vault_text)
    data = loader.get_

# Generated at 2022-06-17 06:47:05.582702
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleLoader with vault_secrets
    vault_secrets = [{'password': 'secret'}]

# Generated at 2022-06-17 06:47:17.956754
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import cStringIO

    # Test with a file-like object
    data = u"---\n- hosts: all\n  gather_facts: no\n"
    stream = StringIO(data)
    loader = AnsibleLoader(stream)
    assert isinstance(loader.get_single_data(), list)
    assert isinstance(loader.get_single_data()[0], dict)
    assert loader.get_single_data()[0]['hosts'] == 'all'

    # Test with a string

# Generated at 2022-06-17 06:47:31.350409
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from io import StringIO


# Generated at 2022-06-17 06:47:39.666406
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo: 1
    bar:
      baz: 3
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()

    assert data['foo'] == 1
    assert data['bar']['baz'] == 3

    dumper = AnsibleDumper()
    output = dumper.dump(data, Dumper=dumper)

    assert output == data

# Generated at 2022-06-17 06:47:49.639187
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes

    if PY3:
        unicode = str

    # Test with a string
    data = '''
    - hosts: all
      gather_facts: no
      tasks:
        - name: test
          debug:
            msg: "{{ 'Hello World!' | to_nice_yaml }}"
    '''
    data = to_bytes(data, errors='surrogate_or_strict')
    data = AnsibleLoader(data).get_single_data

# Generated at 2022-06-17 06:47:54.472154
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secret = VaultSecret('vault_secret')
    vault_secret.load()

    vault = VaultLib([vault_secret])

    data = dict(
        a=1,
        b=2,
        c=3,
        d=dict(
            e=4,
            f=5,
            g=6,
            h=dict(
                i=7,
                j=8,
                k=9,
            )
        )
    )


# Generated at 2022-06-17 06:48:03.661901
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      bar:
        baz: qux
    '''

    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleUnicode)
    assert loader.get_single_data() == 'foo:\n  bar:\n    baz: qux\n'

    dumper = AnsibleDumper()
    assert dumper.represent_data(loader.get_single_data()) == data

# Generated at 2022-06-17 06:48:10.834205
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    data = '''
    foo:
      - bar
      - baz
    '''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), dict)
    assert loader.get_single_data() == {'foo': ['bar', 'baz']}
    assert loader.get_single_data(safe=False) == {'foo': ['bar', 'baz']}
    assert loader.get_single_data(safe=True) == {'foo': [AnsibleUnicode('bar'), AnsibleUnicode('baz')]}

    # Test with a file
    import os


# Generated at 2022-06-17 06:48:21.434383
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test constructor
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

    # Test AnsibleConstructor
    assert loader.file_name is None
    assert loader.vault_secrets is None
    assert loader.vault_password_files == []
    assert loader.vault_ids == {}
    assert loader.vault_version == 1
    assert loader.vault_support_version == 1
    assert loader.vault_support_version == 1
    assert loader.vault_support_version == 1
    assert loader.vault_support_version == 1

# Generated at 2022-06-17 06:48:29.969532
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from io import StringIO


# Generated at 2022-06-17 06:48:41.464796
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    import yaml

    # Create a vault secret
    vault_secret = VaultSecret('secret')

    # Create a vault object
    vault = VaultLib([vault_secret])

    # Create a string with encrypted data
    encrypted_data = vault.encrypt('my_secret')

    # Create a string with unencrypted data
    unencrypted_data = 'my_secret'

    # Create a string with encrypted data
    encrypted_data_unicode = vault.encrypt(u'my_secret')

    # Create a string with unencrypted

# Generated at 2022-06-17 06:48:51.036473
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-17 06:49:11.514427
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test loading of vault-encrypted strings

# Generated at 2022-06-17 06:49:28.694750
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io
    import unittest
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class TestAnsibleLoader(unittest.TestCase):

        def setUp(self):
            self.loader = AnsibleLoader(None)

        def tearDown(self):
            pass


# Generated at 2022-06-17 06:49:40.900786
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-17 06:49:51.295745
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword

# Generated at 2022-06-17 06:50:02.558567
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar:
          baz: 1
      - bar:
          baz: 2
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert data['foo'][0]['bar']['baz'] == 1
    assert data['foo'][1]['bar']['baz'] == 2

    # test round trip
    dumper = AnsibleDumper()
    dumped_data = dumper.dump(data)
    assert dumped_data == data

    # test unicode


# Generated at 2022-06-17 06:50:04.375621
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-17 06:50:15.581783
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB

# Generated at 2022-06-17 06:50:26.892820
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:50:35.688263
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault_secrets = [VaultSecret('secret', 'password')]
    vault = VaultLib(vault_secrets)

    # Test the constructor
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)
    assert isinstance(loader, AnsibleLoader)

    # Test the AnsibleConstructor
    data = loader.construct_yaml_map(None)
    assert isinstance(data, dict)

    data = loader.construct_yaml_seq(None)

# Generated at 2022-06-17 06:50:44.980840
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:51:12.807620
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib

    # Test with vault_secrets
    vault_secrets = [{'vault_secret': 'secret'}]
    vault_password = 'secret'
    vault = VaultLib(vault_secrets)

# Generated at 2022-06-17 06:51:21.784306
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:51:29.489530
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUn

# Generated at 2022-06-17 06:51:40.639336
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test AnsibleLoader
    data = b'{ foo: bar }'
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleMapping)

    data = b'[ foo, bar ]'
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleSequence)

    data = b'foo: bar'
    loader = AnsibleLoader(data)

# Generated at 2022-06-17 06:51:52.624617
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      - bar:
          baz: 1
      - bar:
          baz: 2
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert data == {'foo': [{'bar': {'baz': 1}}, {'bar': {'baz': 2}}]}

    dumper = AnsibleDumper()
    data = dumper.represent_data(data)
    assert data == '''\
foo:
- bar: {baz: 1}
- bar: {baz: 2}
'''


# Generated at 2022-06-17 06:52:01.086600
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS


# Generated at 2022-06-17 06:52:05.748657
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    data = '''
    ---
    - hosts: localhost
      tasks:
        - name: test
          debug:
            msg: "{{ '{ \"a\": 1 }' | from_json }}"
    '''

    stream = StringIO(data)
    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-17 06:52:13.624115
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultVersionedUnicode

    # Test AnsibleMapping
    assert isinstance(AnsibleLoader('').construct_yaml_map(None), AnsibleMapping)
    assert isinstance(AnsibleLoader('').construct_yaml_omap(None), AnsibleMapping)

    # Test AnsibleSequence

# Generated at 2022-06-17 06:52:26.967101
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - hosts: all
      gather_facts: no
      tasks:
      - name: test
        debug:
          msg: "{{ '{{' }} foo {{ '}}' }}"
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()

    assert data[0]['tasks'][0]['debug']['msg'] == AnsibleUnicode('{{ foo }}')

    dumper = AnsibleDumper()
    output = dumper.dump(data, Dumper=AnsibleDumper)

    assert output == data

# Generated at 2022-06-17 06:52:29.454641
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (2, 7):
        from io import StringIO
    else:
        from StringIO import StringIO

    stream = StringIO(u'{ foo: bar }')
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {u'foo': u'bar'}

# Generated at 2022-06-17 06:53:18.532460
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:53:26.836882
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    # Test AnsibleLoader
    data = '''
a: 1
b:
  c: 3
  d: 4
'''
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    assert isinstance(loader.get_single_data()['a'], int)
    assert isinstance(loader.get_single_data()['b'], AnsibleMapping)

# Generated at 2022-06-17 06:53:35.302416
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    data = '''
    ---
    - hosts: localhost
      tasks:
      - name: test
        debug:
          msg: "{{ '{' }}foo{'}' }"
    '''

    stream = StringIO(data)
    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-17 06:53:44.717075
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secrets = [VaultSecret('secret', 'password')]
    vault = VaultLib(vault_secrets)

    # Test with a string