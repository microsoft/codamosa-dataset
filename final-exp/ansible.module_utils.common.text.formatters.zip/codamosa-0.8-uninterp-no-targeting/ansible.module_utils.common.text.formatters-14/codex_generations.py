

# Generated at 2022-06-20 16:25:54.158725
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        assert human_to_bytes('50M') == 52428800, 'human_to_bytes("50M") returns wrong value'
    except AssertionError as err:
        print("AssertionError: %s" % err)
    except Exception as err:
        print('Expected assertion but got Exception: %s' % err)
    try:
        assert human_to_bytes(50, 'M') == 52428800, 'human_to_bytes(50, "M") returns wrong value'
    except AssertionError as err:
        print("AssertionError: %s" % err)
    except Exception as err:
        print('Expected assertion but got Exception: %s' % err)

# Generated at 2022-06-20 16:26:02.905209
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import sys
    import json
    import argparse
    import logging
    import collections

    # setting ansible log handler
    logfmt = "%(asctime)s.%(msecs)03d %(levelname)-5.5s [%(name)s] %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"
    ansible_logger = logging.getLogger('ansible')
    ansible_logger.setLevel(logging.INFO)
    shandler = logging.StreamHandler(sys.stdout)
    shandler.setFormatter(logging.Formatter(logfmt, datefmt))
    ansible_logger.addHandler(shandler)

    p = argparse.ArgumentParser()
    p.add

# Generated at 2022-06-20 16:26:10.115479
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Single lowercase unit
    assert bytes_to_human(100, False, 'b') == '100.00 bits'
    assert bytes_to_human(100, False, 'B') == '100.00 Bytes'
    # Single uppercase unit
    assert bytes_to_human(100, False, 'B') == '100.00 Bytes'
    assert bytes_to_human(100, False, 'B') == '100.00 Bytes'
    # Wrong unit
    try:
        bytes_to_human(100, False, 'm')
    except ValueError:
        pass
    try:
        bytes_to_human(100, False, 'Mb')
    except ValueError:
        pass
    try:
        bytes_to_human(100, False, 'Gb')
    except ValueError:
        pass

# Generated at 2022-06-20 16:26:13.243479
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['Test1', 2, 'Test3', 'Test4', 'Test5']
    assert(lenient_lowercase(test_list) == ['test1', 2, 'test3', 'test4', 'test5'])


# Generated at 2022-06-20 16:26:20.273107
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1025) == '1.00 KB'
    assert bytes_to_human(1025, True) == '1.00 Kbits'
    assert bytes_to_human(1025, True, 'Kb') == '1.00 Kb'
    assert bytes_to_human(1025, unit='Kib') == '1.00 Kib'
    assert bytes_to_human(1025, True, 'Kib') == '1.00 Kib'
    assert bytes_to_human(1025, unit='kb') == '1.00 Kbits'
    assert bytes_to_human(1025, True, 'kb') == '1.00 kb'

# Generated at 2022-06-20 16:26:30.866922
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1") == 1
    assert human_to_bytes("1") == human_to_bytes(1)
    assert human_to_bytes("1b") == 1
    assert human_to_bytes("1b") == human_to_bytes("1b", isbits=True)
    assert human_to_bytes("1b", isbits=True) == human_to_bytes(1, isbits=True)
    assert human_to_bytes("1b") == human_to_bytes("1", isbits=True)
    assert human_to_bytes("1B") == 1
    assert human_to_bytes("1B") == human_to_bytes("1", isbits=False)
    assert human_to_bytes("1B") == human_to_bytes("1B", isbits=False)
   

# Generated at 2022-06-20 16:26:41.959985
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Raw bytes
    assert bytes_to_human(1024) == '1.00 Bytes'
    assert bytes_to_human(1024*1024) == '1.00 MB'
    assert bytes_to_human(1024*1024*1024) == '1.00 GB'
    assert bytes_to_human(1024*1024*1024*1024) == '1.00 TB'
    assert bytes_to_human(1024*1024*1024*1024*1024) == '1.00 PB'
    assert bytes_to_human(1024*1024*1024*1024*1024*1024) == '1.00 EB'
    assert bytes_to_human(1024*1024*1024*1024*1024*1024*1024) == '1.00 ZB'
    assert bytes_to_human(1024*1024*1024*1024*1024*1024*1024*1024)

# Generated at 2022-06-20 16:26:54.599777
# Unit test for function bytes_to_human
def test_bytes_to_human():

    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1000) == '1.00 KB'
    assert bytes_to_human(2097152) == '2.00 MB'
    assert bytes_to_human(2, unit='M') == '2.00 MB'
    assert bytes_to_human(2, unit='M', isbits=True) == '2.00 Mb'
    assert bytes_to_human(2, unit='M', isbits=False) == '2.00 MB'
    assert bytes_to_human(2, unit='B', isbits=False) == '2.00 Bytes'
    assert bytes_to_human(2, unit='K', isbits=False) == '2.00 KB'

# Generated at 2022-06-20 16:27:02.080225
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:27:12.882179
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # check human byte representation
    assert bytes_to_human(1000) == "1000.00 Bytes"
    assert bytes_to_human(1023) == "1023.00 Bytes"
    assert bytes_to_human(1023, unit='K') == "1.00 KB"
    assert bytes_to_human(1023, unit='KB') == "1.00 KB"
    assert bytes_to_human(1023, unit='k') == "1.00 KB"
    assert bytes_to_human(1023, unit='kB') == "1.00 KB"
    assert bytes_to_human(1023, unit='Kb') == "1.00 KB"
    assert bytes_to_human(1023, unit='kb') == "1.00 KB"

# Generated at 2022-06-20 16:27:25.499246
# Unit test for function bytes_to_human
def test_bytes_to_human():

    size = 2 ** 30
    assert bytes_to_human(size) == '1.00 GB'
    size = 2 ** 20
    assert bytes_to_human(size) == '1.00 MB'
    size = 2 ** 10
    assert bytes_to_human(size) == '1.00 KB'
    size = 2 ** 0
    assert bytes_to_human(size) == '1.00 bytes'
    size = 2 ** 7
    assert bytes_to_human(size) == '128.00 bytes'

    size = 2 ** 30
    assert bytes_to_human(size, unit='G') == '1.00 G'
    size = 2 ** 20
    assert bytes_to_human(size, unit='M') == '1.00 M'
    size = 2 ** 10

# Generated at 2022-06-20 16:27:35.212451
# Unit test for function bytes_to_human
def test_bytes_to_human():
    from sys import version_info
    if version_info.major < 3:
        assert bytes_to_human(1023) == '1023 Bytes'
        assert bytes_to_human(1023, unit='b') == '1023 bits'
        assert bytes_to_human(2 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '2 YB'
        assert bytes_to_human(2 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024, isbits=True) == '2 Ybits'
    else:
        assert bytes_to_human(1023) == '1023.00 Bytes'
        assert bytes_to_human(1023, unit='b') == '1023.00 bits'
        assert bytes_to_human

# Generated at 2022-06-20 16:27:44.826039
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('10M') == 10485760)
    assert(human_to_bytes('10m') == 10485760)
    assert(human_to_bytes('10Mb') == 1048576)
    assert(human_to_bytes('10mb') == 1048576)
    assert(human_to_bytes('10MB') == 1048576)
    assert(human_to_bytes('10MB', isbits=True) == 1048576)
    assert(human_to_bytes('10Mb', isbits=True) == 8388608)
    assert(human_to_bytes('10mb', isbits=True) == 8388608)


# Generated at 2022-06-20 16:27:56.254569
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 B'
    assert bytes_to_human(10) == '10.00 B'
    assert bytes_to_human(1000) == '1000.00 B'
    assert bytes_to_human(1000, unit='K') == '1.00 KB'
    assert bytes_to_human(1000, unit='M') == '0.00 MB'
    assert bytes_to_human(1000, unit='G') == '0.00 GB'
    assert bytes_to_human(1000, unit='T') == '0.00 TB'
    assert bytes_to_human(1000, unit='P') == '0.00 PB'
    assert bytes_to_human(1000, unit='E') == '0.00 EB'

# Generated at 2022-06-20 16:28:06.505958
# Unit test for function human_to_bytes
def test_human_to_bytes():
    for (number, expected, unit, isbits) in [('10M', 10485760, None, False),
                                             (10, 10, 'M', False),
                                             ('10Mb', 13107200, None, True),
                                             (10, 81920, 'Mb', True),
                                             (10, 10, None, False),
                                             (10.5, 10, None, False)]:
        assert human_to_bytes(number, unit, isbits) == expected


# Generated at 2022-06-20 16:28:10.775545
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["one", 2, 3]) == ["one", 2, 3]
    assert lenient_lowercase(["ONe", 2, 3]) == ["one", 2, 3]
    assert lenient_lowercase(["ONe", "TWo", "thRee"]) == ["one", "two", "three"]
    assert lenient_lowercase(["ONe", "TWo", "thRee"]) == ["one", "two", "three"]
    assert lenient_lowercase(["ONE", "TWO", "THREE"]) == ["one", "two", "three"]


# Generated at 2022-06-20 16:28:22.932279
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(100000, unit='b') == '100000.00 bits'
    assert bytes_to_human(100000, unit='B') == '97656.25 Bytes'
    assert bytes_to_human(100000, unit='K') == '97.66 KB'
    assert bytes_to_human(100000, unit='M') == '0.10 MB'
    assert bytes_to_human(100000, unit='G') == '0.10 GB'
    assert bytes_to_human(100000, unit='T') == '0.10 TB'
    assert bytes_to_human(100000, unit='K', isbits=True) == '97656.25 Kbits'
    assert bytes_to_human(100000, unit='M', isbits=True) == '97.66 Mbits'

# Generated at 2022-06-20 16:28:25.384385
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['FOO', 10, 'BAR']) == ['foo', 10, 'bar']

# Generated at 2022-06-20 16:28:35.801677
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human(1099511627776) == '1.00 TB'
    assert bytes_to_human(1099511627776) == '1.00 TB'
    assert bytes_to_human(1125899906842624) == '1.00 PB'
    assert bytes_to_human(1152921504606846976) == '1.00 EB'

# Generated at 2022-06-20 16:28:46.850050
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert(bytes_to_human(1) == '1.00 Bytes')
    assert(bytes_to_human(1000) == '1.00 KB')
    assert(bytes_to_human(1000, unit='K') == '1.00 KB')
    assert(bytes_to_human(1000000) == '1.00 MB')
    assert(bytes_to_human(1000000, unit='b') == '1.00 Mb')
    assert(bytes_to_human(1000000000) == '1.00 GB')
    assert(bytes_to_human(1000000000, unit='M') == '1.00 GB')
    assert(bytes_to_human(1000000000000) == '1.00 TB')
    assert(bytes_to_human(1000000000000000) == '1.00 PB')

# Generated at 2022-06-20 16:29:04.897488
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_values = {
        'ansible': {
            'ansible': 1,
            'kb': 1024,
            'MB': 1048576,
            'kbB': 1024,
            'Mb': 1048576,
            'MbB': 1048576,
            'Mbb': 1048576,
            'MbbB': 1048576,
            'z': '1000000000000000000',
            'E': '10000000000000000000'
        }
    }
    for key, value in test_values.items():
        for key_inner, value_inner in value.items():
            if isinstance(value_inner, str):
                value_inner = int(value_inner)
            result = human_to_bytes(key_inner, isbits=bool(key == 'ansible'))

# Generated at 2022-06-20 16:29:14.305325
# Unit test for function bytes_to_human
def test_bytes_to_human():
    SUFFIXES = {'Z': 1 << 80, 'Y': 1 << 70, 'E': 1 << 60, 'P': 1 << 50, 'T': 1 << 40, 'G': 1 << 30, 'M': 1 << 20, 'K': 1 << 10, 'B': 1}
    for suffix_name, suffix_value in sorted(iteritems(SUFFIXES), key=lambda item: -item[1]):
        assert (suffix_name in bytes_to_human(suffix_value) and bytes_to_human(suffix_value).startswith('1.00'))
        assert (suffix_name in bytes_to_human(suffix_value, False) and bytes_to_human(suffix_value).startswith('1.00'))

# Generated at 2022-06-20 16:29:24.806717
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:29:37.049647
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['', '', '']) == ['', '', '']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase(['1', '2', '3']) == ['1', '2', '3']
    assert lenient_lowercase(['a', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 'B', 3]) == ['a', 'b', 3]

# Generated at 2022-06-20 16:29:40.770465
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    l = ['a', 'B', 'c', 'D', 'E', 6, 7, 8, 9, 'Z']
    assert lenient_lowercase(l) == ['a', 'b', 'c', 'd', 'e', 6, 7, 8, 9, 'z']



# Generated at 2022-06-20 16:29:45.679406
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['sTring1', 'sTring2', 'sTring3']) == ['string1', 'string2', 'string3']
    assert lenient_lowercase(['sTring1', 'sTring2', 3]) == ['string1', 'string2', 3]



# Generated at 2022-06-20 16:29:53.970114
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(100) == '100.00 Bytes'
    assert bytes_to_human(1000) == '1000.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'

# Generated at 2022-06-20 16:29:56.217426
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_input = [1, 'Ansible', ['a', 'b'], ('c', 'd')]
    expected_output = [1, 'ansible', ['a', 'b'], ('c', 'd')]
    assert lenient_lowercase(test_input) == expected_output


# Generated at 2022-06-20 16:30:07.523461
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes(1024, isbits=True) == 1
    assert human_to_bytes('1024b') == 1
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes(1024, 'B') == 1024
    assert human_to_bytes('10Mb', 'MB') == 10485760
    assert human_to_bytes('10Mb', 'b') == 1048576
    assert human_to_bytes('0') == 0
    assert human_to_bytes('0', 'b') == 0
    assert human_to_bytes('100') == 100
    assert human_to_bytes('100B')

# Generated at 2022-06-20 16:30:09.424885
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["ABC", 1, "def"]) == ["abc", 1, "def"]



# Generated at 2022-06-20 16:30:30.826852
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:30:38.288475
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'
    assert bytes_to_human(10, unit='b') == '10.00 bits'
    assert bytes_to_human(10, isbits=True) == '10.00 bits'
    assert bytes_to_human(10, unit='K') == '10.00 KBytes'
    assert bytes_to_human(10, unit='k') == '10.00 kbits'
    assert bytes_to_human(10, unit='Kb') == '10.00 kbits'
    assert bytes_to_human(10, unit='KB') == '10.00 KBytes'

# Generated at 2022-06-20 16:30:46.748110
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:30:57.662998
# Unit test for function bytes_to_human
def test_bytes_to_human():
    test_data = [
        (1234567, '1.18 MB'),
        (1234567, '1.18 MB', 'M'),
        (1234567, '1.18 M', 'M'),
        (1234567, '1183.73 KB', 'K'),
        (1234567, '1183.73 k', 'k'),
        (1234567, '1258290.88 b', 'b')
    ]

# Generated at 2022-06-20 16:31:09.426826
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(15) == '15 Bytes'
    assert bytes_to_human(1500) == '1500 Bytes'
    assert bytes_to_human(1500000) == '1.46 MB'
    assert bytes_to_human(1500000000) == '1.40 GB'
    assert bytes_to_human(1500000000000) == '1.36 TB'
    assert bytes_to_human(1500000000000000) == '1.31 PB'
    assert bytes_to_human(150000000000000000) == '1.27 EB'
    assert bytes_to_human(150000000000000000000) == '1.23 ZB'
    assert bytes_to_human(150000000000000000000000) == '1.19 YB'

# Generated at 2022-06-20 16:31:15.524739
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KBytes'
    assert bytes_to_human(1024, True) == '1.00 Kbits'
    assert bytes_to_human(1024, False, 'M') == '0.00 MBytes'
    assert bytes_to_human(1048576, False, 'M') == '1.00 MBytes'
    assert bytes_to_human(1048576, False, 'Mb') == '0.00 MBits'
    assert bytes_to_human(104857600, False, 'Mb') == '10.00 MBits'
    assert bytes_to_human(104857600, False, 'MBytes') == '10.00 MBytes'
    assert bytes_to_human(1048576, False, 'MBytes') == '1.00 MBytes'

# Generated at 2022-06-20 16:31:19.301199
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['TEST', 1, 'TEST3']) == ['test', 1, 'test3']
    assert lenient_lowercase(['TEST', 1]) == ['test', 1]
    assert lenient_lowercase(['TEST']) == ['test']

# Generated at 2022-06-20 16:31:31.157902
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('=== Test human_to_bytes function:')
    import pprint

# Generated at 2022-06-20 16:31:34.877554
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c'])
    assert(lenient_lowercase(['A', 'B', 0, 1]) == ['a', 'b', 0, 1])


# Unit tests for function human_to_bytes

# Generated at 2022-06-20 16:31:42.508284
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test list contains strings and integer
    str_list = ['str1', 'str2', 123, 'str3']
    # Check if returned value is not list
    assert not isinstance(lenient_lowercase(str_list), list)
    # Check if returned value is tuple
    assert isinstance(lenient_lowercase(str_list), tuple)
    # Check if subset of returned value is list
    assert isinstance(lenient_lowercase(str_list)[:2], list)



# Generated at 2022-06-20 16:31:59.906356
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    # Test list of strings
    lst1 = ['G', 'BYTES', 'z', 'p', 'Y']
    result = lenient_lowercase(lst1)
    print(result)
    assert result == ['g', 'bytes', 'z', 'p', 'y']

    # Test list of strings and ints
    lst2 = ['G', 1, 'BYTES', 'z', 2, 'p', 'Y']
    result = lenient_lowercase(lst2)
    print(result)
    assert result == ['g', 1, 'bytes', 'z', 2, 'p', 'y']

# Generated at 2022-06-20 16:32:08.454374
# Unit test for function bytes_to_human
def test_bytes_to_human():
    test_list = [('1MB', '1.00 MB'), ('1024', '1.00 KB'), ('18874368', '18.00 MB'), ('1Kb', '0.00 b'), ('1KB', '1000.00 b'), ('18874368', '1.80 MBb')]
    for test, expected in test_list:
        isbits = False
        if 'b' in test:
            isbits = True
        if expected != bytes_to_human(human_to_bytes(test, isbits=isbits), isbits):
            raise Exception("test_bytes_to_human() failed. Value %s was not converted to expected value %s" % (test, expected))



# Generated at 2022-06-20 16:32:20.073391
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test case: no unit, no default unit
    assert human_to_bytes('100') == 100
    # Test case: no unit, default unit
    assert human_to_bytes('100', default_unit='K') == 100 * 1024
    # Test case: byte unit
    assert human_to_bytes('100B') == 100
    # Test case: KB unit
    assert human_to_bytes('100KB') == 100 * 1024
    # Test case: MB unit
    assert human_to_bytes('100MB') == 100 * 1024 * 1024
    # Test case: GB unit
    assert human_to_bytes('100GB') == 100 * 1024 * 1024 * 1024
    # Test case: TB unit
    assert human_to_bytes('100TB') == 100 * 1024 * 1024 * 1024 * 1024
    # Test case: PB unit
    assert human_

# Generated at 2022-06-20 16:32:24.081923
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Testing with string
    lst = ['A', 'B', 'C', '/', 5, 6, 7]
    lowered = lenient_lowercase(lst)
    assert lowered == ['a', 'b', 'c', '/', 5, 6, 7]


# Generated at 2022-06-20 16:32:30.136297
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes(2, 'MB') == 2097152
    assert human_to_bytes('1Mb', isbits=True) == 1048576



# Generated at 2022-06-20 16:32:38.246917
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(100, 'B') == '100.00 Bytes'
    assert bytes_to_human(1024, 'B') == '1.00 KB'
    assert bytes_to_human(1024 * 1024, 'B') == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024, 'B') == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024, 'B') == '1.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024, 'B') == '1.00 PB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024, 'B') == '1.00 EB'

# Generated at 2022-06-20 16:32:49.451772
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test all the supported suffixes
    suffixes = [('b', 1), ('Kb', 1 << 10), ('Mb', 1 << 20), ('Gb', 1 << 30), ('Tb', 1 << 40), ('Pb', 1 << 50), ('Eb', 1 << 60), ('Zb', 1 << 70), ('Yb', 1 << 80)]
    for suffix, value in suffixes:
        assert human_to_bytes('42%s' % suffix, isbits=True) == 42 * value, \
            "FAILED '42%s' conversion to int" % suffix


# Generated at 2022-06-20 16:33:00.299056
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(5) == 5
    assert human_to_bytes(8, default_unit='B') == 8
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('2.5K') == 2560
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1.2m') == 1258291
    assert human_to_bytes('1g') == 1073741824
    assert human_to_bytes('1t') == 1099511627776
    assert human_to_bytes(1, 'Y') == 1152921504606846976
    assert human_to_bytes(1, 'Z') == 1180591620717411303424
    assert human_to_bytes(1, 'E') == 12089258196146

# Generated at 2022-06-20 16:33:10.131794
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, isbits=True) == '1.00 bits'
    assert bytes_to_human(1, unit='b') == '1.00 bits'
    assert bytes_to_human(1023) == '1023.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, isbits=True) == '1.00 Kb'
    assert bytes_to_human(1024 * 123) == '123.00 KB'
    assert bytes_to_human(1024 * 12342) == '12.11 MB'
    assert bytes_to_human(1024 * 12342, isbits=True) == '12.11 Mb'
    assert bytes_to

# Generated at 2022-06-20 16:33:19.984318
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:33:47.950811
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    from ansible.module_utils.parsing.convert_bool import boolean
    assert lenient_lowercase(['This', 'Is', 'A', 'Test', 'Case']) == ['this', 'is', 'a', 'test', 'case']
    assert lenient_lowercase(['True', 'False']) == ['true', 'false']
    assert lenient_lowercase([True, False]) == [True, False]
    assert lenient_lowercase([True, 'False']) == [True, 'false']

# Generated at 2022-06-20 16:33:54.407221
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['1', '2', '3']) == ['1', '2', '3']
    assert lenient_lowercase([{'extender': 'test'}, '2', '3']) == [{'extender': 'test'}, '2', '3']
    assert lenient_lowercase(['1', 2, '3']) == ['1', 2, '3']
    assert lenient_lowercase([u'1', '2', '3']) == ['1', '2', '3']
    assert lenient_lowercase([u'1', '2', None]) == ['1', '2', None]

# Generated at 2022-06-20 16:34:05.158986
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(102400) == '100.00 KB'
    assert bytes_to_human(10240000) == '9.77 MB'
    assert bytes_to_human(1024000000) == '953.67 MB'
    assert bytes_to_human(1024000000000) == '93.13 GB'
    assert bytes_to_human(1024000000000000) == '9.09 TB'
    assert bytes_to_human(1024000000000000000) == '8.79 PB'
    assert bytes_to_human(1024000000000000000000) == '8.58 EB'
    assert bytes_to_human(1024000000000000000000000) == '8.38 ZB'
    assert bytes_to_human(1024000000000000000000000000) == '8.19 YB'

# Generated at 2022-06-20 16:34:11.336718
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 3, 'A', 'B']) == [1, 2, 3, 'A', 'B']
    assert lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['B', 'A', 7]) == ['b', 'a', 7]

# Generated at 2022-06-20 16:34:21.295717
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(100) == '100.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 EB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 ZB'

# Generated at 2022-06-20 16:34:32.632271
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(2) == '2.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 EB'

# Generated at 2022-06-20 16:34:40.963421
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Unit test for function human_to_bytes"""

    assert human_to_bytes('1') == 1
    assert human_to_bytes('5') == 5
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('12.5') == 12
    assert human_to_bytes('12.5B') == 12
    assert human_to_bytes('.5') == 0
    assert human_to_bytes('.5B') == 0
    assert human_to_bytes('.5K') == 512
    assert human_to_bytes('.5M') == 524288

    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('10Kb') == 1280

# Generated at 2022-06-20 16:34:49.670720
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1) == 1, '1 byte should return 1 integer'
    assert human_to_bytes('1') == 1, '1 byte should return 1 integer'
    assert human_to_bytes(10) == 10, '10 bytes should return 10 integers'
    assert human_to_bytes(10.0) == 10, '10.0 bytes should return 10 integers'
    assert human_to_bytes('10.0') == 10, '10.0 bytes should return 10 integers'

    assert human_to_bytes('1M') == 1048576, '1 MB should return 1048576 integers'
    assert human_to_bytes('1M', isbits=True) == 8388608, '1 Mb should return 8388608 integers'

# Generated at 2022-06-20 16:35:00.028894
# Unit test for function human_to_bytes
def test_human_to_bytes():
    number = '5'
    expected = 5
    assert(human_to_bytes(number) == expected)

    number = '5E'
    expected = 5 * 1 << 60
    assert(human_to_bytes(number) == expected)

    number = '5Eb'
    expected = 5 * 1 << 60
    assert(human_to_bytes(number, isbits=True) == expected)

    number = '5M'
    expected = 5 * 1 << 20
    assert(human_to_bytes(number) == expected)

    number = '5Mb'
    expected = 5 * 1 << 20
    assert(human_to_bytes(number, isbits=True) == expected)


# Generated at 2022-06-20 16:35:10.893530
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''Testing human_to_bytes()'''
    def test(value, expected, default_unit, isbits):
        res = human_to_bytes(value, default_unit, isbits)
        assert res == expected, "Res={0}, Expected={1}, Value={2}, Default_unit={3}, Isbits={4}".format(res, expected, value, default_unit, isbits)

    test('10b', 10, None, True)
    test('10B', 10, None, False)
    test('10', 10, None, False)
    test('10', 10, None, True)
    test('10k', 10240, None, False)
    test('10k', 10240, None, True)
    test('10K', 10240, None, False)