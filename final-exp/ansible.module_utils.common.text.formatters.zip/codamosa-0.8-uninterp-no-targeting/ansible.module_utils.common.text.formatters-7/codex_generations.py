

# Generated at 2022-06-20 16:25:51.671383
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert list == type(lenient_lowercase([]))
    assert 'one' == lenient_lowercase(['one'])[0]
    assert 'two' == lenient_lowercase(['One', 'two'])[1]
    assert 1 == lenient_lowercase([1, 'two'])[0]
    assert 'two' == lenient_lowercase([1, 'two'])[1]


# Generated at 2022-06-20 16:26:00.966902
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(123, isbits=False, unit=None) == '123.00 Bytes'
    assert bytes_to_human(123, isbits=True, unit=None) == '123.00 bits'
    assert bytes_to_human(123, isbits=False, unit='Y') == '0.00 BY'
    assert bytes_to_human(123, isbits=False, unit='Z') == '0.00 BZ'
    assert bytes_to_human(123, isbits=False, unit='E') == '0.00 BE'
    assert bytes_to_human(123, isbits=False, unit='P') == '0.00 BP'
    assert bytes_to_human(123, isbits=False, unit='T') == '0.00 BT'

# Generated at 2022-06-20 16:26:03.213089
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['LOWER', 'MIXED', 'UPPER', 1, 2, 3]) == ['lower', 'mixed', 'upper', 1, 2, 3])



# Generated at 2022-06-20 16:26:08.063219
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'B', 'c']
    assert lenient_lowercase(['AbC', 'd']) == ['abc', 'd']
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['', 'a', 'b', '', '']) == ['', 'a', 'b', '', '']



# Generated at 2022-06-20 16:26:19.417006
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10, isbits=True, unit='b') == "10.00 bits"
    assert bytes_to_human(10, isbits=True, unit='KB') == "10240.00 bits"
    assert bytes_to_human(10, isbits=True, unit='K') == "10240.00 bits"
    assert bytes_to_human(10, isbits=True, unit='Kb') == "10240.00 bits"
    assert bytes_to_human(10, isbits=True, unit='kb') == "10.00 bits"
    assert bytes_to_human(10, isbits=True, unit='gb') == "10000000.00 bits"
    assert bytes_to_human(10, isbits=True, unit='b') == "10.00 bits"
    assert bytes_to

# Generated at 2022-06-20 16:26:22.127254
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['FOO', ['BAR']]) == ['foo', ['BAR']]


# Generated at 2022-06-20 16:26:28.833975
# Unit test for function human_to_bytes
def test_human_to_bytes():

    import pytest
    from ansible.module_utils.network.common.utils import human_to_bytes


# Generated at 2022-06-20 16:26:39.838536
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    import pytest

    # Pass a list with some strings lowercased
    assert lenient_lowercase(["Foo", "Bar", "Baz"]) == ["foo", "bar", "baz"]
    assert lenient_lowercase(["Foo", "Bar", 1, "Baz"]) == ["foo", "bar", 1, "baz"]
    assert lenient_lowercase(["Foo", "Bar", 1, "Baz", "Foo"]) == ["foo", "bar", 1, "baz", "foo"]
    assert lenient_lowercase(["Foo", "Bar", "Baz", "Foo"]) == ["foo", "bar", "baz", "foo"]

# Generated at 2022-06-20 16:26:51.663075
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1025) == '1.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1049000) == '1.01 MB'
    assert bytes_to_human(1234) == '1.21 KB'
    assert bytes_to_human(12345) == '12.06 KB'
    assert bytes_to_human(1234567) == '1.18 MB'

# Generated at 2022-06-20 16:27:00.915007
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Check whether integer number is returned
    assert isinstance(human_to_bytes('10M'), int)
    # Check whether proper number is returned
    assert human_to_bytes('10M') == 10 * 1024 * 1024
    # Check whether proper number is returned in case number is a float
    assert human_to_bytes('4.5G') == 4.5 * 1024 * 1024 * 1024
    # Check whether proper number is returned in case number is a float and rounded
    assert human_to_bytes('4.49G') == 4 * 1024 * 1024 * 1024
    # Check whether proper number is returned in case number is without suffix
    assert human_to_bytes('10') == 10
    # Check whether exception is raised in case non-number is passed

# Generated at 2022-06-20 16:27:13.715890
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1') == 1)
    assert(human_to_bytes('2') == 2)
    assert(human_to_bytes('-1') == -1)
    assert(human_to_bytes('0') == 0)
    assert(human_to_bytes('+1') == 1)
    assert(human_to_bytes('2.5') == 2)
    assert(human_to_bytes('2.5B') == 2)
    assert(human_to_bytes('2.5b') == 2)
    assert(human_to_bytes('1b') == 1)
    assert(human_to_bytes('1B') == 1)
    assert(human_to_bytes('1Kb') == 1024)
    assert(human_to_bytes('1KB') == 1000)

# Generated at 2022-06-20 16:27:24.021540
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024*1024) == '1.00 MB'
    assert bytes_to_human(1024*1024*1024) == '1.00 GB'
    assert bytes_to_human(1024*1024*1024*1024) == '1.00 TB'
    assert bytes_to_human(1024*1024*1024*1024*1024) == '1.00 PB'
    assert bytes_to_human(1024*1024*1024*1024*1024*1024) == '1.00 EB'
    assert bytes_to_human(1024*1024*1024*1024*1024*1024*1024) == '1.00 ZB'

# Generated at 2022-06-20 16:27:34.089089
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import unittest
    class TestHumanToBytes(unittest.TestCase):

        def test_human_to_bytes(self):
            # bytes
            self.assertEqual(human_to_bytes('1K'), 1024)
            self.assertEqual(human_to_bytes('1M'), 1024 * 1024)
            self.assertEqual(human_to_bytes('1G'), 1024 * 1024 * 1024)
            # bit
            self.assertEqual(human_to_bytes('1K', isbits=True), 1024)
            self.assertEqual(human_to_bytes('1M', isbits=True), 1024 * 1024)
            self.assertEqual(human_to_bytes('1G', isbits=True), 1024 * 1024 * 1024)

            #test with default unit B

# Generated at 2022-06-20 16:27:44.650601
# Unit test for function bytes_to_human
def test_bytes_to_human():

    assert bytes_to_human(0) == "0 Bytes"
    assert bytes_to_human(0, unit="b") == "0 Bytes", "test with unit b failed"
    assert bytes_to_human(0, unit="B") == "0 Bytes", "test with unit B failed"
    assert bytes_to_human(0, unit="B") == "0 Bytes", "test with unit B failed"
    assert bytes_to_human(0, unit="Mb") == "0 Mbits", "test with unit Mb failed"
    assert bytes_to_human(0, unit="MB") == "0 MBytes", "test with unit MB failed"
    assert bytes_to_human(0, unit="") == "0 Bytes", "test with unit '' failed"
    assert bytes_to_human(0, unit="K")

# Generated at 2022-06-20 16:27:56.209118
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:28:06.462074
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test base case
    assert human_to_bytes('1000000000') == 1000000000
    assert human_to_bytes('1000000000b') == 1000000000
    # Test upper/low case unit
    assert human_to_bytes('1M') == 1000000
    assert human_to_bytes('1m') == 1000000
    assert human_to_bytes('1mB') == 1000000
    assert human_to_bytes('1MB') == 1000000
    # Test upper/low case unit for bits
    assert human_to_bytes('1Mb') == 1000000
    assert human_to_bytes('1mb') == 1000000
    assert human_to_bytes('1mb', isbits=True) == 1000000
    assert human_to_bytes('1MB', isbits=True) == 131072
    # Test decimal

# Generated at 2022-06-20 16:28:10.008689
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['A', 'B']) == ['a', 'b']
    assert lenient_lowercase(['A', 1, 'B', 3]) == ['a', 1, 'b', 3]
    assert lenient_lowercase(['A', ['B'], 'C', (1,), 'D']) == ['a', ['B'], 'c', (1,), 'd']


# Generated at 2022-06-20 16:28:21.968037
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # bytes tests
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1Bytes') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1byte') == 1
    assert human_to_bytes('1Bb') == 1
    assert human_to_bytes('1Bbyte') == 1
    assert human_to_bytes('1bB') == 1
    assert human_to_bytes('1byteB') == 1
    assert human_to_bytes('1byteByte') == 1
    assert human_to_bytes('1byteByteB') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes(1) == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes

# Generated at 2022-06-20 16:28:27.976290
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'C', 1]) == ['a', 'b', 'c', 1]


# Generated at 2022-06-20 16:28:30.281848
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'A', 5, 'B', 10, 'C']) == [1, 'a', 5, 'b', 10, 'c']


# Generated at 2022-06-20 16:28:39.984117
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(20) == '20.00 Bytes'
    assert bytes_to_human(20, unit='z') == '20.00 ZBytes'
    assert bytes_to_human(20, unit='b') == '20.00 bits'
    assert bytes_to_human(20, isbits=True) == '20.00 bits'
    assert bytes_to_human(20, unit='B') == '20.00 Bytes'


# Generated at 2022-06-20 16:28:49.022931
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(123) == '123 Bytes'
    assert bytes_to_human(1234) == '1.21 KB'
    assert bytes_to_human(12345) == '12.06 KB'
    assert bytes_to_human(1234567) == '1.18 MB'
    assert bytes_to_human(1234567890) == '1.15 GB'
    assert bytes_to_human(1234567890123) == '1.12 TB'
    assert bytes_to_human(1234567890123456) == '1.1 PB'
    assert bytes_to_human(1234567890123456789) == '1111.11 PB'
    assert bytes_to_human(1234567890123456789012) == '1010000 PB'
    assert bytes_

# Generated at 2022-06-20 16:28:56.059193
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase(['', None, '', False, True]) == ['', None, '', False, True]



# Generated at 2022-06-20 16:29:05.776479
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1000000000) == '1.00 GB'
    assert bytes_to_human(100) == '100.00 Bytes'
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(2000) == '2.00 KB'
    assert bytes_to_human(2048, unit='KB') == '2.00 KB'
    assert bytes_to_human(2048, unit='MB') == '0.00 MB'
    # bits
    assert bytes_to_human(0, isbits=True) == '0 bits'
    assert bytes_to_human(1000000000, isbits=True) == '1.00 Gb'

# Generated at 2022-06-20 16:29:14.994570
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('100') == 100
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('100K') == 102400
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('100M') == 104857600
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1B', default_unit='B') == 1
    assert human_to_bytes('100B', default_unit='B') == 100

# Generated at 2022-06-20 16:29:25.065916
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # Tests for function human_to_bytes
    # Testing positive cases
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('2Y') == 2199023255552
    assert human_to_bytes('0.5G') == 536870912
    assert human_to_bytes('0.5Z') == 5368709120
    assert human_to_bytes('0.5T') == 549755813888
    assert human_to_bytes('0.5E') == 5583458809664
    assert human_to_bytes('0.5P') == 567137275957248

# Generated at 2022-06-20 16:29:37.912814
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lc = lenient_lowercase
    assert lc([1]) == [1]
    assert lc(['1']) == ['1']
    assert lc([1, '1']) == [1, '1']
    assert lc(['A']) == ['a']
    assert lc(['a']) == ['a']
    assert lc(['A', 'b']) == ['a', 'b']
    assert lc(['A', 'b', 'C']) == ['a', 'b', 'c']
    assert lc(['A', 'b', 'C', 'd']) == ['a', 'b', 'c', 'd']
    assert lc(['A', 'b', 'C', 'd', 'E']) == ['a', 'b', 'c', 'd', 'e']


# Generated at 2022-06-20 16:29:43.457608
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(5, isbits=True) == '40 bits'
    assert bytes_to_human(5) == '5 Bytes'
    assert bytes_to_human(5, unit='b') == '40 bits'
    assert bytes_to_human(5, unit='B') == '5 Bytes'
    assert bytes_to_human(5, unit='Bb') == '5 Bytes'

# Generated at 2022-06-20 16:29:52.556306
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == (1 << 20)
    assert human_to_bytes('1M', isbits=True) == (1 << 20) * 8
    assert human_to_bytes('1M', default_unit='M') == (1 << 20)
    assert human_to_bytes('0.5B') == 0.5
    assert human_to_bytes('0.5k') == 512
    assert human_to_bytes('0.5Kb') == 512
    assert human_to_bytes('0.5kB', unit='b', isbits=True) == 512
    assert human_to_bytes('0.5 mb', isbits=True) == 512
    assert human_to_bytes('1.5 B', unit='k', isbits=True) == 3 * 8
    assert human_to_bytes

# Generated at 2022-06-20 16:30:03.283781
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert '1.00 B' == bytes_to_human(1)
    assert '10.00 B' == bytes_to_human(10)
    assert '100.00 B' == bytes_to_human(100)
    assert '1.02 KB' == bytes_to_human(1024)
    assert '1.00 KB' == bytes_to_human(1000)
    assert '1.00 MB' == bytes_to_human(1000 * 1000, unit='m')
    assert '1.00 MB' == bytes_to_human(1000 * 1000, unit='mB')
    assert '1.00 MB' == bytes_to_human(1000 * 1000, unit='mb')
    assert '1.00 MB' == bytes_to_human(1024 * 1024, unit='m')
    assert '1.00 MB' == bytes_to

# Generated at 2022-06-20 16:30:15.226661
# Unit test for function bytes_to_human
def test_bytes_to_human():
    byte_tests = (
        (0, '0 Bytes'),
        (1, '1 Bytes'),
        (1 << 10, '1.00 KB'),
        (1 << 20, '1.00 MB'),
        (1 << 30, '1.00 GB'),
        (1 << 40, '1.00 TB'),
        (1 << 50, '1.00 PB'),
        (1 << 60, '1.00 EB'),
        (1 << 70, '1.00 ZB'),
        (1 << 80, '1.00 YB'),
    )


# Generated at 2022-06-20 16:30:20.292620
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K', isbits=False) == 1024
    assert human_to_bytes('1K', isbits=False, default_unit='B') == 1024
    assert human_to_bytes(1, 'K', isbits=False) == 1024
    assert human_to_bytes(1, 'KB', isbits=False) == 1024
    assert human_to_bytes(1, 'KiB', isbits=False) == 1024
    assert human_to_bytes(1, 'Kib', isbits=False) == 1024
    assert human_to_bytes('2K', isbits=False) == 2048
    assert human_to_bytes('1MB', isbits=False, default_unit='B') == 1048576
    assert human_to_bytes('1M', isbits=False, default_unit='B')

# Generated at 2022-06-20 16:30:32.021251
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(140) == '140.00 Bytes'
    assert bytes_to_human(1480) == '1.45 KB'
    assert bytes_to_human(1480, isbits=True) == '11.84 Kb'
    assert bytes_to_human(1480, unit='k') == '1.45 KB'
    assert bytes_to_human(1480, unit='K') == '1.45 KB'
    assert bytes_to_human(1480, unit='k', isbits=True) == '11.84 Kb'
    assert bytes_to_human(1480, unit='K', isbits=True) == '11.84 Kb'
    assert bytes_to_human(1480000) == '1.40 MB'

# Generated at 2022-06-20 16:30:40.861005
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', False, 'C']) == ['a', False, 'c']
    assert lenient_lowercase(['A', None, 'C']) == ['a', None, 'c']



# Generated at 2022-06-20 16:30:43.083200
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'a', 'B', 3]) == [1, 'a', 'B', 3]



# Generated at 2022-06-20 16:30:51.871037
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["a", "B", "C"]) == ["a", "b", "c"]
    assert lenient_lowercase(["a", 1, 2]) == ["a", 1, 2]
    assert lenient_lowercase(["A", 1, 2]) == ["a", 1, 2]
    assert lenient_lowercase(["A", 1, 2]) != ["a", "b", "c"]
    assert lenient_lowercase(["A", 1, 2]) != ["A", "B", "C"]

# Generated at 2022-06-20 16:31:03.088292
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:31:06.936665
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['1', '2', '3']) == ['1', '2', '3']
    assert lenient_lowercase(['1', 2, '3']) == ['1', 2, '3']



# Generated at 2022-06-20 16:31:16.367762
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1b', default_unit='B') == 1
    assert human_to_bytes('1b', default_unit='B', isbits=True) == 1

    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1B', default_unit='B') == 1
    assert human_to_bytes('1B', default_unit='B', isbits=True) == 8

    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576

    assert human_to_bytes

# Generated at 2022-06-20 16:31:24.565737
# Unit test for function bytes_to_human
def test_bytes_to_human():
    test_data = [
        (1048576, '1.00 MB'), (0, '0 Bytes'), (123456789, '117.74 MB'),
        (1162805192, '1.08 GB'), (1234567890123, '11.16 TB'),
        (12345678901234567890, '1.07 PB'), (12345678901234567890123, '110.84 EB')
    ]
    for (size, expected_result) in test_data:
        result = bytes_to_human(size)
        assert (result == expected_result)



# Generated at 2022-06-20 16:31:32.993376
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['A', 'Bc', u'D']) == ['a', 'bc', u'd']
    assert lenient_lowercase(['A', (1,2,3), u'D']) == ['a', (1,2,3), u'd']



# Generated at 2022-06-20 16:31:40.438682
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('10') == 10
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1K', 'Kb') == 1024
    assert human_to_bytes('1.5K', 'Kb') == 1536
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1.5MB') == 1572864
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1.5b') == 1.5
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1.5Mb') == 1572864
   

# Generated at 2022-06-20 16:31:44.888408
# Unit test for function bytes_to_human
def test_bytes_to_human():

    f = bytes_to_human(22343, isbits=True, unit='b')
    assert f == '22343 bits'

    f = bytes_to_human(22343, isbits=False, unit='B')
    assert f == '22343 Bytes'

    f = bytes_to_human(22343)
    assert f == '22343 Bytes'



# Generated at 2022-06-20 16:31:50.660280
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.2 Mb', isbits=True) == int(1200000)
    assert human_to_bytes('1.2Mb', isbits=True) == int(1200000)
    assert human_to_bytes('1.2Mb', isbits=False) == int(1200000)
    assert human_to_bytes('1.2Mb', isbits=False, default_unit='K') == int(1200000)
    assert human_to_bytes('1.2Mb', isbits=False, default_unit='Kb') == int(1200000)
    assert human_to_bytes('1.2Mb', isbits=True, default_unit='Kb') == int(1200000)

# Generated at 2022-06-20 16:32:00.949115
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # some basic tests
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1Mb', isbits=False) == 1048576/8
    assert human_to_bytes('1Mb', isbits=False, unit='B') == 1048576/8
    assert human_to_bytes('1Mb', isbits=False, unit='B') == human_to_bytes(1, 'Mb', False)
    assert human_to_bytes('1', isbits=False, unit='Mb') == human_to_bytes('1Mb')
    assert human

# Generated at 2022-06-20 16:32:02.830887
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['TEST', 2]) == ['test', 2]



# Generated at 2022-06-20 16:32:05.631345
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['a', 'B', 'c', 1, 'e']) == ['a', 'b', 'c', 1, 'e'])

# Generated at 2022-06-20 16:32:12.998070
# Unit test for function bytes_to_human
def test_bytes_to_human():
    def assert_bytes_to_human(size, res, isbits=False, unit=None):
        assert bytes_to_human(size, isbits, unit) == res
    assert_bytes_to_human(100, '100 Bytes')
    assert_bytes_to_human(1000, '1,000 Bytes')
    assert_bytes_to_human(1000.0, '999.00 Bytes')
    assert_bytes_to_human(200000000, '200,000.00 KB')
    assert_bytes_to_human(100000000000, '100,000.00 MB')
    assert_bytes_to_human(200000000000, '200,000.00 MB')
    assert_bytes_to_human(3000000000000, '300,000.00 GB')
    # testing unit filter
    assert_bytes_to_

# Generated at 2022-06-20 16:32:24.340857
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(11) == '11 Bytes'
    assert bytes_to_human(12) == '12 Bytes'
    assert bytes_to_human(150) == '150 Bytes'
    assert bytes_to_human(1500) == '1.46 KB'
    assert bytes_to_human(1500, unit='B') == '1500 Bytes'
    assert bytes_to_human(150000) == '146.10 KB'
    assert bytes_to_human(1500000) == '1.43 MB'
    assert bytes_to_human(15000000) == '14.33 MB'
    assert bytes_to_human(15000000) == '14.33 MB'
    assert bytes_to_human(1500000000) == '1.37 GB'

# Generated at 2022-06-20 16:32:28.519397
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['abc', 'DEF', 3, 'ghi']) == ['abc', 'def', 3, 'ghi']



# Generated at 2022-06-20 16:32:43.991396
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1023) == '1023.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1025) == '1.00 KB'
    assert bytes_to_human(1048575) == '1023.99 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048577) == '1.00 MB'
    assert bytes_to_human(1073741823) == '1023.99 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human(1073741825) == '1.00 GB'

# Generated at 2022-06-20 16:32:52.826675
# Unit test for function bytes_to_human
def test_bytes_to_human():
    import random
    import string

    random.seed(123)
    isbits = False
    unit_idx = 0
    old_unit = None
    for idx in range(10000):
        unit = random.choice(list(SIZE_RANGES))
        if unit_idx % 100 == 0:
            old_unit = unit
            unit = None
        size = random.randint(0, 1 << 40)
        res = bytes_to_human(size, isbits, unit)
        if unit_idx % 100 == 99:
            assert res.endswith(old_unit), "%s doesn't end with %s" % (res, old_unit)
        bytes_ = human_to_bytes(res)

# Generated at 2022-06-20 16:33:01.891217
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''Unit test for function human_to_bytes'''
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10.0b') == 10
    assert human_to_bytes('10') == 10

    assert human_to_bytes('10K') == 10240
    assert human_to_bytes(10, 'K') == 10240
    assert human_to_bytes('10.1K') == 10240
    assert human_to_bytes(10.1, 'K') == 10240
    assert human_to_bytes('10.1KB') == 10240

    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes('10.1M') == 10485760
   

# Generated at 2022-06-20 16:33:10.597837
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print('The tests expect the following result:')
    print('Convert Bytes: ', end='')
    print('1B(1 byte) 2B(2 byte) 1.00KB(1024 byte) 1.00MB(1048576 byte) 1.00GB(1073741824 byte) 1.00TB(1099511627776 byte) 1.00PB(1125899906842624 byte) 1.00EB(1152921504606846976 byte) 1.00ZB(1180591620717411303424 byte) 1.00YB(1208925819614629174706176 byte)')
    print('Convert bits: ', end='')

# Generated at 2022-06-20 16:33:18.687310
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10, unit='b') == '10.00 bits'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, isbits=True) == '10.00 bits'
    assert bytes_to_human(10, isbits=True, unit='b') == '10.00 bits'
    assert bytes_to_human(10, isbits=False, unit='B') == '10.00 Bytes'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'
    assert bytes_to_human(10, unit='m') == '10.00 MB'

# Generated at 2022-06-20 16:33:29.057979
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test call with default unit
    assert human_to_bytes('8M') == 8388608
    # Test call with custom unit
    assert human_to_bytes('10240', 'K') == 10240
    # Test call with invalid input but valid unit
    assert human_to_bytes('8M', 'K') == 1048576
    # Test call with valid unit in original input string
    assert human_to_bytes('8M', 'K') == 1048576
    # Test call with bad unit
    try:
        human_to_bytes('8M', 'I')
    except ValueError:
        pass
    else:
        raise AssertionError('human_to_bytes() does not raise ValueError with invalid unit')
    # Test call with bad input format

# Generated at 2022-06-20 16:33:39.225696
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test for invalid parameters
    try:
        bytes_to_human(-1)
    except ValueError:
        pass
    else:
        raise AssertionError("bytes_to_human() failed to raise exception when input was < 0")

    # Test for boundary numbers
    assert bytes_to_human(0) == '0.00 Bytes'

    # Test for bytestring
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(7, unit='b') == '7.00 bits'
    assert bytes_to_human(10, unit='K') == '10.00 KB'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(10240) == '10.00 KB'
    assert bytes_to_human

# Generated at 2022-06-20 16:33:42.703476
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['a', 'B', 1]
    assert lenient_lowercase(lst) == ['a', 'b', 1]



# Generated at 2022-06-20 16:33:46.878215
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["AaBb"]) == ["aabb"]
    assert lenient_lowercase(["AaBb", "123"]) == ["aabb", "123"]


# Unit tests for function human_to_bytes

# Generated at 2022-06-20 16:33:49.240884
# Unit test for function bytes_to_human
def test_bytes_to_human():
    bytes_val = 1048575
    bit_val = 8388607

    assert bytes_to_human(bytes_val) == '1.00 MB'
    assert bytes_to_human(bit_val, isbits=True) == '839.00 kb'

# Generated at 2022-06-20 16:34:06.416675
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(2) == '2 Bytes'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(100) == '100 Bytes'
    assert bytes_to_human(1000) == '1.00 KB'
    assert bytes_to_human(2000) == '2.00 KB'
    assert bytes_to_human(10000) == '9.77 KB'
    assert bytes_to_human(20000) == '19.5 KB'
    assert bytes_to_human(100000) == '97.7 KB'
    assert bytes_to_human(200000) == '195 KB'
    assert bytes_to_human(1000000) == '976.6 KB'
    assert bytes

# Generated at 2022-06-20 16:34:13.737743
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_cases = [
        [['A', 'B'], ['a', 'b']],
        [['A', 1, 'B'], ['a', 1, 'b']],
        [['A', 1, 'B', (1,)], ['a', 1, 'b', (1,)]],
    ]

    for test in test_cases:
        assert lenient_lowercase(test[0]) == test[1]



# Generated at 2022-06-20 16:34:22.799781
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human(1099511627776) == '1.00 TB'
    assert bytes_to_human(1125899906842624) == '1.00 PB'
    assert bytes_to_human(1152921504606846976) == '1.00 EB'
    assert bytes_to_human(1180591620717411303424) == '1.00 ZB'
    assert bytes_to_human

# Generated at 2022-06-20 16:34:27.043905
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_lst = ['a', 'b', 'c', 'ABC', ['d', 'E']]
    assert lenient_lowercase(test_lst) == ['a', 'b', 'c', ['d', 'e'], 'abc']


# Generated at 2022-06-20 16:34:32.863622
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test input list having only strings
    test_input = ['Red', 'Green', 'Blue']
    assert lenient_lowercase(test_input) == ['red', 'green', 'blue']

    # Test input list having a non string value
    test_input = [None, 'Red', 'Green', 'Blue']
    assert lenient_lowercase(test_input) == [None, 'red', 'green', 'blue']


# Generated at 2022-06-20 16:34:36.842306
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'C', 'd']) == ['a', 'b', 'c', 'd']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase(['A', 'b', 2, True]) == ['a', 'b', 2, True]



# Generated at 2022-06-20 16:34:44.405524
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test with lowercase
    assert lenient_lowercase(['string', 1, 2, 'string']) == ['string', 1, 2, 'string']
    assert lenient_lowercase(['string', 1, 2, 'string']).__class__.__name__ == 'list'

    # Test with uppercase
    assert lenient_lowercase(['STRING', 1, 2, 'STRING']) == ['string', 1, 2, 'string']
    assert lenient_lowercase(['STRING', 1, 2, 'STRING']).__class__.__name__ == 'list'

    # Test with mixed case
    assert lenient_lowercase(['sTrInG', 1, 2, 'sTrInG']) == ['string', 1, 2, 'string']

# Generated at 2022-06-20 16:34:51.756052
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:35:04.047551
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """
    bytes_to_human() will convert number of bytes to human readable format
    example: bytes_to_human(10000, isbits=False) returns: '9.77 KB',
    bytes_to_human(10000, isbits=True) returns: '79.2 Kb' and
    bytes_to_human(10000, unit='k') returns '9.77 KB'.
    """
    assert bytes_to_human(1000) == '1000.00 Bytes'
    assert bytes_to_human(1000, isbits=True) == '8000.00 bits'
    assert bytes_to_human(10000) == '9.77 KB'
    assert bytes_to_human(10000, isbits=True) == '79.2 Kb'
    assert bytes_to_human(10000, unit='k') == '9.77 KB'

# Generated at 2022-06-20 16:35:06.719893
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    s_list = ['AAAbbb', 1234]
    assert lenient_lowercase(s_list) == ['aaabbb', 1234]

# Generated at 2022-06-20 16:35:29.864334
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test = [1, 'aB', 'AC', 'ba', 'Ca', 'dc', 'Dd', 'EE', 'ff', 'sI', 'sU', 'sV', 'sT', 'sO', 'sP', 'sQ', 'sR', 'sW']
    result = ['1', 'ab', 'AC', 'ba', 'Ca', 'dc', 'Dd', 'EE', 'ff', 'si', 'su', 'sv', 'st', 'so', 'sp', 'sq', 'sr', 'sw']
    result = lenient_lowercase(test)
    assert result == result

# Generated at 2022-06-20 16:35:32.951951
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    assert lenient_lowercase(['1', 2]) == ['1', 2]
    assert lenient_lowercase(['1', 2, 'AbC', 'De']) == ['1', 2, 'abc', 'de']



# Generated at 2022-06-20 16:35:43.246873
# Unit test for function bytes_to_human
def test_bytes_to_human():

    # Test for default/empty unit
    assert bytes_to_human(size=1024) == '1.00 KB'
    assert bytes_to_human(size=1024, unit='') == '1.00 KB'
    assert bytes_to_human(size=1024, unit=None) == '1.00 KB'

    # Test for bytes unit
    assert bytes_to_human(size=1024, unit='B') == '1024.00 Bytes'
    assert bytes_to_human(size=1024, unit='b') == '1024.00 Bytes'
    assert bytes_to_human(size=1024, unit='byte') == '1024.00 Bytes'
    assert bytes_to_human(size=1024, unit='Byte') == '1024.00 Bytes'