

# Generated at 2022-06-20 16:25:50.076629
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, isbits=True) == '10.00 bits'
    assert bytes_to_human(10, unit='K') == '0.01 KB'
    assert bytes_to_human(10, unit='K', isbits=True) == '0.01 Kb'

# Generated at 2022-06-20 16:25:59.439390
# Unit test for function bytes_to_human
def test_bytes_to_human():

    result = bytes_to_human('10') == '10.00 Bytes'
    assert result

    result = bytes_to_human(10) == '10.00 Bytes'
    assert result

    result = bytes_to_human('10K') == '10.00 KB'
    assert result

    result = bytes_to_human(10, unit='k') == '10.00 KB'
    assert result

    result = bytes_to_human('10M') == '10.00 MB'
    assert result

    result = bytes_to_human(10, unit='m') == '10.00 MB'
    assert result

    result = bytes_to_human('10G') == '10.00 GB'
    assert result

    result = bytes_to_human(10, unit='g') == '10.00 GB'

# Generated at 2022-06-20 16:26:06.909261
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(2) == '2.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(2097152) == '2.00 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human(2147483648) == '2.00 GB'
    assert bytes_to_human(1099511627776) == '1.00 TB'

# Generated at 2022-06-20 16:26:14.985072
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test bytes (bits=False)
    assert(human_to_bytes('1MB') == 1048576)
    assert(human_to_bytes('1MB', default_unit='MB') == 1048576)
    assert(human_to_bytes('1', default_unit='MB') == 1048576)
    assert(human_to_bytes('1.5Mb', isbits=False) == 1572864)
    assert(human_to_bytes('1.5Mb', default_unit='MB', isbits=False) == 1572864)
    assert(human_to_bytes('1.5Mb', default_unit='kb', isbits=False) == 1536)
    # Test bits
    assert(human_to_bytes('1MB', isbits=True) == 8388608)

# Generated at 2022-06-20 16:26:25.648891
# Unit test for function human_to_bytes
def test_human_to_bytes():
    def test_it(in_value, expected, unit=None, isbits=False):
        result = human_to_bytes(in_value, default_unit=unit, isbits=isbits)
        if result != expected:
            raise AssertionError("Failed to convert '%s'. Expected %s, got %s" % (in_value, expected, result))

    test_it('1K', 1024)
    test_it('1M', 1024 * 1024)
    test_it('1G', 1024 * 1024 * 1024)
    test_it('1T', 1024 * 1024 * 1024 * 1024)

    test_it('1000', 1000)
    test_it('1.1K', 1120)
    test_it('1.1M', 1120 * 1024)

# Generated at 2022-06-20 16:26:37.845921
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # byte case
    assert human_to_bytes('0b') == 0
    assert human_to_bytes('0') == 0
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('0.5') == 0
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.2') == 1
    assert human_to_bytes('1.6') == 1
    assert human_to_bytes('1K') == 1 << 10
    assert human_to_bytes('1.5M') == (1 << 20) + (1 << 19)
    # bit case
    assert human_to_bytes('1.1b', True) == 1
    assert human_to_bytes('10b', True) == 1
    assert human_to_bytes('12b', True)

# Generated at 2022-06-20 16:26:49.270548
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # checking base case
    result = bytes_to_human(1)
    assert result == '1.00 Bytes'

    # checking isbits
    result = bytes_to_human(1024, True)
    assert result == '8.00 bits'

    # checking output format
    result = bytes_to_human(1000)
    assert result == '1000.00 Bytes'

    # checking unit
    result = bytes_to_human(1024, unit='k')
    assert result == '1.00 KB'

    # checking for different unit
    result = bytes_to_human(1, unit='b')
    assert result == '1.00 Bytes'

    # checking wrong unit
    try:
        result = bytes_to_human(1, unit='x')
    except ValueError:
        pass



# Generated at 2022-06-20 16:26:59.597713
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10) == 10
    assert human_to_bytes(10, 'B') == 10
    assert human_to_bytes(10, 'KB') == 10240
    assert human_to_bytes(10, 'MB') == 10485760
    assert human_to_bytes(10, 'GB') == 10737418240
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10', 'B') == 10
    assert human_to_bytes('10', 'KB') == 10240
    assert human_to_bytes('10', 'MB') == 10485760
    assert human_to_bytes('10', 'GB') == 10737418240

    assert human_to_bytes('1MB') == 1048576

# Generated at 2022-06-20 16:27:11.444504
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
        Unit test function for function human_to_bytes

        The function checks if:
            - function works as expected
            - function raises ValueError when an unexpected string is passed to it
    '''

    # Unit test for function human_to_bytes_bytes

# Generated at 2022-06-20 16:27:19.016836
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('5B') == 5
    assert human_to_bytes(5) == 5
    assert human_to_bytes('2048B') == 2048
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K') == 2**10
    assert human_to_bytes('10K') == 2**10 * 10
    assert human_to_bytes('1M') == 2**20
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1G') == 2**30
    assert human_to_bytes('1G') == 1024 * 1024 * 1024
    assert human_to_bytes('1T') == 2**40
    assert human_to_bytes('1T') == 1024

# Generated at 2022-06-20 16:27:32.539011
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:27:40.140197
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ["CASE-SENsiTIve", "lower"]
    assert ["case-sensitive", "lower"] == lenient_lowercase(test_list), \
        "Did not convert two strings to lower case."
    non_string_list = [3, "CASE-SENsiTIve", "lower"]
    assert [3, "case-sensitive", "lower"] == lenient_lowercase(non_string_list), \
        "Did not pass non-string elements of the list through untouched."



# Generated at 2022-06-20 16:27:48.987118
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert('0 Bytes' == bytes_to_human(0))
    assert('1 Byte' == bytes_to_human(1))
    assert('1 Kilobyte' == bytes_to_human(1024))
    assert('2048 Bytes' == bytes_to_human(2048))
    assert('1.00 Kilobytes' == bytes_to_human(2048, 2))
    assert('1.00 Megabytes' == bytes_to_human(1024 * 1024, 2))
    assert('1.00 Gigabytes' == bytes_to_human(1024 * 1024 * 1024, 2))
    assert('1.00 Terabytes' == bytes_to_human(1024 * 1024 * 1024 * 1024, 2))
    assert('1.00 Petabytes' == bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024, 2))

# Generated at 2022-06-20 16:27:51.382121
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [3, 'Yes', 'no']
    assert ['no', 'yes', 'no'] == lenient_lowercase(test_list)


# Generated at 2022-06-20 16:27:55.042976
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    l = ['a', 'b', 'c', 1, 2, 3, None]
    result = ['a', 'b', 'c', 1, 2, 3, None]
    assert lenient_lowercase(l) == result


# Generated at 2022-06-20 16:28:02.645380
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test suffix KB
    assert bytes_to_human(1000) == '1.00 KB'
    assert bytes_to_human(1000, isbits=True) == '1.00 Kbits'
    assert bytes_to_human(1000, isbits=True, unit='K') == '1.00 Kbits'
    assert bytes_to_human(1000, isbits=True, unit='M') == '1.00 Mbits'
    assert bytes_to_human(1023, unit='K') == '1.00 KB'

    # Test suffix MB
    assert bytes_to_human(1000 * 1000) == '1.00 MB'
    assert bytes_to_human(1000 * 1000, isbits=True) == '1.00 Mbits'

# Generated at 2022-06-20 16:28:10.483704
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KBytes'
    assert bytes_to_human(1024 * 1024) == '1.00 MBytes'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 EBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 ZBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024)

# Generated at 2022-06-20 16:28:14.336840
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['lower', 'lower', 'lower', 'lower'] == lenient_lowercase(['Lower', 'LOWER', 'Lower', 1])


# Generated at 2022-06-20 16:28:24.249152
# Unit test for function human_to_bytes
def test_human_to_bytes():
    class Test:
        def __init__(self, number, unit, result):
            self.number = number
            self.unit = unit
            self.result = result
            pass

        def __str__(self):
            return "Test(%s, %s, %d)" % (self.number, self.unit, self.result)


# Generated at 2022-06-20 16:28:29.207967
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_data = [u'10M', 10, ['10M', 10, u'Foo', 'bar']]
    output_data = [u'10m', 10, [u'10m', 10, u'Foo', 'bar']]
    assert output_data == lenient_lowercase(input_data)


# Generated at 2022-06-20 16:28:46.191360
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test 1: Test with bytes
    given_bytes = 1048576
    expected_output = '1.00 MB'

    actual_output = bytes_to_human(given_bytes)
    assert actual_output == expected_output, "Actual output '{}' != Expected output '{}'".format(actual_output, expected_output)

    # Test 2: Test with bits
    given_bits = 1048576
    expected_output = '1.00 Mbits'

    actual_output = bytes_to_human(given_bits, isbits=True)
    assert actual_output == expected_output, "Actual output '{}' != Expected output '{}'".format(actual_output, expected_output)

    # Test 3: Test with bytes and unit
    given_bytes = 1048576

# Generated at 2022-06-20 16:28:48.262880
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Test', 'TEST', 'Test123', 123]) == ['test', 'test', 'test123', 123]



# Generated at 2022-06-20 16:28:55.287301
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    array_lower = ['test', 1, 'A', 'b']
    assert lenient_lowercase(array_lower) == ['test', 1, 'a', 'b']
    array_lower = [{'test': 'a', 'b': 1}, {'test': 'a', 'b': 1}]
    assert lenient_lowercase(array_lower) == [{'test': 'a', 'b': 1}, {'test': 'a', 'b': 1}]



# Generated at 2022-06-20 16:29:05.119331
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:29:14.479682
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """
    This function will run a series of unit tests against
    the function named: human_to_bytes().
    """
    print("Testing function human_to_bytes()")
    try:
        human_to_bytes('1A')
    except ValueError as e:
        print("Testing with '1A' failed as expected: %s" % e)
    else:
        print("Testing with '1A' passed unexpectedly.")
        print("Aborting with errors.")
        exit(1)

    try:
        human_to_bytes('10')
    except ValueError as e:
        print("Testing with '10' failed as expected: %s" % e)
    else:
        print("Testing with '10' passed unexpectedly.")
        print("Aborting with errors.")
        exit(1)


# Generated at 2022-06-20 16:29:24.802700
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test with a string list
    test_list = ['a', 'B', 'c', 'd', 'e', 'f', 'G']
    assert lenient_lowercase(test_list) == ['a', 'b', 'c', 'd', 'e', 'f', 'g']
    # Test with a mixed list
    test_list = ['a', 1, 'B', 'c', 'd', 'e', 'f', 'G', False]
    assert lenient_lowercase(test_list) == ['a', 1, 'b', 'c', 'd', 'e', 'f', 'g', False]
    # Test with a various complex elements
    test_list = ['a', ['B', 1], 'c', 'd', 'e', 'f', ['G', {'1': 'G'}]]
    assert lenient

# Generated at 2022-06-20 16:29:37.912230
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1, isbits=True) == '8 bits'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1, unit='B') == '1 Bytes'
    assert bytes_to_human(1, unit='K') == '0.00 KB'
    assert bytes_to_human(1, unit='M') == '0.00 MB'
    assert bytes_to_human(1, unit='G') == '0.00 GB'
    assert bytes_to_human(1, unit='T') == '0.00 TB'
    assert bytes_to_human(1, unit='b') == '8 bits'
    assert bytes_to_human(1, isbits=True, unit='b') == '8 bits'
    assert bytes_to_human

# Generated at 2022-06-20 16:29:48.332976
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048576, isbits=True) == '1.00 Mb'
    assert bytes_to_human(1048576, unit='b') == '8.00 Mb'
    assert bytes_to_human(1048576, isbits=True, unit='K') == '10.00 Kb'
    assert bytes_to_human(1000) == '1000.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'

# Generated at 2022-06-20 16:29:55.331597
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('-1') == -1
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('-1M') == -1048576
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1M', isbits=True) == 1048576
    assert human_to_bytes('-1M', isbits=True) == -1048576
    assert human_to_bytes('1.0M', isbits=True) == 1048576
    assert human_to_bytes('1M', default_unit='B') == 1048576
    assert human_to_bytes('-1M', default_unit='B') == -1048576
    assert human_to_

# Generated at 2022-06-20 16:30:07.598312
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2M', default_unit='B') == 2 * 1024 * 1024
    assert human_to_bytes('2M') == 2 * 1024 * 1024
    assert human_to_bytes('2Mb') == 2 * 1024 * 1024
    assert human_to_bytes('2Mb', isbits=True) == 2 * 1024 * 1024
    assert human_to_bytes('2Mb', default_unit='b') == 2 * 1024 * 1024
    assert human_to_bytes('2M', default_unit='b') == 2 * 1000 * 1000

    assert human_to_bytes('2Mb', unit='b') == 2 * 1000 * 1000
    assert human_to_bytes('2Mb', unit='b', isbits=True) == 2 * 1024 * 1024

# Generated at 2022-06-20 16:30:21.385976
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_cases = [
        (["a", "A", "B", "c"], ["a", "a", "B", "c"]),
        (["a", 1, "b", "c"], ["a", 1, "b", "c"]),
    ]
    for param, expected in test_cases:
        result = lenient_lowercase(param)
        if result == expected:
            print("PASS")
        else:
            print("FAIL")
            print("input: {0}".format(param))
            print("expected: {0}".format(expected))
            print("output: {0}".format(result))


if __name__ == '__main__':
    test_lenient_lowercase()
    print(lenient_lowercase(["a", "A", "B", "c"]))

# Generated at 2022-06-20 16:30:32.857566
# Unit test for function bytes_to_human
def test_bytes_to_human():
    import sys
    import json
    import os

    # Store the original sys.stdout
    orig_stdout = sys.stdout

    # Pick one of the test .json files
    test_json = 'test_bytes_to_human.json'
    test_file = os.path.join(os.path.dirname(__file__), test_json)

    # Read the contents of the test file
    with open(test_file) as file_object:
        test_data = json.loads(file_object.read())

    # Check only the values of the test file
    for key, value in iteritems(test_data):
        real_value = bytes_to_human(size=key)

# Generated at 2022-06-20 16:30:44.779827
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10 * 1 << 20, "10M => %d (should be %d)" % (human_to_bytes('10M'), 10 * 1 << 20)
    assert human_to_bytes('10m') == 10 * 1 << 20, "10m => %d (should be %d)" % (human_to_bytes('10m'), 10 * 1 << 20)
    assert human_to_bytes(10, 'M') == 10 * 1 << 20, "10M => %d (should be %d)" % (human_to_bytes(10, 'M'), 10 * 1 << 20)
    assert human_to_bytes(100, 'B') == 100, "100B => %d (should be %d)" % (human_to_bytes(100, 'B'), 100)
    assert human_to_bytes

# Generated at 2022-06-20 16:30:56.323088
# Unit test for function bytes_to_human
def test_bytes_to_human():
    import pytest
    assert bytes_to_human(1) == "1.00 Bytes"
    assert bytes_to_human(42) == "42.00 Bytes"
    assert bytes_to_human(42, unit='B') == "42.00 Bytes"
    assert bytes_to_human(1000) == "1000.00 Bytes"
    assert bytes_to_human(1024) == "1.00 KBytes"
    assert bytes_to_human(1024 * 42) == "42.00 KBytes"
    assert bytes_to_human(1024**2) == "1.00 MBytes"
    assert bytes_to_human(1024**2 * 42) == "42.00 MBytes"
    assert bytes_to_human(1024**3) == "1.00 GBytes"

# Generated at 2022-06-20 16:31:07.944905
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("123") == 123
    assert human_to_bytes("123.") == 123
    assert human_to_bytes("1KB") == 1024
    assert human_to_bytes("1M") == 1048576
    assert human_to_bytes("1.5M") == 1572864
    assert human_to_bytes("1M", default_unit='b') == 1048576
    assert human_to_bytes("4M", default_unit='b') == 4194304
    assert human_to_bytes("1Mb") == 1048576
    assert human_to_bytes("4Mb", isbits=True) == 4194304
    assert human_to_bytes("4Kb") == 4096
    assert human_to_bytes("4Kb", isbits=True) == 4096
    assert human_to_bytes

# Generated at 2022-06-20 16:31:17.106430
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2M') == 20971520
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('50M') == 52428800
    assert human_to_bytes('5MB') == 5242880
    assert human_to_bytes('3Gb') == 33554432
    assert human_to_bytes('4GB') == 4194304
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('2b') == 2
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('5KB') == 5120
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('2bits') == 2
    assert human_to_bytes('2BYTES')

# Generated at 2022-06-20 16:31:20.613049
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['TEST1', 'test2', 'NoTest', 'nOtEsT']) == ['test1', 'test2', 'NoTest', 'nOtEsT']
    assert lenient_lowercase([123]) == [123]

# Unit tests for function human_to_bytes

# Generated at 2022-06-20 16:31:32.495018
# Unit test for function human_to_bytes
def test_human_to_bytes():
    for result, test_number in ((1048576, '1MB'), (1024, '1KB'), (1048576, '1Mb'), (1024, '1Kb'),
                                (1024, '1024'), (1024, '1024B'), (1, '1'), (1, '1B'),
                                (1024, '1024.'), (1024, '1024.0'), (1048576, '1M'), (1024, '1K'),
                                (1048576, '1M '), (1024, '1K ')):
        if human_to_bytes(test_number, isbits=False) != result:
            raise ValueError("test of human_to_bytes for %s failed. Expected %s, got %s" % (test_number, result, human_to_bytes(test_number, isbits=False)))



# Generated at 2022-06-20 16:31:35.115523
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', ['b', 'c'], {'d': 'e'}]) == ['a', ['b', 'c'], {'d': 'e'}]



# Generated at 2022-06-20 16:31:41.739835
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1, isbits=False) == "1.00 Bytes"
    assert bytes_to_human(1, isbits=True) == "1.00 bits"
    assert bytes_to_human(10, isbits=False) == "10.00 Bytes"
    assert bytes_to_human(10, isbits=True) == "10.00 bits"
    assert bytes_to_human(1024, isbits=False) == "1.00 KB"
    assert bytes_to_human(1024, isbits=True) == "8.00 Kbits"
    assert bytes_to_human(1024 * 1024, isbits=False) == "1.00 MB"
    assert bytes_to_human(1024 * 1024, isbits=True) == "8.00 Mbits"
    assert bytes_to_human

# Generated at 2022-06-20 16:31:57.031944
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['string', 'haS', 1, (1,), [1], {'1': 1}, None]
    lowered = lenient_lowercase(lst)
    assert isinstance(lowered, list)
    assert 'string' in lowered
    assert 'has' in lowered
    assert 1 in lowered
    assert (1,) in lowered
    assert [1] in lowered
    assert {'1': 1} in lowered
    assert None in lowered



# Generated at 2022-06-20 16:31:58.483132
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 10, 20]) == ['a', 'b', 10, 20]



# Generated at 2022-06-20 16:32:05.954496
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest
    from nose.tools import assert_raises

    def test_human_to_bytes_exception(expression, exception_message):
        with pytest.raises(ValueError) as err:
            human_to_bytes(expression)
        assert exception_message in str(err), "Expected exception '%s' not found in ValueError message: %s" % (exception_message, err)

    test_human_to_bytes_exception('', 'can\'t interpret following string')
    test_human_to_bytes_exception('test', 'can\'t interpret following string')

    test_human_to_bytes_exception('1.0', 'can\'t interpret following number')
    test_human_to_bytes_exception('1.0.0', 'can\'t interpret following number')
    test_

# Generated at 2022-06-20 16:32:13.178442
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Testing the human_to_bytes() function."""

    from nose.plugins.skip import SkipTest

    try:
        import requests
    except ImportError:
        raise SkipTest('Missing "requests" library needed for this test. Skipping.')


# Generated at 2022-06-20 16:32:20.785835
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # We want to make sure the function is idempotent
    # and that it respects non-strings
    assert lenient_lowercase(['Foo', 'Bar', 'Baz']) == ['foo', 'bar', 'baz']
    assert lenient_lowercase(['FOO', 'BAR', 'BAZ']) == ['foo', 'bar', 'baz']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]

# Unit tests for function human_to_bytes

# Generated at 2022-06-20 16:32:24.467223
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(15) == '15 Bytes'
    assert bytes_to_human(15, unit='K') == '15 KBytes'
    assert bytes_to_human(15, unit='K', isbits=True) == '15 Kbits'


# Generated at 2022-06-20 16:32:35.742509
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:32:47.909740
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1b', True) == 1
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1Kb', True) == 1024
    assert human_to_bytes('1MB') == 1024 * 1024
    assert human_to_bytes('1MB', True) == (1024 * 1024) * 8
    assert human_to_bytes('1T') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1T', True) == (1024 * 1024 * 1024 * 1024) * 8
    assert human_to_bytes('1K', default_unit='b') == 8
    assert human_to_bytes

# Generated at 2022-06-20 16:32:53.903822
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['ansible', 'is', 'awesome', 2, True] == lenient_lowercase(['Ansible', 'is', 'awesome', 2, True])
    assert ['ansible', 'is', 'awesome', '2', 'true'] == lenient_lowercase(['Ansible', 'is', 'awesome', '2', 'true'])



# Generated at 2022-06-20 16:33:02.122450
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("0") == 0
    assert human_to_bytes("0B") == 0
    assert human_to_bytes("0b") == 0
    assert human_to_bytes("0B", isbits=True) == 0
    assert human_to_bytes("1") == 1
    assert human_to_bytes("0.5") == 0
    assert human_to_bytes("0.5B") == 0
    assert human_to_bytes("0.5KB") == 512
    assert human_to_bytes("1B") == 1
    assert human_to_bytes("1b") == 1
    assert human_to_bytes("1KB") == 1024
    assert human_to_bytes("1KB", isbits=True) == 1024 * 8
    assert human_to_bytes("1.5KB") == 1536

# Generated at 2022-06-20 16:33:20.258661
# Unit test for function human_to_bytes
def test_human_to_bytes():
    cases = [
        ('10M', 10485760),
        ('20M', 20971520),
    ]

    for (text, result) in cases:
        assert human_to_bytes(text) == result


# Generated at 2022-06-20 16:33:22.269855
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['UPPER', 'Lower', 'CamelCase', 1]) == ['upper', 'lower', 'CamelCase', 1]


# Generated at 2022-06-20 16:33:27.876615
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10000) == '9.77 KB'
    assert bytes_to_human(100001221) == '95.37 MB'



# Generated at 2022-06-20 16:33:37.967114
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C', 'D', 10, 5, 4]) == ['a', 'b', 'c', 'd', 10, 5, 4]
    assert lenient_lowercase(['A', 'B', 'C', 'D', '10', '5', '4']) == ['a', 'b', 'c', 'd', '10', '5', '4']
    assert lenient_lowercase([1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-20 16:33:49.922061
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, isbits=True) == '10.00 bits'

    assert bytes_to_human(10, unit='b') == '10.00 bits'
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'

    assert bytes_to_human(10, unit='K') == '10.00 KB'
    assert bytes_to_human(10, unit='M') == '10.00 MB'
    assert bytes_to_human(10, unit='G') == '10.00 GB'
    assert bytes_to_human(10, unit='T') == '10.00 TB'

    assert bytes_to_human(10, unit='k') == '10.00 Kb'
   

# Generated at 2022-06-20 16:33:57.252292
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # checks unit determination
    assert 'byte' == human_to_bytes('100')[1]
    assert 'bit' == human_to_bytes('100', isbits=True)[1]
    assert 'Bytes' == human_to_bytes('100', unit='b')[1]
    assert 'bits' == human_to_bytes('100', isbits=True, unit='B')[1]

    # checks simple bytes convert
    assert 100 == human_to_bytes('100')[0]
    assert 100 == human_to_bytes('100', unit='B')[0]
    assert 100 == human_to_bytes('100b')[0]
    assert 100 == human_to_bytes('100 b')[0]
    assert 100 == human_to_bytes('100 B')[0]

    # checks simple bits convert
    assert 100

# Generated at 2022-06-20 16:34:07.632477
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_with_words = ['Hello', 'World', 'This', 'Is', 'A', 'String', 'With', 'Some', 'Uppercase', 'Letters']
    list_with_numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    list_letters_and_numbers = [1, 2, 3, 'A', 'B', 'C', 4, 5, 6]
    list_numbers_words_and_numbers = [1, 'ONE', 2, 'TWO', 3, 'THREE', 4, 'FOUR', 5, 'FIVE']

    assert lenient_lowercase(list_with_words) == ['hello', 'world', 'this', 'is', 'a', 'string', 'with', 'some', 'uppercase', 'letters']
    assert len

# Generated at 2022-06-20 16:34:13.692433
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['ABC', 'DEF', 'GEH', 1, 2, 3]) == ['abc', 'def', 'geh', 1, 2, 3]
    assert lenient_lowercase(['ABC', 'DE', 'G', 1, 2, 3]) == ['abc', 'de', 'g', 1, 2, 3]


# Generated at 2022-06-20 16:34:22.766800
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_cases = [
        ('1MB', 1048576),
        ('1.2KB', 1228.8),
        ('1.2MB', 1228800.0),
        ('1.2GB', 1288490188.8),
        ('1.2TB', 13194139533312.0),
        ('1.2PB', 1374389534720000000.0),
        ('1.2EB', 1.409495851816e+20),
        ('1.2ZB', 1.465818530599e+23),
        ('1.2YB', 1.528766598164e+26),
        ('1.2b', 1.2),
        ('1.2Kb', 1228.8),
    ]


# Generated at 2022-06-20 16:34:34.124709
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(42) == '42.00 Bytes'
    assert bytes_to_human(1234) == '1.23 KB'
    assert bytes_to_human(2 ** 20) == '1.00 MB'
    assert bytes_to_human(2 ** 20 + 2 ** 10) == '1.01 MB'
    assert bytes_to_human(2 ** 30) == '1.00 GB'
    assert bytes_to_human(2 ** 30 + 2 ** 20) == '1.01 GB'
    assert bytes_to_human(2 ** 30 + 2 ** 20 + 2 ** 10) == '1.01 GB'
    assert bytes_to_human(2 ** 40) == '1.00 TB'
    assert bytes_to_

# Generated at 2022-06-20 16:35:15.173673
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # check valid inputs
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('10M') == 10 * (1 << 20)
    assert human_to_bytes('20G') == 20 * (1 << 30)
    assert human_to_bytes('30T') == 30 * (1 << 40)
    assert human_to_bytes('40P') == 40 * (1 << 50)
    assert human_to_bytes('50E') == 50 * (1 << 60)
    assert human_to_bytes('10K') == 10 * (1 << 10)
    assert human_to_bytes('1MB') == 10 ** 6
    assert human_to_bytes('1.1M') == 1126400
    assert human_to_bytes('1.7M', default_unit='B') == 1802240
   

# Generated at 2022-06-20 16:35:26.149567
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # This should return 10.00 MBytes
    assert bytes_to_human(10485760) == '10.00 MBytes'
    # This should return 10.00 MBytes
    assert bytes_to_human(10000000) == '10.00 MBytes'
    # This should return 10.00 MB
    assert bytes_to_human(10000000, unit='M') == '10.00 MB'
    # This should return 10.00 Mbits
    assert bytes_to_human(10000000, isbits=True, unit='M') == '10.00 Mbits'
    # This should return 0.00 Bytes
    assert bytes_to_human(0) == '0.00 Bytes'
    # This should return 0.00 bits
    assert bytes_to_human(0, isbits=True) == '0.00 bits'

# Generated at 2022-06-20 16:35:36.169227
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024, False, 'B') == '1.00 Bytes'
    assert bytes_to_human(1024, True, 'b') == '1.00 bits'
    assert bytes_to_human(1024, False) == '1.00 KB'
    assert bytes_to_human(1024, True) == '1.00 Kb'
    assert bytes_to_human(1024, False, 'K') == '1.00 KB'
    assert bytes_to_human(1024, True, 'K') == '1.00 Kb'
    assert bytes_to_human(1024, False, 'M') == '0.00 MB'
    assert bytes_to_human(1024, True, 'M') == '0.00 Mb'

# Generated at 2022-06-20 16:35:45.697214
# Unit test for function human_to_bytes