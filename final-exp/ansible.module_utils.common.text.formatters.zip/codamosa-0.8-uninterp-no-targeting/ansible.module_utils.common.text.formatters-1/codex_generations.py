

# Generated at 2022-06-20 16:25:50.906907
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1]) == [1]
    assert lenient_lowercase(['abcd']) == ['abcd']
    assert lenient_lowercase(['AbCd']) == ['abcd']
    assert lenient_lowercase([1, 'abcd']) == [1, 'abcd']
    assert lenient_lowercase(['AbCd', 'efgh']) == ['abcd', 'efgh']
    assert lenient_lowercase(['AbCd', 'efgh', 'zYxW']) == ['abcd', 'efgh', 'zyxw']

# Generated at 2022-06-20 16:25:53.098418
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Foo', 'bar', 123]) == ['foo', 'bar', 123]



# Generated at 2022-06-20 16:26:02.055346
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('2K', 'B') == 2048
    assert human_to_bytes('25', 'K') == 25 * 1024
    assert human_to_bytes('3.5M') == int(3.5 * (1 << 20))
    assert human_to_bytes('2B') == 2
    assert human_to_bytes('2.5b', isbits=True) == int(2.5)
    assert human_to_bytes('1 MB') == 1 * (1 << 20)
    assert human_to_bytes(1) == 1
    assert human_to_bytes(2, 'K') == 2048
    assert human_to_bytes(3.5, 'M') == int(3.5 * (1 << 20))

# Generated at 2022-06-20 16:26:12.612579
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """
    This function tests human_to_bytes() function
    It uses different size formats
    """
    import re

    assert human_to_bytes('1M') == 1048576, 'Error in conversion'
    assert human_to_bytes('1Mb') == 1048576, 'Error in conversion'
    assert human_to_bytes('1MB') == 1048576, 'Error in conversion'
    assert human_to_bytes('1KB') == 1024, 'Error in conversion'
    assert human_to_bytes('1B') == 1, 'Error in conversion'
    assert human_to_bytes('1b') == 1, 'Error in conversion'
    assert human_to_bytes('1.1M') == 1153433, 'Error in conversion'

# Generated at 2022-06-20 16:26:20.497183
# Unit test for function bytes_to_human
def test_bytes_to_human():
    p = re.compile("^[\d+|\d+\.\d+] [KMGT]?[Bbit]$")
    assert p.match(bytes_to_human(5))
    assert p.match(bytes_to_human(3000000000))
    assert p.match(bytes_to_human(300000000000))
    assert p.match(bytes_to_human(300000000000000))
    assert p.match(bytes_to_human(300000000000000, unit='b'))

# Generated at 2022-06-20 16:26:27.495863
# Unit test for function human_to_bytes
def test_human_to_bytes():
    def test_human_to_bytes_case(name, test_value, expected_value, unit, isbits):
        try:
            assert human_to_bytes(test_value, unit, isbits) == expected_value
        finally:
            print('Test : %s Passed' % name)

    # Test cases - bytes conversion
    test_human_to_bytes_case('test_human_to_bytes_case 1', '10.5 Mb', 11010048.0, unit=None, isbits=False)
    test_human_to_bytes_case('test_human_to_bytes_case 2', 10, 10, unit=None, isbits=False)
    test_human_to_bytes_case('test_human_to_bytes_case 3', '10M', 10485760, unit=None, isbits=False)

# Generated at 2022-06-20 16:26:38.745493
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("Testing function human_to_bytes")

# Generated at 2022-06-20 16:26:47.551197
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_cases = [
        (['hello', 'world', 'bar', 'Baz'], ['hello', 'world', 'bar', 'Baz']),
        (['hello', 'world', 'bar', 'Baz', 1, 2, 3, 4], ['hello', 'world', 'bar', 'Baz', 1, 2, 3, 4])
    ]
    for test_case, expect in test_cases:
        result = lenient_lowercase(test_case)
        assert result == expect, "`lenient_lowercase` failed to lowercase string only: %s" % result


# Generated at 2022-06-20 16:26:58.515836
# Unit test for function bytes_to_human
def test_bytes_to_human():
    tests = [
        '0B',
        '1',
        '1b',
        '1.0B',
        '1.00b',
        '1K',
        '1KB',
        '1Kb',
        '1.5K',
        '1.5KB'
    ]

    results = [
        '0.00 Bytes',
        '1.00 Bytes',
        '1.00 bits',
        '1.00 Bytes',
        '1.00 bits',
        '1024.00 Bytes',
        '1024.00 Bytes',
        '1024.00 bits',
        '1024.00 Bytes',
        '1024.00 Bytes'
    ]


# Generated at 2022-06-20 16:27:10.426353
# Unit test for function bytes_to_human
def test_bytes_to_human():
    once_range = {
        'B': 1,
        'K': 1 << 10,
        'M': 1 << 20,
        'G': 1 << 30,
        'T': 1 << 40,
        'P': 1 << 50,
        'E': 1 << 60,
        'Z': 1 << 70,
        'Y': 1 << 80,
    }
    for suffix, limit in sorted(iteritems(once_range), key=lambda item: -item[1]):
        for size in (1, limit, int(limit * 1.2)):
            value = bytes_to_human(size)
            assert value == '%s B' % size, 'Expect to get %s from %s' % ('%s B' % size, value)

        size = int(limit * 1.6)
        value = bytes_

# Generated at 2022-06-20 16:27:19.933225
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        assert human_to_bytes('-1') == -1
    except Exception:
        raise AssertionError('Failed to convert -1 to bytes')

    try:
        assert human_to_bytes('1') == 1
    except Exception:
        raise AssertionError('Failed to convert 1 to bytes')

    try:
        assert human_to_bytes('1B') == 1
    except Exception:
        raise AssertionError('Failed to convert 1B to bytes')

    try:
        assert human_to_bytes('2') == 2
    except Exception:
        raise AssertionError('Failed to convert 2 to bytes')

    try:
        assert human_to_bytes('100') == 100
    except Exception:
        raise AssertionError('Failed to convert 100 to bytes')


# Generated at 2022-06-20 16:27:26.377171
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10 * 1024 * 1024
    assert human_to_bytes('10Mb') == 10 * 1024 * 1024 * 8
    assert human_to_bytes('10MB') == 10 * 1024 * 1024
    assert human_to_bytes('10MB', isbits=True) == 10 * 1024 * 1024 * 8
    assert human_to_bytes('10b') == 1
    assert human_to_bytes('10b', isbits=True) == 10
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10B', default_unit='b') == 10 * 8
    assert human_to_bytes('10B', default_unit='k') == 10 * 1024

# Generated at 2022-06-20 16:27:31.081579
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input = [1, "a", "A", "b", "B", "C"]
    result = lenient_lowercase(input)
    assert all(i == j for i, j in zip([1, "a", "a", "b", "b", "c"], result))
    assert result[0] == 1


# Generated at 2022-06-20 16:27:35.818379
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    value = ['A', 'B', 'C', 1, 2, 3, None]
    expected = ['a', 'b', 'c', 1, 2, 3, None]
    value_lower = lenient_lowercase(value)
    assert value_lower == expected, "Failed to convert list elements to lowercase"


# Generated at 2022-06-20 16:27:46.265526
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(0.9) == '0.90 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1.9) == '1.90 Bytes'
    assert bytes_to_human(1023) == '1023.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(104857600) == '100.00 MB'
    assert bytes_to_human(1048576000) == '1000.00 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'

# Generated at 2022-06-20 16:27:52.725556
# Unit test for function bytes_to_human
def test_bytes_to_human():
    inputs = [
        0,
        1,
        1000,
        1025,
        1024 * 1024,
        1024 * 1024 * 1024,
        0xFFFFFFFFF,
        0xFFFFFFFFFF,
        0xFFFFFFFFFFF,
        0xFFFFFFFFFFFF,
        0xFFFFFFFFFFFFF,
        0xFFFFFFFFFFFFFF,
        0xFFFFFFFFFFFFFFF,
        0xFFFFFFFFFFFFFFFF,
        0xFFFFFFFFFFFFFFFFF,
    ]

# Generated at 2022-06-20 16:27:57.072410
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    input = ['abc', '', 'ABC', ['moo'], {'a': 'b'}, None]
    expected_result = ['abc', '', 'abc', ['moo'], {'a': 'b'}, None]

    actual_result = lenient_lowercase(input)
    assert actual_result == expected_result

# Generated at 2022-06-20 16:28:06.506532
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(100, unit='k') == '0.10 KBytes'
    assert bytes_to_human(100, unit='b') == '0.01 Kbits'
    assert bytes_to_human(100) == '100.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 2, unit='b') == '16.00 Gbits'
    assert bytes_to_human(1024 * 1024 * 1024 * 2, unit='b') == '16.00 Gbits'
    assert bytes_to_human(2, isbits=True) == '2.00 bits'



# Generated at 2022-06-20 16:28:18.241198
# Unit test for function human_to_bytes
def test_human_to_bytes():
    bad_values = ['', 'M', 'KM', 'b']

# Generated at 2022-06-20 16:28:29.365988
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2097152
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('5G') == 5368709120
    assert human_to_bytes('1T') == 1099511627776

    assert human_to_bytes('2k') == 2097152
    assert human_to_bytes('10m') == 10485760
    assert human_to_bytes('5g') == 5368709120
    assert human_to_bytes('1t') == 1099511627776

    assert human_to_bytes('3K') == 3145728
    assert human_to_bytes('2M') == 20971520
    assert human_to_bytes('4G') == 4294967296
    assert human_to_bytes('7T') == 75

# Generated at 2022-06-20 16:28:45.141684
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:28:57.091407
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human(1073741824, unit='g') == '1.00 GB'
    assert bytes_to_human(1073741824, unit='G') == '1.00 GB'
    assert bytes_to_human(1073741824, unit='Gb') == '1073741824.00 Gb'
    assert bytes_to_human(1073741824, unit='GB') == '1073741824.00 GB'

    assert bytes_to_human(1073741824, isbits=True) == '1073741824.00 Gb'
    assert bytes_to_human(1073741824, isbits=True, unit='g') == '1073741824.00 Gb'
    assert bytes_to_human

# Generated at 2022-06-20 16:29:06.540886
# Unit test for function bytes_to_human
def test_bytes_to_human():
    from ansible.module_utils.basic import AnsibleModule

    expect_B = [('0b', '0.00 Bytes'), ('1', '1.00 Bytes'), ('100', '100.00 Bytes'), ('10K', '10240.00 Bytes'),
                ('1024K', '1048576.00 Bytes'), ('1024M', '1048576000.00 Bytes'), ('1024G', '1048576000000.00 Bytes')]

    expect_b = [('0b', '0.00 bits'), ('1', '8.00 bits'), ('1024', '8192.00 bits'), ('10K', '81920.00 bits'),
                ('1024K', '8388608.00 bits'), ('1024M', '8388608000.00 bits'), ('1024G', '8388608000000.00 bits')]


# Generated at 2022-06-20 16:29:09.283289
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['DIGITAL', 'OCEAN', 'is', 'AWESOME', 1234, '!']) == ['digital', 'ocean', 'is', 'awesome', 1234, '!']

# Generated at 2022-06-20 16:29:22.189948
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1000) == '1000 Bytes'
    assert bytes_to_human(1000000) == '1.00 MB'
    assert bytes_to_human(1000000000) == '1.00 GB'
    assert bytes_to_human(1000000000000) == '1.00 TB'
    assert bytes_to_human(1000000000000000) == '1.00 PB'
    assert bytes_to_human(1000000000000000000) == '1.00 EB'
    assert bytes_to_human(1000000000000000000000) == '1.00 ZB'
    assert bytes_to_human(1000000000000000000000000) == '1.00 YB'
    assert bytes_to_human(1000000000000000000000000000) == '1000.00 YB'

# Generated at 2022-06-20 16:29:29.923755
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test bytes to bytes
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1kB') == 1024
    assert human_to_bytes('2.5Kb') == 2560
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('2.5MB') == 262144000
    assert human_to_bytes('2.5Mb') == 2621440
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1gB') == 1073741824
    assert human_to_bytes('2.5Gb') == 274877906944
    assert human_to_bytes('2.5gb') == 274877906944

# Generated at 2022-06-20 16:29:40.213252
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test isbits=True
    assert(human_to_bytes('1b') == 1)  # 1 bit
    assert(human_to_bytes('1bit') == 1)  # 1 bit
    assert(human_to_bytes('1B') == 8)  # 1 byte in bits
    assert(human_to_bytes('1byte') == 8)  # 1 byte in bits
    assert(human_to_bytes('1b', isbits=True) == 1)  # 1 bit
    assert(human_to_bytes('1bit', isbits=True) == 1)  # 1 bit
    assert(human_to_bytes('1B', isbits=True) == 8)  # 1 byte in bits
    assert(human_to_bytes('1byte', isbits=True) == 8)  # 1 byte in bits

# Generated at 2022-06-20 16:29:43.205974
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['ABC', 1, 'Xyz', (1, 2)]) == ['abc', 1, 'xyz', (1, 2)]

# Generated at 2022-06-20 16:29:49.639258
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['testString', 'test']) == ['teststring', 'test']
    assert lenient_lowercase([1, 'test']) == [1, 'test']
    assert lenient_lowercase(['B', 'test']) == ['B', 'test']
    assert lenient_lowercase([2, 4, 7]) == [2, 4, 7]
    assert lenient_lowercase(['b', 'p']) == ['b', 'p']


# Generated at 2022-06-20 16:29:56.641674
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """Test cases for bytes_to_human function."""
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(100) == '100.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(10000) == '9.77 KB'
    assert bytes_to_human(100001221) == '95.37 MB'
    assert bytes_to_human(unit='M', size=100001221) == '9.54 MB'
    assert bytes_to_human(size=60000000, unit='b') == '60.00 Mbits'
    assert bytes_to_human(size=60000, isbits=True) == '60.00 Kbits'

# Generated at 2022-06-20 16:30:08.395619
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['1', '2', '3'] == lenient_lowercase(['1', '2', '3'])
    assert ['1', 2, '3'] == lenient_lowercase(['1', 2, '3'])
    assert ['1', '2', '3'] == lenient_lowercase(['1', '2', '3'])
    assert ['1', 2, '3'] == lenient_lowercase(['1', 2, '3'])


# Unit tests for function human_to_bytes

# Generated at 2022-06-20 16:30:12.408291
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Hello', 'WORLD', 1, 2, '1']) == ['hello', 'WORLD', 1, 2, '1']


# Generated at 2022-06-20 16:30:21.749154
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1024B') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1GB') == 1073741824

    assert human_to_bytes('1024', 'KB') == 1048576
    assert human_to_bytes('1024', 'MB') == 1048576
    assert human_to_bytes('1KB', 'KB') == 1024
    assert human_to_bytes('1KB', 'MB') == 1024
    assert human_to_bytes('1MB', 'MB') == 1048576

    assert human_to_bytes('1024K', 'KB') == 1024
    assert human_to_bytes('1024K', 'MB') == 1048576



# Generated at 2022-06-20 16:30:27.195931
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list1 = ['1', 2, 3, [1, 2, 3, 'aBc'], (1, 2, 'aBC')]
    list2 = ['1', 2, 3, [1, 2, 3, 'abc'], (1, 2, 'abc')]

    assert lenient_lowercase(list1) == list2


# Generated at 2022-06-20 16:30:36.319402
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Running unit test for function human_to_bytes
    '''
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1KB', isbits=True) == 8192
    assert human_to_bytes('1KB', unit='B') == 1024
    assert human_to_bytes('1KB', unit='b') == 8192
    assert human_to_bytes('1KB', unit='KB') == 1024
    assert human_to_bytes('1KB', isbits=True, unit='KB') == 8192
    assert human_to_bytes('1KB', isbits=True, unit='b') == 8192

# Generated at 2022-06-20 16:30:45.957837
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        human_to_bytes("10")
    except ValueError:
        pass
    else:
        raise Exception("ValueError is not raised.")

    assert human_to_bytes("1B") == 1
    assert human_to_bytes("10B") == 10
    assert human_to_bytes("1KB") == 1024
    assert human_to_bytes("10KB") == 10 * 1024
    assert human_to_bytes("1MB") == 2 ** 20
    assert human_to_bytes("1Mb") == 2 ** 20
    assert human_to_bytes("2.5MB") == 2.5 * 2 ** 20
    assert human_to_bytes("1.5GB") == 1.5 * 2 ** 30
    assert human_to_bytes("1.5Gb") == 1.5 * 2 ** 30
    assert human_

# Generated at 2022-06-20 16:30:57.137685
# Unit test for function bytes_to_human
def test_bytes_to_human():
    testCases = {0: '0.00 Bytes',
                 1: '1.00 Bytes',
                 1024: '1.00 KB',
                 1048576: '1.00 MB',
                 1073741824: '1.00 GB',
                 1099511627776: '1.00 TB',
                 1125899906842624: '1.00 PB',
                 1152921504606846976: '1.00 EB',
                 1180591620717411303424: '1.00 ZB',
                 1208925819614629174706176: '1.00 YB',
                 }

    for num, result in testCases.items():
        print(result, ": ", bytes_to_human(num))
        assert bytes_to_human(num) == result


# Generated at 2022-06-20 16:31:08.835818
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:31:15.467357
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Test human_to_bytes with various values
    """
    assert human_to_bytes('15') == 15
    assert human_to_bytes('15M') == 157286400  # = 15 * 1024 * 1024
    assert human_to_bytes('15MB') == 157286400  # = 15 * 1024 * 1024
    assert human_to_bytes('15.5M') == 16252928.0  # = (15.5 * 1024 * 1024)/1
    assert human_to_bytes('15.5MB') == 16252928.0  # = (15.5 * 1024 * 1024)/1
    assert human_to_bytes('15B') == 15
    assert human_to_bytes('15KB') == 15360  # = 15 * 1024
    assert human_to_bytes('15KiB') == 157286400

# Generated at 2022-06-20 16:31:16.545602
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 1, 'B', 3]) == ['a', 1, 'b', 3]

# Generated at 2022-06-20 16:31:34.154482
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048576, unit='M') == '1024.00 MB'
    assert bytes_to_human(1048576, unit='Mb') == '1048576.00 Mb'
    assert bytes_to_human(1048576, unit='bit') == '8388608.00 bits'
    assert bytes_to_human(1048576, unit='b') == '8388608.00 b'
    assert bytes_to_human(1048576, isbits=True) == '8388608.00 bits'
    assert bytes_to_human(1048576, isbits=True, unit='M') == '8388608.00 Mbits'

# Generated at 2022-06-20 16:31:41.169399
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B', isbits=False) == 1
    assert human_to_bytes('4KB', isbits=False) == 4096
    assert human_to_bytes('5MB', isbits=False) == 5242880
    assert human_to_bytes('6GB', isbits=False) == 6442450944
    assert human_to_bytes('7TB', isbits=False) == 74505805984
    assert human_to_bytes('8PB', isbits=False) == 858993458816
    assert human_to_bytes('9EB', isbits=False) == 9713032379904
    assert human_to_bytes('10ZB', isbits=False) == 10737418240000000
    assert human_to_bytes('11YB', isbits=False) == 118059

# Generated at 2022-06-20 16:31:43.099736
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['foo', 1, 1.0] == lenient_lowercase(['foo', 1, 1.0])



# Generated at 2022-06-20 16:31:54.114544
# Unit test for function bytes_to_human
def test_bytes_to_human():
    results = dict(
        y=1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024,
        z=1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024,
        e=1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024,
        p=1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024,
        t=1024 * 1024 * 1024 * 1024 * 1024,
        g=1024 * 1024 * 1024,
        m=1024 * 1024,
        k=1024,
        b=1,
    )
    # Test bytes
    for key, value in iteritems(results):
        assert bytes_to_human(value) == '1.00 Bytes'
        assert bytes_to_human(value, unit=key.upper()) == '1.00 Bytes'

   

# Generated at 2022-06-20 16:32:02.609824
# Unit test for function bytes_to_human
def test_bytes_to_human():
    test_dict = {
        'B': 1,
        'Kb': 1048576,
        'Mb': 1073741824,
        'Gb': 1099511627776,
        'Tb': 1125899906842624
    }

    for unit in test_dict:
        assert bytes_to_human(test_dict[unit], unit=unit) == '1.00 %s' % unit

    test_dict = {
        'B': 1,
        'K': 1048576,
        'M': 1073741824,
        'G': 1099511627776,
        'T': 1125899906842624
    }

    for unit in test_dict:
        assert bytes_to_human(test_dict[unit], unit=unit) == '1.00 %sBytes' % unit

   

# Generated at 2022-06-20 16:32:11.425938
# Unit test for function bytes_to_human
def test_bytes_to_human():

    result = bytes_to_human(0)
    assert result ==  "0 Bytes"

    result = bytes_to_human(1)
    assert result ==  "1 Bytes"

    result = bytes_to_human(1,isbits=True)
    assert result == "1 bits"

    result = bytes_to_human(1024)
    assert result ==  "1.00 KB"

    result = bytes_to_human(1024,isbits=True)
    assert result ==  "1.00 Kb"

    result = bytes_to_human(1024,isbits=True,unit="b")
    assert result ==  "1.00 b"

    result = bytes_to_human(1024,isbits=True,unit="k")
    assert result ==  "1.00 Kb"

    result = bytes_to

# Generated at 2022-06-20 16:32:22.666423
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    tests = [
        # Input list, expected output list
        (None, []),
        ([], []),
        (['a'], ['a']),
        (['A'], ['a']),
        ([1], [1]),
        (['a', 'b'], ['a', 'b']),
        (['A', 'b'], ['a', 'b']),
        (['a', 'B'], ['a', 'b']),
        (['A', 'B'], ['a', 'b']),
        (['a', 2], ['a', 2]),
        (['A', 2], ['a', 2]),
    ]
    for test, expected in tests:
        actual = lenient_lowercase(test)

# Generated at 2022-06-20 16:32:25.387833
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ["string.lower()", "FOOBAR", None] == lenient_lowercase(["string.lower()", "FOOBAR", None])

# Unit tests for function human_to_bytes

# Generated at 2022-06-20 16:32:36.009938
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """Unit test for function bytes_to_human"""

    class _Exception(Exception):
        pass

    if human_to_bytes('1MB') < 1048575:
        raise _Exception('Error: Not a valid value')

    if human_to_bytes('1048575B') < 1048575:
        raise _Exception('Error: Not a valid value')

    if human_to_bytes('1048575 bytes') < 1048575:
        raise _Exception('Error: Not a valid value')

    if human_to_bytes('1024 KB') != 1048576:
        raise _Exception('Error: Not a valid value')

    if human_to_bytes('1024kB') != 1048576:
        raise _Exception('Error: Not a valid value')


# Generated at 2022-06-20 16:32:43.691435
# Unit test for function bytes_to_human
def test_bytes_to_human():
    for metric in ['bit', 'byte']:
        for unit in ['', 'B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']:
            for size in [0, 1, 100, 200, 1000, 3000, 5000, 10000, 100000, 114645, 1000000, 1000000000]:
                assert bytes_to_human(size, isbits=(metric == 'bit'), unit=unit) == '%s %s' % (size, metric)


# Generated at 2022-06-20 16:33:00.695496
# Unit test for function human_to_bytes
def test_human_to_bytes():
    conversion_score = 0

    # Help in tracking test performance
    def assert_eq(expected_value, value, format_string, *args):
        global conversion_score
        if expected_value == value:
            conversion_score += 1
            print(" OK ", format_string % args)
        else:
            print("FAIL", format_string % args, "got", value, "instead of", expected_value)

    assert_eq(1234, human_to_bytes("1234", 'B'), "Conversion with explicit unit should work")
    assert_eq(1234, human_to_bytes("1234", 'mB'), "Conversion with ambiguous unit should work")
    assert_eq(1234, human_to_bytes("1234"), "Conversion without unit should work")


# Generated at 2022-06-20 16:33:05.861630
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list1 = ['a', 'B', 'c', 1, 2, 3]
    list1_result = lenient_lowercase(list1)
    print("The list is: %s" % list1)
    print("The result of lowercasing is: %s" % list1_result)
    assert list1_result == ['a', 'b', 'c', 1, 2, 3]

# Generated at 2022-06-20 16:33:13.015365
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """ Unit tests for human_to_bytes() function. """
    print('Testing human_to_bytes()')

    # pylint: disable=line-too-long

# Generated at 2022-06-20 16:33:16.076450
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Test the lenient_lowercase function."""
    lst = ['foo', 'BAR']
    lst_lowered = ['foo', 'bar']
    assert lenient_lowercase(lst) == lst_lowered


# Unit tests for function human_to_bytes

# Generated at 2022-06-20 16:33:19.570096
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(('a', 'b', 'c')) == ['a', 'b', 'c']
    assert lenient_lowercase(('A', 'B', 'C')) == ['a', 'b', 'c']
    assert lenient_lowercase(('A', 'B', 'C', 0)) == ['a', 'b', 'c', 0]


# Generated at 2022-06-20 16:33:26.340840
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test valid values
    assert human_to_bytes('1') == 1, 'test_human_to_bytes: failed to convert "1"'
    assert human_to_bytes('1.0') == 1, 'test_human_to_bytes: failed to convert "1.0"'
    assert human_to_bytes('1.5') == 1, 'test_human_to_bytes: failed to convert "1.5"'
    assert human_to_bytes('1Y') == 1 << 80, 'test_human_to_bytes: failed to convert "1Y" (ie: "1.2089258196146292e+24")'
    assert human_to_bytes('1.5Y') == 1 << 80, 'test_human_to_bytes: failed to convert "1.5Y"'

# Generated at 2022-06-20 16:33:36.118453
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Testcase: lower-case strings
    test_in = ['foo', 'bar']
    expected = ['foo', 'bar']
    test = lenient_lowercase(test_in)
    assert test == expected

    # Testcase: lower-case and upper-case strings
    test_in = ['foo', 'bar', 'BAZ']
    expected = ['foo', 'bar', 'baz']
    test = lenient_lowercase(test_in)
    assert test == expected

    # Testcase: non-string types
    test_in = ['foo', 'bar', 42]
    expected = ['foo', 'bar', 42]
    test = lenient_lowercase(test_in)
    assert test == expected

    return True



# Generated at 2022-06-20 16:33:48.089868
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1023) == "1023.00 Bytes"
    assert bytes_to_human(1024 * 1024) == "1.00 MB"
    assert bytes_to_human(1024 * 1024 * 1024) == "1.00 GB"
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == "1.00 TB"
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == "1.00 PB"
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == "1.00 EB"

    assert bytes_to_human(1024, isbits=True) == "8.00 Kb"
    assert bytes_to_human(1023, isbits=True)

# Generated at 2022-06-20 16:33:51.114882
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    original = [1, 'two', 'ThRee', 4, u'FIVE', 6, 7, 'eight9']
    expected = [1, 'two', 'ThRee', 4, u'FIVE', 6, 7, 'eight9']
    actual = lenient_lowercase(original)

    assert actual == expected


# Generated at 2022-06-20 16:33:57.107497
# Unit test for function human_to_bytes
def test_human_to_bytes():
    success = True

# Generated at 2022-06-20 16:34:15.523374
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Run unit tests for function human_to_bytes"""
    # test bit to bytes
    assert human_to_bytes('10b') == 1
    assert human_to_bytes('10B') == 1
    assert human_to_bytes('10Mb') == 12582912
    #test bytes to bytes
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10Mb') == 12582912
    assert human_to_bytes('10MB') == 10485760
    #test bits to bits
    assert human_to_bytes('10B', isbits=True) == 80
    assert human_to_bytes('10b', isbits=True) == 10
    assert human_to_bytes('10Mb', isbits=True)

# Generated at 2022-06-20 16:34:19.541872
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576,'bytes') == '1.00 MB'
    assert bytes_to_human(1048576,'bits') == '1.00 Mb'
    assert bytes_to_human(1048576,'bits',unit='bit') == '1048576.00 bits'

# Generated at 2022-06-20 16:34:28.407442
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    l = [1, "a", "B", "c"]
    assert (lenient_lowercase(l) == [1, "a", "B", "c"])
    l = ["a", "B", "c", 1]
    assert (lenient_lowercase(l) == ["a", "B", "c", 1])
    l = ["a", "B", "c", 1, {"a": "A"}]
    assert (lenient_lowercase(l) == ["a", "B", "c", 1, {"a": "A"}])



# Generated at 2022-06-20 16:34:37.470234
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(2048, isbits=True) == '16.00 Kb'
    assert bytes_to_human(2048, isbits=True, unit='b') == '2.00 Kb'
    assert bytes_to_human(2048, isbits=True, unit='B') == '32.00 Kb'
    assert bytes_to_human(2048, unit='M') == '0.00 MB'
    assert bytes_to_human(2048, unit='b') == '2.00 Kbits'
    assert bytes_to_human(2048, unit='B') == '16.00 Kbits'
    assert bytes_to_human(2048, unit='m') == '0.00 mBytes'

# Generated at 2022-06-20 16:34:48.124077
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == "1.00 Bytes"
    assert bytes_to_human(1, unit="B") == "1.00 Bytes"
    assert bytes_to_human(1, unit="b") == "1.00 bits"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1024 * 1024) == "1.00 MB"
    assert bytes_to_human(1024 * 1024 * 1024) == "1.00 GB"
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == "1.00 TB"
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == "1.00 PB"

# Generated at 2022-06-20 16:34:59.389238
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(10, unit='K') == '0.01 KB'
    assert bytes_to_human(10, unit='k') == '0.01 KB'
    assert bytes_to_human(10, unit='B') == '10 Bytes'
    assert bytes_to_human(10, unit='b') == '0.08 bits'
    assert bytes_to_human(10, isbits=True) == '0.08 bits'
    assert bytes_to_human(10, isbits=True, unit='B') == '80 bits'
    assert bytes_to_human(10, isbits=True, unit='b') == '0.08 bits'

# Generated at 2022-06-20 16:35:10.244241
# Unit test for function human_to_bytes
def test_human_to_bytes():
    raw_input = '1.5MB'
    expected = 1572864

    result = human_to_bytes(raw_input)
    assert result == expected, 'Expected: %s, result: %s' % (expected, result)

    raw_input = 10
    expected = 10
    default_unit = 'G'
    result = human_to_bytes(raw_input, default_unit=default_unit)
    assert result == expected, 'Expected: %s, result: %s' % (expected, result)

    raw_input = '1.5Gb'
    expected = 1572864
    isbits = True
    result = human_to_bytes(raw_input, isbits=isbits)
    assert result == expected, 'Expected: %s, result: %s' % (expected, result)

    raw_

# Generated at 2022-06-20 16:35:14.815550
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'foo', 'BaR']) == [1, 'foo', 'BaR']
    assert lenient_lowercase([1, 'foo', 'BaR', 'bar', 'Bazz']) == [1, 'foo', 'BaR', 'bar', 'Bazz']
    assert lenient_lowercase(['Bar', 'Bar', 'Bar']) == ['Bar', 'Bar', 'Bar']

# Generated at 2022-06-20 16:35:25.731764
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1.5

    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1b', isbits=True) == 1

    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1KBb', isbits=True) == 1024

    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1mb', isbits=True) == 1048576
    assert human_to_bytes('1mB', isbits=True) == 1048576


# Generated at 2022-06-20 16:35:35.580960
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("Unit test for human_to_bytes...")
    data = [
        ('2.5K', [256000, 2560, 25600, 2.56]),
        ('3m', [3e+6, 3000000, 300000, 3]),
        ('2', [2, 2.0, 2.0, 2.0]),
        ('2.5', [2.5, 2.5, 2.5, 2.5])
    ]
    for test_input, expected_output in data:
        bytes_output = human_to_bytes(test_input)
        print("input: %s  ->  output: %s  expected output: %s" % (test_input, bytes_output, expected_output))
        assert bytes_output in expected_output

