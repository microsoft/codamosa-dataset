

# Generated at 2022-06-20 16:25:52.809603
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(['Data', 'Data', 1, 'Data', 'Data'])
    assert result == ['data', 'data', 1, 'data', 'data']

    result = lenient_lowercase(['Data'])
    assert result == ['data']

    result = lenient_lowercase([1, 1, 1, 1, 1, 1])
    assert result == [1, 1, 1, 1, 1, 1]

# Generated at 2022-06-20 16:26:01.831664
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(164926744, isbits=False) == '156.00 MBytes'
    assert bytes_to_human(164926744, isbits=True) == '141.00 Mbits'
    assert bytes_to_human(145084288, isbits=False, unit='B') == '1382976.00 Bytes'
    assert bytes_to_human(145084288, isbits=False, unit='b') == '1382976.00 Bytes'
    assert bytes_to_human(145084288, isbits=True, unit='B') == '1382976.00 Bytes'
    assert bytes_to_human(145084288, isbits=True, unit='b') == '1382976.00 Bytes'

# Generated at 2022-06-20 16:26:12.336569
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 EB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 ZB'

    # Unit test for bits
    assert bytes_

# Generated at 2022-06-20 16:26:19.818331
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_data = [
        ('FooBar', ('foobar',)),
        ('FooBar', ('FOOBAR',)),
        ('FooBar', ('FooBar',)),
        ('foobar', ('foobar',)),
        ('foobar', ('FOOBAR',)),
        ('foobar', ('FooBar',)),
        ('FOOBAR', ('foobar',)),
        ('FOOBAR', ('FOOBAR',)),
        ('FOOBAR', ('FooBar',)),
        (1, (1,)),
        (0.0, (0.0,)),
        (None, (None,)),
        ([], ([],)),
        ({}, ({},)),
        (set(), (set(),)),
    ]


# Generated at 2022-06-20 16:26:23.328890
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['ABC']) == ['abc']
    assert lenient_lowercase(['ABC', 1, 'DEF']) == ['abc', 1, 'def']


# Generated at 2022-06-20 16:26:27.925629
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test 1
    try:
        result = human_to_bytes('1024')
        assert(result == 1024)
        result = human_to_bytes('1K')
        assert(result == 1024)
        result = human_to_bytes('1 KB')
        assert(result == 1024)
        result = human_to_bytes('1KB')
        assert(result == 1024)
    except ValueError as e:
        print('Error: ' + str(e))
        raise AssertionError('Test 1 (basic test) failed')
    print('Test 1 passed')

    # test 2

# Generated at 2022-06-20 16:26:30.866665
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['UPPERCASE', 'LowerCase', 'Mixed', 1, 2, 3]) == ['uppercase', 'lowercase', 'mixed', 1, 2, 3]


# Generated at 2022-06-20 16:26:41.959110
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Unit test for human_to_bytes '''

# Generated at 2022-06-20 16:26:54.600314
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # check bytes
    assert bytes_to_human(1048576, unit='B') == '1.00 MBytes'
    assert bytes_to_human(1048576, unit='bytes') == '1.00 MBytes'
    assert bytes_to_human(1048576, unit='Mbytes') == '1.00 MBytes'
    assert bytes_to_human(1048576, unit='MBytes') == '1.00 MBytes'
    # check bits
    assert bytes_to_human(1048576, unit='b') == '8.00 Mbits'
    assert bytes_to_human(1048576, unit='bits') == '8.00 Mbits'
    assert bytes_to_human(1048576, unit='Mbits') == '8.00 Mbits'

# Generated at 2022-06-20 16:27:02.080007
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    print('test for function lenient_lowercase')

    # Test case 1
    # Input: input_list = ['a', 'b', 'C', 1, 2]
    # Expected result: ['a', 'b', 'C', 1, 2]
    input_list = ['a', 'b', 'C', 1, 2]
    result = lenient_lowercase(input_list)
    assert result == ['a', 'b', 'C', 1, 2], 'Unexpected result'
    print('1) Test case 1 passed.')

    # Test case 2
    # Input: input_list = ['A', 'b', 'c', 1, 2]
    # Expected result: ['a', 'b', 'c', 1, 2]
    input_list = ['A', 'b', 'c', 1, 2]

# Generated at 2022-06-20 16:27:08.106707
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_data = ['TEST', [1, 2, 3], {1: 'one', 2: 'two'}, None]
    expected_result = ['test', [1, 2, 3], {1: 'one', 2: 'two'}, None]
    assert(lenient_lowercase(test_data) == expected_result)

# Generated at 2022-06-20 16:27:13.843682
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1, unit='b') == '8.00 bits'
    assert bytes_to_human(1, unit=None) == '1.00 Bytes'
    assert bytes_to_human(8, unit='b') == '1.00 bits'
    assert bytes_to_human(1024, unit='K') == '1.00 KB'
    assert bytes_to_human(100 * 1024, unit='K') == '100.00 KB'
    assert bytes_to_human(1 * 1024 * 1024, unit='M') == '1.00 MB'
    assert bytes_to_human(1 * 1024 * 1024 * 1024, unit='G') == '1.00 GB'
    assert bytes_to_human(1 * 1024 * 1024 * 1024 * 1024, unit='T') == '1.00 TB'

# Generated at 2022-06-20 16:27:24.056890
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KB'
    
    # Testing number coming with different precision
    assert bytes_to_human(1025) == '1.00 KB'
    assert bytes_to_human(1023) == '1.00 KB'
    assert bytes_to_human(1034) == '1.01 KB'
    assert bytes_to_human(1024, unit='B') == '1024.00 B'
    assert bytes_to_human(1024, unit='Kb') == '8192.00 Kb'
    assert bytes_to_human(1025, unit='Kb') == '8192.00 Kb'
    assert bytes_to_human(1023, unit='Kb') == '8192.00 Kb'

# Generated at 2022-06-20 16:27:34.091212
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest
    # check correct convertion when unit is given
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1 KB') == 1024

    # check correct convertion when multiple spaces are used
    assert human_to_bytes('1     KB') == 1024
    assert human_to_bytes('1 KB    ') == 1024
    assert human_to_bytes('1  KB   ') == 1024

    # check correct convertion when unit is given and a size number is fractional
    assert human_to_bytes('1.5KB') == 1536
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5 KB') == 1536

    # check correct convertion when unit is given and a

# Generated at 2022-06-20 16:27:44.650528
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
    assert lenient_lowercase(['a', 'b', 'C', 'd']) == ['a', 'b', 'C', 'd']
    assert lenient_lowercase(['A', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
    assert lenient_lowercase(['A', 'b', 'C', 'd']) == ['a', 'b', 'C', 'd']
    assert lenient_lowercase(['a', 'b', 'c', 'd', 1]) == ['a', 'b', 'c', 'd', 1]

# Generated at 2022-06-20 16:27:48.403751
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['A', 'B']) == ['a', 'b'])
    assert(lenient_lowercase([3, 'B']) == [3, 'b'])

# Generated at 2022-06-20 16:27:58.586525
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes(1) == 1
    assert human_to_bytes(1.0) == 1
    assert human_to_bytes('2M') == 2 * 1024 ** 2
    assert human_to_bytes(2, 'M') == 2 * 1024 ** 2
    assert human_to_bytes('2.5M') == int(2.5 * 1024 ** 2)
    assert human_to_bytes(2.5, 'M') == int(2.5 * 1024 ** 2)
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1

    assert human_to_bytes('1Mb') == int(1 * 1024 ** 2)

# Generated at 2022-06-20 16:28:08.706683
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1023) == '1023.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KBytes'
    assert bytes_to_human(2 * 1024 * 1024) == '2.00 MBytes'
    assert bytes_to_human(2 * 1024 * 1024, unit='M') == '2.00 MBytes'
    assert bytes_to_human(2 * 1024 * 1024, unit='K') == '2048.00 KBytes'
    assert bytes_to_human(2 * 1024 * 1024, unit='B') == '2.00 MBytes'
    assert bytes_to_human(2 * 1024 * 1024, unit='b') == '2.00 MBytes'

# Generated at 2022-06-20 16:28:14.087810
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('without units') == 0)
    assert(human_to_bytes('3') == 3)
    assert(human_to_bytes('3', 'b') == 3)
    assert(human_to_bytes('3', 'B') == 3)
    assert(human_to_bytes('3B') == 3)
    assert(human_to_bytes('3b') == 3)
    assert(human_to_bytes('3K') == 3 * (1 << 10))
    assert(human_to_bytes('3KiB') == 3 * (1 << 10))
    assert(human_to_bytes('3KiB', 'b') == 3 * (1 << 10))
    assert(human_to_bytes('3Kib', 'b') == 3 * (1 << 10))

# Generated at 2022-06-20 16:28:24.131304
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.2Kb') == 1024 + 256
    assert human_to_bytes('1.2Kb', isbits=True) == 1024 + 256
    assert human_to_bytes('1.2Kb', default_unit='b') == 1024 + 256
    assert human_to_bytes('1.2Kb', default_unit='b', isbits=True) == 1024 + 256
    assert human_to_bytes('1.2Kb', default_unit='B') == 1024 + 256
    assert human_to_bytes('1.2Kb', default_unit='B', isbits=False) == 1024 + 256
    assert human_

# Generated at 2022-06-20 16:28:32.291710
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import assert_equal

    assert_equal(human_to_bytes('1'), 1)
    assert_equal(human_to_bytes('10'), 10)
    assert_equal(human_to_bytes('100'), 100)
    assert_equal(human_to_bytes('1kB'), 1000)
    assert_equal(human_to_bytes('1KB'), 1000)
    assert_equal(human_to_bytes('1Kb'), 128)
    assert_equal(human_to_bytes('1K'), 1024)
    assert_equal(human_to_bytes('1MB'), 1048576)
    assert_equal(human_to_bytes('1MB', isbits=True), 8000000)
    with assert_raises(ValueError):
        human_to_bytes('1Mb', isbits=True)

# Generated at 2022-06-20 16:28:43.903888
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
        test_human_to_bytes:
            Check if the functions passing return value as expected.
            The function tested is human_to_bytes, the function is called
            with different parameters and the actual output and
            expected output is compared.
    '''
    actual_output = human_to_bytes('1')
    assert actual_output == 1, "Expected: 1, Got: " + str(actual_output)

    actual_output = human_to_bytes('1b')
    assert actual_output == 1, "Expected: 1, Got: " + str(actual_output)

    actual_output = human_to_bytes('1kb')
    assert actual_output == 1024, "Expected: 1024, Got: " + str(actual_output)


# Generated at 2022-06-20 16:28:51.448174
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:29:02.206826
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:29:12.578482
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10000) == '9.77 KB'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1023) == '1.00 KB'
    assert bytes_to_human(1000) == '1000.00 Bytes'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10.0) == '10.00 Bytes'
    assert bytes_to_human(10.1) == '10.10 Bytes'
    assert bytes_to_human(10.01) == '10.01 Bytes'
    assert bytes_to_human(10.09) == '10.09 Bytes'

# Generated at 2022-06-20 16:29:15.965294
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_cases = {
        'This is a test': 'this is a test',
        '1 Foo': ['1', 'foo'],
        '2 UPPER': ['2', 'upper']
    }
    for key in test_cases.keys():
        test_case = test_cases[key]
        result = lenient_lowercase(key.split(' '))
        assert result == test_case, \
            'lenient_lowercase(%s) failed, returned %s, expected %s' % (key, result, test_case)

# Generated at 2022-06-20 16:29:21.022258
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''
    Test function bytes_to_human.
    '''
    assert bytes_to_human(8) == "8 Bytes"
    assert bytes_to_human(8, unit='b') == "8 bits"
    assert bytes_to_human(8, isbits=False, unit='B') == "8 Bytes"
    assert bytes_to_human(8, unit='B') == "8 Bytes"
    assert bytes_to_human(8, isbits=False, unit='b') == "8 bits"
    assert bytes_to_human(8, unit='b') == "8 bits"
    assert bytes_to_human(8, isbits=False, unit='K') == "0.01 KB"

# Generated at 2022-06-20 16:29:29.291057
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'b', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 1, 'c']) == ['a', 1, 'c']

# Generated at 2022-06-20 16:29:39.821678
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # bytes
    assert bytes_to_human(1) == "1 Bytes"
    assert bytes_to_human(1000) == "1000 Bytes"
    assert bytes_to_human(1024) == "1 KBytes"
    assert bytes_to_human(1.5*1024) == "1.50 KBytes"
    assert bytes_to_human(2*1024) == "2 KBytes"
    assert bytes_to_human(2.5*1024) == "2.50 KBytes"
    assert bytes_to_human(1024*1024) == "1 MBytes"
    assert bytes_to_human(1024*1024*1024) == "1 GBytes"
    assert bytes_to_human(1024*1024*1024*1024) == "1 TBytes"

# Generated at 2022-06-20 16:29:48.022072
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == "1.00 B"
    assert bytes_to_human(1025) == "1.00 KB"
    assert bytes_to_human(1025, 'Kb') == "1.00 Kb"
    assert bytes_to_human(1025, 'KB') == "1.00 KB"
    assert bytes_to_human(1025, unit='KB') == "1.00 KB"
    assert bytes_to_human(1025, unit='Kb') == "1.00 Kb"



# Generated at 2022-06-20 16:30:10.204783
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['Apples', 'Oranges', 2, '1', 10]
    test_list_dict = {'Apples': 1, 'Oranges': 2, 'Mangos': 3}
    expected_list = ['apples', 'oranges', 2, '1', 10]
    expected_list_dict = {'apples': 1, 'oranges': 2, 'mangos': 3}

    actual_list = lenient_lowercase(test_list)
    actual_list_dict = lenient_lowercase(test_list_dict)

    assert actual_list == expected_list
    assert actual_list_dict == expected_list_dict



# Generated at 2022-06-20 16:30:20.544294
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print("Bytes to human test Start")
    f = open('findbugs_to_human.txt', 'r')
    unit = ['b','K','M','G','T','P','E','Z','Y']
    expected_outputs = []
    for line in f:
        expected_outputs.append(line)
    f.close()
    f = open('bytes_to_human_error.txt', 'w')
    i = 0
    j = 0
    while i < len(expected_outputs):
        output = bytes_to_human(i,False,unit[j]).strip()
        if output == expected_outputs[i].strip():
            i += 1
            j += 1
        else:
            print("Mismatch found")

# Generated at 2022-06-20 16:30:30.055740
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    from ansible.module_utils._text import to_text

    assert to_text(lenient_lowercase([1, 2])) == u"1, 2"
    assert lenient_lowercase(["HELLO", 2, 3]) == ["hello", 2, 3]
    assert lenient_lowercase(["hello", 2, 3]) == ["hello", 2, 3]
    assert to_text(lenient_lowercase([u'HELLO', 2, 3])) == u'hello, 2, 3'
    assert to_text(lenient_lowercase([u'hello', 2, 3])) == u'hello, 2, 3'

# Generated at 2022-06-20 16:30:37.818331
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(2 ** 80, False, 'Y') == '1.00 YB'
    assert bytes_to_human(2 ** 80, False, 'Z') == '1024.00 ZB'
    assert bytes_to_human(2 ** 80, False, 'E') == '1048576.00 EB'
    assert bytes_to_human(2 ** 80, False, 'P') == '1073741824.00 PB'
    assert bytes_to_human(2 ** 80, False, 'T') == '1099511627776.00 TB'
    assert bytes_to_human(2 ** 80, False, 'G') == '1125899906842624.00 GB'
    assert bytes_to_human(2 ** 80, False, 'M') == '1152921504606846976.00 MB'


# Generated at 2022-06-20 16:30:46.717627
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """
    Unit test for bytes_to_human function
    """
    print('Testing bytes_to_human')
    print('Test case 1:')
    if bytes_to_human(1, isbits=False, unit=None) != '1.00 Bytes':
        print('bytes_to_human(1, isbits=False, unit=None) != "1.00 Bytes"')
        return False

    print('Test case 2:')
    if bytes_to_human(2048, isbits=False, unit='B') != '2.00 Bytes':
        print('bytes_to_human(2048, isbits=False, unit="B") != "2.00 Bytes"')
        return False

# Generated at 2022-06-20 16:30:57.662476
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # assert with non-default unit values
    assert 1048576 == human_to_bytes('1MB')
    assert 1048576 * 2 == human_to_bytes('2MB')
    assert 1048576 * 4 == human_to_bytes('4MB')
    assert 1048576 * 8 == human_to_bytes('8MB')
    assert 1048576 * 10 == human_to_bytes('10MB')
    assert 1048576 * 15 == human_to_bytes('15MB')
    assert 1048576 * 16 == human_to_bytes('16MB')

    assert 1024 == human_to_bytes('1KB')
    assert 1024 * 2 == human_to_bytes('2KB')
    assert 1024 * 4 == human_to_bytes('4KB')
    assert 1024 * 8 == human_to_bytes('8KB')
    assert 1024

# Generated at 2022-06-20 16:31:09.140697
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048577) == '1.00 MB'
    assert bytes_to_human(1048576, unit='M') == '1.00 MB'
    assert bytes_to_human(1048576, unit='K') == '1024.00 K'
    assert bytes_to_human(1048576, unit='G') == '1.00 GB'
    assert bytes_to_human(1048576, unit='b') == '8388608 bits'

    assert bytes_to_human(1048576, unit='b', isbits=True) == '8388608 bits'
    assert bytes_to_human(1048576, unit='G', isbits=True) == '8.00 GB'

    assert bytes_to

# Generated at 2022-06-20 16:31:14.171256
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([0, 1, 2]) == [0, 1, 2]
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase([list, dict]) == [list, dict]

# Generated at 2022-06-20 16:31:19.432492
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    data = [
        {'in': ['A', 'b', 'c', 'D'], 'out': ['a', 'b', 'c', 'd']},
        {'in': ['A', 1, 2, 'D'], 'out': ['a', 1, 2, 'd']},
    ]

    for test in data:
        result = lenient_lowercase(test['in'])
        assert result == test['out'], "Test %s failed: %s != %s" % (test['in'], result, test['out'])



# Generated at 2022-06-20 16:31:24.677579
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Cisco IOS', 'NX-OS']) == ['cisco ios', 'nx-os']
    assert lenient_lowercase(['cisco_ios', 'NX-OS']) == ['cisco_ios', 'nx-os']
    assert lenient_lowercase(['cisco-ios', 'NX-OS']) == ['cisco-ios', 'nx-os']
    assert lenient_lowercase(['rtr1', 'nx1']) == ['rtr1', 'nx1']
    assert lenient_lowercase(['rtr1', '4096']) == ['rtr1', 4096]
    assert lenient_lowercase(['rtr1', 4096]) == ['rtr1', 4096]

# Generated at 2022-06-20 16:31:59.110114
# Unit test for function bytes_to_human
def test_bytes_to_human():
    data = ['1', '1b', '1.0B', '1.0K', '1.0M', '1.0G', '1.0T', '1.0P', '1.0E', '1.0Z', '1.0Y']
    result = ['1.00 Bytes', '1.00 bits', '1.00 Bytes', '1.00 KB', '1.00 MB', '1.00 GB', '1.00 TB', '1.00 PB', '1.00 EB', '1.00 ZB',
              '1.00 YB']
    assert [bytes_to_human(v) for v in data] == result


# Generated at 2022-06-20 16:32:02.129449
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_list = ['abc', 1, 2, 'DEF']
    output_list = ['abc', 1, 2, 'DEF']
    assert lenient_lowercase(input_list) == output_list



# Generated at 2022-06-20 16:32:11.019326
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:32:13.727792
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["STRING", 1, "sTrInG", 2]) == ['string', 1, 'sTrInG', 2]

# Generated at 2022-06-20 16:32:24.676465
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(10485800) == '10.00 MB'
    assert bytes_to_human(1048580000) == '1005.11 MB'
    assert bytes_to_human(104858000000) == '9765.63 MB'
    assert bytes_to_human(104858000000, unit='m') == '1048.58 MB'
    assert bytes_to_human(104858000000, unit='b') == '92468.71 MB'
    assert bytes_to_human(104858000000, unit='K') == '1023520.00 MB'
    assert bytes_to_human(104858000000, unit='g') == '0.10 MB'


# Generated at 2022-06-20 16:32:35.931671
# Unit test for function bytes_to_human
def test_bytes_to_human():
    tests = [
        ((-1, 'B'), '-0.00 Bytes'),
        ((1, 'B'), '1.00 Bytes'),
        ((2, 'b'), '2.00 bits'),
        ((1, 'KB'), '1.00 KB'),
        ((1, 'kB'), '1.00 kB'),
        ((1, 'Mb'), '1.00 Mb'),
        ((1, 'MB'), '1.00 MB'),
        ((1, 'M'), '1.00 M'),
        ((1, 'Z'), '1.00 Z'),
        ((1, 'z'), '1.00 ZB'),
        ((1, 'O'), '0'),
        ((1, ''), '1.00 ')
    ]

# Generated at 2022-06-20 16:32:47.910150
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:32:58.868276
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:33:09.550288
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(2) == '2.00 Bytes'
    assert bytes_to_human(1234) == '1234.00 Bytes'
    assert bytes_to_human(500000) == '500000.00 Bytes'
    assert bytes_to_human(2 ** 10) == '1024.00 Bytes'
    assert bytes_to_human(2 ** 20) == '1048576.00 Bytes'
    assert bytes_to_human(2 ** 30) == '1073741824.00 Bytes'
    assert bytes_to_human(2 ** 40) == '1099511627776.00 Bytes'
    assert bytes_to_human

# Generated at 2022-06-20 16:33:17.878583
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1') == 1)
    assert(human_to_bytes('1.1') == 1)
    assert(human_to_bytes('1.5') == 1)
    assert(human_to_bytes('1.9') == 1)
    assert(human_to_bytes('1.0') == 1)

    assert(human_to_bytes('1K') == 1024)
    assert(human_to_bytes('1KB') == 1024)
    assert(human_to_bytes('1MB') == 1024 * 1024)
    assert(human_to_bytes('1GB') == 1024 * 1024 * 1024)
    assert(human_to_bytes('1TB') == 1024 * 1024 * 1024 * 1024)
    assert(human_to_bytes('1PB') == 1024 * 1024 * 1024 * 1024 * 1024)


# Generated at 2022-06-20 16:33:48.368830
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    l = ['TEST', 123, 'TEST', 'TEST']
    assert lenient_lowercase(l) == ['test', 123, 'test', 'test']

# Generated at 2022-06-20 16:33:54.902473
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Base test bytes
    ''' Devide base values by 1024 to get binary base values '''

    assert(human_to_bytes("1048576") == 1048576)
    assert(human_to_bytes("1Y") == (1 << 80))
    assert(human_to_bytes("1Z") == 1 << 70)
    assert(human_to_bytes("1E") == (1 << 60))
    assert(human_to_bytes("1P") == (1 << 50))
    assert(human_to_bytes("1T") == (1 << 40))
    assert(human_to_bytes("1G") == (1 << 30))
    assert(human_to_bytes("1M") == (1 << 20))
    assert(human_to_bytes("1K") == (1 << 10))

# Generated at 2022-06-20 16:34:01.329306
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase([1,2,3]) == [1,2,3]
    assert lenient_lowercase(['a', 2, 'c']) == ['a', 2, 'c']


if __name__ == '__main__':
    import pytest

    pytest.main(['-x', __file__])

# Generated at 2022-06-20 16:34:13.078482
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test when passing bits
    assert bytes_to_human(1048576, isbits=True) == "8.00 Mbits"
    assert bytes_to_human(1048576, isbits=True, unit='M') == "8.00 Mbits"
    assert bytes_to_human(1048576, isbits=True, unit='m') == "8.00 Mbits"
    assert bytes_to_human(1048576000, isbits=True, unit='G') == "8.00 Gbits"
    assert bytes_to_human(1048576000, isbits=True, unit='g') == "8.00 Gbits"
    # Test when passing bytes
    assert bytes_to_human(1048576) == "1.00 MB"

# Generated at 2022-06-20 16:34:21.372155
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(10, unit='b') == '0.10 bits'
    assert bytes_to_human(10, isbits=True) == '0.10 bits'
    assert bytes_to_human(10, isbits=True, unit='B') == '10.00 bits'
    assert bytes_to_human(10, isbits=True, unit='K') == '10000.00 bits'
    assert bytes_to_human(10, isbits=True, unit='Kb') == '1.20 Kbits'
    assert bytes_to_human(10, isbits=True, unit='Kb') == '1.20 Kbits'

# Generated at 2022-06-20 16:34:28.861810
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1, unit='b') == '1 bits'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1048576 TB'
    assert bytes_to_human(1024 * 1024 * 1024, 'MB') == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024, unit = 'b') == '8589934592 bits'

# Generated at 2022-06-20 16:34:39.441698
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """
    Unit test for function bytes_to_human()
    """
    assert '0.00 Bytes' == bytes_to_human(0)
    assert '5.00 Bytes' == bytes_to_human(5)
    assert '512.00 Bytes' == bytes_to_human(512)
    assert '1.00 KB' == bytes_to_human(1024)
    assert '2.00 KB' == bytes_to_human(2000)
    assert '3.00 KB' == bytes_to_human(3000)
    assert '0.00 KBytes' == bytes_to_human(0, unit='K')
    assert '0.00 MBytes' == bytes_to_human(0, unit='M')
    assert '0.00 GBytes' == bytes_to_human(0, unit='G')
   

# Generated at 2022-06-20 16:34:48.354384
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes(10, 'M') == human_to_bytes(10, 'M', isbits=True)
    assert human_to_bytes('10M', isbits=True) == human_to_bytes(10, 'M', isbits=True)
    assert human_to_bytes('10M', isbits=True) == human_to_bytes(10, 'Mb')
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('1Mb') == 1048576
    assert human_to

# Generated at 2022-06-20 16:34:59.490163
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1100) == '1.07 KB'
    assert bytes_to_human(10000) == '9.77 KB'
    assert bytes_to_human(100000) == '97.66 KB'
    assert bytes_to_human(1000000) == '976.56 KB'
    assert bytes_to_human(10000000) == '9.54 MB'
    assert bytes_to_human(100000000) == '95.37 MB'
    assert bytes_to_human(1000000000) == '953.67 MB'
    assert bytes_to_human(10000000000) == '9.31 GB'

# Generated at 2022-06-20 16:35:03.556161
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    x = ['a', 2, 'B', 3, 'd', 4]
    x_lowered = ['a', 2, 'b', 3, 'd', 4]
    assert lenient_lowercase(x) == x_lowered