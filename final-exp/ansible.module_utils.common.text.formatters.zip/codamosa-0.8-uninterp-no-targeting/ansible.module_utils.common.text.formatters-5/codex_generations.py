

# Generated at 2022-06-20 16:25:52.663087
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Conversion using unit
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'M', isbits=True) == 10485760
    # Conversion using the unit in the string
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    # Conversion using default_unit
    assert human_to_bytes(10) == 10
    assert human_to_bytes(10, isbits=True) == 10
    assert human_to_bytes(10, 'M', isbits=True) == 10485760
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes('10') == 10

# Generated at 2022-06-20 16:26:01.315224
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test that lenient_lowercase works when given a list of strings
    assert lenient_lowercase(['Foo', 'BAR', 'Baz']) == ['foo', 'bar', 'baz']
    # Test that lenient_lowercase works when given a list with non-string items
    assert lenient_lowercase(['Foo', 'BAR', 'Baz', 10]) == ['foo', 'bar', 'baz', 10]
    # Test that lenient_lowercase works when given a list of string-like items
    assert lenient_lowercase(['Foo', 'BAR', 'Baz', datetime.date(2019, 12, 25)]) == ['foo', 'bar', 'baz', datetime.date(2019, 12, 25)]

# Generated at 2022-06-20 16:26:12.221528
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        human_to_bytes('10', 'M')
    except:
        print("ERROR: #1")
        return False

    try:
        human_to_bytes('10M')
    except:
        print("ERROR: #2")
        return False

    try:
        human_to_bytes('10', 'KB')
    except:
        print("ERROR: #3")
        return False

    try:
        human_to_bytes('10kb')
    except:
        print("ERROR: #4")
        return False

    try:
        human_to_bytes('10kb', isbits=True)
    except:
        print("ERROR: #5")
        return False

    try:
        human_to_bytes('10MB')
    except:
        print("ERROR: #6")
        return

# Generated at 2022-06-20 16:26:19.686999
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Unit test for function bytes_to_human with bytes=True
    assert bytes_to_human(1024) == '1.00 KBytes'
    assert bytes_to_human(1024, isbits=False, unit='K') == '1.00 KBytes'
    assert bytes_to_human(1024, isbits=False, unit='M') == '0.00 MBytes'
    assert bytes_to_human(1024, isbits=False, unit='G') == '0.00 GBytes'
    assert bytes_to_human(1024, isbits=False, unit='T') == '0.00 TBytes'
    assert bytes_to_human(1024, isbits=False, unit='P') == '0.00 PBytes'

# Generated at 2022-06-20 16:26:30.779455
# Unit test for function human_to_bytes
def test_human_to_bytes():

    assert human_to_bytes('2048') == 2048
    assert human_to_bytes('1.4M') == 1474560
    assert human_to_bytes('1.4M', isbits=True) == 1474560
    assert human_to_bytes('1.4b', isbits=True) == 1
    assert human_to_bytes('1.4B', isbits=True) == 1474560
    assert human_to_bytes('1.4', unit='M') == 1474560
    assert human_to_bytes('1.4', unit='m') == 1474560
    assert human_to_bytes('1.4Kb') == 1648
    assert human_to_bytes('1.4Kb', isbits=True) == 1648

# Generated at 2022-06-20 16:26:41.723072
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test without unit
    result = bytes_to_human(1)
    assert result == '1.00 Bytes', result

    result = bytes_to_human(1234)
    assert result == '1.23 KB', result

    result = bytes_to_human(12345)
    assert result == '12.35 KB', result

    result = bytes_to_human(1234567)
    assert result == '1.23 MB', result

    result = bytes_to_human(12345678)
    assert result == '12.34 MB', result

    # Test with unit
    result = bytes_to_human(1, unit='b')
    assert result == '1.00 bits', result

    result = bytes_to_human(12345, unit='K')
    assert result == '12.06 KBytes', result

    result

# Generated at 2022-06-20 16:26:54.434219
# Unit test for function human_to_bytes
def test_human_to_bytes():  # pragma: no cover
    from ansible.module_utils.network_common import NetboxUnits
    from ansible.module_utils.network_common import NetboxBits
    from ansible.module_utils.network_common import NetboxHumanNumber

    # unit: bytes
    nbu = NetboxUnits('2048')
    assert nbu.value == 2048
    assert str(nbu) == '2048'
    assert nbu.unit == NetboxUnits.UNIT_BYTES
    assert nbu.unit_name == 'Bytes'

    # unit: MBytes
    nbu = NetboxUnits('2M')
    assert nbu.value == 2097152
    assert str(nbu) == '2097152'
    assert nbu.unit == NetboxUnits.UNIT_MEGABYT

# Generated at 2022-06-20 16:26:58.915405
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['sTring', 'string', 1, ('second', 'Tuple'), ('Tuple', 'Tuple')]
    result = ['string', 'string', 1, ('second', 'Tuple'), ('Tuple', 'Tuple')]
    assert lenient_lowercase(test_list) == result


# Generated at 2022-06-20 16:27:10.650438
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('25.5Mb', isbits=True) == 2621440
    assert human_to_bytes('25.5Mb') == 2621440

# Generated at 2022-06-20 16:27:15.411735
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['a', 'b', 12, 'c']) == ['a', 'b', 12, 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c']

# Generated at 2022-06-20 16:27:25.559213
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:27:35.243670
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test valid input strings
    assert human_to_bytes('1') == 1
    assert human_to_bytes('12') == 12
    assert human_to_bytes('123') == 123
    assert human_to_bytes('123B') == 123
    assert human_to_bytes('123b') == 123
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1MB') == 1024 * 1024
    assert human_to_bytes('1Mb') == 1024 * 1024
    assert human_to_bytes('1Gb') == 1024 * 1024 * 1024
    assert human_to_bytes('1TB') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1PB') == 1024 * 1024 * 1024 * 1024 * 1024
    assert human

# Generated at 2022-06-20 16:27:45.847977
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(0, isbits=True) == '0 bits'
    assert bytes_to_human(0, unit='m') == '0 MBytes'
    assert bytes_to_human(0, isbits=True, unit='m') == '0 Mbits'
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1023, isbits=True) == '8191 bits'
    assert bytes_to_human(1, unit='m') == '0.00 MBytes'
    assert bytes_to_human(1, isbits=True, unit='m') == '0.00 Mbits'

# Generated at 2022-06-20 16:27:52.482588
# Unit test for function bytes_to_human
def test_bytes_to_human():
    result = bytes_to_human(1024)
    assert result == "1.00 KB"

    result = bytes_to_human(10210)
    assert result == "10.00 KB"

    result = bytes_to_human(1048576)
    assert result == "1.00 MB"

    result = bytes_to_human(104857600)
    assert result == "100.00 MB"

    result = bytes_to_human(1073741824)
    assert result == "1.00 GB"

    result = bytes_to_human(1099511627776)
    assert result == "1.00 TB"

    result = bytes_to_human(1125899906842624)
    assert result == "1.00 PB"

    result = bytes_to_human(1152921504606846976)


# Generated at 2022-06-20 16:28:01.075754
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1000) == '1000.00 Bytes'
    assert bytes_to_human(10000000) == '9.54 MB'
    assert bytes_to_human(1000000000) == '953.67 MB'
    assert bytes_to_human(1000000000000) == '931.32 GB'
    assert bytes_to_human(1000000000000000) == '909.49 TB'
    assert bytes_to_human(1000000000000000000) == '888.18 PB'
    assert bytes_to_human(1000000000000000000000) == '867.31 EB'
    assert bytes_to_human(1000000000000000000000000) == '846.84 ZB'
    assert bytes_to_human(1000000000000000000000000000) == '826.78 YB'

# Generated at 2022-06-20 16:28:08.227763
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(2, False, 'K') == '0.00 KB'
    assert bytes_to_human(2, False, 'M') == '0.00 MB'
    assert bytes_to_human(2, False, 'G') == '0.00 GB'
    assert bytes_to_human(2, False, 'T') == '0.00 TB'
    assert bytes_to_human(2, False, 'E') == '0.00 EB'
    assert bytes_to_human(2, False, 'P') == '0.00 PB'
    assert bytes_to_human(2, False, 'Z') == '0.00 ZB'
    assert bytes_to_human(2, False, 'Y') == '0.00 YB'


# Generated at 2022-06-20 16:28:20.067462
# Unit test for function bytes_to_human
def test_bytes_to_human():
    ''' Test bytes_to_human function '''

    # check that function is not returning unexpected values
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(48) == '48 Bytes'
    assert bytes_to_human(1 << 10) == '1.00 KB'
    assert bytes_to_human(1 << 20) == '1.00 MB'
    assert bytes_to_human(1 << 30) == '1.00 GB'
    assert bytes_to_human(1 << 80) == '1.00 YB'
    assert bytes_to_human(1e10) == '91.74 GB'

    # function is returning expected values
    assert bytes_to_human(1) == '1 Bytes'

# Generated at 2022-06-20 16:28:32.138777
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1, 'Failed to convert 1B to bytes'
    assert human_to_bytes('1KB') == 1000, 'Failed to convert 1K to bytes'
    assert human_to_bytes('1K') == 1000, 'Failed to convert 1K to bytes'
    assert human_to_bytes(1) == 1, 'Failed to convert 1 to bytes'
    assert human_to_bytes('1.5MB') == 1500000, 'Failed to convert 1.5M to bytes'
    assert human_to_bytes('1.5G') == 1500000000, 'Failed to convert 1.5G to bytes'
    assert human_to_bytes('5.5M') == 5500000, 'Failed to convert 5.5M to bytes'

# Generated at 2022-06-20 16:28:43.719049
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(number='1', default_unit='K') == 1024
    assert human_to_bytes(number='1B') == 1
    assert human_to_bytes(number='10kB') == 10240
    assert human_to_bytes(number='1.1Mb') == 1100000
    assert human_to_bytes(number='1e3GB', default_unit='GB') == 1000*1024*1024*1024
    assert human_to_bytes(number='1Eb') == 10**15
    assert human_to_bytes(number='1.0Eb', default_unit='Eb') == 10**15
    assert human_to_bytes(number='3.4E+4') == 340000
    assert human_to_bytes(number='3.4e-4') == 0.00034
    assert human_

# Generated at 2022-06-20 16:28:51.338016
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:28:59.990335
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 1, 'c']) == ['a', 'b', 1, 'c']

test_lenient_lowercase()

# Generated at 2022-06-20 16:29:10.733132
# Unit test for function human_to_bytes
def test_human_to_bytes():
    human_to_bytes(1)
    human_to_bytes('1')
    human_to_bytes('1.1')
    human_to_bytes('1.0')
    human_to_bytes('1', default_unit='B')
    human_to_bytes('1', default_unit='b')

    human_to_bytes('1', default_unit='B')
    human_to_bytes('1', default_unit='GB')
    human_to_bytes('1', default_unit='MB')
    human_to_bytes('1', default_unit='KB')
    human_to_bytes('1', default_unit='B')

    human_to_bytes('1', default_unit='b')
    human_to_bytes('1', default_unit='Gb')

# Generated at 2022-06-20 16:29:22.458631
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    assert that the function cannot convert to bytes from a unit
        of bits when isbits=False
    assert correct byte conversion from a unit of byte
    assert correct byte conversion from a unit of kilobyte
    assert correct byte conversion from a unit of megabyte
    assert correct byte conversion from a unit of gigabyte
    assert correct byte conversion from a unit of terabyte
    assert correct byte conversion from a unit of petabyte
    '''
    assert 1 == human_to_bytes(1)
    assert 1 == human_to_bytes(1, 'b')
    assert 1024 == human_to_bytes(1, 'k')
    assert 1048576 == human_to_bytes(1, 'm')
    assert 1073741824 == human_to_bytes(1, 'g')

# Generated at 2022-06-20 16:29:27.589318
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Tests for function lenient_lowercase."""
    assert lenient_lowercase(["123", "456"]) == ["123", "456"]
    assert lenient_lowercase([123, "456"]) == [123, "456"]
    assert lenient_lowercase(["123", 456]) == ["123", 456]
    assert lenient_lowercase(["Ansible", "rocks"]) == ["ansible", "rocks"]



# Generated at 2022-06-20 16:29:38.649238
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1023') == 1023
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1024B') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1k', isbits=True) == 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1Mb') == 1024 * 1024
    assert human_to_bytes('1M', isbits=True) == 1024 * 1024

# Generated at 2022-06-20 16:29:49.228346
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from ansible_collections.nxos.nxos.tests.unit.compat.mock import patch
    from ansible_collections.nxos.nxos.plugins.modules import nxos_module_utils

    with patch.object(nxos_module_utils, 'SIZE_RANGES', {'B': 1, 'K': 1024, 'M': 1 << 20, 'G': 1 << 30, 'T': 1 << 40}):
        assert nxos_module_utils.human_to_bytes('100M') == 104857600
        assert nxos_module_utils.human_to_bytes('100') == 100
        assert nxos_module_utils.human_to_bytes(10) == 10
        assert nxos_module_utils.human_to_bytes('10MB') == 10

# Generated at 2022-06-20 16:29:56.362152
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1000) == '1.00 KB'
    assert bytes_to_human(1000000) == '1.00 MB'
    assert bytes_to_human(10**12) == '1.00 TB'
    assert bytes_to_human(10**15) == '1.00 PB'
    assert bytes_to_human(10**18) == '1.00 EB'
    assert bytes_to_human(10**21) == '1.00 ZB'
    assert bytes_to_human(10**24) == '1.00 YB'

    assert bytes_to_human(1, isbits=True) == '1 bits'

# Generated at 2022-06-20 16:30:03.395792
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
    assert lenient_lowercase(['A', 'b', 'C', 'd']) == ['a', 'b', 'c', 'd']
    assert lenient_lowercase([1, 'b', 2, 3]) == [1, 'b', 2, 3]


# Generated at 2022-06-20 16:30:07.572578
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Test lenient_lowercase
    """
    test_list = ['a', 2, 'c', 4]
    test_list_lowercase = ['a', 2, 'c', 4]

    result = lenient_lowercase(test_list)

    assert result == test_list_lowercase

# Generated at 2022-06-20 16:30:16.099502
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'b', 3]) == ['a', 'b', 3]
    assert lenient_lowercase(['aA', 'b', 'c']) == ['aa', 'b', 'c']
    assert lenient_lowercase(['Aa', 'b', 3]) == ['aa', 'b', 3]

# Generated at 2022-06-20 16:30:33.857471
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        human_to_bytes('2')
        assert False
    except ValueError:
        pass

    assert 10 == human_to_bytes('10')
    assert 10 == human_to_bytes('10b')
    assert 1049600 == human_to_bytes('10.24K')
    assert 10485760 == human_to_bytes('10M')
    assert 104857600 == human_to_bytes('100M')
    assert 1048576000 == human_to_bytes('1000M')
    assert 10485760000 == human_to_bytes('10000M')
    assert 1073741824 == human_to_bytes('1G')
    assert 10737418240 == human_to_bytes('10G')
    assert 1099511627776 == human_to_bytes('1T')


# Generated at 2022-06-20 16:30:40.336314
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'A', 'B']) == ['a', 'a', 'b']
    assert lenient_lowercase(['a', 'A', None]) == ['a', 'a', None]
    assert lenient_lowercase(['a', 'A', 'B', 12]) == ['a', 'a', 'b', 12]



# Generated at 2022-06-20 16:30:47.702894
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Skip test in Python 3+
    if hasattr(__builtins__, '__IPYTHON__'):
        return

    from nose.tools import assert_equal, assert_raises
    from math import floor

    def human_to_bytes_test(string, expected):
        assert_equal(human_to_bytes(string), expected, "Conversion failed for input %s" % string)

    def human_to_bits_test(string, expected):
        assert_equal(human_to_bytes(string, isbits=True), expected, "Conversion failed for input %s, isbits" % string)


# Generated at 2022-06-20 16:30:57.916553
# Unit test for function bytes_to_human
def test_bytes_to_human():
    if bytes_to_human(1023, unit='B') != '1023 Bytes':
        raise AssertionError("Expected '1023 Bytes', got " + bytes_to_human(1023, unit='B'))
    if bytes_to_human(1024, unit='B') != '1.00 KB':
        raise AssertionError("Expected '1.00 KB', got " + bytes_to_human(1024, unit='B'))
    if bytes_to_human(1024, unit='K') != '1.00 KB':
        raise AssertionError("Expected '1.00 KB', got " + bytes_to_human(1024, unit='K'))

# Generated at 2022-06-20 16:31:09.411871
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # Lowercase suffixes
    assert human_to_bytes('10k') == 10240
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10G') == 10737418240
    assert human_to_bytes('10T') == 10995116277760

    # Uppercase suffixes
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10G') == 10737418240

    # Single-character suffixes
    assert human_to_bytes('10k') == 10240
    assert human_to_bytes('10m') == 10485760
    assert human_to_bytes('10g') == 107

# Generated at 2022-06-20 16:31:18.026022
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('Testing function human_to_bytes()')

    # simple conversion with B units
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.1B') == 1
    assert human_to_bytes('-1.1B') == -1

    # simple conversion with Kb units
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1.1Kb', isbits=True) == 1152
    assert human_to_bytes('-1.1Kb', isbits=True) == -1152

    # simple conversion with MB units
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1.1MB') == 1153433.6

# Generated at 2022-06-20 16:31:29.707683
# Unit test for function bytes_to_human
def test_bytes_to_human():
    if bytes_to_human(1) != '1.00 Bytes':
        return False
    if bytes_to_human(1024) != '1.00 KB':
        return False
    if bytes_to_human(1048576) != '1.00 MB':
        return False
    if bytes_to_human(1073741824) != '1.00 GB':
        return False
    if bytes_to_human(1099511627776) != '1.00 TB':
        return False
    if bytes_to_human(1125899906842624) != '1.00 PB':
        return False
    if bytes_to_human(1152921504606846976) != '1.00 EB':
        return False

# Generated at 2022-06-20 16:31:38.462338
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''Test function human_to_bytes with various inputs.
    '''
    try:
        human_to_bytes('')
        assert False
    except ValueError:
        pass

    try:
        human_to_bytes('10.2M')
    except ValueError:
        assert False

    assert human_to_bytes('1Kb', isbits=True) == 1024

    assert human_to_bytes('2K') == 2048

    assert human_to_bytes('2K', isbits=True) == 16384

    assert human_to_bytes('1MB', unit='M') == 1048576

    try:
        human_to_bytes('1MB', unit='b')
        assert False
    except ValueError:
        pass

    assert human_to_bytes('1B') == 1


# Generated at 2022-06-20 16:31:47.063211
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(2 ** 10) == "1.00 KB"
    assert bytes_to_human(2 ** 20) == "1.00 MB"
    assert bytes_to_human(2 ** 30) == "1.00 GB"
    assert bytes_to_human(2 ** 40) == "1.00 TB"
    assert bytes_to_human(2 ** 50) == "1.00 PB"
    assert bytes_to_human(2 ** 60) == "1.00 EB"
    assert bytes_to_human(2 ** 70) == "1.00 ZB"
    assert bytes_to_human(2 ** 80) == "1.00 YB"

    assert bytes_to_human(2 ** 10, isbits=True) == "1.00 Kb"

# Generated at 2022-06-20 16:31:58.371275
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2 * (1 << 10)
    assert human_to_bytes('2k') == 2 * (1 << 10)
    assert human_to_bytes('2M') == 2 * (1 << 20)
    assert human_to_bytes('2m') == 2 * (1 << 20)
    assert human_to_bytes('2G') == 2 * (1 << 30)
    assert human_to_bytes('2g') == 2 * (1 << 30)
    assert human_to_bytes('2Kb') == 2 * (1 << 10)
    assert human_to_bytes('2kb') == 2 * (1 << 10)
    assert human_to_bytes('2Mb') == 2 * (1 << 20)

# Generated at 2022-06-20 16:32:16.341659
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:32:26.287308
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1MB', isbits=True) == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 8388608
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('0.5MB') == 524288
    assert human_to_bytes('1', unit='MB') == 1048576
    # check for 'b' (byte) and 'b' (bit)
    assert human_to_bytes('1b') == 1
    assert human_to_bytes

# Generated at 2022-06-20 16:32:28.981022
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['First', 2, 'third']) == ['first', 2, 'third']
    assert lenient_lowercase([]) == []

# Generated at 2022-06-20 16:32:37.606108
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import assert_equal
    assert_equal(human_to_bytes('1K', default_unit='B'), 1024)
    assert_equal(human_to_bytes('2K', 'B'), 2048)
    assert_equal(human_to_bytes('1'), 1)
    assert_equal(human_to_bytes('1K', isbits=True), human_to_bytes('1Kb'))
    assert_equal(human_to_bytes('1Kb', isbits=True), 8192)
    assert_equal(human_to_bytes('2M', 'B'), 2*1024*1024)
    assert_equal(human_to_bytes('2M'), 2*1024*1024)
    assert_equal(human_to_bytes('2Mb', isbits=True), 2*1024*1024*8)
   

# Generated at 2022-06-20 16:32:39.582120
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['UNITTEST', 'value']) == ['unittest', 'value']



# Generated at 2022-06-20 16:32:50.294073
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10MIB') == 10485760
    assert human_to_bytes('thirty-three zeebytes') == 33554433
    assert human_to_bytes('1,048,576') == 1048576
    assert human_to_bytes('10KiB') == 10240
    assert human_to_bytes('10KiB', 'B') == 10240
    assert human_to_bytes(10.0, 'M') == 10485760
    assert human_to_bytes('10M', default_unit='B') == 10485760
    assert human_to_bytes('2b') == 2
    assert human_to_bytes('2b', isbits=True) == 2
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_

# Generated at 2022-06-20 16:33:00.665914
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('100') == 100
    assert human_to_bytes('100B') == 100
    assert human_to_bytes('100Bytes') == 100
    assert human_to_bytes('100Bytes', unit='b') == 100
    assert human_to_bytes('100Bytes', unit='B') == 100
    assert human_to_bytes('100Bytes', unit='B') == 100
    assert human_to_bytes('1024Bytes', unit='b') == 1024
    assert human_to_bytes('1024Bytes', unit='B') == 1024
    assert human_to_bytes('2048B', unit='b') == 2048
    assert human_to_bytes('2048B', unit='B') == 2048
    assert human_to_bytes('5MB') == 5242880

# Generated at 2022-06-20 16:33:02.776959
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(['TeSt', 1, 'Test'])
    if result != ['test', 1, 'Test']:
        raise AssertionError("lenient_lowercase() returns %s, but expected ['test', 1, 'Test']" % result)



# Generated at 2022-06-20 16:33:05.950714
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'bC']) == ['a', 'b', 'bc']
    assert lenient_lowercase(['a', 1, 'b']) == ['a', 1, 'b']


# Generated at 2022-06-20 16:33:11.404380
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test string
    assert lenient_lowercase(["I'm all lowercase", 1]) == ["I'm all lowercase", 1]
    assert lenient_lowercase(["I'm not lowercase", 1]) == ["i'm not lowercase", 1]
    assert lenient_lowercase(["I'm not lowercase", "I'm also not lowercase"]) == ["i'm not lowercase", "i'm also not lowercase"]



# Generated at 2022-06-20 16:33:36.777339
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Unit test for human_to_bytes"""
    cases = [
        {'input': '2', 'output': 2},
        {'input': '2.5', 'output': 2.5},
        {'input': '2K', 'output': 2048},
        {'input': '2M', 'output': 2097152},
        {'input': '2Kb', 'output': 2048, 'unit': 'b', 'isbits': True},
        {'input': '2kb', 'output': 2048, 'unit': 'b', 'isbits': True},
        {'input': '2Mb', 'output': 2097152, 'unit': 'b', 'isbits': True},
        {'input': '2mb', 'output': 2097152, 'unit': 'b', 'isbits': True}
    ]

   

# Generated at 2022-06-20 16:33:48.775685
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1M') == 1 << 20
    assert human_to_bytes('1.5M') == 1.5 << 20
    assert human_to_bytes('1024B') == 1024
    assert human_to_bytes('1.5K') == 1.5 << 10
    assert human_to_bytes('1.5kb') == 1.5 << 10
    assert human_to_bytes('1.5MB') == 1.5 << 20
    assert human_to_bytes('1.5Mb') == 1.5 << 20
    assert human_to_bytes('1.5GB') == 1.5 << 30
    assert human_to_bytes('1.5Gb') == 1.5 << 30
    assert human_to_bytes('1.5TB') == 1

# Generated at 2022-06-20 16:33:55.297623
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    When comparing the results of function with pre-calculated results,
    please note that the results have a floating-point error.

    This is due to the fact that the division of float numbers
    can cause this effect.
    '''

# Generated at 2022-06-20 16:34:03.573680
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(2048, unit='b') == '1.00 KB'
    assert bytes_to_human(2048, isbits=True, unit='b') == '10.00 KB'
    assert bytes_to_human(2048, isbits=True, unit='bB') == '1.00 KB'
    assert bytes_to_human(2048, isbits=True, unit='BB') == '10.00 KB'


# Generated at 2022-06-20 16:34:15.335887
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """ test function human_to_bytes()"""

# Generated at 2022-06-20 16:34:23.853790
# Unit test for function human_to_bytes
def test_human_to_bytes():
    res = human_to_bytes('2K')
    assert res == 2 ** 10, "Error in human_to_bytes(): '%s' expected but got '%s' (%s)" % (2 ** 10, res, type(res))

    res = human_to_bytes('2K', isbits=True)
    assert res == 2 ** 10, "Error in human_to_bytes(): '%s' expected but got '%s' (%s)" % (2 ** 10, res, type(res))

    res = human_to_bytes('2Kb')
    assert res == 2 ** 10, "Error in human_to_bytes(): '%s' expected but got '%s' (%s)" % (2 ** 10, res, type(res))

    res = human_to_bytes('2Kb', isbits=True)
    assert res

# Generated at 2022-06-20 16:34:34.556618
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10) == 10

    assert human_to_bytes(10, 'M') == 10 * 1024 ** 2
    assert human_to_bytes(10, 'M', True) == 10 * 1024 ** 2
    assert human_to_bytes(10, 'Mb', True) == 10 * 1024 ** 2

    assert human_to_bytes(10, 'B') == 10
    assert human_to_bytes(10, 'Bb') == 10
    assert human_to_bytes(10, 'B', True) == 10
    assert human_to_bytes(10, 'Bb', True) == 10

    assert human_to_bytes('10 B') == 10
    assert human_to_bytes('10 Bb') == 10
    assert human_to_bytes('10 B', True) == 10
    assert human_to_

# Generated at 2022-06-20 16:34:37.059805
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    inputlist = ['string', 1, 1.0]
    outputlist = ['string', 1, 1.0]
    assert lenient_lowercase(inputlist) == outputlist



# Generated at 2022-06-20 16:34:40.845717
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['foo', 'BAR', 123, 'FOO']) == ['foo', 'bar', 123, 'FOO']



# Generated at 2022-06-20 16:34:49.568386
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('20B') == 20
    assert human_to_bytes(20) == 20
    assert human_to_bytes('20') == 20
    assert human_to_bytes('20b') == 20
    assert human_to_bytes('20B', isbits=True) == 20
    assert human_to_bytes('20K') == 20 * (1 << 10)
    assert human_to_bytes('20K') == human_to_bytes('20k')
    assert human_to_bytes('20k', isbits=True) == 20 * (1 << 10)
    assert human_to_bytes('20Kb') == 20 * (1 << 10)
    assert human_to_bytes('20K', isbits=True) == 20 * (1 << 10)
    assert human_to_bytes('20KB') == human

# Generated at 2022-06-20 16:35:29.680849
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, unit='K') == '0.00 KB'
    assert bytes_to_human(1, unit='M') == '0.00 MB'
    assert bytes_to_human(1, unit='G') == '0.00 GB'
    assert bytes_to_human(1, unit='T') == '0.00 TB'
    assert bytes_to_human(1, unit='P') == '0.00 PB'
    assert bytes_to_human(1, unit='E') == '0.00 EB'
    assert bytes_to_human(1, unit='Z') == '0.00 ZB'

# Generated at 2022-06-20 16:35:37.757700
# Unit test for function bytes_to_human