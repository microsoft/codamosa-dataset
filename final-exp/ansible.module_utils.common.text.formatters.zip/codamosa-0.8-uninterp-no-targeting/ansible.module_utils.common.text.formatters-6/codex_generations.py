

# Generated at 2022-06-20 16:25:55.492956
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test for bytes
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='B') == '1.00 B'
    assert bytes_to_human(1, unit='b') == '8.00 bits'
    assert bytes_to_human(5000) == '4.88 KB'
    assert bytes_to_human(1000000) == '976.56 KB'
    assert bytes_to_human(1000000000) == '953.67 MB'
    assert bytes_to_human(1000000000000) == '931.32 GB'
    assert bytes_to_human(1000000000000000) == '909.49 TB'
    assert bytes_to_human(1000000000000000000) == '888.18 PB'

# Generated at 2022-06-20 16:26:03.997338
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1', 'b') == 1
    assert human_to_bytes('1', 'B') == 1

    assert human_to_bytes('1', 'b', True) == 1
    assert human_to_bytes('1b', 'b', True) == 1
    assert human_to_bytes('1B', 'b', True) == 8

    assert human_to_bytes('1Mb', 'B', True) == 1048576
    assert human_to_bytes('1M', 'B') == 1048576
    assert human_to_bytes('1MB', 'B') == 1048576
    assert human_to_bytes('1Mb', 'B') == 8388608

    assert human_to_bytes('0.5K', 'B') == 500

# Generated at 2022-06-20 16:26:06.402739
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input = ['foo', 'Bar', 'BAZ', 1, True, ]
    output = ['foo', 'bar', 'baz', 1, True, ]
    assert(output == lenient_lowercase(input))


# Generated at 2022-06-20 16:26:14.404438
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:26:21.394349
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(3.21, unit='G') == '3.21 GBytes'
    assert bytes_to_human(3.21, unit='K') == '3200.00 KBytes'
    assert bytes_to_human(3.21, unit='M') == '3.21 MBytes'
    assert bytes_to_human(3.21, unit='B') == '3 Bytes'
    assert bytes_to_human(3.21, unit='G', isbits=True) == '3.21 Gbits'
    assert bytes_to_human(3.21, unit='K', isbits=True) == '3200.00 Kbits'
    assert bytes_to_human(3.21, unit='M', isbits=True) == '3.21 Mbits'

# Generated at 2022-06-20 16:26:25.018966
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_list = ['abc', 'DEF', '123', 'aBc', 'DeF', '456']
    expected_output = ['abc', 'def', 123, 'abc', 'def', 456]
    assert lenient_lowercase(input_list) == expected_output


# Tests for the human_to_bytes function

# Generated at 2022-06-20 16:26:37.208528
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, isbits=True) == '1.00 bits'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, isbits=True) == '10.00 bits'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, isbits=True) == '8.00 Kb'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048576, isbits=True) == '8.00 Mb'
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human

# Generated at 2022-06-20 16:26:49.140594
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test bytes
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('3K') == 3 * 1024
    assert human_to_bytes('3k') == 3 * 1024
    assert human_to_bytes('20M') == 20 * 1024 * 1024
    assert human_to_bytes('20m') == 20 * 1024 * 1024
    assert human_to_bytes('1G') == 1 * 1024 * 1024 * 1024
    assert human_to_bytes('1g') == 1 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1K') == 1.1 * 1024
    assert human_to_bytes('1.1k') == 1.1 * 1024
    assert human_to

# Generated at 2022-06-20 16:26:59.494998
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('Unit test for function human_to_bytes:')

# Generated at 2022-06-20 16:27:08.338527
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([10, 'A', 'B', 'C', 1]) == [10, 'a', 'b', 'c', 1]
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase([10, 'a', 'b', 'c', 1]) == [10, 'a', 'b', 'c', 1]

# Generated at 2022-06-20 16:27:16.662234
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10.1') == 10
    assert human_to_bytes('10.9') == 10
    assert human_to_bytes('1k') == 1000
    assert human_to_bytes('10k') == 10000
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('10m') == 10000000
    assert human_to_bytes('10M') == 10485760

    # 10^6 bits == '10Mb'
    assert human_to_bytes('10Mb', isbits=True) == 1000000
    assert human_to_bytes('20Mb', isbits=True) == 2000000

    # 10^6 bits == '10MB'


# Generated at 2022-06-20 16:27:22.301235
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1024, unit='KB') == '1.00 KB'
    assert bytes_to_human(1024, unit='bits') == '1.00 bits'
    assert bytes_to_human(1024, isbits=True, unit='b') == '1.00 b'

# Generated at 2022-06-20 16:27:32.786723
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test for bytes
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1023) == '1023.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1023) == '1023.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1023) == '1023.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1023) == '1023.00 GB'

# Generated at 2022-06-20 16:27:35.864147
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['a', 'b', 'c', 1, 2]
    lowered = ['a', 'b', 'c', 1, 2]

    assert lenient_lowercase(lst) == lowered



# Generated at 2022-06-20 16:27:38.535007
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['A', 1, 'B', 2]) == ['a', 1, 'b', 2])



# Generated at 2022-06-20 16:27:47.976224
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024, unit="TB") == '90.51 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024, unit="YB") == '1.00 YB'

    assert bytes_to_human((1024 * 1024 * 1024 * 1024 * 1024) / 10) == '100.00 PB'
    assert bytes_to_human((1024 * 1024 * 1024 * 1024 * 1024) / 10, unit="TB") == '9051.20 TB'

# Generated at 2022-06-20 16:27:50.945825
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Upper', 'Lower', 1]) == ['upper', 'lower', 1]


# Generated at 2022-06-20 16:28:00.069041
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:28:09.007570
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:28:20.560273
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2Kb') == 2048
    assert human_to_bytes('2KB') == 2048
    assert human_to_bytes('2kB') == 2048
    assert human_to_bytes('2kb') == 2048
    assert human_to_bytes('2kb', isbits=True) == 2048
    assert human_to_bytes('2Mb', isbits=True) == 2 * 1024 * 1024
    assert human_to_bytes('2KB', isbits=True) == 2048 * 8
    assert human_to_bytes('1M', unit='b') == 8 * 1024 * 1024
    assert human_to_bytes('2M', unit='b') == 16 * 1024 * 1024


# Generated at 2022-06-20 16:28:36.891239
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(3) == '3.00 Bytes'
    assert bytes_to_human(3, unit="B") == '3.00 Bytes'
    assert bytes_to_human(3, unit="b") == '3.00 Bytes'
    assert bytes_to_human(1023) == '1023.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, unit="K") == '1.00 KB'
    assert bytes_to_human(1024, unit="k") == '1.00 KB'
    assert bytes_to_human(1024 * 1024, unit="K") == '1024.00 KB'
    assert bytes_to_human(2048, unit="K") == '2.00 KB'
    assert bytes_

# Generated at 2022-06-20 16:28:47.206801
# Unit test for function human_to_bytes
def test_human_to_bytes():
    def test(args, expected_value, expected_error=None):
        try:
            value = human_to_bytes(args[0], args[1] if len(args) > 1 else None, args[2] if len(args) > 2 else False)
            print(value)
            if expected_error is not None:
                raise AssertionError("Expected ValueError was not raised")
        except ValueError:
            if expected_error is None:
                raise
        else:
            assert value == expected_value, "Expected: %s, Actual: %s" % (expected_value, value)

    test(['7G', 'c', True], 784751695360, "7Gc bit")
    test(['7G', 'c'], 7847516953600, "7Gc")
    test

# Generated at 2022-06-20 16:28:53.508540
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['WE', 'LOVE', 'TESTS']) == ['we', 'love', 'tests']
    assert lenient_lowercase(['WE', 'LOVE', None]) == ['we', 'love', None]
    assert lenient_lowercase(['WE', 'LOVE', 0]) == ['we', 'love', 0]


# Generated at 2022-06-20 16:28:56.103763
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]


# Generated at 2022-06-20 16:29:05.814257
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    basic test to check bytes_to_human
    '''
    # general test
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 2
    assert human_to_bytes('2') == 2
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('2.5B') == 3
    assert human_to_bytes('10K') == 10 * 1024
    assert human_to_bytes('2.5K') == round(2.5 * 1024)
    assert human_to_bytes('10M') == 10 * 1024 * 1024
    assert human_to_bytes('2.5M') == round(2.5 * 1024 * 1024)
    assert human_to_bytes('10G') == 10 * 1024 * 1024 * 1024

# Generated at 2022-06-20 16:29:15.040095
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:29:19.199997
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    mixed = [1, '2', 'a', 'B']
    lower = lenient_lowercase(mixed)
    assert mixed == lower
    assert mixed[1] == 2
    assert mixed[2] == 'a'
    assert mixed[3] == 'B'



# Generated at 2022-06-20 16:29:27.433988
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Result should be lowercase
    assert lenient_lowercase(['red', 'GREEN', 'Blue']) == ['red', 'green', 'blue']

    # Result should be empty list
    assert lenient_lowercase([]) == []

    # Input list should be unmodified
    x = ['red', 'GREEN', 'Blue']
    y = lenient_lowercase(x)
    assert x == ['red', 'GREEN', 'Blue']
    assert y == ['red', 'green', 'blue']

    # Result should be empty list
    assert lenient_lowercase([None]) == [None]
    assert lenient_lowercase([1]) == [1]
    assert lenient_lowercase(['red', None]) == ['red', None]



# Generated at 2022-06-20 16:29:38.524459
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test if mixed list is lower cased
    mixedlist = [True, 'string', '2', 3, False, 'mixed']
    mixedlist = lenient_lowercase(mixedlist)
    assert mixedlist == [True, 'string', '2', 3, False, 'mixed']

    # Test if lower cased list is not changed
    normallist = [3, 'string', '2', True, 'mixed', False]
    normallist = lenient_lowercase(normallist)
    assert normallist == [3, 'string', '2', True, 'mixed', False]

    # Test if upper cased list is lower cased
    upperlist = [3, 'STRING', '2', True, 'MIXED', False]
    upperlist = lenient_lowercase(upperlist)

# Generated at 2022-06-20 16:29:43.062137
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    for arg in (None, 1, ['a', 'b'], {'a': 1, 'b': 2}, 5.0):
        assert arg == lenient_lowercase(arg)
    assert ['a', 'b', 'c'] == lenient_lowercase(['A', 'B', 'C'])



# Generated at 2022-06-20 16:29:56.224071
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['HeLlO', 1, 'WORLD', 'hello']) == ['hello', 1, 'world', 'hello']


# Generated at 2022-06-20 16:30:04.752792
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10240) == '10.00 KB'
    assert bytes_to_human(10240, unit='b') == '0.01 KB'
    assert bytes_to_human(10240, unit='B') == '10.00 KB'
    assert bytes_to_human(10240, unit='G') == '0.01 GB'
    assert bytes_to_human(10240, unit='M') == '0.01 MB'
    assert bytes_to_human(10240, unit='K') == '10.00 KB'



# Generated at 2022-06-20 16:30:13.464913
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Using the current test setup, the tests are run in an environment where
    # floating point values are represented as float (not Decimal). Therefore
    # floating point multiplication can lead to things such as 0.5 * 2 = 0.9999999999999999, etc.
    # This test ensures that when *using* the function, it works as expected.

    # Base tests

    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 0
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1Kb') == 0
    assert human_to_bytes('1Mb') == 131072
    assert human_to_bytes('1MB') == 0
    assert human_to_bytes('1Gb') == 134217728

# Generated at 2022-06-20 16:30:16.148042
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['1Mb', '1KB', '1M']) == ['1mb', '1kb', '1M']

# Generated at 2022-06-20 16:30:21.172802
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(100) == "100 Bytes"
    assert bytes_to_human(1024) == "1.00 KBytes"
    assert bytes_to_human(1024 * 1024) == "1.00 MBytes"
    assert bytes_to_human(1024 * 1024 * 1024) == "1.00 GBytes"
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == "1.00 TBytes"


# Generated at 2022-06-20 16:30:32.689975
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test for bytes as input
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b') == 10

    # Test for KiloBytes as input
    assert human_to_bytes('3KB') == 3072
    assert human_to_bytes('3KB', isbits=True) == 3072 * 8
    assert human_to_bytes('3Kb') == 3072 * 8
    assert human_to_bytes('3Kb', isbits=True) == 3072 * 8

    # Test for MegaBytes as input
    assert human_to_bytes('2MB') == 2097152
    assert human_to_bytes('2MB', isbits=True) == 2097152 * 8
    assert human_to_bytes('2Mb') == 2097152 * 8

# Generated at 2022-06-20 16:30:44.781645
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2') == 2
    assert human_to_bytes('2B') == 2
    assert human_to_bytes('2b') == 2
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2k') == 2048
    assert human_to_bytes('2KB') == 2048
    assert human_to_bytes('2Kb') == 2048
    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('2m') == 2097152
    assert human_to_bytes('2MB') == 2097152
    assert human_to_bytes('2Mb') == 2097152
    assert human_to_bytes('2G') == 2147483648
    assert human_to_bytes('2g') == 2147483648


# Generated at 2022-06-20 16:30:56.324947
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='b') == '1.00 bit'
    assert bytes_to_human(1, isbits=True) == '1.00 bits'
    assert bytes_to_human(1, isbits=True, unit='b') == '1.00 bits'

    assert bytes_to_human(1 * SIZE_RANGES['K']) == '1.00 KBytes'
    assert bytes_to_human(1 * SIZE_RANGES['K'], unit='b') == '1.00 Kbit'
    assert bytes_to_human(1 * SIZE_RANGES['K'], isbits=True) == '1.00 Kbits'

# Generated at 2022-06-20 16:31:02.789939
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # test with mixed case and non-string values
    assert lenient_lowercase(["foo", 1, "BaR", 2, "bar"]) == ["foo", 1, "BaR", 2, "bar"]
    assert lenient_lowercase(["FOO", 1, "BaR", 2, "bar"]) == ["foo", 1, 1, "bar", 2, "bar"]



# Generated at 2022-06-20 16:31:13.140871
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['Z', 'Y', 'X']) == ['z', 'y', 'x']
    assert lenient_lowercase(['Z', 'Y', 'X', [1, 2]]) == ['z', 'y', 'x', [1, 2]]

# Generated at 2022-06-20 16:31:39.012078
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["FOO", "bar", 1]) == ["foo", "bar", 1]
    assert lenient_lowercase(["FOO", "", 1]) == ["foo", "", 1]

# Unit tests for function human_to_bytes

# Generated at 2022-06-20 16:31:43.440401
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 1, 'b', 2]) == ['a', 1, 'b', 2]
    assert lenient_lowercase([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert lenient_lowercase(['A', 'B', 'C', 'D']) == ['a', 'b', 'c', 'd']



# Generated at 2022-06-20 16:31:54.572717
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_data = [
        ('1Y', 1 << 80),
        ('1Z', 1 << 70),
        ('1E', 1 << 60),
        ('1P', 1 << 50),
        ('1T', 1 << 40),
        ('1G', 1 << 30),
        ('1M', 1 << 20),
        ('1K', 1 << 10),
        ('1B', 1),
        ('1Y', 1 << 80),
        ('1Z', 1 << 70),
        ('1E', 1 << 60),
        ('1P', 1 << 50),
        ('1T', 1 << 40),
        ('1G', 1 << 30),
        ('1M', 1 << 20),
        ('1K', 1 << 10),
        ('1B', 1),
        ('100', 100),
        ('1', 1)
    ]

# Generated at 2022-06-20 16:32:02.889277
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:32:09.393039
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1328) == '1.30 KB'
    assert bytes_to_human(100) == '100.00 Bytes'
    assert bytes_to_human(1048576, True) == '8.00 Mbits'
    assert bytes_to_human(1328, True) == '10.56 Kbits'
    assert bytes_to_human(100, True) == '800.00 bits'


# Generated at 2022-06-20 16:32:12.872891
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_data1 = ['Hello', 'world', 123, '!']
    assert lenient_lowercase(test_data1) == ['hello', 'world', 123, '!']



# Generated at 2022-06-20 16:32:17.493555
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    l = lenient_lowercase(['a', 1, 'b', None, 'c'])
    assert l == ['a', 1, 'b', None, 'c']


# Unit tests for function human_to_bytes

# Generated at 2022-06-20 16:32:23.012148
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(2) == '2.00 Bytes'
    assert bytes_to_human(2, unit='b') == '16.00 bits'
    assert bytes_to_human(2, isbits=True) == '16.00 bits'
    assert bytes_to_human(2, unit='b', isbits=True) == '16.00 bits'



# Generated at 2022-06-20 16:32:29.112713
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Foo', 2, 'bar', 'FOO']) == ['foo', 2, 'bar', 'FOO']
    assert lenient_lowercase(['Foo', 'bar', 'FOO']) == ['foo', 'bar', 'FOO']



# Generated at 2022-06-20 16:32:37.698216
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Unit test for function human_to_bytes.

    To be used when the function is changed."""

    def report_diff(actual, expected):
        diff = []
        for a_key, a_val in iteritems(actual):
            if a_key not in expected:
                diff.append("missing key: %s" % a_key)
            else:
                if expected[a_key] != a_val:
                    diff.append("%s: %s != %s" % (a_key, a_val, expected[a_key]))
        for a_key, a_val in iteritems(expected):
            if a_key not in actual:
                diff.append("missing key: %s" % a_key)
        if diff:
            raise AssertionError("\n".join(diff))


# Generated at 2022-06-20 16:33:09.435190
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024, False) == "1.00 KB"
    assert bytes_to_human(2048, False) == "2.00 KB"
    assert bytes_to_human(2048, False, 'K') == "2.00 K"
    assert bytes_to_human(4096, True) == "4.00 Kb"
    assert bytes_to_human(4096, True, 'K') == "4.00 K"
    assert bytes_to_human(4096, True, 'M') == "0.00 M"
    assert bytes_to_human(1024, True, 'Kb') == "1.00 K"
    assert bytes_to_human(1024, True, 'MB') == "0.00 M"

# Generated at 2022-06-20 16:33:11.404553
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['abc', 4, 'CDE']) == ['abc', 4, 'cde']


# Generated at 2022-06-20 16:33:19.273768
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test with just a number
    assert human_to_bytes('10') == 10

    # test with bytes
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10bytes') == 10
    assert human_to_bytes('10Bytes') == 10
    assert human_to_bytes('10byte') == 10
    assert human_to_bytes('10Byte') == 10
    assert human_to_bytes('10bYtEs') == 10
    assert human_to_bytes('10BYTES') == 10
    assert human_to_bytes('10a') == 10

    # test with kiloBytes
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1k') == 1024
    assert human_to

# Generated at 2022-06-20 16:33:26.132553
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10Gb') == 10737418240
    assert human_to_bytes('10G') == 10737418240
    assert human_to_bytes('10G', 'b') == 85899345920
    assert human_to_bytes('10G', 'B') == 10737418240
    assert human_to_bytes('2.5k') == 2560
    assert human_to_bytes('2.5k', 'B') == 2560
    assert human_to_bytes('2.5kb') == 2560
    assert human_to_bytes('2.5kb', 'b') == 2560
    assert human_to_bytes('2.5k', 'b') == 2560

# Generated at 2022-06-20 16:33:27.510072
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [None, "foo", "bar", True, 1]
    assert [None, "foo", "bar", True, 1] == lenient_lowercase(lst)



# Generated at 2022-06-20 16:33:33.517272
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['aBc', '123', 'xyZ']) == ['abc', '123', 'xyz']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase(['123.45']) == ['123.45']
    assert lenient_lowercase([['a', 'b']]) == [['a', 'b']]


# Generated at 2022-06-20 16:33:39.315861
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Setup
    test_list = [
        {'input': [], 'output': []},
        {'input': ['Test'], 'output': ['test']},
        {'input': ['Test', None, 'any'], 'output': ['test', None, 'any']},
    ]

    # Execution
    for test in test_list:
        result = lenient_lowercase(test['input'])

        # Checking
        assert result == test['output']



# Generated at 2022-06-20 16:33:51.333374
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test number using 'B' as a byte identifier
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('0B') == 0
    assert human_to_bytes('0b') == 0
    assert human_to_bytes('0.1B') == 0
    assert human_to_bytes('0.1b') == 0
    assert human_to_bytes(10) == 10
    assert human_to_bytes(10.0) == 10
    assert human_to_bytes(10.1) == 10
    assert human_to_bytes(10.9) == 10

    # test number using 'Eb' as a bit identifier
    assert human_to_bytes('10Eb', isbits=True) == 1250000000000
    assert human_

# Generated at 2022-06-20 16:34:01.021305
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [
        'HELLO',
        {'world': 'WORLD'},
        ['foo', 'bar', 'baz'],
        ['FOO', 'BAR', {'BAZ': 'Baz'}],
    ]
    ans = [
        'hello',
        {'world': 'WORLD'},
        ['foo', 'bar', 'baz'],
        ['foo', 'bar', {'BAZ': 'Baz'}],
    ]

    assert lenient_lowercase(lst) == ans



# Generated at 2022-06-20 16:34:02.416352
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert list(lenient_lowercase(('abc', 1))) == ['abc', 1]
    assert list(lenient_lowercase(['abc', 1])) == ['abc', 1]

# Generated at 2022-06-20 16:34:24.592992
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ["Abc", "DEF", 10, "Hello"]
    expected_list = ["abc", "def", 10, "Hello"]
    result_list = lenient_lowercase(test_list)
    assert result_list == expected_list

# Generated at 2022-06-20 16:34:35.032445
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1Yb') == 1208925819614629174706176
    assert human_to_bytes('1ZB') == 1180591620717411303424
    assert human_to_bytes('1eb') == 1208925819614629174706176
    assert human_to_bytes('1pb') == 1125899906842624
    assert human_to_bytes('1TB') == 1099511627776
    assert human_to_bytes(1, 'GB') == 1073741824
    assert human_to_bytes(1, unit='GB') == 1073741824
    assert human_to_bytes('1Mb', isbits=True) == 1048

# Generated at 2022-06-20 16:34:43.041266
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Unit test for human_to_bytes function."""

    # test default unit
    try:
        human_to_bytes('10')
    except Exception as e:
        assert isinstance(e, ValueError)

    try:
        human_to_bytes('10', 'b')
        assert False, 'human_to_bytes("10", "b") must throw an exception'
    except Exception as e:
        assert isinstance(e, ValueError)

    # test positive cases
    assert human_to_bytes('10', 'b') == 10
    assert human_to_bytes('10', 'bit') == 10
    assert human_to_bytes('1K', 'b') == 1024
    assert human_to_bytes('6Kb') == 6144
    assert human_to_bytes('1kb', 'bit') == 1024

# Generated at 2022-06-20 16:34:51.181487
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """Performs a set of tests to validate that bytes_to_human is working properly.

    function: bytes_to_human
    """

# Generated at 2022-06-20 16:35:03.815545
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Unit test for function human_to_bytes '''

    # test single bit case
    assert human_to_bytes('1b') == 0
    # test human_to_bytes with bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1234B') == 1234
    assert human_to_bytes(1234) == 1234
    # test KB
    assert human_to_bytes('1KB') == 1000
    assert human_to_bytes('1Kb') == 1000
    assert human_to_bytes('0.001KB') == 1
    assert human_to_bytes('0.001Kb') == 1
    assert human_to_bytes('1.234KB') == 1234
    assert human_to_bytes('1.234Kb') == 1234
    # test MB


# Generated at 2022-06-20 16:35:11.153180
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_list = ['yE', 'yes', 'YES', 'No', 'no', 'nO', '', True, False, None]
    output_list = lenient_lowercase(input_list)
    expected_output_list = ['ye', 'yes', 'yes', 'no', 'no', 'no', '', True, False, None]
    assert output_list == expected_output_list, "Expected %s, but got %s" % (expected_output_list, output_list)

# Unit tests for functions bytes_to_human and human_to_bytes

# Generated at 2022-06-20 16:35:18.312936
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    This function is for unit test for function human_to_bytes
    human_to_bytes() does 3 things:
        1. convert from human readable string to bytes.
        2. convert from human readable string to bits (when isbits=True)
        3. convert from number to bytes (for example: human_to_bytes(10, 'm') => 10485760)
    '''
    print("\tUnit test for function human_to_bytes():\n")
    success = True
    print("\t\t1. Convert from human readable string to bytes:")
    human_readable_strings = [('10M', 10485760), ('3.14M', 3314810), ('10MB', 10485760), ('10MB', 10485760)]

# Generated at 2022-06-20 16:35:28.938166
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """ Unit test for bytes_to_human
    >>> assert bytes_to_human(1024) == '1.00 KBytes'
    >>> assert bytes_to_human(1234) == '1.21 KBytes'
    >>> assert bytes_to_human(1234, unit='k') == '1.21 kBytes'
    >>> assert bytes_to_human(1234, unit='k', isbits=True) == '1.21 Kbits'
    >>> assert bytes_to_human(1234, 'k') == '1.21 kBytes'
    >>> assert bytes_to_human(1234, 'k', isbits=True) == '1.21 Kbits'
    """



# Generated at 2022-06-20 16:35:33.516398
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    l1 = ['A', 'B', 'C']
    assert lenient_lowercase(l1) == ['a', 'b', 'c']

    l2 = ['X', 'Y', 42, 123, {'a': 'd'}]
    assert lenient_lowercase(l2) == ['x', 'y', 42, 123, {'a': 'd'}]

# Generated at 2022-06-20 16:35:43.895838
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print("Testing function bytes_to_human()")
    status = 0
    result = bytes_to_human(10)
    if result != '10.00 Bytes':
        status = 1
        print("Test failed: 10 bytes -> %s instead of 10 Bytes" % result)

    result = bytes_to_human(10, unit='K')
    if result != '0.01 KB':
        status = 1
        print("Test failed: 10 bytes -> %s instead of 0.01 KB" % result)

    result = bytes_to_human(10, unit='k')
    if result != '0.01 KB':
        status = 1
        print("Test failed: 10 bytes -> %s instead of 0.01 KB" % result)

    result = bytes_to_human(10, unit='Kb')