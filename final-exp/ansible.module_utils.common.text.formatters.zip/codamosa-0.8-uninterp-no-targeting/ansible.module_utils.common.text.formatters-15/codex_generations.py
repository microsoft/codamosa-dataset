

# Generated at 2022-06-20 16:25:53.051176
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:26:02.006212
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:26:09.266693
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'c']) == ['a', 1, 'c']
    assert lenient_lowercase([u'A', u'B', u'c']) == ['a', 'b', 'c']
    assert lenient_lowercase([u'A', 1, u'c']) == ['a', 1, 'c']



# Generated at 2022-06-20 16:26:16.227660
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == "10.00 Bytes"
    assert bytes_to_human(1023) == "1023.00 Bytes"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1000000) == "976.56 KB"
    assert bytes_to_human(1000000000) == "953.67 MB"
    assert bytes_to_human(1000000000000) == "931.32 GB"
    assert bytes_to_human(1000000000000000) == "909.49 TB"
    assert bytes_to_human(1000000000000000000) == "888.18 PB"


# Generated at 2022-06-20 16:26:26.119880
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:26:35.493255
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_data = [
        [1, 2, 3],
        [1, 'b', 3],
        ['A', 2, 'C'],
        ['A', 'b', 'C'],
    ]

    expected_results = [
        [1, 2, 3],
        [1, 'b', 3],
        ['a', 2, 'c'],
        ['a', 'b', 'c'],
    ]

    for i in range(len(test_data)):
        assert lenient_lowercase(test_data[i]) == expected_results[i]


# Generated at 2022-06-20 16:26:44.594281
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, unit='b') == '10.00 bits'
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(10, unit='KB') == '0.01 KB'
    assert bytes_to_human(1024 * 0.5) == '0.50 KB'
    assert bytes_to_human(1024 * 0.5, unit='b') == '0.50 Kb'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024, unit='B') == '1.00 MB'
    assert bytes_to_human(1024, unit='Mc') == '0.00 Mc'

# Generated at 2022-06-20 16:26:55.823659
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048576, unit='K') == '1024.00 KB'
    assert bytes_to_human(1048576, unit='b') == '8388608.00 bits'
    assert bytes_to_human(1048576, isbits=True) == '8388608.00 bits'
    assert bytes_to_human(1048576, unit='kb') == '8388608.00 bits'
    assert bytes_to_human(1048576, unit='kB') == '1024.00 KB'
    assert bytes_to_human(1048576, unit='k') == '1024.00 KB'

# Generated at 2022-06-20 16:26:58.515434
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['str1', 'str2', 1, {'key': 'val'}]) == ['str1', 'str2', 1, {'key': 'val'}]



# Generated at 2022-06-20 16:27:04.827163
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_test = ["A", "B", "c", "d", "E", "F", 1, 2, 3, 4, 5]
    assert lenient_lowercase(list_test) == ["a", "b", "c", "d", "e", "f", 1, 2, 3, 4, 5]


# Generated at 2022-06-20 16:27:09.792325
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test = ['TEST_VAL1', 'Test_Val2', 1234]
    assert lenient_lowercase(test) == ['test_val1', 'test_val2', 1234]



# Generated at 2022-06-20 16:27:15.263566
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(range(5)) == [0, 1, 2, 3, 4]
    assert lenient_lowercase(['a', 'b', 'C', 3]) == ['a', 'b', 'C', 3]
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['a', 'b', 'C', [1, 2, 3]]) == ['a', 'b', 'C', [1, 2, 3]]

# Generated at 2022-06-20 16:27:24.198966
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(24000, None) == '24.00 KBytes'
    assert bytes_to_human(1048576, None) == '1.00 MBytes'
    assert bytes_to_human(1073741824, None) == '1.00 GBytes'
    assert bytes_to_human(1099511627776, None) == '1.00 TBytes'
    assert bytes_to_human(1125899906842624, None) == '1.00 PBytes'
    assert bytes_to_human(1152921504606846976, None) == '1.00 EBytes'
    assert bytes_to_human(1180591620717411303424, None) == '1.00 ZBytes'

# Generated at 2022-06-20 16:27:30.860224
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert [] == lenient_lowercase([])
    assert ['a', 1, 'b', 2] == lenient_lowercase(['a', 1, 'b', 2])
    assert ['a', '1', 'b', '2'] == lenient_lowercase(['A', '1', 'B', '2'])
    assert ['a', '1', 'b', '2'] == lenient_lowercase(['a', '1', 'b', '2'])

# Generated at 2022-06-20 16:27:42.174173
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:27:50.321580
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('100') == 100)
    assert(human_to_bytes('100b') == 100)
    assert(human_to_bytes('100b', isbits=True) == 100)
    assert(human_to_bytes('100B') == 100)
    assert(human_to_bytes('100B', isbits=True) == 100)
    assert(human_to_bytes('100KB') == 100*100)
    assert(human_to_bytes('100KB', isbits=True) == 100*100)
    assert(human_to_bytes('100Kb') == 100*100)
    assert(human_to_bytes('100Kb', isbits=True) == 100*100)
    assert(human_to_bytes('100MB') == 100*100*100)

# Generated at 2022-06-20 16:27:57.238756
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1MB') == 1024 * 1024
    assert human_to_bytes('1Mb') == 1024 * 1024
    assert human_to_bytes('1Mb', isbits=True) == 1024 * 1024
    assert human_to_bytes('1ZZ') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-20 16:28:07.683307
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test with bits suffix
    assert bytes_to_human(4096, isbits=True) == '32.00 bits'
    assert bytes_to_human(4096, isbits=True, unit='b') == '32.00 bits'
    assert bytes_to_human(4096, isbits=True, unit='k') == '32.00 Kb'
    assert bytes_to_human(4096, isbits=True, unit='M') == '0.00 Mb'
    assert bytes_to_human(4096, isbits=True, unit='G') == '0.00 Gb'

    # Test with bytes suffix
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048576, unit='B') == '1.00 MB'
    assert bytes

# Generated at 2022-06-20 16:28:18.901677
# Unit test for function bytes_to_human
def test_bytes_to_human():
    result = bytes_to_human(1)
    assert '1 Bytes' == result

    result = bytes_to_human(1, unit='B')
    assert '1 Bytes' == result

    result = bytes_to_human(2048, unit='KB')
    assert '2.00 KB' == result

    result = bytes_to_human(2048, unit='Kb')
    assert '2.00 Kb' == result

    result = bytes_to_human(2048, isbits=True, unit='KB')
    assert '16.00 Kb' == result

    result = bytes_to_human(2048, isbits=True, unit='Kb')
    assert '16.00 Kb' == result



# Generated at 2022-06-20 16:28:30.365605
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(10, unit='b') == '80 bits'
    assert bytes_to_human(10, isbits=True, unit='B') == '80 bits'
    assert bytes_to_human(10, isbits=True, unit='b') == '80 bits'
    assert bytes_to_human(10, isbits=True, unit='k') == '80 bits'
    assert bytes_to_human(1, isbits=True, unit='b') == '8 bits'
    assert bytes_to_human(1, isbits=True, unit='B') == '8 bits'
    assert bytes_to_human(1, isbits=True, unit='k') == '8 bits'

# Generated at 2022-06-20 16:28:45.396197
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(2) == 2
    assert human_to_bytes(2, unit='B') == 2
    assert human_to_bytes(2, 'B') == 2
    assert human_to_bytes(2, 'K') == 2 * 1024
    assert human_to_bytes(2, 'Kb') == 2 * 1024
    assert human_to_bytes(2, 'kB') == 2 * 1024
    assert human_to_bytes(2, 'Kb', isbits=True) == 2 * 1024
    assert human_to_bytes(2, 'KB', isbits=True) == 2 * 1024 * 8
    assert human_to_bytes(2, isbits=True) == 2
    assert human_to_bytes(2, default_unit='Kb', isbits=True) == 2 * 1024
    assert human_

# Generated at 2022-06-20 16:28:52.213620
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test = ['this', 'is', 'upper', 'CASE']
    assert(['this', 'is', 'upper', 'case'] == lenient_lowercase(test))
    test.append(['or', 'not'])
    assert(['this', 'is', 'upper', 'case', ['or', 'not']] == lenient_lowercase(test))



# Generated at 2022-06-20 16:29:00.494543
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['aa', 'BB', 'CC', ['DD', 'EE', 'FF']]
    lst_lowercased = lenient_lowercase(lst)
    assert lst_lowercased[0] == 'aa'
    assert lst_lowercased[1] == 'bb'
    assert lst_lowercased[2] == 'cc'
    assert lst_lowercased[3][0] == 'DD'
    assert lst_lowercased[3][1] == 'EE'
    assert lst_lowercased[3][2] == 'FF'


# Generated at 2022-06-20 16:29:10.994230
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:29:22.544226
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:29:30.095820
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:29:34.323696
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_test = ['A', 1, 'B', 2, 'C']
    list_result = ['a', 1, 'b', 2, 'c']

    assert list_result == lenient_lowercase(list_test)



# Generated at 2022-06-20 16:29:41.207170
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import random
    units = ''.join(SIZE_RANGES.keys())
    for i in range(100):
        count = random.randint(0, 100000)
        unit = random.choice(units)
        data = "%d%s" % (count, unit)
        result = human_to_bytes(data)
        assert result == int(round(count * SIZE_RANGES[unit])), "Error converting '%s', result %d != %d" % (data, result, int(round(count * SIZE_RANGES[unit])))


if __name__ == "__main__":
    test_human_to_bytes()

# Generated at 2022-06-20 16:29:50.965233
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1.5Mb') == 1572864
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('.5M') == 524288
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5', default_unit='M') == 1572864
    assert human_to_bytes('1500K') == 1572864
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5k') == 1536
    assert human_to_bytes('1.5B') == 1
    assert human_to_bytes('1.5b') == 1



# Generated at 2022-06-20 16:29:56.571457
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:30:10.947412
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.5') == 2
    assert human_to_bytes('1.6') == 2
    assert human_to_bytes('1.5B') == 2
    assert human_to_bytes('1.6b') == 2

    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1.0Kb') == 1024

# Generated at 2022-06-20 16:30:20.895289
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert (1048576 == human_to_bytes('1M'))
    assert (1048576 == human_to_bytes('1048576'))

    assert (1048576 == human_to_bytes('1M', 'b', isbits=True))
    assert (1048576 == human_to_bytes('1048576', 'b', isbits=True))

    assert (1048576 == human_to_bytes('1MB', isbits=False))
    assert (1048576 == human_to_bytes('1MB', isbits=True))

    assert (1048576 == human_to_bytes('1MB', 'B', isbits=False))
    assert (1048576 == human_to_bytes('1MB', 'b', isbits=True))


# Generated at 2022-06-20 16:30:32.419221
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(100) == '100.00 Bytes'
    assert bytes_to_human(100, unit='B') == '100.00 Bytes'
    assert bytes_to_human(100, unit='B', isbits=True) == '0.00 bits'
    assert bytes_to_human(100, isbits=True) == '0.00 bits'
    assert bytes_to_human(1000) == '1.00 KB'
    assert bytes_to_human(1000, unit='B') == '1000.00 Bytes'
    assert bytes_to_human(1000, isbits=True) == '0.01 Kb'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, unit='B') == '1024.00 Bytes'
   

# Generated at 2022-06-20 16:30:37.122605
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'C', 'D', 123, True]) == ['a', 'b', 'c', 'd', 123, True]


# Generated at 2022-06-20 16:30:46.430059
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == "0.00 Bytes"
    assert bytes_to_human(0.9) == "0.90 Bytes"
    assert bytes_to_human(1) == "1.00 Bytes"
    assert bytes_to_human(1.9) == "1.90 Bytes"
    assert bytes_to_human(1, isbits=True) == "1.00 bits"
    assert bytes_to_human(1.9, isbits=True) == "1.90 bits"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1048576) == "1.00 MB"
    assert bytes_to_human(1073741824) == "1.00 GB"

# Generated at 2022-06-20 16:30:57.423752
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KBytes'
    assert bytes_to_human(1024, unit='k') == '1.00 KBytes'
    assert bytes_to_human(1024, unit='K') == '1.00 KBytes'
    assert bytes_to_human(1024, unit='KB') == '1.00 KB'
    assert bytes_to_human(1024, unit='Kb') == '1.00 Kb'
    assert bytes_to_human(1024, unit='b') == '1024.00 b'
    assert bytes_to_human(1024, unit='B') == '1024.00 B'
    assert bytes_to_human(1024, isbits=True) == '8.00 Kbits'

# Generated at 2022-06-20 16:31:02.480287
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['abc', 1234]) == ['abc', 1234]
    assert lenient_lowercase(['AbC', 5678]) == ['abc', 5678]
    assert lenient_lowercase(['ABC', 'XYZ']) == ['abc', 'xyz']



# Generated at 2022-06-20 16:31:09.527734
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2k') == 2048
    assert human_to_bytes('2048') == 2048
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1572864') == 1572864
    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('2Mb') == 2097152
    assert human_to_bytes('2MB') == 2097152
    assert human_to_bytes('2MB', isbits=True) == 2097152
    assert human_to_bytes('2b') == 2
    assert human_to_bytes('2') == 2
    assert human_to_bytes('2.0') == 2
    assert human_to_bytes('.3M') == 314572

# Generated at 2022-06-20 16:31:15.169844
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [
        'test_string',
        'test_string_1',
        'test_string_2',
        100,
        200,
        300,
    ]

    result = lenient_lowercase(test_list)

    assert result == [
        'test_string',
        'test_string_1',
        'test_string_2',
        100,
        200,
        300,
    ]


# Generated at 2022-06-20 16:31:18.524023
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a','B','C','D']) == ['a','b','c','d']
    assert lenient_lowercase(['aa','B','C','D']) == ['aa','b','c','d']
    assert lenient_lowercase(['aa', 10, 20, 30]) == ['aa', 10, 20, 30]

# Generated at 2022-06-20 16:31:31.066426
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [1, 'a', 'A', 'A', 'b', 'B', 'C', 1]
    correct_list = [1, 'a', 'a', 'a', 'b', 'b', 'c', 1]
    assert correct_list == lenient_lowercase(test_list)

# Generated at 2022-06-20 16:31:39.084542
# Unit test for function bytes_to_human
def test_bytes_to_human():
    tests = [
        {'in': 100000000, 'out': '95 MBytes'},
        {'in': 800000000, 'out': '777 MB'},
        {'in': 80000000000, 'out': '74 GB'},
        {'in': 800000000000, 'out': '737 GB'},
        {'in': 8000000000000, 'out': '70 TB'},
        {'in': 2**80, 'out': '1 YBytes'},
        {'in': 10, 'out': '10 Bytes'},
        {'in': 10000000, 'out': '9.5 MB'},
    ]


# Generated at 2022-06-20 16:31:47.505953
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10M', isbits=True) == 10485760
    assert human_to_bytes('10MB', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760

# Generated at 2022-06-20 16:31:53.736050
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    from nose.tools import assert_list_equal
    assert_list_equal(lenient_lowercase(['a', 'B', 'c']), ['a', 'B', 'c'])
    assert_list_equal(lenient_lowercase(['a', 'B', 'c', 1, 2, 3]), ['a', 'B', 'c', 1, 2, 3])



# Generated at 2022-06-20 16:32:02.400102
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('0') == 0
    assert human_to_bytes(1) == 1
    assert human_to_bytes(0) == 0

    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.5') == 1

    # + unit
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1KB') == human_to_bytes(1, 'KB') == 1024
    assert human_to_bytes('1Kb') == human_to_bytes(1, 'Kb', True) == 1024
    assert human_to_bytes('1MB') == human_to_bytes(1, 'MB') == 1048576
    assert human_to_bytes('1Mb') == human

# Generated at 2022-06-20 16:32:11.243813
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['dog', 'cat', 1, 2]) == ['dog', 'cat', 1, 2]
    assert lenient_lowercase(['dog', 'cat', 'mouse', 1]) == ['dog', 'cat', 'mouse', 1]
    assert lenient_lowercase(['dog', 'cat', 'mouse', 2, 'cat']) == ['dog', 'cat', 'mouse', 2, 'cat']
    assert lenient_lowercase(['Dog', 'Cat', 'Mouse', '1', '2', 'cat']) == ['dog', 'cat', 'mouse', '1', '2', 'cat']
    assert lenient_lowercase(['','Dog', 'Cat', 'Mouse', '1', '2', 'cat']) == ['','dog', 'cat', 'mouse', '1', '2', 'cat']

# Generated at 2022-06-20 16:32:22.603675
# Unit test for function bytes_to_human
def test_bytes_to_human():
    bytes_in_10MB = 10485760  # test value
    bytes_in_10KB = 10240  # test value
    bytes_in_1K = 1024  # test value
    bytes_in_1B = 1  # test value
    bits_in_10MB = 83886080  # test value
    bits_in_10KB = 81920  # test value
    bits_in_1K = 8192  # test value
    bits_in_1B = 8  # test value


# Generated at 2022-06-20 16:32:34.063931
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1020, unit='B') == '1020 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(10**3) == '1.00 KB'
    assert bytes_to_human(10**6) == '1.00 MB'
    assert bytes_to_human(10**9) == '1.00 GB'
    assert bytes_to_human(10**12) == '1.00 TB'
    assert bytes_to_human(10**15) == '1.00 PB'
    assert bytes_to_human(10**18) == '1.00 EB'
    assert bytes_to_human(10**21) == '1.00 ZB'

# Generated at 2022-06-20 16:32:37.191341
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c'])


# Generated at 2022-06-20 16:32:48.630498
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import collections


# Generated at 2022-06-20 16:33:05.418540
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # tests without unit argument
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2k') == 2048
    assert human_to_bytes('2 k') == 2048
    assert human_to_bytes('2KB') == 2048
    assert human_to_bytes('2kb') == 2048
    assert human_to_bytes('2 kB') == 2048
    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('2m') == 2097152
    assert human_to_bytes('2 m') == 2097152
    assert human_to_bytes('2MB') == 2097152
    assert human_to_bytes('2mb') == 2097152
    assert human_to_bytes('2 mB') == 2097152

    # tests with unit
    assert human_

# Generated at 2022-06-20 16:33:13.009952
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert lenient_lowercase([1, 2, '', '', 5]) == [1, 2, '', '', 5]
    assert lenient_lowercase(['One', 'Two', 'Three', 'Four', 'Five']) == ['one', 'two', 'three', 'four', 'five']
    assert lenient_lowercase([1, 2, 'THREE', 'Four', 'Five']) == [1, 2, 'three', 'four', 'five']


# Generated at 2022-06-20 16:33:20.170721
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, unit='K') == '1.00 KB'
    assert bytes_to_human(1024, unit='M') == '0.00 MB'
    assert bytes_to_human(1024, unit='B') == '1024.00 Bytes'
    assert bytes_to_human(1024, unit='b', isbits=True) == '8192.00 bits'
    assert bytes_to_human(1024, unit='Kb', isbits=True) == '8.38 Kb'
    assert bytes_to_human(1024, unit='Mb', isbits=True) == '0.81 Mb'



# Generated at 2022-06-20 16:33:25.703534
# Unit test for function human_to_bytes
def test_human_to_bytes():

    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K', default_unit='B') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1 MB') == 1048576
    assert human_to_bytes('1 Mb') == 1048576
    assert human_to_bytes('1 mb') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1.2Mb') == 1258291
    assert human_

# Generated at 2022-06-20 16:33:36.776056
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:33:48.774907
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.5M', default_unit='B') == 1572864
    assert human_to_bytes('1.5M', default_unit='B', isbits=True) == 1572864
    assert human_to_bytes('1.5M', default_unit='b') == 1572864
    assert human_to_bytes('1.5M', default_unit='b', isbits=True) == 1572864
    assert human_to_bytes('1.5 Gb', default_unit='GB') == 1572864000
    assert human_to_bytes('1.5 Gb', default_unit='GB', isbits=True) == 1572864000
    assert human_to_bytes('1.5 Gb', default_unit='b') == 1572864000

# Generated at 2022-06-20 16:33:55.215857
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("Running unit test for function human_to_bytes ...")

# Generated at 2022-06-20 16:34:05.747502
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10m') == 10 * (1 << 20)
    assert human_to_bytes('10M') == 10 * (1 << 20)
    assert human_to_bytes('10') == 10
    assert human_to_bytes('0') == 0
    assert human_to_bytes('10.5K') == 10.5 * (1 << 10)
    assert human_to_bytes('1.0K') == 1 * (1 << 10)
    assert human_to_bytes('1.2K') == 1.2 * (1 << 10)
    assert human_to_bytes('0.1K') == 1 * (1 << 10) / 10
    assert human_to_bytes('0.1B') == 1 / 10
    assert human_to_bytes('0.1c', default_unit='M') == 1

# Generated at 2022-06-20 16:34:17.491163
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes(1) == 1
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes(1.0, 'M') == 1048576
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes(1.5, 'M') == 1572864
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.0Mb', isbits=True) == 1048576
    assert human_to_bytes(1.0, 'Mb', isbits=True) == 1048576
    assert human_to_bytes('1.2') == 1
    assert human_to_bytes('1.2', unit='M')

# Generated at 2022-06-20 16:34:21.709377
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    strings = ['one', 'Two', 'three', 4, 5]
    expect_list = ['one', 'two', 'three', 4, 5]
    assert lenient_lowercase(strings) == expect_list



# Generated at 2022-06-20 16:34:44.642326
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'

    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(10 * 1024) == '10.00 KB'
    assert bytes_to_human(10 * 1024 ** 2) == '10.00 MB'
    assert bytes_to_human(10 * 1024 ** 3) == '10.00 GB'
    assert bytes_to_human(10 * 1024 ** 4) == '10.00 TB'
    assert bytes_to_human(10 * 1024 ** 5) == '10.00 PB'
    assert bytes_to_human(10 * 1024 ** 6) == '10.00 EB'

# Generated at 2022-06-20 16:34:51.883814
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # For bytes
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1TB') == 1099511627776
    assert human_to_bytes('1PB') == 1125899906842624
    assert human_to_bytes('1EB') == 1152921504606846976

    # For bits
    assert human_to_bytes('1', isbits=True) == 1
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1Tb', isbits=True) == 1099511627776
    assert human

# Generated at 2022-06-20 16:35:04.045916
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(10000) == '9.77 KB'
    assert bytes_to_human(999999, unit='B') == '999.99 KB'
    assert bytes_to_human(999999, unit='b') == '999.99 Kb'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048576, unit='B') == '1.00 MB'
    assert bytes_to_human(1048576, unit='b') == '1.00 Mb'
    assert bytes_to_human(1099511627776) == '1.00 TB'
    assert bytes_to_human(1099511627776, unit='B') == '1.00 TB'
   

# Generated at 2022-06-20 16:35:07.952713
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:35:16.282167
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test the default unit B
    assert human_to_bytes('123') == 123
    assert human_to_bytes(123) == 123
    assert human_to_bytes('123', default_unit='B') == 123
    assert human_to_bytes(123, default_unit='B') == 123
    assert human_to_bytes('123.65') == 123
    assert human_to_bytes(123.65) == 124

    # test defaults (normal cases)
    assert human_to_bytes('1B') == 1

    assert human_to_bytes('1K') == 1 << 10
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024

    assert human_to_bytes('1M') == 1 << 20

# Generated at 2022-06-20 16:35:28.649077
# Unit test for function bytes_to_human
def test_bytes_to_human():
    units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']

    def _test_bytes(i):
        return '%.2f %s' % (i, units[0])

    def _test_bits(i):
        return '%.2f %s' % (i, 'bits')

    def _test_kbytes(i):
        return '%.2f %s' % (i, units[1])

    def _test_mbits(i):
        return '%.2f %s' % (i, 'Mbits')

    # Test default case
    assert bytes_to_human(1000) == _test_bytes(1)
    # Test bytes
    assert bytes_to_human(1000, unit='B') == _test_bytes(1)


# Generated at 2022-06-20 16:35:33.645527
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['foo', 'Bar', 1, 2]) == ['foo', 'Bar', 1, 2]
    assert lenient_lowercase(['Foo', 'bar', 1, 2]) == ['Foo', 'bar', 1, 2]
    assert lenient_lowercase(['FoO', 'bAR', 1, 2]) == ['FoO', 'bAR', 1, 2]