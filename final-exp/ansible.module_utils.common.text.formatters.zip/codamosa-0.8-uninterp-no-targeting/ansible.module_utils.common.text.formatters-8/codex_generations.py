

# Generated at 2022-06-20 16:25:55.533983
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', u'B', 'C']) == ['a', u'B', 'c']
    assert lenient_lowercase(['A', ['B'], 'C']) == ['a', ['B'], 'c']
    assert lenient_lowercase(['A', ['B', u'C'], 'C']) == ['a', ['B', u'C'], 'c']

# Generated at 2022-06-20 16:26:04.030194
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    tests = (
        (['1.1.1.1', '2.2.2.2'], ['1.1.1.1', '2.2.2.2']),
        (['TEST', 'Trial', 'Try', 'FINAL'], ['test', 'trial', 'try', 'final']),
        (['A', 'B', 'C', 'D', 'E'], ['a', 'b', 'c', 'd', 'e']),
        (['1', '2', '3', '4', '5'], ['1', '2', '3', '4', '5']),
        (['TEST', 'Trial', 'Try', 1, 'FINAL'], ['test', 'trial', 'try', 1, 'final']),
        ('TEST', 'TEST'),
    )

# Generated at 2022-06-20 16:26:05.914915
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['hi', 1, 'Bye']
    lowered_list = lenient_lowercase(test_list)
    assert lowered_list == ['hi', 1, 'bye']

# Generated at 2022-06-20 16:26:13.850948
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.0Mb', isbits=True) == 1048576
    assert human_to_bytes('1.0Mb') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB', isbits=True) == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1.0MB', isbits=True) == 1048576
    assert human_to_bytes('1.0MB') == 1048576
    assert human_to_bytes('1.0MB', isbits=True) == 1048576
    assert human_to_bytes('1.0MB') == 1048

# Generated at 2022-06-20 16:26:25.192894
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0, isbits=True) == '0 bits'
    assert bytes_to_human(1, isbits=True) == '1 bit'
    assert bytes_to_human(10, isbits=True) == '10 bits'

    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1023, isbits=True) == '8191 bits'

    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, isbits=True) == '8.00 Kb'

    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024, isbits=True) == '8.00 Mb'

    assert bytes_to_human

# Generated at 2022-06-20 16:26:37.390212
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1') == 1)
    assert(human_to_bytes('2B') == 2)
    assert(human_to_bytes('2b') == 2)
    assert(human_to_bytes('2b', isbits=True) == 2 * 8)
    assert(human_to_bytes('1B') == 1)
    assert(human_to_bytes('1K') == 1 << 10)
    assert(human_to_bytes('2KB') == 1 << 11)
    assert(human_to_bytes('1M') == 1 << 20)
    assert(human_to_bytes('2Kb') == 1 << 11)
    assert(human_to_bytes('2Mb') == 1 << 21)
    assert(human_to_bytes('1G') == 1 << 30)

# Generated at 2022-06-20 16:26:49.181258
# Unit test for function bytes_to_human
def test_bytes_to_human():
    for units in ['MB', 'Mb', 'M', 'm']:
        assert bytes_to_human(1, unit=units) == '1024.00 MB'
        assert bytes_to_human(1, isbits=True, unit=units) == '1024.00 Mb'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, isbits=True) == '8.00 bits'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, isbits=True) == '80.00 bits'
    assert bytes_to_human(100) == '100.00 Bytes'
    assert bytes_to_human(100, isbits=True) == '800.00 bits'
    assert bytes_to

# Generated at 2022-06-20 16:26:53.277976
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    testList = ["EDA", "API", "User"]
    expectedList = ["eda", "api", "User"]

    result = lenient_lowercase(testList)

    assert result == expectedList
    


# Generated at 2022-06-20 16:27:03.385828
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:27:13.633442
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:27:25.269669
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == "1.00 Bytes"
    assert bytes_to_human(2) == "2.00 Bytes"
    assert bytes_to_human(1024) == "1024.00 Bytes"
    assert bytes_to_human(1024, unit="KB") == "1.00 KB"
    assert bytes_to_human(2048, unit="KB") == "2.00 KB"
    assert bytes_to_human(1 << 20, unit="KB") == "1024.00 KB"
    assert bytes_to_human(10 * (1 << 30), unit="KB") == "10240.00 KB"
    assert bytes_to_human(10 * (1 << 30), unit="MB") == "10240.00 MB"

# Generated at 2022-06-20 16:27:35.010335
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Unit test function for function human_to_bytes()'''
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('100GB') == 107374182400
    assert human_to_bytes('100G') == 100000000000
    assert human_to_bytes('50Kb') == 50240
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('5.5kb') == 5632
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('5.5MB') == 5767168
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('5.5Gb') == 5942066688

# Generated at 2022-06-20 16:27:45.611021
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import sys
    import unittest

    # prepare test cases (as a list of tuples)

# Generated at 2022-06-20 16:27:52.333592
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('5.5kb') == 5632

    assert human_to_bytes('1Y', unit='B') == 1024
    assert human_to_bytes('1YB', unit='B') == 1024
    assert human_to_bytes('1Y', unit='K') == 1048576
    assert human_to_bytes('1YB', unit='K') == 1048576

# Generated at 2022-06-20 16:27:57.113524
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # input a list with a mix of strings and integers
    test_input = ['teSt', 1, 'test2', 'TeST3', 4, 5]
    # expected output
    expected_output = ['test', 1, 'test2', 'test3', 4, 5]
    assert lenient_lowercase(test_input) == expected_output



# Generated at 2022-06-20 16:28:02.155956
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['aBcD', 'bcd', u'BCD', bytearray('abcd'), 42]) == ['abcd', 'bcd', 'bcd', bytearray('abcd'), 42]

# Unit tests for function human_to_bytes

# Generated at 2022-06-20 16:28:10.128177
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1) == 1
    assert human_to_bytes(1.0) == 1
    assert human_to_bytes(0.0) == 0
    assert human_to_bytes('0') == 0
    assert human_to_bytes('1') == 1
    assert human_to_bytes('2M') == 2 * 1024 ** 2
    assert human_to_bytes('2Mb') == 2 * 1024 ** 2
    assert human_to_bytes('1M') == 1024 ** 2
    assert human_to_bytes('1MB') == 1024 ** 2
    assert human_to_bytes('1Mb', isbits=True) == 1024 ** 2
    assert human_to_bytes('1MB', isbits=True) == 0

# Generated at 2022-06-20 16:28:22.968256
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024, unit='b') == '8.00 Mb'
    assert bytes_to_human(1024, unit='b') == '8.00 Kb'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'
    assert bytes_

# Generated at 2022-06-20 16:28:26.729276
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'ABC', 'xyz', 'pqR', '12']) == [1, 'abc', 'xyz', 'pqr', '12']

# Generated at 2022-06-20 16:28:37.305762
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('5') == 5
    assert human_to_bytes('5.9') == 5
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2Kb', isbits=True) == 2048
    assert human_to_bytes('2.3M') == 2457600
    assert human_to_bytes('2.3Mb', isbits=True) == 2457600
    assert human_to_bytes('2.4Z') == 2638827934208
    assert human_to_bytes('2.4Zb', isbits=True) == 2638827934208
    assert human_to_bytes('3T') == 3221225472
    assert human_

# Generated at 2022-06-20 16:28:50.332666
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # When isbits is False, byte identifiers are passed in upper-case
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1KB') == 1 << 10
    assert human_to_bytes('1MB') == 1 << 20
    assert human_to_bytes('1GB') == 1 << 30
    assert human_to_bytes('1TB') == 1 << 40
    assert human_to_bytes('1PB') == 1 << 50
    assert human_to_bytes('1EB') == 1 << 60
    assert human_to_bytes('1ZB') == 1 << 70
    assert human_to_bytes('1YB') == 1 << 80


# Generated at 2022-06-20 16:28:56.806792
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [1,'a','B','C',1,1.1]
    test_results = lenient_lowercase(test_list)
    assert test_results[0] == 1
    assert test_results[1] == 'a'
    assert test_results[2] == 'b'
    assert test_results[3] == 'c'
    assert test_results[4] == 1
    assert test_results[5] == 1.1


# Generated at 2022-06-20 16:29:01.583952
# Unit test for function bytes_to_human
def test_bytes_to_human():
    for unit, limit in iteritems(SIZE_RANGES):
        if limit == 1:
            assert bytes_to_human(limit) == '1 Byte'
        else:
            assert bytes_to_human(limit, unit=unit) == '1.00 %s' % unit



# Generated at 2022-06-20 16:29:04.029159
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["ABC", "DEF", 1]) == ["abc", "def", 1]



# Generated at 2022-06-20 16:29:13.572010
# Unit test for function bytes_to_human
def test_bytes_to_human():
    test_data = {
        1048576.0: '1.00 MB',
        1071388.0: '1.02 MB',
        102400.0: '100.00 KB',
        12800.0: '12.50 KB',
        1000.0: '1.00 KB',
        1.0: '1.00 B',
        50: '50.00 B',
        0.0: '0.00 B',
        32.0: '32.00 B',
    }
    for value, expected_value in test_data.items():
        if bytes_to_human(value) == expected_value:
            pass

# Generated at 2022-06-20 16:29:24.802688
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:29:37.912279
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:29:48.332086
# Unit test for function human_to_bytes
def test_human_to_bytes():
    tests = (
        ('0', 0),
        ('1', 1),
        ('0.0', 0),
        ('0.1', 0),
        ('1.1', 1),
        ('2K', 2048),
        ('1k', 1024),
        ('2M', 2 * 1024 ** 2),
        ('64g', 64 * 1024 ** 3),
        ('64G', 64 * 1024 ** 3),
        ('16t', 16 * 1024 ** 4),
        ('1b', 1),
        ('2Kb', 2048),
        ('1kb', 1024),
        ('2Mb', 2 * 1024 ** 2),
        ('64gb', 64 * 1024 ** 3),
        ('64Gb', 64 * 1024 ** 3),
        ('16tb', 16 * 1024 ** 4),
    )

    for input, expected in tests:
        res

# Generated at 2022-06-20 16:29:53.383238
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['aBc', 2]) == ['abc', 2]
    assert lenient_lowercase(['aBc', 'dEf']) == ['abc', 'def']
    assert lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase([]) == []


# Unit tests for function human_to_bytes
# Positive case

# Generated at 2022-06-20 16:29:59.155269
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1b') == 1, \
        "human_to_byte('1b') != 1"
    assert human_to_bytes('1b', isbits=True) == 1, \
        "human_to_byte('1b', isbits=True) != 1"
    assert human_to_bytes('1B') == 1, \
        "human_to_byte('1B') != 1"
    assert human_to_bytes(1, 'b') == 1, \
        "human_to_byte(1, 'b') != 1"
    assert human_to_bytes(1, 'b', isbits=True) == 1, \
        "human_to_byte(1, 'b', isbits=True) != 1"

# Generated at 2022-06-20 16:30:20.064225
# Unit test for function human_to_bytes
def test_human_to_bytes():
    human_to_bytes(10, 'M') == 10485760
    human_to_bytes('10M') == 10485760
    human_to_bytes(10, 'G') == 10737418240
    human_to_bytes(10, 'G') == 10737418240
    human_to_bytes('10g') == 107374182400
    human_to_bytes('10') == 10
    human_to_bytes('10.5') == 10
    human_to_bytes('10.5', 'G') == 1125899906842624
    human_to_bytes('10.5', 'g') == 11258999068426240
    human_to_bytes('10.5', 'M') == 1099511627776
    human_to_bytes('10.5', 'm') == 1099511627

# Generated at 2022-06-20 16:30:31.987323
# Unit test for function human_to_bytes
def test_human_to_bytes():
    if human_to_bytes('2K') != 2048:
        raise AssertionError('expected 2048, got %s' % human_to_bytes('2K'))
    if human_to_bytes(2048) != 2048:
        raise AssertionError('expected 2048, got %s' % human_to_bytes(2048))
    if human_to_bytes('2K', isbits=True) != 2097152:
        raise AssertionError('expected 2097152, got %s' % human_to_bytes('2K'))
    if human_to_bytes('2Mb', isbits=True) != 2 * 1024 * 1024:
        raise AssertionError('expected %s, got %s' % (2 * 1024 * 1024, human_to_bytes('2Mb', isbits=True)))

# Generated at 2022-06-20 16:30:36.372903
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    mylist = [1, 'a', 'B']

    assert ['a', 'a', 'b'] == lenient_lowercase(mylist)



# Generated at 2022-06-20 16:30:45.997505
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(5) == '5.00 Bytes'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048576 * 1024) == '1.00 GB'
    assert bytes_to_human(1048576 * 1048576) == '1.00 TB'
    assert bytes_to_human(1048576 * 1048576 * 1024) == '1.00 PB'
    assert bytes_to_human(1048576 * 1048576 * 1048576) == '1.00 EB'
    assert bytes_

# Generated at 2022-06-20 16:30:54.561347
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_list = [1, 'A', 'a', 1.1]
    output_list = [1, 'a', 'a', 1.1]
    assert output_list == lenient_lowercase(input_list)

    input_list = ['', 1, True, ['b', 'a'], {'a': 1}]
    output_list = ['', 1, True, ['b', 'a'], {'a': 1}]
    assert output_list == lenient_lowercase(input_list)



# Generated at 2022-06-20 16:31:05.936481
# Unit test for function bytes_to_human
def test_bytes_to_human():
    result = bytes_to_human(1)
    assert (result == '1.00 Bytes'), "Byte to human match failed"
    result = bytes_to_human(10, isbits=False, unit='B')
    assert (result == '10.00 Bytes'), "Byte to human match failed"
    result = bytes_to_human(10, isbits=False, unit='bytes')
    assert (result == '10.00 Bytes'), "Byte to human match failed"
    result = bytes_to_human(10, isbits=False, unit='BYTE')
    assert (result == '10.00 Bytes'), "Byte to human match failed"
    result = bytes_to_human(10, isbits=False, unit='BYTES')
    assert (result == '10.00 Bytes'), "Byte to human match failed"


# Generated at 2022-06-20 16:31:15.474300
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(100) == '100.00 Bytes'
    assert bytes_to_human(10000) == '9.77 KB'
    assert bytes_to_human(100000) == '97.66 KB'
    assert bytes_to_human(1000000) == '976.56 KB'
    assert bytes_to_human(10000000) == '9.54 MB'
    assert bytes_to_human(100000000) == '95.37 MB'
    assert bytes_to_human(1000000000) == '953.67 MB'
    assert bytes_to_human(10000000000) == '9.31 GB'
    assert bytes_to_human

# Generated at 2022-06-20 16:31:26.266340
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, isbits=True) == '1.00 Kb'
    assert bytes_to_human(1024 * 1024 * 1024 * 8) == '8.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 8, isbits=True) == '8.00 Gb'
    assert bytes_to_human(1024 * 1024 * 1024 * 8 * 1024 * 1024) == '8.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 8 * 1024 * 1024, isbits=True) == '8.00 Tb'
    assert bytes_to_human(1024 * 1024 * 1024 * 8 * 1024 * 1024 * 1024) == '8.00 PB'

# Generated at 2022-06-20 16:31:36.448407
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('1.5Mb', isbits=True) == 1572864
    assert human_to_bytes('1.5Mb', default_unit='MB') == 1572864
    assert human_to_bytes(1500000, default_unit='MB') == 1500000
    assert human_to_bytes('1') == 1
    assert human_to_bytes(1) == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes(1.5) == 1
    assert human_to_bytes('.5') == 0

# Generated at 2022-06-20 16:31:40.401362
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['ONE', 'two', 'three']) == ['one', 'two', 'three']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-20 16:32:21.012673
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase(['a', 2, 'c']) == ['a', 2, 'c']

# Generated at 2022-06-20 16:32:25.270437
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase([]) == [])
    assert(lenient_lowercase(['a', 'B', 1, 2]) == ['a', 'b', 1, 2])
    assert(lenient_lowercase(['a', 'B', 1, 2, []]) == ['a', 'b', 1, 2, []])

# Generated at 2022-06-20 16:32:30.735535
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['abCd', 'eFg', 'H']) == ['abcd', 'efg', 'h']
    assert lenient_lowercase(['abCd', None, 3, []]) == ['abcd', None, 3, []]



# Generated at 2022-06-20 16:32:38.550541
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1025) == '1.00 KB'
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(1.5 * 1000 ** 2) == '1.50 MB'
    assert bytes_to_human(2 ** 20) == '1.00 MB'
    assert bytes_to_human(3 * 1000 ** 3) == '3.00 GB'
    assert bytes_to_human(1000 ** 4) == '1.00 TB'
    assert bytes_to_human(1000 ** 5) == '1.00 PB'
    assert bytes_to_human(1000 ** 6) == '1.00 EB'
   

# Generated at 2022-06-20 16:32:49.638560
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Testing for bytes
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1023) == '1023.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 ** 5) == '1.00 TB'
    assert bytes_to_human(1024 ** 6) == '1.00 PB'
    assert bytes_to_human(1024 ** 7) == '1.00 EB'
    assert bytes_to_human(1024 ** 8) == '1.00 ZB'

    # Testing for bits
    assert bytes_to_

# Generated at 2022-06-20 16:32:56.695854
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_string = [' ', 'A', 'B', 'C', 'D', 'E']
    assert lenient_lowercase(test_string) == [' ', 'a', 'b', 'c', 'd', 'e']

    test_string = [' ', 'A', 42, 'E']
    assert lenient_lowercase(test_string) == [' ', 'a', 42, 'e']



# Generated at 2022-06-20 16:33:05.553235
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1mb', isbits=True) == 1048576
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'G') == 10737418240
    assert human_to_bytes(10, 'T') == 10995116277760
    assert human_to_bytes(10, 'P') == 11258999068426240

# Generated at 2022-06-20 16:33:14.871666
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("Testing human_to_bytes()")
    # Byte unit tests
    if human_to_bytes("10") != 10:
        raise ValueError("human_to_bytes() failed to convert 10.")

    if human_to_bytes("10K") != 10 * 1024:
        raise ValueError("human_to_bytes() failed to convert 10K.")

    if human_to_bytes("10KB") != 10 * 1024:
        raise ValueError("human_to_bytes() failed to convert 10KB.")

    if human_to_bytes("10MB") != 10 * 1024 ** 2:
        raise ValueError("human_to_bytes() failed to convert 10MB.")

    if human_to_bytes("10GB") != 10 * 1024 ** 3:
        raise ValueError("human_to_bytes() failed to convert 10GB.")


# Generated at 2022-06-20 16:33:19.211383
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(10, isbits=True) == '10 bits'
    for unit in SIZE_RANGES.keys():
        assert bytes_to_human(1000, unit=unit)[-2:] == unit
        assert bytes_to_human(1000, isbits=True, unit=unit[0].lower())[-3:] == unit[0].lower()

# Generated at 2022-06-20 16:33:26.075992
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == "0 Bytes"
    assert bytes_to_human(1) == "1 Bytes"
    assert bytes_to_human(10) == "10 Bytes"
    assert bytes_to_human(100) == "100 Bytes"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1048576) == "1.00 MB"
    assert bytes_to_human(1048576, isbits=True) == "1.00 Mb"
    assert bytes_to_human(1073741824) == "1.00 GB"
    assert bytes_to_human(1073741824, isbits=True) == "1.00 Gb"

# Generated at 2022-06-20 16:33:58.451376
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['foo', 1, ' Foo ', 'bar']
    lowered = ['foo', 1, ' foo ', 'bar']
    assert lenient_lowercase(lst) == lowered

# Generated at 2022-06-20 16:34:01.064811
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['LOWER', 'UPPER', 1, 2, 3]) == ['lower', 'upper', 1, 2, 3]



# Generated at 2022-06-20 16:34:12.691788
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:34:22.003541
# Unit test for function bytes_to_human
def test_bytes_to_human():
    if human_to_bytes('10M') != 10485760:
        raise AssertionError("human_to_bytes('10M') should return 10485760 instead of %s" % human_to_bytes('10M'))

    if bytes_to_human(10485760) != '10.00 MB':
        raise AssertionError("bytes_to_human(10485760) should return '10.00 MB' instead of %s" % bytes_to_human(10485760))

    if human_to_bytes('10Mb', isbits=True) != 10485760:
        raise AssertionError("human_to_bytes('10Mb', isbits=True) should return 10485760 instead of %s" % human_to_bytes('10Mb'))


# Generated at 2022-06-20 16:34:27.901882
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(['A', 'b', 1, True, False, 'c'])
    assert result == ['a', 'b', 1, True, False, 'c'], "Unexpected result for input [A, b, 1, True, False, c]"

# Unit tests for functions human_to_bytes, bytes_to_human

# Generated at 2022-06-20 16:34:35.211409
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 ** 3) == '1.00 GB'
    assert bytes_to_human(1024 ** 4) == '1.00 TB'
    assert bytes_to_human(1024 ** 5) == '1.00 PB'
    assert bytes_to_human(1024 ** 6) == '1.00 EB'
    assert bytes_to_human(1024 ** 7) == '1.00 ZB'
    assert bytes_to_human(1024 ** 8) == '1.00 YB'


# Generated at 2022-06-20 16:34:43.170364
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, unit="B") == '10.00 Bytes'
    assert bytes_to_human(10, unit="b") == '10.00 Bytes'
    assert bytes_to_human(10, unit="B", isbits=True) == '10.00 Bytes'
    assert bytes_to_human(10, isbits=True) == '10.00 bits'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit="B") == '1.00 Bytes'
    assert bytes_to_human(1, unit="b", isbits=True) == '1.00 bits'

# Generated at 2022-06-20 16:34:51.268779
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:34:55.107009
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    mylist = ['One', 2, 'THREE', 'FoUr', 5]
    assert lenient_lowercase(mylist) == ['one', 2, 'three', 'four', 5]

# Generated at 2022-06-20 16:35:04.455271
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # List of lowercase strings
    assert lenient_lowercase(['foo', 'bar', 'baz']) == ['foo', 'bar', 'baz']
    # List containing an int
    assert lenient_lowercase(['foo', 'bar', 123]) == ['foo', 'bar', 123]
    # List containing None
    assert lenient_lowercase(['foo', 'bar', None]) == ['foo', 'bar', None]
    # List containing a dict
    assert lenient_lowercase(['foo', 'bar', {'foo': 'bar'}]) == ['foo', 'bar', {'foo': 'bar'}]
