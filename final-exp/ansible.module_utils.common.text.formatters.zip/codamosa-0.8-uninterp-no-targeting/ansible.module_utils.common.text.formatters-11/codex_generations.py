

# Generated at 2022-06-20 16:25:50.428437
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lowercase_string = lenient_lowercase(
        ['B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O'])
    assert (lowercase_string == ['b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o'])
    lowercase_list = lenient_lowercase(
        ['B', 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O'])

# Generated at 2022-06-20 16:25:52.587089
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 1, 'B', 'C']) == ['a', 1, 'b', 'c']

# Generated at 2022-06-20 16:25:57.816952
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lower_list = ["test_value", "Test_Value", 1, "test_value1", [], {}]
    expected_list = ["test_value", "test_value", 1, "test_value1", [], {}]
    result_list = lenient_lowercase(lower_list)
    assert(expected_list == result_list)

# Choose all the test values for function human_to_bytes

# Generated at 2022-06-20 16:25:59.284100
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['foo', 'Bar', 1]) == ['foo', 'bar', 1]


# Generated at 2022-06-20 16:26:04.300497
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(1025) == '1.00 KB'
    assert bytes_to_human(1025546) == '1.00 MB'
    assert bytes_to_human(10256847) == '9.77 MB'
    assert bytes_to_human(10256847, isbits=True) == '77.96 bits'



# Generated at 2022-06-20 16:26:08.233164
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, isbits=True) == '10.00 bits'
    assert bytes_to_human(10, unit='M') == '0.01 MBytes'
    assert bytes_to_human(10, isbits=True, unit='m') == '0.01 mbits'



# Generated at 2022-06-20 16:26:19.416800
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10K') == 10 * 1024
    assert human_to_bytes('10Kb') == 10 * 1024
    assert human_to_bytes('10KB') == 10 * 1024
    assert human_to_bytes('10M') == 10 * 1024 * 1024
    assert human_to_bytes('10Mb') == 10 * 1024 * 1024
    assert human_to_bytes('10MB') == 10 * 1024 * 1024
    assert human_to_bytes('10G') == 10 * 1024 * 1024 * 1024
    assert human_to_bytes('10Gb') == 10 * 1024 * 1024 * 1024
   

# Generated at 2022-06-20 16:26:24.964799
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:26:37.584984
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('120') == 120
    assert human_to_bytes('.1Y') == 1 * (1 << 79)
    assert human_to_bytes('.1Z') == 1 * (1 << 69)
    assert human_to_bytes('.1E') == 1 * (1 << 59)
    assert human_to_bytes('.1P') == 1 * (1 << 49)
    assert human_to_bytes('.1T') == 1 * (1 << 39)
    assert human_to_bytes('.1G') == 1 * (1 << 29)
    assert human_to_bytes('.1M') == 1 * (1 << 19)
    assert human_to_bytes('.1K') == 1 * (1 << 9)
    assert human_to_bytes('.1B') == 1
    assert human

# Generated at 2022-06-20 16:26:44.844483
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['lowercase', 'CaPiTaLiZeD', 1, 2.0, True, False, '1', '1.0', None, [2], {'a': 1}]
    result_list = ['lowercase', 'capitalized', 1, 2.0, True, False, '1', '1.0', None, [2], {'a': 1}]
    compare_results = lenient_lowercase(test_list) == result_list
    assert compare_results



# Generated at 2022-06-20 16:26:57.814592
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print("TESTING BYTES_TO_HUMAN")
    assert bytes_to_human(1) == "1.00 Bytes", "size %s converted to %s" % (1, bytes_to_human(1))
    assert bytes_to_human(10) == "10.00 Bytes", "size %s converted to %s" % (10, bytes_to_human(10))
    assert bytes_to_human(100) == "100.00 Bytes", "size %s converted to %s" % (100, bytes_to_human(100))
    assert bytes_to_human(1000) == "1000.00 Bytes", "size %s converted to %s" % (1000, bytes_to_human(1000))

# Generated at 2022-06-20 16:27:03.998377
# Unit test for function bytes_to_human
def test_bytes_to_human():
    def test(size, expected):
        actual = bytes_to_human(size)
        if actual != expected:
            print("Expected: %s, got: %s" % (expected, actual))
            exit(1)

    test(0, '0.00 Bytes')
    test(1, '1.00 Bytes')
    test(1025, '1.00 KB')
    test(1572864, '1.50 MB')
    test(1610612736, '1.50 GB')
    test(137438953472, '1.25 TB')
    test(144115188075855872, '1.25 PB')
    test(1511157274518286468, '1.25 EB')
    test(15845632502852867518, '1.25 ZB')
   

# Generated at 2022-06-20 16:27:14.038976
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:27:24.055601
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test with unit in name
    assert human_to_bytes('1M') == 1048576 and human_to_bytes('1') == 1
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5mB') == 1572864
    assert human_to_bytes('1.5MB') == 1572864
    assert human_to_bytes('1.5Mb') == 1572864
    assert human_to_bytes('1.5Mb', isbits=True) == 1572864
    # Test with unit in argument
    assert human_to_bytes(100, 'KB') == 102400
    assert human_to_bytes(100, 'Kb') == 51200
    assert human_to_bytes(100, 'Kb', isbits=True) == 51200


# Generated at 2022-06-20 16:27:32.496324
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 3, 4]) == ['a', 'b', 3, 4]
    assert lenient_lowercase([u'a', u'\u03A0', 'B', 3, 4]) == ['a', u'\u03A0', 'b', 3, 4]
    assert lenient_lowercase([u'\u03A0', 3, 4]) == [u'\u03A0', 3, 4]
    assert lenient_lowercase([u'a', u'b', None]) == ['a', 'b', None]
    assert lenient_lowercase([u'a']) == ['a']

# Generated at 2022-06-20 16:27:43.712361
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, unit='b') == '1.00 bits'
    assert bytes_to_human(1, isbits=True) == '1.00 bits'
    assert bytes_to_human(1, unit='b', isbits=True) == '1.00 bits'
    assert bytes_to_human(1, unit='B', isbits=True) == '8.00 bits'
    assert bytes_to_human(1, isbits=True, unit='B') == '8.00 bits'
    assert bytes_to_human(1023) == '1023.00 Bytes'

# Generated at 2022-06-20 16:27:45.987377
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['Ansible', 2, 'Ans', None]
    assert lenient_lowercase(test_list) == ['ansible', 2, 'ans', None]



# Generated at 2022-06-20 16:27:56.690013
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(10, unit='B') == '10 Bytes'
    assert bytes_to_human(10, unit='b') == '80 bits'
    assert bytes_to_human(10, isbits=True) == '80 bits'
    assert bytes_to_human('10') == '10 Bytes'
    assert bytes_to_human('10b') == '80 bits'
    assert bytes_to_human('10B') == '10 Bytes'
    assert bytes_to_human('10Mb') == '80.00 Mb'
    assert bytes_to_human('10MB') == '10.00 MB'


# Generated at 2022-06-20 16:28:00.896434
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_input = ['Key1', 2, 'Key3']
    list_output = ['key1', 2, 'key3']

    assert lenient_lowercase(list_input) == list_output



# Generated at 2022-06-20 16:28:09.272145
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(2048) == '2 KB'
    assert bytes_to_human(2048, unit='b') == '16 Kbits'
    assert bytes_to_human(2048, unit='B') == '2 KB'
    assert bytes_to_human(2048, unit='B', isbits=True) == '16 Kbits'
    assert bytes_to_human(2048, unit='b', isbits=True) == '16 Kbits'
    assert bytes_to_human(2048, unit='G', isbits=True) == '16 Mbits'
    assert bytes_to_human(2048, unit='G', isbits=False) == '0 GB'

# Generated at 2022-06-20 16:28:20.203597
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(5368709120, unit='B') == '5.00 GB'
    assert bytes_to_human(5368709120, unit='b') == '5.00 Gbits'
    assert bytes_to_human(8796093022208, unit='B') == '80.00 TB'
    assert bytes_to_human(8796093022208, unit='b') == '80.00 Tbits'


# Generated at 2022-06-20 16:28:32.297563
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert(bytes_to_human(0) == '0 Bytes')
    assert(bytes_to_human(0, unit='B') == '0 Bytes')
    assert(bytes_to_human(0, unit='b') == '0 bits')
    assert(bytes_to_human(0, unit='B', isbits=True) == '0 bits')
    assert(bytes_to_human(0, unit='b', isbits=True) == '0 bits')
    assert(bytes_to_human(10) == '10.00 Bytes')
    assert(bytes_to_human(10, unit='B') == '10.00 Bytes')
    assert(bytes_to_human(10, unit='b') == '10.00 bits')

# Generated at 2022-06-20 16:28:36.891038
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [1, 'string', ('tuple',), [list], {Dict: 'dict'}, 'String']
    assert lenient_lowercase(lst) == [1, 'string', ('tuple',), [list],
                                     {Dict: 'dict'}, 'string']

# Generated at 2022-06-20 16:28:47.207025
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:28:59.019616
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # common case, no unit specified. ValueError is expected
    try:
        result = human_to_bytes('10')
        assert(False), 'ValueError was not raised'
    except ValueError:
        assert(True)
    # common case, unit specified
    try:
        result = human_to_bytes('10M')
        assert(result == 10485760)
        assert(True)
    except ValueError:
        assert(False), 'Incorrect value was returned'
    # unit of lowercase
    try:
        result = human_to_bytes('10m')
        assert(result == 10485760)
        assert(True)
    except ValueError:
        assert(False), 'Incorrect value was returned'
    # unit with space

# Generated at 2022-06-20 16:29:07.428386
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:29:16.231267
# Unit test for function bytes_to_human
def test_bytes_to_human():
    import random
    import math
    import unittest

    class TestSequenceFunctions(unittest.TestCase):

        def setUp(self):
            '''This method is called before each test run'''
            self.quantity = 65536
            self.max_value = 2 ** 64
            self.min_value = 1
            self.unit_list = ['Y', 'Z', 'E', 'P', 'T', 'G', 'M', 'K', 'B']

        def test_bytes_to_human(self):
            '''test bytes_to_human function with valid arguments'''
            # check conversion with default unit
            assert bytes_to_human(self.max_value) == '16 EBytes'
            # check conversion with specified unit

# Generated at 2022-06-20 16:29:25.999814
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:29:32.720325
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['a', 'B', 'C', 123, [1, 2, 3], {'a': 'A'}]
    lst_lc = ['a', 'b', 'c', 123, [1, 2, 3], {'a': 'A'}]
    result = lenient_lowercase(lst)
    assert result == lst_lc

# Generated at 2022-06-20 16:29:36.861031
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["Spam", "eggs"]) == ["spam", "eggs"]
    assert lenient_lowercase(["spam", 1]) == ["spam", 1]
    assert lenient_lowercase(["spam"]) == ["spam"]


# Generated at 2022-06-20 16:29:49.841698
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """
    This function mainly tests the function bytes_to_human.
    """
    assert(bytes_to_human(1 << 10) == '1.00 KB')
    assert(bytes_to_human(1 << 20) == '1.00 MB')
    assert(bytes_to_human(1 << 30) == '1.00 GB')
    assert(bytes_to_human(1 << 40) == '1.00 TB')
    assert(bytes_to_human(1 << 50) == '1.00 PB')
    assert(bytes_to_human(1 << 30, unit='K') == '102400.00 KB')
    assert(bytes_to_human(1 << 30, unit='M') == '1024.00 MB')

# Generated at 2022-06-20 16:29:59.261157
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 'D']) == ['a', 'B', 'c', 'D']
    assert lenient_lowercase([1, 'a', 2, 'B', 3, 'c', 4, 'D', 5]) == [1, 'a', 2, 'B', 3, 'c', 4, 'D', 5]
    assert lenient_lowercase(['A', 1, 'B', 2]) == ['a', 1, 'B', 2]
    assert lenient_lowercase([1, 'A', 2, 'B']) == [1, 'a', 2, 'B']
    assert lenient_lowercase([True, False, 'A', 'B']) == [True, False, 'a', 'B']

# Generated at 2022-06-20 16:30:09.625198
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test known examples
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('1.6B') == 1
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10G') == 10737418240
    assert human_to_bytes('10P') == 11258999068426240
    # test cache_size with default unit
    assert human_to_bytes('1', default_unit='B') == 1
    assert human_to_bytes('10', default_unit='M') == 10485760
    assert human_to_bytes('10.6', default_unit='MB') == 11067420
    assert human_to_

# Generated at 2022-06-20 16:30:17.364445
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['ABC', 'abc', '123']) == ['abc', 'abc', '123']
    assert lenient_lowercase(['aBc', 'DeF']) == ['abc', 'def']
    assert lenient_lowercase([1234, 'eFg']) == [1234, 'efg']
    assert lenient_lowercase([None, '!']) == [None, '!']
    assert lenient_lowercase([]) == []


# Generated at 2022-06-20 16:30:21.610749
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048576, isbits=True) == '1.00 Mb'
    assert bytes_to_human(1048576, isbits=True, unit='b') == '1.00 Mb'
    assert bytes_to_human(1048576, isbits=True, unit='') == '8388608.00 bits'



# Generated at 2022-06-20 16:30:33.008691
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 B'
    assert bytes_to_human(1023) == '1023.00 B'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024**2) == '1.00 MB'
    assert bytes_to_human(1024**3) == '1.00 GB'
    assert bytes_to_human(1024**4) == '1.00 TB'
    assert bytes_to_human(1024**5) == '1.00 PB'
    assert bytes_to_human(1024**6) == '1.00 EB'
    assert bytes_to_human(1024**7) == '1.00 ZB'
    assert bytes

# Generated at 2022-06-20 16:30:44.817249
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'
    assert bytes_to_human(10, unit='byte') == '10.00 Bytes'
    assert bytes_to_human(10, unit='Bytes') == '10.00 Bytes'
    assert bytes_to_human(10, unit='bytes') == '10.00 Bytes'
    assert bytes_to_human(10, unit='b') == '10.00 bytes'
    assert bytes_to_human(10, unit='bit') == '10.00 bits'
    assert bytes_to_human(10, unit='bits') == '10.00 bits'
    assert bytes_to_human(10, isbits=True) == '10.00 bits'

# Generated at 2022-06-20 16:30:56.324004
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Validate convert bytes human string to human unit bytes '''
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('800') == 800
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('10KB') == 10240
    assert human_to_bytes('10KB', 'K') == 10240
    assert human_to_bytes('10KB', 'Kb') == 10240
    assert human_to_bytes('10KB', 'KB') == 10240
    assert human_to_bytes('10KB', 'kb') == 10240
    assert human_to_bytes('10mB') == 10240
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes

# Generated at 2022-06-20 16:31:07.944851
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    from itertools import product
    from random import randint

    class TestHumanToBytes(unittest.TestCase):

        def setUp(self):
            self.sut = human_to_bytes
            # Generate list of valid human-readable values (bytes)
            self.values = []
            for iter in product('0123456789', ('', '.'), ('', '.'), ('', '.'), ('', '.', '.'), ('', '.'), ('', '.', '.'), ('', '.', '.'), ('', '.', '.')):
                self.values.append(''.join(iter))
            # Generate list of suffixes


# Generated at 2022-06-20 16:31:14.177928
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # testing bytes_to_human
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'
    assert bytes_to_human(10, unit='b') == '80.00 bits'
    assert bytes_to_human(10, isbits=True) == '80.00 bits'
    assert bytes_to_human(10, isbits=True, unit='B') == '10.00 Bytes'
    assert bytes_to_human(10, isbits=True, unit='b') == '80.00 bits'

    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(0, unit='B') == '0.00 Bytes'
    assert bytes_to_

# Generated at 2022-06-20 16:31:27.557817
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # bytes tests
    assert human_to_bytes('0B') == 0
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10.0B') == 10
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1KB') == 1000
    assert human_to_bytes('1kB') == 1000
    assert human_to_bytes('0.5kB') == 500
    assert human_to_bytes('1Mb') == 1024 ** 2
    assert human_to_bytes('1MB') == 1000 ** 2
    assert human_to_bytes('1mB') == 1000 ** 2
    assert human_to_bytes('0.5mB') == 500 ** 2
    assert human_to_bytes('1Gb') == 1024 ** 3
    assert human_to_

# Generated at 2022-06-20 16:31:31.701684
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(10, True) == '10 bits'
    assert bytes_to_human(12345, unit='') == '12.06 Bytes'
    assert bytes_to_human(12345, unit='b') == '98.76 bits'
    assert bytes_to_human(1234, unit='B') == '1.21 KB'
    assert bytes_to_human(1234, unit='KB') == '1.21 KB'
    assert bytes_to_human(1234, unit='Kb') == '9.86 Kb'
    assert bytes_to_human(1234, unit='K') == '1.21 KB'

# Generated at 2022-06-20 16:31:38.803999
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["a", "b", "c"]) == ["a", "b", "c"]
    assert lenient_lowercase([1, "b", "c"]) == [1, "b", "c"]
    assert lenient_lowercase(["A", "b", "c"]) == ["a", "b", "c"]
    assert lenient_lowercase(["A", 2, "c"]) == ["a", 2, "c"]
    assert lenient_lowercase(["a", "B", "c"]) == ["a", "b", "c"]
    assert lenient_lowercase(["a", "B", 3]) == ["a", "b", 3]



# Generated at 2022-06-20 16:31:47.323794
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # test_bytes_to_human_for_bytes

    for i in SIZE_RANGES:
        if i == 'B':
            assert bytes_to_human(SIZE_RANGES.get(i)) == '1.00 Bytes'
        elif i == 'K':
            assert bytes_to_human(SIZE_RANGES.get(i)) == '1.00 KB'
        elif i == 'M':
            assert bytes_to_human(SIZE_RANGES.get(i)) == '1.00 MB'
        elif i == 'G':
            assert bytes_to_human(SIZE_RANGES.get(i)) == '1.00 GB'

# Generated at 2022-06-20 16:31:49.463929
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 1, 'B', 2]) == ['a', 1, 'b', 2]



# Generated at 2022-06-20 16:32:00.360807
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, isbits=True) == '10.00 bits'
    assert bytes_to_human(10, unit='b') == '10.00 bits'
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(0.9) == '0.90 Bytes'
    assert bytes_to_human(10.9) == '10.90 Bytes'
    assert bytes_to_human(10.12345) == '10.12 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, isbits=True) == '1.00 Kb'

# Generated at 2022-06-20 16:32:10.144541
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('test_human_to_bytes()')

# Generated at 2022-06-20 16:32:14.445538
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', True, 'C']) == ['a', True, 'c']

# Generated at 2022-06-20 16:32:19.733636
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    normal = ['a', 'B', u'c']
    non_strings = [1, {'a': 'b'}, {}]
    mixed = normal + non_strings
    result = lenient_lowercase(mixed)
    assert(result == ['a', 'b', u'c'] + non_strings)


# Generated at 2022-06-20 16:32:28.653298
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, unit='B'.lower()) == '1.00 bytes'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'
    assert bytes_to_human(10, unit='B'.lower()) == '10.00 bytes'
    assert bytes_to_human(1000) == '1.00 KB'
    assert bytes_to_human(1000, unit='K') == '1.00 KB'
    assert bytes_to_human(1000, unit='K'.lower()) == '1.00 Kb'

# Generated at 2022-06-20 16:32:40.322863
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, unit='m') == '10.00 MBytes'
    assert bytes_to_human(10, unit='m', isbits=True) == '10.00 Mb'

# Generated at 2022-06-20 16:32:50.911702
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print(bytes_to_human(1))                         # 1.00 bytes
    print(bytes_to_human(1, unit="B"))               # 1.00 bytes
    print(bytes_to_human(1, unit="B", isbits=True))  # 8.00 b
    print(bytes_to_human(1, unit="K", isbits=True))  # 0.01 Kb
    print(bytes_to_human(1, unit="K", isbits=False)) # 1.00 KB
    print(bytes_to_human(1, unit="kb"))              # 1.00 Kb
    print(bytes_to_human(1, "KB"))                   # 1.00 KB
    print(bytes_to_human(1, "Kb"))                   # 1.00 Kb
    # ValueError

# Generated at 2022-06-20 16:33:00.794147
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import sys
    import pytest

    class TestData(object):
        pass

    test_data = [
        TestData(),
        TestData(),
        TestData(),
        TestData(),
        TestData(),
        TestData(),
        TestData(),
        TestData(),
        TestData(),
        TestData(),
        TestData(),
        TestData(),
        TestData(),
        TestData(),
        TestData(),
    ]
    test_data[0].input = "10k"
    test_data[0].output = 10000.0
    test_data[1].input = "10M"
    test_data[1].output = 10000000
    test_data[2].input = "1.5M"
    test_data[2].output = 1500000

# Generated at 2022-06-20 16:33:05.084191
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1234') == 1234)
    assert(human_to_bytes('1234B') == 1234)
    assert(human_to_bytes('1234b') == 1234)
    assert(human_to_bytes('1234 GB') == 1234000000000)
    assert(human_to_bytes('1234 Mb') == 1234000000)
    assert(human_to_bytes('1234 GB', isbits=True) == 1234000000000000)
    assert(human_to_bytes('1234 Mb', isbits=True) == 12340000000)
    # Test default unit
    assert(human_to_bytes('1234', 'B') == 1234)
    assert(human_to_bytes('1234', 'G') == 1234000000000)

# Generated at 2022-06-20 16:33:11.879375
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 'a', 'B', 'C']) == [1, 2, 'a', 'B', 'C']
    assert lenient_lowercase(['a', 'B', 'C']) == ['a', 'B', 'C']
    assert lenient_lowercase(['a', 'B', 'C', 1, 2]) == ['a', 'B', 'C', 1, 2]
    assert lenient_lowercase([1, 2]) == [1, 2]



# Generated at 2022-06-20 16:33:15.354971
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_data = [1, 2, 3, 'test', 'TEST', 'TEST', 5, 6, 7]
    expected_result = [1, 2, 3, 'test', 'test', 'test', 5, 6, 7]
    assert lenient_lowercase(test_data) == expected_result



# Generated at 2022-06-20 16:33:19.510143
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1000) == '1000.00 Bytes'
    assert bytes_to_human(10**6) == '1.00 MBytes'
    assert bytes_to_human(10**9) == '1.00 GBytes'
    assert bytes_to_human(10**12) == '1.00 TBytes'


# Generated at 2022-06-20 16:33:25.136929
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10) == 10
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10k') == 10240
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10G') == 10737418240
    assert human_to_bytes('10b') == 1
    assert human_to_bytes('10kb') == 1280
    assert human_to_bytes('10Mb') == 1310720
    assert human_to_bytes('10Gb') == 134217728
    assert human_to_bytes('10Kb', isbits=True) == 1280
    assert human_to_bytes('10MB', isbits=True) == 134217728
    assert human_to_

# Generated at 2022-06-20 16:33:28.450843
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1000000) == '976.56 KBytes'
    assert bytes_to_human(1000000, unit='k') == '1000.00 KBytes'
    assert bytes_to_human(1000000000, unit='g') == '1.00 GBytes'
    assert bytes_to_human(1000000000, isbits=True, unit='g') == '1000.00 Gbits'


# vim: ai et ts=4 sw=4

# Generated at 2022-06-20 16:33:39.225774
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test edge cases
    assert human_to_bytes('') == 0
    assert human_to_bytes('-1') == -1
    assert human_to_bytes('-1.5') == -1
    assert human_to_bytes('1-') == 1
    assert human_to_bytes('1-5') == 1

    # Test simple valid strings without a unit
    assert human_to_bytes('3') == 3
    assert human_to_bytes(3) == 3
    assert human_to_bytes('3.2') == 3
    assert human_to_bytes('23232.9999') == 23233

    # Test valid strings with a unit
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('2K') == 2048

# Generated at 2022-06-20 16:33:56.753668
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:34:07.120754
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """testing bytes_to_human
    """

    if human_to_bytes('1Mb', isbits=True) != 1048576:
        raise AssertionError("byte_to_human() failed to count bits")

    elif human_to_bytes('1MB', isbits=True) != 0:
        raise AssertionError("byte_to_human() failed to count bits, uppercase B was passed")

    elif human_to_bytes('1MB', isbits=False) != 1048576:
        raise AssertionError("byte_to_human() failed to count bytes")

    elif human_to_bytes('1Mb', isbits=False) != 0:
        raise AssertionError("byte_to_human() failed to count bytes, lowercase b was passed")


# Generated at 2022-06-20 16:34:12.621103
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test default_unit=None
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1M') == 1048576
    # Test default_unit='B'
    assert human_to_bytes('1', 'B') == 1
    assert human_to_bytes('1M', 'B') == 1048576
    # Test default_unit='m'
    assert human_to_bytes('1', 'm') == 0.001
    assert human_to_bytes('1M', 'm') == 1048.576
    # Test isbits=True
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1B', isbits=True) == 8
    assert human_to_bytes('1mb', isbits=True) == 1000000

# Generated at 2022-06-20 16:34:17.594996
# Unit test for function bytes_to_human
def test_bytes_to_human():
    for suffix, limit in sorted(iteritems(SIZE_RANGES), key=lambda item: -item[1]):
        actual = bytes_to_human(limit)
        expected = "1.00 %s" % suffix
        message = "bytes_to_human() failed. Expect %s, but got %s" % (expected, actual)
        assert actual == expected, message


# Generated at 2022-06-20 16:34:26.234988
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1 KB') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1mb', isbits=True) == 1048576



# Generated at 2022-06-20 16:34:36.047907
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert '10.00 Bytes' == bytes_to_human(10)
    assert '1.00 Bit' == bytes_to_human(1, isbits=True)
    assert '1.01 Bits' == bytes_to_human(1.01, isbits=True)
    assert '1.00 KiloBytes' == bytes_to_human(1024)
    assert '1.00 KiloBits' == bytes_to_human(1024, isbits=True)
    assert '1.00 KB' == bytes_to_human(1024, unit='K')
    assert '1.00 KB' == bytes_to_human(1024, unit='k')
    assert '1.00 KB' == bytes_to_human(1024, unit='kb')

# Generated at 2022-06-20 16:34:40.265791
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['ONE', 'TWO', 'THREE']) == ['one', 'two', 'three']
    assert lenient_lowercase(['ONE', 2, 'THREE']) == ['one', 2, 'three']
    assert lenient_lowercase(['ONE', 2, 'THREE']) != ['one', 'two', 'three']

# Generated at 2022-06-20 16:34:49.060523
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Unit test for human_to_bytes()
    '''

# Generated at 2022-06-20 16:35:00.537725
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Assert type and values are as expected
    assert isinstance(human_to_bytes('1K'), int)
    assert human_to_bytes('1K') == 1024
    assert isinstance(human_to_bytes('1M'), int)
    assert human_to_bytes('1M') == 1024 * 1024
    assert isinstance(human_to_bytes('10M'), int)
    assert human_to_bytes('10M') == 1024 * 1024 * 10
    assert isinstance(human_to_bytes('1G'), int)
    assert human_to_bytes('1G') == 1024 * 1024 * 1024
    assert isinstance(human_to_bytes('1T'), int)
    assert human_to_bytes('1T') == 1024 * 1024 * 1024 * 1024
    assert isinstance(human_to_bytes('1P'), int)


# Generated at 2022-06-20 16:35:11.372407
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_data = (
        ('1', 1),
        ('1K', 1024),
        ('1B', 1),
        ('1b', 1),
        ('1.5K', 1536),
        ('500Mb', 500000000),
        ('500MB', 500000000),
        ('500MBb', 500000000),
        ('500MBB', 500000000),
        ('500M', 500000000),
        ('500Mb', 500000000),
        ('500MB', 500000000),
        ('500Mb', 500000000),
        ('500MB', 500000000),
    )

    for item in test_data:
        assert human_to_bytes(item[0]) == item[1]
        assert human_to_bytes(item[0], 'B') == item[1]