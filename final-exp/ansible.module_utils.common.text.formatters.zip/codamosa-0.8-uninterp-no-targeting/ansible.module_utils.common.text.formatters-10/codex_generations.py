

# Generated at 2022-06-20 16:25:52.664215
# Unit test for function human_to_bytes
def test_human_to_bytes():
    if human_to_bytes('10M') != 10485760:
        print('failed: human_to_bytes: 10M != 10485760')
    if human_to_bytes('10.5M') != 10485760:
        print('failed: human_to_bytes: 10.5M != 10485760')
    if human_to_bytes(10, 'M') != 10485760:
        print('failed: human_to_bytes: 10M != 10485760')
    if human_to_bytes(10.5, 'M') != 10485760:
        print('failed: human_to_bytes: 10.5M != 10485760')
    if human_to_bytes('1 KB') != 1024:
        print('failed: human_to_bytes: 1 KB != 1024')

# Generated at 2022-06-20 16:26:01.665959
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('20B') == 20
    assert human_to_bytes('20KB') == 20480
    assert human_to_bytes('20KB', isbits=False, unit='K') == 20480
    assert human_to_bytes(20, isbits=False, unit='K') == 20480
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1.0Mb', isbits=True) == 1048576
    assert human_to_bytes('1Gb', isbits=True) == 1073741824
    assert human_to_bytes('1TB') == 1099511627776
    assert human_to_bytes('1PB') == 1125899906842624
    assert human_to_bytes('1EB') == 1152921504606846976

# Generated at 2022-06-20 16:26:12.259300
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1000) == '1.00 KB'
    assert bytes_to_human(1023) == '1023.00 Bytes'
    assert bytes_to_human(1023, unit='B') == '1023.00 Bytes'
    assert bytes_to_human(1023, unit='M') == '0.00 MB'
    assert bytes_to_human(1023, unit='K') == '1.00 KB'
    assert bytes_to_human(1023, unit='b') == '1023.00 bits'
    assert bytes_to_human(1023, unit='mb') == '0.00 Mbits'
    assert bytes_to_human(1023, unit='kb') == '1.00 Kbits'

# Generated at 2022-06-20 16:26:19.722066
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Define test cases below
    # Key is test string, value is expected result
    test_cases = {
        '10M': 10485760,
        '10Mb': 10485760,
        '12.4M': 13041664,
        '50G': 53687091200,
        '50Gb': 53687091200,
        '12.4Gb': 13421772800,
        '12.4gB': 13421772800,
        '2048': 2048,
        '2048B': 2048,
        '1024B': 1024,
        '1024b': 1024,
        '2048b': 2048
    }

    for test_string, test_result in iteritems(test_cases):
        result = human_to_bytes(test_string)

# Generated at 2022-06-20 16:26:24.876591
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    listA = ['a', 'B', 'C', 'D', 1, 2, 3, 4, None]
    listB = ['a', 'b', 'c', 'd', 1, 2, 3, 4, None]

    if lenient_lowercase(listA) != listB:
        raise(Exception("Failed to convert list elements to lowercase"))


# Generated at 2022-06-20 16:26:37.162101
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print('----- test human_to_bytes() -----')

# Generated at 2022-06-20 16:26:49.041877
# Unit test for function bytes_to_human
def test_bytes_to_human():
    data = [
        # MB
        (1024 * 1024 * 0.1, '102.40 KBytes'),
        (1024 * 1024 * 2, '2.00 MBytes'),
        (1024 * 1024 * 2.1, '2.10 MBytes'),
        (1024 * 1024 * 3.2, '3.20 MBytes'),
        (1024 * 1024 * 1024, '1.00 GBytes'),
        # KB
        (1024 * 1, '1.00 KBytes'),
        (1024 * 10, '10.00 KBytes'),
        # B
        (1024, '1024.00 Bytes'),
        (10, '10.00 Bytes'),
        (1, '1.00 Bytes'),
    ]
    for (input, expected) in data:
        output = bytes_to_human(input)

# Generated at 2022-06-20 16:26:59.424527
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:27:11.354352
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1B', 'b') == 1
    assert human_to_bytes('1b', 'B') == 1
    assert human_to_bytes('1b', 'b') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1', 'b') == 1
    assert human_to_bytes('1', 'B') == 1
    assert human_to_bytes('1', 'byte') == 1
    assert human_to_bytes('1', 'Byte') == 1
    assert human_to_bytes('1', 'BYTE') == 1
    assert human_to_bytes('1', 'bit') == 1

# Generated at 2022-06-20 16:27:14.661412
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C', 2.5]) == ['a', 'b', 'c', 2.5]


# Generated at 2022-06-20 16:27:21.036276
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('3.5M') == 3728128
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5', default_unit='B') == 1
    assert human_to_bytes('1.5', default_unit='M') == 1572864


# Generated at 2022-06-20 16:27:29.954882
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, isbits=True) == '8.00 bits'
    assert bytes_to_human(1, isbits=True, unit='k') == '8000.00 bits'
    assert bytes_to_human(1, unit='K') == '1.00 KB'
    assert bytes_to_human(1, isbits=True, unit='M') == '8000.00 Kbits'


# Generated at 2022-06-20 16:27:38.640973
# Unit test for function bytes_to_human
def test_bytes_to_human():
    from ansible.module_utils._text import to_text
    # Test for bytes
    assert bytes_to_human(4294967296) == '4.00 GB'
    assert bytes_to_human(4294967296, unit='gb') == '4.00 gB'
    assert bytes_to_human(4294967296, unit='gb', isbits=True) == '4.00 Gbits'
    assert bytes_to_human(4294967296, unit='gb', isbits=False) == '4.00 GB'
    assert bytes_to_human(4294967296, unit='gB') == '4.00 GB'
    assert bytes_to_human(4294967296, unit='Gb') == '4.00 GB'

    # Test for bits

# Generated at 2022-06-20 16:27:47.975221
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(0, unit='B') == '0.00 Bytes'
    assert bytes_to_human(0, unit='b') == '0.00 b'
    assert bytes_to_human(0, isbits=True) == '0.00 bits'

    assert bytes_to_human(2) == '2.00 Bytes'
    assert bytes_to_human(2, unit='B') == '2.00 Bytes'
    assert bytes_to_human(2, unit='b') == '16.00 b'
    assert bytes_to_human(2, isbits=True) == '16.00 bits'

    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_

# Generated at 2022-06-20 16:27:55.511984
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list1 = ['a', 'B', 'cD']
    list2 = [1, 2, 3, 'a', 'B', 'cD']
    list3 = [1, 2, 3]
    assert lenient_lowercase(list1) == ['a', 'b', 'cd']
    assert lenient_lowercase(list2) == [1, 2, 3, 'a', 'b', 'cd']
    assert lenient_lowercase(list3) == list3



# Generated at 2022-06-20 16:28:02.951779
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Byte'
    assert bytes_to_human(5) == '5 Bytes'
    assert bytes_to_human(1.4) == '1.40 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024.4) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'

# Generated at 2022-06-20 16:28:10.687009
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''
    test function bytes_to_human() against values given in the table below
    '''

    test_data = {
        '1': '1 Bytes',
        '10': '10 Bytes',
        '100': '100 Bytes',
        '1000': '1.00 KB',
        '1000000': '1.00 MB',
        '1000000000': '1.00 GB',
        '1000000000000': '1.00 TB',
        '1000000000000000': '1.00 PB',
        '1000000000000000000': '1.00 EB',
        '1000000000000000000000': '1.00 ZB',
        '1000000000000000000000000': '1.00 YB',
    }
    for size, human_format in test_data.items():
        assert bytes_to_human(int(size)) == human_format

# Generated at 2022-06-20 16:28:22.968947
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 10, False, None) == '10.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 10, False, 'T') == '10.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 10, True, None) == '10.00 Tb'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 10, True, 'T') == '10.00 Tb'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 10 + 1024 * 1024 * 1024 * 1024 * 5, False, None) == '15.00 TB'

# Generated at 2022-06-20 16:28:28.539487
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(['a', 'B', 1, 2, 'c'])
    assert ('a' in result) == True
    assert ('B' in result) == True
    assert ('1' in result) == False
    assert ('2' in result) == False
    assert ('c' in result) == True



# Generated at 2022-06-20 16:28:39.897135
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:28:44.639714
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(['A', {'b': 'B'}, None, '', 3])
    assert result == ['a', {'b': 'B'}, None, '', 3]

# Generated at 2022-06-20 16:28:56.330009
# Unit test for function bytes_to_human
def test_bytes_to_human():
    ''' Verify that bytes_to_human() exists and returns expected value '''
    assert bytes_to_human(1000000000) == '1.00 GB'
    assert bytes_to_human(1000000000, unit='B') == '1.00 GB'
    assert bytes_to_human(1000000000, unit='GB') == '1.00 GB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048576, unit='B') == '1.00 MB'
    assert bytes_to_human(1048576, unit='MB') == '1.00 MB'
    assert bytes_to_human(16384) == '16.00 KB'
    assert bytes_to_human(16384, unit='B') == '16.00 KB'

# Generated at 2022-06-20 16:29:05.978855
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test bytes case
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes(1) == 1
    assert human_to_bytes(1, 'B') == 1
    assert human_to_bytes(1, 'b') == 1
    assert human_to_bytes(10, 'b') == 10
    assert human_to_bytes('0.5B') == 0
    assert human_to_bytes('0.5b') == 0
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b') == 10
    assert human_

# Generated at 2022-06-20 16:29:15.129299
# Unit test for function bytes_to_human
def test_bytes_to_human():
    inputs_outputs = [
        (1, '1.00 Bytes'),
        (2, '2.00 Bytes'),
        (1024, '1.00 KB'),
        (1024 * 1024, '1.00 MB'),
        (1024 * 1024 * 1024, '1.00 GB'),
        (1024 * 1024 * 1024 * 1024, '1.00 TB'),
        (1024 * 1024 * 1024 * 1024 * 1024, '1.00 PB'),
        (1024 * 1024 * 1024 * 1024 * 1024 * 1024, '1.00 EB'),
        (1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024, '1.00 ZB'),
        (1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024, '1.00 YB')
    ]

    for input_output in inputs_outputs:
        input = input_output

# Generated at 2022-06-20 16:29:17.949584
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['TEST', 10, dict(key='val')]) == ['test', 10, dict(key='val')]
    return True



# Generated at 2022-06-20 16:29:25.337091
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(['A', 'B', 1, 2])
    expected = ['a', 'b', 1, 2]
    assert result == expected, 'lenient_lowercase() result does not match expected result'
    result = lenient_lowercase(['A', 1, 2])
    expected = ['a', 1, 2]
    assert result == expected, 'lenient_lowercase() result does not match expected result'
    result = lenient_lowercase([1, 2])
    expected = [1, 2]
    assert result == expected, 'lenient_lowercase() result does not match expected result'



# Generated at 2022-06-20 16:29:30.678472
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['l1', 1, 'l3', None, {}, 'L6']
    expected = ['l1', 1, 'l3', None, {}, 'l6']
    assert lenient_lowercase(lst) == expected



# Generated at 2022-06-20 16:29:31.779394
# Unit test for function human_to_bytes
def test_human_to_bytes():
    pass

# Generated at 2022-06-20 16:29:35.872780
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, unit='K') == '0.01 KB'
    assert bytes_to_human(10, unit='Mb') == '0.01 Mb'


# Generated at 2022-06-20 16:29:46.117190
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(2) == '2.00 Bytes'
    assert bytes_to_human(1000) == '1.00 KB'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(2**20) == '1.00 MB'
    assert bytes_to_human(2**30) == '1.00 GB'
    assert bytes_to_human(2**40) == '1.00 TB'
    assert bytes_to_human(2**50) == '1.00 PB'
    assert bytes_to_human(2**60) == '1.00 EB'
    assert bytes_to_human(2**70) == '1.00 ZB'
    assert bytes_

# Generated at 2022-06-20 16:29:55.380446
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 B'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 EB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 ZB'

# Generated at 2022-06-20 16:30:04.574791
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """
    Return a lowercase list of elements
    """
    assert lenient_lowercase(['abc', u'123', {'key': 'value'}]) == ['abc', u'123', {'key': 'value'}]
    assert lenient_lowercase(['ABC', u'123', {'key': 'value'}]) == ['abc', u'123', {'key': 'value'}]
    assert lenient_lowercase([u'АБВ', u'123', {'key': 'value'}]) == [u'абв', u'123', {'key': 'value'}]



# Generated at 2022-06-20 16:30:08.269785
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [b'a', 'b', u'c', []]
    lst_lower = lenient_lowercase(lst)
    assert lst_lower == [b'a'.decode('utf-8'), 'b', u'c'.lower(), []]



# Generated at 2022-06-20 16:30:15.732696
# Unit test for function bytes_to_human
def test_bytes_to_human():
    if bytes_to_human(1) == '1.00 Bytes':
        if bytes_to_human(1048576) == '1.00 MB':
            if bytes_to_human(1024, isbits=True) == '8.00 Kb':
                print("test_bytes_to_human passed")
                sys.exit(0)

    print("test_bytes_to_human failed")
    sys.exit(1)



# Generated at 2022-06-20 16:30:23.174756
# Unit test for function human_to_bytes
def test_human_to_bytes():
    number = '10M'
    result = human_to_bytes(number)
    assert result == 10485760, 'human_to_bytes failed to convert 10M to 10485760'
    number = 10
    result = human_to_bytes(number, 'M')
    assert result == 10485760, 'human_to_bytes failed to convert 10 to 10485760'
    number = 10
    result = human_to_bytes(number, 'b')
    assert result == 10, 'human_to_bytes failed to convert 10 to 10'
    number = '10b'
    result = human_to_bytes(number, isbits=True)
    assert result == 10, 'human_to_bytes failed to convert 10b to 10'
    number = '10b'

# Generated at 2022-06-20 16:30:33.857635
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' This function run unit test for human_to_bytes function'''
    import pytest
    from ansible.module_utils.netapp_e_utils import human_to_bytes


# Generated at 2022-06-20 16:30:44.958851
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2') == 2
    assert human_to_bytes('2b') == 2
    assert human_to_bytes('2B') == 2
    assert human_to_bytes('2Kb') == 2048
    assert human_to_bytes('2Kb', isbits=True) == 2048
    assert human_to_bytes('2KB') == 2048
    assert human_to_bytes('2KB', isbits=True) == 2048
    assert human_to_bytes('3Mb', isbits=True) == 3145728
    assert human_to_bytes('3MB', isbits=True) == 3145728
    assert human_to_bytes('3Mb') == 3145728
    assert human_to_bytes('3MB') == 3145728
    assert human_to_bytes('1') == 1
   

# Generated at 2022-06-20 16:30:56.362311
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """
    All tests run with default marker character '\N{CHECK MARK}'
    All tests run with default marker character '\N{HEAVY MULTIPLICATION X}'
    """

# Generated at 2022-06-20 16:31:07.987571
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Byte'
    assert bytes_to_human(2) == '2 Bytes'
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1025) == '1.00 KB'
    assert bytes_to_human(11000) == '10.73 KB'
    assert bytes_to_human(151000) == '147.66 KB'
    assert bytes_to_human(1572864) == '1.50 MB'
    assert bytes_to_human(15728640) == '15.00 MB'

# Generated at 2022-06-20 16:31:17.136197
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Simple test (some examples from wikipedia)
    assert human_to_bytes('1 GB') == 1 * 1000 * 1000 * 1000
    assert human_to_bytes('1MB') == 1 * 1000 * 1000
    assert human_to_bytes('1Mb', isbits=True) == 1 * 1000 * 1000
    assert human_to_bytes('1MB', isbits=True) == 1 * 1000 * 1000 * 8
    assert human_to_bytes('1023', default_unit='B') == 1023
    assert human_to_bytes('1023', default_unit='b') == 1023
    assert human_to_bytes(1023, default_unit='b') == 1023
    assert human_to_bytes(1023) == 1023
    assert human_to_bytes('1023') == 1023
    assert human_to_bytes

# Generated at 2022-06-20 16:31:33.078473
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Positive cases
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1M', isbits=True) == 131072
    assert human_to_bytes('1Mb', isbits=True) == 131072
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1G', isbits=True) == 134217728
    assert human_to_bytes('1Gb', isbits=True) == 134217728
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1k', isbits=True) == 128
    assert human_to_bytes('1kb', isbits=True) == 128
    assert human_to_

# Generated at 2022-06-20 16:31:36.904661
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['One', 'Two', 'Three']) == ['one', 'two', 'three']
    assert lenient_lowercase([1, 'Two', 'Three']) == [1, 'two', 'three']
    assert lenient_lowercase(['One', 2, 'Three']) == ['one', 2, 'three']



# Generated at 2022-06-20 16:31:46.648462
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import unittest
    import random

    class TestHumanToBytes(unittest.TestCase):
        def test_string(self):
            self.assertRaises(ValueError, human_to_bytes, 'test')
        def test_float(self):
            self.assertRaises(ValueError, human_to_bytes, 1.1)
        def test_negative(self):
            self.assertRaises(ValueError, human_to_bytes, -1.1)
        def test_int(self):
            self.assertRaises(ValueError, human_to_bytes, 1)
        def test_empty_string(self):
            self.assertRaises(ValueError, human_to_bytes, '')

# Generated at 2022-06-20 16:31:55.856405
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', u'\u00e4']) == ['a', 'b', 'c', u'\u00e4']
    assert lenient_lowercase(['a', 'B', 'c', 1, u'\u00e4']) == ['a', 'b', 'c', 1, u'\u00e4']
    assert lenient_lowercase(['a', 'B', 'c', 1, u'\u00e4']) != ['a', 'b', 'c', 1, u'\u00e4'], 'This test should fail.'

# Generated at 2022-06-20 16:32:03.664934
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:32:06.465983
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    x = ['hello', 1, ['world'], 'again']
    assert lenient_lowercase(x) == ['hello', 1, ['world'], 'again']



# Generated at 2022-06-20 16:32:13.458760
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Does lenient_lowercase change "K" to "k"?
    assert lenient_lowercase(['K']) == ['K']
    # Does lenient_lowercase change "K" to "k" when Uppercase is expected?
    assert lenient_lowercase(['K'], expected=['K']) == ['K']
    # Does lenient_lowercase change "K" to "k" when Lowercase is expected?
    assert lenient_lowercase(['K'], expected=['k']) == ['K']

    # Does lenient_lowercase work for "bytes" correctly?
    assert lenient_lowercase(['KB'], expected=['kb']) == ['KB']
    assert lenient_lowercase(['Kb'], expected=['kb']) == ['Kb']

# Generated at 2022-06-20 16:32:24.426728
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1,000GB') == 1099511627776
    assert human_to_bytes('1,000.00GB') == 1099511627776
    assert human_to_bytes('1,000.00G') == 1099511627776
    assert human_to_bytes('10G') == 10737418240
    assert human_to_bytes('10,737,418,240') == 10737418240
    assert human_to_bytes('10,737,418,240.123') == 10737418240
    assert human_to_bytes('10,737,418,240.123GB') == 10737418240

# Generated at 2022-06-20 16:32:35.741562
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1 MB') == 1048576
    assert human_to_bytes('1048576') == 1048576
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1 Kb') == 1024
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1kb', isbits=True) == 1024
    assert human_to_bytes('1 Kb', isbits=True) == 1024
    assert human_to_bytes('1.1b', isbits=True) == 1.1

# Generated at 2022-06-20 16:32:44.407953
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    array_test_cases = [
        ([], []),
        (['A', 'b', 'c'], ['a', 'b', 'c']),
        (['A', 1, 'c'], ['a', 1, 'c']),
        (['A', ['b', 'c'], 'c'], ['a', ['b', 'c'], 'c']),
    ]
    for test_case in array_test_cases:
        if lenient_lowercase(test_case[0]) != test_case[1]:
            return False
    return True


# Generated at 2022-06-20 16:33:00.695414
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """Unit test for bytes_to_human function."""

    ''' Check bytes to human display '''
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human(1000000000000) == '1.00 TB'
    assert bytes_to_human(1099511627776) == '1.00 PB'
    assert bytes_to_human(1125899906842624) == '1.00 EB'
    assert bytes_to_human(1152921504606846976) == '1.00 ZB'
    assert bytes_

# Generated at 2022-06-20 16:33:10.164885
# Unit test for function bytes_to_human
def test_bytes_to_human():
    size = 1048576
    expected_value_in_bytes = '1.00 MB'
    assert bytes_to_human(size) == expected_value_in_bytes

    size = 1048576
    expected_value_in_bits = '8.00 Mb'
    assert bytes_to_human(size, isbits=True) == expected_value_in_bits

    size = '1.00M'
    expected_value = 1048576
    assert human_to_bytes(size) == expected_value

    size = '1.00MB'
    expected_value = 1048576
    assert human_to_bytes(size) == expected_value

    size = '1.00Mb'
    expected_value = 1048576
    assert human_to_bytes(size, isbits=True) == expected_value

    size

# Generated at 2022-06-20 16:33:19.983871
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1024B') == 1024
    assert human_to_bytes('1025', 'B') == 1025
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K', 'B') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB') == 1024 * 1024
    assert human_to_bytes('1GB') == 1024 * 1024 * 1024
    assert human_to_bytes('1TB') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1PB') == 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to

# Generated at 2022-06-20 16:33:26.596488
# Unit test for function bytes_to_human
def test_bytes_to_human():
    test_list = [
        (1, '1 Bytes'),
        (10, '10 Bytes'),
        (1023, '1023 Bytes'),
        (1024, '1.00 KB'),
        (1024 * 1024 * 1, '1.00 MB'),
        (1024 * 1024 * 10, '10.00 MB'),
        (1024 * 1024 * 100, '100.00 MB'),
        (1024 * 1024 * 1024, '1.00 GB'),
        (1024 * 1024 * 1024 * 1024, '1.00 TB'),
        (1024 * 1024 * 1024 * 1024 * 1024, '1.00 PB'),
        (1024 * 1024 * 1024 * 1024 * 1024 * 1024, '1.00 EB'),
        (1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024, '1.00 ZB'),
    ]


# Generated at 2022-06-20 16:33:30.710312
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['TeSt', 'baz', 1, 'BaR']) == ['test', 'baz', 1, 'bar']
    assert lenient_lowercase([]) == []
    assert lenient_lowercase('test') == ['t', 'e', 's', 't']

# Generated at 2022-06-20 16:33:41.279663
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2 << 10
    assert human_to_bytes('2K', isbits=True) == 2 << 10 * 8

    # check unit[0] is uppercase
    assert human_to_bytes('2b') == 2
    assert human_to_bytes('2B') == 2
    assert human_to_bytes('2Kb', isbits=True) == 2 << 10 * 8
    assert human_to_bytes('2KB', isbits=True) == 2 << 10 * 8

    # check default_unit
    assert human_to_bytes('10', default_unit='K') == 10 << 10
    assert human_to_bytes('10', default_unit='b', isbits=True) == 10

    # check convert float value

# Generated at 2022-06-20 16:33:53.443752
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test return value when isbits is False
    assert bytes_to_human(1, isbits=False) == '1 Bytes'
    assert bytes_to_human(123, isbits=False) == '123 Bytes'
    assert bytes_to_human(12345, isbits=False) == '12.06 KBytes'
    assert bytes_to_human(12345678, isbits=False) == '11.77 MBytes'
    assert bytes_to_human(12345678901, isbits=False) == '11.29 GBytes'
    assert bytes_to_human(12345678901234, isbits=False) == '11.57 TBytes'
    assert bytes_to_human(12345678901234567, isbits=False) == '11.80 PBytes'
    assert bytes_to

# Generated at 2022-06-20 16:34:04.846984
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:34:16.664552
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'
    assert bytes_to_human(10, unit='b') == '10.00 bits'
    assert bytes_to_human(10, isbits=True, unit='b') == '10.00 bits'
    assert bytes_to_human(10, isbits=True, unit='B') == '10.00 Bytes'

    assert bytes_to_human(10, unit='M') == '0.00 MB'
    assert bytes_to_human(10, unit='M', isbits=True) == '0.00 MB'
    assert bytes_to_human(10, unit='m') == '0.00 Mb'

# Generated at 2022-06-20 16:34:24.654590
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('10KB') == 10240
    assert human_to_bytes('10Kb') == 10240
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10G') == 10737418240
    assert human_to_bytes('10GB') == 10737418240
    assert human_to_bytes('10Gb') == 10737418240
    assert human_to_bytes(10, 'KB') == 10240
    assert human_to_bytes(10, 'Kb') == 10240
    assert human_to_bytes(10, 'MB') == 10485760

# Generated at 2022-06-20 16:34:43.480647
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1023) == '1023.00 B'
    assert bytes_to_human(1024, unit='M') == '0.00 MB'
    assert bytes_to_human(1024 ** 2, unit='M') == '1.00 MB'
    assert bytes_to_human(1024 ** 2, unit='Kb') == '1024.00 Kb'
    assert bytes_to_human(1024 ** 2, isbits=True, unit='Kb') == '8388608.00 Kb'
    assert bytes_to_human(1024 ** 2, isbits=True) == '8388608.00 kb'



# Generated at 2022-06-20 16:34:51.465496
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(5) == '5.00 Bytes'
    assert bytes_to_human(12) == '12.00 Bytes'
    assert bytes_to_human(123) == '123.00 Bytes'
    assert bytes_to_human(1234) == '1.21 KB'
    assert bytes_to_human(12345) == '12.06 KB'
    assert bytes_to_human(123456) == '120.56 KB'
    assert bytes_to_human(1234567) == '1.18 MB'
    assert bytes_to_human(12345678) == '11.77 MB'
    assert bytes_to_human(123456789) == '117.74 MB'
    assert bytes_to

# Generated at 2022-06-20 16:35:03.999278
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test for bytes - expected result 1048576
    assert 1048576, human_to_bytes('1M')
    # test for passing string number directly - expected result 1048576
    assert 1048576, human_to_bytes('1048576')
    # test for passing string number with bytes suffix - expected result 1048576
    assert 1048576, human_to_bytes('1048576B')
    # test for passing string number with bits suffix and isbits=True - expected result 1048576
    assert 1048576, human_to_bytes('10Mb', isbits=True)
    # test for passing string number with bits suffix - expected result 1048576
    assert 1048576, human_to_bytes('1048576b')
    # test for passing string number with bits suffix and default_unit='mb' - expected result 1048576
   

# Generated at 2022-06-20 16:35:13.724557
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_data = {
        '0': 0,
        '1': 1,
        '1B': 1,
        '0b': 0,
        '1b': 1,
        '8B': 8,
        '8b': 8,
        '11b': 11,
        '1.2Mb': 1200000,
    }

    # Flag isbits is False by default
    for key, value in iteritems(test_data):
        assert(human_to_bytes(key) == value)
        assert(human_to_bytes(key, isbits=False) == value)

    # Flag isbits is True

# Generated at 2022-06-20 16:35:24.593730
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert 1 == human_to_bytes(1)
    assert 1 == human_to_bytes('1')
    assert 1 == human_to_bytes('1B')
    assert 1 == human_to_bytes('1b', isbits=True)
    assert 1048576 == human_to_bytes('1M')
    assert 1048576 == human_to_bytes('1m', default_unit='m')
    assert 1073741823 == human_to_bytes('1 gb', isbits=True)
    assert 1073741824 == human_to_bytes('1 gb')
    assert 2147483648 == human_to_bytes('2 gb')
    assert 1073741824 == human_to_bytes('1gb')
    assert 2147483648 == human_to_bytes('2gb')

# Generated at 2022-06-20 16:35:34.988679
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(10, unit='b') == '10 bits'
    assert bytes_to_human(10, unit='B') == '10 Bytes'
    assert bytes_to_human(10.5, unit='B') == '10.50 Bytes'
    assert bytes_to_human(10.5, unit='b') == '10.50 bits'
    assert bytes_to_human(123456789, isbits=True) == '123.46 bits'
    assert bytes_to_human(123456789, isbits=True, unit='b') == '123.46 bits'
    assert bytes_to_human(123456789, isbits=True, unit='B') == '123.46 bits'
    assert bytes_to_