

# Generated at 2022-06-20 16:25:54.157616
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:26:02.905454
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    >>> test_human_to_bytes()
    '''

    # test as a normal function
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1TB') == 1099511627776
    assert human_to_bytes('1PB') == 1125899906842624
    assert human_to_bytes('1EB') == 1152921504606846976
    assert human_to_bytes('1ZB') == 1180591620717411303424
    assert human_to_bytes('1YB') == 1208925819614629174706176

    assert human_to

# Generated at 2022-06-20 16:26:10.115363
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:26:15.626856
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_list_of_strings = ['abc', 'XYZ', 1, 2, '123', 'D', 'Efk']
    expected_result = ['abc', 'xyz', 1, 2, '123', 'd', 'efk']
    assert lenient_lowercase(input_list_of_strings) == expected_result

# Generated at 2022-06-20 16:26:22.340628
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 EB'

# Generated at 2022-06-20 16:26:29.083801
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # bytes
    assert human_to_bytes('1') == 1, 'Error in conversion 1B'
    assert human_to_bytes('1B') == 1, 'Error in conversion 1B'
    assert human_to_bytes('1b') == 1, 'Error in conversion 1b'
    assert human_to_bytes('1.5B') == 1, 'Error in conversion 1.5B'
    assert human_to_bytes('1.5b') == 1, 'Error in conversion 1.5b'
    # kilobytes
    assert human_to_bytes('1K') == 1024, 'Error in conversion 1K'
    assert human_to_bytes('1k') == 1024, 'Error in conversion 1k'
    assert human_to_bytes('1.5K') == 1024, 'Error in conversion 1.5K'

# Generated at 2022-06-20 16:26:39.952690
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1000) == '1000 Bytes'
    assert bytes_to_human(1048576) == '1.00 MBytes'
    assert bytes_to_human(1048576.1) == '1.00 MBytes'
    assert bytes_to_human(1048576000) == '1000.00 MBytes'
    assert bytes_to_human(1048576000.0) == '1000.00 MBytes'
    assert bytes_to_human(10485760000) == '10000.00 MBytes'
    assert bytes_to_human(10485760000.0) == '10000.00 MBytes'
    assert bytes_to_human(104857600000000) == '1000000000.00 GBytes'

# Generated at 2022-06-20 16:26:44.672766
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert [1, 'A', 'B', 'c'] == lenient_lowercase([1, 'A', 'B', 'c'])
    assert ['a', 'b', 'c'] == lenient_lowercase(['A', 'B', 'c'])



# Generated at 2022-06-20 16:26:48.362227
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['Test', 1, 'tEsT', 'a']
    result = ['test', 1, 'tEsT', 'a']
    assert lenient_lowercase(test_list) == result


# Generated at 2022-06-20 16:26:58.956310
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(10, isbits=True) == '10 bits'
    assert bytes_to_human(10, unit='B') == '10 Bytes'
    assert bytes_to_human(10, unit='b') == '10 bits'
    assert bytes_to_human(10, unit='Bb') == '10 Bytes'
    assert bytes_to_human(20, unit='Bb') == '20 bits'
    assert bytes_to_human(20, unit='BB') == '20 Bytes'
    assert bytes_to_human(2048) == '2.00 KBytes'
    assert bytes_to_human(2048, isbits=True) == '16.00 Kbits'

# Generated at 2022-06-20 16:27:05.708991
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1]) == [1]
    assert lenient_lowercase(['a']) == ['a']
    assert lenient_lowercase(['A']) == ['a']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']

# Generated at 2022-06-20 16:27:10.472364
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['TEST', 'test', 'teSt', dict(), 'test2']
    result_lst = ['test', 'test', 'teSt', dict(), 'test2']
    res = lenient_lowercase(lst)
    assert res == result_lst, 'Lenient lowercase is not working'


#  Unit test for human_to_bytes()

# Generated at 2022-06-20 16:27:18.510198
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test bytes case
    assert bytes_to_human(10240) == '10.00 KB'
    assert bytes_to_human(10240, unit='K') == '10.00 KBytes'
    # Test bytes case (float)
    assert bytes_to_human(10240.0) == '10.00 KB'
    assert bytes_to_human(10240.0, unit='K') == '10.00 KBytes'
    # Test bits case
    assert bytes_to_human(10240, isbits=True) == '10.00 Kb'
    assert bytes_to_human(10240, isbits=True, unit='K') == '10.00 Kbits'
    # Test bits case (float)

# Generated at 2022-06-20 16:27:24.408498
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_list = ['red', 'RED', 1, 'Blue', 5, 'green', 'Yellow', 'yel', 'yelloW']
    output_list = ['red', 'red', 1, 'blue', 5, 'green', 'yellow', 'yel', 'yellow']
    assert lenient_lowercase(input_list) == output_list



# Generated at 2022-06-20 16:27:34.363340
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:27:44.969612
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes('10m') == human_to_bytes(10, 'm')
    assert human_to_bytes('10m') == human_to_bytes('10', 'm')
    assert human_to_bytes('10.3M') == human_to_bytes('10.3', 'M')
    assert human_to_bytes('10.3M') == human_to_bytes('10.3', 'M')
    assert human_to_bytes(10.3, 'M') == human_to_bytes(10.3, 'm')
    assert human_to_bytes('1Mb') == human_to_bytes(1, 'm', True)
    assert human_to_bytes('1m') == human_

# Generated at 2022-06-20 16:27:56.348963
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1023) == '1023.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(10240) == '10.00 KB'
    assert bytes_to_human(1023 * 1024) == '1023.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(10 * 1024 * 1024) == '10.00 MB'
    assert bytes_to_human(1023 * 1024 * 1024) == '1023.00 MB'

# Generated at 2022-06-20 16:28:03.261839
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['1', '2', 3]
    assert(lenient_lowercase(test_list) == test_list)

    test_list = ['1', '2', '3']
    assert(lenient_lowercase(test_list) == ['1', '2', '3'])

    test_list = ['A', 'B', 'C']
    assert(lenient_lowercase(test_list) == ['a', 'b', 'c'])



# Generated at 2022-06-20 16:28:08.106509
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''Testing bytes_to_human()
    '''

# Generated at 2022-06-20 16:28:10.819939
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10000) == '9.77 KB'
    assert bytes_to_human(100001221) == '95.37 MB'
    assert bytes_to_human(None) is None

# Generated at 2022-06-20 16:28:24.451691
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:28:28.322514
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['a', 'b', 123] == lenient_lowercase(['A', 'b', 123])
    assert ['a', 'b', 123, 'c'] == lenient_lowercase(['A', 'b', 123, 'c'])

# Generated at 2022-06-20 16:28:39.717815
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10.5M') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10m') == 10485760
    assert human_to_bytes('10m', isbits=True) == 10485760
    assert human_to_bytes('1.2K') == 122880
    assert human_to_bytes('1.2k') == 122880
    assert human_to_bytes('1.2k', isbits=True) == 122880
    assert human_to_bytes('1.2Kb') == 122880
    assert human_to

# Generated at 2022-06-20 16:28:42.806019
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test = ['a', 'A', 1, 'Apple', 'APPLE']
    res = ['a', 'a', 1, 'apple', 'apple']
    assert(lenient_lowercase(test) == res)



# Generated at 2022-06-20 16:28:44.547146
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'b', 1]



# Generated at 2022-06-20 16:28:53.092178
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    values = [
        'lowercase',
        'lowerCASE',
        'lowerCasE',
        1,
        [1, 2],
        {'one': 1, 'two': 2},
    ]
    expected = [
        'lowercase',
        'lowercase',
        'lowercase',
        1,
        [1, 2],
        {'one': 1, 'two': 2},
    ]
    result = lenient_lowercase(values)
    if expected != result:
        raise Exception("failed")



# Generated at 2022-06-20 16:28:57.656038
# Unit test for function bytes_to_human
def test_bytes_to_human():
    lines = []
    lines.append('Test bytes_to_human function:')
    lines.append('')
    lines.append(' 1B => ' + str(bytes_to_human(1)))
    lines.append(' 1000B => ' + str(bytes_to_human(1000)))
    lines.append(' 1KB => ' + str(bytes_to_human(1000, unit='K')))
    lines.append(' 1.1KB => ' + str(bytes_to_human(1100, unit='K')))
    lines.append(' 1000KB => ' + str(bytes_to_human(1000000, unit='K')))
    lines.append(' 0.5MB => ' + str(bytes_to_human(500000, unit='M')))

# Generated at 2022-06-20 16:29:07.598609
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:29:16.317905
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1000) == "1000.00 Bytes"
    assert bytes_to_human(1048576) == "1.00 MB"
    assert bytes_to_human(2 * 1048576) == "2.00 MB"
    assert bytes_to_human(1048576, unit='B') == "1048576.00 Bytes"
    assert bytes_to_human(2 * 1048576, unit='B') == "2097152.00 Bytes"
    assert bytes_to_human(1000, unit='B') == "1000.00 Bytes"
    assert bytes_to_human(1000, unit='B', isbits=True) == "8000.00 bits"
    assert bytes_to_human(1048576, unit='B', isbits=True) == "8388608.00 bits"
   

# Generated at 2022-06-20 16:29:26.069959
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        human_to_bytes('10a')
    except ValueError:
        pass
    else:
        raise AssertionError('Error: 10a value is not a valid string')

    try:
        human_to_bytes('10B')
    except ValueError:
        raise AssertionError('Error: 10B value is a valid string')

    assert human_to_bytes('0') == 0
    assert human_to_bytes('1') == 1
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10.0') == 10
    assert human_to_bytes('10.0K') == 10240
    assert human_to_bytes('1.048576Mb') == 1048576
    assert human_to_bytes('1.048576Mb', isbits=True)
   

# Generated at 2022-06-20 16:29:39.053629
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('5K') == 5120
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1K', default_unit='MB') == 1048576
    assert human_to_bytes('1K', default_unit='MB', isbits=True) == 1048576
    assert human_to_bytes('1K', isbits=True) == 1024
    assert human_to_bytes('1Kb', default_unit='Mb', isbits=True) == 1024

# Generated at 2022-06-20 16:29:49.679981
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2.2M') == 2252800
    assert human_to_bytes('.2M') == 209715.2
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10.34Mb') == 10763617
    assert human_to_bytes('10M', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 1250000
    assert human_to_bytes('10.34Mb', isbits=True) == 1295785.6
    assert human_to_bytes(10485760) == 10485760

# Generated at 2022-06-20 16:29:56.668248
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Examples taken from https://en.wikipedia.org/wiki/Binary_prefix
    assert human_to_bytes('1Ki') == 1024
    assert human_to_bytes('2.5MB') == 2500000
    assert human_to_bytes('1.223G') == 1223000000

    # Should also be able to handle upper case
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('100MB') == 104857600

    # Examples for bit values
    assert human_to_bytes('1.2Mb', isbits=True) == 1500000
    assert human_to_bytes('2.5Gb', isbits=True) == 2500000000

    # Should also be able to handle unitless values
    assert human_to_bytes('2') == 2



# Generated at 2022-06-20 16:30:07.930127
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('10B') == 10
    assert human_to_bytes(1) == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes(1024) == 1024
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes(1024 * 1024) == (1024 * 1024)
    assert human_to_bytes('1024.24') == 1024
    assert human_to_bytes('1024.24K') == 1024 * 1024
    assert human_to_bytes('1024.24Kb') == 1024 * 1024
    assert human_to_bytes('1024.24 Mb') == 1024 * 1024 * 1024
    assert human_to_bytes('1024.24Mb') == 1024 * 1024 * 1024
    assert human_to_bytes

# Generated at 2022-06-20 16:30:20.016936
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import assert_equals
    import random

    for isbits in [False, True]:
        for i in range(100):
            num = random.randint(1, 10 * 1000 * 1000 * 1000)

# Generated at 2022-06-20 16:30:23.024446
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', "b", 3]) == ['a', 'b', 3]



# Generated at 2022-06-20 16:30:25.778657
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['STRING', 2, 'string2']
    assert lenient_lowercase(test_list) == ['string', 2, 'string2']

# Generated at 2022-06-20 16:30:28.016099
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['key1', 13, 'VAL2']
    result = lenient_lowercase(lst)
    asser

# Generated at 2022-06-20 16:30:31.789644
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list1 = ['foo', 'bar', 'Baz', 1, 2, 3]
    list2 = ['foo', 'bar', 'baz', 1, 2, 3]
    assert lenient_lowercase(list1) == list2


# Generated at 2022-06-20 16:30:44.266653
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(10, unit='B') == '10 Bytes'
    assert bytes_to_human(2 ** 10) == '1.00 KB'
    assert bytes_to_human(2 ** 20) == '1.00 MB'
    assert bytes_to_human(2 ** 30) == '1.00 GB'
    assert bytes_to_human(2 ** 40) == '1.00 TB'
    assert bytes_to_human(2 ** 50) == '1.00 PB'
    assert bytes_to_human(2 ** 60) == '1.00 EB'
    assert bytes_to_human

# Generated at 2022-06-20 16:30:57.945122
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:31:09.412783
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Unit tests for the function human_to_bytes

    def _test(test_cases):
        # Helper function to run a list of test cases

        for (input, expected) in test_cases:
            result = human_to_bytes(input)
            msg = "Failed to convert %s: (%s != %s)" % (input, expected, result)
            assert expected == result, msg

    def _test_default_unit(test_cases, unit):
        # Helper function to run a list of test cases with a default unit

        for (input, expected) in test_cases:
            result = human_to_bytes(input, default_unit=unit)
            msg = "Failed to convert %s with default_unit=%s: (%s != %s)" % (input, unit, expected, result)
            assert expected == result

# Generated at 2022-06-20 16:31:18.026869
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = human_to_bytes('1200')
    assert result == 1200
    result = human_to_bytes('1200b')
    assert result == 1200
    result = human_to_bytes('1200B')
    assert result == 1200
    result = human_to_bytes('1200B', isbits=True)
    assert result == 1200
    result = human_to_bytes('12KB')
    assert result == 12288
    result = human_to_bytes('12Kb', isbits=True)
    assert result == 12288
    result = human_to_bytes('12Kb', isbits=True, unit='b')
    assert result == 12288
    result = human_to_bytes('12Kb', isbits=True, unit='B')
    assert result == 12288

# Generated at 2022-06-20 16:31:29.708508
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10B', 'X') == 10
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10', 'X') == 10
    assert human_to_bytes('10B', 'b') == 10
    assert human_to_bytes('10b', 'X') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10b', 'X') == 10
    assert human_to_bytes('1.5B') == 1
    assert human_to_bytes('1.5Mb') == 1536000
    assert human_to_bytes('1.5Mb', isbits=True) == 1536000
    assert human_to_bytes('1.5MB') == 157

# Generated at 2022-06-20 16:31:33.364513
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Testing simple string in list
    assert lenient_lowercase(['TEST']) == ['test']

    # Testing a number in list
    assert lenient_lowercase([123]) == [123]

    # Testing a unicode string in list
    assert lenient_lowercase([u'\u2713']) == [u'\u2713']


# Generated at 2022-06-20 16:31:40.698307
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(4) == '4 Bytes'
    assert bytes_to_human(502) == '502 Bytes'
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'

# Generated at 2022-06-20 16:31:48.521657
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1, isbits=False, unit=None) == '1.00 Bytes'
    assert bytes_to_human(10, isbits=False, unit=None) == '10.00 Bytes'
    assert bytes_to_human(1000, isbits=False, unit=None) == '1.00 KBytes'
    assert bytes_to_human(1000000000000, isbits=False, unit=None) == '10995.11 TBytes'
    assert bytes_to_human(1000000000000, isbits=True, unit=None) == '90995.11 Tbits'
    assert bytes_to_human(1000, isbits=False, unit='k') == '1.00 KBytes'

# Generated at 2022-06-20 16:31:59.594752
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:32:09.391790
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Unit test for function human_to_bytes

    '''

    for size in ['1', '1.5', '1.50', '3.5K', '3.5Kb', '3.6Kb', '1.5M', '1.5Mb', '2.5Mb']:
        print('%s becomes %s' % (size, bytes_to_human(human_to_bytes(size))))

    for size in ['1', '1.5', '1.50', '3.5K', '3.5Kb', '3.6Kb', '1.5M', '1.5Mb', '2.5Mb']:
        print('%s becomes %s' % (size, bytes_to_human(human_to_bytes(size, isbits=True))))

   

# Generated at 2022-06-20 16:32:15.161377
# Unit test for function bytes_to_human
def test_bytes_to_human():
    for number in [0.1, 0.5, 1, 10, 14, 100, 999, 1000, 1000.0]:
        for unit in sorted(SIZE_RANGES.keys(), key=lambda item: -SIZE_RANGES[item]):
            assert bytes_to_human(number, unit=unit) == '%.2f %s' % (number, unit)


# Generated at 2022-06-20 16:32:27.908689
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # 'MB' case
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1MB', 'MB') == 1048576
    assert human_to_bytes('1MB', '') == 1048576
    assert human_to_bytes('1MB', None) == 1048576
    # 'Mb' case
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1Mb', 'Mb', True) == 1048576
    assert human_to_bytes('1Mb', '', True) == 1048576
    assert human_to_bytes('1Mb', None, True) == 1048576
    # 'Kb' case

# Generated at 2022-06-20 16:32:37.606391
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:32:48.952910
# Unit test for function human_to_bytes
def test_human_to_bytes():
    cases = (
        ('H2', "128M", (1 << 27)),
        ('H3', "128M", (1 << 27)),
        ('H4', "128MB", (1 << 27)),
        ('H5', "128Mb", (1 << 27)),
        ('H6', "128MB", (1 << 27)),
        ('H7', "128Mb", (1 << 27)),
        ('H8', "128MB", (1 << 27)),
        ('H9', "128Mb", (1 << 27)),
        ('H10', "128mb", (1 << 27)),
    )

# Generated at 2022-06-20 16:32:59.793905
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1 KBytes'
    assert bytes_to_human(1024, False, 'b') == '8 bits'
    assert bytes_to_human(1024, False, 'B') == '1 KBytes'
    assert bytes_to_human(1024, True, 'b') == '1024 bits'
    assert bytes_to_human(1024, True, 'B') == '8 bits'
    assert bytes_to_human(1024, False, 'k') == '1 kBytes'
    assert bytes_to_human(1024, False, 'K') == '1 KBytes'
    assert bytes_to_human(1024, True, 'k') == '1024 bits'
    assert bytes_to_human(1024, True, 'K') == '8 bits'

# Generated at 2022-06-20 16:33:10.061789
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test Bytes
    assert human_to_bytes('0B') == 0
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('0.1B') == 0
    assert human_to_bytes('0.2B') == 0
    assert human_to_bytes('0.5B') == 0
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.2B') == 1
    assert human_to_bytes('1.5B') == 2
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10.1B') == 10
    assert human_to_bytes('10.2B') == 10
    assert human_to_bytes('10.5B') == 11
    assert human_to_bytes

# Generated at 2022-06-20 16:33:18.343261
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10) == 10
    assert human_to_bytes('10KB') == 10240
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10GB') == 10737418240
    assert human_to_bytes('10TB') == 10995116277760
    assert human_to_bytes('10PB') == 11258999068426240
    assert human_to_bytes('10EB') == 11529215046068469760
    assert human_to_bytes('10ZB') == 1180591620717411303424
    assert human_to_bytes('10YB') == 1208925819614629174706176
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M')

# Generated at 2022-06-20 16:33:28.523543
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(50) == 50
    assert human_to_bytes(50.0) == 50
    assert human_to_bytes('50') == 50
    assert human_to_bytes('50.0') == 50

    assert human_to_bytes('50.0M') == 50 * 1024 * 1024
    assert human_to_bytes('50.0MB') == 50 * 1024 * 1024
    assert human_to_bytes('50.0Mb') == 50 * 1024 * 1024
    assert human_to_bytes('50.0m') == 50 * 1024

    assert human_to_bytes('50.0K') == 50 * 1024
    assert human_to_bytes('50.0KB') == 50 * 1024
    assert human_to_bytes('50.0Kb') == 50 * 1024


# Generated at 2022-06-20 16:33:38.626844
# Unit test for function human_to_bytes
def test_human_to_bytes():

    error_list = []

    human_to_bytes_test_data = [
        ('2K', 2048),
        ('2k', 2048),
        ('1M',  1048576),
        ('1m',  1048576),
        ('1G',  1073741824),
        ('1g',  1073741824),
        ('1T',  1099511627776),
        ('1t',  1099511627776),
        ('2',   2),
    ]

    # Do not test these cases, they depend on the M values on the system
    # ('1M', 1),
    # ('1M', 2),
    # ('1M', 3),
    # ('1M', 4),
    # ('1G', 1),
    # ('1G', 2),
    # ('1G', 3),

# Generated at 2022-06-20 16:33:50.650909
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert(bytes_to_human(1234) == '1.23 KB')
    assert(bytes_to_human(1234, unit='b') == '10.07 bits')
    assert(bytes_to_human(1234, unit='b') == '10.07 bits')
    assert(bytes_to_human(2048, unit='b') == '16.38 bits')
    assert(bytes_to_human(2048, unit='b') == '16.38 bits')
    assert(bytes_to_human(4096, unit='b') == '32.77 bits')
    assert(bytes_to_human(4096, unit='kb') == '4.00 KB')
    assert(bytes_to_human(4096, unit='kb') == '4.00 KB')

# Generated at 2022-06-20 16:33:56.087153
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['F', 'f', 'Foo', 'FOo']) == ['f', 'f', 'foo', 'foo']
    assert lenient_lowercase(['F', Foo, Foo]) == ['f', Foo, Foo]
    assert lenient_lowercase([Foo, 'F', Foo]) == [Foo, 'f', Foo]
    assert lenient_lowercase(['Foo', 'F', Foo]) == ['foo', 'f', Foo]
    assert lenient_lowercase([Foo, 'F']) == [Foo, 'f']

# Generated at 2022-06-20 16:34:08.615938
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1000) == '1000.00 Bytes'
    assert bytes_to_human(1023) == '1023.00 Bytes'

    assert bytes_to_human(1, unit='k') == '0.00 KB'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, unit='k') == '1.00 KB'
    assert bytes_to_human(1025, unit='k') == '1.00 KB'
    assert bytes_to_human(1025, unit='K') == '1.00 KB'
    assert bytes_to_human(1025, unit='Kb') == '1.00 KB'

# Generated at 2022-06-20 16:34:19.892810
# Unit test for function bytes_to_human
def test_bytes_to_human():

    """
    Test to ensure that we have the correct values on the output
    """
    assert bytes_to_human(1234) == '1.23 KB'
    assert bytes_to_human(456789) == '456.79 KB'
    assert bytes_to_human(10000000000) == '10.00 GB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(100000) == '97.66 KB'
    assert bytes_to_human(3072) == '3.00 KB'
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, isbits=True) == '8.00 Kb'
   

# Generated at 2022-06-20 16:34:31.637606
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1234567890) == '1.15 GB'
    assert bytes_to_human(1234567890, unit='B') == '1.15 GB'
    assert bytes_to_human(1234567890, unit='b') == '9.54 Gb'
    assert bytes_to_human(1234567890, unit='byte') == '1.15 GB'
    assert bytes_to_human(1234567890, unit='Byte') == '1.15 GB'
    assert bytes_to_human(1234567890, unit='B,') == '1.15 GB'
    assert bytes_to_human(1234567890, unit='Me') == '1.20 MB'
    assert bytes_to_human(1234567890, unit=' ') == '1.15 GB'
   

# Generated at 2022-06-20 16:34:39.851141
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:34:48.691409
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1KBb') == 1024
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1bB') == 1
    assert human_to_bytes('1kB') == 1024
    assert human_to_bytes('1bK') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1MB') == 10

# Generated at 2022-06-20 16:35:00.029064
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2K', None, True) == 2048 * 8
    assert human_to_bytes('2Kb') == 2048 * 8
    assert human_to_bytes('2M') == 2 * 1024 * 1024
    assert human_to_bytes('2Mb') == 2 * 1024 * 1024 * 8
    assert human_to_bytes('2G') == 2 * 1024 * 1024 * 1024
    assert human_to_bytes('2Gb') == 2 * 1024 * 1024 * 1024 * 8
    assert human_to_bytes('2T') == 2 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('2Tb') == 2 * 1024 * 1024 * 1024 * 1024 * 8
    assert human_to_bytes

# Generated at 2022-06-20 16:35:07.305394
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A','B','C','D','E']) == ['a','b','c','d','e']
    assert lenient_lowercase(['A',2,'C',4,'E']) == ['a',2,'c',4,'e']
    assert lenient_lowercase(['A',2.3,'C',4.56,'E']) == ['a',2.3,'c',4.56,'e']


# Generated at 2022-06-20 16:35:15.848027
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:35:27.572086
# Unit test for function bytes_to_human
def test_bytes_to_human():
    size = 1
    assert(bytes_to_human(size) == '1.00 B')
    assert(bytes_to_human(size, isbits=True) == '8.00 b')
    size = 1024
    assert(bytes_to_human(size) == '1.00 K')
    assert(bytes_to_human(size, isbits=True) == '8.00 Kb')
    size = 10240
    assert(bytes_to_human(size) == '10.00 K')
    assert(bytes_to_human(size, isbits=True) == '80.00 Kb')
    size = 1048576
    assert(bytes_to_human(size) == '1.00 M')
    assert(bytes_to_human(size, isbits=True) == '8.00 Mb')
    size

# Generated at 2022-06-20 16:35:31.341453
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['one', 'TWO', 3, 'FoUr']
    result = ['one', 'two', 3, 'four']
    assert(lenient_lowercase(test_list) == result)
