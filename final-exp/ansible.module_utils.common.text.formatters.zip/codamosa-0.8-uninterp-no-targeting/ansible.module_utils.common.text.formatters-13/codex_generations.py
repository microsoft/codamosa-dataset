

# Generated at 2022-06-20 16:25:59.520909
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert(bytes_to_human(1048576) == '1.00 MB')
    assert(bytes_to_human(1048576, unit='m') == '1024.00 MB')
    assert(bytes_to_human(1048576, unit='mB') == '1024.00 MB')
    assert(bytes_to_human(1048576, unit='mb') == '8388608.00 mb')
    assert(bytes_to_human(1048576, unit='b') == '8388608.00 b')
    assert(bytes_to_human(1048576, unit='B') == '1048576.00 B')
    assert(bytes_to_human(1048576, unit='K') == '1024.00 KB')

# Generated at 2022-06-20 16:26:06.984395
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:26:15.056080
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == "1.00 Bytes"
    assert bytes_to_human(2) == "2.00 Bytes"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1024*1024) == "1.00 MB"
    assert bytes_to_human(1024*1024*1024) == "1.00 GB"
    assert bytes_to_human(1024*1024*1024*1024) == "1.00 TB"
    assert bytes_to_human(1024*1024*1024*1024*1024) == "1.00 PB"
    assert bytes_to_human(1024*1024*1024*1024*1024*1024) == "1.00 EB"

# Generated at 2022-06-20 16:26:25.693788
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Valid cases
    assert '1.00 Bytes' == bytes_to_human(1)
    assert '1.00 Bytes' == bytes_to_human(1, unit='')
    assert '1.00 Bytes' == bytes_to_human(1, unit='b')
    assert '1.00 Bytes' == bytes_to_human(1, unit='B')
    assert '1.00 Bytes' == bytes_to_human(1, isbits=False)
    assert '1.00 Bytes' == bytes_to_human(1, isbits=False, unit='')
    assert '1.00 Bytes' == bytes_to_human(1, isbits=False, unit='b')

# Generated at 2022-06-20 16:26:37.881293
# Unit test for function bytes_to_human
def test_bytes_to_human():

    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(0, unit='b') == '0 Bytes'
    assert bytes_to_human(0, unit='B') == '0 Bytes'

    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1, unit='b') == '1 Bytes'

    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, unit='B') == '1.00 KB'
    assert bytes_to_human(1024, unit='b') == '1.00 KB'

    assert bytes_to_human(2048) == '2.00 KB'

# Generated at 2022-06-20 16:26:49.359613
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # bytes case
    assert human_to_bytes('100', isbits=False) == 100
    assert human_to_bytes('100', isbits=False, default_unit='b') == 100
    assert human_to_bytes('100b', isbits=False) == 100
    assert human_to_bytes('100B', isbits=False) == 100
    assert human_to_bytes('100KB', isbits=False) == 102400
    assert human_to_bytes('100MB', isbits=False) == 102400 * 1024
    assert human_to_bytes('100TB', isbits=False) == 102400 * 1024 * 1024 * 1024
    # bits case
    assert human_to_bytes('100', isbits=True) == 100
    assert human_to_bytes('100', isbits=True, default_unit='b') == 100

# Generated at 2022-06-20 16:26:59.661676
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1099511627776) == '1.00 TB'
    assert bytes_to_human(1125899906842624) == '1.00 PB'
    assert bytes_to_human(1152921504606846976) == '1.00 EB'
    assert bytes_to_human(1180591620717411303424) == '1.00 ZB'
    assert bytes_to_human(1208925819614629174706176) == '1.00 YB'
   

# Generated at 2022-06-20 16:27:10.205266
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'A']) == [1, 'a']
    assert lenient_lowercase(['a', 'b']) == ['a', 'b']
    assert lenient_lowercase(['A', 'b']) == ['a', 'b']
    assert lenient_lowercase([1, 'a']) == [1, 'a']
    assert lenient_lowercase(['a', 'B']) == ['a', 'b']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 'B', 'c']) == [1, 'b', 'c']



# Generated at 2022-06-20 16:27:18.329604
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(0, unit='b') == '0.00 bits'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='B') == '1.00 B'
    assert bytes_to_human(2 ** 10) == '1.00 KBytes'
    assert bytes_to_human(2 ** 10, unit='B') == '1024.00 B'
    assert bytes_to_human(2 ** 20) == '1.00 MBytes'
    assert bytes_to_human(2 ** 30) == '1.00 GBytes'
    assert bytes_to_human(2 ** 40) == '1.00 TBytes'

# Generated at 2022-06-20 16:27:25.725074
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest

    # Converting bytes
    assert human_to_bytes('1.1') == 1.1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.1B') == 1.1
    assert human_to_bytes('1.1KB') == 1.1 * SIZE_RANGES['K']
    assert human_to_bytes('1.1Kb') == 1.1 * SIZE_RANGES['K']
    assert human_to_bytes('1.1KB', isbits=True) == 1.1 * SIZE_RANGES['K']
    assert human_to_bytes('1.1MB') == 1.1 * SIZE_RANGES['M']

# Generated at 2022-06-20 16:27:35.181493
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'c', 'D', 'e', 1]) == ['a', 'b', 'c', 'd', 'e', 1]
    assert lenient_lowercase(['A', 'B', 'c', 'D', 'e', 1, None] == ['a', 'b', 'c', 'd', 'e', 1, None])
    assert lenient_lowercase(['A', 'B', 'c', 'D', 'e', 1, {}] == ['a', 'b', 'c', 'd', 'e', 1, {}])
    assert lenient_lowercase([]) == []



# Generated at 2022-06-20 16:27:42.585170
# Unit test for function bytes_to_human
def test_bytes_to_human():
    result = bytes_to_human(1048576, unit='M')
    assert result == "1.00 MB"
    result = bytes_to_human(10485760, unit='M')
    assert result == "10.00 MB"
    result = bytes_to_human(104857600, unit='M')
    assert result == "100.00 MB"
    result = bytes_to_human(1048576000, unit='M')
    assert result == "1000.00 MB"



# Generated at 2022-06-20 16:27:50.579484
# Unit test for function bytes_to_human
def test_bytes_to_human():
    comp_list = [
        (10, "10 Bytes"),
        (1023, "1023 Bytes"),
        (1024, "1.00 KB"),
        (1024 * 1024, "1.00 MB"),
        (1024 * 1024 * 1024, "1.00 GB"),
        (1024 * 1024 * 1024 * 1024, "1.00 TB"),
        (1024 * 1024 * 1024 * 1024 * 1024, "1.00 PB"),
        (1024 * 1024 * 1024 * 1024 * 1024 * 1024, "1.00 EB"),
        (1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024, "1.00 ZB"),
        (1024 ** 10, "1.00 YB"),
    ]


# Generated at 2022-06-20 16:27:55.739478
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['ABC', 1, 2, 3, 'DEF', 'GHI']) == ['abc', 1, 2, 3, 'def', 'ghi'] or \
        lenient_lowercase(['ABC', 1, 2, 3, 'DEF', 'GHI']) == ['Abc', 1, 2, 3, 'Def', 'Ghi']

# Generated at 2022-06-20 16:28:03.098373
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # 'B' first
    assert(human_to_bytes('1B') == 1)
    assert(human_to_bytes('1.25B') == 1)
    # test upper and lower cases here
    assert(human_to_bytes('100b') == 100)
    assert(human_to_bytes('100B') == 100)
    assert(human_to_bytes('100.5b') == 100)
    assert(human_to_bytes('100.5B') == 100)
    assert(human_to_bytes('0b') == 0)
    assert(human_to_bytes('0.5B') == 0)
    assert(human_to_bytes('1M') == 1 << 20)
    assert(human_to_bytes('1m') == 1 << 20)

# Generated at 2022-06-20 16:28:10.770410
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test bytes
    print('***** Testing bytes_to_human() conversion function with bytes *****')

# Generated at 2022-06-20 16:28:22.931738
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("positive test for human_to_bytes()")
    for key, value in sorted(iteritems(SIZE_RANGES)):
        if key != 'B':
            if value != 1:
                print("    test for '%s'" % key)
                assert(human_to_bytes(key) == value)
                assert(human_to_bytes(key * 0.5) == int(value / 2))
                assert(human_to_bytes(key + "b") == value)
                assert(human_to_bytes(key + "b", isbits=True) == value)
            else:
                print("    test for '%s'" % key)
                assert(human_to_bytes(key) == 1)
                assert(human_to_bytes(key, isbits=True) == 1)


# Generated at 2022-06-20 16:28:34.096071
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['X', 'Y', 'Z']) == ['x', 'y', 'z']
    assert lenient_lowercase(['a', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', '1', 'C']) == ['a', '1', 'c']
    assert lenient_lowercase(['A', [1, 2, 3], 'C']) == ['a', [1, 2, 3], 'c']
    assert lenient_lowercase(['A', None, 'C'])

# Generated at 2022-06-20 16:28:41.779268
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760, "human_to_bytes('10M') failed"
    assert human_to_bytes('10Mb') == 10485760, "human_to_bytes('10Mb') failed"
    assert human_to_bytes('10Mb', isbits=True) == 13107200, "human_to_bytes('10Mb', isbits=True) failed"
    assert human_to_bytes('2K') == 2048, "human_to_bytes('2K') failed"
    assert human_to_bytes('2K', unit='B') == 2048, "human_to_bytes('2K', unit='B') failed"
    assert human_to_bytes('2K', unit='b') == 2048, "human_to_bytes('2K', unit='b') failed"

# Generated at 2022-06-20 16:28:50.206847
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == "0 Bytes"
    assert bytes_to_human(1) == "1 Byte"
    assert bytes_to_human(10) == "10 Bytes"
    assert bytes_to_human(1023) == "1023 Bytes"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1024 * 1024) == "1.00 MB"
    assert bytes_to_human(1024 * 1024 * 1024) == "1.00 GB"
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == "1.00 TB"
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == "1.00 PB"
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024)

# Generated at 2022-06-20 16:29:02.727318
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    def test(input_list, expected_output):
        result = lenient_lowercase(input_list)
        if result != expected_output:
            raise AssertionError('Test failed for function lenient_lowercase. Expected output: %s. Actual output: %s.' % (expected_output, result))

    # simple test
    test(['test1', 'test2', 'test3'], ['test1', 'test2', 'test3'])
    # make sure the list order is maintained
    test(['test1', 'test2', 'test3', 'test4'], ['test1', 'test2', 'test3', 'test4'])
    # make sure the list order is maintained

# Generated at 2022-06-20 16:29:12.658093
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(2.51) == '2.51 Bytes'
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1025) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024, unit='M') == '1.00MB'
    assert bytes_to_human(1024 * 1024, unit='B') == '1.00 Bytes'

# Generated at 2022-06-20 16:29:23.084004
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import assert_equal

    # convert bytes
    assert_equal(human_to_bytes('1KB'), 1024)
    assert_equal(human_to_bytes('1 Kb'), 1024)
    assert_equal(human_to_bytes('1 KB'), 1024)
    assert_equal(human_to_bytes('1Kb'), 1024)
    assert_equal(human_to_bytes(1024), 1024)
    assert_equal(human_to_bytes(1024, 'B'), 1024)
    assert_equal(human_to_bytes(1024, 'KB'), 1024)
    assert_equal(human_to_bytes(1024, 'Kb'), 1024)
    assert_equal(human_to_bytes(1024, 'KB', isbits=True), 1024)

# Generated at 2022-06-20 16:29:34.371287
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='b') == '1.00 bits'
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(2048, unit='MB') == '0.00 MB'
    assert bytes_to_human(4096) == '4.00 KB'
    assert bytes_to_human(8192) == '8.00 KB'
    assert bytes_to_human(8192, unit='mb') == '0.01 mb'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048576, unit='kb') == '1024.00 kb'

# Generated at 2022-06-20 16:29:42.457336
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2K', default_unit='B') == 2048
    assert human_to_bytes('2K', default_unit='B') == 2048
    assert human_to_bytes('2K', default_unit='b') == 2048
    assert human_to_bytes('2K', default_unit='b', isbits=True) == 2048
    assert human_to_bytes('2Kb', default_unit='b', isbits=True) == 2048
    assert human_to_bytes('1MB', default_unit='B') == 1048576
    assert human_to_bytes('1Mb', default_unit='b', isbits=True) == 1048576
    assert human_to_bytes('2KB', default_unit='B') == 2048
    assert human_

# Generated at 2022-06-20 16:29:45.347443
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [1, 'One', '1', 'ONE']
    assert lenient_lowercase(lst) == [1, 'one', '1', 'one']

# Generated at 2022-06-20 16:29:47.930591
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['abc', 1, 'def', 'GHI']) == ['abc', 1, 'def', 'GHI']



# Generated at 2022-06-20 16:29:55.469792
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10240, unit='K') == '10.00 KBytes'
    assert bytes_to_human(1024, unit='K') == '1.00 KBytes'
    assert bytes_to_human(512, unit='K') == '0.50 KBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 7) == '7.00 TBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 7, isbits=True) == '7.00 Tbits'
    try:
        assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 7, unit='M') == '7.00 MBytes'
    except AssertionError:
        pass

# Generated at 2022-06-20 16:30:02.710571
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['asdf', 5, 'qwer']
    expected_result = ['asdf', 5, 'qwer']
    actual_result = lenient_lowercase(lst)
    assert expected_result == actual_result

    lst = ['ASDF', 5, 'qwer']
    expected_result = ['asdf', 5, 'qwer']
    actual_result = lenient_lowercase(lst)
    assert expected_result == actual_result



# Generated at 2022-06-20 16:30:07.661731
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list1 = ['a','b','c','','d','U','e','abc','f','G','','k','2','1','A','5']
    list2 = ['a','b','c','','d','u','e','abc','f','g','','k','2','1','a','5']
    assert lenient_lowercase(list1) == list2



# Generated at 2022-06-20 16:30:17.364898
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 2]) == ['a', 1, 2]
    assert lenient_lowercase([]) == []



# Generated at 2022-06-20 16:30:22.076746
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase([None]) == [None]
    assert lenient_lowercase(['0']) == ['0']
    assert lenient_lowercase(['0', '0']) == ['0', '0']
    assert lenient_lowercase(['testString1']) == ['teststring1']
    assert lenient_lowercase(['testString1', 'testString2']) == ['teststring1', 'teststring2']
    assert lenient_lowercase(['testString1', 512]) == ['teststring1', 512]
    assert lenient_lowercase(['testString1', None, 'testString2']) == ['teststring1', None, 'teststring2']
    assert lenient_lowercase(['testString1', 512, 'testString2'])

# Generated at 2022-06-20 16:30:28.462883
# Unit test for function bytes_to_human
def test_bytes_to_human():
    for unit in ['b', 'kb', 'MB', 'Gb', 'TB']:
        assert bytes_to_human(1048576, unit=unit) == '1.00 %s' % unit.upper()

    for isbits in [False, True]:
        assert bytes_to_human(10485760, isbits=isbits) == '10.00 %s' % ('bits' if isbits else 'MB')


# Generated at 2022-06-20 16:30:32.551233
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(2048) == '2.00 KBytes'
    assert bytes_to_human(2048, unit='b') == '2048.00 bits'
    assert bytes_to_human(2048, unit='m') == '0.00 MBytes'

# Generated at 2022-06-20 16:30:44.779240
# Unit test for function bytes_to_human
def test_bytes_to_human():
    bytes_to_human_test_data = (
        (1, '1.00 Bytes', 'byte'),
        (1024, '1.00 KB', 'KB'),
        (1048576, '1.00 MB', None),
        (1073741824, '1.00 GB', None),
        ((2 ** 10), '1.00 KB', None),
        ((2 ** 20), '1.00 MB', None),
        ((2 ** 30), '1.00 GB', None),
        ((2 ** 40), '1.00 TB', None),
        ((2 ** 50), '1.00 PB', None),
        ((2 ** 60), '1.00 EB', None),
        ((2 ** 70), '1.00 ZB', None),
        ((2 ** 80), '1.00 YB', None),
    )
   

# Generated at 2022-06-20 16:30:56.333508
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1 M') == 1048576
    assert human_to_bytes('1 Mb') == 131072
    # assert human_to_bytes('1 mb') == 131072
    # assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1MB', unit='b') == 8388608
    assert human_to_bytes('1Mb', unit='b', isbits=True) == 8388608
    assert human_to_bytes('10MB', unit='b', isbits=True) == 83886080
    assert human_to_bytes('1Mb', isbits=True) == 8388608
    assert human_to_bytes('10MB', isbits=True) == 83886080
    assert human_to_bytes('1mb') == 131072


# Generated at 2022-06-20 16:31:07.950947
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1000) == "1000 Bytes"
    assert bytes_to_human(1000, unit='B') == "1000 Bytes"
    assert bytes_to_human(1000, unit='b') == "1000 bits"
    assert bytes_to_human(1000, isbits=True) == "1000 bits"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1024, unit='B') == "1.00 KB"
    assert bytes_to_human(1024, unit='b') == "1.00 Kb"
    assert bytes_to_human(1024, isbits=True) == "1.00 Kb"
    assert bytes_to_human(1048576) == "1.00 MB"

# Generated at 2022-06-20 16:31:17.105073
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'
    assert bytes_to_human(10, unit='K') == '10.00 KB'
    assert bytes_to_human(10, unit='M') == '10.00 MB'
    assert bytes_to_human(10, unit='G') == '10.00 GB'
    assert bytes_to_human(10, unit='T') == '10.00 TB'
    assert bytes_to_human(10, unit='P') == '10.00 PB'
    assert bytes_to_human(10, unit='E') == '10.00 EB'

# Generated at 2022-06-20 16:31:28.086268
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """
    Test conversion of various strings to bytes
    """
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', 'B') == 10485760
    assert human_to_bytes('10', 'MB') == 10485760
    assert human_to_bytes('10mb') == 1048576
    assert human_to_bytes('100') == 100
    assert human_to_bytes('100', 'MB') == 104857600
    assert human_to_bytes('100', 'b') == 800
    assert human_to_bytes(100, 'Mb') == 104857600
    assert human_to_bytes(100, 'b') == 800

    try:
        human_to_bytes('100', 'F')
    except ValueError:
        pass

# Generated at 2022-06-20 16:31:30.667318
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 1, 'B', 2]) == ['a', 1, 'b', 2]

# Generated at 2022-06-20 16:31:44.455216
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test lowercasing of a list of unicode strings
    test_list = ['Alaska', 'Alabama', u'Montana', u'Ark\xe1nsas']
    test_list_lowercased = ['alaska', 'alabama', u'montana', u'ark\xe1nsas']
    assert lenient_lowercase(test_list) == test_list_lowercased
    # Test conversion of non-string elements of a list
    test_list = ['Alaska', 1, u'Montana', 0]
    test_list_lowercased = ['alaska', 1, u'montana', 0]
    assert lenient_lowercase(test_list) == test_list_lowercased



# Generated at 2022-06-20 16:31:54.257616
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024000) == '1000.00 KB'
    assert bytes_to_human(1024000, unit='b') == '8192.00 Kbit'
    assert bytes_to_human(1024000, isbits=True) == '8192.00 Kbit'
    assert bytes_to_human(1024000, isbits=True, unit='b') == '8192.00 Kbit'
    assert bytes_to_human(1024000, isbits=True, unit='M') == '8.00 MBit'
    assert bytes_to_human(1024000, isbits=False, unit='M') == '0.98 MB'



# Generated at 2022-06-20 16:31:59.365453
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1025 * 1024 * 1024) == '1025.00 MB'



# Generated at 2022-06-20 16:32:01.818119
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['a', 'b', 'c', 3, 4] == lenient_lowercase(['A', 'B', 'C', 3, 4])

# Generated at 2022-06-20 16:32:03.658752
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['aBc', 'DEf', 123]) == ['abc', 'def', 123])


# Generated at 2022-06-20 16:32:12.111974
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(100) == '100 Bytes'
    assert bytes_to_human(999) == '999 Bytes'
    assert bytes_to_human(1000) == '0.98 KBytes'
    assert bytes_to_human(1024) == '1.00 KBytes'
    assert bytes_to_human(10*1024) == '10.00 KBytes'
    assert bytes_to_human(100*1024) == '97.66 KBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TBytes'


# Generated at 2022-06-20 16:32:23.483143
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB') == 1024**2
    assert human_to_bytes('1GB') == 1024**3
    assert human_to_bytes('1TB') == 1024**4
    assert human_to_bytes('1PB') == 1024**5
    assert human_to_bytes('1EB') == 1024**6
    assert human_to_bytes('1ZB') == 1024**7
    assert human_to_bytes('1YB') == 1024**8
    assert human_to_bytes('1YiB') == 1024**8
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1Mb') == 1024**2
    assert human_to_bytes

# Generated at 2022-06-20 16:32:34.806273
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == "10.00 Bytes"
    assert bytes_to_human(10, unit='B') == "10.00 Bytes"
    assert bytes_to_human(10, unit='b') == "10.00 bits"
    assert bytes_to_human(10, unit='Kb') == "80.00 bits"
    assert bytes_to_human(10, unit='KB') == "10.00 KBytes"
    assert bytes_to_human(10, unit='kb') == "80.00 Kbits"
    assert bytes_to_human(10, unit='Mb') == "81920.00 bits"
    assert bytes_to_human(10, isbits=True, unit='MB') == "80.00 Mbits"

# Generated at 2022-06-20 16:32:47.486558
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1025) == '1.00 KB'
    assert bytes_to_human(1000, unit='K') == '1.00 KB'
    assert bytes_to_human(1048577) == '1.00 MB'
    assert bytes_to_human(1048576, unit='M') == '1.00 MB'
    assert bytes_to_human(1073741825) == '1.00 GB'
    assert bytes_to_human(1073741824, unit='G') == '1.00 GB'
    assert bytes_to_human(110000000000) == '1.00 TB'
    assert bytes_to_human(1099511627776, unit='T') == '1.00 TB'

# Generated at 2022-06-20 16:32:58.311347
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # check string passes as integer
    assert bytes_to_human(1024) == '1.00 KB'
    # check string
    assert bytes_to_human('1024') == '1.00 KB'
    # check type error
    try:
        bytes_to_human(u'1024')
    except TypeError:
        pass
    else:
        assert False, 'Expected TypeError but no exception happened'

    # check bits
    assert bytes_to_human(1024, isbits=True) == '8.00 Kb'
    # check forced unit
    assert bytes_to_human(1024, unit='M') == '1.00 MB'
    assert bytes_to_human(1024, isbits=True, unit='G') == '1.00 Gb'

    # check negative value error

# Generated at 2022-06-20 16:33:08.040909
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase((123, 'AbCd')) == [123, 'abcd']

# Generated at 2022-06-20 16:33:16.536299
# Unit test for function bytes_to_human
def test_bytes_to_human():

    try:
        r = bytes_to_human(-1)
    except Exception:
        pass
    else:
        raise AssertionError("convert negative number (%d) to bytes should raise exception" % -1)


# Generated at 2022-06-20 16:33:21.629013
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    data = [{'a': 'FOo', 'b': 'Bar', 'c': 3.14},
            {'a': 'aZz', 'b': 'bAr', 'c': 3.14},
            {'a': 'Az', 'b': 'bAr', 'c': ['Baz']}]
    data_lower = [{'a': 'foo', 'b': 'bar', 'c': 3.14},
                  {'a': 'azz', 'b': 'bar', 'c': 3.14},
                  {'a': 'az', 'b': 'bar', 'c': ['baz']}]

    for (element, elem_lower) in zip(data, data_lower):
        assert lenient_lowercase(element) == elem_lower

# Generated at 2022-06-20 16:33:23.813011
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["A", "b", 1, "c"]) == ["a", "b", 1, "c"]


# Generated at 2022-06-20 16:33:31.522915
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(2 ** 20) == '1.00 MB'
    assert bytes_to_human(2 ** 31) == '2.00 GB'
    assert bytes_to_human(2 ** 10, isbits=True) == '1.00 Kb'
    assert bytes_to_human(2 ** 33, isbits=True) == '2.00 Gb'



# Generated at 2022-06-20 16:33:42.363946
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10m') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10MB', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10') == 10
    try:
        human_to_bytes('10Mz')
        raise Exception('Exception expected')
    except ValueError:
        pass

    try:
        human_to_bytes('10Z')
        raise Exception('Exception expected')
    except ValueError:
        pass


# Generated at 2022-06-20 16:33:51.850264
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', None, 'C']) == ['a', None, 'c']
    assert lenient_lowercase(['A', 'B', None]) == ['a', 'b', None]
    assert lenient_lowercase(['A', 1, {}]) == ['a', 1, {}]
    assert lenient_lowercase([None, None, None]) == [None, None, None]
    assert lenient_lowercase([]) == []

# Generated at 2022-06-20 16:34:04.351208
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import types
    import unittest

    # test for exceptions
    with unittest.TestCase():
        class TestHumanToBytes(unittest.TestCase):
            def test_exceptions(self):
                with self.assertRaises(ValueError):
                    human_to_bytes('')
                with self.assertRaises(ValueError):
                    human_to_bytes('1')
                with self.assertRaises(ValueError):
                    human_to_bytes('1K')
                with self.assertRaises(ValueError):
                    human_to_bytes('1Kb')
                with self.assertRaises(ValueError):
                    human_to_bytes('Kb')
                with self.assertRaises(ValueError):
                    human_to_bytes('1kb')

# Generated at 2022-06-20 16:34:07.165191
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['FOO', ['bar', 'baz'], 'baz']) == ['foo', ['bar', 'baz'], 'baz']

# Generated at 2022-06-20 16:34:09.396585
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', [], {}, None]) == ['a', 'b', [], {}, None]
    assert lenient_lowercase(['A', 'B', [], {}, None]) == ['a', 'b', [], {}, None]

# Generated at 2022-06-20 16:34:41.939535
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import unittest

# Generated at 2022-06-20 16:34:50.415087
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:35:02.870446
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert 0 == human_to_bytes(0)
    assert 1 == human_to_bytes('1')
    assert 1 == human_to_bytes('1b')
    assert 10 == human_to_bytes('10')
    assert 1024 == human_to_bytes('1K')
    assert 1024 == human_to_bytes('1KB')
    assert 1024 == human_to_bytes('1Kb')
    assert 1024 == human_to_bytes('1k')
    assert 1024 == human_to_bytes('1kb')
    assert 1 << 20 == human_to_bytes('1MB')
    assert 1 << 20 == human_to_bytes('1Mb')
    assert 1 << 10 == human_to_bytes('1KB')
    assert 1 << 10 == human_to_bytes('1Kb')
    assert 1 << 30 == human_to

# Generated at 2022-06-20 16:35:12.737041
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:35:23.277566
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:35:33.981723
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(2) == '2.00 Bytes'
    assert bytes_to_human(2048) == '2.00 KBytes'
    assert bytes_to_human(2048.5) == '2.00 KBytes'
    assert bytes_to_human(2048, unit='K') == '2.00 KBytes'
    assert bytes_to_human(2048, unit='Kb') == '16384.00 bits'
    assert bytes_to_human(2048, unit='M') == '0.00 MBytes'
    assert bytes_to_human(2048, unit='G') == '0.00 GBytes'

# Generated at 2022-06-20 16:35:44.386112
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # testing default unit B (bytes)
    print('Bytes to bytes test:')
    value = '1B'
    expected = 1
    result = human_to_bytes(value)
    print('Result: {} \t\tExpected: {} \t\tStatus: {}'.format(result, expected, 'PASS' if result == expected else 'FAIL'))

    print('Bytes to bytes test:')
    value = '1'
    expected = 1
    result = human_to_bytes(value)
    print('Result: {} \t\tExpected: {} \t\tStatus: {}'.format(result, expected, 'PASS' if result == expected else 'FAIL'))

    value = '1.2'
    expected = 1.2
    result = human_to_bytes(value)