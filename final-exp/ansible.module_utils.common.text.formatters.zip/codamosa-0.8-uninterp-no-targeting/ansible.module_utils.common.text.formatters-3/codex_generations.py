

# Generated at 2022-06-20 16:25:57.538926
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M', isbits=False) == 10485760
    assert human_to_bytes('10M', isbits=True) == 83886080
    assert human_to_bytes('10MB', isbits=False) == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 83886080
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10MB') == 83886080
    assert human_to_bytes('10mB') == 83886080
    assert human_to_bytes('10MB', default_unit='B') == 10485760
    assert human_to_bytes('10MB', default_unit='b') == 83886080

# Generated at 2022-06-20 16:26:04.733484
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1G', unit='M') == 1048576
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5G', unit='M') == 1572864
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5M', unit='G') == 0
    assert human_to_bytes('1.5M', unit='M') == 1572864
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1.5K') == 1536

# Generated at 2022-06-20 16:26:12.556989
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert '12.00 B' == bytes_to_human(12)
    assert '12.00 Bytes' == bytes_to_human(12, False, 'B')
    assert '1.00 KB' == bytes_to_human(1024)
    assert '1.00 KB' == bytes_to_human(1000, False, 'KB')
    assert '1.00 MB' == bytes_to_human(1000000, False, 'MB')
    assert '9.77 GB' == bytes_to_human(10000000000)
    assert '0.10 TB' == bytes_to_human(100000000000)
    assert '0.01 PB' == bytes_to_human(1000000000000)
    assert '0.00 EB' == bytes_to_human(10000000000000)
    assert '0.00 ZB' == bytes_

# Generated at 2022-06-20 16:26:16.431513
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['a', 'b', 'c'] == lenient_lowercase(['A', 'B', 'C'])
    assert [42] == lenient_lowercase([42])
    assert [42, 'a', 'b', 'c'] == lenient_lowercase([42, 'A', 'B', 'C'])
    assert [] == lenient_lowercase([])

# Generated at 2022-06-20 16:26:17.751484
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Abc', 12, 'Xyz']) == ['abc', 12, 'xyz']

# Generated at 2022-06-20 16:26:23.774583
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes('10M', 'M') == 10485760
    assert human_to_bytes('10k') == human_to_bytes(10, 'k') == 10240
    assert human_to_bytes('10k', 'k') == 10240
    assert human_to_bytes('10k', 'm') is None
    assert human_to_bytes('10m') is None
    assert human_to_bytes('10Mb') == human_to_bytes(10, 'mb', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10mb', isbits=True)

# Generated at 2022-06-20 16:26:35.670038
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(61586948, unit='K') == '60.00 KB'
    assert bytes_to_human(61586948, unit='M') == '0.06 MB'
    assert bytes_to_human(61586948, unit='b') == '488.69 Kbits'
    assert bytes_to_human(61586948, isbits=True, unit='b') == '488.69 Kbits'
    assert bytes_to_human(61586948, isbits=True, unit='B') == '61.59 MB'
    assert bytes_to_human(61586948, unit='B') == '61.59 MB'
    assert bytes_to_human(61586948, unit=None) == '61.59 MB'

# Generated at 2022-06-20 16:26:40.700555
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print(bytes_to_human(4278190080, None, 'b'))
    print(bytes_to_human(4278190080, None, 'B'))
    print(bytes_to_human(4278190080, True, 'b'))
    print(bytes_to_human(4278190080, True, 'B'))
    print(bytes_to_human(4278190080, True, None))

# Generated at 2022-06-20 16:26:44.706286
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['a', 'B', 3, 'D']) == ['a', 'b', 3, 'd']


# Generated at 2022-06-20 16:26:55.893405
# Unit test for function bytes_to_human
def test_bytes_to_human():
    test_set = (
        (0, '0 Bytes'),
        (1, '1 Bytes'),
        (1024, '1.00 KB'),
        (1048576, '1.00 MB'),
        (1073741824, '1.00 GB'),
        (1099511627776, '1.00 TB'),
        (1125899906842624, '1.00 PB'),
        (1152921504606846976, '1.00 EB'),
        (1180591620717411303424, '1.00 ZB'),
        (1208925819614629174706176, '1.00 YB'),
    )
    for i, o in test_set:
        assert bytes_to_human(i) == o

# Generated at 2022-06-20 16:27:10.825488
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:27:12.442503
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['a', 'B', ('c', 'D')] == lenient_lowercase(['A', 'B', ('c', 'D')])


# Generated at 2022-06-20 16:27:19.618032
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(100100100100100100100100100100100) == '100100100100100100100100100100100 Bytes'
    assert bytes_to_human(100100100100100100100100100100100, unit='G') == '100100.10 Gigabytes'
    assert bytes_to_human(100100100100100100100100100100100, unit='m') == '100100100100100100100100100100100 Megabytes'
    assert bytes_to_human(100100100100100100100100100100100, unit='y') == '100100100100100100100100100100100 Yottabytes'
    assert bytes_to_human(100100100100100100100100100100100, unit='z') == '100100100100100100100100100100100 Zettabytes'
    assert bytes

# Generated at 2022-06-20 16:27:26.282328
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # no unit ('10')
    assert human_to_bytes('10') == 10
    # unit ('10M')
    assert human_to_bytes('10M') == 10485760
    # unit ('10Mb')
    assert human_to_bytes('10Mb', True) == 10485760
    # unit ('10MB')
    assert human_to_bytes('10MB') == 10485760
    # unit ('10mb')
    assert human_to_bytes('10mb', True) == 10485760
    # unit ('10b')
    assert human_to_bytes('10b', True) == 10
    # unit ('10B')
    assert human_to_bytes('10B') == 10

    # with default unit ('10', 'M')

# Generated at 2022-06-20 16:27:35.451318
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes(1) == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1.2KB') == 1249
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.1M') == 1153433
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1.2G') == 1288490189
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1.2T') == 1319413953356

    assert human_to_bytes(1, default_unit='G') == 1073741824

# Generated at 2022-06-20 16:27:45.926385
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1.1) == '1.10 Bytes'
    assert bytes_to_human(1.1, isbits=True) == '1.10 bits'
    assert bytes_to_human(5000) == '4.88 KB'
    assert bytes_to_human(1000000) == '976.56 KB'
    assert bytes_to_human(1000000000) == '953.67 MB'
    assert bytes_to_human(1000000000000) == '931.32 GB'
    assert bytes_to_human(1000000000000000) == '909.49 TB'
    assert bytes_to_human(1000000000000000000) == '888.16 PB'


# Generated at 2022-06-20 16:27:49.694117
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['test', 'TeSt', u'test', u'TeSt', {'test': 'test'}, 2]
    result = ['test', 'TeSt', u'test', u'TeSt', {'test': 'test'}, 2]
    assert result == lenient_lowercase(test_list)

# Unit tests for function human_to_bytes

# Generated at 2022-06-20 16:27:52.844795
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 1, False]) == ['a', 1, False]
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase([1, 'a', False]) == [1, 'a', False]



# Generated at 2022-06-20 16:28:01.257411
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Function for human_to_bytes unit test '''
    # Convert number in string format into bytes (ex: '2K' => 2048)
    unit_test_result = human_to_bytes('2k')
    unit_test_expected = 2048
    assert unit_test_expected == unit_test_result

    # Convert number in string format into bytes (ex: '10M' => 10485760)
    unit_test_result = human_to_bytes('10m')
    unit_test_expected = 10485760
    assert unit_test_expected == unit_test_result

    # Convert number in string format into bytes (ex: '10e' => 10000000000000000000)
    unit_test_result = human_to_bytes('10e')
    unit_test_expected = 10000000000000000000
    assert unit_test_

# Generated at 2022-06-20 16:28:04.806878
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'b', True]) == ['a', 'b', True]
    assert lenient_lowercase(['a', 'b', False]) == ['a', 'b', False]

# Unit test function human_to_bytes

# Generated at 2022-06-20 16:28:13.321356
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:28:23.649887
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('Starting Test for human_to_bytes()')
    assert human_to_bytes('20') == 20, 'Failed test for raw number'
    assert human_to_bytes('10MB') == 10485760, 'Failed test for byte'
    assert human_to_bytes('1Mb') == 1048576, 'Failed test for bit'
    assert human_to_bytes('1Mb', isbits=True) == 1048576, 'Failed test for bit'
    assert human_to_bytes('10MB', unit='b') == 10485760, 'Failed test for byte with unit'
    assert human_to_bytes('1Mb', unit='B') == 1048576, 'Failed test for bit with unit'

if __name__ == '__main__':
    test_human_to_bytes()

# Generated at 2022-06-20 16:28:34.448950
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''Unit test for function bytes_to_human'''
    import sys
    import pytest


# Generated at 2022-06-20 16:28:45.578564
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:28:57.569230
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import random
    import sys
    from nose.plugins.skip import SkipTest
    try:
        random = random.SystemRandom()
    except NotImplementedError:
        raise SkipTest('no secure pseudo random number generator available')

    scale = random.choice(list(SIZE_RANGES.keys()))
    max_value = human_to_bytes(1, scale)
    assert max_value > 0
    number = random.random()*max_value
    assert number > 0
    number_str = bytes_to_human(number, unit=scale)
    assert number_str != ''
    number_int = int(random.random()*max_value)
    assert number_int > 0
    number_str = bytes_to_human(number_int, unit=scale)
    assert number_str != ''
    number_str

# Generated at 2022-06-20 16:28:59.841859
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'A', True]) == [1, 'a', True]


# Generated at 2022-06-20 16:29:07.727989
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:29:16.378122
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('0') == 0
    assert human_to_bytes('1') == 1
    assert human_to_bytes('10') == 10

    assert human_to_bytes('0K') == 0
    assert human_to_bytes('1K') == 10 ** 3
    assert human_to_bytes('10K') == 10 ** 4
    assert human_to_bytes('10k') == 10 ** 4
    assert human_to_bytes('1Kb', isbits=True) == 10 ** 3
    assert human_to_bytes('1KB', isbits=True) == 10 ** 3

    assert human_to_bytes('0M') == 0
    assert human_to_bytes('1M') == 10 ** 6
    assert human_to_bytes('10M') == 10 ** 7

# Generated at 2022-06-20 16:29:19.055466
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Unit test for lenient_lowercase

    :return: True if test passed
    :rtype: bool
    """
    # Element is not a string
    if lenient_lowercase([1]) != [1]:
        return False
    # Element is a string
    elif lenient_lowercase(['AbC']) != ['abc']:
        return False
    else:
        return True

# Generated at 2022-06-20 16:29:27.894213
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(10, unit='K') == '0.01 KB'
    assert bytes_to_human(124, unit='b') == '124.00 bits'
    assert bytes_to_human(124) == '124.00 Bytes'
    assert bytes_to_human(1048576, unit='K') == '1.00 KB'
    assert bytes_to_human(1048576, unit='M') == '1.00 MB'
    assert bytes_to_human(1048576, unit='G') == '1.00 GB'
    assert bytes_to_human(1048576, unit='T') == '1.00 TB'

# Generated at 2022-06-20 16:29:40.213444
# Unit test for function bytes_to_human
def test_bytes_to_human():
    if bytes_to_human(1) != "1.00 Bytes":
        raise AssertionError(bytes_to_human(1))
    if bytes_to_human(1, isbits=True) != "1.00 bits":
        raise AssertionError(bytes_to_human(1, isbits=True))
    if bytes_to_human(1023) != "1023.00 Bytes":
        raise AssertionError(bytes_to_human(1023))
    if bytes_to_human(1023, isbits=True) != "8186.40 bits":
        raise AssertionError(bytes_to_human(1023, isbits=True))
    if bytes_to_human(1024) != "1.00 KB":
        raise AssertionError(bytes_to_human(1024))
   

# Generated at 2022-06-20 16:29:43.205974
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B']) == ['a', 'b']
    assert lenient_lowercase(['a', 1]) == ['a', 1]

# Generated at 2022-06-20 16:29:47.189007
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_of_strings = ['lower', 'UPPER', 'MixEd']
    list_of_strings_lower_expected = ['lower', 'upper', 'mixed']
    assert list_of_strings_lower_expected == lenient_lowercase(list_of_strings)


# Generated at 2022-06-20 16:29:55.003660
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test conversion to Bytes
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(2, unit='B') == '2.00 Bytes'
    assert bytes_to_human(2, unit='b') == '2.00 bits'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'
    assert bytes_to_human(10, unit='b') == '10.00 bits'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(2048, unit='K') == '2.00 KB'

# Generated at 2022-06-20 16:30:05.732259
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_dict = {'A': {'a': 1, 'b': 2}, 'b': {'a': 3, 'b': 4}, 'C': {'a': 5, 'b': 6}}
    assert lenient_lowercase(test_dict) ==  {'A': {'a': 1, 'b': 2}, 'b': {'a': 3, 'b': 4}, 'C': {'a': 5, 'b': 6}}
    assert lenient_lowercase(list(test_dict)) == ['A', 'b', 'C']

    test_list = [1, 2, 'a', 'B']
    assert lenient_lowercase(test_list) == [1, 2, 'a', 'B']


# Unit tests for function human_to_bytes

# Generated at 2022-06-20 16:30:10.459291
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Foo', 'bar']) == ['foo', 'bar']
    assert lenient_lowercase(['Foo', 12]) == ['foo', 12]
    assert lenient_lowercase([{'bar': 'buzz'}]) == [{'bar': 'buzz'}]
    assert lenient_lowercase([]) == []

# Generated at 2022-06-20 16:30:13.967370
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 1, 2]) == ['a', 'b', 1, 2]

    assert lenient_lowercase([1, '2', 3, 'A']) == [1, '2', 3, 'A']

# Generated at 2022-06-20 16:30:21.325886
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(["aaa", "bbb"]) == ["aaa", "bbb"]
    assert lenient_lowercase(["aaa", "bbb", 10]) == ["aaa", "bbb", 10]
    assert lenient_lowercase(["AAA", "BBB"]) == ["aaa", "bbb"]
    assert lenient_lowercase([10, 20, 30]) == [10, 20, 30]
    assert lenient_lowercase(["AAA", "BBB", 10]) == ["aaa", "bbb", 10]


# Generated at 2022-06-20 16:30:32.806252
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("testing human_to_bytes ...")


# Generated at 2022-06-20 16:30:44.791124
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_data = [
        ('1MB', 1048576),
        ('1Mb', 131072),
        ('1MB', 1048576, 'M'),
        ('1Mb', 131072, 'M'),
        ('10MB', 10485760),
        ('10Mb', 1310720),
        ('10MB', 10485760, 'M'),
        ('10Mb', 1310720, 'M'),
    ]

    for test in test_data:
        assert human_to_bytes(test[0]) == test[1]
        if len(test) > 2:
            assert human_to_bytes(test[0], test[2]) == test[1]
            assert human_to_bytes(test[0], default_unit='M', isbits=True) == test[1]
    assert human

# Generated at 2022-06-20 16:31:06.066071
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K', isbits=False) == 2 * 1024
    assert human_to_bytes('2K', isbits=True) == 2 * 1024
    assert human_to_bytes('2KB', isbits=False) == 2 * 1024
    assert human_to_bytes('2KB', isbits=True) == 2 * 1024
    assert human_to_bytes('2Kb', isbits=False) == 2 * 1024
    assert human_to_bytes('2Kb', isbits=True) == 2 * 1024
    assert human_to_bytes('2kB', isbits=False) == 2 * 1024
    assert human_to_bytes('2kB', isbits=True) == 2 * 1024
    assert human_to_bytes('2kb', isbits=False) == 2 * 1024

# Generated at 2022-06-20 16:31:12.757553
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    expected = [1, 'a', 'b', 3, 'c', 'd']
    actual = lenient_lowercase([1, 'A', 'b', 3, 'C', 'D'])
    assert expected == actual

    expected = [1, 'a', 'b', 'abc', 'ABC', 'aBc', 3, 'c', 'd']
    actual = lenient_lowercase([1, 'A', 'b', 'abc', 'ABC', 'aBc', 3, 'C', 'D'])
    assert expected == actual

# Generated at 2022-06-20 16:31:14.579701
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input = ['a', 'B', 'c', 9]
    output = ['a', 'B', 'c', 9]
    assert lenient_lowercase(input) == output


# Generated at 2022-06-20 16:31:21.248722
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:31:32.875933
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1023) == '1023.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1025) == '1.00 KB'
    assert bytes_to_human(1048575) == '1024.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048577) == '1.00 MB'
    assert bytes_to_human(1073741823) == '1024.00 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'
   

# Generated at 2022-06-20 16:31:40.348700
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Unit test for function human_to_bytes
    '''
    assert human_to_bytes('1') == 1
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('3M') == 3145728
    assert human_to_bytes('4G') == 4294967296
    assert human_to_bytes('5T') == 549755813888
    assert human_to_bytes('6P') == 644245094100480
    assert human_to_bytes('7E') == 75161927684587520
    assert human_to_bytes('8Z') == 8606711681639782400
    assert human_to_bytes('9Y') == 9.766802649856912e+21
    assert human_to_bytes('10b')

# Generated at 2022-06-20 16:31:47.715569
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    cases = [
        ([], []),
        (['a', 'B', '3'], ['a', 'B', '3']),
        (['hello', 'world'], ['hello', 'world']),
        (['HELLO', 'WORLD'], ['hello', 'world']),
        (['hello', 'world', 'WORLD', 7, 'seven'], ['hello', 'world', 'world', 7, 'seven']),
        (['hello', 'world', 'HELLO', 7, 'seven'], ['hello', 'world', 'hello', 7, 'seven'])
    ]
    for case in cases:
        assert lenient_lowercase(case[0]) == case[1]



# Generated at 2022-06-20 16:31:58.940590
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['no', 'change', 'needs', 'to', 'be', 'done']) == ['no', 'change', 'needs', 'to', 'be', 'done']
    assert lenient_lowercase(['all', 'of', 'these', 'need', 'to', 'be', 'lowered']) == ['all', 'of', 'these', 'need', 'to', 'be', 'lowered']
    assert lenient_lowercase(['all', 'of', 'these', 'need', 'to', 'be', 'lowered', u'but', u'no', u'unicode']) == ['all', 'of', 'these', 'need', 'to', 'be', 'lowered', u'but', u'no', u'unicode']

# Generated at 2022-06-20 16:32:08.539067
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert f'{bytes_to_human(1048576)}' == '1.00 MB'
    assert f'{bytes_to_human(1048576, unit="m")}' == '1.00 M'
    assert f'{bytes_to_human(1048576, unit="M")}' == '1.00 M'
    assert f'{bytes_to_human(1048576, unit="Mb")}' == '1.00 Mb'
    assert f'{bytes_to_human(1048576, unit="MB")}' == '1.00 MB'
    assert f'{bytes_to_human(1048576, unit="MB", isbits=True)}' == '8388608.00 b'

# Generated at 2022-06-20 16:32:12.041822
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['TeST', ['T', 'ES'], 'TEST']
    assert lenient_lowercase(lst) == ['test', ['T', 'ES'], 'test']



# Generated at 2022-06-20 16:32:28.033677
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test converting bytes
    assert(human_to_bytes('1') == 1)
    assert(human_to_bytes('1') == 1)
    assert(human_to_bytes('1B') == 1)
    assert(human_to_bytes('1b') == 1)
    assert(human_to_bytes('1M') == 1024 * 1024)
    assert(human_to_bytes('1Mb') == 1024 * 1024)
    assert(human_to_bytes('1.1M') == 1024 * 1024 * 1.1)

    # Test converting bits
    assert(human_to_bytes('1', isbits=True) == 1)
    assert(human_to_bytes('1b', isbits=True) == 1)
    assert(human_to_bytes('1Mb', isbits=True) == 1024 * 1024)

# Generated at 2022-06-20 16:32:36.941369
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' testing function human_to_bytes '''
    # test bytes
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10mB') == 10485760
    assert human_to_bytes('10mb') == 10485760
    # test bits
    assert human_to_bytes('10M', isbits=True) == 134217728
    assert human_to_bytes('10Mb', isbits=True) == 134217728
    # test bits with unit
    assert human_to_bytes('10Mb', isbits=True, unit="mb") == 134217728

# Generated at 2022-06-20 16:32:48.444331
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:32:59.297628
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(2) == '2.00 Bytes'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(20) == '20.00 Bytes'
    assert bytes_to_human(20.2) == '20.20 Bytes'

    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(10240) == '10.00 KB'
    assert bytes_to_human(20480) == '20.00 KB'
    assert bytes_to_human(20480.2) == '20.48 KB'

    assert bytes_to_

# Generated at 2022-06-20 16:33:09.990945
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:33:18.270886
# Unit test for function bytes_to_human
def test_bytes_to_human():

    assert bytes_to_human(100) == "100.00 Bytes"
    assert bytes_to_human(100, unit='B') == "100.00 Bytes"

    assert bytes_to_human(100, unit='b') == "100.00 bits"
    assert bytes_to_human(100, isbits=True) == "100.00 bits"

    assert bytes_to_human(1048576) == "1.00 MB"
    assert bytes_to_human(1048576, unit='M') == "1.00 MB"

    assert bytes_to_human(1048576, unit='m') == "1.00 Mb"
    assert bytes_to_human(1048576, unit='m', isbits=True) == "1.00 Mb"


# Generated at 2022-06-20 16:33:24.115088
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.2K') == 1200
    assert human_to_bytes('1.2K', 'K') == 1200
    assert human_to_bytes('1.2M') == 1258291
    assert human_to_bytes('1.2M') == 1258291
    assert human_to_bytes('1.2G') == 1288490189
    assert human_to_bytes('1.2T') == 1319089742006
    assert human_to_bytes('1.2P') == 1350085171767299
    assert human_to_bytes('1.2E') == 13802047118023740
    assert human_to_bytes('1.2Z') == 141033415094596760
    assert human_to_bytes('1.2Y') == 1441463590090556

# Generated at 2022-06-20 16:33:28.087222
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['aB', 'aBc']) == ['ab', 'abc']
    assert lenient_lowercase(['aB', 3]) == ['ab', 3]

# Generated at 2022-06-20 16:33:38.220927
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(100) == '100.00 Bytes'

    assert bytes_to_human(1023) == '1023.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1536) == '1.50 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'

    assert bytes_to_human(1023, isbits=True) == '8191.00 bits'

# Generated at 2022-06-20 16:33:43.240142
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    LOWERCASE_LIST = ['a', 'B', '1', 3]
    compare_list = ['a', 'B', '1', 3]
    assert lenient_lowercase(LOWERCASE_LIST) == compare_list


## Unit tests for human_to_bytes

# Generated at 2022-06-20 16:33:59.501461
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    value = ['hello', 42, 'True', {'a': 'b'}]
    result = lenient_lowercase(value)
    assert result == ['hello', 42, 'True', {'a': 'b'}]


# Generated at 2022-06-20 16:34:09.664936
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('15G') == 1610612736
    assert human_to_bytes('15.5G') == 1610612736
    assert human_to_bytes('8.5G') == 901232640
    assert human_to_bytes('8G') == 8589934592
    assert human_to_bytes('8.5G') == 901232640
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('15MB') == 15728640
    assert human_to_bytes('15.5MB') == 16252928
    assert human_

# Generated at 2022-06-20 16:34:20.813310
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('10KB') == 10240
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624

    try:
        human_to_bytes('1PB')
    except ValueError as e:
        assert 'failed to convert' in str(e)
    else:
        assert False, "ValueError was not raised. (test_human_to_bytes)"


# Generated at 2022-06-20 16:34:27.160882
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """
    Test function lenient_lowercase
    """
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['test']) == ['test']
    assert lenient_lowercase([1]) == [1]
    assert lenient_lowercase(['test', 1]) == ['test', 1]
    assert lenient_lowercase([1, 'test']) == [1, 'test']

# Generated at 2022-06-20 16:34:36.819005
# Unit test for function bytes_to_human
def test_bytes_to_human():
    units = ['B', 'K', 'KB', 'M', 'MB', 'G', 'GB', 'T', 'TB', 'P', 'PB', 'E', 'EB', 'Z', 'ZB']
    values = [1, 1<<10, 1<<20, 1<<30, 1<<40, 1<<50, 1<<60, 1<<70, 1<<80]

# Generated at 2022-06-20 16:34:41.553404
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['Test', 'TEST', ['TEST'], ['Test'], {'Test': 'TEST'}, {'TEST': 'Test'}, '', ' ']
    result = lenient_lowercase(test_list)
    if ['test', 'test', ['TEST'], ['test'], {'TEST': 'TEST'}, {'TEST': 'Test'}, '', ' '] != result:
        raise AssertionError

# Generated at 2022-06-20 16:34:50.129136
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print(bytes_to_human(0, False))
    print(bytes_to_human(1, False))
    print(bytes_to_human(1023, False))
    print(bytes_to_human(1024, False))
    print(bytes_to_human(2 * 1024 * 1024, False))
    print(bytes_to_human(2 * 1024 * 1024 * 1024, False))
    print('-' * 50)
    print(bytes_to_human(0, False, 'B'))
    print(bytes_to_human(1, False, 'B'))
    print(bytes_to_human(1023, False, 'B'))
    print(bytes_to_human(1024, False, 'B'))
    print(bytes_to_human(2 * 1024 * 1024, False, 'B'))
   

# Generated at 2022-06-20 16:35:02.500863
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1MB', isbits=True) == 1048576 * 8
    assert human_to_bytes('1000') == 1000
    assert human_to_bytes('10.5K') == 10500
    assert human_to_bytes('10.5M') == 10500000
    assert human_to_bytes('10.5G') == 10500000 * 1000
    assert human_to_bytes('10.5T') == 10500000 * 1000 * 1000
    assert human_to_bytes('1Tb', isbits=True) == 1099511627776
    assert human_to_bytes('1T', unit='B') == 1099511627776


# Generated at 2022-06-20 16:35:07.125905
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['AA', 'BB', 'cc']) == ['aa', 'bb', 'cc']
    assert lenient_lowercase(['AA', 'BB', 2, 'cc']) == ['aa', 'bb', 2, 'cc']

# Generated at 2022-06-20 16:35:13.990089
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['a','b','c','d','e'] == lenient_lowercase(['a','b','c','d','e'])
    assert ['A','b','c','d','e'] == lenient_lowercase(['A','b','c','d','e'])
    assert ['a','b','c',3,'e'] == lenient_lowercase(['a','b','c',3,'e'])
    assert ['a','b','c',[3,4],'e'] == lenient_lowercase(['a','b','c',[3,4],'e'])
