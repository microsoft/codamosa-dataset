

# Generated at 2022-06-20 16:25:46.971278
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'c']) == ['a', 'b', 'c']



# Generated at 2022-06-20 16:25:56.266018
# Unit test for function bytes_to_human
def test_bytes_to_human():
    import unittest

    class HumanToBytesTests(unittest.TestCase):

        def test_human_to_bytes_with_unit(self):
            self.assertEqual(lenient_lowercase(human_to_bytes(1000, 'b')), '1000')
            self.assertEqual(lenient_lowercase(human_to_bytes(1000, 'B')), '1000')
            self.assertEqual(lenient_lowercase(human_to_bytes(1000, 'Kb')), '1000')
            self.assertEqual(lenient_lowercase(human_to_bytes(1000, 'KB')), '8192')
            self.assertEqual(lenient_lowercase(human_to_bytes(1000, 'mb')), '1000000')

# Generated at 2022-06-20 16:26:04.583368
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:26:12.383751
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # positive test cases
    # example with unit
    assert human_to_bytes('2.5K', 'M', isbits=True) == 25600
    assert human_to_bytes('1.5Kb', 'Mb') == 1536
    assert human_to_bytes('20K', 'M', isbits=True) == 20480
    assert human_to_bytes('1.5Mb', 'G') == 1572864
    assert human_to_bytes('1.5G', 'T') == 16106127360
    assert human_to_bytes('1.5Eb', 'Zb') == 161243136
    assert human_to_bytes('1.5Z', 'Y') == 161764545024
    assert human_to_bytes('15ZB', 'YB') == 161764545024

# Generated at 2022-06-20 16:26:23.520435
# Unit test for function bytes_to_human
def test_bytes_to_human():
    if human_to_bytes('1MB') != (1024 * 1024):
        raise ValueError("human_to_bytes() failed to convert '1MB' (unit = None, isbits = False).")
    if human_to_bytes(1048576, unit='B') != (1024 * 1024):
        raise ValueError("human_to_bytes() failed to convert '1048576' (unit = 'B', isbits = False).")
    if human_to_bytes('1MB', isbits=True) != (1024 * 1024):
        raise ValueError("human_to_bytes() failed to convert '1MB' (unit = 'MB', isbits = True).")

# Generated at 2022-06-20 16:26:30.147127
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [
        1234,
        'ABcd',
        'abCd',
        '',
        u'ABCD',
        u'abc',
    ]
    expected_list = [
        1234,
        'abcd',
        'abcd',
        '',
        'abcd',
        'abc',
    ]

    assert lenient_lowercase(test_list) == expected_list



# Generated at 2022-06-20 16:26:32.945504
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['aBc', 123, None]) == ['abc', 123, None]
    assert lenient_lowercase(['aBc123', 123, None]) == ['abc123', 123, None]


# Generated at 2022-06-20 16:26:43.372874
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024, False, 'K') == '1.00 KB'
    assert bytes_to_human(1024, True, 'K') == '8192.00 bits'
    assert bytes_to_human(1, True, 'K') == '8.00 bits'
    assert bytes_to_human(1024, True, 'B') == '8192.00 bits'
    assert bytes_to_human(1024, False) == '1.00 KB'
    assert bytes_to_human(1024, False, 'K') == '1.00 KB'
    assert bytes_to_human(1024, False, 'B') == '1024.00 Bytes'
    assert bytes_to_human(1024, False, 'B') == '1024.00 Bytes'

# Generated at 2022-06-20 16:26:55.026604
# Unit test for function bytes_to_human
def test_bytes_to_human():
    try:
        assert bytes_to_human(1) == '1 Bytes'
    except AssertionError:
        raise AssertionError("bytes_to_human() failed to convert 1 Bytes")
    try:
        assert bytes_to_human(2, isbits=True) == '2 bits'
    except AssertionError:
        raise AssertionError("bytes_to_human() failed to convert 2 bits")
    try:
        assert bytes_to_human(1048576, unit='m') == '1 MBytes'
    except AssertionError:
        raise AssertionError("bytes_to_human() failed to convert 1048576 Bytes using MBytes as unit")

# Generated at 2022-06-20 16:27:00.163367
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 123]) == ['a', 'b', 123]
    assert lenient_lowercase(['.', 'A', 123]) == ['.', 'a', 123]
    assert lenient_lowercase([123, 'A', 'B']) == [123, 'a', 'b']
    assert lenient_lowercase([123, 'A', 123]) == [123, 'a', 123]

# Generated at 2022-06-20 16:27:06.756471
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['New', 'York', 'City']) == ['new', 'york', 'city']
    assert lenient_lowercase([True, 1, 1.1]) == [True, 1, 1.1]



# Generated at 2022-06-20 16:27:13.997467
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'E') == 11258999068426240
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes(10, 'Mb', isbits=True) == 10485760
    assert human_to_bytes(10, 'Mb', isbits=False) == human_to_bytes('10MB')



# Generated at 2022-06-20 16:27:23.049270
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['a']) == ['a']
    assert lenient_lowercase([1]) == [1]
    assert lenient_lowercase(['1']) == ['1']
    assert lenient_lowercase([1, 'a']) == [1, 'a']
    assert lenient_lowercase(['a', 'A']) == ['a', 'a']
    assert lenient_lowercase([['a'], 'A']) == [['a'], 'a']
    assert lenient_lowercase(['A', ['a']]) == ['a', ['a']]


# Generated at 2022-06-20 16:27:25.414745
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['upper', 'MiXeD', '1', 2]) == ['upper', 'mixed', '1', 2]



# Generated at 2022-06-20 16:27:35.150870
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(2) == '2 Bytes'
    assert bytes_to_human(3) == '3 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human(1099511627776) == '1.00 TB'
    assert bytes_to_human(1125899906842624) == '1.00 PB'
    assert bytes_to_human(1152921504606846976) == '1.00 EB'
   

# Generated at 2022-06-20 16:27:45.728452
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:27:52.411263
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2k', isbits=False) == 2048
    assert human_to_bytes('4m', isbits=False) == 4194304
    assert human_to_bytes('4M', isbits=False) == 4194304
    assert human_to_bytes('4MB', isbits=False) == 4194304
    assert human_to_bytes('4Mb', isbits=True) == 4194304
    assert human_to_bytes('0.5Mb', isbits=True) == 524288
    assert human_to_bytes('0.5m', isbits=False) == 524288
    assert human_to_bytes('0.5M', isbits=False) == 524288
    assert human_to_bytes('0.5MB', isbits=False) == 524288

# Generated at 2022-06-20 16:28:01.013176
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1024 * 1024

    assert human_to_bytes('1mb', isbits=True) == 1024 * 1024
    assert human_to_bytes('1Mb', isbits=True) == 1024 * 1024
    assert human_to_bytes('1Mb', isbits=False) == 0
    assert human_to_bytes('1Mb', unit='B') == 0
    assert human_to_bytes('1MB', unit='b') == 0

    assert human_to_bytes('1Mb', unit='b', isbits=True) == 1024 * 1024
    assert human_to_bytes('1b', unit='b', isbits=True) == 1

    assert human_to_

# Generated at 2022-06-20 16:28:07.645417
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """
    This is the test fixture for lenient_lowercase
    """
    assert lenient_lowercase(['A', 'b', 'C', 'd']) == ['a', 'b', 'c', 'd']
    assert lenient_lowercase([1, 2, 'a', 'b']) == [1, 2, 'a', 'b']
    assert lenient_lowercase([['a', 'b'], 2]) == [['a', 'b'], 2]
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['A']) == ['a']


# Generated at 2022-06-20 16:28:18.849720
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """Unit test for bytes_to_human"""

    # test unit argument
    assert '1.00 KBytes' == bytes_to_human(1024, 'K')
    assert '1048576.00 Bytes' == bytes_to_human(1024**2, 'B')
    assert '1.00 Mbits' == bytes_to_human(1024**2, 'Mb')
    assert '1.00 MBytes' == bytes_to_human(1024**2, 'MB')

    # test default value - Bytes
    assert '1024.00 Bytes' == bytes_to_human(1024)

    # test default value - bits
    assert '8388608.00 bits' == bytes_to_human(1024**3, isbits=True)

# Generated at 2022-06-20 16:28:35.638768
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import eq_


# Generated at 2022-06-20 16:28:42.301980
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['a', 'b', 1] == lenient_lowercase(['a', 'b', 1])
    assert ['a', 'b', 1] == lenient_lowercase(['A', 'B', 1])
    assert ['a', 'b'] == lenient_lowercase(['A', 'B'])
    assert ['a', 'b', 1] == lenient_lowercase(['a', 'b', '1'])

# Generated at 2022-06-20 16:28:50.481255
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(123456, unit='k') == '120.56 KB'
    assert bytes_to_human(123456, unit='kb') == '120.56 KB'
    assert bytes_to_human(123456, unit='kb', isbits=True) == '120.56 Kb'
    assert bytes_to_human(123456, unit='kilo') == '120.56 KB'
    assert bytes_to_human(123456, isbits=True, unit='b') == '120.56 bytes'
    assert bytes_to_human(123456, isbits=True, unit='bits') == '120.56 bits'
    assert bytes_to_human(1024, unit='k') == '1.00 KB'
    assert bytes_to_human(1024, unit='kb') == '1.00 KB'


# Generated at 2022-06-20 16:29:01.362721
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Byte'
    assert bytes_to_human(2) == '2 Bytes'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(1000) == '1000 Bytes'
    assert bytes_to_human(1025) == '1.01 KB'
    assert bytes_to_human(102400) == '100.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(104857600) == '100.00 MB'
    assert bytes_to_human(1048576000) == '1000.00 MB'

# Generated at 2022-06-20 16:29:11.781298
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B', isbits=True) == 8
    assert human_to_bytes('1b', isbits=True) == 1

    assert human_to_bytes('1') == 1
    assert human_to_bytes('1', 'M', isbits=False) == bytes_to_human(1048576, unit='B')
    assert human_to_bytes('1', 'M', isbits=True) == bytes_to_human(1048576, unit='b')

    assert human_to_bytes('1M') == bytes_to_human(1048576, unit='B')

# Generated at 2022-06-20 16:29:18.426929
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:29:23.266212
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Test for human_to_bytes function."""
    result = human_to_bytes('10B')
    assert result == 10
    result = human_to_bytes('10M')
    assert result == 10 * (1 << 20)
    result = human_to_bytes('10Mb', isbits=True)
    assert result == 10 * (1 << 20)

# Generated at 2022-06-20 16:29:34.613854
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert (bytes_to_human(10) == "10 Bytes")
    assert (bytes_to_human(10, unit='B') == "10 Bytes")
    assert (bytes_to_human(10, unit='b') == "10 bits")
    assert (bytes_to_human(10, isbits=True) == "10 bits")
    assert (bytes_to_human(1000) == "1.00 KB")
    assert (bytes_to_human(1000, unit='B') == "1.00 KB")
    assert (bytes_to_human(1024) == "1.00 KB")
    assert (bytes_to_human(1024, unit='B') == "1.00 KB")
    assert (bytes_to_human(1024, unit='K') == "1.00 KB")

# Generated at 2022-06-20 16:29:39.373782
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lowercased = lenient_lowercase([b'string', b'binary', 'String', 'Binary', b'BinaryData', 'NonStringObject'])
    assert lowercased == [b'string', b'binary', 'string', 'binary', b'BinaryData', 'NonStringObject']



# Generated at 2022-06-20 16:29:49.927082
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('19.5 Y') == 19.5 * (1 << 80)
    assert human_to_bytes('19.5 Yb') == 19.5 * (1 << 80)
    assert human_to_bytes('19.5 Zb') == 19.5 * (1 << 70)
    assert human_to_bytes('19.5 Eb') == 19.5 * (1 << 60)
    assert human_to_bytes('19.5 Pb') == 19.5 * (1 << 50)
    assert human_to_bytes('19.5 Tb') == 19.5 * (1 << 40)
    assert human_to_bytes('19.5 Gb') == 19.5 * (1 << 30)
    assert human_to_bytes('19.5 Mb') == 19.5 * (1 << 20)

# Generated at 2022-06-20 16:29:58.669534
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase(['a', 1.0, 'C']) == ['a', 1.0, 'c']
    assert lenient_lowercase(['a', (1, 2), 'C']) == ['a', (1, 2), 'c']
    assert lenient_lowercase(['a', {1, 2}, 'C']) == ['a', {1, 2}, 'c']



# Generated at 2022-06-20 16:30:09.217142
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert '1.00 TB' == bytes_to_human(human_to_bytes('1TB'))
    assert '1.00 GB' == bytes_to_human(human_to_bytes('1GB'))
    assert '1.00 MB' == bytes_to_human(human_to_bytes('1MB'))
    assert '1.00 KB' == bytes_to_human(human_to_bytes('1KB'))
    assert '1.00 B' == bytes_to_human(human_to_bytes('1'))
    assert '1.00 B' == bytes_to_human(human_to_bytes('1', 'B'))
    assert '1.00 KB' == bytes_to_human(human_to_bytes('1', 'K'))
    assert '1.00 B' == bytes_to_human

# Generated at 2022-06-20 16:30:18.007382
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test string as input
    assert(lenient_lowercase(['A', 'String']) == ['a', 'string'])
    # Test list as input
    assert(lenient_lowercase(['A', ['A', 'String']]) == ['a', ['A', 'String']])
    # Test dict as input
    assert(lenient_lowercase(['A', {'A': 'String'}]) == ['a', {'A': 'String'}])
    # Test tuple as input
    assert(lenient_lowercase([]) == [])


# Generated at 2022-06-20 16:30:29.596383
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(100) == '100.00 Bytes'
    assert bytes_to_human(100, unit='B') == '100.00 Bytes'
    assert bytes_to_human(100, unit='Bb') == '100.00 Bytes'
    assert bytes_to_human(100, unit='b') == '100.00 bits'
    assert bytes_to_human(100, isbits=True) == '100.00 bits'

    # Bytes
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(2) == '2.00 Bytes'
    assert bytes_to_human(1023) == '1023.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_

# Generated at 2022-06-20 16:30:33.015887
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    assert lenient_lowercase(["a", "B", 1, 2]) == ["a", "b", 1, 2]
    assert lenient_lowercase(["a", ["B", "C"], 1, 2]) == ["a", ["B", "C"], 1, 2]
    assert lenient_lowercase(["a", ["B", "C"], [1, 2, 3]]) == ["a", ["B", "C"], [1, 2, 3]]
    assert lenient_lowercase("Hello World") == "hello world"
    assert lenient_lowercase("Hello World") != "Hello World"

# Generated at 2022-06-20 16:30:44.818170
# Unit test for function bytes_to_human

# Generated at 2022-06-20 16:30:56.323158
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('-13.3B') == -13
    assert human_to_bytes('0.0B') == 0
    assert human_to_bytes('13.3B') == 13
    assert human_to_bytes('-13.3K') == -13 * 1024
    assert human_to_bytes('0.0K') == 0
    assert human_to_bytes('13.3K') == 13 * 1024
    assert human_to_bytes('-13.3M') == -13 * 1024 * 1024
    assert human_to_bytes('0.0M') == 0
    assert human_to_bytes('13.3M') == 13 * 1024 * 1024
    assert human_to_bytes('-13.3G') == -13 * 1024 * 1024 * 1024
    assert human_to_bytes('0.0G')

# Generated at 2022-06-20 16:30:59.769642
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['aBc', 1, 'dEf']) == ['abc', 1, 'def']


# Generated at 2022-06-20 16:31:10.168194
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(13, unit='b') == '13.00 bits', 'Wrong value: %s' % bytes_to_human(13, unit='b')
    assert bytes_to_human(13, unit='b') == '13.00 bits', 'Wrong value: %s' % bytes_to_human(13, unit='b')
    assert bytes_to_human(24, unit='b') == '24.00 bits', 'Wrong value: %s' % bytes_to_human(24, unit='b')
    assert bytes_to_human(99, isbits=True) == '99.00 bits', 'Wrong value: %s' % bytes_to_human(99, isbits=True)

# Generated at 2022-06-20 16:31:18.524320
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:31:36.331207
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert '0.00 Bytes' == bytes_to_human(0)
    assert '1.00 Bytes' == bytes_to_human(1)
    assert '999.00 Bytes' == bytes_to_human(999)
    assert '1023.00 Bytes' == bytes_to_human(1023)
    assert '1.00 KB' == bytes_to_human(1024)
    assert '1.00 KB' == bytes_to_human(1025)
    assert '1023.00 KB' == bytes_to_human(1024 * 1023)
    assert '2.00 MB' == bytes_to_human(1024 * 1024)
    assert '1024.00 MB' == bytes_to_human(1024 * 1024 * 1024)

# Generated at 2022-06-20 16:31:40.065596
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """ Test the lenient_lowercase function"""
    assert lenient_lowercase(['This', 'That', 123]) == ['this', 'that', 123]


# Generated at 2022-06-20 16:31:41.759665
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'abc', 'abcD']) == [1, 'abc', 'abcd']

# Generated at 2022-06-20 16:31:49.154820
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # valid cases
    assert lenient_lowercase([1, '2', 'Foo', 'bar']) == [1, '2', 'foo', 'bar']
    assert lenient_lowercase(['foo']) == ['foo']
    assert lenient_lowercase(['foo', None]) == ['foo', None]
    assert lenient_lowercase([None]) == [None]
    assert lenient_lowercase(['foo', 1]) == ['foo', 1]
    assert lenient_lowercase([1, 'foo']) == [1, 'foo']
    assert lenient_lowercase(['FOO']) == ['foo']
    assert lenient_lowercase([1, 'FOO']) == [1, 'foo']
    assert lenient_lowercase(['FOO', 1]) == ['foo', 1]


# Unit

# Generated at 2022-06-20 16:32:00.138133
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1000') == 1000

    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824

    assert human_to_bytes('2KB') == 2048
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1GB') == 1073741824

    assert human_to_bytes('2Kb') is None
    assert human_to_bytes('1Mb') is None
    assert human_to_bytes('1Gb') is None

    assert human_to_bytes('2KB', isbits=True) == 16384
    assert human_to_bytes('1MB', isbits=True) == 8388608
    assert human_to_bytes

# Generated at 2022-06-20 16:32:09.998582
# Unit test for function bytes_to_human
def test_bytes_to_human():
    prefixe = (('Y', 'YB'), ('Z', 'ZB'), ('E', 'EB'), ('P', 'PB'), ('T', 'TB'), ('G', 'GB'), ('M', 'MB'), ('K', 'KB'), ('B', 'Bytes'))

# Generated at 2022-06-20 16:32:21.998805
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048576, isbits=True) == '8192.00 Kbits'
    assert bytes_to_human(10485760) == '10.00 MB'
    assert bytes_to_human(10485760, unit='K') == '10240.00 KB'
    assert bytes_to_human(10485760, unit='B') == '10485760.00 Bytes'
    assert bytes_to_human(10485760, unit='M') == '10.00 MB'
    assert bytes_to_human(104857601, unit='Kb') == '819200.08 Kbits'
    assert bytes_to

# Generated at 2022-06-20 16:32:26.078148
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['TEST', 99, 'TEST99', 'test99', 99.99]
    expected_list = ['test', 99, 'test99', 'test99', 99.99]
    assert(expected_list == lenient_lowercase(test_list))


# Unit tests for function human_to_bytes

# Generated at 2022-06-20 16:32:36.118037
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1024) == '1.00 KBytes'
    assert bytes_to_human(1024 * 1024 * 2) == '2.00 MBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 2) == '2.00 GBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 2) == '2.00 TBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 2) == '2.00 PBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 2) == '2.00 EBytes'

# Generated at 2022-06-20 16:32:45.513248
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    import pytest
    assert lenient_lowercase([1, 'Abc', 'deF', 'GhI']) == [1, 'abc', 'def', 'ghi']
    assert lenient_lowercase(['Abc', 'deF', 'GhI']) == ['abc', 'def', 'ghi']
    assert lenient_lowercase(['Abc', 'deF', 'GhI', None]) == ['abc', 'def', 'ghi', None]
    with pytest.raises(ValueError):
        lenient_lowercase([1, 'Abc', 'deF', None])

# Generated at 2022-06-20 16:33:07.194492
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == "1.00 Bytes", "Bytes_to_human() failed to convert a number to a string."
    assert bytes_to_human(2 * 1024) == "2.00 KB", "Bytes_to_human() failed to convert a number to a string."
    assert bytes_to_human(2048, unit='K') == "2.00 KB", "Bytes_to_human() failed to convert a number to a string."
    assert bytes_to_human(2048, unit='B') == "2.00 KB", "Bytes_to_human() failed to convert a number to a string."
    try:
        bytes_to_human(2048, unit='G')
        assert False, "Bytes_to_human() failed to convert a number to a string."
    except ValueError:
        pass

# Generated at 2022-06-20 16:33:16.230975
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test: int, float, string and list
    result = lenient_lowercase([1, 2, 'A', 'b', ['C', 'd']])
    assert result == [1, 2, 'a', 'b', ['c', 'd']], result
    result = lenient_lowercase(['A', 'b', ['C', 'd']])
    assert result == ['a', 'b', ['c', 'd']], result
    result = lenient_lowercase(['A', 'b'])
    assert result == ['a', 'b'], result
    result = lenient_lowercase('Ab')
    assert result == 'ab', result
    result = lenient_lowercase(1)
    assert result == 1, result
    result = lenient_lowercase(1.2)
    assert result == 1.2

# Generated at 2022-06-20 16:33:24.394137
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2') == human_to_bytes(2)
    assert human_to_bytes('1.5K') == human_to_bytes(1536)
    assert human_to_bytes('1.5M') == human_to_bytes(1572864)
    assert human_to_bytes('1.5G') == human_to_bytes(1610612736)

    assert human_to_bytes('1K') == human_to_bytes(1, 'K')
    assert human_to_bytes('1M') == human_to_bytes(1, 'M')
    assert human_to_bytes('1G') == human_to_bytes(1, 'G')

    assert human_to_bytes('1KB') == human_to_bytes(1, 'KB')

# Generated at 2022-06-20 16:33:36.073781
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1B') == 1)
    assert(human_to_bytes('1b') == 1)
    assert(human_to_bytes('1') == 1)
    assert(human_to_bytes('1Mb') == 1048576)
    assert(human_to_bytes('1MB') == 1048576)
    assert(human_to_bytes('1Kb') == 1024)
    assert(human_to_bytes('1KB') == 1024)
    assert(human_to_bytes('1Kb', isbits=True) == 1024)
    assert(human_to_bytes('1KB', isbits=True) == 1024)
    assert(human_to_bytes(1, unit='b') == 1)
    assert(human_to_bytes(1, unit='B') == 1)
   

# Generated at 2022-06-20 16:33:48.054079
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == "1 Bytes"
    assert bytes_to_human(255) == "255 Bytes"
    assert bytes_to_human(256) == "1.00 KB"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(2048) == "2.00 KB"
    assert bytes_to_human(1024 * 10) == "10.00 KB"
    assert bytes_to_human(1024 * 1024) == "1.00 MB"
    assert bytes_to_human(1024 * 2047) == "2.00 MB"
    assert bytes_to_human(1024 * 2048) == "2.00 MB"
    assert bytes_to_human(1024 * 2049) == "2.01 MB"

# Generated at 2022-06-20 16:33:54.596757
# Unit test for function bytes_to_human
def test_bytes_to_human():
    size_list = [
        1,
        1023,
        1024,
        1025,
        10998,
        (1 << 20),
        (1 << 20) + 1,
        (1 << 20) + (1 << 10),
        ((1 << 20) + (1 << 10) + 1),
        (1 << 30),
        (1 << 40),
        (1 << 50),
        (1 << 60),
        (1 << 70),
        (1 << 80),
        (1 << 90),
        (1 << 100),
        (1 << 110),
    ]


# Generated at 2022-06-20 16:33:57.960570
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(['one', 'two', 4, 5, 'six'] == lenient_lowercase(['ONE', 'two', 4, 5, 'Six']))


# Generated at 2022-06-20 16:34:08.224851
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1024000') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1b') == 0
    assert human_to_bytes('1B', isbits=False) == 1
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1mB') == 1048576
    assert human_to_bytes('1mB', isbits=True) == 1048576
    assert human_to_bytes('1MB', isbits=True) == 1048576
    assert human_to_bytes('1MB', isbits=False) == 1048576
    assert human_to_bytes('1MB', default_unit='m') == 1048576

# Generated at 2022-06-20 16:34:19.541856
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''test for function bytes_to_human'''

    test_data = [
        [0, '0 Bytes'],
        [1, '1 Bytes'],
        [1024, '1.00 KB'],
        [1025, '1.00 KB'],
        [4 * 1024 * 1024 + 1, '4.00 MB'],
        [1024 * 1024 * 1024 + 1, '1.00 GB'],
        [1 * 1024 * 1024 * 1024 * 1024, '1.00 TB'],
        [1 * 1024 * 1024 * 1024 * 1024 * 1024, '1.00 PB'],
        [1 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024, '1.00 EB'],
        [1 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024, '1.00 ZB'],
    ]

# Generated at 2022-06-20 16:34:31.308181
# Unit test for function human_to_bytes

# Generated at 2022-06-20 16:35:06.812143
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'B', 'c']
    assert lenient_lowercase(['a', 123, 'c']) == ['a', 123, 'c']
    assert lenient_lowercase(['a', None, 'c']) == ['a', None, 'c']

# Generated at 2022-06-20 16:35:11.377631
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """
    Test cases to test bytes_to_human function
    """

# Generated at 2022-06-20 16:35:14.256929
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'A', 'b', 'B', 1, 'm']) == ['a', 'A', 'b', 'B', 1, 'm']


# Unit tests for function human_to_bytes

# Generated at 2022-06-20 16:35:25.051610
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print('test_bytes_to_human(size, isbits=False, unit=None):')
    test_values = {
        2: '2.00 Bytes',
        1024: '1.00 KB',
        2048: '2.00 KB',
        10485760: '10.00 MB',
        10485760.0: '10.00 MB',
        1073741824: '1.00 GB',
        1073741824.0: '1.00 GB',
        1099511627776: '1.00 TB',
        1099511627776.0: '1.00 TB',
    }

    for size in test_values:
        print('size: %s => %s' % (size, bytes_to_human(size)))


# Generated at 2022-06-20 16:35:35.363663
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert 1 == human_to_bytes('1b')
    assert 1 == human_to_bytes('1b', isbits=True)
    assert 1 == human_to_bytes('1')
    assert 1 == human_to_bytes('1B')
    assert 1 == human_to_bytes('1.')
    assert 1 == human_to_bytes('.1')
    assert 1 == human_to_bytes('1.0')
    assert 1 == human_to_bytes('.1', 'B')
    assert 1 == human_to_bytes('.1b', 'B')
    assert 1 == human_to_bytes('.1B', 'B')
    assert 8 == human_to_bytes('.1b', 'B', isbits=True)
    assert 1 == human_to_bytes('1B', 'B')
    assert 1000