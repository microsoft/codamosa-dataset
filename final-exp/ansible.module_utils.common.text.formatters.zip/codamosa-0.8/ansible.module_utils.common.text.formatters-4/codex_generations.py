

# Generated at 2022-06-11 01:40:18.929274
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['some_string', 1, 2, 3] == lenient_lowercase(['some_string', 1, 2, 3])
    assert ['some_string', 'one', 'two', 'three'] == lenient_lowercase(['Some_string', 'ONE', 'Two', 'ThreE'])


# Generated at 2022-06-11 01:40:22.223021
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['String', 'another String', 'one more String', 1, 2, 3]) == ['string', 'another string', 'one more string', 1, 2, 3]

# Generated at 2022-06-11 01:40:29.145432
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:40:38.080003
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes(10485760) == 10485760
    assert human_to_bytes(10485760, 'MB') == 10485760
    assert human_to_bytes('10.5Mb') == 13120000
    assert human_to_bytes('10.5MB', isbits=True) == 13120000
    assert human_to_bytes(13120000, 'MB', isbits=True) == 13120000
    assert human_to_bytes('10.5M') == 10970000
    assert human_to_bytes('10.5MB') == 10970000
    assert human_to_bytes(10970000, 'MB') == 10970000
   

# Generated at 2022-06-11 01:40:41.503333
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([u'unit', u'test']) == ['unit', 'test']
    assert lenient_lowercase([u'unit', 2]) == ['unit', 2]

# Generated at 2022-06-11 01:40:52.072914
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes(1.1) == 1
    assert human_to_bytes('1.1K') == 1.1 * 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('10M') == 10 * 1024 ** 2
    assert human_to_bytes('1M') == 1024 ** 2
    assert human_to_bytes('10.3M') == 10.3 * 1024 ** 2
    assert human_to_bytes('1.8E') == 1.8 * 1024 ** 6
    assert human_to_bytes('1.5G') == 1.5 * 1024 ** 3
    assert human_to_bytes('10G') == 10 * 1024 ** 3
    assert human_

# Generated at 2022-06-11 01:41:04.107792
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K', 'K') == 2048
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2Kb') == 2048
    assert human_to_bytes('2Mb') == 2097152
    assert human_to_bytes('2Mb', 'Mb') == 2097152
    assert human_to_bytes('2Mb', 'MB', True) == 2097152
    assert human_to_bytes('2', 'M') == 2097152
    assert human_to_bytes('2') == 2
    assert human_to_bytes('2', 'G') == 2147483648
    assert human_to_bytes('2G') == 2147483648
    assert human_to_bytes('2.5GB') == 2684354560

    assert human_

# Generated at 2022-06-11 01:41:15.315218
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['1', '2', '3']) == ['1', '2', '3']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase([None]) == [None]
    assert lenient_lowercase([{}]) == [{}]
    assert lenient_lowercase([object()]) == [object()]



# Generated at 2022-06-11 01:41:20.643555
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:41:32.849026
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1024000
    assert human_to_bytes('0.5M') == 512000
    assert human_to_bytes('0.25M') == 256000
    assert human_to_bytes(1, 'M') == 1024000
    assert human_to_bytes(0.5, 'M') == 512000
    assert human_to_bytes(0.25, 'M') == 256000

    assert human_to_bytes(1, 'MB') == 1048576
    assert human_to_bytes(0.5, 'MB') == 524288
    assert human_to_bytes(0.25, 'MB') == 262144
    assert human_to_bytes(1, 'Mb') == 1048576
    assert human_to_bytes(0.5, 'Mb') == 524

# Generated at 2022-06-11 01:41:44.596763
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:41:49.732805
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    from ansible.compat.tests.mock import patch

    with patch('ansible.compat.tests.mock.PropertyMock') as mock:
        mock.return_value = 'lower'
        assert lenient_lowercase([1, 2, 'test']) == [1, 2, 'lower']

# Generated at 2022-06-11 01:42:00.354861
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', 1]) == ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'z', 'x', 'c', 'v', 'b', 'n', 'm', 1]


# Generated at 2022-06-11 01:42:02.739612
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 1, 2]) == ['a', 'b', 1, 2]



# Generated at 2022-06-11 01:42:10.629215
# Unit test for function bytes_to_human

# Generated at 2022-06-11 01:42:14.075858
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(('asdf', 3.14, u'qWERTY'))
    assert result[0] == 'asdf'
    assert result[1] == 3.14
    assert result[2] == u'qwertY'

# Generated at 2022-06-11 01:42:17.820955
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['value', 'VALUE', 'Value', 1, 2, '1']
    result_list = ['value', 'value', 'value', 1, 2, '1']
    assert lenient_lowercase(test_list) == result_list



# Generated at 2022-06-11 01:42:23.122356
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [
        'ABC',
        'AbC',
        123,
        {'key': 'value'}
    ]
    assert lenient_lowercase(test_list) == ['abc', 'abc', 123, {'key': 'value'}]



# Generated at 2022-06-11 01:42:29.628435
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 1, 3.2, {}, []]) == ['a', 'b', 1, 3.2, {}, []]
    assert lenient_lowercase(['A', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase([u'A', u'Ü', 'C']) == ['a', u'ü', 'c']


# Test for human_to_bytes

# Generated at 2022-06-11 01:42:35.070849
# Unit test for function human_to_bytes
def test_human_to_bytes():
    cases = {
        '2K': 2 * 1024,
        '12M': 12 * 1024 * 1024,
        '1G': 1 * 1024 * 1024 * 1024,
        '12Kb': 12 * 1024,
        '1MB': 1 * 1024 * 1024,
        '100B': 100,
        '100b': 100,
    }
    for test_input, expect in cases.items():
        ret = human_to_bytes(test_input)
        assert ret == expect, "Test input: %s, ret: %s, expect: %s" % (test_input, ret, expect)



# Generated at 2022-06-11 01:42:45.069440
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, isbits=True) == '80.00 bits'
    assert bytes_to_human(10, unit='b') == '10.00 bits'
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'

# Generated at 2022-06-11 01:42:56.053631
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.0kb') == 1024  # Human readable format is case insensitive (1KB = 1kb = 1k = 1kB)
    assert human_to_bytes('1kB') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes(10, 'm') == 10485760
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10', 'M') == 10485760
    assert human_to_bytes(1024, 'k') == 1048576
    assert human_to_bytes('1024K') == 1048576
    assert human_to_bytes('1B') == 1

# Generated at 2022-06-11 01:43:06.965375
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B', isbits=True) == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1000b') == 125
    assert human_to_bytes('1000B') == 125
    assert human_to_bytes('1000b', isbits=True) == 125
    assert human_to_bytes('1000B', isbits=True) == 125

    assert human_to_bytes('1K') == 1 << 10

# Generated at 2022-06-11 01:43:18.548814
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('10') == 10
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('1M') == 1024 ** 2
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('1G') == 1024 ** 3
    assert human_to_bytes('10G') == 10737418240
    assert human_to_bytes('1T') == 1024 ** 4
    assert human_to_bytes('10T') == 10995116277760
    assert human_to_bytes('1P') == 1024 ** 5
    assert human_to_bytes('10P') == 11258999068426240

    assert human_to_bytes

# Generated at 2022-06-11 01:43:31.253298
# Unit test for function human_to_bytes
def test_human_to_bytes():
    min_value = -1
    max_value = 10
    for i in range(min_value, max_value):
        human_number = bytes_to_human(i)
        human_number_bytes = human_number + " (bytes)"
        human_number_bits = human_number + " (bits)"
        result = human_to_bytes(human_number_bytes)
        assert i == result, "Convertion failed. Expected %s but got %s" % (i, result)
    result = human_to_bytes('2K')
    assert result == 2 * 1024, "Convertion failed. Expected %s but got %s" % (2 * 1024, result)
    result = human_to_bytes('2m', isbits=True)

# Generated at 2022-06-11 01:43:33.485687
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['aBc', 1.0, 'cD', 'EF']) == ['abc', 1.0, 'cd', 'ef']



# Generated at 2022-06-11 01:43:45.750146
# Unit test for function bytes_to_human
def test_bytes_to_human():

    assert bytes_to_human(1000000000) == '1.00 GB'
    assert bytes_to_human(1500000000) == '1.50 GB'
    assert bytes_to_human(2000000000) == '2.00 GB'
    assert bytes_to_human(512000000) == '512.00 MB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(10485760) == '10.00 MB'
    assert bytes_to_human(104857600) == '100.00 MB'
    assert bytes_to_human(1048576000) == '1000.00 MB'
    assert bytes_to_human(10485760000) == '10000.00 MB'
    assert bytes_to_human(1024) == '1.00 KB'


# Generated at 2022-06-11 01:43:57.088342
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """
    Unit test for bytes_to_human function.
    """
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(10, isbits=True) == '10 bits'
    assert bytes_to_human(10, unit='B') == '10 Bytes'
    assert bytes_to_human(10, isbits=True, unit='b') == '10 bits'
    assert bytes_to_human(10, unit='m') == '0.01 MB'
    assert bytes_to_human(10, isbits=True, unit='M') == '10 Mb'
    assert bytes_to_human(2**32) == '4.00 GB'
    assert bytes_to_human(2**32, isbits=True) == '4.00 Gb'
    assert bytes_

# Generated at 2022-06-11 01:44:07.338950
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('Testing function human_to_bytes ...')
    assert(human_to_bytes('10m') == 10 * SIZE_RANGES['M']), "human_to_bytes('10m') does not return 10 * 1024 * 1024"
    assert(human_to_bytes('10M') == 10 * SIZE_RANGES['M']), "Test 2 failed"
    assert(human_to_bytes('10mb') == 10 * SIZE_RANGES['M']), "Test 3 failed"
    assert(human_to_bytes('10MB') == 10 * SIZE_RANGES['M']), "Test 4 failed"
    assert(human_to_bytes('10Mb', isbits=True) == 10 * SIZE_RANGES['M']), "Test 5 failed"

# Generated at 2022-06-11 01:44:19.412882
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes(1024) == 1024
    assert human_to_bytes(1024) == 1 * SIZE_RANGES['K']
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1mb') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1M') == 1048576

# Generated at 2022-06-11 01:44:26.479434
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase([u"UNIT", 42, "FORTY-TWO"]) == ["unit", 42, "forty-two"])


# Generated at 2022-06-11 01:44:36.626199
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # case 1: integer not as string
    try:
        human_to_bytes(1)
        assert False
    except ValueError:
        pass

    # case 2: integer as string (with unit)
    assert human_to_bytes('1') == 1

    # case 3: integer as string
    assert human_to_bytes('1') == 1

    # case 4: float as string
    assert human_to_bytes('1.5') == 1

    # case 5: number as string (with unit)
    assert human_to_bytes('1K') == 1024

    # case 5: number as string (with unit)
    assert human_to_bytes('1.5K') == 1536

    # case 6: number and bit as string
    assert human_to_bytes('1Mb', isbits=True) == 1048576



# Generated at 2022-06-11 01:44:48.014350
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # This is a test for unit of function human_to_bytes.
    # Goal: cover function with test cases.
    # Limit for bytes:
    SIZE_RANGES_LTR = {
        'B': 1,
        'K': 1 << 10,
        'M': 1 << 20,
        'G': 1 << 30,
        'T': 1 << 40,
        'P': 1 << 50,
        'E': 1 << 60,
        'Z': 1 << 70,
        'Y': 1 << 80,
    }
    # Limit for bits:

# Generated at 2022-06-11 01:44:52.139115
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Foo', 'Bar']) == ['foo', 'bar']
    assert lenient_lowercase(['Foo', 123]) == ['foo', 123]
    assert lenient_lowercase([123, 'Foo']) == [123, 'Foo']

# Generated at 2022-06-11 01:44:56.012948
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['I', 'Me', 'Mine']) == ['i', 'me', 'mine']
    assert lenient_lowercase(['I', 123, 'Me', 'Mine']) == ['i', 123, 'me', 'mine']


# Unit tests for function human_to_bytes

# Generated at 2022-06-11 01:45:03.231926
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Test for lenient_lowercase function.

    Checks that function returns correct values for correct input arguments
    and raises ValueError for incorrect arguments.
    """
    from nose.tools import eq_, raises
    eq_(lenient_lowercase(['wrong', 'answer']), ['wrong', 'answer'])
    eq_(lenient_lowercase(['Right', 'answer', '1']), ['right', 'answer', '1'])
    eq_(lenient_lowercase([]), [])



# Generated at 2022-06-11 01:45:08.661926
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c'])
    assert(lenient_lowercase(['A', 1, 'B', 2]) == ['a', 1, 'b', 2])
    assert(lenient_lowercase(['A', None, 'B']) == ['a', None, 'b'])

# Generated at 2022-06-11 01:45:19.223328
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import unittest
    import pytest
    import random

    # test cases with bytes
    TEST_CASES_BYTES = [
        ('2', 2), ('20M', 20 * 1024 * 1024), ('20MB', 20 * 1024 * 1024), ('20MBB', 20 * 1024 * 1024),
        ('20MBBb', 20 * 1024 * 1024), ('20MBBbB', 20 * 1024 * 1024), ('20MBBbBs', 20 * 1024 * 1024),
        ('20Mb', 20 * 1024 * 1024), ('20Mbb', 20 * 1024 * 1024), ('20MbbB', 20 * 1024 * 1024),
        ('20MbbBs', 20 * 1024 * 1024), ('20B', 20), ('20b', 20), ('20bb', 20), ('20bbB', 20)
    ]

    # test cases with bits
   

# Generated at 2022-06-11 01:45:30.795232
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # example for negative zero
    assert(human_to_bytes('0') == 0)
    assert(human_to_bytes('-0') == 0)
    assert(human_to_bytes('1') == 1)

    # example for bytes
    assert(human_to_bytes('32b') == 32)
    assert(human_to_bytes('0B') == 0)
    assert(human_to_bytes('1b') == 1)
    assert(human_to_bytes('10.5b') == 11)
    assert(human_to_bytes('1.0b') == 1)
    assert(human_to_bytes('-0.0b') == 0)

    # example for bytes with 'B'
    assert(human_to_bytes('2KB') == 2048)

# Generated at 2022-06-11 01:45:42.698850
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1K') == 1 << 10
    assert human_to_bytes('1.5K') == (1 << 10) + (1 << 9)
    assert human_to_bytes('1M') == 1 << 20
    assert human_to_bytes('1.5M') == (1 << 20) + (1 << 19)
    assert human_to_bytes('1G') == 1 << 30
    assert human_to_bytes('1.5G') == (1 << 30) + (1 << 29)
    assert human_to_bytes('1T') == 1 << 40
   

# Generated at 2022-06-11 01:46:03.545292
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:46:05.726881
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]

# Unit tests for function human_to_bytes


# Generated at 2022-06-11 01:46:17.859281
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Bytes
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2KB') == 2048
    assert human_to_bytes('2Kb') == 2048
    assert human_to_bytes('2k') == 2048

    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('2MB') == 2097152
    assert human_to_bytes('2Mb') == 2097152
    assert human_to_bytes('2m') == 2097152

    assert human_to_bytes('2G') == 2147483648
    assert human_to_bytes('2GB') == 2147483648
    assert human_to_bytes('2Gb') == 2147483648
    assert human_to_bytes('2g') == 2147483648



# Generated at 2022-06-11 01:46:27.658570
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:46:29.733601
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 'aBc']) == [1, 2, 'abc']


# Generated at 2022-06-11 01:46:40.087257
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_test_data = [
        [['aAa', 'AaA', 'bB'], ['aaa', 'aaa', 'bb']],
        [['aAa', 'AaA', {}, 'bB'], ['aaa', 'aaa', {}, 'bb']],
        [['aAa', 'AaA', {}, 'bB', 48], ['aaa', 'aaa', {}, 'bb', 48]],
        [['aAa', 'AaA', {}, 'bB', 48, '0b0'], ['aaa', 'aaa', {}, 'bb', 48, '0b0']],
    ]
    for test_data in input_test_data:
        assert lenient_lowercase(test_data[0]) == test_data[1]



# Generated at 2022-06-11 01:46:51.498784
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:47:03.611169
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # 1048576 (2^20) is the number of Bytes in a Megabyte
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1m', isbits=True) == 1048576
    assert human_to_bytes('1mb', isbits=True) == 1048576

    try:
        human_to_bytes('1MG')
        assert False, 'MG not a valid unit, should throw an error'
    except ValueError:
        pass

# Generated at 2022-06-11 01:47:14.494125
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Unit test for human_to_bytes function.
    '''

    from os import environ
    import sys

    if 'TRAVIS' in environ:
        # Skip test if running on Travis
        return

    def print_error_message(input_str, output_str, err_str):
        print("FAILED CONVERSION FOR {}".format(input_str))
        print("\tEXPECTED RESULT: {}".format(output_str))
        print("\tGOT: {}\n{}".format(err_str, sys.exc_info()[0]))
        print("-" * 80)

    def print_success_message(input_str, output_str):
        print("PASSED CONVERSION FOR {}".format(input_str))

# Generated at 2022-06-11 01:47:20.646106
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Single byte, no unit
    assert human_to_bytes('123') == 123
    assert human_to_bytes('123.45') == 123
    assert human_to_bytes(' 123 ') == 123
    assert human_to_bytes('123.45.6') == 123
    assert human_to_bytes(' 123 ') == 123
    assert human_to_bytes('123.45 ') == 123

    # Single byte, with unit
    assert human_to_bytes('123b') == 123
    assert human_to_bytes('123.45B') == 123
    assert human_to_bytes(' 123 b ') == 123
    assert human_to_bytes('123.45.6B') == 123
    assert human_to_bytes(' 123 B ') == 123
    assert human_to_bytes('123.45 B ') == 123

# Generated at 2022-06-11 01:47:36.515826
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_data = [
        'aBcD',
        ['aBcD'],
        ['aBcD', b'eFgH'],
        ['aBcD', [b'eFgH']],
    ]
    expected_results = [
        'abcd',
        ['abcd'],
        ['abcd', b'efgh'],
        ['abcd', [b'efgh']],
    ]

    results = lenient_lowercase(test_data)

    assert results == expected_results



# Generated at 2022-06-11 01:47:47.198644
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'b', 1, 'c']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'b', 1, 'c']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'c']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['a', 1, True, 'b', 'c']) == ['a', 1, True, 'b', 'c']



# Generated at 2022-06-11 01:47:55.710181
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:48:07.987246
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import sys
    try:
        # If this fails, you are on Python 2 which has no assertRaisesRegexp()
        assertRaisesRegex = getattr(__builtins__, 'assertRaisesRegex', None)
    except AttributeError:
        assertRaisesRegex = None

    if not assertRaisesRegex:

        def assertRaisesRegex(exception, regex):
            # This is just a dummy function to replace assertRaisesRegexp()
            # and make the code compatible with both Python 2 and 3
            return

    def check_value(value, expected, isbits=False, unit=None):
        if isbits is True:
            result = human_to_bytes(value, isbits=True) == expected
        elif unit is None:
            result = human_to_bytes(value) == expected


# Generated at 2022-06-11 01:48:16.064171
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(['A', 'B', 'C'])
    if [item.lower() for item in ['A', 'B', 'C']] != result:
        raise Exception('test_lenient_lowercase failed')

    result = lenient_lowercase(['A', 'B', {'C': 1}, 'D'])
    if [item.lower() if isinstance(item, str) else item for item in ['A', 'B', {'C': 1}, 'D']] != result:
        raise Exception('test_lenient_lowercase failed')

    print('test_lenient_lowercase passed')



# Generated at 2022-06-11 01:48:18.245649
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(['A', 1, 'BC', False])
    assert repr(result) == "['a', 1, 'bc', False]"

# Generated at 2022-06-11 01:48:27.868236
# Unit test for function lenient_lowercase

# Generated at 2022-06-11 01:48:39.201478
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:48:44.019267
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test list of only strings
    assert lenient_lowercase(['test']) == ['test'.lower()]

    # Test list of mixed strings and non-strings
    assert lenient_lowercase([1, 'test']) == [1, 'test'.lower()]

# Unit tests for function human_to_bytes

# Generated at 2022-06-11 01:48:55.682479
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:49:23.685744
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    ''' Test lenient_lowercase() function '''
    test_list = ['str', 1, 'str2', {'a': 'b'}]
    test_list_lower = lenient_lowercase(test_list)
    assert test_list_lower == ['str', 1, 'str2', {'a': 'b'}]
    test_list2 = ['str', {'asd', 'qwe'}, 'str2', {'a': 'b', 'c': 'd'}]
    test_list2_lower = lenient_lowercase(test_list2)
    assert test_list2_lower == ['str', {'asd', 'qwe'}, 'str2', {'a': 'b', 'c': 'd'}]

# Generated at 2022-06-11 01:49:35.421195
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("\nStart running test for human_to_bytes()")

# Generated at 2022-06-11 01:49:40.517411
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase([1, 2, "ab", 3]) == [1, 2, "ab", 3]
    assert lenient_lowercase(["AB", 2, "ab", "cd"]) == ["ab", 2, "ab", "cd"]



# Generated at 2022-06-11 01:49:47.446098
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    '''This function just checks example.'''
    lst = ['abc', '', 'aBc', 0, None, [], {}, 'c', '0']
    # check if it's working and doesn't have any regression
    final_lst = ['abc', '', 'abc', 0, None, [], {}, 'c', '0']
    assert lenient_lowercase(lst) == final_lst


# Generated at 2022-06-11 01:49:52.128793
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c', 'D', 'e']) == ['a', 'b', 'c', 'D', 'e']
    assert lenient_lowercase(['a', 'b', 5, 10, 'e']) == ['a', 'b', 5, 10, 'e']

# Generated at 2022-06-11 01:50:04.669606
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # should return a number of bytes
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2k') == 2048
    assert human_to_bytes('2KB') == 2048
    assert human_to_bytes('2kb') == 2048
    # bytes without unit is not allowed - ValueError
    try:
        human_to_bytes('2')
        raise Exception
    except ValueError:
        pass

    # should return a number of bits
    assert human_to_bytes('2K', isbits=True) == 16384
    assert human_to_bytes('2k', isbits=True) == 16384
    assert human_to_bytes('2Kb', isbits=True) == 16384
    assert human_to_bytes('2kb', isbits=True) == 16384

    # bits without unit