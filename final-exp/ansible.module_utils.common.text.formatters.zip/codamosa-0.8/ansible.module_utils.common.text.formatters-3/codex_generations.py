

# Generated at 2022-06-11 01:40:16.206306
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("Unit test for function human_to_bytes")
    import sys
    import types

    cur_func = sys._getframe().f_code.co_name

    # List of test case

# Generated at 2022-06-11 01:40:22.034299
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test human_to_bytes converting bytes
    tests = [('2048B', 2048), ('1MB', 1048576), ('10 MB', 10485760), ('1 KB', 1024)]
    for test, result in tests:
        assert human_to_bytes(test) == result

    # Test human_to_bytes converting bits
    tests_bits = [('2048b', 2048), ('1 Mb', 1048576), ('10 Mb', 10485760), ('1 Kb', 1024)]
    for test_bits, result_bits in tests_bits:
        assert human_to_bytes(test_bits, isbits=True) == result_bits

    # Test human_to_bytes with no unit given

# Generated at 2022-06-11 01:40:26.258517
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['1', 'Test', 'Str', 1, 2]
    assert lenient_lowercase(lst) == ['1', 'test', 'str', 1, 2]
    lst = [{'key': 'lower'}, 'Test', 'Str', 1, 2]
    assert lenient_lowercase(lst) == [{'key': 'lower'}, 'test', 'str', 1, 2]

# Generated at 2022-06-11 01:40:28.346802
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['a', 'B', 5]) == ['a', 'b', 5])


# Generated at 2022-06-11 01:40:37.530499
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M', isbits=False) == int(round(1024 * 1024))
    assert human_to_bytes('1Mb', isbits=True) == int(round(1024 * 1024))
    assert human_to_bytes('1.12M', isbits=False) == int(round(1.12 * 1024 * 1024))
    assert human_to_bytes('11.2M', isbits=False) == int(round(11.2 * 1024 * 1024))
    assert human_to_bytes('11.2M', 'M', isbits=False) == int(round(11.2 * 1024 * 1024))
    assert human_to_bytes('11.2MB', isbits=False) == int(round(11.2 * 1024 * 1024))

# Generated at 2022-06-11 01:40:49.150368
# Unit test for function human_to_bytes
def test_human_to_bytes():
    if human_to_bytes('10M', 'B') != 10485760:
        raise Exception('test_human_to_bytes failed 0')
    if human_to_bytes('10M') != 10485760:
        raise Exception('test_human_to_bytes failed 1')
    if human_to_bytes('10') != 10:
        raise Exception('test_human_to_bytes failed 2')
    if human_to_bytes('10K') != 10240:
        raise Exception('test_human_to_bytes failed 3')
    if human_to_bytes('10Mb', isbits=True) != 10485760:
        raise Exception('test_human_to_bytes failed 4')

# Generated at 2022-06-11 01:40:56.661470
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest
    # bytes with suffixes
    assert human_to_bytes('1337 B') == 1337
    assert human_to_bytes('1337b') == 1337
    assert human_to_bytes('1337 Bb') == 1337
    assert human_to_bytes('1337B') == 1337
    assert human_to_bytes('1 KB') == 1024
    assert human_to_bytes('3 K') == 3072
    assert human_to_bytes('1 b') == 1
    assert human_to_bytes('3 b') == 3
    assert human_to_bytes('1.5 B') == 1.5
    assert human_to_bytes('1.5 KB') == 1536
    assert human_to_bytes('1.5 Kb') == 1536

# Generated at 2022-06-11 01:41:00.532575
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['TTT', 123, 'xxx', 'YYY']) == ['ttt', 123, 'xxx', 'yyy']



# Generated at 2022-06-11 01:41:11.857853
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10, isbits=False) == '10 Bytes'
    assert bytes_to_human(10, isbits=True) == '10 bits'
    assert bytes_to_human(10, isbits=True, unit='B') == '80 bits'
    assert bytes_to_human(10, isbits=True, unit='b') == '80.00 bits'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1044480) == '1021.80 KB'
    assert bytes_to_human(14268461056) == '13.30 GB'
    assert bytes_to_human(14268461056, unit='Kb') == '1.08 GB'

# Generated at 2022-06-11 01:41:20.315699
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Unit test for function human_to_bytes"""
    assert(human_to_bytes('2', 'K') == 2 * 1024)
    assert(human_to_bytes('2K') == 2 * 1024)
    assert(human_to_bytes('2M') == 2 * 1024 * 1024)
    assert(human_to_bytes('2G') == 2 * 1024 * 1024 * 1024)
    assert(human_to_bytes('2T') == 2 * 1024 * 1024 * 1024 * 1024)
    assert(human_to_bytes('2P') == 2 * 1024 * 1024 * 1024 * 1024 * 1024)
    assert(human_to_bytes('2E') == 2 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024)

# Generated at 2022-06-11 01:41:34.735217
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes('10Mb') == human_to_bytes(10, 'Mb', isbits=True)
    assert human_to_bytes('10Mb', isbits=True) == human_to_bytes(10, 'Mb', isbits=True)

    # test file size
    assert human_to_bytes('1E', isbits=False) == human_to_bytes(1, 'E', isbits=False)
    assert human_to_bytes('1G', isbits=False) == human_to_bytes(1, 'G', isbits=False)
    assert human_to_bytes('1M', isbits=False) == human_to_bytes(1, 'M', isbits=False)


# Generated at 2022-06-11 01:41:44.096895
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024
    # 'M' in 1M
    assert human_to_bytes('1M') == 1024 * 1024, 'failed when passing 1M'
    # lowercase, according to SIZE_RANGES
    assert human_to_bytes('1m') == 1024 * 1024, 'failed when passing 1m'
    assert human_to_bytes('1b') == 1, 'failed when passing 1b'
    assert human_to_bytes('1.5b') == 1, 'failed when passing 1.5b'
    assert human_to_bytes('1.5k') == 1536, 'failed when passing 1.5k'
    assert human_to_bytes('1.5K') == 1536, 'failed when passing 1.5K'
    assert human_to_bytes(1000) == 1000

# Generated at 2022-06-11 01:41:52.610068
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    "Test case for function lenient_lowercase"
    assert lenient_lowercase(['a', 'B', 1, 'D', 'b']) == ['a', 'B', 1, 'D', 'b']
    assert lenient_lowercase(['A', 'B', 1, 'D', 'b']) == ['a', 'B', 1, 'D', 'b']
    assert lenient_lowercase(['a', 'b', 1, 'd', 'B']) == ['a', 'b', 1, 'd', 'B']


# Generated at 2022-06-11 01:42:03.970093
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:42:05.394639
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576

# Generated at 2022-06-11 01:42:12.112807
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(0) == 0
    assert human_to_bytes('0') == 0
    assert human_to_bytes("0b") == 0
    assert human_to_bytes("0b", "B") == 0
    assert human_to_bytes("0KB") == 0
    assert human_to_bytes("0MB") == 0
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0KB') == 1024
    assert human_

# Generated at 2022-06-11 01:42:16.727880
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test case with a mix of upper, lower and non-string elements
    lst_upper = ["STRING1", "string2", "string3", 1, 2]
    lst_expected = ["string1", "string2", "string3", 1, 2]
    assert lenient_lowercase(lst_upper) == lst_expected

# Generated at 2022-06-11 01:42:21.812608
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A']) == ['a']
    assert lenient_lowercase(['A', 1]) == ['a', 1]
    assert lenient_lowercase([['b']]) == [['b']]

# Generated at 2022-06-11 01:42:32.120538
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import sys

# Generated at 2022-06-11 01:42:43.542651
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Test function with several sample cases"""

# Generated at 2022-06-11 01:42:56.192654
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('11') == 11
    assert human_to_bytes('11', unit='B') == 11
    assert human_to_bytes('11B') == 11
    assert human_to_bytes('11b', isbits=True) == 11
    assert human_to_bytes('11 Mb', isbits=True) == 11 * 1024 * 1024
    assert human_to_bytes('11.2Mb', isbits=True) == 11.2 * 1024 * 1024
    assert human_to_bytes('11.2Mb', isbits=False) == 11.2 * 1024 * 1024
    assert human_to_bytes('11.2MB', isbits=False) == 11.2 * 1024 * 1024
    assert human_to_bytes('11.2k', isbits=False) == 11.2 * 1024
    assert human_to

# Generated at 2022-06-11 01:43:07.065948
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1000, default_unit='B') == 1000
    assert human_to_bytes('1000', default_unit='B') == 1000
    assert human_to_bytes('1000.0', default_unit='B') == 1000
    assert human_to_bytes('1000.0B', default_unit='B') == 1000
    assert human_to_bytes(u'2KB', default_unit='B') == 2048
    assert human_to_bytes('2 Kb', default_unit='B') == 2048
    assert human_to_bytes(4, default_unit='Kb') == 4096
    #
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1 Mb', isbits=True) == 1048576

# Generated at 2022-06-11 01:43:18.549329
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes("21.5", unit='TB') == 236047475968)
    assert(human_to_bytes("21.5B", unit='TB') == 21.5)
    assert(human_to_bytes("21.5", unit='b') == 21.5)
    assert(human_to_bytes("21.5b", unit='b') == 21.5)
    assert(human_to_bytes("21.5b", unit='b', isbits=True) == 21.5)
    assert(human_to_bytes("21.5", unit='b', isbits=True) == 21.5)
    assert(human_to_bytes("21.5M") == 225280)
    assert(human_to_bytes("21.5M", isbits=True) == 225280000)

# Generated at 2022-06-11 01:43:21.734952
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lower = lenient_lowercase([1, 'AbCdEf'])
    assert lower[0] == 1
    assert lower[1] == 'abcdef'



# Generated at 2022-06-11 01:43:33.484728
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_cases = [
        ('1B', 1, None),
        ('1B', 1, 'B'),
        ('1KB', 1000, None),
        ('1KB', 0, 'B'),
        ('1Kb', 1000, None, True),
        ('1Kb', 0, 'B', True),
        ('1Kb', 0, 'Mb', True),
        ('1Mb', 1000000, None, True),
        ('1Mb', 0, 'B', True),
        ('1MB', 1000000, None),
        ('1MB', 0, 'B'),
        ('1Mb', 0, 'MB', True),
        ('1.2Mb', 1200000, None, True),
        ('1.2b', 1.2, None, True)
    ]

# Generated at 2022-06-11 01:43:45.750906
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('10K', default_unit='M') == 10240
    assert human_to_bytes('10', default_unit='M') == 10
    assert human_to_bytes('1.2M') == 1258291
    assert human_to_bytes('0.1M') == 104858
    assert human_to_bytes('1.2Mb') == 1572864
    assert human_to_bytes('0.1Mb', isbits=True) == 125829
    assert human_to_bytes('1.2B') == 1
    assert human_to_bytes('.2B') == 0
    assert human_to_bytes('.2b') == 0
    assert human_to_bytes('1.2X') == 1
    assert human

# Generated at 2022-06-11 01:43:56.380503
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    test_list = ['test1', 'test2', 2, 3, 4, "test5", 'test6', ('test7',), ('test8', 'test9'), ['test10']]
    result = lenient_lowercase(test_list)

    assert result == ['test1', 'test2', 2, 3, 4, "test5", 'test6', ('test7',), ('test8', 'test9'), ['test10']], \
        'lenient_lowercase() returned unexpected result {} instead of {}'.format(result,
                                                                                 ['test1', 'test2', 2, 3, 4, "test5", 'test6', ('test7',), ('test8', 'test9'), ['test10']])



# Generated at 2022-06-11 01:44:07.073019
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M'), \
        'Failure to convert bytes from human-readable format to integer.' \
        ' Example: human_to_bytes("10M") returns 10485760 (int).'
    assert human_to_bytes('1MB') == human_to_bytes(1, 'MB'), \
        'Failure to convert bytes from human-readable format to integer.' \
        ' Example: human_to_bytes("1MB") returns 1048576 (int).'
    assert human_to_bytes('1MB') == 1048576, \
        'Failure to convert bytes from human-readable format to integer.' \
        ' Example: human_to_bytes("1MB") returns 1048576 (int).'
    assert human_to_bytes('1w') == human_to_

# Generated at 2022-06-11 01:44:12.895961
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Abc', 'def']) == ['abc', 'def']
    assert lenient_lowercase(['Abc', 123]) == ['abc', 123]
    assert lenient_lowercase(['Abc', 'def', 123, (4, 5)]) == ['abc', 'def', 123, (4, 5)]



# Generated at 2022-06-11 01:44:24.215364
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Unit test for function human_to_bytes
    '''
    # cases that must pass
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('0b') == 0
    assert human_to_bytes('0B') == 0
    assert human_to_bytes('0K') == 0
    assert human_to_bytes('0Kb') == 0
    assert human_to_bytes('0KB') == 0
    assert human_to_bytes('1', 'M') == 1048576
    assert human_to_bytes('1.5', 'M') == 1572864
    assert human_to_bytes('1.5M') == 1572864
    assert human_to

# Generated at 2022-06-11 01:44:36.140646
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:44:47.100648
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1') == 1)
    assert(human_to_bytes('1b') == 1)
    assert(human_to_bytes('1k') == 1024)
    assert(human_to_bytes('1M') == 1024 * 1024)
    assert(human_to_bytes('1G') == 1024 * 1024 * 1024)
    assert(human_to_bytes('1T') == 1024 * 1024 * 1024 * 1024)
    assert(human_to_bytes('1Y') == 1024 * 1024 * 1024 * 1024 * 1024)
    assert(human_to_bytes('1P') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024)
    assert(human_to_bytes('1Z') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024)

# Generated at 2022-06-11 01:44:56.210216
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:45:07.421047
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1000
    assert human_to_bytes('1KB') == 1000
    assert human_to_bytes('1kb') == 1000
    assert human_to_bytes('1Kb') == 1000
    assert human_to_bytes('1M') == 1000000
    assert human_to_bytes('1MB') == 1000000
    assert human_to_bytes('1mb') == 1000000
    assert human_to_bytes('1.1M') == 1100000
    assert human_to_bytes('1.1MB') == 1100000
    assert human_to_bytes('1.1mb') == 1100000
    assert human_to

# Generated at 2022-06-11 01:45:18.303701
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1024B') == 1024
    assert human_to_bytes('1K', 'B') == 1024
    assert human_to_bytes('1K', 'B') == human_to_bytes('1K')
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M', 'B') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    with pytest.raises(ValueError):
        assert human_to_bytes('1MB', isbits=True)

# Generated at 2022-06-11 01:45:26.960167
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1 gb') == 1073741824
    assert human_to_bytes('1Tb') == 1099511627776


# Generated at 2022-06-11 01:45:30.936645
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """
    Test lenient_lowercase
    """
    str_list = ['A', 'aaa', '123', [], {}, 1, 3.2]
    expected_result = ['a', 'aaa', '123', [], {}, 1, 3.2]
    assert lenient_lowercase(str_list) == expected_result



# Generated at 2022-06-11 01:45:42.810885
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest

    _errors = []

    def _assert(**kwargs):
        _errors.append(kwargs)


# Generated at 2022-06-11 01:45:47.223993
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest
    test_content = [
        ('1', 1),
        ('10B', 10),
        ('1B', 1),
        ('1KB', '1024'),
        ('10KB', '10240'),
        ('7.2K', '7168'),
        ('1M', '1048576'),
        ('1.3M', '1310720'),
        ('1.3MB', '1310720'),
        ('1.3Mb', ValueError),
        ('1.3MBb', ValueError),
    ]
    for content in test_content:
        try:
            result = human_to_bytes(content[0])
        except Exception as e:
            result = type(e)
        assert type(result) == type(content[1])

# Generated at 2022-06-11 01:45:54.003553
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Testing for correct conversion of strings to integer number of bytes '''
    assert human_to_bytes('1B') == 1, 'human_to_bytes("1B") should return: 1'
    assert human_to_bytes('2b') == 2, 'human_to_bytes("2b") should return: 2'
    assert human_to_bytes('1K') == 1024, 'human_to_bytes("1K") should return: 1024'
    assert human_to_bytes('1kB') == 1024, 'human_to_bytes("1kB") should return: 1024'
    assert human_to_bytes('1Kb') == 1024, 'human_to_bytes("1Kb") should return: 1024'
    assert human_to_bytes('1KB') == 1024, 'human_to_bytes("1KB") should return: 1024'


# Generated at 2022-06-11 01:46:06.651019
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test without unit set to 'B'
    assert human_to_bytes('2B') == 2
    assert human_to_bytes('2b') == 2
    assert human_to_bytes('2B', isbits=True) == 2
    assert human_to_bytes('2b', isbits=True) == 2
    assert human_to_bytes(2) == 2
    assert human_to_bytes(2.2) == 2
    # Test with unit set to 'B'
    assert human_to_bytes('2') == 2
    assert human_to_bytes('2', default_unit='B') == 2
    assert human_to_bytes('2', isbits=True) == 2
    assert human_to_bytes('2', default_unit='B', isbits=True) == 2

# Generated at 2022-06-11 01:46:18.698590
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:46:28.203203
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Test function human_to_bytes(). '''
    # Test usual notation with case-insensitive:
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10mb') == 10485760
    assert human_to_bytes('10Kb') == 10240
    assert human_to_bytes(10240, 'Kb') == 10240
    assert human_to_bytes('10GB', 'MB') == 10485760
    # Test long notation, with case-insensitive:
    assert human_to_bytes('10 byte') == 10
    assert human_to_bytes('10 bytes') == 10
    assert human_to_bytes('10 Bytes') == 10

# Generated at 2022-06-11 01:46:39.007114
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes('10K') == human_to_bytes(10, 'K')
    assert human_to_bytes('10B') == human_to_bytes(10, 'B')
    assert human_to_bytes('1Mb') == human_to_bytes(1, 'Mb', isbits=True)
    assert human_to_bytes('1Kb') == human_to_bytes(1, 'Kb', isbits=True)
    assert human_to_bytes('1b') == human_to_bytes(1, 'b', isbits=True)
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'K') == 10240


# Generated at 2022-06-11 01:46:50.245070
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.basic import AnsibleModule

    def test_human_to_bytes_cases(module):
        cases = dict(
            negative_number=dict(number='-1'),
            invalid_number=dict(number='INVALID'),
        )
        for name, args in iteritems(cases):
            with pytest.raises(ValueError):
                module.exit_json(changed=False, number=module.human_to_bytes(**args))

    # test without unit definition
    module = AnsibleModule(
        argument_spec=dict(
            number=dict(required=True),
        ),
        supports_check_mode=True
    )
    module.human_to_bytes = human_to_bytes
   

# Generated at 2022-06-11 01:47:02.479112
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import assert_raises, assert_equal

    assert_equal(human_to_bytes('1024'), 1024)
    assert_equal(human_to_bytes('2K'), 2048)
    assert_equal(human_to_bytes('2k'), 2048)
    assert_equal(human_to_bytes('2KB'), 2048)
    assert_equal(human_to_bytes('2Kb'), 2048)

    assert_equal(human_to_bytes('1024', isbits=True), 1024)
    assert_equal(human_to_bytes('2K', isbits=True), 2048)
    assert_equal(human_to_bytes('2k', isbits=True), 2048)
    assert_equal(human_to_bytes('2KB', isbits=True), 2048)

# Generated at 2022-06-11 01:47:06.146472
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 1, 'b', 2]) == ['a', 1, 'b', 2]



# Generated at 2022-06-11 01:47:08.514520
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['FOO', 'bAr', 42]) == ['foo', 'bar', 42]

# Generated at 2022-06-11 01:47:15.721233
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('5K') == 5120
    assert human_to_bytes('5Kb') == 5120
    assert human_to_bytes('5kb') == 6400
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10mb') == 13107200
    assert human_to_bytes('10MBb') == 13107200
    assert human_to_bytes('10Mbb') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10M', isbits=True) == 10485760
    assert human_to_bytes('10mb', isbits=True) == 13107200
   

# Generated at 2022-06-11 01:47:26.171490
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """
    Test function human_to_bytes
    """

    data_tests = [
        '10M',
        '1.2M',
        '10G',
        '10K',
        '10Kb',
        '10Mb',
        '10Gb',
        '1.2Mb',
        '1.2KB',
        '1.2MB',
        '1.2GB',
        '1.2KBb',
        '1.2MBb',
        '1.2GBb',
    ]

    for test in data_tests:
        test_result = human_to_bytes(test)
        assert test_result == human_to_bytes(test_result, 'B')


# Generated at 2022-06-11 01:47:42.554101
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Some examples for unit testing
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5M', 'B') == 1572864
    assert human_to_bytes('1.5Mb') == 1572864
    assert human_to_bytes('1.5Mb', 'b') == 1572864
    assert human_to_bytes('1.5Mb', isbits=True) == 1572864
    assert human_to_bytes('1.5Mb', 'b', isbits=True) == 1572864
    assert human_to_bytes('1.5M', 'KB') == 1536
    assert human_to_bytes('1.5Mb', 'KB', isbits=True) == 1536
    assert human_to_bytes('8K') == 8192

# Generated at 2022-06-11 01:47:52.685421
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["M1.Pla1N", "PiA.N", 1, 4, 5]) == ['m1.pla1n', 'pia.n', 1, 4, 5]
    assert lenient_lowercase(["M1.Pla1N", 1, 4, 5]) == ['m1.pla1n', 1, 4, 5]
    assert lenient_lowercase([1, 4, 5]) == [1, 4, 5]
    assert lenient_lowercase(["M1.Pla1N", "Pia.N", "pia.n"]) == ['m1.pla1n', 'pia.n', 'pia.n']



# Generated at 2022-06-11 01:47:54.531732
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Apple', 'PEAR', 1]) == ['apple', 'pear', 1]

# Generated at 2022-06-11 01:48:07.190216
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624

    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('10k') == 10240
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1g') == 1073741824
    assert human_to_bytes('1t') == 1099511627776
    assert human_to_bytes('1p') == 1125899906842624

# Generated at 2022-06-11 01:48:17.386906
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test '_human_to_bytes' function
    if human_to_bytes(1) != 1:
        raise AssertionError("assertion failed: human_to_bytes(1) != 1")
    if human_to_bytes('1') != 1:
        raise AssertionError("assertion failed: human_to_bytes('1') != 1")

    if human_to_bytes('1K') != 1024:
        raise AssertionError("assertion failed: human_to_bytes('1K') != 1024")
    if human_to_bytes('1M') != 1024 * 1024:
        raise AssertionError("assertion failed: human_to_bytes('1M') != 1024 * 1024")

# Generated at 2022-06-11 01:48:20.991057
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    import sys
    assert lenient_lowercase(['a', 'b', 'C', 'D']) == ['a', 'b', 'c', 'd']
    assert lenient_lowercase(['A', 'b', 1, 'C', 'D', sys]) == ['a', 'b', 1, 'c', 'd', sys]


# Generated at 2022-06-11 01:48:28.065201
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """test lowercase"""
    test_cases = [
        [['a', 'b', 'c'], ['a', 'b', 'c']],
        [['A', 'b', 'c'], ['a', 'b', 'c']],
        # non-str values should be passthrough
        [['a', 'b', 5], ['a', 'b', 5]],
    ]
    for case in test_cases:
        assert(lenient_lowercase(case[0]) == case[1])


# Generated at 2022-06-11 01:48:32.482992
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['FOO', 'BAR', 'baz']) == ['foo', 'bar', 'baz']
    assert lenient_lowercase(['FOO', 'BAR', 123]) == ['foo', 'bar', 123]


# Generated at 2022-06-11 01:48:43.833651
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('12T') == 1299511627776
    assert human_to_bytes('12TB') == 1299511627776
    assert human_to_bytes('12Tb') == 1328479514624640
    assert human_to_bytes('12.5 Tb') == 1410593792186880
    assert human_to_bytes('.5T') == 549755813888
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('1048576') == 1048576
    assert human_to_bytes(1048576) == 1048576
    assert human_to_bytes(1048576, 'kb') == 1024

# Generated at 2022-06-11 01:48:55.679896
# Unit test for function human_to_bytes
def test_human_to_bytes():
    cases = [
        ('10', 10),
        ('10.5', 10.5),
        ('10Mb', 10 * 1 << 20),
        ('10M', 10 * 1 << 20),
        ('5Mb', 10 * 1 << 19),
        ('20b', 20),
        ('20B', 20),
        ('20Bb', 20),
        ('', 0),
        ('20bB', 20),
        ('10MbB', 10 * 1 << 20),
        ('10M', 10 * 1 << 20),
        ('5Mb', 10 * 1 << 19),
        ('20b', 20),
        ('20B', 20),
        ('20Bb', 20),
        ('', 0),
    ]

    for case in cases:
        assert human_to_bytes(case[0]) == case[1]


# Generated at 2022-06-11 01:49:09.672411
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10') == 10
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('0MB') == 0
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB', unit='KB') == 1048576
    assert human_to_bytes('1MB', unit='KB', isbits=True) == 1048576



# Generated at 2022-06-11 01:49:21.001424
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:49:24.281183
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([[1, 2, 3], "FoO", "BAR"]) == [[1, 2, 3], "FoO", "BAR"]


# Generated at 2022-06-11 01:49:29.061208
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['abc', 1, 'def', 2]) == ['abc', 1, 'def', 2]
    assert lenient_lowercase([1, 'ABC', 'def', 2]) == [1, 'abc', 'def', 2]

# Generated at 2022-06-11 01:49:38.344705
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    # test lowercase with a list of lists
    test_list = {'foo':
                 {'bAr':
                  [{'baz': 'BAZ'}, 'Boo', 42],
                  'baz': [{'baz': 'BAZ'}, 'Boo', 42]},
                 'baR':
                 {'bAr':
                  [{'baz': 'BAZ'}, 'Boo', 42],
                  'baz': [{'baz': {'foo': 'FOO'}}, 'Boo', 42]}}

# Generated at 2022-06-11 01:49:41.420001
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ["Test", u"Test", 123]
    assert lenient_lowercase(test_list) == ["test", u"Test", 123]



# Generated at 2022-06-11 01:49:50.364088
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    '''
    Unit test for function lenient_lowercase
    '''
    assert lenient_lowercase(['AA', 'BB', 'CC']) == ['aa', 'bb', 'cc']
    assert lenient_lowercase(['AA', 1, 'CC']) == ['aa', 1, 'cc']
    assert lenient_lowercase(['AA', 1, 'CC', {'a': 'aa'}]) == ['aa', 1, 'cc', {'a': 'aa'}]
    assert lenient_lowercase(['AA', 1, ['CC', 'DD', 'EE'], {'a': 'aa'}]) == ['aa', 1, ['cc', 'dd', 'ee'], {'a': 'aa'}]



# Generated at 2022-06-11 01:50:03.008340
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976
    assert human_to_bytes('1Z') == 1180591620717411303424
   