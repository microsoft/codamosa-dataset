

# Generated at 2022-06-11 01:40:13.934138
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['aBc', 1, 'dEf']) == ['abc', 1, 'def']



# Generated at 2022-06-11 01:40:21.014272
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert 1048576 == human_to_bytes('1MB')
    assert human_to_bytes('1MB') == human_to_bytes('1MBb')
    assert human_to_bytes('1KBb') == human_to_bytes('1Kb')
    assert human_to_bytes('1', 'M') == human_to_bytes('1M')
    assert human_to_bytes('1', 'K') == human_to_bytes('1K')
    assert human_to_bytes('1', 'K', isbits=True) == human_to_bytes('1Kb')
    assert human_to_bytes('1024', isbits=True) == human_to_bytes('1Kb')
    assert human_to_bytes('1.5Kb') == human_to_bytes('1.5Kb')
    assert human

# Generated at 2022-06-11 01:40:28.596231
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:40:37.729467
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:40:49.430274
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from copy import copy

    # Test data

# Generated at 2022-06-11 01:41:00.623100
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576, unit='M') == '1.00 MB'
    assert bytes_to_human(1048577, unit='M') == '1.00 MB'
    assert bytes_to_human(1048576, unit='KB') == '1024.00 KB'
    assert bytes_to_human(1048576, unit='KB') == '1024.00 KB'
    assert bytes_to_human(1048577, unit='KB') == '1025.00 KB'
    assert bytes_to_human(1, unit='M') == '0.00 MB'
    assert bytes_to_human(1, unit='KB') == '0.00 KB'


# Generated at 2022-06-11 01:41:11.956315
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:41:17.547125
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lower_case_str = lenient_lowercase(['Hello', 'The', 1, 2, 3, 'World'])
    assert('hello' in lower_case_str)
    assert('the' in lower_case_str)
    assert(1 in lower_case_str)
    assert(2 in lower_case_str)
    assert(3 in lower_case_str)
    assert('world' in lower_case_str)



# Generated at 2022-06-11 01:41:30.660867
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:41:41.621001
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    test_human_to_bytes()
       To test the function human_to_bytes()
    '''
    print("----------- test_human_to_bytes -----------")
    print("The function human_to_bytes() with no unit param."
          "It returns the correct value depending on the input parameter.\n")


# Generated at 2022-06-11 01:41:56.347416
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10MB', isbits=True) == 10485760
    assert human_to_bytes('10MB', unit='M') == 10485760
    assert human_to_bytes('2M', unit='M') == 2097152
    assert human_to_bytes('10MB', unit='B') == 10485760
    assert human_to_bytes('2M', default_unit='B') == 2000000
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10Mb', unit='Mb') == 10

# Generated at 2022-06-11 01:42:01.558601
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['abc']) == ['abc']
    assert lenient_lowercase([1]) == [1]
    assert lenient_lowercase(['abc', 1]) == ['abc', 1]
    assert lenient_lowercase(['Abc', 1]) == ['abc', 1]

# Generated at 2022-06-11 01:42:11.101439
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K', default_unit='B') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K', default_unit='b') == 1024
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'M', isbits=True) == 83886080
    assert human_to_bytes(10, 'Mb') == 83886080
    assert human_to_bytes(10, 'MB') == 10485760

    assert bytes_to_human(10485760, isbits=True) == '83886080.00 bits'
    assert bytes_to_human(10485760, isbits=False) == '10.00 MB'

# Generated at 2022-06-11 01:42:15.504299
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['Az', 'b', 1]
    lower_list = lenient_lowercase(test_list)
    assert lower_list == ['az', 'b', 1]
    try:
        lenient_lowercase(test_list)
    except ValueError:
        assert True


# Generated at 2022-06-11 01:42:23.199209
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # "Failure" cases
    assertEqual(human_to_bytes('1MB'), 1048576)
    assertEqual(human_to_bytes('1MB', 'GB'), 1048576)
    assertEqual(human_to_bytes('1GB', 'MB'), 1000000)
    assertEqual(human_to_bytes('1MB', default_unit='GB'), 1048576)

    # "Success" cases
    assertEqual(human_to_bytes('1MB'), 1048576)
    assertEqual(human_to_bytes('1G'), 1073741824)
    assertEqual(human_to_bytes('4Kb'), 4096)
    assertEqual(human_to_bytes('4K'), 4096)
    assertEqual(human_to_bytes('4k'), 4096)

# Generated at 2022-06-11 01:42:32.865469
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'a', 'A']) == ['a', 'a', 'a']
    assert lenient_lowercase(['a', 'A', 'a']) == ['a', 'a', 'a']
    assert lenient_lowercase(['a', 'A', 'b', 'c', 'B', 'C']) == ['a', 'a', 'b', 'c', 'b', 'c']
    assert lenient_lowercase("aAa") == 'aaa'
    assert lenient_lowercase("AAA") == 'aaa'
    assert lenient_lowercase("aaa") == 'aaa'
    assert lenient_lowercase("AAA") == 'aaa'
    assert lenient_lowercase("AaA") == 'aaa'

# Generated at 2022-06-11 01:42:42.014670
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_dict = {
        '10M': 10485760,
        '10MB': 10485760,
        '1.5E': 1610612736,
        '1.5EB': 1610612736,
        '1Mb': 1048576,
        '1.5mb': 1572864,
        '1b': 1,
        '1Kb': 1024,
    }

    for k, v in test_dict.items():
        assert human_to_bytes(k) == v
        assert human_to_bytes(human_to_bytes(k), isbits=True, default_unit='b') == v


# Generated at 2022-06-11 01:42:53.738162
# Unit test for function human_to_bytes
def test_human_to_bytes():
    buf = "10M"
    expected_value = 10 * 1024 * 1024

    if human_to_bytes(buf) != expected_value:
        raise AssertionError("human_to_bytes() failed to convert %s" % buf)

    if human_to_bytes(buf, unit="M") != expected_value:
        raise AssertionError("human_to_bytes() failed to convert %s with default unit M" % buf)

    if human_to_bytes(buf, unit="") != expected_value:
        raise AssertionError("human_to_bytes() failed to convert %s with default unit ''" % buf)

    if human_to_bytes(buf, default_unit="M") != expected_value:
        raise AssertionError("human_to_bytes() failed to convert %s with default unit M" % buf)

# Generated at 2022-06-11 01:43:05.228909
# Unit test for function bytes_to_human

# Generated at 2022-06-11 01:43:17.792231
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5k') == 1536
    assert human_to_bytes('1.5Kb') == 1536
    assert human_to_bytes('1.5kb') == 1536
    assert human_to_bytes('1.5Kb', isbits=True) == 1536
    assert human_to_bytes('1.5kb', isbits=True) == 1536

    # check with default unit
    assert human_to_bytes

# Generated at 2022-06-11 01:43:25.398902
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import unittest

    class TestCases(unittest.TestCase):
        def test_bytes_to_human(self):
            self.assertEqual(bytes_to_human(1024, unit='K'), '1.00 KB')
            self.assertEqual(bytes_to_human(1024), '1.00 KB')
            self.assertEqual(bytes_to_human(1024, unit='k'), '1.00 KB')
            self.assertEqual(bytes_to_human(1024, unit='k', isbits=True), '8.00 Kb')
            self.assertEqual(bytes_to_human(1024, unit='K', isbits=True), '8.00 Kb')
            self.assertEqual(bytes_to_human(1024, isbits=True), '8.00 Kb')


# Generated at 2022-06-11 01:43:35.256331
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:43:47.146178
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:43:57.957877
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_input = [
        'abc',
        'ABC',
        ['abc', 'ABC', '123', 'xyz'],
        ['abc', 'XYZ', 123, 'xyz'],
        ['ABC', 'XYZ', 123, 'xyz'],
        ['ABC', 'XYZ', 123, 'xyz'],
    ]
    expected_output = [
        'abc',
        'abc',
        ['abc', 'abc', '123', 'xyz'],
        ['abc', 'xyz', 123, 'xyz'],
        ['abc', 'xyz', 123, 'xyz'],
        ['abc', 'xyz', 123, 'xyz'],
    ]
    for inp, expected in zip(test_input, expected_output):
        assert lenient_lowercase(inp) == expected

# Generated at 2022-06-11 01:44:00.331488
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Checking if all ascii chars are lowercased properly"""
    for i in range(0, 128):
        assert lenient_lowercase([chr(i)]) == [chr(i).lower()]



# Generated at 2022-06-11 01:44:05.338915
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    for values, expected_result in (
            (['SOMETHING', 'SOMETHING ELSE'], ['something', 'something else']),
            ([5, 10, None], [5, 10, None])):
        assert lenient_lowercase(values) == expected_result



# Generated at 2022-06-11 01:44:17.814350
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1232', default_unit='B') == 1232
    assert human_to_bytes(1024, default_unit='B') == 1024
    assert human_to_bytes(1024, 'K') == 1048576
    assert human_to_bytes('1024K') == 1048576
    assert human_to_bytes('1024Kb') == 1048576
    assert human_to_bytes('1024kb') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1.5Mb') == 1572864
    assert human_to_bytes('1.5M', isbits=True) == 1572864
    assert human_to_bytes('1.5Kb') == 1536

# Generated at 2022-06-11 01:44:27.830699
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # bytes test
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('1.5B') == 1
    assert human_to_bytes('0') == 0
    assert human_to_bytes('1.234B') == 1
    assert human_to_bytes('1.2345B') == 1
    assert human_to_bytes('1.23456B') == 1
    assert human_to_bytes('1.234567B') == 1
    assert human_to_bytes('1.2345678B') == 1
    assert human_to_bytes('1.23456789B') == 1
    # kilobytes test
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('10kb')

# Generated at 2022-06-11 01:44:37.943896
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:44:50.174601
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:45:02.542725
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest

    # Test with default unit
    assert human_to_bytes('2') == 2
    assert human_to_bytes('2K') == 2 * 1024
    assert human_to_bytes('2M') == 2 * 1024 * 1024
    assert human_to_bytes('2G') == 2 * 1024 * 1024 * 1024
    assert human_to_bytes('2T') == 2 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('2P') == 2 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('2E') == 2 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('2Z') == 2 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-11 01:45:05.972100
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [1, 'ABC', 'abc', 'AbC']
    assert lenient_lowercase(lst) == [1, 'ABC', 'abc', 'AbC']



# Generated at 2022-06-11 01:45:17.045470
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import unittest

    class HumanToBytesTestCase(unittest.TestCase):
        def test_basic(self):
            self.assertEqual(human_to_bytes('512'), 512)
            self.assertEqual(human_to_bytes('1MB'), 1048576)
            self.assertEqual(human_to_bytes('1Kb', isbits=True), 1024)
            self.assertEqual(human_to_bytes('1.5M', default_unit='B'), 1572864)
            self.assertEqual(human_to_bytes('.5 Mb', isbits=True), 65536)
            self.assertEqual(human_to_bytes(123), 123)
            self.assertEqual(human_to_bytes(1024), 1024)

# Generated at 2022-06-11 01:45:22.530866
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test empty value
    try:
        assert(human_to_bytes('') == 0)
    except ValueError:
        raise AssertionError("Unit test fail: empty value, raise ValueError")

    # test string with value and wrong unit
    for t in ['A', 'EA', 'PaB', 'EP', 'bA', 'Pb', 'Ab']:
        try:
            human_to_bytes(t)
        except ValueError:
            pass
        else:
            raise AssertionError("Unit test fail: string with value and invalid unit, don't raise ValueError")

    # test incorrect string with value and unit

# Generated at 2022-06-11 01:45:31.329445
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1KB') == 1024, "human_to_bytes doesn't return expected value"
    assert human_to_bytes('1MB') == 1048576, "human_to_bytes doesn't return expected value"
    assert human_to_bytes('1GB') == 1073741824, "human_to_bytes doesn't return expected value"
    assert human_to_bytes('1TB') == 1099511627776, "human_to_bytes doesn't return expected value"
    assert human_to_bytes(1) == 1, "human_to_bytes doesn't return expected value"
    assert human_to_bytes('1.1Kb') == 1150, "human_to_bytes doesn't return expected value"

# Generated at 2022-06-11 01:45:42.811427
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17283797779826688
    assert human_to_bytes('1.5Z') == 1768147420057967616
    assert human_to_bytes('1.5Y') == 180810920306865356800
    assert human_to_bytes('1.5B') == 15
    assert human_to_bytes('.5K') == 512
   

# Generated at 2022-06-11 01:45:47.205238
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ## Verify human_to_bytes raises ValueError when string input is invalid
    try:
        human_to_bytes('fasfs')
        assert (False, "Raise ValueError when string input is invalid")
    except ValueError:
        pass

    ## Verify human_to_bytes make proper conversion
    # Case 1: no unit given and default_unit given
    assert (human_to_bytes('2', default_unit='K') == 2048)

    # Case 2: unit given
    assert (human_to_bytes('2K') == 2048)

    # Case 3: no unit given and no default_unit given
    try:
        assert(human_to_bytes('2') == 2)
    except ValueError:
        pass

if __name__ == '__main__':
    test_human_to_bytes()

# Generated at 2022-06-11 01:45:55.181821
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_cases = [
        ('1B', 1),
        ('1.0B', 1),
        ('1.0', 1),
        ('1', 1),
        ('2K', 2048),
        ('10M', 10485760),
        ('1G', 1073741824),
        ('1T', 1099511627776),
        ('10P', 1125899906842624),
        ('1E', 1152921504606846976),
        ('1Z', 1180591620717411303424),
        ('1Y', 1208925819614629174706176)
    ]
    for s, n in test_cases:
        assert(human_to_bytes(s)==n)


# Generated at 2022-06-11 01:46:06.299922
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test exceptions
    bad_inputs = [None, '', 'X']
    for value in bad_inputs:
        try:
            human_to_bytes(value)
            assert False, 'ValueError is expected for %s' % value
        except ValueError:
            pass

    # Test good inputs

# Generated at 2022-06-11 01:46:18.372925
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('3K') == 3072
    assert human_to_bytes('3k') == 3072
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('2GB') == 2147483648
    assert human_to_bytes('2TB') == 2199023255552
    assert human_to_bytes('3.5TB') == 3865470566400
    assert human_to_bytes('3.5') == 3.5

# Generated at 2022-06-11 01:46:23.282290
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['First', 1, 'Second', 2, 'Third']
    result = ['first', 1, 'second', 2, 'third']
    assert(lenient_lowercase(lst) == result)

# Generated at 2022-06-11 01:46:31.152338
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test with default unit (bytes)
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1024.0') == 1024.0
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1024kb') == 1024 * SIZE_RANGES['K']
    assert human_to_bytes('1024kb') != 1024
    assert human_to_bytes('1024kb') != 1024.0
    assert human_to_bytes('1024kb') == 1024 * SIZE_RANGES['K']
    assert human_to_bytes('1024K') == 1024 * SIZE_RANGES['K']

# Generated at 2022-06-11 01:46:41.390240
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Performs a set of unit tests for function human_to_bytes '''

# Generated at 2022-06-11 01:46:44.112930
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ["Test", 1, "test", "1"]
    assert lenient_lowercase(test_list) == ["test", 1, "test", "1"]

# Generated at 2022-06-11 01:46:56.155683
# Unit test for function human_to_bytes
def test_human_to_bytes():
    def human_to_bytes_test_helper(x, x_unit, y):
        actual = human_to_bytes(x, x_unit, isbits=False)
        actual_bits = human_to_bytes(x, x_unit, isbits=True)
        expected = y[0]
        expected_bits = y[1]
        message = 'Expecting %d, but got %d for "%s"' % (expected, actual, x)
        message_bits = message + ' when bits is True'
        assert actual == expected, message
        assert actual_bits == expected_bits, message_bits

    human_to_bytes_test_helper('1M', None, (1048576, 1048576 * 8))

# Generated at 2022-06-11 01:47:06.518754
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1Gb', isbits=True) == 1073741824
    assert human_to_bytes('1Mb') == 1
    assert human_to_bytes('1MB', isbits=True) == 1
    assert human_to_bytes('7.5k') == 7680
    assert human_to_bytes('.75k') == 768
    assert human_to_bytes('.75K') == 768
    assert human_to_bytes('.75g') == 805306368
    assert human_to_bytes('.75G') == 805306368
    assert human_to_

# Generated at 2022-06-11 01:47:17.227277
# Unit test for function human_to_bytes
def test_human_to_bytes():
    def test_number_bytes(number, unit, expected):
        actual = human_to_bytes(number, unit)
        assert actual == expected, "'%s' is not equal to '%s'" % (actual, expected)

    # test some simple values
    test_number_bytes('1', 'B', 1)
    test_number_bytes('2.3', 'B', 2)
    test_number_bytes('3', 'bytes', 3)
    test_number_bytes('3b', 'bytes', 3)
    test_number_bytes('3B', 'bytes', 3)
    test_number_bytes('4B', 'bytes', 4)
    test_number_bytes('4b', 'b', 4)
    test_number_bytes('4b', 'bits', 4)

# Generated at 2022-06-11 01:47:24.541833
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    assert lenient_lowercase(['abc', 'ABC', 'AbC']) == ['abc', 'abc', 'abc'], "lenient_lowercase(['abc', 'ABC', 'AbC']) failed to return ['abc', 'abc', 'abc']"
    assert lenient_lowercase(['abc', 123, 'AbC', True]) == ['abc', 123, 'abc', True], "lenient_lowercase(['abc', 123, 'AbC', True]) failed to return ['abc', 123, 'abc', True]"



# Generated at 2022-06-11 01:47:35.132221
# Unit test for function human_to_bytes
def test_human_to_bytes():

    testfunc = human_to_bytes

    # check proper string conversion
    assert testfunc('-1') == -1
    assert testfunc('0') == 0
    assert testfunc('1') == 1
    assert testfunc('1K') == 1024
    assert testfunc('1 K') == 1024
    assert testfunc('1M') == 1024 * 1024
    assert testfunc('1G') == 1024 * 1024 * 1024
    assert testfunc('1T') == 1024 * 1024 * 1024 * 1024
    assert testfunc('1P') == 1024 * 1024 * 1024 * 1024 * 1024
    assert testfunc('1E') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert testfunc('1Z') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert testfunc('1Y') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-11 01:47:47.042683
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == (1 << 20)
    assert human_to_bytes('1Mb', isbits=True) == (1 << 20)
    assert human_to_bytes(10, 'M') == (1 << 20)
    assert human_to_bytes(10, 'm') == (1 << 20)
    assert human_to_bytes(10.1, 'm') == (1 << 20)
    assert human_to_bytes(16.7, 'M') == (1 << 20)
    assert human_to_bytes('16.7', 'M') == (1 << 20)
    assert human_to_bytes('16.7K') == (1 << 17)
    assert human_to_bytes('1M') == (1 << 20)
    assert human_to_bytes('1.1M')

# Generated at 2022-06-11 01:47:58.665432
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['123', '456', '789']) == ['123', '456', '789']
    assert lenient_lowercase(['A', 123, 'C']) == ['a', 123, 'c']


# Generated at 2022-06-11 01:48:01.969577
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Ansible', 'is', 2, 'awesome']) == ['ansible', 'is', 2, 'awesome']



# Generated at 2022-06-11 01:48:06.737554
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', (1, 2, 3), [1, 2, 3], 'c']) == ['a', 'B', (1, 2, 3), [1, 2, 3], 'c']


# Unit tests for function human_to_bytes

# Generated at 2022-06-11 01:48:10.635997
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['abc', 'def'] == lenient_lowercase(['ABC', 'def'])
    assert [1, 2] == lenient_lowercase([1, 2])
    assert ['1', '2'] == lenient_lowercase(['1', '2'])


# Generated at 2022-06-11 01:48:20.052959
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("\nTesting function human_to_bytes")


# Generated at 2022-06-11 01:48:22.104000
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'B', 3, 'd']) == [1, 'b', 3, 'd']


# Generated at 2022-06-11 01:48:26.911271
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["A", "b", 81, 2.0]) == ["a", "b", 81, 2.0]
    assert lenient_lowercase(["A", 81, 2.0]) == ["a", 81, 2.0]
    assert lenient_lowercase(["A", "B"]) == ["a", "b"]

# Generated at 2022-06-11 01:48:37.937515
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' This function verifies that human_to_bytes() returns expected value '''
    # Examples from man page
    if human_to_bytes('2B') != 2:
        return 1
    if human_to_bytes('3b') != 0:
        return 1
    if human_to_bytes('4K') != 4096:
        return 2
    if human_to_bytes('5Kb') != 0:
        return 2
    if human_to_bytes('6M') != 6291456:
        return 3
    if human_to_bytes('7Mb') != 0:
        return 3
    if human_to_bytes('8G') != 8589934592:
        return 4
    if human_to_bytes('9Gb') != 0:
        return 4

# Generated at 2022-06-11 01:48:47.659846
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:48:56.188286
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Check that if the parameter is a string,
    # it returns the lowercase version of that string.
    assert 'a' == lenient_lowercase(['a'])[0]
    # Check that if the parameter is a list,
    # it returns the lowercase version of that list.
    assert ['a'==lenient_lowercase[['a']]]
    # Check that if the parameter is not a string,
    # it returns the same object with no conversion.
    assert 0 == lenient_lowercase([0])[0]


# Generated at 2022-06-11 01:49:07.778584
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('0M') == 0
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2Kb') == 2048
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('3.14Mb') == 3276800
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('2MBb') == 2097152
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('-4K') == -4096
    assert human_to_bytes('5MBb', isbits=True) == 5242880
    assert human_to_bytes('6.21MBb', isbits=True) == 6456576
    assert human_to_

# Generated at 2022-06-11 01:49:11.646424
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    data = ["Alpha", "BETA", "gamma", 1, 1.1]
    data_lower = ["alpha", "beta", "gamma", 1, 1.1]

    data_result = lenient_lowercase(data)

    assert data_result == data_lower, "Failed to convert list of mixed case strings to lowercase"


# Generated at 2022-06-11 01:49:22.109733
# Unit test for function human_to_bytes
def test_human_to_bytes():
    t = human_to_bytes('10M')
    assert t == 10485760
    t = human_to_bytes('1024K')
    assert t == 1048576
    t = human_to_bytes('1G')
    assert t == 1073741824
    t = human_to_bytes('2.5G', unit = 'B')
    assert t == 2684354560
    t = human_to_bytes(5)
    assert t == 5
    t = human_to_bytes(5, 'K', isbits = True)
    assert t == 5120
    t = human_to_bytes(1, 'Mb', isbits = True)
    assert t == 1048576
    t = human_to_bytes(1, 'KB', isbits = True)
    assert t == 1048576


# Generated at 2022-06-11 01:49:34.027103
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes('10MB') == human_to_bytes(10, 'MB')
    assert human_to_bytes('10MB', True) == human_to_bytes(10, 'MB', True)
    assert human_to_bytes('10Mb') == human_to_bytes(10, 'Mb')
    assert human_to_bytes('10Mb', True) == human_to_bytes(10, 'Mb', True)
    assert human_to_bytes('10M') == human_to_bytes(10, 'M', True)
    assert human_to_bytes('10MB') == human_to_bytes(10, 'MB', True)
    assert human_to_bytes('10Mb') == human_

# Generated at 2022-06-11 01:49:45.543081
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:49:52.149394
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Positive tests:
    assert(human_to_bytes('1B') == 1)
    assert(human_to_bytes('10b') == 10)
    assert(human_to_bytes('10KB') == 10240)
    assert(human_to_bytes('10Kb') == 12800)
    assert(human_to_bytes('10MB') == 10485760)
    assert(human_to_bytes('10Mb') == 10485760)
    assert(human_to_bytes('10GB', isbits=True) == 9.313225746154785e+10)
    assert(human_to_bytes('10Gb', isbits=True) == 116415322061)
    assert(human_to_bytes('2Tb', isbits=True) == 2199023255552)

# Generated at 2022-06-11 01:50:04.669325
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('100') == 100)
    assert(human_to_bytes('100B') == 100)
    assert(human_to_bytes('100KB') == 102400)
    assert(human_to_bytes('100.5KB') == 102400.5)
    assert(human_to_bytes('.5KB') == 512.0)
    assert(human_to_bytes('1.5KB') == 1536.0)
    assert(human_to_bytes('1.5Kb') == 1536.0)
    assert(human_to_bytes('1.5Kb', isbits=True) == 1536.0)
    assert(human_to_bytes('1.5MB') == 1572864.0)