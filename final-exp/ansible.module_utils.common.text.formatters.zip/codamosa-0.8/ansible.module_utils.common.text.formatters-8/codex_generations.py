

# Generated at 2022-06-11 01:40:21.916256
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # default unit test
    assert human_to_bytes(100, 'b') == 100
    # bytes unit test
    assert human_to_bytes(10, 'B') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10B ') == 10
    assert human_to_bytes(' 10B ') == 10
    assert human_to_bytes(' 10 B ') == 10
    assert human_to_bytes(' 10 B') == 10
    assert human_to_bytes('10 B') == 10
    assert human_to_bytes('1kB') == 1000
    assert human_to_bytes('1 MB') == 1000000
    assert human_to_bytes('1Gb') == 1000000000
    assert human_to_bytes('1Tb') == 1000000000000
    assert human_to_bytes

# Generated at 2022-06-11 01:40:29.054264
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Abc', 'Xyz', 12, 'Mno']) == ['abc', 'xyz', 12, 'mno']
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['UPPERCASE', 'MiXeD']) == ['uppercase', 'mixed']
    assert lenient_lowercase(['UPPERCASE', None]) == ['uppercase', None]

bytes_to_human(1, unit='B')
bytes_to_human(1, unit='K')
bytes_to_human(1, unit='M')
bytes_to_human(1, unit='G')
bytes_to_human(1, unit='T')
bytes_to_human(1, unit='E')
bytes_to_human(1, unit='P')


# Generated at 2022-06-11 01:40:38.032770
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    teststr = ['foo', 'bar', 'Baz', 'qux']
    teststr_expected = ['foo', 'bar', 'baz', 'qux']
    actual = lenient_lowercase(teststr)
    assert actual == teststr_expected

    teststr = ['foo', 1, 'Baz', 'qux']
    teststr_expected = ['foo', 1, 'baz', 'qux']
    actual = lenient_lowercase(teststr)
    assert actual == teststr_expected

    teststr = ['foo', 1, ['Baz', 'bar'], 'qux']
    teststr_expected = ['foo', 1, ['Baz', 'bar'], 'qux']
    actual = lenient_lowercase(teststr)
    assert actual == teststr_expected

# Unit tests for function human_to

# Generated at 2022-06-11 01:40:49.777071
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test with default unit, B which is converted to Bytes
    assert human_to_bytes("1") == 1
    assert human_to_bytes("1B") == 1
    assert human_to_bytes("Bytes") == 1
    assert human_to_bytes("BYTES") == 1

    # Test with unit Z
    assert human_to_bytes("1Z") == (1 << 70)
    assert human_to_bytes("1z") == (1 << 70)

    # Test with float
    assert human_to_bytes("1.5G") == (1.5 * (1 << 30))

    # Test with unit k
    assert human_to_bytes("1k") == 1024
    assert human_to_bytes("1K") == 1024
    # Test with unit K

# Generated at 2022-06-11 01:40:56.986760
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest

    # test with default values
    assert human_to_bytes('100') == 100
    assert human_to_bytes(100) == 100
    assert human_to_bytes('100') == human_to_bytes(100)

    # test with bytes idenitfiers
    assert human_to_bytes('100B') == 100
    assert human_to_bytes('100b') == 100
    assert human_to_bytes('100 byte') == 100
    assert human_to_bytes('100 bytes') == 100
    assert human_to_bytes('100 Byte') == 100
    assert human_to_bytes('100 Bytes') == 100
    assert human_to_bytes('100 ByteS') == 100
    assert human_to_bytes('100000000 Bytes') == 100000000

    # test with kilobytes idenitfiers


# Generated at 2022-06-11 01:41:09.050081
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:41:13.487819
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 'a', 'B']) == [1, 'a', 'B']
    assert lenient_lowercase([]) == []

# Generated at 2022-06-11 01:41:15.883336
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    l = ['a', 2, 'b', 'c']
    assert ['a', 2, 'b', 'c'] == lenient_lowercase(l)



# Generated at 2022-06-11 01:41:17.612438
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 3]) == ['a', 'b', 3]
    assert lenient_lowercase(['a', 'B', 'C']) == ['a', 'b', 'c']

# Generated at 2022-06-11 01:41:30.661416
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1', 'B') == 1)
    assert(human_to_bytes('1', 'K') == 1024)
    assert(human_to_bytes('1b') == 1)
    assert(human_to_bytes('1B') == 1)
    assert(human_to_bytes('1K') == 1024)
    assert(human_to_bytes('1KB') == 1024)
    assert(human_to_bytes('1M') == 1024 * 1024)
    assert(human_to_bytes('1MB') == 1024 * 1024)
    assert(human_to_bytes('1G') == 1024 * 1024 * 1024)
    assert(human_to_bytes('1GB') == 1024 * 1024 * 1024)
    assert(human_to_bytes('1T') == 1024 * 1024 * 1024 * 1024)
   

# Generated at 2022-06-11 01:41:43.524422
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:41:55.456364
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576, "Failed to convert 1M to bytes"
    assert human_to_bytes('1Mb') == 1048576, "Failed to convert 1Mb to bytes"
    assert human_to_bytes('1MB', isbits=False) == 1048576, "Failed to convert 1MB to bytes"
    assert human_to_bytes('1MB', isbits=True) == 8388608, "Failed to convert 1MB to bytes"
    assert human_to_bytes('1MB', isbits=True, default_unit='Mb') == 8388608, "Failed to convert 1MB to bytes"
    assert human_to_bytes('1Mb', isbits=False, default_unit='MB') == 1048576, "Failed to convert 1Mb to bytes"


# Generated at 2022-06-11 01:42:06.272238
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.2') == 1
    assert human_to_bytes('1K') == 1 << 10
    assert human_to_bytes('1M') == 1 << 20
    assert human_to_bytes('1G') == 1 << 30
    assert human_to_bytes('1T') == 1 << 40
    assert human_to_bytes('1P') == 1 << 50
    assert human_to_bytes('1E') == 1 << 60
    assert human_to_bytes('1Z') == 1 << 70
    assert human_to_bytes('1Y') == 1 << 80
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.2B') == 1
    assert human_to_bytes('1b') == 1

# Generated at 2022-06-11 01:42:12.666303
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == "10 Bytes"
    assert bytes_to_human(10, isbits=True) == "10 bits"
    assert bytes_to_human(10, unit='b') == "10 bits"
    assert bytes_to_human(10, unit='B') == "10 Bytes"
    assert bytes_to_human(10, unit='b') == "10 bits"
    assert bytes_to_human(10, unit='B') == "10 Bytes"
    assert bytes_to_human(1) == "1 Byte"
    assert bytes_to_human(11) == "11 Bytes"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(2048, isbits=True) == "1.00 Kb"
    assert bytes

# Generated at 2022-06-11 01:42:21.578089
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', isbits=True) == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10MB', isbits=True) == 10485760
    assert human_to_bytes('10m') == 10485760
    assert human_to_bytes('10m', isbits=True) == 10485760
    assert human_to_bytes('10Mb') == 134217728
    assert human_to_bytes('10Mb', isbits=True) == 134217728
    assert human_to_bytes('10mb') == 134217728
    assert human_to_bytes('10mb', isbits=True) == 134217728

# Generated at 2022-06-11 01:42:24.956468
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['One', 2, 3, 'Four']) == ['one', 2, 3, 'four']


# Unit tests for function human_to_bytes

# Generated at 2022-06-11 01:42:30.927093
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['A', 'B', 'C']
    assert lenient_lowercase(['A', 'b', 'C']) == ['A', 'b', 'C']
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-11 01:42:42.015923
# Unit test for function human_to_bytes
def test_human_to_bytes():
    testing_data = {
        '1K': 1024,
        '1KB': 1024,
        '1M': 1048576,
        '2.5M': 2621440,
        '2.5MB': 2621440,
        '1E': 1125899906842624,
        '1EiB': 1152921504606846976,
        '8EiB': 9223372036854775808,
        '2.5EiB': 268435456000000000,
        '1ZiB': 115292150460684697600,
        '-2K': -2048,
        '1Eib': ValueError,
        '1.1.1E': ValueError,
        '1Ei': ValueError,
        'str': ValueError
    }

# Generated at 2022-06-11 01:42:53.694702
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:43:05.188788
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test normal usage
    assert human_to_bytes('10MB') == 10485760
    # test string number and space before/after it
    assert human_to_bytes(' 123 ') == 123
    # test not valid input
    try:
        human_to_bytes('abc')
    except ValueError as e:
        assert str(e) == "human_to_bytes() can't interpret following string: abc"
    # test not valid number
    try:
        human_to_bytes('123abc')
    except ValueError as e:
        assert str(e) == "human_to_bytes() can't interpret following number: 123abc (original input string: 123abc)"
    # test wrong unit
    try:
        human_to_bytes('123 abc')
    except ValueError as e:
        assert str(e)

# Generated at 2022-06-11 01:43:14.706226
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['one', 'two', 'THREE', 1, 2, 3]
    lowered_lst = lenient_lowercase(lst)
    assert lowered_lst == ['one', 'two', 'three', 1, 2, 3]



# Generated at 2022-06-11 01:43:23.968285
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:43:35.084702
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import assert_equals

    # bytes:
    assert_equals(human_to_bytes('1B'), 1)
    assert_equals(human_to_bytes('2b'), 2)
    assert_equals(human_to_bytes('2'), 2)
    assert_equals(human_to_bytes('2B'), 2)
    assert_equals(human_to_bytes('2b'), 2)
    assert_equals(human_to_bytes('2.0B'), 2)
    assert_equals(human_to_bytes('2.0b'), 2)
    assert_equals(human_to_bytes('2.0'), 2)
    assert_equals(human_to_bytes('2.0B', isbits=True), 2)

# Generated at 2022-06-11 01:43:46.993841
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('Testing human_to_bytes() function:')
    # bytes
    print('\tinput: "10B" => output: %s (type: %s)' % (human_to_bytes('10B'), type(human_to_bytes('10B'))))
    print('\tinput: "10B" => output: %s (type: %s)' % (human_to_bytes('10b'), type(human_to_bytes('10b'))))
    print('\tinput: "10byte" => output: %s (type: %s)' % (human_to_bytes('10byte'), type(human_to_bytes('10byte'))))

# Generated at 2022-06-11 01:43:55.046524
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # test string type
    assert lenient_lowercase(['string_type', 'STRING_TYPE']) == ['string_type', 'string_type']
    # test multiple type
    assert lenient_lowercase(['string_type', 'STRING_TYPE', 4]) == ['string_type', 'string_type', 4]
    # test list type
    assert lenient_lowercase([['string_type', 'STRING_TYPE'], 4]) == [['string_type', 'string_type'], 4]



# Generated at 2022-06-11 01:44:02.325947
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test bytes range
    assert human_to_bytes('5G') == 5368709120
    assert human_to_bytes('5Z') == 524288000000000000
    assert human_to_bytes('5E') == 52428800000000000
    assert human_to_bytes('5P') == 5242880000000000
    assert human_to_bytes('5T') == 52428800000000
    assert human_to_bytes('5M') == 52428800
    assert human_to_bytes('5K') == 5120
    assert human_to_bytes('5B') == 5

    # Test bits range
    assert human_to_bytes('5Gb', isbits=True) == 5368709120
    assert human_to_bytes('5Zb', isbits=True) == 524288000000000000
    assert human_to_bytes

# Generated at 2022-06-11 01:44:10.211313
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B', default_unit='B') == 1
    assert human_to_bytes('20', default_unit='B') == 20
    assert human_to_bytes('20', default_unit='b') == 20
    assert human_to_bytes('20B') == 20
    assert human_to_bytes('20b') == 20
    assert human_to_bytes('20K') == 20480
    assert human_to_bytes('20M') == 20971520
    assert human_to_bytes('20G') == 21474836480
    assert human_to_bytes('20T') == 21990232555520
    assert human_to_bytes('20P') == 2251799813685240
    assert human_to_bytes('20E') == 2305843009213693952
    assert human

# Generated at 2022-06-11 01:44:13.080980
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['one', 'TWO', 3]) == ['one', 'two', 3]


# Generated at 2022-06-11 01:44:17.709351
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['FOO', 1, 'bar']) == ['foo', 1, 'bar']
    assert lenient_lowercase(['FOO', 'BAR']) == ['foo', 'bar']
    assert lenient_lowercase([1, 2]) == [1, 2]



# Generated at 2022-06-11 01:44:27.757164
# Unit test for function bytes_to_human
def test_bytes_to_human():
    #Assertions
    assert bytes_to_human(1048576) == '1.00 MBytes'
    assert bytes_to_human(1024) == '1.00 KBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '8.00 EBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024, unit='P') == '8.00 PBytes'
    assert bytes_to_human(1024 * 1024 * 1024, unit='M') == '1.00 MBytes'

    assert bytes_to_human(1048576, isbits=True) == '8.00 Mbits'
    assert bytes_to_human(1024, isbits=True) == '8.00 Kbits'

# Generated at 2022-06-11 01:44:47.049265
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(1, 'MB') == 1048576
    assert human_to_bytes(1, 'Mb', True) == 1048576
    assert human_to_bytes('1Mb', True) == 1048576
    assert human_to_bytes(1, 'MB', True) == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1.1M') == 1048576
    assert human_to_bytes(23, 'B') == 23
    assert human_to_bytes('23B') == 23
    assert human_to_bytes(1, 'Kb') == 1000
    assert human_

# Generated at 2022-06-11 01:44:56.177984
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest
    # Sample test data
    # test format: <human_string> : <expect_result>

# Generated at 2022-06-11 01:45:07.422098
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    from ansible.module_utils._text import to_native
    assert to_native(lenient_lowercase('ABC')) == 'abc', 'The function lenient_lowercase() failed on lowercase string'
    assert to_native(lenient_lowercase(['ABC', 'DEF', 1, 2])) == ['abc', 'def', 1, 2], "The function lenient_lowercase() failed on list of str and int"
    assert to_native(lenient_lowercase({'ABC', 'DEF'})) == {'abc', 'def'}, "The function lenient_lowercase() failed on set of str"

# Generated at 2022-06-11 01:45:18.302978
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    cases = [
        {'input': ['a', 'b', 'c'], 'expected': ['a', 'b', 'c']},
        {'input': ['a', 'b', None, 'c'], 'expected': ['a', 'b', None, 'c']},
        {'input': ['a', 'b', 1, 'c'], 'expected': ['a', 'b', 1, 'c']},
        {'input': ['a', 'b', 1.0, 'c'], 'expected': ['a', 'b', 1.0, 'c']},
        {'input': ['a', 'B', 'c'], 'expected': ['a', 'b', 'c']},
    ]

    for case in cases:
        result = lenient_lowercase(case['input'])
        assert result == case['expected']

# Generated at 2022-06-11 01:45:30.760025
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:45:39.270088
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [1, 'a', 'B', 'c', 'D', 3, 'E', 'F', '\t', '\n', None, True, False, {'a': 1}, [1, 2, 3]]
    result_list = [1, 'a', 'B', 'c', 'D', 3, 'E', 'F', '\t', '\n', None, True, False, {'a': 1}, [1, 2, 3]]
    assert lenient_lowercase(test_list) == result_list

# Generated at 2022-06-11 01:45:44.543436
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:45:53.919329
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Check for input with unit and without unit
    assert(human_to_bytes('3K') == 3072)
    assert(human_to_bytes('3K', 'B') == 3072)
    assert(human_to_bytes('3K', 'k') == 3072)
    assert(human_to_bytes('3K', 'b') == 3072 * 8)

    assert(human_to_bytes('3K', 'k', isbits=True) == 3072 * 8)

    # Check for input with unit and wrong unit
    try:
        human_to_bytes('3K', 'M')
    except ValueError:
        pass
    else:
        assert(1 == 0)

    # Check for input with unit and wrong unit

# Generated at 2022-06-11 01:45:57.949618
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(["hello", "ANSIBLE", "WORld", "yo", "1234"])
    assert result == ['hello', 'ansible', 'world', 'yo', '1234'], "lenient_lowercase is not working properly"


# Generated at 2022-06-11 01:46:01.954127
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    inlist = ['aA', 'BB']
    outlist = ['aa', 'bb']
    assert (lenient_lowercase(inlist) == outlist)


# Generated at 2022-06-11 01:46:17.859281
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:46:22.989786
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10MB', unit='kb') == 1048576
    assert human_to_bytes('10kb', unit='mb') == 0.01
    assert human_to_bytes('10M', unit='kb') == 10240


# Generated at 2022-06-11 01:46:26.227403
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 1, 2, 'C']) == ['a', 'b', 1, 2, 'c']
    assert lenient_lowercase(['A', 'B']) == ['a', 'b']

# Generated at 2022-06-11 01:46:32.370918
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    def validate(lst, lowered):
        for item, item_lowered in zip(lst, lowered):
            try:
                assert item.lower() == item_lowered
            except AssertionError:
                assert item == item_lowered

    lst = [
        '1',
        {'a': 1},
        '2',
        3
    ]

    lowered = lenient_lowercase(lst)

    validate(lst, lowered)

# Generated at 2022-06-11 01:46:42.059972
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10MBytes') == 10485760
    assert human_to_bytes('10Mbyte') == 10485760
    assert human_to_bytes('10Mbyte', isbits=True) == 0
    assert human_to_bytes('10Mbit') == 10485760
    assert human_to_bytes(10, 'Mb') == 0
    assert human_to_bytes('10Mb') == 0
    assert human_to_bytes('10Mbits') == 0
    assert human_to_bytes('10Mbit', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10

# Generated at 2022-06-11 01:46:54.189071
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1) == 1
    assert human_to_bytes('1') == 1  # Bytes (base)
    assert human_to_bytes('1') == 1  # Bytes (base)

    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.1B') == 1

    assert human_to_bytes('1K', default_unit='B') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1K', 'B') == 1024

    assert human_to_bytes('1M', default_unit='b') == 1048

# Generated at 2022-06-11 01:47:05.137834
# Unit test for function human_to_bytes
def test_human_to_bytes():
    tests = [
        ('1K', 1024),
        ('1M', 1048576),
        ('1G', 1073741824),
        ('1KiB', 1024),
        ('1MiB', 1048576),
        ('1GiB', 1073741824),
        ('1MB', 1048576),
        ('1GB', 1073741824),
        ('2MB', 2097152),
        ('2GB', 2147483648),
        ('1B', 1),
        ('10b', 1),
        ('1k', 1024),
        ('1m', 1048576),
         # this one is a bit tricky
        ('1Mb', 1048576),
        (1, 1),
    ]

    for param, result in tests:
        assert human_to_bytes(param) == result
        assert human

# Generated at 2022-06-11 01:47:12.095133
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test = ['FOO', 'Bar', '1Baz', u'Bà®', 0, False]
    wanted = ['foo', 'bar', '1baz', u'Bà®', 0, False]
    result = lenient_lowercase(test)
    if wanted != result:
        raise AssertionError("lenient_lowercase({}) != {} (wanted), got {}".format(test, wanted, result))


# Generated at 2022-06-11 01:47:19.697504
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:47:28.352798
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10m') == None
    assert human_to_bytes('10m', default_unit='B') == 10485760
    assert human_to_bytes('10b') == None
    assert human_to_bytes('10b', isbits=False) == 10485760
    assert human_to_bytes('10b', default_unit='B') == 10485760
    assert human_to_bytes('10b', isbits=True) == 10
    assert human_to_bytes('10', isbits=True) == 10
    assert human_to_bytes('10', isbits=False) == 10
    assert human_to_bytes('') == None
   

# Generated at 2022-06-11 01:47:48.194471
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:47:56.057722
# Unit test for function human_to_bytes
def test_human_to_bytes():
    human_cases = (
        ('1M', 1048576),
        ('1k', 1024),
        ('1B', 1),
        ('1b', None, True),
        ('1B', None, True),
        ('1k', None, True),
        ('1M', None, True),
    )
    for c, v, b in human_cases:
        if v is None:
            assert human_to_bytes(c, isbits=b) == human_to_bytes(c, unit='B', isbits=b)
        else:
            assert human_to_bytes(c) == v
            assert human_to_bytes(c, isbits=b) == v
            assert human_to_bytes(c, unit='B', isbits=b) == v



# Generated at 2022-06-11 01:48:08.291164
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Test for converting various strings to a number of bytes.
    '''
    # Test for converting to bytes
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1', 'M') == 1048576
    assert human_to_bytes(1, 'M') == 1048576
    # Test for converting to bits
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1', 'MB', isbits=True) == 8388608
    assert human_to_bytes(1, 'MB', isbits=True) == 8388608
    # Negative test

# Generated at 2022-06-11 01:48:10.165809
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B']) == ['a', 'b']
    assert lenient_lowercase([1, 2]) == [1, 2]
    assert lenient_lowercase(['A', 2]) == ['a', 2]
    assert lenient_lowercase([1, 'B']) == [1, 'B']


# Generated at 2022-06-11 01:48:17.824010
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    class Foo(object):
        def __init__(self, name):
            self.name = name

        def __repr__(self):
            return '<Foo:%s>' % self.name

    input = [Foo('A'), 'B', Foo('C'), 'D', Foo('E')]
    output = lenient_lowercase(input)
    assert output[0] == input[0]
    assert output[1] == 'b'
    assert output[2] == input[2]
    assert output[3] == 'd'
    assert output[4] == input[4]


# Generated at 2022-06-11 01:48:27.263976
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1.5

    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b', isbits=True) == 1

    assert human_to_bytes('1KB') == 1000
    assert human_to_bytes('1Kb', isbits=True) == 1000
    assert human_to_bytes('1MB') == 1000000
    assert human_to_bytes('1Mb', isbits=True) == 1000000
    assert human_to_bytes('1GB') == 1000000000
    assert human_to_bytes('1Gb', isbits=True) == 1000000000
    assert human_to_bytes('1TB') == 1000000000000

# Generated at 2022-06-11 01:48:38.284620
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:48:44.239807
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_obj = ['A', 1, 'B', "STRING", 'C']
    res = lenient_lowercase(test_obj)
    assert res == ['a', 1, 'b', "STRING", 'c']
    assert res == lenient_lowercase(res)
    assert res == lenient_lowercase(lenient_lowercase(res))



# Generated at 2022-06-11 01:48:46.315802
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    l = lenient_lowercase(['upper', 'lower', None, 1])
    assert (l == ['upper', 'lower', None, 1])

# Generated at 2022-06-11 01:48:58.790058
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest

    def assert_human_to_bytes(input_string, expected_value=None, expected_exception=None):
        if expected_exception is not None:
            with pytest.raises(expected_exception):
                human_to_bytes(input_string)
        else:
            assert(human_to_bytes(input_string) == expected_value)

    assert_human_to_bytes('', 0)
    assert_human_to_bytes(0, 0)
    assert_human_to_bytes('10', 10)
    assert_human_to_bytes('10M', 10 * 2 ** 20)
    assert_human_to_bytes('10MB', 10 * 2 ** 20)
    assert_human_to_bytes('1.5MB', 1.5 * 2 ** 20)
    assert_human

# Generated at 2022-06-11 01:49:23.499078
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    human_to_bytes() returns an int, that is compared with expected result
    (also an int). Will raise AssertionError if test fails.
    '''
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('2MB') == 2097152
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2KB') == 2048
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('31B') == 31

# Generated at 2022-06-11 01:49:28.410052
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_list = ['hEllO', 'World', '!', 1, 2, 3]
    output_list = ['hello', 'world', '!', 1, 2, 3]

    assert lenient_lowercase(input_list) == output_list



# Generated at 2022-06-11 01:49:37.979472
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' testing bytes and bits scenarios '''
    # bytes test scenarios
    assert human_to_bytes(10, 'bytes') == human_to_bytes('10', 'bytes')
    assert human_to_bytes(10, 'bytes') == human_to_bytes('10b', 'bytes')
    assert human_to_bytes(10, 'bytes') == human_to_bytes('10B', 'bytes')
    assert human_to_bytes(10, 'bytes') == human_to_bytes('10', 'bytes')
    assert human_to_bytes(10, 'bytes') == human_to_bytes('10B', 'bytes')

    # bits test scenarios
    assert human_to_bytes(10, 'bits', isbits=True) == human_to_bytes('10', 'bits', isbits=True)
    assert human_to_bytes

# Generated at 2022-06-11 01:49:47.922032
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([u'Абырвалг']) == ['абырвалг']
    assert lenient_lowercase(['Абырвалг', 1]) == ['абырвалг', 1]
    assert lenient_lowercase(['Абырвалг', '1']) == ['абырвалг', '1']
    assert lenient_lowercase(['Абырвалг', u'1']) == ['абырвалг', '1']

# Generated at 2022-06-11 01:49:51.930340
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['1', '2', '3'] == lenient_lowercase([1, '2', '3'])
    assert ['a', 'b', 'c'] == lenient_lowercase(['A', 'b', 'C'])



# Generated at 2022-06-11 01:50:04.532277
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:50:14.408304
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M', 'B') == 10485760.0
    assert human_to_bytes(10485760, 'B') == 10485760.0
    assert human_to_bytes('10M', 'bit') == 10485760.0 * 8
    assert human_to_bytes(10485760, 'bit') == 10485760.0 * 8

    # with default unit set to bytes
    assert human_to_bytes('10M') == 10485760.0
    assert human_to_bytes('10K', isbits=False) == 10240
    assert human_to_bytes('10K', isbits=True) == 81920

    # with default unit set to bits
    assert human_to_bytes('10M', isbits=True) == 10485760.0 * 8
