

# Generated at 2022-06-11 01:40:18.038134
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # pass some valid/invalid arguments to human_to_bytes function
    # and make sure function behaves as expected
    assert human_to_bytes('10Mb') == 104857600
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('-1MB') == -1048576
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('1MB', isbits=True) == 8388608
    assert human_to_bytes('-1MB', isbits=True) == -8388608
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('-1Mb', isbits=True) == -1048576
    assert human_to_bytes

# Generated at 2022-06-11 01:40:26.882042
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("10M") == (10 * 1024 * 1024)
    assert human_to_bytes("10MB") == (10 * 1024 * 1024)
    assert human_to_bytes("10Mb", isbits=True) == (10 * 1024 * 1024)
    assert human_to_bytes("10Mb") == (10 * 1024 * 1024)
    assert human_to_bytes("10Mb", default_unit=None, isbits=False) == (10 * 1024 * 1024)
    assert human_to_bytes("10Mb", isbits=False) == (10 * 1024 * 1024)
    assert human_to_bytes("10", default_unit="Mb", isbits=True) == (10 * 1024 * 1024)

# Generated at 2022-06-11 01:40:36.284800
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1000) == "1000 Bytes"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1048576) == "1.00 MB"
    assert bytes_to_human(1073741824) == "1.00 GB"
    assert bytes_to_human(1099511627776) == "1.00 TB"
    assert bytes_to_human(1125899906842624) == "1.00 PB"
    assert bytes_to_human(1152921504606846976) == "1.00 EB"
    assert bytes_to_human(1180591620717411303424) == "1.00 ZB"

# Generated at 2022-06-11 01:40:47.602268
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1byte') == 1
    assert human_to_bytes('1bytes') == 1
    assert human_to_bytes('1Byte') == 1
    assert human_to_bytes('1Bytes') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1Kbyte') == 1024
    assert human_to_bytes('1Kbytes') == 1024
    assert human_to_bytes('1KByte') == 1024
    assert human_to_bytes('1KBytes') == 1024
    assert human_to_bytes('1M') == 1024 ** 2
    assert human_to

# Generated at 2022-06-11 01:40:55.830157
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert (human_to_bytes('10B') == 10)
    assert (human_to_bytes('10B', isbits=True) == 10)
    assert (human_to_bytes('10b', isbits=True) == 10)
    assert (human_to_bytes(10) == 10)
    assert (human_to_bytes('10') == 10)
    assert (human_to_bytes('10.0') == 10)
    assert (human_to_bytes('10.4') == 10)
    assert (human_to_bytes('10.5') == 11)
    assert (human_to_bytes('1K') == 1 << 10)
    assert (human_to_bytes('1K', isbits=True) == 1 << 10)

# Generated at 2022-06-11 01:41:01.002573
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['ABC', 123, 'XYZ', 456]) == ['abc', 123, 'xyz', 456]
    assert lenient_lowercase(['ABC']) == ['abc']
    assert lenient_lowercase([123]) == [123]


# Generated at 2022-06-11 01:41:12.737376
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2K') == human_to_bytes(2, 'K')
    assert human_to_bytes('1000') == 1000
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1.1MB') == 1153433
    assert human_to_bytes('1Mb', True) == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes(1000, 'Mb', True) == 1250000000
    assert human_to_bytes(1000, 'Mb', isbits=True) == 1250000000


# Generated at 2022-06-11 01:41:20.593276
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:41:32.805955
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K', default_unit='b') == 2048
    assert human_to_bytes('2KiB') == 2048
    assert human_to_bytes('2.5KiB') == 2560
    assert human_to_bytes('2.0KiB') == 2048
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2.5K') == 2560
    assert human_to_bytes('2.0K') == 2048
    assert human_to_bytes('2kB') == 2048
    assert human_to_bytes('2.5kB') == 2560
    assert human_to_bytes('2.0kB') == 2048
    assert human_to_bytes('2Kb') == 2048
    assert human_to_bytes('2.5Kb') == 2560

# Generated at 2022-06-11 01:41:42.938071
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10.1') == 10
    assert human_to_bytes('bad input') == ValueError
    assert human_to_bytes('10.1KB') == 10240
    assert human_to_bytes('10.1MB') == 10485760
    assert human_to_bytes('10.1GB') == 10737418240
    assert human_to_bytes('10.1TB') == 10995116277760
    assert human_to_bytes('10.1PB') == 11258999068426240
    assert human_to_bytes('10.1EB') == 11529215046068469760
    assert human_to_bytes('10.1ZB') == 1180591620717411303424

# Generated at 2022-06-11 01:41:48.932547
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    d = ['Zero', 0, 'One', 1]
    result = lenient_lowercase(d)
    assert result == ['zero', 0, 'one', 1]



# Generated at 2022-06-11 01:41:58.590069
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' test function human_to_bytes '''
    tests = [
        ('2K', 2048),
        ('et', 0),
        ('5.5M', 5767168),
        ('5.5MB', 5767168),
        ('5.5E', 5.5),
        ('1.5MB', 1572864),
        ('1MB', 1048576),
        ('1b', 1),
        ('1Mb', 1048576)
    ]
    for test_input, test_output in tests:
        test_result = human_to_bytes(test_input)
        assert test_result == test_output



# Generated at 2022-06-11 01:42:08.365169
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10kb') == 10240
    assert human_to_bytes('10mb') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10mB') == 10485760
    assert human_to_bytes('10MB', isbits=True) == 1048576
    assert human_to_bytes('10Mb', isbits=True) == 1048576
    assert human_to_bytes('10gb') == 10737418240
    assert human_to_bytes('10gB') == 10737418240
    assert human_to_bytes('10Gb', isbits=True) == 1073741824
    assert human_to_bytes('10GB', isbits=True) == 107

# Generated at 2022-06-11 01:42:12.705107
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 3, None]) == ['a', 'b', 3, None]
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['', 'A', 'B']) == ['', 'a', 'b']

# Generated at 2022-06-11 01:42:15.791724
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C', 1, 2, 3, None, False]) == ['a', 'b', 'c', 1, 2, 3, None, False]



# Generated at 2022-06-11 01:42:23.329898
# Unit test for function human_to_bytes
def test_human_to_bytes():
    testcases = {
        '2M': 2000000,
        '3K': 3000,
        '5Y': 5 * (1 << 80),
        '10b': 1,
        '10B': 1,
        '4KB': 4096,
        '6MB': 6000000,
        '1.5G': 1500000000,
        '1.8T': 1800000000000,
        '3.3P': 3300000000000000,
        '3.3E': 33000000000000000000,
        '3.3Z': 33000000000000000000000,
        '3.3Y': 33000000000000000000000000,
    }

    failed = []

    for tc in testcases:
        try:
            assert human_to_bytes(tc) == testcases[tc]
        except AssertionError:
            failed.append(tc)


# Generated at 2022-06-11 01:42:32.965387
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Passing input parameter as string.
    # example: human_to_bytes('10M') <=> human_to_bytes(10, 'M').
    tests = [('1', 1), ('1MB', 1 << 20), ('2.1M', 2.1 * (1 << 20)), ('2.5KB', 2.5 * (1 << 10)), ('1Mb', 1 << 17), ('1.5MB', 1.5 * (1 << 20))]
    for test in tests:
        result = human_to_bytes(test[0])
        assert result == test[1]

    # Passing input parameter as integer and suffix.

# Generated at 2022-06-11 01:42:43.286541
# Unit test for function human_to_bytes
def test_human_to_bytes():
    tests = (
        ('1', 1, 'no suffix'),
        ('1k', 1024, 'lowercase suffix'),
        ('1K', 1024, 'uppercase suffix'),
        ('1kb', 1000, 'bits'),
        ('1kB', 1024, 'bits'),
        ('1Kb', 1000, 'bits'),
        ('1KB', 1024, 'bits'),
        ('1M', 1048576, 'uppercase suffix'),
        ('1Mb', 1048576, 'bits'),
        ('1MB', 1048576, 'bits'),
    )
    for test in tests:
        if human_to_bytes(test[0]) != test[1]:
            raise ValueError('Failed test: %s' % test[2])

# Generated at 2022-06-11 01:42:51.860255
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    examples = {
        'lower': ['lower', 'lower', 'lower'],
        'lower, numbers': ['123', '123', 123],
        'lower, uppercase': ['lOwEr', 'lower', 'lower'],
        'lower, mixed': ['lower123', 'lower123', 'lower123'],
        'lower, mixed 2': ['lower', 'lower', 'loWeR'],
    }
    for test_name, example in iteritems(examples):
        yield lenient_lowercase_test, test_name, example



# Generated at 2022-06-11 01:42:58.680433
# Unit test for function bytes_to_human
def test_bytes_to_human():
    params = {
        ('Bytes', 'Bytes'): 1048576,
        ('KBytes', 'KB'): 1048576,
        ('MBytes', 'MB'): 1048576,
        ('GBytes', 'GB'): 1048576,
        ('TBytes', 'TB'): 1048576,
        ('PBytes', 'PB'): 1048576,
        ('Bits', 'bits'): 8388608,
        ('Kbits', 'Kb'): 8388608,
        ('Mbits', 'Mb'): 8388608,
        ('Gbits', 'Gb'): 8388608,
        ('Tbits', 'Tb'): 8388608,
        ('Pbits', 'Pb'): 8388608,
    }

    for expected, param in iteritems(params):
        result = bytes_to_human

# Generated at 2022-06-11 01:43:17.732031
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1025, isbits=False, unit='B') == '1.00 KB'
    assert bytes_to_human(16777216, isbits=False, unit='B') == '16.00 MB'
    assert bytes_to_human(1099511627776, isbits=False, unit='B') == '1024.00 GB'
    assert bytes_to_human(1099511627776, isbits=False, unit='b') == '1024.00 Gb'
    assert bytes_to_human(1, isbits=True, unit=None) == '8.00 bits'
    assert bytes_to_human(8, isbits=True, unit=None) == '8.00 bits'

# Generated at 2022-06-11 01:43:20.464803
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['a', 'B', 'C', 1, 2]) == ['a', 'b', 'c', 1, 2])


# Generated at 2022-06-11 01:43:27.370857
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Replace this with a call to your function and a set of asserts to test all supported inputs.
    result = lenient_lowercase(['AbC', 'dEf', 1, True, {'gH': 'jK'}, None, []])
    assert result == ['abc', 'def', 1, True, {'gH': 'jK'}, None, []]



# Generated at 2022-06-11 01:43:36.131530
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Tests for function human_to_bytes
    '''
    # bytes_to_human() test
    # byte unit test for bytes_to_human()
    assert bytes_to_human(1024) == '1.00 KB'
    # bit unit test for bytes_to_human()
    assert bytes_to_human(1024, isbits=True) == '8.00 Kb'
    # KBytes unit test for bytes_to_human()
    assert bytes_to_human(1024, unit='K') == '1.00 KBytes'
    # MBytes unit test for bytes_to_human()
    assert bytes_to_human(1024, unit='M') == '1.00 MBytes'
    # Kbits unit test for bytes_to_human()

# Generated at 2022-06-11 01:43:46.493394
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # lenient_lowercase should work as expected for mixed cases
    test_list = ['A', 'B', 'c', 'D', 'e', 'F']
    test_list_expect = ['a', 'b', 'c', 'd', 'e', 'f']
    assert lenient_lowercase(test_list) == test_list_expect

    # lenient_lowercase should leave non-string elements untouched
    test_list = ['A', 123, 'c', 'D', 'e', 'F']
    test_list_expect = ['a', 123, 'c', 'd', 'e', 'f']
    assert lenient_lowercase(test_list) == test_list_expect



# Generated at 2022-06-11 01:43:57.549093
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976
    assert human_to_bytes('1Z') == 1180591620717411303424
    assert human_to_bytes('1Y') == 1208925819614629174706176
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1Mb') == 1048576
    assert human

# Generated at 2022-06-11 01:44:03.558065
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, unit='byte') == '1.00 Bytes'
    assert bytes_to_human(1, unit='bytes') == '1.00 Bytes'
    assert bytes_to_human(1, unit='By') == '1.00 Bytes'
    assert bytes_to_human(1, unit='BY') == '1.00 Bytes'
    assert bytes_to_human(1, unit='BYTES') == '1.00 Bytes'
    assert bytes_to_human(1, unit='b') == '8.00 bits'

# Generated at 2022-06-11 01:44:07.578011
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-11 01:44:19.542762
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Test human_to_bytes function"""

# Generated at 2022-06-11 01:44:28.578212
# Unit test for function human_to_bytes
def test_human_to_bytes():
    values_to_test = {
        '10M': 10 * 1024 ** 2,
        '10.2M': int(round(10.2 * 1024 ** 2)),
        '1024K': 1024 * 1024,
        '1024b': 1024 * 8,
        '1Mb': 1024 * 1024,
        '10Mb': 10 * 1024 ** 2,
        '10.2Mb': int(round(10.2 * 1024 ** 2)),
        '1024Kb': 1024 * 1024,
        '1024b': 8 * 1024,
        '1024': 1024,
    }
    for value_to_test, expected_result in iteritems(values_to_test):
        assert human_to_bytes(value_to_test) == expected_result
        assert human_to_bytes(value_to_test, isbits=True) == expected

# Generated at 2022-06-11 01:44:40.316155
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_tuples = [
        (['a', 'b', 'c', 'D', 'E', 'F', 'g'], ['a', 'b', 'c', 'D', 'E', 'F', 'g']),
        (['a', 'b', 'c', '3', '2', '1', 'g'], ['a', 'b', 'c', 3, 2, 1, 'g']),
        (['a', 'b', 'c', '{', '[', ']', 'g'], ['a', 'b', 'c', '{', '[', ']', 'g']),
        (['a', 'b', 'c', '{', '1.1', '}', 'g'], ['a', 'b', 'c', '{', '1.1', '}', 'g']),
    ]

   

# Generated at 2022-06-11 01:44:45.503349
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase(['A', 2, 'C']) == ['a', 2, 'c']

# Generated at 2022-06-11 01:44:55.331599
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_data = [['a', 'b', 'C'], 'ab', ['a', ['b', 'c'], 'd'], set('abc')]
    for item in test_data:
        lowered = lenient_lowercase(item)
        for i in range(len(item)):
            item_value = item[i]
            try:
                lowered_value = lowered[i]
            except IndexError:
                print('IndexError for item %s, i = %s' % (item, i))
                raise
            if isinstance(item_value, (list, tuple, set)):
                assert isinstance(lowered_value, (list, tuple, set))
                assert lenient_lowercase(item_value) == lowered_value

# Generated at 2022-06-11 01:44:58.622722
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [1, 2, 'this', 'THAT', 3]
    expected_list = [1, 2, 'this', 'that', 3]
    assert expected_list == lenient_lowercase(test_list)



# Generated at 2022-06-11 01:45:02.140464
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B']) == ['a', 'b']
    assert lenient_lowercase(1) == 1
    assert lenient_lowercase('a') == 'a'



# Generated at 2022-06-11 01:45:13.640473
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # testing the 'b' (lowercase) - bit identifier
    if human_to_bytes('10b') != 10:
        raise AssertionError("human_to_bytes() failed to convert 10b to bytes")

    if human_to_bytes('10b', default_unit='Mb', isbits=True) != 128000:
        raise AssertionError("human_to_bytes() failed to convert 10b to bits (default unit specified)")

    if human_to_bytes('5b', default_unit='kb', isbits=True) != 5120:
        raise AssertionError("human_to_bytes() failed to convert 5b to bits (default unit specified)")

    # testing the 'B' (uppercase) - byte identifier

# Generated at 2022-06-11 01:45:17.392245
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    l = ["a", "B", "c", {}]
    assert l == ["a", "B", "c", {}]
    assert l.lower() == AttributeError
    assert lenient_lowercase(l) == ["a", "b", "c", {}]


# Generated at 2022-06-11 01:45:24.058035
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('123') == 123
    assert human_to_bytes('123b') == 123
    assert human_to_bytes('123B') == 123
    assert human_to_bytes('123B', isbits=True) == 123
    assert human_to_bytes('123b', isbits=True) == 123
    assert human_to_bytes('123b') == 123
    assert human_to_bytes('123b', isbits=False) == 123
    assert human_to_bytes('123B', isbits=False) == 123
    assert human_to_bytes('123 B') == 123
    assert human_to_bytes('123 B', isbits=False) == 123
    assert human_to_bytes('123b', isbits=True) == 123
    assert human_to_bytes('123.456') == 123
   

# Generated at 2022-06-11 01:45:27.456431
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 'B', 'c']) == [1, 'b', 'c']



# Generated at 2022-06-11 01:45:38.487211
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # 2**10 == 1024
    assert human_to_bytes('1K', isbits=False) == 1024
    assert human_to_bytes('1kB', isbits=True) == 1024

    # 2**20 == 1024 ** 2
    assert human_to_bytes('1M', isbits=False) == 1024 * 1024
    assert human_to_bytes('1Mb', isbits=True) == 1024 * 1024

    # 2**30 == 1024 ** 3
    assert human_to_bytes('1G', isbits=False) == 1024 * 1024 * 1024
    assert human_to_bytes('1Gb', isbits=True) == 1024 * 1024 * 1024

    # 2**40 == 1024 ** 4
    assert human_to_bytes('1T', isbits=False) == 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-11 01:45:54.800085
# Unit test for function lenient_lowercase

# Generated at 2022-06-11 01:46:05.986593
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = human_to_bytes('100 B')
    assert(100 == result)
    result = human_to_bytes('100B')
    assert(100 == result)
    result = human_to_bytes('100 b')
    assert(100 == result)
    result = human_to_bytes('100b')
    assert(100 == result)
    result = human_to_bytes('10 Kb')
    assert(10240 == result)
    result = human_to_bytes('10kB')
    assert(10240 == result)
    result = human_to_bytes('10 KB')
    assert(10240 == result)
    result = human_to_bytes('10kB', isbits=True)
    assert(10080 == result)
    result = human_to_bytes('10 KB', isbits=True)

# Generated at 2022-06-11 01:46:08.739217
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['bob', 'jim', 1, None]
    assert lenient_lowercase(lst) == ['bob', 'jim', 1, None]



# Generated at 2022-06-11 01:46:20.754003
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from random import randint
    from string import digits, ascii_uppercase
    from datetime import datetime

    expected_values = (
        (1024, 'kB'),
        (1024**2, 'MB'),
        (1024**3, 'GB'),
        (1024**4, 'TB'),
        (1024**5, 'PB'),
        (1024**6, 'EB'),
        (1024**7, 'ZB'),
        (1024**8, 'YB'),
    )

    rs = random_string(40)

    # testing general
    for _bytes, unit in expected_values:
        human = bytes_to_human(_bytes)
        print("Testing general %s %s" % (str(_bytes), human))
        assert human_to_bytes(human) == _bytes

    # testing defined unit

# Generated at 2022-06-11 01:46:25.974794
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test success case
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1Mb', isbits=True) == 1048576

    # Test failure case
    try:
        human_to_bytes('1M')
    except ValueError as e:
        assert "The suffix must be one of" in str(e)

# Generated at 2022-06-11 01:46:36.215578
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Test description:
    * Check if human_to_bytes works properly
    * Test for all units for both of use cases when isbits = False and isbits = True
    * Test for wrong input values
    '''


# Generated at 2022-06-11 01:46:43.320798
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A']) == ['a']
    assert lenient_lowercase(['a']) == ['a']
    assert lenient_lowercase(['123']) == ['123']
    assert lenient_lowercase(['ab', 'Cd', 'ef', '123']) == ['ab', 'cd', 'ef', '123']
    assert lenient_lowercase([123, 'Cd', 'ef', '123']) == [123, 'cd', 'ef', '123']
    assert lenient_lowercase([123, 'Cd', [], '123']) == [123, 'cd', [], '123']


# Generated at 2022-06-11 01:46:48.399414
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Test lenient_lowercase function"""
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 1, 'b']) == ['a', 1, 'b']


# Generated at 2022-06-11 01:46:54.380742
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_values = [
        'lower',
        'UPPER',
        1,
        '1'
    ]
    result = lenient_lowercase(test_values)
    expected = [
        'lower',
        'upper',
        1,
        '1'
    ]
    assert result == expected

# Unit tests for function human_to_bytes

# Generated at 2022-06-11 01:47:05.250810
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''Unit test for human_to_bytes'''
    failed = False

    for test in [
        ('10K', 10240, 'M'),
        ('10MB', 10485760, None),
        ('10M', 10485760, None),
        ('1B', 1, None),
        ('10B', 10, None),
        ('1Bit', 1, True),
        ('10Bits', 10, True),
        ('10Kb', 102400, True),
        ('10Mb', 10485760, True),
        ('10Gb', 10737418240, True),
    ]:
        value = test[0]
        expected = test[1]
        isbits = test[2]


# Generated at 2022-06-11 01:47:19.249956
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [
        ['a', 'b', 'c', None, 1, 2, '3'],
        [1, 2, 3],
        [],
        ['A', 'B', 'c', None, 1, 2, '3'],
    ]
    ans_list = [
        ['a', 'b', 'c', None, 1, 2, '3'],
        [1, 2, 3],
        [],
        ['a', 'b', 'c', None, 1, 2, '3'],
    ]
    for i, case in enumerate(test_list):
        assert ans_list[i] == lenient_lowercase(case)


# Generated at 2022-06-11 01:47:22.719384
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['A', 'B', None, 'D']
    assert sorted(lenient_lowercase(lst)) == sorted(['a', 'b', None, 'd'])



# Generated at 2022-06-11 01:47:32.893481
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1 ', 'B') == 1
    assert human_to_bytes('1.5', 'B') == 1
    assert human_to_bytes('1.5', 'M') == 1572864
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5MB') == 1572864
    assert human_to_bytes('1.5 Mb') == 1572864
    assert human_to_bytes('1.5 MB') == 1572864
    assert human_to_bytes('1.5 b') == 1572864
    assert human_to_bytes('1.5 mb', isbits=True) == 1572864
    assert human_to_bytes('1.5 M', isbits=True)

# Generated at 2022-06-11 01:47:34.398818
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Foo', 'BaR', 42, lambda x: x]) == ['foo', 'baR', 42, lambda x: x]

# Generated at 2022-06-11 01:47:42.670850
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'a', 'b', 'c']) == [1, 'a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 'A', 'B', 'c']) == [1, 'a', 'b', 'c']



# Generated at 2022-06-11 01:47:46.894591
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Bob', 'Alice', 'Eve', 'B0b', None, 1, False, b'Alice']) == ['bob', 'alice', 'eve', 'b0b', None, 1, False, b'Alice']

# Generated at 2022-06-11 01:47:55.581271
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K', default_unit='B') == 1024
    assert human_to_bytes('10K', default_unit='B') == 10240
    assert human_to_bytes('10M', default_unit='B') == 10485760
    assert human_to_bytes('10G', default_unit='B') == 10737418240
    assert human_to_bytes('10T', default_unit='B') == 10995116277760
    assert human_to_bytes('10E', default_unit='B') == 11258999068426240
    assert human_to_bytes('10P', default_unit='B') == 1152921504606847000
    assert human_to_bytes('10Y', default_unit='B') == 1180591620717411303424
    assert human_to

# Generated at 2022-06-11 01:48:00.456484
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 1]) == ['a', 1]
    # make sure capital letters are still converted to lower case
    assert lenient_lowercase(['B', 2]) == ['b', 2]


# Unit tests for function human_to_bytes

# Generated at 2022-06-11 01:48:11.912661
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Testing basic functionality and various exceptions.
    '''
    assert human_to_bytes('1M') == 1048576, 'human_to_bytes() failed to convert 1M.'
    assert human_to_bytes('10M') == 10485760, 'human_to_bytes() failed to convert 10M.'
    assert human_to_bytes('1Mb', isbits=True) == 1048576, 'human_to_bytes() failed to convert 1Mb.'
    assert human_to_bytes('10Mb', isbits=True) == 10485760, 'human_to_bytes() failed to convert 10Mb.'
    assert human_to_bytes('1', unit='kb') == 1024, 'human_to_bytes() failed to convert 1kb.'
    assert human_to_bytes('10', unit='Mb')

# Generated at 2022-06-11 01:48:13.958627
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['string', 1, '2string']
    result = lenient_lowercase(lst)
    assert result == ['string', 1, '2string']
    assert result is not lst



# Generated at 2022-06-11 01:48:40.105344
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2B') == 2
    assert human_to_bytes('2', 'B') == 2
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2', 'K') == 2048
    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('2', 'M') == 2097152
    assert human_to_bytes('2G') == 2147483648
    assert human_to_bytes('2', 'G') == 2147483648
    assert human_to_bytes('2T') == 2199023255552
    assert human_to_bytes('2', 'T') == 2199023255552
    assert human_to_bytes('2.5M') == 262144000

# Generated at 2022-06-11 01:48:45.265216
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    simple_list = ['a', 'b', 'c', 'd']
    assert lenient_lowercase(simple_list) == ['a', 'b', 'c', 'd']
    complicated_list = ['a', ('b', 'c'), 'd']
    assert lenient_lowercase(complicated_list) == ['a', ('b', 'c'), 'd']

# Generated at 2022-06-11 01:48:55.851010
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    import types
    # test normal string and integers
    assert ['a', 'b'] == lenient_lowercase(['a', 'b'])
    assert ['a', 4] == lenient_lowercase(['a', 4])
    assert ['a', types.FunctionType(lambda x: x, globals())] == lenient_lowercase(['a', lambda x: x])
    # test None, Empty string, Empty list
    assert [] == lenient_lowercase([])
    assert [] == lenient_lowercase(None)
    assert [''] == lenient_lowercase([''])
    # test boolean True and False
    assert [False, True] == lenient_lowercase([False, True])



# Generated at 2022-06-11 01:49:05.380260
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [1, 1.0, 'test']
    expected_result = [1, 1.0, 'test']
    assert lenient_lowercase(test_list) == expected_result, \
        'lenient_lowercase(%s) returned %s, expected %s' % (test_list, expected_result, lenient_lowercase(test_list))

    test_list = [u'test', 1, 'test2']
    expected_result = [u'test', 1, 'test2']
    assert lenient_lowercase(test_list) == expected_result, \
        'lenient_lowercase(%s) returned %s, expected %s' % (test_list, expected_result, lenient_lowercase(test_list))



# Generated at 2022-06-11 01:49:11.451280
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['Hello']) == ['hello']
    assert lenient_lowercase(['Hello', 'World']) == ['hello', 'world']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase([1, 'WORLD', [2, 'foo']]) == [1, 'WORLD', [2, 'foo']]



# Generated at 2022-06-11 01:49:22.073360
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # bytes
    assert human_to_bytes('5B') == 5
    assert human_to_bytes('5 B') == 5
    assert human_to_bytes('5 B', 'B') == 5
    assert human_to_bytes('5', 'B') == 5
    assert human_to_bytes('5', ' ') == 5
    assert human_to_bytes('5 B', 'kB') == 5000
    assert human_to_bytes('5', 'kB') == 5000
    assert human_to_bytes(5, 'kB') == 5000
    assert human_to_bytes('5', 'kB') == 5000
    assert human_to_bytes('5KB', isbits=True) == 5120
    assert human_to_bytes('5Kb', isbits=True) == 5120

# Generated at 2022-06-11 01:49:33.976643
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10Bb') == 10

    assert human_to_bytes('10b') == 1
    assert human_to_bytes('10bb') == 1

    assert human_to_bytes('1KB') == 1000
    assert human_to_bytes('1KBb') == 1000
    assert human_to_bytes('1K') == 1000
    assert human_to_bytes('1Kb') == 1000

    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576


# Generated at 2022-06-11 01:49:45.441960
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Human to bytes (base 10)
    assert 1024 == human_to_bytes('1K')
    assert 1024 == human_to_bytes('1Kb')
    assert 1024 == human_to_bytes('1KB')
    assert 1048576 == human_to_bytes('1M')
    assert 1048576 == human_to_bytes('1Mb')
    assert 1048576 == human_to_bytes('1MB')
    assert 1073741824 == human_to_bytes('1G')
    assert 1073741824 == human_to_bytes('1Gb')
    assert 1073741824 == human_to_bytes('1GB')
    assert 1099511627776 == human_to_bytes('1T')
    assert 1099511627776 == human_to_bytes('1Tb')
    assert 1099511627776 == human

# Generated at 2022-06-11 01:49:50.892174
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["ab", "c"]) == ['ab', 'c']
    assert lenient_lowercase(["ab", 10]) == ['ab', 10]
    assert lenient_lowercase(["ab", 10, "c"]) == ['ab', 10, 'c']
    assert lenient_lowercase(["ab", None]) == ['ab', None]
    assert lenient_lowercase([None, 10]) == [None, 10]
    assert lenient_lowercase(["ab", "C"]) == ['ab', 'c']



# Generated at 2022-06-11 01:50:00.261588
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [
        'A',
        'BB',
        'A',
        'ASDF',
        ['A', 'B'],
        'BSSADF',
        ['SDF', 'SDA', 'SDF'],
    ]
    expected_list = [
        'a',
        'bb',
        'a',
        'asdf',
        ['A', 'B'],
        'bssadf',
        ['SDF', 'SDA', 'SDF'],
    ]

    assert expected_list == lenient_lowercase(test_list)

