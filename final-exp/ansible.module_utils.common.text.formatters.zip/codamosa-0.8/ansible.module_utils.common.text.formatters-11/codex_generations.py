

# Generated at 2022-06-11 01:40:19.135873
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # 'Bytes'
    assert 1024 == human_to_bytes('1K')
    assert 1048576 == human_to_bytes('1M')
    assert 1073741824 == human_to_bytes('1G')
    assert 1099511627776 == human_to_bytes('1T')
    assert 1125899906842624 == human_to_bytes('1P')
    assert 1152921504606846976 == human_to_bytes('1E')
    assert 1180591620717411303424 == human_to_bytes('1Z')
    assert 1208925819614629174706176 == human_to_bytes('1Y')
    assert 0 == human_to_bytes('0K')
    assert 2047 == human_to_bytes('2K')

    # 'bytes'
    assert 1024 == human_to

# Generated at 2022-06-11 01:40:27.712317
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Function: human_to_bytes
    '''
    for value in ['10M', '10MB', '10Mb', '10mB']:
        assert human_to_bytes(value) == 10485760, "human_to_bytes() failed to convert %s to 10485760" % value

    for value in ['10Mb', '10MB', '10mB', '10MB']:
        assert human_to_bytes(value, isbits=True) == 10485760, "human_to_bytes() failed to convert %s to 10485760" % value

    try:
        human_to_bytes('10M', 'K')
        raise AssertionError("human_to_bytes() failed to raise an exception with 10M and K as parameters")
    except ValueError:
        pass

   

# Generated at 2022-06-11 01:40:29.975212
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lowercase_list = lenient_lowercase(["A", 1, "B", "c", 4, {}])
    assert lowercase_list == ["a", 1, "b", "c", 4, {}]


# Generated at 2022-06-11 01:40:38.594450
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human("1.234M") == "1285248 Bytes"
    assert bytes_to_human("1.234K") == "1248 Bytes"
    assert bytes_to_human("1.234G") == "132070144 Bytes"
    assert bytes_to_human("1.234E") == "13522782208 Bytes"
    assert bytes_to_human("1.234P") == "1374430488576 Bytes"
    assert bytes_to_human("1.234T") == "139816688218112 Bytes"
    assert bytes_to_human("1.234Z") == "1422149213448192 Bytes"
    assert bytes_to_human("1.234Y") == "14464450557210624 Bytes"
    assert bytes_to_human

# Generated at 2022-06-11 01:40:50.064805
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:40:57.114553
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(4096, None) == '4.00 KBytes'
    assert bytes_to_human(4096, 'k') == '4.00 KB'
    assert bytes_to_human(4096, 'K') == '4.00 KB'
    assert bytes_to_human(4096, 'KB') == '4.00 KB'
    assert bytes_to_human(4096, 'b') == '4096.00 bits'
    assert bytes_to_human(4096, 'B') == '4096.00 B'
    assert bytes_to_human(4096, 'M') == '0.00 MB'
    assert bytes_to_human(4096, 'bits') == '4096.00 bits'
    # next call would raise ValueError: human_to_bytes() failed to convert num (

# Generated at 2022-06-11 01:41:09.050273
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1M', isbits=True) == 8388608
    assert human_to_bytes('1M', default_unit='K') == 1024
    assert human_to_bytes('1M', default_unit='K', isbits=True) == 8192
    assert human_to_bytes('1Mb') == 8388608
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 8388608
    assert human_to_bytes('1MB', isbits=True) == 8388608
    assert human_to_bytes('1MB', isbits=True) == 8388608
    assert human

# Generated at 2022-06-11 01:41:18.741223
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Success
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.2B') == 1
    assert human_to_bytes('1.2KB') == 1200
    assert human_to_bytes('1000b') == 125
    assert human_to_bytes('0.125Mb') == 16000
    assert human_to_bytes('0.125Mb', isbits=True) == 16000
    assert human_to_bytes('0.125Mb', isbits=False) == 125000
    assert human_to_bytes('0.125MB') == 125000
    assert human_to_bytes('0.125MB', isbits=True) == 125000
    assert human_to_bytes('1.2KB', isbits=True) == 1200

# Generated at 2022-06-11 01:41:30.979936
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human('1B') == '1.00 Bytes'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(100) == '100.00 Bytes'
    assert bytes_to_human(1000) == '1,000.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human(1099511627776) == '1.00 TB'
    assert bytes_to_human(1125899906842624) == '1.00 PB'

# Generated at 2022-06-11 01:41:41.882364
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, unit='k') == '1.00 KB'
    assert bytes_to_human(1024, unit='k', isbits=True) == '8.00 Kb'
    assert bytes_to_human(1024, unit='k', isbits=False) == '1.00 KB'
    assert bytes_to_human(1024, unit='') == '1.00 K'
    assert bytes_to_human(1000) == '1000.00 Bytes'
    assert bytes_to_human(1000, unit='B') == '1000.00 Bytes'
    assert bytes_to_human(1000, unit='b') == '8000.00 b'

# Generated at 2022-06-11 01:41:50.616443
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [1, 2, "Hello", "world", "HELLO", "wOrLd", "HEllO woRlD"]
    lst_lower = ["hello", "world", "hello", "world", "hello", "world", "hello world"]
    assert (lst_lower == lenient_lowercase(lst))



# Generated at 2022-06-11 01:41:59.840209
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10 * 1024 * 1024
    assert human_to_bytes('10M', 'M') == 10 * 1024 * 1024
    assert human_to_bytes('10M', 'KB') == 10 * 1024 * 1024 / 1024
    assert human_to_bytes('10Mb') == 10 * 1024 * 1024
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10K') == 10 * 1024
    assert human_to_bytes('10K', 'K') == 10 * 1024
    assert human_to_bytes('1Mb') == 1048576/8


# Generated at 2022-06-11 01:42:05.819106
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_cases = [
        (["A", "b", "C", 1], ["a", "b", "c", 1]),
        (["A", "B", "C"], ["a", "b", "c"]),
        ([1, 2, 3], [1, 2, 3])
    ]
    for case in test_cases:
        assert(lenient_lowercase(case[0]) == case[1])



# Generated at 2022-06-11 01:42:10.874389
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 2]) == ['a', 'b', 2]
    assert lenient_lowercase(['A', 'B', [1, 'a', 2]]) == ['a', 'b', [1, 'a', 2]]
    assert lenient_lowercase(['A', 'B', {'a': 1, 'b': 2}]) == ['a', 'b', {'a': 1, 'b': 2}]



# Generated at 2022-06-11 01:42:20.386471
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1', unit='B') == 1
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1', unit='K') == 1024
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1', unit='M') == 1048576
    assert human_to_bytes('1g') == 1073741824
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1', unit='G') == 1073741824
    assert human_

# Generated at 2022-06-11 01:42:30.885693
# Unit test for function human_to_bytes
def test_human_to_bytes():
    human_to_bytes('10M') == human_to_bytes(10, 'M') == 10 * (1 << 20)
    human_to_bytes('10Mb') == human_to_bytes(10, 'Mb', isbits=True) == 10 * (1 << 20)
    human_to_bytes('10MB') == human_to_bytes(10, 'MB') == 10 * (1 << 20)
    human_to_bytes('10MB', isbits=True) == human_to_bytes(10, 'MB', isbits=True) == 10 * (1 << 20)
    try: human_to_bytes('10MB', isbits=True)
    except ValueError: pass
    try: human_to_bytes('10MBb')
    except ValueError: pass

# Generated at 2022-06-11 01:42:42.015795
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('5.5Mb') == 5767175
    assert human_to_bytes('1.5B') == 2
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('4k') == 4096
    assert human_to_bytes('4K') == 4096
    assert human_to_bytes('4Kb') == 4096
    assert human_to_bytes('4KB') == 4096
    assert human_to_bytes('4K', isbits=True) == 4096
    assert human_to_bytes('100Kb') == 102400
    assert human_to_bytes('100KB') == 102400
    assert human_to_bytes('100Kb', isbits=True) == 102400
    assert human_

# Generated at 2022-06-11 01:42:53.377797
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list1 = ['This', 'will', 'work']
    list2 = ['So', 'will', ['This', 'one']]
    list3 = [2, 'AND', 'This', 'One', [4, 'will'], 'too']

    # Check the function with a simple list
    assert lenient_lowercase(list1) == ['this', 'will', 'work']

    # Check the function with a list that contains a list
    assert lenient_lowercase(list2) == ['so', 'will', ['This', 'one']]

    # Check the function with a list that contains
    # items of different types
    assert lenient_lowercase(list3) == [2, 'and', 'this', 'One', [4, 'will'], 'too']



# Generated at 2022-06-11 01:43:03.902598
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['example', 'Example', 'EXAMPLE']) == ['example', 'example', 'example']
    assert lenient_lowercase(['Example', 'EXAMPLE', 2]) == ['example', 'example', 2]
    assert lenient_lowercase(['EXAMPLE', 'example', 2]) == ['example', 'example', 2]
    assert lenient_lowercase(['example', 'EXAMPLE', 2]) == ['example', 'example', 2]
    assert lenient_lowercase(['example', 'example', 2]) == ['example', 'example', 2]
    assert lenient_lowercase([2, 'example', 'EXAMPLE']) == [2, 'example', 'example']

# Generated at 2022-06-11 01:43:11.262867
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # function validates strings only
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['aBc']) == ['abc']
    assert lenient_lowercase(['aBc', 'D', 'EF']) == ['abc', 'D', 'EF']
    assert lenient_lowercase(['aBc', 'D', 'EF', 123]) == ['abc', 'D', 'EF', 123]



# Generated at 2022-06-11 01:43:29.480262
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import unittest
    import os
    import sys

    class Test(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        # test bytes to bits conversions
        def test_human_to_bytes_to_bits(self):
            bits_identifier = 'b'
            for _unit in ['M', 'GB', 'KB', 'B']:
                for _bits in [True, False]:
                    self.assertEqual(human_to_bytes('1%s' % _unit, default_unit=_unit, isbits=_bits),
                                            human_to_bytes('8%s%s' % (bits_identifier, _unit.lower()), default_unit=_unit, isbits=_bits))

        # test bytes conversion

# Generated at 2022-06-11 01:43:32.442099
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['FOO', 42, 23.4, 'bar', 'baz']) == ['foo', 42, 23.4, 'bar', 'baz']



# Generated at 2022-06-11 01:43:37.370554
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['yes', 'no', 2, 'a', 'b', 3, ['x'], ['a', 'b'], None] == lenient_lowercase(['YES', 'No', 2, 'A', 'B', 3, ['X'], ['A', 'B'], None])



# Generated at 2022-06-11 01:43:42.411270
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_list = [
        ('\n40.2k\n', 40960),
        ('4\n0\n.\n2\nk\n', 40960),
        ('40.2k', 40960),
        ('40k', 40960),
        ('40kB', 40960),
        ('40KB', 40960),
        ('40K', 40960),
        ('40Kb', 40960),
        ('40Kb', 40960),
        ('40b', 40),
        ('40B', 40),
        ('40', 40),
        ('40.', 40),
        ('40.0', 40),
        ('40.2', 40),
        ('40.2', 40),
        ('0.2k', 200),
        ('512', 512),
        ('', 0),
    ]


# Generated at 2022-06-11 01:43:45.412610
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    value = ['Atest', 'Btest', 'C', 'D']
    assert lenient_lowercase(value) == ['atest', 'btest', 'C', 'D']



# Generated at 2022-06-11 01:43:56.841205
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Testing human_to_bytes
    assert human_to_bytes('1') == 1
    assert human_to_bytes(1) == 1
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes(1, 'Mb', True) == 1048576
    assert human_to_bytes('1.1Mb') == 1153433
    assert human_to_bytes('1.1 MB') == 1153433
    assert human_to_bytes('1.1    mb', isbits=True) == 1153433
    assert human_to_bytes(2, unit='K') == 2048
    assert human_to_bytes(2, unit='KB') == 2048
    assert human_to_bytes('1K') == 1024


# Generated at 2022-06-11 01:44:07.302140
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1 K') == 1024
    assert human_to_bytes('1 M') == 1024 * 1024
    assert human_to_bytes('1 Mb', isbits=True) == 1024 * 1024
    assert human_to_bytes('1 MB', isbits=True) == 8 * 1024 * 1024
    assert human_to_bytes('1 G') == 1024 * 1024 * 1024
    assert human_to_bytes('1 G', unit='M') == 1024 * 1024
    assert human_to_bytes('1 Gb', isbits=True) == 1024 * 1024 * 1024
    assert human_to_bytes('1 GB', isbits=True) == 8 * 1024 * 1024 * 1024
    assert human_to_bytes('1024') == 1024

# Generated at 2022-06-11 01:44:11.816744
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A']) == ['a']
    assert lenient_lowercase([10]) == [10]
    assert lenient_lowercase(['A', 10, 'B']) == ['a', 10, 'b']


# Generated at 2022-06-11 01:44:23.354825
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Basic tests for function human_to_bytes '''
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624

    # test for bad input
    try:
        human_to_bytes('1W')
        assert False, 'Fixed input should have raised exception'
    except Exception:
        pass

    # test for integer input
    assert human_to_bytes(1024) == 1024
    assert human_to_bytes(1048576) == 1048576
    assert human_to_bytes(1073741824) == 1073741824



# Generated at 2022-06-11 01:44:32.725190
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:44:48.879271
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Unit test for a function human_to_bytes '''
    # Test a parameter number is not a string
    try:
        human_to_bytes(123)
    except Exception as e:
        assert "human_to_bytes() can't interpret following string" in str(e)
    # Test a parameter number is an empty string
    try:
        human_to_bytes('')
    except Exception as e:
        assert "human_to_bytes() can't interpret following string" in str(e)
    # Test a parameter has no number and unit
    try:
        human_to_bytes('   ')
    except Exception as e:
        assert "human_to_bytes() can't interpret following string" in str(e)
    # Negative value

# Generated at 2022-06-11 01:44:57.038812
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['1', '2', '3']) == ['1', '2', '3']
    assert lenient_lowercase(['j', 'k', 'L']) == ['j', 'k', 'l']
    assert lenient_lowercase(['J', 'K', 'l']) == ['j', 'k', 'l']
    assert lenient_lowercase(['K', 'l', 'm']) == ['k', 'l', 'm']
    assert lenient_lowercase(['l', 'm', 'n']) == ['l', 'm', 'n']
    assert lenient_lowercase(['m', 'n', 1]) == ['m', 'n', 1]

# Generated at 2022-06-11 01:45:03.137829
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase(['a', [1,2,3], 'C']) == ['a', [1,2,3], 'c']



# Generated at 2022-06-11 01:45:07.700084
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_data = ['a', 'B', 123, 'D', '', None, ['E', 'F'] ]
    list_result = ['a', 'b', 123, 'd', '', None, ['e', 'f'] ]
    assert lenient_lowercase(list_data) == list_result


# Generated at 2022-06-11 01:45:12.080361
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['UPPER', 'lower', 'MiXeD', 1, True]
    correct_result = ['upper', 'lower', 'mixed', 1, True]
    assert lenient_lowercase(test_list) == correct_result



# Generated at 2022-06-11 01:45:21.244939
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest

    bytes_data = {
        '2K': 1024 * 2,
        '1M': 1024 * 1024,
        '256MB': 1024 * 1024 * 256,
        '3.5M': 1024 * 1024 * 3.5,
        '5Y': 1024 * 1024 * 1024 * 1024 * 1024 * 5,
        '0': 0,
    }
    bits_data = {
        '1mb': 1024 * 1024,
        '1Mb': 1024 * 1024,
        '2kb': 1024 * 2,
        '10adf': 10,
        '15.55Mb': 1024 * 1024 * 15.55,
        '0': 0,
        '1b': 1
    }


# Generated at 2022-06-11 01:45:29.332859
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # pylint: disable=unused-variable
    # 1. Test normal lowercase functionality
    test_data = ['a', 'b', 'A', 'c', 'C']
    expected_result = ['a', 'b', 'a', 'c', 'c']
    result = lenient_lowercase(test_data)
    assert expected_result == result
    # 2. Test non-string item in list
    test_data = ['a', 1, 'C']
    expected_result = ['a', 1, 'c']
    result = lenient_lowercase(test_data)
    assert expected_result == result

# Generated at 2022-06-11 01:45:40.797237
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1000') == 1000
    assert human_to_bytes('1000.0') == 1000
    assert human_to_bytes('1000.10') == 1000
    assert human_to_bytes('1000.9999') == 1001
    assert human_to_bytes('1000.1m') == 1000000
    assert human_to_bytes('1000.1M') == 1000000
    assert human_to_bytes('1000.1mB') == 1000000
    assert human_to_bytes('1000.1MB') == 1000000
    assert human_to_bytes('1000.1mb') is None
    assert human_to_bytes('1000.1MB', isbits=True) is None
    assert human_to_bytes('1000.1mb', isbits=True) == 1000000

# Generated at 2022-06-11 01:45:44.442633
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lower = lenient_lowercase([1, 'A', 'a', 'B', 2])
    assert isinstance(lower, list)
    assert lower == [1, 'a', 'a', 'b', 2]



# Generated at 2022-06-11 01:45:53.867996
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B', None) == 1
    assert human_to_bytes('1B', 'B') == 1
    assert human_to_bytes('1', 'B') == 1
    assert human_to_bytes('1', default_unit='b') == 8
    assert human_to_bytes('1', default_unit='B') == 1
    assert human_to_bytes('1', 'b') == 8
    assert human_to_bytes('1', 'B') == 1
    assert human_to_bytes('1Kb', 'B') == 1024
    assert human_to_bytes('1Kb', 'b') == 8192
    assert human_to_bytes('1Kb', 'B', isbits=True) == 1024
    assert human_to_bytes('1Kb', 'b', isbits=True)

# Generated at 2022-06-11 01:46:05.495461
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['ABC', 'def', 123, 'GHI', 456]) == ['abc', 'def', 123, 'GHI', 456]


# Generated at 2022-06-11 01:46:17.506896
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:46:21.503614
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 2, 'c']) == ['a', 2, 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']


# Unit tests for bytes_to_human

# Generated at 2022-06-11 01:46:27.840715
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase([1, 2, 3, 4]) == [1, 2, 3, 4])
    assert(lenient_lowercase([1, "a", 3, "b"]) == [1, "a", 3, "b"])
    assert(lenient_lowercase(["a", "b", "c"]) == ["a", "b", "c"])
    assert(lenient_lowercase(["A", "B", "C"]) == ["a", "b", "c"])


# Generated at 2022-06-11 01:46:38.641841
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2 << 10
    assert human_to_bytes('2Kb') == 2 << 10
    assert human_to_bytes('2kB') == 2 << 10
    assert human_to_bytes('2Mb') == 2 << 20
    assert human_to_bytes('2MB') == 2 << 20
    assert human_to_bytes('2G') == 2 << 30
    assert human_to_bytes('2Gb') == 2 << 30
    assert human_to_bytes('2GB') == 2 << 30
    assert human_to_bytes('2Tb') == 2 << 40
    assert human_to_bytes('2TB') == 2 << 40
    assert human_to_bytes('2Pb') == 2 << 50
    assert human_to_bytes('2PB') == 2 << 50
    assert human

# Generated at 2022-06-11 01:46:49.685383
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('10M') == 10485760)
    assert(human_to_bytes('10MB') == 10485760)
    assert(human_to_bytes('10MB', unit='MB') == 10485760)
    assert(human_to_bytes(10, default_unit='M') == 10485760)
    assert(human_to_bytes(10, default_unit='MB') == 10485760)
    assert(human_to_bytes('10', default_unit='M') == 10485760)
    assert(human_to_bytes('10', default_unit='MB') == 10485760)
    assert(human_to_bytes('10Mb') == 10485760)

# Generated at 2022-06-11 01:47:01.921269
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Unit test for Ansible module_utils.network, function human_to_bytes '''
    from ansible.module_utils.network import human_to_bytes

# Generated at 2022-06-11 01:47:08.051431
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase([1, 'B', 3]) == [1, 'b', 3]

# Generated at 2022-06-11 01:47:09.533705
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['BAR', 42, 'Foo']) == ['bar', 42, 'foo']


# Unit tests for function human_to_bytes

# Generated at 2022-06-11 01:47:17.988289
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Unit test for function lenient_lowercase."""

    # Test with lowercase
    assert lenient_lowercase(["a", "b", "c"]) == ["a", "b", "c"]

    # Test with uppercase
    assert lenient_lowercase(["A", "B", "C"]) == ["a", "b", "c"]

    # Test with mixed case
    assert lenient_lowercase(["A", "b", "c"]) == ["a", "b", "c"]

    # Test with mixed case and mixed with non-strings
    assert lenient_lowercase(["A", "b", 1, 2, "c"]) == ["a", "b", 1, 2, "c"]

# Generated at 2022-06-11 01:47:33.122310
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    from ansible.utils.unicode import to_bytes
    cases = (
        (['FOO', 'Bar', 1], ['foo', 'bar', 1]),
        (['FOO', 'Bar', '1K'], ['foo', 'bar', '1K']),
    )
    for (in_data, out_data) in cases:
        assert lenient_lowercase(in_data) == out_data


# Generated at 2022-06-11 01:47:44.792663
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1") == 1    # no unit, int -> 1byte
    assert human_to_bytes("1B") == 1   # 'B', 1byte -> 1byte
    assert human_to_bytes("1MB") == 1048576   # 'B', 1MB -> 1B - 1048576bytes
    assert human_to_bytes("1MB", isbits=True) == 1048576   # 'b', 1MB -> 1b - 1048576bits

    assert human_to_bytes("1Mb", default_unit="Mb") == 1048576   # 'b', 1Mb -> 1b - 1048576bits
    assert human_to_bytes("1.5Mb", default_unit="Mb") == 1536000   # 'b', 1.5Mb -> 1.5b - 1536000bits


# Generated at 2022-06-11 01:47:47.929207
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['UPPER', 'lowercase']) == ['upper', 'lowercase']
    assert lenient_lowercase(['UPPER', 'lowercase', 1]) == ['upper', 'lowercase', 1]

# Generated at 2022-06-11 01:47:54.116581
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ["string"] == lenient_lowercase(["string"])
    assert ["string"] == lenient_lowercase(["String"])
    assert [1, "string"] == lenient_lowercase([1, "String"])
    assert [1, "string"] == lenient_lowercase([1, "string"])
    assert [1, "string", [2, "string2"]] == lenient_lowercase([1, "string", [2, "string2"]])



# Generated at 2022-06-11 01:48:01.354131
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    param = ['ABC', 'aBc', 'AbC', 'aBc', 'ABC', 'AbC', 42]
    result = ['abc', 'abc', 'abc', 'abc', 'abc', 'abc', 42]
    assert lenient_lowercase(param) == result

if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(["-s", __file__]))

# Generated at 2022-06-11 01:48:04.620714
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]



# Generated at 2022-06-11 01:48:15.216471
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('608MB') == 629145600
    assert human_to_bytes('608MB', default_unit='MB') == 629145600
    assert human_to_bytes('608', default_unit='MB') == 629145600
    assert human_to_bytes('608mb', isbits=True) == 629145600
    assert human_to_bytes('608mb', default_unit='MB', isbits=True) == 629145600
    assert human_to_bytes('608Mb', default_unit='Mb', isbits=True) == 629145600
    assert human_to_bytes('608', default_unit='Mb', isbits=True) == 629145600

# Generated at 2022-06-11 01:48:21.505058
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    tests = [
        {'input': [], 'expeceted': []},
        {'input': ['A', 'B', 'C'], 'expeceted': ['a', 'b', 'c']},
        {'input': [1, 2, 3], 'expeceted': [1, 2, 3]},
        {'input': ['A', 2, 'C'], 'expeceted': ['a', 2, 'c']},
    ]
    for test in tests:
        result = lenient_lowercase(test['input'])
        assert result == test['expeceted']

# Generated at 2022-06-11 01:48:29.282224
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result1 = lenient_lowercase(['TEST', 'TEST2'])
    assert result1[0] == 'test'
    assert result1[1] == 'test2'

    result2 = lenient_lowercase([10, 20])
    assert result2[0] == 10
    assert result2[1] == 20

    # The following is to fix "UnboundLocalError: local variable 'val' referenced before assignment"
    # (Unit test code)
    val = None
    result3 = lenient_lowercase([val])
    assert result3[0] is None

# Generated at 2022-06-11 01:48:34.369577
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['foo', 'BAR', '', '123', 123, None]
    actual = lenient_lowercase(test_list)
    expected = ['foo', 'bar', '', '123', 123, None]

    assert actual == expected, 'lenient_lowercase returned %s, expected %s' % (actual, expected)

# Generated at 2022-06-11 01:49:01.340353
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Negative cases
    try:
        human_to_bytes('ag')
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError for human_to_bytes("ag")')

    try:
        human_to_bytes('1.0Mb')
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError for human_to_bytes("1.0Mb")')

    try:
        human_to_bytes('1.0Kb', isbits=True)
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError for human_to_bytes("1.0Kb", isbits=True)')

    # Positive cases - no unit
    assert human_to_bytes('1') == 1


# Generated at 2022-06-11 01:49:11.027167
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Test lenient_lowercase function"""
    for lst, result in (
            [['foo', 'bar'], ['foo', 'bar']],
            [['foo', None], ['foo', None]],
            [[None, 'bar'], [None, 'bar']],
            [[None, None], [None, None]],
            [['FOO', 'BAR'], ['foo', 'bar']],
            [['FOO', None], ['foo', None]],
            [[None, 'BAR'], [None, 'bar']],
            [[None, None], [None, None]],
            ):
        assert(lenient_lowercase(lst) == result)


# Generated at 2022-06-11 01:49:17.174733
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # ensures that a list with a non string element is not converted
    assert lenient_lowercase(['a', ['b'], 'c']) == ['a', ['b'], 'c']
    # ensures that a list with a string element is converted
    assert lenient_lowercase(['a', ['b'], 'C']) == ['a', ['b'], 'c']

# Generated at 2022-06-11 01:49:23.003517
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input = ['ABC', True, [1, 2], {'a': 'b', 'c': 'd'}, 100, True]
    result = lenient_lowercase(input)
    if result[0] != 'abc' or result[1] != True or result[2] != [1, 2] or result[3] != {'a': 'b', 'c': 'd'} or result[4] != 100 or result[5] != True:
        return False
    return True


# Generated at 2022-06-11 01:49:27.778290
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["A", "B", "C"]) == ["a", "b", "c"]
    assert lenient_lowercase([1, 'B', "C"]) == [1, 'b', "c"]


# Unit tests for function human_to_bytes

# Generated at 2022-06-11 01:49:37.603587
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1.5K') == (1024 * 1.5)
    assert human_to_bytes('1.5KB') == (1024 * 1.5)
    assert human_to_bytes('1.5Kb', isbits=True) == (1024 * 1.5)
    assert human_to_bytes('1.5Mb', isbits=True) == (1024 * 1024 * 1.5)
    assert human_to_bytes('1500 b', isbits=True) == 1500
    assert human_to_bytes('1.5M', default_unit='B') == (1024 * 1024 * 1.5)

# Generated at 2022-06-11 01:49:40.617451
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['HelloWorld', 12345, 'eXaMpLe']
    assert lenient_lowercase(lst) == ['helloworld', 12345, 'example']



# Generated at 2022-06-11 01:49:50.397366
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test mixed case input
    assert lenient_lowercase(['config', 'vlan', '1', 'name', 'ansible']) == ['config', 'vlan', '1', 'name', 'ansible']

    # Test mixed case input with int
    assert lenient_lowercase(['config', 'vlan', '1', 'name', 1]) == ['config', 'vlan', '1', 'name', 1]

    # Test lowercase input
    assert lenient_lowercase(['config', 'vlan', '1', 'name', 'ansible']) == ['config', 'vlan', '1', 'name', 'ansible']

    # Test uppercase input

# Generated at 2022-06-11 01:50:00.768292
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(["I", "AM", 1, "TEST", "STRING"])
    assert result == ["i", "am", 1, "TEST", "STRING"]
    result = lenient_lowercase(["I", 1, "AM", "TEST", "STRING"])
    assert result == ["i", 1, "am", "TEST", "STRING"]
    result = lenient_lowercase([1, "I", "AM", "TEST", "STRING"])
    assert result == [1, "i", "am", "TEST", "STRING"]

if __name__ == '__main__':
    test_lenient_lowercase()

# Generated at 2022-06-11 01:50:07.082881
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['foo', 'bar']) == ['foo', 'bar']
    assert lenient_lowercase(['FOO', 'BAR']) == ['foo', 'bar']
    assert lenient_lowercase([u'FOO', u'BAR']) == [u'foo', u'bar']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
