

# Generated at 2022-06-11 01:40:28.087390
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('234') == 234
    assert human_to_bytes('234M') == (234 * (2 ** 20))
    assert human_to_bytes('234m') == (234 * (2 ** 20))
    assert human_to_bytes(' 234  ') == 234
    assert human_to_bytes(' 234M ') == (234 * (2 ** 20))
    assert human_to_bytes(' 234m ') == (234 * (2 ** 20))
    assert human_to_bytes('234Mb') == (234 * (2 ** 20))
    assert human_to_bytes('234mb') == (234 * (2 ** 20))
    assert human_to_bytes('  234  Mb') == (234 * (2 ** 20))

# Generated at 2022-06-11 01:40:32.292245
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Hello', 'wOrLd']) == ['hello', 'world']
    assert lenient_lowercase(['Hello', 'WOrLd', [1, 2, 3]]) == ['hello', 'world', [1, 2, 3]]



# Generated at 2022-06-11 01:40:39.073911
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2K', 'B') == 2048
    assert human_to_bytes('2', 'KB') == 2048
    assert human_to_bytes('2', 'KB', True) == 2048
    assert human_to_bytes('2Kb') == 2048
    assert human_to_bytes('2Kb', True) == 2048
    assert human_to_bytes('2kb', True) == 2048
    assert human_to_bytes('2.2K') == 2 * 1024 + (1024 * 0.2)
    assert human_to_bytes('2.4M') == 2 * 1024 * 1024 + (1024 * 0.4)
    assert human_to_bytes('2k') == 2048
    assert human_to_bytes('2Mb', True) == 2048 * 1024

# Generated at 2022-06-11 01:40:50.343444
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        assert(human_to_bytes('test') == None)
    except ValueError:
        pass

    try:
        assert(human_to_bytes('test', isbits=True) == None)
    except ValueError:
        pass

    try:
        assert(human_to_bytes('2t') == None)
    except ValueError:
        pass

    try:
        assert(human_to_bytes('2t', isbits=True) == None)
    except ValueError:
        pass

    try:
        assert(human_to_bytes('2Tb') == None)
    except ValueError:
        pass

    try:
        assert(human_to_bytes('2TB', isbits=True) == None)
    except ValueError:
        pass


# Generated at 2022-06-11 01:41:02.560152
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """
    Unit test for human_to_bytes
    """
    assert human_to_bytes("1") == 1
    assert human_to_bytes("1.1") == 1
    assert human_to_bytes(1.1) == 1
    assert human_to_bytes(1) == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.1B') == 1
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1TB') == 1099511627776

# Generated at 2022-06-11 01:41:14.314799
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:41:20.019720
# Unit test for function human_to_bytes
def test_human_to_bytes():
    cases = [
        ('1K', 1024),
        ('1M', 1048576),
        ('1Kb', 1024),
        ('1Mb', 1048576),
        ('1B', 1),
        ('1.5B', 1.5),
        ('1.5KB', 1536),
        ('1.5 KB', 1536),
        ('1.5K', 1536),
        ('0.0K', 0),
        ('0K', 0),
        ('0.0M', 0),
        ('1.0Kb', 1024),
        ('1.0M', 1048576),
    ]

    failed_cases = []

# Generated at 2022-06-11 01:41:31.826065
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:41:42.535947
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Positive tests
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1 << 20
    assert human_to_bytes('1G') == 1 << 30
    assert human_to_bytes('1T') == 1 << 40
    assert human_to_bytes('1E') == 1 << 50
    assert human_to_bytes('1P') == 1 << 60
    assert human_to_bytes('1.2T') == 1 << 40
    assert human_to_bytes('0.8T') == 1 << 40
    assert human_to_bytes('7.9T') == 1 << 40
    assert human_to_bytes('8T') == 1 << 40
    assert human_to_bytes('8.0T') == 1 << 40

# Generated at 2022-06-11 01:41:54.625296
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['1', '2', '3', 4, 5]) == ['1', '2', '3', 4, 5]
    assert lenient_lowercase(['1', '2', '3', 4.5, '5']) == ['1', '2', '3', 4.5, '5']
    assert lenient_lowercase(['1', '2', '3', '4.5', '5']) == ['1', '2', '3', '4.5', '5']
    assert lenient_lowercase(['1', '2', '3', '-4.5', '5']) == ['1', '2', '3', '-4.5', '5']

# Generated at 2022-06-11 01:41:59.538657
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'Test', 'TEST']) == [1, 'test', 'TEST']


# Generated at 2022-06-11 01:42:08.959387
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest

    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('MB') == 1 << 20
    assert human_to_bytes('1MB') == 1 << 20
    assert human_to_bytes('1.0MB') == 1 << 20
    assert human_to_bytes('1.0mB') == 1 << 20
    assert human_to_bytes('1.5MB') == (1 << 20) + (1 << 19)
    assert human_to_bytes('1.5Mb') == (1 << 20) + (1 << 19)
    assert human_to_bytes('1.5Mb', isbits=True) == (1 << 20) + (1 << 19)

# Generated at 2022-06-11 01:42:15.037153
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['Foo','Bar','baz','Qux','quux','Baz','QUUUX','bar','fOo']) == ['foo','bar','baz','qux','quux','baz','quuux','bar','foo'])
    assert(lenient_lowercase([1,2,[3,4],5,'Foo',6]) == [1,2,[3,4],5,'Foo',6])

# Generated at 2022-06-11 01:42:22.952928
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1Mb') == 1048576)
    assert(human_to_bytes('1MB') == 1048576)
    assert(human_to_bytes('1.1Mb') == 1153433.6)
    assert(human_to_bytes('1.1M') == 1048576)
    assert(human_to_bytes('1.1MB') == 1048576)
    assert(human_to_bytes('1048576') == 1048576)
    assert(human_to_bytes(1048576) == 1048576)
    assert(human_to_bytes('1M') == 1048576)
    assert(human_to_bytes(1048576, default_unit='B') == 1048576)

# Generated at 2022-06-11 01:42:32.120109
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [
        "TestString",
        (1, 2),
        ["TestList", "TestList2"],
        {'TestDict': 'TestDictValue'},
        ['TestList', (1, 2), {'TestDict': 'TestDictValue'}]]

    expected_result = [
        "teststring",
        (1, 2),
        ["testlist", "testlist2"],
        {'testdict': 'TestDictValue'},
        ['testlist', (1, 2), {'testdict': 'TestDictValue'}]]

    observed_result = lenient_lowercase(test_list)

    assert expected_result == observed_result, 'Results do not match'



# Generated at 2022-06-11 01:42:39.738634
# Unit test for function human_to_bytes
def test_human_to_bytes():
    human_to_bytes('1B')
    human_to_bytes('1B', 'B')
    human_to_bytes('1', 'B')
    human_to_bytes('10M')
    human_to_bytes('10M', 'Mb')
    human_to_bytes('10Mb')
    human_to_bytes('10Mb', 'Mb')
    human_to_bytes(10, 'Mb')
    human_to_bytes(10, 'Mb', True)



# Generated at 2022-06-11 01:42:43.741750
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_input = ['Test', 123, 'aBc', [1, 2, 3]]
    expected_output = ['test', 123, 'abc', [1, 2, 3]]
    assert lenient_lowercase(test_input) == expected_output


# Generated at 2022-06-11 01:42:55.223544
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Unit tests for function human_to_bytes '''

# Generated at 2022-06-11 01:43:06.470751
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list_1 = [0, 'a', 'B', True, None, {}, ['', 'w', 'x', 'Y'] ]
    test_list_2 = [0, 'a', 'B', True, None, {}, ['', 'w', 'x', 'Y'] ]
    test_list_3 = [(1, 'a'), (2, 'w'), (3, 'x'), (4, 'Y')]
    test_list_4 = [(1, 'a'), (2, 'w'), (3, 'x'), (4, 'Y')]
    test_list_5 = ['1', 'a', 'B', 'True', 'None', '{}', ['', 'w', 'x', 'Y'] ]

# Generated at 2022-06-11 01:43:18.473302
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('5') == 5
    assert human_to_bytes(5) == 5

    assert human_to_bytes('5K') == 5 * 1024
    assert human_to_bytes('5KB') == 5 * 1024
    assert human_to_bytes('5Kb') == 5 * 1024
    assert human_to_bytes('5kB') == 5 * 1024
    assert human_to_bytes('5KiB') == 5 * 1024
    assert human_to_bytes('5kib') == 5 * 1024
    assert human_to_bytes('5kb') == 5 * 1024
    assert human_to_bytes('5K') == human_to_bytes('5K', default_unit='K')

# Generated at 2022-06-11 01:43:32.569584
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from pytest import raises

    assert human_to_bytes('1') == 1
    assert human_to_bytes(1) == 1
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2k') == 2048
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1kB', isbits=True) == 1024
    assert human_to_bytes('1KB', isbits=True) == 1024
    assert human_to_bytes('1kb', isbits=True) == 1024
    assert human_to_bytes('1.0 Kb', isbits=True) == 1024

# Generated at 2022-06-11 01:43:44.899958
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB') == 1024 * 1024
    assert human_to_bytes('1GB') == 1024 * 1024 * 1024
    assert human_to_bytes('1TB') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1PB') == 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1EB') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1ZB') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1YB') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024

    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1m') == 1024 * 1024

# Generated at 2022-06-11 01:43:56.790780
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # testing bytes cases
    assert human_to_bytes('12345') == 12345, "Can't convert '12345' to integer"
    assert human_to_bytes('11KB') == 11264, "Can't convert '11KB' to 11264"
    assert human_to_bytes('4096') == 4096, "Can't convert '4096' to 4096"
    assert human_to_bytes('1m') == 1048576, "Can't convert '1m' to 1048576"
    try:
        human_to_bytes('1Mb')
        assert False, "Failed to detect wrong unit identifier in '1Mb'"
    except Exception:
        pass

    # testing bits cases

# Generated at 2022-06-11 01:44:07.264855
# Unit test for function human_to_bytes
def test_human_to_bytes():
    #, size, isbits, unit, expected_return
    test_cases = [
        ('10M', 10, 'M', False),
        ('10Gb', 10, 'Gb', True),
        ('10Mb', 10, 'Mb', True),
        ('10Mb', 10, 'Mb', True),
        ('10Mb', 10, 'Mb', True),
        ('10Mb', 10, 'Mb', True),
        ('10Mb', 10, 'Mb', True),
        ('10Mb', 10, 'Mb', True),
        ('10Mb', 10, 'Mb', True),
    ]

    for test in test_cases:
        input_size, input_num, input_unit, input_isbits = test
        expected_size = input_num * SIZE_RANGES

# Generated at 2022-06-11 01:44:09.632920
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['foo', 'bar', 'baz'] == lenient_lowercase(['FOO', 'BAR', 'baz'])



# Generated at 2022-06-11 01:44:13.739136
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    testlist = ['AaB', 5, 'Ccc', '11']
    testlowerset = lenient_lowercase(testlist)
    assert testlowerset == ['aab', 5, 'ccc', '11']


# Generated at 2022-06-11 01:44:24.898430
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1', unit='B') == 1
    assert human_to_bytes('1', unit='B') == human_to_bytes('1B', unit='B')
    assert human_to_bytes('1', unit='B') == human_to_bytes('1b', unit='b')

    assert human_to_bytes('2', unit='B') == 2
    assert human_to_bytes('2', unit='B') == human_to_bytes('2B', unit='B')
    assert human_to_bytes('2', unit='B') == human_to_bytes('2b', unit='b')

    assert human_to_bytes('1', unit='KB') == 1024
    assert human_to_bytes('1', unit='KB') == human_to_bytes('1KB', unit='KB')
    assert human

# Generated at 2022-06-11 01:44:34.790270
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Default - without unit
    assert human_to_bytes("10") == 10

    # Default - without unit (decimal)
    assert human_to_bytes("10.2") == 10.2

    # Default - without unit (integer)
    assert human_to_bytes("10.0") == 10

    # Default - with unit 'B'
    assert human_to_bytes("10B") == 10

    # Default - with unit 'B' (decimal)
    assert human_to_bytes("10.2B") == 10.2

    # Default - with unit 'B' (integer)
    assert human_to_bytes("10.0B") == 10

    # Default - with unit 'b' (not bits)
    try:
        human_to_bytes("10b")
    except ValueError:
        pass

# Generated at 2022-06-11 01:44:44.602957
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:44:55.036202
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # basic
    assert human_to_bytes('100B') == 100
    assert human_to_bytes('100K') == 100 * (1 << 10)
    assert human_to_bytes('100M') == 100 * (1 << 20)
    assert human_to_bytes('100G') == 100 * (1 << 30)
    assert human_to_bytes('100T') == 100 * (1 << 40)

    # decimal
    assert human_to_bytes('100.5K') == 100500

    # float, decimal
    assert human_to_bytes('100.5') == 100500

    # float, no decimal
    assert human_to_bytes('100.0') == 100000

    # integer
    assert human_to_bytes('100') == 100000

    # default
    assert human_to_bytes('100', 'M')

# Generated at 2022-06-11 01:45:10.436042
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2010M') == 21474836480
    assert human_to_bytes(2010, 'M') == 21474836480
    assert human_to_bytes(2010, 'M', isbits=True) == 21474836480
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes(10, 'Mb') == 10485760
    assert human_to_bytes(10, 'Mb', isbits=True) == 10485760

    try:
        human_to_bytes('10Mb', isbits=False)
    except ValueError as e:
        assert e.args[0] == "human_to_bytes() failed to convert 10Mb. Value is not a valid string (expect Mb or Mb)"


# Generated at 2022-06-11 01:45:20.202954
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:45:30.851537
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    n_list = [3, 'a', 'b', 'c']
    n_lower = lenient_lowercase(n_list)
    assert n_lower == [3, 'a', 'b', 'c']

    n_list = [3.5, 'ab', 'b1', 'Cc']
    n_lower = lenient_lowercase(n_list)
    assert n_lower == [3.5, 'ab', 'b1', 'Cc']

    n_list = [3, 'a', 'b', 'c', 3.5, 'ab', 'b1', 'Cc']
    n_lower = lenient_lowercase(n_list)
    assert n_lower == [3, 'a', 'b', 'c', 3.5, 'ab', 'b1', 'Cc']

    n

# Generated at 2022-06-11 01:45:42.750421
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    example_list = [1, '2', 3, '4']
    assert lenient_lowercase(example_list) == [1, '2', 3, '4']

    example_list = ['a', 'b', 'c', 'd']
    assert lenient_lowercase(example_list) == ['a', 'b', 'c', 'd']

    example_list = ['A', 'B', 'C', 'D']
    assert lenient_lowercase(example_list) == ['a', 'b', 'c', 'd']

    example_list = ['A', 'B', 'C', 'D', 1, 2, 3, 4]
    assert lenient_lowercase(example_list) == ['a', 'b', 'c', 'd', 1, 2, 3, 4]



# Generated at 2022-06-11 01:45:52.847761
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''Unit test for function human_to_bytes'''
    '''Test function if isbits=Fase'''
    assert human_to_bytes('1KB') == 1000
    assert human_to_bytes('1Kb') == 1000
    assert human_to_bytes('1k') == 1000
    assert human_to_bytes('10MB') == 10000000

    '''Test function if isbits=True'''
    assert human_to_bytes('1KB', isbits=True) == 8e+03
    assert human_to_bytes('1Kb', isbits=True) == 8e+03
    assert human_to_bytes('1k', isbits=True) == 8e+03
    assert human_to_bytes('10MB', isbits=True) == 8e+07


# Generated at 2022-06-11 01:46:04.297373
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10MB', 'm') == 10485760
    assert human_to_bytes('10MB', 'M') == 10485760
    assert human_to_bytes('10MB', unit='M') == 10485760
    assert human_to_bytes('10M', isbits=True) == 8388608
    assert human_to_bytes('10Mb', isbits=True) == 8388608
    assert human_to_bytes('10Mb', 'm', isbits=True) == 8388608
    assert human_to_bytes('10Mb', 'M', isbits=True) == 8388608

# Generated at 2022-06-11 01:46:15.986557
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test bits
    assert human_to_bytes('1.5Mb', isbits=True) == int(round(1.5 * (SIZE_RANGES['M'])))
    assert human_to_bytes('10b', isbits=True) == 10
    assert human_to_bytes('2Mb', isbits=True) == 2097152
    assert human_to_bytes('2Mb', 'b', True) == 2097152
    try:
        assert human_to_bytes('6Mb', default_unit='Mb') == 6291456
    except ValueError as e:
        assert '6Mb' in str(e)
        assert 'default' in str(e)
    # assert human_to_bytes('1000') == 1000

# Generated at 2022-06-11 01:46:22.523149
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # simple test
    x = ['a', 'b', 'c', 1, 2, 3]
    assert lenient_lowercase(x) == ['a', 'b', 'c', 1, 2, 3]
    
    # test strings
    x = ['a', 'b', 1, 'c', 2, 'd', 3]
    assert lenient_lowercase(x) == ['a', 'b', 1, 'c', 2, 'd', 3]


# Generated at 2022-06-11 01:46:30.711239
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import sys
    import pytest

    #
    # GIVEN:
    #

    #
    # WHEN:
    #

    #
    # THEN:
    #
    assert human_to_bytes('1') == 1
    assert human_to_bytes(1) == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.1B') == 1
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('1.12345B') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1M') == 1024 ** 2

# Generated at 2022-06-11 01:46:41.045591
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:46:50.842670
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a','b',1,'d']) == ['a','b',1,'d']


# Generated at 2022-06-11 01:47:03.029423
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:47:13.836244
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:47:24.668292
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:47:28.253865
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['abc123', 'DEF456', 1, 2, 3]
    expect = ['abc123', 'def456', 1, 2, 3]
    assert lenient_lowercase(test_list) == expect



# Generated at 2022-06-11 01:47:30.636884
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['TEST', 1, 'TEST2']) == ['test', 1, 'test2']

# Generated at 2022-06-11 01:47:33.672277
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 1, 'B', 'c', 'D']) == ['a', 1, 'b', 'c', 'd']


# Unit tests for function human_to_bytes


# Generated at 2022-06-11 01:47:39.955201
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # simple string
    assert lenient_lowercase(['FOO']) == ['foo']

    # simple list
    assert lenient_lowercase([['FOO', 'FOO'], ['BAR', 'BAR']]) == [['foo', 'foo'], ['bar', 'bar']]

    # mixed list
    assert lenient_lowercase(['FOO', [1, 2], 'BAR', ['ZOO', 'ZOO']]) == ['foo', [1, 2], 'bar', ['ZOO', 'ZOO']]

    # simple dict
    assert lenient_lowercase({'foo': 'FOO', 'bar': 'BAR'}) == {'foo': 'foo', 'bar': 'bar'}

    # mixed dict

# Generated at 2022-06-11 01:47:45.469095
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["lower", "UPPER", "mixed", "CAMELCASE", 1, 2, 3, None, [1, 2, 3]]) == ["lower", "upper", "mixed", "CAMELCASE", 1, 2, 3, None, [1, 2, 3]]


# Generated at 2022-06-11 01:47:54.855261
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('12MB') == 12582912
    assert human_to_bytes('12M') == 12582912
    assert human_to_bytes('12', 'M') == 12582912
    assert human_to_bytes(12, 'M') == 12582912
    assert human_to_bytes(12, unit='M') == 12582912

    assert human_to_bytes('12KB') == 12288
    assert human_to_bytes('12K') == 12288
    assert human_to_bytes('12', 'K') == 12288
    assert human_to_bytes(12, 'K') == 12288
    assert human_to_bytes(12, unit='K') == 12288

    assert human_to_bytes('12MB', isbits=True) == 12000000
    assert human_to

# Generated at 2022-06-11 01:48:18.861354
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # bytes tests
    assert(human_to_bytes('1KB') == 1024)
    assert(human_to_bytes('10MB') == 10485760)
    assert(human_to_bytes('10MB', 'KB') == 10240)
    assert(human_to_bytes('10MB', 'KB') == 10240)
    assert(human_to_bytes('10MB', 'Kb') == 10240)
    assert(human_to_bytes('10MB', 'Kb', isbits=True) == 10240)
    assert(human_to_bytes('10MB', 'KB', isbits=True) == 10485760)

    # bits tests
    assert(human_to_bytes('100Mb', 'Kb') == 102400)

# Generated at 2022-06-11 01:48:24.233606
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_cases = [
        ('2K', 2048),
        ('3k', 3072),
        ('1M', 1048576),
        ('5M', 5242880),
        ('2G', 2147483648),
        ('4g', 4294967296),
    ]
    for case, expected_result in test_cases:
        result = human_to_bytes(case)
        assert result == expected_result


# Generated at 2022-06-11 01:48:30.080070
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    l1 = lenient_lowercase([1,2,3])
    assert l1 == [1,2,3]
    l2 = lenient_lowercase([1,'a',3])
    assert l2 == [1,'a',3]
    l3 = lenient_lowercase(['A',2,'C'])
    assert l3 == ['a',2,'c']


# Generated at 2022-06-11 01:48:33.057703
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Test', 1, 'Other']) == ['test', 1, 'other'], "List elements should be lowercased"


# Generated at 2022-06-11 01:48:44.365154
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10MB', unit='b') == 10485760
    assert human_to_bytes('10MB', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=True, unit='b') == 10485760

    assert human_to_bytes('10KB') == 10240
    assert human_to_bytes('10Kb') == 10240
    assert human_to_bytes('10KB', unit='b') == 10240
    assert human_to_bytes('10KB', isbits=True) == 10240
    assert human_to_bytes('10Kb', isbits=True, unit='b') == 10240

# Generated at 2022-06-11 01:48:51.485592
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test1 = ['HeLLo', 'WoRLD!']
    result1 = ['hello', 'world!']
    assert lenient_lowercase(test1) == result1

    test2 = ['HeLLo', 123]
    result2 = ['hello', 123]
    assert lenient_lowercase(test2) == result2

    test3 = ['HeLLo', 'WORLD!', 123]
    result3 = ['hello', 'world!', 123]
    assert lenient_lowercase(test3) == result3

# Generated at 2022-06-11 01:49:03.002118
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1.5Tb', isbits=True) == 1649267441664
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1.5Mb', isbits=True) == 1572864
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5Mb') == 1572864

# Generated at 2022-06-11 01:49:12.830514
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2k') == 2048
    assert human_to_bytes('2KB') == 2048
    assert human_to_bytes('2kb') == 2048
    assert human_to_bytes(2, 'K') == 2048
    assert human_to_bytes(2, 'k') == 2048
    assert human_to_bytes(2, 'KB') == 2048
    assert human_to_bytes(2, 'kb') == 2048
    assert human_to_bytes(2) == 2
    assert human_to_bytes(2.5) == 2
    assert human_to_bytes(2.5, 'k') == 2560
    assert human_to_bytes('2.5') == 2
    assert human_to_bytes('2.5', 'k') == 25

# Generated at 2022-06-11 01:49:15.464233
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'a', 'b', 'B', 1, 2]) == ['a', 'a', 'b', 'b', 1, 2]

# Generated at 2022-06-11 01:49:23.457995
# Unit test for function human_to_bytes
def test_human_to_bytes():
    tests = [
        ('10b', 1),
        ('10B', 1),
        ('1K', 1024),
        ('1M', 1024 * 1024),
        ('1G', 1024 * 1024 * 1024),
        ('1T', 1024 * 1024 * 1024 * 1024),
    ]
    tests.extend([
        ('1kb', 1024),
        ('1kb', 1024),
        ('1kb', 1024),
        ('1kb', 1024),
        ('1kb', 1024),
    ])
    tests.extend([
        ('1Kb', 1),
        ('1Kb', 1),
        ('1Kb', 1),
        ('1Kb', 1),
        ('1Kb', 1),
    ])

# Generated at 2022-06-11 01:50:03.570391
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # bits case
    assert human_to_bytes('1 Mb', isbits=True) == 1048576
    # bytes case
    assert human_to_bytes('1 MB') == 1048576
    # unit defined
    assert human_to_bytes('2.2Mb', 'Mb', True) == 2359296
    # unit not defined but isbits=True and unit=b
    assert human_to_bytes('2.2b', True) == 2.2
    # unit not defined but isbits=False and unit=B
    assert human_to_bytes('2.2B') == 2.2
    # unit not defined but isbits=True and unit=B
    assert human_to_bytes('2.2B', isbits=True) == 2.2
    # unit not defined but isbits=False and unit=b
   