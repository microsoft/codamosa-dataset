

# Generated at 2022-06-11 01:40:20.505011
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Positive test
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976
    assert human_to_bytes('1Z') == 1180591620717411303424
    assert human_to_bytes('1Y') == 1208925819614629174706176
    assert human_to_bytes('1', 'K') == 1024

# Generated at 2022-06-11 01:40:28.567097
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KBytes'
    assert bytes_to_human(1098) == '1.07 KBytes'
    assert bytes_to_human(1001002) == '976.56 KBytes'
    assert bytes_to_human(1001002048) == '9.30 GBytes'
    assert bytes_to_human(1001002048, unit='M') == '10219.98 MBytes'
    assert bytes_to_human(1001002048, unit='m') == '10219.98 MBytes'
    assert bytes_to_human(1001002048, unit='k') == '10255330.89 KBytes'
    assert bytes_to_human(1001002048, unit='K') == '10255330.89 KBytes'
    assert bytes_

# Generated at 2022-06-11 01:40:37.729663
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', 'B') == 10485760
    assert human_to_bytes('10M', isbits=True) == 134217728
    assert human_to_bytes('10Mb') == 134217728
    assert human_to_bytes('1.0Mb') == 134217728
    assert human_to_bytes('10M', 'M') == 10485760
    assert human_to_bytes('10M', 'K') == 104857.6
    assert human_to_bytes('10M', 'G') == 0.01
    assert human_to_bytes('10M', 'T') == 0.00001



# Generated at 2022-06-11 01:40:49.430256
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Test module function human_to_bytes '''
    # integer value
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes(1024) == 1024
    assert human_to_bytes(1024, default_unit='B') == 1024
    assert human_to_bytes(1024, default_unit='B') == 1024
    # float value
    assert human_to_bytes(1024.5) == 1024
    assert human_to_bytes('1024.5') == 1024
    assert human_to_bytes(1024.5, default_unit='B') == 1024
    assert human_to_bytes('1024.5', default_unit='B') == 1024
    # spaces
    assert human_to_bytes('1024.5 B') == 1024
    assert human_to_bytes(' 1024.5 B ') == 1024

# Generated at 2022-06-11 01:40:56.793592
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('Testing human_to_bytes()')

# Generated at 2022-06-11 01:41:00.140186
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']



# Generated at 2022-06-11 01:41:01.541431
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Hello', 3]) == ['hello', 3]

# Generated at 2022-06-11 01:41:13.239903
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10) == 10
    assert human_to_bytes('10') == 10
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2K', isbits=True) == '2.00 Kbits'
    assert human_to_bytes('2K', isbits=True, unit='Mb') == '0.02 Mb'
    assert human_to_bytes('2K', isbits=True, unit='B') == '16.00 B'
    assert human_to_bytes('2G', isbits=True) == '2.00 Gbits'
    assert human_to_bytes('2Mbps') == '262.14 Kbps'

# Generated at 2022-06-11 01:41:20.830436
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1KB', 'B') == 1024)
    assert(human_to_bytes('1KB') == 1024)
    assert(human_to_bytes('1K') == 1024)
    assert(human_to_bytes('1MB') == 1048576)
    assert(human_to_bytes('1M') == 1048576)
    assert(human_to_bytes('1GB') == 1073741824)
    assert(human_to_bytes('1G') == 1073741824)
    assert(human_to_bytes('1TB') == 1099511627776)
    assert(human_to_bytes('1T') == 1099511627776)
    assert(human_to_bytes('1PB') == 1125899906842624)

# Generated at 2022-06-11 01:41:31.637450
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test simple string
    assert lenient_lowercase(['A']) == ['a']

    # Test simple list
    assert lenient_lowercase(['A', 'B']) == ['a', 'b']

    # Test list of mixed strings and non-strings
    assert lenient_lowercase(['A', 1]) == ['a', 1]

    # Test list with nested lists and tuples
    assert lenient_lowercase(['A', ['B', 'C'], ('D', 'E')]) == ['a', ['B', 'C'], ('D', 'E')]

    # Test list with nested empty list or tuple
    assert lenient_lowercase(['A', [], ()]) == ['a', [], ()]


# Generated at 2022-06-11 01:41:37.114214
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['aBc', 'dEf', 123, 456]) == ['abc', 'def', 123, 456]



# Generated at 2022-06-11 01:41:39.785945
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 3, 'A', 'B', 'C']) == [1, 3, 'a', 'b', 'c']



# Generated at 2022-06-11 01:41:48.979564
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test the bytes_to_human function.
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, True) == '1.00 bits'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, True) == '8.00 Kb'
    assert bytes_to_human(1024, unit='K') == '1.00 K'
    assert bytes_to_human(1024, unit='M') == '0.00 MB'
    assert bytes_to_human(1024, unit='B') == '1.00 B'
    assert bytes_to_human(1024, unit='b') == '8.00 b'
    assert bytes_to_human(1024, unit='K') == '1.00 K'

# Generated at 2022-06-11 01:41:54.874306
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase([1, 'a', 2, 'B']) == [1, 'a', 2, 'B']


# Generated at 2022-06-11 01:42:05.860026
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert '1.00 Bytes' == bytes_to_human(1)

    assert '1.00 KB' == bytes_to_human(10**3)
    assert '1.00 MB' == bytes_to_human(10**6)
    assert '1.00 GB' == bytes_to_human(10**9)
    assert '1.00 TB' == bytes_to_human(10**12)
    assert '1.00 PB' == bytes_to_human(10**15)
    assert '1.00 EB' == bytes_to_human(10**18)
    assert '1.00 ZB' == bytes_to_human(10**21)
    assert '1.00 YB' == bytes_to_human(10**24)

# Generated at 2022-06-11 01:42:12.225925
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print(bytes_to_human(1000000, isbits=True, unit='b'))
    print(bytes_to_human(10000000, isbits=True, unit='b'))
    print(bytes_to_human(1000000, isbits=True, unit='B'))
    print(bytes_to_human(10000000, isbits=True, unit='B'))
    print(bytes_to_human(1000000, isbits=True, unit='bits'))
    print(bytes_to_human(10000000, isbits=True, unit='bits'))
    print(bytes_to_human(1000000, isbits=True, unit='bits'))
    print(bytes_to_human(10000000, isbits=True, unit='bits'))

# Generated at 2022-06-11 01:42:21.245830
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    for key, value in SIZE_RANGES.items():
        print(key + 'B', value)
    '''
    # bytes
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b') == 10
    # bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    # bytes
    assert human_to_bytes('0B') == 0
    assert human_to_bytes('0b') == 0
    # bytes
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10', 'B') == 10
    assert human_to_bytes('10', 'b') == 10
    # bytes
    assert human_to_bytes('1') == 1

# Generated at 2022-06-11 01:42:28.429529
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_data = {'1K': 1024,
                '2k': 2048,
                '10k': 10240,
                '1M': 1048576,
                '1m': 1048576,
                '1mB': 1048576,
                '1MB': 1048576,
                '1Kb': 8192,
                '1kb': 8192}

    for data in iteritems(test_data):
        assert human_to_bytes(data[0]) == data[1]

# Generated at 2022-06-11 01:42:34.013020
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase([1,2]) == [1,2]
    assert lenient_lowercase(['aB','C','D']) == ['ab','c','d']
    assert lenient_lowercase(['a',None, 23]) == ['a',None,23]
    assert lenient_lowercase(['a','B','z']) == ['a','b','z']


# Generated at 2022-06-11 01:42:40.880129
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(128) == '128 Bytes'
    assert bytes_to_human(128*1024) == '128.00 KB'
    assert bytes_to_human(128*1024*1024) == '128.00 MB'
    assert bytes_to_human(128*1024*1024*1024) == '128.00 GB'
    assert bytes_to_human(128*1024*1024*1024*1024) == '128.00 TB'


# Generated at 2022-06-11 01:42:55.050807
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1B', 'B') == 1
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1KB') == 1000
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1TB') == 1099511627776

# Generated at 2022-06-11 01:43:06.472321
# Unit test for function human_to_bytes
def test_human_to_bytes():

    tests = dict()

    # number
    tests['1'] = 1
    tests['-10'] = -10
    tests['0'] = 0
    tests['1.2'] = 1
    tests['1.6'] = 2
    tests['.6'] = 1
    # units
    tests['1K'] = 1024
    tests['-10K'] = -10240
    tests['1M'] = 1048576
    tests['1G'] = 1073741824
    tests['1T'] = 1099511627776
    tests['1P'] = 1125899906842624
    tests['1E'] = 1152921504606847000
    tests['1Z'] = 1180591620717411303424
    tests['1Y'] = 1208925819614629174706176

    # unit multiplied by 1000


# Generated at 2022-06-11 01:43:18.473936
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1', default_unit='B') == 1)
    assert(human_to_bytes('1', default_unit='K') == 1024)
    assert(human_to_bytes('1', default_unit='M') == 1048576)
    assert(human_to_bytes('1', default_unit='G') == 1073741824)
    assert(human_to_bytes('1', default_unit='T') == 1099511627776)
    assert(human_to_bytes('1', default_unit='P') == 1125899906842624)
    assert(human_to_bytes('1', default_unit='E') == 1152921504606846976)
    assert(human_to_bytes('1', default_unit='Z') == 1180591620717411303424)


# Generated at 2022-06-11 01:43:31.164087
# Unit test for function human_to_bytes
def test_human_to_bytes():
    examples = [
        {'value': '1', 'result': 1, 'unit': None},
        {'value': '1B', 'result': 1, 'unit': 'B'},
        {'value': '1', 'result': 1000, 'unit': 'K'},
        {'value': '1.1K', 'result': 1120, 'unit': 'K'},
        {'value': '1.1', 'result': 1120, 'unit': 'K'},
        {'value': '1.1K', 'result': 1119488, 'unit': 'M'},
        {'value': '1.1M', 'result': 11443264, 'unit': 'M'}]
    for example in examples:
        h2b = human_to_bytes(example['value'], example['unit'])
       

# Generated at 2022-06-11 01:43:37.419957
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase([0]) == [0]
    assert lenient_lowercase(['0']) == ['0']
    assert lenient_lowercase(['0', '1', '2']) == ['0', '1', '2']
    assert lenient_lowercase(['a', 1, 2]) == ['a', 1, 2]
    assert lenient_lowercase(['a', 'A']) == ['a', 'A']
    assert lenient_lowercase(['Hello', 'World']) == ['hello', 'world']
    assert lenient_lowercase(['1k', '2K']) == ['1k', '2K']


# Generated at 2022-06-11 01:43:48.086324
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1B', default_unit='b', isbits=True) == 8
    assert human_to_bytes('2b', default_unit='B', isbits=True) == 2
    assert human_to_bytes('2B', default_unit='b', isbits=True) == 16
    assert human_to_bytes('2K') == 2 * 1024
    assert human_to_bytes('2Kb') == 2 * 1024 * 8
    assert human_to_bytes('2KB') == 2 * 1024
    assert human_to_bytes('2Kb', default_unit='B', isbits=True) == 2 * 1024 * 8
    assert human_to_bytes('2KB', default_unit='b', isbits=True) == 2

# Generated at 2022-06-11 01:43:58.419370
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:44:08.531273
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test bytes with one-char suffix
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1024B') == 1024
    # test bytes with two-char suffix
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1024KB') == 1048576
    # test bytes with one-char uppercase suffix
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1024K') == 1048576
    # test bytes using default unit
    assert human_to_bytes('1', 'B') == 1
    assert human_to_bytes('1', 'KB') == 1024
    assert human_to_bytes('1', 'K') == 1024
    # test bits with one-char suffix

# Generated at 2022-06-11 01:44:13.080886
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    data = ['a', 'B', 'C', 1, 2, 3, {'key': 'value'}]
    expected = ['a', 'b', 'c', 1, 2, 3, {'key': 'value'}]
    assert lenient_lowercase(data) == expected

# Generated at 2022-06-11 01:44:24.342581
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB', 'M') == 1048576
    assert human_to_bytes('1KB', 'K') == 1024
    assert human_to_bytes('1Mb') == 131072
    assert human_to_bytes('1Kb') == 128
    assert human_to_bytes('1Mb', 'Mb') == 131072
    assert human_to_bytes('1Kb', 'Kb') == 128
    assert human_to_bytes('1Mb', isbits=True) == 131072

# Generated at 2022-06-11 01:44:37.170867
# Unit test for function human_to_bytes
def test_human_to_bytes():
    tests = {
        '1': 1,
        '1B': 1,
        '2.3M': 2411520,
        '3.3Mb': 3.3 * 1048576 / 8,
        '4.4Kb': 4.4 * 1024 / 8,
        '5.5m': 5.5 * 1024 * 1024,
        '6.6K': 6.6 * 1024,
        '7.7kB': 7.7 * 1024,
        '8.8KB': 8.8 * 1000,
        '9.9Mb': 9.9 * 1048576 / 8,
    }
    for input_string, expected_result in tests.items():
        result = human_to_bytes(input_string)

# Generated at 2022-06-11 01:44:48.777492
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert('a' == lenient_lowercase(['a'])[0])
    assert('b' == lenient_lowercase(['B'])[0])
    assert(lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c'])
    assert(lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c'])
    assert(lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c'])
    assert(lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c'])
    assert(lenient_lowercase(['a', 'b', 'c', 1]) == ['a', 'b', 'c', 1])

# Generated at 2022-06-11 01:44:56.986421
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """
    Function 'human_to_bytes' unit test
    """
    from __main__ import human_to_bytes
    from ansible.module_utils import basic


# Generated at 2022-06-11 01:45:01.791723
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    l = [0, 1, "a", "A", "Bc", "bC", "def", "DEF"]
    assert(lenient_lowercase(l) == [0, 1, "a", "a", "Bc", "bC", "def", "def"])


# Generated at 2022-06-11 01:45:07.651267
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['TEST', 'TEST', 'TEST']) == ['test', 'test', 'test']
    assert lenient_lowercase(['TEST', 'TEST', 'TEST', [1, 2, 3], 'TEST', 'TEST']) == ['test', 'test', 'test', [1, 2, 3], 'test', 'test']



# Generated at 2022-06-11 01:45:18.468941
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    from ansible.module_utils import basic
    import pytest
    module = basic.AnsibleModule(argument_spec={
        'some_list': {
            'type': 'list',
        },
    })

# Generated at 2022-06-11 01:45:30.724600
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:45:38.751815
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['teststring1', 2, 'teststring3', 4]) == ['teststring1', 2, 'teststring3', 4]
    assert lenient_lowercase(['teststring1', 'teststring2', 'teststring3']) == ['teststring1', 'teststring2', 'teststring3']
    assert lenient_lowercase(['testString1', 'testString2', 'testString3']) == ['teststring1', 'teststring2', 'teststring3']


# Generated at 2022-06-11 01:45:49.801022
# Unit test for function human_to_bytes
def test_human_to_bytes():
    for unit in ['K', 'k', 'KB', 'Kb', 'KiB', 'Kib', 'Ki', 'KiB', 'kb']:
        value = human_to_bytes("10.1 * %s" % unit)
        assert value == 10.1 * SIZE_RANGES[unit[0].upper()]
    # Test bits
    for unit in ['Kb', 'Kbit', 'Kib']:
        value = human_to_bytes("10.1 * %s" % unit, isbits=True)
        assert value == 10.1 * SIZE_RANGES[unit[0].upper()]
    # Test bytes

# Generated at 2022-06-11 01:45:59.923737
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = []
    test_list.append('test')
    test_list.append(1)
    test_list.append('test2')
    test_list.append('TEST')
    test_list.append('Test2')
    test_list.append(123)
    test_list_lower = []
    test_list_lower.append('test')
    test_list_lower.append(1)
    test_list_lower.append('test2')
    test_list_lower.append('TEST')
    test_list_lower.append('Test2')
    test_list_lower.append(123)
    assert(lenient_lowercase(test_list) == test_list_lower)


# Generated at 2022-06-11 01:46:06.349597
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(["A", "B", "C"]) == ["a", "b", "c"]
    assert lenient_lowercase(["A", 1, "B", "C", [1, 2, 3]]) == ["a", 1, "b", "c", [1, 2, 3]]

# Generated at 2022-06-11 01:46:18.425918
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Unit test for function human_to_bytes '''

# Generated at 2022-06-11 01:46:23.817510
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:46:29.527596
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('0M') == 0
    assert human_to_bytes('10Mb') == 13107200
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 13107200
    assert human_to_bytes('10', 'Mb', isbits=True) == 1310720


# Generated at 2022-06-11 01:46:40.212313
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test for bytes
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_

# Generated at 2022-06-11 01:46:51.647481
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:46:56.724799
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['UPPER', 'lower', 'CamelCase']) == ['upper', 'lower', 'camelcase']
    assert lenient_lowercase(['UPPER', 5, 'lower', 'CamelCase']) == ['upper', 5, 'lower', 'camelcase']

# Generated at 2022-06-11 01:47:00.114875
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    my_list = ['a', 1, 'B', 'd']
    assert lenient_lowercase(my_list) == ['a', 1, 'b', 'd']

# Generated at 2022-06-11 01:47:08.485781
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:47:15.475592
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test string
    test_str = ['a', 'B', 'c', None, 0]
    # Result string
    result_str = lenient_lowercase(test_str)
    # Expected string
    expected_str = ['a', 'b', 'c', None, 0]

    # Error message
    error_msg = 'Wrong result value. Expected "%s" got "%s"' % (expected_str, result_str)
    # Test string
    assert result_str == expected_str, error_msg

# Generated at 2022-06-11 01:47:22.298806
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lower_list = lenient_lowercase(['A', 'B', 1, 2])

    assert lower_list == ['a', 'b', 1, 2]



# Generated at 2022-06-11 01:47:25.993200
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_list = ['foo', 'FoO', 'BAR', 3]
    expected_list = ['foo', 'FoO', 'bar', 3]
    assert(lenient_lowercase(input_list) == expected_list)

# Unit tests for function human_to_bytes

# Generated at 2022-06-11 01:47:36.059667
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:47:40.957606
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['abc', 10, [1, 2]]
    result = lenient_lowercase(test_list)
    assert result == ['abc', 10, [1, 2]]

    assert lenient_lowercase([]) == []

    assert lenient_lowercase([10]) == [10]



# Generated at 2022-06-11 01:47:52.490478
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M') == human_to_bytes('10', 'M')

    assert human_to_bytes('10M', isbits=True) == 10485760
    assert human_to_bytes('10M', isbits=True) == human_to_bytes('10', 'M', isbits=True)

    assert human_to_bytes('10kb') == human_to_bytes('10', 'kb') == 10240
    assert human_to_bytes('10Kb') == human_to_bytes('10', 'Kb') == 10240
    assert human_to_bytes('10K', 'b') == human_to_bytes('10Kb') == 10240
    assert human_to_bytes('10k', 'B') == human_

# Generated at 2022-06-11 01:47:57.935247
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Test for lenient_lowercase function."""
    test_input = [{'a': 'b'}, 'A', ['1', 2, '3']]
    test_output = [{'a': 'b'}, 'a', ['1', 2, '3']]
    assert lenient_lowercase(test_input) == test_output

# Generated at 2022-06-11 01:48:01.202278
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["abc", 123]) == ["abc", 123]
    assert lenient_lowercase(["Abc", 123]) == ["abc", 123]


# Generated at 2022-06-11 01:48:12.559494
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K', isbits=False) == 2048
    assert human_to_bytes('2K', isbits=True) == 15 * 1024
    assert human_to_bytes('15Kb', isbits=True) == 15 * 1024
    assert human_to_bytes('15KB', isbits=True) == 15 * 1024
    assert human_to_bytes('15Kb', isbits=False) == 15 * 1000
    assert human_to_bytes('15KB', isbits=False) == 15 * 1000
    assert human_to_bytes('15KB', default_unit='B', isbits=True) == 15 * 1024
    with pytest.raises(ValueError) as excinfo:
        human_to_bytes('15Kb', default_unit='B', isbits=False)

# Generated at 2022-06-11 01:48:16.157307
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list1 = lenient_lowercase(['ABC', 'AbC', 'aBc', 'abC', 1])
    list2 = ['abc', 'abc', 'abc', 'abc', 1]

    assert list1 == list2, "Failed to properly lowercase all string elements"

# Generated at 2022-06-11 01:48:21.380163
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'B', 'C', 'd']) == [1, 'B', 'C', 'd']
    assert lenient_lowercase([1, 'B', 'C', 'd', 'b']) == [1, 'B', 'C', 'd', 'b']
    assert lenient_lowercase(['a', 'B', 'C', 'd', 'b']) == ['a', 'B', 'C', 'd', 'b']



# Generated at 2022-06-11 01:48:36.601807
# Unit test for function human_to_bytes
def test_human_to_bytes():
    tests = [('1', 1),
             ('1B', 1),      # single B
             ('1b', 1),      # single b
             ('1K', 1 << 10),
             ('1M', 1 << 20),
             ('1G', 1 << 30),
             ('1.2M', 1.2 * (1 << 20)),
             ('1.2MB', 1.2 * (1 << 20)),
             ('1.2Mb', 1.2 * (1 << 20)),
             ('1.2Gb', 1.2 * (1 << 30)),
             ('1000', 1000),
             ('1.2Mb', 1.2 * (1 << 20), 'b'),
             ]
    for test in tests:
        expected = test[1]
        result = human_to_bytes(*test[:-1])
        assert expected == result

# Generated at 2022-06-11 01:48:46.910753
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:48:59.441919
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase([None]) == [None]
    assert lenient_lowercase(['']) == ['']
    assert lenient_lowercase([u'']) == [u'']
    assert lenient_lowercase(['A']) == ['a']
    assert lenient_lowercase(['a']) == ['a']
    assert lenient_lowercase([u'A']) == [u'a']
    assert lenient_lowercase([u'a']) == [u'a']
    assert lenient_lowercase([1]) == [1]
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase([u'abC']) == [u'abc']
    assert lenient_lowercase

# Generated at 2022-06-11 01:49:01.620710
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['a', 'B', 1]
    assert ['a', 'b', 1] == lenient_lowercase(lst)

# Generated at 2022-06-11 01:49:06.716486
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Use case 1, for list of string
    input = ['abc', 'ABC', '123', 'ąęć']
    expected = ['abc', 'abc', '123', 'ąęć']
    received = lenient_lowercase(input)
    assert expected == received


# Generated at 2022-06-11 01:49:15.095921
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:49:17.864169
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Unit test for function lenient_lowercase"""
    assert lenient_lowercase(['aBc', 2]) == ['abc', 2]



# Generated at 2022-06-11 01:49:20.114750
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['String', 123, 'string']) == ['string', 123, 'string']



# Generated at 2022-06-11 01:49:23.015942
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ["string", "STRING", 1, 2, ]
    assert lenient_lowercase(test_list) == ["string", "string", 1, 2]

# Generated at 2022-06-11 01:49:34.792219
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['foo', ['b', 'a', 'r']] == lenient_lowercase(['FoO', ['b', 'a', 'r']])
    assert ['foo', ['b', 'a', 'r']] == lenient_lowercase(['FoO', ['b', 'a', 'r']],)
    assert ['foo', ['b', 'a', 'r']] == lenient_lowercase(['FoO', ['b', 'a', 'r']],)
    assert ['foo', ['b', 'a', 'r']] == lenient_lowercase(['FoO', ['b', 'a', 'r']],)
    assert ['foo', ['b', 'a', 'r']] == lenient_lowercase(['FoO', ['b', 'a', 'r']],)


# Unit tests

# Generated at 2022-06-11 01:49:48.869955
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_lst = ["SPIS", "123", 123, ("1", "2", "3", "4"), {"k1": "v1"}]
    expected_lst = ["spis", "123", 123, ("1", "2", "3", "4"), {"k1": "v1"}]
    output_lst = lenient_lowercase(input_lst)
    assert output_lst == expected_lst

# Generated at 2022-06-11 01:49:52.243056
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    arr = ['first', 'second', 1, 2]
    expected = ['first', 'second', 1, 2]
    assert expected == lenient_lowercase(arr)

# Unit tests for function human_to_bytes

# Generated at 2022-06-11 01:49:59.854982
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input = [1, 'One', 'oNe', 1, 2.0, 'test', 'Test', 'tEst', 'tEst', 1, 2, 'test', '1', 2, 'test', None]
    output = [1, 'one', 'one', 1, 2.0, 'test', 'test', 'test', 'test', 1, 2, 'test', '1', 2, 'test', None]
    assert lenient_lowercase(input) == output


# Generated at 2022-06-11 01:50:02.045392
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['hi', 1, 'there']) == ['hi', 1, 'there']

# Generated at 2022-06-11 01:50:10.482707
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1.5G') == 1572864000
    assert human_to_bytes('1.5Gb') == 1572864000
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5Mb') == 1572864
    assert human_to_bytes('1.5K') == 15