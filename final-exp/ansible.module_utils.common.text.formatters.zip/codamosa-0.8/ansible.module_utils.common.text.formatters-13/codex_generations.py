

# Generated at 2022-06-11 01:40:28.595523
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:40:37.729285
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes('10.1M') == 10568320

    assert human_to_bytes('10Mb') == 13107200
    assert human_to_bytes('10Mb', isbits=True) == 13107200
    assert human_to_bytes(13107200, 'b', isbits=True) == 13107200
    assert human_to_bytes('10.1Mb', isbits=True) == 13455996.8

    assert human_to_bytes('10MB', isbits=False) == 10485760
    assert human_to_bytes('10MB', isbits=True) == 133100800

# Generated at 2022-06-11 01:40:49.429955
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # B is an alias of 'Bytes'
    assert human_to_bytes('5B') == 5
    assert human_to_bytes('5b') == 5
    assert human_to_bytes('5') == 5
    assert human_to_bytes('5.5') == 5
    assert human_to_bytes('5.5MB') == 5000000
    assert human_to_bytes('5.5Mb') == 5000000
    assert human_to_bytes('5.5Mb', isbits=True) == 55000
    assert human_to_bytes('5.5', unit='M') == 5500000
    assert human_to_bytes('5.5', unit='Mb') == 5500000
    assert human_to_bytes('5.5', unit='Mb', isbits=True) == 550000
    assert human_to

# Generated at 2022-06-11 01:40:56.792963
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test bytes values
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1024*1024
    assert human_to_bytes('1G') == 1024*1024*1024
    assert human_to_bytes('1T') == 1024*1024*1024*1024
    # Test bits values
    assert human_to_bytes('10Mb', isbits=True) == 1024*1024
    assert human_to_bytes('10Mb') == 10485760
    # Test raw values
    assert human_to_bytes('10') == 10
    # Test raw values with unit argument
    assert human_to_bytes(10, default_unit='K') == 10*1024
    # Test 'b' unit argument
    assert human_to_bytes('10b', default_unit='b') == 10
   

# Generated at 2022-06-11 01:41:08.999932
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='b') == '1.00 bits'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1023) == '1023.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'
    assert bytes_

# Generated at 2022-06-11 01:41:14.933917
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['abc', 'def', 'ghi'] == lenient_lowercase(['abc', 'def', 'ghi'])
    assert ['abc', '', '', 'ghi'] == lenient_lowercase(['abc', '', '', 'ghi'])
    assert ['abc', '', '', []] == lenient_lowercase(['abc', '', '', []])


# Generated at 2022-06-11 01:41:20.354513
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1', 'B') == 1
    assert human_to_bytes(1, 'B') == 1
    assert human_to_bytes('1', 'KB') == 1024
    assert human_to_bytes('1', 'Kb') == 1024
    assert human_to_bytes('1', 'Kb', isbits=True) == 1024
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1mB') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes(1048576, 'B') == 1048576


# Generated at 2022-06-11 01:41:23.245190
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 1, 2]) == ['a', 'b', 1, 2]


# Generated at 2022-06-11 01:41:34.976258
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1024) == '1 KB'
    assert bytes_to_human(1024 * 1024) == '1 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1 PB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1 EB'

# Generated at 2022-06-11 01:41:44.250780
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1KB') == 1000
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1K') == 1000
    assert human_to_bytes('1K') == 1000
    assert human_to_bytes('1.5MB') == 1500000
    assert human_to_bytes('1.5MB') == 1500000
    assert human_to_bytes('1.5gb') == 1600000000
    assert human_to_bytes('1.5Gb') == 1600000000
    assert human_to_bytes('2T') == 2000000000000
    assert human_to_bytes('1.5PB') == 15000000000000000
    assert human_to_bytes('1.5ZB') == 150000000000000000000
    assert human_to_bytes

# Generated at 2022-06-11 01:41:59.792099
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0, isbits=False, unit=None) == '0.00 Bytes'
    assert bytes_to_human(0, isbits=False, unit='B') == '0.00 Bytes'
    assert bytes_to_human(0, isbits=True, unit='b') == '0.00 bits'
    assert bytes_to_human(0, isbits=True, unit=None) == '0.00 bits'
    assert bytes_to_human(1, isbits=False, unit=None) == '1.00 Bytes'
    assert bytes_to_human(1, isbits=False, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, isbits=True, unit='b') == '1.00 bits'
    assert bytes_to_

# Generated at 2022-06-11 01:42:09.113530
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:42:19.168879
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1K', default_unit='K') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1M', unit='M') == 1024 * 1024
    assert human_to_bytes('1Mb', isbits=True, unit='Mb') == 1024 * 1024
    assert human_to_bytes('1M', default_unit='M') == 1024 * 1024

# Generated at 2022-06-11 01:42:25.434235
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2', 'B') == 2
    assert human_to_bytes('2', 'K') == 2 * 1024
    assert human_to_bytes('2.5', 'K') == 2.5 * 1024
    assert human_to_bytes('10M') == 10 * 1024 * 1024
    assert human_to_bytes('2Kb') == 2 * 1024
    assert human_to_bytes('4Mb', isbits=True) == 4 * 1024 * 1024
    assert human_to_bytes('4Gb', isbits=True) == 4 * 1024 * 1024 * 1024
    assert human_to_bytes('1', 'B') == 1
    assert human_to_bytes('1', 'b') == 1
    assert human_to_bytes('1', 'B', isbits=True) == 1
    assert human_to_

# Generated at 2022-06-11 01:42:34.103024
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert lenient_lowercase(['A', 'B', 'C', 'D', 'E']) == ['a', 'b', 'c', 'd', 'e']
    assert lenient_lowercase(['a', 1, 'b', 2, 'c', 3, ['d', 4], 5]) == ['a', 1, 'b', 2, 'c', 3, ['d', 4], 5]
    assert lenient_lowercase([[1, 2], [3, 4], [5, 6]]) == [[1, 2], [3, 4], [5, 6]]

# Generated at 2022-06-11 01:42:45.329383
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Test for function human_to_bytes:
        for case of when the specified unit is 'b' or 'B'
        (=> for case of bits or bytes interpretation)
    '''
    sample_bits_cases = [ '100b', '100B', '100', '100b ', '100b\t', '100\nB', '100\tB' ]
    sample_bytes_cases = ['100', '100B', '100b', '100B ', '100B\t', '100\nB', '100\tB', '100.0B', '100.0 B']
    sample_bytes_cases_default_unit = [ ('100', 'B'), ('100', 'K'), ('100', 'M') ]

# Generated at 2022-06-11 01:42:50.040310
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    original = ['a', 1, 'b', 2, 'c', 'd']
    expected = ['a', 1, 'b', 2, 'c', 'd']
    assert lenient_lowercase(original) == expected


# Generated at 2022-06-11 01:42:58.004992
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == "1.00 Bytes"
    assert bytes_to_human(10) == "10.00 Bytes"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1024*1024) == "1.00 MB"
    assert bytes_to_human(1024*1024*1024) == "1.00 GB"
    assert bytes_to_human(1024*1024*1024*1024) == "1.00 TB"
    assert bytes_to_human(1024*1024*1024*1024*1024) == "1.00 PB"
    assert bytes_to_human(1024*1024*1024*1024*1024*1024) == "1.00 EB"

# Generated at 2022-06-11 01:43:06.224244
# Unit test for function human_to_bytes
def test_human_to_bytes():
    for key, limit in iteritems(SIZE_RANGES):
        assert human_to_bytes('1' + key.upper()) == limit

    assert human_to_bytes('1Kb') == 1000
    assert human_to_bytes('1kb', isbits=True) == 1000
    assert human_to_bytes('500b', isbits=True) == 500

    assert human_to_bytes('1 B') == 1
    assert human_to_bytes('1 bytes') == 1
    assert human_to_bytes('1 byte') == 1
    assert human_to_bytes('1 Byte', isbits=True) == 8
    assert human_to_bytes('0.5 Kb') == 500
    assert human_to_bytes('0.5 Kb', isbits=True) == 500

# Generated at 2022-06-11 01:43:15.922974
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Testing of lenient_lowercase function with single string
    assert isinstance(lenient_lowercase("string"), str)
    # Testing of lenient_lowercase function with string list
    assert isinstance(lenient_lowercase(["string", "string"]), list)
    # Testing of lenient_lowercase function with non-string list
    assert isinstance(lenient_lowercase([1, 2, 3, 5]), list)
    # Testing of lenient_lowercase function with string and non-string list
    assert isinstance(lenient_lowercase(["string", "string", 3, 5]), list)

# Generated at 2022-06-11 01:43:24.012515
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_list = [1, 'A', 'b']
    expected_output = [1, 'a', 'b']
    actual_output = lenient_lowercase(input_list)
    print("expected_output: %s" % expected_output)
    print("  actual_output: %s" % actual_output)
    assert expected_output == actual_output


# Generated at 2022-06-11 01:43:35.085632
# Unit test for function human_to_bytes
def test_human_to_bytes():
    bytes_list = [('2K', 2048),
                  ('2.5M', int(2.5 * 1024 * 1024)),
                  ('0.5K', 512),
                  ('1b', 1),
                  ('0.75MB', int(0.75 * 1024 * 1024)),
                  ('0.75b', 1),
                  ('2B', 2),
                  ('1B', 1),
                  ('1.9M', int(1.9 * 1024 * 1024)),
                  ('1.9b', 1),
                  ('1b', 1),
                  ('11.9Mb', int(11.9 * 1024 * 1024)),
                  ('1.9Mb', int(1.9 * 1024 * 1024)),
                  ('1.9MB', int(1.9 * 1024 * 1024)),
                  ('1.9b', 1),
                  ]
   

# Generated at 2022-06-11 01:43:39.615034
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Test function lenient_lowercase"""
    assert lenient_lowercase(['AaA', 2, 'aAa']) == ['aaa', 2, 'aaa']

# Generated at 2022-06-11 01:43:48.751131
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest
    from functools import partial

    human_to_bytes_t = partial(human_to_bytes, isbits=False)
    human_to_bits_t = partial(human_to_bytes, isbits=True)

    def test_bytes(in_, out):
        assert human_to_bytes_t(in_) == out

    def test_bytes_default_unit_error(in_):
        with pytest.raises(ValueError):
            human_to_bytes_t(in_)

    def test_bytes_unit_error(in_):
        with pytest.raises(ValueError):
            human_to_bytes_t(in_, default_unit='M')


# Generated at 2022-06-11 01:43:58.777715
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1000') == 1000
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1KB') == 1000
    assert human_to_bytes('1M') == 1000000
    assert human_to_bytes('1Mb') == 131072
    assert human_to_bytes('1Mb', isbits=True) == 131072
    assert human_to_bytes('1m') == 1000000
    assert human_to_bytes('1mb') == 131072
    assert human_to_bytes('1mb', isbits=True) == 131072
    assert human_

# Generated at 2022-06-11 01:44:08.660477
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest


# Generated at 2022-06-11 01:44:20.981342
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1B', isbits=True) == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('2K') == 2 << 10
    assert human_to_bytes('2K', isbits=True) == 2 << 10
    assert human_to_bytes('2K', default_unit='B') == 2 << 10
    assert human_to_bytes('2K', default_unit='B', isbits=True) == 2 << 10
    assert human_to_bytes('1MB') == 1 << 20
    assert human_to_bytes('1MB', isbits=True) == 1 << 20

# Generated at 2022-06-11 01:44:29.295092
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # tests for 'B' identifier
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('10b') == ValueError
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10Kb') == ValueError
    assert human_to_bytes('10KB') == 10 * pow(2, 10)
    assert human_to_bytes('10Mb') == ValueError
    assert human_to_bytes('10MB') == 10 * pow(2, 20)
    assert human_to_bytes('10Gb') == ValueError
    assert human_to_bytes('10GB') == 10 * pow(2, 30)
    assert human_to_bytes('10Tb') == ValueError
    assert human_to_bytes('10TB') == 10 * pow(2, 40)


# Generated at 2022-06-11 01:44:38.272330
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:44:42.737841
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_of_values = ['lower', 'upper', 1, 'Mixed', 'multiLines\n123']

    assert lenient_lowercase(list_of_values) == ['lower', 'upper', 1, 'mixed', 'multilines\n123']



# Generated at 2022-06-11 01:44:55.208664
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:45:01.791383
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['foo', 'bar']) == ['foo', 'bar'])
    assert(lenient_lowercase(['foo', 'bar', 3]) == ['foo', 'bar', 3])
    assert(lenient_lowercase(['foo', 'BAR', 'baz']) == ['foo', 'bar', 'baz'])
    assert(lenient_lowercase(['foo', 'bAR', 3]) == ['foo', 'bar', 3])


# Generated at 2022-06-11 01:45:12.230309
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase([1, 'a', 3]) == [1, 'a', 3]
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']

# Unit tests for function human_to_bytes()

# Generated at 2022-06-11 01:45:21.294248
# Unit test for function human_to_bytes
def test_human_to_bytes():
    bytes_number = 2 ** 20
    K = 1 << 10
    M = 1 << 20
    G = 1 << 30
    T = 1 << 40
    hr_format = '%s'

    assert bytes_number == human_to_bytes('%sMB' % hr_format % 1)
    assert int(bytes_number / K) == human_to_bytes('%sKB' % hr_format % 1)
    assert int(bytes_number / M) == human_to_bytes('%sB' % hr_format % 1)
    assert int(bytes_number / G) == human_to_bytes('%sGB' % hr_format % 1)
    assert int(bytes_number / T) == human_to_bytes('%sTB' % hr_format % 1)
    assert int(bytes_number / float(K))

# Generated at 2022-06-11 01:45:31.071277
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test case 1: List with lower and upper case strings, as well as ints
    lc = lenient_lowercase(['abc', 1, 'def'])
    assert(lc == ['abc', 1, 'def'])

    # Test case 2: List with only upper case strings
    lc = lenient_lowercase(['ABC', 'DEF'])
    assert(lc == ['abc', 'def'])

    # Test case 3: List with only lower case strings
    lc = lenient_lowercase(['abc', 'def'])
    assert(lc == ['abc', 'def'])

    # Test case 4: List with only numbers
    lc = lenient_lowercase([1, 2])
    assert(lc == [1, 2])

    # Test case 5: Empty list

# Generated at 2022-06-11 01:45:42.811102
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:45:44.577400
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['a', 'B', 'c', 1, 2, 3]
    test_list_lowercased = ['a', 'b', 'c', 1, 2, 3]
    assert lenient_lowercase(test_list) == test_list_lowercased

# Generated at 2022-06-11 01:45:49.005275
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    '''
    Tests the lenient_lowercase function.
    '''
    test_list = ['A', 'B', 'C']
    result = lenient_lowercase(test_list)
    assert result == ['a', 'b', 'c']


# Generated at 2022-06-11 01:45:56.133491
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    empty_list = []
    assert lenient_lowercase(empty_list) == []

    list_with_strings = ['foo', 'BaR', 'BaZ', 'BaM']
    assert lenient_lowercase(list_with_strings) == ['foo', 'bar', 'baz', 'bam']

    list_with_string_and_number = ['foo', 'BaR', 1, 'BaZ', 'BaM']
    assert lenient_lowercase(list_with_string_and_number) == ['foo', 'bar', 1, 'baz', 'bam']

    list_with_only_number = [1, 2, 3]
    assert lenient_lowercase(list_with_only_number) == [1, 2, 3]


# Generated at 2022-06-11 01:45:57.133078
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'b', 1]

# Generated at 2022-06-11 01:46:03.137724
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    example_list = [1, 'a', 'B', 3, 'C', 'D']
    example_list_lowercase = [1, 'a', 'b', 3, 'c', 'd']

    assert example_list_lowercase == lenient_lowercase(example_list)

# Generated at 2022-06-11 01:46:06.131325
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['apple', 'APPLE', 7, 8, u'ÄÖÜ']) == ['apple', 'apple', 7, 8, u'äöü']

# Unit tests for function human_to_bytes

# Generated at 2022-06-11 01:46:13.577826
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    with open('/proc/meminfo', 'r') as f:
        meminfo = f.read()
    meminfo_list = meminfo.split('\n')
    # swap the first line, which looks like: MemTotal:        8205052 kB
    meminfo_list[0] = 'memtotal:        8205052 kB'
    meminfo_list = lenient_lowercase(meminfo_list)
    assert 'memtotal' in meminfo_list[0]

# Generated at 2022-06-11 01:46:16.549075
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['this', 'THAT', ['and', 'THE', 'other']]) == ['this', 'that', ['and', 'the', 'other']]

# Generated at 2022-06-11 01:46:24.647961
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test case where all elements are strings
    test_list = ['a', 'B', 'c', 'd']
    correct_result = ['a', 'b', 'c', 'd']
    result = lenient_lowercase(test_list)
    assert result == correct_result

    # Test case where one element is an int
    test_list = ['a', 1, 'c', 'd']
    correct_result = ['a', 1, 'c', 'd']
    result = lenient_lowercase(test_list)
    assert result == correct_result


# Unit tests for function human_to_bytes

# Generated at 2022-06-11 01:46:33.606189
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # bytes
    assert human_to_bytes('12') == 12
    assert human_to_bytes('12b') == 12
    assert human_to_bytes('12B') == 12
    assert human_to_bytes('12byte') == 12
    assert human_to_bytes('12bytes') == 12
    assert human_to_bytes('12Byte') == 12
    assert human_to_bytes('12Bytes') == 12
    assert human_to_bytes('12.5') == 12
    assert human_to_bytes('12.5b') == 12
    assert human_to_bytes('12.5B') == 12
    assert human_to_bytes('12.5byte') == 12
    assert human_to_bytes('12.5bytes') == 12
    assert human_to_bytes('12.5Byte') == 12
    assert human

# Generated at 2022-06-11 01:46:41.467015
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_mixed_list = ['A', 'B', 'C', 'D', 'a', 'b', 'c', 'd', 89, 'e', 'E', 'f', 'F', '123', '456', '756', 875]
    test_mixed_list_lowered = ['a', 'b', 'c', 'd', 'a', 'b', 'c', 'd', 89, 'e', 'e', 'f', 'f', '123', '456', '756', 875]
    assert lenient_lowercase(test_mixed_list) == test_mixed_list_lowered



# Generated at 2022-06-11 01:46:44.612653
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['HELLO', 'o']) == ['hello', 'o'])
    assert(lenient_lowercase(['Hello', object()]) == ['hello', object()])

# Generated at 2022-06-11 01:46:56.588059
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1B') == 1)
    assert(human_to_bytes('1b') == human_to_bytes('1b', isbits=True))
    assert(human_to_bytes('1KB', 'K') == 1024)
    assert(human_to_bytes('2.5Mb', 'Mb', isbits=True) == human_to_bytes('2500000b', isbits=True))
    assert(human_to_bytes('2500000b', isbits=True) == human_to_bytes('2.5MB', isbits=True))
    assert(human_to_bytes('1Mb', isbits=True) == human_to_bytes('1024Kb', isbits=True))

# Generated at 2022-06-11 01:47:06.813818
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import assert_equal, assert_raises
    assert_equal(human_to_bytes('10M'), 10485760)
    assert_equal(human_to_bytes('10M', 'B'), 10485760)
    assert_equal(human_to_bytes('10 MB'), 10485760)
    assert_equal(human_to_bytes('10MB'), 10485760)
    assert_equal(human_to_bytes('10 MB', 'B'), 10485760)
    assert_equal(human_to_bytes('10 MB', 'b'), 10485760 * 8)
    assert_equal(human_to_bytes('10 MBytes'), 10485760)
    assert_equal(human_to_bytes('M', 'B'), 1048576)

# Generated at 2022-06-11 01:47:25.248540
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_to_test = []
    expected_result = []
    assert lenient_lowercase(list_to_test) == expected_result

    list_to_test = [
        'AaBbCcDdEeFf',
        1,
        22,
        333,
        4444,
        55555,
        666666,
        7777777,
        88888888,
        'aabbccddeeff',
    ]
    expected_result = [
        'aabbccddeeff',
        1,
        22,
        333,
        4444,
        55555,
        666666,
        7777777,
        88888888,
        'aabbccddeeff',
    ]
    assert lenient_lowercase(list_to_test)

# Generated at 2022-06-11 01:47:35.751260
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import sys

    is_py3 = sys.version_info >= (3,)
    print("Testing python version: %s ..." % sys.version_info)

    #----------------------------------------------------------------------------------------------------
    # Test cases for 'isbits' = False (default value)
    #----------------------------------------------------------------------------------------------------
    # tests for lower case
    assert(human_to_bytes('10b') == 10)
    assert(human_to_bytes('1k') == 1000)
    assert(human_to_bytes('2.5m') == 2500000)
    assert(human_to_bytes('1gb') == 1000000000)
    assert(human_to_bytes('1tb') == 1000000000000)

    # tests for upper case
    assert(human_to_bytes('10B') == 10)
    assert(human_to_bytes('1K') == 1000)


# Generated at 2022-06-11 01:47:40.397295
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_value = [1, 'UPPER', 'lower', 'mixED']
    expected_result = [1, 'upper', 'lower', 'mixed']
    test_result = lenient_lowercase(test_value)
    assert test_result == expected_result



# Generated at 2022-06-11 01:47:51.988872
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_list_strings = ['a', 'B', 'C', 'D']
    result = lenient_lowercase(input_list_strings)
    assert result == ['a', 'b', 'c', 'd']
    input_list_mixed = ['a', 2, 'C', 'D']
    result = lenient_lowercase(input_list_mixed)
    assert result == ['a', 2, 'c', 'd']
    input_list_none = ['a', None, 'C', 'D']
    result = lenient_lowercase(input_list_none)
    assert result == ['a', None, 'c', 'd']
    input_list_mixed_none = ['a', 2, None, 'D']
    result = lenient_lowercase(input_list_mixed_none)

# Generated at 2022-06-11 01:48:04.298234
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Testing size in bytes
    assert human_to_bytes('11MB') == 11*1024*1024
    assert human_to_bytes('11 Mb') == 11*1024*1024
    assert human_to_bytes('11mb') == 11*1024*1024
    assert human_to_bytes('11 mb') == 11*1024*1024
    assert human_to_bytes('11mB') == 11*1024*1024
    assert human_to_bytes('11 mB') == 11*1024*1024
    assert human_to_bytes('11 MB') == 11*1024*1024
    assert human_to_bytes('11 MB') == 11*1024*1024
    assert human_to_bytes('11.5 MB') == 11.5*1024*1024
    assert human_to_bytes('11.5 Mb') == 11.5*1024*1024
   

# Generated at 2022-06-11 01:48:06.433621
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['ABC', 123, 'def']) == ['abc', 123, 'def']

# Generated at 2022-06-11 01:48:16.548558
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(0) == 0
    assert human_to_bytes(1) == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.2') == 1
    assert human_to_bytes('1.7') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1a') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1c') == 1

    assert human_to_bytes('10') == 10
    assert human_to_bytes(10) == 10
    assert human_to_bytes('10a') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10c') == 10

    assert human_to

# Generated at 2022-06-11 01:48:18.942727
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['a12', 'b1', 'C5', 'd5', 'e67'] == lenient_lowercase(['a12', 'b1', 'C5', 2, 3])

# Generated at 2022-06-11 01:48:22.280067
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'b', 'A', 3, 'B', 'C']) == ['a', 'b', 'a', 3, 'b', 'c']
    assert lenient_lowercase(['A']) == ['a']



# Generated at 2022-06-11 01:48:33.448218
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1', 'Mb', True) == 1024 * 1024
    assert human_to_bytes('1Mb', isbits=True) == 1024 * 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1MB') == 1024 * 1024
    assert human_to_bytes('1MB', default_unit='B') == 1024 * 1024
    assert human_to_bytes('1MB', default_unit='B', isbits=True) == 1024 * 1024
    assert human_to_bytes('1MB', isbits=True) == 1024 * 1024
    assert human_to_bytes('1MB', 'b') == 1024 * 1024
    assert human_to_bytes('1MB', 'b', True) == 1024 * 1024

# Generated at 2022-06-11 01:48:55.386229
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_list = [
        0,
        'Hello',
        'World',
        42,
    ]

    output_list = lenient_lowercase(input_list)
    assert output_list[0] == 0
    assert output_list[1] == 'hello'
    assert output_list[2] == 'world'
    assert output_list[3] == 42


# Generated at 2022-06-11 01:48:58.690020
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_list = ['Dog', 'Cat', None, 'Rat']
    assert lenient_lowercase(input_list) == ['dog', 'cat', None, 'rat']

# Generated at 2022-06-11 01:49:05.823217
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_cases = [{'input': ['sOmeThing', 1, 'THiS'], 'expected': ['something', 1, 'this']},
                  {'input': ['this', 1, 'THAT', [1, '2']], 'expected': ['this', 1, 'that', [1, '2']]},
                  {'input': [['tHiS', 1], {'k': 'v'}], 'expected': [['this', 1], {'k': 'v'}]}]
    for test_case in test_cases:
        assert lenient_lowercase(test_case['input']) == test_case['expected']

# Generated at 2022-06-11 01:49:08.449429
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    elems = [1, 'Ab', 33, '']
    assert lenient_lowercase(elems) == [1, 'ab', 33, '']

# Generated at 2022-06-11 01:49:17.094078
# Unit test for function human_to_bytes
def test_human_to_bytes():
    def test(input, expected, expected_err=None, default_unit=None, isbits=False):
        try:
            actual = human_to_bytes(input, default_unit=default_unit, isbits=isbits)
            assert actual == expected
        except Exception as e:
            if expected_err is None:
                print("test_human_to_bytes failed for input %s, expected=%s, isbit=%s, default_unit=%s, got exception=%s, expected_err=%s" % (input, expected, isbits, default_unit, e, expected_err))
                raise

# Generated at 2022-06-11 01:49:21.161288
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['FOO', 'BAR']) == ['foo', 'bar']
    assert lenient_lowercase(['FOO', '2']) == ['foo', '2']
    assert lenient_lowercase(['FOO', 2]) == ['foo', 2]


# Generated at 2022-06-11 01:49:33.226872
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import unittest
    class HumanBytesConversionTests(unittest.TestCase):
        def test_no_unit(self):
            self.assertEqual(human_to_bytes('0'), 0)
            self.assertEqual(human_to_bytes('0', default_unit='b'), 0)
            self.assertEqual(human_to_bytes('42'), 42)
            self.assertEqual(human_to_bytes('42', default_unit='b'), 42)
            self.assertEqual(human_to_bytes('3.14'), 3)
            self.assertEqual(human_to_bytes('3.14', default_unit='b'), 3)
            self.assertEqual(human_to_bytes('1.5'), 1)

# Generated at 2022-06-11 01:49:40.345130
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert [1, 2] == lenient_lowercase([1, 2])
    assert ['1', '2'] == lenient_lowercase(['1', '2'])
    assert ['1', '2', '3'] == lenient_lowercase(['1', '2', '3'])
    assert ['1', '2', 3] == lenient_lowercase(['1', '2', 3])
    assert ['1', '2', '3'] == lenient_lowercase(['1', '2', '3'])
    assert ['1', '2', 3] == lenient_lowercase(['1', '2', 3])
    assert ['1', '2', '3'] == lenient_lowercase(['1', '2', '3'])

# Generated at 2022-06-11 01:49:50.233334
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_cases = {
        '10M': 10485760,
        '100MB': 104857600,
        '1K': 1024,
        '1KB': 1024,
        '1024B': 1024,
        '10K': 10240,
        '10KB': 10240,
        '1M': 1048576,
        '10Mb': 13107200,
        '1Mb': 131072,
        '1KBb': 8192,
        '100b': 13,
        '100Bb': 8400,
        '2E': 2199023255552,
        '2Eb': 2199023255552,
        '2EBb': 175921860444160,
    }


# Generated at 2022-06-11 01:49:54.890575
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['A1', 'a2', '3']
    expected_list = ['a1', 'a2', '3']
    lowercased_list = lenient_lowercase(test_list)

    assert lowercased_list == expected_list