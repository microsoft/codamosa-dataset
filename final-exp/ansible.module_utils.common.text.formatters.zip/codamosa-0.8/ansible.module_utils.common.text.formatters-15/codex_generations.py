

# Generated at 2022-06-11 01:40:26.611257
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_table = [
        ('1B', 1),
        ('1K', 1024),
        ('1.5k', 1536),
        ('2M', 2 * 1024 * 1024),
        ('2.5M', round(2.5 * 1024 * 1024)),
        ('1T', 1 * 1024 * 1024 * 1024 * 1024),
        ('0.01T', 1099511627776),
        ('1Kb', 8192),
        ('1Bb', 8),
        ('1KBB', 1024),
        ('1KBBb', 8192)
    ]
    for test_string, expected_result in test_table:
        assert human_to_bytes(test_string) == expected_result
        assert human_to_bytes(test_string, isbits=True) == expected_result



# Generated at 2022-06-11 01:40:36.138602
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """
    Make sure that a given value is converted to bytes correctly
    """
    assert human_to_bytes('10K') == 10 * 1024
    assert human_to_bytes('10.5M') == 10 * 1024 * 1024 + 512 * 1024
    assert human_to_bytes('10.5K') == 10 * 1024 + 512
    assert human_to_bytes('10.5KB') == 10 * 1024 + 512
    assert human_to_bytes('10.5Kb') == 10 * 1024 + 512
    assert human_to_bytes('10.5Mb') == 10 * 1024 * 1024 + 512 * 1024
    assert human_to_bytes('10.5MB') == 10 * 1024 * 1024 + 512 * 1024
    assert human_to_bytes('10.5Gb') == 10 * 1024 * 1024 * 1024 + 512 * 1024 * 1024

# Generated at 2022-06-11 01:40:46.393790
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['a', 'b', 'c'] == lenient_lowercase(['a', 'b', 'c'])
    assert ['abc', 'def', 'ghi'] == lenient_lowercase(['aBc', 'DeF', 'gHi'])
    assert [1, 'b', 'c'] == lenient_lowercase([1, 'b', 'c'])
    assert [1, [], 'c'] == lenient_lowercase([1, [], 'c'])
    assert [1, 2, 3] == lenient_lowercase(['1', '2', '3'])
    assert ['abc', 'def', 'ghi'] == lenient_lowercase(['aBc', 'DeF', 'gHi'])

# Generated at 2022-06-11 01:40:49.676502
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ["John", "DOE", 1, True]
    lst_lower = ["john", "doe", 1, True]
    assert lenient_lowercase(lst) == lst_lower

# Generated at 2022-06-11 01:40:52.647489
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Abc', 2, [3, 4]]) == ['abc', 2, [3, 4]]



# Generated at 2022-06-11 01:41:00.433341
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == [], "lenient_lowercase did not work for []"
    assert lenient_lowercase(['Hello']) == ['hello'], "lenient_lowercase did not work for ['Hello']"
    assert lenient_lowercase(['Hello', {'world': 1}]) == ['hello', {'world': 1}], "lenient_lowercase did not work for ['Hello', {'world': 1}]"


# Generated at 2022-06-11 01:41:05.709682
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Foo', 'BAR']) == ['foo', 'bar']
    assert lenient_lowercase([{'A': 'a'}, {'b': 'B'}]) == [{'A': 'a'}, {'b': 'B'}]
    assert lenient_lowercase([1, 2]) == [1, 2]



# Generated at 2022-06-11 01:41:16.736034
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1b') == 1)
    assert(human_to_bytes('1B') == 1)
    assert(human_to_bytes('1MB') == 1048576)
    assert(human_to_bytes('10K') == 10240)
    assert(human_to_bytes('10.5M') == 10485760)
    assert(human_to_bytes('10Gb') == 10737418240)
    assert(human_to_bytes('10Z') == 1125899906842624000)
    assert(human_to_bytes('10.5Z') == (1 + 5) * 1125899906842624000)
    assert(human_to_bytes('10.5G') == (1 + 5) * 1073741824)

# Generated at 2022-06-11 01:41:21.529234
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('0') == human_to_bytes(0) == 0
    assert human_to_bytes('2K') == human_to_bytes('2K') == human_to_bytes('   2K   ') == human_to_bytes(2, 'K') == human_to_bytes(2, unit='k') == 2048
    assert human_to_bytes('2M') == human_to_bytes('2M') == human_to_bytes('   2M   ') == human_to_bytes(2, 'M') == human_to_bytes(2, unit='m') == 2097152
    assert human_to_bytes('2G') == human_to_bytes('2G') == human_to_bytes('   2G   ') == human_to_bytes(2, 'G') == human_to_

# Generated at 2022-06-11 01:41:24.720110
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    given = [1, 2, 'AbC']
    expected = [1, 2, 'abc']
    actual = lenient_lowercase(given)
    assert expected == actual

# Generated at 2022-06-11 01:41:38.356756
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import assert_equal
    assert_equal(human_to_bytes('10M'), 10 * (1 << 20))
    assert_equal(human_to_bytes('10Mb', isbits=True), 10 * (1 << 20))
    assert_equal(human_to_bytes('10MB'), 10 * (1 << 20))
    assert_equal(human_to_bytes('10MB', isbits=True), 10 * (1 << 20))
    assert_equal(human_to_bytes('10Mb', unit='b', isbits=False), 10 * (1 << 20))
    assert_equal(human_to_bytes('10Mb', unit='B', isbits=True), 10 * (1 << 20))
    assert_equal(human_to_bytes('10B'), 10)

# Generated at 2022-06-11 01:41:45.878327
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('100') == 100)
    assert(human_to_bytes('100.10') == 100)
    assert(human_to_bytes('100.10B') == 100)
    assert(human_to_bytes('100.10b') == 100)
    assert(human_to_bytes('100.10Kb') == (100 * 1024))
    assert(human_to_bytes('100.10Kb', isbits=True) == (100 * 1024))
    assert(human_to_bytes('100.10MB') == (100 * 1024 * 1024))
    assert(human_to_bytes('100.10Mb') == (100 * 1024 * 1024))
    assert(human_to_bytes('100.10Mb', isbits=True) == (100 * 1024 * 1024))

# Generated at 2022-06-11 01:41:58.595526
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # None value
    assert lenient_lowercase(None) is None
    # Empty list
    assert lenient_lowercase([]) == []
    # Only string value
    assert lenient_lowercase(['a']) == ['a']
    # Only int value
    assert lenient_lowercase([1]) == [1]
    # Only bool value
    assert lenient_lowercase([True]) == [True]
    # Only list value
    assert lenient_lowercase([['a']]) == [['a']]
    # Only dict value
    assert lenient_lowercase([{'a': 'b'}]) == [{'a': 'b'}]
    # Only tuple value
    assert lenient_lowercase([(1, 2)]) == [(1, 2)]
    # String, int and bool value

# Generated at 2022-06-11 01:42:08.397871
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10 * 1024 * 1024
    assert human_to_bytes('5.8M') == int(5.8 * 1024 * 1024)

    assert human_to_bytes('10m', default_unit='B') == 10 * 1024 * 1024
    assert human_to_bytes('5.8m', default_unit='B') == int(5.8 * 1024 * 1024)

    assert human_to_bytes('10m', default_unit='M') == 10
    assert human_to_bytes('5.8m', default_unit='M') == int(5.8)

    assert human_to_bytes('10m', default_unit='b') == 10 * 1000 * 1000
    assert human_to_bytes('5.8m', default_unit='b') == int(5.8 * 1000 * 1000)

# Generated at 2022-06-11 01:42:18.782348
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10.5K') == 10.5 * 1024
    assert human_to_bytes('10.5M') == 10.5 * 1024 * 1024
    assert human_to_bytes('10.5G') == 10.5 * 1024 * 1024 * 1024
    assert human_to_bytes('10.5T') == 10.5 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('10.5P') == 10.5 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('10.5E') == 10.5 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('10.5Z') == 10.5 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('10.5Y') == 10.5

# Generated at 2022-06-11 01:42:29.938252
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("2G") == 2147483648
    assert human_to_bytes("2GB") == 2147483648
    assert human_to_bytes("2Gib") == 2147483648
    assert human_to_bytes("2GiB") == 2147483648
    assert human_to_bytes("2G", "B") == 2147483648
    assert human_to_bytes("2Gi", "B") == 2147483648
    assert human_to_bytes("2GiB", "B") == 2147483648
    assert human_to_bytes("2Gib", "b") == 1073741824
    assert human_to_bytes("2Gi", "") == 2147483648
    assert human_to_bytes("2Gb", isbits=True) == 214748

# Generated at 2022-06-11 01:42:40.421373
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('5.5M') == 5 * 1024 * 1024 * 60 / 100
    assert human_to_bytes('5.5M', isbits=True) == 5 * 1024 * 1024 * 60 / 100
    assert human_to_bytes('5.5MB') == 5.5 * 1024 * 1024
    assert human_to_bytes('5.5Mb', isbits=True) == 5.5 * 1024 * 1024
    assert human_to_bytes('1MB', 'M') == 1024 * 1024
    assert human_to_bytes('1MB', 'K') == 1024 * 1024 * 1024
    assert human_to_bytes('.5MB') == .5 * 1024 * 1024



# Generated at 2022-06-11 01:42:43.285638
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    seq = ['foo', 'bar', 100, 200]
    result = lenient_lowercase(seq)
    assert ['foo', 'bar', 100, 200] == result



# Generated at 2022-06-11 01:42:54.817419
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1, 'B') == 1
    assert human_to_bytes(1.0, 'MB') == 1048576
    assert human_to_bytes('1.0Kb') == 128
    assert human_to_bytes('2Kb') == 256
    assert human_to_bytes('2Kb', isbits=True) == 256
    assert human_to_bytes('2Mb', isbits=True) == 2097152
    assert human_to_bytes('1 MB') == 1048576
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2K') == human_to_bytes('2Kb')
    assert human_to_bytes('2M') == human_to_bytes('2Mb')

# Generated at 2022-06-11 01:43:06.355560
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """
    Function to test bytes_to_human
    :return:
    """
    def test_bth(i, o):
        """
        Function to test function bytes_to_human
        :param i: input of bytes_to_human
        :param o: expected output of bytes_to_human
        :return:
        """
        print("Testing bytes_to_human with input %s and expecting output %s" % (str(i), str(o)))
        res = bytes_to_human(i)
        print("bytes_to_human returned output %s" % str(res))
        assert res == o

    test_bth(1, "1.00 Bytes")
    test_bth(1 << 10, "1.00 KB")
    test_bth(1 << 20, "1.00 MB")


# Generated at 2022-06-11 01:43:20.581186
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # bytes test
    assert human_to_bytes(1) == 1
    assert human_to_bytes(1, 'B') == 1
    assert human_to_bytes(1, 'b') == 1

    assert human_to_bytes('1') == 1
    assert human_to_bytes('1', 'B') == 1
    assert human_to_bytes('1', 'b') == 1

    assert human_to_bytes(1, default_unit='B') == 1
    assert human_to_bytes('1', default_unit='B') == 1

    assert human_to_bytes(1, default_unit='b') == 1
    assert human_to_bytes('1', default_unit='b') == 1

    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1



# Generated at 2022-06-11 01:43:32.652423
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1024) == 1024
    assert human_to_bytes(1024, default_unit='B') == 1024
    assert human_to_bytes(1024, default_unit='K') == 1048576
    assert human_to_bytes(1024, 'K') == 1048576
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K', 'K') == 1024
    assert human_to_bytes('1Kb', isbits = True) == 1024
    assert human_to_bytes('256Mb', isbits = True) == 268435456
    assert human_to_bytes('256MB', isbits = True) == 268435456
    assert human_to_bytes('256Mb', isbits = False) == 268435456

# Generated at 2022-06-11 01:43:44.985138
# Unit test for function bytes_to_human
def test_bytes_to_human():
    inputs = [
        (10, '10 Bytes'),
        (1023, '1023 Bytes'),
        (1024, '1.00 KB'),
        (1048576, '1.00 MB'),
        (1073741824, '1.00 GB'),
        (1099511627776, '1.00 TB'),
        (1125899906842624, '1.00 PB'),
        (1152921504606846976, '1.00 EB'),
        (1180591620717411303424, '1.00 ZB'),
        (1208925819614629174706176, '1.00 YB'),
    ]

    for input, output in inputs:
        assert bytes_to_human(input) == output


# Generated at 2022-06-11 01:43:47.882265
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'ABC', 'Def']) == [1, 'abc', 'def']

# Generated at 2022-06-11 01:43:52.313580
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    sample_list = ['apple', 'Banana', 23, 42.79, 'aaa']
    result = lenient_lowercase(sample_list)
    assert(result == ['apple', 'banana', 23, 42.79, 'aaa'])


# Generated at 2022-06-11 01:44:00.747478
# Unit test for function human_to_bytes
def test_human_to_bytes():
  # Test bytes_to_human
  assert bytes_to_human(1000) == '1.00 KB'
  assert bytes_to_human(1000000) == '1.00 MB'
  assert bytes_to_human(1000000, isbits=True) == '1.00 Mb'
  assert bytes_to_human('1000B') == '1.00 KB'
  assert bytes_to_human('1KB') == '1.00 KB'
  assert bytes_to_human('1MB') == '1.00 MB'
  assert bytes_to_human('1Mb', isbits=True) == '1.00 Mb'
  assert bytes_to_human('1.5MB') == '1.50 MB'
  assert bytes_to_human('1.5MB', isbits=True) == '1.50 Mb'


# Generated at 2022-06-11 01:44:09.454794
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_data = [
        ('test', 'test'),
        ('Test', 'test'),
        ('Test1', 'test1'),
        ([], []),
        ([1, 2], [1, 2]),
        (['1', 2], ['1', 2]),
        ([1, '2'], [1, '2']),
        (['1', '2'], ['1', '2']),
        ([['1', '2']], [['1', '2']]),
    ]

    for input_data, expected_result in test_data:
        result = lenient_lowercase(input_data)
        assert result == expected_result, 'Expected result is %s but got %s' % (expected_result, result)



# Generated at 2022-06-11 01:44:21.700116
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # normal cases
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976
    assert human_to_bytes('1Z') == 1180591620717411303424
    assert human_to_bytes('1Y') == 1208925819614629174706176

    # edge cases
    assert human_to_bytes('1B') == 1

# Generated at 2022-06-11 01:44:30.578349
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_table = [
        ('10B', 10, None),
        ('10b', 10, None, True),
        ('10', 10, 'B'),
        ('10M', 10 * 1024 * 1024, None),
        ('10Mb', 10 * 1024 * 1024, None, True),
        ('10G', 10 * 1024 * 1024 * 1024, None),
        ('1.2K', int(1.2 * 1024), None),
        ('-1.2', -1.2, 'B'),
        ('1.1', 1.1, 'B'),
        ('49.1K', 50 * 1024, None),
        ('3.3T', 3.3 * 1024 * 1024 * 1024 * 1024, None),
        ('-3.3T', -3.3 * 1024 * 1024 * 1024 * 1024, None),
    ]


# Generated at 2022-06-11 01:44:35.935698
# Unit test for function lenient_lowercase

# Generated at 2022-06-11 01:44:52.057252
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1) == 1
    assert human_to_bytes(1.0) == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1') == 1

    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1 << 10

    assert human_to_bytes('1.5Kb') == 1 << 10
    assert human_to_bytes('1.5Mb', isbits=True) == (1 << 20) + (((1 << 20) >> 2))

    # bytes
    assert human_to_bytes('1.5B') == 1
    assert human_to_bytes('1.5B', default_unit='K') == (1 << 10) + (((1 << 10) >> 2))

# Generated at 2022-06-11 01:45:02.441915
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10 * 1024 * 1024
    assert human_to_bytes('10M', default_unit='B') == 10 * 1024 * 1024
    assert human_to_bytes('10B', default_unit='M') == 10
    assert human_to_bytes(10, default_unit='M') == 10
    assert human_to_bytes(10, default_unit='MB') == 10 * 1024 * 1024
    assert human_to_bytes('10.0M') == 10 * 1024 * 1024
    assert human_to_bytes('10.5M') == 11 * 1024 * 1024

    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b', isbits=True) == 1

# Generated at 2022-06-11 01:45:12.033433
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert [] == lenient_lowercase([])
    assert ["a"] == lenient_lowercase(["a"])
    assert [1] == lenient_lowercase([1])
    assert ["a", 1, (1,), [1]] == lenient_lowercase(["a", 1, (1,), [1]])
    assert [1, 2, 3, 4] == lenient_lowercase((1, 2, 3, 4))
    assert [1, 2, 3, 4] == lenient_lowercase([1, 2, 3, 4])
    assert [1, 2, 3, 4] == lenient_lowercase([1, "2", b"3", u"4"])

# Generated at 2022-06-11 01:45:19.261899
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    import pytest
    assert lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase((1, 2, '3')) == [1, 2, '3']
    assert lenient_lowercase((1, 2, ['3'])) == [1, 2, ['3']]


if __name__ == '__main__':
    import pytest
    pytest.main([] + __file__)

# Generated at 2022-06-11 01:45:30.824402
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5MB') == 1572864
    assert human_to_bytes('1.5kb') == 1536
    assert human_to_bytes('1.5KB') == 1536
    assert human_to_bytes('1.5K') == 1536

# Generated at 2022-06-11 01:45:42.748186
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test with default unit argument
    assert human_to_bytes('3.5g') == 3758096384
    # Test with explicit unit argument
    assert human_to_bytes('1.2', 'm') == 12000000
    # Test that number with no unit also works
    assert human_to_bytes('1200') == 1200
    # Test that units are case insensitive
    assert human_to_bytes('100k') == 102400
    assert human_to_bytes('100K') == 102400
    # Test that first char of unit string is used
    assert human_to_bytes('100kbytes') == 102400
    assert human_to_bytes('100Kbytes') == 102400
    # Test that trailing non-unit chars are stripped
    assert human_to_bytes('100Kbytes ') == 102400
    # Test that errors are raised
   

# Generated at 2022-06-11 01:45:52.845690
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, '2', 3, 'ERROR']) == [1, '2', 3, 'ERROR']
    assert lenient_lowercase(['1']) == ['1']
    assert lenient_lowercase(['1', '3', '5']) == ['1', '3', '5']
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['a']) == ['a']
    assert lenient_lowercase(['A']) == ['a']
    assert lenient_lowercase(['a', 'A']) == ['a', 'a']
    assert lenient_lowercase([u'Ł']) == [u'ł']
    assert lenient_lowercase([u'Ł', 'A']) == [u'ł', 'a']

# Unit test

# Generated at 2022-06-11 01:45:57.197281
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['aA', 'BB', 1, 2.0, True, False, [], None]
    assert lenient_lowercase(lst) == ['aa', 'bb', 1, 2.0, True, False, [], None]


# Unit tests for function human_to_bytes

# Generated at 2022-06-11 01:46:07.191805
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Tests without unit
    assert human_to_bytes('10') == 10
    assert human_to_bytes('.10') == 0.1
    assert human_to_bytes('0.10') == 0.1
    assert human_to_bytes('.10K') == 102.4  # Needed by the interface module
    assert human_to_bytes('2147483647') == 2147483647
    assert human_to_bytes('21474836470') == 21474836470
    assert human_to_bytes('-2147483648') == -2147483648

    # Tests of bytes
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('10 b') == 10

    # Tests of kilobytes
   

# Generated at 2022-06-11 01:46:19.135776
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:46:31.205691
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Tests for all cases in human_to_bytes function."""
    assert human_to_bytes('1.1M') == 1167000
    assert human_to_bytes('1.1M', default_unit='M') == 1167000
    assert human_to_bytes('1.0M', default_unit='M') == 1048576
    assert human_to_bytes('1.0M', default_unit='Mb', isbits=True) == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1.1Mb', isbits=True) == 1170000
    assert human_to_bytes('2M', default_unit='M') == 2097152
    assert human_to_bytes('2K') == 2048
    assert human_to

# Generated at 2022-06-11 01:46:41.467569
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test bits output
    assert '1 bit' == bytes_to_human(1, isbits=True)
    assert '1.00 bits' == bytes_to_human(1, isbits=True, unit='B')
    assert '0.01 bits' == bytes_to_human(1, isbits=True, unit='K')
    assert '1048576 bits' == bytes_to_human(1, isbits=True, unit='M')

    # Test Bytes output
    assert '1 B' == bytes_to_human(1, isbits=False, unit='B')
    assert '1 B' == bytes_to_human(1, isbits=False, unit='b')
    assert '0.01 KB' == bytes_to_human(1, isbits=False, unit='K')

# Generated at 2022-06-11 01:46:53.389372
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1') == 1)
    assert(human_to_bytes('1M') == 1048576)
    assert(human_to_bytes('1M', 'B') == 1048576)
    assert(human_to_bytes('10M') == 10485760)
    assert(human_to_bytes('1MB') == 1048576)
    assert(human_to_bytes('1.5Mb', isbits=True) == 1572864)
    assert(human_to_bytes('1.5Mb') == 1572864)
    assert(human_to_bytes('1Mb') == 1048576)
    assert(human_to_bytes('1.5MB', isbits=True) == 1572864)

# Generated at 2022-06-11 01:47:04.672222
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M') == 10 * 1024 * 1024
    assert human_to_bytes('10MB') == 10 * 1024 * 1024
    assert human_to_bytes('10Mb', isbits=True) == 10 * 1024 * 1024
    assert human_to_bytes('10Mb') == human_to_bytes(10, 'Mb') == 10 * 1024 * 1024
    assert human_to_bytes('10MBb') == human_to_bytes(10, 'MBb') == 10 * 1024 * 1024

    assert human_to_bytes('10G') == human_to_bytes(10, 'G') == 10 * 1024 * 1024 * 1024
    assert human_to_bytes('10Gb', isbits=True) == 10 * 1024 * 1024 * 1024
    assert human_to_

# Generated at 2022-06-11 01:47:15.642338
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1 B") == 1
    assert human_to_bytes("1 KB") == 1024
    assert human_to_bytes("1 MB") == 1024 * 1024
    assert human_to_bytes("1 GB") == 1024 * 1024 * 1024
    assert human_to_bytes("1 TB") == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes("1 PB") == 1024 * 1024 * 1024 * 1024 * 1024
    try:
        human_to_bytes("1 PB")
        assert False, "Argument '1 PB' not found to be invalid"
    except ValueError:
        pass
    try:
        human_to_bytes("1 Kb")
        assert False, "Argument '1 Kb' not found to be invalid"
    except ValueError:
        pass

# Generated at 2022-06-11 01:47:23.107584
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(None) == []
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(["a", "B", "C"]) == ["a", "B", "C"]
    assert lenient_lowercase(["a", "B", "C", 7]) == ["a", "B", "C", 7]
    assert lenient_lowercase(["a", "b", "C", 7]) == ["a", "b", "C", 7]


# Generated at 2022-06-11 01:47:33.305595
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0E0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1024 * 1024
    assert human_to_bytes('1.0G') == 1024 * 1024 * 1024
    assert human_to_bytes('1.0T') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.0P') == 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.0E') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.0Z') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024


# Generated at 2022-06-11 01:47:38.203790
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['a', 'b', 1, (1, 2, 3)]) == ['a', 'b', 1, (1, 2, 3)]

# Unit tests for human_to_bytes

# Generated at 2022-06-11 01:47:50.431584
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('1MB') == 1048576

    # test defaults
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1', default_unit='K') == 1024

    assert human_to_bytes('2b') == 1
    assert human_to_bytes('2 bits') == 1
    assert human_to_bytes('7B') == 7
    assert human_to_bytes('3K') == 3072
    assert human_to_bytes('2Kb') == 2048
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 131072

# Generated at 2022-06-11 01:48:02.253763
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.23') == 1
    assert human_to_bytes('1.23b') == 1
    assert human_to_bytes('1.23B') == 1
    assert human_to_bytes('1.23b', isbits=True) == 1.23
    assert human_to_bytes('1.23B', isbits=True) == 12.3
    assert human_to_bytes('1.23kb') == 1.23 * 1024
    assert human_to_bytes('1.23kB') == 1.23 * 1024
    assert human_to_bytes('1.23mb') == 1.23 * 1024 ** 2
    assert human_to_bytes('1.23MB') == 1.23 * 1024 ** 2

# Generated at 2022-06-11 01:48:08.897403
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_list = ['1', 2, 'Two']
    output_list = ['1', 2, 'two']
    assert output_list == lenient_lowercase(input_list)

# Generated at 2022-06-11 01:48:10.738450
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['ABC', 123]) == ['abc', 123]



# Generated at 2022-06-11 01:48:20.125161
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:48:24.992197
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    testcase_true = ['foo', 'bar', 'baz']
    testcase_false = ['foo', 'bar', 'baz', 1]
    assert lenient_lowercase(testcase_true) == ['foo', 'bar', 'baz']
    assert lenient_lowercase(testcase_false) == ['foo', 'bar', 'baz', 1]

# Generated at 2022-06-11 01:48:36.130897
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:48:46.584585
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest
    # negative tests
    with pytest.raises(ValueError) as excinfo:
        human_to_bytes('1Kb', isbits=True)
    assert 'expect Kb or Kbit' in str(excinfo.value)

    with pytest.raises(ValueError) as excinfo:
        human_to_bytes('1b')
    assert 'expect B or byte' in str(excinfo.value)

    with pytest.raises(ValueError) as excinfo:
        human_to_bytes('1', unit='b')
    assert 'expect 1b or 1bit' in str(excinfo.value)

    with pytest.raises(ValueError) as excinfo:
        human_to_bytes('', unit='b')

# Generated at 2022-06-11 01:48:59.110974
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10.1') == 10
    assert human_to_bytes('10.9') == 11
    assert human_to_bytes('10K') == 10 * 1000
    assert human_to_bytes('10M') == 10 * 1000 ** 2
    assert human_to_bytes('10G') == 10 * 1000 ** 3
    assert human_to_bytes('10T') == 10 * 1000 ** 4
    assert human_to_bytes('10P') == 10 * 1000 ** 5
    assert human_to_bytes('10E') == 10 * 1000 ** 6
    assert human_to_bytes('10Z') == 10 * 1000 ** 7
    assert human_to_bytes('10Y') == 10 * 1000 ** 8
    assert human_to_bytes('10b') == 10


# Generated at 2022-06-11 01:49:07.339606
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """
    Test human_to_bytes
    """

# Generated at 2022-06-11 01:49:15.535831
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest
    assert 512 == human_to_bytes('512')
    assert 1024 == human_to_bytes('1K')
    assert 1024 * 1024 * 2 == human_to_bytes('2MB')
    assert 1024 * 1024 * 2 == human_to_bytes('2M')
    assert 1024 * 1024 * 2 == human_to_bytes('2Mb', isbits=True)
    assert 1024 * 1024 * 2 == human_to_bytes('2Mb', default_unit='Mb', isbits=True)
    assert 1024 * 1024 * 2 == human_to_bytes('2MB', default_unit='MB')
    assert 1024 * 1024 * 2 == human_to_bytes('2M', default_unit='M')
    assert 1024 * 1024 * 2 == human_to_bytes('2MB', unit='M')

# Generated at 2022-06-11 01:49:23.463275
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:49:37.245662
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lower_string = 'lower_string'
    upper_string = 'UPPER_STRING'
    string_with_num = 'String99'
    list_of_strings = ['sTring', 'another_string']
    list_of_strings_with_num = ['string1', 'another_string']
    list_of_chars = ['a', 'b', 'c']
    list_of_mixed_type = [1, 2, 'string', lenient_lowercase]

    assert lenient_lowercase(lower_string) == lower_string
    assert lenient_lowercase(upper_string) == upper_string.lower()
    assert lenient_lowercase(string_with_num) == string_with_num

# Generated at 2022-06-11 01:49:42.720603
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['a', 'b', 'C']) == ['a', 'b', 'c'])
    assert(lenient_lowercase(['a', 2, 'C']) == ['a', 2, 'c'])
    assert(lenient_lowercase([2, 'b', 'C']) == [2, 'b', 'c'])


# Generated at 2022-06-11 01:49:47.922149
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [
        'Test',
        'Test',
        'TEST',
        'tEST',
        1
    ]
    assert lenient_lowercase(test_list) == [
        'test',
        'test',
        'test',
        'test',
        1
    ]



# Generated at 2022-06-11 01:49:52.727440
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    ''' Test that lenient_lowercase is case-insensitive and handles non-strings '''
    test_list = ['Foo', 'bar', 'Baz', 1]
    result = lenient_lowercase(test_list)
    assert result == ['foo', 'bar', 'baz', 1]


# Generated at 2022-06-11 01:50:05.113805
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import unittest

    class TestHumanToBytes(unittest.TestCase):
        def test_bytes_to_human(self):
            tests = {
                '1KB': 1024,
                '2K': 2048,
                '0.5K': 512,
                '1M': 1048576,
                '2MB': 2 * 1048576,
                '1.5M': int(1.5 * 1048576),
                '1.5G': int(1.5 * 1073741824),
                '1.5T': int(1.5 * 1099511627776),
            }
            for human, expected in iteritems(tests):
                self.assertEqual(human_to_bytes(human), expected)
                self.assertEqual(human_to_bytes(expected), expected)

# Generated at 2022-06-11 01:50:15.037048
# Unit test for function human_to_bytes