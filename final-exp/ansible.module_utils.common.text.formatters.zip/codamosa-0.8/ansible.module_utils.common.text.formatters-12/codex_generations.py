

# Generated at 2022-06-11 01:40:21.157985
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:40:28.645318
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test case 1
    assert human_to_bytes('100B') == 100

    # Test case 2
    assert human_to_bytes('100b') == 100

    # Test case 3
    assert human_to_bytes('1k') == 1024

    # Test case 4
    assert human_to_bytes('1K') == 1024

    # Test case 5
    assert human_to_bytes('2K') == 2048

    # Test case 6
    assert human_to_bytes('10M') == 10485760

    # Test case 7
    assert human_to_bytes('10m') == 10485760

    # Test case 8
    assert human_to_bytes('1G') == 1073741824

    # Test case 9
    assert human_to_bytes('1g') == 1073741824

    # Test case 10
   

# Generated at 2022-06-11 01:40:33.493752
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase([1, 'two', 3]) == [1, 'two', 3]
    assert lenient_lowercase(['ONE', 'Two', 'Three']) == [1, 'two', 'three']

# Generated at 2022-06-11 01:40:44.517438
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print(human_to_bytes('-1K'))
    print(human_to_bytes('-1K', default_unit='M'))
    print(human_to_bytes('-1K', default_unit='G'))
    print(human_to_bytes('1K'))
    print(human_to_bytes('1K', default_unit='M'))
    print(human_to_bytes('1K', default_unit='G'))
    print(human_to_bytes('-0.5K'))
    print(human_to_bytes('-0.5K', default_unit='M'))
    print(human_to_bytes('-0.5K', default_unit='G'))
    print(human_to_bytes('0.5K'))

# Generated at 2022-06-11 01:40:54.330582
# Unit test for function human_to_bytes
def test_human_to_bytes():
    bytes_to_test = [('1K', 1024), ('10M', 10485760), ('1G', 1073741824), ('137B', 137), ('1MB', 1048576), ('1KB', 1024), ('10Mb', 13107200), ('118.3K', 120970), ('500KB', 512000), ('100MB', 104857600), ('9.78Mb', 1237500), ('1.3T', 137438953472), ('1.3TB', 137438953472), ('1.3Tb', 171798691840), ('1.3Tb', 171798691840), ('1b', 1), ('1B', 1), ('1Kb', 1024), ('1KBb', 1024), ('1KBB', 1024), ('1Bb', 1)]

# Generated at 2022-06-11 01:40:59.638109
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'a', 'b', 2]) == [1, 'a', 'b', 2]
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']



# Generated at 2022-06-11 01:41:10.736533
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('0.5MB') == 524288
    assert human_to_bytes('1.1Mb') == 1153433.6
    assert human_to_bytes('2.2MB', isbits=True) == 2306867.2
    assert human_to_bytes('3.3b') == 0.4125
    assert human_to_bytes('4.4b', isbits=True) == 0.55
    assert human_to_bytes('5.5 kb') == 5632
    assert human_to_bytes('6.6kb', isbits=True) == 6768
    assert human_to_bytes('7.7 MB') == 805306368
    assert human_to_bytes('8.8 MB', isbits=True) == 943718

# Generated at 2022-06-11 01:41:19.786120
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # to bytes
    assert human_to_bytes('2b') == 2
    assert human_to_bytes('2B') == 2
    assert human_to_bytes('2k') == 2048
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2m') == 2097152
    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('2g') == 2147483648
    assert human_to_bytes('2G') == 2147483648

    # to bits
    assert human_to_bytes('2b', isbits=True) == 2
    assert human_to_bytes('2k', isbits=True) == 2048
    assert human_to_bytes('2m', isbits=True) == 2097152
    assert human_to_

# Generated at 2022-06-11 01:41:31.642844
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Unit test for function human_to_bytes."""
    assert human_to_bytes('1000') == 1000
    assert human_to_bytes('1000.0') == 1000
    assert human_to_bytes('1M') == human_to_bytes(1, 'M')
    assert human_to_bytes('1.5M') == human_to_bytes(1.5, 'M')
    assert human_to_bytes(1000, 'b') == 125000
    assert human_to_bytes(1000, 'B') == 1000
    assert human_to_bytes(1024, 'K') == 1024 * 1024
    assert human_to_bytes(1000, 'K') == 1000000
    assert human_to_bytes(1000, 'KB') == 1000000
    assert human_to_bytes(1000, 'KBs') == 1000000

# Generated at 2022-06-11 01:41:42.455138
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:41:45.369595
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    pass

# Generated at 2022-06-11 01:41:48.638648
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'b', 'C']) == [1, 'b', 'c']


# Generated at 2022-06-11 01:41:51.330938
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['One', 'TWO', 3, 4.0]) == ['one', 'two', 3, 4.0]


# Generated at 2022-06-11 01:41:58.793019
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    # Create a list of test string, some will fail when lowercased
    list_to_test = ['test', 1, 'TEST', 'tESt']

    # Lowercase everything using original function
    test_list = list(map(lambda x: x.lower(), list_to_test))

    # Lowercase everything using lenient_lowercase
    test_list_lenient = lenient_lowercase(list_to_test)

    assert test_list_lenient == test_list

# Generated at 2022-06-11 01:42:08.499670
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:42:18.862374
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test basic bytes
    assert human_to_bytes('1M') == 1048576
    # test bits
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    # test for wrong size format
    try:
        human_to_bytes('1MB', unit='c')
    except ValueError:
        pass
    else:
        raise Exception('test failed')
    # test for wrong bit format
    try:
        human_to_bytes('1MB', isbits=True)
    except ValueError:
        pass
    else:
        raise Exception('test failed')
    # test for wrong byte format
    try:
        human_to_bytes('1MB', unit='b')
    except ValueError:
        pass
    else:
        raise Exception('test failed')



# Generated at 2022-06-11 01:42:29.981057
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Tests for function human_to_bytes()
    # Test for valid arguments
    assert human_to_bytes('12') == 12
    assert human_to_bytes('12B') == 12
    assert human_to_bytes('12b') == 12
    assert human_to_bytes('12KB') == 12 * 1024
    assert human_to_bytes('12Kb') == 12 * 1024
    assert human_to_bytes('12MB') == 12 * 1024 * 1024
    assert human_to_bytes('12Mb') == 12 * 1024 * 1024
    assert human_to_bytes('12GB') == 12 * 1024 * 1024 * 1024
    assert human_to_bytes('12Gb') == 12 * 1024 * 1024 * 1024
    assert human_to_bytes('12TB') == 12 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes

# Generated at 2022-06-11 01:42:40.509361
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test the human_to_bytes function
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes(' 1 ') == 1
    assert human_to_bytes('2K') == 2 * (1 << 10)
    assert human_to_bytes('2M') == 2 * (1 << 20)
    assert human_to_bytes('2G') == 2 * (1 << 30)
    assert human_to_bytes('2T') == 2 * (1 << 40)
    assert human_to_bytes('2Kb') == 2 * (1 << 10)
    assert human_to_bytes('2Mb') == 2 * (1 << 20)

# Generated at 2022-06-11 01:42:52.576545
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Check that all the functions in SIZE_RANGES return the right string
    for suffix, limit in SIZE_RANGES.items():
        size = limit
        expected = "1.00 " + suffix + "B"
        # Check that all the functions in SIZE_RANGES return the right string
        for suffix, limit in SIZE_RANGES.items():
            size = limit
            expected = "1.00 " + suffix + "B"
            assert bytes_to_human(size) == expected
            expected = "1.00 " + suffix + "bit"
            assert bytes_to_human(size, isbits=True) == expected
            # Test str conversion
            expected = "1.00 " + suffix + "B"
            assert bytes_to_human(str(size)) == expected

# Generated at 2022-06-11 01:43:03.076558
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Testing with mixed list
    lst = ['A', 1, 'b', 2, 'c']
    lowered = lenient_lowercase(lst)
    assert lowered == ['a', 1, 'b', 2, 'c']
    assert lst == ['A', 1, 'b', 2, 'c']

    # Testing with lowercase list
    lst = ['a', 'b', 'c', 'd']
    lowered = lenient_lowercase(lst)
    assert lowered == ['a', 'b', 'c', 'd']
    assert lst == ['a', 'b', 'c', 'd']


# Generated at 2022-06-11 01:43:11.160211
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lower_data = lenient_lowercase(['aA', 'BB', 'CC'])
    upper_data = lenient_lowercase(['aA', 'BB', 'CC'])
    assert lower_data == ['aa', 'bb', 'cc']
    assert upper_data == ['AA', 'BB', 'CC']


# Generated at 2022-06-11 01:43:19.007946
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1M') == 1048576)
    assert(human_to_bytes('1Mb') == 1048576)
    assert(human_to_bytes('1Mb', isbits=True) == 1048576)
    assert(human_to_bytes('1M', default_unit='b') == 8388608)
    assert(human_to_bytes('1M', default_unit='b', isbits=True) == 8388608)
    assert(human_to_bytes(10, 'M') == 10485760)
    assert(human_to_bytes(10, 'M', isbits=True) == 10485760)
    assert(human_to_bytes(1048576) == 1048576)

# Generated at 2022-06-11 01:43:31.754131
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # Test bytes units
    assert human_to_bytes("4B") == 4
    assert human_to_bytes("4KB") == 4 * 1000
    assert human_to_bytes("4MB") == 4 * 1000 * 1000
    assert human_to_bytes("4GB") == 4 * 1000 * 1000 * 1000
    assert human_to_bytes("4TB") == 4 * 1000 * 1000 * 1000 * 1000
    assert human_to_bytes("4PB") == 4 * 1000 * 1000 * 1000 * 1000 * 1000
    assert human_to_bytes("4EB") == 4 * 1000 * 1000 * 1000 * 1000 * 1000 * 1000
    assert human_to_bytes("4ZB") == 4 * 1000 * 1000 * 1000 * 1000 * 1000 * 1000 * 1000
    assert human_to_bytes("4YB") == 4 * 1000 * 1000 * 1000 * 1000 * 1000

# Generated at 2022-06-11 01:43:36.996839
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase([1]) == [1]
    assert lenient_lowercase(['a']) == ['a']
    assert lenient_lowercase(['A']) == ['a']
    assert lenient_lowercase(['A', 1, 'b']) == ['a', 1, 'b']


# Generated at 2022-06-11 01:43:47.838495
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K', 'B') == 1024
    assert human_to_bytes('1K', 'B', True) == 1024
    assert human_to_bytes(1, 'KB') == 1024
    assert human_to_bytes(1, 'KB', True) == 1024
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Mb', 'B', True) == 10485760
    assert human_to_bytes(10, 'Mb', True) == 10485760
    assert human_to_bytes(10, default_unit='Mb', isbits=True) == 10485760
    assert human_to_bytes('10') == 10

# Generated at 2022-06-11 01:43:58.229296
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import assert_equal, assert_true

    # Test regular case
    assert_equal(1048576, human_to_bytes("1MB"))
    assert_equal(1023052, human_to_bytes("1023KB"))
    assert_equal(1048576, human_to_bytes("1024K"))

    # Test case with floating point
    assert_equal(1048575, human_to_bytes("1.99MB"))
    assert_equal(1048575, human_to_bytes("1.995MB"))
    assert_equal(1048575, human_to_bytes("1.9951MB"))

    # Test case with unit
    assert_equal(1048576, human_to_bytes("1", "MB"))
    assert_equal(1048576, human_to_bytes("10", "KB"))


# Generated at 2022-06-11 01:44:05.678140
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """
    Check that lenient_lowercase will not raise exceptions
    """
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['aBcD']) == ['abcd']
    assert lenient_lowercase(['aBcD', 3, []]) == ['abcd', 3, []]
    assert lenient_lowercase(['aBcD', 3, [], '0123'.upper()]) == ['abcd', 3, [], '0123'.upper()]

# Generated at 2022-06-11 01:44:09.174160
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['A', 'Bb', 'Cc', 1]
    assert lenient_lowercase(lst) == ['a', 'bb', 'cc', 1]



# Generated at 2022-06-11 01:44:21.425140
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes('2000') == human_to_bytes(2, 'KB')
    assert human_to_bytes('2KB') == human_to_bytes('2K') == human_to_bytes(2, 'KB')
    assert human_to_bytes('10Mb') == human_to_bytes('10M', 'b', True) == human_to_bytes(10, 'M', True)
    assert human_to_bytes('2000b') == human_to_bytes('2Kb') == human_to_bytes(2000, 'b', True)

    assert human_to_bytes('1MB') == human_to_bytes(1, 'MB') == human_to_bytes('1M') == human_to_bytes

# Generated at 2022-06-11 01:44:30.098180
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import unittest
    import sys
    from ansible.module_utils.basic import bytes_to_human as B2H
    from ansible.module_utils.basic import human_to_bytes as H2B

    class TestHumanToBytes(unittest.TestCase):
        def test_human_to_bytes(self):
            # Test when bytes identifier is used (uppercase B)
            self.assertEqual(H2B('1K'), int(1024))
            self.assertEqual(H2B('5K'), int(5*1024))

            self.assertEqual(H2B('1M'), int(1024*1024))
            self.assertEqual(H2B('5M'), int(5*1024*1024))


# Generated at 2022-06-11 01:44:40.915571
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == u'1 Bytes'
    assert bytes_to_human(1024) == u'1.00 KBytes'
    assert bytes_to_human(1024 * 1024) == u'1.00 MBytes'
    assert bytes_to_human(1024 * 1024 * 1024) == u'1.00 GBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == u'1.00 TBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == u'1.00 PBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == u'1.00 EBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == u'1.00 ZBytes'

# Generated at 2022-06-11 01:44:52.661595
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:44:55.539485
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    x = [1, 2, 'a', 'b', 'C', 'D']
    assert lenient_lowercase(x) == [1, 2, 'a', 'b', 'c', 'd']



# Generated at 2022-06-11 01:44:58.026151
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M') == human_to_bytes(10, 'm') == 10485760



# Generated at 2022-06-11 01:45:09.386449
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976
    assert human_to_bytes('1Z') == 1180591620717411303424
    assert human_to_bytes('1Y') == 1208925819614629174706176

    assert human_to_bytes('2Mb', isbits=True) == 2097152

# Generated at 2022-06-11 01:45:19.658975
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('10M', 'B') == 10485760)
    assert(human_to_bytes('100kB', 'B') == 102400)
    assert(human_to_bytes('100kB') == 102400)
    assert(human_to_bytes('100Kb', isbits=True) == 102400)
    assert(human_to_bytes('10M', isbits=True) == 10485760)

    try:
        # Lowercase 'b' at the end of a unit is a byte identifier, not bit identifier
        human_to_bytes('10Mb')
        raise Exception('Fail')
    except ValueError:
        pass


# Generated at 2022-06-11 01:45:26.790928
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['keep_me'] == lenient_lowercase(['keep_me'])
    assert ['lowerme'] == lenient_lowercase(['lowerMe'])
    assert ['leave_me', 'lowerme', 'lowerme', 'lowerme'] == lenient_lowercase(['leave_me', 'lowerMe', 'lowerme', 'lowerMe'])



# Generated at 2022-06-11 01:45:37.739523
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == (1048576)
    assert human_to_bytes('1M') == (1048576)
    assert human_to_bytes('1Mb', isbits=True) == (1048576)
    assert human_to_bytes('1MBb', isbits=True) == (1048576)
    assert human_to_bytes('1', 'MB') == (1048576)
    assert human_to_bytes('1b') == (1)
    assert human_to_bytes('1Mb', isbits=True) == (1048576)
    assert human_to_bytes(1, 'MB') == (1048576)
    assert human_to_bytes('1', 'MB', isbits=True) == (1048576)

# Generated at 2022-06-11 01:45:48.955107
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Testing human_to_bytes conversion function. '''
    import pytest
    # Test conversions
    assert(human_to_bytes('10MB') == 10485760)
    assert(human_to_bytes('10M') == 10485760)
    assert(human_to_bytes('10MB', unit='MB') == 10485760)
    assert(human_to_bytes('10MB', unit='m') == 10485760)
    assert(human_to_bytes('10MB', unit='mB') == 10485760)
    assert(human_to_bytes('10MB', unit='b') == 10485760)
    assert(human_to_bytes('10MB', unit='B') == 10485760)
    assert(human_to_bytes('10KB') == 10240)

# Generated at 2022-06-11 01:45:52.846177
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['foo'] == lenient_lowercase(['FOO'])
    assert ['foo', None] == lenient_lowercase(['FOO', None])
    assert ['foo', 0] == lenient_lowercase(['FOO', 0])
    with pytest.raises(AttributeError):
        lenient_lowercase([None])



# Generated at 2022-06-11 01:46:01.196426
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'aA', 'Ab', 'A', 'c', 123, 'eV']) == ['a', 'aA', 'Ab', 'A', 'c', 123, 'eV']


# Generated at 2022-06-11 01:46:09.070016
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Unit test for human_to_bytes function.
    """
    # testing case with no unit specified
    assert human_to_bytes('2') == 2, "Error in human_to_bytes(2) or no default_unit"
    assert human_to_bytes('2.2') == 2, "Error in human_to_bytes(2.2)"
    assert human_to_bytes('2K') == 2048, "Error in human_to_bytes(2K) - expect 2048"
    assert human_to_bytes('2M') == 2097152, "Error in human_to_bytes(2M) - expect 2097152"
    assert human_to_bytes('1Gb') == 1073741824, "Error in human_to_bytes(1Gb) - expect 1073741824"

# Generated at 2022-06-11 01:46:21.057604
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest
    assert human_to_bytes('2000') == 2000, 'An integer number should be returned as integer (2000)'
    assert human_to_bytes('2000B') == 2000, 'B has to be interpreted as Bytes (2000)'
    assert human_to_bytes('1k') == 1 << 10, '1K has to be interpreted as 1024 (1K)'
    assert human_to_bytes('1K') == 1 << 10, '1K has to be interpreted as 1024 (1K)'
    assert human_to_bytes('1k', isbits=True) == 1 << 10, '1K has to be interpreted as 1024 (1K)'
    assert human_to_bytes('1K', isbits=True) == 1 << 10, '1K has to be interpreted as 1024 (1K)'
    assert human_to_bytes('1m')

# Generated at 2022-06-11 01:46:26.227244
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['FOo', 'BaR', 123, 456.789, '', 'bAz']) == \
        ['foo', 'bar', 123, 456.789, '', 'baz']
    try:
        lenient_lowercase(['foo', 'bar', '', 'baz', ['a', 'b', 'c']])
    except AssertionError:
        assert True

# Generated at 2022-06-11 01:46:34.888577
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048576, unit='B') == '1.00 MB'
    assert bytes_to_human(1048576, unit='MB') == '1.00 MB'
    assert bytes_to_human(0, unit='KB') == '0.00 KB'
    assert bytes_to_human(0, unit='K') == '0.00 K'
    assert bytes_to_human(0, unit='KBytes') == '0.00 KBytes'
    assert bytes_to_human(0, unit='Kb') == '0.00 Kb'
 

# Generated at 2022-06-11 01:46:43.453741
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10 * 1024 * 1024
    assert human_to_bytes('10m') == 10 * 1024 * 1024
    assert human_to_bytes('10MB') == 10 * 1024 * 1024
    assert human_to_bytes('10.1MB') == int(10.1 * 1024 * 1024)
    assert human_to_bytes('.1MB') == int(.1 * 1024 * 1024)
    assert human_to_bytes('0.1MB') == int(.1 * 1024 * 1024)
    assert human_to_bytes('10') == 10
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.5') == 2
    assert human_to_bytes('0.1') == 0
    assert human_to_bytes('100M') == 100 * 1024

# Generated at 2022-06-11 01:46:51.893197
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    print('test_lenient_lowercase')
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['x']) == ['x']
    assert lenient_lowercase(['X']) == ['x']
    assert lenient_lowercase(['X', 'y']) == ['x', 'y']
    assert lenient_lowercase(['X', 'y', 'Z']) == ['x', 'y', 'z']
    assert lenient_lowercase(['X', 'y', '1']) == ['x', 'y', '1']



# Generated at 2022-06-11 01:47:03.958196
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """For a set of input values, check that the function"""
    """returns the expected result"""

# Generated at 2022-06-11 01:47:14.966191
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest

    # Test with bytes
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b', isbits=True) == 10
    assert human_to_bytes('1Kb') == 1000
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1K') == 1000

    # Test with bits
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10b', isbits=True) == 10
    assert human_to_bytes('1Kb', isbits=True) == 1000
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1000
    assert human_to_bytes('1Kb', isbits=False) == 1024

# Generated at 2022-06-11 01:47:25.513648
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''Unit test for function bytes_to_human(size, isbits=False, unit=None)'''
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1, isbits=True) == '8 bits'
    assert bytes_to_human(10, isbits=True) == '80 bits'
    assert bytes_to_human(10, isbits=True, unit='Kb') == '8192 bits'
    assert bytes_to_human(10, unit='B') == '10 Bytes'
    assert bytes_to_human(10, unit='B', isbits=True) == '80 bits'
    assert bytes_to_human(10, unit='Mb') == '10240 Bytes'

# Generated at 2022-06-11 01:47:38.025971
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # check lenient_lowercase on list type
    lst = 'MyGreatList'
    assert lenient_lowercase(lst) == ['m', 'y', 'g', 'r', 'e', 'a', 't', 'l', 'i', 's', 't']

    # check lenient_lowercase on tuple type
    lst = ('MyGREATTuple',)
    assert lenient_lowercase(lst) == ['mygreattuple']

    # check lenient_lowercase on string type
    lst = 'MyGREATString'
    assert lenient_lowercase(lst) == ['mygreatstring']

    # check lenient_lowercase on int type
    lst = 42
    assert lenient_lowercase(lst) == [42]


# Generated at 2022-06-11 01:47:50.277621
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lowercased_list = lenient_lowercase([1, 'a', 'b', 2])
    assert lowercased_list == [1, 'a', 'b', 2]

    lowercased_list = lenient_lowercase(['1', 'A', 'b', 2])
    assert lowercased_list == ['1', 'a', 'b', 2]

    lowercased_list = lenient_lowercase(['1', 'a', 'b', '2'])
    assert lowercased_list == ['1', 'a', 'b', '2']

    lowercased_list = lenient_lowercase([None, True, False])
    assert lowercased_list == [None, True, False]

    lowercased_list = lenient_lowercase([])
    assert lowercased_list == []

# Generated at 2022-06-11 01:47:55.209737
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(["ONE"]) == ["one"]
    assert lenient_lowercase(["Two", 3, "four"]) == ["two", 3, "four"]
    assert lenient_lowercase(["first", "second", "THIRD", 4]) == ["first", "second", "third", 4]

# Generated at 2022-06-11 01:48:07.936276
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.3M') == 1376256
    assert human_to_bytes('1.3Mb', isbits=True) == 1048576
    assert human_to_bytes('.5M') == 524288
    assert human_to_bytes('.5Kb', isbits=True) == 512
    assert human_to_bytes('0KB') == 0
    assert human_to_bytes('2') == 2
    assert human_to_bytes('2b', isbits=True) == 2
    assert human_to_bytes('2Bb', isbits=True) == 2
    assert human_to_bytes('2B') == 2
    assert human_to_bytes('2b') == 2

# Generated at 2022-06-11 01:48:17.994114
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test base cases:
    assert human_to_bytes('0') == 0
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824

    # Test negative values:
    assert human_to_bytes('-1') == -1
    assert human_to_bytes('-1K') == -1024

    # Test float values
    assert human_to_bytes('0.5K') == 512
    assert human_to_bytes('0.5M') == 524288

    # Test string with no number in it (should be passed through):
    assert human_to_bytes('1KB') == '1KB'

    # Test case sensitive units:


# Generated at 2022-06-11 01:48:27.517197
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # testing bytes conversion
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1kb') == 1000
    assert human_to_bytes('1Kb') == 1000
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1K') == 1000
    assert human_to_bytes('1K') != 1024
    assert human_to_bytes('10K') == 10000
    assert human_to_bytes('1M') == 1000000
    assert human_to_bytes('1M', isbits=True) == 8388608
    assert human_to_bytes('1G') == 1000000000

# Generated at 2022-06-11 01:48:32.792641
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase([]) == [])
    assert(lenient_lowercase(['A']) == ['a'])
    assert(lenient_lowercase(['A', 1]) == ['a', 1])
    assert(lenient_lowercase(['A', 'B']) == ['a', 'b'])



# Generated at 2022-06-11 01:48:42.884256
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import zip

    module = AnsibleModule(
        argument_spec=dict(
            value=dict(required=True),
            default_unit=dict(type='str', default=None),
            isbits=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    params = module.params
    try:
        result = human_to_bytes(**params)
    except ValueError as e:
        module.fail_json(msg=e.message)

    module.exit_json(changed=False, result=result)



# Generated at 2022-06-11 01:48:44.933677
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['FOO', 'bar', 1, 2]) == ['foo', 'bar', 1, 2]



# Generated at 2022-06-11 01:48:56.823361
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:49:12.890843
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('2Mb') == 1048576
    assert human_to_bytes('300', unit='Kb') == 307200
    assert human_to_bytes('300kb') == 307200
    assert human_to_bytes('150KB') == 153600
    assert human_to_bytes('150KB', isbits=True) == 1228800
    assert human_to_bytes('300b') == 37.5
    assert human_to_bytes('300b', isbits=True) == 300
    assert human_to_bytes('2.5Mb') == 262144
    assert human_to_bytes('5.5Mb', unit='B') == 5632000

# Generated at 2022-06-11 01:49:18.503272
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Test the lenient_lowercase function
    """
    test_input = ['a', 'B', 'abc', 'def', 'ghi', 1234, 1234.45, 123456789]
    expected_output = ['a', 'b', 'abc', 'def', 'ghi', 1234, 1234.45, 123456789]

    assert lenient_lowercase(test_input) == expected_output

# Generated at 2022-06-11 01:49:21.599991
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['a', 'b', 'c'] == lenient_lowercase(['A', 'B', 'C'])
    assert ['a', 1, 'b'] == lenient_lowercase(['A', 1, 'B'])



# Generated at 2022-06-11 01:49:33.332039
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:49:40.394515
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    import json

    string_list = '["Value1", "Value2", "Value3", "Value4", "Value5", "value6", "value7", "value8"]'
    string_dict = '{"key1": "Value1", "key2": "Value2", "key3": "Value3", "key4": "Value4", "key5": "Value5", "key6": "value6", "key7": "value7", "key8": "value8"}'
    string_dict_list = '{"key1": ["Value1", "Value2"], "key2": "Value2", "key3": "Value3", "key4": "Value4", "key5": "Value5", "key6": "value6", "key7": "value7", "key8": "value8"}'
    string_list_

# Generated at 2022-06-11 01:49:50.259511
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:50:02.881936
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import assert_equals
    from nose.tools import assert_raises

    assert_equals(human_to_bytes('10'), 10)
    assert_equals(human_to_bytes('10', unit='B'), 10)
    assert_equals(human_to_bytes('2K'), 2 * 1024)
    assert_equals(human_to_bytes('2K', unit='B'), 2 * 1024)
    assert_equals(human_to_bytes('2M', unit='B'), 2 * 1024 * 1024)
    assert_equals(human_to_bytes('2M', unit='KB'), 2 * 1024 * 1024 / 1024)
    assert_equals(human_to_bytes('2M', unit='KB', isbits=True), 2 * 1024 * 1024)

# Generated at 2022-06-11 01:50:07.885223
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list = [1, 'A', 'B']
    list2 = ['A', 2]

    list_expected = [1, 'a', 'b']
    list_expected2 = ['a', 2]

    list_return = lenient_lowercase(list)
    list_return2 = lenient_lowercase(list2)

    assert list_return == list_expected
    assert list_return2 == list_expected2
