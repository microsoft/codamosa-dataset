

# Generated at 2022-06-11 01:40:26.980565
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:40:36.355137
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # size in bytes (integer) case
    assert human_to_bytes(12) == 12
    assert human_to_bytes(1) == 1
    assert human_to_bytes(0) == 0

    # size in bytes (float) case
    assert human_to_bytes(1.1) == 1
    assert human_to_bytes(0.1) == 0

    # size in bytes (string) case
    assert human_to_bytes("12") == 12
    assert human_to_bytes("1") == 1
    assert human_to_bytes("0") == 0
    assert human_to_bytes("1.1") == 1
    assert human_to_bytes("0.1") == 0
    assert human_to_bytes("1.1B") == 1
    assert human_to_bytes("0.1B") == 0

# Generated at 2022-06-11 01:40:47.652068
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10.5M') == 10485760
    assert human_to_bytes('10.5MB') == 10485760
    assert human_to_bytes('10.5Mb', isbits=True) == 10485760
    assert human_to_bytes('10.5') == 10
    assert human_to_bytes('10.5B') == 11
    assert human_to_bytes('10.5Gb') == 1125899906
    assert human_to_bytes('0.1') == 0

# Generated at 2022-06-11 01:40:55.857653
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_data = (
        ('1MB', 1048576),
        ('1KB', 1024),
        ('1GB', 1073741824),
        ('1Mb', 1048576),
        ('1KB', 1024),
        ('1Mb', 131072),
    )

    for t in test_data:
        try:
            res = human_to_bytes(t[0], 'b')
        except Exception as e:
            raise Exception("'%s' got exception: %s" % (t[0], e))
        assert res == t[1], "'%s' result was %s and not %s" % (t[0], res, t[1])

    # Validate exception handling

# Generated at 2022-06-11 01:40:59.842239
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    expected = [10, 'a', 'z']
    actual = lenient_lowercase([10, 'A', 'Z'])
    assert actual == expected


# Generated at 2022-06-11 01:41:07.519820
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ["foo", "bar", "baz"]
    assert lst == ["foo", "bar", "baz"]

    assert lst == lenient_lowercase(lst)

    lst = ["foo", ["bar"], "baz"]
    assert lst == ["foo", ["bar"], "baz"]

    assert lst == lenient_lowercase(lst)

    lst = ["foo", ["bar", 1], "baz"]
    assert lst == ["foo", ["bar", 1], "baz"]

    assert lst == lenient_lowercase(lst)

# Generated at 2022-06-11 01:41:18.123361
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import sys
    import re
    import random
    import functools

    @functools.wraps(human_to_bytes)
    def random_test(size):
        return random_test.impl(size)

    def setup(impl):
        random_test.impl = impl
        random_test.__test__ = True
        random_test.__wrapped__ = impl
        return random_test

    def test_case(name, test_cases, impl):
        print('== %s ==' % name)
        random_test.impl = setup(impl)
        print('    random:')
        for _ in range(5):
            random.shuffle(test_cases)
            for case in test_cases:
                print('        %s' % case)
                assert random_test(*case[:-1]) == case

# Generated at 2022-06-11 01:41:30.754211
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('100B') == 100
    assert human_to_bytes('100B', isbits=True) == 100
    assert human_to_bytes('100b') == 100
    assert human_to_bytes('100b', isbits=True) == 100
    assert human_to_bytes('1024B') == 1024
    assert human_to_bytes('1024B', isbits=True) == 1024
    assert human_to_bytes('1024b') == 1024
    assert human_to_bytes('1024b', isbits=True) == 1024
    assert human_to_bytes('2048K', isbits=True) == 2097152
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('1.5T') == int(1.5 * 1024 * 1024 * 1024 * 1024)

# Generated at 2022-06-11 01:41:41.710998
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from ansible.module_utils import basic
    import pytest

    # --- test for bytes ---
    assert human_to_bytes('3 B') == 3
    assert human_to_bytes('3B') == 3
    assert human_to_bytes('3') == 3
    assert human_to_bytes('3.0') == 3
    assert human_to_bytes('3.00') == 3
    assert human_to_bytes(3) == 3
    assert human_to_bytes('3k') == 3 * 1024
    assert human_to_bytes('3K') == 3 * 1024
    assert human_to_bytes('3M') == 3 * 1024 * 1024
    assert human_to_bytes('3G') == 3 * 1024 * 1024 * 1024
    assert human_to_bytes('3T') == 3 * 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-11 01:41:54.479011
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """
    Unit test for function human_to_bytes
    """

# Generated at 2022-06-11 01:42:09.434460
# Unit test for function human_to_bytes
def test_human_to_bytes():
    def check(data):
        code, human, isbits, unit, expected = data
        result = human_to_bytes(human, unit, isbits)
        if result != expected:
            print('Test %s failed for following data: %s, got %s instead of %s' % (code, str(data), result, expected))


# Generated at 2022-06-11 01:42:18.506028
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["test", "string"]) == ['test', 'string']
    assert lenient_lowercase(["TEST", "string"]) == ['test', 'string']
    assert lenient_lowercase(["TEST", "STRING"]) == ['test', 'string']
    assert lenient_lowercase(["test", 1, "STRING"]) == ['test', 1, 'string']
    assert lenient_lowercase(["test", 1, "STRING", "TEST", "TEST"]) == ['test', 1, 'string', 'test', 'test']
    assert lenient_lowercase(["1", "2", "3"]) == ['1', '2', '3']

# Generated at 2022-06-11 01:42:29.939000
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import raises
    from nose.plugins.skip import SkipTest

    # testing bytes as input
    assert human_to_bytes('0b') == 0
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('1MB') == (1 << 20)
    assert human_to_bytes('1M') == (1 << 20)
    assert human_to_bytes('1MB', 'B') == (1 << 20)
    assert human_to_bytes('1M', 'B') == (1 << 20)
    assert human_to_bytes('1') == 1

    # testing bits as input
    assert human_to_bytes('0b', isbits=True) == 0

# Generated at 2022-06-11 01:42:40.420687
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Test case for human_to_bytes"""
    test_ok = 'OK'
    test_failed = 'FAILED'

# Generated at 2022-06-11 01:42:44.106383
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    initial = [1, 'a', 'B', 3]
    expected = [1, 'a', 'b', 3]
    actual = lenient_lowercase(initial)
    assert actual == expected, "Unexpected result"



# Generated at 2022-06-11 01:42:55.403022
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:43:06.551799
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Test for human_to_bytes function.
    :return: dictionary with test_name: test_result passed to assertTrue or assertEqual
    '''
    # create dictionary with parameters and expected output

# Generated at 2022-06-11 01:43:18.511440
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K', default_unit='B') == 2048
    assert human_to_bytes('10Mb', default_unit='Kb', isbits=True) == 1250000
    assert human_to_bytes('1K', default_unit='B') == 1024
    assert human_to_bytes('4Mb', default_unit='b', isbits=True) == 4194304
    assert human_to_bytes('4Mb', default_unit='b', isbits=False) == 4194304
    assert human_to_bytes('4Mb', default_unit='b', isbits=False) == 4194304
    assert human_to_bytes('10b', default_unit='b', isbits=False) == 10
    assert human_to_bytes('10b', default_unit='b', isbits=True)

# Generated at 2022-06-11 01:43:21.220246
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    str_list = ['Foo', 1]
    assert lenient_lowercase(str_list) == ['foo', 1]


# Generated at 2022-06-11 01:43:33.093468
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test1 = []
    test2 = ['a','b','c','d']
    test3 = ['a','b','c',1]
    test4 = ['A','B','C','D']
    test5 = ['A','B','C',1]
    test6 = [1,'b','c','d']
    test7 = [1,'B','C','D']
    test8 = [1,'B','C',1]
    test9 = ['a',1,'c','d']
    test10 = ['A',1,'C','D']
    test11 = ['A',1,'C',1]
    test12 = ['a','b',1,'d']
    test13 = ['A','B',1,'D']
    test14 = ['A','B',1,1]

# Generated at 2022-06-11 01:43:43.381521
# Unit test for function human_to_bytes
def test_human_to_bytes():
    for unit, value in iteritems(SIZE_RANGES):
        assert(human_to_bytes('1%s' % unit) == value)
        if unit == 'B':
            assert(human_to_bytes('1%s' % unit.lower(), isbits=True) == 1)
        else:
            assert(human_to_bytes('1%sb' % unit.lower(), isbits=True) == value)

# Generated at 2022-06-11 01:43:50.609664
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('100') == 100
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('10Kb') == 8192
    assert human_to_bytes('1mB') == 1048576
    assert human_to_bytes('10 mb') == 10485760
    assert human_to_bytes('1g') == 1073741824

    try:
        human_to_bytes('10 B')
        assert False
    except ValueError:
        assert True

    try:
        human_to_bytes('10b')
        assert False
    except ValueError:
        assert True

    try:
        human_to_bytes('10 Mb')
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-11 01:43:53.177075
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['abc', 1, 'CdE', None]) == ['abc', 1, 'CdE', None]



# Generated at 2022-06-11 01:43:57.172871
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # function human_to_bytes is tested in modules
    # nxos_facts, nxos_interface, nxos_l2_interface, nxos_linkagg, nxos_snmp_community, nxos_static_routes, nxos_vxlan_vtep
    pass

# Generated at 2022-06-11 01:43:59.523671
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]


# Unit tests for function human_to_bytes

# Generated at 2022-06-11 01:44:03.974392
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["A", "B", "C"]) == ["a", "b", "c"]
    assert lenient_lowercase(["A", "B", 1]) == ["a", "b", 1]


# Generated at 2022-06-11 01:44:16.488376
# Unit test for function human_to_bytes
def test_human_to_bytes():
    cases = [
        ('1M', 1048576, None),
        ('1Mb', 131072, True),
        ('1MB', 131072, True),
        ('1Mb', 131072, False),
        ('1MB', 131072, True),
        ('10MB', 10485760, True),
        ('10MB', 10485760, False),
        ('10M', 10485760, None),
        ('1MB', 1048576, False),
        ('10MB', 10485760, False),
        ('1B', 1, False),
        ('1', 1, None),
        ('1b', 0.125, False),
        ('1b', 1, True),
        ('0.125', 0.125, None),
        ('1024B', 1024, False),
    ]
   

# Generated at 2022-06-11 01:44:26.859172
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import sys
    e = sys.exit

    try:
        human_to_bytes(10)
        e("human_to_bytes(10) failed")
    except ValueError:
        pass

    assert(human_to_bytes('1b') == 1)
    assert(human_to_bytes('1B') == 1)
    assert(human_to_bytes('1') == 1)
    assert(human_to_bytes('1K') == 1024)
    assert(human_to_bytes('1KB') == 1024)
    assert(human_to_bytes('1M') == 1048576)
    assert(human_to_bytes('1MB') == 1048576)
    assert(human_to_bytes('1MB') == 1048576)
    assert(human_to_bytes('1GB') == 1073741824)

# Generated at 2022-06-11 01:44:37.094512
# Unit test for function human_to_bytes
def test_human_to_bytes():
    tests = [
        ('10', 10),
        ('10b', 10),
        ('1b', 1),
    ]
    tests_bits = [
        ('10', 10),
        ('10b', 10),
        ('1b', 1),
        ('10B', 80),
        ('1B', 8),
    ]
    for text, value in tests:
        assert (human_to_bytes(text) == value)
        assert (human_to_bytes(text, default_unit='b') == value)
        assert (bytes_to_human(human_to_bytes(text)) == '%.2f Bytes' % value)

    for text, value in tests_bits:
        assert (human_to_bytes(text, isbits=True) == value)

# Generated at 2022-06-11 01:44:48.676935
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test cases for bytes unit
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1e') == 1
    assert human_to_bytes(' 1  B') == 1
    assert human_to_bytes('1.23') == 1
    assert human_to_bytes('1.23MB') == 1287424
    assert human_to_bytes('0123456789') == 123456789
    assert human_to_bytes('0123456789.12') == 123456789
    assert human_to_bytes('0123456789.12B') == 123456789
    assert human_to_bytes('0123456789.12b') == 123456789


# Generated at 2022-06-11 01:45:03.787481
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Unit test for function human_to_bytes"""

    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('2m') == 2097152
    assert human_to_bytes('18') == 18
    assert human_to_bytes('18.123') == 18
    assert human_to_bytes('18.123M') == 19141128
    assert human_to_bytes('18.123G') == 19648722432
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1kB') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1KB', unit="K") == 1024
    assert human_to_bytes('1K') == human

# Generated at 2022-06-11 01:45:14.438420
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert 1 == human_to_bytes('1')
    assert 1 == human_to_bytes('1B')
    assert 1 == human_to_bytes('1b')
    assert 1024 == human_to_bytes('1K')
    assert 1048576 == human_to_bytes('1M')
    assert 1073741824 == human_to_bytes('1G')
    assert 1099511627776 == human_to_bytes('1T')
    assert 1125899906842624 == human_to_bytes('1P')
    assert 1152921504606846976 == human_to_bytes('1E')
    assert 1180591620717411303424 == human_to_bytes('1Z')
    asser

# Generated at 2022-06-11 01:45:15.727941
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Ansible', 3, 'Rocks']) == ['ansible', 3, 'rocks']



# Generated at 2022-06-11 01:45:21.666162
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:45:31.201534
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(0, 'B') == 0
    assert human_to_bytes(0, 'KB') == 0
    assert human_to_bytes(0, 'MB') == 0
    assert human_to_bytes(0, 'GB') == 0
    assert human_to_bytes(0, 'TB') == 0
    assert human_to_bytes(0, 'b') == 0
    assert human_to_bytes(0, 'kb') == 0
    assert human_to_bytes(0, 'Mb') == 0
    assert human_to_bytes(0, 'Gb') == 0
    assert human_to_bytes(0, 'Tb') == 0

    assert human_to_bytes(1023, 'B') == 1023
    assert human_to_bytes(1023, 'KB') == 1023
   

# Generated at 2022-06-11 01:45:34.343275
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', None, 0, u'D']) == ['a', 'b', 'c', None, 0, u'd']


# Generated at 2022-06-11 01:45:35.914474
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_test = ['abCd', 'efgh', 1, 'iJkl']
    assert lenient_lowercase(list_test) == ['abcd', 'efgh', 1, 'ijkl']


# Generated at 2022-06-11 01:45:36.984206
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['ABC', 'DEF', 1]) == ['abc', 'def', 1]



# Generated at 2022-06-11 01:45:48.352715
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1) == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1B', 'B') == 1

    assert human_to_bytes("1K") == 1024
    assert human_to_bytes("10M") == 10485760
    assert human_to_bytes("1G") == 1073741824
    assert human_to_bytes("1T") == 1099511627776
    assert human_to_bytes("1P") == 1125899906842624
    assert human_to_bytes("1E") == 1152921504606846976
    assert human_to_bytes("1Z") == 1180591620717411303424
    assert human_to_bytes("1Y") == 1208925819614629174706176

    assert human

# Generated at 2022-06-11 01:45:53.493889
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test basic functionality
    assert lenient_lowercase(['1', 'ab', 'cde']) == ['1', 'ab', 'cde']
    assert lenient_lowercase(['1', 'AB', 'CDE']) == ['1', 'ab', 'cde']

    # Test functionality with non-strings
    assert lenient_lowercase(['1', ['a', 'b'], 5]) == ['1', ['a', 'b'], 5]



# Generated at 2022-06-11 01:46:12.628460
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Test the human_to_bytes function"""


# Generated at 2022-06-11 01:46:15.708556
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(['A', 'B', 1, 2, object()])
    assert result == ['a', 'b', 1, 2, object()]



# Generated at 2022-06-11 01:46:26.102352
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.5M') == 1572864

    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1Mb', True) == 1048576
    assert human_to_bytes('1.5MB', True) == 1572864
    assert human_to_bytes('1.5Mb', True) == 1572864

    assert human_to_bytes('1b', True) == 1
    assert human_to_bytes('1bit', True) == 1
    assert human_to_bytes('1B', True) == 8
    assert human_to_bytes('1Byte', True) == 8


# Generated at 2022-06-11 01:46:36.403110
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test default
    result = human_to_bytes('12000')
    assert result == 12000

    # Test bytes
    result = human_to_bytes('11B')
    assert result == 11

    result = human_to_bytes('12.3B')
    assert result == 12.3

    result = human_to_bytes('12.3b')
    assert result == 12.3

    result = human_to_bytes('1.2kb')
    assert result ==  1220

    result = human_to_bytes('12.3mb')
    assert result == 12.3 * (1 << 20)

    result = human_to_bytes('12.3gb')
    assert result == 12.3 * (1 << 30)

    result = human_to_bytes('12.3tb')
    assert result == 12.3

# Generated at 2022-06-11 01:46:42.038004
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('2G') == 2147483648
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('2.5G') == 2684354560



# Generated at 2022-06-11 01:46:46.263153
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    mylist = [1, 2, 3, 'A', 'B', 'C']
    mylist = lenient_lowercase(mylist)
    assert mylist == [1, 2, 3, 'A', 'B', 'C']


# Generated at 2022-06-11 01:46:57.698917
# Unit test for function human_to_bytes
def test_human_to_bytes():
    t1 = '1'
    r1 = human_to_bytes(t1)
    assert 1 == r1

    t2 = '1 KB'
    r2 = human_to_bytes(t2)
    assert 1024 == r2

    t3 = '1.1 KB'
    r3 = human_to_bytes(t3)
    assert 1 == int(r3 / 1024)

    t4 = '1.9 KB'
    r4 = human_to_bytes(t4)
    assert 2 == int(r4 / 1024)

    t5 = '1 B'
    r5 = human_to_bytes(t5)
    assert 1 == r5

    t6 = '1023 B'
    r6 = human_to_bytes(t6)
    assert 1023 == r6


# Generated at 2022-06-11 01:47:05.840685
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['AbCdEf', 'GhIjKl', 'MnOpQr']) == ['abcdef', 'ghijkl', 'mnopqr']
    assert lenient_lowercase(['AbCdEf', 1, 'MnOpQr']) == ['abcdef', 1, 'mnopqr']
    assert lenient_lowercase(['AbCdEf', ['N', 'O', 'P'], {'Q', 'R'}]) == ['abcdef', ['N', 'O', 'P'], {'Q', 'R'}]



# Generated at 2022-06-11 01:47:09.002205
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    my_list = ['One', 2, 'Apples']
    assert lenient_lowercase(my_list) == ['one', 2, 'apples']



# Generated at 2022-06-11 01:47:18.398235
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1024') == 1024, "unexpected value for '1024'"
    assert human_to_bytes('1M') == 1048576, "unexpected value for '1M'"
    assert human_to_bytes('1Mb', True) == 1048576, "unexpected value for '1Mb'"
    assert human_to_bytes('5MB') == 5 * 1048576, "unexpected value for '5MB'"
    assert human_to_bytes('5Mb', True) == 5 * 1048576, "unexpected value for '5Mb'"
    assert human_to_bytes('1024k') == 1024 * 1000, "unexpected value for '1024k'"
    assert human_to_bytes('1024b', True) == 1024, "unexpected value for '1024b'"

# Generated at 2022-06-11 01:47:40.397058
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase(['A', 2, 3]) == ['a', 2, 3]

# Generated at 2022-06-11 01:47:51.989060
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes(1048576) == 1048576
    assert human_to_bytes(1.0) == 1
    assert human_to_bytes('0.1') == 0
    assert human_to_bytes('0.1B') == 0

# Generated at 2022-06-11 01:47:54.631322
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_array = [u'aBc', 'def', 1]
    assert lenient_lowercase(test_array) == ['abc', 'def', 1]


# Generated at 2022-06-11 01:48:07.357865
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import assert_equals
    from nose.tools import assert_raises
    assert_equals(human_to_bytes(10), 10)
    assert_equals(human_to_bytes(10, 'K'), 10240)
    assert_equals(human_to_bytes(2, 'MB'), 2097152)
    assert_equals(human_to_bytes(1.5, 'MB'), 1572864)
    assert_equals(human_to_bytes(1, 'b'), 0.125)
    assert_equals(human_to_bytes(1, 'b', True), 1)
    assert_equals(human_to_bytes(8, 'B'), 1)
    assert_equals(human_to_bytes(8, 'KB'), 1024)

# Generated at 2022-06-11 01:48:17.517403
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1k', isbits=True) == 1024
    assert human_to_bytes('2M') == 2 * 1024 * 1024
    assert human_to_bytes('2Mb', isbits=True) == 2 * 1024 * 1024
    assert human_to_bytes('2G') == 2 * 1024 * 1024 * 1024
    assert human_to_bytes('2Gb', isbits=True) == 2 * 1024 * 1024 * 1024

# Generated at 2022-06-11 01:48:23.931003
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
    assert lenient_lowercase(['a', 1, 'c', 'd']) == ['a', 1, 'c', 'd']
    assert lenient_lowercase(['a', 'B', 'C', 'd']) == ['a', 'b', 'c', 'd']
    assert lenient_lowercase(['a', 'B', None, 'd']) == ['a', 'b', None, 'd']


# Generated at 2022-06-11 01:48:35.021876
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import ansible.module_utils.network.common.utils as utils

    test1 = '42'
    test2 = '42kb'
    test3 = '42Mb'
    test4 = '42Gb'
    test5 = '42TB'
    test6 = '42eB'
    test7 = '42PB'
    test8 = '42ZB'
    test9 = '42YB'
    test10 = '42.2B'
    test11 = '42.2'

    result1 = utils.human_to_bytes(test1)
    result2 = utils.human_to_bytes(test2)
    result3 = utils.human_to_bytes(test3, isbits=True)
    result4 = utils.human_to_bytes(test4)
    result5

# Generated at 2022-06-11 01:48:45.861538
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Tests for human_to_bytes function '''

# Generated at 2022-06-11 01:48:57.912722
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test size to bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1GB') == 1073741824

    # test float
    assert human_to_bytes('0.5KB') == 512

    # test with unit
    assert human_to_bytes(1, 'GB') == 1073741824

    # test lower/upper case
    assert human_to_bytes('1kB') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1KB') == 1024

    # test bits

# Generated at 2022-06-11 01:49:04.444808
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('--> Unit test for function human_to_bytes')
    print('--- test_human_to_bytes')
    for num in ('2K', '2M', '2G', '2T', '2P', '2E', '2Z', '2Y'):
        print(num, '=', human_to_bytes(num))
    print('--- test_human_to_bytes isbits=True')
    for num in ('2Kb', '2Mb', '2Gb', '2Tb', '2Pb', '2Eb', '2Zb', '2Yb'):
        print(num, '=', human_to_bytes(num, isbits=True))
    print('--- test_human_to_bytes unit=b')

# Generated at 2022-06-11 01:49:47.318820
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10m') == 10485760
    assert human_to_bytes('10mb') == 10485760
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10Kb') == 81920

    # Check that ValueError exception is thrown in the following conditions
    try:
        human_to_bytes('10MB', isbits=True)
    except ValueError:
        pass

# Generated at 2022-06-11 01:49:49.316034
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['ONE', 'two', 3]) == ['one', 'two', 3]



# Generated at 2022-06-11 01:50:01.551882
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:50:10.198081
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # 10 values with unit
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1KB') == 1000
    assert human_to_bytes('1.0Kb') == 1000
    assert human_to_bytes('1Mb', isbits=True) == 1000000
    with pytest.raises(ValueError):
        assert human_to_bytes('1MB', isbits=True)
    assert human_to_bytes('1.0MB') == 1000000
    assert human_to_bytes('1.0.0M') == 1000000

    # 10 values without unit