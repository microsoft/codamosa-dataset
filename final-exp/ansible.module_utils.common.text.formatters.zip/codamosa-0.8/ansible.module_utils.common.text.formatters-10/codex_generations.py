

# Generated at 2022-06-11 01:40:20.969928
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test basic functionality
    res = human_to_bytes("1", default_unit='b')
    assert res == 1, "human_to_bytes('1') failed, value %d was returned" % res
    res = human_to_bytes("1", default_unit='B')
    assert res == 1, "human_to_bytes('1') failed, value %d was returned" % res
    res = human_to_bytes("1", default_unit='b', isbits=True)
    assert res == 1, "human_to_bytes('1') failed, value %d was returned" % res

    # test for different units
    res = human_to_bytes("1", default_unit='K')
    assert res == 1024, "human_to_bytes('1') failed, value %d was returned" % res
    res = human_

# Generated at 2022-06-11 01:40:28.596028
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2k') == 2048
    assert human_to_bytes('2M') == 2 * 1024 * 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10.9M') == 11 * 1024 * 1024
    assert human_to_bytes('1.1M') == 1024 * 1024
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.1.1') == 111
    assert human_to_bytes('M') == None
    assert human_to_bytes('') == None

    assert human_to_bytes('2K', 'M') == 2048 / 1024
    assert human_to_bytes('2k', 'm') == 2048 / 1024
    assert human_

# Generated at 2022-06-11 01:40:37.772484
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10) == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5k') == 1536
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5Kb', isbits=True) == 1536
    assert human_to_bytes('1.5Mb', isbits=True) == 1572864
    assert human_to_bytes('1.5Mb', isbits=False) == 1572864
    assert human_to_bytes('1.5M', isbits=True) == 1572864

# Generated at 2022-06-11 01:40:43.929598
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [1, 'a', 'b', 'c', 2, 'd', 'E']
    assert lenient_lowercase(lst) == [1, 'a', 'b', 'c', 2, 'd', 'e']
    lst = ['A', 1, 'B', 2, 'C']
    assert lenient_lowercase(lst) == ['a', 1, 'b', 2, 'c']

# Generated at 2022-06-11 01:40:48.843765
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['aBcD', 'EFgh', 1, 2, 3, True, False]
    result = ['abcd', 'efgh', 1, 2, 3, True, False]
    assert lenient_lowercase(lst) == result
    assert lenient_lowercase([]) == []


# Generated at 2022-06-11 01:40:56.500281
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Test cases for human_to_bytes:
    # Case 1: Both number and unit are specified
    # Case 2: No unit specified, but one specified as second argument
    # Case 3: Both number and unit are specified, where unit is given in lower case
    # Case 4: Only number is specified
    # Case 5: Invalid parameters are passed
    # Case 6: check behavior with bits instead of bytes
    # Case 7: Invalid parameters (bits) are passed
    '''

# Generated at 2022-06-11 01:41:08.941992
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert '1.00 B' == bytes_to_human(human_to_bytes('1'))
    assert '1.00 kB' == bytes_to_human(human_to_bytes('1k'))
    assert '1.00 MB' == bytes_to_human(human_to_bytes('1m'))
    assert '1.00 GB' == bytes_to_human(human_to_bytes('1g'))
    assert '1.00 TB' == bytes_to_human(human_to_bytes('1t'))
    assert '1.00 KB' == bytes_to_human(human_to_bytes('1KB'))
    assert '1.00 MB' == bytes_to_human(human_to_bytes('1MB'))

# Generated at 2022-06-11 01:41:18.674175
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("Test: human_to_bytes()")

    # Tuple of (string, unit, isbit, result):

# Generated at 2022-06-11 01:41:22.883132
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [4, "hi", "", "3", "Ho", None]
    assert lenient_lowercase(lst) == [4, "hi", "", "3", "ho", None]



# Generated at 2022-06-11 01:41:34.574222
# Unit test for function human_to_bytes
def test_human_to_bytes():
    val_raw_number = 100
    val_bytes = '5B'
    val_bytes_with_spaces = '   6 B'
    val_bytes_Kb = '5 Kb'
    val_bytes_mb_lowercase = '5mb'
    val_bytes_gb_uppercase = '5GB'
    val_bytes_tb_mixedcase = '5Tb'
    val_bytes_wrong_byte_value = '5C'
    val_bytes_wrong_bit_value = '5KbB'
    val_bytes_wrong_unit = '1MZ'

    assert human_to_bytes(val_raw_number) == val_raw_number
    assert human_to_bytes(val_bytes) == 5

# Generated at 2022-06-11 01:41:46.188638
# Unit test for function bytes_to_human
def test_bytes_to_human():
    tests = [
        (1, '1 Bytes'),
        (1024, '1.02 KB'),
        (1048576, '1.05 MB'),
        (1073741824, '1.07 GB'),
        (1099511627776, '1.10 TB'),
        (1125899906842624, '1.13 PB'),
        (1152921504606846976, '1.15 EB'),
        (1180591620717411303424, '1.18 ZB'),
        (1208925819614629174706176, '1.21 YB')
    ]

    for size, result in tests:
        assert bytes_to_human(size) == result


# Generated at 2022-06-11 01:41:52.201378
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['SOMETHING', 'Something Else']) == ['something', 'Something Else']
    assert lenient_lowercase(['SOMETHING', 2]) == ['something', 2]
    assert lenient_lowercase(['lowercase', 'ALLCAPS'],) == ['lowercase', 'allcaps']

# Generated at 2022-06-11 01:42:03.824924
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:42:06.885162
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [1, 'Abc', 'def', 3]
    expected = [1, 'abc', 'def', 3]
    result = lenient_lowercase(lst)
    assert list.__eq__(result, expected)

# Generated at 2022-06-11 01:42:16.825858
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'b']) == ['a', 'b']
    assert lenient_lowercase(['A', 'b', 5]) == ['a', 'b', 5]

    # function should raise exception if element is not string nor number
    try:
        lenient_lowercase(['A', 'b', []])
        assert False
    except AttributeError:
        assert True
    except Exception:
        assert False

    # function should raise exception if element is a string, but not a valid string
    try:
        lenient_lowercase(['A', 'b', 'C123'])
        assert False
    except AttributeError:
        assert False
    except Exception:
        assert True



# Generated at 2022-06-11 01:42:28.565405
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['a', 'b', 'c', 'd', 1, 2, 3, 4]) == ['a', 'b', 'c', 'd', 1, 2, 3, 4])
    assert(lenient_lowercase([]) == [])
    assert(lenient_lowercase(['D', 'C', 'E', 'F', 'G']) == ['d', 'c', 'e', 'f', 'g'])
    assert(lenient_lowercase(['D', 'C', 'E', 'F', 'G', 1, 2, 3, 4, 5, 6]) == ['d', 'c', 'e', 'f', 'g', 1, 2, 3, 4, 5, 6])


# Generated at 2022-06-11 01:42:35.714196
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert(bytes_to_human(10245) == '10.00 kB')
    assert(bytes_to_human(10245, unit='k') == '10.00 kB')
    assert(bytes_to_human(10245, unit='K') == '10.00 kB')
    assert(bytes_to_human(10245, unit='M') == '0.01 MB')
    assert(bytes_to_human(10245, unit='m') == '10.00 kB')
    assert(bytes_to_human(10245, unit='G') == '0.00 GB')
    assert(bytes_to_human(10245, unit='g') == '10.00 kB')
    assert(bytes_to_human(10245, unit='T') == '0.00 TB')

# Generated at 2022-06-11 01:42:48.046865
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print('Test 1 - bytes_to_human()')
    try:
        print('bytes_to_human(size=10, unit=None) = %s (should be 10 Bytes)' % bytes_to_human(size=10, unit=None))
    except Exception as e:
        print('Test 1 - bytes_to_human() failed with an exception: %s' % str(e))
        exit(1)
    print('Test 2 - bytes_to_human()')
    try:
        print('bytes_to_human(size=1000, unit=None) %s (should be 1000 Bytes)' % bytes_to_human(size=1000, unit=None))
    except Exception as e:
        print('Test 2 - bytes_to_human() failed with an exception: %s' % str(e))
        exit(1)


# Generated at 2022-06-11 01:42:57.117331
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Test cases for function human_to_bytes
    '''
    assert human_to_bytes('1KB') == 1000
    assert human_to_bytes('1KB') == human_to_bytes(1, 'K')
    assert human_to_bytes('1B') == human_to_bytes(1, 'b')
    assert human_to_bytes(1) == human_to_bytes(1, '')
    assert human_to_bytes('1.5MB') == 1500000
    assert human_to_bytes('1.5MB') == human_to_bytes(1.5, 'M')
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0') == human_to_bytes('1.') == human_to_bytes('1')
    assert human_

# Generated at 2022-06-11 01:43:02.216990
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 4, 'C']) == ['a', 4, 'c']
    assert lenient_lowercase('DEF') == 'def'
    assert lenient_lowercase(3) == 3

# Generated at 2022-06-11 01:43:13.902433
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Tests for human_to_bytes()
    '''


# Generated at 2022-06-11 01:43:18.586036
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['1', '2', 'A', 'B']) == ['1', '2', 'a', 'b']
    assert lenient_lowercase(['1', '2', 1, 2]) == ['1', '2', 1, 2]


# Generated at 2022-06-11 01:43:31.296903
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('100M') == 1024 * 1024 * 100

    assert human_to_bytes('1B', default_unit='M') == 1
    assert human_to_bytes('1K', default_unit='M') == 1 << 10
    assert human_to_bytes('1K', default_unit='G') == 1 << 20
    assert human_to_bytes('1K', default_unit='T') == 1 << 30

    assert human_to_bytes('1MB') == 1 << 20
    assert human_to_bytes('1Mb') == 1 << 20
    assert human_to_bytes('1MBb') == 1 << 20
   

# Generated at 2022-06-11 01:43:36.872012
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert [1, 2, 3, 'a', 'b', 'c'] == lenient_lowercase([1, 2, 3, 'a', 'b', 'c'])
    assert [1, 2, 3, 'a', 'b', 'c'] == lenient_lowercase([1, 2, 3, 'A', 'B', 'C'])
    assert ['a', 'b', 'c'] == lenient_lowercase(['A', 'B', 'C'])
    assert ['a', 'b', 'c'] == lenient_lowercase(['a', 'b', 'c'])



# Generated at 2022-06-11 01:43:42.570641
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['a', 'A', 'B', 'b', 1, 2]
    result = lenient_lowercase(test_list)
    assert result == ['a', 'a', 'b', 'b', 1, 2], "Result is not correct: %s" % result



# Generated at 2022-06-11 01:43:49.870819
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['one', 'two', 'three', 'FOUR', 'FIVE'] == lenient_lowercase(['one', 'two', 'three', 'FOUR', 'FIVE'])
    assert ['one', 'two', 1, 'FOUR', 'FIVE'] == lenient_lowercase(['one', 'two', 1, 'FOUR', 'FIVE'])
    assert ['one', 'two', None, 'FOUR', 'FIVE'] == lenient_lowercase(['one', 'two', None, 'FOUR', 'FIVE'])
    assert ['one', 'two', u'three', 'FOUR', 'FIVE'] == lenient_lowercase(['one', 'two', u'three', 'FOUR', 'FIVE'])

# Generated at 2022-06-11 01:43:56.699858
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760, "10M to bytes should return 10485760"
    assert human_to_bytes('10M', 'b', True) == 10485760, "10M to bits should return 10485760"
    assert human_to_bytes('10M', 'b', False) == 10485760, "10M to bytes should return 10485760"
    assert human_to_bytes('10b', 'b') == 10, "10b to bits should return 10"

# Generated at 2022-06-11 01:43:59.233981
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['aBc', 'DeF', 1, [2]]) == ['abc', 'def', 1, [2]]



# Generated at 2022-06-11 01:44:09.005611
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Unit test for function human_to_bytes"""
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.00') == 1
    assert human_to_bytes('1.01') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('2.0') == 2
    assert human_to_bytes('1e0') == 1
    assert human_to_bytes('1e1') == 10
    assert human_to_bytes('1.0e1') == 10
    assert human_to_bytes('1.0e0') == 1
    assert human_to

# Generated at 2022-06-11 01:44:17.919310
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    actual = lenient_lowercase(['Foo', 'Bar'])
    assert actual == ['foo', 'bar']
    actual = lenient_lowercase(['Foo', '42'])
    assert actual == ['foo', '42']
    actual = lenient_lowercase(['Foo', ['Bar', 'Baz']])
    assert actual == ['foo', ['Bar', 'Baz']]
    actual = lenient_lowercase(['Foo', {'Bar' : 'Baz'}])
    assert actual == ['foo', {'Bar' : 'Baz'}]


# Generated at 2022-06-11 01:44:22.430776
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'b', 'C', 'D']) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-11 01:44:31.203986
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Unit test for function human_to_bytes
    test_data = (
        ('1', 1),
        ('2k', 2 * 1024),
        ('2K', 2 * 1024),
        ('2kb', 2 * 1024),
        ('2KB', 2 * 1024),
        ('2M', 2 * 1024 * 1024),
        ('2MB', 2 * 1024 * 1024),
        ('2m', 2 * 1024 * 1024),
        ('2mb', 2 * 1024 * 1024),
        ('2Kb', 2048),
        ('2b', 2),
        ('2B', 2),
        ('2.5K', 2560),
        ('2.5k', 2560),
        ('0.5tb', 5497558138880),
        ('0.5tb', 5497558138880),
    )

   

# Generated at 2022-06-11 01:44:39.520835
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10 * (1 << 20)
    assert human_to_bytes('10M', 'M') == 10 * (1 << 20)
    assert human_to_bytes('10Mb', isbits=True) == 10 * (1 << 20)
    assert human_to_bytes('10Mb', 'Mb', isbits=True) == 10 * (1 << 20)
    assert human_to_bytes('10', 'M') == 10 * (1 << 20)
    assert human_to_bytes('10.00001', 'M') == 10 * (1 << 20)
    assert human_to_bytes('10.00001', 'M') == 10 * (1 << 20)
    assert human_to_bytes('10.00001M') == 10 * (1 << 20)
    assert human_to

# Generated at 2022-06-11 01:44:51.765220
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1, "1B should be 1"
    assert human_to_bytes('1KB') == 1024, "1KB should be 1024"
    assert human_to_bytes('1Mb') == 1 * 1024 * 1024, "1Mb should be 1 * 1024 * 1024"
    assert human_to_bytes('1mb', isbits=True) == 1 * 1024 * 1024, "1mb should be 1 * 1024 * 1024"
    assert human_to_bytes('1b') == 1, "1b should be 1"
    assert human_to_bytes('1b', isbits=True) == 1, "1b should be 1"
    assert human_to_bytes('1 KB') == 1024, "1 KB should be 1024"
    assert human_to_bytes('1 KB', unit='KB') == 1024

# Generated at 2022-06-11 01:44:55.624408
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    strings = ['KiB', 'MiB', 'GiB', 'TiB']
    lowered = []
    for i in strings:
        lowered.append(lenient_lowercase(i))
    assert lowered == ['kib', 'mib', 'gib', 'tib']
    return True



# Generated at 2022-06-11 01:44:57.311307
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'a', 'B']) == [1, 'a', 'B']

# Generated at 2022-06-11 01:45:08.547012
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import unittest2
    import sys


# Generated at 2022-06-11 01:45:15.160551
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'b', 'C', 'd']) == ['a', 'b', 'c', 'd']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase([1.0, 2.0, 3.0]) == [1.0, 2.0, 3.0]
    assert lenient_lowercase([]) == []


# Generated at 2022-06-11 01:45:22.823600
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from logzero import logger
    ''' test for function human_to_bytes when bits=False (default) '''
    logger.info("---------test_human_to_bytes: bits=False---------")
    logger.info("Expected result for '1b' i.e. bits=False")
    logger.info("Actual result: %s, Expected result: %s" % (human_to_bytes('1b'), 1))
    logger.info("---------test_human_to_bytes: bits=False---------")
    ''' test for function human_to_bytes when bits=True '''
    logger.info("---------test_human_to_bytes: bits=True---------")
    logger.info("Expected result for '1b' i.e. bits=True")

# Generated at 2022-06-11 01:45:26.435856
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 2, 'B']) == ['a', 2, 'b']
    assert lenient_lowercase(['A', 'a', 'A']) == ['a', 'a', 'a']


# Generated at 2022-06-11 01:45:39.997674
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:45:50.808896
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Byte'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 EB'

# Generated at 2022-06-11 01:46:02.979810
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1', isbits=True) == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1.5MB') == 1572864
    assert human_to_bytes('1.5Mb', isbits=True) == 1572864
    assert human_to_bytes('2048B') == 2048
    assert human_to_bytes('2048b', isbits=True) == 2048
    assert human_to_

# Generated at 2022-06-11 01:46:04.803342
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Foo', 'Bar', 'Baz']) == ['foo', 'bar', 'baz']



# Generated at 2022-06-11 01:46:16.655184
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest

    error_msg = 'Given size %s do not match expected result %s'

    # size test

# Generated at 2022-06-11 01:46:20.395055
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert isinstance(lenient_lowercase(['A', 1, 'B', 2]), list)
    assert lenient_lowercase(['A', 1, 'B', 2]) == ['a', 1, 'b', 2]



# Generated at 2022-06-11 01:46:29.328950
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """ Perform unit testing for function human_to_bytes """
    assert human_to_bytes('12K') == 12 * 1024
    assert human_to_bytes('10M') == 10 * 1024 * 1024
    assert human_to_bytes('1G') == 1 * 1024 * 1024 * 1024
    assert human_to_bytes('1.5M') == int(1.5 * 1024 * 1024)
    assert human_to_bytes('12Kb') == 12 * 1024 / 8
    assert human_to_bytes('12KB', isbits=True) == 12 * 1024 / 8
    assert human_to_bytes('12Kb', isbits=False) == 12 * 1024
    assert human_to_bytes(10, 'M') == 10 * 1024 * 1024
    assert human_to_bytes(10, 'B') == 10


# Generated at 2022-06-11 01:46:40.045453
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """
    Test bytes conversion
    """
    # default (bytes)
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.1M') == 1179648
    assert human_to_bytes('1.11M') == 1179648
    assert human_to_bytes('MB') == 1
    assert human_to_bytes('.1MB') == 1
    # default isbits
    assert human_to_bytes('1Mb') == 8388608
    assert human_to_bytes('Mb') == 1
    assert human_to_bytes('.1Mb') == 1
    # default - error

# Generated at 2022-06-11 01:46:45.462639
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['a', 1, [2, 3], None, 'B', 'c', {'foo': 1}]
    expected_result = ['a', 1, [2, 3], None, 'b', 'c', {'foo': 1}]
    lowered = lenient_lowercase(lst)
    assert lowered == expected_result


# Generated at 2022-06-11 01:46:56.938591
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('0') == 0
    assert human_to_bytes('0.0') == 0
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1024.') == 1024
    assert human_to_bytes('1024.0') == 1024

    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842620

# Generated at 2022-06-11 01:47:09.017698
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Default unit test: B
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1GB') == 1073741824
    assert human_to

# Generated at 2022-06-11 01:47:13.881077
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['ABC']) == ['abc']
    assert lenient_lowercase([3]) == [3]
    assert lenient_lowercase(['ABC', 3, 'xyz']) == ['abc', 3, 'xyz']

# Generated at 2022-06-11 01:47:24.708114
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:47:35.330300
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('3.4B') == 3
    assert human_to_bytes('3.4B', default_unit='B') == 3
    assert human_to_bytes('3.4') == 3
    assert human_to_bytes('3.4', default_unit='B') == 3
    assert human_to_bytes('3.4Kb', isbits=True) == 3400
    assert human_to_bytes('3.4K', isbits=False) == 3*1024
    assert human_to_bytes('3.4Kb', isbits=False) == 3.4*1024
    assert human_to_bytes('3.4Kb') == 3.4*1024
    assert human_to_bytes('3.4K') == 3*1024

# Generated at 2022-06-11 01:47:47.302367
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # passing values that should pass
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1 ') == 1
    assert human_to_bytes('1  ') == 1
    assert human_to_bytes(' 1') == 1
    assert human_to_bytes(' 1 ') == 1
    assert human_to_bytes(' 1  ') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1e1') == 10
    assert human_to_bytes('1.1M') == 1153433
    assert human_to_bytes('1.1K') == 1120.0
    assert human_to_bytes('1.1K', isbits=True) == 560000.0
    assert human_to_bytes('1.1K', unit='M')

# Generated at 2022-06-11 01:47:54.939086
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    ''' Test case for function lenient_lowercase '''
    assert 'foo' == lenient_lowercase(['fOo'])[0]
    assert 'foo' == lenient_lowercase(['fOo'])[0]
    assert 'fOo' == lenient_lowercase(['fOo', 'bar'])[0]
    assert 'bar' == lenient_lowercase(['fOo', 'bar'])[1]
    assert 'foo' == lenient_lowercase(['fOo', 'bar'])[0]
    assert 'bar' == lenient_lowercase(['fOo', 'bar'])[1]


# Generated at 2022-06-11 01:48:07.697750
# Unit test for function bytes_to_human
def test_bytes_to_human():

    # unit is not passed, should return with 'Bytes' suffix
    assert bytes_to_human(1048576) == '1.00 MB'
    # unit is passed, should return with 'KB' suffix
    assert bytes_to_human(1048576, unit='k') == '1024.00 KB'

    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(0.7 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '6.22 YB'

    assert bytes_to_human(1048576, isbits=True) == '8388608.00 bits'

# Generated at 2022-06-11 01:48:12.004457
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10) == 10
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10G') == 10737418240
    assert human_to_bytes('10T') == 10995116277760
    assert human_to_bytes('10P') == 11258999068426240
    assert human_to_bytes('10E') == 11529215046068469760
    assert human_to_bytes('10Z') == 1180591620717411303424
    assert human_to_bytes('10Y') == 12

# Generated at 2022-06-11 01:48:20.914863
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Unit test for function human_to_bytes'''
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2.5k') == 2560
    assert human_to_bytes('2KB') == 2048
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5MB') == 1572864
    assert human_to_bytes('1.5b') == 1.5
    assert human_to_bytes('1.5Kb') == 1500
    assert human_to_bytes('1.5Mb') == 1572864.0
    assert human_to_bytes('1.5Gb')

# Generated at 2022-06-11 01:48:31.730594
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, isbits=True) == '1.00 bits'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024, unit='G') == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024, unit='g') == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024, unit='m') == '1,048,576.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024, unit='k') == '1,073,741,824.00 KB'


# Generated at 2022-06-11 01:48:48.591167
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['one', 'two', 'three', 1]
    assert lenient_lowercase(test_list) == ['one', 'two', 'three', 1]
    test_list = ['one', 'two', 'THREE', 1]
    assert lenient_lowercase(test_list) == ['one', 'two', 'three', 1]
    test_list = ['ONE', 'two', 'THREE', 1]
    assert lenient_lowercase(test_list) == ['one', 'two', 'three', 1]
    test_list = ['ONE', 'TWO', 'THREE', 1]
    assert lenient_lowercase(test_list) == ['one', 'two', 'three', 1]
    test_list = ['ONE', 'TWO', 'THREE', 'FIVE']
    assert lenient_lower

# Generated at 2022-06-11 01:48:57.551623
# Unit test for function human_to_bytes
def test_human_to_bytes():
    data = [('1', 1), ('1MB', 1048576), ('1kb', 1000), ('1k', 1024), ('1024k', 1048576), ('1.1M', 1150000)]
    for args, out in data:
        assert human_to_bytes(args) == out

    data = [('1', 1), ('1Mb', 1048576), ('1kb', 1000), ('1k', 1000), ('1024k', 1024000), ('1.1M', 1150000)]
    for args, out in data:
        assert human_to_bytes(args, isbits=True) == out

# Generated at 2022-06-11 01:49:06.691210
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('0') == 0
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10K') == 10 * 1024
    assert human_to_bytes('2.5M') == 2.5 * 1024 * 1024
    assert human_to_bytes('10.3M') == 10.3 * 1024 * 1024
    assert human_to_bytes('10.3Mb') == int(10.3 * 1024 * 1024 * 8)
    assert human_to_bytes('10MB') == 10 * 1024 * 1024
    assert human_to_bytes('10mB') == 10 * 1024 * 1024
    assert human_to_bytes('10M') == 10 * 1024 * 1024

# Generated at 2022-06-11 01:49:15.108027
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(2914200) == '2.78 MB'
    assert bytes_to_human(2914200, unit='Mb') == '2.45 Mb'
    assert bytes_to_human(2914200, isbits=True, unit='m') == '2.45 m'
    assert bytes_to_human(2914200, isbits=True) == '23.31 Mb'
    assert bytes_to_human(3142000000) == '2.93 GB'
    assert bytes_to_human(3142000000, isbits=True) == '25.48 Gb'
    assert bytes_to_human(2914200000) == '2.74 GB'
    assert bytes_to_human(3142000000, isbits=True) == '25.48 Gb'

# Generated at 2022-06-11 01:49:23.241354
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('1B') == 1
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'KB') == 10000
    assert human_to_bytes(10, 'Kb') == 8000
    assert human_to_bytes(10, 'Mb') == 12500000
    assert human_to_bytes(10, 'MB', isbits=True) == 12500000
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10', default_unit='K') == 10240
    assert human_to_bytes('10', 'K') == 10240
    # Negative numbers
    assert human_to_bytes('-10K') == -10240

# Generated at 2022-06-11 01:49:35.049506
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == "10 Bytes"
    assert bytes_to_human(1025) == "1.00 KB"
    assert bytes_to_human(1048576) == "1.00 MB"
    assert bytes_to_human(1073741824) == "1.00 GB"
    assert bytes_to_human(1099511627776) == "1.00 TB"
    assert bytes_to_human(1125899906842624) == "1.00 PB"
    assert bytes_to_human(1152921504606846976) == "1.00 EB"
    assert bytes_to_human(1180591620717411303424) == "1.00 ZB"

# Generated at 2022-06-11 01:49:43.121685
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_inputs = {
        '1MB': 1048576,
        '1KB': 1024,
        '1GB': 1073741824,
        '5b': 5,
        '5bB': 5,
        '5BB': 5,
        '5bb': 5
    }

    for human_string, expected_value in iteritems(test_inputs):
        result = human_to_bytes(human_string)
        assert result == expected_value, "The human string: %s expected to return: %s, got: %s" % (human_string, expected_value, result)

# Generated at 2022-06-11 01:49:48.195949
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 1, 'b']) == ['a', 1, 'b']
    assert lenient_lowercase(['A', '', 1, 'b']) == ['a', '', 1, 'b']
    assert lenient_lowercase('aaa') == ['a', 'a', 'a']



# Generated at 2022-06-11 01:49:51.336327
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'b', 1]

# unit test for function human_to_bytes

# Generated at 2022-06-11 01:50:04.013916
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import operator

    # Test all supported ranges for bytes and bits
    for range_key in SIZE_RANGES.keys():
        test_bytes = '{0}B'.format(range_key)
        test_bits = '{0}b'.format(range_key)
        if test_bits == 'b':
            test_bits = 'b'
            test_bytes = 'B'
        # Test both integer and float input
        for test_num in [1, 1.0]:
            unit_bytes = human_to_bytes(test_num, default_unit=test_bytes)
            print('testing {0} {1}bytes => {2}'.format(test_num, test_bytes, unit_bytes))

            # We should have the same integer