

# Generated at 2022-06-11 01:40:18.542890
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='b') == '8.00 bits'
    assert bytes_to_human(1023) == '1023.00 Bytes'
    assert bytes_to_human(1023, unit='b') == '8192.00 bits'
    assert bytes_to_human(1023, unit='k') == '0.00 KB'
    assert bytes_to_human(1023, unit='K') == '0.00 KB'
    assert bytes_to_human(1023, unit='kb') == '8.00 Kb'
    assert bytes_to_human(1023, unit='kB') == '8.00 Kb'

# Generated at 2022-06-11 01:40:27.264669
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''Unit test'''
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(-1) == '-1.00 Bytes'
    assert bytes_to_human(256) == '256.00 Bytes'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(251771391) == '239.25 MB'
    assert bytes_to_human(251771391, unit='kb') == '246215.58 KB'
    assert bytes_to_human(251771391, unit='mb') == '239.25 MB'
    assert bytes_to_human(251771391, unit='gb') == '0.23 GB'

# Generated at 2022-06-11 01:40:30.086363
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # TODO: add more unit test
    test_list = [{'a': 'b'}, 'c', 'd']
    assert(lenient_lowercase(test_list) == [{'a': 'b'}, 'c', 'd'])



# Generated at 2022-06-11 01:40:38.637612
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:40:50.064658
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', 'B') == 10485760
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes('1MB') == 1048576

    assert human_to_bytes('10G') == 10737418240
    assert human_to_bytes('10GB') == 10737418240

    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10KB') == 10240
    assert human_to_bytes('10GB') == 10737418240
    assert human_to_bytes('10TB') == 10995116277760

    assert human_to_bytes('10PB') == 11258999068426240
    assert human_to

# Generated at 2022-06-11 01:41:02.514505
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('1M', isbits=True) == 1048576
    assert human_to_bytes('2Mb') == 2097152
    assert human_to_bytes('2Mb', isbits=True) == 2097152
    assert human_to_bytes('1G', 'B') == 1073741824
    assert human_to_bytes('1B', 'G') == 1e-09
    assert human_to_bytes('2Kb', 'B') == 256
    assert human_to_bytes('1B', 'Kb') == 0.001
    assert human_to_bytes('1K', 'Kb') == 0.125

# Generated at 2022-06-11 01:41:10.089582
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2k', 'B') == 2048
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('10b', isbits=True) == 1.25
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('10MB', 'b', isbits=True) == 8192000


# Generated at 2022-06-11 01:41:19.361898
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    human_to_bytes test function

    :return:
    '''

# Generated at 2022-06-11 01:41:31.336645
# Unit test for function human_to_bytes
def test_human_to_bytes():
    number_of_tests = 0
    number_of_tests_failed = 0

    def compare_correct_results(num, bnum, unit=None, isbits=False):
        global number_of_tests
        global number_of_tests_failed
        number_of_tests += 1
        if bnum != human_to_bytes(num, default_unit=unit, isbits=isbits):
            print('test #%d human_to_bytes("%s") failed (isbits: %s)' % (number_of_tests, num, str(isbits)))
            number_of_tests_failed += 1

    compare_correct_results('1M', 1048576, 'B')
    compare_correct_results('1024K', 1048576, 'B')

# Generated at 2022-06-11 01:41:42.211031
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import eq_
    # test bytes to bytes conversion
    eq_(human_to_bytes('1B', isbits=False), 1, "Bytes conversion failed")
    eq_(human_to_bytes('1KB', isbits=False), 1024, "Kilobytes conversion failed")
    eq_(human_to_bytes('1MB', isbits=False), 1048576, "Megabytes conversion failed")
    eq_(human_to_bytes('1GB', isbits=False), 1073741824, "Gigabytes conversion failed")
    eq_(human_to_bytes('1TB', isbits=False), 1099511627776, "Terabytes conversion failed")
    eq_(human_to_bytes('1PB', isbits=False), 1125899906842624, "Petabytes conversion failed")

# Generated at 2022-06-11 01:41:57.673819
# Unit test for function human_to_bytes
def test_human_to_bytes():

    TEST_DATA = [
        ('2', 2, 2),
        (' 10 ', 10, 10),
        ('10M', 10485760, 10 * 1024 * 1024),
        (' 2E ', 1610612736, 2 * 1024 * 1024 * 1024),
        ('1Kb', 1024, 1 * 1024 * 8),
        ('30Pb', 3.220092962793689e+17, 30 * 1024 * 1024 * 1024 * 1024 * 8),
        ('1.5B', 1, 1),
        ('10Mb', 10485760, 10 * 1024 * 1024 * 8),
        ('10mB', 10485760, 10 * 1024 * 1024),
        ('1EB', 1099511627776, 1 * 1024 * 1024 * 1024 * 1024),
        ('1.0b', 1, 1 / 8),
    ]

# Generated at 2022-06-11 01:42:07.775040
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test unary conversion to bytes
    assert human_to_bytes('1', default_unit='k') == 1024
    assert human_to_bytes(1) == 1
    assert human_to_bytes(1, default_unit='m') == 1048576
    assert human_to_bytes(1.5) == 1
    assert human_to_bytes(1.5, default_unit='m') == 1572864
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1g') == 1073741824
    assert human_to

# Generated at 2022-06-11 01:42:11.410737
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    tmp_list = ['test', 1, 'A', 'test2', 9]
    tmp_list_lowered = ['test', 1, 'a', 'test2', 9]

    assert lenient_lowercase(tmp_list) == tmp_list_lowered

# Generated at 2022-06-11 01:42:20.755297
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_values = dict()
    test_values['1G'] = 1073741824
    test_values['1G '] = 1073741824
    test_values['1Gb'] = 134217728
    test_values['1Gb '] = 134217728
    test_values['1.5G'] = 1610612736
    test_values['1.5Gb'] = 1879048192
    test_values['1.5G '] = 1610612736
    test_values['100m'] = 104857600
    test_values['100mb'] = 13107200
    test_values['1.5M'] = 1572864
    test_values['1.5Mb'] = 196608
    test_values['1.5K'] = 1536

# Generated at 2022-06-11 01:42:31.179031
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('2') == 2
    assert human_to_bytes('2K') == 2 * (1 << 10)
    assert human_to_bytes('2M') == 2 * (1 << 20)
    assert human_to_bytes('1.5M') == int(1.5 * (1 << 20))
    assert human_to_bytes('5G') == 5 * (1 << 30)
    assert human_to_bytes('1Z') == 1 * (1 << 70)
    assert human_to_bytes('1.5Z', 'B') == int(1.5 * (1 << 70))
    assert human_to_bytes('.5Kb') == int(0.5 * (1 << 10))

# Generated at 2022-06-11 01:42:40.509512
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes(10, 'M') == 10485760
    try:
        human_to_bytes(10, 'Mb')
    except ValueError:
        pass

    assert human_to_bytes('1Mb', isbits=True) == 1048576
    try:
        human_to_bytes('1MB', isbits=True)
    except ValueError:
        pass

    assert human_to_bytes('512MB') == 536870912
    try:
        human_to_bytes('512MB', isbits=True)
    except ValueError:
        pass


# Generated at 2022-06-11 01:42:43.790379
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_data = [1, '3', 'aBcD', None]

    assert lenient_lowercase(input_data) == [1, '3', 'abcd', None]



# Generated at 2022-06-11 01:42:55.208995
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # Test bytes
    # Test Uppercase
    assert(human_to_bytes('1K') == 1024)
    assert(human_to_bytes('1kB') == 1024)
    assert(human_to_bytes('10KB') == 10240)
    assert(human_to_bytes('1.3M') == 1376256)
    assert(human_to_bytes('1.3MB') == 1376256)
    assert(human_to_bytes('10MB') == 10485760)
    assert(human_to_bytes('4.5G') == 4777574400)
    assert(human_to_bytes('4.5GB') == 4777574400)
    assert(human_to_bytes('4.5gB') == 4777574400)

# Generated at 2022-06-11 01:43:06.470736
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test for bytes
    assert human_to_bytes(1048576) == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1 TB') == 1099511627776
    assert human_to_bytes('1 PB') == 1125899906842624
    assert human_to_bytes('1.5TB') == 1649267441664
    assert human_to_bytes('1.5TB', default_unit='B') == 1649267441664
    assert human_to_bytes('1.5TB', default_unit='MB') == 1649267441664

# Generated at 2022-06-11 01:43:15.038990
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["a", "b", "c"]) == ["a", "b", "c"]
    assert lenient_lowercase(["A", "b", "c"]) == ["a", "b", "c"]
    assert lenient_lowercase(["A", "B", "c"]) == ["a", "b", "c"]
    assert lenient_lowercase(["A", "B", "C"]) == ["a", "b", "c"]
    assert lenient_lowercase(["a", "b", 1]) == ["a", "b", 1]

# Generated at 2022-06-11 01:43:31.068829
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Tests for unit detection
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1Mb') == 1024 * 1024
    assert human_to_bytes('1mb') == 1024 * 1024
    assert human_to_bytes('1G') == 1024 * 1024 * 1024
    assert human_to_bytes('1Gb') == 1024 * 1024 * 1024
    assert human_to_bytes('1gb') == 1024 * 1024 * 1024
    assert human_to_bytes('10K') == 1024 * 10
    assert human_

# Generated at 2022-06-11 01:43:37.956699
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test lowercase normally
    input_lst = ["Abc", 1, "Kjk", 2, "uyT", "hTt", 4]
    expected_lst = ["abc", 1, "kjk", 2, "uyt", "htt", 4]
    actual_lst = lenient_lowercase(input_lst)
    assert expected_lst == actual_lst

    # Test when something already lowercase
    input_lst = ["Abc", 1, "abc", 2, "uyT", "hTt", 4]
    expected_lst = ["abc", 1, "abc", 2, "uyt", "htt", 4]
    actual_lst = lenient_lowercase(input_lst)
    assert expected_lst == actual_lst

    # Test when something other than a string


# Generated at 2022-06-11 01:43:48.388395
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(3) == '3.00 Bytes'
    assert bytes_to_human(3, unit='B') == '3.00 Bytes'
    assert bytes_to_human(3, unit='K') == '0.00 KB'
    assert bytes_to_human(3, unit='M') == '0.00 MB'
    assert bytes_to_human(3, unit='G') == '0.00 GB'
    assert bytes_to_human(3, unit='T') == '0.00 TB'
    assert bytes_to_human(3, unit='P') == '0.00 PB'
    assert bytes_to_human(3, unit='E') == '0.00 EB'
    assert bytes_to_human(3, unit='Z') == '0.00 ZB'

# Generated at 2022-06-11 01:43:55.823246
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['a', 'A', 'b', 'B'] == lenient_lowercase(['a', 'A', 'b', 'B'])
    assert ['a', 'A', 'b', 'B', 10, 11, 12] == lenient_lowercase(['a', 'A', 'b', 'B', 10, 11, 12])
    assert ['a', 'A', 'b', 'B', 1, 2, 3] == lenient_lowercase(['a', 'A', 'b', 'B', 1, 2, 3])


# Generated at 2022-06-11 01:43:58.982544
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['foo', 'bar', 3] == lenient_lowercase(['foo', 'bar', 3])
    assert ['foo', 'bar', 'qux'] == lenient_lowercase(['FOO', 'BAR', 'QUX'])



# Generated at 2022-06-11 01:44:00.694783
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['FOO', 'BAR']) == ['foo', 'bar']


# Generated at 2022-06-11 01:44:09.889659
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:44:22.135383
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('123') == 123
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.5B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1.5b') == 1
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1.5K') == 1024 * 1.5
    assert human_to_bytes('1k', unit='K') == 1024
    assert human_to_bytes('1k', unit='M') == 1024 * 1024
    assert human_to_bytes('1k', unit='b') == 1024

# Generated at 2022-06-11 01:44:30.581131
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:44:33.407869
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_in = [1, 'A', 'B']
    list_out = lenient_lowercase(list_in)
    assert len(list_out) == 3
    assert list_out[0] == 1
    assert list_out[1] == 'a'
    assert list_out[2] == 'b'

# Generated at 2022-06-11 01:44:38.950083
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """test case for lenient_lowercase"""
    lst = ['A','a','b','B','c','C',1,2,3]
    assert ['a','a','b','b','c','c',1,2,3] == lenient_lowercase(lst)



# Generated at 2022-06-11 01:44:51.369637
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', default_unit='B') == 10485760
    assert human_to_bytes('10m') == 10485760
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b', default_unit='b') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('0.5K') == 512
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Y') == 1208925819614629174706176
    assert human_to_bytes('0.5Kb') == 64
    assert human_to_bytes('1Gb') == 134217728
    assert human_to

# Generated at 2022-06-11 01:45:01.536986
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test bytes
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10mB') == 10485760
    # test bits
    assert human_to_bytes('10M', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10mb', isbits=True) == 10485760

    assert human_to_bytes('10M', isbits=True) == human_to_bytes('10M', isbits=False) * 8

    # test negative case

# Generated at 2022-06-11 01:45:09.132647
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['a', 'B', 'c']
    lower_lst = lenient_lowercase(lst)
    assert lower_lst == ['a', 'B', 'c']

    lst = [1, 2, 3]
    lower_lst = lenient_lowercase(lst)
    assert lower_lst == [1, 2, 3]

    lst = ['a', 2, 'c']
    lower_lst = lenient_lowercase(lst)
    assert lower_lst == ['a', 2, 'c']

# Generated at 2022-06-11 01:45:19.519099
# Unit test for function bytes_to_human

# Generated at 2022-06-11 01:45:30.823193
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test case with raw bytes
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, unit='k') == '1.00 KB'
    assert bytes_to_human(1024, unit='K') == '1.00 KB'
    assert bytes_to_human(1024, unit='KB') == '1.00 KB'
    assert bytes_to_human(1024, unit='kilo') == '1.00 KB'

    assert bytes_to_human(1.5 * 1024 ** 2) == '1.50 MB'
    assert bytes_to_human(1.5 * 1024 ** 2, unit='m') == '1.50 MB'
    assert bytes_to_human(1.5 * 1024 ** 2, unit='M') == '1.50 MB'
    assert bytes_

# Generated at 2022-06-11 01:45:42.759996
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('0.5k') == 512
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1 MB') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1.5m') == 1572864
    assert human_to_bytes('1.5m', 'm') == 1572864
    assert human_to_bytes('1.5m', 'b') == 1572864
    assert human_to_bytes('1.5m', 'B') == 1572864
    assert human_to_bytes('-1.5m', 'B') == 0
    assert human_to_bytes

# Generated at 2022-06-11 01:45:52.846450
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Test different cases of human_to_bytes function"""
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', default_unit='M') == 10485760
    assert human_to_bytes('10', default_unit='M') == 10485760
    assert human_to_bytes('10GB', default_unit='M') == 10737418240
    assert human_to_bytes(10, default_unit='M') == 10485760
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes(1) == 1
    assert human_to_bytes(0.5) == 0
    assert human

# Generated at 2022-06-11 01:46:04.297483
# Unit test for function bytes_to_human

# Generated at 2022-06-11 01:46:15.983699
# Unit test for function bytes_to_human

# Generated at 2022-06-11 01:46:25.238468
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import unittest

    # string number as arg, bytes
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10Mb') == 134217728
    assert human_to_bytes('10KB') == 10240
    assert human_to_bytes('10Kb') == 81920
    assert human_to_bytes('10.2Mb') == 138412032
    assert human_to_bytes('10.2MB') == 10685760
    assert human_to_bytes('10.2Mb') == 138412032
    assert human_to_bytes('10.2KB') == 10496
   

# Generated at 2022-06-11 01:46:29.862578
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['A', 'B', 'C', 1, u'D']) == ['a', 'b', 'c', 1, u'd']



# Generated at 2022-06-11 01:46:40.533252
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1000) == '1 KB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1 YB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024, unit='B') == '1 YB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024, unit='y') == '1 YB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024, unit='Y') == '1 YB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024, unit='G') == '1 TB'
    assert bytes_to_human(1024 * 1024 * 1024, unit='M') == '1 GB'
   

# Generated at 2022-06-11 01:46:44.161824
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['hello', 'world', 5]) == ['hello', 'world', 5]
    assert lenient_lowercase(['hello', 'world', '5']) == ['hello', 'world', '5']


# Generated at 2022-06-11 01:46:48.400469
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(['a', 'b', 1, 2])
    assert result == ['a', 'b', 1, 2], 'Expected ["a", "b", 1, 2], got: %s' % result


# Generated at 2022-06-11 01:47:00.631160
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1.5) == '1.50 Bytes'
    assert bytes_to_human(-1.5) == '-1.50 Bytes'
    assert bytes_to_human(1000) == '1.00 kB'
    assert bytes_to_human(1000000) == '1.00 MB'
    assert bytes_to_human(1000000000) == '1.00 GB'
    assert bytes_to_human(1000000000000) == '1.00 TB'
    assert bytes_to_human(1000000000000000) == '1.00 PB'
    assert bytes_to_human(1000000000000000000) == '1.00 EB'


# Generated at 2022-06-11 01:47:08.668352
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Function human_to_bytes tests
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', 'K') == 10485760
    assert human_to_bytes('10', 'M') == 10485760

    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1M', 'B') == 1048576
    assert human_to_bytes('1MB', 'B') == 1048576

    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1K', isbits=True) == 1024

# Generated at 2022-06-11 01:47:18.229111
# Unit test for function human_to_bytes
def test_human_to_bytes():
    s = '10M'
    assert human_to_bytes(s) == 10000000
    assert human_to_bytes(s, unit='m') == 10000000
    assert human_to_bytes(s, unit='mB') == 10000000
    assert human_to_bytes(s, unit='mb') == 10000000
    assert human_to_bytes(s, unit='b') == 10000000
    assert human_to_bytes(s, unit='bits') == 10000000
    assert human_to_bytes(s, isbits=True) == 10000000
    assert human_to_bytes(s, isbits=True, unit='b') == 10000000
    assert human_to_bytes(s, isbits=True, unit='bits') == 10000000

    s = '10Mb'

# Generated at 2022-06-11 01:47:27.490255
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1048576') == 1048576
    assert human_to_bytes(1048576) == 1048576

    assert human_to_bytes('1024', isbits=True) == 1024
    assert human_to_bytes('1kb', isbits=True) == 1024
    assert human_to_bytes('1mb', isbits=True) == 1048576
    assert human_to_bytes('1gb', isbits=True) == 1073741824
    assert human_to_bytes

# Generated at 2022-06-11 01:47:32.694343
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['M', 'K', 'G']
    expect = ['m', 'k', 'g']
    actual = lenient_lowercase(lst)
    if expect != actual:
        raise ValueError("Lenient lowercase failed. Expected: %s. Actual: %s." % (expect, actual))
    pass


# Generated at 2022-06-11 01:47:52.912991
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['foo']) == ['foo']
    assert lenient_lowercase(['Foo']) == ['foo']
    assert lenient_lowercase(['FOO']) == ['foo']
    assert lenient_lowercase(['f', 'F', 'b', 'o']) == ['f', 'F', 'b', 'o']
    assert lenient_lowercase(['f', 'F', 'B', 'o']) == ['f', 'F', 'B', 'o']
    assert lenient_lowercase(['f', 'F', 'b', 'O']) == ['f', 'F', 'b', 'O']
    assert lenient_lowercase(['f', 'F', 'B', 'O']) == ['f', 'F', 'B', 'O']


# Generated at 2022-06-11 01:48:05.289400
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''run unit test for human_to_bytes'''

# Generated at 2022-06-11 01:48:09.490722
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['one', 'two', 'THREE', 'four']) == ['one', 'two', 'three', 'four']
    assert lenient_lowercase([{'one': 'two'}, 'three']) == [{'one': 'two'}, 'three']

# Generated at 2022-06-11 01:48:19.255766
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # testing bytes conversion
    assert human_to_bytes(10) == 10
    assert human_to_bytes('10') == 10
    assert human_to_bytes(10.0) == 10
    assert human_to_bytes('10.0') == 10
    assert human_to_bytes('10.1') == 10
    assert human_to_bytes(10.9) == 10
    assert human_to_bytes('10.9') == 10
    assert human_to_bytes(0.9) == 0
    assert human_to_bytes('0.9') == 0
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes(1.1) == 1
    assert human_

# Generated at 2022-06-11 01:48:24.386115
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['vlan123', 'vlan456']) == ['vlan123', 'vlan456']
    assert lenient_lowercase(['vlan123', 'Vlan456']) == ['vlan123', 'vlan456']
    assert lenient_lowercase(['vlan123', 'Vlan456', 123]) == ['vlan123', 'vlan456', 123]



# Generated at 2022-06-11 01:48:30.237366
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'b', 'cd', 3]) == [1, 'b', 'cd', 3]
    assert lenient_lowercase([1, 'B', 'Cd', 3]) == [1, 'b', 'cd', 3]
    assert lenient_lowercase([1, 'B', 'cd', 3]) == [1, 'b', 'cd', 3]



# Generated at 2022-06-11 01:48:41.381395
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Hello', 'WORLD', 'I', 'Am', 'Test']) == ['hello', 'world', 'I', 'Am', 'Test']
    assert lenient_lowercase(['Hello', 'WORLD', 'I', 'Am', 'Test', 'Test2', [1, 2, 3], (4, 5, 6), {'a': 1, 'b': 2}]) == ['hello', 'world', 'I', 'Am', 'Test', 'Test2', [1, 2, 3], (4, 5, 6), {'a': 1, 'b': 2}]
    assert lenient_lowercase([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert lenient_lowercase([]) == []


# Generated at 2022-06-11 01:48:44.109202
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['ABC', 'ABc', 1, 'abC', True, 'ABC', False]
    assert lenient_lowercase(lst) == lst



# Generated at 2022-06-11 01:48:55.737702
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1b', isbits=True) == human_to_bytes('1b', unit='b', isbits=True)
    assert human_to_bytes('1b', isbits=False) == human_to_bytes('1', unit='b', isbits=False)
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5b', isbits=True) == 1
    assert human_to_bytes('1.5b', isbits=False) == 2

# Generated at 2022-06-11 01:49:00.891553
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.2') == 1
    assert human_to_bytes('1.2K') == 1200
    assert human_to_bytes('1.2Kb', isbits=True) == 1536
    assert human_to_bytes('1.2Kb', unit='KB', isbits=True) == 1536
    assert human_to_bytes('1.2Kb', unit='Kb', isbits=True) == 1536
    assert human_to_bytes('1.2Kb', unit='KB', isbits=False) == 1536
    assert human_to_bytes('1.2Kb', unit='Kb', isbits=False) == 1200

# Generated at 2022-06-11 01:49:20.960710
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', isbits=True) == 10485760
    assert human_to_bytes('10.2M', isbits=True) == 10638051.2
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10mb', isbits=True) == 10485760
    assert human_to_bytes('10 k') == 10240
    assert human_to_bytes('10 K') == 10240
    assert human_to_bytes('10 kb', isbits=True) == 10240
    assert human_to_bytes('10 KB', isbits=True) == 10240
    assert human_to_bytes('1023 KB') == 1048576

# Generated at 2022-06-11 01:49:33.129584
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    source_list = ['A', 'Z', 'a', 'z', 'A', 'Z']
    dest_list = lenient_lowercase(source_list)
    assert dest_list == ['a', 'z', 'a', 'z', 'a', 'z']
    assert source_list == ['A', 'Z', 'a', 'z', 'A', 'Z']

    source_list = [1, 2, 3, 4, 5, 6]
    dest_list = lenient_lowercase(source_list)
    assert dest_list == [1, 2, 3, 4, 5, 6]
    assert source_list == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-11 01:49:40.292040
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
       Unit test for human_to_bytes function:
       - convert 10M into 10485760 (int)
       - convert '10M' into 10485760 (int)
       - convert '10MB' into 10485760 (int)
       - convert '10mb' into 10485760 (int)
       - convert '10Mb' into 10485760 (int)
       '''
    result = human_to_bytes(10, 'M')
    assert result == 10 * 1024 * 1024

    result = human_to_bytes('10', 'M')
    assert result == 10 * 1024 * 1024

    result = human_to_bytes('10M')
    assert result == 10 * 1024 * 1024

    result = human_to_bytes('10mb', isbits=True)
    assert result == 10 * 1024 * 1024

# Generated at 2022-06-11 01:49:43.656267
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['123', 'abc']) == ['123', 'abc']
    assert lenient_lowercase(['123', 'abc', 123]) == ['123', 'abc', 123]



# Generated at 2022-06-11 01:49:51.565159
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    1B = 1
    1K = 1024
    1KB = 1024
    1M = 1048576
    1MB = 1048576
    1G = 1073741824
    1GB = 1073741824
    1T = 1099511627776
    1TB = 1099511627776
    1P = 1125899906842624
    1PB = 1125899906842624
    1E = 1152921504606847000
    1EB = 1152921504606847000
    1Z = 1180591620717411303424
    1ZB = 1180591620717411303424
    1Y = 1208925819614629174706176
    1YB = 1208925819614629174706176
    '''
    # 'MB' -> 'B'

# Generated at 2022-06-11 01:49:55.270084
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['A', 'b', 'c', 10, 15, 20]
    assert lenient_lowercase(lst) == ['a', 'b', 'c', 10, 15, 20]



# Generated at 2022-06-11 01:50:06.358617
# Unit test for function human_to_bytes
def test_human_to_bytes():
    error_msg = ''
    errors = []
    for line in open('/tmp/human_to_bytes.txt'):
        if line.startswith('#'):
            continue
        line = line.strip()
        if not line:
            continue
        elem = line.split()
        try:
            assert(int(elem[1]) == human_to_bytes(elem[0]))
        except AssertionError:
            error_msg = 'fail: orig: %s calculated: %s' % (elem[1], human_to_bytes(elem[0]))
            errors.append(error_msg)
    if errors:
        raise AssertionError("Test failed:\n%s" % '\n'.join(errors))