

# Generated at 2022-06-11 01:40:21.079244
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes('10M') == human_to_bytes(10, 'Mb')
    assert human_to_bytes('10Mb', isbits=True) == human_to_bytes(10, 'Mb', isbits=True)
    assert human_to_bytes('10Mb', isbits=True) == 10 * 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('10MB') == human_to_bytes(10, 'Mb')
    assert human_to_bytes('10MB') == 10 * 1048576
    assert human_to_bytes('10MB') == human_to_bytes(10, 'MB')
   

# Generated at 2022-06-11 01:40:28.621775
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest

    # basic test
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2k') == 2048

    # without unit
    assert human_to_bytes('2048') == 2048

    # default unit test
    assert human_to_bytes('2048', 'B') == 2048
    assert human_to_bytes('2048', 'G') == 2048 * 1024 * 1024 * 1024

    # bits case
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1Mb', 'b') == 1048576

    # case sensitive
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 1048576


# Generated at 2022-06-11 01:40:36.561723
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c'], "First list"
    assert lenient_lowercase([123, 'B', ['C', 'D']]) == [123, 'b', ['C', 'D']], "Second list"
    assert lenient_lowercase([1, 'b', 2, 'c', 3]) == [1, 'b', 2, 'c', 3], "Third list"
    assert lenient_lowercase(['A', 'B', ['C', 'D']]) == ['a', 'b', ['C', 'D']], "Fourth list"



# Generated at 2022-06-11 01:40:47.963743
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest


# Generated at 2022-06-11 01:40:51.592330
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C', 2]) == ['a', 'b', 'c', 2]


# Generated at 2022-06-11 01:41:03.158656
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Unit test for function human_to_bytes'''

    def test_human_to_bytes_with_unit(value, unit, isbits, expect):
        result = human_to_bytes(value, unit, isbits)
        assert result == expect, "Expected %d, is %d (default unit=%s, isbits=%s, input=%s)" % (expect, result, unit, isbits, value)


# Generated at 2022-06-11 01:41:14.893670
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Verify human_to_bytes
    #
    #  - Convert from bytes to bits.
    assert (human_to_bytes('10B', isbits=True) == 80)
    assert (human_to_bytes(1024, isbits=True) == 8192)
    assert (human_to_bytes(1024, 'B', isbits=True) == 8192)
    assert (human_to_bytes('1000', 'b') == 125000)
    assert (human_to_bytes(8192, 'b') == 1024000)

    #  - Convert from bits to bytes.
    assert (human_to_bytes('10b') == 1)
    assert (human_to_bytes(8192, 'b') == 1024000)
    assert (human_to_bytes(1024000) == 1024000)

# Generated at 2022-06-11 01:41:20.315728
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test various cases of the function
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1B', isbits=True) == 1

    assert human_to_bytes('1k', isbits=True) == 1024
    assert human_to_bytes('1K', isbits=True) == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1k') == 1024

    assert human_to_bytes('1m') == 1024**2
    assert human_to_bytes('1M') == 1024**2
    assert human_to_bytes('1m', isbits=True) == 1024**2
    assert human_to

# Generated at 2022-06-11 01:41:32.603689
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1000) == '1.00 KB'
    assert bytes_to_human(1000000) == '1.00 MB'
    assert bytes_to_human(1000000000) == '1.00 GB'
    assert bytes_to_human(1000000000000) == '1.00 TB'
    assert bytes_to_human(1000000000000000) == '1.00 PB'
    assert bytes_to_human(1000000000000000000) == '1.00 EB'
    assert bytes_to_human(1000000000000000000000) == '1.00 ZB'
    assert bytes_to_human(1000000000000000000000000) == '1.00 YB'
    assert bytes_to_human(1099511627776) == '1.00 TB'

# Generated at 2022-06-11 01:41:41.796841
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test for no unit of parameters
    result = human_to_bytes('2')
    assert result == 2
    # Test for simple input
    result = human_to_bytes('2.1M')
    assert result == 2202011
    # Test for default unit parameter
    result = human_to_bytes('2.2', 'M')
    assert result == 2200000
    # Test for bits
    result = human_to_bytes('3.3Mb', True)
    assert result == 3300000
    # Test for failure
    failed = False
    try:
        human_to_bytes('2.2', 'D')
    except Exception:
        failed = True
    assert failed



# Generated at 2022-06-11 01:41:56.727037
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['foo', 'bar']) == ['foo', 'bar']
    assert lenient_lowercase(['FOO', 'BAR']) == ['foo', 'bar']
    assert lenient_lowercase(['foo', u'b\xe4r']) == ['foo', u'b\xe4r']
    assert lenient_lowercase([u'f\xf6o', 'bar']) == [u'f\xf6o', 'bar']
    assert lenient_lowercase([u'f\xf6o', u'b\xe4r']) == [u'f\xf6o', u'b\xe4r']
    assert lenient_lowercase([1, 2]) == [1, 2]

# Generated at 2022-06-11 01:42:07.026063
# Unit test for function lenient_lowercase

# Generated at 2022-06-11 01:42:11.414182
# Unit test for function human_to_bytes
def test_human_to_bytes():
    tests = {
        '10': 10,
        '20K': 20000,
        '0.5M': 512000,
        '1G': 1000000000,
    }

    for key, value in iteritems(tests):
        assert human_to_bytes(key) == value



# Generated at 2022-06-11 01:42:20.754817
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:42:31.178929
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # In bytes
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2K') == human_to_bytes(2, 'K')
    assert human_to_bytes('2KB') == human_to_bytes(2, 'KB')
    assert human_to_bytes('2Kb') == human_to_bytes(2, 'kb')
    assert human_to_bytes('2kB') == human_to_bytes(2, 'kB')
    # In bits
    assert human_to_bytes('2K', isbits=True) == (2048 * 8)
    assert human_to_bytes('2K', isbits=True) == human_to_bytes(2, 'K', isbits=True)
    assert human_to_bytes('2KB', isbits=True) == human_to

# Generated at 2022-06-11 01:42:42.355891
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:42:54.000839
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("2M") == 2097152
    assert human_to_bytes("800") == 800
    assert human_to_bytes("1M", "B") == 1048576
    assert human_to_bytes("1", "m") == 1048576
    assert human_to_bytes("1M", "b") == 1048576
    assert human_to_bytes("1Mb") == 1048576
    assert human_to_bytes("1Mb", isbits=True) == 1048576
    assert human_to_bytes("10mb", isbits=True) == 10485760
    assert human_to_bytes("10MB", isbits=True) == 10485760
    assert human_to_bytes("10MB", isbits=True, unit="b") == 10485760
    assert human_to

# Generated at 2022-06-11 01:43:05.352012
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """ Tests the lenient_lowercase function. """
    # Create a list of mixed objects
    mixed_list = ["str1", 2, "str3", 4]
    # Create a string
    test_string = "SomeString"
    # Create a dictionary
    test_dictionary = {"key1": "value1"}

    # Strings should be lower cased
    assert lenient_lowercase([test_string]) == ["somestring"]
    # Lists should be lower cased
    assert lenient_lowercase(mixed_list) == ["str1", 2, "str3", 4]
    # Dictionaries should be lower cased
    assert lenient_lowercase(test_dictionary) == {"key1": "value1"}
    # Empty lists should pass
    assert lenient_lowercase([]) == []
    # Empty

# Generated at 2022-06-11 01:43:17.781506
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1.2M') == 1258291
    assert human_to_bytes('1.2T') == 12884901888
    assert human_to_bytes('1.2Tb') == 12884901888
    assert human_to_bytes('1.2E') == 13194139533312
    assert human_to_bytes('1.2Eb') == 13194139533312
    assert human_to_bytes('1.2Eb', isbits=True) == 13194139533312
    assert human_to_bytes('1Mb', isbits=True) == 1048576

# Generated at 2022-06-11 01:43:30.170825
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2') == 2
    assert human_to_bytes('2b') == 2
    assert human_to_bytes('2B') == 2
    assert human_to_bytes('2K') == 2 * 1024
    assert human_to_bytes('2M') == 2 * 1024 * 1024
    assert human_to_bytes('2K', isbits=True) == 2 * 1024 * 8
    assert human_to_bytes('2M', isbits=True) == 2 * 1024 * 1024 * 8
    assert human_to_bytes('2M', default_unit='b') == 2 * 1024 * 1024 * 8
    assert human_to_bytes(2, default_unit='k') == 2 * 1024
    assert human_to_bytes(2, default_unit='M') == 2 * 1024 * 1024
    assert human_to_

# Generated at 2022-06-11 01:43:43.985272
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # List of test data, where the first element is the input, and the second
    # element is the expected output.
    test_data = [['Hello World', 'hello world'],
                 ['HELLO WORLD', 'hello world'],
                 [123, 123],
                 [['Hello'], ['hello']],
                 [['HELLO'], ['hello']]]

    for data in test_data:
        input = data[0]
        output = data[1]
        assert output == lenient_lowercase(input)

# Generated at 2022-06-11 01:43:55.825032
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes(1024) == 1024
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1g') == 1073741824
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1t') == 1099511627776
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1TB') == 1099511627776
    assert human_to

# Generated at 2022-06-11 01:44:06.136365
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Raise value error if can't parse string
    try:
        human_to_bytes('mb')
    except ValueError as err:
        assert "can't interpret" in str(err)

    # Raise value error if no units specified, even with a number
    try:
        human_to_bytes('1')
    except ValueError as err:
        assert "specified" in str(err)

    # Raise value error if unit is 'b'
    try:
        human_to_bytes('1b')
    except ValueError as err:
        assert "'B' (uppercase)" in str(err)

    # Return number if suffix is returned as bytes
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1MB', unit='B') == 1048576
    assert human_to_bytes

# Generated at 2022-06-11 01:44:12.397507
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 'B', 'C']) != ['a', 'b', 'C']



# Generated at 2022-06-11 01:44:15.748503
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['one', 'Two', '3', 'IV']
    result = ['one', 'two', '3', 'IV']
    assert lenient_lowercase(test_list) == result


# Generated at 2022-06-11 01:44:18.123883
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['FOO', 'BAR', None, False]) == ['foo', 'bar', None, False])



# Generated at 2022-06-11 01:44:28.046740
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('23') == 23
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', default_unit='B') == 10485760
    assert human_to_bytes('10') == 10
    assert human_to_bytes(10) == 10
    assert human_to_bytes(10, default_unit='B') == 10
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('10KB') == 10240
    assert human_to_bytes('10K', default_unit='B') == 10240
    assert human_to_

# Generated at 2022-06-11 01:44:31.746519
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['123', '456', 789]) == ['123', '456', 789]
    assert lenient_lowercase(['123.000', '456.000', 789.000]) == ['123.000', '456.000', 789.000]



# Generated at 2022-06-11 01:44:33.712279
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 1, None, object()]) == ['a', 1, None, object()]


# Generated at 2022-06-11 01:44:36.585899
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['abc', 'Abc'] == lenient_lowercase(['abc', 'Abc'])
    assert [123, 'Abc'] == lenient_lowercase([123, 'Abc'])

# Generated at 2022-06-11 01:44:51.045133
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1KB') == 1000
    assert human_to_bytes('1KB', 'B') == 1000
    assert human_to_bytes('1.1K') == 1100
    assert human_to_bytes('1.1 KB') == 1100
    assert human_to_bytes('1 mb') == 1000
    assert human_to_bytes('1mb') == 1000
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1 MB') == 1048576
    assert human_to_bytes('1 Mb') == 1048576
    assert human_to_bytes(1024, 'K') == 1
    assert human_to_bytes('1M') == 1048576
    assert human_

# Generated at 2022-06-11 01:45:00.972288
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest
    # testing string bytes
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    # testing string bits
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10m', isbits=True) == 10485760
    with pytest.raises(ValueError) as excinfo:
        human_to_bytes('10mB', isbits=True)
    assert 'expect Mb or bit' in str(excinfo.value)
    # testing pure number
    assert human_to_bytes(10) == 10
    # testing float number

# Generated at 2022-06-11 01:45:04.550982
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_input = [123, 'aBc', 'deF', 890]
    test_output = ['123', 'abc', 'def', '890']
    assert lenient_lowercase(test_input) == test_output


# Generated at 2022-06-11 01:45:15.971499
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1BB') == 1

    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 1048576

    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1.0KB') == 1024
    assert human_to_bytes('1.0Kb') == 1024
    assert human_to_bytes('1KBB') == 1024

    assert human_to_bytes('0.5Kb') == 512
    assert human_to_bytes('0.125Mb') == 131072
    assert human_to

# Generated at 2022-06-11 01:45:21.836740
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest


# Generated at 2022-06-11 01:45:24.706365
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['foo', 'bar', 3] == lenient_lowercase(['FOO', 'bar', 3])


# Generated at 2022-06-11 01:45:32.082555
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776

    try:
        assert human_to_bytes('1Z') == 0
        raise AssertionError('should not accept 1Z')
    except ValueError:
        pass

    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1Tb') == 1099511627776


# Generated at 2022-06-11 01:45:43.532125
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test bytes_to_human
    assert human_to_bytes("1B") is 1
    assert human_to_bytes("1K") is 1 << 10
    assert human_to_bytes("1KB") is 1 << 10
    assert human_to_bytes("1M") is 1 << 20
    assert human_to_bytes("1MB") is 1 << 20
    assert human_to_bytes("1G") is 1 << 30
    assert human_to_bytes("1GB") is 1 << 30
    assert human_to_bytes("1T") is 1 << 40
    assert human_to_bytes("1TB") is 1 << 40
    assert human_to_bytes("1P") is 1 << 50
    assert human_to_bytes("1PB") is 1 << 50
    assert human_to_bytes("1E") is 1 << 60


# Generated at 2022-06-11 01:45:47.014756
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'F', 3, {'key': 'value'}]) == ['a', 'b', 'f', 3, {'key': 'value'}]



# Generated at 2022-06-11 01:45:55.087378
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_set = [
        ('12', 12),
        ('10b', 10),
        ('10B', 10),
        ('10Gb', 10 * 1024 * 1024 * 1024),
        ('10GB', 10 * 1024 * 1024 * 1024),
        ('10G', 10 * 1024 * 1024 * 1024),
        ('1Mb', 1024 * 1024),
        ('1MB', 1048576),
        ('1M', 1048576),
        ('1Kb', 1024),
        ('1KB', 1024),
        ('1K', 1024),
    ]
    for test in test_set:
        assert human_to_bytes(test[0]) == test[1], "Testing %s expected %d got: %d" % (test[0], test[1], human_to_bytes(test[0]))



# Generated at 2022-06-11 01:46:05.567298
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Ricardo', 'MeNdez']) == ['ricardo', 'mendez']
    assert lenient_lowercase(['My Number', 5]) == ['my number', 5]
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']

# Generated at 2022-06-11 01:46:17.651080
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test wrong value return
    assert human_to_bytes('1Mb', True) == 1048576
    assert human_to_bytes('1MB', False) == 1048576
    try:
        human_to_bytes('1Mbs')
        raise ValueError('expected ValueError exception not raised')
    except ValueError:
        pass
    try:
        human_to_bytes('1Mb', False)
        raise ValueError('expected ValueError exception not raised')
    except ValueError:
        pass
    try:
        human_to_bytes('1MB', True)
        raise ValueError('expected ValueError exception not raised')
    except ValueError:
        pass
    # test conversion
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K', 'M') == 1024 * 1024


# Generated at 2022-06-11 01:46:27.505332
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # bytes cases
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10MB') == 10485760

    # bits cases
    assert human_to_bytes('10M', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 13107200
    assert human_to_bytes('10MB', isbits=True) == 13107200

    # integer cases
    assert human_to_bytes(10) == 10
    assert human_to_bytes(10, unit='KB') == 10240
    assert human_to_bytes(10, unit='Mb') == 1310720
    assert human_to_bytes(10, unit='MB') == 10

# Generated at 2022-06-11 01:46:38.281743
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:46:49.274426
# Unit test for function human_to_bytes
def test_human_to_bytes():
    data = {}
    data[1] = [('1', 1), ('1K', 1024), ('1.5Mb', 1536000),
               ('1MB', 1048576), ('1E', 1152921504606846976),
               ('1.5', 1.5), ('1.5.5', ValueError), ('1|5', ValueError),
               ('1.5K', 1536), ('1Eb', 1152921504606846976)]


# Generated at 2022-06-11 01:46:50.827795
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_human_to_bytes()

# Generated at 2022-06-11 01:46:54.317729
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    values = ['STRING', 1, 2.0, None]
    assert lenient_lowercase(values) == ['string', 1, 2.0, None]


# Generated at 2022-06-11 01:46:59.734302
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    values = ['lower', 'UPPER', 'Mixed', 1]
    converted = lenient_lowercase(values)

    assert converted[0] == 'lower'
    assert converted[1] == 'upper'
    assert converted[2] == 'mixed'
    assert converted[3] == 1

# Unit tests for function human_to_bytes

# Generated at 2022-06-11 01:47:08.285163
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = human_to_bytes('1B')
    assert result == 1

    result = human_to_bytes('1Mb', isbits=True)
    assert result == 1048576

    result = human_to_bytes('1B', default_unit='M')
    assert result == 1048576

    result = human_to_bytes('2.5G', default_unit='KB')
    assert result == 268435456

    result = human_to_bytes('2.5', default_unit='KB')
    assert result == 2560

    result = human_to_bytes('2.5GB', default_unit='KB')
    assert result == 2684354560


# Generated at 2022-06-11 01:47:15.412016
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    The following data was generated using shell commands.
    '''

# Generated at 2022-06-11 01:47:33.438459
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''test human_to_bytes function'''
    # Test for various inputs

# Generated at 2022-06-11 01:47:45.315079
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Bytes tests
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes(1024) == 1024
    assert human_to_bytes(1024, 'B') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1024B') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1MB') == 1024 ** 2
    assert human_to_bytes('1GB') == 1024 ** 3
    assert human_to_bytes('1TB') == 1024 ** 4

    # Bits tests
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1kb', isbits=True) == 1024

# Generated at 2022-06-11 01:47:50.987129
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['a', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 5, 6]) == ['a', 5, 6]
    assert lenient_lowercase(['a', 5, 6]) == ['a', 5, 6]


# Generated at 2022-06-11 01:48:03.121513
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:48:14.173031
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Unit test for function human_to_bytes
        Assert that the function convert a human readable string to bytes
        example: '1MB' => 1048576.
    '''
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1TB') == 1099511627776
    assert human_to_bytes('1PB') == 1125899906842624
    assert human_to_bytes('1PB') == 1125899906842624
    assert human_to_bytes('1EB') == 1152921504606846976
    assert human_to_bytes('1ZB') == 1180

# Generated at 2022-06-11 01:48:15.845024
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    return True

# Generated at 2022-06-11 01:48:21.922994
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1]) == [1]
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase([1, 'str']) == [1, 'str']
    assert lenient_lowercase(['str', 2]) == ['str', 2]
    assert lenient_lowercase(['str']) == ['str']
    assert lenient_lowercase([1, 2, 3, 'Str', 'STR', 'stR']) == [1, 2, 3, 'Str', 'STR', 'stR']



# Generated at 2022-06-11 01:48:33.006090
# Unit test for function human_to_bytes

# Generated at 2022-06-11 01:48:36.123859
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    l = ['FOO', 'bar', b'baz', u'spam']
    assert lenient_lowercase(l) == ['foo', 'bar', b'baz', u'spam']


# Generated at 2022-06-11 01:48:46.549280
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.2M') == 1228800
    assert human_to_bytes('1.2Mb') == 1572864000
    assert human_to_bytes('1.2MB', isbits=True) == 15728640000
    assert human_to_bytes('1.2MB') == 12582912
    assert human_to_bytes('10Mb') == 1572864000
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10MB', 'MB') == 10485760
    assert human_to_bytes('3.3MB') == 34603008

# Generated at 2022-06-11 01:49:08.269140
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["A", "B", "C"]) == ["a", "b", "c"]
    assert lenient_lowercase(["a", "b", "c"]) == ["a", "b", "c"]
    assert lenient_lowercase(["a", "b", 12345]) == ["a", "b", 12345]



# Generated at 2022-06-11 01:49:16.937377
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB', default_unit='B') == 1048576
    assert human_to_bytes('1MB', default_unit='b') == 1048576
    assert human_to_bytes('1Mb', default_unit='B') == 1048576
    assert human_to_bytes('1Mb', default_unit='b') == 1048576
    assert human_to_bytes('1MB', default_unit='b', isbits=True) == 1048576
    assert human_to_bytes('1Mb', default_unit='B', isbits=True) == 1048576

# Generated at 2022-06-11 01:49:25.005772
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test successful conversions
    # bytes with 'b'
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('10b', isbits=True) == 10
    # bytes with 'B'
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10B', isbits=True) == 10
    assert human_to_bytes('1B', isbits=True) == 1
    # kilobytes with 'Kb'
    assert human_to_bytes('1Kb') == 1000
    assert human_to_bytes('1kb') == 1000
    assert human_to

# Generated at 2022-06-11 01:49:34.709959
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [
        'STUFF',

        ['STUFF', 'WITH', 'MORESTUFF'],
        ['STUFF', ('WITH', 'STUFF'), 'MORESTUFF'],
        ['STUFF', ('WITH', ('STUFF',)), 'MORESTUFF'],

        ('STUFF', 'WITH', 'MORESTUFF'),
        ('STUFF', ('WITH', 'STUFF'), 'MORESTUFF'),
        ('STUFF', ('WITH', ('STUFF',)), 'MORESTUFF'),
    ]

    for entry in test_list:
        assert lenient_lowercase(entry) == entry.lower()


# Generated at 2022-06-11 01:49:46.210688
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('0.01M') == 10240
    assert human_to_bytes('5K') == 5120
    assert human_to_bytes('2G') == 2147483648
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Z') == 1125899906842624
    assert human_to_bytes('1Y') == 1152921504606846976

    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10Mb') == 1048

# Generated at 2022-06-11 01:49:51.603941
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1000') == 1000
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824

    with pytest.raises(ValueError):
        human_to_bytes('1ABC')



# Generated at 2022-06-11 01:49:58.710860
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase([1, 'b', 3]) == [1, 'b', 3]
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']



# Generated at 2022-06-11 01:50:08.749362
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b', isbits=True) == 10
    assert human_to_bytes('1.1B') == 1
    assert human_to_bytes('2K') == 2000
    assert human_to_bytes('1M') == 1000000
    assert human_to_bytes('2M') == 2000000
    assert human_to_bytes('1Mb', isbits=True) == 1000000
    assert human_to_bytes('2Mb', isbits=True) == 2000000
    assert human_to_bytes('2Mb', isbits=False) == 2080000
    assert human_to_bytes('2 mB', default_unit='B') == 2000000
    assert human_to_bytes