

# Generated at 2022-06-22 22:12:11.763968
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import itertools

    test_list_1 = ['0', '1', '2.2', '2.4', '2.1', '2', '2.00000001']
    test_list_2 = ['', 'b', 'B', 'a', 'A', 'BB', 'Aa']
    test_list = list(itertools.product(test_list_1, test_list_2))
    for number, unit in test_list:
        print("Testing number = %s (unit = %s) ..." % (number, unit))

# Generated at 2022-06-22 22:12:19.896325
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert -1 != human_to_bytes('1')
    assert -1 != human_to_bytes('1K')
    assert -1 != human_to_bytes('1M')
    assert -1 != human_to_bytes('1G')
    assert -1 != human_to_bytes('1T')
    assert -1 != human_to_bytes('1P')
    assert -1 != human_to_bytes('1E')
    assert -1 != human_to_bytes('1Z')
    assert -1 != human_to_bytes('1Y')

    assert 1048576 == human_to_bytes('1m')
    assert 1048576 == human_to_bytes('1M')
    assert 1048576 == human_to_bytes('1MB')
    assert 1048576 == human_to_bytes('1mb')
   

# Generated at 2022-06-22 22:12:30.468295
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(537592713359) == '497.67 GB'
    assert bytes_to_human(537592713359, unit='GB') == '497.67 GB'
    assert bytes_to_human(537592713359, unit='TB') == '0.49 TB'
    assert bytes_to_human(537592713359, unit='MB') == '5375.93 MB'
    assert bytes_to_human(537592713359, unit='KB') == '5411402.34 KB'
    assert bytes_to_human(537592713359, unit='B') == '537592713359 Bytes'
    assert bytes_to_human(5) == '5 Bytes'
    assert bytes_to_human(0) == '0 Bytes'



# Generated at 2022-06-22 22:12:42.233580
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import unittest

# Generated at 2022-06-22 22:12:53.468181
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Any object which is not string
    class TestClass:
        pass

    class TestClass2:
        def __str__(self):
            return 'test'
    test_class = TestClass()
    test_class2 = TestClass2()

    assert lenient_lowercase(['TEST', 'TEST2']) == ['test', 'test2']
    assert lenient_lowercase(['test', 'TEST', 'TEST2']) == ['test', 'test', 'test2']
    assert lenient_lowercase([test_class, 'TEST']) == [test_class, 'test']
    assert lenient_lowercase(['test', test_class2]) == ['test', 'test']



# Generated at 2022-06-22 22:12:58.542664
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([2]) == [2]
    assert lenient_lowercase(['foo', 2, 'bar']) == ['foo', 2, 'bar']
    assert lenient_lowercase(['foo', 'FOO', 'bar']) == ['foo', 'FOO', 'bar']
    assert lenient_lowercase(['F00', 'FOO', 'bar']) == ['f00', 'FOO', 'bar']

# Generated at 2022-06-22 22:13:10.612346
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == "0 Bytes"
    assert bytes_to_human(10) == "10 Bytes"
    assert bytes_to_human(100) == "100 Bytes"
    assert bytes_to_human(1000) == "1.00 KB"
    assert bytes_to_human(10000) == "9.77 KB"
    assert bytes_to_human(100000) == "97.66 KB"
    assert bytes_to_human(1000000) == "976.56 KB"
    assert bytes_to_human(10000000) == "9.54 MB"
    assert bytes_to_human(100000000) == "95.37 MB"
    assert bytes_to_human(1000000000) == "953.67 MB"

# Generated at 2022-06-22 22:13:15.819285
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(["a", "B", "c"]) == ["a", "B", "c"]
    assert lenient_lowercase(["a", 123, "A", "b", "C"]) == ["a", 123, "A", "b", "C"]


# Generated at 2022-06-22 22:13:24.481512
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # bytes
    assert bytes_to_human(0, False) == '0 bytes'
    assert bytes_to_human(10, False) == '10 bytes'
    assert bytes_to_human(1023, False) == '1023 bytes'
    assert bytes_to_human(1024, False) == '1 KB'
    assert bytes_to_human(1024**2, False) == '1 MB'
    assert bytes_to_human(1024**3, False) == '1 GB'
    assert bytes_to_human(1024**4, False) == '1 TB'
    assert bytes_to_human(1024**5, False) == '1 PB'
    assert bytes_to_human(1024**6, False) == '1 EB'
    assert bytes_to_human(1024**7, False) == '1 ZB'


# Generated at 2022-06-22 22:13:30.336631
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b']) == ['a', 'b']
    assert lenient_lowercase(['A', 'b']) == ['a', 'b']
    assert lenient_lowercase(['A', 'b', 2]) == ['a', 'b', 2]
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']


# Unit tests for function human_to_bytes

# Generated at 2022-06-22 22:13:40.223125
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == "0 Bytes"
    assert bytes_to_human(1) == "1 Byte"
    assert bytes_to_human(2) == "2 Bytes"
    assert bytes_to_human(0.1) == "0.10 Bytes"
    assert bytes_to_human(0.2) == "0.20 Bytes"
    assert bytes_to_human(10 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == "1.00 YBytes"
    assert bytes_to_human(10 * 1024 * 1024 * 1024 * 1024 * 1024) == "1.00 ZBytes"
    assert bytes_to_human(10 * 1024 * 1024 * 1024 * 1024) == "1.00 EBytes"

# Generated at 2022-06-22 22:13:50.417239
# Unit test for function bytes_to_human
def test_bytes_to_human():
    for x  in (1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000, 10000000000, 100000000000, 1000000000000, 10000000000000, 100000000000000, 1000000000000000, 10000000000000000, 100000000000000000, 1000000000000000000, 10000000000000000000, 100000000000000000000, 1000000000000000000000):
        print(x, bytes_to_human(x))
    for x  in (1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000, 10000000000, 100000000000, 1000000000000, 10000000000000, 100000000000000, 1000000000000000, 10000000000000000, 100000000000000000, 1000000000000000000, 10000000000000000000, 100000000000000000000, 1000000000000000000000):
        print(x, bytes_to_human(x, isbits=True))

# Generated at 2022-06-22 22:13:53.742389
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase([23, 'H', 'e', 'l', 'L', 'o'])
    assert result == [23, 'h', 'e', 'l', 'l', 'o']



# Generated at 2022-06-22 22:14:01.404292
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:14:11.454322
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """Test for bytes_to_human()"""
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-22 22:14:23.468560
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # testing bytes and bits
    result = human_to_bytes('10M')
    assert result == 10485760, "10M should return 10485760"
    result = human_to_bytes('10Mb')
    assert result == 8388608, "10Mb should return 8388608"
    result = human_to_bytes('10Mb', isbits=True)
    assert result == 8388608, "10Mb should return 8388608"
    result = human_to_bytes('10MB', isbits=True)
    assert result == 8388608, "10MB should return 8388608"
    result = human_to_bytes('10MB')
    assert result == 10485760, "10MB should return 10485760"



# Generated at 2022-06-22 22:14:27.820459
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst1 = lenient_lowercase(['A', 'AB', 'ABC'])
    assert lst1 == ['a', 'ab', 'abc']

    lst2 = lenient_lowercase(['A', 'AB', 'ABC', 10, {'A': 10}])
    assert lst2 == ['a', 'ab', 'abc', 10, {'A': 10}]



# Generated at 2022-06-22 22:14:38.755029
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Unit test for bytes_to_human (normal case)
    def test_bytes_to_human():
        data = {
            '1': '1.00 Bytes',
            '1024': '1.00 KBytes',
            '1536': '1.50 KBytes',
            '1048576': '1.00 MBytes',
        }
        for source, expected in data.items():
            assert bytes_to_human(int(source)) == expected

    # Test case when bits are supplied.
    def test_bits_to_human():
        data = {
            '1': '1.00 bits',
            '8': '1.00 bits',
            '1024': '128.00 bits',
            '1536': '192.00 bits',
            '1048576': '131072.00 bits',
        }

# Generated at 2022-06-22 22:14:44.060544
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C', 'D', 'E']) == ['a', 'b', 'c', 'd', 'e']
    assert lenient_lowercase(['A', 1, 'C', 'D', 'E']) == ['a', 1, 'c', 'd', 'e']


# Generated at 2022-06-22 22:14:46.708366
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'A', 'b', 'Cc']) == [1, 'a', 'b', 'Cc']



# Generated at 2022-06-22 22:14:51.851167
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_string = ['thIs', 'S', 'is', 'testing', 'function']
    output_string = lenient_lowercase(input_string)
    expected_output = ['this', 'S', 'is', 'testing', 'function']
    assert expected_output == output_string, "Lenient lowercase function failed"



# Generated at 2022-06-22 22:15:02.836657
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('15.7K') == 16000
    assert human_to_bytes('15.7K', isbits=True) == 16000
    assert human_to_bytes('15.7M', isbits=True) == 16000000

    try:
        human_to_bytes('15.7K', isbits=True, default_unit='b')
        raise Exception()
    except ValueError:
        pass

    assert human_to_bytes(15.7, default_unit='MB') == 16000000
    assert human_to_bytes(15.7, default_unit='Kb') == 16000
    assert human_to_bytes(15.7, default_unit='Kb', isbits=True) == 16000


# Generated at 2022-06-22 22:15:06.095234
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['a', 'b', 1, 2]
    test_lst = ['a', 'b', 1, 2]
    assert lenient_lowercase(lst) == test_lst


# Generated at 2022-06-22 22:15:15.516313
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:15:25.361619
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    cases = [
        # Input, output
        ['', []],
        [[], []],
        [{}, []],
        [['a'], ['a']],
        [['A'], ['a']],
        [['A', 'B', 'C'], ['a', 'b', 'c']],
        [['A', 'b', 'C'], ['a', 'b', 'c']],
        [['A', 1, 'C'], ['a', 1, 'c']],
        [['A', 1, 'C', 'D', 'e', 'F'], ['a', 1, 'c', 'd', 'e', 'f']],
    ]
    for case in cases:
        assert lenient_lowercase(case[0]) == case[1]


# Generated at 2022-06-22 22:15:37.164548
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1k', unit='b') == 1024
    assert human_to_bytes('1k', unit='B') == 1024
    assert human_to_bytes('1kb', unit='b') == 1000
    assert human_to_bytes('1kb', unit='B') == 1000
    assert human_to_bytes('1Mb', unit='b') == 1000000
    assert human_to_bytes('1Mb', unit='B') == 1000000
    assert human_to_bytes('1mb', unit='B') == 131072
    assert human_to_bytes('1MB', unit='b') == 131072
    assert human_to_bytes('1Mb') == 1000000
    assert human_to_bytes('1mb') == 131072
    assert human_to_bytes('1MB') == 131072

# Generated at 2022-06-22 22:15:47.906367
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['foo', 100, 'bar', 42, 'Baz']) == ['foo', 100, 'bar', 42, 'Baz']
    assert lenient_lowercase(['FOO', 100, 'bar', 42, 'BaZ']) == ['foo', 100, 'bar', 42, 'BaZ']
    assert lenient_lowercase(['FOO', 100, 'bar', 42, 'BaZ']) == ['foo', 100, 'bar', 42, 'BaZ']
    assert lenient_lowercase(['FOO']) == ['FOO']
    assert lenient_lowercase([100]) == [100]
    assert lenient_lowercase(['FOO', 'bar']) == ['FOO', 'bar']

# Generated at 2022-06-22 22:15:59.241812
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:16:10.966707
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test bytes case
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1024b') == 1024
    assert human_to_bytes('1024Bytes') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1KB', isbits=False) == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1 Mb') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1.1Kb') == 1120
    assert human_to_bytes('1,1Kb') == 1120
    assert human_to_bytes('1.1Mb') == 1152000
    assert human

# Generated at 2022-06-22 22:16:14.578005
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['FOO', 'bar', 1, 'baz']

    assert lenient_lowercase(lst) == ['foo', 'bar', 1, 'baz']



# Generated at 2022-06-22 22:16:23.867164
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Test function lenient_lowercase (in util.py)."""
    # Empty list case
    lst = []
    assert lenient_lowercase(lst) == []

    # basic list case
    lst = ['Alpha', 'beta', 'Gamma']
    assert lenient_lowercase(lst) == ['alpha', 'beta', 'gamma']

    # list with non-string items
    lst = ['Alpha', 123, 'Beta', 456]
    assert lenient_lowercase(lst) == ['alpha', 123, 'beta', 456]


# Unit tests for human_to_bytes

# Generated at 2022-06-22 22:16:30.567165
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10240) == '10.00 KB'
    assert bytes_to_human(10240, unit='K') == '10.00 KB'
    assert bytes_to_human(10240, unit='M') == '0.01 MB'

    # test in bits
    assert bytes_to_human(10240, True) == '8.00 Kb'
    assert bytes_to_human(10240, True, 'K') == '8.00 Kb'
    assert bytes_to_human(10240, True, 'M') == '0.01 Mb'


# Generated at 2022-06-22 22:16:36.434300
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    class weird_string:
        def lower(self):
            return 'weird'
    lowercased = lenient_lowercase(['HELLO', 5, 'World', weird_string()])
    assert lowercased == ['hello', 5, 'world', 'weird']


# Generated at 2022-06-22 22:16:47.786270
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        result = human_to_bytes('10M')
        assert result == 10485760
    except Exception as e:
        assert result == None, "unable to convert to bytes '10M'. error: %s" % str(e)

    try:
        result = human_to_bytes('5G')
        assert result == 5368709120
    except Exception as e:
        assert result == None, "unable to convert to bytes '5G'. error: %s" % str(e)

    try:
        result = human_to_bytes('1K', default_unit='B')
        assert result == 1024
    except Exception as e:
        assert result == None, "unable to convert to bytes '1K' with default unit = 'B'. error: %s" % str(e)


# Generated at 2022-06-22 22:16:59.458531
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10.25M') == 10485760
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('2.5B') == 3
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('2.5Kb') == 2560
    assert human_to_bytes('2.5Kb', isbits=True) == 2560
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('2.5kb') == 2560
    assert human_to_bytes(1024) == 1024
    assert human_to_bytes(1024, 'B')

# Generated at 2022-06-22 22:17:03.309016
# Unit test for function bytes_to_human
def test_bytes_to_human():
    human = bytes_to_human(1000000000)
    assert human == '976.56 MB', 'failed to convert Bytes in MB'
    human = bytes_to_human(1000000000, isbits=True)
    assert human == '781.25 Mb', 'failed to convert bits in Mb'
    return None


# Generated at 2022-06-22 22:17:10.941872
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # exception test
    try:
        human_to_bytes(None)
    except ValueError:
        pass
    else:
        assert False, "Expected exception for None input"
    try:
        human_to_bytes('invalid')
    except ValueError:
        pass
    else:
        assert False, "Expected exception for invalid input"
    # bytes case
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.1B') == 1
    assert human_to_bytes('1.1KB') == 1116
    assert human_to_bytes('0.1MB') == 100000
    assert human_to_bytes('1024') == 1024
    assert human

# Generated at 2022-06-22 22:17:21.264710
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # tests with bytes identifier (default)
    assert human_to_bytes("1KB") == 1024
    assert human_to_bytes("1KB", default_unit='B') == 1024
    assert human_to_bytes("1KB", default_unit='b') == 1024
    assert human_to_bytes("1B", default_unit='b') == 1
    assert human_to_bytes("1Kb") == 10**3
    assert human_to_bytes("1kb", default_unit='b') == 10**3
    assert human_to_bytes("1Kb", unit='B') == 10**3
    assert human_to_bytes("1Kb", unit='b') == 8192
    assert human_to_bytes("12b") == 12
    assert human_to_bytes("12b", default_unit='B') == 12
   

# Generated at 2022-06-22 22:17:26.626753
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    l1 = ['One', 'Two', 'Three']
    l2 = [1, 2, 'Three']
    assert l1 == lenient_lowercase(l1)
    assert ['one', 'two', 'Three'] == lenient_lowercase(l2)


# Generated at 2022-06-22 22:17:30.687620
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lowered = lenient_lowercase(['aBc', 1, 'dEf'])
    assert lowered == ['abc', 1, 'def']
    lowered = lenient_lowercase(['aBc', None, 'dEf'])
    assert lowered == ['abc', None, 'def']

# Generated at 2022-06-22 22:17:40.352903
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human(1099511627776) == '1.00 TB'
    assert bytes_to_human(1125899906842624) == '1.00 PB'
    assert bytes_to_human(1152921504606846976) == '1.00 EB'
    assert bytes_to_human(1180591620717411303424) == '1.00 ZB'
    assert bytes_to_human

# Generated at 2022-06-22 22:17:45.318818
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, '4', 'ab']) == [1, '4', 'ab']
    assert lenient_lowercase([1, '4', 'Ab']) == [1, '4', 'ab']
    assert lenient_lowercase(['A', '4', 'ab']) == ['a', '4', 'ab']

# Generated at 2022-06-22 22:17:51.945782
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 2, 'C']) == ['a', 2, 'c']
    assert lenient_lowercase(['a', 2, object]) == ['a', 2, object]



# Generated at 2022-06-22 22:18:03.879159
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == "1 Bytes"
    assert bytes_to_human(1, True) == "1 bits"
    assert bytes_to_human(1023) == "1023 Bytes"
    assert bytes_to_human(1023, True) == "1023 bits"
    assert bytes_to_human(1024) == "1.00 kB"
    assert bytes_to_human(1024, True) == "1.00 kbit"
    assert bytes_to_human(1023 * 1024) == "1023.00 kB"
    assert bytes_to_human(1023 * 1024, True) == "1023.00 kbit"
    assert bytes_to_human(1024 * 1024) == "1.00 MB"

# Generated at 2022-06-22 22:18:16.203613
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(100) == '100 Bytes'
    assert bytes_to_human(100e3) == '100 KB'
    assert bytes_to_human(100e6) == '100 MB'
    assert bytes_to_human(100e9) == '100 GB'
    assert bytes_to_human(100e12) == '100 TB'
    assert bytes_to_human(100e15) == '100 PB'
    assert bytes_to_human(100e18) == '100 EB'
    assert bytes_to_human(100e21) == '100 ZB'
    assert bytes_to_human(100e24) == '100 YB'

# Generated at 2022-06-22 22:18:26.692670
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10, unit='m') == '0.01 MB'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(100) == '100 Bytes'
    assert bytes_to_human(1000) == '1000 Bytes'
    assert bytes_to_human(2000) == '1.95 KB'
    assert bytes_to_human(10240) == '10.00 KB'
    assert bytes_to_human(32000000) == '30.51 MB'
    assert bytes_to_human(64000000) == '61.00 MB'
    assert bytes_to_human(0.01) == '10 Bytes'
    assert bytes_to_human(0.10) == '100 Bytes'
    assert bytes_to_human(0.50)

# Generated at 2022-06-22 22:18:33.680292
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10KiB') == 1024 * 10
    assert human_to_bytes('10KByte') == 1024 * 10
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'MB') == 10485760
    assert human_to_bytes(10.0, 'MB') == 10485760
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576

# Generated at 2022-06-22 22:18:39.458932
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b']) == ['a', 'b']
    assert lenient_lowercase(['A', 'B']) == ['a', 'b']
    assert lenient_lowercase(['A', 'B', '1', 2, True]) == ['a', 'b', '1', 2, True]


# Generated at 2022-06-22 22:18:45.691878
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10000) == '9.77 KB'

    # test bits
    assert bytes_to_human(10000, isbits=True) == '9.77 Kb'

    # test unit
    assert bytes_to_human(10000, unit='m') == '9.77 MB'
    assert bytes_to_human(10000, isbits=True, unit='m') == '9.77 Mb'



# Generated at 2022-06-22 22:18:48.202826
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Hello', 1, 'WORLD', 3.2, 4]) == ['hello', 1, 'world', 3.2, 4]


# Generated at 2022-06-22 22:18:57.716389
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('0') == 0
    assert human_to_bytes('0.0') == 0
    assert human_to_bytes('0b') == 0
    assert human_to_bytes('0B') == 0
    assert human_to_bytes('0.0b') == 0
    assert human_to_bytes('0.0B') == 0
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('100') == 100

# Generated at 2022-06-22 22:19:08.776684
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """Test function bytes_to_human"""
    assert bytes_to_human(500) == '500 Bytes'
    assert bytes_to_human(500, unit='b') == '500 bits'
    assert bytes_to_human(500, unit='b',isbits=True) == '500 bits'
    assert bytes_to_human(500, unit='kb') == '500 KBytes'
    assert bytes_to_human(500, unit='mb') == '500 MBytes'
    assert bytes_to_human(500, unit='zb') == '500 Zbits'
    assert bytes_to_human(500, unit='zb',isbits=True) == '500 Zbits'
    assert bytes_to_human(500, unit='bz') == '500 bZ'

# Generated at 2022-06-22 22:19:16.230153
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == "1.00 Bytes"
    assert bytes_to_human(1, unit='B') == "1.00 Bytes"
    assert bytes_to_human(1, unit='b') == "1.00 bits"
    assert bytes_to_human(10) == "10.00 Bytes"
    assert bytes_to_human(10, unit='B') == "10.00 Bytes"
    assert bytes_to_human(10, unit='b') == "10.00 bits"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1024, unit='K') == "1.00 KB"
    assert bytes_to_human(1024, unit='Kb') == "1.00 Kbits"
    assert bytes_to_human

# Generated at 2022-06-22 22:19:19.211256
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Foo', 'Bar', 1, 'Baz', None, True, False]) == ['foo', 'bar', 1, 'baz', None, True, False]



# Generated at 2022-06-22 22:19:30.263495
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10 B'
    assert bytes_to_human(10, unit='M') == '0.01 MB'
    assert bytes_to_human(10, unit='K') == '10 KB'
    assert bytes_to_human(10, unit='G') == '0.00 GB'
    assert bytes_to_human(10, isbits=True) == '10 b'
    assert bytes_to_human(10, unit='M', isbits=True) == '0.01 Mb'
    assert bytes_to_human(10, unit='K', isbits=True) == '10 Kb'
    assert bytes_to_human(10, unit='G', isbits=True) == '0.00 Gb'

# Generated at 2022-06-22 22:19:33.565243
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [1, 'Test', 3, 'WORD']
    assert sorted(lenient_lowercase(lst)) == sorted(lst)



# Generated at 2022-06-22 22:19:41.320519
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [5, 'aBc', [1, 2, 3], {'a': 1}, (1, 2, 3), '123']
    lst_lowered = lenient_lowercase(lst)

    assert lst_lowered[0] == lst[0]
    assert lst_lowered[1] == 'abc'
    assert lst_lowered[2] == lst[2]
    assert lst_lowered[3] == lst[3]
    assert lst_lowered[4] == lst[4]
    assert lst_lowered[5] == '123'

# Generated at 2022-06-22 22:19:50.487350
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(200, isbits=False, unit='B') == '200.00 Bytes'
    assert bytes_to_human(4, isbits=False, unit='B') == '4.00 Bytes'
    assert bytes_to_human(200, isbits=True, unit='b') == '200.00 bits'
    assert bytes_to_human(4, isbits=True, unit='b') == '4.00 bits'

    assert bytes_to_human(2000, isbits=False, unit='B') == '2.00 KB'
    assert bytes_to_human(2000, isbits=True, unit='b') == '2.00 Kb'
    assert bytes_to_human(2, isbits=False, unit='B') == '2.00 Bytes'
    assert bytes_to_

# Generated at 2022-06-22 22:20:03.204071
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10240) == '10.00 KB'
    assert bytes_to_human(10240, isbits=True) == '82.00 Kbits'
    assert bytes_to_human(10240, unit='kb') == '10.00 kb'
    assert bytes_to_human(10240, unit='kb', isbits=True) == '82.00 Kbits'
    assert bytes_to_human(10240, unit='KB') == '10.00 KB'
    assert bytes_to_human(10240, unit='KB', isbits=True) == '82.00 Kbits'
    assert bytes_to_human(10240, unit='MB') == '0.01 MB'
    assert bytes_to_human(10240, unit='MB', isbits=True) == '0.01 Mbits'

# Generated at 2022-06-22 22:20:08.935916
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10, unit='B') == "10.00 Bytes"
    assert bytes_to_human(10, unit='K') == "0.01 KB"
    assert bytes_to_human(10, unit='M') == "0.00 MB"
    assert bytes_to_human(10, unit='G') == "0.00 GB"
    assert bytes_to_human(10, unit='T') == "0.00 TB"
    assert bytes_to_human(10, unit='P') == "0.00 PB"
    assert bytes_to_human(10, unit='E') == "0.00 EB"
    assert bytes_to_human(10, unit='Z') == "0.00 ZB"

# Generated at 2022-06-22 22:20:18.027736
# Unit test for function human_to_bytes
def test_human_to_bytes():
    success = True

# Generated at 2022-06-22 22:20:25.655227
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1, "incorrect value"
    assert human_to_bytes('1.0') == 1, "incorrect value"
    assert human_to_bytes('1M') == 1048576, "incorrect value"
    assert human_to_bytes('1.1M') == 1153433, "incorrect value"
    assert human_to_bytes('1.1MB') == 1153433, "incorrect value"
    assert human_to_bytes('1.1Mb', isbits=True) == 1153433, "incorrect value"
    assert human_to_bytes('1.1KB') == 1126, "incorrect value"
    assert human_to_bytes('1.1Kb', isbits=True) == 1126, "incorrect value"
    assert human_to_bytes

# Generated at 2022-06-22 22:20:33.185948
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert(bytes_to_human(1) == '1.00 Bytes')
    assert(bytes_to_human(0) == '0.00 Bytes')
    assert(bytes_to_human(10) == '10.00 Bytes')
    assert(bytes_to_human(500) == '500.00 Bytes')
    assert(bytes_to_human(1024) == '1.00 KB')
    assert(bytes_to_human(1024, unit='k') == '1.00 KB')
    assert(bytes_to_human(1000, unit='k') == '0.98 KB')



# Generated at 2022-06-22 22:20:36.559001
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    import pytest

    assert lenient_lowercase([1, 'A', 2, 'B']) == [1, 'a', 2, 'b']
    with pytest.raises(AttributeError):
        lenient_lowercase([None])

# Generated at 2022-06-22 22:20:44.573980
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1', 'mb') == 1048576
    assert human_to_bytes('1', 'mb', isbits=True) == 8388608

    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 8388

# Generated at 2022-06-22 22:20:55.173414
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('2G') == 2 * 1048576 * 1024
    assert human_to_bytes('3.3Y') == (3.3 * 10**24)
    assert human_to_bytes('1MiB') == 1048576
    assert human_to_bytes('1.1K') == 1120
    assert human_to_bytes('') == 0
    assert human_to_bytes('0b') == 0
    assert human_to_bytes(u'1KB') == 1024
    assert human_to_bytes(u'1\u00b0') == 0
    assert human_to_bytes('1b') == 1

# Generated at 2022-06-22 22:21:05.674814
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''Unit test for function bytes_to_human'''

# Generated at 2022-06-22 22:21:14.592358
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('2B') == 2
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976
    assert human_to_bytes('1Z') == 1180591620717411303424
    assert human_to_bytes('1Y') == 1208925819614629174706176
    assert human_to_bytes('1.5Y') == 1813388277410988

# Generated at 2022-06-22 22:21:25.208581
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:21:32.765927
# Unit test for function human_to_bytes
def test_human_to_bytes():
    cases = [('100', 100),
             ('100B', 100),
             ('100b', 100),
             ('100Bb', 100),
             ('100bB', 100),
             ('100KB', 101024),
             ('100KBb', 101024),
             ('100bKB', 101024),
             ('100Mb', 104857600),
             ('100MB', 104857600),
             ('100MbB', 104857600),
             ('100MBb', 104857600),
             ('100G', 107374182400),
             ('100Gb', 11258999068426240),
             ('100GbB', 11258999068426240),
             ('100GB', 107374182400),
             ('100GBb', 11258999068426240),
             (100, 100)]


# Generated at 2022-06-22 22:21:33.975031
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Hello', 'world', 1, 'there']) == ['hello', 'world', 1, 'there']



# Generated at 2022-06-22 22:21:36.593033
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    items = ['1', '2', '4', '8']
    expected = [1, 2, 4, 8]
    actual = [value for value in lenient_lowercase(items)]
    assert expected == actual



# Generated at 2022-06-22 22:21:40.267703
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['A', 'b', True, False, {}, {'a': 1}, 1, 'string', '1', None, 1.5, [], [1, 'b'], 'aBcD']
    assert lenient_lowercase(lst) == ['a', 'b', True, False, {}, {'a': 1}, 1, 'string', '1', None, 1.5, [], [1, 'b'], 'abcd']


# Generated at 2022-06-22 22:21:47.869431
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['foo']) == ['foo']
    assert lenient_lowercase(['foo', 'bar']) == ['foo', 'bar']
    assert lenient_lowercase(['FOO', 'BAR']) == ['foo', 'bar']
    assert lenient_lowercase(['foo', 10, 'bar']) == ['foo', 10, 'bar']
    assert lenient_lowercase(['FOO', 10, 'BAR']) == ['foo', 10, 'bar']



# Generated at 2022-06-22 22:21:57.557567
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1, 'M') == 1048576
    assert human_to_bytes(1, 'K') == 1024
    assert human_to_bytes(1, 'G') == 1073741824
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1 Mb') == 1048576
    assert human_to_bytes('1 Kb') == 1024
    assert human_to_bytes('1 Gb') == 1073741824
    assert human_to_bytes('1 Bb') == 1
    assert human_to_bytes('1 Bb', isbits=True) == 8
   

# Generated at 2022-06-22 22:22:05.883852
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # convert Byte Values
    values = [
        (0, '0B'),
        (1, '1B'),
        (1000, '1000B'),
        (1023, '1023B'),
        (1024, '1KB'),
        (1024 * 1024, '1MB'),
        (1024 * 1024 * 1024, '1GB'),
        (1024 * 1024 * 1024 * 1024, '1TB'),
        (1024 * 1024 * 1024 * 1024 * 1024, '1PB'),
        (1024 ** 5, '1EB'),
        (1024 ** 6, '1ZB'),
        (1024 ** 7, '1YB'),
    ]
    for num, value in values:
        assert num == human_to_bytes(value)

    # convert Bit Values