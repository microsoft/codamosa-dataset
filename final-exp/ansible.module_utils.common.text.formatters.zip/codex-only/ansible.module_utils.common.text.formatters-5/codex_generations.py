

# Generated at 2022-06-22 22:12:08.898527
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [1, 'aBc', 3.2, 'cDE fgh']
    result = [1, 'abc', 3.2, 'cde fgh']
    assert result == lenient_lowercase(lst)
    lst = ['abc', 2, 3, 'dD eFg', 4, 5]
    result = ['abc', 2, 3, 'dd efg', 4, 5]
    assert result == lenient_lowercase(lst)

# Generated at 2022-06-22 22:12:17.198215
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == "10.00 Bytes"
    assert bytes_to_human(10, isbits=False) == "10.00 Bytes"
    assert bytes_to_human(10, isbits=True) == "10.00 bits"
    assert bytes_to_human(10, unit='B') == "10.00 Bytes"
    assert bytes_to_human(10, unit='B', isbits=False) == "10.00 Bytes"
    assert bytes_to_human(10, isbits=True, unit='b') == "10.00 bits"
    assert bytes_to_human(10, unit='b') == "10.00 bits"

    # Check if unit is respected

# Generated at 2022-06-22 22:12:23.015764
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """Unit test for bytes_to_human"""

    # testing default unit case
    result = bytes_to_human(2048)
    assert result == '2.00 KBytes', "function bytes_to_human returns %s on input %s for default unit" % (result, 2048)

    # testing bits case
    result = bytes_to_human(2048, isbits=True)
    assert result == '16384.00 bits', "function bytes_to_human returns %s on input %s for bits" % (result, 2048)

    # testing bytes case
    result = bytes_to_human(2048, unit='B')
    assert result == '2048.00 Bytes', "function bytes_to_human returns %s on input %s for Bytes" % (result, 2048)

    # testing bits case with bits unit

# Generated at 2022-06-22 22:12:25.382785
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["FOO", "bar"]) == ["foo", "bar"]
    assert lenient_lowercase(["foo", "BAR"]) == ["foo", "BAR"]



# Generated at 2022-06-22 22:12:32.898745
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'a', 'A', 'B']) == ['a', 'a', 'a', 'b']
    assert lenient_lowercase([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert lenient_lowercase(['1', 2, '3', 4]) == ['1', 2, '3', 4]
    assert lenient_lowercase(['1', '2', 3, 4]) == ['1', '2', 3, 4]

# Generated at 2022-06-22 22:12:38.924289
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [u'äöü', 'öäü', 'üöä', 1234, ["a", "ö", 1234]]
    assert lenient_lowercase(test_list) == [u'äöü', 'öäü', 'üöä', 1234, ["a", "ö", 1234]]


# Generated at 2022-06-22 22:12:47.357113
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(2000) == '2.00 KBytes'
    assert bytes_to_human(2000000) == '1.91 MBytes'
    assert bytes_to_human(2000000000) == '1.86 GBytes'
    assert bytes_to_human(2000000000000) == '1.82 TBytes'
    assert bytes_to_human(2000000000000000) == '1.77 PBytes'
    assert bytes_to_human(2000000000000000000) == '1.73 EBytes'
    assert bytes_to_human(2000000000000000000000) == '1.69 ZBytes'
    assert bytes_to_human(2000000000000000000000000) == '1.65 YBytes'
    assert bytes_to_human(2000, unit='b') == '2.00 Kbits'

# Generated at 2022-06-22 22:12:57.557312
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:13:02.252538
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("2B") == 2
    assert human_to_bytes("2B", 'K') == 2048
    assert human_to_bytes("0.1MB") == 104857.6
    assert human_to_bytes("0.1MB", 'K') == 1024
    assert human_to_bytes("0.1MB", 'b') == 1048576
    assert human_to_bytes("0.1MB", 'B') == 1048576
    assert human_to_bytes("0.125MB") == 131072
    assert human_to_bytes("10G") == 10737418240
    assert human_to_bytes("10.25G") == 110199076864
    assert human_to_bytes("10.25Mb") == 12300000

# Generated at 2022-06-22 22:13:12.340202
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:13:21.897578
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:13:32.882277
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10m') == 10485760
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', 'B') == 10485760
    assert human_to_bytes('10M', 'b') == 10485760
    assert human_to_bytes('10M', isbits=True) == 10485760
    assert human_to_bytes('0.5M', isbits=True) == 524288
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10mB') == 10485760
    assert human_to_bytes('10mB', isbits=True) == 104857

# Generated at 2022-06-22 22:13:41.787150
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2M') == 2 * 1024 * 1024, "human_to_bytes('2M') failed"
    assert human_to_bytes('2M') == human_to_bytes(2, 'M'), "human_to_bytes('2M') failed"
    assert human_to_bytes(2, 'M') == human_to_bytes('2M'), "human_to_bytes(2, 'M') failed"
    assert human_to_bytes('2.5M') == int(round(2.5 * 1024 * 1024)), "human_to_bytes('2.5M') failed"
    assert human_to_bytes('2B') == 2, "human_to_bytes('2B') failed"

# Generated at 2022-06-22 22:13:51.001166
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(5, False) == '5 Bytes'
    assert bytes_to_human(5, False, unit='b') == '5 Bytes'
    assert bytes_to_human(5, False, unit='B') == '5 Bytes'
    assert bytes_to_human(5, True, unit='b') == '5 bits'
    assert bytes_to_human(5, True, unit='B') == '40 bits'
    assert bytes_to_human(5000000, False) == '4.81 MB'
    assert bytes_to_human(5000000, False, unit='k') == '4812.80 KB'
    assert bytes_to_human(5000000, False, unit='K') == '4812.80 KB'
    assert bytes_to_human(5000000, False, unit='m')

# Generated at 2022-06-22 22:13:59.834192
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:14:05.547726
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    values = ['abc', 'ABC', 123, [1, 2, 3]]
    assert lenient_lowercase(values) == ['abc', 'abc', 123, [1, 2, 3]]



# Generated at 2022-06-22 22:14:09.070611
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [1, 2, 'TeSt', 5, 6]
    answer = [1, 2, 'test', 5, 6]
    assert answer == lenient_lowercase(test_list)


# Generated at 2022-06-22 22:14:12.589026
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 32, 'e', 'F']) == ['a', 'b', 'c', 32, 'e', 'f']
    assert lenient_lowercase([]) == []

# Generated at 2022-06-22 22:14:24.003407
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:14:36.537463
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1000) == '1000 Bytes'
    assert bytes_to_human(10 * 1000**3, 'G') == '10.00 GBytes'
    assert bytes_to_human(10 * 1000**3, 'GB') == '10.00 GB'
    assert bytes_to_human(10 * 1000**3, 'Gb') == '10.00 Gb'

    assert bytes_to_human(10 * 1000**3, isbits=True, unit='Gb') == '10.00 Gb'
    assert bytes_to_human(10 * 1000**3, isbits=True) == '80.00 Gbits'
    assert bytes_to_human(10 * 1000**3, isbits=True, unit='gb') == '80.00 Gbits'


# Generated at 2022-06-22 22:14:48.085666
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest

    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.2KB') == 1228
    assert human_to_bytes('1.2K') == 1228
    assert human_to_bytes('1.2K', 'B') == 1228
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', 'B') == 10485760
    assert human_to_bytes('2G') == 2147483648
    assert human_to_bytes('2T') == 2199023255552
    assert human_to_bytes('2P') == 2251799813685248
    assert human_to_bytes('2E') == 2305843009213693952

    assert human_to_bytes('1b')

# Generated at 2022-06-22 22:14:57.139829
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Test the lenient_lowercase function.

    expected_result is a list of expected results for each value in input_list
    """
    input_list = [
        'This is a string',
        'Testing123',
        '',
        None,
        {'wrong': 'type'},
        ['list'],
        123,
        'TEST',
        'text text',
    ]
    expected_result = [
        'this is a string',
        'testing123',
        '',
        None,
        {'wrong': 'type'},
        ['list'],
        123,
        'test',
        'text text',
    ]
    results = list(lenient_lowercase(input_list))

# Generated at 2022-06-22 22:15:08.512249
# Unit test for function bytes_to_human
def test_bytes_to_human():

    if bytes_to_human(1) != '1.00 Bytes':
        raise AssertionError("bytes_to_human() failed to convert 1 to expected value '1.00 Bytes'")
    if bytes_to_human(2, unit='b') != '1.00 bit':
        raise AssertionError("bytes_to_human() failed to convert 2 to expected value '1.00 bit'")
    if bytes_to_human(2048, unit='b') != '1.99 Kbit':
        raise AssertionError("bytes_to_human() failed to convert 2048 to expected value '1.99 Kbit'")

# Generated at 2022-06-22 22:15:17.739011
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10', default_unit='M') == 10485760
    assert human_to_bytes('10Mb', default_unit='M', isbits=True) == 10485760
    assert human_to_bytes(10, default_unit='M') == 10485760
    assert human_to_bytes('0B') == 0
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10.0') == 10
    assert human_to_bytes('10.5') == 11
    assert human_to_bytes(10.0)

# Generated at 2022-06-22 22:15:23.315637
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 10, 'C']) == ['a', 'b', 10, 'c']



# Generated at 2022-06-22 22:15:29.483142
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [1, 2, 3, '4', '4.4', None, 'NEEDS-UPPER', 'needs-lower']

    expected_list = [1, 2, 3, '4', '4.4', None, 'NEEDS-UPPER', 'needs-lower']
    result = lenient_lowercase(test_list)
    assert result == expected_list

    expected_list = [1, 2, 3, '4', '4.4', None, 'needs-upper', 'needs-lower']
    result = lenient_lowercase(test_list, keep_case=False)
    assert result == expected_list


# Generated at 2022-06-22 22:15:34.430596
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['A', 'B', 'C', 1]
    result_list = ['a', 'b', 'c', 1]
    assert lenient_lowercase(test_list) == result_list



# Generated at 2022-06-22 22:15:36.586983
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['HELLO', None, 'World', True]) == ['hello', None, 'world', True]


# Generated at 2022-06-22 22:15:47.438574
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test strings
    test_string_list = ['0xA', 'j', 'jdhdh', 'jkdfkjh',
                        0, 1, 2, '0', '1', '2',
                        1234, 1234.5678,
                        [1, 2, 3, 4],
                        {'0': "1", 1: 2, 3: 4},
                        ('a', 'bb', 'ccc', 'dddd'),
                        ]
    # The expected results

# Generated at 2022-06-22 22:15:58.741455
# Unit test for function human_to_bytes
def test_human_to_bytes():
    human_bytes = [
        ('1k', 1000),
        ('10m', 10000000),
        ('15g', 15000000000),
        ('1K', 1024),
        ('1 mb', 1000000),
        ('1 G', 1000000000),
        ('1MB', 1000000),
        ('1 KB', 1000),
        ('1 b', 1),
        ('1B', 1),
        ('1 B', 1),
        ('100', 100),
        ('100.0', 100),
        ('100.12345', 100.12345),
        ('100.12345  Kb', 100123.45),
    ]

# Generated at 2022-06-22 22:16:10.885703
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("10M") == 10 * (1 << 20)
    assert human_to_bytes("10.5M") == int(10.5 * (1 << 20))
    assert human_to_bytes("10M", default_unit="B") == 10 * (1 << 20)
    assert human_to_bytes("10M", default_unit="K") == 10 * (1 << 20) / (1 << 10)
    assert human_to_bytes("10Mb", isbits=True) == 10 * (1 << 20)
    assert human_to_bytes("10.5Mb", isbits=True) == int(10.5 * (1 << 20))
    assert human_to_bytes("10.5", default_unit="K") == 10.5 * (1 << 10)

# Generated at 2022-06-22 22:16:23.325366
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(100000) == '100.00 KB'
    assert bytes_to_human(100000, 'b') == '100.00 KB'
    assert bytes_to_human(100000, 'bit') == '100.00 KB'
    assert bytes_to_human(100000, 'B') == '100.00 KB'
    assert bytes_to_human(100000, 'byte') == '100.00 KB'
    assert bytes_to_human(10000000) == '10.00 MB'

    assert bytes_to_human(1000, isbits=True) == '1.00 Kb'
    assert bytes_to_human(1000, 'b') == '1.00 Kb'
    assert bytes_to_human(1000, 'bit') == '1.00 Kb'
    assert bytes_to

# Generated at 2022-06-22 22:16:25.077388
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 1, 'D']) == ['a', 'b', 1, 'd']


# Generated at 2022-06-22 22:16:32.400792
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Checking bytes
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('20B') == 20
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('20b') == 20
    assert human_to_bytes('10') == 10
    assert human_to_bytes('20') == 20
    assert human_to_bytes('10M') == 10*1024*1024
    assert human_to_bytes('20M') == 20*1024*1024
    assert human_to_bytes('1MB', 'M') == 1*1024*1024
    assert human_to_bytes('1MB', 'G') == 1073741824
    assert human_to_bytes('1MB', 'B') == 1048576
    assert human_to_bytes('1MB', 'b') == 8

# Generated at 2022-06-22 22:16:33.858893
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase([None, 12, 'string', 'str'])
    assert result == [None, 12, 'string', 'str'], "Failed lenient_lowercase test"


# Generated at 2022-06-22 22:16:44.082912
# Unit test for function human_to_bytes
def test_human_to_bytes():
    tests = [
        ('1.5M', 1572864),
        ('1.5', 1.5),
        ('1,5K', 1536),
        ('1,5', 1.5),
        ('150,5', 150.5),
        ('150.5', 150.5),
        ('150 K', 153600),
        ('100.9Mb', 10485760),
        ('100.9M', 104857600),
        ('100.9 Mb', 104857600),
        ('100.9MB', 104857600),
        ('100.9MB', 104857600),
        ('100.9 MB', 104857600),
        ('100.9', 100.9)
    ]

# Generated at 2022-06-22 22:16:51.922646
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:17:02.721079
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Bytes test
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('1 byte', 'B') == 1
    assert human_to_bytes('1 byte', None, True) == 1
    assert human_to_bytes('10 bytes', 'B') == 10
    assert human_to_bytes('1M byte', None) == 1048576
    assert human_to_bytes('1M byte', 'B') == 1048576
    assert human_to_bytes('1M byte', 'M') == 1048576
    assert human_to_bytes('1.5M byte', 'M') == 1572864

# Generated at 2022-06-22 22:17:10.448303
# Unit test for function bytes_to_human
def test_bytes_to_human():
    if bytes_to_human(0) != "0 Bytes":
        raise ValueError("bytes_to_human(0) FAILED")
    if bytes_to_human(1) != "1 Bytes":
        raise ValueError("bytes_to_human(1) FAILED")
    if bytes_to_human(1 << 10) != "1.00 KB":
        raise ValueError("bytes_to_human(1 << 10) FAILED")
    if bytes_to_human(1 << 20) != "1.00 MB":
        raise ValueError("bytes_to_human(1 << 20) FAILED")
    if bytes_to_human(1 << 30) != "1.00 GB":
        raise ValueError("bytes_to_human(1 << 30) FAILED")

# Generated at 2022-06-22 22:17:17.512161
# Unit test for function human_to_bytes
def test_human_to_bytes():

    assert human_to_bytes('15.5k') == 16384, 'human_to_bytes() failed to convert %s' % '15.5k'
    assert human_to_bytes('5M') == 5242880, 'human_to_bytes() failed to convert %s' % '5M'
    assert human_to_bytes('5M', isbits=True) == 5242880, 'human_to_bytes() failed to convert %s' % '5M'
    assert human_to_bytes('5Mb', isbits=True) == 5242880, 'human_to_bytes() failed to convert %s' % '5Mb'
    assert human_to_bytes('5Mb') == 5242880, 'human_to_bytes() failed to convert %s' % '5Mb'
    assert human

# Generated at 2022-06-22 22:17:20.902611
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    data = [0, 1, 2, 'A', 'B', 'C']
    expected = [0, 1, 2, 'a', 'b', 'c']
    result = lenient_lowercase(data)
    assert result == expected

# Generated at 2022-06-22 22:17:32.465447
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:17:41.144036
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1234) == '1.23 KB'
    assert bytes_to_human(1234567) == '1.18 MB'
    assert bytes_to_human(1234567890) == '1.15 GB'
    assert bytes_to_human(1234567890123) == '1.12 TB'

    assert bytes_to_human(1234, isbits=True) == '9.76 Kb'
    assert bytes_to_human(1234567, isbits=True) == '9.53 Mb'
    assert bytes_to_human(1234567890, isbits=True) == '9.34 Gb'
    assert bytes_to_human(1234567890123, isbits=True) == '9.15 Tb'


# Generated at 2022-06-22 22:17:50.496408
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Unit test for function human_to_bytes '''
    # Examples of how Strings should be converted to ints
    human_to_bytes_conversions = [
        ('1B', 1),
        ('1K', 1024),
        ('1M', 1048576),
        ('1G', 1073741824),
        ('1Y', 1.2089258196146292e+24),
        ('1Kb', 1024),
        ('1Mb', 1048576),
        ('1Gb', 1073741824),
        ('1Yb', 1.2089258196146292e+24),
    ]
    for entry in human_to_bytes_conversions:
        ''' Make sure the UniTest is set up correctly. '''

# Generated at 2022-06-22 22:18:03.035457
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:18:11.072736
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test function
    ''' Checking function with bytes as a unit (uppercase byte identifier 'B') '''
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1kB') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1TB') == 1099511627776
    assert human_to_bytes('1PB') == 1125899906842624
    assert human_to_bytes('1EB') == 1152921504606846976
    assert human_to_bytes('1ZB') == 1180591620717411303424
    assert human_to_bytes('1YB') == 1208925819614629174706176


# Generated at 2022-06-22 22:18:15.897564
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(5000, False) == '4.88 KB'
    assert bytes_to_human(1048576, False) == '1.00 MB'
    assert bytes_to_human(1073741824, False) == '1.00 GB'
    assert bytes_to_human(0, False) == '0.00 Bytes'
    assert bytes_to_human(30, False) == '30.00 Bytes'
    assert bytes_to_human(5000, False, 'B') == '4.88 KB'
    assert bytes_to_human(5000, False, 'K') == '4.88 KB'
    assert bytes_to_human(5000, False, 'M') == '0.00 MB'


# Generated at 2022-06-22 22:18:26.382523
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest

    if human_to_bytes('10M') != 10485760:
        raise AssertionError('human_to_bytes failed: input 10M returned %s, expected 10485760' % human_to_bytes('10M'))

    if human_to_bytes('10M', 'B') != 10485760:
        raise AssertionError('human_to_bytes failed: input 10M, unit B returned %s, expected 10485760' % human_to_bytes('10M', 'B'))

    if human_to_bytes('10MB') != 10485760:
        raise AssertionError('human_to_bytes failed: input 10MB returned %s, expected 10485760' % human_to_bytes('10MB'))


# Generated at 2022-06-22 22:18:33.492427
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0, unit='b') == '0 bits'
    assert bytes_to_human(0, unit='B') == '0 Bytes'
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(0, isbits=True) == '0 bits'
    assert bytes_to_human(1234, isbits=True) == '1.21 Kbits'
    assert bytes_to_human(12345, isbits=True) == '12.06 Kbits'
    assert bytes_to_human(1234567890, isbits=True) == '1.15 Gbits'
    assert bytes_to_human(1234567890, isbits=True, unit='b') == '1.15 Gbits'

# Generated at 2022-06-22 22:18:44.144290
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes(1) == 1
    assert human_to_bytes('    1   ') == 1
    assert human_to_bytes('42') == 42
    assert human_to_bytes(42) == 42
    assert human_to_bytes(1.5) == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes(1.5, default_unit='K') == 1024
    assert human_to_bytes('1.5', default_unit='K') == 1024
    try:
        assert human_to_bytes('K') == 1
    except ValueError:
        pass
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes(1, 'K') == 1024
    assert human

# Generated at 2022-06-22 22:18:48.821379
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import sys
    if sys.version_info[0] == 2:
        string_types = (str, unicode)
    else:
        string_types = (str,)
    from numbers import Number

    # test func output format
    assert isinstance(human_to_bytes('2B'), Number)
    assert isinstance(human_to_bytes('5K'), Number)
    assert isinstance(human_to_bytes('10M'), Number)
    assert isinstance(human_to_bytes('15G'), Number)
    assert isinstance(human_to_bytes('1Y'), Number)
    assert isinstance(human_to_bytes('1Z'), Number)
    assert isinstance(human_to_bytes('1E'), Number)
    assert isinstance(human_to_bytes('1P'), Number)

# Generated at 2022-06-22 22:18:55.217133
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Tests for valid inputs
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 100, 'c']) == ['a', 100, 'c']
    # Test for non-string input
    assert lenient_lowercase([100]) == [100]
    # Test for non-string and non-number input
    assert lenient_lowercase([None]) == [None]


# Generated at 2022-06-22 22:19:07.364610
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(12) == '12.00 Bytes'
    assert bytes_to_human(128) == '128.00 Bytes'
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(2048, True) == '16.00 Kb'
    assert bytes_to_human(2048, False, 'G') == '0.00 GB'
    assert bytes_to_human(2048, True, 'G') == '0.00 Gb'
    assert bytes_to_human(2048, True, 'b') == '1.62 Kbits'

    # Unit test for function human_to_bytes
    assert human_to_bytes('12') == 12
    assert human_to_bytes('128') == 128

# Generated at 2022-06-22 22:19:13.945616
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:19:17.560031
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input = [ 'a', 'B', 1 ]
    output = lenient_lowercase(input)
    assert output == [ 'a', 'b', 1 ]



# Generated at 2022-06-22 22:19:20.249024
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['tEsT', 123, 77.7, 'test_test']
    assert lenient_lowercase(test_list) == ['test', 123, 77.7, 'test_test']


# Generated at 2022-06-22 22:19:31.115179
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 'b', 'c']) == [1, 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 'B', 'C']) == [1, 'B', 'C']
    assert lenient_lowercase(['a', 2, 'c']) == ['a', 2, 'c']
    assert lenient_lowercase(['aBc', 'B', 'C']) == ['abc', 'B', 'C']

# Generated at 2022-06-22 22:19:41.157387
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:19:44.352767
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'B', 'c']
    assert lenient_lowercase(['a', 'B', 1, 'c']) == ['a', 'B', 1, 'c']

# Generated at 2022-06-22 22:19:55.841921
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M', default_unit='B') == 1048576, 'One MByte should be 1048576 bytes'
    assert human_to_bytes('1Mb', default_unit='B', isbits=True) == 1048576, 'One Mbit should be 1048576 bytes'
    try:
        human_to_bytes('1MB', default_unit='B')
        assert False, '1048576 value should not be expected as an output of conversion'
    except ValueError:
        pass
    try:
        human_to_bytes('1Mb', default_unit='B')
        assert False, '1048576 value should not be expected as an output of conversion'
    except ValueError:
        pass

# Generated at 2022-06-22 22:20:05.263161
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # test list of strings
    res = lenient_lowercase(['Foo', 'Bar', 'Baz'])
    assert res == ['foo', 'bar', 'baz']
    # test list of int
    res = lenient_lowercase(['Foo', 'Bar', 10])
    assert res == ['foo', 'bar', 10]
    # test list of dicts
    res = lenient_lowercase(['Foo', {'id': '10', 'name': 'test'}, 10])
    assert res == ['foo', {'id': '10', 'name': 'test'}, 10]


# Generated at 2022-06-22 22:20:16.391592
# Unit test for function bytes_to_human
def test_bytes_to_human():
    tests = (
        (1, '1 Bytes'),
        (10, '10 Bytes'),
        (1000, '1000 Bytes'),
        (1024, '1.00 KBytes'),
        (1048576, '1.00 MBytes'),
        (1073741824, '1.00 GBytes'),
        (1099511627776, '1.00 TBytes'),
        (1125899906842624, '1.00 PBytes'),
        (1152921504606846976, '1.00 EBytes'),
        (11815784444945473536, '1.00 ZBytes'),
        (12131175087682117632, '1.00 YBytes'),
    )
    for test in tests:
        size, expected = test
        actual = bytes_to_human(size)
       

# Generated at 2022-06-22 22:20:24.565553
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Unit test for function human_to_bytes
    '''
    test_table = (('1MB', 1048576),
                  ('1M', 1048576),
                  ('543b', 543),
                  ('543B', 543),
                  ('1K', 1024),
                  ('1Kb', 1024)
                  )
    for test_value in test_table:
        result = human_to_bytes(test_value[0])
        assert result == test_value[1], "%s == %s" % (result, test_value[1])
        test_value = (test_value[0].lower(), test_value[1])
        result = human_to_bytes(test_value[0])

# Generated at 2022-06-22 22:20:30.184119
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    test_list = ['Foo', 'Bar', 1, 2, 'Baz', 'FOO', 3, 'Foo']
    expected_list = ['foo', 'bar', 1, 2, 'baz', 'foo', 3, 'foo']

    assert lenient_lowercase(test_list) == expected_list

# Generated at 2022-06-22 22:20:40.683830
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:20:48.131507
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Unit test for function bytes_to_human
    test_values = {
        '1B': '1.00 Bytes',
        10: '10.00 Bytes',
        '10B': '10.00 Bytes',
        '1.1B': '1.10 Bytes',
        '10KB': '10240.00 Bytes',
        '1KB': '1024.00 Bytes',
        '1.1K': '1152.00 Bytes',
        '1K': '1024.00 Bytes',
    }

    for key, value in list(test_values.items()):
        result = bytes_to_human(key, unit='B')
        assert result == value, 'Error: %s != %s' % (result, value)



# Generated at 2022-06-22 22:20:56.042900
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Create input and expected output values
    test_input_values = [['A', 1], [u'B', 2], [1, 3], ['a', 1], [u'b', 2], [u'A', 1], [u'B', 2], [1, 3]]
    expected_output_values = [['a', 1], [u'b', 2], [1, 3], ['a', 1], [u'b', 2], [u'a', 1], [u'b', 2], [1, 3]]

    # Iterate through the inputs and compare to expected outputs
    for index, value in enumerate(test_input_values):
        assert lenient_lowercase(value) == expected_output_values[index]

# Generated at 2022-06-22 22:21:06.250496
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert (bytes_to_human(1024) == '1.00 KB')
    assert (bytes_to_human(1024, unit='KB') == '1.00 KB')
    assert (bytes_to_human(1024, unit='KB', isbits=True) == '8.00 Kb')
    assert (bytes_to_human(1024, isbits=True) == '8.00 Kb')
    assert (bytes_to_human(0.1) == '0.10 Bytes')
    assert (bytes_to_human(0.1, unit='b') == '0.10 bits')
    assert (bytes_to_human(1099733) == '1.06 MB')
    assert (bytes_to_human(1099733, unit='MB') == '1.06 MB')

# Generated at 2022-06-22 22:21:15.011837
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # value in bytes with byte unit
    assert human_to_bytes("1") == 1
    assert human_to_bytes("1", default_unit="B") == 1
    assert human_to_bytes("1b") == 1
    assert human_to_bytes("1byte") == 1
    assert human_to_bytes("1bytes") == 1
    assert human_to_bytes("1 B") == 1
    assert human_to_bytes("1 byte") == 1
    assert human_to_bytes("1 bytes") == 1
    # value in bits with byte unit
    assert human_to_bytes("1", isbits=True) == 1
    assert human_to_bytes("1", default_unit="b", isbits=True) == 1
    assert human_to_bytes("1b", isbits=True) == 1
    assert human_

# Generated at 2022-06-22 22:21:19.564958
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    str = ['D', 'E', 'F', 'G', 'H', 1, 2]
    assert lenient_lowercase(str) == ['d', 'e', 'f', 'g', 'h', 1, 2]

# Generated at 2022-06-22 22:21:30.287213
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == "0 Bytes"
    assert bytes_to_human(1) == "1 Bytes"
    assert bytes_to_human(10) == "10 Bytes"
    assert bytes_to_human(10.3) == "10.30 Bytes"
    assert bytes_to_human(100) == "100 Bytes"
    assert bytes_to_human(100.3) == "100.30 Bytes"
    assert bytes_to_human(1000) == "1.00 KB"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1024.3) == "1.00 KB"
    assert bytes_to_human(10240) == "10.00 KB"

# Generated at 2022-06-22 22:21:33.860235
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['FOO', 'bAr', 1, 2, [], {}]
    result_list = ['foo', 'bar', 1, 2, [], {}]
    assert lenient_lowercase(test_list) == result_list


# Generated at 2022-06-22 22:21:38.529597
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['a', 1, 'b', 2]
    assert lenient_lowercase(lst) == ['a', 1, 'b', 2]

    lst = ['a', 'B', 'c', 'D']
    assert lenient_lowercase(lst) == ['a', 'b', 'c', 'd']



# Generated at 2022-06-22 22:21:43.886353
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'b', 'C', 1]) == ['a', 'b', 'c', 1]


# Generated at 2022-06-22 22:21:55.342213
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''Test function human_to_bytes'''

    # Default conversion
    assert(human_to_bytes('2K') == 2048)
    assert(human_to_bytes('2k') == 2048)
    assert(human_to_bytes('2M') == 2 * 1024 * 1024)
    assert(human_to_bytes('2m') == 2 * 1024 * 1024)
    assert(human_to_bytes('2G') == 2 * 1024 * 1024 * 1024)
    assert(human_to_bytes('2g') == 2 * 1024 * 1024 * 1024)
    # Test conversion without unit
    assert(human_to_bytes('3') == 3)
    assert(human_to_bytes('10') == 10)
    # Test conversion with unit
    assert(human_to_bytes('11', 'M') == 11 * 1024 * 1024)

# Generated at 2022-06-22 22:22:04.443413
# Unit test for function bytes_to_human