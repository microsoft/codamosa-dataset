

# Generated at 2022-06-22 22:12:08.505274
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K', None, False) == 2*1024
    assert human_to_bytes('2K', 'B') == 2*1024
    assert human_to_bytes('2Kb', 'B', True) == 2*1024
    assert human_to_bytes('2Kb', None, True) == 2*1024
    assert human_to_bytes('2K', 'b', True) == 2*1024
    assert human_to_bytes('2Kb', 'b', True) == 2*1024
    assert human_to_bytes('2K', None, True) == 2*1024
    assert human_to_bytes('2K', 'b') == 2*1024


# Generated at 2022-06-22 22:12:17.116057
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:12:27.779603
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_input = [u'αβγδεζηθικλμνξοπρστυφχψω', 'A', [u'Α', u'Β', 'C'], 'D', None, 1, 2.3, u'Αβγδεζηθικλμνξοπρστυφχψω']

# Generated at 2022-06-22 22:12:33.897586
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1025) == '1.00 KB'
    assert bytes_to_human(1024 ** 2) == '1.00 MB'
    assert bytes_to_human(1024 ** 3) == '1.00 GB'
    assert bytes_to_human(1024 ** 4) == '1.00 TB'
    assert bytes_to_human(1024 ** 5) == '1.00 PB'
    assert bytes_to_human(1024 ** 6) == '1.00 EB'

# Generated at 2022-06-22 22:12:43.568278
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import sys
    import pytest

    # Test case:
    # Check that function expect string as a first parameter. Some non-string parameters
    # should rised TypeError exception
    num_type_test = ['2',
                     2,
                     2.0,
                     (1, 2),
                     {'a': 1},
                     ['2'],
                     None]
    for num in num_type_test:
        with pytest.raises(TypeError):
            human_to_bytes(num)

    # Test case:
    # Check that function expect string as a second parameter. Some non-string parameters
    # should rised TypeError exception

# Generated at 2022-06-22 22:12:50.942467
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test negative case
    import pytest
    with pytest.raises(ValueError):
        assert human_to_bytes("10MB")
    with pytest.raises(ValueError):
        assert human_to_bytes("10.0Mb", isbits=True)
    with pytest.raises(ValueError):
        assert human_to_bytes("10.0Mb", isbits=False)
    with pytest.raises(ValueError):
        assert human_to_bytes("10Mbbb")
    # test positive case
    assert human_to_bytes("10.0Mb", isbits=True) == 10485760
    assert human_to_bytes("1.0Mb", isbits=True) == 1048576
    assert human_to_bytes("1.0M") == 1048576
   

# Generated at 2022-06-22 22:13:01.414354
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # bytes
    assert bytes_to_human(1) == "1.00 Bytes"
    # kilo
    assert bytes_to_human(1 << 10) == "1.00 KB"
    assert bytes_to_human(1 << 10 * 2) == "1.00 MB"
    assert bytes_to_human(1 << 10 * 3) == "1.00 GB"
    assert bytes_to_human(1 << 10 * 4) == "1.00 TB"
    assert bytes_to_human(1 << 10 * 5) == "1.00 PB"
    assert bytes_to_human(1 << 10 * 6) == "1.00 EB"
    assert bytes_to_human(1 << 10 * 7) == "1.00 ZB"

# Generated at 2022-06-22 22:13:11.794133
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test bytes conversion
    assert bytes_to_human(0) == "0.00 Bytes"
    assert bytes_to_human(1) == "1.00 Bytes"
    assert bytes_to_human(2) == "2.00 Bytes"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1048576) == "1.00 MB"
    assert bytes_to_human(1073741824) == "1.00 GB"
    assert bytes_to_human(1099511627776) == "1.00 TB"
    assert bytes_to_human(1125899906842624) == "1.00 PB"
    assert bytes_to_human(1152921504606846976) == "1.00 EB"
    assert bytes_to_

# Generated at 2022-06-22 22:13:19.932082
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lower_list = ['test', '', 1, True, False, None, [], 0]
    upper_list = ['TEST', '', 1, True, False, None, [], 0]
    random_list = ['1', 2, [], None, True, False, [1, 2], 'test']
    # lenient_lowercase test
    assert lower_list == lenient_lowercase(lower_list)
    assert upper_list == lenient_lowercase(upper_list)
    assert random_list == lenient_lowercase(random_list)
    print('test_lenient_lowercase done')


# Generated at 2022-06-22 22:13:31.362565
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test for bytes
    test_bytes = [{'size': 0, 'isbits': False, 'unit': None, 'result': '0.00 Bytes'},
                  {'size': 1, 'isbits': False, 'unit': None, 'result': '1.00 Bytes'},
                  {'size': 1024, 'isbits': False, 'unit': None, 'result': '1.00 KB'},
                  {'size': 10, 'isbits': False, 'unit': 'K', 'result': '0.01 KB'},
                  {'size': 2**30, 'isbits': False, 'unit': 'G', 'result': '1.00 GB'},
                  {'size': 2**20, 'isbits': False, 'unit': 'M', 'result': '1.00 MB'}]


# Generated at 2022-06-22 22:13:40.751816
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:13:50.829234
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '8192.00 YB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '8192.00 ZB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '8192.00 EB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '8192.00 PB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '8192.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024) == '8192.00 GB'
    assert bytes_to_human(1024 * 1024) == '8192.00 MB'

# Generated at 2022-06-22 22:13:59.695985
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='K') == '1.00 KB'
    assert bytes_to_human(1, unit='M') == '1.00 MB'
    assert bytes_to_human(1, unit='G') == '1.00 GB'
    assert bytes_to_human(1, unit='T') == '1.00 TB'
    assert bytes_to_human(1, unit='b') == '1.00 bits'
    assert bytes_to_human(1, isbits=True, unit='K') == '1.00 KB'
    assert bytes_to_human(1, isbits=True, unit='M') == '1.00 MB'

# Generated at 2022-06-22 22:14:11.618124
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1075271643) == "1.02 GB"
    assert bytes_to_human(1) == "1 Bytes"
    assert bytes_to_human(1075271643, unit="G") == "1.02 G"
    assert bytes_to_human(1075271643, unit="KB") == "1048576 KB"
    assert bytes_to_human(1075271643, unit="MB") == "1024 MB"
    assert bytes_to_human(1075271643, unit="GB") == "1 GB"
    assert bytes_to_human(1075271643, unit="TB") == "0 TB"
    assert bytes_to_human(1, unit="GB") == "0 GB"

# Generated at 2022-06-22 22:14:16.163667
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["Abc", "Def", 3, 4, 5]) == ["abc", "def", 3, 4, 5]

# Generated at 2022-06-22 22:14:26.464100
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('100K') == 100 * 1024)
    assert(human_to_bytes('100M') == 100 * 1024 * 1024)
    assert(human_to_bytes('100G') == 100 * 1024 * 1024 * 1024)

    try:
        human_to_bytes('100x')
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError is not raised')

    assert(human_to_bytes('100b') == 8)
    assert(human_to_bytes('100kb') == 1000 * 8)
    assert(human_to_bytes('100mb') == 1000 * 1000 * 8)
    assert(human_to_bytes('100gb') == 1000 * 1000 * 1000 * 8)


# Generated at 2022-06-22 22:14:38.029192
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Bytes unit test
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1Byte') == 1
    assert human_to_bytes('1bYTe') == 1
    assert human_to_bytes('1Byte ') == 1
    assert human_to_bytes(' 1Byte') == 1
    assert human_to_bytes('   1Byte') == 1
    assert human_to_bytes('  1\tByte') == 1
    assert human_to_bytes('1\tByte') == 1
    assert human_to_bytes('\n1\tByte\n') == 1
    assert human_to_bytes('1.0 Byte') == 1
    assert human_to_bytes('1 byte') == 1
    assert human_to_bytes

# Generated at 2022-06-22 22:14:49.621202
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # bytes
    human_to_bytes('1B')  # => 1 (int)
    human_to_bytes('1b')  # => ValueError
    human_to_bytes('1KB')  # => 1024 (int)
    human_to_bytes('1Kb')  # => ValueError
    human_to_bytes('10MB')  # => 10485760 (int)
    human_to_bytes('10Mb')  # => ValueError
    human_to_bytes('10GB')  # => 10737418240 (int)
    human_to_bytes('10Gb')  # => ValueError
    human_to_bytes('10TB')  # => 10995116277760 (int)
    human_to_bytes('10Tb')  # => ValueError
    human_to_bytes('10PB') 

# Generated at 2022-06-22 22:14:52.640732
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    data = ['a', 'B', 'C', 3, 4]
    data = lenient_lowercase(data)
    assert data == ['a', 'b', 'c', 3, 4], data


# Generated at 2022-06-22 22:14:58.295875
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    import pytest
    assert lenient_lowercase(['Foo', 'BAR']) == ['foo', 'bar']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase(['Foo', None]) == ['foo', None]


# Generated at 2022-06-22 22:15:07.207551
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['a', 'b', 'c'] == lenient_lowercase(['a', 'b', 'c'])
    assert ['a', 'b', 'c', '123'] == lenient_lowercase(['a', 'b', 'c', '123'])
    assert ['a', 'b', 'c', 123] == lenient_lowercase(['a', 'b', 'c', 123])
    assert ['a', 'b', 'c', [1, 2, 3]] == lenient_lowercase(['a', 'b', 'c', [1, 2, 3]])



# Generated at 2022-06-22 22:15:16.819111
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # byte class
    assert human_to_bytes("1B") == 1
    assert human_to_bytes("10b") == 10
    assert human_to_bytes("1.2b", unit='b') == 1
    assert human_to_bytes("1.2B", unit='b') == 1
    assert human_to_bytes("1.2B", unit='B') == 1
    assert human_to_bytes("1.2KB", unit='B') == 1200
    assert human_to_bytes("1.2MB") == 1200000
    assert human_to_bytes("1.2TB") == 1200000000000
    assert human_to_bytes("1.2PB") == 1200000000000000
    assert human_to_bytes("1.2EB") == 120000000000000000
    assert human_to_bytes("1.2ZB") == 12

# Generated at 2022-06-22 22:15:26.694505
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # lenient_lowercase must return lowercase string
    # if string passed in
    assert 'a string lowercased' == lenient_lowercase('A String Lowercased')

    length = len('A LIST OF STRING ELEMENTS')

    # lenient_lowercase must return a list with the number
    # of items equal to the number of items in the input
    # list
    assert length == len(lenient_lowercase('A LIST OF STRING ELEMENTS'.split()))

    # lenient_lowercase must return a list that contains
    # lowercased strings, if the input list contains
    # strings
    assert ['a', 'list', 'of', 'string', 'elements'] == lenient_lowercase(['A', 'LIST', 'OF', 'STRING', 'ELEMENTS'])

    # lenient_lowercase must return

# Generated at 2022-06-22 22:15:32.883071
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase([]) == [])
    assert(lenient_lowercase(['a', 'b']) == ['a', 'b'])
    assert(lenient_lowercase(['A', 'B']) == ['a', 'b'])
    assert(lenient_lowercase(['A', 1, 'B']) == ['a', 1, 'b'])

# Generated at 2022-06-22 22:15:42.685524
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """ Unit test for bytes_to_human becomes here """


# Generated at 2022-06-22 22:15:51.320730
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:15:56.832222
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_test = ['A', 'a', 2, 'B', 'b', 'Z']
    result = lenient_lowercase(list_test)
    assert len(list_test) == len(result)
    assert 'A' not in result
    assert 'a' in result
    assert 2 in result
    assert 'B' not in result
    assert 'b' in result
    assert 'Z' in result



# Generated at 2022-06-22 22:16:07.115075
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # conversion should be in bytes
    assert human_to_bytes(2) == 2
    assert human_to_bytes(2.5) == 2
    assert human_to_bytes('2') == 2
    assert human_to_bytes('2.5') == 2
    assert human_to_bytes('2TB') == 2*1024*1024*1024*1024
    assert human_to_bytes('2Tb') == 2*1024*1024*1024*1024
    assert human_to_bytes('2T') == 2*1024*1024*1024*1024
    assert human_to_bytes('2T', 'B') == 2*1024*1024*1024*1024
    assert human_to_bytes('2GB') == 2*1024*1024*1024
    assert human_to_bytes('2Gb') == 2*1024*1024*1024
    assert human

# Generated at 2022-06-22 22:16:15.177247
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # max value for bytes
    assert human_to_bytes('9E', isbits=False) == 9000000000000000000
    assert human_to_bytes('9E', isbits=True) == 9000000000000000000 * 8
    # bytes
    assert human_to_bytes('2', isbits=False) == 2
    assert human_to_bytes('20', isbits=False) == 20
    assert human_to_bytes('200', isbits=False) == 200
    assert human_to_bytes('2K', isbits=False) == 2048
    assert human_to_bytes('2K', unit='b', isbits=True) == 2048 * 8
    assert human_to_bytes('2KB', isbits=False) == 2048
    assert human_to_bytes('2KB', unit='b', isbits=True) == 2048 * 8

# Generated at 2022-06-22 22:16:23.326696
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["10Gb", "20G", 3, "Gb", "mb", 1, 1000, "40Mb", "5MB", "5Mb", "100Mb", "1b", "10Gb", "WOOF"]) == \
           ["10gb", "20g", 3, "Gb", "mb", 1, 1000, "40mb", "5mb", "5Mb", "100Mb", "1b", "10gb", "WOOF"]

# Generated at 2022-06-22 22:16:29.738428
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a','b','c','string','d','e','f']) == ['a','b','c','string','d','e','f']
    assert lenient_lowercase([1,2,3,'string',4,5,6]) == ['1', '2', '3', 'string', '4', '5', '6']
    assert lenient_lowercase(['1', '2', '3', 4, 5, 6]) == ['1', '2', '3', '4', '5', '6']



# Generated at 2022-06-22 22:16:41.024858
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1K') == 1 << 10
    assert human_to_bytes('1KB') == 1 << 10
    assert human_to_bytes('1M') == 1 << 20
    assert human_to_bytes('1MB') == 1 << 20
    assert human_to_bytes('1G') == 1 << 30
    assert human_to_bytes('1GB') == 1 << 30
    assert human_to_bytes('1T') == 1 << 40
    assert human_to_bytes('1TB') == 1 << 40
    assert human_to_bytes('1P') == 1 << 50
    assert human_to_bytes('1PB') == 1 << 50
    assert human_to_bytes('1E') == 1 << 60

# Generated at 2022-06-22 22:16:49.586624
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1000) == '1000 Bytes'
    assert bytes_to_human(1000, isbits=True) == '1000 bits'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(10, isbits=True) == '10 bits'
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1023, isbits=True) == '1023 bits'
    assert bytes_to_human(1024) == '1.00 KBytes'
    assert bytes_to_human(1024, isbits=True) == '1.00 Kbits'
    assert bytes_to_human(1024 * 1024) == '1.00 MBytes'
    assert bytes_to_human(1024 * 1024, isbits=True)

# Generated at 2022-06-22 22:16:54.775478
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert 1048576 == human_to_bytes('1MB')
    assert 1048576 == human_to_bytes('1048576')
    assert 1048576 == human_to_bytes('1048576.0')
    assert 1048576 == human_to_bytes(1048576)
    assert 1048576 == human_to_bytes(1048576.0)
    assert 10 == human_to_bytes('10')
    assert 512 == human_to_bytes('512')
    assert 1048576 == human_to_bytes('10M')
    assert 1048576 == human_to_bytes('1.048576e+06')
    assert 1048576 == human_to_bytes('1.048576E+06')
    assert 1048576 == human_to_bytes('1.048576E06')
    assert 1048576 == human

# Generated at 2022-06-22 22:17:04.290980
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='b') == '1.00 bits'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, isbits=True) == '1.00 bits'
    assert bytes_to_human(1, isbits=True, unit='b') == '1.00 bits'
    assert bytes_to_human(1, isbits=True, unit='B') == '8.00 bits'
    assert bytes_to_human(1.0) == '1.00 Bytes'
    assert bytes_to_human(1.0, unit='b') == '1.00 bits'

# Generated at 2022-06-22 22:17:11.691605
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('10G', 'K') == 10485760
    assert human_to_bytes('10G', 'K') == 10485760
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(8.3, 'M') == 8686080
    assert human_to_bytes(8.3, 'K') == 8192
    assert human_to_bytes(8.3, 'K') == 8192

    # bits case
    assert human_to_bytes('10Mb', 'Kb', isbits=True) == 104857

# Generated at 2022-06-22 22:17:16.917473
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
     Test cases for human_to_bytes
     :return:
     '''
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'M', isbits=True) == 83886080
    assert human_to_bytes(10, 'MB') == 10485760
    assert human_to_bytes(10, 'MB', isbits=True) == 83886080
    assert human_to_bytes(10, 'Mb') == 1048576
    assert human_to_bytes(10, 'Mb', isbits=True) == 8388608
    assert human_to_bytes(10, 'mb') == 8388608
    assert human_to_bytes(10, 'mb', isbits=True) == 8388608
    assert human_to_

# Generated at 2022-06-22 22:17:24.944620
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('0Y') == 0
    assert human_to_bytes('0') == 0
    assert human_to_bytes('0YB') == 0
    assert human_to_bytes('0B') == 0
    assert human_to_bytes(0) == 0
    assert human_to_bytes(b'0') == 0
    assert human_to_bytes(u'0') == 0
    assert human_to_bytes('0Yb') == 0
    assert human_to_bytes('0b') == 0
    assert human_to_bytes(0, unit='b') == 0
    assert human_to_bytes('2Z') == 2 * (1 << 70)
    assert human_to_bytes('2E') == 2 * (1 << 60)

# Generated at 2022-06-22 22:17:36.620821
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest

    tests = [
        ('5b', 5, True),
        ('5kb', 5120, False),
        ('1mb', 1048576, False),
        ('1gb', 1073741824, False),
        ('3.2gb', 3.2 * 1073741824, False),
        ('3.2tb', 3.2 * 1073741824 * 1024, False),
        ('3.2pb', 3.2 * 1073741824 * 1024**2, False),
        ('3.2eb', 3.2 * 1073741824 * 1024**3, False)
    ]

    for value, expected, isbits in tests:
        assert expected == human_to_bytes(value, isbits=isbits), 'failed for: %s' % value



# Generated at 2022-06-22 22:17:41.646255
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [1, 'a', '', 'b', None, 'C']
    assert lenient_lowercase(lst) == [1, 'a', '', 'b', None, 'C']



# Generated at 2022-06-22 22:17:43.002004
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Ab','C',1]) == ['ab','C',1]


# Generated at 2022-06-22 22:17:48.172138
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # test 1
    assert lenient_lowercase(['ABC', 1, [1, 2]]) == ['abc', 1, [1, 2]]

    # test 2
    assert lenient_lowercase([0, 1, 2]) == [0, 1, 2]

    # test 3
    assert lenient_lowercase([0, 'a', 1, 2]) == [0, 'a', 1, 2]


# Generated at 2022-06-22 22:17:55.082644
# Unit test for function bytes_to_human
def test_bytes_to_human():
    for unit in SIZE_RANGES.keys():
        assert bytes_to_human(human_to_bytes('1%s' % unit)) == '1.00 Bytes', '%s test fail' % unit
        assert bytes_to_human(human_to_bytes('1%sB' % unit)) == '1.00 Bytes', '%sB test fail' % unit
        assert bytes_to_human(human_to_bytes('1%sb' % unit), isbits=True) == '1.00 bits', '%sb test fail' % unit



# Generated at 2022-06-22 22:17:58.995886
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'Abc', 'abc']) == [1, 'Abc', 'abc']
    assert lenient_lowercase([1, 'Abc', 'DEf']) == [1, 'Abc', 'DEf']

# Generated at 2022-06-22 22:18:05.612776
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest

    def test_human_to_bytes_with_unit(unit_value, expected_result, isbits=False):
        assert human_to_bytes(unit_value, isbits=isbits) == expected_result

    def test_human_to_bytes_with_default_unit(unit_value, expected_result, default_unit, isbits=False):
        assert human_to_bytes(unit_value, default_unit, isbits=isbits) == expected_result

    # Valid test cases
    # bytes
    test_human_to_bytes_with_unit('1',          1, )
    test_human_to_bytes_with_unit('1B',         1, )
    test_human_to_bytes_with_unit('1b',         1, )
    test_human_to_bytes_with

# Generated at 2022-06-22 22:18:16.676511
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:18:27.137947
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(0.5) == '0.50 Bytes'
    assert bytes_to_human(0.3) == '0.30 Bytes'
    assert bytes_to_human(0.1) == '0.10 Bytes'
    assert bytes_to_human(0.0000023) == '0.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KiB'
    assert bytes_to_human(1024, unit='G') == '1.00 GiB'

    assert bytes_to_human(1024, isbits=True) == '1.00 Kib'
    assert bytes_to_human(1024, isbits=True, unit='G') == '1.00 Gib'

# Generated at 2022-06-22 22:18:34.920499
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_cases = (
        (['a', 'B', (1, )], ['a', 'b', (1, )]),
        ((), ()),
        (['A'], ['a']),
        (('a', 'B', 'C'), ('a', 'b', 'C')),
    )
    for input_string, expected_result in test_cases:
        result = lenient_lowercase(input_string)
        assert result == expected_result, "%s returned %s but expected %s" % (input_string, result, expected_result)



# Generated at 2022-06-22 22:18:38.719228
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1', 'B') == 1
    assert human_to_bytes('1', 'KB') == 0
    assert human_to_bytes('1', 'Kb') == 0
    assert human_to_bytes('1', 'B', True) == 1
    assert human_to_bytes('1', 'KB', True) == 0
    assert human_to_bytes('1', 'Kb', True) == 0



# Generated at 2022-06-22 22:18:40.885480
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 2, 'c']) == ['a', 2, 'c']



# Generated at 2022-06-22 22:18:45.287266
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['ABC', 'DEF']) == ['abc', 'def']
    # Error triggered on lower case of number
    assert lenient_lowercase(['ABC', 1]) == ['abc', 1]


# Generated at 2022-06-22 22:18:51.386972
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print(bytes_to_human(1024, False))
    print(bytes_to_human(1024, True))
    print(bytes_to_human(1024, False, 'b'))
    print(bytes_to_human(1024, True, 'B'))
    print(bytes_to_human(1024, False, 'K'))
    print(bytes_to_human(1024, True, 'k'))



# Generated at 2022-06-22 22:18:59.756230
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1, isbits=True) == '1 bits'
    assert bytes_to_human(2) == '2 Bytes'
    assert bytes_to_human(2, isbits=True) == '2 bits'
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1023, isbits=True) == '8191 bits'
    assert bytes_to_human(1024) == '1 KB'
    assert bytes_to_human(1024, isbits=True) == '1 Kb'
    assert bytes_to_human(2048) == '2 KB'
    assert bytes_to_human(2048, isbits=True) == '2 Kb'
    assert bytes

# Generated at 2022-06-22 22:19:09.662971
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes(1, 'M') == 1048576
    assert human_to_bytes('1.0M') == human_to_bytes('1M')
    assert human_to_bytes(10, 'K') == 10240
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('0.5M') == 524288
    assert human_to_bytes('0.5M', 'K') == 512
    assert human_to_bytes(0.5, 'M', 'K') == 512
    assert human_to_bytes('0.5', 'M') == 524288

# Generated at 2022-06-22 22:19:18.709855
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['a', 'b', 'C', 'D', '1'], lenient_lowercase(['a', 'b', 'C', 'D', '1'])
    assert 'a', lenient_lowercase('a')
    assert {'a', 'b'}, lenient_lowercase({'a', 'b'})
    assert ['a', 'b', 1, {'c', 'd'}], lenient_lowercase(['a', 'b', 1, {'c', 'd'}])


# Generated at 2022-06-22 22:19:28.571117
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'B']) == ['a', 'b', 'B']
    assert lenient_lowercase(['a', 'b', 3]) == ['a', 'b', 3]
    assert lenient_lowercase(['a', 'b', 'C', 'D', 'E']) == ['a', 'b', 'C', 'D', 'E']
    assert lenient_lowercase(['a', 'b', 'C', 'D', 'E', 12345]) == ['a', 'b', 'C', 'D', 'E', 12345]



# Generated at 2022-06-22 22:19:34.734930
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(['A', 'B', 'C'])
    assert result == ['a', 'b', 'c']

    result = lenient_lowercase(['a', 'b', 'c'])
    assert result == ['a', 'b', 'c']

    result = lenient_lowercase([{}, 'a', False])
    assert result == [{}, 'a', False]



# Generated at 2022-06-22 22:19:45.743707
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:19:53.502473
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Note: these tests are run from base of project, need to get out of current dir.
    import os
    os.chdir('..')
    # Simple K/M/G conversion
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', 'b') == 83886080
    assert human_to_bytes('10M', isbits=True) == 83886080

    # Simple KB/MB/GB conversion - should be same output as K/M/G
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10MB', 'b') == 83886080
    assert human_to_bytes('10MB', isbits=True) == 83886080

    # Simple Kb/Mb/Gb conversion
    assert human

# Generated at 2022-06-22 22:20:05.607381
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:20:16.722282
# Unit test for function bytes_to_human
def test_bytes_to_human():

    units = ('', 'K', 'M', 'G', 'T', 'P')
    for unit in units:
        for num, expect in ((0, '0 Bytes'), (1, '1 Byte'), (10, '10 Bytes'),
                            (1023, '1023 Bytes'), (1024, '1.00 KB'),
                            (1025, '1.00 KB'), (2048, '2.00 KB'),
                            (1048576, '1.00 MB'), (1073741824, '1.00 GB'),
                            (1099511627776, '1.00 TB'), (1125899906842624, '1.00 PB')):
            ret = bytes_to_human(num * (1024 ** (units.index(unit) + 1)), unit=unit)

# Generated at 2022-06-22 22:20:24.829620
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Testing lowercase suffix with bits and bytes
    assert(human_to_bytes('10m', isbits=True) == 10485760)
    assert(human_to_bytes('10M', isbits=False) == 10485760)
    # Testing uppercase suffix with bits and bytes
    assert(human_to_bytes('10MB', isbits=False) == 10485760)
    assert(human_to_bytes('10MB', isbits=False) == 10485760)
    # Testing single unit identifier with bits and bytes
    assert(human_to_bytes('10mb', isbits=True) == 10485760)
    assert(human_to_bytes('10b', isbits=True) == 10)
    assert(human_to_bytes('10B', isbits=False) == 10)


# Generated at 2022-06-22 22:20:35.520551
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024*1024) == '1.00 MB'
    assert bytes_to_human(1024*1024*1025) == '1.05 GB'
    assert bytes_to_human(1024*1024*1024) == '1.00 GB'
    assert bytes_to_human(1024*1024*1024*1024) == '1.00 TB'
    assert bytes_to_human(1024*1024*1024*1024*1024) == '1.00 PB'
    assert bytes_to_human(1024*1024*1024*1024*1024*1024) == '1.00 EB'


# Generated at 2022-06-22 22:20:43.860944
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:20:52.564913
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'foo', 'BAR', {'a': 'b'}, [1, 2]]) == [1, 'foo', 'BAR', {'a': 'b'}, [1, 2]]
    assert lenient_lowercase([1, 'fOo', 'BaR', {'a': 'b'}, [1, 2]]) == [1, 'foo', 'BAR', {'a': 'b'}, [1, 2]]
    assert lenient_lowercase(['fOo', 'BaR']) == ['foo', 'BAR']

# Generated at 2022-06-22 22:20:58.640780
# Unit test for function human_to_bytes
def test_human_to_bytes():
    bytes = human_to_bytes('1MB')
    assert bytes == 1048576
    bytes = human_to_bytes('1GB')
    assert bytes == 1073741824
    bytes = human_to_bytes('1TB')
    assert bytes == 1099511627776
    bytes = human_to_bytes('1PB')
    assert bytes == 1125899906842624
    bytes = human_to_bytes('1EB')
    assert bytes == 1152921504606846976
    bytes = human_to_bytes('1ZB')
    assert bytes == 1180591620717411303424
    bytes = human_to_bytes('1YB')
    assert bytes == 1208925819614629174706176
    bytes = human_to_bytes('1B')
    assert bytes == 1
    bytes = human_to

# Generated at 2022-06-22 22:21:08.033611
# Unit test for function bytes_to_human
def test_bytes_to_human():
    for nb_bytes in [0, 1, 512, 1023, 1024, 305419896, 512 * 1024 * 1024 * 1024 * 1024]:
        result = bytes_to_human(nb_bytes)
        assert isinstance(result, str) and " " in result and "{} {}".format(nb_bytes, 'Bytes') in result

    for nb_bits in [0, 1, 512, 1023, 1024, 305419896, 512 * 1024 * 1024 * 1024 * 1024]:
        result = bytes_to_human(nb_bits, isbits=True)
        assert isinstance(result, str) and " " in result and "{} {}".format(nb_bits, 'bits') in result

    assert bytes_to_human(1023, unit='K') == '1.00 KiBytes'

# Generated at 2022-06-22 22:21:15.884960
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase([""]) == [""]
    assert lenient_lowercase(["Aa"]) == ["aa"]
    assert lenient_lowercase(["Bb"]) == ["bb"]
    assert lenient_lowercase(["Cc"]) == ["cc"]
    assert lenient_lowercase(["Dd"]) == ["dd"]
    assert lenient_lowercase(["Ee"]) == ["ee"]
    assert lenient_lowercase(["Ff"]) == ["ff"]
    assert lenient_lowercase(["Gg"]) == ["gg"]
    assert lenient_lowercase(["Hh"]) == ["hh"]
    assert lenient_lowercase(["Ii"]) == ["ii"]

# Generated at 2022-06-22 22:21:25.533869
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase([]) == [])
    assert(lenient_lowercase(['a', 'b']) == ['a', 'b'])
    assert(lenient_lowercase(['a', 'B']) == ['a', 'b'])
    assert(lenient_lowercase(['a', 'B', 'c', 'D', 'e']) == ['a', 'b', 'c', 'D', 'e'])
    assert(lenient_lowercase(['a', 0, 'b', 'B', 'c', 'D', 'e']) == ['a', 0, 'b', 'b', 'c', 'D', 'e'])



# Generated at 2022-06-22 22:21:29.204378
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['AAAA']).pop() == 'aaaa'
    assert lenient_lowercase(['AAAA', 2, 3]).pop() == 3


# Generated at 2022-06-22 22:21:39.368098
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test bytes value
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1KBB') == 1024
    assert human_to_bytes('1KBb') == 1024
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1kB') == 1024
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1KBB') == 1024

# Generated at 2022-06-22 22:21:51.958645
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10.0M') == 10485760, "unit test failed: value: 10.0M --- expected: 10485760"
    assert human_to_bytes('10.0Mb', True) == 10485760, "unit test failed: value: 10.0Mb --- expected: 10485760"
    assert human_to_bytes('10.0MB') == 10485760, "unit test failed: value: 10.0MB --- expected: 10485760"
    assert human_to_bytes('10.0Mb', False) == 10485760, "unit test failed: value: 10.0Mb --- expected: 10485760"

# Generated at 2022-06-22 22:21:53.561218
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['AbC123', 123]) == ['abc123', 123]


# Generated at 2022-06-22 22:22:02.946192
# Unit test for function human_to_bytes
def test_human_to_bytes():

    assert(human_to_bytes('1') == 1)
    assert(human_to_bytes('10') == 10)
    assert(human_to_bytes('-87') == -87)
    assert(human_to_bytes('1B') == 1)
    assert(human_to_bytes('10B') == 10)
    assert(human_to_bytes('2K') == 2048)
    assert(human_to_bytes('2M') == 2097152)
    assert(human_to_bytes('2G') == 2147483648)
    assert(human_to_bytes('2T') == 2199023255552)
    assert(human_to_bytes('2P') == 2251799813685248)
    assert(human_to_bytes('2E') == 22605091655795712)
   