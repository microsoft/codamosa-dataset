

# Generated at 2022-06-22 22:12:09.732309
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(2, unit='B') == '2.00 Bytes'
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'
    assert bytes_to_human(10, unit='K') == '10.00 KB'
    assert bytes_to_human(10, unit='kB') == '8.00 Kb'
    assert bytes_to_human(2, unit='K') == '2.00 KB'
    assert bytes_to_human(2, unit='kB') == '1.60 Kb'

# Generated at 2022-06-22 22:12:15.926199
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 'a', 'b', 'c']) == [1, 2, 'a', 'b', 'c']
    assert lenient_lowercase([1, 2, 'A', 'b', 'C']) == [1, 2, 'a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']


# Generated at 2022-06-22 22:12:19.658798
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['Test1']) == ['test1']
    assert lenient_lowercase(['Test1', None]) == ['test1', None]

# Generated at 2022-06-22 22:12:30.185357
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1.5
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17283797747683328

    assert human_to_bytes('1Z') == 1152921504606846976
    assert human_to_bytes('1Y') == 12089

# Generated at 2022-06-22 22:12:41.962884
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(.1) == '0.10 Bytes'
    assert bytes_to_human(.0001) == '0.00 Bytes'
    assert bytes_to_human(1.0) == '1.00 Bytes'
    assert bytes_to_human(1.2, False, 'b') == '1.20 bits'
    assert bytes_to_human(1023.999) == '1.00 KB'
    assert bytes_to_human(1023.999, False, 'B') == '1023.99 Bytes'
    assert bytes_to_human(1023.999, False, 'Kb') == '1023.99 Kbits'

# Generated at 2022-06-22 22:12:44.904969
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    original_list = ["String", '123', "string2", "tEst", 123]
    expected_list = ["string", '123', "string2", "test", 123]
    assert lenient_lowercase(original_list) == expected_list

# Generated at 2022-06-22 22:12:51.690358
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1024) == '1 KB'
    assert bytes_to_human(1024 * 1024) == '1 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1 PB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1 EB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1 ZB'



# Generated at 2022-06-22 22:13:01.486466
# Unit test for function bytes_to_human
def test_bytes_to_human():

    # Size is less then a byte. Should return same number of bits
    assert bytes_to_human(100, True) == '100 bits'
    # Size equals single byte
    assert bytes_to_human(8, True) == '8 bits'
    # Size equals single byte, but rounded up
    assert bytes_to_human(9, True) == '9 bits'
    # Size is less than one kilobit
    assert bytes_to_human(99, True) == '99 bits'
    # Size is less than one kilobit
    assert bytes_to_human(1000000, True) == '100 Mbps'
    # Size equals one Megabit
    assert bytes_to_human(1000000, True) == '100 Mbps'
    # Size is 1.1 Megabit. Should be rounded up.

# Generated at 2022-06-22 22:13:11.833797
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1', default_unit=None) == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K', default_unit='B') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1KB') == 1000
    assert human_to_bytes('1Kb') == 8
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1MB') == 1000 * 1000
    assert human_to_bytes('1Mb') == 8 * 1000

# Generated at 2022-06-22 22:13:18.398722
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1000) == '1 K'
    assert bytes_to_human(1000, False, unit='B') == '1000 B'
    assert bytes_to_human(1024) == '1 K'
    assert bytes_to_human(1024, False, unit='B') == '1024 B'
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(2 ** 60) == '1 E'
    assert bytes_to_human(2 ** 70) == '1 P'
    assert bytes_to_human(2 ** 80) == '1 Y'
    assert bytes_to_human(2 ** 90) == '1 Z'
    assert bytes_to_human(2 ** 100) == '1024 Z'

# Generated at 2022-06-22 22:13:30.135426
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print("bytes_to_human() unit test\n")

    print(" - Testing input: bytes_to_human(11, 'B')")
    assert bytes_to_human(11, 'B') == '11 Bytes'

    print(" - Testing input: bytes_to_human(1048576, 'B')")
    assert bytes_to_human(1048576, 'B') == '1.00 MB'

    print(" - Testing input: bytes_to_human(8388608, 'B')")
    assert bytes_to_human(8388608, 'B') == '8.00 MB'

    print(" - Testing input: bytes_to_human(140000000000000000, 'B')")
    assert bytes_to_human(140000000000000000, 'B') == '1.40 PB'


# Generated at 2022-06-22 22:13:40.001814
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10, False, None) == '10.00 Bytes'
    assert bytes_to_human(10, True, None) == '10.00 bits'
    assert bytes_to_human(10, True, 'B') == '10.00 bits'
    assert bytes_to_human(10, False, 'B') == '10.00 Bytes'
    assert bytes_to_human(1023, False, None) == '1023.00 Bytes'
    assert bytes_to_human(1024, False, None) == '1.00 kBytes'
    assert bytes_to_human(1024, True, None) == '1.00 kbits'
    assert bytes_to_human(human_to_bytes('1Mb', isbits=True), True, None) == '1.00 Mbits'


# Generated at 2022-06-22 22:13:50.197533
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(102400) == '100.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(104857600) == '100.00 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human(10737418240) == '10.00 GB'
    assert bytes_to_human(1099511627776) == '1.00 TB'
    assert bytes_to_human(10995116277760) == '10.00 TB'
    assert bytes_to_human(1125899906842624) == '1.00 PB'

# Generated at 2022-06-22 22:14:00.438375
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(2 * 1024 * 1024) == '2.00 MB'
    assert bytes_to_human(10 * 1024, 'KB') == '10 KB'
    assert bytes_to_human(2 * 1024 * 1024, 'B') == '2.00 MB'
    assert bytes_to_human(5 * 1024 * 1024 * 1024, 'B') == '5.00 GB'
    assert bytes_to_human(2048, 'Kb') == '2.00 Kb'
    assert bytes_to_human(10 * 1024, 'kb') == '10 kb'
    assert bytes_to_human(2048, 'b') == '2.00 b'
    assert bytes_to_human(10 * 1024, 'b') == '10 b'

# Generated at 2022-06-22 22:14:05.595322
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:14:15.257248
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:14:19.988384
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    class A():
        pass

    assert lenient_lowercase(A()) == A()
    assert lenient_lowercase('azAZ') == 'azaz'
    assert lenient_lowercase(['AZ', 'Bb', A()]) == ['az', 'bb', A()]

# Generated at 2022-06-22 22:14:28.737579
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test good conversions
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.4') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.4M') == 1468006
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1T') == 1099511627776

    # Test bad conversions
    try:
        human_to_bytes('L')
        assert False, "human_to_bytes() should have thrown an exception"
    except ValueError:
        pass


# Generated at 2022-06-22 22:14:39.870821
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:14:41.931310
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input = [10, 'strA']
    output = [10, 'stra']
    assert input == output



# Generated at 2022-06-22 22:14:46.017227
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['First', '2nd', 3]) == ['first', '2nd', 3]
    assert lenient_lowercase('upper') == 'upper'


# Generated at 2022-06-22 22:14:55.437197
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # assert human_to_bytes('1M') == 1024**2
    # assert human_to_bytes('1MB') == 1024**2
    assert human_to_bytes('1Mb', isbits=True) == 1024**2
    assert human_to_bytes('1.5Mb', isbits=True) == 1536000
    assert human_to_bytes('1.5Kb', isbits=True) == 1536
    assert human_to_bytes('1.5M', unit='b', isbits=True) == 1536000
    assert human_to_bytes('1.5K', unit='b', isbits=True) == 1536
    assert human_to_bytes('1.5M', unit='b') == 1536000
    assert human_to_bytes('1.5K', unit='b') == 1536


# Generated at 2022-06-22 22:15:02.169798
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Check that size ranges are correctly ordered
    assert SIZE_RANGES['B'] < SIZE_RANGES['K']
    # Check that size ranges are correctly ordered
    assert SIZE_RANGES['b'] < SIZE_RANGES['K']

    # Test bytes
    assert human_to_bytes('10') == 10
    assert human_to_bytes(10) == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes(10, 'B') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes(10, 'b') == 10

    assert human_to_bytes('1K') == 1 << 10
    assert human_to_bytes(1, 'K') == 1 << 10

# Generated at 2022-06-22 22:15:12.477342
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # Test bytes
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10B', 'B') == 10
    assert human_to_bytes('10', 'B') == 10
    assert human_to_bytes(10, 'B') == 10
    assert human_to_bytes('1', 'B') == 1
    assert human_to_bytes(1.5, 'B') == 1
    assert human_to_bytes(1.5, 'b') == 1
    assert human_to_bytes('1.5B') == 2

    # Test kilobytes
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('10K', 'K') == 10240
    assert human_to_bytes(10, 'K') == 10240
    assert human_to_

# Generated at 2022-06-22 22:15:20.363237
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:15:24.435056
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M', 'M') == 10485760
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10Mb', 'Mb', True) == 10485760



# Generated at 2022-06-22 22:15:30.946079
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network_common import human_to_bytes

    module = AnsibleModule(argument_spec=dict())

    # tests for human_to_byte conversion

# Generated at 2022-06-22 22:15:40.625324
# Unit test for function bytes_to_human
def test_bytes_to_human():
    test_bytes = [0, 1, 511, 512, 1023, 1024, 2047, 2048, 4095, 4096, 2097151, 2097152, 4194303, 4194304, 8388607, 8388608, 16777215, 16777216, 4294967295, 4294967296, 8589934591, 8589934592, 9007199254740991, 9007199254740992, 9007199254740994]

# Generated at 2022-06-22 22:15:49.985251
# Unit test for function bytes_to_human
def test_bytes_to_human():
    if human_to_bytes('10M') != 10 * (1 << 20):
        raise ValueError("Test 1: Failed")
    if human_to_bytes('10MB') != 10 * (1 << 20):
        raise ValueError("Test 2: Failed")
    if human_to_bytes('10Mb', isbits=True) != 10 * (1 << 20):
        raise ValueError("Test 3: Failed")
    if human_to_bytes('10', unit='M') != 10 * (1 << 20):
        raise ValueError("Test 4: Failed")
    if bytes_to_human(10 * (1 << 20)) != '10.00 MB':
        raise ValueError("Test 5: Failed")

# Generated at 2022-06-22 22:16:00.615412
# Unit test for function lenient_lowercase

# Generated at 2022-06-22 22:16:11.730108
# Unit test for function bytes_to_human
def test_bytes_to_human():
    base = 'Bytes'
    bytes_number = 123456789
    assert bytes_to_human(bytes_number) == '123.46 MB'
    assert bytes_to_human(bytes_number, unit='M') == '0.12 MB'
    assert bytes_to_human(bytes_number, unit='K') == '123456.79 K'
    assert bytes_to_human(bytes_number, unit='B') == '123456789 B'
    assert bytes_to_human(bytes_number, unit='b') == '98.70 Mbits'

    assert bytes_to_human(bytes_number, isbits=True) == '98.70 Mbits'
    assert bytes_to_human(bytes_number, isbits=True, unit='M') == '0.08 Mb'

# Generated at 2022-06-22 22:16:18.027145
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('0') == 0
    assert human_to_bytes('1') == 1
    assert human_to_bytes(' 1 ') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('3.4') == 3
    assert human_to_bytes('3.5') == 4
    assert human_to_bytes('3.6') == 4
    assert human_to_bytes('3.7') == 4
    assert human_to_bytes('3.8') == 4
    assert human_to_bytes('3.9') == 4
    assert human_to_bytes('3.01') == 3   # not 4
    assert human_to_bytes('3.010') == 3  # not 4
    assert human_to_bytes('3.01001') == 4 

# Generated at 2022-06-22 22:16:28.709337
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(123) == "123.00 Bytes"
    assert bytes_to_human(123.456) == "123.45 Bytes"
    assert bytes_to_human(123.456, unit='b') == "123.46 Bytes"
    assert bytes_to_human(1) == "1.00 Bytes"
    assert bytes_to_human(1023) == "1023.00 Bytes"
    assert bytes_to_human(1023.2) == "1023.20 Bytes"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1048576) == "1.00 MB"
    assert bytes_to_human(1073741824) == "1.00 GB"

# Generated at 2022-06-22 22:16:35.344386
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test a list of normal strings
    assert lenient_lowercase(['abc', 'DEF', 'Ghi']) == \
        ['abc', 'def', 'ghi']

    # Test a list of mixed strings
    assert lenient_lowercase(['abc', 1, 'Ghi']) == \
        ['abc', 1, 'ghi']



# Generated at 2022-06-22 22:16:43.108373
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase([1]) == [1]
    assert lenient_lowercase(['a', 'B', 'c', 'D']) == ['a', 'B', 'c', 'D']
    assert lenient_lowercase('test') == 'test'
    assert lenient_lowercase(['123', '456']) == ['123', '456']
    assert lenient_lowercase([1, 'abc', 'DEF']) == [1, 'abc', 'DEF']
    assert lenient_lowercase(['abcd', 'efgh', [1, 2, 3]]) == ['abcd', 'efgh', [1, 2, 3]]



# Generated at 2022-06-22 22:16:51.280880
# Unit test for function human_to_bytes
def test_human_to_bytes():
    def test_exception(input_, msg):
        try:
            human_to_bytes(input_)
        except ValueError as e:
            assert input_ in e.args, msg

        try:
            human_to_bytes(input_, default_unit='M')
        except ValueError as e:
            assert input_ in e.args, msg

    test_exception('1sdad', 'Not a number')
    test_exception('1.6.1', 'Not a number')
    test_exception(' 1.0', 'Not a number')
    test_exception('1.0 ', 'Not a number')
    test_exception('-1.0', 'Not a number')
    test_exception('1.0a', 'Not a number')

# Generated at 2022-06-22 22:16:58.343240
# Unit test for function bytes_to_human
def test_bytes_to_human():
    units = ['Y', 'Z', 'E', 'P', 'T', 'G', 'M', 'K', 'B']
    for unit in units:
        value = human_to_bytes(1, unit)
        assert bytes_to_human(value, unit=unit) == '1.00 ' + unit + 'B'
        assert bytes_to_human(value, isbits=True, unit=unit) == '1.00 ' + unit + 'b'



# Generated at 2022-06-22 22:17:03.096290
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 5, [1, 2]]) == ['a', 5, [1, 2]]
    assert lenient_lowercase(['A', 5, [1, 2]]) == ['a', 5, [1, 2]]



# Generated at 2022-06-22 22:17:15.324873
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:17:18.875901
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['aAa', 'bbBb', 1, 2, 3, None]
    assert lenient_lowercase(lst) == ['aaa', 'bbbb', 1, 2, 3, None]



# Generated at 2022-06-22 22:17:25.753277
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_list = [('0B', 0),
                 ('1b', 1),
                 ('1Bb', 8),
                 ('2KiB', 2048),
                 ('1M', 1048576),
                 ('1.1Mb', 1153433.6),
                 ('2.2MiB', 2359296),
                 ('3.3G', 3.3 * 1024 * 1024 * 1024),
                 ('3.3Gb', 3.3 * 1024 * 1024 * 1024 * 8),
                 ('3.3GiB', 35651584),
                 ('1.1MiB', 1153434),
                 ('2.2Mb', 2359296 * 8),
                 ('3.3Gib', 356515840),
                 ('3.3GB', 3.3 * 1024 * 1024 * 1024),
                ]


# Generated at 2022-06-22 22:17:35.151497
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes(10) == 10
    assert human_to_bytes('10.0') == 10
    assert human_to_bytes(10.0) == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes(10, unit='b') == 10
    assert human_to_bytes('10Mb') == 10 * 1024 * 1024
    assert human_to_bytes(10, unit='Mb') == 10 * 1024 * 1024
    assert human_to_bytes('10.1Mb') == 10 * 1024 * 1024 + 102400
    assert human_to_bytes(10.1, unit='Mb') == 10 * 1024 * 1024 + 102400
    assert human_to_bytes('10.0Mb') == 10 * 1024 * 1024

# Generated at 2022-06-22 22:17:38.016004
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'a', 'b', 'c', 2]) == [1, 'a', 'b', 'c', 2]
    assert lenient_lowercase([1, 'A', 'b', 'C', 2]) == [1, 'a', 'b', 'c', 2]


# Generated at 2022-06-22 22:17:42.796413
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['A']) == ['a']
    assert lenient_lowercase([123]) == [123]
    assert lenient_lowercase(['A', 123, 'b']) == ['a', 123, 'b']

# Generated at 2022-06-22 22:17:50.691876
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    cases = [
        {
            'input': ['a', 'b', 'c'],
            'expected': ['a', 'b', 'c'],
        },
        {
            'input': ['A', 'b', 'C'],
            'expected': ['a', 'b', 'c'],
        },
        {
            'input': ['A', ['B'], 'C'],
            'expected': ['a', ['B'], 'c'],
        },
    ]
    for case in cases:
        actual = lenient_lowercase(case['input'])
        assert actual == case['expected'], "Expected: %s, Actual: %s" % (case['expected'], actual)

# Generated at 2022-06-22 22:18:03.212454
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(2048, unit='k') == '2.00 KB'
    assert bytes_to_human(2048, unit='kb') == '2.00 KB'
    assert bytes_to_human(2048, unit='kB') == '2.00 KB'
    assert bytes_to_human(2048, unit='KB') == '2.00 KB'

    assert bytes_to_human(2048, isbits=True) == '2.00 Kb'
    assert bytes_to_human(2048, isbits=True, unit='k') == '2.00 Kb'
    assert bytes_to_human(2048, isbits=True, unit='kb') == '2.00 Kb'
    assert bytes_

# Generated at 2022-06-22 22:18:06.286322
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576) == '1.00 MB'  # Bytes
    assert bytes_to_human(1048576, isbits=True) == '8.00 Mb'  # bits



# Generated at 2022-06-22 22:18:10.784178
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['a1', 'B2', 3, {'a':1}]) == ['a1', 'b2', 3, {'a':1}]

# Generated at 2022-06-22 22:18:18.636722
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''bytes_to_human test'''

    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(0.99) == '0.99 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, unit='K') == '1.00 KB'
    assert bytes_to_human(1024, unit='KB') == '1.00 KB'
    assert bytes_to_human(1025) == '1.00 KB'
    assert bytes_to_human(1025, unit='K') == '1.00 KB'
    assert bytes_to_human(1025, unit='KB') == '1.00 KB'
    assert bytes_to

# Generated at 2022-06-22 22:18:28.114361
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10, unit='K') == '0.01 KB'
    assert bytes_to_human(1010, unit='K') == '0.98 KB'
    assert bytes_to_human(1010, unit='M') == '0.00 MB'
    assert bytes_to_human(99999999, unit='Mb') == '79.00 Mb'
    assert bytes_to_human(10001010, unit='b') == '79.00 bits'
    assert bytes_to_human(1000000000, unit='Gb') == '8.00 Gb'
    assert bytes_to_human(1000000000, unit='MB') == '953.67 MB'
    assert bytes_to_human(1000000000, unit='MB') == '953.67 MB'

# Generated at 2022-06-22 22:18:39.898640
# Unit test for function bytes_to_human
def test_bytes_to_human():
    out = bytes_to_human(1)
    assert out == '1.00 Bytes'
    out = bytes_to_human(1, unit='b')
    assert out == '1.00 Bytes'
    out = bytes_to_human(1, unit='B')
    assert out == '1.00 Bytes'
    out = bytes_to_human(1, unit='K')
    assert out == '1.00 KB'
    out = bytes_to_human(1, unit='Kb')
    assert out == '1.00 KB'
    out = bytes_to_human(1, unit='kb')
    assert out == '1.00 Kb'
    out = bytes_to_human(1, isbits=True, unit='kb')
    assert out == '1.00 Kbits'

# Generated at 2022-06-22 22:18:50.942515
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    from collections import OrderedDict
    from ansible.module_utils._text import to_text, to_bytes

    # simple list of strings
    list_of_strings = ["First", "Second", "Third"]
    assert lenient_lowercase(list_of_strings) == ["first", "second", "third"]

    # list containing a unicode string
    list_of_strings = ["First", u"zweiter", "Third"]
    assert lenient_lowercase(list_of_strings) == ["first", u"zweiter", "third"]

    # list containing a string with diacritics
    list_of_strings = ["First", u"zweiter", u"Élément"]
    assert lenient_lowercase(list_of_strings) == ["first", u"zweiter", u"Élément"]

# Generated at 2022-06-22 22:18:59.440323
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1MBb', isbits=True) == 1048576
    assert human_to_bytes('1024.0B') == 1024
    assert human_to_bytes('1024.0b', isbits=True) == 1024
    assert human_to_bytes('1024B') == 1024

# Generated at 2022-06-22 22:19:04.991070
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Size
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(1 << 10) == '1.00 KBytes'
    assert bytes_to_human(1 << 20) == '1.00 MBytes'
    assert bytes_to_human(1 << 30) == '1.00 GBytes'
    assert bytes_to_human(1 << 40) == '1.00 TBytes'

    # Bits
    assert bytes_to_human(0, True) == '0 bits'
    assert bytes_to_human(1, True) == '1 bits'
    assert bytes_to_human(10, True) == '10 bits'

# Generated at 2022-06-22 22:19:13.364641
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1) == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1

    assert human_to_bytes('1K') == 1 << 10
    assert human_to_bytes('1KB') == 1 << 10
    assert human_to_bytes('1Kb') == human_to_bytes('1KB', isbits=True)
    assert human_to_bytes('1Kb', isbits=True) == 1 << 10
    assert human_to_bytes('1K', default_unit='B') == 1 << 10
    assert human_to_bytes('1K', default_unit='b') == 1 << 10

    assert human_to_bytes('1M') == 1 << 20
    assert human_to_bytes('1Mb') == human_to_

# Generated at 2022-06-22 22:19:23.153872
# Unit test for function bytes_to_human
def test_bytes_to_human():
    units = ['B', 'K', 'KB', 'M', 'MB', 'G', 'GB']
    assert [bytes_to_human(i) for i in [0, 1, 1024, 1025, 1048576, 1048577, 1073741824, 1073741825]] == ['0.00 Bytes', '1.00 Bytes', '1.00 KB', '1.00 KB', '1.00 MB', '1.00 MB', '1.00 GB', '1.00 GB']

# Generated at 2022-06-22 22:19:32.336224
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''
    Function bytes_to_human converts bytes to bit with human readable format
    '''
    assert bytes_to_human(0, False) == '0 Bytes'
    assert bytes_to_human(0, True) == '0 bits'
    assert bytes_to_human(0, True, 'k') == '0 Kbits'
    assert bytes_to_human(0, True, 'g') == '0 Gbits'
    assert bytes_to_human(1000000, True, 'g') == '0.95 Gbits'
    assert bytes_to_human(1000000, True, 'm') == '0.93 Mbits'
    assert bytes_to_human(1000000, True, 'k') == '976.56 Kbits'
    assert bytes_to_human(1000000, False) == '1 MB'

# Generated at 2022-06-22 22:19:42.966961
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # AnsibleModule and Bytes related imports
    # module = AnsibleModule({'size': '10'})
    # module = AnsibleModule({'size': '10B'})
    module = AnsibleModule({'size': '10MB'})
    # module = AnsibleModule({'size': '10KB'})
    # module = AnsibleModule({'size': '10K'})
    # module = AnsibleModule({'size': '10M'})
    # module = AnsibleModule({'size': '10G'})
    # module = AnsibleModule({'size': '10T'})
    # module = AnsibleModule({'size': '10P'})
    # module = AnsibleModule({'size': '10Z'})
    # module = AnsibleModule({'size': '10Y'})
    # module

# Generated at 2022-06-22 22:19:54.125549
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Function tests the following cases:
        - converting from bytes to human representation (base 1024)
        - converting from bits to human representation (base 1024)
        - converting from bytes to human representation (base 1000)
        - converting from bits to human representation (base 1000)
        - converting from human representation to bytes (base 1024)
        - converting from human representation to bits (base 1024)
        - converting from human representation to bytes (base 1000)
        - converting from human representation to bits (base 1000)
    '''

# Generated at 2022-06-22 22:20:06.725476
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024*1024) == '1.00 MB'
    assert bytes_to_human(1024*1024*1024) == '1.00 GB'
    assert bytes_to_human(1024*1024*1024*1024) == '1.00 TB'
    assert bytes_to_human(1024*1024*1024*1024*1024) == '1.00 PB'
    assert bytes_to_human(1024*1024*1024*1024*1024*1024) == '1.00 EB'

# Generated at 2022-06-22 22:20:17.205838
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Test cases for function human_to_bytes '''
    # convert from bytes
    assert human_to_bytes('1') == 1
    assert human_to_bytes('2') == 2
    assert human_to_bytes('1M') == 1 << 20
    assert human_to_bytes('2M') == 2 << 20
    assert human_to_bytes('1Mb') == (1 << 20) * 8
    assert human_to_bytes('2Mb') == (2 << 20) * 8

    # convert from bits
    assert human_to_bytes('1', isbits=True) == 1
    assert human_to_bytes('2', isbits=True) == 2
    assert human_to_bytes('1M', isbits=True) == 1 << 20

# Generated at 2022-06-22 22:20:22.088343
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576, unit='M') == '1.00 MB'
    assert bytes_to_human(1048576, unit='m') == '1.00 MB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048576, True) == '1.00 Mbits'



# Generated at 2022-06-22 22:20:23.650494
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'b', 'C', 1]) == ['a', 'b', 'c', 1]


# Generated at 2022-06-22 22:20:33.875100
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = human_to_bytes('2k')
    assert result == 2048, "got %s, should be 2048" % result

    result = human_to_bytes('2B')
    assert result == 2, "got %s, should be 2" % result

    result = human_to_bytes('1.5K')
    assert result == 1536, "got %s, should be 1536" % result

    result = human_to_bytes('1.5Kb', True)
    assert result == 1536, "got %s, should be 1536" % result

    result = human_to_bytes('1.5K', True)
    assert result == 1, "got %s, should be 1" % result

    result = human_to_bytes('1.5Mb', True)

# Generated at 2022-06-22 22:20:42.766139
# Unit test for function bytes_to_human
def test_bytes_to_human():

    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, unit='M') == '0.00 MB'
    assert bytes_to_human(10, unit='M') == '0.01 MB'
    assert bytes_to_human(100, unit='M') == '0.10 MB'
    assert bytes_to_human(1000, unit='M') == '1.00 MB'
    assert bytes_to_human(1024, unit='M') == '1.00 MB'
    assert bytes_to_human(1024**2, unit='M') == '1024.00 MB'

    assert bytes_to_human(1, unit='b') == '1.00 bits'
   

# Generated at 2022-06-22 22:20:54.632629
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """ Unit test adapter for bytes_to_human.

    Returns:
        Returns the result of the unit test.
        (True, 'All expected values match the actual values in the function bytes_to_human')
    Raises:
        Raises an error when there is a mismatch between the actual and expected values.
    """

# Generated at 2022-06-22 22:21:05.345995
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit="kb") == '1.00 KB'
    assert bytes_to_human(human_to_bytes(1, "kb") - 1, "kb") == '0.00 KB'
    assert bytes_to_human(human_to_bytes(1, "kb")) == '1.00 KB'
    assert bytes_to_human(human_to_bytes(1, "MB") - 1, "MB") == '0.00 MB'
    assert bytes_to_human(human_to_bytes(1, "MB")) == '1.00 MB'
    assert bytes_to_human(1024 ** 2 - 1) == '1023.00 Bytes'

# Generated at 2022-06-22 22:21:14.356507
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(123456789) == '117.74 MB'
    assert bytes_to_human(1234567890) == '1.15 GB'
    assert bytes_to_human(123456789012) == '11.57 GB'
    assert bytes_to_human(123456789012345) == '1.11 TB'
    assert bytes_to_human(12345678901234567890) == '1.09 PB'
    assert bytes_to_human(12345678901234567890123) == '1.07 EB'
    assert bytes_to_human(12345678901234567890123456) == '1.05 ZB'

# Generated at 2022-06-22 22:21:17.821275
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'A', 2, 'B']) == [1, 'a', 2, 'b']
    assert lenient_lowercase([3, 'C', 4]) == [3, 'c', 4]



# Generated at 2022-06-22 22:21:28.026494
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # human_to_bytes() test
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10', unit='B') == 10
    assert human_to_bytes('10', unit='b') == 10
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('10K') == human_to_bytes('10KB')
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10Mb') == 13107200
    assert human_to_bytes('10Mb', isbits=True) == 13107200
    assert human_to_bytes('10Mb', default_unit='M') == 10485760

# Generated at 2022-06-22 22:21:38.481839
# Unit test for function lenient_lowercase

# Generated at 2022-06-22 22:21:47.154415
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Testing arrays
    actual = lenient_lowercase(['UpPeR', 'lOWeR', 'MiXeD'])
    expected = ['upper', 'lower', 'mixed']
    assert actual == expected

    actual = lenient_lowercase([1, 2, 3, 4, 5])
    expected = [1, 2, 3, 4, 5]
    assert actual == expected

    actual = lenient_lowercase([None, 'sTring'])
    expected = [None, 'string']
    assert actual == expected


# Generated at 2022-06-22 22:21:56.821298
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print('Testing bytes_to_human')
    # sanity check
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(2 ** 20) == '1.00 MB'
    assert bytes_to_human(2 ** 30) == '1.00 GB'
    assert bytes_to_human(2 ** 40) == '1.00 TB'
    assert bytes_to_human(2 ** 50) == '1.00 PB'
    assert bytes_to_human(2 ** 60) == '1.00 EB'
    assert bytes_to_human(2 ** 70) == '1.00 ZB'
    assert bytes_to_human(2 ** 80) == '1.00 YB'

    # partial sanity

# Generated at 2022-06-22 22:22:05.485557
# Unit test for function human_to_bytes
def test_human_to_bytes():

    assert human_to_bytes('1.1M') == 11534336
    assert human_to_bytes('1.1M', isbits=True) == 11534336
    assert human_to_bytes('1K', default_unit='B') == 1024
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.2K') == 1228
    assert human_to_bytes('1.2K', isbits=True) == 1228
    assert human_to_bytes('1Kb') == 8192
    assert human_to_bytes('1.2Kb', isbits=True) == 9856
    assert human_to_bytes('1.1Mb') == 11534336
    assert human_to_bytes('1.1Mb', isbits=True) == 11534336
    assert human