

# Generated at 2022-06-22 22:12:11.773837
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(2000, unit='k') == '1.95 KB', \
        'Failed to convert bytes to human readable format with unit (k).'

    assert bytes_to_human(2000, unit='m') == '0.00 MB', \
        'Failed to convert bytes to human readable format with unit (m).'

    assert bytes_to_human(2000, unit='g') == '0.00 GB', \
        'Failed to convert bytes to human readable format with unit (g).'

    assert bytes_to_human(2000, unit='t') == '0.00 TB', \
        'Failed to convert bytes to human readable format with unit (t).'


# Generated at 2022-06-22 22:12:21.094538
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, unit='Y') == '1.00 YBytes'
    assert bytes_to_human(1, unit='Z') == '1.00 ZBytes'

    assert bytes_to_human(512) == '512.00 Bytes'
    assert bytes_to_human(512, unit='B') == '512.00 Bytes'
    assert bytes_to_human(512, unit='Y') == '512.00 YBytes'
    assert bytes_to_human(512, unit='Z') == '512.00 ZBytes'

    assert bytes_to_human(1073741824) == '1.00 GBytes'
   

# Generated at 2022-06-22 22:12:25.731866
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['UPPERCASE', 1, 'mixEd', None, 'lowercase']
    actual = lenient_lowercase(lst)
    assert actual == ['uppercase', 1, 'mixed', None, 'lowercase']

# Generated at 2022-06-22 22:12:31.649929
# Unit test for function human_to_bytes
def test_human_to_bytes():
    for value in ['1', '1MB', '1Mb', '1KB', '1Kb', '1B', '1b', '1.5MB', '1.5KB', '1.5MB']:
        print(human_to_bytes(value))


if __name__ == '__main__':
    test_human_to_bytes()

# Generated at 2022-06-22 22:12:34.176966
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a']) == ['a']
    assert lenient_lowercase([1, 'a']) == [1, 'a']

# Unit tests for function human_to_bytes

# Generated at 2022-06-22 22:12:43.733390
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # isbits = False
    assert bytes_to_human(1) == "1 Bytes"
    assert bytes_to_human(1023) == "1023 Bytes"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1048576) == "1.00 MB"
    assert bytes_to_human(1099511627776) == "1.00 TB"
    assert bytes_to_human(1125899906842624) == "1.00 PB"
    assert bytes_to_human(1152921504606846976) == "1.00 EB"
    assert bytes_to_human(1180591620717411303424) == "1.00 ZB"

# Generated at 2022-06-22 22:12:52.974341
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # test normal case
    assert bytes_to_human(1024 * 1024 * 1024) == "1.00 GB"
    assert bytes_to_human(1024 * 1024 * 1024, unit="MB") == "1024.00 MB"

    # test isbits
    assert bytes_to_human(1024 * 1024 * 1024, isbits=True) == "8.00 Gbits"

    # test long
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == "8.00 EB"

    # test rounding
    assert bytes_to_human(1024 * 1024 * 1024 + 512) == "1.00 GB"



# Generated at 2022-06-22 22:13:04.228635
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 EB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 ZB'

# Generated at 2022-06-22 22:13:13.620533
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(None) == '0 Bytes'
    assert bytes_to_human(0) == '0 Bytes'

    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, unit='KB') == '1.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048576, unit='MB') == '1.00 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human(1073741824, unit='GB') == '1.00 GB'
   

# Generated at 2022-06-22 22:13:16.263567
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    import pytest

    assert lenient_lowercase(['A', 'B']) == ['a', 'b']
    assert lenient_lowercase(['A', 123, 'B']) == ['a', 123, 'b']

# Generated at 2022-06-22 22:13:24.314354
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('0', default_unit='B') == 0
    assert human_to_bytes('0b', default_unit='B') == 0
    assert human_to_bytes('0B', default_unit='b') == 0

    assert human_to_bytes('0 B') == 0
    assert human_to_bytes('0 b') == 0
    assert human_to_bytes('0 B') == 0

    assert human_to_bytes('0.0 B') == 0
    assert human_to_bytes('0.0 b') == 0
    assert human_to_bytes('0.0 B') == 0

    assert human_to_bytes('0.00 B') == 0
    assert human_to_bytes('0.00 b') == 0
    assert human_to_bytes('0.00 B') == 0


# Generated at 2022-06-22 22:13:34.116608
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import assert_equals
    assert_equals(human_to_bytes('10M'), 10485760)
    assert_equals(human_to_bytes('10G'), 10737418240)
    assert_equals(human_to_bytes('10m'), 10485760)
    assert_equals(human_to_bytes('10g'), 10737418240)
    assert_equals(human_to_bytes('10Mb'), 10485760)
    assert_equals(human_to_bytes('10Gb'), 10737418240)
    assert_equals(human_to_bytes('10mb'), 10485760)
    assert_equals(human_to_bytes('10gb'), 10737418240)

# Generated at 2022-06-22 22:13:42.430733
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Expect Lowercase
    l = ["string", "string"]
    assert lenient_lowercase(l) == ["string", "string"]

    l = [1, 2]
    assert lenient_lowercase(l) == [1, 2]

    l = ["String", "String"]
    assert lenient_lowercase(l) == ["string", "string"]

    l = ["STRING", "STRING"]
    assert lenient_lowercase(l) == ["string", "string"]

    l = ["string", 2]
    assert lenient_lowercase(l) == ["string", 2]

    l = [1, "String"]
    assert lenient_lowercase(l) == [1, "string"]

    l = [1, "STRING"]

# Generated at 2022-06-22 22:13:55.667102
# Unit test for function bytes_to_human
def test_bytes_to_human():
    result = bytes_to_human(1)
    assert '1.00 B' == result

    result = bytes_to_human(1, isbits=True)
    assert '8.00 b' == result

    result = bytes_to_human(2048)
    assert '2.00 K' == result

    result = bytes_to_human(2048, isbits=True)
    assert '16.00 Kb' == result

    result = bytes_to_human(2048, unit='K')
    assert '2.00 K' == result

    result = bytes_to_human(2048, unit='b')
    assert '16.00 Kb' == result

    result = bytes_to_human(2048, unit='T')
    assert '0.00 T' == result


# Generated at 2022-06-22 22:14:02.604906
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test for bytes
    assert human_to_bytes('10.0B') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10') == 10
    assert human_to_bytes(10) == 10

# Generated at 2022-06-22 22:14:12.839264
# Unit test for function bytes_to_human
def test_bytes_to_human():
    s = human_to_bytes('1')
    assert s == 1
    s = human_to_bytes('1.1')
    assert s == 1
    s = human_to_bytes('2.2')
    assert s == 2
    s = human_to_bytes('1K')
    assert s == 1024
    s = human_to_bytes('1M')
    assert s == 1048576
    s = human_to_bytes('1G')
    assert s == 1073741824
    s = human_to_bytes('1T')
    assert s == 1099511627776
    s = human_to_bytes('1P')
    assert s == 1125899906842624
    s = human_to_bytes('1E')
    assert s == 1152921504606846976
    s = human_

# Generated at 2022-06-22 22:14:23.598858
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048576, unit="KB") == '1024.00 KB'
    assert bytes_to_human(1048576, unit="Kb") == '8388608.00 Kb'
    assert bytes_to_human(1048576, isbits=True, unit="Kb") == '8388608.00 Kb'
    assert bytes_to_human(1048576, isbits=True) == '8388608.00 bits'
    assert bytes_to_human(1048576, unit="bytes") == '1048576.00 bytes'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes

# Generated at 2022-06-22 22:14:31.012772
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:14:38.447376
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'c']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 1, 'c', None, 'ab']) == ['a', 1, 'c', None, 'ab']
    assert lenient_lowercase(['A', 1, 'c', None, 'ab', 'CBA']) == ['a', 1, 'c', None, 'ab', 'CBA']

# Generated at 2022-06-22 22:14:49.699133
# Unit test for function bytes_to_human
def test_bytes_to_human():
    test_parameters = [1, 10, 100, 1000, 10000, 56789, 1000000,
                       10000000, 100000000, 1000000000,
                       10000000000, 100000000000, 1000000000000,
                       56789000000, 10000000000000, -1, -10.1, -10.0, 0, 1.0]

# Generated at 2022-06-22 22:14:53.934776
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]


# The following tests are for human_to_bytes()

# Generated at 2022-06-22 22:15:03.246132
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2.2K', default_unit='B') == 2 * (1 << 10) + 2 * (1 << 9)
    assert human_to_bytes('2.2M', default_unit='B') == 2 * (1 << 20) + 2 * (1 << 19)
    assert human_to_bytes('2.2G', default_unit='B') == 2 * (1 << 30) + 2 * (1 << 29)
    assert human_to_bytes('.2G', default_unit='B') == 2 * (1 << 29)
    assert human_to_bytes('.2m', default_unit='B') == 2 * (1 << 19)
    assert human_to_bytes('2.2', default_unit='B') == 2

# Generated at 2022-06-22 22:15:13.445789
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:15:20.619089
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1234]) == ['a', 'b', 1234]
    assert lenient_lowercase(['A', 'B', None]) == ['a', 'b', None]
    assert lenient_lowercase([]) == []



# Generated at 2022-06-22 22:15:22.856752
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'A', 'b', 'c']) == [1, 'a', 'b', 'c']



# Generated at 2022-06-22 22:15:30.072396
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('1KB') == 1000
    assert human_to_bytes('1Kb') == human_to_bytes('1KB', isbits=True)
    assert human_to_bytes('1MB') == 1000000
    assert human_to_bytes('1Mb') == human_to_bytes('1MB', isbits=True)
    assert human_to_bytes('1GB') == 1000000000
    assert human_to_bytes('1Gb') == human_to_bytes('1GB', isbits=True)
    assert human_to_bytes('1TB') == 1000000000000
    assert human_to_bytes('1Tb') == human_to_bytes('1TB', isbits=True)


# Generated at 2022-06-22 22:15:40.482420
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print('Test %s' % bytes_to_human(1024))
    print('Test %s' % bytes_to_human(1024, isbits=True))
    print('Test %s' % bytes_to_human(1024, unit='Byte'))
    print('Test %s' % bytes_to_human(1024, isbits=True, unit='Bit'))
    print('Test %s' % bytes_to_human(1024, isbits=False, unit='Byte'))
    print('Test %s' % bytes_to_human(1024, isbits=True, unit='Bit'))
    print('Test %s' % bytes_to_human(1024, unit='K'))
    print('Test %s' % bytes_to_human(1024, isbits=True, unit='k'))

# Generated at 2022-06-22 22:15:49.884026
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('10M') == 10485760)
    assert(human_to_bytes('10M', isbits=True) == 10485760)
    assert(human_to_bytes('10Mb') == 10485760)
    assert(human_to_bytes('10Mb', isbits=True) == 10485760)
    assert(human_to_bytes(10, 'M') == 10485760)
    assert(human_to_bytes(10, 'M', isbits=True) == 10485760)
    assert(human_to_bytes(10, 'MB') == 10485760)
    assert(human_to_bytes(10, 'MB', isbits=True) == 10485760)

# Generated at 2022-06-22 22:15:53.457219
# Unit test for function bytes_to_human
def test_bytes_to_human():
    test_values = (
        (1000000, '1.00 MB'),
        (2048, '2.00 KB'),
        (2147483648, '2.00 GB'),
        (2500000000, '2.38 GB'),
        (30000000000, '28.61 GB'),
        (8000000000, '7.63 GB'),
    )

    for value in test_values:
        assert bytes_to_human(value[0]) == value[1]


# Generated at 2022-06-22 22:16:00.897510
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class Test(object):
        def __init__(self, result=None, exception=None):
            self.exception = exception
            self.result = result


# Generated at 2022-06-22 22:16:07.569128
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 'cA']) == ['a', 'B', 'c', 'cA']
    assert lenient_lowercase(['a', 'B', 4, 'cA']) == ['a', 'B', 4, 'cA']
    assert lenient_lowercase(['a', 'B', None, 'cA']) == ['a', 'B', None, 'cA']

# Generated at 2022-06-22 22:16:15.462153
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10', 'B') == 10
    assert human_to_bytes('10', 'b') == 10
    assert human_to_bytes('10', 'b', isbits=True) == 10
    assert human_to_bytes('10KB') == 10240
    assert human_to_bytes('10KB', isbits=True) == 10240
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=False) == 10485760
    assert human_to_bytes('10.5Mb', isbits=True)

# Generated at 2022-06-22 22:16:21.992912
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """
    Test converting list to lowercase.
    """
    assert lenient_lowercase(['Mb']) == ['mb']
    assert lenient_lowercase([True]) == [True]
    assert lenient_lowercase(['MB']) == ['MB']
    assert lenient_lowercase([{'a': 1}]) == [{'a': 1}]


# Generated at 2022-06-22 22:16:25.615343
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'B', 'c']
    assert lenient_lowercase(['a', 'B', None]) == ['a', 'B', None]
    assert lenient_lowercase(['a', 'B', 5]) == ['a', 'B', 5]



# Generated at 2022-06-22 22:16:32.617629
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10000) == '9.77 KB'
    assert bytes_to_human(100001221) == '95.37 MB'
    assert bytes_to_human(100001221000) == '9.31 GB'
    assert bytes_to_human(100001221000000) == '8.59 TB'
    assert bytes_to_human(100001221000000000) == '7.87 PB'
    assert bytes_to_human(100001221000000000000) == '7.15 EB'
    assert bytes_to_human(100001221000000000000000) == '6.44 ZB'
    assert bytes_to_human(100001221000000000000000000) == '5.72 YB'

    assert bytes_to_human(10, isbits=True) == '80.00 bits'
    assert bytes_to_

# Generated at 2022-06-22 22:16:36.205152
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(int(1E9)) == "1.00 GB"
    assert bytes_to_human(int(10E9)) == "10.00 GB"
    assert bytes_to_human(int(1E9), unit='b') == "8.00 Gb"
    assert bytes_to_human(int(1E9), unit='B') == "1.00 GB"



# Generated at 2022-06-22 22:16:44.796093
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10B', isbits=True) == 80
    assert human_to_bytes('10b', isbits=True) == 10
    assert human_to_bytes('10b', isbits=False) == 10
    assert human_to_bytes('20b', isbits=False) == 20
    assert human_to_bytes('20b', isbits=True) == 160
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1k', isbits=True) == 8192
    assert human_to_bytes('1.2M') == 1258291
    assert human_to_bytes('1.2MB') == 1258291
    assert human_to_

# Generated at 2022-06-22 22:16:54.324337
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print("Unit test bytes_to_human()")


# Generated at 2022-06-22 22:16:59.412201
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['A']) == ['a']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase([1, 'A', 3]) == [1, 'a', 3]

# Generated at 2022-06-22 22:17:09.356946
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(float('Nan')) == 'Nan Bytes'
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Byte'

    assert bytes_to_human(2 ** 10) == '1.00 KBytes'
    assert bytes_to_human(2 ** 20) == '1.00 MBytes'
    assert bytes_to_human(2 ** 30) == '1.00 GBytes'
    assert bytes_to_human(2 ** 40) == '1.00 TBytes'
    assert bytes_to_human(2 ** 50) == '1.00 PBytes'
    assert bytes_to_human(2 ** 60) == '1.00 EBytes'

# Generated at 2022-06-22 22:17:20.358828
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1000) == '1000.00 Bytes'
    assert bytes_to_human(100000) == '100000.00 Bytes'
    assert bytes_to_human(1000000) == '1000000.00 Bytes'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(10485760) == '10.00 MB'
    assert bytes_to_human(104857600) == '100.00 MB'
    assert bytes_to_human(1048576000) == '1000.00 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'

# Generated at 2022-06-22 22:17:31.983179
# Unit test for function lenient_lowercase

# Generated at 2022-06-22 22:17:40.948882
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Bytes to Bytes conversion
    tests = [
        ('1024', 1024),
        ('1B', 1),
        ('1M', 1 * 1024 * 1024),
        ('1GB', 1 * 1024 * 1024 * 1024),
    ]
    # run tests
    for item in tests:
        assert human_to_bytes(item[0]) == item[1]

    # Bytes to bits conversion

# Generated at 2022-06-22 22:17:50.409726
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:18:02.950059
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert (human_to_bytes('2K')) == 2048
    assert (human_to_bytes('2B')) == 2
    assert (human_to_bytes('2M')) == 2097152
    assert (human_to_bytes('2Mb')) == 2097152
    assert (human_to_bytes('2MB')) == 2097152
    assert (human_to_bytes('2MB', isbits=True)) == 16777216
    assert (human_to_bytes('2G')) == 2147483648
    assert (human_to_bytes('2b')) == 1
    assert (human_to_bytes('2MB', isbits=False)) == 2097152
    assert (human_to_bytes('2Mb', isbits=True)) == 2097152

# Generated at 2022-06-22 22:18:05.302650
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'C', 1, 2]) == ['a', 'b', 'c', 1, 2]

# Generated at 2022-06-22 22:18:16.571306
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:18:27.057464
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test conversion of bytes to human
    assert bytes_to_human(1000) == '1.00 KB'
    assert bytes_to_human(1000 ** 2) == '1.00 MB'
    assert bytes_to_human(1000 ** 3) == '1.00 GB'
    assert bytes_to_human(1000 ** 4) == '1.00 TB'
    assert bytes_to_human(1000 ** 5) == '1.00 PB'
    assert bytes_to_human(1000 ** 6) == '1.00 EB'
    assert bytes_to_human(1000 ** 7) == '1.00 ZB'
    assert bytes_to_human(1000 ** 8) == '1.00 YB'
    assert bytes_to_human(122345) == '122.35 KB'

    # Test conversion of bits to human
   

# Generated at 2022-06-22 22:18:38.243760
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'
    assert bytes_to_human(10, unit='b') == '10.00 bits'
    assert bytes_to_human(10, isbits=True) == '10.00 bits'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, unit='K') == '10.00 KB'
    assert bytes_to_human(10, isbits=True, unit='K') == '10240.00 bits'
    assert bytes_to_human(10, isbits=True, unit='b') == '10.00 bits'
    assert bytes_to_human(10, unit='Kb') == '10240.00 bits'

# Generated at 2022-06-22 22:18:46.474350
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:18:56.288377
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:19:00.799407
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['aBc']) == ['abc']
    assert lenient_lowercase([1, 'aBc']) == [1, 'abc']

# Generated at 2022-06-22 22:19:06.032309
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1mb') == 1
    assert human_to_bytes('1Gb') == 1 << 30
    assert human_to_bytes('1Gb', isbits=True) == 1 << 20
    assert human_to_bytes('1.5Gb', isbits=True) == 1.5 * 1 << 20
    assert human_to_bytes('0.5B') == 0.5
    assert human_to_bytes('0.5 B') == 0.5
    assert human_to_bytes('5.5 kB') == 5.5 * 1 << 10
   

# Generated at 2022-06-22 22:19:11.858204
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(2048, unit='kb') == '2.00 KB'
    assert bytes_to_human(2048, unit='k') == '2.00 KB'
    assert bytes_to_human(2048, isbits=True) == '16.00 Kb'
    assert bytes_to_human(0, isbits=True) == '0 bits'



# Generated at 2022-06-22 22:19:22.398729
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('0') == 0
    assert human_to_bytes('0b') == 0
    assert human_to_bytes('0B') == 0
    assert human_to_bytes('0bits') == 0
    assert human_to_bytes('0Bits') == 0
    assert human_to_bytes('0bIts') == 0
    assert human_to_bytes('0.0') == 0
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.1B') == 1
    assert human_to_bytes('1.1kB') == 1100
    assert human_to_bytes('1.1KB') == 1100

# Generated at 2022-06-22 22:19:31.989091
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import os
    import sys
    import unittest

    # setting exception to None, to avoid "TypeError: catching classes that do not inherit from BaseException is not allowed"
    # exception
    def exec_test_human_to_bytes(e=None):
        class TestHumanToBytes(unittest.TestCase):
            def test_human_to_bytes(self):
                human_to_bytes('999')
                human_to_bytes('1.1Kb')
                human_to_bytes('1.1Kb', isbits=True)
                human_to_bytes('1.1Kb', isbits=False)
                human_to_bytes('1.1K', isbits=False)
                human_to_bytes(1.1, 'K', isbits=False)

# Generated at 2022-06-22 22:19:40.446161
# Unit test for function bytes_to_human
def test_bytes_to_human():
    size = 1048576
    assert '1.00 MB' == bytes_to_human(size)
    assert '8.00 Mb' == bytes_to_human(size, isbits=True)
    assert '1.00 B' == bytes_to_human(size, unit='B')
    assert '1.00 KB' == bytes_to_human(size, unit='K')
    assert '0.01 MB' == bytes_to_human(size/100, unit='B')
    try:
        bytes_to_human(size, unit='Unexpected')
    except ValueError:
        pass



# Generated at 2022-06-22 22:19:44.043953
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'C', ['F', 'd'], 'b', 'E', 'a']) == ['a', 'c', ['f', 'd'], 'b', 'e', 'a']



# Generated at 2022-06-22 22:19:55.427554
# Unit test for function bytes_to_human
def test_bytes_to_human():
    bytes_list = [((1 << 10) - 1), (1 << 10), (1 << 10) + 1, (1 << 20) - 1, (1 << 20), (1 << 20) + 1,
                  (1 << 30) - 1, (1 << 30), (1 << 30) + 1, (1 << 40) - 1, (1 << 40), (1 << 40) + 1,
                  (1 << 50) - 1, (1 << 50), (1 << 50) + 1, (1 << 60) - 1, (1 << 60), (1 << 60) + 1,
                  (1 << 70) - 1, (1 << 70), (1 << 70) + 1, (1 << 80) - 1, (1 << 80), (1 << 80) + 1]

# Generated at 2022-06-22 22:20:08.055352
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Byte'
    assert bytes_to_human(2) == '2 Bytes'
    assert bytes_to_human(2, 'B') == '2 Bytes'
    assert bytes_to_human(1, 'B') == '1 Byte'
    assert bytes_to_human(1, 'b') == '8 bits'
    assert bytes_to_human(2, 'b') == '16 bits'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, 'K') == '1.00 KB'
    assert bytes_to_human(1024, 'Kb') == '8.00 Kb'

# Generated at 2022-06-22 22:20:18.080493
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1048576, unit='b') == '1.00 Mb'
    assert bytes_to_human(1048576 * 2, unit='b') == '2.00 Mb'
    assert bytes_to_human(1048576 * 3, unit='b') == '3.00 Mb'
    assert bytes_to_human(1048576 * 4, unit='b') == '4.00 Mb'
    assert bytes_to_human(1048576 * 5, unit='b') == '5.00 Mb'
    assert bytes_to_human(1048576 * 6, unit='b') == '6.00 Mb'

# Generated at 2022-06-22 22:20:22.196584
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['a', 1] == lenient_lowercase(['A', 1])
    assert ['a'] == lenient_lowercase(['A'])
    assert ['a'] == lenient_lowercase(['a'])
    assert ['a', 'a'] == lenient_lowercase(['A', 'a'])


# Generated at 2022-06-22 22:20:27.743370
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """
    Unit test for function bytes_to_human()
    """
    assert bytes_to_human(10, False) == '10 Bytes'
    assert bytes_to_human(10, True) == '10 bits'

    assert bytes_to_human(10, False, 'B') == '10 Bytes'
    assert bytes_to_human(10, True, 'B') == '10 bytes'

    assert bytes_to_human(1000, False) == '1000 Bytes'
    assert bytes_to_human(1000, True) == '1000 bits'

    assert bytes_to_human(1024, False) == '1 KBytes'
    assert bytes_to_human(1024, True) == '1 KBits'
    assert bytes_to_human(1024, False, 'B') == '1024 Bytes'
    assert bytes_

# Generated at 2022-06-22 22:20:35.766091
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['abc', 'ABC', 1, 2, [3, 4], {'a': 1, 'b': 2}]
    lowered_lst = lenient_lowercase(lst)
    assert lowered_lst[0] == 'abc'
    assert lowered_lst[1] == 'abc'
    assert lowered_lst[2] == 1
    assert lowered_lst[3] == 2
    assert lowered_lst[4] == [3, 4]
    assert lowered_lst[5] == {'a': 1, 'b': 2}

# Generated at 2022-06-22 22:20:44.613210
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:20:50.746908
# Unit test for function bytes_to_human
def test_bytes_to_human():

    def test_bytes_to_human_conversion(b, s):
        r = bytes_to_human(b)
        assert r == s, 'conversion failed: %d -> %s (expected: %s)' % (b, r, s)

    test_bytes_to_human_conversion(10, '10.00 Bytes')
    test_bytes_to_human_conversion(1000, '1000.00 Bytes')
    test_bytes_to_human_conversion(512 * 1024, '524288.00 Bytes')
    test_bytes_to_human_conversion(1024 * 1024, '1048576.00 Bytes')
    test_bytes_to_human_conversion(3 * 1024 * 1024, '3145728.00 Bytes')

# Generated at 2022-06-22 22:21:04.375995
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('5MB') == 5242880
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1 B') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes(100) == 100
    assert human_to_bytes(100.1) == 100
    assert human_to_bytes('100') == 100

# Generated at 2022-06-22 22:21:09.947973
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit="b") == '1.00 bits'
    assert bytes_to_human(2048, unit="B") == '2.00 KB'
    assert bytes_to_human(2048, unit="b") == '16.00 Kb'
    assert bytes_to_human(2048, isbits=True) == '16.00 Kb'
    assert bytes_to_human(2048, isbits=True, unit="b") == '16.00 Kb'
    assert bytes_to_human(2048, isbits=True, unit="B") == '16384.00 B'

# Generated at 2022-06-22 22:21:20.369939
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    class TestObject(object):
        def __str__(self):
            return 'Test'

    assert lenient_lowercase(['TEST', 'TEST', 'TEST']) == ['test', 'test', 'test']
    assert lenient_lowercase(['TEST', 'TEST', 'Test']) == ['test', 'test', 'Test']
    assert lenient_lowercase(['TeST', 'test', 'Test']) == ['test', 'test', 'Test']
    assert lenient_lowercase(['test', 'test', 'test']) == ['test', 'test', 'test']
    assert lenient_lowercase([TestObject(), TestObject(), TestObject()]) == [TestObject(), TestObject(), TestObject()]



# Generated at 2022-06-22 22:21:31.085260
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Byte'
    assert bytes_to_human(1023) == '1023.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1025) == '1.00 KB'
    assert bytes_to_human(10240) == '10.00 KB'
    assert bytes_to_human(1048575) == '1023.99 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1073741823) == '1023.99 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'
   

# Generated at 2022-06-22 22:21:42.533337
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1

    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == (1024 * 1024)
    assert human_to_bytes('1G') == (1024 * 1024 * 1024)
    assert human_to_bytes('1T') == (1024 * 1024 * 1024 * 1024)
    assert human_to_bytes('1P') == (1024 * 1024 * 1024 * 1024 * 1024)
    assert human_to_bytes('1E') == (1024 * 1024 * 1024 * 1024 * 1024 * 1024)
    assert human_to_bytes('1Z') == (1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024)

    assert human_to

# Generated at 2022-06-22 22:21:46.741667
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    x = [u'ABc', 1, 2, 3, 'CD', u'ef']
    y = lenient_lowercase(x)
    assert y == [u'abc', 1, 2, 3, u'cd', u'ef']



# Generated at 2022-06-22 22:21:56.329641
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10 * (1 << 20)
    assert human_to_bytes('10M', 'b') == 10 * (1 << 20) * 8
    assert human_to_bytes('10M', isbits=True) == 10 * (1 << 20) * 8
    assert human_to_bytes('10K') == 10 * (1 << 10)
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('1kb') == 1 << 10
    assert human_to_bytes('10kb') == 10 << 10
    assert human_to_bytes('1Mb') == 1 << 20
    assert human_to_bytes('10Mb') == 10 << 20
    assert human_to_bytes('1GB') == 1

# Generated at 2022-06-22 22:22:03.451469
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list1 = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    list2 = [1,2,3,4,5,6,7,8,9]

    assert list1 == lenient_lowercase([x.upper() for x in list1])
    assert list2 == lenient_lowercase(list2)
    assert list1 + list2 == lenient_lowercase([x.upper() for x in list1] + list2)