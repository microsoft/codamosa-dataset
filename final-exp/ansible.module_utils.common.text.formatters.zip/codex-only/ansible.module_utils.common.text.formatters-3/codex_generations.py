

# Generated at 2022-06-22 22:12:08.735844
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import random
    import string
    import unittest

    # Prepare a list of random strings

# Generated at 2022-06-22 22:12:17.115888
# Unit test for function bytes_to_human
def test_bytes_to_human():
    num = 511
    assert bytes_to_human(num, isbits=False, unit=None) == '511 Bytes'
    assert bytes_to_human(num, isbits=False, unit='Bytes') == '511 Bytes'
    assert bytes_to_human(num, isbits=False, unit='B') == '511 Bytes'
    assert bytes_to_human(num, isbits=False, unit='b') == '511 Bytes'

    num = 1024
    assert bytes_to_human(num, isbits=False, unit=None) == '1.00 KB'
    assert bytes_to_human(num, isbits=False, unit='Bytes') == '1.00 KB'
    assert bytes_to_human(num, isbits=False, unit='B') == '1.00 KB'
    assert bytes

# Generated at 2022-06-22 22:12:27.755681
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(4242424242) == "3.95 GB"
    assert bytes_to_human(4242424242, unit='k') == "4040050.39 KB"
    assert bytes_to_human(4242424242, unit='K') == "4040050.39 KB"
    assert bytes_to_human(4242424242, unit='M') == "3949.68 MB"
    assert bytes_to_human(4242424242, unit='G') == "3.82 GB"
    assert bytes_to_human(42) == "42 Bytes"
    assert bytes_to_human(42, unit='B') == "42 Bytes"
    assert bytes_to_human(42, unit='b') == "336 bits"

# Generated at 2022-06-22 22:12:29.866193
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['foo', 1, 'bar']) == ['foo', 1, 'bar']

# Generated at 2022-06-22 22:12:39.395460
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """
    This test data consists of list whose every element is
    either a string or non string type
    """
    _input_data = [
        ['Elem', 'elem', 'ELEM', 1, 2, '1', '2', '1+2'],
        ['Elem', 'elem', 'ELEM'],
        ['ELEM', 'elem', 'ELEM', 1, 2, '1', '2', '1+2'],
    ]

# Generated at 2022-06-22 22:12:47.803390
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Create an object that is not a string
    class NotStringy(object):
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return str(self.value)

        def __repr__(self):
            return "NotStringy(%s)" % self.value

        __unicode__ = __repr__


# Generated at 2022-06-22 22:12:57.599554
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest


# Generated at 2022-06-22 22:13:02.944677
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list1 = [1, 2, 'Abc']
    list2 = [1, 2, 'abc']
    list3 = lenient_lowercase(list1)
    if list3 == list2:
        print("Test Case 1: Passed")
    else:
        print("Test Case 1: Failed")

    list1 = [1, 2, 3, 'Abc']
    list2 = [1, 2, 3, 'Abc']
    list3 = lenient_lowercase(list1)
    if list3 == list2:
        print("Test Case 2: Passed")
    else:
        print("Test Case 2: Failed")



# Generated at 2022-06-22 22:13:12.015107
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:13:18.081074
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['1', '2', '3']) == ['1', '2', '3']
    assert lenient_lowercase(['ONE', 'TWO', 'Three']) == ['one', 'two', 'Three']
    assert lenient_lowercase(['1', '2', 'test', '3']) == ['1', '2', 'test', '3']


# Unit tests for function human_to_bytes

# Generated at 2022-06-22 22:13:25.763970
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Test the function 'human_to_bytes' to check if it works '''
    # Convert to bytes
    val = human_to_bytes('10m')
    assert val == 10485760, 'Error in human_to_bytes() for 10m'
    val = human_to_bytes('10M')
    assert val == 10485760, 'Error in human_to_bytes() for 10M'
    val = human_to_bytes('10Mb')
    assert val == 13107200, 'Error in human_to_bytes() for 10Mb'
    val = human_to_bytes('10MB')
    assert val == 10485760, 'Error in human_to_bytes() for 10MB'
    val = human_to_bytes('10MB', default_unit='M')
    assert val == 10485760

# Generated at 2022-06-22 22:13:35.666906
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:13:43.347485
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 EB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 ZB'

# Generated at 2022-06-22 22:13:55.791830
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:13:59.443018
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_of_values = ['A','b','C','1.1','T',1234]
    list_of_values_lower = ['a','b','c','1.1','t',1234]
    assert lenient_lowercase(list_of_values) == list_of_values_lower


# Generated at 2022-06-22 22:14:11.464368
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1000') == 1000
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1 m') == 1048576
    assert human_to_bytes('1.5GB') == 1572864000
    assert human_to_bytes('2kB') == 2048
    assert human_to_bytes('2 kB') == 2048
    assert human_to_bytes('2KB') == 2048
    assert human_to_bytes('2.5MB') == 2621440
    assert human_to_bytes('1.1mb') == 1153433

# Generated at 2022-06-22 22:14:18.996409
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['a', 'B', 'c', 1, 2, 3]
    lc_lst = lenient_lowercase(lst)
    assert lc_lst == ['a', 'b', 'c', 1, 2, 3]



# Generated at 2022-06-22 22:14:23.103048
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['A']) == ['a']
    assert lenient_lowercase(['A', 1]) == ['a', 1]
    assert lenient_lowercase([['A'], 1]) == [['A'], 1]

# Generated at 2022-06-22 22:14:26.734700
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_data = [
        [['FOO', 'fOO', 'foO', 'foo', None], ['foo', 'foo', 'foo', 'foo', None]]
    ]

    for data in test_data:
        assert lenient_lowercase(data[0]) == data[1]


# Generated at 2022-06-22 22:14:32.328828
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase(['A', 2, 'C']) == ['a', 2, 'c']


# Generated at 2022-06-22 22:14:38.996970
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 Bytes'
    assert bytes_to_human(1024, unit='b') == '1024.00 bits'
    assert bytes_to_human(1024, unit='kb') == '1.00 Kilobytes'
    assert bytes_to_human(1024, unit='kb', isbits=True) == '1024.00 Kbits'
    assert bytes_to_human(1024, unit='MB', isbits=True) == '0.00 Mbits'


# Generated at 2022-06-22 22:14:50.417655
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:14:57.324328
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert (human_to_bytes('10M', 'B') == 10485760)
    assert (human_to_bytes('10M') == 10485760)
    assert (human_to_bytes('11.5M') == 11995709)
    assert (human_to_bytes('10.5M', 'M') == 10.5)
    assert (human_to_bytes('10b') == 1)
    assert (human_to_bytes('10B') == 10)
    assert (human_to_bytes('10b', isbits=True) == 1)
    assert (human_to_bytes('10B', isbits=True) == 80)



# Generated at 2022-06-22 22:15:01.843619
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert (lenient_lowercase(['a', 'B', 'Cc', 'DdDd', 2]) == ['a', 'b', 'cc', 'dddd', 2])



# Generated at 2022-06-22 22:15:12.142044
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(2) == '2 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(2 * 1024 * 1024) == '2.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(2 * 1024 * 1024 * 1024) == '2.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'

# Generated at 2022-06-22 22:15:20.119190
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, True) == '10.00 bits'
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'
    assert bytes_to_human(10, unit='b') == '10.00 bits'
    assert bytes_to_human(10, unit='K') == '0.01 kBytes'
    assert bytes_to_human(10, unit='Kb') == '0.01 kbits'
    assert bytes_to_human(10, unit='kB') == '10.00 Bytes'
    assert bytes_to_human(10, unit='kb') == '10.00 bits'
    assert bytes_to_human(1000) == '1000.00 Bytes'
    assert bytes_

# Generated at 2022-06-22 22:15:26.730837
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    from nose.tools import assert_equal
    assert_equal(lenient_lowercase([]), [])
    assert_equal(lenient_lowercase(['a', 'b']), ['a', 'b'])
    assert_equal(lenient_lowercase(['a', 'b', 'c', 1, 2, None]), ['a', 'b', 'c', 1, 2, None])
    assert_equal(lenient_lowercase(['A', 'B', 'C', 1, 2, None]), ['a', 'b', 'c', 1, 2, None])

# Generated at 2022-06-22 22:15:38.042331
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """functional unit test for command itruncate"""
    # test cases, each case consists of 4 elements:
    #   source, default_unit, isbits, expected result

# Generated at 2022-06-22 22:15:41.036850
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
  assert lenient_lowercase(['Ab', 2, 'c']) == ['ab', 2, 'c']



# Generated at 2022-06-22 22:15:50.282427
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Unit test for function human_to_bytes
    """
    isbits = False
    assert human_to_bytes('10') == int(10)
    assert human_to_bytes('10M') == int(10 * 1024 * 1024)
    assert human_to_bytes('1.5M') == int(1.5 * 1024 * 1024)
    assert human_to_bytes('1K') == int(1024)
    assert human_to_bytes('1G') == int(1 * 1024 * 1024 * 1024)
    assert human_to_bytes('2.5Z', isbits=isbits) == int(2.5 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024)
    assert human_to_bytes('1Mb', isbits=isbits) == int(1 * 1024 * 1024)

# Generated at 2022-06-22 22:15:54.139335
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(
        ['Ansible', 'Project', 1, 'aNSibleProject001/', (1, )]
    ) == ['ansible', 'project', 1, 'ansibleproject001/', (1, )]



# Generated at 2022-06-22 22:15:58.031146
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 1.0, 'zero']) == [1, 1.0, 'zero']
    assert lenient_lowercase(['O', 'ONE', 'ONe']) == ['o', 'ONE', 'ONe']



# Generated at 2022-06-22 22:16:10.813273
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:16:17.429817
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Simple case
    assert bytes_to_human(1 << 20) == '1.00 MB'

    # With minimum number of decimal digits
    assert bytes_to_human((1 << 10) + 1, unit='K') == '1.0 KB'

    # Precision test for values between range limits
    assert bytes_to_human((1 << 10) + 1) == '1.00 KB'

    # Test for values between unit range limit and next one
    assert bytes_to_human(((1 << 20) + 1), unit='K') == '1025.00 KB'

    # Test for values below limit 0.01B
    assert bytes_to_human(((1 << 10) - 1), unit='b') == '0.98 b'

    # Function should ignore unit case

# Generated at 2022-06-22 22:16:28.340420
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """Test bytes_to_human function"""

# Generated at 2022-06-22 22:16:34.133770
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert (human_to_bytes('10M') == 10485760)
    assert (human_to_bytes('10', 'M') == 10485760)
    assert (human_to_bytes('10.0M') == 10485760)
    assert (human_to_bytes('10.0', 'M') == 10485760)
    assert (human_to_bytes('10.0MB') == 10485760)
    assert (human_to_bytes('10.0', 'MB') == 10485760)

    assert (human_to_bytes('10k') == 10240)
    assert (human_to_bytes('10', 'k') == 10240)
    assert (human_to_bytes('10.0k') == 10240)

# Generated at 2022-06-22 22:16:43.183884
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Valid inputs
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes(2048, 'KB') == 2097152
    assert human_to_bytes('1Mb', isbits=True) == 8 * 1048576
    assert human_to_bytes(64, 'Gb') == 1.073741824e+10
    assert human_to_bytes(256, 'GB') == 268435456
    assert human_to_bytes('1b', 'KB', isbits=True) == 128
    assert human_to_bytes(128, 'b', 'K') == 1.048576
    assert human_to_bytes('1Kb', 'b', 'M', isbits=True) == 8388608

# Generated at 2022-06-22 22:16:49.957753
# Unit test for function human_to_bytes
def test_human_to_bytes():
    with pytest.raises(TypeError) as excinfo:
        assert human_to_bytes(123) == 123

    assert 'not a string' in str(excinfo.value)
    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('2097152') == 2097152
    assert human_to_bytes('2M', 'G') == 2097152000
    assert human_to_bytes('2.2M') == 2252800
    assert human_to_bytes('2.2.2M') == 0
    assert human_to_bytes('2.2M', 'B') == 2252800
    assert human_to_bytes('2.2M', 'K') == 2200
    assert human_to_bytes('2.2M', 'T') == 2
    assert human_to

# Generated at 2022-06-22 22:17:00.004783
# Unit test for function bytes_to_human
def test_bytes_to_human():
    test_values = [
        (1024, '1.00 KBytes'),
        (2048, '2.00 KBytes'),
        (8 * 1024, '8.00 KBytes'),
        (42 * 1024 * 1024, '42.00 MBytes'),
        (42 * 1024 * 1024 + 1, '42.00 MBytes'),
        (42 * 1024 * 1024 + 512, '42.00 MBytes'),
        (42 * 1024 * 1024 + 513, '43.00 MBytes')]

    for size, expected in test_values:
        result = bytes_to_human(size)
        assert expected == result, "expect %s, got %s" % (expected, result)
    print("Test bytes_to_human() passed")


# Generated at 2022-06-22 22:17:03.584309
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([0, 'A', 'Ba', 2, 'Ca', 'Da']) == [0, 'a', 'ba', 2, 'ca', 'da']

# Generated at 2022-06-22 22:17:11.155415
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert(bytes_to_human(1)) == '1.00 Bytes'
    assert(bytes_to_human(1, isbits=True)) == '1.00 bits'
    assert(bytes_to_human(1024, unit='b')) == '1.00 Kbits'
    assert(bytes_to_human(1024, unit='B')) == '1.00 KB'
    assert(bytes_to_human(1048576, unit='B')) == '1.00 MB'
    assert(bytes_to_human(1048576, unit='b')) == '1.00 Mbits'
    assert(bytes_to_human(1099511627776, unit='B')) == '1.00 TB'

# Generated at 2022-06-22 22:17:21.408188
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048576, unit='M') == '1.00 M'
    assert bytes_to_human(1048576, unit='m') == '1.00 m'
    assert bytes_to_human(1048576, unit='kb') == '1024.00 kb'
    assert bytes_to_human(1048576, unit='kb', isbits=True) == '8388608.00 kb'
    assert bytes_to_human(0) == '0.00 B'
    assert bytes_to_human(0, unit='m') == '0.00 m'
    assert bytes_to_human(0, unit='m', isbits=True) == '0.00 m'

# Generated at 2022-06-22 22:17:31.318613
# Unit test for function bytes_to_human
def test_bytes_to_human():
    expected = {
        (1, 'bytes', None): '1 Bytes',
        (1, 'bytes', 'B'): '1 Bytes',
        (2, 'bytes', None): '2 Bytes',
        (2, 'bytes', 'B'): '2 Bytes',
        (1, 'bits', None): '1 bits',
        (1, 'bits', 'b'): '1 bits',
        (2, 'bits', None): '2 bits',
        (2, 'bits', 'b'): '2 bits',
    }
    for args, result in expected.items():
        assert bytes_to_human(*args) == result


# Generated at 2022-06-22 22:17:36.800516
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['abc']) == ['abc']
    assert lenient_lowercase(['aBC']) == ['abc']
    assert lenient_lowercase(['aBc', 1, 2, []]) == ['abc', 1, 2, []]



# Generated at 2022-06-22 22:17:45.265879
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # test with a list of strings, we should have all lowercase
    assert lenient_lowercase(['Test1', 'Test2', 'Test3']) == ['test1', 'test2', 'test3']

    # test with a list of strings and numbers, we should have the numbers in the list
    assert lenient_lowercase(['Test1', 'Test2', 1, 2, 3]) == ['test1', 'test2', 1, 2, 3]



# Generated at 2022-06-22 22:17:56.189550
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1000) == '1000 Bytes'
    assert bytes_to_human(1000, unit='b') == '1000 Bits'
    assert bytes_to_human(1000, isbits=True) == '1000 bits'
    assert bytes_to_human(1000, isbits=True, unit='b') == '1000 bits'
    assert bytes_to_human(1000, unit='K') == '0.98 Kilobytes'
    assert bytes_to_human(1000, unit='B') == '1000 Bytes'
    assert bytes_to_human(1024, unit='B') == '1024 Bytes'
    assert bytes_to_human(1024, unit='B') == '1024 Bytes'

    assert bytes_to_human(1024, unit='b') == '8192 Bits'

# Generated at 2022-06-22 22:17:59.149017
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(2097152) == '2.00 MB'


# Generated at 2022-06-22 22:18:03.381283
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert(bytes_to_human(100100100) == '100.10 MB')
    assert (bytes_to_human(100100100, isbits=True) == '800.80 Mb')
    assert (bytes_to_human(0, isbits=True) == '0 bits')



# Generated at 2022-06-22 22:18:15.752708
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """ Validate that human_to_bytes converts properly
    """
    assert human_to_bytes("0") == 0
    assert human_to_bytes("0b") == 0
    assert human_to_bytes("0B") == 0
    assert human_to_bytes("1") == 1
    assert human_to_bytes("1b") == 1
    assert human_to_bytes("1B") == 1
    assert human_to_bytes("1.5b") == 1
    assert human_to_bytes("1.5B") == 1
    assert human_to_bytes("1K") == 1024
    assert human_to_bytes("1M") == 1024 * 1024
    assert human_to_bytes("1G") == 1024 * 1024 * 1024
    assert human_to_bytes("1T") == 1024 * 1024 * 1024 * 1024
   

# Generated at 2022-06-22 22:18:19.552325
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B']) == ['a', 'b']
    assert lenient_lowercase(['A', 1, 'B', None]) == ['a', 1, 'b', None]

# Generated at 2022-06-22 22:18:23.275517
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B']) == ['a', 'b']
    assert lenient_lowercase(['a', 'b']) == ['a', 'b']
    assert lenient_lowercase(['a', 1]) == ['a', 1]
    assert lenient_lowercase([1, 'b']) == [1, 'b']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-22 22:18:31.458723
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1023).startswith("1.00 ")
    assert bytes_to_human(1023, unit='B') == "1023.00 Bytes"
    assert bytes_to_human(1023, unit='K').startswith("1.00 ")
    assert bytes_to_human(1023, unit='K').endswith(" KB")
    assert bytes_to_human(1023, unit='Kb') == "1023.00 Kbits"
    assert bytes_to_human(1023, unit='Kb').endswith(" Kbits")
    assert bytes_to_human(1023.23, unit='B') == "1023.23 Bytes"
    assert bytes_to_human(1023.23, unit='K') == "0.98 KB"
    assert bytes_

# Generated at 2022-06-22 22:18:42.773925
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1023, unit='B') == '1023 B'
    assert bytes_to_human(1023, unit='B') == '1023 B'
    assert bytes_to_human(1023, unit='b') == '1023 b'
    assert bytes_to_human(1023, unit='b', isbits=True) == '1023 b'

    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, unit='K') == '1.00 KB'
    assert bytes_to_human(1024, unit='b') == '1.00 KBb'

# Generated at 2022-06-22 22:18:53.026986
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(2) == '2 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human(1099511627776) == '1.00 TB'
    assert bytes_to_human(1125899906842624) == '1.00 PB'
    assert bytes_to_human(1152921504606846976) == '1.00 EB'

# Generated at 2022-06-22 22:18:54.479699
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    print(lenient_lowercase(['FOO', 'foo', 'BAR', 42]))


# Generated at 2022-06-22 22:19:07.282601
# Unit test for function bytes_to_human
def test_bytes_to_human():
    if bytes_to_human(0, unit='b') != '0 bits':
        raise ValueError("bytes_to_human(0, unit='b') expected '0 bits', got: '%s'" % bytes_to_human(0, unit='b'))
    if bytes_to_human(1, unit='b') != '1 bit':
        raise ValueError("bytes_to_human(1, unit='b') expected '1 bit', got: '%s'" % bytes_to_human(1, unit='b'))
    if bytes_to_human(1) != '1 Byte':
        raise ValueError("bytes_to_human(1) expected '1 Byte', got: '%s'" % bytes_to_human(1))
    if bytes_to_human(1, unit='KB') != '1000 Bytes':
        raise

# Generated at 2022-06-22 22:19:10.890220
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 1, 2]) == ['a', 'b', 1, 2]
    assert lenient_lowercase(['a', [1, 2]]) == ['a', [1, 2]]
    assert lenient_lowercase([]) == []



# Generated at 2022-06-22 22:19:20.210131
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Unit tests for function lenient_lowercase"""

    # Empty
    assert lenient_lowercase([]) == []

    # Single element
    assert lenient_lowercase(["HeLlo"]) == ["hello"]

    # Multiple elements
    assert lenient_lowercase(["HeLlo", "wOrLd"]) == ["hello", "world"]

    # Non-string
    assert lenient_lowercase(["HeLlo", 10]) == ["hello", 10]
    assert lenient_lowercase([["HeLlo"], 10]) == [["HeLlo"], 10]



# Generated at 2022-06-22 22:19:31.118697
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print('Test bytes_to_human')

# Generated at 2022-06-22 22:19:42.794453
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(12345) == '12.06 KB'
    assert bytes_to_human(1234567) == '1.18 MB'
    assert bytes_to_human(123456789) == '118.61 MB'
    assert bytes_to_human(1234567890) == '1.15 GB'
    assert bytes_to_human(1234567890123) == '1.10 TB'
    assert bytes_to_human(1234567890123456) == '1.05 PB'
    assert bytes_to_human(1234567890123456789) == '1.01 EB'
    assert bytes_to_human(1234567890123456789012) == '9.77 ZB'

# Generated at 2022-06-22 22:19:51.842710
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert '1.00 Byte' == bytes_to_human(human_to_bytes('1B'))
    assert '1.00 KByte' == bytes_to_human(human_to_bytes('1KB'))
    assert '1.00 MByte' == bytes_to_human(human_to_bytes('1MB'))
    assert '1.00 GByte' == bytes_to_human(human_to_bytes('1GB'))
    assert '1.00 TByte' == bytes_to_human(human_to_bytes('1TB'))

    assert '1.00 bit' == bytes_to_human(human_to_bytes('1b'), isbits=True)
    assert '1.00 Kbit' == bytes_to_human(human_to_bytes('1Kb'), isbits=True)

# Generated at 2022-06-22 22:20:04.283185
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Byte'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human(1099511627776) == '1.00 TB'
    assert bytes_to_human(1 << 40) == '1.00 TB'
    assert bytes_to_human(1 << 50) == '1.00 PB'
    assert bytes_to_human(1 << 60) == '1.00 EB'
    assert bytes_to_human(1 << 70) == '1.00 ZB'
    # Test bits

# Generated at 2022-06-22 22:20:15.730806
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' The function test_human_to_bytes tests the following input
    strings:
    1. The string representation of an integer number;
    2. The string representation of an integer number with
    suffix (ex 'KB'/'MB' - lowercase and uppercase)
    3. The string representation of an float number with
    suffix (ex 'KB'/'MB' - lowercase and uppercase)
    4. The string representation of an integer number with
    prefix and suffix (ex 'MB'/'KB' - lowercase and uppercase)
    5. The string representation of an integer number with
    prefix and suffix - the mix of uppercase and lowercase letters (ex 'MB'/'KB' - lowercase and uppercase)

    The expected returned value is an integer equal to the number of bytes
    '''

# Generated at 2022-06-22 22:20:23.986088
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:20:34.149134
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import assert_equal, assert_raises
    assert_equal(human_to_bytes('1024'), 1024)
    assert_equal(human_to_bytes('1024', isbits=True), 1024)
    assert_equal(human_to_bytes('1024 B'), 1024)
    assert_equal(human_to_bytes('1024 KB'), 1024 * 1024)
    assert_equal(human_to_bytes('1024 Kb'), 1024 * 1024)
    assert_equal(human_to_bytes('1024 mb'), 1024 * 1024 * 1024)
    assert_equal(human_to_bytes('1024 Mb', isbits=True), 1024 * 1024 * 1024)
    assert_equal(human_to_bytes('5M'), 1024 * 1024 * 5)

# Generated at 2022-06-22 22:20:37.445889
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input = [None, 'Lower', 'UPPER', 'MiXeD', '123']
    output = ['none', 'lower', 'upper', 'mixed', '123']
    assert lenient_lowercase(input) == output



# Generated at 2022-06-22 22:20:45.162447
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:20:50.716259
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Abc', u'dEf', 1, []]) == ['abc', u'def', 1, []]
    # Unicode strings are left as-is
    assert lenient_lowercase([u'Abc', u'абв']) == [u'Abc', u'абв']

# Generated at 2022-06-22 22:21:01.963020
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'Mb') == 13107200
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10Mb') == 13107200
    assert human_to_bytes('10MBb') == 13107200
    assert human_to_bytes('10Mb', isbits=True) == 13107200
    assert human_to_bytes(10) == 10

# Generated at 2022-06-22 22:21:12.125532
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert (bytes_to_human(0) == '0 Bytes')
    assert (bytes_to_human(1) == '1 Bytes')
    assert (bytes_to_human(1024) == '1.00 KB')
    assert (bytes_to_human(1048576) == '1.00 MB')
    assert (bytes_to_human(1073741824) == '1.00 GB')
    assert (bytes_to_human(1099511627776) == '1.00 TB')
    assert (bytes_to_human(1125899906842624) == '1.00 PB')
    assert (bytes_to_human(1152921504606846976) == '1.00 EB')

# Generated at 2022-06-22 22:21:21.573779
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Simple test
    assert bytes_to_human(1024, unit='MB') == '0.00 MB'
    # Test if None
    assert bytes_to_human(None, unit='MB') is None
    # Test if MB
    assert bytes_to_human(1024 * 1024, unit='MB') == '1.00 MB'
    assert bytes_to_human(1204 * 1024, unit='MB') == '1.17 MB'
    assert bytes_to_human(17920 * 1024, unit='MB') == '17.32 MB'
    # Test if GB
    assert bytes_to_human(1024 * 1024 * 1024, unit='GB') == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 2, unit='GB') == '2.00 GB'

# Generated at 2022-06-22 22:21:31.703512
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:21:34.771266
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    sample_data = ['FoO', 'bAr', ['FoO', 1, 'bAr'], ('FoO', 1, 'bAr')]
    expected_result = ['foo', 'bar', ['foo', 1, 'bar'], ('foo', 1, 'bar')]

    for data, expected in zip(sample_data, expected_result):
        assert lenient_lowercase(data) == expected


# Generated at 2022-06-22 22:21:40.746403
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert '10 Bytes' == bytes_to_human(10)
    assert '10 bits' == bytes_to_human(10, isbits=True)
    assert '10 KB' == bytes_to_human(10240)
    assert '10 Kb' == bytes_to_human(10240, isbits=True)
    assert '10.20 GB' == bytes_to_human(10*1024*1024*1024+2*1024*1024)
    assert '10.20 Gb' == bytes_to_human(10*1024*1024*1024+2*1024*1024, isbits=True)
    assert '10.20 TB' == bytes_to_human(1024*1024*1024*1024*10+2*1024*1024*1024)

# Generated at 2022-06-22 22:21:52.685766
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes(10, 'MB') == 10485760
    assert human_to_bytes(1000, 'Mb', isbits=True) == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1Mb') == 1048576  # default unit is byte
    assert human_to_bytes('1b') == 1  # default unit is byte
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1') == 1

    # wrong entries
    try:
        human_to_bytes('1024')
    except ValueError:
        pass

# Generated at 2022-06-22 22:22:02.012073
# Unit test for function human_to_bytes