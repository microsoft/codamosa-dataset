

# Generated at 2022-06-22 22:12:07.918243
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 6]) == ['a', 6]
    assert lenient_lowercase([u'a', u'b', u'c']) == ['a', 'b', 'c']

# Unit tests for function human_to_bytes

# Generated at 2022-06-22 22:12:16.735874
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576) == '1.00 MBytes'
    assert bytes_to_human(1048576, unit='K') == '1024.00 KBytes'
    assert bytes_to_human(1048576, unit='M') == '1.00 MBytes'
    assert bytes_to_human(1048576, unit='G') == '0.00 GBytes'
    assert bytes_to_human(1048576, unit='b') == '8388608.00 bits'
    assert bytes_to_human(1048576, unit='B') == '1048576.00 Bytes'
    assert bytes_to_human(1048576, isbits=True) == '8388608.00 bits'

# Generated at 2022-06-22 22:12:24.063121
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 EB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 ZB'

# Generated at 2022-06-22 22:12:30.510356
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1.5

    assert human_to_bytes('1 Mb') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1 Mb', isbits=True) == 8388608
    assert human_to_bytes('1Mb', isbits=True) == 8388608
    assert human_to_bytes('1 mb', isbits=True) == 8388608
    assert human_to_bytes('1mb', isbits=True) == 8388608
    assert human_to_bytes('1 MB', isbits=True) == 8388608
    assert human_to_bytes('1M b', isbits=True) == 8388608

# Generated at 2022-06-22 22:12:42.309710
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # list of dictionary
    l1 = [{'a': 1}, {'b': 2}, {'c': 3}]
    l1_expected = [{'a': 1}, {'b': 2}, {'c': 3}]

    # list of string
    l2 = ['a', 'b', 'c']
    l2_expected = ['a', 'b', 'c']

    # list of dictionary and string
    l3 = [{'a': 1}, 'b', 'c']
    l3_expected = [{'a': 1}, 'b', 'c']

    # list of dictionary and integer
    l4 = [{'a': 1}, 2, 'c']
    l4_expected = [{'a': 1}, 2, 'c']

    # list of empty dict
    l5 = [{}]

# Generated at 2022-06-22 22:12:54.115581
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:13:01.754026
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:13:12.062753
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Non-bytes (B) tests
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1 MB') == 1048576
    assert human_to_bytes('1mb') == 1048576
    assert human_to_bytes('1 Mb') == 1048576
    assert human_to_bytes('1.5MB') == 1572864
    assert human_to_bytes('1.5Mb') == 1572864
    assert human_to_bytes('1.5 Mb') == 1572864
    assert human_to_bytes('.5MB') == 524288
    assert human_to_bytes('.5Mb') == 524288
    assert human_to_bytes('.5 Mb') == 524288
    assert human_to_bytes('0') == 0

# Generated at 2022-06-22 22:13:18.542192
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from collections import namedtuple
    from pytest import fixture, raises
    from builtins import ValueError


# Generated at 2022-06-22 22:13:20.118963
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['One', 2, 'TRE']) == ['one', 2, 'tre']



# Generated at 2022-06-22 22:13:31.463801
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []

    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']

    assert lenient_lowercase(['a', '1', 'c']) == ['a', '1', 'c']
    assert lenient_lowercase(['a', '1b', 'c']) == ['a', '1b', 'c']


# Generated at 2022-06-22 22:13:40.819324
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1.1) == '1.10 Bytes'
    assert bytes_to_human(1, isbits=True) == '1.00 bits'
    assert bytes_to_human(1.1, isbits=True) == '1.10 bits'
    assert bytes_to_human(100.1) == '100.10 Bytes'
    assert bytes_to_human(1000.1) == '1000.10 Bytes'
    assert bytes_to_human(10000.1) == '10000.10 Bytes'
    assert bytes_to_human(100000.1) == '100000.10 Bytes'
    assert bytes_to_human(1000000.1) == '1000000.10 Bytes'

# Generated at 2022-06-22 22:13:50.932244
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test list with strings (should be converted)
    test_list = ['Foo', 'BAr']
    expected = ['foo', 'bar']
    result = lenient_lowercase(test_list)
    assert expected == result, "Test failed: Got %s, expected %s" % (result, expected)

    # Test list with ints (Should not be converted)
    test_list = [1, 2, 3, 4]
    expected = [1, 2, 3, 4]
    result = lenient_lowercase(test_list)
    assert expected == result, "Test failed: Got %s, expected %s" % (result, expected)

    # Test list with string and int (Strings should be converted and ints should not be converted)

# Generated at 2022-06-22 22:13:59.802406
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2 * (1 << 10)
    assert human_to_bytes(2, 'K') == human_to_bytes('2K')
    assert human_to_bytes('2Kb', isbits=True) == human_to_bytes('2K', isbits=True)
    assert human_to_bytes(2, 'Kb', isbits=True) == human_to_bytes(2, 'K', isbits=True)
    assert human_to_bytes(2) == 2
    assert human_to_bytes(2.0) == 2

    # Test case for `raw_number` param
    assert human_to_bytes(2, isbits=True) == 2
    assert human_to_bytes(2.0, isbits=True) == 2
    assert human_to_bytes

# Generated at 2022-06-22 22:14:11.652039
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(3) == '3.00 Bytes'
    assert bytes_to_human(3.0) == '3.00 Bytes'
    assert bytes_to_human(3.14) == '3.14 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024.0) == '1.00 KB'
    assert bytes_to_human(1024.14) == '1.00 KB'
    assert bytes_to_human(1024+0.14) == '1.00 KB'
    assert bytes_to_human(1024*1024) == '1.00 MB'
    assert bytes_to_human(1024*1024*1024) == '1.00 GB'
    assert bytes_to_human(1024*1024*1024*1024)

# Generated at 2022-06-22 22:14:23.951019
# Unit test for function human_to_bytes
def test_human_to_bytes():
    raw_inputs = {
        '2K': 2 * SIZE_RANGES['K'],
        '2.5K': 2.5 * SIZE_RANGES['K'],
        '1K': 1 * SIZE_RANGES['K'],
        '2Kb': 2 * SIZE_RANGES['K'],
        '1Mb': 1 * SIZE_RANGES['M'],
        '2M': 2 * SIZE_RANGES['M'],
        '2.5M': 2.5 * SIZE_RANGES['M']}


# Generated at 2022-06-22 22:14:35.816689
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test = [
        'abc',
        'ABC',
        ['aBc', 'Man', 'V1.0'],
        [1, 2, 3],
        {'a': 'b', 'c': 'd'},
        {'Man': 'Rat', 'Foo': 'Bar'},
    ]

    answer = [
        'abc',
        'abc',
        ['abc', 'man', 'v1.0'],
        [1, 2, 3],
        {'a': 'b', 'c': 'd'},
        {'man': 'Rat', 'foo': 'Bar'},
    ]

    for t, a in zip(test, answer):
        assert lenient_lowercase(t) == a

# Generated at 2022-06-22 22:14:46.957848
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:14:51.546278
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B', isbits=True) == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0') == 1

    # Test Kibi
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1k') == 1024
    assert human_to_

# Generated at 2022-06-22 22:15:02.763937
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:15:07.715275
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10) == 10
    assert human_to_bytes(10, unit='M') == 10485760
    assert human_to_bytes(10, unit='b') == 1.25
    assert human_to_bytes(10, unit='b', isbits=True) == 10

    assert human_to_bytes('10') == 10
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Kb') == 12800
    assert human_to_bytes('10kb') == 12800
    assert human_to_bytes('10Kb', isbits=True) == 10240
    assert human_to_bytes('10Mb', isbits=True) == 10485760


# Generated at 2022-06-22 22:15:12.730810
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 'a', 'B']) == [1, 2, 'a', 'B']
    assert lenient_lowercase(['a', 'B', 1, 2]) == ['a', 'B', 1, 2]
    assert lenient_lowercase(['a', 'B', '1', '2']) == ['a', 'B', '1', '2']
    assert lenient_lowercase(1) is 1
    assert lenient_lowercase('a') == 'a'

# Generated at 2022-06-22 22:15:15.555712
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'Bc', 1, None, [], 'abc', '1', '', b'abc']) == ['a', 'bc', 1, None, [], 'abc', '1', '', 'abc']

# Generated at 2022-06-22 22:15:25.695267
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1.5Mb') == 1572864)
    assert(human_to_bytes('1.5Mb', isbits=True) == 1572864)
    assert(human_to_bytes('1.5MB') == 1572864)
    assert(human_to_bytes('1.5M') == 1572864)
    assert(human_to_bytes('1.5m') == 1572864)
    assert(human_to_bytes('1.5g') == 157286400)
    assert(human_to_bytes('1.5k') == 1500)
    assert(human_to_bytes('1.5') == 1)
    assert(human_to_bytes('1.5', 'M') == 1572864)

# Generated at 2022-06-22 22:15:37.463335
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1B', 'B') == 1
    assert human_to_bytes('1', 'B') == 1
    assert human_to_bytes('1', 'b') == 1
    assert human_to_bytes('1', 'B', isbits=True) == 1
    assert human_to_bytes('1', 'b', isbits=True) == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1b', 'B') == 1
    assert human_to_bytes('1b', 'b') == 1
    assert human_to_bytes('1b', isbits=True) == 1

# Generated at 2022-06-22 22:15:42.794688
# Unit test for function human_to_bytes
def test_human_to_bytes():
    bytes_values = [
        ('2K', 2048),
        ('2M', 2097152),
        ('2G', 2147483648),
        ('2048', 2048),
    ]
    for human_input, expected_bytes in bytes_values:
        assert human_to_bytes(human_input) == expected_bytes



# Generated at 2022-06-22 22:15:51.384763
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('123') == 123)
    assert(human_to_bytes('1234567') == 1234567)
    assert(human_to_bytes('1K') == 1024)
    assert(human_to_bytes('12K') == 12288)
    assert(human_to_bytes('1M') == 1048576)
    assert(human_to_bytes('1.5M') == 1572864)
    assert(human_to_bytes('1.5K') == 1536)
    assert(human_to_bytes('1G') == 1073741824)
    assert(human_to_bytes('1.5G') == 1610612736)
    assert(human_to_bytes('1.5K', default_unit="B") == 1536)

# Generated at 2022-06-22 22:15:57.934842
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'b', 1, 'c']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']


# Generated at 2022-06-22 22:16:10.805644
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(100000000, unit='B') == '100.00 MB'
    assert bytes_to_human(1000000) == '1.00 MB'
    assert bytes_to_human(10000) == '10.00 KB'
    assert bytes_to_human(1000) == '1.00 KB'
    assert bytes_to_human(100) == '100.00 B'
    assert bytes_to_human(10) == '10.00 B'
    assert bytes_to_human(1) == '1.00 B'
    assert bytes_to_human(0.01, unit='B') == '0.01 B'
    assert bytes_to_human(0.01, unit='K') == '0.00 KB'

# Generated at 2022-06-22 22:16:22.539762
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    print("test lenient_lowercase function")
    arr = ['AAA', 'bbb', 3, 'CCC']
    lower = lenient_lowercase(arr)
    print("arr = %s, lower = %s" % (arr, lower))

    arr = ['A1A', 'b1b', 'c1c', 3, 'C1C']
    lower = lenient_lowercase(arr)
    print("arr = %s, lower = %s" % (arr, lower))

    arr = ['A1A', ['b1b'], 'c1c', 3, 'C1C']
    lower = lenient_lowercase(arr)
    print("arr = %s, lower = %s" % (arr, lower))



# Generated at 2022-06-22 22:16:33.534423
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1023, unit='k') == '1.00 KB'
    assert bytes_to_human(1023, unit='K') == '1.00 KB'
    assert bytes_to_human(1023, isbits=True) == '8191.00 bits'
    assert bytes_to_human(1023, isbits=True, unit='Mb') == '8.00 Mb'
    assert bytes_to_human(1023, isbits=True, unit='B') == '8191.00 bits'
    assert bytes_to_human(1023, isbits=True, unit='b') == '8191.00 bits'
    assert bytes_to_human(-1023) == '-1023 Bytes'

#

# Generated at 2022-06-22 22:16:37.270287
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 1, 'b']) == ['a', 1, 'b']
    assert lenient_lowercase(['a', 'B', 'C']) == ['a', 'b', 'c']


# Generated at 2022-06-22 22:16:48.722568
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print('====== Unit test for bytes_to_human ======')
    print('1) test bytes_to_human with valid case')
    print('   input: bytes_to_human(size=1048576, isbits=False, unit=None)')
    print('   output:', bytes_to_human(size=1048576, isbits=False, unit=None))
    print('2) test bytes_to_human with invalid case')
    print('   input: bytes_to_human(size=48576, isbits=True, unit=K)')
    print('   output:', bytes_to_human(size=48576, isbits=True, unit=K))
    print('3) test bytes_to_human with invalid case')

# Generated at 2022-06-22 22:16:53.248642
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('+ Testing function human_to_bytes()')
    test_list = [
        ('1', 1),
        ('2', 2),
        ('2.0', 2),
        ('1K', 1 << 10),
        ('1 M', 1 << 20),
        ('3.2K', 3.2 * 1 << 10),
        ('1.3M', 1.3 * 1 << 20),
        ('3.2Tb', 3.2 * 1 << 40),
        ('1.3b', 1.3),
        ('3.2Zb', 3.2 * 1 << 70),
        ('1.3Pb', 1.3 * 1 << 50),
    ]
    for number, result in test_list:
        assert human_to_bytes(number) == result



# Generated at 2022-06-22 22:17:03.383511
# Unit test for function bytes_to_human
def test_bytes_to_human():
    import random
    for i in range(10):
        for suffix in ['', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y']:
            for bits in [False, True]:
                num = random.randrange(SIZE_RANGES[suffix[-1].upper()]) + random.random()
                size = num * SIZE_RANGES[suffix[-1].upper()]
                if bits:
                    test_result = bytes_to_human(size, isbits=True)
                else:
                    test_result = bytes_to_human(size)
                result = '%.2f %s' % (num, suffix + 'B')
                if bits:
                    result = '%.2f %s' % (num, suffix + 'b')
                result = result.lower

# Generated at 2022-06-22 22:17:11.004604
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' test for function human_to_bytes
    '''
    assert human_to_bytes(1, 'K') == 1024, 'ERROR in human_to_bytes(1, "K"): %s' % human_to_bytes(1, 'K')
    assert human_to_bytes('1', 'K') == 1024, 'ERROR in human_to_bytes("1", "K"): %s' % human_to_bytes('1', 'K')
    assert human_to_bytes('1M') == 1048576, 'ERROR in human_to_bytes("1M"): %s' % human_to_bytes('1M')

# Generated at 2022-06-22 22:17:21.301722
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M', default_unit='bytes') == 10 * 1024 * 1024
    assert human_to_bytes(10, 'm', default_unit='bytes') == 10 * 1024 * 1024
    assert human_to_bytes('2K') == 2 * 1024
    assert human_to_bytes(0, 'm') == 0
    assert human_to_bytes(0.5, 'KB') == 512
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes(1, 'b') == 1
    assert human_to_bytes(1, 'b', isbits=True) == 1

# Generated at 2022-06-22 22:17:29.523123
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['aB', 'cd', 2]) == ['ab', 'cd', 2]
    assert lenient_lowercase(['aB', 'cd']) == ['ab', 'cd']
    assert lenient_lowercase(['aB', 2]) == ['ab', 2]
    assert lenient_lowercase([2, 'aB']) == [2, 'ab']
    assert lenient_lowercase(['aB']) == ['ab']

# Unit tests for function human_to_bytes

# Generated at 2022-06-22 22:17:39.628802
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(2048, unit='K') == '2.00 KB'
    assert bytes_to_human(2048, unit='K', isbits=True) == '2.00 Kbit'
    assert bytes_to_human(2 * 1024**2) == '2.00 MB'
    assert bytes_to_human(2 * 1024**2 * 1024) == '2.00 TB'
    assert bytes_to_human(2 * 1024**3 * 1024) == '2.00 PB'
    assert bytes_to_human(2 * 1024**4 * 1024) == '2.00 EB'

# Generated at 2022-06-22 22:17:49.200429
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(size=0) == "0 Bytes"
    assert bytes_to_human(size=1) == "1 Bytes"
    assert bytes_to_human(size=1024) == "1.00 KB"
    assert bytes_to_human(size=1048576) == "1.00 MB"
    assert bytes_to_human(size=1073741824) == "1.00 GB"
    assert bytes_to_human(size=1073741824, unit='GB') == "1.00 GB"
    assert bytes_to_human(size=1073741824, unit='gB') == "1.00 GB"
    assert bytes_to_human(size=1073741824, unit='Gb') == "1.00 Gb"



# Generated at 2022-06-22 22:17:57.394421
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print("Testing bytes to human conversions...")

# Generated at 2022-06-22 22:18:00.738481
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['string1', 2, 'string3']
    ret = lenient_lowercase(lst)
    assert ret == ['string1', 2, 'string3']



# Generated at 2022-06-22 22:18:03.666402
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_list = ['Test', 'Test2']
    first_string = input_list[0]
    first_string = first_string.upper()

    input_list[0] = first_string

    assert input_list == ['TEST', 'Test2']

    lenient_lowercase(input_list)

    assert input_list == ['test', 'Test2']

# Generated at 2022-06-22 22:18:10.519638
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) != ['A', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) != ['a', 'B', 1, 'C']
    assert lenient_lowercase(['A', 'B', 1, 'C']) != ['a', 'b', 1, 'C']
    assert lenient_lowercase(['A', 'B', 1, 'C']) != ['a', 'b', 1, 'c', 'D']



# Generated at 2022-06-22 22:18:20.472217
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Byte'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(100) == '100 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, unit='k') == '1.00 KB'
    assert bytes_to_human(1024, unit='K') == '1.00 KB'
    assert bytes_to_human(1024, unit='Kb') == '1.00 Kb'
    assert bytes_to_human(1024, unit='kb') == '1.00 kb'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_

# Generated at 2022-06-22 22:18:29.536962
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('Testing function human_to_bytes.')
    print('Tests with bytes should pass.')

# Generated at 2022-06-22 22:18:37.003144
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(None) == []
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['a']) == ['a']
    assert lenient_lowercase([1]) == [1]
    assert lenient_lowercase(['a', 1, 'b']) == ['a', 1, 'b']
    assert lenient_lowercase(['A', 'B']) == ['a', 'b']

# Generated at 2022-06-22 22:18:45.816359
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1000', default_unit='M') == 1000 * pow(2, 20)
    assert human_to_bytes('1000', default_unit='MB') == 1000 * pow(2, 20)
    assert human_to_bytes('1000', default_unit='Mb') == 1000 * pow(2, 17)
    assert human_to_bytes('1000', default_unit='mB') == 1000 * pow(2, 17)

    assert human_to_bytes('1000', default_unit='K') == 1000 * pow(2, 10)
    assert human_to_bytes('1000', default_unit='KB') == 1000 * pow(2, 10)
    assert human_to_bytes('1000', default_unit='Kb') == 1000
    assert human_to_bytes('1000', default_unit='kB') == 1000


# Generated at 2022-06-22 22:18:55.762003
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes('1Mb', isbits=True) == human_to_bytes(1, 'Mb', True)
    assert human_to_bytes(1, 'Mb', True) == human_to_bytes(1, 'Mb', True)
    assert human_to_bytes('1Mb', True) == human_to_bytes(1, 'Mb', True)
    assert human_to_bytes('1M', False) == human_to_bytes(1, 'M', False)
    assert human_to_bytes(1, 'M', True) == human_to_bytes(1, 'M', True)


# Generated at 2022-06-22 22:19:07.465260
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10.5M') == 10485760
    assert human_to_bytes('10.5M', 'MB') == 10485760
    assert human_to_bytes('1000KB') == 1048576
    assert human_to_bytes('10240b') == 1280
    assert human_to_bytes('10240b', 'kb') == 1280
    assert human_to_bytes('10240b', 'kb', True) == 1280
    assert human_to_bytes('10240b', True) == 1280
    assert human_to_bytes('1000KB', True) == 8000000
    assert human_to_bytes('1000KB', 'kb', True) == 8000000
    assert human_to_bytes('1mb', True) == 1048576

# Generated at 2022-06-22 22:19:08.938342
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['A', 'B', 'str']) == ['a', 'b', 'str'])



# Generated at 2022-06-22 22:19:14.425625
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10000) == '9.77 KB'
    assert bytes_to_human(100001221) == '95.37 MB'
    assert bytes_to_human(12334) == '12.00 KB'
    assert bytes_to_human(10000, unit='K') == '9.77 KB'
    assert bytes_to_human(10000, unit='M') == '0.01 MB'
    assert bytes_to_human(12334, unit='K') == '12.00 KB'
    assert bytes_to_human(12334, unit='b', isbits=True) == '98.67 kb'
    assert bytes_to_human(12334, unit='k', isbits=True) == '98.67 kb'

# Generated at 2022-06-22 22:19:23.737409
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10 * 1024 * 1024, 'function failed to convert "10M" to bytes'
    assert human_to_bytes('10K') == 10 * 1024, 'function failed to convert "10K" to bytes'
    assert human_to_bytes('10B') == 10, 'function failed to convert "10B" to bytes'
    assert human_to_bytes('10M', default_unit='K') == 10 * 1024 * 1024, 'function failed to convert "10M" to bytes'
    assert human_to_bytes('10K', default_unit='M') == 10 * 1024, 'function failed to convert "10K" to bytes'
    assert human_to_bytes('10B', default_unit='G') == 10, 'function failed to convert "10B" to bytes'
    assert human_to_bytes

# Generated at 2022-06-22 22:19:32.660901
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test valid input types
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes(1) == 1
    assert human_to_bytes(1.1) == 1
    assert human_to_bytes('1.1B') == 1
    assert human_to_bytes('1B') == 1

    # Test edge cases
    assert human_to_bytes(0.9) == 0
    assert human_to_bytes('0.9') == 0

# Generated at 2022-06-22 22:19:35.350544
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 1, 'b', True, 'aloha']) == ['a', 1, 'b', True, 'aloha']

# Unit tests for function human_to_bytes

# Generated at 2022-06-22 22:19:39.784933
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['ab', 'AB', 2, {'a': 'b'}, 'c', 'C', 'd', 'D']) == ['ab', 'ab', 2, {'a': 'b'}, 'c', 'c', 'd', 'd']
    assert lenient_lowercase([]) == []



# Generated at 2022-06-22 22:19:49.269669
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import assert_equal

    assert_equal(human_to_bytes(0), 0)
    assert_equal(human_to_bytes('0'), 0)
    assert_equal(human_to_bytes('   0   '), 0)
    assert_equal(human_to_bytes(1), 1)
    assert_equal(human_to_bytes('1'), 1)
    assert_equal(human_to_bytes('1B'), 1)
    assert_equal(human_to_bytes('1b'), 1)
    assert_equal(human_to_bytes('1KB'), 1024)
    assert_equal(human_to_bytes('1KBb'), 1024)
    assert_equal(human_to_bytes('1Kb'), 1000)
    assert_equal(human_to_bytes('1MB'), 1048576)


# Generated at 2022-06-22 22:19:55.260974
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A']) == ['a']
    assert lenient_lowercase([1]) == [1]
    assert lenient_lowercase(['a']) == ['a']
    assert lenient_lowercase(['A', 1]) == ['a', 1]
    assert lenient_lowercase([]) == []



# Generated at 2022-06-22 22:19:59.957643
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    lenient_lowercase(['a', 1, 'c']) == ['a', 1, 'c']



# Generated at 2022-06-22 22:20:12.065312
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:20:21.214513
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:20:27.624674
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['hi', 'there', 'how', 'Are You', 1, 2, 3]) == ['hi', 'there', 'how', 'Are You', 1, 2, 3]
    assert lenient_lowercase(['Hi', 'tHERE', 'HOW', 'ARE YOU', 1, 2, 3]) == ['hi', 'there', 'how', 'ARE YOU', 1, 2, 3]


# Unit tests for function human_to_bytes

# Generated at 2022-06-22 22:20:38.181306
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # convert number of bytes (i.e. 1024 * 7) to human-readable format
    assert bytes_to_human(1024 * 7) == '7.00 KB'
    # convert number of bytes (i.e. 1024 * 7) to human-readable format using unit 'K'
    assert bytes_to_human(1024 * 7, unit='K') == '7.00 KB'
    # convert number of bytes (i.e. 1024 * 7) to human-readable format using unit 'Kb'
    assert bytes_to_human(1024 * 7, unit='Kb') == '7.00 KB'
    # convert number of bytes (i.e. 1024 * 7) to human-readable format using unit 'b'
    assert bytes_to_human(1024 * 7, unit='b') == '7.00 KiB'
    # convert number of

# Generated at 2022-06-22 22:20:43.226522
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'b', 2]) == ['a', 'b', 2]
    assert lenient_lowercase(['a', u'b', u'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', u'b', [] ]) == ['a', 'b', [] ]


# Generated at 2022-06-22 22:20:49.878591
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test number 10
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(10, unit='b') == '10 Bytes'
    assert bytes_to_human(10, unit='B') == '10 Bytes'
    assert bytes_to_human(10, unit='B', isbits=True) == '80 bits'
    assert bytes_to_human(10, unit='b', isbits=True) == '80 bits'
    assert bytes_to_human(10, isbits=True) == '80 bits'

    # Test number 2048
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(2048, unit='b') == '2.00 KB'
    assert bytes_to_human(2048, unit='B')

# Generated at 2022-06-22 22:20:55.692703
# Unit test for function bytes_to_human
def test_bytes_to_human():
    bytesize = [512, 1024, 1025, 4194304, 1073741824, 1099511627776, 1 << 80]
    units = ['KB', 'KB', 'MB', 'MB', 'GB', 'TB', 'YB']
    for idx, size in enumerate(bytesize):
        result = bytes_to_human(size, unit=units[idx])
        assert result is not None, 'bytes_to_human: %s should not be None' % result


# Generated at 2022-06-22 22:21:06.010101
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:21:14.837549
# Unit test for function human_to_bytes
def test_human_to_bytes():
    should_be = {'1M': 1048576, '1Mb': 1048576, '2KB': 2048, '100B': 100, '1B': 1, '1Kb': 1024, '8Kb': 8192, '1Mb': 1048576, '1GB': 1073741824, '10Kb': 10240}

    for k in should_be:
        assert human_to_bytes(k) == should_be[k]
    try:
        human_to_bytes('1Kbb')
        assert False
    except ValueError as e:
        assert str(e) == "human_to_bytes() failed to convert 1Kbb (unit = Kb). The suffix must be one of Y, Z, E, P, T, G, M, K, B"


# Generated at 2022-06-22 22:21:23.275484
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human(1099511627776) == '1.00 TB'
    assert bytes_to_human(1125899906842624) == '1.00 PB'
    assert bytes_to_human(1152921504606846976) == '1.00 EB'

    assert bytes_to_human(1, isbits=True) == '1 bits'
    assert bytes_to_human(1024, isbits=True) == '1.00 Kbits'
    assert bytes_to_human

# Generated at 2022-06-22 22:21:31.857144
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test base cases
    test_string = '1'
    assert str(human_to_bytes(test_string)) == '1', 'Failed to convert {0} to bytes 1'.format(test_string)
    test_string = '1048576'
    assert str(human_to_bytes(test_string)) == '1048576', 'Failed to convert {0} to bytes 1048576'.format(test_string)
    test_string = '1 Mb'
    assert str(human_to_bytes(test_string, isbits=True)) == '1048576', 'Failed to convert {0} to bytes 1048576'.format(test_string)
    test_string = '1 MB'

# Generated at 2022-06-22 22:21:43.522732
# Unit test for function human_to_bytes
def test_human_to_bytes():
    base_value = 1 << 30

    def validate_convertion(input_value, expected_output, expected_unit, isbits=False):
        output = human_to_bytes(input_value, isbits=isbits)
        assert output == expected_output, "Unexpected result for %s (%s) expected %d, but got %d." % (input_value, expected_unit, expected_output, output)

    validate_convertion('1', 1, 'B', isbits=False)
    validate_convertion('2', 2, 'B', isbits=False)
    validate_convertion('0.5', 0, 'B', isbits=False)
    validate_convertion('0.50000000000001', 1, 'B', isbits=False)


# Generated at 2022-06-22 22:21:55.004278
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:22:06.290062
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''Unit tests for function bytes_to_human
    '''
    tests = [0, 1, 2, 3, 4, 7, 11, 1024, 1024, 1024, (2 * 1024 * 1024), (2 * 1024 * 1024 * 1024), (2 * 1024 * 1024 * 1024 * 1024), (2 * 1024 * 1024 * 1024 * 1024 * 1024),
             (2 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024), (2 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024)]
    unit = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y']
    in_unit = ['b', 'Kb', 'Mb', 'Gb', 'Tb', 'Pb', 'Eb', 'Zb', 'Yb']