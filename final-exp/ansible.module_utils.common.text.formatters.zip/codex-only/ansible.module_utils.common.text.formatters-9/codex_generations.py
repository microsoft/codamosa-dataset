

# Generated at 2022-06-22 22:12:10.328130
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    import random
    import string
    random_string_1 = ''.join(random.choice(string.ascii_letters) for _ in range(random.randint(1, 100)))
    random_string_2 = ''.join(random.choice(string.ascii_letters) for _ in range(random.randint(1, 100)))
    random_list = [random_string_1, random_string_2]
    result = lenient_lowercase(random_list)
    assert result[0].lower() == random_string_1
    assert result[1].lower() == random_string_2



# Generated at 2022-06-22 22:12:20.512130
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Tests for human_to_bytes and bytes_to_human '''
    from nose2.tools import params

# Generated at 2022-06-22 22:12:30.922568
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print('testing bytes_to_human')
    assert bytes_to_human(1) == '1 Bytes', 'Failed to convert bytes'
    assert bytes_to_human(1024) == '1 KB', 'Failed to convert KB'
    assert bytes_to_human(1048576) == '1 MB', 'Failed to convert MB'
    assert bytes_to_human(1073741824) == '1 GB', 'Failed to convert GB'
    assert bytes_to_human(1099511627776) == '1 TB', 'Failed to convert TB'
    assert bytes_to_human(1125899906842624) == '1 PB', 'Failed to convert PB'
    assert bytes_to_human(1152921504606846976) == '1 EB', 'Failed to convert EB'
    assert bytes_

# Generated at 2022-06-22 22:12:42.682360
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:12:54.153046
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Test cases for human_to_bytes function
    '''
    # Test cases for bytes
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.2') == 1
    assert human_to_bytes(1) == 1
    assert human_to_bytes(1.0) == 1
    assert human_to_bytes(1.2) == 1

    assert human_to_bytes('1K') == 1000
    assert human_to_bytes('1.0K') == 1000
    assert human_to_bytes('1.2K') == 1000
    assert human_to_bytes(1024) == 1024
    assert human_to_bytes(1024.00) == 1024

# Generated at 2022-06-22 22:13:05.809784
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import unittest
    import pytest

    class HumanToBytesTester(unittest.TestCase):
        def test_empty(self):
            with self.assertRaises(ValueError):
                human_to_bytes('')

        def test_bad_unit_class(self):
            with self.assertRaises(ValueError):
                human_to_bytes('1Kb')

        def test_bad_unit_class_2(self):
            with self.assertRaises(ValueError):
                human_to_bytes('1mb')

        def test_bad_unit_class_3(self):
            with self.assertRaises(ValueError):
                human_to_bytes('1GB', isbits=True)


# Generated at 2022-06-22 22:13:08.480866
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase([1, 2, 'ABC', 10, 'def'])
    assert [1, 2, 'abc', 10, 'def'] == result


# Generated at 2022-06-22 22:13:16.362228
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Byte'
    assert bytes_to_human(2.2) == '2.20 Bytes'

    assert bytes_to_human(2 ** 10) == '1.00 KB'
    assert bytes_to_human(2 ** 20) == '1.00 MB'
    assert bytes_to_human(2 ** 30) == '1.00 GB'
    assert bytes_to_human(2 ** 40) == '1.00 TB'
    assert bytes_to_human(2 ** 50) == '1.00 PB'
    assert bytes_to_human(2 ** 60) == '1.00 EB'
    assert bytes_to_human(2 ** 70) == '1.00 ZB'
    assert bytes_

# Generated at 2022-06-22 22:13:24.385623
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b') == 10

    assert human_to_bytes('1K') == 1000
    assert human_to_bytes('1Kb') == 1000
    assert human_to_bytes('1M') == 1000000
    assert human_to_bytes('1Mb') == 1000000
    assert human_to_bytes('1G') == 1000000000
    assert human_to_bytes('1Gb') == 1000000000

    assert human_to_bytes('0.5K') == 500
    assert human_to_bytes('0.5Kb') == 500
    assert human_to_bytes('0.5M') == 500000
    assert human_to_bytes('0.5Mb') == 500000


# Generated at 2022-06-22 22:13:32.843526
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:13:37.030571
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test = ['1', 'a', 'A', '10', 'aa', 'aA', 'a10']
    test_lower = ['1', 'a', 'a', '10', 'aa', 'aa', 'a10']
    assert lenient_lowercase(test) == test_lower



# Generated at 2022-06-22 22:13:39.741799
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 2, 3]) == ['a', 'b', 2, 3]
    assert lenient_lowercase(['A', 'b', 2, 3]) == ['a', 'b', 2, 3]
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-22 22:13:45.613020
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.1M') == 1100000
    assert human_to_bytes('1.1M', default_unit='B') == 1100000
    assert human_to_bytes('1.1M', default_unit='M') == 1100000
    assert human_to_bytes('1.1MB') == 1100000
    assert human_to_bytes('1.1Mb', isbits=True) == 1100000
    assert human_to_bytes('1.1K', isbits=True) == 1100
    assert human_to_bytes('1.1M', isbits=True, unit='B') == 1100000
    assert human_to_bytes('1.1M', isbits=True, unit='M') == 1100000

# Generated at 2022-06-22 22:13:57.114910
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Byte'
    assert bytes_to_human(1, isbits=True) == '1 bit'
    assert bytes_to_human(1, unit='b') == '1 bit'
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1023, unit='B') == '1023 Bytes'
    assert bytes_to_human(1023, unit='b') == '1023 bits'

    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, isbits=True) == '1.00 Kb'

# Generated at 2022-06-22 22:14:06.773726
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024*1024*2) == '2.00 MB'
    assert bytes_to_human(1024*1024*1.5) == '1.50 MB'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024*0.5) == '0.50 KB'

    # Unit test for function bytes_to_human and isbits parameter
    assert bytes_to_human(1024*1024*2 * 8, isbits=True) == '2.00 MB'
    assert bytes_to_human(1024*1024*1.5 * 8, isbits=True) == '1.50 MB'
    assert bytes_to_human(1024 * 8, isbits=True) == '1.00 KB'

# Generated at 2022-06-22 22:14:16.064905
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # B (Bytes)
    assert(human_to_bytes('1B') == 1)
    assert(human_to_bytes('1b') == 1)
    assert(human_to_bytes('1Bb') == 1)
    assert(human_to_bytes('1BBbb') == 1)
    assert(human_to_bytes('1bBb') == 1)
    # K (Kilobytes)
    assert(human_to_bytes('1K') == 1024)
    assert(human_to_bytes('1k') == 1024)
    assert(human_to_bytes('1Kb') == 1024)
    assert(human_to_bytes('1kb') == 1024)
    assert(human_to_bytes('1Kkb') == 1024)
    assert(human_to_bytes('1kbK') == 1024)

# Generated at 2022-06-22 22:14:26.398944
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_1 = ['aBc', 1, 2, 3]
    list_2 = ['Abc', 1, 2, 3]
    list_3 = ['Abc', 1, 2, {'d': 1}]
    list_4 = ['Abc', 1, 2, [1,2,3]]
    list_5 = ['Abc', 1, 2, None]

    assert lenient_lowercase(list_1) == ['abc', 1, 2, 3]
    assert lenient_lowercase(list_2) == ['abc', 1, 2, 3]
    assert lenient_lowercase(list_3) == ['abc', 1, 2, {'d': 1}]
    assert lenient_lowercase(list_4) == ['abc', 1, 2, [1,2,3]]
    assert lenient_lower

# Generated at 2022-06-22 22:14:31.092381
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B']) == ['a', 'b']
    assert lenient_lowercase(['A', 'B', 100, 200]) == ['a', 'b', 100, 200]



# Generated at 2022-06-22 22:14:36.480617
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # bytes
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1MB') == 1024 * 1024
    assert human_to_bytes('1G') == 1024 * 1024 * 1024
    assert human_to_bytes('1GB') == 1024 * 1024 * 1024
    assert human_to_bytes('1ZB') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1YB') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024

    # test default_unit
    assert human_to_bytes('1', 'GB') == 1024 * 1024 * 1024

# Generated at 2022-06-22 22:14:47.994048
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1024, 'b', isbits=True) == 1024
    assert human_to_bytes(1025, 'b', isbits=True) == 1025

    assert human_to_bytes('1kB', 'b', isbits=True) == 1024
    assert human_to_bytes('2KB', 'b', isbits=True) == 2048
    assert human_to_bytes('2Kb', 'b', isbits=True) == 2048
    assert human_to_bytes('2kb', 'b', isbits=True) == 2048
    assert human_to_bytes('1KBB', isbits=True) == 1024
    assert human_to_bytes('1KBb', isbits=True) == 1024
    assert human_to_bytes('1KbB', isbits=True) == 1024

    assert human_to

# Generated at 2022-06-22 22:14:57.063823
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:15:07.378672
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 1, 'c']) == ['a', 1, 'c']
    assert lenient_lowercase([1, 2, 'c']) == [1, 2, 'c']
    assert lenient_lowercase(['a', 'b', 3]) == ['a', 'b', 3]
    assert lenient_lowercase(['a', 'b', []]) == ['a', 'b', []]
    assert lenient_lowercase([['a', 'b'], [], []]) == [['a', 'b'], [], []]



# Generated at 2022-06-22 22:15:17.000654
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10, False, 'B') == '10.00 Bytes'
    assert bytes_to_human(10, False, 'b') == '10.00 Bytes'
    assert bytes_to_human(10, False, 'K') == '10240.00 Bytes'
    assert bytes_to_human(10, False, 'KB') == '10240.00 Bytes'
    assert bytes_to_human(10, False, 'KBb') == '10240.00 Bytes'
    assert bytes_to_human(10, False, 'KB') == '10240.00 Bytes'
    assert bytes_to_human(1, False, 'K') == '1024.00 Bytes'
    assert bytes_to_human(1, False, 'Kb') == '1024.00 Bytes'
   

# Generated at 2022-06-22 22:15:26.846570
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # should lowercase string
    assert lenient_lowercase(['This', 'IS', 'an', 'example']) == ['this', 'is', 'an', 'example']

    # should pass through non-string element unmodified
    assert lenient_lowercase([12345, 'This', 'IS', 'an', 'example']) == [12345, 'this', 'is', 'an', 'example']

    # should pass through an item that raises an AttributeError when calling lower()
    class MyClass:
        pass

    myclass_element = MyClass()
    assert lenient_lowercase(['This', 'IS', 'an', 'example', myclass_element]) == ['this', 'is', 'an',
                                                                                  'example', myclass_element]
    # should be able to handle None
    assert lenient_lowercase

# Generated at 2022-06-22 22:15:31.568921
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['a', 'b', 'c'] == lenient_lowercase(['A', 'B', 'C'])
    assert ['1', 2, 'c'] == lenient_lowercase(['1', 2, 'C'])
    assert [] == lenient_lowercase([])

# Generated at 2022-06-22 22:15:39.187003
# Unit test for function bytes_to_human
def test_bytes_to_human():
    try:
        assert bytes_to_human(1000) == '1000 Bytes'
        assert bytes_to_human(1024) == '1.00 KB'
        assert bytes_to_human(1048576) == '1.00 MB'
        assert bytes_to_human(10485760) == '10.00 MB'
        assert bytes_to_human(1048576000) == '1000.00 MB'
        assert bytes_to_human(1073741824) == '1.00 GB'
    except AssertionError:
        raise AssertionError("Test failed, bytes_to_human()")

# Generated at 2022-06-22 22:15:49.388326
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(4, 'K') == 4 * 1024
    assert human_to_bytes(4, 'Kb') == 4 * 1024
    assert human_to_bytes(4, 'K') == human_to_bytes(4, 'Kb')
    assert human_to_bytes(4, 'K', isbits=True) == 4 * 1024 / 8
    assert human_to_bytes(4, 'Kb', isbits=True) == 4 * 1024 / 8
    assert human_to_bytes('4K') == human_to_bytes(4, 'K')
    assert human_to_bytes('4Kb') == human_to_bytes(4, 'Kb')
    assert human_to_bytes('4Kb') == human_to_bytes(4, 'K')

# Generated at 2022-06-22 22:15:57.765608
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(None) is None
    assert lenient_lowercase(True) is True
    assert lenient_lowercase(False) is False
    assert lenient_lowercase('') == ''
    assert lenient_lowercase('string') == 'string'
    assert lenient_lowercase(['lower', 'UPPER']) == ['lower', 'upper']
    assert lenient_lowercase(['lower', 'upper', 1]) == ['lower', 'upper', 1]
    assert lenient_lowercase(['lower', None]) == ['lower', None]



# Generated at 2022-06-22 22:16:10.014985
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Default unit case
    assert bytes_to_human(2 * SIZE_RANGES['K']) == '2.00 KB'
    # bits case
    assert bytes_to_human(2 * SIZE_RANGES['K'], isbits=True) == '16.00 Kb'
    # no limit case
    assert bytes_to_human(SIZE_RANGES['K'] + SIZE_RANGES['K'] / 2) == '1.50 KB'
    # unit case
    assert bytes_to_human(SIZE_RANGES['K'], unit='m') == '0.00 MB'
    assert bytes_to_human(SIZE_RANGES['M'], unit='K') == '1024.00 KB'

# Generated at 2022-06-22 22:16:22.490936
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # default unit
    assert human_to_bytes('2K') == 2048
    # default unit with decimals
    assert human_to_bytes('2.1K') == 2144
    # default unit with decimals
    assert human_to_bytes('2.1K') == 2144
    # default unit with decimals
    assert human_to_bytes('2.1K') == 2144
    # default unit with decimals and negative number
    assert human_to_bytes('-2.1K') == -2144
    # default unit with negative number
    assert human_to_bytes('-2K') == -2048
    # default unit without unit
    assert human_to_bytes('2') == 2
    # default unit without unit and negative number
    assert human_to_bytes('-2') == -2
   

# Generated at 2022-06-22 22:16:26.063094
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["A", "B", "C"]) == ["a", "b", "c"]
    assert lenient_lowercase(["A", 1, "C"]) == ["a", 1, "c"]



# Generated at 2022-06-22 22:16:32.848094
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:16:37.269573
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Basic list
    test_list = ['One', 'two', 3]
    result = lenient_lowercase(test_list)
    assert result == ['one', 'two', 3]

    # Dictionary
    test_dict = {'one': 1, 'TWO': 2, 'thrEE': 'three'}
    result = lenient_lowercase(test_dict)
    assert result == {'one': 1, 'TWO': 2, 'thrEE': 'three'}

    # Tuples
    test_tuple = ('one', 'two', 'thrEE')
    result = lenient_lowercase(test_tuple)
    assert result == ('one', 'two', 'thrEE')

    # String
    test_string = 'thIs'
    result = lenient_lowercase(test_string)


# Generated at 2022-06-22 22:16:48.724628
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 'b', 'c']) == [1, 'b', 'c']
    assert lenient_lowercase(['1a']) == ['1a']
    assert lenient_lowercase(['1A']) == ['1a']
    assert lenient_lowercase(['1a1']) == ['1a1']
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(None) is None

# Generated at 2022-06-22 22:16:50.373476
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'A', 1, 2, 3]) == ['a', 'a', 1, 2, 3]



# Generated at 2022-06-22 22:17:00.943342
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert(bytes_to_human(10) == '10 Bytes')
    assert(bytes_to_human(1024) == '1.00 KBytes')
    assert(bytes_to_human(1048576) == '1.00 MBytes')
    assert(bytes_to_human(1073741824) == '1.00 GBytes')
    assert(bytes_to_human(1099511627776) == '1.00 TBytes')
    assert(bytes_to_human(1099511627776 * 10) == '10.00 TBytes')
    # Test unit param
    assert(bytes_to_human(1024, unit='K') == '1.00 KBytes')
    assert(bytes_to_human(1024, unit='k') == '1.00 KBytes')

# Generated at 2022-06-22 22:17:09.492626
# Unit test for function lenient_lowercase

# Generated at 2022-06-22 22:17:20.481727
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # test bytes
    assert bytes_to_human(int(1)) == "1.00 Bytes", "bytes_to_human (1) failed"
    assert bytes_to_human(int(2)) == "2.00 Bytes", "bytes_to_human (2) failed"
    assert bytes_to_human(int(1023)) == "1023.00 Bytes", "bytes_to_human (1023) failed"
    assert bytes_to_human(int(1024)) == "1.00 KB", "bytes_to_human (1024) failed"
    assert bytes_to_human(int(1024 * 2)) == "2.00 KB", "bytes_to_human (2K) failed"

# Generated at 2022-06-22 22:17:31.983438
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:17:40.937077
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Bytes test
    assert human_to_bytes('0') == 0
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('.1') == 0
    assert human_to_bytes('1.1k') == 1120
    assert human_to_bytes('1.1KB') == 1120
    assert human_to_bytes('1.1MB') == 1.1 * (1 << 20)
    assert human_to_bytes('1.1GB') == 1.1 * (1 << 30)
    assert human_to_bytes('1.1TB') == 1.1 * (1 << 40)
    assert human_to_bytes('1.1BYTES') == 1.1

# Generated at 2022-06-22 22:17:50.380917
# Unit test for function bytes_to_human
def test_bytes_to_human():
    import unittest

# Generated at 2022-06-22 22:18:02.905527
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:18:08.038752
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Human readable by default
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, isbits=False, unit='K') == '1.00 KB'
    assert bytes_to_human(1024, isbits=False, unit='B') == '1,024.00 Bytes'
    assert bytes_to_human(1024, isbits=False, unit='M') == '1.00 MB'
    assert bytes_to_human(1024, isbits=False, unit='G') == '1.00 GB'
    assert bytes_to_human(1024, isbits=False, unit='T') == '1.00 TB'
    assert bytes_to_human(1024, isbits=False, unit='P') == '1.00 PB'

# Generated at 2022-06-22 22:18:17.875580
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.5M', isbits=True) == 1572864
    assert human_to_bytes('1M', isbits=True) == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1', 'Mb') == 1048576
    assert human_to_bytes(1, 'Mb') == 1048576
    assert human_to_bytes(1.1, 'Mb') == 1179648

    assert human_to_bytes('1.5K', isbits=True) == 1536
    assert human_to_bytes('1K', isbits=True) == 1024
    assert human_to_bytes('1Kb') == 1024
   

# Generated at 2022-06-22 22:18:21.049998
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    L = [1, 'ABC', 'abC', 'Efg']
    L_expected = [1, 'abc', 'abc', 'efg']
    assert lenient_lowercase(L) == L_expected

# Generated at 2022-06-22 22:18:26.621409
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = human_to_bytes('10M')
    assert result == 10485760
    result = human_to_bytes('10MB')
    assert result == 10485760
    result = human_to_bytes('10MB', isbits=True)
    assert result == 83886080
    result = human_to_bytes('10Mb', isbits=True)
    assert result == 83886080
    result = human_to_bytes('10Mb', isbits=False)
    assert result == 10485760
    result = human_to_bytes('10Mb')
    assert result == 10485760
    result = human_to_bytes('10')
    assert result == 10
    result = human_to_bytes('10', 'M')
    assert result == 10485760
    result = human_to_

# Generated at 2022-06-22 22:18:28.865061
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['This', 'is', 'a', 4, 'Test']) == ['this', 'is', 'a', 4, 'test']



# Generated at 2022-06-22 22:18:34.556626
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(512) == '512.00 Bytes'
    assert bytes_to_human(1048575) == '1023.99 KB'
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human(1099511627776) == '1.00 TB'
    assert bytes_to_human(1, isbits=True) == '1.00 Bits'
    assert bytes_to_human(131072, isbits=True) == '1.00 Kb'
    assert bytes_to_human(1073741824, isbits=True) == '8.00 Gb'



# Generated at 2022-06-22 22:18:44.661367
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('0') == 0
    assert human_to_bytes('1') == 1
    assert human_to_bytes('0.5') == 0
    assert human_to_bytes('1.5') == 2
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('1024K') == 1048576
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1TB') == 1099511627776
    assert human_to_bytes('1PB') == 1125899906842624

    # bits
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1024Kb', isbits=True) == 1048576
    assert human_to_bytes

# Generated at 2022-06-22 22:18:54.952508
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:19:07.377017
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:19:19.569260
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:19:30.904323
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1024) == '1 KB'
    assert bytes_to_human(1024 ** 2) == '1 MB'
    assert bytes_to_human(1024 ** 3) == '1 GB'
    assert bytes_to_human(1024 ** 4) == '1 TB'
    assert bytes_to_human(1024 ** 5) == '1 PB'
    assert bytes_to_human(1024 ** 6) == '1 EB'
    assert bytes_to_human(1024 ** 7) == '1 ZB'
    assert bytes_to_human(1024 ** 8) == '1 YB'
    assert bytes_to_human(1024 ** 9) == '1024 YB'

# Generated at 2022-06-22 22:19:41.015729
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0, unit='B') == '0.00 Bytes'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1023, unit='B') == '1023.00 Bytes'
    assert bytes_to_human(1024, unit='B') == '1.00 KB'
    assert bytes_to_human(1024 * 1024, unit='B') == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024, unit='B') == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024, unit='B') == '1.00 TB'

# Generated at 2022-06-22 22:19:51.619327
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:20:02.903616
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576, False, 'M') == '1.00 MB'
    assert bytes_to_human(1048576, False, 'Mb') == '1.00 MB'
    assert bytes_to_human(1048576, True, 'Mb') == '1.00 Mb'
    assert bytes_to_human(None, False, 'Mb') == '0.00 Bytes'
    assert bytes_to_human(None, True, 'Mb') == '0.00 bits'

    try:
        assert bytes_to_human(1048576, True, 'MB') == '1.00 MB'
    except ValueError:
        return True
    assert False



# Generated at 2022-06-22 22:20:08.649445
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1mb', isbits=True) == 1048576, 'human_to_bytes() failed test #1'
    assert human_to_bytes('1MB', default_unit='Mb', isbits=True) == 1048576, 'human_to_bytes() failed test #2'
    assert human_to_bytes(-1, 'MB') == -1048576, 'human_to_bytes() failed test #3'
    assert human_to_bytes((-1), 'MB', isbits=True) == -1048576, 'human_to_bytes() failed test #4'
    assert human_to_bytes('1') == 1, 'human_to_bytes() failed test #5'
    assert human_to_bytes(1) == 1, 'human_to_bytes() failed test #6'

# Generated at 2022-06-22 22:20:18.231749
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:20:25.757884
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:20:36.609082
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test data
    # <input>, <expected output>
    # value, unit tests
    test_data = (
        (0, '0 Bytes'),
        (1, '1 Bytes'),
        (1023, '1023 Bytes'),
        (1024, '1 KB'),
        (1024 ** 2, '1 MB'),
        (1024 ** 3, '1 GB'),
        (1024 ** 4, '1 TB'),
        (1024 ** 5, '1 PB'),
        (1024 ** 6, '1 EB'),
        (1024 ** 7, '1 ZB'),
        (1024 ** 8, '1 YB'),
        (1024 ** 9, '1024 YB'),
        (1024 ** 10, '1048576 YB'),
    )

    for input, expected_output in test_data:
        result = bytes_to_human

# Generated at 2022-06-22 22:20:45.585855
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Byte'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 ** 2) == '1.00 MB'
    assert bytes_to_human(1024 ** 3) == '1.00 GB'
    assert bytes_to_human(1024 ** 4) == '1.00 TB'
    assert bytes_to_human(1024 ** 5) == '1.00 PB'
    assert bytes_to_human(1024 ** 6) == '1.00 EB'
    assert bytes_to_human(1024 ** 7) == '1.00 YB'
    assert bytes_to_human(1024 ** 8) == '1.00 ZB'
    assert bytes_to_

# Generated at 2022-06-22 22:20:55.632162
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2') == 2
    assert human_to_bytes('2K') == 2 * 1024
    assert human_to_bytes('2k') == 2 * 1024
    assert human_to_bytes('2MB') == 2 * 1024 * 1024
    assert human_to_bytes('2Mb') == 2 * 1024 * 1024
    assert human_to_bytes('2mB') == 2 * 1024 * 1024
    assert human_to_bytes('2b') == 2 * 1
    assert human_to_bytes('2B') == 2 * 1
    # exception test
    try:
        human_to_bytes('2bB')
    except Exception:
        pass
    else:
        raise Exception("Exception not raised")
    try:
        human_to_bytes('2Kb')
    except Exception:
        pass


# Generated at 2022-06-22 22:21:05.975571
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # base case
    assert human_to_bytes('1024') == 1024

    # explicit byte
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1

    # explicit bits
    assert human_to_bytes('1b', isbits=True) == 1

    # KB
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1KB', isbits=True) == 8192
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1kb', isbits=True) == 8192

    # MB
    assert human_to_bytes('1MB') == 1024 * 1024
    assert human_to_bytes('1MB', isbits=True) == 8192 * 1024

# Generated at 2022-06-22 22:21:09.349881
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Test function lenient_lowercase"""
    test_list = ['Hello', 1, 'World', 2]
    ret = ['hello', 1, 'world', 2]
    assert lenient_lowercase(test_list) == ret


# Generated at 2022-06-22 22:21:16.564498
# Unit test for function human_to_bytes
def test_human_to_bytes():
    tests = []
    tests.append({'input': '1K', 'expected': 1024, 'options': {}})
    tests.append({'input': '1KB', 'expected': 1024, 'options': {}})
    tests.append({'input': '1.5k', 'expected': 1536, 'options': {}})
    tests.append({'input': '1.5kb', 'expected': 1536, 'options': {}})
    tests.append({'input': '1024k', 'expected': 1024 * 1024, 'options': {}})
    tests.append({'input': '1024kb', 'expected': 1024 * 1024, 'options': {}})
    tests.append({'input': '3Mb', 'expected': 3 * 1024 * 1024, 'options': {'isbits': True}})

# Generated at 2022-06-22 22:21:27.831529
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1MB', 'B') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1Mb', 'b') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576

    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1

    assert human_to_bytes('1MB', 'b', isbits=True) == 134217728
    assert human_to_bytes('1Mb', 'b', isbits=True) == 134217728

# Generated at 2022-06-22 22:21:38.445179
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:21:43.834725
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['AbC', 244]
    expected_list = ['abc', 244]
    if lenient_lowercase(test_list) == expected_list:
        return True
    return False

# Unit tests for function bytes_to_human and human_to_bytes

# Generated at 2022-06-22 22:21:55.317946
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(5368709120) == '5.00 GB'
    assert bytes_to_human(5368709120, unit='G') == '5.00 GB'
    assert bytes_to_human(9999, unit='G') == '0.01 GB'
    assert bytes_to_human(9999, unit='M') == '9.99 MB'
    assert bytes_to_human(9999, unit='K') == '9.77 KB'
    assert bytes_to_human(9999, unit='B') == '9999.00 Bytes'
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'

# Generated at 2022-06-22 22:22:06.550597
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['1', '2', 3]) == ['1', '2', 3]
    assert lenient_lowercase(['1', '2', '3s']) == ['1', '2', '3s']
    assert lenient_lowercase(['1', '2', '3s', '4s']) == ['1', '2', '3s', '4s']
    assert lenient_lowercase(['1', '2', 3, '4s']) == ['1', '2', 3, '4s']
    assert lenient_lowercase(['1', '2', '3s', 4, '5s', 6, '7s']) == ['1', '2', '3s', 4, '5s', 6, '7s']