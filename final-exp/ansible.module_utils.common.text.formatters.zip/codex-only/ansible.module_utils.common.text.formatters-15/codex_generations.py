

# Generated at 2022-06-22 22:12:11.248846
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Unit test for human_to_bytes
    See also: https://github.com/ansible/ansible/pull/16341
    '''

    # Valid input
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5 ') == 1
    assert human_to_bytes(' 1.5 ') == 1
    assert human_to_bytes('1.5B') == 1
    assert human_to_bytes('1.5B ') == 1
    assert human_to_bytes(' 1.5B') == 1
    assert human_to_bytes(' 1.5B ') == 1
    assert human_to_bytes('1.5 KB') == 1536
    assert human_to_bytes('1.5Kb')

# Generated at 2022-06-22 22:12:18.385506
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, unit='k') == '1.00 KB'
    assert bytes_to_human(1024, unit='K') == '1.00 KB'
    assert bytes_to_human(1024, unit='b') == '8.00 Kbits'
    assert bytes_to_human(1024, unit='B') == '1.00 KB'
    assert bytes_to_human(1024, unit='m') == '0.00 MB'
    assert bytes_to_human(1024, unit='M') == '0.00 MB'
    assert bytes_to_human(1024, unit='m', isbits=True) == '8.00 Mbits'

# Generated at 2022-06-22 22:12:29.088422
# Unit test for function bytes_to_human
def test_bytes_to_human():
    test_cases = [
        (0,                             '0 Bytes'),
        (1,                             '1 Byte'),
        (1024,                          '1.00 KBytes'),
        (1024 * 1024,                   '1.00 MBytes'),
        (1024 ** 3,                     '1.00 GBytes'),
        (1024 ** 4,                     '1.00 TBytes'),
        (1024 ** 5,                     '1.00 PBytes'),
        (1024 ** 6,                     '1.00 EBytes'),
        (1024 ** 7,                     '1.00 ZBytes'),
        (1024 ** 8,                     '1.00 YBytes'),
        (1024 ** 9,                     '1024.00 YBytes'),
    ]
    for size, expected in test_cases:
        assert bytes_to_human(size) == expected



# Generated at 2022-06-22 22:12:37.752817
# Unit test for function human_to_bytes
def test_human_to_bytes():
    for i in ('10B', '-1B', '1K', '2M', '10G', '11.5K', '5.5Mb', '-5.5Mb', '5.5mb', '-5.5mb'):
        try:
            print('%s -> %s' % (i, human_to_bytes(i)))
        except ValueError as e:
            print('%s -> %s' % (i, e))


if __name__ == '__main__':
    test_human_to_bytes()

# Generated at 2022-06-22 22:12:45.381739
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1]) == [1]
    assert lenient_lowercase(['aBc']) == ['abc']
    assert lenient_lowercase([1, 'aBc', 5]) == [1, 'abc', 5]
    assert lenient_lowercase(['aBc', 'DeF', 'gHi']) == ['abc', 'def', 'ghi']
    assert lenient_lowercase(['aBc', 'DeF', 5]) == ['abc', 'def', 5]
    assert lenient_lowercase([1, 2, 3, 'aBc', 'DeF', 5]) == [1, 2, 3, 'abc', 'def', 5]

# Generated at 2022-06-22 22:12:56.214077
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10 KB') == 10240
    assert human_to_bytes('10 MB') == 10485760
    assert human_to_bytes('10 GB') == 10737418240
    assert human_to_bytes('10 TB') == 10995116277760
    assert human_to_bytes('10 PB') == 11258999068426240
    assert human_to_bytes('10 EB') == 115292150460684697600
    assert human_to_bytes('10 ZB') == 118059162071741130342400
    assert human_to_bytes('10 YB') == 1208925819614629174706176000

    assert human_to_bytes('1 b') == 1
    assert human_to_bytes('1 B') == 1
    assert human_to_bytes('1 Kb')

# Generated at 2022-06-22 22:13:00.294091
# Unit test for function bytes_to_human
def test_bytes_to_human():
    test_pairs = (
        (2048, '2.00 KB'),
        (3072, '3.00 KB'),
        (5368709120, '5.00 GB'),
        (536870912, '512.00 MB'),
        (536870912000, '5.00 TB'),
    )
    for test_size, expected_size in test_pairs:
        assert bytes_to_human(test_size) == expected_size
            # print('expected_size: %s' % expected_size)

# Generated at 2022-06-22 22:13:08.119844
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lowercase_list = ['a', 'b', 'c', 'd', 'e', 'f']
    test_list1 = ['A', 'b', 'C', 'd', 'e', 'f', 123, 456, 789]
    assert lenient_lowercase(test_list1) == lowercase_list
    test_list2 = ['a', 'B', 'c', 'D', 'e', 'f', 123, 456, 'g']
    assert lenient_lowercase(test_list2) == lowercase_list


# Generated at 2022-06-22 22:13:12.492730
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['ABC', 'def', 123]) == ['abc', 'def', 123]
    assert lenient_lowercase(['AA', 'BB', 'CC']) == ['aa', 'bb', 'cc']
    assert lenient_lowercase(['aB', 'bC', 'cD']) == ['ab', 'bc', 'cd']


# Generated at 2022-06-22 22:13:22.002168
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1500') == 1500
    assert human_to_bytes('500M') == 524288000
    assert human_to_bytes('10P') == 1125899906842624

    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1kb') == 1000
    assert human_to_bytes('1Mb') == 1000000
    assert human_to_bytes('1Gb') == 1000000000
    assert human_to_bytes('1Tb') == 10000000000

# Generated at 2022-06-22 22:13:32.668535
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1 mb') == 1048576
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1 TB') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1TB') == 1099511627776

    # add one more check of isbits=True
    assert human_to_bytes('1MB', isbits=True) == 1048576



# Generated at 2022-06-22 22:13:41.658190
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest

    # test valid numbers
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'K') == 10240
    assert human_to_bytes(10240, 'B') == 10240
    assert human_to_bytes(1, 'Kb') == 1
    assert human_to_bytes(10, 'Mb', isbits=True) == 10485760
    assert human_to_bytes(10, 'Kb', isbits=True) == 10240
    assert human_to_bytes(10240, 'b') == 10240

    # test valid numbers without unit
    assert human_to_bytes(10) == 10
    assert human_to_bytes(10.0) == 10
    assert human_to_bytes(10.5) == 10


# Generated at 2022-06-22 22:13:43.992375
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'test', b'test']) == [1, 'test', b'test']
    assert lenient_lowercase([1, 'TEST', b'test']) == [1, 'test', b'test']


# Generated at 2022-06-22 22:13:55.830017
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:14:04.054390
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Valid inputs
    assert human_to_bytes(10, 'MB') == 10 * 1024 * 1024
    assert human_to_bytes('10M') == 10 * 1024 * 1024
    assert human_to_bytes('10') == 10

    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes(1, 'b') == 1
    assert human_to_bytes(1, 'B') == 1

    assert human_to_bytes('1mb') == 1 * 1024 * 1024
    assert human_to_bytes('1Mb', isbits=True) == 1 * 1024 * 1024
    assert human_to_bytes('1mB', isbits=True) == 1 * 1024 * 1024
    assert human_to_bytes('1Mb', isbits=False)

# Generated at 2022-06-22 22:14:11.147116
# Unit test for function bytes_to_human
def test_bytes_to_human():
    result = bytes_to_human(124857600, unit='B')
    assert result == '120.00 MB', \
        "Test case result failed, actual result is: %s" % result

    result = bytes_to_human(124857600, unit='M')
    assert result == '120.00 MB', \
        "Test case result failed, actual result is: %s" % result

    result = bytes_to_human(124857600, unit='m')
    assert result == '120.00 MB', \
        "Test case result failed, actual result is: %s" % result

# Generated at 2022-06-22 22:14:23.921982
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['foo', 'bar', 'baz']) == ['foo', 'bar', 'baz']
    assert lenient_lowercase([u'foo', u'bar', u'baz']) == ['foo', 'bar', 'baz']
    assert lenient_lowercase(['foo', ['bar', ['baz']]]) == ['foo', ['bar', ['baz']]]
    assert lenient_lowercase(['foo', ['bar', ['baz']], ('boo',)]) == ['foo', ['bar', ['baz']], ('boo',)]
    assert sorted(lenient_lowercase(set(['foo', 'bar', 'baz']))) == sorted(['foo', 'bar', 'baz'])



# Generated at 2022-06-22 22:14:32.771513
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['a']) == ['a']
    assert lenient_lowercase(['a', 'B']) == ['a', 'b']
    assert lenient_lowercase([1]) == [1]
    assert lenient_lowercase(['a', 1, 'B', 'c']) == ['a', 1, 'b', 'c']
    assert lenient_lowercase(['a', 'B', 1, 'c']) == ['a', 'b', 1, 'c']

# Generated at 2022-06-22 22:14:38.116630
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert '1.00 Byte' == bytes_to_human(1)
    assert '1023.00 Bytes' == bytes_to_human(1023)
    assert '0.99 KiloBytes' == bytes_to_human(1024)
    assert '1.00 KiloByte' == bytes_to_human(1024, unit='K')
    assert '1.00 KiloBytes' == bytes_to_human(1025)
    assert '1.00 KiloByte' == bytes_to_human(1025, unit='K')
    assert '1.50 KiloBytes' == bytes_to_human(1536)
    assert '1.50 KiloByte' == bytes_to_human(1536, unit='K')
    assert '62.56 MegaByte' == bytes_to_human(65536 * 0.1)


# Generated at 2022-06-22 22:14:49.619312
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(10, isbits=True) == '10 bits'
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(2048, isbits=True) == '2.00 Kb'
    assert bytes_to_human(2097152, isbits=True) == '2.00 Mb'
    assert bytes_to_human(2147483648, isbits=True) == '2.00 Gb'
    assert bytes_to_human(1000000000000000000, isbits=True) == '10.00 Eb'
    assert bytes_to_human(1000000000000000000000, isbits=True) == '10.00 Zb'

# Generated at 2022-06-22 22:14:55.467311
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_good = ['aaa', 'aaA', 'aAa', 'AaA', 'Aaa', 'aa1', 'Aa1', 'aA1', '1aa', '1aA', '1Aa']
    list_expect = ['aaa', 'aaa', 'aaa', 'aaa', 'aaa', 'aa1', 'aa1', 'aa1', '1aa', '1aa', '1aa']
    list_lower = lenient_lowercase(list_good)
    list_lower == list_expect



# Generated at 2022-06-22 22:15:03.678835
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''Test to show various combinations
    '''
    # Test various units
    unit_list = [None, 'K', 'M', 'G', 'T', 'E', 'P', 'Z', 'Y']
    # Test specific unit
    unit_list.append('B')
    expected_list_bytes = ['1.00 Bytes', '0.98 Kilobytes', '0.96 Megabytes', '0.94 Gigabytes', '0.93 Terabytes', '0.92 Exabytes', '0.91 Petabytes', '0.90 Zettabytes', '0.89 Yottabytes', '1.00 Bytes']

# Generated at 2022-06-22 22:15:08.420676
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10.5M') == 10995116
    assert human_to_bytes('10.5Mb', isbits=True) == 131200
    assert human_to_bytes(1099511627776) == 1099511627776
    assert human_to_bytes('1099511627776B') == 1099511627776
    assert human_to_bytes(0) == 0
    assert human_to_bytes('0') == 0
    assert human_to_bytes('0.00') == 0
    assert human_to_bytes(0.00) == 0
    assert human_to_bytes('20 Mb') == 20971520
    assert human_to_

# Generated at 2022-06-22 22:15:17.661617
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # for bytes
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1MB', default_unit='M') == 1048576
    assert human_to_bytes('1.5MB') == 1572864
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5MB', isbits=True) == 1572864
    assert human_to_bytes('1.5MB', unit='B') == 1572864
    assert human_to_bytes('1Mb', isbits=True) == 131072
    assert human_to_bytes(1.5, unit='M') == 1572864
    assert human_to_bytes(1.5, unit='B') == 2

# Generated at 2022-06-22 22:15:27.098822
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:15:38.277110
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 ** 2) == '1.00 MB'
    assert bytes_to_human(1024 ** 3) == '1.00 GB'
    assert bytes_to_human(1024 ** 4) == '1.00 TB'
    assert bytes_to_human(1024 ** 5) == '1.00 PB'
    assert bytes_to_human(1024 ** 6) == '1.00 EB'
    assert bytes_to_human(1024 ** 7) == '1.00 ZB'
    assert bytes_to_human(1024 ** 8) == '1.00 YB'


# Generated at 2022-06-22 22:15:41.879211
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1,2,3, 'A', 'B']) == [1,2,3, 'A', 'B']


# Generated at 2022-06-22 22:15:50.759766
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:15:55.874480
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """Test function bytes_to_human."""
    from ansible.module_utils.facts.network.suse import bytes_to_human

# Generated at 2022-06-22 22:16:06.381172
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1000) == '1000 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    # when unit is None (default), unit will be detected automatically
    assert bytes_to_human(1024 * 1024 * 1024.0, unit=None) == '1.00 GB'
    # unit is case insensitive
    assert bytes_to_human(1048576 * 1024.0, unit='gB') == '1.00 TB'
    assert bytes_to_human(1048576 * 1024 * 1024.0, unit='Gb') == '1.00 PB'
    assert bytes_to_human(1048576 * 1024 * 1024 * 1024.0, unit='GB') == '1.00 EB'
    assert bytes

# Generated at 2022-06-22 22:16:14.655466
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:16:26.545202
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:16:38.630409
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list1 = ['A', 'B', 'C']
    list2 = [1, 2, 3]
    list3 = ['1', '2', '3']
    list4 = ['A', 'B', 2, 3]
    list5 = ['A', 'B', 3.2, 3.3]

    assert lenient_lowercase(list1) == ['a', 'b', 'c']
    assert lenient_lowercase(list2) == [1, 2, 3]
    assert lenient_lowercase(list3) == ['1', '2', '3']
    assert lenient_lowercase(list4) == ['a', 'b', 2, 3]
    assert lenient_lowercase(list5) == ['a', 'b', 3.2, 3.3]

# Generated at 2022-06-22 22:16:46.913353
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024, isbits=False) == '1.00 KBytes'
    assert bytes_to_human(1024, isbits=True) == '1.00 Kbits'
    assert bytes_to_human(1024000, isbits=True) == '1.00 Mbits'
    assert bytes_to_human(1024, unit='k') == '1.00 kBytes'
    assert bytes_to_human(1024000, unit='K') == '1.00 KBytes'
    assert bytes_to_human(1024, unit='K') == '0.00 KBytes'



# Generated at 2022-06-22 22:16:54.023749
# Unit test for function bytes_to_human
def test_bytes_to_human():
    import unittest
    class TestHumanBytes(unittest.TestCase):
        def test_human_bytes_typical_1(self):
            self.assertEqual(bytes_to_human(42), '42.00 Bytes')

        def test_human_bytes_typical_2(self):
            self.assertEqual(bytes_to_human(42, unit='b'), '42.00 b')

        def test_human_bytes_typical_3(self):
            self.assertEqual(bytes_to_human(42, unit='B'), '42.00 Bytes')

        def test_human_bytes_typical_4(self):
            self.assertEqual(bytes_to_human(42, unit='Mb'), '42.00 Mb')


# Generated at 2022-06-22 22:16:57.398173
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'C', 3, 4, object()]) == ['a', 'b', 'c', 3, 4, object()]

# Generated at 2022-06-22 22:16:59.650420
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 1, 2]) == ['a', 'b', 1, 2]


# Generated at 2022-06-22 22:17:05.572497
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert 1 == human_to_bytes('1b')
    assert 1024 == human_to_bytes('1K', default_unit='b')
    assert 25600 == human_to_bytes('25KB')
    assert 4194304 == human_to_bytes('4M')
    assert 8589934592 == human_to_bytes('8G')
    assert 16 == human_to_bytes('16')
    assert 16 == human_to_bytes(16)
    assert 16 == human_to_bytes('16M', default_unit='b')
    assert 16 == human_to_bytes(16, default_unit='B')


# Generated at 2022-06-22 22:17:12.573693
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("Running unit test for human_to_bytes")

# Generated at 2022-06-22 22:17:22.280283
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:17:27.376357
# Unit test for function human_to_bytes
def test_human_to_bytes():
    def h2b(s):
        return human_to_bytes(s)

    def assertEqual(s1, s2):
        v1 = h2b(s1)
        v2 = h2b(s2)
        if v1 != v2:
            raise Exception("Expected %s, got %s: %s != %s" % (v2, v1, s2, s1))

    assertEqual('1', 1)
    assertEqual('1b', 1)
    assertEqual('0.5b', 0.5)
    assertEqual('0.5', 0.5)
    assertEqual('0.5K', 0.5 * (1 << 10))
    assertEqual('0.5Kb', 0.5 * (1 << 10) * 8)

# Generated at 2022-06-22 22:17:36.128942
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:17:39.493087
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    l = ['test', 'Test', 'TEST', 1, 2, 'test1']
    assert lenient_lowercase(['test', 'Test', 'TEST', 1, 2, 'test1']) == ['test', 'test', 'test', 1, 2, 'test1']


# Generated at 2022-06-22 22:17:49.486887
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    from ansible.module_utils._text import to_text

    assert lenient_lowercase([]) == []
    assert lenient_lowercase('abc') == ['abc']
    assert lenient_lowercase(['A', 'B', 'c']) == ['a', 'b', 'c']

    # Check for unicode strings
    assert lenient_lowercase(['hé', 'A', 'B', 'c']) == ['hé', 'a', 'b', 'c']
    assert lenient_lowercase(['hé', 'A', 'B', 'c', 1]) == ['hé', 'a', 'b', 'c', 1]
    assert lenient_lowercase(['hé', [u'B', 'c'], 1]) == ['hé', [u'B', 'c'], 1]
    assert len

# Generated at 2022-06-22 22:17:57.573397
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:18:03.254607
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_input_list = ['abc', 1, 'Abc', True, None, ['aBc', 'String']]
    expected_result = ['abc', 1, 'abc', True, None, ['abc', 'String']]
    result_list = lenient_lowercase(test_input_list)
    assert result_list == expected_result, "test_lenient_lowercase()"


# Generated at 2022-06-22 22:18:11.205877
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('3.2G') == 3.2 * 1024 * 1024 * 1024
    assert human_to_bytes('3.2G', 'B') == 3.2 * 1024 * 1024 * 1024
    assert human_to_bytes('3.2G', 'b') == 3.2 * 8 * 1024 * 1024 * 1024
    assert human_to_bytes('3.2G', 'b', True) == 3.2 * 8 * 1024 * 1024 * 1024
    assert human_to_bytes('3.2GB') == 3.2 * 1024 * 1024 * 1024
    assert human_to_bytes('3.2GB', 'B') == 3.2 * 1024 * 1024 * 1024
    assert human_to_bytes('3.2G', isbits=True) == 3.2 * 1024 * 1024 * 1024

# Generated at 2022-06-22 22:18:12.891213
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(['ASdf', '414', [1, 2]])
    print(result)
    assert result == ['asdf', '414', [1, 2]]


# Generated at 2022-06-22 22:18:24.576292
# Unit test for function human_to_bytes
def test_human_to_bytes():
    def test(input, output, unit=None, isbits=False):
        if human_to_bytes(input, unit, isbits) != output:
            raise AssertionError("%s(%s, %s) != %s" % (human_to_bytes.__name__, repr(input), repr(unit), repr(output)))

    test('0', 0)
    test('1', 1)
    test('1.0', 1)
    test('1e2', 100)
    test('1M', 1048576)
    test('1.1M', 1146880)
    test('1.5M', 1572864)
    test('1m', 1048576, isbits=True)
    test('1.1m', 1146880, isbits=True)

# Generated at 2022-06-22 22:18:28.949604
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'C']) == ['a', 'B', 'C']
    assert lenient_lowercase([1, 'B', 'C']) == [1, 'B', 'C']
    assert lenient_lowercase([None, 'B', 'C']) == [None, 'B', 'C']



# Generated at 2022-06-22 22:18:32.721319
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lenient_lowercase_values = lenient_lowercase(['string', 'STRING', 'STRING'])
    assert lenient_lowercase_values == ['string', 'string', 'string']


# Generated at 2022-06-22 22:18:40.797590
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'b', 1, 2, 'c']) == ['a', 'b', 1, 2, 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 1, 'c']) == ['a', 'b', 1, 'c']


# Generated at 2022-06-22 22:18:52.161590
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='b') == '1.00 bits'
    assert bytes_to_human(1, isbits=True) == '1.00 bits'
    assert bytes_to_human(1, isbits=False) == '1.00 Bytes'
    assert bytes_to_human(1, unit=None) == '1.00 Bytes'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, unit='b') == '1.00 bits'
    assert bytes_to_human(10, unit='b') == '10.00 bits'
    assert bytes_to_human(10, unit='b') == '10.00 bits'

# Generated at 2022-06-22 22:19:00.276055
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes(1) == 1
    assert human_to_bytes(1.0) == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1.0M') == 1024 * 1024
    assert human_to_bytes('1MB') == 1024 * 1024
    assert human_to_bytes('1MB', default_unit='M') == 1024 * 1024

# Generated at 2022-06-22 22:19:10.801539
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:19:21.991956
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human(1099511627776) == '1.00 TB'
    assert bytes_to_human(1125899906842624) == '1.00 PB'
    assert bytes_to_human(1152921504606846976) == '1.00 EB'
    assert bytes_to_human(1180591620717411303424) == '1.00 ZB'

# Generated at 2022-06-22 22:19:31.846750
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(5) == 5
    assert human_to_bytes(5, 'b') == 5
    assert human_to_bytes(3, 'm') == 3
    assert human_to_bytes(3, 'mb') == 3 * 1024 * 1024
    assert human_to_bytes(3, 'Mb') == 3 * 1024 * 1024
    assert human_to_bytes(3, 'Mb', isbits=True) == 3 * 1024 * 1024
    assert human_to_bytes(3, 'Mb') == human_to_bytes('3Mb')
    assert human_to_bytes('3mb') == 3 * 1024 * 1024
    assert human_to_bytes('3MB') == 3 * 1024 * 1024
    assert human_to_bytes('3', 'Mb') == 3 * 1024 * 1024
    assert human_

# Generated at 2022-06-22 22:19:42.433883
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('100', 'M') == 100 * SIZE_RANGES['M']
    assert human_to_bytes('100M') == 100 * SIZE_RANGES['M']
    assert human_to_bytes('3.3G') == int(round(SIZE_RANGES['G'] * 3.3))

    try:
        human_to_bytes('100.100M')
        assert False
    except ValueError:
        assert True
    try:
        human_to_bytes('100.100')
        assert False
    except ValueError:
        assert True
    try:
        human_to_bytes('100Mb')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-22 22:19:51.489872
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KBytes'
    assert bytes_to_human(1025) == '1.00 KBytes'
    assert bytes_to_human(1048576) == '1.00 MBytes'
    assert bytes_to_human(1073741824) == '1.00 GBytes'
    assert bytes_to_human(1099511627776) == '1.00 TBytes'
    assert bytes_to_human(1125899906842624) == '1.00 PBytes'
    assert bytes_to_human(1152921504606846976) == '1.00 EBytes'
    assert bytes_to_human(1180591620717411303424) == '1.00 ZBytes'

# Generated at 2022-06-22 22:20:03.922542
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5KB') == 1536
    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('2MB') == 2097152
    assert human_to_bytes('2.5M') == 2621440
    assert human_to_bytes('2.5MB') == 2621440
    assert human_to_bytes('3G') == 3221225472
    assert human_to_bytes('3GB') == 3221225472

# Generated at 2022-06-22 22:20:15.389911
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(2048, isbits=False, unit='M') == '0.00 MB'
    assert bytes_to_human(2048, isbits=True, unit='K') == '16384.00 Kb'
    assert bytes_to_human(2048, isbits=False, unit='B') == '2048.00 Bytes'
    assert bytes_to_human(2048, isbits=False) == '2.00 KB'
    assert bytes_to_human(2048, isbits=True) == '16384.00 Kb'
    assert bytes_to_human(2048, isbits=True, unit='') == '16384.00 bits'

# Generated at 2022-06-22 22:20:18.982770
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    src = ['k1', 'V2', 'P3', 'P4', [5, 6, 7]]
    dst = ['k1', 'v2', 'p3', 'p4', [5, 6, 7]]
    assert lenient_lowercase(src) == dst
    return

# Generated at 2022-06-22 22:20:25.877180
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # testing bytes conversion
    assert bytes_to_human(1, False) == '1.00 Bytes'
    assert bytes_to_human(1, False, 'K') == '0.00 KB'
    assert bytes_to_human(1, False, 'M') == '0.00 MB'
    assert bytes_to_human(1, False, 'G') == '0.00 GB'
    assert bytes_to_human(1, False, 'T') == '0.00 TB'
    assert bytes_to_human(1, False, 'P') == '0.00 PB'
    assert bytes_to_human(1, False, 'E') == '0.00 EB'
    assert bytes_to_human(1, False, 'Z') == '0.00 ZB'

# Generated at 2022-06-22 22:20:28.122404
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([None, 'a', 'B', 'c']) == [None, 'a', 'b', 'c']

# Generated at 2022-06-22 22:20:38.624245
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Valid input
    result = bytes_to_human(10 * SIZE_RANGES["K"], unit='b')
    assert result == '10 Mb'

    # Valid input with other base
    result = bytes_to_human(10 * SIZE_RANGES["K"], isbits=True, unit='B')
    assert result == '10 Mb'

    # Valid input with different unit
    result = bytes_to_human(10 * SIZE_RANGES["K"], unit='B')
    assert result == '10 MB'

    # Input with invalid unit
    try:
        result = bytes_to_human(10 * SIZE_RANGES["K"], unit='X')
    except ValueError as e:
        assert "human_to_bytes() failed to convert 10.0 KB." in str(e)

# Generated at 2022-06-22 22:20:42.245725
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    x = ['a', 'A', 'a', 'A', None, 1, 2, 3, 'B', 'b', 'a']
    assert lenient_lowercase(x) == ['a', 'a', 'a', 'a', None, 1, 2, 3, 'b', 'b', 'a']


# Generated at 2022-06-22 22:20:51.380399
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    source_list = ['a11', True, 'b22', False, 'c33']
    target_list = ['a11', True, 'b22', False, 'c33']
    assert lenient_lowercase(source_list) == target_list

    source_list = ['A11', False, 'B22', True, 'C33']
    target_list = ['a11', False, 'b22', True, 'c33']
    assert lenient_lowercase(source_list) == target_list

# Generated at 2022-06-22 22:21:04.418766
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''Unit tests for function bytes_to_human'''
    assert '0 Bytes' == bytes_to_human(0)
    assert '1 Byte' == bytes_to_human(1)
    assert '2 Bytes' == bytes_to_human(2)
    assert '1023 Bytes' == bytes_to_human(1023)
    assert '1.00 KBytes' == bytes_to_human(1024)
    assert '1.00 MB' == bytes_to_human(1024 ** 2, unit='M')
    assert '1048576 MB' == bytes_to_human(1024 ** 2 * 1048576, unit='M')

    assert '1.00 B' == bytes_to_human(1049, unit='B')
    assert '9.77 KB' == bytes_to_human(10000, unit='K')

# Generated at 2022-06-22 22:21:10.563178
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b']) == ['a', 'b']
    assert lenient_lowercase(['A', 'B']) == ['a', 'b']
    assert lenient_lowercase(['a', 'b', 1, 2]) == ['a', 'b', 1, 2]
    assert lenient_lowercase(['A', 'B', 1, 2]) == ['a', 'b', 1, 2]

# Unit tests for function human_to_bytes

# Generated at 2022-06-22 22:21:17.098320
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(123) == '123 Bytes'
    assert bytes_to_human(1234) == '1.21 KB'
    assert bytes_to_human(12345) == '12.06 KB'
    assert bytes_to_human(1234567) == '1.18 MB'
    assert bytes_to_human(1234567890) == '1.15 GB'
    assert bytes_to_human(1234567890123) == '1.12 TB'
    assert bytes_to_human(1234567890123456) == '1.10 PB'
    assert bytes_to_human(1234567890123456789) == '1.07 EB'

# Generated at 2022-06-22 22:21:24.061775
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_data = [['a', 'A'], 'a', ['Ab', 'ab'], ['abC', ['AB', 'c']], 123, ['123']]
    test_result = [['a', 'a'], 'a', ['ab', 'ab'], ['abc', ['ab', 'c']], 123, ['123']]
    for i in range(len(test_data)):
        assert lenient_lowercase(test_data[i]) == test_result[i]



# Generated at 2022-06-22 22:21:32.242123
# Unit test for function bytes_to_human
def test_bytes_to_human():
    v = human_to_bytes('2K')
    assert v == 2048
    assert bytes_to_human(v) == '2.00 KBytes', "Wrong bytes_to_human() conversion"

    v = human_to_bytes('2KB')
    assert v == 2 * SIZE_RANGES['K']
    assert bytes_to_human(v) == '2.00 KB', "Wrong bytes_to_human() conversion"

    v = human_to_bytes('2KBytes')
    assert v == 2 * SIZE_RANGES['K']
    assert bytes_to_human(v) == '2.00 KB', "Wrong bytes_to_human() conversion"

    v = human_to_bytes('2M')
    assert v == 2 * SIZE_RANGES['M']
    assert bytes_

# Generated at 2022-06-22 22:21:43.939688
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes', "Unit test failed. Expected '1.00 Bytes' but returned '%s'" % bytes_to_human(1)
    assert bytes_to_human(1024) == '1.00 KB', "Unit test failed. Expected '1.00 KB' but returned '%s'" % bytes_to_human(1024)
    assert bytes_to_human(1024, unit='k') == '1.00 KB', "Unit test failed. Expected '1.00 KB' but returned '%s'" % bytes_to_human(1024, unit='k')

# Generated at 2022-06-22 22:21:48.826814
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 'bob', True]) == [1, 'bob', True]



# Generated at 2022-06-22 22:21:58.883556
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # This test uses function bytes_to_human to convert bytes to human readable format.
    # The byte_to_human function uses dictionary which is defined as global variable.
    assert bytes_to_human(66) == '66.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human(1099511627776) == '1.00 TB'
    assert bytes_to_human(1125899906842624) == '1.00 PB'
    assert bytes_to_human(1152921504606846976) == '1.00 EB'

# Generated at 2022-06-22 22:22:06.484122
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Positive case
    human_size = bytes_to_human(1024)
    if human_size != '1 KBytes':
        raise AssertionError('Function bytes_to_human returns unknown value: %s' % human_size)

    # Negative case
    human_size = bytes_to_human(83223300, unit='M')
    if human_size != '79 MBytes':
        raise AssertionError('Function bytes_to_human returns unknown value: %s' % human_size)

