

# Generated at 2022-06-22 22:12:11.730864
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(2 ** 10) == '1.00 KB'
    assert bytes_to_human(2 ** 20) == '1.00 MB'
    assert bytes_to_human(2 ** 30) == '1.00 GB'
    assert bytes_to_human(2 ** 40) == '1.00 TB'
    assert bytes_to_human(2 ** 50) == '1.00 PB'
    assert bytes_to_human(2 ** 60) == '1.00 EB'
    assert bytes_to_human(2 ** 70) == '1.00 ZB'
    assert bytes_to_human(2 ** 80) == '1.00 YB'

# Generated at 2022-06-22 22:12:14.517896
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    t = [1, 'hello', 'WoRlD', 'finAl', 'FINAL']
    assert lenient_lowercase(t) == [1, 'hello', 'world', 'finAl', 'FINAL']


# Generated at 2022-06-22 22:12:16.017024
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['', 1, 'aA']) == ['', 1, 'aa']

# Generated at 2022-06-22 22:12:19.325443
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['ABC', 'cDE', 123, 3.14]) == ['abc', 'cde', 123, 3.14]


# Generated at 2022-06-22 22:12:24.347397
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M', 'B') == 1048576
    assert human_to_bytes('10M', 'MB') == 10485760
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    try:
        human_to_bytes('10b', isbits=True)
    except ValueError:
        pass
    else:
        assert False


if __name__ == "__main__":
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-22 22:12:29.681483
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # lowercase
    assert lenient_lowercase(['GET', 'POST', 'PUT']) == ['get', 'post', 'put']

    # pass non-string type
    assert lenient_lowercase(['GET', 123]) == ['get', 123]

    # nil
    assert lenient_lowercase([]) == []



# Generated at 2022-06-22 22:12:41.227176
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:12:49.500647
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test for bytes
    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('2.5M') == 262144
    assert human_to_bytes('0.5M') == 512000
    assert human_to_bytes('2.5MB') == 262144
    assert human_to_bytes('2.5MB', default_unit='M') == 262144
    # default_unit parameter added to be able to accept values that are not terminated with a letter.
    assert human_to_bytes('2.5', default_unit='M') == 262144
    assert human_to_bytes('2.5M') == 262144
    assert human_to_bytes('2.5Mb') == 262144
    assert human_to_bytes('2.5BB') == 2

# Generated at 2022-06-22 22:13:01.129010
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test1 = []
    test2 = ['', '', '']
    test3 = ['1', '2', '3']
    test4 = [123, 456, 789]
    test5 = ['abc', 'abc', 'abc']
    test6 = [123, 456, 'abc']
    test7 = ['Abc', 'Abc', 'Abc']
    test8 = ['ABC', 1, 2, 3]
    test9 = ['', 'abC', 678, 'XYZ']

    assert lenient_lowercase(test1) == test1
    assert lenient_lowercase(test2) == test2
    assert lenient_lowercase(test3) == test3
    assert lenient_lowercase(test4) == test4

# Generated at 2022-06-22 22:13:08.030849
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lc_tests = [
        (['asdf', 'ghjkl', 'Foo', 'BAR'], ['asdf', 'ghjkl', 'foo', 'bar']),
        (['asdf', 'ghjkl', 123, 456.78], ['asdf', 'ghjkl', 123, 456.78]),
    ]
    for (test, expected) in lc_tests:
        assert(lenient_lowercase(test) == expected)

# Generated at 2022-06-22 22:13:14.208391
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [1, "TEST", ("TUPLE", "OF", "TEST"), ["LIST", "OF", "TEST"], "TEST",
                 {"dict": {"of": [{"test": {"nested": ("TEST",)}}]}}]
    expect_list = [1, "test", ("TUPLE", "OF", "TEST"), ["LIST", "OF", "TEST"], "test",
                   {"dict": {"of": [{"test": {"nested": ("TEST",)}}]}}]

    assert expect_list == lenient_lowercase(test_list)

# Generated at 2022-06-22 22:13:24.135867
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.1M') == 1105920
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1.1Mb', isbits=True) == 1105920
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1.1Mb') == 1105920
    assert human_to_bytes('1.2', default_unit='M') == 1258291
    assert human_to_bytes('1.2', default_unit='K') == 1200

# Generated at 2022-06-22 22:13:32.484059
# Unit test for function bytes_to_human
def test_bytes_to_human():
    tests = [
        (1000, '1000.00 Bytes'),
        (1000000, '1000.00 KB'),
        (100000000, '100.00 MB'),
        (100000000000, '100.00 GB'),
        (100000000000000, '100.00 TB'),
        (100000000000000000, '100.00 PB'),
        (100000000000000000000, '100.00 EB'),
        (100000000000000000000000, '100.00 ZB'),
        (100000000000000000000000000, '100.00 YB'),
    ]
    for number, result in tests:
        assert(bytes_to_human(number) == result)



# Generated at 2022-06-22 22:13:41.518260
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(512) == '512.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, isbits=True) == '1.00 Kb'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024, isbits=True) == '1.00 Mb'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024, isbits=True) == '1.00 Gb'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'

# Generated at 2022-06-22 22:13:45.482923
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    from ansible.module_utils._text import to_bytes

    lst = [
        "ALL",
        [["One", "Two", "Three"], ["Four", "Five", "six"]],
        "seven"
    ]

    assert lenient_lowercase(lst) == [
        "all",
        [["One", "Two", "Three"], ["Four", "Five", "six"]],
        "seven"
    ]
    assert bytes == type(lenient_lowercase(lst)[0])


# Generated at 2022-06-22 22:13:57.024510
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test with numbers and 'B' bytes suffix
    assert human_to_bytes('0B') == 0
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('10Kb') == 12800
    assert human_to_bytes('10Kb', isbits=True) == 12800
    assert human_to_bytes('10MB', isbits=True) == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10Mb') == 12582912
    assert human_to_bytes('10Mb', isbits=True) == 12582912
    assert human_to_bytes('10GB') == 10737418240

# Generated at 2022-06-22 22:14:03.379896
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # bytes
    assert bytes_to_human(10) == '10 bytes'
    assert bytes_to_human(0) == '0 bytes'
    assert bytes_to_human(10, unit='B') == '10 bytes'
    assert bytes_to_human(0, unit='B') == '0 bytes'
    assert bytes_to_human(10, unit='bytes') == '10 bytes'
    assert bytes_to_human(0, unit='bytes') == '0 bytes'
    # kilobytes
    assert bytes_to_human(1024, unit='B') == '1024 bytes'
    assert bytes_to_human(1048576, unit='B') == '1.00 MB'
    assert bytes_to_human(1048576, unit='KB') == '1048576 bytes'

# Generated at 2022-06-22 22:14:08.629944
# Unit test for function human_to_bytes
def test_human_to_bytes():
    def validate(number, expected):
        try:
            actual = human_to_bytes(number)
        except Exception as e:
            actual = e
        assert actual == expected, "Expected %r, but got %r" % (expected, actual)

    def validate_bits(number, expected):
        try:
            actual = human_to_bytes(number, isbits=True)
        except Exception as e:
            actual = e
        assert actual == expected, "Expected %r, but got %r" % (expected, actual)

    validate("10M", 10485760)
    validate("-10M", -10485760)
    validate("10Mb", 10485760)
    validate("10MB", ValueError("expect Bb or bit"))
    validate("10", 10)

# Generated at 2022-06-22 22:14:18.631946
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.12M', None) == 1179648
    assert human_to_bytes('1.12M') == 1179648
    assert human_to_bytes('1.12M', 'MB') == 1179648
    assert human_to_bytes('1.12M', 'Mb') == 1179648
    assert human_to_bytes('1.12K', 'MB') == 1120

    assert human_to_bytes('1.12Mb') == 1179648
    assert human_to_bytes('1.12Mb', 'MB') == 1179648
    assert human_to_bytes('1.12Mb', 'Mb') == 1179648
    assert human_to_bytes('1.12Kb', 'MB') == 1120


# Generated at 2022-06-22 22:14:23.687011
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['one', 'tWo', 'tHree']) == ['one', 'two', 'three']
    assert lenient_lowercase(['One', 'three', 'five']) == ['one', 'three', 'five']
    assert lenient_lowercase(['One', 3, 'five']) == ['one', 3, 'five']


# Generated at 2022-06-22 22:14:29.433825
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10000, False) == '9.77 KBytes'
    assert bytes_to_human(10000, True) == '78.125 Kbits'
    assert bytes_to_human(10000, False, 'B') == '10000 B'
    assert bytes_to_human(10000, False, 'k') == '9.77 KB'
    assert bytes_to_human(10000, False, 'K') == '9.77 KB'
    assert bytes_to_human(10000, False, 'M') == '0.01 MB'


# Generated at 2022-06-22 22:14:34.432495
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input = ['aA', 1, 2, '3', 'asdkfjlASKJdf']
    expected_output = ['aa', 1, 2, '3', 'asdkfjlaskjdf']
    assert lenient_lowercase(input) == expected_output



# Generated at 2022-06-22 22:14:39.907448
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # If a list element is a string, it should be lowercased
    assert lenient_lowercase(['UPPER', 'MiXeD', 'lOwEr']) == ['upper', 'mixed', 'lower']

    # If a list element is not a string, it should be returned unchanged
    assert lenient_lowercase(['UPPER', object(), 'lOwEr']) == ['upper', object(), 'lower']



# Generated at 2022-06-22 22:14:51.543048
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Examples:
    human_to_bytes('1Mb') returns 1048576
    human_to_bytes('1Mb', isbits=True) returns 1048576
    human_to_bytes('1Mb', isbits=False) raises ValueError
    '''
    # Bytes test
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1B', isbits=False) == 1
    assert human_to_bytes('1b', isbits=False) == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1B', isbits=True) == 8
    # Bits test
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1Mb') == 1048

# Generated at 2022-06-22 22:14:59.092957
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Create a list with non-string values
    test_list = ['abc', 12, 34, '123']
    # Returned list
    r_list = lenient_lowercase(test_list)
    # Expected returned list
    e_list = ['abc', 12, 34, '123']

    if r_list != e_list:
        return False

    return True


# Generated at 2022-06-22 22:15:10.370610
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('100') == 100
    assert human_to_bytes('100.5') == 100
    assert human_to_bytes('100.5K') == 102400
    assert human_to_bytes('100.5KB') == 102400
    assert human_to_bytes('100.5Kb') == 102400
    assert human_to_bytes('100.5kb', isbits=True) == 102400
    assert human_to_bytes('100.5B') == 100
    assert human_to_bytes('100.5b', isbits=True) == 100
    assert human_to_bytes('100.5') == 100
    assert human_to_bytes('100.5t') == 1125899906842624
    assert human_to_bytes('100.5T') == 1099511627776
    assert human

# Generated at 2022-06-22 22:15:13.688559
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase([1]) == [1]

# Generated at 2022-06-22 22:15:25.206556
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' basic functions tests'''
    assert human_to_bytes(1, 'B') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes(1, 'Kb') == 1024
    assert human_to_bytes(1, 'Kb', isbits=True) == 1024
    assert human_to_bytes(1, 'Mb') == 1048576
    assert human_to_bytes(1, 'Mb', isbits=True) == 1048576
    assert human_to_bytes(1, 'Gb') == 1073741824
    assert human_to

# Generated at 2022-06-22 22:15:33.035144
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["1", "9", "B"]) == ["1", "9", "b"]
    assert lenient_lowercase(["1", "9", "B", 10]) == ["1", "9", "b", 10]
    try:
        lenient_lowercase([1, 9, "B"])
    except Exception:
        pass
    else:
        raise AssertionError("Failed to raise exception on non-strings")


# Generated at 2022-06-22 22:15:42.801982
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert(bytes_to_human(1048576) == '1.00 MB')
    assert(bytes_to_human(1048576, isbits=True) == '8.00 Mb')
    assert(bytes_to_human(1048576, isbits=True, unit='m') == '8388608.00 Mb')
    assert(bytes_to_human(1048576, isbits=True, unit='M') == '8.00 Mb')
    assert(bytes_to_human(1048576, unit='M') == '1.00 MB')
    assert(bytes_to_human(1073741824, isbits=True, unit='M') == '8.00 Gb')
    assert(bytes_to_human(1073741824, unit='M') == '1.00 GB')

# Generated at 2022-06-22 22:15:51.383688
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1024, default_unit='bytes') == 1024
    assert human_to_bytes(102400, default_unit='bytes') == 102400
    assert human_to_bytes('102400', default_unit='bytes') == 102400
    assert human_to_bytes('1024', default_unit='bytes') == 1024
    assert human_to_bytes('1024', default_unit='kilobytes') == 1048576
    assert human_to_bytes('1024', default_unit='MB') == 1048576
    assert human_to_bytes('1024', default_unit='kb') == 1048576
    assert human_to_bytes('1024kb') == 1048576
    assert human_to_bytes('1024mb') == 1073741824
    assert human_to_bytes('1024gb') == 1073741824 * 1024

# Generated at 2022-06-22 22:15:54.018684
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['string', 10]
    expected_list = ['string', 10]
    result = lenient_lowercase(test_list)
    assert result == expected_list



# Generated at 2022-06-22 22:16:04.517345
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:16:11.338301
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]
    assert lenient_lowercase(['A', 'B', 'C', '1']) == ['a', 'b', 'c', '1']
    assert lenient_lowercase(['1']) == ['1']
    print('Test lenient_lowercase: PASS')



# Generated at 2022-06-22 22:16:23.587236
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976
    assert human_to_bytes('1Z') == 1180591620717411303424
    assert human_to_bytes('1Y') == 1208925819614629174706176
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to

# Generated at 2022-06-22 22:16:29.669760
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(2, isbits=False, unit='K') == '2.00 KB'
    assert bytes_to_human(2048, isbits=False, unit='B') == '2.00 KB'
    assert bytes_to_human(int(2048*8), isbits=True, unit='K') == '1.00 KB'
    assert bytes_to_human(int(2048*8), isbits=True, unit='M') == '0.00 MB'



# Generated at 2022-06-22 22:16:34.299107
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['foo', 42]) == ['foo', 42]
    assert lenient_lowercase(['FOO', 'BAR']) == ['foo', 'bar']



# Generated at 2022-06-22 22:16:43.416272
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, isbits=True) == '1.00 Kb'
    assert bytes_to_human(1024, unit='B') == '1.00 KB'
    assert bytes_to_human(1024, unit='KB') == '1.00 KB'
    assert bytes_to_human(1024, unit='K') == '1.00 KB'
    assert bytes_to_human(1024, unit='kB') == '1.00 Kb'
    assert bytes_to_human(1024, unit='Kb') == '1.00 Kb'
    assert bytes_to_human(1024, unit='K') == '1.00 KB'
    assert bytes_to

# Generated at 2022-06-22 22:16:45.366072
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["ABC", 1, [2, 3], "abcd"]) == ["abc", 1, [2, 3], "abcd"]

# Generated at 2022-06-22 22:16:49.989795
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(["A", "B", "C"]) == ["a", "b", "c"]
    assert lenient_lowercase(["A", 1, "C"]) == ["a", 1, "c"]
    assert lenient_lowercase(["A", 1, "C", ""]) == ["a", 1, "c", ""]



# Generated at 2022-06-22 22:16:52.671606
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', None]) == ['a', 'b', None]

# Generated at 2022-06-22 22:17:03.121336
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes(3, 'K') == 3 * 1024
    assert human_to_bytes('10M') == 10 * 1024 * 1024
    assert human_to_bytes('10Mb', isbits=True) == 10 * 1024 * 1024
    assert human_to_bytes('10MB', isbits=False) == 10 * 1024 * 1024
    assert human_to_bytes('10MB', isbits=True) == 10 * 8 * 1024 * 1024
    assert human_to_bytes('10M', isbits=True) == 10 * 8 * 1024 * 1024
    # Conversion fails if 'b' is passed as a byte identifier

# Generated at 2022-06-22 22:17:06.767320
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['hElLo', 'WorLd']) == ['hello', 'world']
    assert lenient_lowercase(['hello', 124]) == ['hello', 124]
    assert lenient_lowercase(['hElLo', ['WorLd']]) == ['hello', ['WorLd']]


# Generated at 2022-06-22 22:17:17.964643
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes('10M', 'B') == human_to_bytes(10, 'M')
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'M', isbits=True) == 10485760
    assert human_to_bytes('1Gb', isbits=True) == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1T') == 1099511627776

# Generated at 2022-06-22 22:17:25.479557
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2048', 'B') == 2048
    assert human_to_bytes('1K', 'B') == 1024
    assert human_to_bytes('2M', 'B') == 2097152
    assert human_to_bytes('1G', 'B') == 1073741824
    assert human_to_bytes('1E', 'B') == 1152921504606846976
    assert human_to_bytes('1Z', 'B') == 1180591620717411303424
    assert human_to_bytes('1Y', 'B') == 1208925819614629174706176
    assert human_to_bytes('1') == 1

    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1kb', isbits=True) == 1000


# Generated at 2022-06-22 22:17:34.977429
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 EB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 ZB'

# Generated at 2022-06-22 22:17:37.862429
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input = [1, 2, 'a', 'b', u'c', u'd']
    expected = [1, 2, 'a', 'b', 'c', 'd']
    result = lenient_lowercase(input)
    assert(result == expected)


# Unit tests for human_to_bytes

# Generated at 2022-06-22 22:17:44.207015
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576

    try:
        human_to_bytes('1Mb', isbits=False)
        assert False, '1Mb was passed and not rised the ValueError exception'
    except ValueError:
        pass

    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1Mb', default_unit='b', isbits=False) == 1048576
    assert human_to_bytes('1M', default_unit='b') == 1048576
    assert human_to_bytes('1K', default_unit='b') == 1024

# Generated at 2022-06-22 22:17:55.610101
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    txt = 'This is string only test'
    ansible_string = 'this is string only test'
    assert ansible_string == lenient_lowercase(txt)
    num = 123
    assert num == lenient_lowercase(num)

# Generated at 2022-06-22 22:18:06.410452
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={
        'old': dict(type='list', default=[]),
    })

    cases = [
        {
            'old': ['A', 'B', 'C'],
            'new': ['a', 'b', 'c'],
        },
        {
            'old': ['A', 1, 'C'],
            'new': ['a', 1, 'c'],
        },
    ]

    for testcase in cases:
        new = lenient_lowercase(testcase['old'])
        if new != testcase['new']:
            module.fail_json(msg='test case %s failed: expected %s, got %s' % (testcase['old'], testcase['new'], new))

   

# Generated at 2022-06-22 22:18:12.179590
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["Hello", "WORLD"]) == ["hello", "world"]
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase(["Hello", 5]) == ["hello", 5]
    assert lenient_lowercase(5) == 5

# Generated at 2022-06-22 22:18:23.688731
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1, 'byte') == 1
    assert human_to_bytes(1, 'Byte') == 1
    assert human_to_bytes(1, 'B') == 1
    assert human_to_bytes(1, 'b') == 1
    assert human_to_bytes(1, 'bytes') == 1
    assert human_to_bytes(1, 'Bytes') == 1
    assert human_to_bytes(1, 'Bits') == 1
    assert human_to_bytes(1, 'Bits') == 1
    assert human_to_bytes(1, 'bits') == 1
    assert human_to_bytes(1, 'bit') == 1
    assert human_to_bytes(1, 'b') == 1

    assert human_to_bytes(1, 'kB') == 1024
    assert human_to

# Generated at 2022-06-22 22:18:28.077128
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['AAA', 'BBB', ['CCC'], {'DDD': 'EEE'}, 'FFF']) \
        == ['aaa', 'bbb', ['CCC'], {'DDD': 'EEE'}, 'fff']



# Generated at 2022-06-22 22:18:34.638196
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [1, 'FOO', 'bar']
    assert lst == lenient_lowercase(lst)
    lst = ['FOO', 'bar']
    assert ['FOO', 'bar'] == lenient_lowercase(lst)
    lst = [1, 'FOO', 'bar']
    assert [1, 'foo', 'bar'] == lenient_lowercase(lst)


# Generated at 2022-06-22 22:18:44.726821
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # convert bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('2B') == 2
    assert human_to_bytes('1.1B') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5k') == 1536
    assert human_to_bytes('1.1K') == 1152
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5m') == 1572864
    assert human_to_bytes('1.1M') == 1179648
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5g') == 1610612736
    assert human_to_bytes

# Generated at 2022-06-22 22:18:46.982145
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 1, 'B']) == ['a', 1, 'b']



# Generated at 2022-06-22 22:18:51.837625
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['AbC', '123', None, 1, True, False, 'def', 'ghi', 123, None]
    lower_case_result = lenient_lowercase(test_list)
    assert lower_case_result == ['abc', '123', None, 1, True, False, 'def', 'ghi', 123, None]

# Generated at 2022-06-22 22:18:53.862232
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['1', 1, 'a', 'A']) == ['1', 1, 'a', 'A']

# Generated at 2022-06-22 22:19:01.311430
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # For bytes
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1000) == '1000.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KBytes'
    assert bytes_to_human(2048) == '2.00 KBytes'
    assert bytes_to_human(2048000) == '2000.00 KBytes'
    assert bytes_to_human(2**20) == '1.00 MBytes'
    assert bytes_to_human(2**30) == '1.00 GBytes'
    assert bytes_to_human(2**40) == '1.00 TBytes'

# Generated at 2022-06-22 22:19:12.624567
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', isbits=True) == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10MB', isbits=True) == 10485760
    assert human_to_bytes('10 MB', isbits=True) == 10485760
    assert human_to_bytes('1K', isbits=True) == 1024
    assert human_to_bytes('1KB', isbits=True) == 1024

# Generated at 2022-06-22 22:19:14.329764
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'Test']) == [1, 'test']


# Generated at 2022-06-22 22:19:23.740261
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import assert_raises

    # test bytes
    assert human_to_bytes('2048') == 2048
    assert human_to_bytes('2.5K') == 2560
    assert human_to_bytes('2.5kB') == 2560
    assert human_to_bytes('2.5Kb') == 2560
    assert human_to_bytes('2.5K', isbits=True) == 2560
    assert human_to_bytes('2.5Kb', isbits=True) == 2560
    assert human_to_bytes(30) == 30

    # test bits
    assert human_to_bytes('2048b') == 2048
    assert human_to_bytes('2.5Kb') == 2560
    assert human_to_bytes('2.5kB') == 2048
    assert human_to

# Generated at 2022-06-22 22:19:36.146387
# Unit test for function bytes_to_human
def test_bytes_to_human():

    assert (bytes_to_human(10, False) == '10 Bytes')
    assert (bytes_to_human(10, True) == '10 bits')
    assert (bytes_to_human(10, False, 'b') == '10 Bytes')
    assert (bytes_to_human(10, True, 'b') == '10 bits')
    assert (bytes_to_human(10240, False) == '10.00 KB')
    assert (bytes_to_human(10240, True) == '10.00 Kb')
    assert (bytes_to_human(10240, True, 'b') == '10240 bits')
    assert (bytes_to_human(10240, False, 'B') == '10240 Bytes')

# Generated at 2022-06-22 22:19:46.064909
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(0.5) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(10 * 1024 * 1024) == '10.00 MB'
    assert bytes_to_human(1000 * 1024 * 1024) == '1000.00 MB'
    assert bytes_to_human(1000 * 1024 * 1024 * 1024) == '1.00 TB'

# Generated at 2022-06-22 22:19:53.706741
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:20:05.790481
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Verifying 1KB - 2M, steps of 1KB
    for i in range(1024, 2 ** 21, 1024):
        bytes_to_human(i)
    # Verifying 1Kb - 2Mb, steps of 1Kb
    for i in range(1000, 2 ** 21, 1000):
        bytes_to_human(i, isbits=True)
    # Verifying 1KB - 2M in bytes unit
    for i in range(1024, 2 ** 21, 1024):
        bytes_to_human(i, unit='Bytes')
    # Verifying 1KB - 2M in KB unit
    for i in range(1, 2 ** 11, 1):
        bytes_to_human(i, unit='KB')
    # Verifying 1Kb - 2Mb in Kb unit

# Generated at 2022-06-22 22:20:09.337723
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lower = lenient_lowercase(['A', 'B', 1, 2])
    assert lower == ['a', 'b', 1, 2]

# Generated at 2022-06-22 22:20:18.755726
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(0, "KB") == '0 KB'
    assert bytes_to_human(0, "b") == '0 bits'
    assert bytes_to_human(0, "bits") == '0 bits'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1, "KB") == '1 KB'
    assert bytes_to_human(1, "Mb") == '1 Mb'
    assert bytes_to_human(1, "bits") == '1 bits'
    assert bytes_to_human(1, "B") == '1 Bytes'
    assert bytes_to_human(1, "b") == '1 bits'

# Generated at 2022-06-22 22:20:25.807426
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024, unit='K') == '1024.00 KB'
    assert bytes_to_human(1024 * 1024 / 2, unit='K') == '512.00 KB'
    assert bytes_to_human(1024 * 1024 * 1024 * 2, unit='K') == '2.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 2) == '2.00 GB'
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1024, unit='B') == '1024.00 Bytes'
    assert bytes_to_human(1024, unit='B') == '1024.00 Bytes'

# Generated at 2022-06-22 22:20:28.425822
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(['A', 'B', 3, '4', 5])
    assert result == ['a', 'b', 3, '4', 5]

# Generated at 2022-06-22 22:20:36.172566
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1023) == '1023.00 Bytes'
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1234567890) == '1.15 GB'
    assert bytes_to_human(2048, unit='m') == '0.00 MB'
    assert bytes_to_human(1024, unit='m') == '1.00 MB'

    # human to bytes
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('1.1B') == 1
    assert human_to_bytes('3M') == 3145728
    assert human_to_bytes('3m') == 3

# Generated at 2022-06-22 22:20:45.067724
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('3') == 3
    assert human_to_bytes(3) == 3
    assert human_to_bytes('3b') == 3
    assert human_to_bytes(3, isbits=True) == 3
    assert human_to_bytes('3B') == 3
    assert human_to_bytes('3B', isbits=True) == 3
    assert human_to_bytes('-3B') == -3
    assert human_to_bytes('1K', default_unit='B') == 1000
    assert human_to_bytes('2k', default_unit='b') == 2000
    assert human_to_bytes('3k', default_unit='b', isbits=False) == 3000
    assert human_to_bytes('1M', default_unit='b') == 1000000
    assert human_to_

# Generated at 2022-06-22 22:20:55.444678
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(5) == '5 Bytes'
    assert bytes_to_human(1025) == '1.00 KB'
    assert bytes_to_human(1024*1024) == '1.00 MB'
    assert bytes_to_human(1024*1024*1024) == '1.00 GB'
    assert bytes_to_human(1024*1024*1024*1024) == '1.00 TB'
    assert bytes_to_human(1024*1024*1024*1024*1024) == '1.00 PB'
    assert bytes_to_human(1024*1024*1024*1024*1024*1024) == '1.00 EB'

# Generated at 2022-06-22 22:21:05.861112
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1024, isbits=True) == "1.00 Kb"
    assert bytes_to_human(1000) == "1000.00 Bytes"
    assert bytes_to_human(1000, isbits=True) == "1000.00 bits"
    assert bytes_to_human(1024 * 1024 * 6.1) == "6.10 MB"
    assert bytes_to_human(1024 * 1024 * 6.1, isbits=True) == "6.10 Mb"
    assert bytes_to_human(1024 * 1024 * 1024 * 7.1) == "7.10 GB"
    assert bytes_to_human(1024 * 1024 * 1024 * 7.1, isbits=True) == "7.10 Gb"
    assert bytes_

# Generated at 2022-06-22 22:21:14.747224
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(999) == '999.00 Bytes'
    assert bytes_to_human(132300) == '129.88 KB'
    assert bytes_to_human(2334234) == '2.25 MB'
    assert bytes_to_human(2334234234) == '2.15 GB'
    assert bytes_to_human(2334234234234) == '2.05 TB'
    assert bytes_to_human(2334234234234234) == '1.95 PB'
    assert bytes_to_human(2334234234234234234) == '1.85 EB'
    assert bytes_to_human(2334234234234234234234) == '1.74 ZB'
    assert bytes_to_

# Generated at 2022-06-22 22:21:23.208976
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest

    # Base unit: B - byte
    # Variants: M, K and b - bits
    parametrize = pytest.mark.parametrize


# Generated at 2022-06-22 22:21:26.894347
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'ABC', 'XYZ']) == [1, 'abc', 'xyz']
    assert lenient_lowercase('ABC') == 'abc'
    assert lenient_lowercase(None) is None

# Generated at 2022-06-22 22:21:30.517985
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 3, 'Dog', 'cat', 'CAT']) == [1, 2, 3, 'Dog', 'cat', 'cat']


# Generated at 2022-06-22 22:21:41.315984
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import re
    import pytest
    from sys import version_info

    if version_info[0] == 3:  # pragma: no cover
        long = int  # pylint: disable=redefined-builtin,invalid-name

    def assert_conversion(expected, input_value, isbits=False):
        assert expected == human_to_bytes(input_value, isbits=isbits), 'Input value: %s. isbits: %s' % (input_value, isbits)

    def assert_conversion_raises(input_value, exception_regexp=None, isbits=False):
        with pytest.raises(Exception) as excinfo:
            human_to_bytes(input_value, isbits=isbits)
        if exception_regexp is not None:
            assert re.search

# Generated at 2022-06-22 22:21:53.413127
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    # Test normal case
    test_data = ["lower", "UPPER", "Camel", "Camel", "Camel", "Underscore_", "With-Hyphen"]
    expected_result = ["lower", "upper", "camel", "camel", "camel", "underscore_", "with-hyphen"]
    assert lenient_lowercase(test_data) == expected_result

    # Test with exception
    test_data = ["lower", "UPPER", "Camel", "Camel", "Camel", "Underscore_", "With-Hyphen", 42]
    expected_result = ["lower", "upper", "camel", "camel", "camel", "underscore_", "with-hyphen", 42]
    assert lenient_lowercase(test_data) == expected_result



# Generated at 2022-06-22 22:21:56.516713
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['HELLO', 'world', '1', '2', None, True, False]

    assert lenient_lowercase(test_list) == ['hello', 'world', '1', '2', None, True, False]

# Generated at 2022-06-22 22:22:00.825137
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['The', 'quick', 'brown', 'fox', 'Jumps']) == ['the', 'quick', 'brown', 'fox', 'Jumps']
    assert lenient_lowercase([123, 'quick', 'brown']) == [123, 'quick', 'brown']


# Unit tests for the function human_to_bytes