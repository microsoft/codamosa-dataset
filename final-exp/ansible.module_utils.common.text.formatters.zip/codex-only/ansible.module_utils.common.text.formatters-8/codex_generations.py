

# Generated at 2022-06-22 22:12:08.735239
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(123) == '123.00 Bytes'
    assert bytes_to_human(1023) == '1023.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1025) == '1.01 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 + 1) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 + 1024) == '1.01 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 + 1) == '1.00 GB'

# Generated at 2022-06-22 22:12:10.733506
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['abc', 'DEF', 1, 2]

    assert lenient_lowercase(test_list) == ['abc', 'def', 1, 2]

# Generated at 2022-06-22 22:12:18.179735
# Unit test for function human_to_bytes
def test_human_to_bytes():
    errors = []

    test_number = {
        '1K': 1000,
        '10K': 10000,
        '10M': 10000000,
        '1G': 1000000000,
        '1T': 1000000000000,
        '1P': 1000000000000000,
        '1E': 1000000000000000000,
        '1Z': 1000000000000000000000,
        '1Y': 1000000000000000000000000,
        '10Kb': 12500,
        '1Mb': 1000000,
        '1Gb': 1000000000,
        '1Tb': 1000000000000,
        '1Pb': 1000000000000000,
        '1Eb': 1000000000000000000,
        '1Zb': 1000000000000000000000,
        '1Yb': 1000000000000000000000000,
    }


# Generated at 2022-06-22 22:12:29.013545
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    data = []

    data.append(lenient_lowercase(['ABC', 1, 'def']))
    assert data[0] == ['abc', 1, 'def']

    data.append(lenient_lowercase(['abc', 1, 'DEF']))
    assert data[1] == ['abc', 1, 'DEF']

    data.append(lenient_lowercase(['ABC', 1, 'DEF']))
    assert data[2] == ['ABC', 1, 'DEF']

    data.append(lenient_lowercase(['AbC', 1, 'dEf']))
    assert data[3] == ['AbC', 1, 'dEf']

    data.append(lenient_lowercase(['ABC', 'XYZ']))
    assert data[4] == ['abc', 'xyz']


# Generated at 2022-06-22 22:12:40.700512
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # number of bytes in 1TB expressed in base 2
    TB_base2_in_bytes = 1099511627776
    # number of bytes in 1TB expressed in base 10
    TB_base10_in_bytes = 1000000000000
    # number of bytes in 1PB expressed in base 2
    PB_base2_in_bytes = 1125899906842624
    # number of bytes in 1TB expressed in base 10
    PB_base10_in_bytes = 1000000000000000

    assert bytes_to_human(0) == "0.00 Bytes"
    assert bytes_to_human(1023) == "1023.00 Bytes"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1 << 10) == "1.00 KB"
    assert bytes_to_human

# Generated at 2022-06-22 22:12:49.040133
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', 'b') == 1048576
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10MB', 'b') == 1048576
    assert human_to_bytes('10Mb', 'b') == 1048576
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('10K', 'b') == 1024
    assert human_to_bytes('10KB') == 10240
    assert human_to_bytes('10KB', 'b') == 1024
    assert human_to_bytes('10Kb', 'b') == 1024
    assert human_to_bytes('10G') == 10737418240

# Generated at 2022-06-22 22:12:54.876924
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input = ['a', 'B', 'c', 1, 2, 3]
    output = ['a', 'b', 'c', 1, 2, 3]
    assert lenient_lowercase(input) == output

# Generated at 2022-06-22 22:13:06.596268
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 EB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 ZB'

# Generated at 2022-06-22 22:13:15.279679
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import assert_equals

    assert_equals(human_to_bytes('1M'), 1048576)
    assert_equals(human_to_bytes('1M', default_unit='K'), 1048576)
    assert_equals(human_to_bytes('1M', default_unit='b'), 1048576)
    assert_equals(human_to_bytes('1Mb'), 8388608)
    assert_equals(human_to_bytes('1Mb', default_unit='b'), 8388608)
    assert_equals(human_to_bytes('1Mb', default_unit='B'), 8388608)
    assert_equals(human_to_bytes('1.5Mb'), 12582912)

# Generated at 2022-06-22 22:13:16.731902
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 1]) == ['a', 1]
    assert lenient_lowercase([['A'], 1]) == [['A'], 1]


# Generated at 2022-06-22 22:13:18.241507
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576) == '1.00 MB'



# Generated at 2022-06-22 22:13:25.887030
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1024) == '1.00 KBytes'
    assert bytes_to_human(1024, True) == '8.00 Kbits'
    assert bytes_to_human(8527) == '8.33 KBytes'
    assert bytes_to_human(1000000) == '976.56 KBytes'
    assert bytes_to_human(1000000000) == '953.67 MBytes'
    assert bytes_to_human(1000000000000) == '931.32 GBytes'
    assert bytes_to_human(7000000000) == '6.53 GBytes'
    assert bytes_to_human(7000000000) == '6.53 GBytes'

# Generated at 2022-06-22 22:13:30.098072
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert isinstance(lenient_lowercase([1, 2, 3]), list)
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase(['a', 'B', [1, 2, 3]]) == ['a', 'b', [1, 2, 3]]



# Generated at 2022-06-22 22:13:40.005205
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576) == '1.00 MBytes'
    assert bytes_to_human(1048576, unit='b') == '8192.00 Kbits'
    assert bytes_to_human(1048576, unit='m') == '1.00 MBytes'
    assert bytes_to_human(1048576, unit='M') == '1.00 MBytes'
    assert bytes_to_human(1048576, unit='k') == '1024.00 KBytes'
    assert bytes_to_human(1048576, unit='K') == '1024.00 KBytes'
    assert bytes_to_human(1048576, unit='g') == '0.00 GBytes'
    assert bytes_to_human(1048576, unit='G') == '0.00 GBytes'

# Generated at 2022-06-22 22:13:44.631847
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 'three']) == [1, 2, 'three']
    assert lenient_lowercase(['one', 'TWO', 3]) == ['one', 'two', 3]


# Generated at 2022-06-22 22:13:48.744358
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    data = [1, "abcd", "EFG", "hij.klm"]
    assert ['1', 'abcd', 'efg', 'hij.klm'] == lenient_lowercase(data)

# Generated at 2022-06-22 22:13:59.350342
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('3b') == 3
    assert human_to_bytes('3B') == 3
    assert human_to_bytes('3') == 3
    assert human_to_bytes('.3') == .3
    assert human_to_bytes('0.3') == .3
    assert human_to_bytes('0.3K') == .3 * 1024
    assert human_to_bytes('3K') == 3 * 1024
    assert human_to_bytes('3.1K') == 3 * 1024 + 1024 * .1
    assert human_to_bytes('3.2M') == 3 * 1024 * 1024 + 1024 * 1024 * .2
    assert human_to_bytes('3.3G') == 3 * 1024 * 1024 * 1024 + 1024 * 1024 * 1024 * .3

# Generated at 2022-06-22 22:14:05.942842
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_to_lower = [
        'String',
        object(),
        123
    ]
    expected_lower = [
        'string',
        object(),
        123
    ]
    assert lenient_lowercase(list_to_lower) == expected_lower



# Generated at 2022-06-22 22:14:09.557611
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 1, 2, [1, 2, 3]]) == ['a', 'b', 'c', 1, 2, [1, 2, 3]]



# Generated at 2022-06-22 22:14:19.662483
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, isbits=True) == '1.00 Kb'
    assert bytes_to_human(1024, isbits=True, unit='b') == '1.00 b'
    assert bytes_to_human(1024, unit='kb') == '1.00 kb'
    assert bytes_to_human(1024, unit='KB') == '1.00 KB'
    assert bytes_to_human(1024, unit='Kb') == '1.00 Kb'
    assert bytes_to_human(1024, unit='Kb', isbits=True) == '1.00 Kb'
    assert bytes_to_human(1024, unit='b') == '1.00 b'


# Generated at 2022-06-22 22:14:28.485005
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Function should return the raw size if no unit is given.
    assert bytes_to_human(100) == 100
    assert bytes_to_human(100, unit='') == 100

    assert bytes_to_human(100, unit='b') == '100.00 bits'
    assert bytes_to_human(100, unit='B') == '100.00 Bytes'

    # Test standard units
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1.2) == '1.20 Bytes'

    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1.2) == '1.20 KB'

    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes

# Generated at 2022-06-22 22:14:39.287368
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Byte'
    assert bytes_to_human(1, isbits=True) == '1 bit'
    assert bytes_to_human(2, isbits=True) == '2 bits'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(10, isbits=True) == '10 bits'
    assert bytes_to_human(999) == '999 Bytes'
    assert bytes_to_human(999, isbits=True) == '999 bits'
    assert bytes_to_human(1000) == '1.00 KB'
    assert bytes_to_human(1000, isbits=True) == '1.00 Kb'
    assert bytes_to_

# Generated at 2022-06-22 22:14:50.787383
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(4) == '4.00 Bytes'
    assert bytes_to_human(5122) == '5.00 KB'
    assert bytes_to_human(5122, unit='B') == '5122.00 B'
    assert bytes_to_human(5122, unit='M') == '0.00 MB'
    assert bytes_to_human(5122, unit='K') == '5.00 KB'
    assert bytes_to_human(5128) == '5.00 KB'
    assert bytes_to_human(5130) == '5.01 KB'
    assert bytes_to_human(6 * 10**6) == '6.00 MB'
    assert bytes_to_human(6 * 10**6, unit='M') == '6.00 MB'
    assert bytes_to

# Generated at 2022-06-22 22:15:02.432801
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:15:12.008190
# Unit test for function bytes_to_human
def test_bytes_to_human():

    tests = [
        (1, '1 B'),
        (1024, '1.00 KB'),
        (1048576, '1.00 MB'),
        (1073741824, '1.00 GB'),
        (1099511627776, '1.00 TB'),
        (1125899906842624, '1.00 PB'),
        (1152921504606846976, '1.00 EB'),
        (1180591620717411303424, '1.00 ZB'),
        (1208925819614629174706176, '1.00 YB'),
    ]

    for i in tests:
        assert bytes_to_human(i[0]) == i[1]



# Generated at 2022-06-22 22:15:20.027678
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = []
    test_list.append([])
    test_list.append(None)
    test_list.append('')
    test_list.append('abcdeFGH')
    test_list.append(123)
    test_list.append([1, 2, 3])
    test_list.append(['abcd', 'efgh', 'ijkl'])
    test_list.append(['abcd', 1234, 'efgh'])
    test_list.append(['aBcd', 1234, 'efgh'])
    test_list.append(['abcd', 123.4, 'efgh'])
    test_list.append([])
    test_list.append(['abcdeFGH', 123])
    test_list.append([1, 2, 3])
    test_list

# Generated at 2022-06-22 22:15:24.434201
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Create a list of items to try
    items = [1, "2", None, [], {}, "\n"]

    # Lowercase all items in list and test results
    #   This will not work for items that are not strings
    lowered_items = list(map(lambda s: s.lower(), items))
    assert lowered_items == items

# Generated at 2022-06-22 22:15:36.221167
# Unit test for function bytes_to_human
def test_bytes_to_human():
    test_data = [
        (2048, '2.00 KB'),
        (2048, '2.00 kb', True),
        (2048, '2.00 kB', True),
        (2048, '2.00 Kb', False),
        (2048, '2.00 KB', False),
        (2048, '2.00 KB', False, 'B'),
        (2048, '2.00 Kb', False, 'b'),
        (2048, '2.00 Kb', False, 'kb')
    ]

    for size, expected_output, isbits, unit in test_data:
        actual_output = bytes_to_human(size, isbits, unit)
        assert actual_output == expected_output

# Generated at 2022-06-22 22:15:40.029114
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'b']) == ['a', 'b']
    assert lenient_lowercase(['A', 1, 'b']) == ['a', 1, 'b']


# Generated at 2022-06-22 22:15:49.624668
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:15:57.500302
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', {'b': 'c'}, 'd']) == ['a', {'b': 'c'}, 'd']
    assert lenient_lowercase(['a', ['b', 'C'], 'd']) == ['a', ['b', 'C'], 'd']

# Generated at 2022-06-22 22:16:08.408945
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [1, 'TesT', 2, 3, 'EVErYthIng', '',
           {'key1': 'value1', 'key2': 'value2'}, 'hellO',
           ['1', '2', '3']]
    expected_lst = [1, 'test', 2, 3, 'everything', '',
                    {'key1': 'value1', 'key2': 'value2'}, 'hello',
                    ['1', '2', '3']]
    assert expected_lst == lenient_lowercase(lst)


# Generated at 2022-06-22 22:16:15.991902
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'
    assert bytes_to_human(10, unit='b') == '10.00 bits'
    assert bytes_to_human(10, isbits=True) == '10.00 bits'
    assert bytes_to_human(10, isbits=True, unit='B') == '10.00 bits'
    assert bytes_to_human(10, isbits=True, unit='b') == '10.00 bits'
    assert bytes_to_human(10, unit='K') == '0.01 KB'
    assert bytes_to_human(10, isbits=True, unit='K') == '0.01 Kbits'

# Generated at 2022-06-22 22:16:26.236033
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10 * 1024 * 1024
    assert human_to_bytes('10K') == 10 * 1024
    assert human_to_bytes(1024) == 1024
    assert human_to_bytes('1048576') == 1048576
    assert human_to_bytes(1048576) == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576 * 8
    assert human_to_bytes(10, 'M') == 10 * 1024 * 1024
    assert human_to_bytes(10, 'K') == 10 * 1024


# Generated at 2022-06-22 22:16:31.742481
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # expected_result tuple is equivalent to the input list
    input_list = ['one', 2, 'three', 4]
    expected_result = ['one', 2, 'three', 4]

    if lenient_lowercase(input_list) != expected_result:
        raise AssertionError

    # expected_result tuple has the same values as the input list, but all strings are lower-case
    input_list = ['One', 2, 'three', 4]
    expected_result = ['one', 2, 'three', 4]

    if lenient_lowercase(input_list) != expected_result:
        raise AssertionError

# Generated at 2022-06-22 22:16:42.285034
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Test human_to_bytes with different values.
    '''
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K', isbits=True) == 8192
    assert human_to_bytes('1Kb') == 8192
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB', isbits=True) == 8388608
    assert human_to_bytes('1Mb', isbits=True) == 8388608
    assert human_to_bytes

# Generated at 2022-06-22 22:16:45.611593
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase(['AbC', 'dEf']) == ['abc', 'def']
    assert lenient_lowercase(['AbC', 1, 'dEf']) == ['abc', 1, 'def']

# Generated at 2022-06-22 22:16:52.348424
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(20) == '20 Bytes'
    assert bytes_to_human(1500, True) == '1.50 Kb'
    assert bytes_to_human(2500) == '2.44 KBytes'
    assert bytes_to_human(2500, False, 'b') == '20 Kbits'
    assert bytes_to_human(2500, False, 'Bytes') == '2.44 KBytes'
    assert bytes_to_human(2500, False, 'K') == '2.50 KBytes'
    assert bytes_to_human(2500, False, 'm') == '0.00 MBytes'
    assert bytes_to_human(2500, False, 'M') == '2.50 MBytes'

# Generated at 2022-06-22 22:17:02.907799
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:17:15.283180
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(0, unit='b', isbits=True) == 0
    assert human_to_bytes(10, unit='b', isbits=True) == 10
    assert human_to_bytes(1048576, unit='b', isbits=True) == 8388608
    assert human_to_bytes(1073741824, unit='b', isbits=True) == 8589934592
    assert human_to_bytes(0, unit='B', isbits=False) == 0
    assert human_to_bytes(10, unit='B', isbits=False) == 10
    assert human_to_bytes(1048576, unit='B', isbits=False) == 1048576
    assert human_to_bytes(1073741824, unit='B', isbits=False) == 1073741824

# Generated at 2022-06-22 22:17:20.880750
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['foo', 'bar']) == ['foo', 'bar']
    assert lenient_lowercase(['foo', 12, 'bar']) == ['foo', 12, 'bar']
    assert lenient_lowercase(['FOO', 'Bar']) == ['foo', 'bar']
    assert lenient_lowercase(['FOO', 12, 'Bar']) == ['foo', 12, 'bar']



# Generated at 2022-06-22 22:17:32.364698
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # BYTES
    # Bytes (B)
    assert human_to_bytes('32B') == 32
    assert human_to_bytes('10B', default_unit='B') == 10
    assert human_to_bytes('10') == 10
    assert human_to_bytes(10) == 10
    assert human_to_bytes('10.1') == 10
    assert human_to_bytes('10,1') == 10
    assert human_to_bytes('10,1B') == 10
    assert human_to_bytes('10.1B') == 10
    assert human_to_bytes('10.0B') == 10
    assert human_to_bytes('10.10B') == 10
    assert human_to_bytes('10.B') == 10

    # Kilo Bytes (KB)
    assert human_to_

# Generated at 2022-06-22 22:17:41.099460
# Unit test for function human_to_bytes
def test_human_to_bytes():
    human_to_bytes = human_to_bytes

# Generated at 2022-06-22 22:17:50.479413
# Unit test for function bytes_to_human
def test_bytes_to_human():
    test_sizes = [
        (1, '1.00 Bytes'),
        (20, '20.00 Bytes'),
        (2000, '2.00 KB'),
        (2000000, '2.00 MB'),
        (2000000000, '2.00 GB'),
        (2000000000000, '2.00 TB'),
        (2000000000000000, '2.00 PB'),
        (2000000000000000000, '2.00 EB'),
        (200000000000000000000, '2.00 ZB'),
        (200000000000000000000000, '2.00 YB'),
    ]

    for size, expected in test_sizes:
        assert expected == bytes_to_human(size)
        test_max_val = 2**64 - 1
        assert bytes_to_human(test_max_val) == '18.00 EB'

    test_

# Generated at 2022-06-22 22:18:03.036787
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10.5') == 10
    assert human_to_bytes('10.5K') == 10 * 1024 + 512
    assert human_to_bytes('10.5KB') == 10 * 1024 + 512
    assert human_to_bytes('10.5Kb') == (10 * 1024 + 512) * 8
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10.5b') == 10
    assert human_to_bytes('10.5Mb') == (10 * 1024 * 1024 + 512 * 1024) * 8
    assert human_to_bytes('10.5MB') == (10 * 1024 * 1024 + 512 * 1024)
    assert human_to_bytes('   ') == None
    assert human_to_bytes

# Generated at 2022-06-22 22:18:15.499146
# Unit test for function human_to_bytes
def test_human_to_bytes():
    following_fail = {'invalid': (['2f', '10b', '1Mb', '1Gb', '1.5 M']),
                      'valid': (['100', '100B', '100b', '100KB', '100Kb', '100MB', '100Mb', '100G', '100Gb', '100M'], ['100B', '100b', '100KB', '100Kb', '100MB', '100Mb', '100G', '100Gb', '100M'], [100, 100, 102400, 102400, 104857600, 104857600, 107374182400, 107374182400, 104857600])}
    following_fail.get('invalid')[1].append('1M')
    following_fail.get('valid')[1].append('1M')



# Generated at 2022-06-22 22:18:25.992817
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1g') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1t') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1p') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976

# Generated at 2022-06-22 22:18:28.949506
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A']) == ['a']
    assert lenient_lowercase([1]) == [1]
    assert lenient_lowercase(['B', 'C', 3]) == ['b', 'c', 3]


# Generated at 2022-06-22 22:18:40.980272
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1, unit='b') == '1 b'
    assert bytes_to_human(10, unit='b') == '10 b'
    assert bytes_to_human(1000, unit='b') == '1000 b'
    assert bytes_to_human(1024, unit='b') == '1024 b'
    assert bytes_to_human(1048576, unit='b') == '1048576 b'
    assert bytes_to_human(1073741824, unit='b') == '1073741824 b'
    assert bytes_to_human(1099511627776, unit='b') == '1099511627776 b'
    assert bytes_to_human(1125899906842624, unit='b') == '1125899906842624 b'

# Generated at 2022-06-22 22:18:45.422950
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['This', ['Should', 'be', 'lower', 'cased'], 'only']) == ['this', ['Should', 'be', 'lower', 'cased'], 'only']


# Generated at 2022-06-22 22:18:51.848477
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, unit='b') == '1.00 bits'
    assert bytes_to_human(2 ** 20) == '1.00 MB'
    assert bytes_to_human(2 ** 20, isbits=True) == '8.00 Mb'
    assert bytes_to_human(10, isbits=True, unit='M') == '80.00 Mb'



# Generated at 2022-06-22 22:18:53.990005
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    l1 = ['abc', 'abc', 2, 'abc']
    l1_lc = ['abc', 'abc', 2, 'abc']

    if lenient_lowercase(l1) != l1_lc:
        raise ValueError('lenient_lowercase() returned list that is not expected')

# Unit tests for function human_to_bytes()

# Generated at 2022-06-22 22:18:59.722134
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['A', 'B', 'C', 1, u'D']) == ['a', 'b', 'c', 1, u'd']
    assert lenient_lowercase([u'A', u'B', u'C']) == [u'a', u'b', u'c']



# Generated at 2022-06-22 22:19:09.626419
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:19:17.020900
# Unit test for function bytes_to_human
def test_bytes_to_human():
    test_data = (
        (1024, False, None, '1.00 KBytes'),
        (1024, False, 'M', '0.00 MBytes'),
        (1024, True, 'M', '0.00 Mbits'),
        (1024, True, 'm', '0.00 Mbits'),
        (1024, True, 'K', '0.00 Kbits'),
        (1024, True, 'k', '0.00 Kbits'),
        (1024, True, 'G', '0.00 Gbits'),
        (1024, True, 'g', '0.00 Gbits'),
        (1024, True, 'T', '0.00 Tbits'),
        (1024, True, 't', '0.00 Tbits'),
    )
    for row in test_data:
        size, isbits, unit, output_string

# Generated at 2022-06-22 22:19:19.489011
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ["123"] == lenient_lowercase(["123"])
    assert ["123", "abc"] == lenient_lowercase(["123", "ABc"])



# Generated at 2022-06-22 22:19:29.782187
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1Y') == 1208925819614629174706176)
    assert(human_to_bytes('1Z') == 1180591620717411303424)
    assert(human_to_bytes('1E') == 1152921504606846976)
    assert(human_to_bytes('1P') == 1125899906842624)
    assert(human_to_bytes('1T') == 1099511627776)
    assert(human_to_bytes('1G') == 1073741824)
    assert(human_to_bytes('1M') == 1048576)
    assert(human_to_bytes('1K') == 1024)
    assert(human_to_bytes('1B') == 1)
    assert(human_to_bytes('10B') == 10)


# Generated at 2022-06-22 22:19:35.674547
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = human_to_bytes('10M')
    assert result == 10485760

    result = human_to_bytes('10M', isbits=True)
    assert result == 10485760

    result = human_to_bytes('10Mb', isbits=True)
    assert result == 10485760

    result = human_to_bytes('10Mb')
    assert result == 10485760



# Generated at 2022-06-22 22:19:40.351639
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase([None, 'B', 'C']) == [None, 'b', 'c']
    assert lenient_lowercase([None, ['B', 'c'], 'C']) == [None, ['B', 'c'], 'c']

# Generated at 2022-06-22 22:19:49.767043
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_cases = [
        ('10M', 10485760), ('10MB', 10485760), ('10Mb', 13107200),
        ('10k', 10240), ('10KB', 10240), ('10Kb', 1280),
        ('10b', 10), ('10B', 10), ('10', 10),
    ]
    for test_case in test_cases:
        assert human_to_bytes(test_case[0]) == test_case[1]
        assert human_to_bytes(test_case[1], 'B') == test_case[1]
        assert human_to_bytes(test_case[1], 'b', isbits=True) == test_case[1]


# Generated at 2022-06-22 22:20:03.005368
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:20:08.738641
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''
    bytes_to_human unit test
    '''
    print('bytes_to_human unit test start')
    print('bytes_to_human unit test: check format, input 1048576')
    test_format = re.search(r'^\s*(\d*\.?\d*)\s*([A-Za-z]+)?', bytes_to_human(1048576), flags=re.IGNORECASE)
    if test_format is None:
        print("format test fail.")
    else:
        print("format test success.")
    print("bytes_to_human unit test: check base, input 1048576")
    if test_format.group(2) == 'Bytes':
        print("base test success.")
    else:
        print("base test fail.")

# Generated at 2022-06-22 22:20:17.672276
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Test bytes and bits formatting
    '''
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10M', isbits=True, default_unit='b') == 10485760
    assert human_to_bytes(10, 'M', isbits=True) == 10485760
    assert human_to_bytes(10, 'MB', isbits=False) == 10485760
    assert human_to_bytes('190') == 190
    '''
    Test default unit
    '''
    assert human_to_bytes('190K') == 190*1024
    assert human_to_bytes('190K', default_unit='B') == 190*1024


# Generated at 2022-06-22 22:20:25.498723
# Unit test for function bytes_to_human
def test_bytes_to_human():
    def test(size, unit, expected):
        actual = bytes_to_human(size, unit=unit)
        print("Testing: %d %s. Expected: %s. Actual: %s." % (size, unit, expected, actual))
        assert actual == expected
    test(size=1048576 * 3, unit=None, expected='3.00 MB')
    test(size=1048576 * 3, unit='B', expected='3145728.00 Bytes')
    test(size=1048576 * 3, unit='M', expected='3.00 MB')
    test(size=1048576 * 3, unit='G', expected='0.00 GB')
    test(size=1048576 * 3, unit='g', expected='0.00 GB')

# Generated at 2022-06-22 22:20:29.094288
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [1, "A", "bC"]
    assert lenient_lowercase(lst) == [1, "A", "bc"]

# Generated at 2022-06-22 22:20:36.680673
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # basic cases
    tests = (
            ('1', 1),
            ('-1', -1),
            ('1B', 1),
            ('1b', 1),
            ('1.0', 1.0),
            ('1.1', 1.1),
            ('1.1K', 1024 + 1024 / 10),
            ('1.0K', 1024),
            ('1.0KiB', 1024),
            ('1.0Ki', 1024),
            ('1.0KB', 1000),
            ('1.0Mb', 1000000),
            ('-1.0K', -1024),
        )
    for param, expected in tests:
        assert human_to_bytes(param) == expected
        assert human_to_bytes(param + 'B') == expected
        assert human_to_bytes(param, 'B')

# Generated at 2022-06-22 22:20:45.657020
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, unit='K') == '1.00 KB'
    assert bytes_to_human(1024, unit='m') == '1.00 MB'
    assert bytes_to_human(1024, isbits=True) == '1.00 Kb'
    assert bytes_to_human(1024, isbits=True, unit='k') == '1.00 Kb'
    assert bytes_to_human(1024, isbits=True, unit='M') == '1.00 Mb'
    assert bytes_to_human(1024, isbits=True, unit='m') == '1.00 Mb'
    assert bytes_to_human(1024, isbits=True, unit='b') == '1024.00 b'
    assert bytes_

# Generated at 2022-06-22 22:20:51.444353
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:21:04.417247
# Unit test for function bytes_to_human
def test_bytes_to_human():
    sizes = [1024*1024,
             1024**2+1024,
             1024**2-1,
             1024*1024*1024,
             1024*1024*1024+1024**2,
             1024*1024*1024-1,
             1024*1024*1024*1024,
             1024*1024*1024*1024+1024**3,
             1024*1024*1024*1024-1,
             1024*1024*1024*1024+1024**3+1024**2,
             1024*1024*1024*1024+1024**3-1]
    units = ['B', 'K', 'M', 'G', 'T']

# Generated at 2022-06-22 22:21:13.569346
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Unit test for function human_to_bytes
    :return: True
    '''
    # single byte - no unit passed
    assert human_to_bytes(10) == 10
    # single byte - B unit passed
    assert human_to_bytes(10, 'B') == 10
    # single byte - b unit passed
    assert human_to_bytes(10, 'b') == 10
    # 10 bytes - B unit passed
    assert human_to_bytes(10, 'B') == 10
    # 10 bytes - with space - B unit passed
    assert human_to_bytes(' 10 ', 'B') == 10
    # 10 KB - KB unit passed
    assert human_to_bytes(10, 'KB') == 10240
    # 10 KB - with space - KB unit passed
    assert human_to_bytes(' 10 ', 'KB')

# Generated at 2022-06-22 22:21:22.954166
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert(bytes_to_human(100) == '100.00 Bytes')
    assert(bytes_to_human(100, unit='b') == '800.00 bits')
    assert(bytes_to_human(1000) == '1.00 KB')
    assert(bytes_to_human(1000, unit='B') == '1.00 KB')
    assert(bytes_to_human(1000, unit='b') == '8.00 Kb')
    assert(bytes_to_human(1000, unit='bit') == '8.00 Kbit')
    assert(bytes_to_human(1000, unit='bits') == '8.00 Kbits')
    assert(bytes_to_human(1000, unit='kb') == '8.00 Kb')

# Generated at 2022-06-22 22:21:31.820070
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''
    Test function bytes_to_human
    '''

# Generated at 2022-06-22 22:21:43.472759
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Unit test for function human_to_bytes '''

    # 'Bytes' section

# Generated at 2022-06-22 22:21:54.836815
# Unit test for function bytes_to_human
def test_bytes_to_human():
    module_name = 'ansible.module_utils.net_tools'

# Generated at 2022-06-22 22:21:56.564215
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 1, 2]) == ['a', 'B', 1, 2]

# Generated at 2022-06-22 22:22:05.303733
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(0, unit='b') == '0 Bytes'
    assert bytes_to_human(0, unit='B') == '0 Bytes'
    assert bytes_to_human(0, unit='b') == '0 Bytes'
    assert bytes_to_human(0, unit='B') == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1, unit='b') == '1 Bytes'
    assert bytes_to_human(1, unit='B') == '1 Bytes'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(10, unit='b') == '10 Bytes'
   