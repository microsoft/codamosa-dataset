

# Generated at 2022-06-22 22:12:04.688373
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['User', 'For', 22, 'Password']
    assert 'user' in lenient_lowercase(lst)
    assert 'for' in lenient_lowercase(lst)
    assert 22 in lenient_lowercase(lst)
    assert 'password' in lenient_lowercase(lst)



# Generated at 2022-06-22 22:12:13.993054
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """Test bytes_to_human() with different input arguments.

    Bytes to human readable transformation should be done regardless of the type of input.
    """
    tests = (
        (1, '1 B'),
        (1023, '1023 B'),
        (1024, '1.00 KB'),
        (1024 * 1024 * 2, '2.00 MB'),
        (1024 * 1024 * 1024, '1.00 GB'),
        (1024 ** 4, '1.00 TB'),
        (1024 ** 5, '1.00 PB'),
        (1024 ** 6, '1.00 EB'),
        (1024 ** 7, '1.00 ZB'),
        (1024 ** 8, '1.00 YB'),
    )
    for input_, expected in tests:
        assert bytes_to_human(input_) == expected

    assert bytes

# Generated at 2022-06-22 22:12:17.143109
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert (bytes_to_human(1, 'B') == '1.00 Byte')
    assert (bytes_to_human(10, 'b') == '1.00 bit')
    assert (bytes_to_human(100, 'bits') == '100.00 bits')


# Generated at 2022-06-22 22:12:27.779100
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1024) == '1.00 kB'
    assert bytes_to_human(1023, unit='K') == '9.99 kB'
    assert bytes_to_human(1023000000, unit='M') == '976.56 MB'
    assert bytes_to_human(1023000000, unit='G') == '0.95 GB'
    assert bytes_to_human(1023000000000, unit='T') == '0.93 TB'
    assert bytes_to_human(1023000000000000, unit='P') == '0.90 PB'
    assert bytes_to_human(1023000000000000000, unit='E') == '0.88 EB'

# Generated at 2022-06-22 22:12:37.963330
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1T') == pow(10, 12)
    assert human_to_bytes('1G') == pow(10, 9)
    assert human_to_bytes('1M') == pow(10, 6)
    assert human_to_bytes('1K') == pow(10, 3)
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.5GB') == int(pow(10, 9) * 1.5)

    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1.5Gb', isbits=True) == int(pow(10, 9) * 1.5)


# Generated at 2022-06-22 22:12:45.464674
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == "0.00 Bytes"
    assert bytes_to_human(10) == "0.01 Bytes"
    assert bytes_to_human(15) == "0.01 Bytes"
    assert bytes_to_human(2048) == "2.00 KBytes"
    assert bytes_to_human(1048576) == "1.00 MBytes"
    assert bytes_to_human(1073741824) == "1.00 GBytes"
    assert bytes_to_human(1099511627776) == "1.00 TBytes"
    assert bytes_to_human(1125899906842624) == "1.00 PBytes"
    assert bytes_to_human(1152921504606846976) == "1.00 EBytes"
    assert bytes_to

# Generated at 2022-06-22 22:12:56.254763
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(5) == "5.00 Bytes"
    assert bytes_to_human(1023) == "1023.00 Bytes"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1024**2) == "1.00 MB"
    assert bytes_to_human(1024**3) == "1.00 GB"
    assert bytes_to_human(1024**4) == "1.00 TB"
    assert bytes_to_human(1024**5) == "1.00 PB"
    assert bytes_to_human(1024**6) == "1.00 EB"
    assert bytes_to_human(1024**7) == "1.00 ZB"
    assert bytes_to_human(1024**8) == "1.00 YB"

# Generated at 2022-06-22 22:13:03.119234
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:13:12.307294
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # bytes_to_human
    test_cases_bytes = [
        (0, '0.00 Bytes'),
        (2, '2.00 Bytes'),
        (10240, '10.00 KB'),
        (1024000, '1.00 MB'),
        (2348116, '2.26 MB'),
        (234811600, '224.92 MB'),
        (23481160000, '21.97 GB'),
    ]

    for i, o in test_cases_bytes:
        assert bytes_to_human(i) == o, "%s != %s" % (bytes_to_human(i), o)

    # bytes_to_human with unit

# Generated at 2022-06-22 22:13:21.898073
# Unit test for function human_to_bytes
def test_human_to_bytes():
    input_data = dict()
    input_data['2K'] = 2048
    input_data['2.5M'] = 2560000
    input_data['3.5Mb'] = 3500000
    input_data['3.5M'] = 3670016
    input_data['50'] = 50
    input_data['50B'] = 50
    input_data['b'] = 1
    input_data['10MB'] = 10485760
    input_data['1.1Mb'] = 1150000
    input_data['10Mb'] = 10485760
    input_data['10Kb'] = 102400
    input_data['b'] = 1

    # negative tests
    input_data['10Mb'] = 10
    input_data['10Kb'] = 1

# Generated at 2022-06-22 22:13:27.565559
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['test']) == ['test']
    assert lenient_lowercase(['test', 1]) == ['test', 1]
    assert lenient_lowercase(['test', 1, 'test2']) == ['test', 1, 'test2']



# Generated at 2022-06-22 22:13:38.206110
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test different cases
    params = ["10b", "10", "1 KB", "1 Kb", "1 KB", "1 KBt", "1 Kbt", "1MB", "1Mb", "1 B", "1 b", "1 MB", "1 Mb", "1 K B", "1 K b", "1Gb", "1GbB", "1GbBt", "1MbBt", "1Mb", "1M", "1.5M", "1.5MB", "1.5MbBt", "1.5MBt", "1.5Mbt", "1.5MbtB", "1.5MBBt"]

# Generated at 2022-06-22 22:13:45.072017
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["Ansible", "Project"]) == ["ansible", "project"]
    assert lenient_lowercase([1, ["Ansible", "Project"], "Modules"]) == [1, ["Ansible", "Project"], "modules"]
    assert lenient_lowercase([{"ansible": "Project"}]) == [{"ansible": "Project"}]


# Generated at 2022-06-22 22:13:48.632007
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['aaa', 123]) == ['aaa', 123]
    assert lenient_lowercase(['AAA', 'BBB']) == ['aaa', 'bbb']

# Generated at 2022-06-22 22:13:59.268379
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # isbits = False
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(0, unit='b') == '0 Bytes'
    assert bytes_to_human(1023) == '1023 Bytes'

    assert bytes_to_human(1024) == '1.00 KiB'
    assert bytes_to_human(1024, unit='b') == '1.00 KiB'

    assert bytes_to_human(1024 * 1024) == '1.00 MiB'
    assert bytes_to_human(1024 * 1024, unit='B') == '1.00 MB'
    assert bytes_to_human(1024 * 1024, unit='m') == '1.00 MB'

    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GiB'
   

# Generated at 2022-06-22 22:14:11.390496
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("Test human_to_bytes()")
    result = human_to_bytes(10)
    print('10 =>', result, 'bytes')
    result = human_to_bytes(10, 'm')
    print('10M =>', result, 'bytes')

    result = human_to_bytes(10, 'm', isbits=True)
    print('10Mb =>', result, 'bytes')
    result = human_to_bytes('10', 'm', isbits=True)
    print("'10'Mb =>", result, 'bytes')
    result = human_to_bytes('10Mb', isbits=True)
    print("'10Mb' =>", result, 'bytes')
    result = human_to_bytes('10mB', isbits=True)

# Generated at 2022-06-22 22:14:21.653748
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['aBcDe', 'FgHiJ', 1, 2, 3]) == ['abcde', 'fghij', 1, 2, 3]
    assert lenient_lowercase(['aBcDe', 'FgHiJ', [1, 2, 3], {'a': 1, 'b': 2}, (1, 2, 3)]) == ['abcde', 'fghij', [1, 2, 3], {'a': 1, 'b': 2}, (1, 2, 3)]

# Generated at 2022-06-22 22:14:29.898749
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest

# Generated at 2022-06-22 22:14:40.454637
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 ** 2) == '1.00 MB'
    assert bytes_to_human(1024 ** 3) == '1.00 GB'
    assert bytes_to_human(1024 ** 4) == '1.00 TB'
    assert bytes_to_human(1024 ** 5) == '1.00 PB'
    assert bytes_to_human(1024 ** 6) == '1.00 EB'
    assert bytes_to_human(1024 ** 7) == '1.00 ZB'
    assert bytes_to_human(1024 ** 8) == '1.00 YB'

   

# Generated at 2022-06-22 22:14:51.893843
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes(1, 'MB') == 1048576
    assert human_to_bytes('1mB') == 1048576
    assert human_to_bytes('1mb') == 1048576
    assert human_to_bytes('1Byte') == 1
    assert human_to_bytes('1bYtE') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1', 'b') == 1
    assert human_to_bytes('1', 'bit') == 1
    assert human_to_bytes('1', 'bitS') == 1
    assert human_to_bytes('1', 'bYtE') == 1
    assert human

# Generated at 2022-06-22 22:15:02.837349
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # check all 'natural' units
    for unit in ['b', 'B', 'bit', 'byte']:
        assert human_to_bytes(1, unit) == 1
        assert human_to_bytes(2, unit) == 2

    # natural units with upper case
    for unit in ['B', 'Bit', 'Byte']:
        assert human_to_bytes(1, unit) == 1
        assert human_to_bytes(2, unit) == 2

    # check all 'bytes' units
    for unit in ['K', 'KB', 'Kb', 'Kbit', 'Kbyte']:
        assert human_to_bytes(1, unit) == 1024
        assert human_to_bytes(2, unit) == 2048

    # check all 'bits' units
    for unit in ['Kb', 'KBb']:
        assert human

# Generated at 2022-06-22 22:15:13.078111
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1Bb') == 1
    assert human_to_bytes('1bB') == 1

    assert human_to_bytes('1') == 1
    assert human_to_bytes('1', default_unit='B') == 1
    assert human_to_bytes('1', default_unit='b') == 1

    assert human_to_bytes('1K') == 1 * SIZE_RANGES['K']
    assert human_to_bytes('1k') == 1 * SIZE_RANGES['K']
    assert human_to_bytes('1KB') == 1 * SIZE_RANGES['K']
    assert human_to_bytes('1Kb') == 1 * SIZE_

# Generated at 2022-06-22 22:15:20.784454
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test1 = ['CA1', 'ca2', 'ca3', 'CA4']
    assert lenient_lowercase(test1) == ['ca1', 'ca2', 'ca3', 'ca4']

    test2 = ['CA1', 2, 'ca3', 'CA4']
    assert lenient_lowercase(test2) == ['ca1', 2, 'ca3', 'ca4']

    test3 = [{'a': 1, 'b': 2}]
    assert lenient_lowercase(test3) == [{'a': 1, 'b': 2}]

    test4 = [{'a': 1, 'b': 2}, 'ca1']
    assert lenient_lowercase(test4) == [{'a': 1, 'b': 2}, 'ca1']


# Generated at 2022-06-22 22:15:28.954479
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # bytes explicit unit
    assert bytes_to_human(4, unit='B') == '4.00 Bytes'

    # bits explicit unit
    assert bytes_to_human(4, isbits=True, unit='b') == '4.00 bits'

    # - bytes in autodetect mode (unit=None)
    # from bytes
    assert bytes_to_human(100, unit=None) == '100.00 Bytes'
    # from KB
    assert bytes_to_human(100 * 1024, unit=None) == '100.00 KB'
    # from MB
    assert bytes_to_human(100 * 1024 * 1024, unit=None) == '100.00 MB'
    # from GB
    assert bytes_to_human(100 * 1024 * 1024 * 1024, unit=None) == '100.00 GB'


# Generated at 2022-06-22 22:15:39.589416
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Test suite for human_to_bytes function
    '''
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes('10Mb', True) == human_to_bytes(10, 'M', True)
    assert human_to_bytes('10Mb', True) == human_to_bytes(10, 'mb', True)
    assert human_to_bytes('10MB', True) == human_to_bytes(10, 'MB', True)
    assert human_to_bytes(10, 'M', True) == human_to_bytes(10, 'Mb', True)
    assert human_to_bytes(10, 'MB', True) == human_to_bytes(10, 'Mb', True)

# Generated at 2022-06-22 22:15:46.532917
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase([1]) == [1]
    assert lenient_lowercase(['a', 1, 'b']) == ['a', 1, 'b']
    assert lenient_lowercase(['A', 1, 'B']) == ['a', 1, 'b']
    assert lenient_lowercase(['a', 1, 'b', 'C', 'c', 3]) == ['a', 1, 'b', 'C', 'c', 3]

# Generated at 2022-06-22 22:15:57.447264
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # testing instance with 'b' unit postfix
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10b', default_unit='b') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10B', default_unit='b') == 10
    assert human_to_bytes('10KB') == 10240
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10GB') == 10737418240
    assert human_to_bytes('10TB') == 10995116277760
    assert human_to_bytes('10PB') == 11258999068426240
    assert human_to_bytes('10EB') == 11529215046068469760

# Generated at 2022-06-22 22:16:04.669478
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Banana', 'Orange', 'apple']) == ['banana', 'orange', 'apple']
    assert lenient_lowercase(['', '', '', 1, 2, 3]) == ['', '', '', 1, 2, 3]

# Generated at 2022-06-22 22:16:13.510703
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert (1024 == human_to_bytes('1K')), "human_to_bytes() test failed"
    assert (2097152 == human_to_bytes('2M')), 'human_to_bytes() test failed'
    assert (16777216 == human_to_bytes('16M')), 'human_to_bytes() test failed'
    assert (1073741824 == human_to_bytes('1G')), 'human_to_bytes() test failed'
    assert (1048576 == human_to_bytes('1Mb', isbits=True)), 'human_to_bytes() test failed'
    assert (1048576 == human_to_bytes('1mb', isbits=True)), 'human_to_bytes() test failed'

# Generated at 2022-06-22 22:16:17.540767
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    str = [12, 'a', 'B', ['c', 'd']]
    assert lenient_lowercase(str) == [12, 'a', 'b', ['c', 'd']]



# Generated at 2022-06-22 22:16:25.918561
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert (bytes_to_human(1024) == '1.00 KB')
    assert (bytes_to_human(900000) == '900.00 KB')
    assert (bytes_to_human(950001) == '951.00 KB')
    assert (bytes_to_human(950001, unit='K') == '952.00 KB')
    assert (bytes_to_human(950001, unit='K', isbits=True) == '952.00 Kb')
    assert (bytes_to_human(950001, unit='Mb') == '9.23 Mb')


# Generated at 2022-06-22 22:16:32.758038
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:16:37.202635
# Unit test for function bytes_to_human
def test_bytes_to_human():
    if bytes_to_human(-1024) != '-1 KB':
        print("bytes_to_human(-1024) failed")
        return False
    if bytes_to_human(-1024, True) != '-8 Kb':
        print("bytes_to_human(-1024, True) failed")
        return False
    if bytes_to_human(-1024, False, 'MB') != '-0.00 MB':
        print("bytes_to_human(-1024, False, 'MB') failed")
        return False
    if bytes_to_human(1024) != '1 KB':
        print("bytes_to_human(1024) failed")
        return False
    if bytes_to_human(1024, True) != '8 Kb':
        print("bytes_to_human(1024, True) failed")
        return False

# Generated at 2022-06-22 22:16:48.723114
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'
    assert bytes_to_human(10, unit='B', isbits=True) == '80.00 bits'
    assert bytes_to_human(10, isbits=True) == '80.00 bits'
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(0, unit='B') == '0.00 Bytes'
    assert bytes_to_human(0, unit='B', isbits=True) == '0.00 bits'
    assert bytes_to_human(0, isbits=True) == '0.00 bits'

# Generated at 2022-06-22 22:16:54.238005
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # 2 scenarios
    # 1) bytes
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes(' 2k ') == 2048
    assert human_to_bytes('2Kb ') == 2048
    assert human_to_bytes('0.5k ') == 512
    assert human_to_bytes('1MB ') == 1048576
    assert human_to_bytes('0.5M ') == 524288
    assert human_to_bytes('1Mb ') == 1048576
    assert human_to_bytes('0.5Mb ') == 524288
    assert human_to_bytes('21.4Mb ') == 2242304
    assert human_to_bytes('1G ') == 1073741824
    assert human_to_bytes('0.2G ')

# Generated at 2022-06-22 22:16:57.304341
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 1, 'B']) == ['a', 1, 'b']


# Generated at 2022-06-22 22:17:05.377342
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert 1048576 == human_to_bytes('1M')
    assert 1048576 == human_to_bytes('1M', 'b')
    assert 1048576 == human_to_bytes('1MB')
    assert 1048576 == human_to_bytes('1MB', 'b')
    assert 1048576 == human_to_bytes('1Mb', isbits=True)
    assert 1048576 == human_to_bytes('1Mb', 'B', isbits=True)
    assert 1048576 == human_to_bytes('1mB', 'B', isbits=True)
    assert 1048576 == human_to_bytes('1mb', 'B', isbits=True)
    assert 12582912 == human_to_bytes('12M')
    assert 12582912 == human_to_bytes('12m')

# Generated at 2022-06-22 22:17:15.619676
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_cases = [
        # test_case, expected_result
        (['a', 'B', 'c'], ['a', 'B', 'c']),
        (['a', 'b', 'c'], ['a', 'b', 'c']),
        (['A', 'B', 'C'], ['a', 'B', 'C']),
        ([1, 2, 3], [1, 2, 3]),
        ([True, False, True], [True, False, True]),   # Bool is also not a string.
    ]
    for test_case, expected_result in test_cases:
        assert lenient_lowercase(test_case) == expected_result



# Generated at 2022-06-22 22:17:24.233064
# Unit test for function bytes_to_human
def test_bytes_to_human():
    response = bytes_to_human(1)
    assert response == '1.00 Bytes'

    response = bytes_to_human(1000)
    assert response == '1000.00 Bytes'

    response = bytes_to_human(1000, unit='b')
    assert response == '8000.00 bits'

    response = bytes_to_human(10000)
    assert response == '9.77 KB'

    response = bytes_to_human(100000)
    assert response == '97.66 KB'

    response = bytes_to_human(1000000)
    assert response == '976.56 KB'

    response = bytes_to_human(1000000000)
    assert response == '953.67 MB'

    response = bytes_to_human(1000000000000)
    assert response == '931.32 GB'

   

# Generated at 2022-06-22 22:17:28.629567
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    mylist = [1, "TWO", "three"]
    assert lenient_lowercase(mylist) == [1, "two", "three"]
    assert lenient_lowercase(mylist) != [1, "TWO", "three"]


# Generated at 2022-06-22 22:17:39.163999
# Unit test for function human_to_bytes
def test_human_to_bytes():
    for unit in ['Y', 'Z', 'E', 'P', 'T', 'G', 'M', 'K']:
        assert human_to_bytes('1%s' % unit) == 1 << (SIZE_RANGES['Y'] / SIZE_RANGES[unit])
    assert human_to_bytes('1M') == 1 << 20
    assert human_to_bytes('1.5M') == 1 << 20
    assert human_to_bytes('1.5Mb') == 1 << 20
    assert human_to_bytes('1.5M', isbits=True) == 1.5 * 1 << 20
    assert human_to_bytes('1Mb', isbits=True) == 1 << 20
    assert human_to_bytes('1.5Mb', isbits=True) == 1.5 * 1 << 20
   

# Generated at 2022-06-22 22:17:49.356255
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, isbits=True) == '1.00 bits'
    assert bytes_to_human(0.10, isbits=True) == '0.10 bits'
    assert bytes_to_human(1, default_unit='b') == '1.00 b'
    assert bytes_to_human(0.1, default_unit='b') == '0.10 b'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(2) == '2.00 Bytes'
    assert bytes_to_human(3) == '3.00 Bytes'
    assert bytes_to_human(1, isbits=True) == '1.00 bits'

# Generated at 2022-06-22 22:17:57.502853
# Unit test for function human_to_bytes
def test_human_to_bytes():
    retval = None
    # case 1: '1' (no unit passed)
    retval = human_to_bytes('1')
    assert retval == 1
    # case 2: '1Mb' => 1048576
    retval = human_to_bytes('1Mb', isbits=True)
    assert retval == 1048576
    # case 3: '1MB' => 1048576
    retval = human_to_bytes('1MB')
    assert retval == 1048576
    # case 4: '1M' => 1048576
    retval = human_to_bytes('1M')
    assert retval == 1048576
    # case 5: '1M' => 1048576
    retval = human_to_bytes('1M')
    assert retval == 1048576
    # case 6

# Generated at 2022-06-22 22:18:07.608907
# Unit test for function bytes_to_human
def test_bytes_to_human():
    test_bytes = (
        1,
        10,
        100,
        1000,
        10000,
        100000,
        1000000,
        10000000,
        100000000,
        1000000000,
        10000000000,
        100000000000,
        1000000000000,
        10000000000000,
        100000000000000,
        1000000000000000,
        10000000000000000,
        100000000000000000,
        1000000000000000000,
    )


# Generated at 2022-06-22 22:18:17.633415
# Unit test for function bytes_to_human
def test_bytes_to_human():
    third_party_module = __import__('pandevice')
    if not hasattr(third_party_module, 'bytes_to_human'):
        return
    # Testing the limit of 1 to find a match
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1023) == '1023 Bytes'
    # Testing that the limit of 1024 is used when possible
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 ** 4) == '1.00 TB'
    assert bytes_to_human(1024 ** 5) == '1.00 PB'

# Generated at 2022-06-22 22:18:26.826896
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['LOWER', '1234', 'UPPER', '56', 'number']) == ['lower', '1234', 'upper', '56', 'number']
    assert lenient_lowercase(['lower', '1234', 'upper', '56', 'number']) == ['lower', '1234', 'upper', '56', 'number']
    assert lenient_lowercase(['LOWER', '1234', 'UPPER', '56', 'number']) != ['LOWER', '1234', 'UPPER', '56', 'number']
    assert lenient_lowercase(['LOWER', '1234', 'UPPER', '56', 'number']) != ['LOWER', 'upcase', 'UPPER', '56', 'number']

# Generated at 2022-06-22 22:18:33.757442
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # All correct cases where integer value is returned
    # Tests that accept only bytes values
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1E') == 1125899906842624
    assert human_to_bytes('1P') == 1152921504606846976
    assert human_to_bytes('1T') == 11811162560704051200
    assert human_to_bytes('1Y') == 12060806400704051200
    assert human_to_bytes('1Z') == 12311543040704051200
    assert human_to_bytes('1b')

# Generated at 2022-06-22 22:18:36.838159
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, "Well", 'Ridiculous', "a"]) == [1, 'well', 'ridiculous', 'a']

# Generated at 2022-06-22 22:18:40.884626
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'C', 'd']) == ['a', 'b', 'C', 'd']
    assert lenient_lowercase(['a', 1, 'C', 'd']) == ['a', 1, 'C', 'd']

# Generated at 2022-06-22 22:18:52.293407
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10 bytes') == 10
    assert human_to_bytes('10B bytes') == 10
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('1048576') == 1048576
    assert human_to_bytes('1048576.5') == 1048576
    assert human_to_bytes('1048576.5b', isbits=True) == 1048576
    assert human_to_bytes('1048576.5b') == 1048576
    assert human_

# Generated at 2022-06-22 22:19:00.367511
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:19:10.890277
# Unit test for function bytes_to_human
def test_bytes_to_human():
    ''' Unit test for function bytes_to_human
    '''
    # Success cases
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='k') == '0.00 KB'
    assert bytes_to_human(1048576, unit='k') == '1.00 KB'
    assert bytes_to_human(1048577, unit='k') == '1.00 KB'
    assert bytes_to_human(1048577, unit='k', isbits=True) == '8388.61 Kb'
    assert bytes_to_human(1048577, unit='k', isbits=False) == '1.00 KB'

# Generated at 2022-06-22 22:19:16.460421
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    values = [u'Đjåñ', 1, u'lowercase', b'ascii']
    lowercase = lenient_lowercase(values)
    assert lowercase == [u'đjåñ', 1, u'lowercase', b'ascii']

# Generated at 2022-06-22 22:19:24.518887
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == '1.00 KiB'
    assert bytes_to_human(1024, unit='k') == '1.00 KiB'
    assert bytes_to_human(1024, unit='b') == '8192.00 b'
    assert bytes_to_human(1024, unit='B') == '1024.00 Bytes'

    # Bits representation
    assert bytes_to_human(1024, isbits=True) == '8192.00 bits'
    assert bytes_to_human(1024, unit='k', isbits=True) == '8192.00 bits'
    assert bytes_to_human(1024, unit='b', isbits=True) == '8192.00 b'

# Generated at 2022-06-22 22:19:32.963056
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # tests for unit's values
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0KB') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0MB') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0GB') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0TB') == 1099511627776
    assert human

# Generated at 2022-06-22 22:19:43.087462
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_input = ['a', 'b', 'c', 1, 2]
    test_output = ['a', 'b', 'c', 1, 2]
    assert (lenient_lowercase(test_input) == test_output)
    test_input = [1, 'a', 2, 'b', 3, 'c']
    test_output = [1, 'a', 2, 'b', 3, 'c']
    assert (lenient_lowercase(test_input) == test_output)
    test_input = ['a', 'B', 'c', 'D', 'e']
    test_output = ['a', 'b', 'c', 'd', 'e']
    assert (lenient_lowercase(test_input) == test_output)

# Generated at 2022-06-22 22:19:52.015094
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('10m') == 10485760
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10K', 'K') == 10240
    assert human_to_bytes('10m', 'K') == 10485760
    assert human_to_bytes('10', 'K') == 10240
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('10mb') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1b') == 1

# Generated at 2022-06-22 22:20:04.476986
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([0]) == [0]
    assert lenient_lowercase(['0']) == ['0']
    assert lenient_lowercase(['0', '1']) == ['0', '1']
    assert lenient_lowercase(['0', '1', '2']) == ['0', '1', '2']
    assert lenient_lowercase(['a', 'A', 'b', 'B', 'c', 'C']) == ['a', 'a', 'b', 'b', 'c', 'c']
    assert lenient_lowercase(['avxc', 'AVxc']) == ['avxc', 'avxc']

# Generated at 2022-06-22 22:20:15.518351
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.5B') == 1
    assert human_to_bytes('2B') == 2
    assert human_to_bytes('2.2B') == 2
    assert human_to_bytes('2b') == 2
    assert human_to_bytes('2.2b') == 2
    assert human_to_bytes('2.2KB') == 2 * 1024
    assert human_to_bytes('2.2KBb') == 2 * 1024
    assert human_to_bytes('2.2KBb', isbits=True) == 2 * 1024
    assert human_to_bytes('2.2Mb', isbits=True) == 2.2 * 1024 * 1024
    assert human_to_bytes(10, unit='M') == 10 * 1024 * 1024

# Generated at 2022-06-22 22:20:21.634421
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'b']) == ['a', 'b']
    assert lenient_lowercase(['a', 'b', 64]) == ['a', 'b', 64]
    assert lenient_lowercase(['A', 64]) == ['a', 64]
    assert lenient_lowercase([None, 'a']) == [None, 'a']
    assert lenient_lowercase(['A', None]) == ['a', None]
    assert lenient_lowercase([None, None]) == [None, None]



# Generated at 2022-06-22 22:20:31.459502
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:20:41.875247
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:20:49.071747
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Tests with isbits = False
    # Default unit
    assert '1048576 Bytes' == bytes_to_human(1048576)

    # Default unit
    assert '1.00 Bytes' == bytes_to_human(1)

    # Default unit
    assert '1.00 Bytes' == bytes_to_human(1.0, False)

    # Define unit
    assert '20971520 B' == bytes_to_human(20971520, unit='b')

    # Define unit
    assert '20971520 Bytes' == bytes_to_human(20971520, unit='B')

    # Define unit
    assert '20971520 Bytes' == bytes_to_human(20971520.0, unit='B')

    # Test with isbits = True
    # Test

# Generated at 2022-06-22 22:20:57.150042
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10B', default_unit='B') == 10
    assert human_to_bytes('10KB', default_unit='B') == 10240
    assert human_to_bytes('10KB', default_unit='b') == 10240
    assert human_to_bytes('10mB', default_unit='b') == 131072
    assert human_to_bytes('10Mb', default_unit='b') == 20971520
    assert human_to_bytes('10Mb', isbits=True) == 20971520
    assert human_to_bytes('10M', isbits=False) == 10485760
    assert human_to_bytes('10M') == 10485760

   

# Generated at 2022-06-22 22:21:02.149285
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(['SomeString', 'OtherString', 10, 20, {'name': 'element1'}, {'name': 'element2'}])
    assert result == ['somestring', 'otherstring', 10, 20, {'name': 'element1'}, {'name': 'element2'}]

# Generated at 2022-06-22 22:21:12.244180
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import nose2

# Generated at 2022-06-22 22:21:21.573465
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # bytes
    assert human_to_bytes(2) == 2
    assert human_to_bytes('2') == 2
    assert human_to_bytes(2.0) == 2

    # bytes with suffix
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('2B') == 2
    assert human_to_bytes('1K') == 1 << 10
    assert human_to_bytes('2K') == 2 << 10
    assert human_to_bytes('1M') == 1 << 20
    assert human_to_bytes('2M') == 2 << 20
    assert human_to_bytes('1G') == 1 << 30
    assert human_to_bytes('2G') == 2 << 30
    assert human_to_bytes('1T') == 1 << 40

# Generated at 2022-06-22 22:21:31.714565
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """
    Unit test for function lenient_lowercase
    """
    lst_alpha = ['a', 'B', 'C']
    lst_numeric = [1, 2, 3]
    lst_float = [1.3, 2.5, 3.23]
    lst_str_int = ['1', '2', '3']
    lst_str = ['one', 'two', 'three']
    lst_mix = ['ONE', 'two', 3]

    assert [s.lower() for s in lst_alpha] == lenient_lowercase(lst_alpha)
    assert lst_numeric == lenient_lowercase(lst_numeric)
    assert lst_float == lenient_lowercase(lst_float)
    assert lst_str_int == lenient_lowercase

# Generated at 2022-06-22 22:21:43.362635
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('2') == 2
    assert human_to_bytes('2.5') == 2.5
    assert human_to_bytes('-2.5') == -2.5
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1.5Kb') == 1536
    assert human_to_bytes('1.5KB', isbits=True) == 1536
    assert human_to_bytes('1.5Kb', isbits=True) == 1536
    assert human_to_bytes('1.5Kb', isbits=False) == 1536
    assert human_to_bytes('1.5K', isbits=True) == 2048

# Generated at 2022-06-22 22:21:54.756598
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(10, False, 'B') == '10 Bytes'
    assert bytes_to_human(10, True, 'b') == '10 bits'
    assert bytes_to_human(10, True, 'b') == '10 bits'
    assert bytes_to_human(10, True, 'B') == '10 bits'
    assert bytes_to_human(10, False, 'b') == '10 Bytes'
    assert bytes_to_human(10, unit='B') == '10 Bytes'
    assert bytes_to_human(10, unit='b') == '10 bits'
    assert bytes_to_human(10, unit='b', isbits=True) == '10 bits'

# Generated at 2022-06-22 22:21:57.159194
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]

# Generated at 2022-06-22 22:22:05.660800
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    import sys

    if sys.version_info[:2] >= (3, 0):
        # Test class
        class StrUpper(str):
            def lower(self):
                return super(StrUpper, self).upper()

        # Test lambda
        upper = lambda s: s.upper()

        # Test list of unicode
        test_list = ['abc', 'Abc', 'aBc', 'abC', '123', '#@!', b'abc', u'abc', u'aBc', StrUpper('abc')]
        assert lenient_lowercase(test_list) == ['abc', 'Abc', 'aBc', 'abC', '123', '#@!', b'abc', u'abc', u'aBc', u'ABC']

        # Test list of bytes