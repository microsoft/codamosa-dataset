

# Generated at 2022-06-22 22:12:07.096767
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'b']) == ['a', 'b']
    assert lenient_lowercase(['A', 1]) == ['a', 1]
    assert lenient_lowercase([]) == []
    assert lenient_lowercase('a') == 'a'
    assert lenient_lowercase(['A', 'B', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]
    assert lenient_lowercase([None, None, None]) == [None, None, None]

# Generated at 2022-06-22 22:12:14.708259
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 1, 2]) == ['a', 'b', 1, 2]
    assert lenient_lowercase(['a', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['a', 'B', 1, 2, 'C', 'D', 'E', 'F']) == ['a', 'b', 1, 2, 'c', 'd', 'e', 'f']
    assert lenient_lowercase([1, 2, 3, 4]) == [1, 2, 3, 4]



# Generated at 2022-06-22 22:12:19.429308
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    ''' Test a variety of cases '''
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['a', 'b']) == ['a', 'b']
    assert lenient_lowercase(['A', 'B']) == ['a', 'b']
    assert lenient_lowercase(['a', 1]) == ['a', 1]
    assert lenient_lowercase(['a', 'B']) == ['a', 'b']



# Generated at 2022-06-22 22:12:23.473873
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(99999999999999, unit='b') == '11.00 Tb'
    assert bytes_to_human(1048576, unit='b') == '8.00 Mb'
    assert bytes_to_human(99999999999999, isbits=True) == '11.00 Tb'
    assert bytes_to_human(1048576, isbits=True) == '8.00 Mb'
    assert bytes_to_human(20000) == '19.53 K'
    assert bytes_to_human(8.1) == '8.10 B'
    assert bytes_to_human(0) == '0.00 B'

# Generated at 2022-06-22 22:12:32.655457
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''
    Test case for bytes_to_human function. The function is said to be working properly
    if it returns the same values as the ones below.
    '''


# Generated at 2022-06-22 22:12:43.187856
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1028) == '1028 Bytes'
    assert bytes_to_human(1028 * 1024) == '1028.00 KB'
    assert bytes_to_human(1028 * 1024 * 1024) == '1028.00 MB'
    assert bytes_to_human(1028 * 1024 * 1024 * 1024) == '1028.00 GB'
    assert bytes_to_human(1028 * 1024 * 1024 * 1024 * 1024) == '1028.00 TB'
    assert bytes_to_human(1028 * 1024 * 1024 * 1024 * 1024 * 1024) == '1028.00 PB'

# Generated at 2022-06-22 22:12:46.516469
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['non-string', 'CAPITALIZED', 'mixed']
    assert lenient_lowercase(test_list) == ['non-string', 'capitalized', 'mixed']


# Generated at 2022-06-22 22:12:56.676274
# Unit test for function human_to_bytes
def test_human_to_bytes():
    cases = [
        ('1', 1),
        ('1B', 1),
        ('1b', 1),
        ('1K', 1*1024),
        ('1Kb', 1*1024*8),
        ('10M', 10*1024*1024),
        ('10.0M', 10*1024*1024),
        ('10.01M', 10*1024*1024),
        ('10.01Mb', 10*1024*1024*8),
    ]
    for case in cases:
        try:
            assert case[1] == human_to_bytes(case[0])
        except Exception as e:
            print('Test failed: %s == human_to_bytes(%s): %s' % (case[1], case[0], str(e)))



# Generated at 2022-06-22 22:13:06.463951
# Unit test for function human_to_bytes
def test_human_to_bytes():
    testdict = {'1.5M': 1572864,
                '1.5MB': 1572864,
                '1.5Mb': 1953600,
                '1.5MBb': 1953600,
                '1.5K': 1536,
                '1.5KB': 1536,
                '1.5Kb': 1536,
                '1.5KBb': 1536,
                '1Y': 1250000000000000000000000000000}
    for k, v in testdict.items():
        assert human_to_bytes(k) == v
        assert human_to_bytes(k, isbits=True) == v

# Generated at 2022-06-22 22:13:15.174565
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(2000) == '2000.00 Bytes'
    assert bytes_to_human(2000, unit='b') == '2000.00 bits'
    assert bytes_to_human(2000, isbits=True) == '2000.00 bits'
    assert bytes_to_human(2000, unit='B') == '2000.00 Bytes'
    assert bytes_to_human(2000, unit='b') == '2000.00 bits'
    assert bytes_to_human(2000, unit='Kb') == '2000.00 Kbits'
    assert bytes_to_human(2000, unit='KB') == '2000.00 KB'
    assert bytes_to_human(2000, unit='KB', isbits=True) == '2000.00 Kbits'

# Generated at 2022-06-22 22:13:24.420079
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert (human_to_bytes('1') == 1)
    assert (human_to_bytes('1B') == 1)
    assert (human_to_bytes('1b') == 1)
    assert (human_to_bytes('1KB') == 1024)
    assert (human_to_bytes('1Kb') == 1024)
    assert (human_to_bytes('1kb') == 1024)
    assert (human_to_bytes('1MB') == 1048576)
    assert (human_to_bytes('1Mb') == 1048576)
    assert (human_to_bytes('1mb') == 1048576)
    assert (human_to_bytes('1GB') == 1073741824)
    assert (human_to_bytes('1G') == 1073741824)

# Generated at 2022-06-22 22:13:29.546696
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    values = ['aaa', 'AAA', 'aaA', 'AaA']
    lower_values = ['aaa', 'aaa', 'aaa', 'aaa']
    assert lenient_lowercase(values) == lower_values



# Generated at 2022-06-22 22:13:39.879434
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    human_to_bytes
    '''
    ansible_tests = (
        # input, expected
        ('10M', 10485760),
        ('10K', 10240),
        ('10', 10),
        (0, 0),
        ('0', 0),
        ('-10', -10),
        ('-10K', -10240),
        ('2.3M', 2385920),
        ('2.3G', 2476712960),
        ('2.3', 2.3),
        ('2.3B', 2.3),
    )

    for i, e in ansible_tests:
        assert human_to_bytes(i) == e


# Generated at 2022-06-22 22:13:50.057868
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:13:52.097482
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 1, 2]) == ['a', 'b', 1, 2]

# Generated at 2022-06-22 22:13:56.297620
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['test', 'TEST', 'TesT']) == ['test', 'test', 'test'])
    assert(lenient_lowercase(['test', 'TEST', 'TesT', 1, 2, 3, 'number 4']) == ['test', 'test', 'test', 1, 2, 3, 'number 4'])

# Generated at 2022-06-22 22:13:59.553742
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['ab', 'CD']) == ['ab', 'CD']
    assert lenient_lowercase(['ab', 'CD', [], {}, 42]) == ['ab', 'CD', [], {}, 42]

# Generated at 2022-06-22 22:14:11.580095
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == "1 Bytes"
    assert bytes_to_human(1, unit='kb') == "1024 Bytes"
    assert bytes_to_human(1024, unit='kb') == "1.00 KBytes"
    assert bytes_to_human(1024, unit='Kb') == "8192 bits"
    assert bytes_to_human(1025, unit='kb') == "1.00 KBytes"
    assert bytes_to_human(12582912, unit='mB') == "12.00 MBytes"
    assert bytes_to_human(13422829, unit='MB') == "12.83 MBytes"
    assert bytes_to_human(13856401, unit='mb') == "12.96 Mbits"

# Generated at 2022-06-22 22:14:23.950853
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(2) == '2 Bytes'
    assert bytes_to_human(1024) == '1.00 KBytes'
    assert bytes_to_human(1024 * 2) == '2.00 KBytes'
    assert bytes_to_human(1024 * 1024) == '1.00 MBytes'
    assert bytes_to_human(1024 * 1024 * 2) == '2.00 MBytes'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 2) == '2.00 GBytes'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024)

# Generated at 2022-06-22 22:14:36.537368
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'm') == 10485760
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10m') == 10485760
    assert human_to_bytes('10MegaByte') == 10485760
    assert human_to_bytes('10MegaBytes') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10m') == 10485760
    assert human_to_bytes(10, 'K') == 10240
    assert human_to

# Generated at 2022-06-22 22:14:48.039170
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Test function human_to_bytes."""
    assert human_to_bytes('1') == 1
    assert human_to_bytes('555') == 555
    assert human_to_bytes(555) == 555
    assert human_to_bytes(1) == 1
    assert human_to_bytes(555) == 555
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0kb') == 1024
    assert human_to_bytes('1.1M') == 1179648
    assert human_to_bytes('1.2G') == 12884901888
    assert human_to_bytes('1.3T') == 140737488355336
    assert human_to_bytes('1.4P') == 15

# Generated at 2022-06-22 22:14:57.102673
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00 EB'

# Generated at 2022-06-22 22:15:08.474757
# Unit test for function bytes_to_human
def test_bytes_to_human():
    test_dict = dict(
        test1=(1746549249, '1.65 GiB'),
        test2=(1746549249, 'GiB', 'G'),
        test3=(1746549249, 'G', 'G'),
        test4=(13, '13.00 Bytes'),
        test5=(13, 'Bytes'),
        test6=(13, '13.00 B'),
        test7=(13, 'B'),
        test8=(1746549249, 'G', 'g'),
        test9=(1746549249, 'g', 'G'),
        test10=(1746549249, 'Gb'),
        test11=(1746549249, 'MB'),
        test12=(1746549249, '2GB'),
        test13=(1746549249, 'B', 'b'),
    )


# Generated at 2022-06-22 22:15:17.700157
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Unit Test for function human_to_bytes '''
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1024.0') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K', isbits=True) == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1KB', isbits=True) == 1024
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5Kb') == 1536
    assert human_to_bytes('1.5Kb', isbits=True) == 1536

# Generated at 2022-06-22 22:15:27.129487
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """This function tests the lenient_lowercase function.

    The function lenient_lowercase accepts a list of strings, and converts each string to lower
    case. If an item in the string is not a string, the item is passed through untouched.
    The function then returns the modified list.

    The test cases are:
        1) The function converts all strings in the list to lowercase.
        2) The function leaves non-string elements untouched.
    """

    def test_one_case(input, expected_output):
        """This is a local function to test one case of the lenient_lowercase test.

        Given an input string, this function tests to ensure that the lenient_lowercase function
        converts the string to lower case. This function also ensures that non-string items are
        not converted.
        """

# Generated at 2022-06-22 22:15:38.313342
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:15:44.492349
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 3, 'b']) == ['a', 3, 'b']
    assert lenient_lowercase(['A', [1, 2], 'b']) == ['a', [1, 2], 'b']

# Generated at 2022-06-22 22:15:52.151535
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Foo', 'H3LLO']) == ['foo', 'h3LLO']
    assert lenient_lowercase([1, '2']) == [1, '2']
    assert lenient_lowercase(['1']) == ['1']
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['123', 'FOO']) == ['123', 'foo']
    assert lenient_lowercase(['123']) == ['123']
    assert lenient_lowercase(['FOO']) == ['foo']
    assert lenient_lowercase(['foo']) == ['foo']
    assert lenient_lowercase(['FoO', 'H3LLO']) == ['foo', 'h3LLO']

# Generated at 2022-06-22 22:16:00.804460
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == "0 Bytes"
    assert bytes_to_human(42) == "42 Bytes"
    assert bytes_to_human(42, isbits=True) == "42 bits"
    assert bytes_to_human(42, unit='M') == "0.04 MBytes"
    assert bytes_to_human(42, unit='M', isbits=True) == "0.04 Mbits"
    assert bytes_to_human(42, unit='G') == "0.00 GBytes"
    assert bytes_to_human(42, unit='G', isbits=True) == "0.00 Gbits"


# Generated at 2022-06-22 22:16:11.848553
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1)           == '1 Bytes'
    assert bytes_to_human(1, unit='B') == '1 Bytes'
    assert bytes_to_human(1, unit='K') == '1000 Bytes'
    assert bytes_to_human(1, unit='M') == '1000000 Bytes'
    assert bytes_to_human(1, unit='G') == '1000000000 Bytes'
    assert bytes_to_human(1, unit='T') == '1000000000000 Bytes'
    assert bytes_to_human(1, unit='P') == '1000000000000000 Bytes'
    assert bytes_to_human(1, unit='E') == '1000000000000000000 Bytes'
    assert bytes_to_human(1, unit='Z') == '1000000000000000000000 Bytes'

# Generated at 2022-06-22 22:16:16.816403
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'C']) == ['a', 'B', 'C']
    assert lenient_lowercase(['a', 2, 3]) == ['a', 2, 3]
    assert lenient_lowercase([1, 'abc', 3]) == [1, 'abc', 3]

# Generated at 2022-06-22 22:16:28.232147
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048576, unit='MB') == '1.00 MB'
    assert bytes_to_human(104857600) == '100.00 MB'

    # Bits
    assert bytes_to_human(0, isbits=True) == '0.00 bits'
    assert bytes_to_human(1, isbits=True) == '1.00 bits'
    assert bytes_to_human(10, isbits=True) == '10.00 bits'
    assert bytes_

# Generated at 2022-06-22 22:16:33.321604
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['FOO', 'bar']) == ['foo', 'bar']
    assert lenient_lowercase(['FOO', 123]) == ['foo', 123]

# Generated at 2022-06-22 22:16:39.177900
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument

    assert lenient_lowercase(['UP', 'lo', 'eth0', 'INTERNET']) == ['up', 'lo', 'eth0', 'internet']
    assert lenient_lowercase(['UP', 'lo', 'eth0', 0]) == ['up', 'lo', 'eth0', 0]



# Generated at 2022-06-22 22:16:44.019440
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1000, unit="K") == '0.98 KBytes'
    assert bytes_to_human(1999, unit="K") == '1.95 KBytes'
    assert bytes_to_human(1000000, unit="K") == '976.56 KBytes'


# Generated at 2022-06-22 22:16:51.889783
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, True) == '1.00 Kbits'
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(2048, True) == '2.00 Kbits'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024, True) == '1.00 Mbits'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024, True) == '1.00 Gbits'

# Generated at 2022-06-22 22:17:02.683914
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # test MB 
    assert bytes_to_human(1024*1024, unit='m') == '1.00 MB'
    # test KB
    assert bytes_to_human(1024, unit='k') == '1.00 KB'
    # test GB
    assert bytes_to_human(1024*1024*1024, unit='g') == '1.00 GB'
    # test TB
    assert bytes_to_human(1024*1024*1024*1024, unit='t') == '1.00 TB'
    # test PB
    assert bytes_to_human(1024*1024*1024*1024*1024, unit='p') == '1.00 PB'
    # test ZB
    assert bytes_to_human(1024*1024*1024*1024*1024*1024, unit='z') == '1.00 ZB'
    # test Y

# Generated at 2022-06-22 22:17:06.885144
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['string', 1234]
    expected_list = ['string', 1234]

    result = lenient_lowercase(test_list)
    assert result == expected_list


# Generated at 2022-06-22 22:17:13.467010
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest
    # test positive cases
    assert human_to_bytes('1B', isbits=False) == 1
    assert human_to_bytes('2B', isbits=False) == 2
    assert human_to_bytes('1KB', isbits=False) == 1 << 10
    assert human_to_bytes('2KB', isbits=False) == 2 << 10
    assert human_to_bytes('1MB', isbits=False) == 1 << 20
    assert human_to_bytes('2MB', isbits=False) == 2 << 20
    assert human_to_bytes('1GB', isbits=False) == 1 << 30
    assert human_to_bytes('2GB', isbits=False) == 2 << 30
    assert human_to_bytes('1TB', isbits=False) == 1 << 40
    assert human

# Generated at 2022-06-22 22:17:18.262285
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """Tests bytes_to_human()."""
    assert bytes_to_human('1MB') == '1.00 MB'
    assert bytes_to_human('10MB') == '10.00 MB'
    assert bytes_to_human('1Mb') == '1.00 Mbits'
    assert bytes_to_human('1Mb', isbits=True) == '1.00 Mbits'
    assert bytes_to_human('10Mb') == '10.00 Mbits'
    assert bytes_to_human('10Mb', isbits=True) == '10.00 Mbits'
    assert bytes_to_human('1KB') == '1.00 KB'
    assert bytes_to_human('1Kb') == '1.00 Kbits'

# Generated at 2022-06-22 22:17:23.745580
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', 'M') == 10485760
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5K', 'K') == 1536
    assert human_to_bytes('1.5k') == 1536
    assert human_to_bytes('1.5k', 'K') == 1536
    assert human_to_bytes('1.5k', 'k') == 1536
    assert human_to_bytes('1.5k', 'b') == 1536 * 8

# Generated at 2022-06-22 22:17:28.197201
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C', 1]) == ['a', 'b', 'c', 1]



# Generated at 2022-06-22 22:17:38.832505
# Unit test for function bytes_to_human
def test_bytes_to_human():
    input_data = [(1024, '1Kb'),
                  (102400, '100Kb'),
                  (1048576, '1Mb'),
                  (1073741824, '1Gb'),
                  (1099511627776, '1Tb'),
                  (1125899906842624, '1Pb'),
                  (1152921504606846976, '1Eb'),
                  (1180591620717411303424, '1Zb'),
                  (1208925819614629174706176, '1Yb'),
                  (1237940039285380274899124224, '1024Yb'),
                  (1267650600228229401496703205376, '1048576Yb')]
    # Testing bits

# Generated at 2022-06-22 22:17:43.153901
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['ABC', 'efg', None, 'aBc', True]
    correct_list = ['abc', 'efg', None, 'abc', True]

    assert lenient_lowercase(test_list) == correct_list


# Generated at 2022-06-22 22:17:51.447064
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Validator test
    try:
        human_to_bytes("not a string")
    except ValueError as e: assert str(e) == "human_to_bytes() failed to convert not a string (unit = None). The suffix must be one of B, K, M, G, T, P, E, Z, Y"
    try:
        human_to_bytes("  ")
    except ValueError as e: assert str(e) == "human_to_bytes() failed to convert   (unit = None). The suffix must be one of B, K, M, G, T, P, E, Z, Y"

# Generated at 2022-06-22 22:18:00.198658
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1, False) == '1.00 Bytes'
    assert bytes_to_human(2, False) == '2.00 Bytes'
    assert bytes_to_human(10, False) == '10.00 Bytes'
    assert bytes_to_human(10, False, 'B') == '10.00 Bytes'
    assert bytes_to_human(2 ** 10, False) == '1.00 KB'
    assert bytes_to_human(2 ** 10, False, 'b') == '1.00 Kbits'
    assert bytes_to_human(2 ** 10, False, 'B') == '1.00 KB'
    assert bytes_to_human(2 ** 20, False) == '1.00 MB'

# Generated at 2022-06-22 22:18:04.534572
# Unit test for function human_to_bytes
def test_human_to_bytes():
    answers = [
        (human_to_bytes('1M'), 1048576),
        (human_to_bytes('2K'), 2048),
        (human_to_bytes('1Mb', isbits=True), 1048576),
        (human_to_bytes('1Gb', isbits=True), 1073741824),
        (human_to_bytes('123B'), 123),
        (human_to_bytes('1000b', isbits=True), 125)
    ]
    for answer in answers:
        assert answer[0] == answer[1]



# Generated at 2022-06-22 22:18:11.810593
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(100) == '100.00 Bytes'
    assert bytes_to_human(10 ** 3) == '1.00 KBytes'
    assert bytes_to_human(10 ** 6) == '1.00 MBytes'
    assert bytes_to_human(10 ** 9) == '1.00 GBytes'
    assert bytes_to_human(10 ** 12) == '1.00 TBytes'

    # test for bits
    assert bytes_to_human(100, isbits=True) == '100.00 bits'
    assert bytes_to_human(10 ** 3, isbits=True) == '1.00 Kbits'
    assert bytes_to_human(10 ** 6, isbits=True) == '1.00 Mbits'

# Generated at 2022-06-22 22:18:18.360813
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['hello', 'there']) == ['hello', 'there']
    assert lenient_lowercase(['hello', True]) == ['hello', True]
    assert lenient_lowercase([5, False]) == [5, False]
    assert lenient_lowercase({'hello': 'there', 'goodbye': True}) == {'hello': 'there', 'goodbye': True}
    assert lenient_lowercase({'hello': 'there', 'goodbye': {'what': 'is', 'up': 'here'}}) == {'hello': 'there', 'goodbye': {'what': 'is', 'up': 'here'}}



# Generated at 2022-06-22 22:18:21.011218
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['AA', 'bb', {'cc': 'cc'}, ['dd']]
    assert lst == lenient_lowercase(lst)


# Generated at 2022-06-22 22:18:29.969216
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, unit='k') == '1.00 KB'
    assert bytes_to_human(1, unit='m') == '1.00 MB'
    assert bytes_to_human(1, unit='g') == '1.00 GB'
    assert bytes_to_human(1, unit='t') == '1.00 TB'
    assert bytes_to_human(1, unit='p') == '1.00 PB'
    assert bytes_to_human(1, unit='E') == '1.00 EB'
    assert bytes_to_human(1, unit='Z') == '1.00 ZB'

# Generated at 2022-06-22 22:18:41.916952
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:18:52.954107
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(10.1) == '10.1 Bytes'
    assert bytes_to_human(10.0) == '10 Bytes'
    assert bytes_to_human(10240) == '10 KB'
    assert bytes_to_human(10485760) == '10 MB'
    assert bytes_to_human(10485760), '10 MB'
    assert bytes_to_human(1073741824) == '1 GB'
    assert bytes_to_human(1099511627776) == '1 TB'
    assert bytes_to_human(1125899906842624) == '1 PB'
    assert bytes_to_human(1152921504606846976) == '1 EB'
    assert bytes_

# Generated at 2022-06-22 22:18:55.992797
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['HELLO', 'WoRld']) == ['hello', 'world']
    assert lenient_lowercase(['HELLO', None, 'WoRld']) == ['hello', None, 'world']

# Generated at 2022-06-22 22:18:58.039570
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(['K', 1, 'b', 'B'])
    assert result == ['k', 1, 'b', 'b'], result

# Generated at 2022-06-22 22:19:08.858472
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from nose.tools import assert_equal, assert_raises
    assert_equal(human_to_bytes('10M'), 10485760)
    assert_equal(human_to_bytes('10M', isbits=True), 83886080)
    assert_equal(human_to_bytes('10B'), 10)
    assert_equal(human_to_bytes('10b'), 10)
    assert_equal(human_to_bytes('10Mb'), 10485760)
    assert_equal(human_to_bytes('1k'), 1024)
    assert_equal(human_to_bytes('1k', isbits=True), 8192)
    assert_equal(human_to_bytes('1k', default_unit='M'), 1048576)

# Generated at 2022-06-22 22:19:11.129057
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [1, 'One', 'two', 'three', 4, 'Five']

    assert lenient_lowercase(test_list) == [1, 'one', 'two', 'three', 4, 'five']

# Generated at 2022-06-22 22:19:18.580926
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:19:30.341172
# Unit test for function human_to_bytes
def test_human_to_bytes():
    supported_units = list(SIZES.keys()) + ['b']
    assert len(supported_units) == len(set(supported_units))
    number_of_checked_cases = 0
    # check exception raise cases

# Generated at 2022-06-22 22:19:40.659975
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:19:47.610535
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 1, 'c']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['abc', 'efg', '', 'hij']) == ['abc', 'efg', '', 'hij']
    assert lenient_lowercase(['a', ['B'], 'c']) == ['a', ['B'], 'c']



# Generated at 2022-06-22 22:19:54.536071
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1KiB") == 1024
    assert human_to_bytes("1024") == 1024
    assert human_to_bytes("1") == 1
    assert human_to_bytes("1M") == 1048576
    assert human_to_bytes("1Mb") == 1048576
    assert human_to_bytes("1Mb", isbits=True) == 1048576
    assert human_to_bytes("1GB") == 1073741824
    assert human_to_bytes("1ZB") == 1 << 80
    assert human_to_bytes("16ZB") == 1 << 84

    # Test bits
    assert human_to_bytes("1Kb") == 128
    assert human_to_bytes("1Kb", isbits=True) == 128

    # Test bytes
    assert human_to_

# Generated at 2022-06-22 22:19:56.796256
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'



# Generated at 2022-06-22 22:20:09.650033
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:20:19.125357
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test conversions for thresholds measured in bytes
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(5) == '5 Bytes'
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1024) == '1 KB'
    assert bytes_to_human(2 * 1024) == '2 KB'
    assert bytes_to_human(1023 * 1024) == '1023 KB'
    assert bytes_to_human(1024 * 1024) == '1 MB'
    assert bytes_to_human(2 * 1024 * 1024) == '2 MB'
    assert bytes_to_human(1023 * 1024 * 1024) == '1023 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1 GB'

# Generated at 2022-06-22 22:20:28.662118
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:20:39.151339
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    # Default unit is B
    assert human_to_bytes(100) == human_to_bytes(100, 'B')
    # No unit specified
    assert human_to_bytes('100') == human_to_bytes(100, 'B')
    # Dot is OK
    assert human_to_bytes('10.5M') == human_to_bytes(10.5, 'M')
    assert human_to_bytes('10.5M') == human_to_bytes(10.5, 'M')
    assert human_to_bytes('10.5M') == human_to_bytes('10.5', 'M')
    # Case insensitive

# Generated at 2022-06-22 22:20:46.361925
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert (human_to_bytes('10M') == 10485760)
    assert (human_to_bytes('10B') == 10)
    assert (human_to_bytes('10') == 10)
    assert (human_to_bytes('10b') == 1)
    assert (human_to_bytes('10.1M') == 10485760)
    assert (human_to_bytes('10.9M') == 11010048)
    assert (human_to_bytes('10', 'M') == 10485760)
    assert (human_to_bytes('10', 'M', True) == 1048576)
    assert (human_to_bytes('10b', None, True) == 10)
    assert (human_to_bytes('10.1M', 'M', True) == 1048576)

# Generated at 2022-06-22 22:20:55.929613
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1000) == '1000.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1.5) == '1.50 KB'
    assert bytes_to_human(1024 * 1024 * 1.5) == '1.50 MB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1.5) == '1.50 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1.5, unit='K') == '1536.00 KB'
    assert bytes_to_human(1000, isbits=True) == '8000.00 bits'
    assert bytes_to_human(1024, isbits=True) == '8192.00 bits'

# Generated at 2022-06-22 22:21:01.444140
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(2**10) == '1.00 KB'
    assert bytes_to_human(10**20) == '1.00 TB'
    assert bytes_to_human(2**30, unit='b') == '1.00 Gb'



# Generated at 2022-06-22 22:21:11.511216
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, unit='B') == '1024 Bytes'
    assert bytes_to_human(1024, unit='K') == '1.00 KB'
    assert bytes_to_human(1024, unit='Kb') == '1.00 Kb'
    assert bytes_to_human(1024, isbits=True) == '8.00 Kb'
    assert bytes_to_human(1024, isbits=True, unit='B') == '8192 bits'
    assert bytes_to_human(1024, isbits=True, unit='KB') == '8192 bits'
    assert bytes_

# Generated at 2022-06-22 22:21:20.500380
# Unit test for function bytes_to_human
def test_bytes_to_human():
    bytes_values = [
        ('1', '1.00 Bytes'),
        ('500', '500.00 Bytes'),
        ('10240', '10.00 KB'),
        ('1000000', '1.00 MB'),
        ('1000000000', '1.00 GB'),
        ('1000000000000', '1.00 TB'),
        ('1000000000000000', '1.00 PB'),
    ]
    for byte_value, expected_result in bytes_values:
        result = bytes_to_human(human_to_bytes(byte_value))
        assert result == expected_result, 'got {} from {}, expected {}'.format(result, byte_value, expected_result)



# Generated at 2022-06-22 22:21:31.210972
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(5) == '5.00 Bytes'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(1023) == '1023.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1025) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024)

# Generated at 2022-06-22 22:21:42.681929
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:21:54.220308
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(555) == '555 Bytes'
    assert bytes_to_human(555, unit='B') == '555 Bytes'
    assert bytes_to_human(555, unit='b') == '555 bits'
    assert bytes_to_human(555, isbits=True) == '555 bits'
    assert bytes_to_human(555, isbits=True, unit='b') == '555 bits'

    assert bytes_to_human(1000) == '1000 Bytes'
    assert bytes_to_human(1000, unit='B') == '1000 Bytes'
    assert bytes_to_human(1000, unit='b') == '1000 bits'
    assert bytes_to_human(1000, isbits=True) == '1000 bits'

# Generated at 2022-06-22 22:22:03.524706
# Unit test for function human_to_bytes