

# Generated at 2022-06-22 22:12:06.034285
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["AAA", 1, 2, "BBB", "ccc"]) == ["aaa", 1, 2, "bbb", "ccc"]

# Generated at 2022-06-22 22:12:15.213284
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:12:19.803493
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['A']) == ['a']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 'A']) == [1, 'a']
    assert lenient_lowercase(['A', 1, 'B', 2, 'C']) == ['a', 1, 'b', 2, 'c']

# Generated at 2022-06-22 22:12:30.366245
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:12:37.391095
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    # Simple string test
    assert lenient_lowercase(['a', 'b', 'C', 'd']) == ['a', 'b', 'c', 'd']

    # Integer test
    assert lenient_lowercase([1, 2]) == [1, 2]

    # Mixed test
    assert lenient_lowercase(['A', 1]) == ['a', 1]



# Generated at 2022-06-22 22:12:45.177329
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:12:56.214641
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:13:03.091947
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:13:06.282988
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    units = ['a', 'b', 4, 'C', 'd']
    expected = ['a', 'b', 4, 'c', 'd']
    test = lenient_lowercase(units)
    assert test == expected

# Generated at 2022-06-22 22:13:15.028488
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Byte'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human(1125899906842624) == '1.00 TB'
    assert bytes_to_human(1152921504606846976) == '1.00 PB'
    assert bytes_to_human(1180591620717411303424) == '1.00 EB'

# Generated at 2022-06-22 22:13:24.421633
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test case_1
    size = "1B"
    expect = 1
    result = human_to_bytes(size)
    assert expect == result

    # test case_2
    size = "1KB"
    expect = 1024
    result = human_to_bytes(size)
    assert expect == result

    # test case_3
    size = "1.2M"
    expect = 1200000
    result = human_to_bytes(size)
    assert expect == result

    # test case_4
    size = "1.2mb"
    expect = 1200000
    result = human_to_bytes(size, isbits=True)
    assert expect == result

    # test case_5
    size = "1"
    expect = 1
    result = human_to_bytes(size)
    assert expect == result

# Generated at 2022-06-22 22:13:33.109245
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1000) == "1000.00 Bytes", 'bytes_to_human failed return value for 1000'
    assert bytes_to_human(1000, False, None) == "1000.00 Bytes", 'bytes_to_human failed return value for 1000 byte'
    assert bytes_to_human(1000, True, None) == "8000.00 bits", 'bytes_to_human failed return value for 1000 bit'
    assert bytes_to_human(1000, unit='K') == "1.00 KB", 'bytes_to_human failed return value for 1000K'
    assert bytes_to_human(1000, True, 'K') == "8000.00 Kb", 'bytes_to_human failed return value for 1000Kbit'



# Generated at 2022-06-22 22:13:41.883793
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # convert bytes to human-readable format
    assert human_to_bytes('0.5Mb', isbits=True) == 524288
    # check passed unit is valid
    try:
        assert human_to_bytes('1Bb')
    except ValueError as e:
        assert "expect Bb or bit" in str(e)
    # add unit if none is given
    assert human_to_bytes('1', default_unit='M') == 1048576
    # check that return type is an integer
    assert type(human_to_bytes('1M')) == int
    # check if case insensitive
    assert human_to_bytes('1M') == 1048576
    # check if bytes argument is converted to float
    assert human_to_bytes('1.5M') == 1572864

# Generated at 2022-06-22 22:13:55.228263
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(10240) == '10.00 KB'
    assert bytes_to_human(102937) == '100.62 KB'
    assert bytes_to_human(102937, unit='b') == '823.49 Kb'
    assert bytes_to_human(102937, unit='b', isbits=True) == '823.49 Kb'

    # test bits case
    assert bytes_to_human(1024, isbits=True) == '8.00 Kb'

# Generated at 2022-06-22 22:14:02.304288
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1B', default_unit='B') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K', default_unit='B') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1M') == 1024 ** 2
    assert human_to_bytes('1Mb') == 1024 ** 2
    assert human_to_bytes('1Mb', isbits=True) == 1024 ** 2
    assert human_to_bytes('1M', default_unit='B') == 1024 ** 2

# Generated at 2022-06-22 22:14:11.913083
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test with no string
    assert(lenient_lowercase([]) == [])
    # Test with string
    assert(lenient_lowercase(['a', 'b']) == ['a', 'b'])
    # Test with one string
    assert(lenient_lowercase(['c']) == ['c'])
    # Test with one int
    assert(lenient_lowercase([1]) == [1])
    # Test with unicode string
    assert(lenient_lowercase([u'e']) == [u'e'])
    assert(lenient_lowercase([u'é']) == [u'é'])
    # Test with int and string
    assert(lenient_lowercase([1, u'é', 'a']) == [1, u'é', 'a'])



# Generated at 2022-06-22 22:14:21.247109
# Unit test for function human_to_bytes
def test_human_to_bytes():
    for i in range(10):
        for j in ['Y', 'Z', 'E', 'P', 'T', 'G', 'M', 'K']:
            assert human_to_bytes(str(i) + j) == SIZE_RANGES[j] * i, "Problem with %s" % str(i) + j
            assert human_to_bytes(str(i) + j.lower()) == SIZE_RANGES[j] * i, "Problem with %s" % str(i) + j.lower()

    assert human_to_bytes('2.5M') == 2 * SIZE_RANGES['M'] + SIZE_RANGES['K'] * 512, "Problem with 2.5M"

# Generated at 2022-06-22 22:14:29.657532
# Unit test for function bytes_to_human
def test_bytes_to_human():
    import unittest
    class TestBytesToHuman(unittest.TestCase):
        def test_bytes(self):
            self.assertEqual(bytes_to_human(10), '10 Bytes')
            self.assertEqual(bytes_to_human(1024), '1.00 KB')
            self.assertEqual(bytes_to_human(1025), '1.00 KB')
            self.assertEqual(bytes_to_human(1048576), '1.00 MB')
            self.assertEqual(bytes_to_human(10485760), '10.00 MB')
            self.assertEqual(bytes_to_human(104857600), '100.00 MB')
            self.assertEqual(bytes_to_human(1048576000), '1000.00 MB')

# Generated at 2022-06-22 22:14:40.358385
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("Unit test for function human_to_bytes()")
    print("human_to_bytes('1b') - expected: 1, got: %s" % human_to_bytes('1b'))
    print("human_to_bytes('1.0') - expected: 1.0, got: %s" % human_to_bytes('1.0'))
    print("human_to_bytes('1') - expected: 1, got: %s" % human_to_bytes('1'))
    print("human_to_bytes('1b', isbits=True) - expected: 1, got: %s" % human_to_bytes('1b', isbits=True))

# Generated at 2022-06-22 22:14:46.465739
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    original_list = ['A', 'B', 2, 3, 4, 'C', None]
    lowercased = lenient_lowercase(original_list)
    assert original_list != lowercased
    assert lowercased == ['a', 'b', 2, 3, 4, 'c', None]
    assert original_list == ['A', 'B', 2, 3, 4, 'C', None]



# Generated at 2022-06-22 22:14:52.602168
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase("test") == "test"
    assert lenient_lowercase("Test") == "test"
    assert lenient_lowercase("TEST") == "test"

    assert lenient_lowercase([1, "Test", 3]) == [1, "test", 3]
    assert lenient_lowercase(("test", "Test", "TEST")) == ("test", "test", "test")



# Generated at 2022-06-22 22:15:02.931713
# Unit test for function bytes_to_human
def test_bytes_to_human():
    size = 10240
    unit = 'k'
    s = bytes_to_human(size, unit=unit)
    assert s == '10.00 KB'

    unit = 'b'
    s = bytes_to_human(size, unit=unit)
    assert s == '10240 bits'

    size = 10485760
    unit = 'm'
    s = bytes_to_human(size, unit=unit)
    assert s == '10.00 MB'

    size = 10485760000
    unit = 'g'
    s = bytes_to_human(size, unit=unit)
    assert s == '10.00 GB'

    size = 104857600000000
    unit = 't'
    s = bytes_to_human(size, unit=unit)
    assert s == '10.00 TB'



# Generated at 2022-06-22 22:15:10.774460
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    a_list = ['A', 'B', 'C', False, None, {'A': '1', 'B': '2'}, ['1', '2']]
    result = lenient_lowercase(a_list)

    try:
        assert result == ['a', 'b', 'c', False, None, {'A': '1', 'B': '2'}, ['1', '2']], "The values are not equal!"
    except AssertionError as e:
        print (e.args)

    print("Lenient lowercase test passed!")



# Generated at 2022-06-22 22:15:19.080866
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Giga
    assert bytes_to_human(1 << 30) == '1.00 GB'

    # Mega
    assert bytes_to_human(1 << 20) == '1.00 MB'

    # Kilo
    assert bytes_to_human(1 << 10) == '1.00 KB'

    # Giga
    assert bytes_to_human(1 << 30, unit='B') == '1.00 GB'

    # Kilo
    assert bytes_to_human(1 << 10, unit='B') == '1.00 KB'

    # Giga bits
    assert bytes_to_human(1 << 30, isbits=True) == '1.00 Gb'

    # Mega bits
    assert bytes_to_human(1 << 20, isbits=True) == '1.00 Mb'

    # Kilo bits

# Generated at 2022-06-22 22:15:22.537011
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    data = ['Test', u'Test', 1, 2.0, [1], (1,)]
    result = lenient_lowercase(data)
    assert result == ['test', u'Test', 1, 2.0, [1], (1,)]

# Generated at 2022-06-22 22:15:29.891189
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """
    Unit test for function human_to_bytes.
    """


# Generated at 2022-06-22 22:15:36.984301
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase([True]) == [True]
    assert lenient_lowercase(['a', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase((2.2, 3.3, 4.4)) == (2.2, 3.3, 4.4)



# Generated at 2022-06-22 22:15:43.033112
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Valid input
    assert (lenient_lowercase(['A', 'a', 'A', 'b', 'B', 'X']) == ['a', 'a', 'a', 'b', 'b', 'x'])

    # Invalid input
    assert (lenient_lowercase(['1', 2, '3', '4', 5]) == ['1', 2, '3', '4', 5])



# Generated at 2022-06-22 22:15:51.533432
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == "0 Bytes"
    assert bytes_to_human(1) == "1 Bytes"
    assert bytes_to_human(2) == "2 Bytes"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1025) == "1.00 KB"
    assert bytes_to_human(1024 * 1024) == "1.00 MB"
    assert bytes_to_human(1024 * 1024 * 1024) == "1.00 GB"
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == "1.00 TB"
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == "1.00 PB"

# Generated at 2022-06-22 22:15:59.783571
# Unit test for function bytes_to_human
def test_bytes_to_human():
    cases = (
        # (input, human, bits_human)
        (2 ** 3, '8.00 Bytes', '8.00 bits'),
        (2 ** 10, '1.00 KB', '8.00 Kb'),
        (2 ** 20, '1.00 MB', '8.00 Mb'),
        (2 ** 30, '1.00 GB', '8.00 Gb'),
        (2 ** 40, '1.00 TB', '8.00 Tb'),
        (2 ** 50, '1.00 PB', '8.00 Pb'),
        (2 ** 60, '1.00 EB', '8.00 Eb'),
        (2 ** 70, '1.00 ZB', '8.00 Zb'),
        (2 ** 80, '1.00 YB', '8.00 Yb'),
    )

# Generated at 2022-06-22 22:16:11.085590
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0, False) == '0.00 Bytes'
    assert bytes_to_human(0, True) == '0.00 bits'
    assert bytes_to_human(0, False, 'B') == '0.00 Bytes'
    assert bytes_to_human(0, True, 'B') == '0.00 bits'
    assert bytes_to_human(1, False) == '1.00 B'
    assert bytes_to_human(1, True) == '1.00 b'
    assert bytes_to_human(1, False, 'B') == '1.00 B'
    assert bytes_to_human(1, True, 'B') == '1.00 b'
    assert bytes_to_human(1, False, 'K') == '0.00 KB'

# Generated at 2022-06-22 22:16:23.532441
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(1 << 10) == '1.00 KB'
    assert bytes_to_human(1 << 20) == '1.00 MB'
    assert bytes_to_human(1 << 30) == '1.00 GB'
    assert bytes_to_human(1 << 40) == '1.00 TB'
    assert bytes_to_human(1 << 50) == '1.00 PB'
    assert bytes_to_human(1 << 60) == '1.00 EB'
    assert bytes_to_human(1 << 70) == '1.00 ZB'
    assert bytes_to_human

# Generated at 2022-06-22 22:16:35.013604
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(100) == '100.00 Bytes'
    assert bytes_to_human(999) == '999.00 Bytes'
    assert bytes_to_human(1000) == '1.00 KB'
    assert bytes_to_human(1001) == '1.00 KB'
    assert bytes_to_human(1023) == '1.00 KB'
    assert bytes_to_human(1025) == '1.00 KB'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024)

# Generated at 2022-06-22 22:16:43.896443
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0.00 Bytes'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048577) == '1.00 MB'
    assert bytes_to_human(1048576, unit='K') == '1024.00 K'
    assert bytes_to_human(1048576, unit='k') == '1024.00 K'
    assert bytes_to_human(1048576, unit='M') == '1.00 M'
    assert bytes_to_human(1048576, unit='m') == '1.00 M'
    assert bytes_to_human(1048576, unit='G') == '1.00 G'

# Generated at 2022-06-22 22:16:47.707775
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Create a lists to lowercase
    lst = ['A', 'B', 'C', 'a', 'b', 'c', 1, 2, 3]

    lowered = lenient_lowercase(lst)

    assert lowered == ['a', 'b', 'c', 'a', 'b', 'c', 1, 2, 3]



# Generated at 2022-06-22 22:16:59.411904
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, isbits=True) == '10.00 bits'
    assert bytes_to_human(10, unit='b') == '10.00 bits'
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'
    assert bytes_to_human('10') == '10.00 Bytes'
    assert bytes_to_human('10', isbits=True) == '10.00 bits'
    assert bytes_to_human('10b') == '10.00 bits'
    assert bytes_to_human('10B') == '10.00 Bytes'
    assert bytes_to_human('10Mb') == '10.00 Mbits'

# Generated at 2022-06-22 22:17:03.014511
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [12, 12.3, 'a', 'Ab', '1BC']
    expect_list = [12, 12.3, 'a', 'ab', '1bc']
    assert lenient_lowercase(test_list) == expect_list, 'lenient_lowercase failed'


# Generated at 2022-06-22 22:17:15.325461
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:17:20.918762
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    for test in (
            ['first', 'Second', '3rd', 4, 'FIFTH', 6, 7, 'eighth'],
            [('first', 'Second', '3rd'), 4, 'FIFTH', 'eighth', {'ninth': True}]
    ):
        assert lenient_lowercase(test) == ['first', 'second', '3rd', 4, 'fifth', 6, 7, 'eighth']

# Generated at 2022-06-22 22:17:32.468560
# Unit test for function human_to_bytes
def test_human_to_bytes():
    human_to_bytes('500mb')
    human_to_bytes('500mb', isbits=True)
    human_to_bytes('500MB', isbits=True)
    human_to_bytes('500 Mb', isbits=True, default_unit='MB')
    human_to_bytes('500.8Mb', isbits=True)
    human_to_bytes('500.8 Mb', isbits=True, default_unit='MB')
    human_to_bytes('500MB', default_unit='MB')
    human_to_bytes('500M')
    human_to_bytes('500 MB')
    human_to_bytes('500 MB', default_unit='MB')
    human_to_bytes('500.8 MB')
    human_to_bytes('500.8 MB', default_unit='MB')
    human_

# Generated at 2022-06-22 22:17:39.600401
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(int(1E6)) == "1.00 MB"
    assert bytes_to_human(int(2E6)) == "2.00 MB"
    assert bytes_to_human(int(1234567890)) == "1.15 GB"
    assert bytes_to_human(int(1234567890123)) == "1.15 TB"
    assert bytes_to_human(int(1234567890123456)) == "1.15 PB"
    assert bytes_to_human(int(1234567890123456789)) == "1.15 EB"

    assert bytes_to_human(int(1234567890123456789), 'b') == "9.60 EB"

# Generated at 2022-06-22 22:17:42.850040
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    l = ['A', 'B', 1, 2, 'C']
    assert (lenient_lowercase(l) == ['a', 'b', 1, 2, 'c'])



# Generated at 2022-06-22 22:17:51.313058
# Unit test for function bytes_to_human
def test_bytes_to_human():
    size = 700
    expected = '700 Bytes'
    actual = bytes_to_human(size)
    assert expected == actual

    size = 1024
    expected = '1.00 KB'
    actual = bytes_to_human(size)
    assert expected == actual

    size = 1024*1024
    expected = '1.00 MB'
    actual = bytes_to_human(size)
    assert expected == actual

    size = 1024*1024*1024
    expected = '1.00 GB'
    actual = bytes_to_human(size)
    assert expected == actual

    size = 1024*1024*1024*1024
    expected = '1.00 TB'
    actual = bytes_to_human(size)
    assert expected == actual

    size = 1024*1024*1024*1024*1024
    expected = '1.00 PB'


# Generated at 2022-06-22 22:18:03.835631
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:18:11.424859
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(2 * SIZE_RANGES['K']) == '2 KB'
    assert bytes_to_human(2 * SIZE_RANGES['M']) == '2 MB'
    assert bytes_to_human(2 * SIZE_RANGES['G']) == '2 GB'
    assert bytes_to_human(2 * SIZE_RANGES['T']) == '2 TB'
    assert bytes_to_human(2 * SIZE_RANGES['P']) == '2 PB'

# Generated at 2022-06-22 22:18:16.486671
# Unit test for function human_to_bytes
def test_human_to_bytes():
    tests = [('10', '10B'),
             ('10 Kb', '10240b'),
             ('10 KB', '10240B'),
             ('10 Mb', '10485760b'),
             ('10 MB', '10485760B'),
             ('10 Gb', '10737418240b'),
             ('10 GB', '10737418240B'),
             ('10 Tb', '10995116277760b'),
             ('10 TB', '10995116277760B')]

    for test in tests:
        result = human_to_bytes(test[0], isbits=True)
        assert result == int(test[1][:-1]), 'Test failed: {}!={}'.format(test, result)


# Generated at 2022-06-22 22:18:26.959531
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Test function human_to_bytes '''
    print("########## TEST FUNCTION human_to_bytes ##########")

# Generated at 2022-06-22 22:18:29.497331
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'b', 1]

# Generated at 2022-06-22 22:18:41.519200
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:18:52.889800
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # no unit given
    assert human_to_bytes('10M', default_unit='MB') == 10485760
    # no default unit given - raw number expected
    assert human_to_bytes('10') == 10
    # default unit given - raw number expected
    assert human_to_bytes('10', default_unit='Mb') == 10
    # ValueError expected when no argument was given
    try:
        human_to_bytes('', default_unit='Mb')
    except ValueError as e:
        assert(e.message == "human_to_bytes() can't interpret following string: ")

    # ValueError expected when no number was given

# Generated at 2022-06-22 22:18:58.081721
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:19:01.833944
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'aBc', 123, 'ABC']) == [1, 'abc', 123, 'abc']

# Unit tests for function human_to_bytes

# Generated at 2022-06-22 22:19:13.276949
# Unit test for function bytes_to_human
def test_bytes_to_human():
    result = bytes_to_human(1024)
    assert '1.00 KB' == result, 'result should be 1.00 KB, but is %s' % result

    result = bytes_to_human(1024 * 1024 * 1.5)
    assert '1.50 MB' == result, 'result should be 1.50 MB, but is %s' % result

    result = bytes_to_human(1024 * 1024 * 1024 * 1.5)
    assert '1.50 GB' == result, 'result should be 1.50 GB, but is %s' % result

    result = bytes_to_human(1024 * 1024 * 1024, unit='b')
    assert '8388608 bits' == result, 'result should be 1.50 GB, but is %s' % result


# Generated at 2022-06-22 22:19:23.484113
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    from nose.tools import with_setup, assert_equals, assert_raises

    def setup():
        pass

    def teardown():
        pass

    @with_setup(setup, teardown)
    def test_lenient_lowercase():
        my_dict = {'key1': 1, 'key2': 'val2'}
        my_list = ['val1', 1, 'val2']

        assert_equals(['val1'], lenient_lowercase(['val1']))
        assert_equals(['val1'], lenient_lowercase(['VAL1']))
        assert_equals(['val1', 1], lenient_lowercase(['VAL1', 1]))

# Generated at 2022-06-22 22:19:32.548441
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes('10Mb') == human_to_bytes(10, 'Mb', True)
    assert human_to_bytes('5B') == 5
    assert human_to_bytes('5b') == human_to_bytes(5, 'b', True)
    assert human_to_bytes('5Gi') == human_to_bytes(5, 'Gi')
    assert human_to_bytes('5GiB') == human_to_bytes(5, 'GiB')
    assert human_to_bytes('5GiB', True) == human_to_bytes(5, 'GiB', True)

    # Exception:
    # Can't convert a number provided as

# Generated at 2022-06-22 22:19:36.820227
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 1, 'b']) == ['a', 1, 'b']
    assert lenient_lowercase(['A', 1, 'B']) == ['a', 1, 'b']



# Generated at 2022-06-22 22:19:46.656142
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('1 , 0 0 0') == 1000
    assert human_to_bytes('8b', isbits=True) == 1
    assert human_to_bytes('8b', isbits=False) == 8
    assert human_to_bytes('1kb', isbits=False) == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('0.5T', isbits=False) == 5368709120
    assert human_to_bytes('0.5T', isbits=True) == 429496729600
    assert human_to_bytes('4Gb', isbits=False) == 4294967296

# Generated at 2022-06-22 22:19:53.413896
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """Unit tests for function bytes_to_human()."""
    assert bytes_to_human(1, isbits=False) == '1.00 Bytes'
    assert bytes_to_human(1, isbits=True) == '1.00 bits'
    assert bytes_to_human(2000, isbits=True) == '16.00 Kbits'
    assert bytes_to_human(2000, isbits=False, unit='B') == '2.00 KB'
    assert bytes_to_human(2000, isbits=False, unit='K') == '2.00 KB'
    assert bytes_to_human(2000, isbits=False, unit='KB') == '2.00 KB'



# Generated at 2022-06-22 22:19:58.979908
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:20:11.194200
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:20:20.498700
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:20:31.073319
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('0b') == 0)
    assert(human_to_bytes('1bit') == 1)
    assert(human_to_bytes('2bit') == 2)
    assert(human_to_bytes('2.5bit') == 2)
    assert(human_to_bytes('1.5bit') == 1)

    assert(human_to_bytes('0B') == 0)
    assert(human_to_bytes('1Byte') == 1)
    assert(human_to_bytes('2Byte') == 2)
    assert(human_to_bytes('2.5Byte') == 2)
    assert(human_to_bytes('1.5Byte') == 1)

    assert(human_to_bytes('0kB') == 0)

# Generated at 2022-06-22 22:20:41.519974
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10M', isbits=True) == 10485760
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2KB') == 2048
    assert human_to_bytes('2Kb', isbits=True) == 2048
    assert human_to_bytes('2K', isbits=True) == 2048
    assert human_to_bytes('2Mb', default_unit='b', isbits=True) == 2097152
    assert human_to_bytes('2MB', default_unit='B') == 2097152
    assert human

# Generated at 2022-06-22 22:20:48.824145
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2k') == 2 * 1024
    assert human_to_bytes('2K') == 2 * 1024
    assert human_to_bytes('5MB') == 2 * 1024 * 1024 * 2.5
    assert human_to_bytes('5MB') == 2 * 1024 * 1024 * 2.5
    assert human_to_bytes('5MB', isbits=True) == 2 * 1000 * 1000 * 2.5
    assert human_to_bytes('5MB', isbits=True) == 2 * 1000 * 1000 * 2.5
    assert human_to_bytes('5MB', unit='b') == 2 * 1000 * 1000 * 2.5
    assert human_to_bytes('5MB', unit='B') == 2 * 1024 * 1024 * 2.5
    assert human_to_bytes('1b') == 1
    assert human

# Generated at 2022-06-22 22:20:57.036240
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test for default
    assert bytes_to_human(1234) == '1.23 KB'
    assert bytes_to_human(1234, False, 'K') == '1.23 KB'
    assert bytes_to_human(1234) == '1.23 KB'
    assert bytes_to_human(1234, False, 'K') == '1.23 KB'
    assert bytes_to_human(1234, True, 'K') == '1.23 Kb'
    assert bytes_to_human(1234, False, 'Mi') == '0.00 MB'
    assert bytes_to_human(1234, True, 'Mi') == '0.00 Mb'
    assert bytes_to_human(1234, False, 'Gi') == '0.00 GB'

# Generated at 2022-06-22 22:21:07.031971
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(1000) == '1.00 KB'
    assert bytes_to_human(1023) == '1.02 KB'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 ** 2) == '1.00 MB'
    assert bytes_to_human(1024 ** 3) == '1.00 GB'
    assert bytes_to_human(1024 ** 4) == '1.00 TB'
    assert bytes_to_human(1024 ** 5) == '1.00 PB'
    assert bytes_to_human(1024 ** 6) == '1.00 EB'

# Generated at 2022-06-22 22:21:18.866602
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        assert lenient_lowercase([]) == []
        assert lenient_lowercase(['foo']) == ['foo']
        assert lenient_lowercase(['foo', 'Bar']) == ['foo', 'Bar']
        assert lenient_lowercase(['FOO', 'Bar']) == ['foo', 'Bar']
        assert lenient_lowercase(['FOO', '123']) == ['foo', '123']
        assert lenient_lowercase([u'fóo']) == [u'fóo']
        assert lenient_lowercase([u'fÓo']) == [u'fÓo']
    except AssertionError:
        raise
    except Exception:
        raise AssertionError("function lenient_lowercase failed")


# Generated at 2022-06-22 22:21:23.546469
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    net_os_platform = ('juniper_junos_system', ['MX240', 'JNC', 'JCP'])
    assert lenient_lowercase(net_os_platform[1]) == ['mx240', 'jnc', 'jcp']
    net_os_platform = ('juniper_junos_system', [123, 456, 789])
    assert lenient_lowercase(net_os_platform[1]) == [123, 456, 789]



# Generated at 2022-06-22 22:21:27.040615
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['FOO', 'BAR']) == ['foo', 'bar']
    assert lenient_lowercase([{'FOO': 'bar'}]) == [{'FOO': 'bar'}]


# Generated at 2022-06-22 22:21:37.685216
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1.1M") == 1153433
    assert human_to_bytes("2.2K") == 2200
    assert human_to_bytes("1.1G") == 11258999068426
    assert human_to_bytes("1.1T") == 11258999068426000
    assert human_to_bytes("1.1E") == 11258999068426000000
    assert human_to_bytes("1.1P") == 11258999068426000000000
    assert human_to_bytes("1.1Z") == 11258999068426000000000000
    assert human_to_bytes("1.1Y") == 11258999068426000000000000000

    assert human_to_bytes("1.1") == 1.1
    assert human_to_bytes("2") == 2


# Generated at 2022-06-22 22:21:43.170756
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Check base cases
    assert bytes_to_human(0) == "0 Bytes"
    assert bytes_to_human(1) == "1 Byte"
    assert bytes_to_human(1024) == "1.00 KBytes"
    assert bytes_to_human(1024 * 1024 * 4) == "4.00 MBytes"

    # Check if all units are working properly
    for unit in ['B', 'K', 'M', 'G', 'T', 'E', 'P', 'Z', 'Y']:
        assert bytes_to_human(SIZE_RANGES[unit]) == "1.00 " + unit + "Bytes"

    # Check if we can use bits as base unit
    assert bytes_to_human(1024, isbits=True) == "1.00 Kbits"

    # Check if we can limit the suffix


# Generated at 2022-06-22 22:21:46.376429
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'a', 'A', 'B', 'zZz', 'Z']) == [1, 'a', 'a', 'b', 'zzz', 'z']

# Generated at 2022-06-22 22:21:56.245760
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''
    Tests for bytes_to_human function
    '''
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1024) == '1 KB'
    assert bytes_to_human(1024*1024) == '1 MB'
    assert bytes_to_human(1024*1024*1024) == '1 GB'
    assert bytes_to_human(1024*1024*1024*1024) == '1 TB'
    assert bytes_to_human(1024*1024*1024*1024*1024) == '1 PB'
    assert bytes_to_human(1024*1024*1024*1024*1024*1024) == '1 EB'
    assert bytes_to_human(1024*1024*1024*1024*1024*1024*1024) == '1 ZB'

# Generated at 2022-06-22 22:22:05.085792
# Unit test for function bytes_to_human
def test_bytes_to_human():

    # Test case 1
    # Bits to human readable format
    option = bytes_to_human(2000000000, isbits=True)
    assert option == "2.00 Gbits"

    # Test case 2
    # Bytes to human readable format
    option = bytes_to_human(2000000000)
    assert option == "2.00 GB"

    # Test case 3
    # Invalid unit format
    try:
        bytes_to_human(2000000000, unit="GBB")
    except ValueError:
        assert True
    else:
        assert False

    # Test case 4
    # Invalid unit format
    try:
        bytes_to_human(2000000000, unit="bb")
    except ValueError:
        assert True
    else:
        assert False

    # Test case 5
    # Bytes to human readable format with kb unit