

# Generated at 2022-06-22 22:12:11.850609
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_dict = {
        '1b': 1,
        '1B': 1,
        '1kb': 1024,
        '1kB': 1024,
        '1Kb': 1024,
        '1KB': 1024,
        '1mb': 1048576,
        '1mB': 1048576,
        '1Mb': 1048576,
        '1MB': 1048576,
        '1GB': 1073741824,
        '2MB': 2097152,
        '100000': 100000,
        '12': 12,
        '25K': 25600,
    }
    for key, value in test_dict.items():
        result = human_to_bytes(key)

# Generated at 2022-06-22 22:12:21.094761
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10 * SIZE_RANGES['K'], unit='b') == '80.00 Kbits'
    assert bytes_to_human(10 * SIZE_RANGES['K'], unit='B') == '10.00 KB'
    assert bytes_to_human(10 * SIZE_RANGES['K']) == '10.00 KB'
    assert bytes_to_human(10 * SIZE_RANGES['K'], unit='k') == '10240.00 B'
    assert bytes_to_human(10 * SIZE_RANGES['K'], unit='k', isbits=True) == '81920.00 Kbits'
    assert bytes_to_human(10 * SIZE_RANGES['K']) == '10.00 KB'
    assert bytes_to_

# Generated at 2022-06-22 22:12:25.812054
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['x', 'Y', 'z']) == ['x', 'y', 'z']
    assert lenient_lowercase(['x', 42, 'z']) == ['x', 42, 'z']
    assert lenient_lowercase([42, 'x', 64]) == [42, 'x', 64]



# Generated at 2022-06-22 22:12:36.223917
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == "1.00 Bytes"
    assert bytes_to_human(1, unit='B') == "1.00 Bytes"
    assert bytes_to_human(1, unit='b') == "8.00 bits"
    assert bytes_to_human(10) == "10.00 Bytes"
    assert bytes_to_human(10, unit='b') == "80.00 bits"
    assert bytes_to_human(100) == "100.00 Bytes"
    assert bytes_to_human(100, unit='b') == "800.00 bits"
    assert bytes_to_human(1000) == "1000.00 Bytes"
    assert bytes_to_human(1000, unit='b') == "8000.00 bits"

# Generated at 2022-06-22 22:12:38.930805
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["INDEX", 1, 2, 3]) == ["index", 1, 2, 3]

# Generated at 2022-06-22 22:12:47.357018
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # the function human_to_bytes(number) is covered by test_acl_config.py
    # Here is testing for the function: human_to_bytes(number, unit)
    assert human_to_bytes('2K') == human_to_bytes(2, 'K')
    assert human_to_bytes('20M') == human_to_bytes(20, 'M')
    assert human_to_bytes('2mb') == human_to_bytes(2, 'mb', isbits=True)
    assert human_to_bytes('2Mb') == human_to_bytes(2, 'mb', isbits=True)
    assert human_to_bytes('2MB') == human_to_bytes(2, 'mb', isbits=True)
    assert human_to_bytes('2mb', isbits=True) == human_to

# Generated at 2022-06-22 22:12:57.558000
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["A", "b", "1", "2", "c"]) == ["a", "b", "1", "2", "c"]
    assert lenient_lowercase(["A", "b", "1", "2", 3, "c"]) == ["a", "b", "1", "2", 3, "c"]
    assert lenient_lowercase(["A", ["b", 1], "2", 3, "c"]) == ["a", ["b", 1], "2", 3, "c"]
    assert lenient_lowercase(["A", ["b", 1], ["C", "d"], 3, "e"]) == ["a", ["b", 1], ["C", "d"], 3, "e"]

# Generated at 2022-06-22 22:13:09.453063
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(999, False, "B") == "999.00 Bytes"
    assert bytes_to_human(1000, False, "B") == "1.00 KB"
    assert bytes_to_human(1000, False, "KB") == "1.00 KB"
    assert bytes_to_human(1023, False, "K") == "1023.00 Bytes"
    assert bytes_to_human(1024, False, "K") == "1.00 KB"
    assert bytes_to_human(1025, False, "K") == "1.00 KB"
    assert bytes_to_human(1048576, False, "K") == "1024.00 KB"
    assert bytes_to_human(1048577, False, "K") == "1.00 MB"
    assert bytes_to_

# Generated at 2022-06-22 22:13:11.159923
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 42, None]) == ['a', 'b', 42, None]

# Generated at 2022-06-22 22:13:12.914344
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['ABC', 'D', 'Ef', 123]) == ['abc', 'd', 'ef', 123]


# Generated at 2022-06-22 22:13:19.891569
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Test the lenient_lowercase function."""
    mixed_list = ['FOo', 'bar', 1, 52.4, ['bar', 'baz']]
    lowered = lenient_lowercase(mixed_list)

    assert(lowered[0] == 'foo')
    assert(lowered[1] == 'bar')
    assert(lowered[2] == 1)
    assert(lowered[3] == 52.4)
    assert(lowered[4][0] == 'bar')
    assert(lowered[4][1] == 'baz')


# Generated at 2022-06-22 22:13:31.352951
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Unit test for function bytes_to_human
    # First test some basic functionality
    assert bytes_to_human(1234) == '1.23 KBytes'
    assert bytes_to_human(1234567890) == '1.15 GBytes'
    assert bytes_to_human(3145778438098) == '285.30 TBytes'
    assert bytes_to_human(3145778438098, unit='T') == '3.15 TBytes'
    assert bytes_to_human(3145778438098, unit='t') == '3.15 TBytes'
    assert bytes_to_human(3145778438098, unit='G') == '3145.78 GBytes'

# Generated at 2022-06-22 22:13:40.145722
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert '0 Bytes' == bytes_to_human(0)

    assert '1048576 Bytes' == bytes_to_human(1048576)

    assert '1 MB' == bytes_to_human(1048576)

    assert '1 MB' == bytes_to_human(1048576, unit='m')

    assert '1 M' == bytes_to_human(1048576, unit='b')

    assert '0 bits' == bytes_to_human(0, isbits=True)

    assert '8388608 bits' == bytes_to_human(1048576, isbits=True)

    assert '8388608 b' == bytes_to_human(1048576, isbits=True, unit='b')


# Generated at 2022-06-22 22:13:47.583466
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test for lowercasing of string and integers
    result = lenient_lowercase(['A', 1, 'C', 2])
    assert result == ['a', 1, 'c', 2]
    # Test for no exception handling on a non string object
    bad_input = lenient_lowercase(['A', 'B', 1, 'c', {'a': 1}])
    assert bad_input == ['a', 'b', 1, 'c', {'a': 1}]


# Generated at 2022-06-22 22:13:51.845369
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['foo', 1, 'bar'] == lenient_lowercase(['foo', 1, 'bar'])
    assert ['foo', 'bar'] == lenient_lowercase(['FOO', 'BAR'])


# Generated at 2022-06-22 22:14:00.110130
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1024) == "1.00 KBytes"
    assert bytes_to_human(1024 * 1024) == "1.00 MBytes"
    assert bytes_to_human(1.2 * 1024 * 1024 * 1024) == "1.20 GBytes"
    assert bytes_to_human(1.2 * 1024 ** 3) == "1.20 GBytes"
    assert bytes_to_human(0.9 * 1024 * 1024 * 1024 * 1024) == "0.90 TBytes"
    assert bytes_to_human(0.9 * 1024 ** 4) == "0.90 TBytes"
    assert bytes_to_human(0.9 * 1024 * 1024 * 1024 * 1024 * 1024) == "0.90 PBytes"

# Generated at 2022-06-22 22:14:07.568447
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_1 = ['a', 'B', 'C']
    expected_output = ['a', 'b', 'c']
    assert lenient_lowercase(input_1) == expected_output

    input_2 = ['a', '1']
    expected_output = ['a', '1']
    assert lenient_lowercase(input_2) == expected_output



# Generated at 2022-06-22 22:14:16.787492
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # Bytes
    assert human_to_bytes('2048') == 2048
    assert human_to_bytes('1kB') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1TB') == 1099511627776
    assert human_to_bytes('1PB') == 1125899906842624

    # Bits
    assert human_to_bytes('256b', isbits=True) == 32
    assert human_to_bytes('1Kb', isbits=True) == 128
    assert human_to_bytes('1KB', isbits=True) == 8192
    assert human_to_bytes('10Mb', isbits=True)

# Generated at 2022-06-22 22:14:27.004170
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2 * 1024
    assert human_to_bytes('2M') == 2 * 1024 * 1024
    assert human_to_bytes('2G') == 2 * 1024 * 1024 * 1024
    assert human_to_bytes('2T') == 2 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('2P') == 2 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('2E') == 2 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('2Y') == 2 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024

    assert human_to_bytes('2KB') == 2 * 1024
    assert human_to_bytes('2MB') == 2 * 1024 * 1024
    assert human_to_bytes('2GB')

# Generated at 2022-06-22 22:14:38.186701
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('-1') == -1
    assert human_to_bytes('-1.5') == -1

    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB') == 1024*1024
    assert human_to_bytes('1GB') == 1024*1024*1024
    assert human_to_bytes('1TB') == 1024*1024*1024*1024

    assert human_to_bytes('1KB', 'K') == 1024
    assert human_to_bytes('1MB', 'M') == 1024*1024
    assert human_to_bytes('1GB', 'G') == 1024*1024*1024
    assert human_to_bytes('1TB', 'T')

# Generated at 2022-06-22 22:14:49.670673
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # bytes test
    assert human_to_bytes('10M') == 10737418240
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10 MB') == 10485760
    assert human_to_bytes('10.5 MB') == 11059200000
    assert human_to_bytes('10.5MB') == 1105920000
    assert human_to_bytes('512b') == 512
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes(u'1024') == 1024
    assert human_to_bytes('1024', isbits=False) == 1024
    assert human_to_bytes('1024', isbits=True) == 1024 * 8
    assert human_to_bytes(1024, isbits=True) == 1024 * 8
    assert human_to_

# Generated at 2022-06-22 22:14:52.866066
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    mylist = ["foo", "bar", 1]
    lower = lenient_lowercase(mylist)
    assert mylist == lower


# Generated at 2022-06-22 22:15:02.960271
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(45) == '45.00 Bytes'
    assert bytes_to_human(45, unit='B') == '45.00 Bytes'
    assert bytes_to_human(45, unit='b') == '0.00 bits'
    assert bytes_to_human(45, isbits=True) == '0.00 bits'
    assert bytes_to_human(45, isbits=True, unit='b') == '0.00 bits'
    assert bytes_to_human(45, isbits=True, unit='B') == '360.00 bits'
    assert bytes_to_human(1048576) == '1.00 MB'

# Generated at 2022-06-22 22:15:07.887816
# Unit test for function bytes_to_human
def test_bytes_to_human():
    cases = [
        (1, '1 B'),
        (1 << 10, '1.00 KB'),
        (1 << 20, '1.00 MB'),
        (1 << 30, '1.00 GB'),
        (1 << 40, '1.00 TB'),
        (1 << 50, '1.00 PB'),
        (1 << 60, '1.00 EB'),
        (1 << 70, '1.00 ZB'),
        (1 << 80, '1.00 YB')
    ]
    for value, expect in cases:
        result = bytes_to_human(value)
        if result != expect:
            raise Exception('Expected result of "%s"; got "%s"' % (expect, result))


# A dirty hack to have at least some test coverage
# It can be removed once real unit test is added


# Generated at 2022-06-22 22:15:17.814390
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b', isbits=True) == 1
    assert human_to_bytes('10B', isbits=True) == 10
    assert human_to_bytes('10K', isbits=True) == 10240
    assert human_to_bytes('10Kb', isbits=True) == 10240
    assert human_to_bytes('10kb', isbits=True) == 8192
    assert human_to_bytes('10KB', isbits=True) == 8192
    assert human_to_bytes('10Kb') == 10240
    assert human_to_bytes('10kb') == 8192
    assert human_to_bytes

# Generated at 2022-06-22 22:15:22.626526
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase(['HELLO', 'WORLD']) == ['hello', 'world']
    assert lenient_lowercase(['HELLO', 2, 'WORLD']) == ['hello', 2, 'world']



# Generated at 2022-06-22 22:15:29.943987
# Unit test for function bytes_to_human
def test_bytes_to_human():
        assert bytes_to_human(1) == '1 Bytes'
        assert bytes_to_human(1, unit='G') == '1.00 G'
        assert bytes_to_human(1, isbits=True, unit='K') == '1.00 Kbits'
        assert bytes_to_human(1, isbits=True, unit='Mb') == '1.00 Mbits'
        assert bytes_to_human(1, isbits=True) == '1 bits'
        assert bytes_to_human(1, unit='M') == '1.00 M'
        assert bytes_to_human(1, unit='K') == '1.00 K'
        assert bytes_to_human(1023) == '1023 Bytes'

# Generated at 2022-06-22 22:15:37.332176
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(["A", "B", "C"]) == ["a", "b", "c"])
    assert(lenient_lowercase(["A", 1, "C"]) == ["a", 1, "c"])
    assert(lenient_lowercase([]) == [])
    assert(lenient_lowercase(["A", [1, 2], "C"]) == ["a", [1, 2], "c"])


# Generated at 2022-06-22 22:15:48.059828
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2K', 'M') == 0
    assert human_to_bytes('0') == 0
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.23M') == 1289748
    assert human_to_bytes('1.23M', 'M') == 1
    assert human_to_bytes('1.23Z', 'Z') == 1
    assert human_to_bytes('1.23E', 'E') == 1
    assert human_to_bytes('1.23P', 'P') == 1
    assert human_to_bytes('1.23T', 'T') == 1
    assert human_to_bytes('1.23G', 'G') == 1
    assert human_to_bytes

# Generated at 2022-06-22 22:15:59.400067
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:16:11.043722
# Unit test for function lenient_lowercase

# Generated at 2022-06-22 22:16:22.780136
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Ensure that a string lowercases correctly
    assert lenient_lowercase(['abc']) == ['abc']
    # Ensure that a list of mixed strings and other values lowers correctly
    assert lenient_lowercase(['abc', 1, 'def', 2]) == ['abc', 1, 'def', 2]
    # Ensure that a list of mixed strings and other values that includes a dict lowers correctly
    assert lenient_lowercase(['abc', 1, {'a': 1}]) == ['abc', 1, {'a': 1}]
    # Ensure that a list of mixed strings and other values that includes a tuple lowers correctly
    assert lenient_lowercase(['abc', 1, (1, 2, 3)]) == ['abc', 1, (1, 2, 3)]

# Generated at 2022-06-22 22:16:33.847043
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1024**2) == '1.00 MB'
    assert bytes_to_human(1024*1024) == '1.00 MB'
    assert bytes_to_human(1024**3) == '1.00 GB'
    assert bytes_to_human(1024**4) == '1.00 TB'
    assert bytes_to_human(1024**5) == '1.00 PB'
    assert bytes_to_human(10**9) == '1.00 GB'
    assert bytes

# Generated at 2022-06-22 22:16:43.044320
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_cases = [
        {'lst': ["string", "string", "string"], 'result': ["string", "string", "string"]},
        {'lst': ["string", "STRING", "string"], 'result': ["string", "STRING", "string"]},
        {'lst': ["string", "STRING", "string", 1, 2, 3], 'result': ["string", "STRING", "string", 1, 2, 3]},
        {'lst': ["string", 1, 2, 3], 'result': ["string", 1, 2, 3]},
        {'lst': ["STRING", 1, 2, 3], 'result': ["STRING", 1, 2, 3]},
        {'lst': [1, 2, 3], 'result': [1, 2, 3]},
    ]
   

# Generated at 2022-06-22 22:16:49.900604
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a','B','c','D','e','F','g','H','i','J','k','L','m','N','o','P','q','R','s','T','u','V','w','X','y','Z']) == ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']

# Generated at 2022-06-22 22:16:52.669929
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_sentences = [
        'I have a dream',
        ['I have a dream'],
        ['I have a dream', u'We have a secret'],
        ['I have a dream', ['We have a secret']]
    ]

    for sentence in test_sentences:
        lenient_lowercase(sentence)

# Generated at 2022-06-22 22:17:03.132268
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(2) == '2.00 Bytes'
    assert bytes_to_human(1234) == '1.23 KB'
    assert bytes_to_human(12345) == '12.35 KB'
    assert bytes_to_human(1234567) == '1.18 MB'
    assert bytes_to_human(1234567890) == '1.15 GB'
    assert bytes_to_human(1234567890123) == '1.12 TB'
    assert bytes_to_human(1234567890123456) == '1.10 PB'
    assert bytes_to_human(1234567890123456789) == '1.08 EB'

# Generated at 2022-06-22 22:17:09.775163
# Unit test for function bytes_to_human
def test_bytes_to_human():
    if human_to_bytes('10M') != 10485760:
        raise AssertionError("10MB = 10485760 bytes")

    if human_to_bytes('10M', isbits=True) != 8388608:
        raise AssertionError("10Mb = 8388608 bits")

    if bytes_to_human(104856789) != '98.21 MB':
        raise AssertionError("98.21 MB = 104856789 Bytes")

    if bytes_to_human(83886089, isbits=True) != '66.46 Mb':
        raise AssertionError("66.46 Mb = 83886089 bits")

# Generated at 2022-06-22 22:17:15.453497
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['Foo', 1, [2, 3], 'Bar', (4, 5)]
    expected = ['foo', 1, [2, 3], 'bar', (4, 5)]
    result = lenient_lowercase(lst)
    assert result == expected, "lenient_lowercase did not lowercase correctly. See: {0}".format(result)


# Generated at 2022-06-22 22:17:24.144564
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, True]) == ['a', 1, True]
    assert lenient_lowercase([u'A', u'B', u'C']) == [u'a', u'b', u'c']
    assert lenient_lowercase([u'A', 1, True]) == [u'a', 1, True]
    assert lenient_lowercase([b'A', b'B', b'C']) == [b'a', b'b', b'c']
    assert lenient_lowercase([b'A', 1, True]) == [b'a', 1, True]
    assert lenient_lowercase([]) == []



# Generated at 2022-06-22 22:17:33.997108
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, unit='b') == '8.00 bits'
    assert bytes_to_human(1, isbits=True, unit='B') == '8.00 bits'
    assert bytes_to_human(1, isbits=True, unit='b') == '8.00 bits'
    assert bytes_to_human(1, isbits=True) == '8.00 bits'

    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024, unit='B') == '1.00 KB'

# Generated at 2022-06-22 22:17:40.780971
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1, False) == '1.00 Bytes'
    assert bytes_to_human(101, False) == '101.00 Bytes'
    assert bytes_to_human(101, False, 'B') == '101.00 Bytes'
    assert bytes_to_human(1024, False, 'B') == '1.00 KB'
    assert bytes_to_human(1048576, False, 'B') == '1.00 MB'
    assert bytes_to_human(1073741824, False, 'B') == '1.00 GB'
    assert bytes_to_human(1, True, 'b') == '1.00 bits'
    assert bytes_to_human(10, True, 'b') == '10.00 bits'

# Generated at 2022-06-22 22:17:50.276656
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert "1 B" == bytes_to_human(1)
    assert "512 B" == bytes_to_human(512)
    assert "1,024 B" == bytes_to_human(1024)
    assert "1.00 KB" == bytes_to_human(1024, unit='B')
    assert "0.98 KB" == bytes_to_human(1024, unit='B', unit_sep=False)
    assert "1.00 K" == bytes_to_human(1024, unit='B', unit_sep=False, unit_base=False)
    assert "1.00 KiB" == bytes_to_human(1024, unit='B', unit_sep=False, unit_base=False, use_si=True)

# Generated at 2022-06-22 22:18:02.861851
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10.0') == 10
    assert human_to_bytes('10.1') == 10
    assert human_to_bytes('10.9') == 10
    assert human_to_bytes('10.999999999999999') == 10
    assert human_to_bytes('10.00000000000000000000000000000000000000000000000000000001') == 10
    assert human_to_bytes('1.2M') == 1 * SIZE_RANGES['M'] + 0.2 * SIZE_RANGES['M']
    assert human_to_bytes('1.2Mb', isbits=True) == 1 * SIZE_RANGES['M'] + 0.2 * SIZE_RANGES['M']

# Generated at 2022-06-22 22:18:08.001630
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Example from https://docs.ansible.com/ansible/latest/network/user_guide/network_debug_troubleshooting.html
    assert human_to_bytes('2K') == 2048
    # Example from https://docs.ansible.com/ansible/latest/network/user_guide/platform_junos.html
    assert human_to_bytes('2E') == 1 << 60
    # Examples from https://github.com/ansible/ansible/pull/59249
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10.5K') == 10.5 * 1024
    assert human_

# Generated at 2022-06-22 22:18:14.446025
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """
    >>> test_bytes_to_human()
    Test bytes_to_human function
    Test with size = 0
    Test if suffixes are properly converted
    Test if isbits parameter is False by default
    Test if isbits parameter is used if specified
    Test if unit parameter is used by default
    Test if unit parameter is used if specified
    """
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 22:18:25.310272
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('100M') == 100 * 1024 * 1024
    assert human_to_bytes('100M', 'MB') == 100 * 1024 * 1024
    assert human_to_bytes('0M') == 0
    assert human_to_bytes('0M', 'MB') == 0
    assert human_to_bytes('100MB') == 100 * 1024 * 1024
    assert human_to_bytes('100Mb') == 100 * 1024 * 1024
    assert human_to_bytes('100K') == 100 * 1024
    assert human_to_bytes('100Kb', isbits=True) == 100 * 1024
    assert human_to_bytes('100k', 'B') == 100 * 1024
    assert human_to_bytes('100k') == 100 * 1024
    assert human_to_bytes('100k', default_unit='B') == 100

# Generated at 2022-06-22 22:18:29.614005
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = []
    ret = []
    assert lst == ret, "Fail to test empty list"

    lst = ['a', 'B', 'c', 1, 2]
    ret = ['a', 'b', 'c', 1, 2]
    assert lenient_lowercase(lst) == ret, "Fail to test list contains int, float, str"



# Generated at 2022-06-22 22:18:33.072157
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['lower', 'camelCase', 'UPPER', 1]) == ['lower', 'camelcase', 'upper', 1]


# Generated at 2022-06-22 22:18:33.708478
# Unit test for function human_to_bytes
def test_human_to_bytes():
    pass

# Generated at 2022-06-22 22:18:44.264592
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1b') == human_to_bytes(1, 'b', isbits=True)

    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1B') == human_to_bytes(1, 'b')

    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1k') == human_to_bytes(1024, 'b', isbits=True)

    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1kb') == human_to_bytes(1024, 'b')

    assert human_to_bytes('1m') == 1024 * 1024

# Generated at 2022-06-22 22:18:45.963114
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase([1, 'a', 'B', 'c', 2]) == [1, 'a', 'B', 'c', 2])



# Generated at 2022-06-22 22:18:55.568135
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    # Create a list containing mixed types of data
    list_to_lower = [
        'Test',
        'One',
        1,
        '2',
        '3',
        3.14159,
        'fourth',
        ['fifth'],
        {'sixth': 'value'},
    ]

    # Create a list containing the same data, but converted to lowercase
    list_lower = [
        'test',
        'one',
        1,
        '2',
        '3',
        3.14159,
        'fourth',
        ['fifth'],
        {'sixth': 'value'},
    ]

    # Test the lenient_lowercase function
    assert lenient_lowercase(list_to_lower) == list_lower



# Generated at 2022-06-22 22:19:07.406108
# Unit test for function human_to_bytes
def test_human_to_bytes():

    assert human_to_bytes('10') == 10
    assert human_to_bytes('1') == 1
    assert human_to_bytes('0K') == 0
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1') == 1
    assert human_to_bytes('4M') == 4194304
    assert human_to_bytes('3G') == 3221225472
    assert human_to_bytes('1Mb') == 1 * 1024 * 1024 * 8
    assert human_to_bytes('1Mb', isbits=True) == 1 * 1024 * 1024 * 8

    try:
        human_to_bytes('1Mb')
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-22 22:19:10.193749
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'c', b'D', u'e']) == ['a', 'b', 'c', b'D', u'e']



# Generated at 2022-06-22 22:19:21.650070
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        assert (1, ) == (human_to_bytes('1'), )
        assert (5, ) == (human_to_bytes('5'), )
    except AssertionError:
        raise AssertionError("Test 1 Failed")

    try:
        assert (1024, ) == (human_to_bytes('1K'), )
        assert (2048, ) == (human_to_bytes('2K'), )
    except AssertionError:
        raise AssertionError("Test 2 Failed")

    try:
        assert (1048576, ) == (human_to_bytes('1M'), )
        assert (2097152, ) == (human_to_bytes('2M'), )
    except AssertionError:
        raise AssertionError("Test 3 Failed")


# Generated at 2022-06-22 22:19:27.738957
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """ Unit tests for lenient_lowercase. """
    assert ['a', 'b'] == lenient_lowercase(['a', 'b'])
    assert ['a', 'b', 'c'] == lenient_lowercase(['a', 'b', 'C'])
    assert ['a', 'b', 'c'] == lenient_lowercase(['a', 'b', 3])


# Generated at 2022-06-22 22:19:39.091703
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print(human_to_bytes('10'))
    print(human_to_bytes('10.5'))
    print(human_to_bytes('10.5', default_unit='M'))
    print(human_to_bytes('10M'))
    print(human_to_bytes('10M', default_unit='K'))
    print(human_to_bytes('10mb', isbits=True))
    print(human_to_bytes('10.5Mb', isbits=True))
    print(human_to_bytes('10.5Mb', isbits=True))
    print(human_to_bytes('10.5Mb', isbits=True))
    print(human_to_bytes('10.5M', default_unit='b', isbits=True))

# Generated at 2022-06-22 22:19:48.646887
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(None, False, 'K') == '0.00 KBytes'
    assert bytes_to_human(0, False, 'K') == '0.00 KBytes'
    assert bytes_to_human(None, False, 'B') == '0.00 Bytes'
    assert bytes_to_human(0, False, 'B') == '0.00 Bytes'
    assert bytes_to_human(None, False, 'M') == '0.00 MBytes'
    assert bytes_to_human(0, False, 'M') == '0.00 MBytes'
    assert bytes_to_human(None, False, 'G') == '0.00 GBytes'
    assert bytes_to_human(0, False, 'G') == '0.00 GBytes'
    assert bytes_to_human

# Generated at 2022-06-22 22:19:57.007443
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list_1 = ['a', 'b', 'c']
    test_list_2 = ['A', 'B', 'C']
    test_list_3 = ['a', 'C', 'd']

    assert lenient_lowercase(test_list_1) == test_list_1
    assert lenient_lowercase(test_list_2) == ['a', 'b', 'c']
    assert lenient_lowercase(test_list_3) == test_list_3


# Generated at 2022-06-22 22:20:09.817350
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert 1048576 == human_to_bytes('1MB')
    assert 1048576 == human_to_bytes('1MB', default_unit='M')
    assert 1048576 == human_to_bytes('1', 'M')
    assert 1048576 == human_to_bytes(1, 'M')

    assert 1048576 == human_to_bytes('1M')
    assert 1048576 == human_to_bytes('1M', default_unit='M')
    assert 1048576 == human_to_bytes('1', 'M')
    assert 1048576 == human_to_bytes(1, 'M')

    assert 8388608 == human_to_bytes('8MB')
    assert 8388608 == human_to_bytes('8MB', 'M')

# Generated at 2022-06-22 22:20:13.972623
# Unit test for function bytes_to_human
def test_bytes_to_human():
    for test in (
        (100, "100 Bytes"),
        (1024, "1 KB"),
        (2048, "2 KB"),
        (102400, "100 KB"),
        (1048576, "1 MB"),
    ):
        assert bytes_to_human(test[0]) == test[1]

# Generated at 2022-06-22 22:20:22.373311
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576, unit='M') == "1.00 MB"
    assert bytes_to_human(1048576, unit='K') == "1024.00 KB"
    assert bytes_to_human(1048576) == "1048576.00 Bytes"
    assert bytes_to_human(10) == "10.00 Bytes"
    assert bytes_to_human(0) == "0.00 Bytes"
    assert bytes_to_human(None) == "0.00 Bytes"
    assert bytes_to_human(0, unit='K') == "0.00 KB"
    assert bytes_to_human(1, unit='K') == "1.00 KB"
    assert bytes_to_human(2048, unit='K') == "2.00 KB"
    assert bytes_

# Generated at 2022-06-22 22:20:25.032349
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input = [1, 'Z', 'FIVE']
    output = lenient_lowercase(input)
    assert output == [1, 'z', 'five']

# Generated at 2022-06-22 22:20:35.765386
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:20:37.445829
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['TeSt', 2, {}]) == ['test', 2, {}]


# Generated at 2022-06-22 22:20:40.854864
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [1, 2, 3, 'A', 'B', 'C', None]
    res = lenient_lowercase(lst)
    assert res == [1, 2, 3, 'a', 'b', 'c', None]


# Generated at 2022-06-22 22:20:48.454276
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print("%s" % bytes_to_human(1024))
    print("%s" % bytes_to_human(1024, isbits=True))
    print("%s" % bytes_to_human(1024, unit='b'))
    print("%s" % bytes_to_human(1024, unit='b', isbits=True))
    print("%s" % bytes_to_human(999999999, isbits=True))
    print("%s" % bytes_to_human(999999999, unit='b', isbits=True))
    print("%s" % bytes_to_human(999999999, isbits=False))
    print("%s" % bytes_to_human(999999999, unit='B'))

# Generated at 2022-06-22 22:20:56.834188
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # empty list
    result = lenient_lowercase([])
    assert result == []

    # one element int
    result = lenient_lowercase([1])
    assert result == [1]

    # one element string
    result = lenient_lowercase(['T'])
    assert result == ['t']

    # two elements string
    result = lenient_lowercase(['T', 1])
    assert result == ['t', 1]

    # list of one element string
    result = lenient_lowercase([['T']])
    assert result == [['t']]

    # list of two elements string
    result = lenient_lowercase([['T', 1]])
    assert result == [['t', 1]]

    # list of three elements string

# Generated at 2022-06-22 22:21:06.881938
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1M") == 1048576
    assert human_to_bytes("1M", isbits=True) == 1048576
    assert human_to_bytes("1Mb") == 1048576
    assert human_to_bytes("1Mb", isbits=True) == 1048576
    assert human_to_bytes("1K") == 1024
    assert human_to_bytes("1K", isbits=True) == 1024
    assert human_to_bytes("1Kb") == 1024
    assert human_to_bytes("1Kb", isbits=True) == 1024
    assert human_to_bytes("1") == 1
    assert human_to_bytes("1", isbits=True) == 1
    assert human_to_bytes("1b") == 1

# Generated at 2022-06-22 22:21:10.396221
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    a = ['a', 'b', 'c', 100, ('d', 'e')]
    a_lowered = lenient_lowercase(a)
    assert ['a', 'b', 'c', 100, ('d', 'e')] == a_lowered
    b = ['a', 'b', 'C', 100, ('D', 'e')]
    b_lowered = lenient_lowercase(b)
    assert ['a', 'b', 'c', 100, ('d', 'e')] == b_lowered

# Generated at 2022-06-22 22:21:18.119466
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'c']) == ['a', 1, 'c']

# Generated at 2022-06-22 22:21:28.363618
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert(bytes_to_human(0) == '0.00 Bytes')
    assert(bytes_to_human(1) == '1.00 Bytes')
    assert(bytes_to_human(10) == '10.00 Bytes')
    assert(bytes_to_human(100) == '100.00 Bytes')
    assert(bytes_to_human(1023) == '1023.00 Bytes')
    assert(bytes_to_human(1024) == '1.00 KB')
    assert(bytes_to_human(1024 * 1024) == '1.00 MB')
    assert(bytes_to_human(1024 * 1024 * 1024) == '1.00 GB')
    assert(bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB')

# Generated at 2022-06-22 22:21:38.829279
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(100000000000000000000, unit='Z') == '1.00 ZB'
    assert bytes_to_human(100000000000000000000) == '1.00 ZB'
    assert bytes_to_human(10000) == '9.77 KB'
    assert bytes_to_human(1000) == '1000.00 Bytes'
    assert bytes_to_human(1000, unit='b') == '7.80 Kb'
    assert bytes_to_human(1000, isbits=True) == '1000.00 bits'
    assert bytes_to_human(1000, unit='B', isbits=True) == '0.78 Kb'
    assert bytes_to_human(1048576, unit='B', isbits=True) == '8.00 Mb'

# Generated at 2022-06-22 22:21:50.335050
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == human_to_bytes(1)
    assert human_to_bytes('0') == human_to_bytes(0)
    assert human_to_bytes('11') == human_to_bytes(11)
    assert human_to_bytes('1K') == human_to_bytes(1, 'K')
    assert human_to_bytes('1k') == human_to_bytes(1, 'k')
    assert human_to_bytes('1M') == human_to_bytes(1, 'M')
    assert human_to_bytes('1m') == human_to_bytes(1, 'm')
    assert human_to_bytes('1G') == human_to_bytes(1, 'G')

# Generated at 2022-06-22 22:21:56.997042
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['abc']) == ['abc']
    assert lenient_lowercase([123]) == [123]
    assert lenient_lowercase(['ABC']) == ['abc']
    assert lenient_lowercase([123, 'ABC']) == [123, 'abc']
    assert lenient_lowercase(['ABC', 456]) == ['abc', 456]
    assert lenient_lowercase(['ABC', 'DEF']) == ['abc', 'def']

# Generated at 2022-06-22 22:22:08.411024
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' test human_to_bytes with bytes units (B/B) '''
    assert human_to_bytes('2B') == 2
    assert human_to_bytes('2b') == 2
    assert human_to_bytes('2') == 2
    assert human_to_bytes(2) == 2
    assert human_to_bytes('2.0') == 2
    assert human_to_bytes(2.0) == 2
    assert human_to_bytes('2 Bytes') == 2
    assert human_to_bytes('2 bytes') == 2
    assert human_to_bytes('2 byte') == 2

    ''' test human_to_bytes with bits units (b/b) '''
    assert human_to_bytes('2MB', isbits=True) == 2097152