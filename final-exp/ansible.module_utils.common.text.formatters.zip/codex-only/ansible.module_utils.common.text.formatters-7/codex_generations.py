

# Generated at 2022-06-22 22:12:08.708236
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest
    with pytest.raises(ValueError) as excinfo:
        human_to_bytes('@mb')
    assert str(excinfo.value) == "human_to_bytes() can't interpret following string: @mb"

    with pytest.raises(ValueError) as excinfo:
        human_to_bytes('2K')
    assert str(excinfo.value) == "human_to_bytes() can't interpret following number: 2K (original input string: 2K)"

    with pytest.raises(ValueError) as excinfo:
        human_to_bytes('2K', 'm')

# Generated at 2022-06-22 22:12:17.116350
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Test data for testing human_to_bytes"""

# Generated at 2022-06-22 22:12:27.730231
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''
    A test method for bytes_to_human()
    '''
    # Bytes
    assert bytes_to_human(4294967296) == '4.0 GB'
    assert bytes_to_human(2147483648) == '2.0 GB'
    assert bytes_to_human(1073741824) == '1.0 GB'
    assert bytes_to_human(16777216) == '16.0 MB'
    assert bytes_to_human(8388608) == '8.0 MB'
    assert bytes_to_human(4194304) == '4.0 MB'
    assert bytes_to_human(16384) == '16.0 KB'
    assert bytes_to_human(8192) == '8.0 KB'
    assert bytes_to_human(4096)

# Generated at 2022-06-22 22:12:31.235098
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a1', 'A2']) == ['a1', 'a2']
    assert lenient_lowercase([1, 2]) == [1, 2]
    assert lenient_lowercase('B1') == 'b1'

# Generated at 2022-06-22 22:12:40.566106
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1000') == 1000
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1G') == 1024 * 1024 * 1024
    assert human_to_bytes('1T') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10b', isbits=True) == 10
    assert human_to_bytes('10B', isbits=True) == 10
    assert human_to_bytes('10bit') == 10
    assert human_to_bytes('10bits') == 10
    assert human_to_bytes('10bits', isbits=True) == 10
    assert human_to

# Generated at 2022-06-22 22:12:48.935455
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import unittest
    class TestMyModule(unittest.TestCase):
        def test_bytes(self):
            self.assertEqual(human_to_bytes('1B'), 1)
            self.assertEqual(human_to_bytes('10B'), 10)
            self.assertEqual(human_to_bytes('1B', default_unit='B'), 1)
            self.assertEqual(human_to_bytes('10B', default_unit='B'), 10)
            self.assertEqual(human_to_bytes('1B', default_unit='k'), 1024)
            self.assertEqual(human_to_bytes('10B', default_unit='k'), 10240)

        def test_kbytes(self):
            self.assertEqual(human_to_bytes('1KB'), 1024)
            self

# Generated at 2022-06-22 22:13:00.301443
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print(bytes_to_human(1))
    print(bytes_to_human(500))
    print(bytes_to_human(1024*1024*1024))
    print(bytes_to_human(1024*1024*1024*1024))
    print(bytes_to_human(1024*1024*1024*1024*1024))
    print(bytes_to_human(1024*1024*1024*1024*1024*1024))
    print(bytes_to_human(1024*1024*1024*1024*1024*1024*1024))
    print(bytes_to_human(1024*1024*1024*1024*1024*1024*1024*1024))
    print(bytes_to_human(1024*1024*1024*1024*1024*1024*1024*1024*1024))

# Generated at 2022-06-22 22:13:11.041215
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10m') == 10485760
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.1G') == 115343360
    assert human_to_bytes('1E') == 1125899906842624
    assert human_to_bytes('1Y') == 1180591620717411303424
    assert human_to

# Generated at 2022-06-22 22:13:20.842820
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(722) == '722 Bytes'
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1024) == '1.00 KiB'
    assert bytes_to_human(2048) == '2.00 KiB'
    assert bytes_to_human(3500) == '3.43 KiB'
    assert bytes_to_human(5000000) == '4.77 MiB'
    assert bytes_to_human(100000000) == '95.37 MiB'
    assert bytes_to_human(123456789) == '117.74 MiB'
    assert bytes_to_

# Generated at 2022-06-22 22:13:32.484094
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # simple unit tests for human_to_bytes function

    # byte units
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1 Byte') == 1
    assert human_to_bytes('1bYte') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1 bytes') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1 bytesss') == 1
    assert human_to_bytes('1B') == 1

# Generated at 2022-06-22 22:13:41.518340
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_data = [
        'TestString',
        ['TestList', "TestList"],
        '100',
        [100, 200, 300],
        ['100', '200', '300'],
        ['100', 200, '300'],
        ('100', 200, 300),
        ('100', '200', '300'),
        ('100', 200, '300'),
        {'key1': 'Value1', 'key2': 'Value2'},
        {'key1': 'Value1', 'key2': ['Value2', 'Test1']},
        {'key1': 'Value1', 'key2': ['Value2', 'Test1', 200]},
        {'key1': 'Value1', 'key2': ['Value2', 'Test1', 200, {'key3': 'Value3'}]},
    ]

# Generated at 2022-06-22 22:13:46.100449
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Test the lenient_lowercase function."""
    assert lenient_lowercase(['a', 'B', ['c', 'D'], 'e']) == ['a', 'B', ['c', 'D'], 'e']
    assert lenient_lowercase(['A', 'b']) == ['a', 'b']



# Generated at 2022-06-22 22:13:57.453758
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(500) == '500.00 Bytes'
    assert bytes_to_human(125) == '125.00 Bytes'
    assert bytes_to_human(1000, unit='kB') == '1.00 kBytes'
    assert bytes_to_human(1000, unit='MB') == '1.00 MBytes'
    assert bytes_to_human(96, unit='MB') == '0.09 MBytes'
    assert bytes_to_human(123456789, unit='MB') == '123.46 MBytes'
    assert bytes_to_human(123456789, unit='GB') == '0.12 GBytes'
    assert bytes_to_human(1234567890, unit='GB') == '1.15 GBytes'

# Generated at 2022-06-22 22:14:01.638452
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list1 = ['1', 1, 'ABC', 'abcdWE', 'Ed', '']
    list2 = ['1', 1, 'abc', 'abcdwe', 'ed', '']
    assert lenient_lowercase(list1) == list2
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['', '', '']) == ['', '', '']

# Generated at 2022-06-22 22:14:11.790644
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import unittest
    class HumanToBytesTestCase(unittest.TestCase):
        def test_human_to_bytes(self):
            self.assertEqual(human_to_bytes('1Mb', isbits=True), 1048576)
            self.assertEqual(human_to_bytes('1MB'), 1048576)
            self.assertEqual(human_to_bytes('1MB', 'KB'), 1048576)
            self.assertEqual(human_to_bytes(1, 'MB'), 1048576)
            self.assertEqual(human_to_bytes(1048576), 1048576)
            self.assertEqual(human_to_bytes(1048576, 'KB'), 1048576)

# Generated at 2022-06-22 22:14:22.254879
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['a', 'b']) == ['a', 'b']
    assert lenient_lowercase(['a', 'b', 1, 2]) == ['a', 'b', 1, 2]
    assert lenient_lowercase(['A', 'b', 'C', 'd']) == ['a', 'b', 'c', 'd']
    assert lenient_lowercase(['AA', 'b', 'CC', 'd']) == ['aa', 'b', 'cc', 'd']
    assert lenient_lowercase([['A', 'B'], ['C', 'D']]) == [['A', 'B'], ['C', 'D']]

# Generated at 2022-06-22 22:14:30.274004
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('12') == 12
    assert human_to_bytes('12B') == 12
    assert human_to_bytes('12M') == 12 * 1 << 20
    assert human_to_bytes('12Mb') == 12 * 1 << 20
    assert human_to_bytes('12MB') == 12 * 1 << 20
    assert human_to_bytes('12Gb') == 12 * 1 << 30
    assert human_to_bytes('12.5B') == 12
    assert human_to_bytes('12.5K') == 12.5 * 1 << 10
    assert human_to_bytes('.5K') == 0.5 * 1 << 10
    assert human_to_bytes('1.5K') == 1.5 * 1 << 10
    assert human_to_bytes('.5') == 0.5

# Generated at 2022-06-22 22:14:40.668641
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # All possible test case are represented here

    # Case of bytes
    assert human_to_bytes(0.5, default_unit='B') == 0
    assert human_to_bytes(1, default_unit='B') == 1
    assert human_to_bytes(1, default_unit='B') == 1
    assert human_to_bytes(1.1, default_unit='B') == 1
    assert human_to_bytes(1.5, default_unit='B') == 2
    assert human_to_bytes(10, default_unit='B') == 10
    assert human_to_bytes(10, default_unit='B') == 10
    assert human_to_bytes(10.1, default_unit='B') == 10
    assert human_to_bytes(10.5, default_unit='B') == 11

# Generated at 2022-06-22 22:14:52.105629
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(5) == 5
    assert human_to_bytes('5 B') == 5
    assert human_to_bytes('5 b') == 5
    assert human_to_bytes('5') == 5
    assert human_to_bytes('5', isbits=False) == 5
    assert human_to_bytes('5', isbits=True) == 5

    assert human_to_bytes('5 KB') == 5120
    assert human_to_bytes('5 Kb') == 5120
    assert human_to_bytes('5 K') == 5120
    assert human_to_bytes('5', 'K') == 5120

    assert human_to_bytes('5 MB') == 5242880
    assert human_to_bytes('5 Mb') == 5242880

# Generated at 2022-06-22 22:15:02.902118
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('100') == 100
    assert human_to_bytes('0') == 0
    assert human_to_bytes('100.5') == 100
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1KB', default_unit='B') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1MB', default_unit='B') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.5MB') == 1572864
    assert human_to_bytes('1 mb') == 1048576
    assert human_to_bytes('1 mb', default_unit='B') == 1048

# Generated at 2022-06-22 22:15:13.118558
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Simple test
    assert bytes_to_human(1048576) == '1.00 MB'

    # Test with default unit (no unit used)
    assert bytes_to_human(10485760) == '10.00 MB'

    # Test for bits
    assert bytes_to_human(10485760 * 8, isbits=True) == '10.00 Mb'

    # Test with default unit (no unit used)
    assert bytes_to_human(10485760 * 8, isbits=True) == '10.00 Mb'

    # Test with unit passed
    assert bytes_to_human(10485760, unit='M') == '10.00 MB'
    assert bytes_to_human(10485760, unit='M', isbits=True) == '10.00 Mb'

    # Invalid input


# Generated at 2022-06-22 22:15:24.814201
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # test absolute values
    assert bytes_to_human(1, False) == '1 Bytes'
    assert bytes_to_human(1, True) == '1 Bits'
    assert bytes_to_human(1024, False) == '1.00 KB'
    assert bytes_to_human(1023, False) == '1023.00 Bytes'
    assert bytes_to_human(1024, True) == '8.00 Kb'
    assert bytes_to_human(1023, True) == '8184.00 bits'
    assert bytes_to_human(1024 * 1024, False) == '1.00 MB'
    assert bytes_to_human(1024 * 1024, True) == '8.00 Mb'
    assert bytes_to_human(1024 * 1024 * 1024, False) == '1.00 GB'

# Generated at 2022-06-22 22:15:28.424789
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lower_list = lenient_lowercase(['A', 'B', 1, 'c'])
    assert len(lower_list) == 4
    assert lower_list[0] == 'a'
    assert lower_list[1] == 'b'
    assert lower_list[2] == 1
    assert lower_list[3] == 'c'


# Generated at 2022-06-22 22:15:39.219005
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(0.9) == '0.00 Bytes'
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1.9) == '1.00 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 123) == '123.00 KB'
    assert bytes_to_human(1024 * 12342) == '12.11 MB'
    assert bytes_to_human(1024 * 12342, unit='m') == '12342.00 MB'
    assert bytes_to_human(1024 * 1234, unit='K') == '1259.52 KB'

# Generated at 2022-06-22 22:15:49.229397
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1000) == '1.00 KB'
    assert bytes_to_human(2000) == '2.00 KB'
    assert bytes_to_human(1024 ** 3) == '1.00 GB'
    assert bytes_to_human(1024 ** 3, unit='G') == '1.00 GB'
    assert bytes_to_human(1024 ** 3, unit='K') == '1073741824.00 KB'

    # test bits conversion
    assert bytes_to_human(1000, isbits=True) == '1.00 Kb'
    assert bytes_to_human(2000, isbits=True) == '2.00 Kb'
    assert bytes_to_human(1024 ** 3, isbits=True) == '1.00 Gb'

# Generated at 2022-06-22 22:15:59.315994
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'A', 'B', 'C']) == [1, 'a', 'b', 'c']
    assert lenient_lowercase(['1', 'A', 'B', 'C']) == ['1', 'a', 'b', 'c']
    assert lenient_lowercase(['1', 'a', 'b', 'c']) == ['1', 'a', 'b', 'c']
    assert lenient_lowercase(['1', 1, 2, 'c']) == ['1', 1, 2, 'c']
    assert lenient_lowercase(['1', 1, 2, 'c', 'A']) == ['1', 1, 2, 'c', 'a']


# Generated at 2022-06-22 22:16:10.978871
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Pass in a list of strings and get back a list of all lowercase strings
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    # Pass in a list of strings and integers and get back a list with all strings lowercased
    assert lenient_lowercase(['A', 'B', 1, 2, 3]) == ['a', 'b', 1, 2, 3]
    # Pass in a list with all strings and no integers, get back a list with all lowercased strings
    assert lenient_lowercase(['A', 'B']) == ['a', 'b']
    # Pass in a list with all integers and no strings, get back a list with all of the original integers
    assert lenient_lowercase([1, 2]) == [1, 2]



# Generated at 2022-06-22 22:16:17.206950
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ['a', 'b', 'c'] == lenient_lowercase(['A', 'B', 'C'])
    assert ['a', 1, 2, 3] == lenient_lowercase(['A', 1, 2, 3])
    assert ['a', 'b', {}, []] == lenient_lowercase(['A', 'B', {}, []])


# Generated at 2022-06-22 22:16:26.099276
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1]) == [1]
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['ABC']) == ['abc']
    assert lenient_lowercase(['ABC', 'DEF']) == ['abc', 'def']
    assert lenient_lowercase(['ABC', 1]) == ['abc', 1]
    assert lenient_lowercase([1, 'DEF']) == [1, 'def']
    assert lenient_lowercase([['ABC'], ['DEF']]) == [['abc'], ['def']]


# Unit tests for function human_to_bytes

# Generated at 2022-06-22 22:16:35.236697
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''
    Test bytes_to_human function
    '''
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1023, unit='B') == '1023 Bytes'
    assert bytes_to_human(1023, unit='B') == '1023 Bytes'
    assert bytes_to_human(1023, unit='b') == '1023 bytes'
    assert bytes_to_human(1023, isbits=True) == '1023 bits'



# Generated at 2022-06-22 22:16:44.054366
# Unit test for function bytes_to_human
def test_bytes_to_human():
    """Test for bytes_to_human()."""
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Byte'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(15) == '15 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1234) == '1.21 KB'
    assert bytes_to_human(10 ** 12) == '1.00 TB'
    assert bytes_to_human(10 ** 12 + 1) == '1.00 TB'
    assert bytes_to_human(10 ** 12 - 1) == '1.00 TB'

# Generated at 2022-06-22 22:16:53.633049
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576, unit='M') == '1.00 MB'
    assert bytes_to_human(1048576, unit=None) == '1.00 MB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048576, isbits=True) == '1.00 MB'
    assert bytes_to_human(1048580, isbits=True) == '1.00 MB'
    assert bytes_to_human(1048576, isbits=True, unit='M') == '1.00 MB'
    assert bytes_to_human(1048576, isbits=True, unit='m') == '1.00 MB'

# Generated at 2022-06-22 22:17:03.590175
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Lowercase a list of strings
    list_strings = ['a', 'B', 'c', 'D']
    list_lower = lenient_lowercase(list_strings)
    assert list_lower == ['a', 'b', 'c', 'd']

    # Leave a list as is
    list_strings = ['a', 2, 'c', 'D']
    list_lower = lenient_lowercase(list_strings)
    assert list_lower == ['a', 2, 'c', 'D']

    # Leave a string as is
    str_strings = 'ABc'
    str_lower = lenient_lowercase(str_strings)
    assert str_lower == 'ABc'

    # Lowercase a tuple
    tuple_strings = ('a', 'B', 'c', 'D')
    tuple_lower = lenient_

# Generated at 2022-06-22 22:17:08.841654
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, unit='b') == '1.00 bits'
    assert bytes_to_human(1, isbits=True, unit='b') == '1.00 bits'
    assert bytes_to_human(2**10, unit='B') == '1.00 KB'
    assert bytes_to_human(2**10, unit='b') == '1.00 Kb'
    assert bytes_to_human(2**20, unit='B') == '1.00 MB'
    assert bytes_to_human(2**20, unit='b') == '1.00 Mb'

    assert bytes_to_human(2**30, unit='B') == '1.00 GB'
    assert bytes_to_

# Generated at 2022-06-22 22:17:12.083397
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['AbC', 7, 'D,E?F']
    assert lenient_lowercase(lst) == ['abc', 7, 'd,e?f']

# Generated at 2022-06-22 22:17:21.965405
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(2) == '2.00 Bytes'
    assert bytes_to_human(2, isbits=True) == '2.00 bits'
    assert bytes_to_human(2, unit='b') == '2.00 bits'
    assert bytes_to_human(2, unit='B') == '2.00 Bytes'
    #
    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(2048, unit='b') == '2.00 Kbits'
    assert bytes_to_human(2048, unit='B') == '2.00 KB'
    #
    assert bytes_to_human(2048*1024) == '2.00 MB'

# Generated at 2022-06-22 22:17:33.346269
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(1, unit='B') == '1 Bytes'
    assert bytes_to_human(1, unit='b') == '1 bits'
    assert bytes_to_human(1, isbits=True) == '1 bits'
    assert bytes_to_human(1, unit='b', isbits=True) == '1 bits'
    assert bytes_to_human(1, unit='B', isbits=True) == '8 bits'
    assert bytes_to_human(56, unit='B') == '56 Bytes'

    assert bytes_to_human(1000) == '1000 Bytes'
    assert bytes_to_human(1000, unit='B') == '1000 Bytes'

# Generated at 2022-06-22 22:17:41.552620
# Unit test for function bytes_to_human

# Generated at 2022-06-22 22:17:50.748488
# Unit test for function bytes_to_human
def test_bytes_to_human():
    units = ['K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y']

# Generated at 2022-06-22 22:18:03.299782
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:18:15.745067
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Test the lenient lowercase function"""
    # happy path
    assert lenient_lowercase(['A', 'B', u'C']) == ['a', 'b', 'c']
    # list of non-string elements
    assert lenient_lowercase([1, 2, 3, 4]) == [1, 2, 3, 4]
    # empty list
    assert lenient_lowercase([]) == []
    # list containing a mixture of strings and other objects
    assert lenient_lowercase(['A', 'B', u'C', {'X': 'Y'}]) == ['a', 'b', 'c', {'X': 'Y'}]
    # single non-string element
    assert lenient_lowercase(['A']) == ['a']
    # single string element
    assert lenient_lowercase('A')

# Generated at 2022-06-22 22:18:22.677951
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(2048, 'KB') == '2.00 KB'
    assert bytes_to_human(1500000, 'KB') == '1464.06 KB'
    assert bytes_to_human(2048, 'b') == '16384.00 bits'
    assert bytes_to_human(1500000, 'b') == '12000000.00 bits'



# Generated at 2022-06-22 22:18:31.061740
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    not_list_types = (1, 'a', True, u'ab', b'ab')
    lst_with_list_types = [1, 'a', True, u'ab', b'ab']
    lst_with_mixed_data = ['a', 'b', 1, 2, True]
    empty_list = []
    # Check not list type
    for value in not_list_types:
        assert lenient_lowercase(value) == value
    # Check list type
    for value in lst_with_list_types:
        assert lenient_lowercase(value) == value
    # data is lowercased
    assert lenient_lowercase(['aB', 'bC', 'cD']) == ['ab', 'bc', 'cd']

# Generated at 2022-06-22 22:18:40.558122
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1) == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1K', isbits=True) == 8192
    assert human_to_bytes('1Mb') == 131072
    asse

# Generated at 2022-06-22 22:18:51.835754
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1000000) == '976.56 KB'
    assert bytes_to_human(1000000, unit='K') == '976.56 KB'
    assert bytes_to_human(1000000, unit='M') == '0.98 MB'
    assert bytes_to_human(1000000, unit='G') == '0.00 GB'
    assert bytes_to_human(1000000, isbits=True) == '8.00 Mb'
    assert bytes_to_human(1000000, isbits=True, unit='Mb') == '8.00 Mb'
    assert bytes_to_human(1000000, isbits=True, unit='Gb') == '0.01 Gb'

# Generated at 2022-06-22 22:18:56.721687
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    cases = [
        {'input': [], 'output': []},
        {'input': ['a', 'B', 'c'], 'output': ['a', 'b', 'c']},
        {'input': ['a', 123, 'b'], 'output': ['a', 123, 'b']},
    ]
    for case in cases:
        result = lenient_lowercase(case['input'])
        assert result == case['output'],  "lenient_lowercase(%s) did not equal %s" % (case['input'], case['output'])


# Generated at 2022-06-22 22:19:08.306217
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(12) == '12 Bytes'
    assert bytes_to_human(100) == '100 Bytes'
    assert bytes_to_human(100, unit='b') == '100 bits'
    assert bytes_to_human(100, isbits=True, unit='b') == '100 bits'
    assert bytes_to_human(100, isbits=True, unit='B') == '100 bytes'

    assert bytes_to_human(2 ** 10) == '1.00 KB'
    assert bytes_to_human(2 ** 20) == '1.00 MB'
    assert bytes_to_human(2 ** 30) == '1.00 GB'
    assert bytes_to_human(2 ** 40) == '1.00 TB'

# Generated at 2022-06-22 22:19:13.843804
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [1, 2, 3, 4]
    lower = lenient_lowercase(lst)
    assert lst == lower
    lst = ['1', '2', '3', '4']
    lower = lenient_lowercase(lst)
    assert lst != lower
    assert lower == ['1', '2', '3', '4']
    lst = ['1', 2, '3', '4']
    lower = lenient_lowercase(lst)
    assert lst != lower
    assert lower == ['1', 2, '3', '4']

# Generated at 2022-06-22 22:19:23.514039
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == "10.00 Bytes"
    assert bytes_to_human(1 << 20, unit='K') == "1024.00 KB"
    assert bytes_to_human(1 << 20, unit='kb') == "8192.00 Kb"
    assert bytes_to_human(1 << 20, unit='Kb') == "8192.00 Kb"
    assert bytes_to_human(1 << 20, isbits=True, unit='K') == "8192.00 Kb"
    assert bytes_to_human(1 << 20, isbits=True, unit='Kb') == "8192.00 Kb"
    assert bytes_to_human(1 << 10, unit='bit') == "8.00 bits"
    assert bytes_to_human(1 << 10, unit='bits')

# Generated at 2022-06-22 22:19:26.911910
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    items = ['1', '2', '3', 4, 5]
    lowered = lenient_lowercase(items)
    assert lowered == ['1', '2', '3', 4, 5]



# Generated at 2022-06-22 22:19:38.703950
# Unit test for function lenient_lowercase

# Generated at 2022-06-22 22:19:46.188524
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['1', '2', '3']) == ['1', '2', '3']
    assert lenient_lowercase(['1', '2', '3', 'three']) == ['1', '2', '3', 'three']
    assert lenient_lowercase([1, 'two', '3', 'four']) == [1, 'two', '3', 'four']
    assert lenient_lowercase([1, 'two', 3, 'four']) == [1, 'two', 3, 'four']


# Unit tests for function human_to_bytes()

# Generated at 2022-06-22 22:19:48.451262
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1234) == '1.21 KB'
    assert bytes_to_human(1234, unit='K') == '1.21 KB'


# Generated at 2022-06-22 22:19:54.996233
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['a', 'B', 'c', 'D', 'e']
    assert lenient_lowercase(lst) == ['a', 'B', 'c', 'D', 'e']
    lst = [1, 2, 3, 4, 5]
    assert lenient_lowercase(lst) == [1, 2, 3, 4, 5]
    lst = ['a', 2, 'C', 4, 'E']
    assert lenient_lowercase(lst) == ['a', 2, 'C', 4, 'E']
    lst = []
    assert lenient_lowercase(lst) == []
    lst = ['a', {'b': 2}, 'c']
    assert lenient_lowercase(lst) == ['a', {'b': 2}, 'c']



# Generated at 2022-06-22 22:20:07.636833
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''testing human_to_bytes'''

    def check_value(input_string, isbits=False, unit=None, expected_bytes=None, conversion_function=None):
        '''
        Check if a number is converted correctly
        '''
        # use default function if no function is passed
        if conversion_function is None:
            conversion_function = human_to_bytes
        assert input_string is not None
        assert expected_bytes is not None

        try:
            output_bytes = conversion_function(input_string, unit, isbits)
        except ValueError as exc:
            print('Error converting %s (unit=%s, isbits=%s)' % (input_string, unit, isbits))
            print('Error message: %s' % exc)
            assert False

        # check and print result if failed
       

# Generated at 2022-06-22 22:20:15.771764
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    import unittest

    class TestLenientLowercase(unittest.TestCase):
        def test_lenient_lowercase(self):
            lst = [1, 2, 3, 'Test', 'LOWER', 'upper']
            expected = [1, 2, 3, 'Test', 'lower', 'upper']
            result = lenient_lowercase(lst)
            self.assertTrue(result == expected)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestLenientLowercase)
    unittest.TextTestRunner(verbosity=2).run(suite)



# Generated at 2022-06-22 22:20:24.050701
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'Mb') == 10485760
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes(10, 'b') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2Kb') == 2048
    assert human_to_bytes(10) == 10
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10KB') == 10240

    assert bytes_to_human(1048576, unit='M') == '1.00 MB'

# Generated at 2022-06-22 22:20:34.566113
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10 * 1024 * 1024
    assert human_to_bytes('10M', 'B') == 10 * 1024 * 1024
    assert human_to_bytes('10MB') == 10 * 1024 * 1024
    assert human_to_bytes('10Mb') == 10 * 1024 * 1024
    assert human_to_bytes('10Mb', 'b') == 10 * 1024 * 1024
    assert human_to_bytes('10Mb', 'b', True) == 10 * 1024 * 1024
    assert human_to_bytes('10', 'MB') == 10 * 1024 * 1024
    assert human_to_bytes('10', 'Mb') == 10 * 1024 * 1024

    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10B') == 10

# Generated at 2022-06-22 22:20:43.294412
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:20:44.494601
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, "one", True]) == [1, 'one', True]

# Generated at 2022-06-22 22:20:55.101845
# Unit test for function human_to_bytes

# Generated at 2022-06-22 22:21:05.625812
# Unit test for function bytes_to_human
def test_bytes_to_human():
    import unittest
    class BytesToHumanTestCase(unittest.TestCase):
        def setUp(self):
            pass
        # checks if bytes_to_human returns correct value with given input
        def test_bytes_to_human(self):
            self.assertEqual('100.00 Bytes', bytes_to_human(100))
            self.assertEqual('100.00 Bytes', bytes_to_human(100, False))
            self.assertEqual('100.00 bits', bytes_to_human(100, True))

        # checks if bytes_to_human returns correct value with given input
        def test_bytes_to_human_with_unit(self):
            self.assertEqual('100.00 Bytes', bytes_to_human(100, unit='B'))

# Generated at 2022-06-22 22:21:14.559543
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', isbits=True) == 10485760
    assert human_to_bytes('10G', default_unit='M') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 83886080
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10MB', isbits=True) == 10485760
    assert human_to_bytes('10.5MB') == 10995116
    assert human_to_bytes('10.5MB', isbits=True) == 87964516
    assert human_to_bytes('10.5G') == 10

# Generated at 2022-06-22 22:21:25.133727
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(0.5 * (1 << 20)) == '0.50 MB'
    assert bytes_to_human(0.5 * (1 << 20), isbits=True) == '4.00 Mb'
    assert bytes_to_human(0.5 * (1 << 20), unit='kb') == '512.00 KB'
    assert bytes_to_human(0.5 * (1 << 20), unit='kb', isbits=True) == '4.19 Mb'
    assert bytes_to_human(0.5 * (1 << 20), unit='b') == '4194304.00 bits'

# Generated at 2022-06-22 22:21:28.572571
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['FOO', 'bar']) == ['foo', 'bar']
    assert lenient_lowercase([1, 2]) == [1, 2]
    assert lenient_lowercase(['FOO', 1, 'bar']) == ['foo', 1, 'bar']



# Generated at 2022-06-22 22:21:38.877303
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576) == '1024.00 Bytes'
    assert bytes_to_human(1048576, isbits=True) == '8388608.00 bits'
    assert bytes_to_human(1048576, unit='b') == '8388608.00 bits'
    assert bytes_to_human(1048576, unit='B') == '1024.00 Bytes'
    assert bytes_to_human(1048576, unit='k') == '1024.00 KB'
    assert bytes_to_human(1048576, unit='K') == '1024.00 KB'
    assert bytes_to_human(1048576, unit='M') == '1.05 MB'
    assert bytes_to_human(1048576, unit='G') == '1.07 GB'
    assert bytes_

# Generated at 2022-06-22 22:21:45.537887
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst_to_test = ['abc', 'ABC', 1, 2, 'aBc', None, {'test': 'value'}]
    expected_result = ['abc', 'abc', 1, 2, 'abc', None, {'test': 'value'}]
    assert lenient_lowercase(lst_to_test) == expected_result


# Generated at 2022-06-22 22:21:56.836516
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    print("Testing lenient_lowercase")

    # Test 1, convert lowercase
    test_list = ['a', 'B', 'C']
    output = lenient_lowercase(test_list)
    if output == ['a', 'b', 'c']:
        print("Test 1 OK")
    else:
        print("Test 1 FAIL")

    # Test 2, convert lowercase, no integers
    test_list = ['a', 'B', 1]
    output = lenient_lowercase(test_list)
    if output == ['a', 'b', 1]:
        print("Test 2 OK")
    else:
        print("Test 2 FAIL")

    # Test 3, convert lowercase, no dicts
    test_list = ['a', 'B', {'c': 1}]
    output = lenient_lowercase

# Generated at 2022-06-22 22:22:03.314953
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 'a', 'b', 3, 4, [5], [6], 'c']) == [1, 2, 'a', 'b', 3, 4, [5], [6], 'c']
    assert lenient_lowercase(['a', 'b', 'C', 'D']) == ['a', 'b', 'C', 'D']
    assert lenient_lowercase(['a', 'b', 'C', 'D']) != ['a', 'b', 'c', 'd']
