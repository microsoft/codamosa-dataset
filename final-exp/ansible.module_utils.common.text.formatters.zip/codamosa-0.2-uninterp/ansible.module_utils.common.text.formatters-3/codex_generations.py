

# Generated at 2022-06-16 23:09:22.538744
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17283797748568064
    assert human_to_bytes('1.5Z') == 176783116847593216
    assert human_to_bytes('1.5Y') == 1807381463104057344
    assert human

# Generated at 2022-06-16 23:09:33.706559
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:09:42.853854
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', isbits=True) == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10MB', isbits=True) == 10485760
    assert human_to_bytes('10mb') == 10485760
    assert human_to_bytes('10mb', isbits=True) == 10485760
    assert human_to_bytes('10Mb', unit='b') == 10485760

# Generated at 2022-06-16 23:09:53.482501
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.6') == 2
    assert human_to_bytes('1.6K') == 1638
    assert human_to_bytes('1.6M') == 1677721
    assert human_to_bytes('1.6G') == 1717986918
    assert human_to_bytes('1.6T') == 17592186044416
    assert human_to_bytes('1.6P') == 1797693134862316
    assert human_to_bytes('1.6E') == 1836311903
    assert human_to_bytes('1.6Z') == 1875490612
    assert human

# Generated at 2022-06-16 23:10:05.701458
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.1K') == 1.1 * 1024
    assert human_to_bytes('1.1M') == 1.1 * 1024 * 1024
    assert human_to_bytes('1.1G') == 1.1 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1T') == 1.1 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1P') == 1.1 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1E') == 1.1 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1Z') == 1.1 * 1024 * 1024

# Generated at 2022-06-16 23:10:10.716697
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', None, 'C']) == ['a', 'b', None, 'c']



# Generated at 2022-06-16 23:10:18.952823
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'b', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'b', 'c', 1, 'd']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'b', 'c', 1, 'D']) == ['a', 'b', 'c', 1, 'd']

# Generated at 2022-06-16 23:10:28.975525
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864766192408576
    assert human_to_bytes('1.5Z') == 1768177615427379200
    assert human_to_bytes('1.5Y') == 180776627149865984000
    assert human

# Generated at 2022-06-16 23:10:41.008489
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864626906982400
    assert human_to_bytes('1.5Z') == 17684495219702666240
    assert human_to_bytes('1.5Y') == 1808329804940661248000


# Generated at 2022-06-16 23:10:49.729132
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'e']) == ['a', 'b', 'c', 1, 'd', 'e']

# Generated at 2022-06-16 23:11:03.593823
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17283797747244544
    assert human_to_bytes('1.5Z') == 1768175748597739520
    assert human_to_bytes('1.5Y') == 1808124313733035008

    assert human

# Generated at 2022-06-16 23:11:13.233932
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17283849323579056
    assert human_to_bytes('1.5Z') == 176783115435957760
    assert human_to_bytes('1.5Y') == 1807326416518168576
    assert human_

# Generated at 2022-06-16 23:11:14.909191
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 1, 'c']) == ['a', 'b', 1, 'c']



# Generated at 2022-06-16 23:11:22.122334
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864766192403456
    assert human_to_bytes('1.5Z') == 17684477177623992320

# Generated at 2022-06-16 23:11:32.888405
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 1, 'C', 'D']) == ['a', 1, 'c', 'd']
    assert lenient_lowercase(['A', 1, 'C', 'D', 'E']) == ['a', 1, 'c', 'd', 'e']
    assert lenient_lowercase(['A', 1, 'C', 'D', 'E', 'F']) == ['a', 1, 'c', 'd', 'e', 'f']

# Generated at 2022-06-16 23:11:39.369979
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']

# Generated at 2022-06-16 23:11:46.550740
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', None, 'C']) == ['a', 'b', None, 'c']
    assert lenient_lowercase(['A', 'B', [], 'C']) == ['a', 'b', [], 'c']



# Generated at 2022-06-16 23:11:57.867420
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976
    assert human_to_bytes('1Z') == 1180591620717411303424
    assert human_to_bytes('1Y') == 1208925819614629174706176
    assert human_to_bytes

# Generated at 2022-06-16 23:12:08.923955
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1.5
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17286476637737984
    assert human_to_bytes('1.5Z') == 1768177624796774400
    assert human_to_bytes('1.5Y') == 180773858581227520000


# Generated at 2022-06-16 23:12:17.426022
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17283797747244544
    assert human_to_bytes('1.5Z') == 176783117035452416
    assert human_to_bytes('1.5Y') == 1807381396998225920
    assert human

# Generated at 2022-06-16 23:12:31.591258
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', None]) == ['a', 'b', None]

# Generated at 2022-06-16 23:12:36.535139
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']


# Generated at 2022-06-16 23:12:44.507308
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D', 2]) == ['a', 'b', 1, 'c', 'd', 2]

# Generated at 2022-06-16 23:12:56.507860
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 17678311753906250000
    assert human_to_bytes('1.5Y') == 18073292058164062500000

    assert human

# Generated at 2022-06-16 23:13:04.306048
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 2]) == ['a', 'b', 'c', 1, 'd', 2]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 2, 'e']) == ['a', 'b', 'c', 1, 'd', 2, 'e']

# Generated at 2022-06-16 23:13:11.636613
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', None, 'C']) == ['a', 'b', None, 'c']
    assert lenient_lowercase(['A', 'B', [], 'C']) == ['a', 'b', [], 'c']
    assert lenient_lowercase(['A', 'B', {}, 'C']) == ['a', 'b', {}, 'c']

# Generated at 2022-06-16 23:13:22.540293
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.6') == 2
    assert human_to_bytes('1.6K') == 1638
    assert human_to_bytes('1.6M') == 16777216
    assert human_to_bytes('1.6G') == 17179869184
    assert human_to_bytes('1.6T') == 17592186044416
    assert human_to_bytes('1.6P') == 1797693134862316
    assert human_to_bytes('1.6E') == 1836311903
    assert human_to_bytes('1.6Z') == 1875490613

# Generated at 2022-06-16 23:13:35.014510
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976
    assert human_to_bytes('1Z') == 1180591620717411303424
    assert human_to_bytes('1Y') == 1208925819614629174706176
    assert human_to_bytes

# Generated at 2022-06-16 23:13:46.148997
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 17678311762790400000
    assert human_to_bytes('1.5Y') == 180738309628480000000
    assert human_to

# Generated at 2022-06-16 23:13:57.909999
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D', 2]) == ['a', 'b', 'c', 1, 'd', 2]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D', 2, 'E']) == ['a', 'b', 'c', 1, 'd', 2, 'e']

# Generated at 2022-06-16 23:14:13.841836
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976
    assert human_to_bytes('1Z') == 1180591620717411303424
    assert human_to_bytes('1Y') == 1208925819614629174706176
    assert human_to_bytes

# Generated at 2022-06-16 23:14:25.958251
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'b', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'b', 'c', 1, 'A']) == ['a', 'b', 'c', 1, 'A']

# Generated at 2022-06-16 23:14:38.720088
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D', 2]) == ['a', 'b', 'c', 1, 'd', 2]
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D', 2, 'E']) == ['a', 'b', 'c', 1, 'd', 2, 'e']

# Generated at 2022-06-16 23:14:46.725258
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 1767831179228160000
    assert human_to_bytes('1.5Y') == 18073830466483200000
    assert human_to

# Generated at 2022-06-16 23:14:56.795799
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864626906982400
    assert human_to_bytes('1.5Z') == 17684437172788582400
    assert human_to_bytes('1.5Y') == 1808341165487900672000
   

# Generated at 2022-06-16 23:15:08.963106
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1Mb') == 1024 * 1024
    assert human_to_bytes('1G') == 1024 * 1024 * 1024
    assert human_to_bytes('1Gb') == 1024 * 1024 * 1024
    assert human_to_bytes('1T') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1Tb') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1P') == 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-16 23:15:17.937651
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'b', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['a', 'b', 1, 'c']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['a', 'b', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'b', 'c', 1, 'd']) == ['a', 'b', 'c', 1, 'd']

# Generated at 2022-06-16 23:15:28.977665
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test with default unit
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.5') == 2
    assert human_to_bytes('1.9') == 2
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0.0') == 1
    assert human_to_bytes('1.0.1') == 1
    assert human_to_bytes('1.0.1.1') == 1
    assert human_to_bytes('1.0.1.1.1') == 1
    assert human_to_bytes('1.0.1.1.1.1') == 1
    assert human_to_bytes('1.0.1.1.1.1.1')

# Generated at 2022-06-16 23:15:37.871882
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:15:51.049060
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['a', 'B', 1, 'c']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['a', 'B', 1, 'c', 'D']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['a', 'B', 1, 'c', 'D', 2]) == ['a', 'b', 1, 'c', 'd', 2]
   

# Generated at 2022-06-16 23:16:15.335855
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'B', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'B', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'E']) == ['a', 'B', 'c', 1, 'd', 'E']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'E', 'F', 2]) == ['a', 'B', 'c', 1, 'd', 'E', 'F', 2]

# Generated at 2022-06-16 23:16:25.185888
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 1728647661927680000
    assert human_to_bytes('1.5Z') == 176817763774394880000
    assert human_to_bytes('1.5Y') == 180774924696839168000000

# Generated at 2022-06-16 23:16:31.814743
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test bytes
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', default_unit='B') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10MB', default_unit='B') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Mb', default_unit='B') == 10485760
    assert human_to_bytes('10Mb', default_unit='B', isbits=True) == 10485760
    assert human_to_bytes('10MB', default_unit='B', isbits=True) == 10485760

# Generated at 2022-06-16 23:16:37.662478
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976
    assert human_to_bytes('1Z') == 1180591620717411303424
    assert human_to_bytes('1Y') == 1208925819614629174706176
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1kb') == 1000
    assert human_to_bytes

# Generated at 2022-06-16 23:16:43.222797
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', None, 'C']) == ['a', 'b', None, 'c']


# Generated at 2022-06-16 23:16:51.374084
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C', None]) == ['a', 'b', 1, 'c', None]
    assert lenient_lowercase(['A', 'B', 1, 'C', None, 'D']) == ['a', 'b', 1, 'c', None, 'd']


# Generated at 2022-06-16 23:17:00.820965
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 'B', 'C']) != ['A', 'B', 'C']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase([1, 'B', 3]) == [1, 'B', 3]
    assert lenient_lowercase([1, 'B', 3]) != [1, 'b', 3]
    assert lenient_lowercase([]) == []

# Generated at 2022-06-16 23:17:08.720993
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 1, 'c']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']



# Generated at 2022-06-16 23:17:18.782420
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17283797747705856
    assert human_to_bytes('1.5Z') == 1768175748591104
    assert human_to_bytes('1.5Y') == 1808126740493414
    assert human_to

# Generated at 2022-06-16 23:17:29.391117
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 17678311762791424000
    assert human_to_bytes('1.5Y') == 1807383046284859392000

# Generated at 2022-06-16 23:17:54.032038
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]

# Generated at 2022-06-16 23:18:04.645769
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17283797747244544
    assert human_to_bytes('1.5Z') == 1767831170359816192
    assert human_to_bytes('1.5Y') == 180738104896153600000
    assert human

# Generated at 2022-06-16 23:18:16.206715
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1M', 'B') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1MB', 'B') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1Mb', 'b', isbits=True) == 1048576
    assert human_to_bytes('1Mb', 'b', isbits=False) == 1048576
    assert human_to_bytes('1Mb', 'B', isbits=True) == 1048576
    assert human_to_bytes('1Mb', 'B', isbits=False) == 1048576
    assert human_to_bytes

# Generated at 2022-06-16 23:18:27.928607
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172838496659303936
    assert human_to_bytes('1.5Z') == 1767832263401553920
    assert human_to_bytes('1.5Y') == 18072895602192424960

# Generated at 2022-06-16 23:18:35.843305
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 'D']) == ['a', 'B', 'c', 'D']
    assert lenient_lowercase(['a', 'B', 'c', 'D', 1]) == ['a', 'B', 'c', 'D', 1]
    assert lenient_lowercase(['a', 'B', 'c', 'D', 1, 'e']) == ['a', 'B', 'c', 'D', 1, 'e']
    assert lenient_lowercase(['a', 'B', 'c', 'D', 1, 'e', 'F']) == ['a', 'B', 'c', 'D', 1, 'e', 'F']
    assert lenient_lowercase(['a', 'B', 'c', 'D', 1, 'e', 'F', 2])

# Generated at 2022-06-16 23:18:48.471472
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', 1.0]) == ['a', 'b', 1.0]
    assert lenient_lowercase(['A', 'B', '1.0']) == ['a', 'b', '1.0']
    assert lenient_lowercase(['A', 'B', None]) == ['a', 'b', None]
    assert lenient_lowercase(['A', 'B', True]) == ['a', 'b', True]
    assert lenient_lowercase(['A', 'B', False]) == ['a', 'b', False]
    assert len

# Generated at 2022-06-16 23:18:58.389867
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D']) == ['a', 'b', 'c', 1, 'd']

# Generated at 2022-06-16 23:19:10.940319
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D', 'E']) == ['a', 'b', 1, 'c', 'd', 'e']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D', 'E', 'F']) == ['a', 'b', 1, 'c', 'd', 'e', 'f']