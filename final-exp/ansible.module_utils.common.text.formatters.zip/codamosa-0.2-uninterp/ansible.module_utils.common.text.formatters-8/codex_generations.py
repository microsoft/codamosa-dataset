

# Generated at 2022-06-16 23:09:33.030983
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5Kb') == 1536
    assert human_to_bytes('1.5K', isbits=True) == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5Mb') == 1572864
    assert human_to_bytes('1.5M', isbits=True) == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to

# Generated at 2022-06-16 23:09:42.382647
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test for bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0Kb') == 1024
    assert human_to_bytes('1.0KB') == 1024
    assert human_to_bytes('1.0Kb') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0Mb') == 1048576

# Generated at 2022-06-16 23:09:49.490460
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864766192403456
    assert human_to_bytes('1.5Z') == 1768177619077364736
    assert human_to_bytes('1.5Y') == 180774400755929495552
   

# Generated at 2022-06-16 23:10:01.282720
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.5') == 2
    assert human_to_bytes('1.9') == 2
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976

# Generated at 2022-06-16 23:10:11.241576
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.1K') == 1.1 * 1024
    assert human_to_bytes('1.1M') == 1.1 * 1024 * 1024
    assert human_to_bytes('1.1G') == 1.1 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1T') == 1.1 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1P') == 1.1 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_

# Generated at 2022-06-16 23:10:23.436002
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864766192403456
    assert human_to_bytes('1.5Z') == 1768389630716614656
    assert human_to_bytes('1.5Y') == 18082261916680175616
    assert human_

# Generated at 2022-06-16 23:10:33.494391
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5Kb') == 1536
    assert human_to_bytes('1.5K', isbits=True) == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5Mb') == 1572864
    assert human_to_bytes('1.5M', isbits=True) == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to

# Generated at 2022-06-16 23:10:46.047867
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='b') == '1.00 bits'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, unit='b', isbits=True) == '1.00 bits'
    assert bytes_to_human(1, unit='B', isbits=True) == '8.00 bits'
    assert bytes_to_human(1, isbits=True) == '8.00 bits'
    assert bytes_to_human(1, unit='k') == '1.00 KB'
    assert bytes_to_human(1, unit='k', isbits=True) == '8.00 Kb'

# Generated at 2022-06-16 23:10:59.243416
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', None]) == ['a', 'b', None]
    assert lenient_lowercase(['A', 'B', []]) == ['a', 'b', []]
    assert lenient_lowercase(['A', 'B', {}]) == ['a', 'b', {}]

# Generated at 2022-06-16 23:11:11.286316
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test for bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0b', isbits=True) == 1
    assert human_to_bytes('1.0B', isbits=True) == 8
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0', default_unit='B') == 1
    assert human_to_bytes('1.0', default_unit='b') == 1
    assert human_to_

# Generated at 2022-06-16 23:11:18.577204
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:11:30.024515
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.5') == 2
    assert human_to_bytes('1.9') == 2
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976

# Generated at 2022-06-16 23:11:35.903973
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.6') == 2
    assert human_to_bytes('1.6K') == 1638
    assert human_to_bytes('1.6M') == 16777216
    assert human_to_bytes('1.6G') == 17179869184
    assert human_to_bytes('1.6T') == 17592186044416
    assert human_to_bytes('1.6P') == 1797693134862316
    assert human_to_bytes('1.6E') == 1836311903
    assert human_to_bytes('1.6Z') == 1875490612

# Generated at 2022-06-16 23:11:45.706928
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'B', 'c']
    assert lenient_lowercase([1, 'B', 'c']) == [1, 'B', 'c']
    assert lenient_lowercase(['a', 'B', 3]) == ['a', 'B', 3]
    assert lenient_lowercase([1, 'B', 3]) == [1, 'B', 3]
    assert lenient_lowercase(['a', 2, 3]) == ['a', 2, 3]
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-16 23:11:49.217771
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]


# Generated at 2022-06-16 23:11:59.383787
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D', 2]) == ['a', 'b', 'c', 1, 'd', 2]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D', 2, 'E']) == ['a', 'b', 'c', 1, 'd', 2, 'e']

# Generated at 2022-06-16 23:12:10.926647
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976
    assert human_to_bytes('1.0Z') == 1180591620717411303424
    assert human_to_bytes('1.0Y') == 1208925819614629174706176
    assert human_

# Generated at 2022-06-16 23:12:20.729143
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 1767831154354539520
    assert human_to_bytes('1.5Y') == 180738103316993228800

# Generated at 2022-06-16 23:12:31.880266
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 1728379774856704
    assert human_to_bytes('1.5Z') == 1767831160362496
    assert human_to_bytes('1.5Y') == 18073812984565760
    assert human_to_

# Generated at 2022-06-16 23:12:42.384411
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485680640
    assert human_to_bytes('1.5Z') == 17681757485936230400
    assert human_to_bytes('1.5Y') == 1808124310226841600000
    assert human

# Generated at 2022-06-16 23:12:59.327043
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:13:09.959508
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 10995116

# Generated at 2022-06-16 23:13:20.654248
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 'B', 'C']) != ['A', 'B', 'C']
    assert lenient_lowercase(['A', 'B', 'C']) != ['a', 'B', 'C']
    assert lenient_lowercase(['A', 'B', 'C']) != ['a', 'b', 'C']
    assert lenient_lowercase(['A', 'B', 'C']) != ['a', 'b', 'c']


# Generated at 2022-06-16 23:13:32.684100
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase([1, 'A', 'B', 'C']) == [1, 'a', 'b', 'c']
    assert lenient_lowercase([1, 'A', 'B', 'C', 'D']) == [1, 'a', 'b', 'c', 'D']

# Generated at 2022-06-16 23:13:44.025192
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864766192403456
    assert human_to_bytes('1.5Z') == 17681776806619136000
    assert human_to_bytes('1.5Y') == 1807744809438291968000

# Generated at 2022-06-16 23:13:55.612627
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['a', 'B', 1, 'c']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['a', 'B', 1, 'c', 'd']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['a', 'B', 1, 'c', 'd', 'e']) == ['a', 'b', 1, 'c', 'd', 'e']

# Generated at 2022-06-16 23:14:07.894983
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5k') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5m') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5g') == 1610612736
    assert human_to_bytes('1.5T') == 164926744

# Generated at 2022-06-16 23:14:15.673958
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'E']) == ['a', 'b', 'c', 1, 'd', 'e']


# Generated at 2022-06-16 23:14:27.200392
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976
    assert human_to_bytes('1.0Z') == 1180591620717411303424
    assert human_to_bytes('1.0Y') == 1208925819614629174706176
    assert human_

# Generated at 2022-06-16 23:14:39.787658
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17286476688237568
    assert human_to_bytes('1.5Z') == 176838963076331520
    assert human_to_bytes('1.5Y') == 1808226192475830272
    assert human_

# Generated at 2022-06-16 23:14:55.186930
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D']) == ['a', 'b', 'c', 1, 'D']

# Generated at 2022-06-16 23:15:07.451195
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', default_unit='B') == 10485760
    assert human_to_bytes('10M', default_unit='K') == 10240
    assert human_to_bytes('10M', default_unit='M') == 10
    assert human_to_bytes('10M', default_unit='G') == 0.01
    assert human_to_bytes('10M', default_unit='T') == 0.0001
    assert human_to_bytes('10M', default_unit='P') == 0.000001
    assert human_to_bytes('10M', default_unit='E') == 0.000000001
    assert human_to_bytes('10M', default_unit='Z') == 0.000000000001
    assert human_to

# Generated at 2022-06-16 23:15:17.079823
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0B', 'B') == 1
    assert human_to_bytes('1.0b', 'b') == 1
    assert human_to_bytes('1.0', 'B') == 1
    assert human_to_bytes('1.0', 'b') == 1
    assert human_to_bytes('1.0', 'B') == 1

# Generated at 2022-06-16 23:15:28.266109
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['a', 'B', 1, 'c']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['a', 'B', 1, 'c', 'd']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['a', 'B', 1, 'c', 'd', 'e']) == ['a', 'b', 1, 'c', 'd', 'e']

# Generated at 2022-06-16 23:15:37.401966
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 1767831079205865472
    assert human_to_bytes('1.5Y') == 18073810992056815616
    assert human

# Generated at 2022-06-16 23:15:50.568840
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864766192403456
    assert human_to_bytes('1.5Z') == 1768177699680534528
    assert human_to_bytes('1.5Y') == 180774924221481574400

# Generated at 2022-06-16 23:16:02.387776
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B', isbits=True) == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K', isbits=True) == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1M', isbits=True) == 1024 * 1024
    assert human_to_bytes('1Mb') == 1024 * 1024
    assert human_to_bytes('1MB') == 1024 * 1024
   

# Generated at 2022-06-16 23:16:14.800199
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.5') == 2
    assert human_to_bytes('1.9') == 2
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976

# Generated at 2022-06-16 23:16:22.676569
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976
    assert human_to_bytes('1.0Z') == 1180591620717411303424
    assert human_to_bytes('1.0Y') == 1208925819614629174706176
    assert human_

# Generated at 2022-06-16 23:16:30.518721
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D', 2]) == ['a', 'b', 'c', 1, 'd', 2]
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D', 2, 'E']) == ['a', 'b', 'c', 1, 'd', 2, 'e']

# Generated at 2022-06-16 23:16:47.892110
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'e']) == ['a', 'b', 'c', 1, 'd', 'e']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'e', 'f']) == ['a', 'b', 'c', 1, 'd', 'e', 'f']

# Generated at 2022-06-16 23:16:58.649804
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.6') == 2
    assert human_to_bytes('1.6K') == 1638
    assert human_to_bytes('1.6M') == 16777216
    assert human_to_bytes('1.6G') == 17179869184
    assert human_to_bytes('1.6T') == 17592186044416
    assert human_to_bytes('1.6P') == 1797693134862316
    assert human_to_bytes('1.6E') == 1836311903
    assert human_to_bytes('1.6Z') == 18754906
    assert human

# Generated at 2022-06-16 23:17:11.214251
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:17:20.194682
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test for bytes
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0', default_unit='B') == 1
    assert human_to_bytes('1.0', default_unit='b') == 1
    assert human_to_bytes('1.0', default_unit='B', isbits=True) == 1
    assert human_to_bytes('1.0', default_unit='b', isbits=True) == 1

# Generated at 2022-06-16 23:17:30.419925
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.6') == 2
    assert human_to_bytes('1.6K') == 1638
    assert human_to_bytes('1.6M') == 1677721
    assert human_to_bytes('1.6G') == 1717986918
    assert human_to_bytes('1.6T') == 17592186044416
    assert human_to_bytes('1.6P') == 1797693134862316
    assert human_to_bytes('1.6E') == 18369739842712
    assert human_to_bytes('1.6Z') == 187495979795072

# Generated at 2022-06-16 23:17:42.259100
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('2') == 2
    assert human_to_bytes('2.0') == 2
    assert human_to_bytes('2.1') == 2
    assert human_to_bytes('2.9') == 2
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1.1K') == 1024
    assert human_to_bytes('1.9K') == 1024
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2.0K') == 2048
    assert human_to_bytes('2.1K') == 2048
    assert human_to_

# Generated at 2022-06-16 23:17:54.556969
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]
    assert lenient_lowercase(['a', 'B', 'C', 1, 2, 3, 'D']) == ['a', 'b', 'c', 1, 2, 3, 'd']
    assert lenient_lowercase(['a', 'B', 'C', 1, 2, 3, 'D', 'E']) == ['a', 'b', 'c', 1, 2, 3, 'd', 'e']
    assert lenient_lowercase(['a', 'B', 'C', 1, 2, 3, 'D', 'E', 'F']) == ['a', 'b', 'c', 1, 2, 3, 'd', 'e', 'f']


# Generated at 2022-06-16 23:18:05.179510
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=False) == 10485760
    assert human_to_bytes('10Mb', isbits=False, default_unit='B') == 10485760
    assert human_to_bytes('10Mb', isbits=False, default_unit='b') == 10485760
    assert human_to_bytes('10Mb', isbits=True, default_unit='B') == 10485760
    assert human_to_bytes('10Mb', isbits=True, default_unit='b') == 10485760
    assert human

# Generated at 2022-06-16 23:18:16.739861
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'B', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'B', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd']) == ['a', 'B', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'e']) == ['a', 'B', 'c', 1, 'd', 'e']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'e', 'f']) == ['a', 'B', 'c', 1, 'd', 'e', 'f']
    assert len

# Generated at 2022-06-16 23:18:28.335247
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D', 2]) == ['a', 'b', 1, 'c', 'd', 2]

# Generated at 2022-06-16 23:18:55.633161
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D', 'e']) == ['a', 'b', 'c', 1, 'd', 'e']

# Generated at 2022-06-16 23:19:02.935010
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485680640
    assert human_to_bytes('1.5Z') == 17681757485936230400
    assert human_to_bytes('1.5Y') == 18081237579786915840000

# Generated at 2022-06-16 23:19:14.732035
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D', 2]) == ['a', 'b', 1, 'c', 'd', 2]