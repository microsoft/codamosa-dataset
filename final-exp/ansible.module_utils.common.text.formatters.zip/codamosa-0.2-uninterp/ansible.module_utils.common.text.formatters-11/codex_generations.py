

# Generated at 2022-06-16 23:09:31.373304
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0k') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0m') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0g') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0t')

# Generated at 2022-06-16 23:09:41.111787
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(100) == '100 Bytes'
    assert bytes_to_human(1000) == '1000 Bytes'
    assert bytes_to_human(10000) == '9.77 KB'
    assert bytes_to_human(100000) == '97.66 KB'
    assert bytes_to_human(1000000) == '976.56 KB'
    assert bytes_to_human(10000000) == '9.54 MB'
    assert bytes_to_human(100000000) == '95.37 MB'
    assert bytes_to_human(1000000000) == '953.67 MB'

# Generated at 2022-06-16 23:09:51.442946
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 17678326390790676480
    assert human_to_bytes('1.5Y') == 18073810489675407360000
   

# Generated at 2022-06-16 23:09:57.644729
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']

# Generated at 2022-06-16 23:10:08.808477
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 17678311702760704000
    assert human_to_bytes('1.5Y') == 1807383096285212672000

# Generated at 2022-06-16 23:10:17.497550
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['a', 'B', 1, 'c']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['a', 'B', 1, 'c', 'D']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['a', 'B', 1, 'c', 'D', 2]) == ['a', 'b', 1, 'c', 'd', 2]

# Generated at 2022-06-16 23:10:28.850970
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(100) == '100 Bytes'
    assert bytes_to_human(1000) == '1000 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1073741824) == '1.00 GB'
    assert bytes_to_human(1099511627776) == '1.00 TB'
    assert bytes_to_human(1125899906842624) == '1.00 PB'

# Generated at 2022-06-16 23:10:40.956663
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5k') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5m') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5g') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664

# Generated at 2022-06-16 23:10:47.712531
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5Kb') == 1536
    assert human_to_bytes('1.5Mb') == 1572864
    assert human_to_bytes('1.5Mb', isbits=True) == 1572864
    assert human_to_bytes('1.5MB') == 1572864
    assert human_to_bytes('1.5MB', isbits=True) == 1572864
    assert human_to_bytes('1.5MB', isbits=True, unit='b') == 1572864
    assert human_to_bytes('1.5MB', isbits=True, unit='B') == 15728

# Generated at 2022-06-16 23:11:00.374725
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, unit='b') == '1.00 bits'
    assert bytes_to_human(1, isbits=True) == '1.00 bits'
    assert bytes_to_human(1, isbits=True, unit='b') == '1.00 bits'
    assert bytes_to_human(1, isbits=True, unit='B') == '8.00 bits'
    assert bytes_to_human(1, isbits=False, unit='b') == '0.00 Bytes'
    assert bytes_to_human(1, isbits=False, unit='B') == '1.00 Bytes'

# Generated at 2022-06-16 23:11:11.350733
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'B', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'B', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D']) == ['a', 'B', 'c', 1, 'D']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D', 2]) == ['a', 'B', 'c', 1, 'D', 2]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D', 2, 'e']) == ['a', 'B', 'c', 1, 'D', 2, 'e']

# Generated at 2022-06-16 23:11:20.295794
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:11:32.012210
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 1767831154997722112
    assert human_to_bytes('1.5Y') == 18073810959965646848

# Generated at 2022-06-16 23:11:44.398829
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1B', isbits=True) == 8
    assert human_to_bytes('1B', isbits=True, unit='b') == 8
    assert human_to_bytes('1b', isbits=True, unit='B') == 8
    assert human_to_bytes('1B', isbits=True, unit='B') == 8
    assert human_to_bytes('1b', isbits=True, unit='b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K', isbits=True) == 8192
    assert human_to_bytes

# Generated at 2022-06-16 23:11:56.600504
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 1767831175983099904
    assert human_to_bytes('1.5Y') == 18073830466483118080

# Generated at 2022-06-16 23:12:06.122769
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'E']) == ['a', 'b', 'c', 1, 'd', 'e']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'E', 'F']) == ['a', 'b', 'c', 1, 'd', 'e', 'f']

# Generated at 2022-06-16 23:12:10.818191
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 17678311641833472000
    assert human_to_bytes('1.5Y') == 180738109548121600000
    assert human

# Generated at 2022-06-16 23:12:18.373272
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5k') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5m') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5g') == 1610612736
    assert human_to_bytes('1.5T') == 164926744

# Generated at 2022-06-16 23:12:23.144135
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 1, 'c']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']


# Generated at 2022-06-16 23:12:35.386911
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=False) == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10MB', isbits=True) == 10485760
    assert human_to_bytes('10MB', isbits=False) == 10485760
    assert human_to_bytes('10Mb', isbits=False) == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760

# Generated at 2022-06-16 23:12:45.461809
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5K', isbits=True) == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5M', isbits=True) == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5G', isbits=True) == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5T', isbits=True) == 1649267441664
   

# Generated at 2022-06-16 23:12:51.995927
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'b', 'C']) == ['a', 'b', 'c']

# Generated at 2022-06-16 23:13:01.744198
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', isbits=True) == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10MB', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=False) == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10MB', isbits=False) == 10485760

# Generated at 2022-06-16 23:13:11.006564
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:13:22.099803
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 17681757485936640000
    assert human_to_bytes('1.5Y') == 18081243147518208000000
    assert human

# Generated at 2022-06-16 23:13:34.733583
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977476915200
    assert human_to_bytes('1.5Z') == 1767831175079680000
    assert human_to_bytes('1.5Y') == 180738131849656320000
    assert human

# Generated at 2022-06-16 23:13:42.639471
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D', 2]) == ['a', 'b', 1, 'c', 'd', 2]

# Generated at 2022-06-16 23:13:45.172849
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]


# Generated at 2022-06-16 23:13:52.772043
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'C', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['A', 'b', 'C', 1, 'D']) == ['a', 'b', 'c', 1, 'D']
    assert lenient_lowercase(['A', 'b', 'C', 1, 'D', 2]) == ['a', 'b', 'c', 1, 'D', 2]
    assert lenient_lowercase(['A', 'b', 'C', 1, 'D', 2, 'E']) == ['a', 'b', 'c', 1, 'D', 2, 'E']

# Generated at 2022-06-16 23:14:05.429943
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864766164557824
    assert human_to_bytes('1.5Z') == 1768177699721601024
    assert human_to_bytes('1.5Y') == 1807749244780457984

# Generated at 2022-06-16 23:14:15.987708
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B', isbits=True) == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K', isbits=True) == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1MB', isbits=True)

# Generated at 2022-06-16 23:14:22.676772
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976
    assert human_to_bytes('1Z') == 1180591620717411303424
    assert human_to_bytes('1Y') == 1208925819614629174706176
    assert human_to_bytes

# Generated at 2022-06-16 23:14:35.452678
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'B', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'B', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd']) == ['a', 'B', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'e']) == ['a', 'B', 'c', 1, 'd', 'e']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'e', 'f']) == ['a', 'B', 'c', 1, 'd', 'e', 'f']
    assert len

# Generated at 2022-06-16 23:14:42.912193
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 1, 'c']) == ['a', 1, 'c']
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['a', 'B', 1, 'c']) == ['a', 'b', 1, 'c']



# Generated at 2022-06-16 23:14:54.035118
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'E']) == ['a', 'b', 'c', 1, 'd', 'e']

# Generated at 2022-06-16 23:15:01.299743
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', None]) == ['a', 'b', None]
    assert lenient_lowercase(['A', 'B', 'C', 'D']) == ['a', 'b', 'c', 'd']
    assert lenient_lowercase(['A', 'B', 'C', 'D', 1]) == ['a', 'b', 'c', 'd', 1]
    assert lenient_lowercase(['A', 'B', 'C', 'D', None]) == ['a', 'b', 'c', 'd', None]
    assert lenient_lowercase

# Generated at 2022-06-16 23:15:12.227378
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 17678311762791424000
    assert human_to_bytes('1.5Y') == 1807383096285885440000


# Generated at 2022-06-16 23:15:24.763563
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', 'C', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase([1, 'B', 'C']) == [1, 'b', 'c']
    assert lenient_lowercase([1, 'B', 'C', 1]) == [1, 'b', 'c', 1]
    assert lenient_lowercase([1, 1, 1]) == [1, 1, 1]
    assert lenient_lowercase([1, 'B', 1]) == [1, 'b', 1]
    assert lenient_

# Generated at 2022-06-16 23:15:27.849964
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'C', 'D', 1, 2, 3]) == ['a', 'b', 'c', 'd', 1, 2, 3]



# Generated at 2022-06-16 23:15:32.855121
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D', 'E', 'F']) == ['a', 'b', 'c', 1, 'd', 'e', 'f']

# Generated at 2022-06-16 23:15:50.617734
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.6') == 2
    assert human_to_bytes('1.6K') == 1638
    assert human_to_bytes('1.6M') == 16777216
    assert human_to_bytes('1.6G') == 17179869184
    assert human_to_bytes('1.6T') == 17592186044416
    assert human_to_bytes('1.6P') == 1797693134862316
    assert human_to_bytes('1.6E') == 1836311903
    assert human_to_bytes('1.6Z') == 1875490614

# Generated at 2022-06-16 23:15:52.862124
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]


# Generated at 2022-06-16 23:16:04.126896
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 1767831154354539520
    assert human_to_bytes('1.5Y') == 18073814446568294400

# Generated at 2022-06-16 23:16:16.011599
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976
    assert human_to_bytes('1.0Z') == 1180591620717411303424
    assert human_to_bytes('1.0Y') == 1208925819614629174706176
    assert human_

# Generated at 2022-06-16 23:16:25.649506
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D', 2]) == ['a', 'b', 1, 'c', 'd', 2]

# Generated at 2022-06-16 23:16:32.030636
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 1767831164183859200
    assert human_to_bytes('1.5Y') == 18073812953045350400
    assert human

# Generated at 2022-06-16 23:16:37.244501
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D', 2]) == ['a', 'b', 1, 'c', 'd', 2]

# Generated at 2022-06-16 23:16:46.812413
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', None]) == ['a', 'b', None]
    assert lenient_lowercase(['A', 'B', 'C', 'D']) == ['a', 'b', 'c', 'd']
    assert lenient_lowercase(['A', 'B', 1, 'D']) == ['a', 'b', 1, 'd']
    assert lenient_lowercase(['A', 'B', None, 'D']) == ['a', 'b', None, 'd']

# Generated at 2022-06-16 23:16:58.100922
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D', 'e']) == ['a', 'b', 'c', 1, 'd', 'e']

# Generated at 2022-06-16 23:17:10.588850
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D', 2]) == ['a', 'b', 'c', 1, 'd', 2]
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D', 2, 'E']) == ['a', 'b', 'c', 1, 'd', 2, 'e']

# Generated at 2022-06-16 23:17:30.475409
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.9K') == 1920
    assert human_to_bytes('1.9M') == 19922944
    assert human_to_bytes('1.9G') == 2080374784
    assert human_to_bytes('1.9T') == 2199023255552
    assert human_to_bytes('1.9P') == 228170137728256
    assert human_to_bytes('1.9E') == 2363283657342976
    assert human_to_bytes

# Generated at 2022-06-16 23:17:42.301153
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test for bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624

# Generated at 2022-06-16 23:17:54.562804
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976
    assert human_to_bytes('1.0Z') == 1180591620717411303424
    assert human_to_bytes('1.0Y') == 1208925819614629174706176
    assert human_

# Generated at 2022-06-16 23:18:05.181251
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17283797748568064
    assert human_to_bytes('1.5Z') == 1767832665233408000
    assert human_to_bytes('1.5Y') == 180732654500966400000

    assert human_

# Generated at 2022-06-16 23:18:16.739973
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.01') == 1
    assert human_to_bytes('1.001') == 1
    assert human_to_bytes('1.0001') == 1
    assert human_to_bytes('1.00001') == 1
    assert human_to_bytes('1.000001') == 1
    assert human_to_bytes('1.0000001') == 1
    assert human_to_bytes('1.00000001') == 1
    assert human_to_bytes('1.000000001') == 1
   

# Generated at 2022-06-16 23:18:28.334835
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['a', 'B', 1.0]) == ['a', 'b', 1.0]
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1.0]) == ['a', 'b', 'c', 1.0]
    assert lenient_lowercase(['a', 'B', 'c', 1, 1.0]) == ['a', 'b', 'c', 1, 1.0]


# Generated at 2022-06-16 23:18:30.464431
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'b', 1]


# Generated at 2022-06-16 23:18:37.916573
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 17678374074991032320
    assert human_to_bytes('1.5Y') == 1807301234898206646272
    assert human

# Generated at 2022-06-16 23:18:50.499405
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:18:52.290072
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]


# Generated at 2022-06-16 23:19:19.133693
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864766192403456
    assert human_to_bytes('1.5Z') == 17681776220352512000
    assert human_to_bytes('1.5Y') == 1807744309898989568000
   