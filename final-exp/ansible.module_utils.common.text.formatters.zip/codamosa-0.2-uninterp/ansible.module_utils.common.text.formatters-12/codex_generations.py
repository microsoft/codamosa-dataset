

# Generated at 2022-06-16 23:09:17.133736
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', 'B') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10MB', 'B') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10Mb', 'b', isbits=True) == 10485760
    assert human_to_bytes('10Mb', 'B', isbits=True) == 10485760
    assert human_to_bytes('10MB', 'b', isbits=True) == 10485760
    assert human_to_bytes('10MB', 'B', isbits=True) == 10485760


# Generated at 2022-06-16 23:09:19.382648
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]


# Generated at 2022-06-16 23:09:25.432956
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:09:29.262474
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864766192403456
    assert human_to_bytes('1.5Z') == 17684477171612

# Generated at 2022-06-16 23:09:39.819282
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976
    assert human_to_bytes('1Z') == 1180591620717411303424
    assert human_to_bytes('1Y') == 1208925819614629174706176
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864


# Generated at 2022-06-16 23:09:50.243154
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D', 'E']) == ['a', 'b', 'c', 1, 'd', 'e']

# Generated at 2022-06-16 23:10:02.194068
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.6') == 2
    assert human_to_bytes('1.6K') == 1638
    assert human_to_bytes('1.6M') == 16777216
    assert human_to_bytes('1.6G') == 17179869184
    assert human_to_bytes('1.6T') == 17592186044416
    assert human_to_bytes('1.6P') == 1797693134862316
    assert human_to_bytes('1.6E') == 18369739842712
    assert human_to_bytes('1.6Z') == 18754906944

# Generated at 2022-06-16 23:10:11.840936
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D']) == ['a', 'b', 'c', 1, 'd']

# Generated at 2022-06-16 23:10:24.146765
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864766192403456
    assert human_to_bytes('1.5Z') == 17681776154015748096
    assert human_to_bytes('1.5Y') == 1807734324017916993536

   

# Generated at 2022-06-16 23:10:31.343773
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 17678311774478950400
    assert human_to_bytes('1.5Y') == 1807381038597079040000

# Generated at 2022-06-16 23:10:46.178302
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['a', 'B', 1, 'c']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['a', 'B', 1, 'c', 'D']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['a', 'B', 1, 'c', 'D', 2]) == ['a', 'b', 1, 'c', 'd', 2]

# Generated at 2022-06-16 23:10:59.343547
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.6') == 2
    assert human_to_bytes('1.6K') == 1638
    assert human_to_bytes('1.6M') == 16777216
    assert human_to_bytes('1.6G') == 17179869184
    assert human_to_bytes('1.6T') == 17592186044416
    assert human_to_bytes('1.6P') == 1797693134862316
    assert human_to_bytes('1.6E') == 1836311903
    assert human_to_bytes('1.6Z') == 1875490612

# Generated at 2022-06-16 23:11:11.130575
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485680640
    assert human_to_bytes('1.5Z') == 17678326276686151680
    assert human_to_bytes('1.5Y') == 1807326545271764992000
   

# Generated at 2022-06-16 23:11:20.047370
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17286476636163072
    assert human_to_bytes('1.5Z') == 176844771767169024
    assert human_to_bytes('1.5Y') == 1808248762717163008

    assert human

# Generated at 2022-06-16 23:11:31.739020
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, unit='b') == '10.00 bits'
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'
    assert bytes_to_human(10, unit='b') == '10.00 bits'
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'
    assert bytes_to_human(10, unit='K') == '10.00 KB'
    assert bytes_to_human(10, unit='Kb') == '10.00 Kbits'
    assert bytes_to_human(10, unit='KB') == '10.00 KB'

# Generated at 2022-06-16 23:11:43.942842
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 17678311549995776000
    assert human_to_bytes('1.5Y') == 180738102399489638400

# Generated at 2022-06-16 23:11:56.547338
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(100) == '100 Bytes'
    assert bytes_to_human(1000) == '1000 Bytes'
    assert bytes_to_human(10000) == '9.77 KB'
    assert bytes_to_human(100000) == '97.66 KB'
    assert bytes_to_human(1000000) == '976.56 KB'
    assert bytes_to_human(10000000) == '9.54 MB'
    assert bytes_to_human(100000000) == '95.37 MB'
    assert bytes_to_human(1000000000) == '953.67 MB'

# Generated at 2022-06-16 23:12:06.124837
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', 'C', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D', 'E', 'F']) == ['a', 'b', 'c', 1, 'd', 'e', 'f']

# Generated at 2022-06-16 23:12:16.175554
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.1K') == 1.1 * 1024
    assert human_to_bytes('1.1M') == 1.1 * 1024 * 1024
    assert human_to_bytes('1.1G') == 1.1 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1T') == 1.1 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1P') == 1.1 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1E') == 1.1 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1Z') == 1.1 * 1024 * 1024

# Generated at 2022-06-16 23:12:29.299873
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1T') == 10995116

# Generated at 2022-06-16 23:12:44.810769
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, unit='b') == '1.00 bits'
    assert bytes_to_human(1, isbits=True) == '1.00 bits'
    assert bytes_to_human(1, isbits=True, unit='b') == '1.00 bits'
    assert bytes_to_human(1, isbits=True, unit='B') == '8.00 bits'
    assert bytes_to_human(1, unit='K') == '0.00 KB'
    assert bytes_to_human(1, unit='Kb') == '0.00 Kb'

# Generated at 2022-06-16 23:12:51.180014
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 2]) == ['a', 'b', 'c', 1, 'd', 2]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 2, 'e']) == ['a', 'b', 'c', 1, 'd', 2, 'e']

# Generated at 2022-06-16 23:13:01.001556
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', None, 'C']) == ['a', 'b', None, 'c']
    assert lenient_lowercase(['A', 'B', [], 'C']) == ['a', 'b', [], 'c']
    assert lenient_lowercase(['A', 'B', {}, 'C']) == ['a', 'b', {}, 'c']
    assert lenient_lowercase(['A', 'B', 'C', 'D']) == ['a', 'b', 'c', 'd']


# Unit

# Generated at 2022-06-16 23:13:06.699628
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1T') == 10995116

# Generated at 2022-06-16 23:13:14.315715
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'e']) == ['a', 'b', 'c', 1, 'd', 'e']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'e', 'f']) == ['a', 'b', 'c', 1, 'd', 'e', 'f']
    assert len

# Generated at 2022-06-16 23:13:24.475947
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864766192403456
    assert human_to_bytes('1.5Z') == 17681776302059612160
    assert human_to_bytes('1.5Y') == 180774400403119253504

   

# Generated at 2022-06-16 23:13:36.077727
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 1, 'c']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']

# Generated at 2022-06-16 23:13:47.717269
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 1767831176266444800
    assert human_to_bytes('1.5Y') == 1807381318496460800
    assert human

# Generated at 2022-06-16 23:13:52.375453
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 1, 'c']) == ['a', 1, 'c']
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'b', 1]


# Generated at 2022-06-16 23:14:05.229643
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:14:22.035180
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17283797749768064
    assert human_to_bytes('1.5Z') == 1768175795351938048
    assert human_to_bytes('1.5Y') == 180812676508226723840

# Generated at 2022-06-16 23:14:34.562231
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0k') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0m') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0g') == 1073741824


# Generated at 2022-06-16 23:14:44.282896
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test bytes
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0b', isbits=True) == 1
    assert human_to_bytes('1.0B', isbits=True) == 1
    assert human_to_bytes('1.0', isbits=True) == 1
    assert human_to_bytes('1.0', default_unit='B') == 1
    assert human_to_bytes('1.0', default_unit='b') == 1

# Generated at 2022-06-16 23:14:55.147147
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 1728647661939496960
    assert human_to_bytes('1.5Z') == 176817765047245824000
    assert human_to_bytes('1.5Y') == 180774924206848821248

# Generated at 2022-06-16 23:15:07.404961
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1Mb') == 1024 * 1024
    assert human_to_bytes('1G') == 1024 * 1024 * 1024
    assert human_to_bytes('1Gb') == 1024 * 1024 * 1024
    assert human_to_bytes('1T') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1Tb') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1P') == 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-16 23:15:17.042222
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17283797747244544
    assert human_to_bytes('1.5Z') == 1767831170353792000
    assert human_to_bytes('1.5Y') == 180732985358982758400
    assert human

# Generated at 2022-06-16 23:15:28.216472
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'B', 'c']
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'B', 1]
    assert lenient_lowercase(['a', 'B', 1, 'c']) == ['a', 'B', 1, 'c']
    assert lenient_lowercase(['a', 'B', 1, 'c', 'D']) == ['a', 'B', 1, 'c', 'D']
    assert lenient_lowercase(['a', 'B', 1, 'c', 'D', 2]) == ['a', 'B', 1, 'c', 'D', 2]

# Generated at 2022-06-16 23:15:37.402134
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', None]) == ['a', 'b', None]

# Generated at 2022-06-16 23:15:39.975723
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]


# Generated at 2022-06-16 23:15:53.256979
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.1K') == 1024
    assert human_to_bytes('1.1M') == 1024 * 1024
    assert human_to_bytes('1.1G') == 1024 * 1024 * 1024
    assert human_to_bytes('1.1T') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1P') == 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1E') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024


# Generated at 2022-06-16 23:16:11.028714
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', 'B') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10MB', 'B') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Mb', 'b') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10Mb', 'b', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=False) == 10485760

# Generated at 2022-06-16 23:16:20.511820
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 'B', 'C']) != ['A', 'B', 'C']
    assert lenient_lowercase(['A', 'B', 'C']) != ['a', 'b', 'C']
    assert lenient_lowercase(['A', 'B', 'C']) != ['a', 'B', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) != ['a', 'b', 'C']

# Generated at 2022-06-16 23:16:29.520717
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']

# Generated at 2022-06-16 23:16:42.356132
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:16:47.554423
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 'B', 'C']) != ['A', 'B', 'C']
    assert lenient_lowercase(['A', 1, 'C']) != ['A', 1, 'C']


# Generated at 2022-06-16 23:16:58.572435
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5K', isbits=True) == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5M', isbits=True) == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5G', isbits=True) == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5T', isbits=True) == 1649267441664
   

# Generated at 2022-06-16 23:17:11.104148
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976
    assert human_to_bytes('1.0Z') == 1180591620717411303424
    assert human_to_bytes('1.0Y') == 1208925819614629174706176

    assert human_

# Generated at 2022-06-16 23:17:20.162638
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D', 2]) == ['a', 'b', 1, 'c', 'd', 2]

# Generated at 2022-06-16 23:17:30.383363
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 17681757485957120000
    assert human_to_bytes('1.5Y') == 18081497447735296000000
    assert human

# Generated at 2022-06-16 23:17:42.259104
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17283797748568064
    assert human_to_bytes('1.5Z') == 176783116849582080
    assert human_to_bytes('1.5Y') == 1807381463244820480

    assert human

# Generated at 2022-06-16 23:18:11.236748
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Mb', unit='mb') == 10485760
    assert human_to_bytes('10Mb', unit='Mb') == 10485760
    assert human_to_bytes('10Mb', unit='Mb', isbits=True) == 10485760
    assert human_to_bytes('10Mb', unit='mb', isbits=True) == 10485760
    assert human_to_bytes('10Mb', unit='MB') == 1048

# Generated at 2022-06-16 23:18:22.628362
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.6') == 2
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485680640
    assert human_to_bytes('1.5Z') == 17678326306058

# Generated at 2022-06-16 23:18:32.781140
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D']) == ['a', 'b', 1, 'c', 'd']

# Generated at 2022-06-16 23:18:44.346438
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 'D']) == ['a', 'B', 'c', 'D']
    assert lenient_lowercase(['a', 'B', 'c', 'D', 1]) == ['a', 'B', 'c', 'D', 1]
    assert lenient_lowercase(['a', 'B', 'c', 'D', 1, 'e']) == ['a', 'B', 'c', 'D', 1, 'e']
    assert lenient_lowercase(['a', 'B', 'c', 'D', 1, 'e', 'F']) == ['a', 'B', 'c', 'D', 1, 'e', 'F']
    assert lenient_lowercase(['a', 'B', 'c', 'D', 1, 'e', 'F', 2])

# Generated at 2022-06-16 23:18:53.815636
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 1, 'c']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase([]) == []


# Generated at 2022-06-16 23:19:05.041150
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D', 'E']) == ['a', 'b', 1, 'c', 'd', 'e']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D', 'E', 'F']) == ['a', 'b', 1, 'c', 'd', 'e', 'f']

# Generated at 2022-06-16 23:19:17.293623
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'E']) == ['a', 'b', 'c', 1, 'd', 'e']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'E', 'f', 2]) == ['a', 'b', 'c', 1, 'd', 'e', 'f', 2]