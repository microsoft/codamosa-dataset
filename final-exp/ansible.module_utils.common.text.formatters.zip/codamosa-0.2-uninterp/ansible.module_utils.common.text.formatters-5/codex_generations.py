

# Generated at 2022-06-16 23:09:24.010542
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10MB', isbits=True) == 10485760
    assert human_to_bytes('10Mb', default_unit='B') == 10485760
    assert human_to_bytes('10Mb', default_unit='B', isbits=True) == 10485760
    assert human_to_bytes('10Mb', default_unit='b') == 10485760
    assert human

# Generated at 2022-06-16 23:09:35.459860
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test for bytes
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.1B') == 1
    assert human_to_bytes('1.1b') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.9B') == 1
    assert human_to_bytes('1.9b') == 1

# Generated at 2022-06-16 23:09:46.433430
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864766192403456
    assert human_to_bytes('1.5Z') == 17681776806860963840
    assert human_to_bytes('1.5Y') == 18077343240327014445056


# Generated at 2022-06-16 23:09:58.219854
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485680640
    assert human_to_bytes('1.5Z') == 17678326284733593600
    assert human_to_bytes('1.5Y') == 180732654536128512000

   

# Generated at 2022-06-16 23:10:09.253496
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:10:11.680365
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]


# Generated at 2022-06-16 23:10:19.531061
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D', 2]) == ['a', 'b', 'c', 1, 'd', 2]
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D', 2, 'E']) == ['a', 'b', 'c', 1, 'd', 2, 'e']

# Generated at 2022-06-16 23:10:29.277936
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'E']) == ['a', 'b', 'c', 1, 'd', 'e']

# Generated at 2022-06-16 23:10:41.055554
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='b') == '1.00 bits'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, unit='b') == '1.00 bits'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, unit='B', isbits=True) == '8.00 bits'
    assert bytes_to_human(1, unit='b', isbits=True) == '1.00 bits'
    assert bytes_to_human(1, unit='B', isbits=False) == '1.00 Bytes'

# Generated at 2022-06-16 23:10:43.905497
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]


# Generated at 2022-06-16 23:11:00.292303
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864628504423424
    assert human_to_bytes('1.5Z') == 1768449560954716160
    assert human_to_bytes('1.5Y') == 18083528979452980224
    assert human

# Generated at 2022-06-16 23:11:11.288882
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1Mb') == 1024 * 1024
    assert human_to_bytes('1G') == 1024 * 1024 * 1024
    assert human_to_bytes('1Gb') == 1024 * 1024 * 1024
    assert human_to_bytes('1T') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1Tb') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1P') == 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-16 23:11:16.530655
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) != ['a', 'b', '1', 'c']


# Generated at 2022-06-16 23:11:20.663292
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.6') == 2
    assert human_to_bytes('1.6K') == 1638
    assert human_to_bytes('1.6M') == 16777216
    assert human_to_bytes('1.6G') == 17179869184
    assert human_to_bytes('1.6T') == 17592186044416
    assert human_to_bytes('1.6P') == 1797693134862316
    assert human_to_bytes('1.6E') == 1836311903
    assert human_to_bytes('1.6Z') == 1875490612

# Generated at 2022-06-16 23:11:32.184732
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.6') == 2
    assert human_to_bytes('1.6K') == 1638
    assert human_to_bytes('1.6M') == 1677721
    assert human_to_bytes('1.6G') == 1717986918
    assert human_to_bytes('1.6T') == 17592186044416
    assert human_to_bytes('1.6P') == 1797693134862316
    assert human_to_bytes('1.6E') == 1836311903
    assert human_to_bytes('1.6Z') == 1875490617
    assert human

# Generated at 2022-06-16 23:11:44.668397
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]
    assert lenient_lowercase(['A', 'b', 'C', 1, 2, 3, 'd']) == ['a', 'b', 'c', 1, 2, 3, 'd']
    assert lenient_lowercase(['A', 'b', 'C', 1, 2, 3, 'd', 'E']) == ['a', 'b', 'c', 1, 2, 3, 'd', 'e']
   

# Generated at 2022-06-16 23:11:56.644489
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 1, 'c']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c']

# Generated at 2022-06-16 23:12:04.294045
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'E']) == ['a', 'b', 'c', 1, 'd', 'e']

# Generated at 2022-06-16 23:12:15.662858
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 'B', 'C', 'D']) == ['a', 'b', 'c', 'd']
    assert lenient_lowercase(['A', 'B', 'C', 'D', 'E']) == ['a', 'b', 'c', 'd', 'e']
    assert lenient_lowercase(['A', 'B', 'C', 'D', 'E', 'F']) == ['a', 'b', 'c', 'd', 'e', 'f']

# Generated at 2022-06-16 23:12:29.216624
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D', 'E']) == ['a', 'b', 'c', 1, 'd', 'e']

# Generated at 2022-06-16 23:12:42.848109
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D', 'E', 2]) == ['a', 'b', 'c', 1, 'd', 'e', 2]

# Generated at 2022-06-16 23:12:55.837660
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1Mb') == 1024 * 1024
    assert human_to_bytes('1G') == 1024 * 1024 * 1024
    assert human_to_bytes('1Gb') == 1024 * 1024 * 1024
    assert human_to_bytes('1T') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1Tb') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1P') == 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-16 23:13:07.066496
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5KB') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5MB') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5GB') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5TB') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936

# Generated at 2022-06-16 23:13:12.132375
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 'B', 'C']) != ['A', 'B', 'C']
    assert lenient_lowercase(['A', 1, 'C']) != ['A', 1, 'C']


# Generated at 2022-06-16 23:13:23.083935
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']

# Generated at 2022-06-16 23:13:35.427105
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.6') == 2
    assert human_to_bytes('1.6K') == 1638
    assert human_to_bytes('1.6M') == 1677721
    assert human_to_bytes('1.6G') == 1717986918
    assert human_to_bytes('1.6T') == 17592186044416
    assert human_to_bytes('1.6P') == 17976931348623159
    assert human_to_bytes('1.6E') == 1836311903
    assert human_to_bytes('1.6Z') == 1875490617
    assert human

# Generated at 2022-06-16 23:13:46.603593
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976
    assert human_to_bytes('1Z') == 1180591620717411303424
    assert human_to_bytes('1Y') == 1208925819614629174706176
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864


# Generated at 2022-06-16 23:13:58.450693
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D']) == ['a', 'b', 'c', 1, 'd']

# Generated at 2022-06-16 23:14:10.467324
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976
    assert human_to_bytes('1.0Z') == 1180591620717411303424
    assert human_to_bytes('1.0Y') == 1208925819614629174706176
    assert human_

# Generated at 2022-06-16 23:14:23.175307
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', {'a': 1}, 'C']) == ['a', 'b', {'a': 1}, 'c']
    assert lenient_lowercase(['A', 'B', [1, 2, 3], 'C']) == ['a', 'b', [1, 2, 3], 'c']
    assert lenient_lowercase(['A', 'B', ('a', 'b', 'c'), 'C']) == ['a', 'b', ('a', 'b', 'c'), 'c']
    assert lenient_lower

# Generated at 2022-06-16 23:14:39.016201
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'C', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['A', 'b', 'C', 1, '1']) == ['a', 'b', 'c', 1, '1']
    assert lenient_lowercase(['A', 'b', 'C', 1, '1', 'a']) == ['a', 'b', 'c', 1, '1', 'a']

# Generated at 2022-06-16 23:14:46.944915
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D', 2]) == ['a', 'b', 1, 'c', 'd', 2]

# Generated at 2022-06-16 23:14:56.988260
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 'B', 'C']) != ['A', 'B', 'C']
    assert lenient_lowercase(['A', 'B', 'C']) != ['a', 'b', 'C']
    assert lenient_lowercase(['A', 'B', 'C']) != ['a', 'B', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) != ['A', 'b', 'c']

# Generated at 2022-06-16 23:15:09.329331
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test bytes
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0b', isbits=True) == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0', default_unit='B') == 1
    assert human_to_bytes('1.0', default_unit='b') == 1

# Generated at 2022-06-16 23:15:12.302291
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 'D', 1, 2, 3]) == ['a', 'b', 'c', 'd', 1, 2, 3]


# Generated at 2022-06-16 23:15:24.764682
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]
    assert lenient_lowercase(['a', 'B', 'C', 1, 2, 3, 'D']) == ['a', 'b', 'c', 1, 2, 3, 'D']
    assert lenient_lowercase(['a', 'B', 'C', 1, 2, 3, 'D', 'E']) == ['a', 'b', 'c', 1, 2, 3, 'D', 'E']
    assert lenient_lowercase(['a', 'B', 'C', 1, 2, 3, 'D', 'E', 'F']) == ['a', 'b', 'c', 1, 2, 3, 'D', 'E', 'F']


# Generated at 2022-06-16 23:15:33.634456
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['a', 'B', 1, 'c']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['a', 'B', 1, 'c', 'd']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['a', 'B', 1, 'c', 'd', 'e']) == ['a', 'b', 1, 'c', 'd', 'e']

# Generated at 2022-06-16 23:15:40.668779
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0Kb') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0Mb') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0Gb') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776

# Generated at 2022-06-16 23:15:54.070972
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase([1, 'B', 'C']) == [1, 'b', 'c']
    assert lenient_lowercase([1, 'B', 'C', 'D']) == [1, 'b', 'c', 'd']
    assert lenient_lowercase([1, 'B', 'C', 'D', 'E']) == [1, 'b', 'c', 'd', 'e']

# Generated at 2022-06-16 23:15:57.136418
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 1, 'c']) == ['a', 'b', 1, 'c']


# Generated at 2022-06-16 23:16:06.977970
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]


# Generated at 2022-06-16 23:16:17.987774
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'E']) == ['a', 'b', 'c', 1, 'd', 'e']

# Generated at 2022-06-16 23:16:27.943826
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 1728647661924485120
    assert human_to_bytes('1.5Z') == 176838953978066782208
    assert human_to_bytes('1.5Y') == 1808226407445485548544
   

# Generated at 2022-06-16 23:16:40.944420
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17286476629764096
    assert human_to_bytes('1.5Z') == 176844773765844992
    assert human_to_bytes('1.5Y') == 18082487313587712
    assert human_to

# Generated at 2022-06-16 23:16:49.357285
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5k') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5m') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5g') == 1610612736
    assert human_to_bytes('1.5T') == 164926744

# Generated at 2022-06-16 23:16:59.691507
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0B', isbits=True) == 1
    assert human_to_bytes('1.0b', isbits=True) == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0K', isbits=True) == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0M', isbits=True) == 1048576
    assert human_to_bytes('1.0G') == 1073741824


# Generated at 2022-06-16 23:17:10.423402
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', None]) == ['a', 'b', None]
    assert lenient_lowercase(['A', 'B', {'a': 'b'}]) == ['a', 'b', {'a': 'b'}]
    assert lenient_lowercase(['A', 'B', ['a', 'b']]) == ['a', 'b', ['a', 'b']]



# Generated at 2022-06-16 23:17:19.701019
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', None]) == ['a', 'b', None]
    assert lenient_lowercase(['A', 'B', 'C', 'D']) == ['a', 'b', 'c', 'd']
    assert lenient_lowercase(['A', 'B', 'C', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['A', 'B', 'C', None]) == ['a', 'b', 'c', None]

# Generated at 2022-06-16 23:17:30.149830
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['a', 'B', 1, 'c']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['a', 'B', 1, 'c', 'd']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['a', 'B', 1, 'c', 'd', 2]) == ['a', 'b', 1, 'c', 'd', 2]

# Generated at 2022-06-16 23:17:42.125222
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', None]) == ['a', 'b', None]
    assert lenient_lowercase(['A', 'B', 'C', 'D']) == ['a', 'b', 'c', 'd']
    assert lenient_lowercase(['A', 'B', 'C', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['A', 'B', 'C', None]) == ['a', 'b', 'c', None]

# Generated at 2022-06-16 23:17:59.146376
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'b', 'C']) == ['a', 'b', 'C']
    assert lenient_lowercase(['a', 'b', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['a', 'b', 1, 'c']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['a', 'b', 1, 'C']) == ['a', 'b', 1, 'C']
    assert lenient_lowercase(['a', 'b', 1, 'C', 'd']) == ['a', 'b', 1, 'C', 'd']

# Generated at 2022-06-16 23:18:08.698676
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'e']) == ['a', 'b', 'c', 1, 'd', 'e']

# Generated at 2022-06-16 23:18:20.358500
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.6') == 2
    assert human_to_bytes('1.6K') == 1638
    assert human_to_bytes('1.6M') == 1677721
    assert human_to_bytes('1.6G') == 1717986918
    assert human_to_bytes('1.6T') == 17592186044416
    assert human_to_bytes('1.6P') == 17976931348623159
    assert human_to_bytes('1.6E') == 1836311903
    assert human_to_bytes('1.6Z') == 1875490617
    assert human

# Generated at 2022-06-16 23:18:31.020425
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:18:33.861182
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]


# Generated at 2022-06-16 23:18:45.426703
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17286476637767680
    assert human_to_bytes('1.5Z') == 176838963071661056
    assert human_to_bytes('1.5Y') == 1808226708655646720
    assert human_to

# Generated at 2022-06-16 23:18:50.997640
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17283797747244544
    assert human_to_bytes('1.5Z') == 176783267949207552
    assert human_to_bytes('1.5Y') == 1807285584269758464

    assert human

# Generated at 2022-06-16 23:19:01.366035
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:19:13.699133
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['a', 'B', 1, 'c']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['a', 'B', 1, 'c', 'd']) == ['a', 'b', 1, 'c', 'd']