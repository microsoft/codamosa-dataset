

# Generated at 2022-06-16 23:09:22.456915
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.6') == 2
    assert human_to_bytes('1.6K') == 1638
    assert human_to_bytes('1.6M') == 16777216
    assert human_to_bytes('1.6G') == 17179869184
    assert human_to_bytes('1.6T') == 17592186044416
    assert human_to_bytes('1.6P') == 1797693134862316
    assert human_to_bytes('1.6E') == 1836311903
    assert human_to_bytes('1.6Z') == 18754906
    assert human

# Generated at 2022-06-16 23:09:33.606931
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test for bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0k') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0m') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0g') == 1073741824

# Generated at 2022-06-16 23:09:42.816232
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.5') == 2
    assert human_to_bytes('1.9') == 2
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976

# Generated at 2022-06-16 23:09:53.430614
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 1767831137235660800
    assert human_to_bytes('1.5Y') == 18073810990586521600

# Generated at 2022-06-16 23:10:05.648986
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:10:09.194308
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:10:17.834057
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 17678326676627783680
    assert human_to_bytes('1.5Y') == 180730990976658796544


# Generated at 2022-06-16 23:10:28.851269
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0B', default_unit='B') == 1
    assert human_to_bytes('1.0b', default_unit='B') == 1
    assert human_to_bytes('1.0B', default_unit='b') == 1
    assert human_to_bytes('1.0b', default_unit='b') == 1
    assert human_to_bytes('1.0', default_unit='B')

# Generated at 2022-06-16 23:10:40.958606
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D', 'E']) == ['a', 'b', 1, 'c', 'd', 'e']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D', 'E', 'F']) == ['a', 'b', 1, 'c', 'd', 'e', 'f']

# Generated at 2022-06-16 23:10:47.788152
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1g') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1t') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624

# Generated at 2022-06-16 23:11:01.844206
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.9K') == 1920
    assert human_to_bytes('1.9M') == 19922944
    assert human_to_bytes('1.9G') == 2080374784
    assert human_to_bytes('1.9T') == 2199023255552
    assert human_to_bytes('1.9P') == 228170137728256
    assert human_to_bytes('1.9E') == 23606943545600000

# Generated at 2022-06-16 23:11:12.000614
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1P') == 112589990

# Generated at 2022-06-16 23:11:17.232097
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0B', default_unit='B') == 1
    assert human_to_bytes('1.0b', default_unit='B') == 1
    assert human_to_bytes('1.0B', default_unit='b') == 1
    assert human_to_bytes('1.0b', default_unit='b') == 1
    assert human_to_bytes('1.0', default_unit='B')

# Generated at 2022-06-16 23:11:28.522916
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'B', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'B', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D']) == ['a', 'B', 'c', 1, 'D']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D', 2]) == ['a', 'B', 'c', 1, 'D', 2]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D', 2, 'e']) == ['a', 'B', 'c', 1, 'D', 2, 'e']

# Generated at 2022-06-16 23:11:37.193875
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0Kb') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0Mb') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0Gb') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776

# Generated at 2022-06-16 23:11:47.819528
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 17681757485957120000
    assert human_to_bytes('1.5Y') == 18081322382650368000000
    assert human

# Generated at 2022-06-16 23:11:58.939410
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D', 2]) == ['a', 'b', 1, 'c', 'd', 2]

# Generated at 2022-06-16 23:12:10.353862
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.6') == 2
    assert human_to_bytes('1.6K') == 1638
    assert human_to_bytes('1.6M') == 16777216
    assert human_to_bytes('1.6G') == 17179869184
    assert human_to_bytes('1.6T') == 17592186044416
    assert human_to_bytes('1.6P') == 1797693134862316
    assert human_to_bytes('1.6E') == 1836311903
    assert human_to_bytes('1.6Z') == 1875490612

# Generated at 2022-06-16 23:12:15.538874
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D']) == ['a', 'b', 1, 'c', 'd']


# Generated at 2022-06-16 23:12:29.215342
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test for bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0b', isbits=True) == 1
    assert human_to_bytes('1.0', default_unit='B') == 1
    assert human_to_bytes('1.0', default_unit='b') == 1
    assert human_to_bytes('1.0', default_unit='b', isbits=True) == 1

# Generated at 2022-06-16 23:12:42.214053
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 10995116

# Generated at 2022-06-16 23:12:55.519398
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 1728647668863997952
    assert human_to_bytes('1.5Z') == 176817761866162123776
    assert human_to_bytes('1.5Y') == 180774480951416334868

# Generated at 2022-06-16 23:13:06.659118
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'B', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'B', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D']) == ['a', 'B', 'c', 1, 'D']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D', 2]) == ['a', 'B', 'c', 1, 'D', 2]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D', 2, 'e']) == ['a', 'B', 'c', 1, 'D', 2, 'e']

# Generated at 2022-06-16 23:13:08.974164
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]


# Generated at 2022-06-16 23:13:15.808645
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.1K') == 1.1 * 1024
    assert human_to_bytes('1.1M') == 1.1 * 1024 * 1024
    assert human_to_bytes('1.1G') == 1.1 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1T') == 1.1 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1P') == 1.1 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1E') == 1.1 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1Z') == 1.1 * 1024 * 1024

# Generated at 2022-06-16 23:13:25.384741
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.00') == 1
    assert human_to_bytes('1.01') == 1
    assert human_to_bytes('1.1K') == 1.1 * 1024
    assert human_to_bytes('1.1M') == 1.1 * 1024 * 1024
    assert human_to_bytes('1.1G') == 1.1 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1T') == 1.1 * 1024 * 1024 * 1024 * 1024
    assert human_

# Generated at 2022-06-16 23:13:36.410076
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.1K') == 1024
    assert human_to_bytes('1.1M') == 1048576
    assert human_to_bytes('1.1G') == 1073741824
    assert human_to_bytes('1.1T') == 1099511627776
    assert human_to_bytes('1.1P') == 1125899906842624
    assert human_to_bytes('1.1E') == 1152921504606846976
    assert human_to_bytes('1.1Z') == 1180591620717411303424
    assert human_to_bytes('1.1Y') == 1208925819614629174706176

    assert human_

# Generated at 2022-06-16 23:13:48.085582
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17283797747244544
    assert human_to_bytes('1.5Z') == 1768175748595769344
    assert human_to_bytes('1.5Y') == 1808124312491745447936
   

# Generated at 2022-06-16 23:13:59.547592
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', {'C': 'D'}, 'E']) == ['a', 'b', {'C': 'D'}, 'e']
    assert lenient_lowercase(['A', 'B', ['C', 'D'], 'E']) == ['a', 'b', ['C', 'D'], 'e']
    assert lenient_lowercase(['A', 'B', ('C', 'D'), 'E']) == ['a', 'b', ('C', 'D'), 'e']

# Generated at 2022-06-16 23:14:08.603100
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D']) == ['a', 'b', 1, 'c', 'd']



# Generated at 2022-06-16 23:14:17.808364
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]
    assert lenient_lowercase(['A', 'B', 'C', '1', '2', '3']) == ['a', 'b', 'c', '1', '2', '3']

# Generated at 2022-06-16 23:14:28.886824
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:14:41.109485
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5k') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5m') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5g') == 1610612736
    assert human_to_bytes('1.5T') == 164926744

# Generated at 2022-06-16 23:14:52.681764
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.9K') == 1920
    assert human_to_bytes('1.9Kb') == 1920
    assert human_to_bytes('1.9Kb', isbits=True) == 1920
    assert human_to_bytes('1.9K', isbits=True) == 1920
    assert human_to_bytes('1.9Mb', isbits=True) == 1920
    assert human_to_bytes('1.9M', isbits=True) == 1920
    assert human_to_bytes('1.9Mb') == 1920
    assert human_to

# Generated at 2022-06-16 23:14:55.061650
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]


# Generated at 2022-06-16 23:15:01.942171
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17283797748568064
    assert human_to_bytes('1.5Z') == 176783115435404800
    assert human_to_bytes('1.5Y') == 1807326545272647680
    assert human

# Generated at 2022-06-16 23:15:12.641505
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5k') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5m') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5g') == 1610612736
    assert human_to_bytes('1.5T') == 164926744

# Generated at 2022-06-16 23:15:25.110426
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976
    assert human_to_bytes('1.0Z') == 1180591620717411303424
    assert human_to_bytes('1.0Y') == 1208925819614629174706176
    assert human_

# Generated at 2022-06-16 23:15:35.490070
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976
    assert human_to_bytes('1Z') == 1180591620717411303424
    assert human_to_bytes('1Y') == 1208925819614629174706176
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864


# Generated at 2022-06-16 23:15:48.738947
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.5') == 2
    assert human_to_bytes('1.9') == 2
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976

# Generated at 2022-06-16 23:16:00.900410
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['a', 'B', 1.0]) == ['a', 'b', 1.0]
    assert lenient_lowercase(['a', 'B', None]) == ['a', 'b', None]


# Generated at 2022-06-16 23:16:07.547700
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864766192403456
    assert human_to_bytes('1.5Z') == 17681776247967735808
    assert human_to_bytes('1.5Y') == 180774924473418954752

   

# Generated at 2022-06-16 23:16:18.372332
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.5') == 2
    assert human_to_bytes('1.9') == 2
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976

# Generated at 2022-06-16 23:16:28.315856
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.01') == 1
    assert human_to_bytes('1.99') == 1
    assert human_to_bytes('1.1K') == 1.1 * 1024
    assert human_to_bytes('1.1M') == 1.1 * 1024 * 1024
    assert human_to_bytes('1.1G') == 1.1 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1T') == 1.1 * 1024 * 1024 * 1024 * 1024
    assert human_

# Generated at 2022-06-16 23:16:41.306799
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'B', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'B', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd']) == ['a', 'B', 'c', 1, 'd']

# Generated at 2022-06-16 23:16:49.603505
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]
    assert lenient_lowercase(['A', 'B', 'C', 1, 2, 3, 'D', 'E', 'F']) == ['a', 'b', 'c', 1, 2, 3, 'd', 'e', 'f']

# Generated at 2022-06-16 23:16:59.906175
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K', isbits=True) == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1M', isbits=True) == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1G', isbits=True) == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1T', isbits=True) == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1P', isbits=True) == 1125899906842624
    assert human_

# Generated at 2022-06-16 23:17:12.345982
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 1767831175364514816
    assert human_to_bytes('1.5Y') == 18073813183619483648

# Generated at 2022-06-16 23:17:24.710818
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'B', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'B', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D']) == ['a', 'B', 'c', 1, 'D']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D', 2]) == ['a', 'B', 'c', 1, 'D', 2]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D', 2, 'e']) == ['a', 'B', 'c', 1, 'D', 2, 'e']

# Generated at 2022-06-16 23:17:33.072887
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D', 2]) == ['a', 'b', 'c', 1, 'd', 2]
    assert lenient_lowercase(['A', 'B', 'C', 1, 'D', 2, 'E']) == ['a', 'b', 'c', 1, 'd', 2, 'e']

# Generated at 2022-06-16 23:17:54.249608
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test bytes
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', default_unit='B') == 10485760
    assert human_to_bytes('10M', default_unit='B') == human_to_bytes(10, 'M')
    assert human_to_bytes('10M', default_unit='B') == human_to_bytes(10, 'M', isbits=False)
    assert human_to_bytes('10M', default_unit='B') == human_to_bytes(10, 'M', isbits=True)
    assert human_to_bytes('10M', default_unit='B') == human_to_bytes(10, default_unit='M')
    assert human_to_bytes('10M', default_unit='B') == human_to

# Generated at 2022-06-16 23:18:04.838096
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test cases for bytes
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0k') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0m') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0g') == 10737418

# Generated at 2022-06-16 23:18:16.564230
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:18:28.291631
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976
    assert human_to_bytes('1.0Z') == 1180591620717411303424
    assert human_to_bytes('1.0Y') == 1208925819614629174706176
    assert human_

# Generated at 2022-06-16 23:18:36.057976
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172838496659303936
    assert human_to_bytes('1.5Z') == 1767832956833283968
    assert human_to_bytes('1.5Y') == 18072809571765339648

# Generated at 2022-06-16 23:18:48.790735
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']

# Generated at 2022-06-16 23:18:58.575464
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 1, 'c']) == ['a', 1, 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'e']) == ['a', 'b', 'c', 1, 'd', 'e']

# Generated at 2022-06-16 23:19:11.269419
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to