

# Generated at 2022-06-16 23:09:25.082334
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976
    assert human_to_bytes('1.0Z') == 1180591620717411303424
    assert human_to_bytes('1.0Y') == 1208925819614629174706176
    assert human_

# Generated at 2022-06-16 23:09:36.451103
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.5') == 2
    assert human_to_bytes('1.9') == 2
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976

# Generated at 2022-06-16 23:09:44.760893
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976
    assert human_to_bytes('1Z') == 1180591620717411303424
    assert human_to_bytes('1Y') == 1208925819614629174706176
    assert human_to_bytes

# Generated at 2022-06-16 23:09:48.227099
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]

# Generated at 2022-06-16 23:09:59.353424
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 1767831154359577600
    assert human_to_bytes('1.5Y') == 180738102333609984000

# Generated at 2022-06-16 23:10:02.596889
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]

# Generated at 2022-06-16 23:10:12.053409
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test for bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624

# Generated at 2022-06-16 23:10:24.432470
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.1K') == 1.1 * 1024
    assert human_to_bytes('1.1M') == 1.1 * 1024 * 1024
    assert human_to_bytes('1.1G') == 1.1 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1T') == 1.1 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1P') == 1.1 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1E') == 1.1 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1Z') == 1.1 * 1024 * 1024

# Generated at 2022-06-16 23:10:33.601411
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 17678301279967232000
    assert human_to_bytes('1.5Y') == 1807329304912140800000
    assert human

# Generated at 2022-06-16 23:10:45.973799
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 'D', 'e', 'F', 'g', 'H', 'i', 'J', 'k', 'L', 'm', 'N', 'o', 'P', 'q', 'R', 's', 'T', 'u', 'V', 'w', 'X', 'y', 'Z']) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

# Generated at 2022-06-16 23:11:01.003690
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17286476629764096
    assert human_to_bytes('1.5Z') == 176817769966158848
    assert human_to_bytes('1.5Y') == 1807734323989839872
    assert human

# Generated at 2022-06-16 23:11:11.320409
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17283797748568064
    assert human_to_bytes('1.5Z') == 1767832518977028096
    assert human_to_bytes('1.5Y') == 180738104896993280000

    assert human

# Generated at 2022-06-16 23:11:20.296105
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(100) == '100 Bytes'
    assert bytes_to_human(1000) == '1000 Bytes'
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024 * 1024) == '1.00 MB'
    assert bytes_to_human(1024 * 1024 * 1024) == '1.00 GB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    assert bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'
    assert bytes_

# Generated at 2022-06-16 23:11:32.010398
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(100) == '100 Bytes'
    assert bytes_to_human(1000) == '1000 Bytes'
    assert bytes_to_human(10000) == '9.77 KB'
    assert bytes_to_human(100000) == '97.66 KB'
    assert bytes_to_human(1000000) == '976.56 KB'
    assert bytes_to_human(10000000) == '9.54 MB'
    assert bytes_to_human(100000000) == '95.37 MB'
    assert bytes_to_human(1000000000) == '953.67 MB'

# Generated at 2022-06-16 23:11:44.399365
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.1K') == 1.1 * 1024
    assert human_to_bytes('1.1M') == 1.1 * 1024 * 1024
    assert human_to_bytes('1.1G') == 1.1 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1T') == 1.1 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1P') == 1.1 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_

# Generated at 2022-06-16 23:11:56.598882
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.01') == 1
    assert human_to_bytes('1.001') == 1
    assert human_to_bytes('1.0001') == 1
    assert human_to_bytes('1.00001') == 1
    assert human_to_bytes('1.000001') == 1
    assert human_to_bytes('1.0000001') == 1
    assert human_to_bytes('1.00000001') == 1
    assert human_to_bytes('1.000000001') == 1
   

# Generated at 2022-06-16 23:12:04.241952
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='b') == '1.00 bits'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, unit='B', isbits=True) == '1.00 bits'
    assert bytes_to_human(1, unit='b', isbits=True) == '1.00 bits'
    assert bytes_to_human(1, unit='K') == '1.00 KB'
    assert bytes_to_human(1, unit='K', isbits=True) == '1.00 Kb'
    assert bytes_to_human(1, unit='M') == '1.00 MB'

# Generated at 2022-06-16 23:12:15.620693
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17283797749762048
    assert human_to_bytes('1.5Z') == 176783116418854912
    assert human_to_bytes('1.5Y') == 1807381464338822144
    assert human

# Generated at 2022-06-16 23:12:29.216606
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:12:40.616381
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864766192408576
    assert human_to_bytes('1.5Z') == 17681776226059053056
    assert human_to_bytes('1.5Y') == 1807734317688758677504


# Generated at 2022-06-16 23:12:56.243345
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'B', 'c']
    assert lenient_lowercase(['a', 'B', 1]) == ['a', 'B', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'B', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D']) == ['a', 'B', 'c', 1, 'D']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D', 'E']) == ['a', 'B', 'c', 1, 'D', 'E']

# Generated at 2022-06-16 23:13:07.597312
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 17678311702884106240
    assert human_to_bytes('1.5Y') == 1807381444278970363904
   

# Generated at 2022-06-16 23:13:14.905724
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.1K') == 1.1 * 1024
    assert human_to_bytes('1.1M') == 1.1 * 1024 * 1024
    assert human_to_bytes('1.1G') == 1.1 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1T') == 1.1 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1P') == 1.1 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1E') == 1.1 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.1Z') == 1.1 * 1024 * 1024

# Generated at 2022-06-16 23:13:24.740322
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', isbits=True) == 10485760
    assert human_to_bytes('10M', isbits=False) == 10485760
    assert human_to_bytes('10M', isbits=False, default_unit='B') == 10485760
    assert human_to_bytes('10M', isbits=False, default_unit='M') == 10
    assert human_to_bytes('10M', isbits=True, default_unit='M') == 10
    assert human_to_bytes('10M', isbits=True, default_unit='B') == 10485760
    assert human_to_bytes('10M', isbits=True, default_unit='Mb') == 10
    assert human_to_

# Generated at 2022-06-16 23:13:36.119146
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:13:47.774378
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D']) == ['a', 'b', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'D', 'e']) == ['a', 'b', 'c', 1, 'd', 'e']

# Generated at 2022-06-16 23:13:59.230436
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.01') == 1
    assert human_to_bytes('1.001') == 1
    assert human_to_bytes('1.0001') == 1
    assert human_to_bytes('1.00001') == 1
    assert human_to_bytes('1.000001') == 1
    assert human_to_bytes('1.0000001') == 1
    assert human_to_bytes('1.00000001') == 1
    assert human_to_bytes('1.000000001') == 1
   

# Generated at 2022-06-16 23:14:11.245279
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.1K') == 1024
    assert human_to_bytes('1.1M') == 1048576
    assert human_to_bytes('1.1G') == 1073741824
    assert human_to_bytes('1.1T') == 1099511627776
    assert human_to_bytes('1.1P') == 1125899906842624
    assert human_to_bytes('1.1E') == 1152921504606846976

# Generated at 2022-06-16 23:14:23.775245
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', [1, 2, 3], 'C']) == ['a', 'b', [1, 2, 3], 'c']
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['A']) == ['a']

# Generated at 2022-06-16 23:14:36.523417
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 1767831154354539520
    assert human_to_bytes('1.5Y') == 180738103335451136000

# Generated at 2022-06-16 23:14:51.731778
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977485619200
    assert human_to_bytes('1.5Z') == 1767831154354539520
    assert human_to_bytes('1.5Y') == 18073810339527806464

# Generated at 2022-06-16 23:14:59.809570
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'B', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'B', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd']) == ['a', 'B', 'c', 1, 'd']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'e', 'F']) == ['a', 'B', 'c', 1, 'd', 'e', 'F']

# Generated at 2022-06-16 23:15:11.591882
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172869730668216320
    assert human_to_bytes('1.5Z') == 176838963071524608000
    assert human_to_bytes('1.5Y') == 18081719557327360000000000

# Generated at 2022-06-16 23:15:24.528572
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864766192408576
    assert human_to_bytes('1.5Z') == 17681776154265625600
    assert human_to_bytes('1.5Y') == 1807744005898298880000

# Generated at 2022-06-16 23:15:34.540264
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 1728647663776768000
    assert human_to_bytes('1.5Z') == 176817763074114560000

# Generated at 2022-06-16 23:15:47.639489
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976
    assert human_to_bytes('1.0Z') == 1180591620717411303424
    assert human_to_bytes('1.0Y') == 1208925819614629174706176
    assert human_

# Generated at 2022-06-16 23:16:00.006630
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:16:07.180108
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864766192403456
    assert human_to_bytes('1.5Z') == 1768177680942417920
    assert human_to_bytes('1.5Y') == 18077448089651568640

# Generated at 2022-06-16 23:16:18.107230
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:16:28.095223
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C']) == ['a', 'b', 1, 'c']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D']) == ['a', 'b', 1, 'c', 'd']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D', 'E']) == ['a', 'b', 1, 'c', 'd', 'e']
    assert lenient_lowercase(['A', 'B', 1, 'C', 'D', 'E', 'F']) == ['a', 'b', 1, 'c', 'd', 'e', 'f']

# Generated at 2022-06-16 23:16:44.023949
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976
    assert human_to_bytes('1.0Z') == 1180591620717411303424
    assert human_to_bytes('1.0Y') == 1208925819614629174706176
    assert human_

# Generated at 2022-06-16 23:16:51.124941
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', None]) == ['a', 'b', None]
    assert lenient_lowercase(['A', 'B', 'C', 'D']) == ['a', 'b', 'c', 'd']
    assert lenient_lowercase(['A', 'B', 'C', 'D', 1]) == ['a', 'b', 'c', 'd', 1]
    assert lenient_lowercase(['A', 'B', 'C', 'D', None]) == ['a', 'b', 'c', 'd', None]
    assert lenient_lowercase

# Generated at 2022-06-16 23:17:00.669521
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.1K') == 1024 + (1024 / 10)
    assert human_to_bytes('1.1M') == 1024 * 1024 + (1024 * 1024 / 10)
    assert human_to_bytes('1.1G') == 1024 * 1024 * 1024 + (1024 * 1024 * 1024 / 10)
    assert human_to_bytes('1.1T') == 1024 * 1024 * 1024 * 1024 + (1024 * 1024 * 1024 * 1024 / 10)
    assert human_to_bytes('1.1P') == 1024 * 1024 * 1024 * 1024 * 1024 + (1024 * 1024 * 1024 * 1024 * 1024 / 10)
    assert human_to_bytes('1.1E') == 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-16 23:17:13.086157
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17286476629764096
    assert human_to_bytes('1.5Z') == 176817763715495936
    assert human_to_bytes('1.5Y') == 1807766605438482432

# Generated at 2022-06-16 23:17:25.540074
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'E']) == ['a', 'b', 'c', 1, 'd', 'e']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'E', 2]) == ['a', 'b', 'c', 1, 'd', 'e', 2]

# Generated at 2022-06-16 23:17:33.564972
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1Mb') == 1024 * 1024
    assert human_to_bytes('1G') == 1024 * 1024 * 1024
    assert human_to_bytes('1Gb') == 1024 * 1024 * 1024
    assert human_to_bytes('1T') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1Tb') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1P') == 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-16 23:17:44.702010
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', None]) == ['a', 'b', None]
    assert lenient_lowercase(['A', 'B', []]) == ['a', 'b', []]
    assert lenient_lowercase(['A', 'B', {}]) == ['a', 'b', {}]
    assert lenient_lowercase(['A', 'B', ()]) == ['a', 'b', ()]

# Generated at 2022-06-16 23:17:56.185203
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864766192408576
    assert human_to_bytes('1.5Z') == 17681776247967744000
    assert human_to_bytes('1.5Y') == 1807766274614773760000

# Generated at 2022-06-16 23:18:06.635569
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 17283797748568064
    assert human_to_bytes('1.5Z') == 176817579535245312
    assert human_to_bytes('1.5Y') == 1808126765083955200
    assert human

# Generated at 2022-06-16 23:18:18.188176
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10MB', isbits=True) == 10485760
    assert human_to_bytes('10MB', isbits=False) == 10485760
    assert human_to_bytes('10Mb', isbits=False) == 10485760
    assert human_to_bytes('10Mb', isbits=False, unit='M') == 10485760
    assert human_to_bytes('10Mb', isbits=False, unit='K') == 10240

# Generated at 2022-06-16 23:18:26.189491
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]



# Generated at 2022-06-16 23:18:33.006851
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172864766192403456
    assert human_to_bytes('1.5Z') == 1768177630235065344
    assert human_to_bytes('1.5Y') == 18077085995467149312


# Generated at 2022-06-16 23:18:44.614984
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Tb') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to

# Generated at 2022-06-16 23:18:55.788299
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'B', 'c']
    assert lenient_lowercase(['a', 'B', 'c', 1]) == ['a', 'B', 'c', 1]
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'E']) == ['a', 'B', 'c', 1, 'd', 'E']
    assert lenient_lowercase(['a', 'B', 'c', 1, 'd', 'E', 2]) == ['a', 'B', 'c', 1, 'd', 'E', 2]

# Generated at 2022-06-16 23:19:07.050779
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test cases for bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0k') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0m') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0g') == 10737418

# Generated at 2022-06-16 23:19:18.659888
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.9') == 1
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5k') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5m') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5g') == 1610612736
    assert human_to_bytes('1.5T') == 164926744