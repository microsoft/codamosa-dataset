

# Generated at 2022-06-24 21:06:46.306926
# Unit test for function human_to_bytes
def test_human_to_bytes():
    answer = human_to_bytes('256b')
    if 256 != answer:
        raise AssertionError(answer)
    answer = human_to_bytes('256b',isbits=True)
    if 256 != answer:
        raise AssertionError(answer)
    answer = human_to_bytes('256b',isbits=False)
    if 1 != answer:
        raise AssertionError(answer)
    answer = human_to_bytes('1b')
    if 1 != answer:
        raise AssertionError(answer)
    answer = human_to_bytes('1b',isbits=True)
    if 1 != answer:
        raise AssertionError(answer)
    answer = human_to_bytes('1.0b',isbits=True)

# Generated at 2022-06-24 21:06:53.812011
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1TB') == 1099511627776
    assert human_to_bytes('1PB') == 1125899906842624
    assert human_to_bytes('1EB') == 1152921504606846976
    assert human_to_bytes('1ZB') == 1180591620717411303424
    assert human_to_bytes('1YB') == 1208925819614629174706176
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1') == 1
    assert human_

# Generated at 2022-06-24 21:07:02.503905
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1GB') == 1073741824, 'Example 1'
    assert human_to_bytes('1K') == 1024, 'Example 2'
    assert human_to_bytes('1.2K') == 1228, 'Example 3'
    assert human_to_bytes('1.2b') == 1.2, 'Example 4'
    assert human_to_bytes('1.2bb') == 1.2, 'Example 5'
    assert human_to_bytes('1.2bB') == 1.2, 'Example 6'
    assert human_to_bytes('1.2bbb') == 1.2, 'Example 7'
    assert human_to_bytes('1.2b') == 1.2, 'Example 8'

# Generated at 2022-06-24 21:07:11.081137
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1M', default_unit='B') == 1048576
    assert human_to_bytes('2M', default_unit='B') == 2097152
    assert human_to_bytes('3M', default_unit='B') == 3145728
    assert human_to_bytes(3, default_unit='MB') == 3145728
    assert human_to_bytes(4, default_unit='M') == 4194304
    assert human_

# Generated at 2022-06-24 21:07:15.341850
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes(1000, 'K') == 1024000
    try:
        human_to_bytes('random_string')
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-24 21:07:21.675351
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', unit='K') == 10240
    assert human_to_bytes('10M') == human_to_bytes(10, 'Mb', isbits=True)
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=True) == human_to_bytes(10, 'M', isbits=True)
    assert human_to_bytes('10Mb', isbits=True) == human_to_bytes(10, unit='Mb', isbits=True)

# Generated at 2022-06-24 21:07:26.055755
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Case 0
    str_0 = 'GK\n\\$]+e&F'
    var_0 = human_to_bytes(str_0)
    assert int(var_0) == 0


# Generated at 2022-06-24 21:07:30.639000
# Unit test for function human_to_bytes
def test_human_to_bytes():
    for str_0 in range(1, 100000):
        var_0 = human_to_bytes(str_0)

# Generated at 2022-06-24 21:07:36.397164
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Unit test for function human_to_bytes - string value
    assert human_to_bytes('1.2M') == 1228800
    # Unit test for function human_to_bytes - integer value
    assert human_to_bytes(1.2, 'M') == 1228800


# Generated at 2022-06-24 21:07:46.480367
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2K', isbits=True) == 2097152
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10Mb') == 1048576
    assert human_to_bytes('20G') == 209715200
    assert human_to_bytes('1T') == 1073807360
    assert human_to_bytes('20P') == 230584300921369400
    assert human_to_bytes('10E') == 11258999068426240
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('2kb') == 2048

# Generated at 2022-06-24 21:07:58.227894
# Unit test for function human_to_bytes
def test_human_to_bytes():
    input_0 = '1.00E+01 B'
    expect_0 = 10
    output_0 = human_to_bytes(input_0)
    if expect_0 != output_0:
        raise ValueError("Expect %s, but got %s" % (expect_0, output_0))
    input_1 = '1.00E+01'
    expect_1 = 10
    output_1 = human_to_bytes(input_1)
    if expect_1 != output_1:
        raise ValueError("Expect %s, but got %s" % (expect_1, output_1))
    input_2 = '20'
    expect_2 = 20
    output_2 = human_to_bytes(input_2)

# Generated at 2022-06-24 21:08:04.590355
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test1 = ['AAA', ['BBB'], 'ccc', {'DDD': 'ddd'}]
    test2 = lenient_lowercase(test1)
    assert(isinstance(test2[0], str))
    assert(isinstance(test2[1], list))
    assert(isinstance(test2[2], str))
    assert(isinstance(test2[3], dict))
    assert(test2[0] == 'aaa')
    assert(test2[1] == ['BBB'])
    assert(test2[2] == 'ccc')
    assert(test2[3] == {'DDD': 'ddd'})


# Generated at 2022-06-24 21:08:06.424835
# Unit test for function human_to_bytes
def test_human_to_bytes():
    if __name__ == '__main__':
        test_case_0()


# Generated at 2022-06-24 21:08:15.761738
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test default function
    assert human_to_bytes('10M') == 10485760
    # Test with B
    assert human_to_bytes('10MB') == 10485760
    # Test with KB
    assert human_to_bytes('10KB') == 10240
    # Test with Kb
    assert human_to_bytes('10Kb', isbits=True) == 10240
    # Test with b
    assert human_to_bytes('10Kb') == 10240
    # Test with default unit
    assert human_to_bytes('10', default_unit='M') == 10485760
    # Test with default unit with KB
    assert human_to_bytes('10', default_unit='KB') == 10240
    # Test with default unit with Kb

# Generated at 2022-06-24 21:08:26.124721
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.2M') == 1228800
    assert human_to_bytes('1.2Mb') == 1228800
    assert human_to_bytes('-1.2Mb') == -1228800

    assert human_to_bytes('1K', isbits=True) == 1024
    assert human_to_bytes('-1K', isbits=True) == -1024
    assert human_to_bytes('1K') == 1024 * 1024
    assert human_to_bytes('-1K') == -1024 * 1024

    assert human_to_bytes('1.2Mb', isbits=True) == 1228800
    assert human_to_bytes('1.2M', isbits=True) == 12582912

    assert human

# Generated at 2022-06-24 21:08:35.311813
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_dict = {
        'lenient_lowercase_0': {
            'input': ["A", "b", 1],
            'output': ["a", "b", 1]
        },
        'lenient_lowercase_1': {
            'input': ["A", "b", 1],
            'output': ["a", "b", 1]
        },
    }

    for case, data in test_dict.items():
        result = lenient_lowercase(data['input'])
        expected_result = data['output']
        assert result == expected_result, 'Test %s, got %s and expected %s' % (case, result, expected_result)


# Generated at 2022-06-24 21:08:38.473540
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['TEST', 'TEST1']) == ['test', 'test1']
    assert lenient_lowercase([1, 2]) == [1, 2]
    assert lenient_lowercase([1, 'TEST']) == [1, 'test']

# Generated at 2022-06-24 21:08:41.307259
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['aBc', 'dEf', 1]) == ['abc', 'def', 1]

# Data retrieval test for function bytes_to_human

# Generated at 2022-06-24 21:08:48.049339
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M', 'M') == 1048576
    assert human_to_bytes('1G', 'M') == 1073741824
    assert human_to_bytes('1MB', 'M') == 1048576
    assert human_to_bytes('1GB', 'M') == 1073741824
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1.1M', 'M') == 1179648
    assert human_to_bytes('1023') == 1023


# Generated at 2022-06-24 21:08:57.142662
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K', default_unit='B') == 2048
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=False) == 12582912
    assert human_to_bytes('10Mb', default_unit='K') == 8192
    assert human_to_bytes('10mb', default_unit='k') == 8192
    assert human_to_bytes('10kb', default_unit='k') == 10240
    assert human_to_bytes('10', default_unit='MB') == 10485760
    assert human_to_bytes('10Kb', default_unit='K') == 10240

# Generated at 2022-06-24 21:09:02.441869
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['abc', '123']) == ['abc', '123']


# Generated at 2022-06-24 21:09:07.508222
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['Foo', 'BAR', 'qux', 1, 2, 3]) == ['foo', 'bar', 'qux', 1, 2, 3]



# Generated at 2022-06-24 21:09:10.660776
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['kArUN', 'NiHaL']) == ['karun', 'nihal']


# Generated at 2022-06-24 21:09:20.907540
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test with no default unit
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10') == human_to_bytes(10)
    assert human_to_bytes('10G') == 10737418240
    assert human_to_bytes('10G') == human_to_bytes(10, 'G')
    assert human_to_bytes('10GK') == human_to_bytes(10, 'GK')
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10B') == human_to_bytes(10, 'B')
    assert human_to_bytes('10BK')

# Generated at 2022-06-24 21:09:24.639211
# Unit test for function human_to_bytes
def test_human_to_bytes():
    input_value = '2K'
    try:
        expected_result = 2048
        result = human_to_bytes(input_value)
        assert result == expected_result
    except AssertionError as e:
        print('Expected outcome: %s, Actual outcome: %s.' % (expected_result, result))
        raise e


# Generated at 2022-06-24 21:09:27.083935
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ans = human_to_bytes('1KB') 
    assert ans == 1024


# Generated at 2022-06-24 21:09:38.433270
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10, 'M') == 10485760, "human_to_bytes() failed to convert 10M to bytes"
    assert human_to_bytes(10) == 10, "human_to_bytes() failed to convert 10 to bytes (default unit)"
    assert human_to_bytes('10M') == 10485760, "human_to_bytes() failed to convert string 10M to bytes (with default unit)"
    assert human_to_bytes('10M', isbits=True) == 1250000, "human_to_bytes() failed to convert string 10M to bits (w/ default unit)"
    assert human_to_bytes('10b') == 1, "human_to_bytes() failed to convert string 10b to bits"

# Generated at 2022-06-24 21:09:49.335007
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1000', 'M') == 1048576
    assert human_to_bytes('1000', 'K') == 1024
    assert human_to_bytes('1000', 'G') == 1073741824
    assert human_to_bytes('10.5', 'M') == 10485760
    assert human_to_bytes('10.5', 'K') == 10752
    assert human_to_bytes('10.5', 'G') == 1125899906842624
    assert human_to_bytes('10.5', 'B') == 10.5
    assert human_to_bytes('10.5', 'm') == 10.5
    assert human_to_bytes('10.5', 'k') == 10.5
    assert human_to_bytes('10.5', 'g') == 10.5

# Generated at 2022-06-24 21:09:58.164321
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Ensure that lenient_lowercase converts strings, lists, and tuples to lowercase
    str_input = 'TeStInG'
    list_input = ['tEsTiNg', 'lIsT']
    tuple_input = ('TeStInG', 'tUpLe')
    str_ouput = 'testing'
    list_output = ['testing', 'list']
    tuple_output = ('testing', 'tuple')
    assert lenient_lowercase(str_input) == str_ouput
    assert lenient_lowercase(list_input) == list_output
    assert lenient_lowercase(tuple_input) == tuple_output

    # Ensure that it passes through non-string type as-is
    dict_input = {'TeStInG': 'dIcT'}

# Generated at 2022-06-24 21:10:10.199607
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024, "wrong value returned"
    assert human_to_bytes('K') == 1024, "wrong value returned"
    assert human_to_bytes(1, 'K') == 1024, "wrong value returned"
    assert human_to_bytes(1000000, 'B') == 1000000, "wrong value returned"
    assert human_to_bytes('100000B') == 100000, "wrong value returned"
    assert human_to_bytes('100.5M') == 1048576000, "wrong value returned"
    assert human_to_bytes(0.1, 'B') == 0, "wrong value returned"
    assert human_to_bytes(2.5, 'KB') == 2560, "wrong value returned"

# Generated at 2022-06-24 21:10:19.031613
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('GK\n\\$]+e&F') == -1783263616
    assert human_to_bytes('144q6Y!;6$$J<6\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06\x06') == 524288

# Generated at 2022-06-24 21:10:25.756973
# Unit test for function human_to_bytes
def test_human_to_bytes():
    string = '10K'
    assert human_to_bytes(string) == 10240
    string = '10KB'
    assert human_to_bytes(string) == 10240
    string = '10.3Mb'
    assert human_to_bytes(string, isbits=True) == 10.3 * 1024 * 1024
    string = '-10.3M'
    assert human_to_bytes(string) == -(10.3 * 1024 * 1024)
    string = '10MB'
    assert human_to_bytes(string) == 10 * 1024 * 1024
    string = '10.0MB'
    assert human_to_bytes(string) == 10 * 1024 * 1024
    string = '2.2Mb'

# Generated at 2022-06-24 21:10:38.040655
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("\ntest_human_to_bytes")
    try:
        human_to_bytes('10M', isbits=True)
        print("error: human_to_bytes('10M', isbits=True) - should raise ValueError")
    except ValueError as err:
        print("OK: human_to_bytes('10M', isbits=True) - expect error: %s" % err)

    try:
        human_to_bytes('100Mb', isbits=False)
        print("error: human_to_bytes('100Mb', isbits=False) - should raise ValueError")
    except ValueError as err:
        print("OK: human_to_bytes('100Mb', isbits=False) - expect error: %s" % err)


# Generated at 2022-06-24 21:10:47.233397
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # This test case tests whether the human_to_bytes fails to convert an amount
    # in human-readable format to an integer
    with pytest.raises(ValueError) as ex:
        human_to_bytes('10M')
    assert 'human_to_bytes() can\'t interpret' in str(ex.value)
    # This test case tests whether the human_to_bytes fails to convert an amount
    # in human-readable format to an integer
    with pytest.raises(ValueError) as ex:
        human_to_bytes('10M')
    assert 'human_to_bytes() can\'t interpret' in str(ex.value)
    with pytest.raises(ValueError) as ex:
        human_to_bytes('10M')

# Generated at 2022-06-24 21:10:50.542794
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Compare output of lenient_lowercase against str.lower
    assert lenient_lowercase(['a', 'b', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]
    assert lenient_lowercase([]) == []



# Generated at 2022-06-24 21:10:56.059268
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 1]) == ['a', 1]


# Generated at 2022-06-24 21:11:04.718484
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes("42") == 42)
    assert(human_to_bytes("42B") == 42)
    assert(human_to_bytes("42b") == 42)
    assert(human_to_bytes("42M") == 42000000)
    assert(human_to_bytes("42Mb") == 54600000)
    assert(human_to_bytes("42m") == 42000000)
    assert(human_to_bytes("42mB") == 42000000)
    assert(human_to_bytes("42mb") == 54600000)
    assert(human_to_bytes("42K") == 42000)
    assert(human_to_bytes("42Kb") == 52800)
    assert(human_to_bytes("42k") == 42000)

# Generated at 2022-06-24 21:11:15.491362
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([u'foo', 'BAR', 123]) == [u'foo', 'bar', 123]
    assert lenient_lowercase(['foo', 'BAR', 123]) == ['foo', 'bar', 123]
    assert lenient_lowercase(['FOO', u'BAR', 123]) == ['foo', 'bar', 123]
    assert lenient_lowercase([u'FOO', u'BAR', 123]) == ['foo', 'bar', 123]
    assert lenient_lowercase([u'FOO', u'bAR']) == ['foo', 'bar']
    assert lenient_lowercase(['FOO', 'bAR']) == ['foo', 'bar']
    assert lenient_lowercase(['FOO', 'bAR']) == ['foo', 'bar']
    assert lenient_lower

# Generated at 2022-06-24 21:11:20.155731
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10Mb') == 1310720
    assert human_to_bytes('10Mb', True) == 1310720
    assert human_to_bytes('10Mb', False) == 10485760
    assert human_to_bytes('10Mb', False, 'M') == 10485760
    assert human_to_bytes('10Mb', True, 'M') == 10485760



# Generated at 2022-06-24 21:11:22.831107
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert lenient_lowercase(['a', 'b']) == ['a', 'b']
    assert lenient_lowercase(['a', 1]) == ['a', 1]

# Generated at 2022-06-24 21:11:33.280647
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['ABC', 'DEF', 'GHI']) == ['abc', 'def', 'ghi']
    assert lenient_lowercase(['abc', 'DEF', 'ghi']) == ['abc', 'def', 'ghi']
    assert lenient_lowercase(['123', 'DEF', '456']) == ['123', 'def', '456']
    assert lenient_lowercase(['123', 223, 456]) == ['123', 223, 456]



# Generated at 2022-06-24 21:11:37.722537
# Unit test for function human_to_bytes
def test_human_to_bytes():
    s = human_to_bytes('10M')
    assert(s == 10485760)
    s = human_to_bytes('10Mb')
    assert(s == 10485760)
    s = human_to_bytes('10M', isbits=True)
    assert(s == 83886080)


# Generated at 2022-06-24 21:11:46.477991
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    passwd = '$5$M^hjujaj@wQm$n5/Vu5n5!xF5/U3qcU6Y2QWjnU/vwIgNfR6lHl4/EO'
    passwd_l = '$5$m^hjujaj@wqm$n5/vu5n5!xf5/u3qcu6y2qwjnu/vwignfr6lhl4/eo'
    ret = lenient_lowercase([passwd])
    if ret[0] != passwd_l:
        raise AssertionError()

# Generated at 2022-06-24 21:11:54.814228
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1TB') == 1099511627776, 'test failed'
    assert human_to_bytes('1T') == 1099511627776, 'test failed'
    assert human_to_bytes('15T') == 17592186044416, 'test failed'
    assert human_to_bytes('500T') == 5497558138880, 'test failed'
    assert human_to_bytes('1TB', isbits=True) == 137438953472, 'test failed'
    assert human_to_bytes('1T', isbits=True) == 137438953472, 'test failed'
    assert human_to_bytes('15T', isbits=True) == 17179869184, 'test failed'
    assert human_to_bytes('500T', isbits=True) == 62

# Generated at 2022-06-24 21:11:56.751278
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([u'aBc']) == ['abc']
    assert lenient_lowercase(['aBc', True, False]) == ['abc', True, False]


# Generated at 2022-06-24 21:12:01.468355
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert [] == lenient_lowercase([])
    assert [1, 2, 3] == lenient_lowercase([1, 2, 3])
    assert ['a', 'b', 'c'] == lenient_lowercase(['A', 'B', 'C'])
    assert ['a', 2, 'c'] == lenient_lowercase(['A', 2, 'C'])


# Generated at 2022-06-24 21:12:10.157930
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = human_to_bytes('1K')
    assert result == 1024
    result = human_to_bytes('1000K')
    assert result == 1024000
    result = human_to_bytes('1Gb')
    assert result == 1073741824
    result = human_to_bytes('1000Mb')
    assert result == 1073741824000
    result = human_to_bytes('1Gb', isbits=True)
    assert result == 1073741824
    result = human_to_bytes('1000Mb', isbits=True)
    assert result == 1073741824000
    try:
        result = human_to_bytes('1000Mb', isbits=False)
    except Exception as e:
        assert isinstance(e, ValueError)

# Generated at 2022-06-24 21:12:14.509149
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_case_0()


# Generated at 2022-06-24 21:12:16.706788
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list1 = ['Hello', 'World']
    assert_0 = lenient_lowercase(list1)
    assert assert_0 == ['hello', 'world']


# Generated at 2022-06-24 21:12:25.799714
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5Mb') == 1572864
    assert human_to_bytes('20b') == 20
    assert human_to_bytes('20') == 20
    assert human_to_bytes(20) == 20
    assert human_to_bytes('20', isbits=True) == 160
    assert human_to_bytes(20, isbits=True) == 160
    assert human_to_bytes('20b', isbits=True) == 20
    assert human_to_bytes(20, unit='KB') == 20480
    assert human_to_bytes('20KB', isbits=True) == 20480

# Generated at 2022-06-24 21:12:38.741958
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """Test for lenient_lowercase
    """
    first_test = [1, 'a', 'b', 2, 3]
    second_test = ['A', 'b', 2, 3]
    third_test = ['A', 'B', 2, 3]
    fourth_test = ['a', 2, 3]
    expected = [1, 'a', 'b', 2, 3]
    assert(expected == lenient_lowercase(first_test))
    expected = [1, 'a', 'b', 2, 3]
    assert(expected == lenient_lowercase(second_test))
    expected = [1, 'a', 'b', 2, 3]
    assert(expected == lenient_lowercase(third_test))
    expected = [1, 'a', 'b', 2, 3]

# Generated at 2022-06-24 21:12:41.240515
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    if lenient_lowercase([b'FOO', 'foo']) != ['foo', 'foo']:
        raise AssertionError


# Generated at 2022-06-24 21:12:46.909362
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['abc', 1, 'def', 'GHI', 'jkl']) == ['abc', 1, 'def', 'ghi', 'jkl']


# Generated at 2022-06-24 21:12:55.511611
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1T', unit='B') == 1099511627776
    assert human_to_bytes('1T', isbits=True) == 8796093022208
    assert human_to_bytes('1T', unit='b', isbits=True) == 8796093022208
    assert human_to_bytes('1Tb', unit='b', isbits=True) == 8796093022208
    assert human_to_bytes('1TB', unit='B') == 1099511627776
    assert human_to_bytes('1TB', unit='B', isbits=True) == 8796093022208
    assert human_to_bytes('1t', unit='B') == 1099511627776
    assert human_to_

# Generated at 2022-06-24 21:13:00.937673
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1.5Mb', isbits=True) == 1572864
    assert human_to_bytes('1.5mB', isbits=False) == 1572864



# Generated at 2022-06-24 21:13:08.956345
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('2K') == 2048)
    assert(human_to_bytes('10M') == 10485760)
    assert(human_to_bytes('10MB') == 10485760)
    assert(human_to_bytes('2kb') == 2048)
    assert(human_to_bytes('1kb', isbits=True) == 1024)
    assert(human_to_bytes('10Mb', isbits=True) == 10485760)
    assert(human_to_bytes('10MB', isbits=True) == 83886080)
    assert(human_to_bytes('2G') == 2147483648)
    assert(human_to_bytes('2GB') == 2147483648)
    assert(human_to_bytes('10Mb') == 10485760)

# Generated at 2022-06-24 21:13:19.363428
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        assert human_to_bytes('1') == 1
        assert human_to_bytes('1K') == 1024
        assert human_to_bytes('1M') == 1048576
        assert human_to_bytes('10b') == 10
        assert human_to_bytes('1Kb', isbits=True) == 1024
        assert human_to_bytes('1Mb', isbits=True) == 1048576
        assert bytes_to_human(human_to_bytes('1Kb', isbits=True), isbits=True) == '1024 bits'
        assert bytes_to_human(human_to_bytes('1Mb', isbits=True), isbits=True) == '1048576 bits'
    except AssertionError as e:
        print('Test failure: ', e)
    else:
        print

# Generated at 2022-06-24 21:13:22.539277
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # lenient_lowercase get a value
    value = ['a', 'b', 1, 2, 3]
    expected = ['a', 'b', 1, 2, 3]
    actual = lenient_lowercase(value)
    assert expected == actual



# Generated at 2022-06-24 21:13:29.103977
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert lenient_lowercase([1, 'a', 'A', 2]) == [1, 'a', 'a', 2]
    assert lenient_lowercase([1, 'A', 2, 'b']) == [1, 'a', 2, 'b']
    assert lenient_lowercase(['a', 'b', 'C', 'D']) == ['a', 'b', 'c', 'd']
    assert lenient_lowercase(['a', 'b', 'c', 'D']) == ['a', 'b', 'c', 'd']
    assert lenient_lowercase(['a', 'B', 'c', 'D']) == ['a', 'b', 'c', 'd']
    assert lenient

# Generated at 2022-06-24 21:13:37.508502
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('12345678') == 12345678
    assert human_to_bytes('2.2M') == 2200000
    assert human_to_bytes('3Gb') == 3145728000
    assert human_to_bytes('4Yb') == 4548047489056
    assert human_to_bytes('5.5 Zb', isbits=True) == 5.5 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('6Eb', isbits=True) == 6.0 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('7 Pb', isbits=True) == 7.0 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('8 Tb', isbits=True) == 8.0 * 1024

# Generated at 2022-06-24 21:13:51.136129
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    for coverage:
        - test case when uint has not been provided with the string (ex: '100')
        - test case when uint is being provided with the string (ex: '100Kb')
        - test case when uint is being provided with the string (ex: '100KB' - bit representation)
    '''
    result = human_to_bytes('200')
    assert result == 200

    result = human_to_bytes('200kb', isbits=True)
    assert result == 200000

    result = human_to_bytes('200KB', isbits=False)
    assert result == 204800
    return



# Generated at 2022-06-24 21:13:57.321867
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(2776) == 2776
    assert lenient_lowercase([2776]) == [2776]
    assert lenient_lowercase(['2776']) == ['2776']
    assert lenient_lowercase(['2776', 2776]) == ['2776', 2776]
    assert lenient_lowercase([2776, '2776']) == [2776, '2776']
    assert lenient_lowercase(['2776', '2776']) == ['2776', '2776']


# Generated at 2022-06-24 21:14:01.955489
# Unit test for function human_to_bytes
def test_human_to_bytes():
    size = '2k'
    human_to_bytes(size)
    size = '2kb'
    human_to_bytes(size, isbits=True)
    size = '2kb'
    human_to_bytes(size, isbits=True, default_unit='b')
    size = '2kb'
    human_to_bytes(size, isbits=True, default_unit='b')
    size = '2kb'
    human_to_bytes(size, isbits=True, default_unit='b')
    size = '2kb'
    human_to_bytes(size, isbits=True, default_unit='b')


# Generated at 2022-06-24 21:14:11.938973
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # checks for positive error case
    try:
        human_to_bytes('2776.5Mb')
    except ValueError:
        # Expected result
        pass
    else:
        raise AssertionError('The above expected to raise exception')

    # checks for positive error case
    try:
        human_to_bytes('2776.5B')
    except ValueError:
        # Expected result
        pass
    else:
        raise AssertionError('The above expected to raise exception')

    # checks for positive error case
    try:
        human_to_bytes('1.5Mb', unit='B')
    except ValueError:
        # Expected result
        pass
    else:
        raise AssertionError('The above expected to raise exception')

    # checks for positive error case

# Generated at 2022-06-24 21:14:21.576770
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1M') == 1048576)
    assert(human_to_bytes('2M') == 2097152)
    assert(human_to_bytes('10M') == 10485760)
    assert(human_to_bytes('1Mb', isbits=True) == 1048576)
    assert(human_to_bytes('10Mb', isbits=True) == 10485760)
    assert(human_to_bytes('2Mb', isbits=True) == 2097152)
    assert(human_to_bytes('2Mb', isbits=True) == 2097152)



# Generated at 2022-06-24 21:14:30.310156
# Unit test for function human_to_bytes
def test_human_to_bytes():
    units = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"]
    raw_numbers = [5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5]

    # test cases are presented as dictionary in format number:expected_result
    test_cases = {i: j*1024 for i, j in zip(units, raw_numbers)}

# Generated at 2022-06-24 21:14:42.568551
# Unit test for function human_to_bytes
def test_human_to_bytes():
    int_0 = human_to_bytes('2K')
    assert int_0 == 2048
    int_1 = human_to_bytes('10.1M')
    assert int_1 == 10485760
    int_2 = human_to_bytes(10.1, 'M')
    assert int_2 == 10485760
    int_3 = human_to_bytes('-128K')
    assert int_3 == -131072
    int_4 = human_to_bytes('0')
    assert int_4 == 0
    int_5 = human_to_bytes('.5M')
    assert int_5 == 524288
    int_6 = human_to_bytes('1K')
    assert int_6 == 1024
    int_7 = human_to_bytes('1.1K')
    assert int

# Generated at 2022-06-24 21:14:52.003467
# Unit test for function human_to_bytes
def test_human_to_bytes():
    check_0 = human_to_bytes('10M')
    assert check_0 == 10485760
    check_1 = human_to_bytes('10MB')
    assert check_1 == 10485760
    check_2 = human_to_bytes('10Mb', isbits=True)
    assert check_2 == 10485760
    check_3 = human_to_bytes('10.4Mb', isbits=True)
    assert check_3 == 10905190
    check_4 = human_to_bytes('10.4Mb', isbits=False)
    assert check_4 == 10.4
    check_5 = human_to_bytes('10Mb')
    assert check_5 == 10485760
    check_6 = human_to_bytes('10MB', isbits=True)

# Generated at 2022-06-24 21:15:02.017907
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # simple case
    assert (human_to_bytes('10M') == 10 * SIZE_RANGES['M'])
    assert (human_to_bytes('10M', 'M') == 10 * SIZE_RANGES['M'])
    assert (human_to_bytes(10, 'M') == 10 * SIZE_RANGES['M'])
    assert (human_to_bytes((10, 'M')) == 10 * SIZE_RANGES['M'])
    # float number
    assert (human_to_bytes('10.4M') == 10 * SIZE_RANGES['M'] + 4 * SIZE_RANGES['M'] / 10)

# Generated at 2022-06-24 21:15:11.361684
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = 2776
    var_0 = lenient_lowercase(int_0)
    var_1 = lenient_lowercase(var_0)
    assert var_1 == 2776
    var_2 = lenient_lowercase(var_1)
    assert var_2 == 2776
    var_3 = lenient_lowercase(var_2)
    assert var_3 == 2776
    var_4 = lenient_lowercase(var_3)
    assert var_4 == 2776
    var_5 = lenient_lowercase(var_4)
    assert var_5 == 2776
    var_6 = lenient_lowercase(var_5)
    assert var_6 == 2776
    var_7 = lenient_lowercase(var_6)

# Generated at 2022-06-24 21:15:27.857865
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1MB', default_unit='M') == 1048576
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10B', default_unit='B') == 10
    assert human_to_bytes('10B', default_unit='M') == 10

    assert human_to_bytes('1Mb') == 1048684
    assert human_to_bytes('1Mb', default_unit='b') == 1048684
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10b', default_unit='b') == 10
    assert human_to_bytes('10b', default_unit='m') == 10

    # Pass default_unit=None (no default unit)

# Generated at 2022-06-24 21:15:37.707060
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = 2776
    var_0 = lenient_lowercase(int_0)
    assert var_0 is int_0, "%s != %s" % (var_0, int_0)

    str_0 = 'abc'
    var_1 = lenient_lowercase(str_0)
    assert var_1 == str_0.lower(), "%s != %s" % (var_1, str_0.lower())

    lst_0 = ['a', 1]
    var_2 = lenient_lowercase(lst_0)
    assert var_2 == ['a', 1], var_2

    lst_1 = ['a', 'b', 1]
    var_3 = lenient_lowercase(lst_1)
    assert var_3 == ['a', 'b', 1], var_

# Generated at 2022-06-24 21:15:49.036054
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K', 'B') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1Kb', 'b') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes(1048576, unit='B') == 1048576
    assert human_to_bytes(1048576, unit='b', isbits=True) == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1Eb', isbits=True) == 1099511627776
    assert human_to_bytes('1Pb', isbits=True) == 112589990

# Generated at 2022-06-24 21:15:50.642039
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = human_to_bytes('1Mb')
    assert result == 1048576



# Generated at 2022-06-24 21:15:53.070649
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = 2776
    var_0 = lenient_lowercase(int_0)

    assert var_0 == 2776



# Generated at 2022-06-24 21:16:00.956600
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Unit test for human_to_bytes without unit
    assert human_to_bytes('1') == 1
    assert human_to_bytes('0') == 0
    assert human_to_bytes('8.1') == 8
    assert human_to_bytes('8.9') == 9
    assert human_to_bytes('.1') == 0
    assert human_to_bytes('-.1') == 0
    assert human_to_bytes('-1.1') == -1
    assert human_to_bytes('-1') == -1

    # Unit test for human_to_bytes with unit
    assert human_to_bytes('1KB') == 1000
    assert human_to_bytes('1MB') == 1000000
    assert human_to_bytes('1.5MB') == 1500000

# Generated at 2022-06-24 21:16:05.442861
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase('2776') == '2776'

# Unit test to verify human_to_bytes is working

# Generated at 2022-06-24 21:16:10.618138
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Test our conversion from human to bytes."""
    result = human_to_bytes('0.0')
    assert result == 0

    result = human_to_bytes('0.0', default_unit='KB')
    assert result == 0

    result = human_to_bytes('1', default_unit='KB')
    assert result == 1024

    result = human_to_bytes('1b')
    assert result == 1

    result = human_to_bytes('1b', isbits=True)
    assert result == 1

    result = human_to_bytes('1b', default_unit='MB')
    assert result == 1

    result = human_to_bytes('10B')
    assert result == 10

    result = human_to_bytes('10B', default_unit='B')
    assert result == 10

    result = human_

# Generated at 2022-06-24 21:16:19.762225
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('-1MB') == -1048576
    assert human_to_bytes('1') == 1
    assert human_to_bytes('-1') == -1
    assert human_to_bytes('1MB', 'B') == 1048576
    assert human_to_bytes('1', 'B') == 1
    assert human_to_bytes('1MB', 'b') == 8388608
    assert human_to_bytes('1', 'b') == 8
    # test with isbits == True
    assert human_to_bytes('1MB', isbits=True) == 1048576
    assert human_to_bytes('-1MB', isbits=True) == -1048576

# Generated at 2022-06-24 21:16:27.885620
# Unit test for function human_to_bytes
def test_human_to_bytes():
    int_0 = 748
    var_0 = str(int_0)
    int_1 = 7564
    var_1 = str(int_1)
    int_2 = 7563
    var_2 = str(int_2)
    int_3 = 746
    var_3 = str(int_3)
    int_4 = 752
    var_4 = str(int_4)

    # Exceptions
    try:
        int_5 = human_to_bytes(int_0)
    except Exception as e:
        int_5 = 0
    try:
        int_6 = human_to_bytes('abc')
    except Exception as e:
        int_6 = 0
    try:
        int_7 = human_to_bytes('0')
    except Exception as e:
        int_