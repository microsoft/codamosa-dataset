

# Generated at 2022-06-24 21:06:53.727508
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test case 0
    input_0 = ' 10M '
    output_0 = 10485760
    human_to_bytes(input_0) == output_0

    # Test case 1
    input_1 = ' 10m '
    output_1 = 10485760
    human_to_bytes(input_1) == output_1

    # Test case 2
    input_2 = ' 10 m '
    output_2 = 10
    human_to_bytes(input_2) == output_2

    # Test case 3
    input_3 = ' 10Mb '
    output_3 = None
    human_to_bytes(input_3) == output_3

    # Test case 4
    input_4 = ' 10Mb '
    output_4 = None

# Generated at 2022-06-24 21:07:02.473981
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K', default_unit='B') == 1024
    assert human_to_bytes(10, default_unit='B') == 10
    assert human_to_bytes('1B', default_unit='B') == 1
    assert human_to_bytes('10B', default_unit='B') == 10
    assert human_to_bytes('1M', default_unit='B') == 1048576
    assert human_to_bytes('1MB', default_unit='B') == 1048576
    assert human_to_bytes('1kb', isbits=True) == 1024 * 8
    assert human_to_bytes('1Mb', isbits=True) == 1048576 * 8
    assert human_to_bytes('1MB', isbits=True) == 1048576 * 8

# Generated at 2022-06-24 21:07:11.061890
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test invalid number
    try:
        human_to_bytes('Mb', isbits=True)
        assert(False)
    except ValueError as e:
        assert(re.match('.*convert Mb.*expect M.*', str(e)))

    # test invalid unit
    try:
        human_to_bytes('1.0', unit='Mb')
        assert(False)
    except ValueError as e:
        assert(re.match('.*can\'t interpret following number: 1.0.*', str(e)))

    # test valid conversion
    assert(human_to_bytes('1Mb', isbits=True) == 1024 * 1024)
    assert(human_to_bytes('1MB', unit='M') == 1024 * 1024)

# Generated at 2022-06-24 21:07:15.710400
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test case 0
    test_0 = '10M'
    assert(human_to_bytes(test_0) == 10485760), 'function human_to_bytes returned unexpected value'

    # Test case 1
    test_1 = '10MB'
    assert(human_to_bytes(test_1) == 10485760), 'function human_to_bytes returned unexpected value'

    # Test case 2
    test_2 = '10Mb'
    try:
        human_to_bytes(test_2)
    except ValueError as err:
        assert(str(err) == 'human_to_bytes() failed to convert 10Mb (unit = Mb). The suffix must be one of Y, Z, E, P, T, G, M, K, B'), "Caught unexpected exception while testing function human_to_bytes"

# Generated at 2022-06-24 21:07:17.417463
# Unit test for function human_to_bytes
def test_human_to_bytes():
    list_0 = []
    var_0 = human_to_bytes(list_0)
    assert var_0 == ValueError

# Generated at 2022-06-24 21:07:28.394047
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('3') == 3
    assert human_to_bytes('3b') == 3
    assert human_to_bytes('3 B') == 3
    assert human_to_bytes('3.0') == 3
    assert human_to_bytes(' 3.0 ') == 3
    assert human_to_bytes('3.0 B') == 3
    assert human_to_bytes('3B') == 3
    assert human_to_bytes('3b', True) == 3
    assert human_to_bytes('3B', True) == 3
    assert human_to_bytes('3B', True) == 3
    assert human_to_bytes('3b', True, 'b') == 3
    assert human_to_bytes('3B', True, 'b') == 3

# Generated at 2022-06-24 21:07:35.639507
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10G') == 10737418240
    assert human_to_bytes('10GB') == 10737418240
    assert human_to_bytes('10GB', 'B') == 10737418240
    assert human_to_bytes('10', 'G') == 10737418240
    assert human_to_bytes('10G', 'B') == 10737418240

    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Mb', 'b') == 10485760
    assert human_to_bytes('10', 'Mb') == 10485760
    assert human_to_bytes('10Mb', 'b', True) == 10485760

    assert human_to_bytes('8.00b', 'b', True) == 8
    assert human

# Generated at 2022-06-24 21:07:45.880384
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1234') == 1234
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5mb') == human_to_bytes('1.5Mb', isbits=True)
    assert human_to_bytes('1.5Mb') == 1572864
    assert human_to_bytes('1.5MB') == 1572864
    assert human_to_bytes('1.5B') == 1
    assert human_to_bytes('1.5b') == human_to_bytes('1.5B', isbits=True)
    assert human_to_bytes('1.5b') == 1
    assert human_to_bytes('1234', unit='K') == 1234 * 1024

# Generated at 2022-06-24 21:07:53.192599
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            number=dict(type='str', required=True),
            default_unit=dict(type='str', required=False),
            isbits=dict(type='bool', required=False)
        )
    )
    number = module.params['number']
    default_unit = module.params['default_unit']
    isbits = module.params['isbits']
    result = human_to_bytes(number, default_unit, isbits)
    module.exit_json(changed=False, meta=result)


# Generated at 2022-06-24 21:08:00.209829
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = []
    var_0 = list_0
    var_1 = var_0
    list_1 = var_1
    var_2 = var_1[:]
    list_2 = var_2
    var_3 = var_2[:]
    list_3 = var_3
    var_4 = var_3[:]
    list_4 = var_4
    var_5 = var_4[:]
    list_5 = var_5
    var_6 = var_5[:]
    list_6 = var_6
    var_7 = var_6[:]
    list_7 = var_7
    var_8 = var_7[:]
    list_8 = var_8
    var_9 = var_8[:]
    list_9 = var_9

# Generated at 2022-06-24 21:08:05.087217
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = []
    var_0 = lenient_lowercase(list_0)


# Generated at 2022-06-24 21:08:14.017523
# Unit test for function bytes_to_human

# Generated at 2022-06-24 21:08:20.455164
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = []
    try:
        expected = []

        var_0 = lenient_lowercase(list_0)
        var_0 = lenient_lowercase(list_0)
        assert var_0 == expected, 'var_0 = lenient_lowercase(list_0)'
    except AssertionError as e:
        print('Failure: test_lenient_lowercase')
        print('Expected: ', expected)
        print('Actual: ', var_0)
        raise e


# Generated at 2022-06-24 21:08:24.885065
# Unit test for function bytes_to_human
def test_bytes_to_human():
    size_0 = 1024
    size_1 = 0
    size_2 = 1048576
    assert bytes_to_human(size_0) == '1.00 KB'
    assert bytes_to_human(size_1) == '0.00 B'
    assert bytes_to_human(size_2) == '1.00 MB'



# Generated at 2022-06-24 21:08:30.079772
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10, None, False) == 10
    assert human_to_bytes('1MB', None, False) == 1048576



# Generated at 2022-06-24 21:08:32.098392
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('Checking function human_to_bytes')
    assert human_to_bytes('1Kb', isbits=True) == 1024



# Generated at 2022-06-24 21:08:37.114868
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        test_case_0()
    except Exception as e:
        raise Exception(e.message + "Test Case failed: Lenient lowercase")

# Generated at 2022-06-24 21:08:46.889497
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048, "Should be equal 2048"
    assert human_to_bytes('2k') == 2048, "Should be equal 2048"
    assert human_to_bytes('2kB') == 2048, "Should be equal 2048"
    assert human_to_bytes('2KB') == 2048, "Should be equal 2048"
    assert human_to_bytes('2Kb') == 2048, "Should be equal 2048"
    assert human_to_bytes('2Kb', isbits=True) == 2048, "Should be equal 2048"
    assert human_to_bytes('2kb', isbits=True) == 2048, "Should be equal 2048"
    assert human_to_bytes('2K', isbits=True) == 2048, "Should be equal 2048"

# Generated at 2022-06-24 21:08:56.503479
# Unit test for function bytes_to_human
def test_bytes_to_human():

    # Object
    obj = bytes_to_human
    assert len(obj.__name__) >= 1
    assert obj.__doc__ is not None
    assert len(obj.__doc__) >= 1

    # Test function
    assert bytes_to_human(1, True) == '1.00 bits'

    assert bytes_to_human(2, False) == '2.00 Bytes'
    assert bytes_to_human(2, True) == '2.00 bits'

    assert bytes_to_human(1024, False) == '1.00 KB'
    assert bytes_to_human(1024, True) == '1.00 Kbits'

    assert bytes_to_human(1024**2, False) == '1.00 MB'

# Generated at 2022-06-24 21:09:03.624716
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['fastEthernet']) == ['fastethernet']
    assert lenient_lowercase(['GigabitEthernet', 2]) == ['gigabitethernet', 2]
    assert lenient_lowercase(['Ethernet3/1', 'b', 'C']) == ['ethernet3/1', 'b', 'C']



# Generated at 2022-06-24 21:09:11.656679
# Unit test for function human_to_bytes
def test_human_to_bytes():

    assert(human_to_bytes('2K') == 2048)
    assert(human_to_bytes('2M') == 2097152)
    assert(human_to_bytes('2G') == 2147483648)
    assert(human_to_bytes('2T') == 2199023255552)
    assert(human_to_bytes('2P') == 2251799813685248)
    assert(human_to_bytes('2E') == 2305843009213693952)
    assert(human_to_bytes('2Z') == 2361183241434822606848)
    assert(human_to_bytes('2Y') == 2417851639229258349412352)
    assert(human_to_bytes('2KB') == 2048)

# Generated at 2022-06-24 21:09:16.516920
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1]
    assert lenient_lowercase(['A', 'B', 'C', 1]) == ['a', 'b', 'c', 1]


# Generated at 2022-06-24 21:09:27.888127
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('Test function human_to_bytes')

# Generated at 2022-06-24 21:09:38.585585
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # test cases
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1000) == '1000.00 B'
    assert bytes_to_human(1024, unit='kb') == '1.00 kb'
    assert bytes_to_human(1000, unit='kb') == '1000.00 B'
    assert bytes_to_human(1000150, unit='kb') == '976.82 kb'
    assert bytes_to_human(1000150) == '976.82 KB'
    assert bytes_to_human(1000150, unit='k') == '976.82 k'
    assert bytes_to_human(1000150, unit='b') == '1000.00 b'

# Generated at 2022-06-24 21:09:46.515749
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = []
    var_0 = lenient_lowercase(list_0)
    assert isinstance(var_0, list)
    assert var_0 == []
    list_1 = [1, 2, 3, 4, "string", True, False, None]
    var_1 = lenient_lowercase(list_1)
    assert isinstance(var_1, list)
    assert var_1 == [1, 2, 3, 4, 'string', True, False, None]



# Generated at 2022-06-24 21:09:54.260493
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("Testing: human_to_bytes()")

    # test normal conversion
    print(human_to_bytes('1K'))
    print(human_to_bytes('1K', False))
    print(human_to_bytes('1K', False, False))
    print(human_to_bytes('1k', False, False))
    print(human_to_bytes('1kb', False, True))
    print(human_to_bytes('1Kb', False, True))

    print(human_to_bytes('1Mb', False, True))
    print(human_to_bytes('1mb', False, True))
    print(human_to_bytes('1Mb', False, True))
    print(human_to_bytes('10M', False, True))

    # test unit conversion

# Generated at 2022-06-24 21:09:58.158043
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 131072
    assert human_to_bytes('1Mb', isbits=True) == 131072
    assert human_to_bytes(1024, default_unit='K') == 1
    assert human_to_bytes('2M', default_unit='K') == 2
    # We would be expecting this to raise an exception, but instead it returns the same as the
    # previous test.
    # assert human_to_bytes('1M', default_unit='K') == 2



# Generated at 2022-06-24 21:10:03.501602
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # Test with default arguments(no arguments)
    result = human_to_bytes()
    assert result is None

    # Test with valid numbers
    result = human_to_bytes('10M')
    assert result == 10485760

    result = human_to_bytes('10MB')
    assert result == 10485760

    result = human_to_bytes('1KB')
    assert result == 1024

    result = human_to_bytes('10mb')
    assert result == 10485760

    result = human_to_bytes('10mb', isbits=True)
    assert result == 10485760 * 8

    result = human_to_bytes('1KB', isbits=True)
    assert result == 1024 * 8

    # Test with non-ascii strings

# Generated at 2022-06-24 21:10:10.545649
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = []
    list_0.append(None)
    expected = [None]
    var_0 = lenient_lowercase(list_0)
    if var_0 != expected:
        raise Exception("FAILED: lenient_lowercase(list_0) expected {} got {}".format(expected, var_0))
    else:
        print("PASSED: lenient_lowercase(list_0) returned {}".format(var_0))


# Generated at 2022-06-24 21:10:20.965216
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = [1,2,3,4]
    var_0 = lenient_lowercase(list_0)
    assert var_0 == list_0

    list_0 = [1,'a',3,4]
    var_0 = lenient_lowercase(list_0)
    assert var_0 == [1,'a',3,4]

    list_0 = ['a', 'B', 'c']
    var_0 = lenient_lowercase(list_0)
    assert var_0 == ['a','b','c']

    list_0 = ['a','b','c']
    var_0 = lenient_lowercase(list_0)
    assert var_0 == ['a','b','c']

    list_0 = []
    var_0 = lenient_lowercase(list_0)


# Generated at 2022-06-24 21:10:34.886367
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''Test cases for function bytes_to_human'''
    assert bytes_to_human(1048576) == '1.00 MB'
    assert bytes_to_human(1048576, unit='kb') == '1024.00 KB'
    assert bytes_to_human(1048576, unit='kb', isbits=True) == '8388608.00 Kb'
    assert bytes_to_human(104847, unit='kb') == '102.26 KB'
    assert bytes_to_human(104847, unit='kb', isbits=True) == '8387776.00 Kb'
    assert bytes_to_human(104847, unit='mb', isbits=True) == '81926.41 Mb'

# Generated at 2022-06-24 21:10:43.727519
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', default_unit='B') == 10485760
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10', default_unit='M') == 10485760
    assert human_to_bytes('10b') == 1
    assert human_to_bytes('10b', isbits=True) == 10
    assert human_to_bytes('10.5M') == 10485760
    assert human_to_bytes('10.5') == 11


# Generated at 2022-06-24 21:10:54.055913
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # 1K - Kilobyte (1000 bytes)
    assert human_to_bytes('1K') == 1000
    # 1Ki - Kibibyte (1024 bytes)
    assert human_to_bytes('1Ki') == 1024
    # 1M - Megabyte (1000000 bytes)
    assert human_to_bytes('1M') == 1000000
    # 1Mi - Mebibyte (1048576 bytes)
    assert human_to_bytes('1Mi') == 1048576
    # 1B - Bytes (1 bytes)
    assert human_to_bytes('1B') == 1
    # 1Bi - Bytes (1 bytes)
    assert human_to_bytes('1Bi') == 1
    # 1.2M - Megabyte (1200000 bytes)
    assert human_to_bytes('1.2M')

# Generated at 2022-06-24 21:11:02.768880
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1') == 1)
    assert(human_to_bytes('0') == 0)
    assert(human_to_bytes('2.5K') == 2560)
    assert(human_to_bytes('2.5k') == 2560)
    assert(human_to_bytes('2.5kb') == 2560)
    assert(human_to_bytes('2.5Mb') == 262144)
    assert(human_to_bytes('2.5MB') == 262144)
    assert(human_to_bytes('2.5mb') == 262144)
    assert(human_to_bytes('2.5g', 'b') == 268435456)
    assert(human_to_bytes('2.5Gb', 'B') == 268435456)

# Generated at 2022-06-24 21:11:14.353803
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1, 'K', True) == 1024
    assert human_to_bytes(2, 'K', True) == 2048
    assert human_to_bytes(1, 'M', True) == 1048576
    assert human_to_bytes(1, 'G', True) == 1073741824
    assert human_to_bytes(1, 'T', True) == 1099511627776
    assert human_to_bytes(1, 'P', True) == 1125899906842624
    assert human_to_bytes(1, 'E', True) == 1152921504606847000
    assert human_to_bytes(1, 'Z', True) == 1180591620717411300000
    assert human_to_bytes(1, 'Y', True) == 12089258196146292000000000


# Generated at 2022-06-24 21:11:24.139659
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1b') == 1

    # testing bits
    assert human_to_bytes('1MB', isbits=True) == 1048576
    assert human_to_bytes('1KB', isbits=True) == 1024
    assert human_to_bytes('1B', isbits=True) == 1
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1b') == 1

# Generated at 2022-06-24 21:11:32.976508
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print("Testing bytes_to_human")
    test_input_0 = [1, '2', 3]
    test_input_1 = [4, '5', 6]
    test_input_2 = ['7', '8', 9]
    expected_0 = ['1 B', '2 B', '3 B']
    expected_1 = ['4 bytes', '5 bytes', '6 bytes']
    expected_2 = ['7 bits', '8 bits', '9 bits']

    print("Input list: ", test_input_0)
    print("Expected output: ", expected_0)
    print("Actual output: ", bytes_to_human(test_input_0[0]))
    print("Input list: ", test_input_1)
    print("Expected output: ", expected_1)

# Generated at 2022-06-24 21:11:41.646776
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # Test with default value for isbits and unit
    assert bytes_to_human(0) == '0 Bytes'
    assert bytes_to_human(10) == '10 Bytes'
    assert bytes_to_human(1023) == '1023 Bytes'
    assert bytes_to_human(1024) == '1 KB'
    assert bytes_to_human(1024**2) == '1 MB'
    assert bytes_to_human(1024**3) == '1 GB'
    assert bytes_to_human(1024**4) == '1 TB'
    assert bytes_to_human(1024**5) == '1 PB'
    assert bytes_to_human(1024**6) == '1 EB'
    assert bytes_to_human(1024**7) == '1 ZB'

# Generated at 2022-06-24 21:11:51.208911
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = {
        '1KB': 1024,
        '1K': 1024,
        '1M': 1048576,
        '1MB': 1048576,
        '1G': 1073741824,
        '1GB': 1073741824,
        '1T': 1099511627776,
        '1TB': 1099511627776
    }
    for key, value in result.items():
        assert human_to_bytes(key) == value
        assert human_to_bytes(key, 'B') == value
        assert human_to_bytes(key, 'b', isbits=True) == value
        assert human_to_bytes(value, 'B') == value
        assert human_to_bytes(value, 'b', isbits=True) == value



# Generated at 2022-06-24 21:11:58.540695
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Testcase 1
    # Tested value returned as expected
    list_1 = ['Test']
    var_1 = lenient_lowercase(list_1)

    assert var_1 == ['test']

    # Testcase 2
    # Tested value returned as expected
    list_2 = ['TEST', 1, 2]
    var_2 = lenient_lowercase(list_2)

    assert var_2 == ['test', 1, 2]

    # Testcase 3
    # Tested value returned as expected
    list_3 = ['TEST']
    var_3 = lenient_lowercase(list_3)

    assert var_3 == ['test']

test_case_0()

# Generated at 2022-06-24 21:12:07.381464
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = []
    var_0 = lenient_lowercase(list_0)
    assert var_0 == []

    list_1 = [1, 'a', 'A', 'B']
    var_0 = lenient_lowercase(list_1)
    assert var_0 == [1, 'a', 'A', 'B']


# Generated at 2022-06-24 21:12:11.264372
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = []
    var_0 = lenient_lowercase(list_0)
    list_1 = ['AbCdEf', [1, 2, 3], {'abc': '123'}]
    var_1 = lenient_lowercase(list_1)
    assert var_0 == []
    assert var_1 == ['abcdef', [1, 2, 3], {'abc': '123'}]


# Generated at 2022-06-24 21:12:17.576376
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("#### Test #1: human_to_bytes() with default_unit=None and isbits=False")
    unit_test_values = [
        ('10M', 10485760),
        ('5.5K', 5632),
        ('1MB', 1048576),
        ('1.1kB', 1130),
        ('1.5B', 1),
        ('0Mb', 0),
        ('1b', 1),
        ('100.444444444444', 100),
    ]

    for unit_test_value in unit_test_values:
        print("Input:     %s" % unit_test_value[0])
        print("Output:    %i" % human_to_bytes(unit_test_value[0]))

# Generated at 2022-06-24 21:12:18.488037
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1k', default_unit='b') == 8


# Generated at 2022-06-24 21:12:20.427469
# Unit test for function human_to_bytes
def test_human_to_bytes():
    number = "1M"
    result = human_to_bytes(number)
    assert result == 1048576


# Generated at 2022-06-24 21:12:31.626427
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert bytes_to_human(1048576, isbits=False, unit='M') == '1.00 MB'
    assert bytes_to_human(1048576, isbits=False, unit='m') == '1.00 MB'
    assert bytes_to_human(1048576, isbits=False, unit='Mb') == '1.00 MB'
    assert bytes_to_human(1048576, isbits=False, unit='MB') == '1.00 MB'
    assert bytes_to_human(1048576, isbits=False, unit='mb') == '1.00 MB'
    assert bytes_to_human(1048576, isbits=False, unit='Mb') == '1.00 MB'

# Generated at 2022-06-24 21:12:40.319620
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('45b') == 45, "Returned value must be 45"
    assert human_to_bytes('45B') == 45, "Returned value must be 45"
    assert human_to_bytes('45bit') == 45, "Returned value must be 45"
    assert human_to_bytes('45byte', isbits=False) == 45, "Returned value must be 45"
    assert human_to_bytes('45bytes') == 45, "Returned value must be 45"
    assert human_to_bytes('45bit', isbits=True) == 45, "Returned value must be 45"
    assert human_to_bytes('45kB') == 45 * 1024, "Returned value must be 45 KB"

# Generated at 2022-06-24 21:12:49.392877
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Bytes test cases - returns a number of bytes
    assert human_to_bytes(0) == 0
    assert human_to_bytes(1) == 1
    assert human_to_bytes(10) == 10
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('1byte') == 1
    assert human_to_bytes('10bytes') == 10
    assert human_to_bytes('1Bytes') == 1
    assert human_to_bytes('10Bytes') == 10
    assert human_to_bytes('1BYTE') == 1
    assert human_to_bytes('10BYTE') == 10
    assert human_to

# Generated at 2022-06-24 21:13:00.405262
# Unit test for function human_to_bytes
def test_human_to_bytes():
    def test_human_to_bytes_value(in_str, unit, isbits, out_int):
        if human_to_bytes(in_str, unit, isbits) == out_int:
            return True
        else:
            return False


# Generated at 2022-06-24 21:13:08.752418
# Unit test for function human_to_bytes
def test_human_to_bytes():
    bytes_0 = human_to_bytes('0B')
    bytes_1 = human_to_bytes('0Bb')
    bytes_2 = human_to_bytes('0', 'B')
    bytes_3 = human_to_bytes('0', 'Bb')
    bytes_4 = human_to_bytes('0', 'b')
    bytes_5 = human_to_bytes('0', 'bb')
    bytes_6 = human_to_bytes('1', 'bb')
    bytes_7 = human_to_bytes('12', 'bb')
    bytes_8 = human_to_bytes('1b')
    bytes_9 = human_to_bytes('1bb')
    bytes_10 = human_to_bytes('12b')
    bytes_11 = human_to_bytes('12bb')

# Generated at 2022-06-24 21:13:21.287706
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = []
    var_0 = lenient_lowercase(list_0)
    assert(var_0 == [])
    list_1 = ['', 'aBc', '123', 'xyz']
    var_1 = lenient_lowercase(list_1)
    assert(var_1 == ['', 'abc', '123', 'xyz'])
    list_2 = [None, 'aBc', '123', None, 'xyz']
    var_2 = lenient_lowercase(list_2)
    assert(var_2 == [None, 'abc', '123', None, 'xyz'])
    list_3 = [0, 1, 2]
    var_3 = lenient_lowercase(list_3)
    assert(var_3 == [0, 1, 2])
    list

# Generated at 2022-06-24 21:13:23.439010
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    var_0 = []
    list_0 = var_0
    var_1 = lenient_lowercase(list_0)
    assert var_1 == []


# Generated at 2022-06-24 21:13:24.249731
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_case_0()

# Generated at 2022-06-24 21:13:25.888076
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase('B') == 'b'
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(1) == 1


# Generated at 2022-06-24 21:13:35.200519
# Unit test for function human_to_bytes
def test_human_to_bytes():
    input_0 = '1MB'
    output = human_to_bytes(input_0)
    assert output == 1048576, 'Failed to convert human_to_bytes(%s)' % input_0

    input_1 = '10M'
    output = human_to_bytes(input_1)
    assert output == 10485760, 'Failed to convert human_to_bytes(%s)' % input_1

    input_2 = '10MBb'
    output = human_to_bytes(input_2)
    assert output == 10485760, 'Failed to convert human_to_bytes(%s)' % input_2

    input_3 = '10MBb'
    output = human_to_bytes(input_3, isbits=True)

# Generated at 2022-06-24 21:13:36.319917
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Init test class
    test_class = test_case_0()


# Generated at 2022-06-24 21:13:45.095938
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == human_to_bytes(2, 'K')
    assert human_to_bytes('0K') == human_to_bytes(0, 'K')
    assert human_to_bytes('1M') == human_to_bytes(1, 'M')
    assert human_to_bytes('1M', default_unit='K') == human_to_bytes(1, 'M')
    assert human_to_bytes('1', default_unit='K') == human_to_bytes(1, 'K')
    try:
        human_to_bytes('abc')
        assert False
    except ValueError:
        pass
    assert human_to_bytes('2K', isbits=True) == human_to_bytes(2, 'K', isbits=True)
    assert human_to_bytes

# Generated at 2022-06-24 21:13:51.026852
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10', 'M') == 10 * (1 << 20)
    assert human_to_bytes('1K') == 1 * (1 << 10)
    assert human_to_bytes('1Kb') == 1 * (1 << 10)
    assert human_to_bytes('1Mb', isbits=True) == 1 * (1 << 20)
    assert human_to_bytes('1Mb') == 1 * (1 << 20)
    assert human_to_bytes(1, 'K', isbits=True) == 1 * (1 << 10)



# Generated at 2022-06-24 21:13:56.454605
# Unit test for function lenient_lowercase

# Generated at 2022-06-24 21:14:02.128175
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        test_case_0()
    except Exception as err:
        print('Test case 0 failed: {}'.format(err.args))
        return
    else:
        print('Test case 0 passed')

    try:
        raise Exception('Test case 1 failed')
    except Exception as err:
        pass
    else:
        print('Test case 1 failed')
    try:
        raise Exception('Test case 2 failed')
    except Exception as err:
        pass
    else:
        print('Test case 2 failed')
    try:
        raise Exception('Test case 3 failed')
    except Exception as err:
        pass
    else:
        print('Test case 3 failed')
    try:
        raise Exception('Test case 4 failed')
    except Exception as err:
        pass
    else:
        print('Test case 4 failed')

# Generated at 2022-06-24 21:14:16.762772
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('15Mb') == 15360000
    assert human_to_bytes('15MB') == 15728640
    assert human_to_bytes(21.5, 'K') == 22050
    assert human_to_bytes(4.4, 'Mb', isbits=True) == 46080
    assert human_to_bytes('1TB') == 1099511627776
    assert human_to_bytes('.004Tb', isbits=True) == 4294967296
    assert human_to_bytes('4') == 4
    assert human_to_bytes('4b') == 1


# Generated at 2022-06-24 21:14:25.838556
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = []
    var_0 = lenient_lowercase(list_0)
    assert len(var_0) == 0
    list_1 = ['1234']
    var_1 = lenient_lowercase(list_1)
    assert len(var_1) == 1
    assert var_1[0] == '1234'
    list_2 = ['abcd', 'efgh']
    var_2 = lenient_lowercase(list_2)
    assert len(var_2) == 2
    assert var_2[0] == 'abcd'
    assert var_2[1] == 'efgh'
    list_3 = ['ABCD', 'EFGH']
    var_3 = lenient_lowercase(list_3)
    assert len(var_3) == 2
    assert var_

# Generated at 2022-06-24 21:14:33.915907
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = []
    var_0 = lenient_lowercase(list_0)
    assert var_0 == list_0

    list_1 = [1, '456', '123', 'AbC', 'aBc', -789, '0', '', None, float('nan')]
    var_1 = lenient_lowercase(list_1)
    assert var_1 == [1, '456', '123', 'abc', 'abc', -789, '0', '', None, float('nan')]
    try:
        var_assert = var_1[4]
    except Exception:
        var_assert = None
    assert var_assert == 'abc'

    list_2 = ['456', 'NB', 2.3, 'AbC', 'A', 'bC', 987, None, 'Nb']


# Generated at 2022-06-24 21:14:38.324443
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['abc', 'ABC', 1, '123', '-123']) == ['abc', 'abc', 1, '123', '-123']


# Generated at 2022-06-24 21:14:47.900050
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.0k') == 1024
    assert human_to_bytes('100') == 100
    assert human_to_bytes('500m') == 524288000
    assert human_to_bytes('6g') == 68719476736
    assert human_to_bytes('2.5TB') == 274877906944
    assert human_to_bytes('3K') == 3072
    assert human_to_bytes('1.0k', 'b') == 1024
    assert human_to_bytes('1.0k', 'b', True) == 8192
    assert human_to_bytes('1.0k', 'B') == 1024
    assert human_to_bytes('1.0k', 'B', True) == 1024
    assert human_to_bytes('1.0M', 'Mb')

# Generated at 2022-06-24 21:14:54.934372
# Unit test for function human_to_bytes
def test_human_to_bytes():
    list_0 = []
    var_0 = lenient_lowercase(list_0)
    assert var_0 == []

    assert human_to_bytes("1B") == 1
    assert human_to_bytes("2K") == 2048
    assert human_to_bytes("3M") == 3145728
    assert human_to_bytes("4G") == 4294967296
    assert human_to_bytes("5T") == 549755813888
    assert human_to_bytes("6P") == 67553994410557440
    assert human_to_bytes("7E") == 8031810176
    assert human_to_bytes("8Z") == 90123456789012345
    assert human_to_bytes("9Y") == 100900000000000000

# Generated at 2022-06-24 21:15:03.919566
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """ """
    res = human_to_bytes("1")
    assert res == 1, "expected 1 got %s" % res
    res = human_to_bytes("1.0")
    assert res == 1, "expected 1 got %s" % res
    res = human_to_bytes("1K")
    assert res == 1024, "expected 1024 got %s" % res
    res = human_to_bytes("K")
    assert res == 1024, "expected 1024 got %s" % res
    res = human_to_bytes("1.0K")
    assert res == 1024, "expected 1024 got %s" % res
    res = human_to_bytes("1.5K")
    assert res == 1536, "expected 1536 got %s" % res
    res = human_to_bytes("1.5MB")
   

# Generated at 2022-06-24 21:15:12.313875
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3], "Incorrect list"
    assert lenient_lowercase([1, "A", 3]) == [1, "A", 3], "Incorrect list"
    assert lenient_lowercase(["A", "B", "C"]) == ["A", "B", "C"], "Incorrect list"
    assert lenient_lowercase(["A", "B", "C"]) != ["a", "b", "c"], "Incorrect list"
    assert lenient_lowercase(["ABC", "DEF", "GHI"]) != ["abc", "def", "ghi"], "Incorrect list"
    assert lenient_lowercase(["ABC", "DEF", "GHI"]) == ["ABC", "DEF", "GHI"], "Incorrect list"




# Generated at 2022-06-24 21:15:14.710149
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert len(lenient_lowercase.__doc__) > 0

# Generated at 2022-06-24 21:15:24.248403
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # Check basic functionality
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('100B') == 100
    assert human_to_bytes('1023B') == 1023
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1KiB') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MiB') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1GiB') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1TiB') == 1099511627776

    # Check bits functionality

# Generated at 2022-06-24 21:15:40.725755
# Unit test for function human_to_bytes

# Generated at 2022-06-24 21:15:48.252777
# Unit test for function lenient_lowercase

# Generated at 2022-06-24 21:15:49.992998
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Function can not be called with a non list type
    with pytest.raises(AttributeError):
        test_case_0()



# Generated at 2022-06-24 21:15:53.141461
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    num = 5
    if test_case_0() == num:
        print("TEST 0 / 1")
        return True
    else:
        print("TEST 0 / 1")
        return False



# Generated at 2022-06-24 21:16:01.017655
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = ['N', 'n', 'aN', 'an', 'An', 'AN', 'A', 'a']
    var_0 = lenient_lowercase(list_0)
    #assert var_0 == ['n', 'n', 'an', 'an', 'an', 'an', 'a', 'a']
    #assert len(var_0) == 8
    list_1 = ['n', 'aN', 'An', 'A']
    var_1 = lenient_lowercase(list_1)
    #assert var_1 == ['n', 'an', 'an', 'a']
    #assert len(var_1) == 4
    list_2 = ['a', 'n', 'N', 'A', 'an', 'AN', 'aN', 'An']
    var_2 = lenient_lowercase

# Generated at 2022-06-24 21:16:08.362112
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Check if return value equals expected value (checks if function returns expected values when given list as a parameter)
    assert lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c'], "Expected return value: ['a', 'b', 'c']"
    # Check if return value equals expected value (checks if function returns expected values when given list as a parameter)
    assert lenient_lowercase(['1', '2', '3']) == ['1', '2', '3'], "Expected return value: ['1', '2', '3']"
    # Check if return value equals expected value (checks if function returns expected values when given list as a parameter)
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3], "Expected return value: [1, 2, 3]"

# Generated at 2022-06-24 21:16:13.804080
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_1 = ['Test', '123', 'Asdf', 'Qwerty']
    list_1_ans = ['test', '123', 'asdf', 'qwerty']

    var_1 = lenient_lowercase(list_1)
    assert var_1 == list_1_ans, "Expected different values"



# Generated at 2022-06-24 21:16:17.723612
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = ['A', 'B', 'C', 'D']
    var_1 = lenient_lowercase(list_0) == ['a', 'b', 'c', 'd']
    if var_1:
        pass
    else:
        raise Exception("Test case failed.")


# Generated at 2022-06-24 21:16:26.501855
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1B") == 1
    assert human_to_bytes("10B") == 10
    assert human_to_bytes("1K") == 1024
    assert human_to_bytes("10K") == 10240
    assert human_to_bytes("10K", default_unit="K") == 10240
    assert human_to_bytes("10M") == 10485760
    assert human_to_bytes("1G") == 1073741824
    assert human_to_bytes("1T") == 1099511627776
    assert human_to_bytes("1P") == 1125899906842624
    assert human_to_bytes("1Mb") == 2097152
    assert human_to_bytes("1Mb", isbits=True) == 2097152

# Generated at 2022-06-24 21:16:27.793008
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')



# Generated at 2022-06-24 21:16:42.404645
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase('1K') == '1k'
    assert lenient_lowercase('1mb') == '1mb'
    assert lenient_lowercase(['1mb', '1MB', '1Mb']) == ['1mb', '1mb', '1mb']
    # Just make sure no exception is raised
    lenient_lowercase(['1mb', '1MB', '1Mb', 123])
