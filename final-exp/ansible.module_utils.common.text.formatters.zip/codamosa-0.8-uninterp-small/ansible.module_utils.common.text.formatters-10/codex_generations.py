

# Generated at 2022-06-24 21:07:02.830043
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K', default_unit='K') == 1024
    assert human_to_bytes('1M', unit='K') == 1024
    assert human_to_bytes(10, 'K') == 10240
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1048576', isbits=True) == 1048576
    assert human_to_bytes(10, unit='Mb') == 10485760
    assert human_to_bytes(10, unit='Mb', isbits=True) == 10485760
    assert human_to_bytes(1, unit='K') == 1024

# Generated at 2022-06-24 21:07:07.159850
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert 0 == human_to_bytes('0')
    assert 0 == human_to_bytes('0.0')
    assert 0 == human_to_bytes('0.0B')
    # Lowercase range keys are supported
    assert 1 == human_to_bytes('1 ', 'K')
    assert 1 == human_to_bytes('1 ', 'k')
    # It is case sensitive
    assert 1 == human_to_bytes('1b')
    assert 1 == human_to_bytes('1B')
    # Bits are supported
    assert 1 == human_to_bytes('1b', isbits=True)
    assert 1 == human_to_bytes('1B', isbits=True)
    # Bits size ranges are supported
    assert 1 == human_to_bytes('1 ', 'B', isbits=True)

    # Test case for bytes

# Generated at 2022-06-24 21:07:17.383074
# Unit test for function human_to_bytes
def test_human_to_bytes():
    human_bytes = '100b'
    human_bits = '100B'
    human_bytes_with_suffix = '100b'
    human_bits_with_suffix = '100B'
    # default value of isbits is False
    assert human_to_bytes(human_bytes) == 100, "bytes must be converted to integer when isbits=False"
    assert human_to_bytes(human_bits) == 8, "bits must be converted to integer when isbits=False"
    assert human_to_bytes(human_bytes_with_suffix) == 100, "bytes must be converted to integer when isbits=False"
    assert human_to_bytes(human_bits_with_suffix) == 8, "bits must be converted to integer when isbits=False"
    # setting isbits to True, function convert bits to integer

# Generated at 2022-06-24 21:07:28.393647
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # positive tests
    assert human_to_bytes('12') == 12
    assert human_to_bytes('0') == 0
    assert human_to_bytes('2.2k') == 2248
    assert human_to_bytes('2.2K') == 2248
    assert human_to_bytes('2.2M') == 2359296
    assert human_to_bytes('2.2G') == 24081774383
    assert human_to_bytes('0.1E') == 1125899906842620
    assert human_to_bytes('2.2') == 2
    assert human_to_bytes('2.2G', 'G') == 24081774383

    # negative tests

# Generated at 2022-06-24 21:07:35.640170
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # Test 1: check human_to_bytes('10K')
    try:
        assert human_to_bytes('10K') == 10240
    except AssertionError:
        print("Test 1: Expecting 10240 got: %s" % human_to_bytes('10K'))
        raise

    # Test 2: check human_to_bytes('10Kb')
    try:
        assert human_to_bytes('10Kb', isbits=True) == 10240
    except AssertionError:
        print("Test 2: Expecting 10240 got: %s" % human_to_bytes('10Kb'))
        raise

    # Test 3: check human_to_bytes('10')

# Generated at 2022-06-24 21:07:45.880353
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Positive test
    int_0 = human_to_bytes('10')
    assert int_0 == 10
    str_0 = bytes_to_human(int_0)
    assert str_0 == '10.00 Bytes'
    str_1 = bytes_to_human(int_0, unit='K')
    assert str_1 == '0.00 KB'
    # Negative test
    try:
        int_1 = human_to_bytes('invalid')
    except Exception as e:
        assert str(e) == "human_to_bytes() can't interpret following string: invalid"

# Generated at 2022-06-24 21:07:49.088859
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert 'test string'.lower() == lenient_lowercase('test string')
    assert ['test', 'string', 'list'].lower() == lenient_lowercase(['test', 'string', 'list'])


# Generated at 2022-06-24 21:07:57.229285
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('0') == 0  # Simple integer conversion
    assert human_to_bytes('2K') == 2048  # simple 2K case
    assert human_to_bytes('0xabc') == 2748  # hex value. should be integer
    assert human_to_bytes('-30M') == -31457280  # negative value, should be integer
    assert human_to_bytes('10B') == 10  # case insensitive. should be integer
    assert human_to_bytes('1Mb') == 1048576  # bits case
    # ERROR cases
    try:
        human_to_bytes('2Kb')
    except ValueError as e:
        assert 'expect Kb or Kbit' in str(e)

# Generated at 2022-06-24 21:07:57.974266
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert test_case_0() == -652


# Generated at 2022-06-24 21:08:00.706409
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = -652
    var_0 = lenient_lowercase(int_0)
    assert var_0 == int_0, "var_0 ({0}) != int_0 ({1})".format(var_0, int_0)



# Generated at 2022-06-24 21:08:12.838065
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1') == 1)
    assert(human_to_bytes('1B') == 1)
    assert(human_to_bytes('1K') == 1024)
    assert(human_to_bytes('1M') == 1048576)
    assert(human_to_bytes('1G') == 1073741824)
    assert(human_to_bytes('1T') == 1099511627776)
    assert(human_to_bytes('1P') == 1125899906842624)
    assert(human_to_bytes('1E') == 1152921504606846976)
    assert(human_to_bytes('1Z') == 1180591620717411303424)
    assert(human_to_bytes('1Y') == 1208925819614629174706176)
   

# Generated at 2022-06-24 21:08:15.731701
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = -652
    var_0 = lenient_lowercase(int_0)
    assert var_0 == -652
    string_0 = 'Mb'
    var_1 = lenient_lowercase(string_0)
    assert var_1 == 'mb'



# Generated at 2022-06-24 21:08:26.734976
# Unit test for function human_to_bytes
def test_human_to_bytes():
    string_with_unit = '2.3G'
    string_without_unit = '2.3'

    assert(human_to_bytes(string_with_unit, 'M') == float(2.3) * 1024 * 1024)
    assert(human_to_bytes(string_without_unit, 'M') == float(2.3) * 1024 * 1024)
    assert(human_to_bytes(string_with_unit, 'K') == float(2.3) * 1024)
    assert(human_to_bytes(string_without_unit, 'K') == float(2.3) * 1024)
    assert(human_to_bytes(string_with_unit, 'B') == float(2.3) * 1024 * 1024 * 1024)

# Generated at 2022-06-24 21:08:36.690768
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    print('Testing lenient_lowercase...')
    str_0 = 'unittesttest'
    str_1 = 'unittesttest'
    str_2 = 'unittesttest'
    str_3 = 'unittesttest'
    dict_0 = {
        str_0.lower(): lenient_lowercase(str_0),
        str_1.lower(): lenient_lowercase(str_1),
        str_2.lower(): lenient_lowercase(str_2),
        str_3.lower(): lenient_lowercase(str_3),
    }
    for key, value in iteritems(dict_0):
        print(value)

# Generated at 2022-06-24 21:08:46.514534
# Unit test for function human_to_bytes

# Generated at 2022-06-24 21:08:51.941928
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test_0
    print('Test 0')
    input_0 = '2K'
    expected_output_0 = 2048
    actual_output_0 = human_to_bytes(input_0)

    assert actual_output_0 == expected_output_0, 'Test 0 failed!'
    print('Test 0 passed.')

    # test_1
    print('Test 1')
    input_1 = '2.5K'
    expected_output_1 = 2560
    actual_output_1 = human_to_bytes(input_1)

    assert actual_output_1 == expected_output_1, 'Test 1 failed!'
    print('Test 1 passed.')

    # test_2
    print('Test 2')
    input_2 = '2.5KB'
    expected_output_2 = 2560
    actual_

# Generated at 2022-06-24 21:08:58.200308
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1TB') == 1099511627776
    assert human_to_bytes('1PB') == 1125899906842624
    assert human_to_bytes('1EB') == 1152921504606847000


# Generated at 2022-06-24 21:09:01.308116
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = human_to_bytes('10')
    expected = 10
    assert result == expected
    result = human_to_bytes('4K', isbits=False)
    expected = 4096
    assert result == expected


# Generated at 2022-06-24 21:09:06.334408
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Case 0
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    # Case 1
    assert human_to_bytes('10', 'M') == human_to_bytes(10, 'M')
    # Case 2
    assert human_to_bytes('10', 'K') == human_to_bytes(10, 'K')
    # Case 3
    assert human_to_bytes(10) == 10
    # Case 4
    assert human_to_bytes('10', 'K', True) == human_to_bytes(10, 'K', True)



# Generated at 2022-06-24 21:09:13.805788
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test for converting to bytes
    try:
        print(human_to_bytes('1MB'))
        print(human_to_bytes('1.2MB'))
        print(human_to_bytes('1.2'))
        print(human_to_bytes('1B', default_unit='B'))
        print(human_to_bytes('10M'))
        print(human_to_bytes(10, 'M'))
        print(human_to_bytes(10))
        print(human_to_bytes('3Gb', isbits=True))
    except ValueError as ex:
        print("Caught exception: %s" % ex)

    # Test for exceptions

# Generated at 2022-06-24 21:09:23.709962
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.0 KB') == 1024
    assert human_to_bytes('1.0 K') == 1024
    assert human_to_bytes('1.0 MB') == 1048576
    assert human_to_bytes('1.0 M') == 1048576
    assert human_to_bytes('1.0 GB') == 1073741824
    assert human_to_bytes('1.0 G') == 1073741824

# Generated at 2022-06-24 21:09:31.942000
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Unit tests for function human_to_bytes"""
    # Test 1: Format '22.0 MB'
    str_to_test = '22.0 MB'
    expected_result = human_to_bytes(str_to_test)
    expected_result_type = type(expected_result)
    assert expected_result == 23592960
    assert expected_result_type == int

    # Test 2: Format '100'
    str_to_test = '100'
    expected_result = human_to_bytes(str_to_test)
    expected_result_type = type(expected_result)
    assert expected_result == 100
    assert expected_result_type == int

    # Test 3: Format '100 KB'
    str_to_test = '100 KB'

# Generated at 2022-06-24 21:09:33.084763
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        test_case_0()
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-24 21:09:34.373455
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_case_0()


# Generated at 2022-06-24 21:09:41.283822
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = -652
    var_0 = lenient_lowercase(int_0)
    assert var_0 == int_0
    float_0 = 2.0
    var_1 = lenient_lowercase(float_0)
    assert var_1 == float_0
    var_2 = lenient_lowercase(int_0)
    assert var_2 == int_0
    str_0 = "THIS IS TEST CASE"
    var_3 = lenient_lowercase(str_0)
    assert var_3 == "this is test case"
    var_4 = lenient_lowercase(str_0)
    assert var_4 == "this is test case"


# Generated at 2022-06-24 21:09:51.166047
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Test function human_to_bytes '''
    # Test with bytes
    result_1 = human_to_bytes('2K')
    assert result_1 == 2048
    result_2 = human_to_bytes('1M')
    assert result_2 == 1048576
    result_3 = human_to_bytes('512B')
    assert result_3 == 512
    result_4 = human_to_bytes('2K', 'b')
    assert result_4 == 2048
    result_5 = human_to_bytes('1M', 'b')
    assert result_5 == 1048576
    result_6 = human_to_bytes('512b')
    assert result_6 == 512
    result_7 = human_to_bytes('32B')
    assert result_7 == 32
    result_8 = human_to_

# Generated at 2022-06-24 21:09:53.267595
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    print('Testing function lenient_lowercase')
    # Case 0
    print('Case 0')
    try:
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-24 21:10:00.123230
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test case with int
    int_0 = -652
    var_0 = lenient_lowercase(int_0)

    assert var_0 == int_0

    # Test case with string
    str_1 = "abCDe"
    var_1 = lenient_lowercase(str_1)

    assert var_1 == "abcde"

    # Test case with list
    list_2 = [1, 2, 3]
    var_2 = lenient_lowercase(list_2)

    assert var_2 == list_2

    list_3 = ['a', 'b', 'c']
    var_3 = lenient_lowercase(list_3)

    assert var_3 == ['a', 'b', 'c']


# Generated at 2022-06-24 21:10:11.442010
# Unit test for function human_to_bytes
def test_human_to_bytes():
    if human_to_bytes('1M') != 1024 * 1024:
        raise AssertionError("human_to_bytes() failed to convert 1M")
    if human_to_bytes(1, 'M') != 1024 * 1024:
        raise AssertionError("human_to_bytes() failed to convert 1M")
    if human_to_bytes('1M', default_unit='M') != 1024 * 1024:
        raise AssertionError("human_to_bytes() failed to convert 1M")
    if human_to_bytes('1.1M') != 1024 * 1024 + 1024 * 100:
        raise AssertionError("human_to_bytes() failed to convert 1.1M")
    if human_to_bytes('1.1M', default_unit='M') != 1024 * 1024 + 1024 * 100:
        raise AssertionError

# Generated at 2022-06-24 21:10:15.397275
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_value = -652
    string_value = 'Example of string value'
    list_of_values = [1, string_value, int_value]

    assert lenient_lowercase(int_value) == '-652'
    assert lenient_lowercase(string_value) == 'example of string value'
    assert lenient_lowercase(list_of_values) == [1, 'example of string value', '-652']



# Generated at 2022-06-24 21:10:19.816045
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """check if the function lenient_lowercase works as expected,
    input: int
    output: str
    """
    assert test_case_0().lower() == str(-652)



# Generated at 2022-06-24 21:10:27.056683
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    base_case = [1.4, 'StRiNg', ['list'], ('tuples',), {'dictionary': 'of keys'}, {2, 3, 4}]
    result = lenient_lowercase(base_case)
    test_result = [1.4, 'string', ['list'], ('tuples',), {'dictionary': 'of keys'}, {2, 3, 4}]
    assert result == test_result, "%r != %r" % (result, test_result)



# Generated at 2022-06-24 21:10:38.647587
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('5B') == 5
    assert human_to_bytes('10b', isbits=True) == 1
    assert human_to_bytes('5.5KB') == 5632
    assert human_to_bytes('10Mb', isbits=True) == 12582912
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('2Tb', isbits=True) == 2199023255552
    assert human_to_bytes('2.2Pb', isbits=True) == 2417851639229258349412352
    assert human_to_bytes('2.2Pb', 'b') == 2417851639229258349412352
    assert human_to_bytes(2.2, 'Pb', True) == 241785

# Generated at 2022-06-24 21:10:39.969368
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = -652
    var_0 = lenient_lowercase(int_0)



# Generated at 2022-06-24 21:10:43.110883
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # Sample asserts
    assert human_to_bytes("1Mb", isbits=True) == 1048576
    assert human_to_bytes("4GB") == 4294967296
    assert human_to_bytes("1Gb") == 900000

# Generated at 2022-06-24 21:10:53.987280
# Unit test for function human_to_bytes
def test_human_to_bytes():
    str_in_bytes = "65B"
    str_in_bits = "65b"
    str_in_bytes_with_space = "65 B"
    str_in_bits_with_space = "65 b"
    str_in_bytes_upper_case = "65B"
    str_in_bits_upper_case = "65b"
    str_in_bytes_with_space_upper_case = "65 B"
    str_in_bits_with_space_upper_case = "65 b"
    str_in_bytes_no_unit = "65"
    int_in_bytes = 65
    invalid = "6c5b"

    # Testing str_in_bytes and str_in_bits
    assert human_to_bytes(str_in_bytes, isbits=False) == 65


# Generated at 2022-06-24 21:10:55.310961
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("10M") == human_to_bytes(10, "M"), "Error in human_to_bytes"


# Generated at 2022-06-24 21:10:56.828308
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    for case in range(0, 1):
        if case == 0:
            test_case_0()



# Generated at 2022-06-24 21:11:05.131482
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(None) is None
    assert human_to_bytes(None, "None") is None
    assert human_to_bytes('123') == 123
    test_input = [
        ('1K', 1024),
        ('1M', 1048576),
        ('1G', 1073741824),
        ('1KB', 1000),
        ('2M', 2000000),
        ('0.5Kb', 512),
        ('0.5MB', 512000),
        ('0.5GB', 512000000),
        ('0.5kb', 500),
        ('0.5Mb', 500000),
        ('0.5GB', 500000000),
        ('1.5Kb', 1536),
        ('1.5Mb', 1500000),
        ('1.5Gb', 1500000000)
    ]


# Generated at 2022-06-24 21:11:15.654215
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("\n[START] Test for human_to_bytes")
    try:
        result = human_to_bytes(12, 'KB')
        assert result == 12288
    except Exception as e:
        print(e)
    try:
        result = human_to_bytes('12KB')
        assert result == 12288
    except Exception as e:
        print(e)
    try:
        result = human_to_bytes('8MB')
        assert result == 8388608
    except Exception as e:
        print(e)
    try:
        result = human_to_bytes('8.5M')
        assert result == 8388608
    except Exception as e:
        print(e)

# Generated at 2022-06-24 21:11:27.585698
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('100M') == 104857600
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('2G') == 2147483648
    assert human_to_bytes('3Kb') == 3072
    assert human_to_bytes('4T') == 4398046511104
    assert human_to_bytes('5P') == 576460752303423488
    assert human_to_bytes('6E') == 72057594037927936
    assert human_to_bytes('7Z') == 8444249301319680256
    assert human_to_bytes('8Y') == 953674316406250000000


# Generated at 2022-06-24 21:11:32.542466
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    str_0 = 'A'
    str_1 = 'a'
    var_0 = lenient_lowercase(str_0)
    var_1 = lenient_lowercase(str_1)
    assert var_0 == 'a'
    assert var_1 == 'a'



# Generated at 2022-06-24 21:11:41.447359
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # assert lenient_lowercase(['sTrIng', 'StrINg']) == ['string', 'string']
    # assert lenient_lowercase(['sTrIng', 2, 'StrINg']) == ['string', 2, 'string']
    # assert lenient_lowercase(['sTrIng', 2, 'StrINg']) == ['string', 2, 'string']
    assert lenient_lowercase([7, 2, 'StrINg']) == [7, 2, 'string']
    # assert lenient_lowercase([7, 2, 'sTrIng']) == [7, 2, 'string']
    # assert lenient_lowercase([7, 1, 2, 'StrINg', 'sTrIng']) == [7, 1, 2, 'string', 'string']



# Generated at 2022-06-24 21:11:47.132298
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase('a') == 'a'
    assert lenient_lowercase('abc') == 'abc'
    assert lenient_lowercase(['a', 'A']) == ['a', 'a']
    assert lenient_lowercase(['a', 'A', 'b', 2, 3, {'a': 'A'}]) == ['a', 'a', 'b', 2, 3, {'a': 'A'}]
    assert lenient_lowercase(['a', ['a', 'A']]) == ['a', ['a', 'a']]
    assert lenient_lowercase(['a', ['a', ['a', 'A']]]) == ['a', ['a', ['a', 'a']]]

# Generated at 2022-06-24 21:11:50.751297
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert test_case_0() == -652


# Generated at 2022-06-24 21:11:53.709303
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = -652
    str_0 = '-652'
    var_0 = lenient_lowercase(int_0)
    assert var_0 == str_0



# Generated at 2022-06-24 21:12:03.686485
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10.5M') == 10485760
    assert human_to_bytes('10.5', 'M') == 10485760
    assert human_to_bytes('10.5 mb') == 1048576
    assert human_to_bytes('10.5Mb') == 1048576
    with pytest.raises(ValueError):
        human_to_bytes('10.5 M')
    with pytest.raises(ValueError):
        human_to_bytes('10.5 m')
    assert human_to_bytes(10.5, 'M') == 10485760
   

# Generated at 2022-06-24 21:12:09.074343
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1k") == 1024
    assert human_to_bytes("1mB") == 1048576
    assert human_to_bytes("1Mb") == 1048576
    assert human_to_bytes("1mb", isbits=True) == 1048576
    assert human_to_bytes("1Mb", isbits=True) == 1048576
    assert human_to_bytes("1MB", unit='B') == 1048576
    assert human_to_bytes("1MB", unit='b', isbits=True) == 1048576



# Generated at 2022-06-24 21:12:18.895892
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C', 1]) == ['a', 'b', 'c', 1]
    assert lenient_lowercase(['A', 'B', 'C', 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]
    assert lenient_lowercase(['A', 'B', 'C', 'Z', 'A', 'b', 'c', 'D']) == ['a', 'b', 'c', 'z', 'a', 'b', 'c', 'd']

# Generated at 2022-06-24 21:12:30.029419
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # Test case with bits being true
    assert human_to_bytes('877Mb', isbits=True) == 877000000

    # Test case with unit argument
    assert human_to_bytes(5, unit='G') == 5000000000

    # Test case with decimal number
    assert human_to_bytes('2.5G') == 2500000000

    # Test case with bytes being lowercase
    assert human_to_bytes('10B', default_unit='b') == 10

    # Test case with bits being lowercase
    assert human_to_bytes('20b') == 2

    # Test case with decimal number
    assert human_to_bytes('3.5k') == 3584

    # Test case with bits being uppercase
    assert human_to_bytes('2kB', isbits=True) == 196608

    # Test case with bits

# Generated at 2022-06-24 21:12:41.629791
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test for invalid input string
    try:
        human_to_bytes('Not_a_string')
    except ValueError as e:
        assert e.message == ("human_to_bytes() can't interpret following string: Not_a_string")

    # Test for invalid input number or wrong data type
    try:
        human_to_bytes('9.0.8')
    except ValueError as e:
        assert e.message == ("human_to_bytes() can't interpret following number: 9.0.8 (original input string: 9.0.8)")

    # Test for existing unit identifiers
    assert human_to_bytes('9.0.8') == 9
    assert human_to_bytes('9999999B') == 9999999
    assert human_to_bytes('9999999K') == 1000000000
    assert human_to_

# Generated at 2022-06-24 21:12:53.820998
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Test function human_to_bytes"""
    # Testing human_to_bytes(number, default_unit=None, isbits=False):
    # Input parameter: number
    # Expected output:
    assert human_to_bytes('0') == 0
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('.5') == 0
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('0.5') == 0
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('0.5M') == 524288

# Generated at 2022-06-24 21:13:02.689717
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1M', default_unit='M') == 1048576
    assert human_to_bytes('10.5M') == 10485760
    assert human_to_bytes('10.5') == 10
    assert human_to_bytes('1.3k') == 1300
    assert human_to_bytes('-1.3k') == -1300
    assert human_to_bytes('-1.3k') == -1300
    assert human_to_bytes('1.3kb') == 1300
    assert human_to_bytes('  1.3  kb  ') == 1300

# Generated at 2022-06-24 21:13:05.925182
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        human_to_bytes('1M')
    except ValueError:
        print('ValueError exception raised')
    try:
        human_to_bytes('1Mb', isbits=True)
    except ValueError:
        print('ValueError exception raised')


# Generated at 2022-06-24 21:13:17.128024
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(
        '1', default_unit='b') == 1, 'First case'
    assert human_to_bytes(
        '1T') == 1099511627776, 'Second case'
    assert human_to_bytes(
        '1Mb') == 131072, 'Third case'
    assert human_to_bytes(
        '1', default_unit='b', isbits=True) == 1, 'Fourth case'
    assert human_to_bytes(
        '10', default_unit='g', isbits=True) == 85899345920, 'Fifth case'
    assert human_to_bytes(
        '1', default_unit='M', isbits=True) == 8388608, 'Sixth case'
    assert human_to_bytes(
        '1Tb') == 8

# Generated at 2022-06-24 21:13:26.515076
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1 kb') == 1024

    assert human_to_bytes('1 mb') == 1048576
    assert human_to_bytes('1mb') == 1048576
    assert human_to_bytes(1, 'MB') == 1048576
    assert human_to_bytes(1, 'Mb') == 1048576
    assert human_to_bytes('1.1 Mb') == 1153433
    assert human_to_bytes('1.1MB') == 1153433
    assert human_to_bytes('1.1 Mb', isbits=True) == 1172202
    assert human_to_bytes('1.1Mb', isbits=True) == 1172202
    assert human_to_bytes(1.1, 'MB', True) == 1172202

# Generated at 2022-06-24 21:13:31.707347
# Unit test for function human_to_bytes
def test_human_to_bytes():
    pass


# Generated at 2022-06-24 21:13:32.697768
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_case_0()

# Generated at 2022-06-24 21:13:34.926790
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    case_0 = test_case_0()
    assert True



# Generated at 2022-06-24 21:13:38.478172
# Unit test for function human_to_bytes
def test_human_to_bytes():
    int_0 = -652
    assert human_to_bytes(int_0) == -652
    # base test
    int_1 = '10M'
    assert human_to_bytes(int_1) == 10485760



# Generated at 2022-06-24 21:13:48.075775
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        test_case_0()
    except Exception as error:
        print(error)
    finally:
        print('Finished tests for lenient_lowercase')



# Generated at 2022-06-24 21:13:59.115186
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """pytest for function: human_to_bytes"""
    if not hasattr(test_human_to_bytes, "counter"):
        test_human_to_bytes.counter = 0

    if test_human_to_bytes.counter == 0:
        test_human_to_bytes.counter = 1
        var_0 = human_to_bytes('2K')
        print(var_0)
    elif test_human_to_bytes.counter == 1:
        test_human_to_bytes.counter = 2
        var_1 = human_to_bytes('10M')
        print(var_1)
    elif test_human_to_bytes.counter == 2:
        test_human_to_bytes.counter = 3
        var_2 = human_to_bytes('1MB')

# Generated at 2022-06-24 21:14:10.924590
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test for passing bytes
    assert human_to_bytes('10') == 10
    assert human_to_bytes('-10') == -10
    assert human_to_bytes('0') == 0
    assert human_to_bytes('1 ') == 1
    assert human_to_bytes('  +1 ') == 1
    assert human_to_bytes('0.1 ') == 1
    assert human_to_bytes('  +0.1 ') == 1
    assert human_to_bytes('0.10 ') == 1
    assert human_to_bytes('  +0.10 ') == 1
    assert human_to_bytes('-0.1 ') == -1
    assert human_to_bytes('  -0.10 ') == -1
    assert human_to_bytes('0.1  ') == 1

# Generated at 2022-06-24 21:14:22.279604
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1B") == 1
    assert human_to_bytes("1K") == 1024
    assert human_to_bytes("1M") == 1048576
    assert human_to_bytes("1G") == 1073741824
    assert human_to_bytes("1T") == 1099511627776
    assert human_to_bytes("1P") == 1125899906842624
    assert human_to_bytes("1E") == 1152921504606846976
    assert human_to_bytes("1Z") == 1180591620717411303424
    assert human_to_bytes("1Y") == 1208925819614629174706176
    assert human_to_bytes("1KB") == 1024
    assert human_to_bytes("1MB") == 1048576
    assert human_

# Generated at 2022-06-24 21:14:32.171417
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        human_to_bytes("")
        assert False
    except ValueError as e:
        assert str(e) == "human_to_bytes() can't interpret following string: "

    try:
        human_to_bytes(100)
        assert False
    except ValueError as e:
        assert str(e) == "human_to_bytes() can't interpret following string: 100"

    try:
        human_to_bytes("123-54")
        assert False
    except ValueError as e:
        assert str(e) == "human_to_bytes() can't interpret following number: 123-54 (original input string: 123-54)"


# Generated at 2022-06-24 21:14:43.342475
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print(human_to_bytes('2K'))  # => 2048
    print(human_to_bytes('1.4M'))  # => 1468006
    print(human_to_bytes('1.4X'))  # => 1468006
    print(human_to_bytes('34.5M'))  # => 3623878656
    print(human_to_bytes('1M'))  # => 1048576
    print(human_to_bytes('1xM'))  # => 1048576
    print(human_to_bytes('1M', 'B'))  # => 1048576
    print(human_to_bytes('1B', 'M'))  # => 0.0009765625
    print(human_to_bytes('', 'M'))  # => 0.0

# Generated at 2022-06-24 21:14:48.844833
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1,"a","B"]) == [1,"a","B"]
    assert lenient_lowercase(["A","b","c"]) == ["a","b","c"]
    assert lenient_lowercase(1) == 1

# test for function human_to_bytes

# Generated at 2022-06-24 21:14:55.578651
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("10M") == 10485760
    assert human_to_bytes("10Mb") == 10485760
    assert human_to_bytes("10M", unit='b') == 10485760
    assert human_to_bytes("10M", isbits=True) == 10485760
    assert human_to_bytes("10Mb", isbits=True) == 10485760
    assert human_to_bytes("10Mb", isbits=True, unit='b') == 10485760
    assert human_to_bytes("10Mb", default_unit='b') == 10485760
    assert human_to_bytes("10M", default_unit='b') == 10485760
    assert human_to_bytes("1K", isbits=True) == 8192
    assert human_

# Generated at 2022-06-24 21:15:04.238571
# Unit test for function human_to_bytes
def test_human_to_bytes():
    size_val = []
    unit_val = []
    expected_val = []
    size_val.append('3.5')
    unit_val.append('MB')
    expected_val.append(36700160)
    size_val.append('1mb')
    unit_val.append('GB')
    expected_val.append(1073741824)
    size_val.append('10.5KB')
    unit_val.append('GB')
    expected_val.append(10)
    size_val.append('15Kb')
    unit_val.append('GB')
    expected_val.append(15)
    size_val.append('6.4')
    unit_val.append('MB')
    expected_val.append(6619136)
    size_val.append('15MB')


# Generated at 2022-06-24 21:15:11.486831
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes('10Mb') == human_to_bytes(10, 'Mb', True)
    assert human_to_bytes(15) == human_to_bytes('15')
    assert human_to_bytes('15') == human_to_bytes(15)
    assert human_to_bytes('15.1') == human_to_bytes(15.1)
    assert human_to_bytes('15.1M') == human_to_bytes(15.1, 'M')
    assert human_to_bytes('15.4M', True) == human_to_bytes(15.4, 'M', True)


# Generated at 2022-06-24 21:15:28.201845
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Make sure that human_to_bytes throws an exception for an invalid input.
    try:
        human_to_bytes('12.5M')
    except ValueError:
        pass
    # Make sure that human_to_bytes returns the correct output when the
    # input is '12M'
    response = human_to_bytes('12M')
    assert response == 12582912
    # Make sure that human_to_bytes returns the correct output when the
    # input is '12Mb' and isbits is True
    response = human_to_bytes('12Mb', isbits=True)
    assert response == 12582912
    # Make sure that human_to_bytes returns the correct output when the
    # input is '10M', the default unit is 'M' and isbits is False
    response = human_to_bytes

# Generated at 2022-06-24 21:15:38.006710
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(512) == 512
    assert human_to_bytes('2KB') == 2048
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('10G') == 10737418240
    assert human_to_bytes('20M') == 20971520
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1KB', unit='b') == 8192
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1Mb', unit='MB') == 1048576

# Generated at 2022-06-24 21:15:47.966973
# Unit test for function human_to_bytes

# Generated at 2022-06-24 21:15:56.036421
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Function lenient_lowercase accepts one argument
    int_0 = -652
    var_2 = lenient_lowercase(int_0)

    assert var_2 == -652

    # Function lenient_lowercase accepts one argument
    str_0 = 'lower'

    var_0 = lenient_lowercase(str_0)

    assert var_0 == 'lower'

    # Function lenient_lowercase accepts one argument
    str_0 = 'UPPER'

    var_0 = lenient_lowercase(str_0)

    assert var_0 == 'upper'

    # Function lenient_lowercase accepts one argument
    str_0 = 'mIxEd'

    var_0 = lenient_lowercase(str_0)

    assert var_0 == 'mixed'

    # Function lenient_lowercase

# Generated at 2022-06-24 21:16:06.198053
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """
    Test for function human_to_bytes
    """
    # Test case 1
    int_1 = 1
    string_1 = "M"
    assert human_to_bytes(int_1, string_1) == 1048576

    # Test case 2
    int_2 = '1'
    string_2 = "M"
    assert human_to_bytes(int_2, string_2) == 1048576

    # Test case 3
    int_3 = 1.0
    string_3 = "M"
    assert human_to_bytes(int_3, string_3) == 1048576

    # Test case 4
    int_4 = 1.0
    string_4 = "M"
    assert human_to_bytes(int_4, string_4) == 1048576

    # Test case 5

# Generated at 2022-06-24 21:16:09.099861
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert isinstance(lenient_lowercase(10), list)


# Generated at 2022-06-24 21:16:18.584444
# Unit test for function human_to_bytes

# Generated at 2022-06-24 21:16:27.229393
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    expected_0 = -652
    expected_1 = 'custom_string'
    expected_2 = True

    int_0 = -652
    str_0 = 'custom_string'
    int_1 = 0
    bool_0 = True

    actual_0 = lenient_lowercase(int_0)
    actual_1 = lenient_lowercase(str_0)
    actual_2 = lenient_lowercase(int_0)
    actual_3 = lenient_lowercase(int_1)
    actual_4 = lenient_lowercase(bool_0)

    assert expected_0 == actual_0
    assert expected_1 == actual_1
    assert expected_0 == actual_2
    assert expected_0 == actual_3
    assert expected_2 == actual_4



# Generated at 2022-06-24 21:16:28.647321
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'b', 'c', 4]) == ['a', 'b', 'c', 4]


# Generated at 2022-06-24 21:16:35.841101
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1K', 'B') == 1024)
    assert(human_to_bytes('1K') == 1024)
    assert(human_to_bytes('1K', 'B', isbits=True) == 1024*8)
    assert(human_to_bytes('1K', isbits=True) == 1024*8)
    assert(human_to_bytes('1KB') == 1024)
    assert(human_to_bytes('1KB', isbits=True) == 1024*8)
    assert(human_to_bytes('1KBb') == 1024*8)
    assert(human_to_bytes('1KBb', isbits=True) == 1024*8)
    assert(human_to_bytes('1Kb') == 1024*8)