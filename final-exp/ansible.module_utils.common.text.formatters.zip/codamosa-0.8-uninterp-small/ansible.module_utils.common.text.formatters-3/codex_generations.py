

# Generated at 2022-06-24 21:07:01.240047
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes('1K') == human_to_bytes(1, 'K')
    assert human_to_bytes('1KB') == human_to_bytes(1, 'KB')
    assert human_to_bytes('10Mb') == human_to_bytes(10, 'Mb', isbits=True)
    assert human_to_bytes('1KBb') == human_to_bytes(1, 'KB', isbits=True)
    assert human_to_bytes('1KB', isbits=True) == human_to_bytes(1, 'KB', isbits=True)
    assert human_to_bytes('1', 'K') == human_to_bytes(1, 'K')
    assert human_to_

# Generated at 2022-06-24 21:07:07.831895
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert not lenient_lowercase("test")
    assert lenient_lowercase("Test")
    assert lenient_lowercase("TEST")
    assert not lenient_lowercase("TEST", "TEST")
    assert lenient_lowercase("TEST", "TEST", "TEST")


# Generated at 2022-06-24 21:07:15.073327
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = 200
    str_0 = "lorem ipsum"
    str_1 = "LOREM IPSUM"
    lst_0 = [int_0, str_0, str_1]
    lst_1 = lenient_lowercase(lst_0)
    assert True == isinstance(lst_1, list)
    assert [int_0, str_0.lower(), str_1.lower()] == lst_1


# Generated at 2022-06-24 21:07:16.895491
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Input parameters
    int_arg = 5

    var_1 = lenient_lowercase(5)


# Generated at 2022-06-24 21:07:28.338621
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(True) == True
    assert lenient_lowercase(False) == False
    assert lenient_lowercase('test string') == 'test string'
    assert lenient_lowercase(1) == 1
    assert lenient_lowercase([1, 2]) == [1, 2]
    assert lenient_lowercase(['test string', 'test string 2']) == ['test string', 'test string 2']
    assert lenient_lowercase(('test1', 'test2')) == ('test1', 'test2')
    assert lenient_lowercase({'test1': 1, 'test2': 2}) == {'test1': 1, 'test2': 2}
    assert lenient_lowercase({'test1'}) == {'test1'}

# Generated at 2022-06-24 21:07:35.614088
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from ansible_collections.community.general.tests.unit.compat.mock import patch

    ansible_module_patch = patch('ansible.module_utils.basic.AnsibleModule')
    ansible_module = ansible_module_patch.start()
    add_argument_patch = patch('ansible.module_utils.basic.AnsibleModule.add_argument')
    add_argument = add_argument_patch.start()
    exit_json_patch = patch('ansible.module_utils.basic.AnsibleModule.exit_json')
    exit_json = exit_json_patch.start()
    fail_json_patch = patch('ansible.module_utils.basic.AnsibleModule.fail_json')
    fail_json = fail_json_patch.start()
    set_exit_json_patch

# Generated at 2022-06-24 21:07:39.755228
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        test_case_0()
    except Exception as e:
        print('Failed to test lenient_lowercase')
        print(str(e))
        sys.exit(1)


# Generated at 2022-06-24 21:07:50.252626
# Unit test for function bytes_to_human

# Generated at 2022-06-24 21:07:56.853512
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test0 = True
    assert human_to_bytes(test0) == True
    test1 = 1
    assert human_to_bytes(test1) == 1
    test2 = '2M'
    unit2 = 'B'
    assert human_to_bytes(test2, unit2) == 2097152
    test3 = '2Mb'
    unit3 = 'b'
    assert human_to_bytes(test3, unit3, True) == 2097152
    test4 = 3
    unit4 = 'M'
    assert human_to_bytes(test4, unit4) == 3145728


# Generated at 2022-06-24 21:08:01.696116
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # tests for valid input
    assert human_to_bytes('0') == 0
    assert human_to_bytes('0b') == 0
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1MB', isbits=True) == 1048576
    assert human_to_bytes('2Mb') == 2097152
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1G', isbits=True) == 8589934592
    assert human_to_bytes('1TB') == 1099511627776
    assert human_to_bytes('1T') == 1099511627776
    assert human_to

# Generated at 2022-06-24 21:08:13.353608
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1.1K') == 1101)
    assert(human_to_bytes(10.5, 'G') == 105999999232)
    assert(human_to_bytes(1, 'k') == 1024)
    assert(human_to_bytes(1, 'kb') == 1024)
    assert(human_to_bytes(1, 'kb', True) == 1024)
    assert(human_to_bytes('1.1b') == 1)
    assert(human_to_bytes('1.1b', isbits=True) == 1)
    assert(human_to_bytes('1Mb', isbits=True) == 1048576)
    assert(human_to_bytes('1Mb') == 1048576)

# Generated at 2022-06-24 21:08:20.889360
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2k') == 2048
    assert human_to_bytes('2048') == 2048
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1g') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1t') == 1099511627776


# Generated at 2022-06-24 21:08:30.452992
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(0) == "0.00 Bytes"
    assert bytes_to_human(1023) == "1023.00 Bytes"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1048575) == "1023.99 KBytes"
    assert bytes_to_human(1048576) == "1.00 MB"
    assert bytes_to_human(1073741823) == "1023.99 MBytes"
    assert bytes_to_human(1073741824) == "1.00 GB"
    assert bytes_to_human(1099511627775) == "1023.99 GBytes"
    assert bytes_to_human(1099511627776) == "1.00 TB"

# Generated at 2022-06-24 21:08:36.394180
# Unit test for function human_to_bytes

# Generated at 2022-06-24 21:08:43.509041
# Unit test for function bytes_to_human
def test_bytes_to_human():
    res = bytes_to_human(1048576)
    if res != '1.00 MB':
        raise AssertionError('Invalid value returned, expected 1.00 MB, got: %s' % res)

    res = bytes_to_human(99)
    if res != '99.00 Bytes':
        raise AssertionError('Invalid value returned, expected 99.00 Bytes, got: %s' % res)

    res = bytes_to_human(2048, unit='kB')
    if res != '2.00 kBytes':
        raise AssertionError('Invalid value returned, expected 2.00 kBytes, got: %s' % res)

    res = bytes_to_human(2048, unit='kB', isbits=True)

# Generated at 2022-06-24 21:08:50.311910
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test raising exception when the first argument is a string
    try:
        human_to_bytes('test_case_0')
        assert False
    except ValueError as e:
        assert '"human_to_bytes() can\'t interpret following string"' in str(e)
    # Test raising exception when the first argument is a list
    try:
        human_to_bytes([])
        assert False
    except ValueError as e:
        assert '"human_to_bytes() can\'t interpret following string"' in str(e)
    # Test raising exception when the first argument is a dict
    try:
        human_to_bytes({})
        assert False
    except ValueError as e:
        assert '"human_to_bytes() can\'t interpret following string"' in str(e)
    # Test raising exception when the first argument is a

# Generated at 2022-06-24 21:09:00.207565
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    var_0 = { 'K' : 1 << 10, 'b' : 1, 'E' : 1 << 60, 'Y' : 1 << 80, 'G' : 1 << 30, 'P' : 1 << 50, 'M' : 1 << 20, 'Z' : 1 << 70, 'B' : 1, 'T' : 1 << 40,  }
    var_1 = human_to_bytes('10', default_unit=None, isbits=False)
    assert var_1 == 10, 'var_1 did not match expected result'

    var_1 = human_to_bytes('10M', isbits=False)
    assert var_1 == 10485760, 'var_1 did not match expected result'

    var_1 = human_to_bytes('10G', isbits=False)
    assert var_1 == 107374

# Generated at 2022-06-24 21:09:01.858979
# Unit test for function human_to_bytes
def test_human_to_bytes():
    expected_result = 1048576
    actual_result = human_to_bytes('1MB')
    assert actual_result == expected_result



# Generated at 2022-06-24 21:09:12.906289
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human('1B') == '1.00 Bytes'
    assert bytes_to_human('1.5B') == '1.50 Bytes'
    assert bytes_to_human('K') == '1.00 KB'
    assert bytes_to_human('10K') == '10.00 KB'
    assert bytes_to_human('10K', unit='B') == '10240.00 Bytes'
    assert bytes_to_human('10KBMB') == '10240.00 Bytes'
    assert bytes_to_human('10,000') == '10.00 KB'
    assert bytes_to_human('10KiB') == '10240.00 Bytes'
    assert bytes_to_human('10kb') == '10240.00 bits'

# Generated at 2022-06-24 21:09:20.133536
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    var_0 = True
    assert lenient_lowercase(var_0) == var_0

    var_1 = False
    assert lenient_lowercase(var_1) == var_1

    var_2 = 'True'
    assert lenient_lowercase(var_2) == var_2.lower()

    var_3 = 'False'
    assert lenient_lowercase(var_3) == var_3.lower()

    var_4 = 'String'
    assert lenient_lowercase(var_4) == var_4.lower()



# Generated at 2022-06-24 21:09:32.025983
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1M') == 1
    assert human_to_bytes('1M', 'B') == 1048576
    assert human_to_bytes('1M', 'b') == 1048576
    assert human_to_bytes('1M', 'm') == 1
    assert human_to_bytes('1M', 'M') == 1
    assert human_to_bytes('1M', 'G') == 0.0009765625

# Generated at 2022-06-24 21:09:36.468461
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('10k') == 10240
    assert human_to_bytes('10Kb') == 12800
    assert human_to_bytes('10kb') == 12800


# Generated at 2022-06-24 21:09:47.081795
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('\nStarting test_human_to_bytes\n')
    #   expected_0 = True
    #   expected_1 = True
    #   expected_2 = True
    #   expected_3 = True
    #   expected_4 = True
    #   expected_5 = True
    #   expected_6 = True
    #   expected_7 = True
    #   expected_8 = True
    #   expected_9 = True
    #   expected_10 = True
    expected_0 = None
    expected_1 = None
    expected_2 = None
    expected_3 = None
    expected_4 = None
    expected_5 = None
    expected_6 = None
    expected_7 = None
    expected_8 = None
    expected_9 = None
    expected_10 = None
    expected_11 = None

# Generated at 2022-06-24 21:09:54.689652
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1MB') == 1048576)
    assert(human_to_bytes('1MB', default_unit='MB') == 1048576)
    assert(human_to_bytes(22, default_unit='Mb') == 11520000)
    assert(human_to_bytes(22, default_unit='Mb', isbits=True) == 27500000)
    assert(human_to_bytes(20, default_unit='Mb', isbits=True) == 25600000)
    assert(human_to_bytes(20, default_unit='b') == 20)
    assert(human_to_bytes(20, default_unit='B') == 20)

    try:
        assert(human_to_bytes(20, default_unit='Bb') == 20)
    except ValueError:
        pass

# Generated at 2022-06-24 21:09:59.468685
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1") == 1
    assert human_to_bytes("1B") == 1
    assert human_to_bytes("1b") == 1
    assert human_to_bytes("1.5B") == 1
    assert human_to_bytes("1.5B", isbits=True) == 1
    # On Python 2.7, int division returns 0
    # https://docs.python.org/2/whatsnew/2.2.html#pep-238-changing-the-division-operator
    assert human_to_bytes("1K") == 1024
    assert human_to_bytes("1K", isbits=True) == 1024
    assert human_to_bytes("1M", isbits=True) == 1048576
    assert human_to_bytes("1G") == 1073741824

# Generated at 2022-06-24 21:10:01.672967
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(True) == 'true'
    assert lenient_lowercase(False) == 'false'

# Generated at 2022-06-24 21:10:03.175742
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(bool_0) == var_0


# Generated at 2022-06-24 21:10:11.678231
# Unit test for function human_to_bytes
def test_human_to_bytes():
    val = "10M"
    unit = "M"
    value1 = human_to_bytes(val, unit)
    value2 = human_to_bytes(10, unit)
    assert value1 == 10485760
    assert value2 == 10485760
    val = "10Mb"
    isbits = True
    value1 = human_to_bytes(val, None, isbits)
    value2 = human_to_bytes(10, unit, isbits)
    assert value1 == 83886080
    assert value2 == 83886080


# Generated at 2022-06-24 21:10:17.765736
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase('some string') == 'some string', "lenient_lowercase('some string')"


# Generated at 2022-06-24 21:10:24.206617
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test for boolean values
    assert(human_to_bytes(True) == 1)
    assert(human_to_bytes(True, 'MB') == 1048576)
    assert(human_to_bytes(True, 'KB') == 1024)
    assert(human_to_bytes(True, 'Kb') == 1024)
    assert(human_to_bytes(True, 'MB', True) == 8388608)
    assert(human_to_bytes(True, 'KB', True) == 8192)
    assert(human_to_bytes(True, 'Kb', True) == 8192)
    assert(human_to_bytes(False) == 0)
    assert(human_to_bytes(False, 'MB') == 0)
    assert(human_to_bytes(False, 'MB', True) == 0)

# Generated at 2022-06-24 21:10:28.708464
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("102400K") == 104857600


# Generated at 2022-06-24 21:10:37.954388
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976

    try:
        assert human_to_bytes('1125899906842625') == 1125899906842625
    except ValueError as e:
        assert 'Failed to convert 1099511627776' in str(e)
        assert 'The suffix must be one of B, B, K, M, G, T, P, E' in str(e)

# Generated at 2022-06-24 21:10:41.367565
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    var_0 = ['123', '456', '789']
    var_0 = lenient_lowercase(var_0)

    assert var_0 == ['123', '456', '789']



# Generated at 2022-06-24 21:10:50.138690
# Unit test for function human_to_bytes
def test_human_to_bytes():
    size = '2K'
    expected = 2048
    result = human_to_bytes(size)
    assert expected == result, "Testcase failed for size %s, expected %s, got %s" % (size, expected, result)

    size = '2k'
    expected = 2048
    result = human_to_bytes(size)
    assert expected == result, "Testcase failed for size %s, expected %s, got %s" % (size, expected, result)

    size = '2m'
    expected = 2097152
    result = human_to_bytes(size)
    assert expected == result, "Testcase failed for size %s, expected %s, got %s" % (size, expected, result)

    size = '2M'
    expected = 2097152
    result = human_to_bytes(size)

# Generated at 2022-06-24 21:10:53.757957
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == '10485760'
    assert human_to_bytes('10Mb') == '10485760'
    assert human_to_bytes(10, 'M') == '10485760'
    assert human_to_bytes(10, 'M', isbits=True) == '1048576'


# Generated at 2022-06-24 21:11:02.804471
# Unit test for function bytes_to_human
def test_bytes_to_human():
    result = bytes_to_human(20000)
    assert result == "19.53 KB"
    result = bytes_to_human(20000, isbits=True)
    assert result == "19.53 Kb"
    result = bytes_to_human(20000, isbits=True, unit='b')
    assert result == "20000 bits"
    result = bytes_to_human(20000, isbits=True, unit='k')
    assert result == "19.53 Kb"
    result = bytes_to_human(20000, isbits=False, unit='B')
    assert result == "20000 Bytes"



# Generated at 2022-06-24 21:11:14.397630
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert True == lenient_lowercase(True)
    assert 'true' == lenient_lowercase('true')
    assert 1 == lenient_lowercase(1)
    assert '1' == lenient_lowercase('1')
    assert 'abc' == lenient_lowercase('abc')
    assert 'abc' == lenient_lowercase('ABC')
    assert ['true', 'false', 123, '1M'] == lenient_lowercase(['true', 'false', 123, '1M'])
    assert {} == lenient_lowercase({})
    assert {'A': 'a', 123: '123'} == lenient_lowercase({'A': 'a', 123: '123'})

# Generated at 2022-06-24 21:11:22.020951
# Unit test for function bytes_to_human
def test_bytes_to_human():
    if bytes_to_human(2048) != "2.00 KB":
        raise Exception("function 'bytes_to_human' failed for input: 2048")


if __name__ == '__main__':
    test_cases = [
        test_case_0,
        test_bytes_to_human,
    ]

    test_runner = TestRunner()
    test_runner.run_test_cases(test_cases)

# Generated at 2022-06-24 21:11:30.548287
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test with a number with a unit
    result = human_to_bytes('20K')
    assert result == 20480
    result = human_to_bytes('20K', 'B')
    assert result == 20480
    # Test with a number without a unit
    result = human_to_bytes('20')
    assert result == 20
    result = human_to_bytes('20', 'B')
    assert result == 20



# Generated at 2022-06-24 21:11:41.770168
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(2) == '2.00 Bytes'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(2, unit='b') == '2.00 bits'
    assert bytes_to_human(10, unit='b') == '10.00 bits'
    assert bytes_to_human(2, isbits=True) == '2.00 bits'
    assert bytes_to_human(10, isbits=True) == '10.00 bits'
    assert bytes_to_human(2, isbits=True, unit='b') == '2.00 bits'
    assert bytes_to_human(10, isbits=True, unit='b') == '10.00 bits'


# Generated at 2022-06-24 21:11:44.306720
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    pass

# Generated at 2022-06-24 21:11:54.098299
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('my_human_to_bytes(1048576) = ', human_to_bytes(1048576))
    print('my_human_to_bytes(1048576,\'K\') = ', human_to_bytes(1048576, 'K'))
    print('my_human_to_bytes(1,\'Mb\') = ', human_to_bytes(1, 'Mb'))
    print('my_human_to_bytes(1,\'Kb\',True) = ', human_to_bytes(1, 'Kb', True))
    print('my_human_to_bytes(1,\'KB\',True) = ', human_to_bytes(1, 'KB', True))



# Generated at 2022-06-24 21:12:01.823823
# Unit test for function human_to_bytes
def test_human_to_bytes():
    out = human_to_bytes('1234', 'B')
    assert( out == 1234 )
    out = human_to_bytes('1234', 'b')
    assert( out == 1234 )
    out = human_to_bytes('1234', 'Mb')
    assert( out == 1234 * 1024 * 1024 )
    out = human_to_bytes('1234', 'Mb', True)
    assert( out == 1234 * 1024 * 1024 )
    out = human_to_bytes('1234', 'b', True)
    assert( out == 1234 )
    out = human_to_bytes('1234', 'B', True)
    assert( out == 1234 )
    out = human_to_bytes('1234', 'bits')
    assert( out == 1234 * 8 )
    out = human_to

# Generated at 2022-06-24 21:12:06.725386
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = human_to_bytes('1GB')
    assert result == 1073741824



# Generated at 2022-06-24 21:12:07.998970
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Testing for True
    assert human_to_bytes(1024, "B") == 1024


# Generated at 2022-06-24 21:12:12.188018
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(True) == True
    assert lenient_lowercase(False) == False
    assert lenient_lowercase('test') == 'test'
    assert lenient_lowercase('Test') == 'test'
    assert lenient_lowercase(5) == 5
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase([1, 'Test', 3]) == [1, 'Test', 3]



# Generated at 2022-06-24 21:12:13.900120
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert callable(lenient_lowercase)
    try:
        test_case_0()
    except:
        assert False, "Test case 0 failed"


# Generated at 2022-06-24 21:12:18.409585
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10240, 'K') == 10 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes(10240, 'k') == 10 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('10K') == 10 * 1024
    assert human_to_bytes('10k') == 10 * 1024


# Generated at 2022-06-24 21:12:23.669506
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase('aBcD') == 'abcd'
    assert lenient_lowercase(False) == False
    assert lenient_lowercase(True) == True


# Generated at 2022-06-24 21:12:27.295340
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = True
    var_0 = lenient_lowercase(list_0)
    assert isinstance(var_0, bool), "function(lenient_lowercase) does not return bool value"


# Generated at 2022-06-24 21:12:38.544338
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('4Mb', isbits=True) == 4 * 1024 * 1024
    assert human_to_bytes('2048b', isbits=True) == 2048
    assert human_to_bytes('1.5M', default_unit='B') == 1536000
    assert human_to_bytes(2000, default_unit='b', isbits=True) == 2000
    assert human_to_bytes(1.5, default_unit='KB') == 1536
    assert human_to_bytes(20000, default_unit='MB') == 2000000000
    assert human_to_bytes('1kb') == 1000
    assert human_to_bytes(0.5) == 0.5

    try:
        assert human_to_bytes('1Mb')
    except ValueError:
        pass


# Generated at 2022-06-24 21:12:46.418296
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert 10 == (human_to_bytes('10'))
    assert 10 == (human_to_bytes(10))
    assert 10 == (human_to_bytes(10, 'B'))

    assert 1024 == (human_to_bytes('1K'))
    assert 1024 == (human_to_bytes('1k'))
    assert 1024 == (human_to_bytes(1, 'K'))

    assert 1048576 == (human_to_bytes('1M'))
    assert 1048576 == (human_to_bytes(1, 'M'))

    assert 1073741824 == (human_to_bytes('1G'))
    assert 1073741824 == (human_to_bytes(1, 'G'))

    assert 1099511627776 == (human_to_bytes('1T'))
    assert 10995

# Generated at 2022-06-24 21:12:55.304655
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('100B') == 100
    assert human_to_bytes('1Mb') == 8388608
    assert human_to_bytes('1Mb', isbits=True) == 8388608
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(1, 'MB') == 1048576
    assert human_to_bytes(1, 'MB', isbits=True) == 1048576
    assert human_to_bytes(1, 'Mb', isbits=True) == 8388608
    assert human_to_bytes(1, 'Mb') == 8388608

# Generated at 2022-06-24 21:12:56.714253
# Unit test for function human_to_bytes
def test_human_to_bytes():
    var_0 = "2K"
    var_1 = human_to_bytes(var_0)
    assert (var_1 == 2048)



# Generated at 2022-06-24 21:13:05.166197
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("10") == 10
    assert human_to_bytes("10M") == 10485760
    assert human_to_bytes("10MB") == 10485760
    assert human_to_bytes("1.5Mb") == 1572864
    assert human_to_bytes("10.5Kb") == 10752
    assert human_to_bytes("10.5Kb", isbits=True) == 10752


# Generated at 2022-06-24 21:13:13.446231
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Testing with default args
    value_human_to_bytes_0 = '0'
    bytes_0 = human_to_bytes(value_human_to_bytes_0)
    assert bytes_0 == 0
    # Testing with 2 args
    value_human_to_bytes_1 = '1000'
    value_human_to_bytes_2 = 'K'
    bytes_1 = human_to_bytes(value_human_to_bytes_1, value_human_to_bytes_2)
    assert bytes_1 == 1024000
    # Testing with 3 args
    value_human_to_bytes_3 = '12Mb'
    value_human_to_bytes_4 = 'b'
    value_human_to_bytes_5 = True

# Generated at 2022-06-24 21:13:14.877280
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1') == 1)



# Generated at 2022-06-24 21:13:21.253133
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    import pytest
    from ansible_collections.ansible.community.plugins.utils.lenient_lowercase import lenient_lowercase

    input_value = ['ANSIBLE', 'IS', 'AWESOME', True, False]
    expected_result = ['ansible', 'is', 'awesome', True, False]
    actual_result = lenient_lowercase(input_value)

    assert expected_result == actual_result


# Generated at 2022-06-24 21:13:27.271078
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('2G') == 2147483648
    assert human_to_bytes('3') == 3
    assert human_to_bytes('3', default_unit='M') == 3145728
    assert human_to_bytes('3', unit='M') == 3145728
    assert human_to_bytes('3', unit='K') == 3072


# Generated at 2022-06-24 21:13:36.508550
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1MB') == 1024 ** 2
    assert human_to_bytes('1M') == 1024 ** 2
    assert human_to_bytes('1GB') == 1024 ** 3
    assert human_to_bytes('1G') == 1024 ** 3
    assert human_to_bytes('1TB') == 1024 ** 4
    assert human_to_bytes('1T') == 1024 ** 4
    assert human_to_bytes('1PB') == 1024 ** 5
    assert human_to_bytes('1P') == 1024 ** 5

# Generated at 2022-06-24 21:13:44.355427
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('100K') == 102400
    assert human_to_bytes('100') == 100
    assert human_to_bytes('0') == 0
    assert human_to_bytes('') == False

    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 1048576

    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1M', isbits=True) == 8388608
    assert human_to_bytes('100K', isbits=True) == 819200

    assert human_

# Generated at 2022-06-24 21:13:49.197675
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    not_lower_text = 'CamelCase'
    lower_text = 'lowercase'
    some_list = ['This', 'is', 'a', 'mix', 'of', not_lower_text, 'and', lower_text]
    new_list = lenient_lowercase(some_list)
    if new_list[5] == 'camelcase':
        return True
    else:
        return False


# Generated at 2022-06-24 21:13:56.279362
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase('some string') == ['some string']
    assert lenient_lowercase(['some string', 'another string']) == ['some string', 'another string']
    assert lenient_lowercase(['some string', 1234]) == ['some string', 1234]
    assert lenient_lowercase(['some string', None]) == ['some string', None]
    assert lenient_lowercase(['some string', True]) == ['some string', True]


# Generated at 2022-06-24 21:13:57.269468
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    assert(lenient_lowercase(True)==True)


# Generated at 2022-06-24 21:14:03.766924
# Unit test for function human_to_bytes
def test_human_to_bytes():
    expected_result_0 = 1048576
    result_0 = human_to_bytes('1MB')
    assert result_0 == expected_result_0
    expected_result_1 = 1048576
    result_1 = human_to_bytes(1, 'M')
    assert result_1 == expected_result_1
    expected_result_2 = 1048576
    result_2 = human_to_bytes(1048576, 'B')
    assert result_2 == expected_result_2
    expected_result_3 = 1044092
    result_3 = human_to_bytes('1.01 Mb')
    assert result_3 == expected_result_3
    expected_result_4 = 8
    result_4 = human_to_bytes('1b')
    assert result_4 == expected_result_4
    expected_

# Generated at 2022-06-24 21:14:15.457280
# Unit test for function human_to_bytes
def test_human_to_bytes():

    func_name = 'test_human_to_bytes'
    func_doc = 'Unit test for function human_to_bytes'
    print('{0}: {1}'.format(func_name, func_doc))
    # test 1 (bytes)
    test_no1 = '2K'
    result_no1 = human_to_bytes(test_no1)
    print('test_no1: result_no1 = {0}'.format(result_no1))
    # test 2 (bytes)
    test_no2 = '10MB'
    result_no2 = human_to_bytes(test_no2)
    print('test_no2: result_no2 = {0}'.format(result_no2))
    # test 3 (bytes)
    test_no3 = '100mb'
    result_

# Generated at 2022-06-24 21:14:16.380271
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    print('Testing lenient_lowercase()...')
    print(test_case_0())



# Generated at 2022-06-24 21:14:23.258889
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # > human_to_bytes('1M')
    if human_to_bytes('1M') != 1048576:
        raise AssertionError('Unexpected output for human_to_bytes("1M"), expected 1048576, got {}'.format(human_to_bytes('1M')))
    # > human_to_bytes('1.2M')
    if human_to_bytes('1.2M') != 1228800:
        raise AssertionError('Unexpected output for human_to_bytes("1.2M"), expected 1228800, got {}'.format(human_to_bytes('1.2M')))
    # > human_to_bytes('1Mb')

# Generated at 2022-06-24 21:14:24.528590
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(bool_0) == "True")


# Generated at 2022-06-24 21:14:33.073378
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # given
    bool_0 = True
    int_0 = 1
    float_0 = 2.0
    str_0 = 'string'
    list_0 = [1,2,3]
    dict_0 = {'key0':'value0','key1':'value1'}

    # when
    var_0 = lenient_lowercase(bool_0)
    var_1 = lenient_lowercase(int_0)
    var_2 = lenient_lowercase(float_0)
    var_3 = lenient_lowercase(str_0)
    var_4 = lenient_lowercase(list_0)
    var_5 = lenient_lowercase(dict_0)

    # then
    assert var_0 == bool_0
    assert var_1 == int_0
    assert var

# Generated at 2022-06-24 21:14:40.018570
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase('1') == '1'


# Generated at 2022-06-24 21:14:44.359446
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    var_1 = 'a'
    var_1 = lenient_lowercase(var_1)
    assert var_1 == 'a'

    var_1 = ['a', 'B', 'C']
    var_2 = ['a', 'b', 'c']
    var_1 = lenient_lowercase(var_1)
    assert var_1 == var_2



# Generated at 2022-06-24 21:14:48.250401
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Input parameters:
    number = '10M'
    default_unit = 'M'
    isbits = False

    # Expected return value:
    expected = 10485760

    # Return value:
    human_to_bytes(number, default_unit, isbits)


# Generated at 2022-06-24 21:14:49.383402
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    with pytest.raises(AttributeError):
        test_case_0()



# Generated at 2022-06-24 21:14:53.840250
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    bool_0 = True
    var_0 = lenient_lowercase(bool_0)



# Generated at 2022-06-24 21:15:03.199809
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    bool_0 = True
    var_0 = lenient_lowercase(bool_0)
    assert var_0 == True
    bool_1 = False
    var_1 = lenient_lowercase(bool_1)
    assert var_1 == False
    int_0 = 5
    var_2 = lenient_lowercase(int_0)
    assert var_2 == 5
    float_0 = 5.0
    var_3 = lenient_lowercase(float_0)
    assert var_3 == 5.0
    str_0 = 'abc'
    var_4 = lenient_lowercase(str_0)
    assert var_4 == 'abc'.lower()
    str_1 = 'ABC'
    var_5 = lenient_lowercase(str_1)

# Generated at 2022-06-24 21:15:04.880180
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(True) == [True], "Test 0 Failed"



# Generated at 2022-06-24 21:15:09.862564
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """
    Test that lenient_lowercase returns correct value
    """
    assert lenient_lowercase(True) == 'true'
    assert lenient_lowercase('Example') == 'example'
    assert lenient_lowercase(False) == 'false'
    assert lenient_lowercase(1) == 1
    assert lenient_lowercase(0) == 0
    assert lenient_lowercase('1') == '1'


# Generated at 2022-06-24 21:15:20.106433
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(0, isbits=True) == 0
    assert human_to_bytes('0', isbits=True) == 0
    assert human_to_bytes('12', isbits=True) == 12
    assert human_to_bytes('12Kb', isbits=True) == (12 * 1024)
    assert human_to_bytes('12KB', isbits=False) == (12 * 1024)
    assert human_to_bytes('12Kb', isbits=False) == (12 * 1024)
    assert human_to_bytes('12KBb', isbits=True) == (12 * 1024)
    assert human_to_bytes('12Kbb', isbits=False) == (12 * 1024)
    assert human_to_bytes('12 kb', isbits=True) == (12 * 1024)
    assert human

# Generated at 2022-06-24 21:15:28.121865
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb', isbits=True) == 1073741824
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb', isbits=True) == 1073741824
    assert human_to_

# Generated at 2022-06-24 21:15:35.989900
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test case with parameters
    bool_0 = True
    var_0 = lenient_lowercase(bool_0)


# Generated at 2022-06-24 21:15:40.821394
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert callable(lenient_lowercase)

    # Call lenient_lowercase with correct arguments
    try:
        lenient_lowercase(test_case_0)
    # Exception thrown
    except Exception as e:
        assert False, "The function lenient_lowercase threw an exception at line {}: {}".format(
            sys.exc_info()[-1].tb_lineno, e)



# Generated at 2022-06-24 21:15:48.315353
# Unit test for function human_to_bytes
def test_human_to_bytes():
    retval = human_to_bytes(2.0, 'M', True)
    assert retval == 2097152
    retval = human_to_bytes(2.0, 'k', True)
    assert retval == 2048
    retval = human_to_bytes('2Mb', True)
    assert retval == 2097152
    retval = human_to_bytes('2KB')
    assert retval == 2048
    retval = human_to_bytes(2.0, 'MB')
    assert retval == 2097152
    retval = human_to_bytes('1B')
    assert retval == 1
    retval = human_to_bytes('1')
    assert retval == 1
    retval = human_to_bytes('1bit')
    assert retval == 0
    retval = human_to

# Generated at 2022-06-24 21:15:52.416903
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    human_to_bytes('1MBb')


# Generated at 2022-06-24 21:16:02.135791
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', isbits=False) == 10485760
    assert human_to_bytes('10M', isbits=True) == 1048576
    assert human_to_bytes('10Mb', isbits=True) == 1048576
    assert human_to_bytes('10Mb') == 1048576000
    assert human_to_bytes('10Mb', isbits=False) == 1048576000
    assert human_to_bytes('10', default_unit='M') == 10485760
    assert human_to_bytes('10', default_unit='M', isbits=False) == 10485760
    assert human_to_bytes('10', default_unit='M', isbits=True) == 1048576
   

# Generated at 2022-06-24 21:16:06.946933
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    print("\n*** Testing function 'lenient_lowercase' ***")
    # Test case 0
    print('Test case 0:')
    bool_0 = True
    var_0 = lenient_lowercase(bool_0)

    if var_0:
        print("1st test passed")
    else:
        print("1st test failed")

    # Test case 1
    print('\nTest case 1:')
    str_0 = 'test'
    var_1 = lenient_lowercase(str_0)

    if var_1 == 'test':
        print("2nd test passed")
    else:
        print("2nd test failed")

    # Test case 2
    print('\nTest case 2:')
    tuple_0 = (1, 2, 3)
    var_2 = lenient_lowercase

# Generated at 2022-06-24 21:16:12.572267
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-24 21:16:14.008670
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test cases:
    test_case_0()


# Generated at 2022-06-24 21:16:20.896560
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_0_value = '10M'
    test_1_value = 10
    test_2_value = 'M'
    test_3_value = human_to_bytes(test_0_value)
    assert test_3_value == 10485760, "Expected output of 10485760, got {}".format(test_3_value)
    test_4_value = human_to_bytes(test_1_value, test_2_value)
    assert test_4_value == 10485760, "Expected output of 10485760, got {}".format(test_4_value)


# Generated at 2022-06-24 21:16:24.839681
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_len = 1000
    var_0 = []
    for i in range(0, list_len):
        var_0.append(chr(97 + i))
    try:
        test_case_0()
    except Exception as exception:
        print(exception)


if __name__ == '__main__':
    test_lenient_lowercase()

# Generated at 2022-06-24 21:16:41.086185
# Unit test for function human_to_bytes
def test_human_to_bytes():
    size = 1024
    result = human_to_bytes(size)
    assert result == 1048576


# testing for human_to_bytes, with unit

# Generated at 2022-06-24 21:16:50.231562
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    bool_0 = True
    var_0 = lenient_lowercase(bool_0)
    assert var_0 == bool_0

    bool_0 = False
    var_0 = lenient_lowercase(bool_0)
    assert var_0 == bool_0

    str_0 = ''
    var_0 = lenient_lowercase(str_0)
    assert var_0 == str_0.lower()

    str_0 = 'abc'
    var_0 = lenient_lowercase(str_0)
    assert var_0 == str_0.lower()

    lst_0 = []
    var_0 = lenient_lowercase(lst_0)
    assert var_0 == lst_0

    lst_0 = ['aBc', [1, 2]]
    var_0 = len