

# Generated at 2022-06-24 21:06:59.188937
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert (human_to_bytes("1K") == 1024)
    assert (human_to_bytes("1K", isbits=True) == 1024)
    assert (human_to_bytes("1Kb", isbits=True) == 1024)
    assert (human_to_bytes("1K", isbits=False) == 1024)
    assert (human_to_bytes("1Mb", isbits=True) == 1048576)
    assert (human_to_bytes("1M", isbits=True) == 1048576)
    assert (human_to_bytes("1Mb", isbits=False) == 1048576)
    assert (human_to_bytes("1M", isbits=False) == 1048576)
    assert (human_to_bytes("1Mb", isbits=False) == 1048576)
   

# Generated at 2022-06-24 21:07:05.674353
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("10") == 10

    assert human_to_bytes("10K") == 10240

    assert human_to_bytes("10K", isbits=True) == 10485760

    assert human_to_bytes("10M") == 10485760

    assert human_to_bytes("10M", isbits=True) == 104857600

    assert human_to_bytes("10M", unit='b') == 104857600

    assert human_to_bytes("10Mb") == 104857600

    assert human_to_bytes("10MBb") == 104857600

    assert human_to_bytes("10M") == 10485760

    assert human_to_bytes("10Mb") == 104857600

    assert human_to_bytes("10MB") == 10485760

   

# Generated at 2022-06-24 21:07:10.505245
# Unit test for function human_to_bytes
def test_human_to_bytes():
    bytes_ = human_to_bytes('2MB')
    assert bytes_ == 2097152
    bytes_ = human_to_bytes('2B', default_unit='P')
    assert bytes_ == 2
    bytes_ = human_to_bytes('1MB', default_unit='P')
    assert bytes_ == 1048576
    bytes_ = human_to_bytes('3.4MB')
    assert bytes_ == 3565158
    bytes_ = human_to_bytes('3.4Mb', isbits=True)
    assert bytes_ == 3565158
    bytes_ = human_to_bytes('1Mb', isbits=True)
    assert bytes_ == 1048576
    bytes_ = human_to_bytes('3Mb', isbits=True)
    assert bytes_ == 3145728
    bytes_ = human_

# Generated at 2022-06-24 21:07:12.281041
# Unit test for function human_to_bytes
def test_human_to_bytes():
    pass



# Generated at 2022-06-24 21:07:21.059805
# Unit test for function human_to_bytes
def test_human_to_bytes():
    str_0 = '5Dm>Ft'
    var_0 = human_to_bytes(str_0)
    expect_0 = 5.0
    assert var_0 == expect_0

    str_1 = '2100'
    unit_1 = 'Mb'
    var_1 = human_to_bytes(str_1, unit_1, isbits=True)
    expect_1 = 268435456.0
    assert var_1 == expect_1

    str_2 = '2100'
    unit_2 = 'MB'
    var_2 = human_to_bytes(str_2, unit_2, isbits=False)
    expect_2 = 214748364800.0
    assert var_2 == expect_2

if __name__ == "__main__":
    test_case

# Generated at 2022-06-24 21:07:23.366028
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        test_case_0()
    except Exception as error_msg:
        print(error_msg)

# Main function for unit testing.

# Generated at 2022-06-24 21:07:26.939837
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # assert str(machine_data.parse_config_line('type',
    #                                           'ip4:192.168.10.1/24')) == 'ETHERNET'
    test_case_0()


# Generated at 2022-06-24 21:07:35.305244
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert bytes_to_human(human_to_bytes('10M')) == '10M'
    assert bytes_to_human(human_to_bytes('1MB')) == '1M'
    assert bytes_to_human(human_to_bytes('10Mb', isbits=True)) == '10Mb'
    assert bytes_to_human(human_to_bytes('1Mb', isbits=True)) == '1Mb'
    assert bytes_to_human(human_to_bytes('1.5M', unit='B')) == '1.50M'
    assert bytes_to_human(human_to_bytes('1.5M', unit='MB')) == '1.50M'

# Generated at 2022-06-24 21:07:39.262753
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test-case 0
    str_0 = '5Dm>Ft'
    var_0 = human_to_bytes(str_0)


# Generated at 2022-06-24 21:07:50.236915
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert (human_to_bytes('10M') == 10485760)
    assert (human_to_bytes('    10M', default_unit='B') == 10485760)
    assert (human_to_bytes(10, 'M') == 10485760)
    assert (human_to_bytes('10Mb', isbits=True) == 1048576)
    assert (human_to_bytes('10m', isbits=True) == 1048576)
    assert (human_to_bytes('10Mb') == 10485760)
    assert (human_to_bytes('10MB', isbits=True) == 1048576)
    assert (human_to_bytes('   10M') == 10485760)
    assert (human_to_bytes('   10M ') == 10485760)

# Generated at 2022-06-24 21:07:59.769020
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1g') == 1073741824
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1t') == 1099511627776
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1p') == 1125899906842624
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1e') == 1152921504606846976

# Generated at 2022-06-24 21:08:10.412536
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('10') == 10
    assert human_to_bytes('100') == 100
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1MB', isbits=False) == 1048576
    assert human_to_bytes('1MB', isbits=True) == 8388608
    assert human_to_bytes('1Mb', isbits=True) == 8388608
    assert human_to_bytes('1M', isbits=True) == 8388608
    assert human_to_bytes('1M', default_unit='KB') == 1024
    assert human_to_bytes('1M', default_unit='MB') == 1048576
   

# Generated at 2022-06-24 21:08:15.304043
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    bytes_0 = b"8j\x91U\xed\x1c\x87\x07'\x89\x83\x02)\xc6\x07&"
    var_0 = lenient_lowercase(bytes_0)


# Generated at 2022-06-24 21:08:18.549624
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('1.5B') == 1
    assert human_to_bytes('10b', True) == 10
    assert human_to_bytes('1.5Gb', True) == 15728640



# Generated at 2022-06-24 21:08:23.753013
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'MB') == 10485760


# Generated at 2022-06-24 21:08:31.096974
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test positive case
    result = human_to_bytes('10MB')
    expected = 10485760
    assert result == expected
    # Test negative case
    result = human_to_bytes('-10MB')
    assert result == -1



# Generated at 2022-06-24 21:08:38.230994
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        assert human_to_bytes('10M') == 10485760
        assert human_to_bytes('10', 'M') == 10485760
    except Exception:
        pass

    try:
        assert human_to_bytes('10MB') == 10485760
        assert human_to_bytes('10', 'MB') == 10485760
    except Exception:
        pass

    try:
        assert human_to_bytes('10Mb', isbits=True) == 10485760
        assert human_to_bytes('10', 'Mb', isbits=True) == 10485760
    except Exception:
        pass


# Generated at 2022-06-24 21:08:47.574055
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase("test string") == "test string"
    assert lenient_lowercase("Test STRING") == "Test STRING"
    assert lenient_lowercase("Žluťoučký koníček") == "Žluťoučký koníček"
    assert lenient_lowercase("Žluťoučký koníček".encode("UTF-8")) == "Žluťoučký koníček"
    assert lenient_lowercase([1, 2, "test string"]) == [1, 2, "test string"]

# Generated at 2022-06-24 21:08:57.143883
# Unit test for function bytes_to_human

# Generated at 2022-06-24 21:09:05.803572
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(100) == '100.00 Bytes'
    assert bytes_to_human(100, 'KB') == '0.09 KB'
    assert bytes_to_human(100, 'MB') == '0.00 MB'
    assert bytes_to_human(100, 'GB') == '0.00 GB'
    assert bytes_to_human(100, 'B') == '100.00 Bytes'
    assert bytes_to_human(100, 'b') == '800.00 bits'
    assert bytes_to_human(100, 'B', True) == '100.00 Bytes'
    assert bytes_to_human(100, 'b', True) == '800.00 bits'
    assert bytes_to_human(100, 'Kb', True) == '1.00 Kbits'

# Generated at 2022-06-24 21:09:12.942891
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase([1, 'tESt', 3]) == [1, 'test', 3]


# Generated at 2022-06-24 21:09:14.954212
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        human_to_bytes('10M') # convert with human readable format
        human_to_bytes(10, 'M') # convert with unit argument
    except ValueError as e:
        print(e)


# Generated at 2022-06-24 21:09:26.427899
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # example: bytes_to_human(128991) returns '126.74 KB'
    bytes_0 = b"8j\x91U\xed\x1c\x87\x07'\x89\x83\x02)\xc6\x07&"
    assert bytes_to_human(bytes_0) == '128.99 Bytes'
    # example: bytes_to_human(100001221) returns '95.4 MB'
    bytes_1 = b"\x8b\x9b\x91\xe4\x84\x8a\x93\xa6\x87\x07'\x89\x83\x02)\xc6\x07&"
    assert bytes_to_human(bytes_1) == '95.40 MB'
    # example: bytes_to_human(

# Generated at 2022-06-24 21:09:37.758658
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2k') == 2048
    assert human_to_bytes('4096B') == 4096
    assert human_to_bytes('4096b') == 4096
    assert human_to_bytes('8Mb') == 8388608
    assert human_to_bytes('8mb') == 8388608
    assert human_to_bytes('8.5Mb') == 8847360
    assert human_to_bytes('8.5mb') == 8847360
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10mb') == 10485760
    assert human_to_bytes('1GB') == 1073741824

# Generated at 2022-06-24 21:09:44.510052
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10.5k') == 10752
    assert human_to_bytes('10.5K') == 10752
    assert human_to_bytes('10.5b') == 10.5
    assert human_to_bytes('10.5B') == 8.4
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes('10.5b', isbits=True) == 10.5
    assert human_to_bytes('10.5B', isbits=True) == 8.4
    assert human_to_bytes('10.5kB', isbits=True) == 838860.8
    assert human_to_bytes(10, 'Mb', isbits=True) == 1048

# Generated at 2022-06-24 21:09:51.414559
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('10M') == 10485760)
    assert(human_to_bytes(10, 'M') == 10485760)
    assert(human_to_bytes('10m') == 10485760)
    assert(human_to_bytes(10, 'm') == 10485760)
    assert(human_to_bytes('10MB') == 10485760)
    assert(human_to_bytes(10, 'MB') == 10485760)
    assert(human_to_bytes('10Mb') == 10485760)
    assert(human_to_bytes(10, 'Mb') == 10485760)
    assert(human_to_bytes('10M', isbits=True) == 10485760)

# Generated at 2022-06-24 21:09:59.077774
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # test default case
    assert b'10.00 Bytes' == bytes_to_human(10)
    assert b'10.00 Bytes' == bytes_to_human(10, isbits=False)

    assert b'2.00 KB' == bytes_to_human(1024)
    assert b'2.00 KB' == bytes_to_human(1024, isbits=False)


# Generated at 2022-06-24 21:10:08.047605
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert (lenient_lowercase('value')) == 'value'
    assert (lenient_lowercase(1)) == 1
    assert (lenient_lowercase(['value','B'])) == ['value','B']
    assert (lenient_lowercase([1,2])) == [1,2]
    assert (lenient_lowercase(('value','B'))) == ('value','B')
    assert (lenient_lowercase((1,2))) == (1,2)



# Generated at 2022-06-24 21:10:15.643786
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1") == 1
    assert human_to_bytes("1") == human_to_bytes("1", 'B')
    assert human_to_bytes("1") == human_to_bytes("1", default_unit='B')
    assert human_to_bytes("1B") == human_to_bytes("1", 'B')
    assert human_to_bytes("1B") == human_to_bytes("1", default_unit='B')
    assert human_to_bytes("1b") == human_to_bytes("1", 'b')
    assert human_to_bytes("1b") == human_to_bytes("1", default_unit='b')
    assert human_to_bytes("1", 'b') == human_to_bytes("8", 'B')

# Generated at 2022-06-24 21:10:21.379660
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    bytes_0 = b"8j\x91U\xed\x1c\x87\x07'\x89\x83\x02)\xc6\x07&"
    assert lenient_lowercase(bytes_0) == [b'8j\x91u\xed\x1c\x87\x07\'\x89\x83\x02)\xc6\x07&']



# Generated at 2022-06-24 21:10:38.040620
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # default_unit is None
    assert human_to_bytes('1MB') == 1048576

    # default_unit is provided
    assert human_to_bytes('1', 'MB') == 1048576

    # float
    assert human_to_bytes('1.2MB') == 1258291

    # int
    assert human_to_bytes(1.2, 'MB') == 1258291

    # isbits=False (default)
    assert human_to_bytes('1Mb', isbits=False) == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 131072

    # isbits=True
    assert human_to_bytes('1MB', isbits=True) == 8388608
    assert human_to_bytes('1MB', isbits=False) == 1048576



# Generated at 2022-06-24 21:10:47.199657
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert lenient_lowercase("HELLO") == ['hello']
    assert bytes_to_human(1) == '1.00 Bytes'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, unit='B') == '1.00 Bytes'
    assert bytes_to_human(1, unit='bits') == '1.00 bits'
    assert bytes_to_human(2, unit='B') == '2.00 Bytes'
    assert bytes_to_human(2, unit='B') == '2.00 Bytes'
    assert bytes_to_human(2, unit='bits') == '2.00 bits'
    assert bytes_to_human(3, unit='B') == '3.00 Bytes'
    assert bytes_

# Generated at 2022-06-24 21:10:54.851020
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = human_to_bytes('10M', default_unit=None, isbits=False)
    assert result == 10485760 
    result = human_to_bytes(10.0, default_unit=None, isbits=False)    
    assert result == 10.0 
    result = human_to_bytes(10.0, default_unit='M', isbits=False)
    assert result == 10485760 
    #
    result = human_to_bytes('10Mb', default_unit=None, isbits=True)
    assert result == 10485760
    result = human_to_bytes('10MB', default_unit=None, isbits=False)
    assert result == 10485760
    result = human_to_bytes('10Mb', default_unit=None, isbits=False)


# Generated at 2022-06-24 21:10:55.561066
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    pass


# Generated at 2022-06-24 21:11:04.456427
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1M', isbits=True) == 8388608
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1MB', isbits=True) == 8388608
    assert human_to_bytes('1Mb') == 8388608
    assert human_to_bytes('1Mb', isbits=True) == 8388608
    assert human_to_bytes('1mb') == 8388608
    assert human_to_bytes('1mb', isbits=True) == 8388608
    assert human_to_bytes('1048576') == 1048576
    assert human_to_bytes('1048576', isbits=True) == 8388608

# Generated at 2022-06-24 21:11:06.870044
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    #  lenient_lowercase()
    test_case_0()

# Generated at 2022-06-24 21:11:13.543128
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([0]) == [0]
    assert lenient_lowercase(["Hello"]) == ["hello"]
    assert lenient_lowercase(["Hello", "WORLD"]) == ["hello", "world"]
    assert lenient_lowercase(["Hello", "1", "WORLD"]) == ["hello", "1", "world"]
    assert lenient_lowercase(["Hello", 1, "WORLD"]) == ["hello", 1, "world"]


# Generated at 2022-06-24 21:11:17.694348
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes(10, 'm') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 134217728
    assert human_to_bytes(10, 'm', isbits=True) == 134217728



# Generated at 2022-06-24 21:11:27.729749
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # check if validation occurs when suffix is not passed
    try:
        bytes_to_human(10, False, None)
    except ValueError:
        pass
    else:
        raise Exception("bytes_to_human function doesn't validate when suffix is not passed")
    # assert if default value is returned
    assert bytes_to_human(10) == '10 Bytes'
    # check if correct value is returned for the passed data
    assert bytes_to_human(10, unit='b') == '10 bits'
    # check if correct value is returned for the passed data
    assert bytes_to_human(10, unit='B') == '10 Bytes'
    # check if correct value is returned for the passed data
    assert bytes_to_human(10, default_unit='B') == '10 Bytes'
    # check if correct value is

# Generated at 2022-06-24 21:11:38.432097
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test_case_0
    try:
        result = human_to_bytes('1024')
        print (result)
    except Exception:
        print('test_case_0 failed')
    # test_case_1
    try:
        result = human_to_bytes('10M')
        print (result)
    except Exception:
        print('test_case_1 failed')
    # test_case_2
    try:
        result = human_to_bytes('10MB')
        print (result)
    except Exception:
        print('test_case_2 failed')
    # test_case_3
    try:
        result = human_to_bytes('10MBb')
        print (result)
    except Exception:
        print('test_case_3 failed')
    # test_case_4

# Generated at 2022-06-24 21:11:52.784149
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test variables
    bytes_0 = b"8j\x91U\xed\x1c\x87\x07'\x89\x83\x02)\xc6\x07&"

    try:
        # Test function
        var_0 = lenient_lowercase(bytes_0)
    except Exception as e:
        # Catches exception
        errorMsg = "Exception '{}' raised for function 'lenient_lowercase' with args '{}'".format(e, bytes_0)
    assert True, errorMsg



# Generated at 2022-06-24 21:12:07.444983
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("10M") == 10485760
    assert human_to_bytes("10M", isbits=False) == 10485760
    assert human_to_bytes("10M", isbits=True) == 10485760*8
    assert human_to_bytes("1K", isbits=True) == 1024*8
    assert human_to_bytes("10Mb", isbits=True) == 10485760
    assert human_to_bytes("10Mb", default_unit=None, isbits=True) == 10485760
    assert human_to_bytes("10Mb", default_unit='M', isbits=True) == 10485760

    # If the suffix is single 'b', it is perceived as a bit suffix (lowercase) (default_unit ignored)
    assert human_to_

# Generated at 2022-06-24 21:12:18.544909
# Unit test for function bytes_to_human
def test_bytes_to_human():
    byte_0 = 393
    byte_0_output = "393.00 Bytes"
    assert(bytes_to_human(byte_0) == byte_0_output)

    byte_1 = 2097152
    byte_1_output = "2.00 Mb"
    assert(bytes_to_human(byte_1) == byte_1_output)

    byte_2 = 8388608
    byte_2_output = "8.00 MB"
    assert(bytes_to_human(byte_2) == byte_2_output)

    byte_3 = 536870912
    byte_3_output = "512.00 MB"
    assert(bytes_to_human(byte_3) == byte_3_output)

    byte_4 = 2147483648

# Generated at 2022-06-24 21:12:29.616979
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K', 'B') == 1024
    assert human_to_bytes('1K', isbits=True) == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 1048576

# Generated at 2022-06-24 21:12:38.741742
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(245760) == '240 KB'
    assert bytes_to_human(245760, isbits=False) == '240 KB'
    assert bytes_to_human(245760, isbits=False, unit='m') == '0.24 MB'
    assert bytes_to_human(245760, isbits=False, unit='MB') == '0.24 MB'
    assert bytes_to_human(245760, isbits=False, unit='mb') == '0.24 MB'
    assert bytes_to_human(245760, isbits=False, unit='k') == '240 KB'
    assert bytes_to_human(245760, isbits=False, unit='B') == '240 KB'

# Generated at 2022-06-24 21:12:46.570735
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    e0 = b'foobar'
    a0 = lenient_lowercase(e0)
    assert a0 == e0, "failed: lenient_lowercase(b'foobar') == b'foobar'"

    # Generate an array of bytes and let's convert it to lowercase.
    # This will allow us to test the exception handling in lenient_lowercase.
    # NOTE: Our expected result is the same, since we didn't ask to modify bytes.
    e1 = b'foobar'
    a1 = lenient_lowercase([b'f', b'o', b'o', b'b', b'a', b'r'])

# Generated at 2022-06-24 21:12:55.384194
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test case 1
    bytes_1 = b"\xd0\xf2\xdcz\x88\xb0\x01\xcb\x08\x83\xe9\x99\x1f\x84\xbcV"
    var_1 = human_to_bytes(bytes_1)
    # Assert function call with argument bytes_1 in correct format
    assert var_1 == 5052732050901081888

    # Test case 2
    bytes_2 = b"z\xe5\xa0c\x90\xa1\x1d\x97\x9f\x8f\x91\xd4\xb5\xe4\xa8m\x16"
    var_2 = human_to_bytes(bytes_2)
    # Assert function call with argument bytes_2 in correct format

# Generated at 2022-06-24 21:13:01.421661
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(2) == '2.00 Bytes'
    assert bytes_to_human(2, isbits=True) == '2.00 bits'
    assert bytes_to_human(2, unit='b') == '2.00 bits'
    assert bytes_to_human(2048, unit='K') == '2.00 KB'

    assert bytes_to_human(2048) == '2.00 KB'
    assert bytes_to_human(2048, isbits=True) == '2.00 Kb'


# Generated at 2022-06-24 21:13:10.134828
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes('10Mb') == human_to_bytes(10, 'Mb', isbits=True)
    assert human_to_bytes('10', 'M') == human_to_bytes(10, 'M')
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes('10 Mb', isbits=True) == human_to_bytes(10, 'Mb', isbits=True)
    assert human_to_bytes('10', 'Mb', isbits=True) == human_to_bytes(10, 'Mb', isbits=True)
    assert human_to_bytes(10, 'Mb', isbits=True) == 10485760
   

# Generated at 2022-06-24 21:13:15.492033
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_case_0()



# Generated at 2022-06-24 21:13:29.205687
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1kB') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1kb') == 1000
    assert human_to_bytes('1KB', isbits=True) == 1000
    assert human_to_bytes('1kb', isbits=True) == 1000
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1MM', unit='b') == 1000000
    assert human_to_bytes('1.5BB') == 1536
    assert human_to_bytes('1.5B', default_unit='b') == 1536
    assert human_to_bytes('1.5 BB') == 1536
    assert human_to

# Generated at 2022-06-24 21:13:34.720008
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    bytes_0 = b"8j\x91U\xed\x1c\x87\x07'\x89\x83\x02)\xc6\x07&"
    var_0 = lenient_lowercase(bytes_0)
    assert var_0 == b"8j\x91u\xed\x1c\x87\x07'\x89\x83\x02)\xc6\x07&"


# Generated at 2022-06-24 21:13:44.067972
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('100k') == 102400
    assert human_to_bytes('100KB') == 102400
    assert human_to_bytes('100Kb') == 102400
    assert human_to_bytes('100M') == 104857600
    assert human_to_bytes('100MB') == 104857600
    assert human_to_bytes('100Mb') == 104857600
    assert human_to_bytes('1.2M') == 1258291
    assert human_to_bytes('1.1K') == 1125
    assert human_to_bytes('1.1k') == 1125
    assert human_to_bytes('10') == 10
    assert human_to_bytes('1K') == 1000
    assert human_to_bytes('1k', default_unit='K') == 1000

# Generated at 2022-06-24 21:13:52.117273
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10, 'MB') == 10485760
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10.34M') == 10893732
    assert human_to_bytes('01M') == 1048576
    assert human_to_bytes('01.00M') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.1M') == 1179648
    assert human_to_bytes('1.1.1M') == 1179648
    assert human_to_bytes('1.1.1Mb', isbits=True) == 1152000

# Generated at 2022-06-24 21:14:00.226637
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """ Test case for human_to_bytes """
    results = []
    # Test case 0
    results.append({
        'test': 'human_to_bytes(10, "M") == 10 * (1<<20)',
        'expected': True,
        'actual': human_to_bytes(10, 'M') == 10 * (1<<20),
        'notes': '10 is expected to be equal to 10 * (1<<20)'
    })

    # Test case 1
    results.append({
        'test': 'human_to_bytes("1MB") == (1<<20)',
        'expected': True,
        'actual': human_to_bytes("1MB") == (1<<20),
        'notes': '1MB is expected to be equal to (1<<20)'
    })

    # Test case 2
   

# Generated at 2022-06-24 21:14:01.814459
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(expected) == actual


# Generated at 2022-06-24 21:14:09.264341
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    bytes_0 = b"8j\x91U\xed\x1c\x87\x07'\x89\x83\x02)\xc6\x07&"
    var_0 = lenient_lowercase(bytes_0)
    assert var_0 == [b'8j', b'U', b'ed', b'1c', b'87', b'07', b'89', b'83', b'02', b'c6', b'07', b'&']

# Generated at 2022-06-24 21:14:20.117138
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes(2, 'M') == 2097152
    assert human_to_bytes('2K', 'M') == 2048
    assert human_to_bytes('2K', 'm') == 2048 * 8
    assert human_to_bytes('2Kb') == 2048
    assert human_to_bytes(2, 'm') == 2 * 8
    assert human_to_bytes('2Kb', 'm') == 2048
    assert human_to_bytes(2, 'Mb') == 2 * 8 * 1048576
    assert human_to_bytes('2.5K') == 2560
    assert human_to_bytes('2.5K', 'M') == 2560
    assert human_to_bytes('2.5Kb') == 2560

# Generated at 2022-06-24 21:14:25.607862
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert test_case_0() == '8j\x91u\xed\x1c\x87\x07\'\x89\x83\x02)\xc6\x07&'


# Generated at 2022-06-24 21:14:31.984061
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    bytes_0 = b"8j\x91U\xed\x1c\x87\x07'\x89\x83\x02)\xc6\x07&"
    var_0 = lenient_lowercase(bytes_0)
    print(var_0)
    assert isinstance(var_0, list), "Expect var_0 to be a list"
    assert var_0 == [8, 105, 145, 85, 237, 28, 135, 7, 39, 137, 131, 2, 41, 198, 7, 38], "Incorrect var_0"



# Generated at 2022-06-24 21:14:53.819629
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    bytes_0 = b"8j\x91U\xed\x1c\x87\x07'\x89\x83\x02)\xc6\x07&"
    var_0 = lenient_lowercase(bytes_0)
    assert var_0 == [56, 106, 145, 85, 237, 28, 135, 7, 39, 137, 131, 2, 41, 198, 7, 38]
    str_0 = '3'
    var_1 = lenient_lowercase(str_0)
    assert var_1 == '3'
    list_0 = ['1', '2', 3]
    var_2 = lenient_lowercase(list_0)
    assert var_2 == ['1', '2', 3]
    dict_0 = {3: '3', '4': 4}
   

# Generated at 2022-06-24 21:15:03.198410
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test1: success
    assert human_to_bytes('10M') == 10485760

    # test2: success
    assert human_to_bytes(10, 'M') == 10485760

    # test3: success
    try:
        human_to_bytes('1MB')
    except Exception as e:
        assert "human_to_bytes() failed to convert 1MB" in str(e)
    else:
        assert False, "Expected error"

    # test4: success
    try:
        human_to_bytes('10MB', 'K')
    except Exception as e:
        assert "human_to_bytes() failed to convert 10MB. Value is not a valid string (expect MBytes or MB)" in str(e)
    else:
        assert False, "Expected error"

    # test5

# Generated at 2022-06-24 21:15:08.760855
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    tmp = b"8j\x91U\xed\x1c\x87\x07'\x89\x83\x02)\xc6\x07&"
    var_0 = b"8j\x91u\xed\x1c\x87\x07'\x89\x83\x02)\xc6\x07&"
    assert lenient_lowercase(tmp) == var_0
    return True


# Generated at 2022-06-24 21:15:10.174838
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        return False

    return True


# Generated at 2022-06-24 21:15:17.046839
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test human_to_bytes with no parameters
    print(human_to_bytes())
    # Test human_to_bytes with one parameter
    print(human_to_bytes(10))
    # Test human_to_bytes with two parameters
    print(human_to_bytes(10, 'B'))
    # Test human_to_bytes with two parameters
    print(human_to_bytes(10, 'B', isbits=False))
    # Test human_to_bytes with two parameters
    print(human_to_bytes(10, 'B', isbits=True))
    # Test human_to_bytes with two parameters
    print(human_to_bytes(8, 'b', isbits=True))
    # Test human_to_bytes with two parameters

# Generated at 2022-06-24 21:15:22.711261
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    out1 = lenient_lowercase((b"8j\x91U\xed\x1c\x87\x07'\x89\x83\x02)\xc6\x07&", 'b'))
    assert out1 == (b"8j\x91U\xed\x1c\x87\x07'\x89\x83\x02)\xc6\x07&", 'b')


# Generated at 2022-06-24 21:15:28.907326
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        test_case_0()
    except Exception as err:
        print('Test case 0 failed: {0}'.format(err))
    else:
        print('Test case 0 passed')



# Generated at 2022-06-24 21:15:30.915924
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 1]) == ['a', 'b', 1], 'Test failed'


# Generated at 2022-06-24 21:15:40.519333
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ''.lower() == lenient_lowercase('')
    assert ''.lower() == lenient_lowercase(u'')
    assert '1'.lower() == lenient_lowercase('1')
    assert '1'.lower() == lenient_lowercase(u'1')
    assert '1'.lower() == lenient_lowercase(b'1')
    assert '1'.lower() == lenient_lowercase('1'.encode())
    assert '1'.lower() == lenient_lowercase(b'1'.decode())
    assert [1, 2, 3] == lenient_lowercase([1, 2, 3])
    assert ['1', '2', '3'] == lenient_lowercase(['1', '2', '3'])
    assert ['1', '2', '3'] == lenient_lowercase

# Generated at 2022-06-24 21:15:49.232143
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1K', isbits=True) == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes(10, 'KB') == 10 * 1024
    assert human_to_bytes(10, 'KB', True) == 10 * 1024
    assert human_to_bytes(10, 'KB', isbits=True) == 10 * 1024

# Generated at 2022-06-24 21:16:19.227457
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # No exception raised
    try:
        test_case_0()
    except Exception:
        assert False



# Generated at 2022-06-24 21:16:27.699445
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes('1Kb', isbits=True) == human_to_bytes(1024, 'Kb', isbits=True)
    assert human_to_bytes('1Kb') == human_to_bytes(1, 'K', isbits=False)
    assert human_to_bytes('1', 'K') == human_to_bytes(1, 'K', isbits=False)
    assert human_to_bytes('100', 'K') == human_to_bytes(100, 'K', isbits=False)
    assert human_to_bytes('1', 'K', isbits=True) == human_to_bytes(1, 'K', isbits=True)

# Generated at 2022-06-24 21:16:33.368529
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

# Generated at 2022-06-24 21:16:44.692804
# Unit test for function human_to_bytes
def test_human_to_bytes():

    bytes1 = human_to_bytes('10')
    bytes2 = human_to_bytes('1Gb')
    bytes3 = human_to_bytes('1MB')
    bytes4 = human_to_bytes('1KB')
    bytes5 = human_to_bytes('10.24B')
    bytes6 = human_to_bytes('1Mb', isbits=True)
    bytes7 = human_to_bytes('10b', isbits=True)

    correct_values = (10, 1073741824, 1048576, 1024, 10.24, 1048576, 10)