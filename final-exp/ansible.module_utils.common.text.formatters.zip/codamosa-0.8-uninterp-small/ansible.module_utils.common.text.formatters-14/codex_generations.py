

# Generated at 2022-06-24 21:06:53.844632
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # basic test (unit is None)
    assert bytes_to_human(1024) == '1.00 KB'
    assert bytes_to_human(1024000) == '1.00 MB'
    assert bytes_to_human(1024000000) == '1.00 GB'
    assert bytes_to_human(102400000000) == '1.00 TB'
    assert bytes_to_human(102400000000000) == '1.00 PB'
    assert bytes_to_human(102400000000000000) == '1.00 EB'
    # basic test (unit is not None, B)
    assert bytes_to_human(1024, unit='B') == '1.00 KB'
    assert bytes_to_human(1024000, unit='B') == '1.00 MB'

# Generated at 2022-06-24 21:06:57.782898
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    tuple_0 = None
    var_0 = lenient_lowercase(tuple_0)
    if var_0 is None:
        print("Test Passed")
    else:
        print("Test Failed")


# Generated at 2022-06-24 21:07:02.718688
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(2, 'MB') == 2097152
    assert human_to_bytes(2, 'Mb', isbits=True) == 2097152
    assert human_to_bytes(2097152, 'B') == 2097152
    assert human_to_bytes(2097152) == 2097152
    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('2MB') == 2097152


# Generated at 2022-06-24 21:07:11.081863
# Unit test for function human_to_bytes
def test_human_to_bytes():
    value = human_to_bytes('1.1kB')
    assert value == 1150
    value = human_to_bytes('1.1Kb')
    assert value == 11450
    value = human_to_bytes('1150')
    assert value == 1150
    value = human_to_bytes('1Mb')
    assert value == 1048576
    value = human_to_bytes('1MB', unit='m')
    assert value == 1048576
    value = human_to_bytes('1MB', unit='M')
    assert value == 1048576
    value = human_to_bytes('1MB', unit='mb')
    assert value == 1048576
    value = human_to_bytes('1MB', unit='Mb')
    assert value == 1048576

# Generated at 2022-06-24 21:07:15.398306
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    # Inputs
    input_value_0 = ['', '', '', '', '', '', '', '', '', '']

    # Outputs
    output = None

    with mock.patch(builtin_string + '.open') as mock_open:
        with mock.patch(builtin_string + '.open') as mock_open2:
            mock_open.return_value = mock.MagicMock()
            mock_open2.return_value = mock.MagicMock()

            # Invoke Method
            # Returns
            return_value = None

            # ExecuteFunction
            function_name = 'function_name'
            return_value = self.execute_function(function_name)

            # Verify
            assert return_value == output

# Generated at 2022-06-24 21:07:22.462566
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('2048') == 2048
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10B', isbits=True) == 10
    assert human_to_bytes('10b', isbits=True) == 10
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10', isbits=True) == 10
    assert human_to_bytes('1MB', isbits=True) == 8388608
    assert human_to_bytes('1M', default_unit='B') == 1048576


# Generated at 2022-06-24 21:07:32.223565
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    tuple_0 = (1, 2,)
    var_0 = lenient_lowercase(tuple_0)
    assert var_0 == (1, 2,)
    tuple_1 = ((1,),)
    var_1 = lenient_lowercase(tuple_1)
    assert var_1 == ((1,),)
    tuple_2 = (1,)
    var_2 = lenient_lowercase(tuple_2)
    assert var_2 == (1,)
    tuple_3 = (1, 2,)
    var_3 = lenient_lowercase(tuple_3)
    assert var_3 == (1, 2,)
    tuple_4 = ((1,), 2, 'Z', 'Y', ('T',),)
    var_4 = lenient_lowercase(tuple_4)
    assert var

# Generated at 2022-06-24 21:07:42.755436
# Unit test for function human_to_bytes
def test_human_to_bytes():
    number, default_unit = '10M', None
    var_1 = human_to_bytes(number, default_unit)
    assert var_1 == 10485760

    number, default_unit = '10M', 'KB'
    var_2 = human_to_bytes(number, default_unit)
    assert var_2 == 10485760

    number, default_unit = '10M', 'EB'
    try:
        var_3 = human_to_bytes(number, default_unit)
    except AttributeError:
        pass
    except Exception:
        pass

    number, default_unit = '10Mb', 'EBb'
    var_4 = human_to_bytes(number, default_unit, True)
    assert var_4 == 13421772800

    number, default_unit = 10,

# Generated at 2022-06-24 21:07:51.567614
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10) == 10
    assert human_to_bytes('1b') == 1

    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1Byte') == 1
    assert human_to_bytes('1Bytes') == 1

    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Ki') == 1024
    assert human_to_bytes('1Kib') == 1024
    assert human_to_bytes('1Kibibyte') == 1024

    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mi') == 1048576
    assert human_to_

# Generated at 2022-06-24 21:07:59.151087
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # check with string representation of number
    assert human_to_bytes("10") == 10
    assert human_to_bytes("10.2") == 10
    assert human_to_bytes("-10") == -10
    assert human_to_bytes("-10.2") == -10
    assert human_to_bytes("10.2K") == 10.2 * 1024
    assert human_to_bytes("10.2M") == 10.2 * 1024 * 1024
    assert human_to_bytes("10.2G") == 10.2 * 1024 * 1024 * 1024
    assert human_to_bytes("10.2T") == 10.2 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes("10.2P") == 10.2 * 1024 * 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-24 21:08:07.405429
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # When isbits is False (default), converts bytes from a human-readable format to integer.
    assert human_to_bytes('1MB', isbits = False) == 1048576
    # When isbits is True, converts bits from a human-readable format to integer.
    assert human_to_bytes('1Mb', isbits = True) == 1048576



# Generated at 2022-06-24 21:08:14.277283
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    tuple_0 = None
    var_0 = lenient_lowercase(tuple_0)
    tuple_0 = ('', 'str_0')
    var_1 = lenient_lowercase(tuple_0)
    tuple_0 = ('str_0',)
    var_2 = lenient_lowercase(tuple_0)
    tuple_0 = ('str_0', 'str_1')
    var_3 = lenient_lowercase(tuple_0)
    tuple_0 = ('str_0', '', '')
    var_4 = lenient_lowercase(tuple_0)


# Generated at 2022-06-24 21:08:23.896116
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    tuple_0 = ()
    var_0 = lenient_lowercase(tuple_0)
    tuple_1 = (None,)
    var_1 = lenient_lowercase(tuple_1)
    str_2 = 'Foo'
    tuple_2 = (str_2, 'bar')
    var_2 = lenient_lowercase(tuple_2)
    str_3 = 'baz'
    tuple_3 = (str_2, str_3)
    var_3 = lenient_lowercase(tuple_3)
    str_4 = 'Foo BA R'
    tuple_4 = (str_2, str_3, str_4)
    var_4 = lenient_lowercase(tuple_4)


# Generated at 2022-06-24 21:08:29.354014
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes(1, 'KB') == 1024
    assert human_to_bytes('1.5KB') == 1536
    assert human_to_bytes(1.5, 'KB') == 1536
    assert human_to_bytes('-1KB') == -1024
    assert human_to_bytes(-1, 'KB') == -1024
    assert human_to_bytes('-1.5KB') == -1536
    assert human_to_bytes(-1.5, 'KB') == -1536
    assert human_to_bytes(1024) == 1024
    assert human_to_bytes(1024, 'B') == 1024
    assert human_to_bytes(1024, 'bits') == 1024
    assert human_to_bytes(1024, 'b') == 1024


# Generated at 2022-06-24 21:08:30.373626
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    print(test_case_0())



# Generated at 2022-06-24 21:08:37.821117
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    arg_0 = (1,2,3,'f','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z')
    try:
        retval_0 = lenient_lowercase(arg_0)
    except Exception as err:
        raise Exception('Exception raised when calling lenient_lowercase(): %s' % err)
    if retval_0 != (1, 2, 3, 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'):
        raise Exception('Return values do not match')

# Generated at 2022-06-24 21:08:47.357868
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    tuple_0 = None
    var_0 = lenient_lowercase(tuple_0)
    assert var_0 == None, "Function lenient_lowercase did not return expected result. Expected: None. Got: %s" % var_0
    tuple_1 = ['a', 'b', 'c']
    var_1 = lenient_lowercase(tuple_1)
    assert var_1 == ['a', 'b', 'c'], "Function lenient_lowercase did not return expected result. Expected: ['a', 'b', 'c']. Got: %s" % var_1
    tuple_2 = [1, 2, 3]
    var_2 = lenient_lowercase(tuple_2)

# Generated at 2022-06-24 21:08:53.138730
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        # Case 0
        tuple_0 = None
        var_0 = lenient_lowercase(tuple_0)
        assert var_0 is None, 'Case 0 ==> failed'
    except AssertionError:
        print('Test Case 0 failed')



# Generated at 2022-06-24 21:08:55.837078
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Check with empty
    assert lenient_lowercase(None) == []
    assert lenient_lowercase([]) == []



# Generated at 2022-06-24 21:09:03.773120
# Unit test for function bytes_to_human
def test_bytes_to_human():
    print(bytes_to_human(5))
    print(bytes_to_human(5, unit='B'))
    print(bytes_to_human(5, unit='P'))
    print(bytes_to_human(5, unit='p'))
    print(bytes_to_human(5, isbits=True))
    print(bytes_to_human(5, isbits=True, unit='b'))
    print(bytes_to_human(5, isbits=True, unit='p'))


# Generated at 2022-06-24 21:09:11.683104
# Unit test for function human_to_bytes
def test_human_to_bytes():
    input_0 = '1b'
    isbits_0 = True
    expected = 1

    actual = human_to_bytes(input_0, default_unit=None, isbits=isbits_0)
    assert actual == expected

    input_1 = '1b'
    isbits_1 = False
    expected = 1

    actual = human_to_bytes(input_1, default_unit=None, isbits=isbits_1)
    assert actual == expected

    input_2 = '1kB'
    isbits_2 = False
    expected = 1024

    actual = human_to_bytes(input_2, default_unit=None, isbits=isbits_2)
    assert actual == expected

    input_3 = '1MB'
    isbits_3 = False
    expected = 1048576


# Generated at 2022-06-24 21:09:21.389000
# Unit test for function lenient_lowercase

# Generated at 2022-06-24 21:09:30.191698
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test case : human_to_bytes() with default unit
    assert human_to_bytes('16M') == 16 * 1024 ** 2
    assert human_to_bytes('10m') == 10 * 1024 ** 2
    assert human_to_bytes('10Mb') == 10 * 1024 ** 2
    assert human_to_bytes('10MB', isbits=True) == 10 * 1024 ** 2
    assert human_to_bytes('10Mb', isbits=True) == 10 * 1024 ** 2
    assert human_to_bytes('10.1.1Mb', isbits=True) == 10 * 1024 ** 2
    assert human_to_bytes('10.1.1M', isbits=True) == 10 * 1024 ** 2
    assert human_to_bytes('10.1Mb', isbits=True) == 10 * 1024 ** 2
   

# Generated at 2022-06-24 21:09:40.174180
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('##### Running unit test for human_to_bytes')
    print(human_to_bytes('1Mb', isbits=True))
    print(human_to_bytes('1M'))
    print(human_to_bytes('1M', unit='B'))
    print(human_to_bytes('10g', unit='b'))
    print(human_to_bytes('10G'))

    print(human_to_bytes('5.5Mb', isbits=True))
    print(human_to_bytes('5.5M'))
    print(human_to_bytes('5.5M', unit='B'))
    print(human_to_bytes('5.5g', unit='b'))
    print(human_to_bytes('5.5G'))


# Generated at 2022-06-24 21:09:51.076691
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(2, 'K') == 2048
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('2G') == 2147483648
    assert human_to_bytes('2T') == 2199023255552
    assert human_to_bytes('2P') == 2251799813685248
    assert human_to_bytes('2E') == 2305843009213693952
    assert human_to_bytes('2Z') == 2361183241434822606848
    assert human_to_bytes('2Y') == 2417851639229258349412352
    assert human_to_bytes('2.1b') == 2.1

# Generated at 2022-06-24 21:09:55.142764
# Unit test for function human_to_bytes
def test_human_to_bytes():
    number = '10MB'
    unit = 'MB'
    isbits = False
    expected = 10485760
    result = human_to_bytes(number, unit, isbits)
    assert(result == expected)

    number = '10Mb'
    unit = 'MB'
    isbits = True
    expected = 10485760
    result = human_to_bytes(number, unit, isbits)
    assert(result == expected)



# Generated at 2022-06-24 21:10:05.705273
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Empty tuple
    tuple_0 = ()
    var_0 = lenient_lowercase(tuple_0)
    assert var_0 == ()

    # String in tuple
    tuple_1 = ("abc",)
    var_1 = lenient_lowercase(tuple_1)
    assert var_1 == ("abc",)

    # Integer in tuple
    tuple_2 = (5, )
    var_2 = lenient_lowercase(tuple_2)
    assert var_2 == (5, )

    # Tuple in tuple
    tuple_3 = (tuple_0, )
    var_3 = lenient_lowercase(tuple_3)
    assert var_3 == (tuple_0, )

    # Tuple with mixed values
    tuple_4 = (1, "abc", tuple_0)

# Generated at 2022-06-24 21:10:10.419381
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        human_to_bytes('42')
    except ValueError:
        pass
    else:
        assert False, "human_to_bytes('42') didn't raise ValueError exception"

    assert human_to_bytes('42') == 42, \
        "human_to_bytes('42') returned %s instead of 42" % human_to_bytes('42')


    assert human_to_bytes('  42  ') == 42, \
        "human_to_bytes('  42  ') returned %s instead of 42" % human_to_bytes('  42  ')


    assert human_to_bytes('42.2') == 42, \
        "human_to_bytes('42.2') returned %s instead of 42" % human_to_bytes('42.2')


    assert human_to_bytes

# Generated at 2022-06-24 21:10:17.066241
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Test for function human_to_bytes"""
    # default case for parameter unit
    assert human_to_bytes(1024) == 1024

    # test 1
    assert human_to_bytes('1.1M', default_unit=None, isbits=False) == 1179648
    # test 2
    assert human_to_bytes('1KB', default_unit=None, isbits=False) == 1024
    # test 3
    assert human_to_bytes('1M', default_unit=None, isbits=False) == 1048576
    # test 4
    assert human_to_bytes('10Mb', default_unit=None, isbits=True) == 10485760
    # test 5
    assert human_to_bytes('700kb', default_unit=None, isbits=True) == 716800
    # test 6

# Generated at 2022-06-24 21:10:21.277425
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    # Setup mock
    class Mock(object):

        @staticmethod
        def mock_lower():
            return 'mocked_lower'

    # Unit test
    tuple_0 = Mock()
    tuple_0.lower = Mock.mock_lower
    var_0 = lenient_lowercase(tuple_0)

    # Check for equality
    assert var_0 == 'mocked_lower'



# Generated at 2022-06-24 21:10:37.486447
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    tuple_0 = None
    var_0 = lenient_lowercase(tuple_0)
    assert var_0 is None
    tuple_0 = (1, 2, 3)
    var_0 = lenient_lowercase(tuple_0)
    assert tuple_0 == var_0
    tuple_0 = ('a', 'b', 'c')
    var_0 = lenient_lowercase(tuple_0)
    assert tuple_0 == var_0
    tuple_0 = ('A', 'B', 'C')
    var_0 = lenient_lowercase(tuple_0)
    assert ('a', 'b', 'c') == var_0
    tuple_0 = ('a', 'b', 'c', 'A', 'B', 'C')

# Generated at 2022-06-24 21:10:40.267998
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        test_case_0()
        print('success')
    except Exception as e:
        print(e)


# Generated at 2022-06-24 21:10:48.981443
# Unit test for function lenient_lowercase

# Generated at 2022-06-24 21:10:53.400786
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''Check that human_to_bytes() supports all units from SIZE_RANGES list'''
    for unit, value in SIZE_RANGES.items():
        human_to_bytes('1%s'% unit)
        human_to_bytes(1, unit)
        human_to_bytes('1%sb' % unit, isbits=True)
        human_to_bytes(1, unit, isbits=True)


# Generated at 2022-06-24 21:11:00.997350
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        assert '1g'.upper() == '1G'
        assert '1g'.lower() == '1g'
        assert '1t'.upper() == '1T'
        assert '1t'.lower() == '1t'

    # Verify that function generates expected exception
    except Exception as e:
        print('Exception raised: <%s>' % (str(e)))



# Generated at 2022-06-24 21:11:12.361429
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Testing function with samples
    tuple_0 = ["Foo", "Bar"]
    assert lenient_lowercase(tuple_0) == ["foo", "bar"]
    tuple_1 = ["Foo", 1234]
    assert lenient_lowercase(tuple_1) == ["foo", 1234]
    tuple_2 = ["Foo", "123"]
    assert lenient_lowercase(tuple_2) == ["foo", "123"]
    tuple_3 = ["Foo", "Bar", "1234"]
    assert lenient_lowercase(tuple_3) == ["foo", "bar", "1234"]
    # Testing function with edge cases
    try:
        test_case_0()
    except TypeError as e:
        assert True
    except Exception:
        assert False


# Generated at 2022-06-24 21:11:19.862078
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes('1.5K', isbits=True) == 1536
    assert human_to_bytes('1.5k', isbits=True) == 1536
    assert human_to_bytes('1.5Mb') == 1572864
    assert human_to_bytes('1.5M', isbits=True) == 1572864
    assert human_to_bytes('1.5Mb', isbits=True) == 1572864
    assert human_to_bytes('1.5M', isbits=True) == 1572864
    assert human_to_bytes('1.5Mb', isbits=True) == 1572864


# Generated at 2022-06-24 21:11:31.183195
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # test value for tuple_0
    tuple_0 = None
    try:
        var_0 = lenient_lowercase(tuple_0)
        assert var_0 == tuple_0
    except Exception as e:
        print("Exception: %s" % e.__str__())
        raise
    # test value for tuple_0
    tuple_0 = ['A', 'B', 'C']
    # test value for tuple_1
    tuple_1 = ['a', 'b', 'c']
    try:
        var_0 = lenient_lowercase(tuple_0)
        assert var_0 == tuple_1
    except Exception as e:
        print("Exception: %s" % e.__str__())
        raise
    # test value for tuple_0

# Generated at 2022-06-24 21:11:41.779049
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Testing with the following parameter:
    #    string = '1K'
    #    default_unit = None
    #    isbits = False
    # Using the following value:
    #    expected = 1024
    string = '1K'
    default_unit = None
    isbits = False
    expected = 1024
    try:
        result = human_to_bytes(string, default_unit, isbits)
    except Exception as err:
        if err.__class__.__name__ == 'ValueError':
            pass
        else:
            raise
    else:
        assert result == expected

    # Testing with the following parameter:
    #    string = 1
    #    default_unit = None
    #    isbits = False
    # Using the following value:
    #    expected = 1
    string = 1
    default

# Generated at 2022-06-24 21:11:51.732415
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    tuple_0 = (0, '1', 2, '3', 4, '5', 6, '7', 8)
    var_0 = lenient_lowercase(tuple_0)

    tuple_1 = ('0', [1, '2', 3], '4', ['5', 6, '7'], 8)
    var_1 = lenient_lowercase(tuple_1)

    tuple_2 = ('0', 1, 2, 3)
    var_2 = lenient_lowercase(tuple_2)

    tuple_3 = ('0', '1')
    var_3 = lenient_lowercase(tuple_3)

    tuple_4 = ('0', '1', '2', '3', '4', '5', '6', '7', '8')

# Generated at 2022-06-24 21:12:03.756883
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """
    Test normal values (bytes to human)
    """
    assert human_to_bytes(100) == 100
    assert human_to_bytes('100') == 100

    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b', isbits=True) == 1

    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1.2K') == 1228
    assert human_to_bytes('1023.99K') == 1048575

    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1.5Mb', isbits=True) == 1572864

# Generated at 2022-06-24 21:12:08.411628
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Testing for gen list
    var_1 = ['apple', 'banana', 'orange']
    assert lenient_lowercase(var_1) == ['apple', 'banana', 'orange']

    # Testing for gen string
    var_2 = 'apple'
    assert lenient_lowercase(var_2) == 'apple'
    # Testing for gen int
    var_3 = 1
    assert lenient_lowercase(var_3) == 1



# Generated at 2022-06-24 21:12:11.330741
# Unit test for function human_to_bytes
def test_human_to_bytes():
    value_0 = human_to_bytes('5K')
    value_1 = human_to_bytes('100')
    value_2 = human_to_bytes('5M', 'B')
    value_3 = human_to_bytes('5Mb', 'b')
    value_4 = human_to_bytes('1 Mb')


# Generated at 2022-06-24 21:12:15.587298
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    print("\nTESTING lenient_lowercase FUNCTION")
    
    tests = (
        ((None), None),
        (('A', 'b', 1, 2), ('a', 'b', 1, 2)),
        (([1, 'A', 2, 3, 'C', 4]), [1, 'a', 2, 3, 'c', 4]),
    )
    for args, expected in tests:
        assert lenient_lowercase(*args) == expected


# Generated at 2022-06-24 21:12:18.843871
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    tuple_0 = [ 'QW' , 'Er', '23' ]
    var_0 = lenient_lowercase(tuple_0)

    if(var_0 == ['qw', 'er', '23']):
        return True
    else:
        return False



# Generated at 2022-06-24 21:12:24.989727
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        test_case_0()
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(e)
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)



# Generated at 2022-06-24 21:12:33.500653
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = [1, 2, 3, 4, 5]
    list_1 = []
    var_0 = lenient_lowercase(list_0)
    assert (var_0 == [1, 2, 3, 4, 5])
    with pytest.raises(AssertionError):
        assert var_0 != [1, 2, 3, 4, 5]
    with pytest.raises(AssertionError):
        assert lenient_lowercase(tuple_0) == None
    with pytest.raises(TypeError):
        assert lenient_lowercase(list_1) == []


# Generated at 2022-06-24 21:12:37.796570
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_case_0()


# Generated at 2022-06-24 21:12:41.318178
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K', isbits=True) == 1024

# Generated at 2022-06-24 21:12:46.451138
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    value_0 = ['Test', 'test', 'oNe']

    assert(lenient_lowercase(value_0) == ['test', 'test', 'one'])



# Generated at 2022-06-24 21:13:00.440328
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Unit test for function lenient_lowercase
    tuple_0 = ["ABC", "DEF", "GHI"]
    expected_result_0 = ["abc", "def", "ghi"]
    actual_result_0 = lenient_lowercase(tuple_0)

    assert actual_result_0 == expected_result_0, "lenient_lowercase() error."

    tuple_1 = None
    expected_result_1 = None
    actual_result_1 = lenient_lowercase(tuple_1)

    assert actual_result_1 == expected_result_1, "lenient_lowercase() error."

    tuple_2 = ["ABC", 123, 456]
    expected_result_2 = ["abc", 123, 456]
    actual_result_2 = lenient_lowercase(tuple_2)


# Generated at 2022-06-24 21:13:03.136183
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(None) == []
    assert lenient_lowercase(('a', None)) == ['a', None]
    assert lenient_lowercase((1, 2)) == [1, 2]
    assert lenient_lowercase(('A', 'B', 1, True, None)) == ['a', 'b', 1, True, None]



# Generated at 2022-06-24 21:13:11.085643
# Unit test for function human_to_bytes
def test_human_to_bytes():
    expected = 1048576
    result = human_to_bytes('1MB')
    assert result == expected
    result = human_to_bytes('1MB', 'M')
    assert result == expected
    result = human_to_bytes('1', 'M')
    assert result == expected
    result = human_to_bytes('1.0MB')
    assert result == expected
    result = human_to_bytes('1.0MB', 'M')
    assert result == expected
    result = human_to_bytes('1,0MB')
    assert result == expected
    result = human_to_bytes('1,0MB', 'M')
    assert result == expected
    result = human_to_bytes('.1MB', 'M')
    assert result == expected / 10
    result = human_to_bytes('.1MB')
   

# Generated at 2022-06-24 21:13:19.870861
# Unit test for function human_to_bytes
def test_human_to_bytes():
    tuple_0 = '10M'
    tuple_1 = None
    tuple_2 = '1MB'
    tuple_3 = True
    tuple_4 = '1Mb'
    tuple_5 = False
    assert human_to_bytes(tuple_0, tuple_1, tuple_3) == 10485760, "human_to_bytes() function failed to convert '10M' (unit = None). Value is not a valid integer (expect YB or Y)"
    assert human_to_bytes(tuple_2, tuple_1, tuple_5) == 1048576, "human_to_bytes() function failed to convert '1MB' (unit = None). Value is not a valid integer (expect YB or Y)"
    assert human_to_bytes(tuple_4, tuple_1, tuple_3) == 1048

# Generated at 2022-06-24 21:13:23.673533
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # Check for expected result with input '10M'
    expected_result = 10485760
    test_case_1 = human_to_bytes('10M')

    assert(expected_result == test_case_1)

    test_case_2 = human_to_bytes(10, 'M')

    assert(expected_result == test_case_2)


# Generated at 2022-06-24 21:13:33.468782
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # input with unit B
    print("input with unit B")
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10B', 'B') == 10
    assert human_to_bytes(10, 'B') == 10
    assert human_to_bytes(10, 'b', isbits=True) == 10

    # input without unit
    print("input without unit")
    assert human_to_bytes('10') == 10
    assert human_to_bytes(10) == 10
    assert human_to_bytes(10.0) == 10

    # input with unit K
    print("input with unit K")
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('10K', 'K') == 10240

# Generated at 2022-06-24 21:13:39.680861
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Asserting type of test case
    assert type(test_case_0) == tuple

    # Assertion 1
    assert lenient_lowercase(test_case_0) == None, "Failed assert human_to_bytes"

    # Assertion 2
    assert lenient_lowercase(test_case_0) != None, "Failed assert human_to_bytes"



# Generated at 2022-06-24 21:13:44.105330
# Unit test for function human_to_bytes
def test_human_to_bytes():
    human = '1M'
    bytes = human_to_bytes(human)
    assert bytes == 1048576

    human = '1Mb'
    bytes = human_to_bytes(human, None, True)
    assert bytes == 1048576

    human = '1MB'
    bytes = human_to_bytes(human, None, False)
    assert bytes == 1048576



# Generated at 2022-06-24 21:13:54.322443
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test case #1
    number = '0'
    default_unit = None
    isbits = False
    result = human_to_bytes(number, default_unit, isbits)
    assert result == 0

    # Test case #2
    number = '10MB'
    default_unit = None
    isbits = False
    result = human_to_bytes(number, default_unit, isbits)
    assert result == 10485760

    # Test case #3
    number = '10.21GB'
    default_unit = None
    isbits = False
    result = human_to_bytes(number, default_unit, isbits)
    assert result == 10918063820

    # Test case #4
    number = '1M'
    default_unit = None
    isbits = False
    result = human

# Generated at 2022-06-24 21:14:01.702142
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    tuple_0 = ()
    var_0 = lenient_lowercase(tuple_0)
    assert var_0 == ()

    tuple_1 = ('', '', '')
    var_1 = lenient_lowercase(tuple_1)
    assert var_1 == ('', '', '')

    tuple_2 = ('a', 'b', 'c', 'd')
    var_2 = lenient_lowercase(tuple_2)
    assert var_2 == ('a', 'b', 'c', 'd')

    tuple_3 = (1, 'a', 2, 'b', 4, 'c', 8, 'd')
    var_3 = lenient_lowercase(tuple_3)
    assert var_3 == (1, 'a', 2, 'b', 4, 'c', 8, 'd')

# Generated at 2022-06-24 21:14:10.349611
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    pass


# Generated at 2022-06-24 21:14:21.577412
# Unit test for function human_to_bytes

# Generated at 2022-06-24 21:14:30.309910
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Equal
    res = human_to_bytes("1")
    assert res == 1
    # Equal
    res = human_to_bytes("10")
    assert res == 10
    # Equal
    res = human_to_bytes("1b")
    assert res == 1
    # Equal
    res = human_to_bytes("10b")
    assert res == 10
    # Equal
    res = human_to_bytes("1B")
    assert res == 1
    # Equal
    res = human_to_bytes("10B")
    assert res == 10
    # Equal
    res = human_to_bytes("1K")
    assert res == 1024
    # Equal
    res = human_to_bytes("1M")
    assert res == 1048576
    # Equal

# Generated at 2022-06-24 21:14:42.568792
# Unit test for function human_to_bytes
def test_human_to_bytes():
    num_1 = '1'
    unit_1 = 'B'
    bit_1 = False
    result_1 = human_to_bytes(num_1, unit_1, bit_1)
    assert result_1 == 1
    num_2 = '0'
    unit_2 = 'b'
    bit_2 = True
    result_2 = human_to_bytes(num_2, unit_2, bit_2)
    assert result_2 == 0
    num_3 = '2K'
    unit_3 = None
    bit_3 = False
    result_3 = human_to_bytes(num_3, unit_3, bit_3)
    assert result_3 == 2048

# Generated at 2022-06-24 21:14:47.904995
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        test_case_0()
    except AssertionError:
        assert False

    assert True



# Generated at 2022-06-24 21:14:48.372572
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert callable(lenient_lowercase)



# Generated at 2022-06-24 21:14:49.786538
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    tuple_0 = None
    var_0 = lenient_lowercase(tuple_0)


# Generated at 2022-06-24 21:14:56.160911
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('12K') == 12 * 1024
    assert human_to_bytes('100Mb') == 100 * 1024 * 1024


# Generated at 2022-06-24 21:15:04.533511
# Unit test for function human_to_bytes
def test_human_to_bytes():
    correct_0 = '2'
    correct_1 = '10'
    correct_2 = '1'
    correct_3 = '50'
    correct_4 = '20'
    correct_5 = '1048576'
    correct_6 = '1048576'
    correct_7 = '1048576'
    correct_8 = '1048576'
    correct_9 = '1048576'
    correct_10 = '1048576'
    correct_11 = '1048576'
    correct_12 = '1048576'
    correct_13 = '1048576'
    correct_14 = '1048576'
    correct_15 = '1048576'
    correct_16 = '1'
    correct_17 = '1'
    correct_18 = '1'

# Generated at 2022-06-24 21:15:10.827535
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # For each of the given examples
    for example in ['1K', '1M', '1G', '1TB']:
        # Assert we can convert the given example
        assert human_to_bytes(example) > 0
    # End for

    try:
        # Attempt to convert
        human_to_bytes('1024X')
    except ValueError:
        pass
    else:
        # If no error is raised, fail
        raise AssertionError('1024X should not convert')
    # End try (no exception raised)

# End def test_human_to_bytes()


# Generated at 2022-06-24 21:15:26.601797
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1) == 1
    assert human_to_bytes(1, 'b') == 1
    assert human_to_bytes(1, 'B') == 1
    assert human_to_bytes(1, 'K') == 1000
    assert human_to_bytes(1, 'KB') == 1000
    assert human_to_bytes(1, 'M') == 1000000
    assert human_to_bytes(1, 'MB') == 1000000

    try:
        human_to_bytes('10')
    except ValueError:
        pass
    else:
        assert False

    try:
        human_to_bytes('10X')
    except ValueError:
        pass
    else:
        assert False

    try:
        human_to_bytes('10Xb')
    except ValueError:
        pass


# Generated at 2022-06-24 21:15:31.080291
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(('foo', 'BaR')) == ['foo', 'bar']
    assert lenient_lowercase(('FOO', 'BaR')) == ['foo', 'bar']
    assert lenient_lowercase(('foo', 'bar')) == ['foo', 'bar']

# Generated at 2022-06-24 21:15:33.040989
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    s = ['a', 'b', 'C']
    assert lenient_lowercase(s) == ['a', 'b', 'c']



# Generated at 2022-06-24 21:15:36.653098
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert (lenient_lowercase(None) == [])
    assert (lenient_lowercase([]) == [])
    assert (lenient_lowercase(['a', 'B', 1]) == ['a', 'b', 1])


# Generated at 2022-06-24 21:15:44.763256
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Determine kbytes from tuple
    tuple_0_1 = '2K'
    var_0_1 = human_to_bytes(tuple_0_1)
    print("1 converted tuple_0_1 == " + str(var_0_1))
    if var_0_1 != 2048:
        raise ValueError("1 failed test for human_to_bytes, got: %d" % var_0_1)

    # Determine kbytes from int
    int_0_1 = 2
    var_0_2 = human_to_bytes(int_0_1)
    print("1 converted int_0_1 == " + str(var_0_2))

# Generated at 2022-06-24 21:15:49.330327
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1M") == 1048576


# Generated at 2022-06-24 21:15:57.567558
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Input parameters
    tuple_0 = []
    tuple_1 = ['A', 'B']
    tuple_2 = ['A', 1]

    # Expected output
    expected_0 = []
    expected_1 = ['a', 'b']
    expected_2 = ['a', 1]

    # Unit test for function lenient_lowercase
    var_0 = lenient_lowercase(tuple_0)
    assert var_0 == expected_0

    # Unit test for function lenient_lowercase
    var_1 = lenient_lowercase(tuple_1)
    assert var_1 == expected_1

    # Unit test for function lenient_lowercase
    var_2 = lenient_lowercase(tuple_2)
    assert var_2 == expected_2



# Generated at 2022-06-24 21:16:07.300403
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert ("None" == lenient_lowercase(None))
    assert ('1' == lenient_lowercase(1))
    assert ('a' == lenient_lowercase('a'))
    assert ('a' == lenient_lowercase('A'))
    assert ('abc' == lenient_lowercase('Abc'))
    assert ('abc' == lenient_lowercase('aBc'))
    assert ('abc' == lenient_lowercase('aBC'))
    assert ('abc' == lenient_lowercase('abC'))
    assert ('abc' == lenient_lowercase('AbC'))
    assert ('abc' == lenient_lowercase('ABC'))
    assert ('abc' == lenient_lowercase('aBC'))
    assert ('abc' == lenient_lowercase('abC'))
   

# Generated at 2022-06-24 21:16:16.985063
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('10.5M') == 10991206
    assert human_to_bytes('0.5M') == 524288
    assert human_to_bytes(2, 'M') == 2097152
    assert human_to_bytes('10.4M', 'K') == 10485760
    assert human_to_bytes('10M', 'B') == 10485760
    assert human_to_bytes(55, 'M') == 57671680
    assert human_to_bytes(55.55, 'M') == 58673798
    assert human_to_bytes('10G') == 10737418240

# Generated at 2022-06-24 21:16:25.997650
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_data_0 = [
        (["123", "aBc", "def", "GHI"], ["123", "abc", "def", "ghi"]),
        (["123", "aBc", None], ["123", "abc", None]),
        ([], []),
        ([None, "aBc", None], [None, "abc", None]),
        (["123", "aBc", "DEF", "GHI", None, "jkl", "MNO"], ["123", "abc", "def", "ghi", None, "jkl", "mno"])
    ]
    test_data_1 = None
    test_data_2 = []
    test_data_3 = None
    test_data_4 = ["123"]
    test_data_5 = None
    test_data_6 = []


# Generated at 2022-06-24 21:16:44.579315
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("Testing human_to_bytes:")
    # assert(human_to_bytes("10M") == "10485760")
    assert(human_to_bytes("10Mb") == "10485760")
    assert(human_to_bytes("10Mb", isbits=True) == "10485760")
    assert(human_to_bytes("10MB") == "10485760")
    assert(human_to_bytes("10MBb") == ValueError)
    assert(human_to_bytes("10") == "10")
    assert(human_to_bytes("10", "Kb") == "8192")
    assert(human_to_bytes("10", "KB") == "10240")
    assert(human_to_bytes("10", "b") == "1")