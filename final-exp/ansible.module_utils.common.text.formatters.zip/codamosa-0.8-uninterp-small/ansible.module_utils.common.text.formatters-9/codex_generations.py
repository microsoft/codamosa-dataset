

# Generated at 2022-06-24 21:06:49.250081
# Unit test for function human_to_bytes
def test_human_to_bytes():
    str_0 = 'Us8{H.R'
    var_0 = human_to_bytes(str_0)
    assert var_0 == 'Us8{H.R', 'Unexpected value returned'

# Generated at 2022-06-24 21:06:59.247928
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert True == isinstance(human_to_bytes(10, 'M'), int)  # base_unit is bytes
    assert True == isinstance(human_to_bytes(10, 'M', isbits=False), int)  # base_unit is bytes
    assert True == isinstance(human_to_bytes(10, 'Mb', isbits=True), int)  # base_unit is bits
    assert 10485760 == human_to_bytes(10, 'M')  # base_unit is bytes
    assert 10485760 == human_to_bytes(10, 'M', isbits=False)  # base_unit is bytes
    assert 10485760 == human_to_bytes(10, 'Mb', isbits=True)  # base_unit is bits

# Generated at 2022-06-24 21:07:01.440147
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        bytes_0 = human_to_bytes(str(var_0), isbits=False)
    except Exception:
        pass
    else:
        assert False, "The statement should not be reached."



# Generated at 2022-06-24 21:07:09.828123
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1K") == 1024
    assert human_to_bytes("5M") == 5242880
    assert human_to_bytes("1G") == 1073741824
    assert human_to_bytes("2t") == 2199023255552
    assert human_to_bytes("3P") == 322122547200
    assert human_to_bytes("4e") == 4503599627370496
    assert human_to_bytes("1K", default_unit='b') == 1024


# Generated at 2022-06-24 21:07:19.365603
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10) == 10
    assert human_to_bytes(10, default_unit='B') == 10
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', default_unit='B') == 10485760
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, default_unit='B') == 10
    assert human_to_bytes(10, default_unit='MB') == 10485760
    assert human_to_bytes(10) == 10
    assert human_to_bytes('1.0B') == 1
    assert human_to_bytes('1.0b') == 1
    assert human_to_bytes('1048576KB') == 1073741824
    assert human

# Generated at 2022-06-24 21:07:20.692324
# Unit test for function human_to_bytes
def test_human_to_bytes():
    input = '1M'
    output = human_to_bytes(input)
    assert output == 1048576


# Generated at 2022-06-24 21:07:28.596072
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1t') == 1 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1T') == 1 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('123T') == 123 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.69t') == 1.69 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.69T') == 1.69 * 1024 * 1024 * 1024 * 1024

    assert human_to_bytes('1P') == 1 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.69P') == 1.69 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1.69p') == 1.69 * 1024 * 1024 * 1024 * 1024 * 1024

   

# Generated at 2022-06-24 21:07:30.607276
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'b', True, 'c']) == ['a', 'b', True, 'c']


# Generated at 2022-06-24 21:07:36.365920
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = [1,None,2,3]
    list_1 = ['A', 'B', 'C']
    assert lenient_lowercase(list_0) == list_0
    assert lenient_lowercase(list_1) == ['a', 'b', 'c']


# Generated at 2022-06-24 21:07:46.481608
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert bytes_to_human(human_to_bytes('16.7M')) == '16.67 MB'
    assert human_to_bytes('10M') == human_to_bytes(10, 'M') == 10485760
    assert bytes_to_human(human_to_bytes('17.7Mb', isbits=True)) == '17.67 Mb'
    assert bytes_to_human(human_to_bytes('1.5M', unit='K')) == '1525 K'
    assert bytes_to_human(human_to_bytes('1.5K', unit='M')) == '1.48 M'
    assert bytes_to_human(human_to_bytes('1.5Mb', unit='Kb', isbits=True)) == '1525 Kb'

# Generated at 2022-06-24 21:07:54.334366
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    unit_test_list = [1, 'test', 1.23, 'TEsT', 'test2', 'test2.t']
    unit_test_ans = [1, 'test', 1.23, 'test', 'test2', 'test2.t']
    unit_test_out = lenient_lowercase(unit_test_list)

    unit_test_err_msg = 'Unexpected list'
    assert unit_test_out == unit_test_ans, unit_test_err_msg


# Generated at 2022-06-24 21:08:04.834324
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1048576*2, isbits=True) == '2097152 bits', "Test 1 failed."
    assert bytes_to_human(1048576*2, isbits=False) == '2 MBytes', "Test 2 failed."
    assert bytes_to_human(1048576*2) == '2 MBytes', "Test 3 failed."
    assert bytes_to_human(1048576*2, isbits=True, unit='b') == '2097152 bits', "Test 4 failed."
    assert bytes_to_human(1048576*2, isbits=False, unit='B') == '2 MBytes', "Test 5 failed."
    assert bytes_to_human(1048576*2, unit='b') == '2097152 bits', "Test 6 failed."

# Generated at 2022-06-24 21:08:08.083771
# Unit test for function bytes_to_human
def test_bytes_to_human():
    '''
    This is the test for function bytes_to_human
    '''
    # check if the function pass for test case 0
    test_case_0()
    # now add the tests for other cases and scenarios




# Generated at 2022-06-24 21:08:16.027114
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test case 0
    inputVal_0 = human_to_bytes('2K')
    resultVal_0 = 2048
    assert resultVal_0 == inputVal_0
    # test case 1
    inputVal_1 = human_to_bytes('10G')
    resultVal_1 = 10737418240
    assert resultVal_1 == inputVal_1
    # test case 2
    try:
        inputVal_2 = human_to_bytes(10)
    except ValueError as err:
        assert err.args[0] == "human_to_bytes() can't interpret following string: 10"
    else:
        assert False, "Expected an exception"
    # test case 3
    inputVal_3 = human_to_bytes('10Mb', isbits=True)
    resultVal_3 = 10485760


# Generated at 2022-06-24 21:08:20.806152
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 21:08:26.809064
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # tests for valid return values
    assert human_to_bytes('1K', isbits=False) == 1024
    assert human_to_bytes('1.2K', isbits=False) == 1228
    assert human_to_bytes('1.2k', isbits=False) == 1228
    assert human_to_bytes('1 M', isbits=False) == 1000000
    assert human_to_bytes('1.2M', isbits=False) == 1200000
    assert human_to_bytes('1.2m', isbits=False) == 1200000
    assert human_to_bytes('1 G', isbits=False) == 1000000000
    assert human_to_bytes('1.2G', isbits=False) == 1200000000
    assert human_to_bytes('1.2g', isbits=False) == 1200000000


# Generated at 2022-06-24 21:08:36.690432
# Unit test for function bytes_to_human
def test_bytes_to_human():

    assert("1.00 B" == bytes_to_human(1))
    assert("1.00 B" == bytes_to_human(1, False))
    assert("1.00 Bytes" == bytes_to_human(1, False, 'B'))
    assert("1.00 Kb" == bytes_to_human(1024, True))
    assert("1.00 B" == bytes_to_human(1, True, 'B'))
    assert("1.00 b" == bytes_to_human(1, True, 'b'))
    assert("1.00 Bits" == bytes_to_human(1, True, 'b'))
    assert("1.00 Bits" == bytes_to_human(1, True, 'Bit'))

# Generated at 2022-06-24 21:08:46.514479
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('Testing human_to_bytes()')

# Generated at 2022-06-24 21:08:56.701170
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Testing for expected results
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1Mb', isbits=False) == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1kb', isbits=True) == 1024
    assert human_to_bytes('1kb', isbits=False) == 1000
    assert human_to_bytes('1kb') == 1000
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1b', isbits=False) == 1

# Generated at 2022-06-24 21:09:04.015892
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 1, 2, 'C']) == ['a', 'b', 1, 2, 'c']
    assert lenient_lowercase(['A', 'B', 'C', 'D', 'E']) == ['a', 'b', 'c', 'd', 'e']


# Generated at 2022-06-24 21:09:12.646374
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["HeLlO", 4, {"a": "b"}]) == ["hello", 4, {"a": "b"}]


# Generated at 2022-06-24 21:09:15.389423
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = ['hello', 'I\'M', 'Foo']
    list_1 = lenient_lowercase(list_0)
    assert list_1 == ['hello', 'I\'M', 'foo']



# Generated at 2022-06-24 21:09:27.200627
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("##### human_to_bytes")
    # Test 1:
    #   Expected: 1048576
    # print("Test 1: " + str(human_to_bytes("1M")))

    # Test 2:
    #   Expected: 0
    # print("Test 2: " + str(human_to_bytes("0.0M")))

    # Test 3:
    #   Expected: 1048576
    # print("Test 3: " + str(human_to_bytes("1M", None)))

    # Test 4:
    #   Expected: 1048576
    # print("Test 4: " + str(human_to_bytes("1", "M")))

    # Test 5:
    #   Expected: 1048576
    # print("Test 5: " + str(human_to_bytes

# Generated at 2022-06-24 21:09:35.444549
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test cases:
    # Case 0:
    test_case_0()
    # # Case 1:
    # test_human_to_bytes_0()
    # # Case 2:
    # test_human_to_bytes_1()
    # # Case 3:
    # test_human_to_bytes_2()
    # # Case 4:
    # test_human_to_bytes_3()
    # # Case 5:
    # test_human_to_bytes_4()


# Generated at 2022-06-24 21:09:46.174395
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert lenient_lowercase(['sample_arg']) == ['sample_arg']
    assert human_to_bytes('1mb', isbits=True) == 1048576
    assert human_to_bytes('1MB', isbits=False) == 1048576
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10MB', isbits=False) == 10485760
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1B', isbits=False) == 1
    assert human_to_bytes('1.54KB', isbits=False) == 1574
    assert human_to_bytes('1.54KB', isbits=True) == 1574

# Generated at 2022-06-24 21:09:54.013291
# Unit test for function lenient_lowercase

# Generated at 2022-06-24 21:09:57.528805
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test 1
    params = lenient_lowercase(['aa',5,'Bc'])
    assert params == ['aa',5,'Bc']
    
    # Test 2
    params = lenient_lowercase(['A', 'B', 'c'])
    assert params == ['a', 'b', 'c']


# Generated at 2022-06-24 21:10:03.851108
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    bool_0 = False
    main_list_0 = ['a', 'b', 4, 'c', 'd', 'e', 'f']
    main_list_1 = ['a', 'b', 'c', 'd', 'e', 'f']
    if main_list_0 == lenient_lowercase(main_list_1):
        bool_0 = True
    return bool_0


# Generated at 2022-06-24 21:10:13.875779
# Unit test for function human_to_bytes

# Generated at 2022-06-24 21:10:20.579770
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert 1 == human_to_bytes('1')
    assert 1048576 == human_to_bytes('1MB')
    assert 1024 == human_to_bytes('1KB')
    assert 1048576 == human_to_bytes('1Mb', isbits=True)
    assert 1024 == human_to_bytes('1Kb', isbits=True)
    assert 1048576 == human_to_bytes('1000000b', isbits=True)
    assert 1024 == human_to_bytes('1024b', isbits=True)
    assert 0 == human_to_bytes('0')


# Generated at 2022-06-24 21:10:28.170244
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['One', 2, 'ThreE']) == ['one', 2, 'three']


# Generated at 2022-06-24 21:10:37.904164
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # Test case 0: simple test case
    result = human_to_bytes('2KB')
    bool_0 = result == 2048
    if bool_0:
        print("PASSED: Test Case 0")
    else:
        print("FAILED: Test Case 0")

    # Test case 1: with space
    result = human_to_bytes(' 2KB')
    bool_0 = result == 2048
    if bool_0:
        print("PASSED: Test Case 1")
    else:
        print("FAILED: Test Case 1")

    # Test case 2: with decimal value
    result = human_to_bytes('  5.3 KB ')
    bool_0 = result == 5376
    if bool_0:
        print("PASSED: Test Case 2")

# Generated at 2022-06-24 21:10:47.139698
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1MB', isbits=True) == 8388608
    assert human_to_bytes('1Mb') == 8388608
    assert human_to_bytes('1.1Mb') == 9437184
    assert human_to_bytes('2MB', isbits=True) == 16777216
    assert human_to_bytes('1 K') == 1024
    assert human_to_bytes('1 Kb') == 8192
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 8192
    assert human_to_bytes(1E6) == 1000000

# Generated at 2022-06-24 21:10:54.175239
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    print("\n")
    print("##### Start tests lenient_lowercase #####")
    print("\n")

    #### Testing # 1 #####
    print("Test #1: lenient_lowercase([None, 'a', 3])")
    test_case_1 = lenient_lowercase([None, 'a', 3])
    if test_case_1 == [None, 'a', 3]:
        print("Status: PASS")
    else:
        print("Status: FAIL")
    print("\n")

    #### Testing # 2 #####
    print("Test #2: lenient_lowercase([None, 'A', 3])")
    test_case_2 = lenient_lowercase([None, 'A', 3])

# Generated at 2022-06-24 21:11:02.855501
# Unit test for function lenient_lowercase

# Generated at 2022-06-24 21:11:13.196354
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # these test cases may fail if the order of SIZE_RANGES is changed
    assert(human_to_bytes('2048') == 2048)
    assert(human_to_bytes('2K') == 2048)
    assert(human_to_bytes('30M') == 31457280)
    assert(human_to_bytes('0.5G') == 536870912)
    assert(human_to_bytes('1T') == 1099511627776)
    assert(human_to_bytes('2KB') == 2048)
    assert(human_to_bytes('3Mb') == 31457280)
    assert(human_to_bytes('1Tb') == 1099511627776)


# Generated at 2022-06-24 21:11:20.826097
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test case 0
    human_0 = '1024'
    human_1 = 'MB'
    int_0 = human_to_bytes(human_0, unit=human_1)
    assert isinstance(int_0, int)
    assert int_0 == 1048576
    human_0 = '1024'
    human_1 = 'mb'
    int_0 = human_to_bytes(human_0, unit=human_1, isbits=True)
    assert isinstance(int_0, int)
    assert int_0 == 1048576
    # Test case 1
    human_0 = '2K'
    int_0 = human_to_bytes(human_0)
    assert isinstance(int_0, int)
    assert int_0 == 2048
    # Test case 2

# Generated at 2022-06-24 21:11:32.184392
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.1 KB') == 1024 * 1.1
    assert human_to_bytes('1.1 MB', isbits=True) == (10 ** 6 * 8) * 1.1
    assert human_to_bytes('1.1 MB', isbits=False) == (10 ** 6) * 1.1
    assert human_to_bytes('1.1 MB', isbits=False, default_unit=None) == 1.1
    assert human_to_bytes('1.1K', isbits=False, default_unit=None) == 1.1
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1MB', isbits=True) == 1048576

# Generated at 2022-06-24 21:11:41.830483
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert (human_to_bytes('10M') == human_to_bytes(10, 'M'))
    assert (human_to_bytes('1MB') == 1048576)
    assert (human_to_bytes('1B', unit='b') == 8)
    assert (human_to_bytes('1B', unit='b', isbits=True) == 8)
    assert (human_to_bytes('1b', unit='B', isbits=True) == 8)
    assert (human_to_bytes('1b', unit='B') == 1)
    assert (human_to_bytes('1b', isbits=True) == 1)
    assert (human_to_bytes('1b') == 1)
    assert (human_to_bytes('1B') == 1)

# Generated at 2022-06-24 21:11:51.775092
# Unit test for function lenient_lowercase

# Generated at 2022-06-24 21:12:10.333899
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('------------------')
    print('Test case:')
    print('Input:')
    print('')
    print('Output:')
    print(human_to_bytes('10M'))
    print('Expected output:')
    print(10485760)
    print('------------------')

    print('------------------')
    print('Test case:')
    print('Input:')
    print('')
    print('Output:')
    print(human_to_bytes('10M', isbits=True))
    print('Expected output:')
    print(10485760)
    print('------------------')

    print('------------------')
    print('Test case:')
    print('Input:')
    print('')
    print('Output:')

# Generated at 2022-06-24 21:12:17.853646
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # case 0
    lst = ['TEST', 'TEST', 'TEST', 'TEST']
    lst_lower = ['test', 'test', 'test', 'test']

    lst_lower_case_0 = lenient_lowercase(lst)
    if not check_case_0(lst_lower_case_0, lst_lower):
        print('Test Case 0 Failed')
        return False

    print('Test Case 0 Passed')
    return True

# Helper functions

# Generated at 2022-06-24 21:12:28.214683
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test case # 0
    assert bytes_to_human(1024) == '1.00 KBytes'
    # test case # 1
    assert bytes_to_human(1024, unit='k') == '1.00 KB'
    # test case # 2
    assert bytes_to_human(1024, unit='kb') == '1.00 Kb'
    # test case # 3
    assert bytes_to_human(1024, unit='Kb') == '1.00 Kb'
    # test case # 4
    assert bytes_to_human(1024, unit='KB') == '1.00 KB'
    # test case # 5
    assert bytes_to_human(1024, isbits=True, unit='kb') == '8.00 Kb'
    # test case # 6

# Generated at 2022-06-24 21:12:37.578787
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K', 'b', True) == 1024
    assert human_to_bytes('1Kb', 'b', True) == 1024
    assert human_to_bytes('1Mb', 'b', True) == 1048576
    assert human_to_bytes('1Gb', 'b', True) == 1073741824
    assert human_to_bytes('1Tb', 'b', True) == 1099511627776
    assert human_to_bytes('1Pb', 'b', True) == 1125899906842624
    assert human_to_bytes('1Eb', 'b', True) == 1152921504606846976
    assert human_to_bytes('1Zb', 'b', True) == 1180591620717411303424

# Generated at 2022-06-24 21:12:41.658168
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'C', 3]) == ['a', 'b', 'c', 3], "Error human_to_bytes"
    assert lenient_lowercase(['a', 'b', 'C']) == ['a', 'b', 'c'], "Error human_to_bytes"
    assert lenient_lowercase([]) == [], "Error human_to_bytes"
    print("lenient_lowercase Test case #0 passed")


# Generated at 2022-06-24 21:12:47.971980
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [1,2,3,'a','b','c','C','A','B','D','C']
    assert lenient_lowercase(lst) == [1,2,3,'a','b','c','C','A','B','D','C']


# Generated at 2022-06-24 21:12:52.989832
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'aBc', 'def', None]) == [1, 'abc', 'def', None]


# Generated at 2022-06-24 21:12:56.969879
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes(10, 'M') == 10485760
    # test function with and without unit
    assert human_to_bytes('10M') == 10485760


# Generated at 2022-06-24 21:13:08.467974
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('0B', 'B') == 0
    assert human_to_bytes('0', 'B') == 0
    assert human_to_bytes('0', 'B', True) == 0
    assert human_to_bytes('0b', 'b', True) == 0
    assert human_to_bytes('0.000', 'B') == 0
    assert human_to_bytes('0.001', 'B') == 0
    assert human_to_bytes('0.999', 'B') == 0
    assert human_to_bytes('1', 'B') == 1
    assert human_to_bytes(1, 'B') == 1
    assert human_to_bytes('1.', 'B') == 1
    assert human_to_bytes('1.0B', 'b', True) == 8
    assert human_to

# Generated at 2022-06-24 21:13:14.237125
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        lenient_lowercase(["A", "b", "C", 2, 4, "Foo", "bar", "BAZ"])
    except AttributeError:
        print("Error in lenient_lowercase")


# Generated at 2022-06-24 21:13:35.143681
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert (human_to_bytes('10MB', 'B') == 10485760)


# Generated at 2022-06-24 21:13:40.675360
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = ['spaces', 'and', 'UPPERCASE']
    result_0 = lenient_lowercase(list_0)
    assert ('spaces' and 'and' and 'uppercase') in result_0


# Generated at 2022-06-24 21:13:45.685640
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_0 = ["foo", "bar", "baz"]
    expected_result = ["foo", "bar", "baz"]
    result = lenient_lowercase(input_0)
    assert result == expected_result



# Generated at 2022-06-24 21:13:52.391207
# Unit test for function human_to_bytes
def test_human_to_bytes():

    ### valid test cases
    if human_to_bytes('1M') != 1048576:
        raise ValueError("test_case_1 failed")

    if human_to_bytes('1Mb', isbits=True) != 1048576:
        raise ValueError("test_case_2 failed")

    if human_to_bytes(10, unit='Mb', isbits=True) != 10485760:
        raise ValueError("test_case_3 failed")

    if human_to_bytes('1MB') != 1048576:
        raise ValueError("test_case_4 failed")

    if human_to_bytes('1Mb') != 1048576:
        raise ValueError("test_case_5 failed")


# Generated at 2022-06-24 21:13:53.976047
# Unit test for function lenient_lowercase
def test_lenient_lowercase(): 
    assert callable(lenient_lowercase)


# Generated at 2022-06-24 21:14:01.478855
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    print('Testing function lenient_lowercase')
    num_0 = str()
    num_1 = int()
    num_2 = str()
    num_3 = int()
    num_4 = str()
    num_5 = int()
    num_6 = str()
    num_7 = int()
    num_8 = str()
    num_9 = int()
    num_10 = str()
    num_11 = int()
    num_12 = str()
    num_13 = int()
    num_14 = str()
    num_15 = int()
    num_16 = str()
    num_17 = int()
    num_18 = str()
    num_19 = int()
    num_20 = str()
    num_21 = int()
    num_22 = str()
    num_

# Generated at 2022-06-24 21:14:07.401500
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_lst = ['The', 'Quick', 'Brown', 1, 'Fox', 'Jumps', 'Over', 'The', 'Lazy', 'Dog']
    expected = ['the', 'quick', 'brown', 1, 'fox', 'jumps', 'over', 'the', 'lazy', 'dog']
    assert lenient_lowercase(input_lst) == expected


# Generated at 2022-06-24 21:14:13.804007
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    arg_0 = ["a", 4, 2, "C"]
    exp_rv = ['a', 4, 2, 'c']
    rv = lenient_lowercase(arg_0)
    assert rv == exp_rv, "Return value is not as expected ({})".format(rv)


# Generated at 2022-06-24 21:14:17.908313
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['hello', 'World']) == ['hello', 'world'], 'Test case Failed'


# Generated at 2022-06-24 21:14:24.085785
# Unit test for function human_to_bytes
def test_human_to_bytes():
    bool_0 = True

    """
    Testing for function human_to_bytes
    """

    # Test case 0
    try:
        # Checking arguments of human_to_bytes
        #
        #
        assert test_case_0()

    except Exception:
        bool_0 = False
        raise

    assert bool_0

if __name__ == "__main__":

     # testing function- bytes_to_human
    # Expected result: 10 Gigabytes, Actual result: 10 Gigabytes
    result = bytes_to_human(10737418240)
    print(result)

    # testing function- bytes_to_human
    # Expected result: 10 Gigabits, Actual result: 10 Gigabits
    result = bytes_to_human(10737418240, True)
    print(result)

    # testing function-

# Generated at 2022-06-24 21:15:07.419770
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
    list_1 = ['1', '1', '2', '3', '5', '8', '13', '21', '34', '55', '89']

    assert list_0 == lenient_lowercase(list_1)


# Generated at 2022-06-24 21:15:14.463102
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    in_0 = ['a', 'B', 'C', 'd', 'E']
    expected_0 = ['a', 'b', 'c', 'd', 'e']
    out_0 = lenient_lowercase(in_0)
    if out_0 == expected_0:
        bool_0 = True
    else:
        bool_0 = False

    return bool_0


# Generated at 2022-06-24 21:15:18.965073
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert False


# Generated at 2022-06-24 21:15:27.457313
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('Function to test : human_to_bytes')

    size_str = '1B'
    print('\tTesting : ', size_str)
    if human_to_bytes(size_str) == 1:
        print('\ttest pass')
    else:
        print('\ttest fails')

    size_str = '1KB'
    print('\tTesting : ', size_str)
    if human_to_bytes(size_str) == 1024:
        print('\ttest pass')
    else:
        print('\ttest fails')

    size_str = '1Kb'
    print('\tTesting : ', size_str)
    if human_to_bytes(size_str, default_unit='K', isbits=True) == 1000:
        print('\ttest pass')

# Generated at 2022-06-24 21:15:37.608835
# Unit test for function human_to_bytes
def test_human_to_bytes():
    if lenient_lowercase(['b']) != ['b']:
        bytes_to_human(lenient_lowercase(['b']))
    if lenient_lowercase(['B']) != ['b']:
        bytes_to_human(lenient_lowercase(['B']))
    if test_case_0() is True:
        bytes_to_human(test_case_0())
    if human_to_bytes('2K') != 2048:
        bytes_to_human(human_to_bytes('2K'))
    if lenient_lowercase(['B']) != ['b']:
        bytes_to_human(lenient_lowercase(['B']))

# Generated at 2022-06-24 21:15:47.943312
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes("10M") == 10485760)
    assert(human_to_bytes("10M", default_unit = 'B') == 10485760)
    assert(human_to_bytes("10M", isbits=True) == 10485760)
    with pytest.raises(ValueError):
        assert(human_to_bytes("10") == 10)
    with pytest.raises(ValueError):
        assert(human_to_bytes("10", default_unit = 'B') == 10)
    with pytest.raises(ValueError):
        assert(human_to_bytes("10", isbits=True) == 10)
    with pytest.raises(ValueError):
        assert(human_to_bytes("10") == 10)

# Generated at 2022-06-24 21:15:56.035745
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1M') != 1048577
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606847000
    assert human_to_bytes('1Z') == 1180591620717411303424
    assert human_to_bytes('1Y') == 1208925819614629174706176
    assert human_to_bytes('1B') == 1
    assert human_

# Generated at 2022-06-24 21:16:06.231971
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test cases
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('1GB', unit='b') == 1073741824
    assert human_to_bytes('1Mb', default_unit='b', isbits=True) == 1048576
    assert human_to_bytes('1Gb', unit='b', isbits=True) == 1073741824
    assert human_to_bytes('1', default_unit='B') == 1
    assert human_to_bytes('1G', isbits=True) == 1 << 30

# Generated at 2022-06-24 21:16:17.552616
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes(10, 'M') == 10000000
    assert human_to_bytes(3, 'KB') == 3000
    assert human_to_bytes(3, 'Kb') == 3000
    assert human_to_bytes(3, 'kb') == 3000
    assert human_to_bytes(2, 'Kb') == 2000
    assert human_to_bytes(2, 'kb') == 2000
    assert human_to_bytes(2, 'Kb', isbits=True) == 2000
    assert human_to_bytes(2, 'kb', isbits=True) == 2000
    assert human_to_bytes(2) == 2
    assert human_to_bytes(10) == 10
    assert human_to_bytes(1.1) == 1

# Generated at 2022-06-24 21:16:26.299144
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2b') ==  0
    assert human_to_bytes('2K') ==  2048
    assert human_to_bytes('2.5k') ==  2560
    assert human_to_bytes('2Kb') ==  (2 * 1024)
    assert human_to_bytes('2M') ==  2097152
    assert human_to_bytes('2m') ==  2097152
    assert human_to_bytes('2mB') ==  2097152
    assert human_to_bytes('2MB') ==  2097152
    assert human_to_bytes('2.5M') ==  (2.5 * 1024 * 1024)
    assert human_to_bytes('2.5MB') ==  (2.5 * 1024 * 1024)