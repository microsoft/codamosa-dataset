

# Generated at 2022-06-24 21:06:40.997731
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('Unit test for function human_to_bytes')

    assert test_case_0() == '-394.00 Bytes'

# Generated at 2022-06-24 21:06:45.822748
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1, 'B') == 1
    assert human_to_bytes(1, 'K') == 1024
    assert human_to_bytes(1, 'M') == 1048576
    assert human_to_bytes(1, 'G') == 1073741824
    assert human_to_bytes(1, 'T') == 1099511627776
    assert human_to_bytes(1, 'P') == 1125899906842624
    assert human_to_bytes(1, 'E') == 1152921504606846976
    assert human_to_bytes(1, 'Z') == 1180591620717411303424
    assert human_to_bytes(1, 'Y') == 1208925819614629174706176
    assert human_to_bytes('1B') == 1

# Generated at 2022-06-24 21:06:52.822867
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('Testing function human_to_bytes()')
    # Testing case #1
    bytes_number = human_to_bytes('1M')
    assert bytes_number == 1048576, "Bytes number is not expected (1M is expected to be 1048576)"
    # Testing case #2
    bytes_number = human_to_bytes('1Mb', isbits=True)
    assert bytes_number == 1048576, "Bytes number is not expected (1Mb is expected to be 1048576)"



# Generated at 2022-06-24 21:06:56.731399
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [11, 'abc', 22, 'def']
    result = lenient_lowercase(lst)
    assert result == [11, 'abc', 22, 'def']


# Generated at 2022-06-24 21:06:59.825234
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['aBc', 42]) == ['abc', 42]


# Generated at 2022-06-24 21:07:04.057522
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert '-394.00 Bytes' == test_case_0()

# Generated at 2022-06-24 21:07:11.481035
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1) == 1
    assert human_to_bytes("1") == 1
    assert human_to_bytes("1B") == 1
    assert human_to_bytes("1b") == 1
    assert human_to_bytes("1b", isbits=True) == 1
    assert human_to_bytes("1K") == 1024
    assert human_to_bytes("1M") == 1024 * 1024
    assert human_to_bytes("1G") == 1024 * 1024 * 1024
    assert human_to_bytes("1T") == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes("1P") == 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes("1", "p") == 1024 * 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-24 21:07:20.894306
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('3.5M') == 3768320
    assert human_to_bytes('1.5M', default_unit="KB") == 1536000
    assert human_to_bytes('1.5Mb') == 1843200
    assert human_to_bytes('1.5Mb', isbits=True) == 1572864
    assert human_to_bytes('1.5MB') == 1572864
    assert human_to_bytes('1.5MB', isbits=True) == 1572864000
    assert human_to_bytes('1.5Mb', unit="KB") == 1843200
    assert human_to_bytes('1.5Mb', default_unit="MB") == 1843200
    assert human_to_bytes('1.5Mb', unit="MB") == 1843200
   

# Generated at 2022-06-24 21:07:22.418099
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = human_to_bytes('1K')
    assert result == 1024


# Generated at 2022-06-24 21:07:32.222606
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB') == 1024 * 1024
    assert human_to_bytes('1GB') == 1024 * 1024 * 1024
    assert human_to_bytes('1TB') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1PB') == 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1EB') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1ZB') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1YB') == 1024 * 1024

# Generated at 2022-06-24 21:07:43.024685
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test with single byte as input
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.1B') == 1
    assert human_to_bytes('1.5B') == 2
    assert human_to_bytes('b') == 1

    # test with unit byte as input
    assert human_to_bytes('1.1 byte') == 1
    assert human_to_bytes('1 byte') == 1
    assert human_to_bytes('1.5 byte') == 2
    assert human_to_bytes('1.5 bytes') == 2
    assert human_to_bytes('bytes') == 1
    assert human_to_bytes(1) == 1

    # test with integer input
    assert human_to_bytes(1) == 1
    assert human_to_bytes(1.1) == 1

# Generated at 2022-06-24 21:07:52.056295
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == "1 Bytes"
    assert bytes_to_human(1024) == "1.00 KB"
    assert bytes_to_human(1024 * 1024) == "1.00 MB"
    assert bytes_to_human(1024 * 1024 * 1024) == "1.00 GB"

    assert bytes_to_human(1024, isbits=True) == "1.00 Kbit"
    assert bytes_to_human(1024 * 1024, isbits=True) == "1.00 Mbit"
    assert bytes_to_human(1024 * 1024 * 1024, isbits=True) == "1.00 Gbit"

    assert bytes_to_human(1024, unit='b') == "8.00 b"

# Generated at 2022-06-24 21:07:56.302323
# Unit test for function human_to_bytes
def test_human_to_bytes():
    unit_test_var_0 = '1KB'
    unit_test_var_1 = '1Kb'

    try:
        unit_test_var_0 = human_to_bytes(str(unit_test_var_0))
        unit_test_var_1 = human_to_bytes(str(unit_test_var_1))

    except Exception:
        pass



# Generated at 2022-06-24 21:08:02.327434
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2K', isbits=True) == 16384
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'M', isbits=True) == 83886080
    assert human_to_bytes(10, 'Mb') == 10485760
    assert human_to_bytes(10, 'Mb', isbits=True) == 83886080
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1K', isbits=True) == 8192
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1M', isbits=True) == 8388608
    assert human_to_

# Generated at 2022-06-24 21:08:06.966052
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['B', 'K', 'M', 'G', 'T']) == ['b', 'k', 'm', 'g', 't']
    assert lenient_lowercase(['B', 2, 3]) == ['b', 2, 3]


# Generated at 2022-06-24 21:08:13.353421
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        assert human_to_bytes('13K') == 13 * 1024
        assert human_to_bytes('6.1 MB') == 6500000
        assert human_to_bytes('0.25 gb') == 268435456
        assert human_to_bytes('2Gb') == 2147483648
        assert human_to_bytes('3.3b') == 3.3
        assert human_to_bytes('0b') == 0
    except Exception as e:
        raise AssertionError("Unexpected result\n%s" % e)


# Generated at 2022-06-24 21:08:23.468785
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("Starting test_human_to_bytes")
    # these are test vars
    test_var_0 = '1023'
    test_var_1 = '1024'
    test_var_2 = '1025'
    test_var_3 = '1023.5'
    test_var_4 = '1024.0'
    test_var_5 = '1025.0'
    # test_var_6 = '20MB'
    # test_var_7 = '10Mb'
    # test_var_8 = '10MB'
    # test_var_9 = '10MB'
    # test_var_10 = '2.5G'

    # this is the test
    test_1 = human_to_bytes(test_var_0)

# Generated at 2022-06-24 21:08:27.279290
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1180591620717411303424) == '10.00 ZiB'



# Generated at 2022-06-24 21:08:36.811954
# Unit test for function bytes_to_human
def test_bytes_to_human():
    # zero bytes
    assert '0 Bytes' == bytes_to_human(0)
    # byte
    assert '1 Byte' == bytes_to_human(1)
    # kilo byte
    assert '1 KB' == bytes_to_human(1024)
    # mega byte
    assert '1 MB' == bytes_to_human(1024 * 1024)
    # giga byte
    assert '1 GB' == bytes_to_human(1024 * 1024 * 1024)
    # two decimals
    assert '100.00 GB' == bytes_to_human(100 * 1024 * 1024 * 1024)
    # one decimals
    assert '100.1 GB' == bytes_to_human(100 * 1024 * 1024 * 1024 + 1024 * 1024 * 100)
    # three decimals
    assert '100.101 GB' == bytes_

# Generated at 2022-06-24 21:08:46.587934
# Unit test for function human_to_bytes
def test_human_to_bytes():
    number_convert = ['2K', 2, '1Mb', '1.1MB', '1 KB', '2.3M', '3E']
    unit_convert = ['B', 'b', 'kb', 'KB', 'Kb', 'MB', 'Kb']
    result_convert = [2048, 2, 1048576, 1048576, 1024, 2386048, 3145728000]
    isbits_convert = [None, False, True, False, True, False, False]


# Generated at 2022-06-24 21:09:01.284787
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1") == 1
    assert human_to_bytes("1.1", default_unit="M") == 115343360
    assert human_to_bytes("2K") == 2048
    assert human_to_bytes("3M") == 3145728
    assert human_to_bytes("4G") == 4294967296
    assert human_to_bytes("5T") == 549755813888
    assert human_to_bytes("6P") == 67553994410557440
    assert human_to_bytes("7E") == 8070450532247928832
    assert human_to_bytes("8Z") == 9444732965739290427392
    assert human_to_bytes("9Y") == 1073741824000000000000000000


# Generated at 2022-06-24 21:09:03.078846
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['FOO', 'BAR', 1, 2]) == ['foo', 'bar', 1, 2], 'Test lenient_lowercase failed!'


# Generated at 2022-06-24 21:09:12.992887
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    numbers = [
        '2K', '2.2M', '100G', '10T', '200P'
    ]
    for number in numbers:
        try:
            human_to_bytes(number)
        except ValueError as err:
            print(err)
            raise
    try:
        human_to_bytes('invalid')
    except ValueError as err:
        if 'invalid' not in err.args[0]:
            print(err)
            raise

    try:
        human_to_bytes('1.1KB')
    except ValueError as err:
        if 'K' not in err.args[0] or 'M' not in err.args[0] or 'G' not in err.args[0]:
            print(err)
            raise


# Generated at 2022-06-24 21:09:18.608919
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(15) == 15
    assert human_to_bytes(10, 'm') == 10
    assert human_to_bytes('5Gb') == 5368709120
    assert human_to_bytes('5GB') == 5368709120
    assert human_to_bytes('5gb') == 5368709120
    assert human_to_bytes('5gB') == 5368709120
    assert human_to_bytes('5g') == 5000000000
    assert human_to_bytes('5k') == 5000000
    assert human_to_bytes('2Mb') == 2097152
    assert human_to_bytes('2MB') == 2097152
    assert human_to_bytes('2mb') == 2097152
    assert human_to_bytes('2mB') == 2097152
    assert human_

# Generated at 2022-06-24 21:09:21.528954
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['lower', 'CASE', 42, True]) == ['lower', 'case', 42, True])



# Generated at 2022-06-24 21:09:23.039096
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(list()) == list()



# Generated at 2022-06-24 21:09:32.530596
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(["foo"]) == ["foo"]
    assert lenient_lowercase(["foo", "bar"]) == ["foo", "bar"]
    assert lenient_lowercase(["FOO", "BAR"]) == ["foo", "bar"]
    assert lenient_lowercase([[]]) == [[]]
    assert lenient_lowercase([["foo"], ["bar"]]) == [["foo"], ["bar"]]
    assert lenient_lowercase([["FOO"], ["BAR"]]) == [["foo"], ["bar"]]
    assert lenient_lowercase(["foo", ["bar", ["baz", "bing"]]]) == ["foo", ["bar", ["baz", "bing"]]]

# Generated at 2022-06-24 21:09:41.107280
# Unit test for function human_to_bytes
def test_human_to_bytes():
    float_0 = -394.0
    var_0 = human_to_bytes(float_0)
    float_1 = -394.0
    var_1 = human_to_bytes(float_1, isbits=True)
    float_2 = -394.0
    var_2 = human_to_bytes(float_2, default_unit='K')
    float_3 = -394.0
    var_3 = human_to_bytes(float_3, default_unit='K', isbits=True)
    float_4 = -394.0
    var_4 = human_to_bytes(float_4, isbits=False)
    str_0 = 'test'
    var_5 = human_to_bytes(str_0, default_unit='K', isbits=True)

# Generated at 2022-06-24 21:09:46.064883
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    '''
    Test lenient_lowercase function
    '''
    assert lenient_lowercase(['a', 'B', 'C', 'D']) == ['a', 'b', 'c', 'd']



# Generated at 2022-06-24 21:09:56.622342
# Unit test for function human_to_bytes
def test_human_to_bytes():
    if human_to_bytes('500mb') != 524288000:
        raise AssertionError("500MB != 524288000 bytes.")
    if human_to_bytes('500mb') != human_to_bytes('500MB'):
        raise AssertionError("500MB != 500MB by default, size should be interpreted as bytes.")
    if human_to_bytes('500mb', isbits=True) != 500000000:
        raise AssertionError("500mb != 500000000 bits.")
    if human_to_bytes('500mb', isbits=True) == human_to_bytes('500MB'):
        raise AssertionError("500mb == 500MB by default, size should be interpreted as bytes.")
    if human_to_bytes('500mb', isbits=True) != human_to_bytes('500Mb'):
        raise

# Generated at 2022-06-24 21:10:03.901098
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_0 = ['bA', 1, 'cA']
    expect_0 = ['ba', 1, 'ca']
    actual_0 = lenient_lowercase(input_0)
    assert expect_0 == actual_0


# Generated at 2022-06-24 21:10:06.890361
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = human_to_bytes(10)
    assert result == 10



# Generated at 2022-06-24 21:10:13.328077
# Unit test for function human_to_bytes
def test_human_to_bytes():
    bytes = human_to_bytes('10M')
    assert bytes == 10485760
    assert isinstance(bytes, int)

    bytes = human_to_bytes('1MB')
    assert bytes == 1048576
    assert isinstance(bytes, int)

    bits = human_to_bytes('10Mb', isbits=True)
    assert bits == 10485760
    assert isinstance(bits, int)

    bits = human_to_bytes('10Mb', unit='Mb', isbits=True)
    assert bits == 10485760
    assert isinstance(bits, int)


# Generated at 2022-06-24 21:10:18.618886
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'A', 'b', 'B']) == ['a', 'a', 'b', 'b']
    assert lenient_lowercase([('a', 'b'), ('B', 'c')]) == [('a', 'b'), ('B', 'c')]


# Generated at 2022-06-24 21:10:22.928298
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Input parameters:
    human_readable_string = '2K'

    # Expected return value:
    expected_output = 2048

    # Actual return value:
    output = human_to_bytes(human_readable_string)

    # Assertion
    assert output == expected_output, 'Expected output: %i, but got: %i' % (expected_output, output)


# Generated at 2022-06-24 21:10:26.066780
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['', '']) == ['', '']
    assert lenient_lowercase(['', '']) == ['', '']


# Generated at 2022-06-24 21:10:38.235048
# Unit test for function human_to_bytes
def test_human_to_bytes():
    #assert(human_to_bytes(1, 'mb') == 1048576)
    assert(human_to_bytes(1, 'MB') == 1048576)
    assert(human_to_bytes('1MB') == 1048576)
    assert(human_to_bytes('1mb', isbits=True) == 1048576)
    assert(human_to_bytes(1, 'kb') == 1024)
    assert(human_to_bytes(1, 'Kb') == 1024)
    assert(human_to_bytes('1kb') == 1024)
    assert(human_to_bytes('1Kb', isbits=True) == 1024)
    #assert(human_to_bytes(1, 'gb') == 1073741824)
    assert(human_to_bytes(1, 'GB') == 1073741824)

# Generated at 2022-06-24 21:10:40.307474
# Unit test for function human_to_bytes
def test_human_to_bytes():
    input = '-394'
    output = human_to_bytes(input)

    assert output is not None


# Generated at 2022-06-24 21:10:49.093676
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_cases = [
        ([], []),
        ([None], [None]),
        ([0, 1], [0, 1]),
        (['a', 'B', 'c'], ['a', 'B', 'c']),
        (['a', 1], ['a', 1]),
        (['A', 'b', 'c'], ['a', 'b', 'c']),
        (['A', 'b', 'c', 'aBc'], ['a', 'b', 'c', 'aBc']),
        ([['a', 'B', 'c'], ['A', 'b', 'c']], [['a', 'B', 'c'], ['a', 'b', 'c']]),
    ]
    for test_case, expected in test_cases:
        result = lenient_lowercase(test_case)

# Generated at 2022-06-24 21:10:52.096897
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["a", "b", "C"]) == ["a", "b", "c"]
    int_lst = [1, 2, 3]
    assert lenient_lowercase(int_lst) == int_lst


# Generated at 2022-06-24 21:11:04.857405
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['TEST', 'TEST', 'TEST']) == ['test', 'test', 'test']
    assert lenient_lowercase(['TEST', 'TEST', [1, 2, 3]]) == ['test', 'test', [1, 2, 3]]
    assert lenient_lowercase(['TEST', 'TEST', ('tuple', 'tuple', 'tuple')]) == ['test', 'test', ('tuple', 'tuple', 'tuple')]
    assert lenient_lowercase(['TEST', 'TEST', {'key': 'value'}]) == ['test', 'test', {'key': 'value'}]

# Generated at 2022-06-24 21:11:07.749484
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['hello', 'WORLD', 42]) == ['hello', 'world', 42]



# Generated at 2022-06-24 21:11:17.581175
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Testing simple string
    result = lenient_lowercase(['Hello World'])
    assert result == ['hello world']

    # Testing None type string
    result = lenient_lowercase(['None'])
    assert result == ['none']

    # Testing empty string
    result = lenient_lowercase([''])
    assert result == ['']

    # Testing int
    result = lenient_lowercase(['1'])
    assert result == ['1']

    # Testing list
    result = lenient_lowercase([['Hello World']])
    assert result == [['hello world']]

    # Testing empty list
    result = lenient_lowercase([[]])
    assert result == [[]]

    # Testing None value inside list
    result = lenient_lowercase([['None']])

# Generated at 2022-06-24 21:11:24.342166
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1]) == [1]
    assert lenient_lowercase(['test', 1, None]) == ['test', 1, None]
    assert lenient_lowercase(['TEST']) == ['test']
    assert lenient_lowercase(['TEST', 'test']) == ['test', 'test']
    assert lenient_lowercase(['TEST', 'test', 1]) == ['test', 'test', 1]
    assert lenient_lowercase(['TEST', 'teSt', 1]) == ['test', 'teSt', 1]


# Generated at 2022-06-24 21:11:35.848925
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1', default_unit='B') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1K', default_unit='B') == 1024
    assert human_to_bytes('1M', default_unit='B') == 1048576
    assert human_to_bytes('1G', default_unit='B') == 1073741824
    assert human_to_bytes('1T', default_unit='B') == 1099511627776
    assert human_to_bytes('1P', default_unit='B') == 1125899906842624
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1023') == 1023

# Generated at 2022-06-24 21:11:38.193982
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    actual = lenient_lowercase(['a', 'B', 1, 2])
    assert actual == ['a', 'b', 1, 2]



# Generated at 2022-06-24 21:11:48.999276
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('6MB') == 6291456
    assert human_to_bytes('7GB') == 734003200
    assert human_to_bytes('8TB') == 8589934592
    assert human_to_bytes('9PB') == 990352031680
    assert human_to_bytes('10EB') == 10276070246400
    assert human_to_bytes('11ZB') == 1060448573670400
    assert human_to_bytes('12YB') == 1093275037637017600
    assert human_to_bytes('13B') == 13
    assert human_to_bytes('14') == 14
    assert human_to_bytes('15.5') == 15
    assert human_to_bytes

# Generated at 2022-06-24 21:11:56.705655
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test empty case
    assert lenient_lowercase([]) == []
    # Test case with lowercase only
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    # Test case with mixed case
    assert lenient_lowercase(['a', 'B', 'C']) == ['a', 'b', 'c']
    # Test case with non-strings
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    # Test case with mixed strings and non-strings
    assert lenient_lowercase(['a', 2, 'c']) == ['a', 2, 'c']


# Generated at 2022-06-24 21:11:59.140147
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list = [1,2,'ABC','XYZ','def']
    list_lc = lenient_lowercase(list)
    assert list_lc == [1,2,'abc','xyz','def'], "Test case failed!"

# Generated at 2022-06-24 21:12:01.639325
# Unit test for function human_to_bytes
def test_human_to_bytes():
    input = '1.0MB'
    expected = 1048576
    actual = human_to_bytes(input)
    assert actual == expected


# Generated at 2022-06-24 21:12:10.618254
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('2B') == 2
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes(2) == 2
    assert human_to_bytes(3.5) == 3
    assert human_to_bytes(1.2) == 1
    assert human_to_bytes('-2B') == -2
    assert human_to_bytes(int) == 0


# Generated at 2022-06-24 21:12:20.781375
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1MB', 'b') == 8388608
    assert human_to_bytes('1MB', isbits=True) == 1048576
    assert human_to_bytes('2.5Gb', isbits=True) == 268435456
    assert human_to_bytes('4M', 'B') == 4194304
    assert human_to_bytes('4 Mb', 'b') == 4194304
    assert human_to_bytes('4 M', 'B') == 4194304
    assert human_to_bytes('4 M', 'B') == 4194304
    assert human_to_bytes('4Mb', isbits=True) == 4194304
    assert human_to_bytes('4MB', 'b') == 4194304

# Generated at 2022-06-24 21:12:32.094159
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Test function human_to_bytes.
    '''
    int_0 = human_to_bytes('1Mb', isbits=True)
    int_1 = human_to_bytes('20')
    int_2 = human_to_bytes('30')
    int_3 = human_to_bytes('40')
    int_4 = human_to_bytes('50')
    int_5 = human_to_bytes('60')
    int_6 = human_to_bytes('70')
    int_7 = human_to_bytes('80')
    int_8 = human_to_bytes('90')
    int_9 = human_to_bytes('100')
    int_10 = human_to_bytes('110')
    int_11 = human_to_bytes('120')
    int_12 = human

# Generated at 2022-06-24 21:12:40.579867
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10.5MB') == 10995116
    assert human_to_bytes('5.5G') == 64424509440
    assert human_to_bytes('10Mb') == human_to_bytes(10, 'Mb', isbits=True)
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10.5Mb', isbits=True) == 10995116
    assert human_to_bytes('5.5Gb', isbits=True) == 64424509440
   

# Generated at 2022-06-24 21:12:46.619379
# Unit test for function human_to_bytes
def test_human_to_bytes():
    input_string = '1KB'
    result_output = human_to_bytes(number=input_string)
    assert result_output == 1024
    print("test_human_to_bytes passed")


# Generated at 2022-06-24 21:12:50.122627
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['foo', 'bar', 5.5]) == ['foo', 'bar', 5.5]


# Generated at 2022-06-24 21:12:58.202400
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test when input is only number and the default unit is B
    assert human_to_bytes('1') == 1
    assert human_to_bytes(123) == 123
    assert human_to_bytes(123.456) == 123

    # Test when input is only number and the default unit is b
    assert human_to_bytes('1', isbits=True) == 1
    assert human_to_bytes(123, isbits=True) == 123
    assert human_to_bytes(123.456, isbits=True) == 123

    # Test when input is only number and the default_unit is not B or b
    assert human_to_bytes('1', 'K') == 1000
    assert human_to_bytes(123, 'Z') == 12300000000000000000000000
    assert human_to_bytes(123.456, 'G') == 123456000000

# Generated at 2022-06-24 21:13:02.547264
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    i_list = ['AA', 'FoO', object(), object(), object(), object(), object(), object()]
    assert(lenient_lowercase(i_list) == ['aa', 'foo', object(), object(), object(), object(), object(), object()])


# Generated at 2022-06-24 21:13:10.534787
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    def compare_results(var_0, var_1):
        var_0 = var_0
        var_1 = var_1
        assert var_0 == var_1

    var_0 = ['1', '2', '3', '4']
    var_1 = ['1', '2', '3', '4']
    compare_results(lenient_lowercase(var_0), var_1)
    var_0 = [1, 2, 3]
    var_1 = [1, 2, 3]
    compare_results(lenient_lowercase(var_0), var_1)
    var_0 = [
        1, 2, 3, 4, '5', [
            1, 2, 3, 4, 5, '6', 7
        ]
    ]

# Generated at 2022-06-24 21:13:21.287477
# Unit test for function human_to_bytes
def test_human_to_bytes():
    byte_list = ['1', '1K', '1M', '1G', '1T', '1P', '1E', '1Z', '1Y', '1b', '1Kb', '1Mb', '1Gb', '1Tb', '1Pb', '1Eb', '1Zb', '1Yb']
    bit_list = ['1Kb', '1Mb', '1Gb', '1Tb', '1Pb', '1Eb', '1Zb', '1Yb']

# Generated at 2022-06-24 21:13:37.250231
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'm') == 1048576
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10mb') == 1048576
    assert human_to_bytes(10, 'mb', isbits=True) == 1048576
    assert human_to_bytes(10, 'Mb', isbits=True) == 10485760
    assert human_to_bytes(10, 'm', isbits=True) == 1048576
    assert human_to_bytes('10.5M') == 10485760
    assert human_to_bytes('10.5MB') == 10485760

# Generated at 2022-06-24 21:13:45.782616
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Ansible module argument_spec test
    # Input: 1024 (number)
    # Output: 1024 (int)
    assert human_to_bytes(1024, default_unit='B') == 1024
    assert human_to_bytes(1024, default_unit=None) == 1024

    # Input: ('1024') (str)
    # Output: 1024 (int)
    assert human_to_bytes('1024', default_unit='B') == 1024
    assert human_to_bytes('1024', default_unit=None) == 1024

    # Input: '0.5' (str)
    # Output: 0.5 (float)
    assert human_to_bytes('0.5', default_unit='B') == 0.5
    assert human_to_bytes('0.5', default_unit=None) == 0.5

    # Input: '

# Generated at 2022-06-24 21:13:53.163595
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'M', True) == 10485760
    assert human_to_bytes(10, 'KB') == 10240
    assert human_to_bytes(10, 'KB', True) == 10240
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', True) == 10485760
    assert human_to_bytes('10M', False) == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10Mb', True) == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10MB', True)

# Generated at 2022-06-24 21:13:56.226155
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lowercase_0 = lenient_lowercase(['msg', 'msg1'])
    lowercase_1 = lenient_lowercase(['msg', 'msg1'])

    # assert statement
    assert lowercase_0 == lowercase_1


# Generated at 2022-06-24 21:13:59.114440
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lenient_lowercase_list = lenient_lowercase([1, 'n', 'N', 'NEE', 'NEEE'])
    assert lenient_lowercase_list == [1, 'n', 'n', 'ne', 'nee']


# Generated at 2022-06-24 21:14:10.850836
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2B') == 2, '2B -> 2'
    assert human_to_bytes('2b') == 2, '2b -> 2'
    assert human_to_bytes('2K') == 2 * 1024, '2K -> 2 * 1024'
    assert human_to_bytes('2KB') == 2 * 1024, '2K -> 2 * 1024'
    assert human_to_bytes('2KB', isbits=True) == 2 * 1024 * 8, '2KB -> 2 * 1024 * 8'
    assert human_to_bytes('2Kb', isbits=True) == 2 * 1024 * 8, '2Kb -> 2 * 1024 * 8'
    assert human_to_bytes('2M') == 2 * 1024 * 1024, '2M -> 2 * 1024 * 1024'

# Generated at 2022-06-24 21:14:14.093459
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["A", "a", 1, None]) == ["a", "a", 1, None]

# Generated at 2022-06-24 21:14:18.804812
# Unit test for function human_to_bytes
def test_human_to_bytes():
    float_0 = -394.0
    var_0 = human_to_bytes(float_0)
    print('var_0: {0}'.format(var_0))
    float_1 = -11600.0
    var_1 = human_to_bytes(float_1)
    print('var_1: {0}'.format(var_1))

# Generated at 2022-06-24 21:14:22.887620
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    print('Test lenient_lowercase')

    assert lenient_lowercase([1, 'foo', 'BAR']) == [1, 'foo', 'BAR']
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'B', 'c']



# Generated at 2022-06-24 21:14:32.198933
# Unit test for function human_to_bytes
def test_human_to_bytes():
    s = human_to_bytes('10M')
    assert s == 10 * 2**20

    s = human_to_bytes('10.2M')
    assert s == 10 * 2**20

    s = human_to_bytes('10.2G', isbits=True)
    assert s == 10.2 * 2**30

    s = human_to_bytes('1337KiB', 'MiB')
    assert s == 1 * 2**20

    s = human_to_bytes('3.5PB', 'TiB')
    assert s == (3.5 * 2**50) / (2**40)

    s = human_to_bytes('3.5PB', 'TiB', isbits=True)
    assert s == (3.5 * 2**50) / (2**40)

    s = human_to

# Generated at 2022-06-24 21:14:42.524343
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    out = lenient_lowercase(['a', 'b', 'C', 1, 2, 3, None])
    assert out == ['a', 'b', 'c', 1, 2, 3, None]



# Generated at 2022-06-24 21:14:51.412753
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # bytes case
    assert human_to_bytes('1') == 1
    assert human_to_bytes('10') == 10
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('10G') == 10737418240
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('10T') == 10995116277760

    # bits case
    assert human_to_bytes('1', isbits=True) == 1

# Generated at 2022-06-24 21:14:54.024910
# Unit test for function human_to_bytes
def test_human_to_bytes():
    int_0 = human_to_bytes('2.0MB')
    assert int_0 == 2097152

# Generated at 2022-06-24 21:15:03.309540
# Unit test for function human_to_bytes

# Generated at 2022-06-24 21:15:08.834540
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    testcases = [
        ([], []),
        (['foo', 'bar'], ['foo', 'bar']),
        (['Foo', 'Bar'], ['foo', 'bar']),
        ([1, 2, 3], [1, 2, 3]),
        ([1, 2, 'Foo'], [1, 2, 'Foo']),
    ]
    for old, new in testcases:
        assert lenient_lowercase(old) == new


# Generated at 2022-06-24 21:15:19.222184
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test 1
    float_0 = -394.0
    var_0 = human_to_bytes(float_0)
    assert var_0 == 0

    # Test 2
    str_0 = '2867MB'
    var_0 = human_to_bytes(str_0)
    assert var_0 == 301683712

    # Test 3
    str_0 = '-3.0'
    var_0 = human_to_bytes(str_0)
    assert var_0 == 0

    # Test 4
    str_0 = '5.0'
    var_0 = human_to_bytes(str_0)
    assert var_0 == 5

    # Test 5
    str_0 = '.0'
    var_0 = human_to_bytes(str_0)

# Generated at 2022-06-24 21:15:23.142804
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024


# Generated at 2022-06-24 21:15:33.963273
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10, default_unit='M') == 10485760
    assert human_to_bytes('20M') == 20971520
    assert human_to_bytes('2 MB') == 2097152
    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('2000') == 2000
    assert human_to_bytes(2000) == 2000
    assert human_to_bytes('1 KB', isbits=True) == 8000
    assert human_to_bytes('1 MB', isbits=True) == 8000000

if __name__ == '__main__':
    test_human_to_bytes()
    test_case_0()

# Generated at 2022-06-24 21:15:42.749963
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Testing 2K case
    result = human_to_bytes('2k')
    assert result == 2048, 'Expected 2048 for 2K, got %s' % result

    # Testing 2KB case
    result = human_to_bytes('2KB')
    assert result == 2048, 'Expected 2048 for 2KB, got %s' % result

    # Testing 1.5K case
    result = human_to_bytes('1.5k')
    assert result == 1536, 'Expected 1536 for 1.5K, got %s' % result

    # Testing 1.5KB case
    result = human_to_bytes('1.5KB')
    assert result == 1536, 'Expected 1536 for 1.5KB, got %s' % result

    # Testing 2Mb case

# Generated at 2022-06-24 21:15:43.656283
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024



# Generated at 2022-06-24 21:15:59.405228
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase(['1', '2', '3']) == ['1', '2', '3']
    assert lenient_lowercase(["1", 2, "3"]) == ["1", 2, "3"]
    assert lenient_lowercase(["1", 2, "3"]) == ["1", 2, "3"]
    assert lenient_lowercase(["a1", "b2", "c3"]) == ["a1", "b2", "c3"]
    assert lenient_lowercase(["A1", "B2", "C3"]) == ["a1", "b2", "c3"]


# Generated at 2022-06-24 21:16:09.395985
# Unit test for function human_to_bytes
def test_human_to_bytes():
    t1 = '2K'
    t2 = '2.5M'
    t3 = '3G'
    t4 = '4.5E'
    t5 = '5.5Kb'
    t6 = '6.5Malso'
    t7 = '7.5kb'
    t8 = '8.5'
    t9 = '9.5Ealso'
    t10 = '10.5'
    t11 = '11.5Mb'

    assert human_to_bytes(t1) == (2 << 10)
    assert human_to_bytes(t2) == (2.5 << 20)
    assert human_to_bytes(t3) == (3 << 30)
    assert human_to_bytes(t4) == (4.5 << 60)
    assert human_

# Generated at 2022-06-24 21:16:13.430491
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase(['1', '2', '3']) == ['1', '2', '3']
    assert lenient_lowercase(['1', 2, '3']) == ['1', 2, '3']

# Generated at 2022-06-24 21:16:22.622855
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test case#0
    float_0 = -394.0
    var_0 = human_to_bytes(float_0)
    assert var_0 == -394
    # Test case#1
    float_1 = 924.0
    var_1 = human_to_bytes(float_1)
    assert var_1 == 924
    # Test case#2
    float_2 = -26.0
    var_2 = human_to_bytes(float_2)
    assert var_2 == -26
    # Test case#3
    float_3 = -863.0
    var_3 = human_to_bytes(float_3)
    assert var_3 == -863
    # Test case#4
    float_4 = 866.0

# Generated at 2022-06-24 21:16:32.913390
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Case 0
    float_0 = -394.0
    assert human_to_bytes(float_0) == -394, "Test case 0 failed"

    # Case 1
    str_0 = '-394.0'
    assert human_to_bytes(str_0) == -394, "Test case 1 failed"

    # Case 2
    str_0 = '-394.0'
    var_0 = human_to_bytes(str_0)
    assert var_0 == -394, "Test case 2 failed"

    # Case 3
    str_0 = '-394.0'
    assert human_to_bytes(str_0) == -394, "Test case 3 failed"

    # Case 4
    str_0 = '-394.0'
    assert human_to_bytes(str_0) == -394

# Generated at 2022-06-24 21:16:36.587757
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = [1, "A", "B", 3, "D"]
    result = lenient_lowercase(lst)
    assert result == [1, "a", "b", 3, "d"]
