

# Generated at 2022-06-24 21:06:59.816951
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 4, 'C']) == ['a', 4, 'c']
    assert lenient_lowercase(['123', 4, '5678']) == ['123', 4, '5678']
    assert lenient_lowercase([None]) == [None]


# Generated at 2022-06-24 21:07:10.906686
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1024B') == 1024
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1m') == 1024 ** 2
    assert human_to_bytes('1mb') == 1024 ** 2
    assert human_to_bytes('1g') == 1024 ** 3
    assert human_to_bytes('1gb') == 1024 ** 3
    assert human_to_bytes('1t') == 1024 ** 4
    assert human_to_bytes('1tb') == 1024 ** 4
    assert human_to_bytes('1p') == 1024 ** 5
    assert human_to_bytes('1pb') == 1024 ** 5
    assert human_to_bytes('1e') == 1024 ** 6

# Generated at 2022-06-24 21:07:17.018433
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    '''
    Test various input for lowercase operation
    '''
    assert lenient_lowercase([]) == []
    assert lenient_lowercase(['test']) == ['test']
    assert lenient_lowercase(['lowercase']) == ['lowercase']
    assert lenient_lowercase(['MIXED', 'CASE']) == ['mixed', 'case']
    assert lenient_lowercase([{'name': 'UPPERCASE', 'id': 'id'}]) == [{'name': 'UPPERCASE', 'id': 'id'}]



# Generated at 2022-06-24 21:07:22.377864
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(['ABc', 1])
    assert result == ['abc', 1]



# Generated at 2022-06-24 21:07:25.215526
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['FoO', None, 123]) == ['foo', None, 123]


# Generated at 2022-06-24 21:07:31.167039
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Check if function human_to_bytes returns expected value
    # Check that ValueError is raised when passed incorrect arguments
    try:
        test_case_0()
    except Exception as e:
        assert False

# Generated at 2022-06-24 21:07:42.205755
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert bytes_to_human(human_to_bytes('1Mb', isbits=True)) == '921.60 Kbits'
    assert bytes_to_human(human_to_bytes('1Kb', isbits=True)) == '921.60 b'
    assert bytes_to_human(human_to_bytes('1b', isbits=True)) == '921.60 bits'
    assert bytes_to_human(human_to_bytes('1Mb')) == '921.60 KBytes'
    assert bytes_to_human(human_to_bytes('1Kb')) == '921.60 Bytes'
    assert bytes_to_human(human_to_bytes('1b')) == '921.60 Bytes'

# Generated at 2022-06-24 21:07:45.715274
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', u'B', 1, 2]) == ['a', u'B', 1, 2]


# Generated at 2022-06-24 21:07:48.928630
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 2, 'C']) == ['a', 2, 'c']


# Generated at 2022-06-24 21:07:52.215966
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['A', '1', '23Ab']
    test_expected_list = ['a', '1', '23Ab']
    test_list_lower = lenient_lowercase(test_list)

    assert test_list_lower == test_expected_list



# Generated at 2022-06-24 21:08:04.867843
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst_0 = ['1', 'sn', 'xH']
    assert lenient_lowercase(lst_0) == ['1', 'sn', 'xh']
    lst_1 = [0, '-', 2]
    assert lenient_lowercase(lst_1) == [0, '-', 2]
    lst_2 = ['D', 'f', '9y']
    assert lenient_lowercase(lst_2) == ['d', 'f', '9y']
    lst_3 = ['F', '6', 'Oq']
    assert lenient_lowercase(lst_3) == ['f', '6', 'oq']
    lst_4 = ['R', '7', 'zZ']

# Generated at 2022-06-24 21:08:13.847695
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_param_0 = [
        {'expected_result': ['a', 'b', 'c'], 'test_input': ['a', 'B', 'C']},
        {'expected_result': [1, 'b', 'c'], 'test_input': [1, 'B', 'C']},
        {'expected_result': [1, 'b', 'c'], 'test_input': [1, 'b', 'c']},
        {'expected_result': [1, 'b', 3], 'test_input': [1, 'b', 3]},
        {'expected_result': [1, 'b', 'c'], 'test_input': [1, 'b', 'c']},
    ]

# Generated at 2022-06-24 21:08:23.855166
# Unit test for function human_to_bytes
def test_human_to_bytes():
    str_0_1 = 'v232030'
    str_1_1 = '@n}Q'
    str_2_1 = 'b'
    str_3_1 = 'i' 
    str_4_1 = '9'

    str_0_2 = '(v0'
    str_1_2 = '}`8h2'
    str_2_2 = '&'
    str_3_2 = 'e'
    str_4_2 = 'i'

    str_0_3 = 'Y'
    str_1_3 = 'C'
    str_2_3 = 'y'
    str_3_3 = 'Y'
    str_4_3 = '`'

    str_0_4 = str_0_1 + str_0_2 + str_0

# Generated at 2022-06-24 21:08:34.913510
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.1M') == 11534336
    assert human_to_bytes(11534336) == 11534336
    assert human_to_bytes('1.1') == 1
    assert human_to_bytes('1.1.1') == 0
    assert human_to_bytes('11') == 11

    assert human_to_bytes('1.1M', isbits=True) == 10485760
    assert human_to_bytes('1.1Kb', isbits=True) == 11264
    assert human_to_bytes('1Kb', isbits=True, default_unit='k') == 1024
    assert human_to_bytes('11', isbits=True) == 0
    assert human_to_bytes('1.1', isbits=True) == 0

# Generated at 2022-06-24 21:08:37.167806
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        assert(test_case_0())
    except AssertionError as e:
        print(e)
        print("TEST FAILED.")
        return
    print("TEST PASSED.")


test_human_to_bytes()

# Generated at 2022-06-24 21:08:40.658105
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(str_0) == 2097152
    try:
        assert str_0 == str_1
    except Exception:
        print(str_0)
        print(str_1)

# Generated at 2022-06-24 21:08:49.770597
# Unit test for function lenient_lowercase

# Generated at 2022-06-24 21:08:54.536666
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['hello', 'world']) == ['hello', 'world']
    assert lenient_lowercase([0x1f4a9, 0x1f4a9]) == [0x1f4a9, 0x1f4a9]



# Generated at 2022-06-24 21:09:05.692168
# Unit test for function human_to_bytes

# Generated at 2022-06-24 21:09:07.434038
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', [1, 2, 3], 'B']) == ['a', [1, 2, 3], 'b']


# Generated at 2022-06-24 21:09:21.630341
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2KB') == 2048
    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('2MB') == 2097152
    assert human_to_bytes('2G') == 2147483648
    assert human_to_bytes('2GB') == 2147483648
    assert human_to_bytes('2T') == 2199023255552
    assert human_to_bytes('2TB') == 2199023255552
    assert human_to_bytes('2P') == 2251799813685248
    assert human_to_bytes('2PB') == 2251799813685248
    assert human_to_bytes('2E') == 2305843009213693952
    assert human_to

# Generated at 2022-06-24 21:09:26.745349
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C', 'D']) == ['a', 'b', 'c', 'd']
    # Test case where mixed casing used
    assert lenient_lowercase(['A', 3, 'C', 4]) == ['a', 3, 'c', 4]


# Generated at 2022-06-24 21:09:35.717939
# Unit test for function human_to_bytes
def test_human_to_bytes():
  # Invalid input
  assertEqual("TypeError", human_to_bytes(10))
  # Invalid input - negative number
  assertEqual("ValueError", human_to_bytes("-10MB"))
  # Invalid input - float number
  assertEqual("ValueError", human_to_bytes("10.0MB"))
  # Raise value error if unit is not 'B' or 'b'
  assertEqual("ValueError", human_to_bytes("10M"))

# Run unittests
if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-24 21:09:46.712762
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048, "bytes_to_human('2K') failed"
    assert human_to_bytes('0MB') == 0, "bytes_to_human('0MB') failed"
    assert human_to_bytes('1MB') == 1048576, "bytes_to_human('1MB') failed"
    assert human_to_bytes('1MB', default_unit='mb') == 1048576, "bytes_to_human('1MB', default_unit='mb') failed"
    assert human_to_bytes('1MB', default_unit='Mb') == 1048576, "bytes_to_human('1MB', default_unit='Mb') failed"

# Generated at 2022-06-24 21:09:48.978072
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Input parameters
    lst = ['AbC', 1, None]
    assert lenient_lowercase(lst) == ['abc', 1, None]


test_case_0()

# Generated at 2022-06-24 21:09:54.283091
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'B', 'c']
    assert lenient_lowercase(['a', 'B', 3]) == ['a', 'B', 3]
    assert lenient_lowercase(['a', 'B', 'c']) != ['a', 'b', 'c']


# Generated at 2022-06-24 21:10:00.933312
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    data = [1, "a", "A", "b", "B", "c"]
    expected_result = [1, "a", "a", "b", "b", "c"]

    assert lenient_lowercase(data) == expected_result

# Generated at 2022-06-24 21:10:11.863566
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert lenient_lowercase(['1KB']) == ['1kb']
    assert lenient_lowercase(['1MB']) == ['1mb']
    assert lenient_lowercase(['1GB']) == ['1gb']
    assert lenient_lowercase(['1TB']) == ['1tb']
    assert lenient_lowercase(['1PB']) == ['1pb']
    assert lenient_lowercase(['1EB']) == ['1eb']
    assert lenient_lowercase(['1ZB']) == ['1zb']
    assert lenient_lowercase(['1YB']) == ['1yb']

    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1GB') == 107

# Generated at 2022-06-24 21:10:15.255300
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([None, 'MiB', 'KB']) == [None, 'mib', 'kb']
    assert lenient_lowercase([True, 'MiB', 'KB']) == [True, 'mib', 'kb']
    assert lenient_lowercase([42, 'MiB', 'KB']) == [42, 'mib', 'kb']



# Generated at 2022-06-24 21:10:17.301950
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 'a', 'B', [], {}]) == [1, 'a', 'B', [], {}]


# Generated at 2022-06-24 21:10:34.450315
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1mb') == 1000000
    assert human_to_bytes('1mb', isbits=True) == 1048576
    assert human_to_bytes('1Mb', default_unit='b') == 1048576
    assert human_to_bytes('2B') == 2
    assert human_to_bytes('2b') == 2
    assert human_to_bytes('2b', isbits=True) == 2
    assert human_to_bytes('2') == 2
    assert human_to_bytes('2', default_unit='B') == 2
    assert human_to_

# Generated at 2022-06-24 21:10:45.256630
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 'D', 2]) == ['a', 'B', 'c', 'D', 2]
    assert lenient_lowercase([2, 'B', 'c', 'd', 2]) == [2, 'B', 'c', 'd', 2]



# Generated at 2022-06-24 21:10:51.641025
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # check function returns a list
    assert isinstance(lenient_lowercase(["apple", "Banana"]), list)
    # check function actually lowercases elements
    assert lenient_lowercase(["apple", "Banana"]) == ['apple', 'banana']
    # check function doesn't lowercase non-strings
    assert lenient_lowercase(["apple", 1]) == ["apple", 1]



# Generated at 2022-06-24 21:10:55.620194
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_case_0()



# Generated at 2022-06-24 21:10:57.474117
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['FOO', 'bar', 2]) == ['foo', 'bar', 2]


# Generated at 2022-06-24 21:11:02.778532
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase(['a', 'B', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase([['a', 'B', 'c'], 'd']) == [['a', 'b', 'c'], 'd']


# Generated at 2022-06-24 21:11:14.397398
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M'), 'Base case, the result should be 10485760.'
    assert human_to_bytes('10MB') == human_to_bytes(10, 'MB'), 'Should also work if a unit is provided as a suffix.'
    assert human_to_bytes(10, 'MB') == human_to_bytes(10, 'M', 'B'), 'Should also work if a default unit is specified.'
    assert human_to_bytes(10, 'Mb', True) == 10485760, 'If the provided unit is in bits, the result should be in bits.'
    assert human_to_bytes(10, 'M', 'b', True) == 10485760, 'If the provided unit is in bits, the result should be in bits.'
    assert human_to

# Generated at 2022-06-24 21:11:22.417311
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['aa','Bb','cc','DD','ee','FF','GG','HH','ii','JJ','kk','LL','mm','NN','oo','PP','qq','RR','ss','TT','uu']) == ['aa','Bb','cc','DD','ee','FF','GG','HH','ii','JJ','kk','LL','mm','NN','oo','PP','qq','RR','ss','TT','uu']


# Generated at 2022-06-24 21:11:32.875173
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # check default behaviour
    var_0 = 'cM'
    var_1 = human_to_bytes(var_0)
    assert var_1 == 1 * 1048576

    # check default behaviour
    var_0 = '30'
    var_1 = human_to_bytes(var_0)
    assert var_1 == 30

    # check default behaviour
    var_0 = '5M'
    var_1 = human_to_bytes(var_0)
    assert var_1 == 5 * 1048576

    # check exception for invalid input
    var_0 = 'Kb'
    try:
        var_1 = human_to_bytes(var_0)
    except Exception as e:
        e_type = str(type(e))
    else:
        assert False

    # check default behaviour
   

# Generated at 2022-06-24 21:11:41.587454
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['b', 'B', 'c', 'C', 'D']) == ['b', 'B', 'c', 'C', 'D']
    assert lenient_lowercase(['B', 'b', 'C', 'c', 'D']) == ['B', 'b', 'C', 'c', 'D']
    assert lenient_lowercase(['b', 'C', 'D', 'a']) == ['b', 'C', 'D', 'a']
    assert lenient_lowercase(['A', 'C', 'D']) == ['A', 'C', 'D']
    assert lenient_lowercase(['B', 'a', 'C', 'D']) == ['B', 'a', 'C', 'D']

# Generated at 2022-06-24 21:11:57.608600
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('lh4]\x0c2M[z') == 18228804230
    assert human_to_bytes('lh4]\x0c2M[z', 'b') == 18228804230
    assert human_to_bytes('lh4]\x0c2M[z', 'b', True) == 14583043384
    assert human_to_bytes('z\x8c\x92\x89N\x81') == 582
    assert human_to_bytes('z\x8c\x92\x89N\x81', 'b') == 582
    assert human_to_bytes('z\x8c\x92\x89N\x81', 'b', True) == 466

# Generated at 2022-06-24 21:11:58.427126
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_case_0()



# Generated at 2022-06-24 21:12:01.553796
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """
    Unit test function human_to_bytes
    """
    str_0 = 'lh4]\x0c2M[z'
    var_0 = human_to_bytes(str_0)


# Generated at 2022-06-24 21:12:06.898713
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['aB', 'C', 3]) == ['ab', 'C', 3]


# Generated at 2022-06-24 21:12:08.480554
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('4G') == 4294967296


# Generated at 2022-06-24 21:12:15.726492
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        str_0 = "1M"
        var_0 = human_to_bytes(str_0)
        assert type(var_0) == int
        assert var_0 == 1048576
    except AssertionError:
        raise AssertionError("test_human_to_bytes failed")



# Generated at 2022-06-24 21:12:25.734276
# Unit test for function human_to_bytes
def test_human_to_bytes():
    str_0 = 'lh4]\x0c2M[z'
    str_unit_0 = 'M'
    assert human_to_bytes(str_0,str_unit_0) == 10000000, "test_human_to_bytes:test_0"

    str_1 = 'p\x00.'
    str_unit_1 = 'G'
    assert human_to_bytes(str_1,str_unit_1) == 1000000000, "test_human_to_bytes:test_1"


# Generated at 2022-06-24 21:12:29.745665
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['abc', 'ABC', '123']) == ['abc', 'abc', '123']
    assert lenient_lowercase(['abc', 1, 'ABC', '123']) == ['abc', 1, 'abc', '123']


# Generated at 2022-06-24 21:12:31.435489
# Unit test for function human_to_bytes
def test_human_to_bytes():
    unit_test_0(test_case_0)



# Generated at 2022-06-24 21:12:33.729661
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['foo', 1]) == ['foo', 1]


# Generated at 2022-06-24 21:12:53.866162
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test with integer input
    assert human_to_bytes(10) == 10, "expected 10"
    # Test with alphanumeric input
    str_0 = 'ABC'
    var_0 = human_to_bytes(str_0)
    assert var_0 == ord('A') * SIZE_RANGES['B'] + ord('B') * SIZE_RANGES['B'] + ord('C') * SIZE_RANGES['B'], \
        "expected " + str(ord('A') * SIZE_RANGES['B'] + ord('B') * SIZE_RANGES['B'] + ord('C') * SIZE_RANGES['B'])
    # Test with float input
    str_1 = '4.2'
    var_1 = human_to_bytes(str_1)


# Generated at 2022-06-24 21:12:56.363342
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['foo', 2, 'BaR']) == ['foo', 2, 'bar']



# Generated at 2022-06-24 21:13:06.043658
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1') == 1)
    assert(human_to_bytes('1K') == 1024)
    assert(human_to_bytes('1KB') == 1024)
    assert(human_to_bytes('1M') == 1048576)
    assert(human_to_bytes('1MB') == 1048576)
    assert(human_to_bytes('1G') == 1073741824)
    assert(human_to_bytes('1GB') == 1073741824)
    assert(human_to_bytes('1T') == 1099511627776)
    assert(human_to_bytes('1TB') == 1099511627776)
    assert(human_to_bytes('1P') == 1125899906842624)

# Generated at 2022-06-24 21:13:09.319165
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['abc', 'def']) == ['abc', 'def']
    assert lenient_lowercase(['abc', 1, 'def']) == ['abc', 1, 'def']


# Generated at 2022-06-24 21:13:14.668934
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lower_list = lenient_lowercase(['hello', 'Hello', 'HeLLo', 1, 2, 3])
    assert lower_list == ['hello', 'hello', 'hello', 1, 2, 3]

# Generated at 2022-06-24 21:13:16.589120
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Last line of unittest.py
    assert True

# Generated at 2022-06-24 21:13:17.436470
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_case_0()



# Generated at 2022-06-24 21:13:20.850060
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert 'bcd' == lenient_lowercase('BCD')
    assert 'efg' == lenient_lowercase('EFG')
    assert ['abc', 123, 45] == lenient_lowercase(['ABC', 123, 45])


# Generated at 2022-06-24 21:13:22.432252
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["A", u"A", 1234]) == ["a", "a", 1234]


# Generated at 2022-06-24 21:13:28.811806
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test when input is a list of strings
    test_list_str = ['a', 'b', 'c', 'd']
    assert lenient_lowercase(test_list_str) == ['a', 'b', 'c', 'd']

    # Test when input is a list containing "None"
    test_list_with_none = ['a', None, 'c', 'd']
    assert lenient_lowercase(test_list_with_none) == ['a', None, 'c', 'd']

    # Test when input is a list containing integers
    test_list_with_int = ['a', 1, 'c', 'd']
    assert lenient_lowercase(test_list_with_int) == ['a', 1, 'c', 'd']



# Generated at 2022-06-24 21:13:39.454329
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Input parameters
    float_0 = 0.001
    # Output parameters
    var_0 = lenient_lowercase(float_0)

    # Check results
    assert var_0 == 0.001



# Generated at 2022-06-24 21:13:47.079686
# Unit test for function human_to_bytes
def test_human_to_bytes():
    string_1 = '1b'
    assert human_to_bytes(string_1, isbits=True) == 1, "Expected '1'"

    string_2 = '1'
    assert human_to_bytes(string_2) == 1, "Expected '1'"

    string_3 = '1B'
    assert human_to_bytes(string_3) == 1, "Expected '1'"

    string_4 = '1KB'
    assert human_to_bytes(string_4) == 1024, "Expected '1024'"

    string_5 = '1Kb'
    assert human_to_bytes(string_5, isbits=True) == 1024, "Expected '1024'"

    string_6 = '1Mb'

# Generated at 2022-06-24 21:13:50.113776
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # TODO: refactor this test using mock module
    # set up test fixtures
    float_0 = 0.001
    # perform test steps
    var_0 = lenient_lowercase(float_0)
    # check test results
    assert var_0 is not None


# Generated at 2022-06-24 21:13:53.222767
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(0.001) == 0.001


# Generated at 2022-06-24 21:13:55.660049
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(0.001) == [float_0]
    assert lenient_lowercase(4) == [4]
    assert lenient_lowercase('FOUR') == ['four']


# Generated at 2022-06-24 21:14:02.688447
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        assert(bytes_to_human(human_to_bytes('10M')) == '10.00 MBytes')
        assert(bytes_to_human(human_to_bytes('10M', default_unit='b')) == '10.00 Mbits')
        assert(bytes_to_human(human_to_bytes('10M', isbits=True)) == '10.00 Mbits')
        assert(bytes_to_human(human_to_bytes('10Mb', isbits=True)) == '10.00 Mbits')
    except Exception:
        assert False
    # checking 1B and 1b being handled correctly
    try:
        assert(bytes_to_human(human_to_bytes('1B') == '1.00 Bytes'))
    except Exception:
        assert False

# Generated at 2022-06-24 21:14:12.172464
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('5.5', default_unit='B') == 5)
    assert(human_to_bytes('5.5B') == 5)
    assert(human_to_bytes('5.5B') == 5)
    assert(human_to_bytes('5.5B') == 5)
    assert(human_to_bytes('5.5B') == 5)
    assert(human_to_bytes('5.5B') == 5)
    assert(human_to_bytes(5.5) == 5)
    assert(human_to_bytes(5.5, default_unit='B') == 5)
    assert(human_to_bytes('5.5B') == 5)
    assert(human_to_bytes('5.5B') == 5)

# Generated at 2022-06-24 21:14:17.352242
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    float_0 = 0.001
    assert isinstance(lenient_lowercase(float_0), float)



# Generated at 2022-06-24 21:14:18.410843
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    float_0 = 0.001
    var_0 = lenient_lowercase(float_0)


# Generated at 2022-06-24 21:14:27.959291
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # unit test for lenient lowercase function
    float_0 = 0.001
    var_0 = lenient_lowercase(float_0)
    if var_0 != float_0:
        raise Exception('failed to lowercase a float')

    str_0 = '1MB'
    var_0 = lenient_lowercase(str_0)
    if var_0 != '1mb':
        raise Exception('failed to lowercase a string')

    none_0 = None
    var_0 = lenient_lowercase(none_0)
    if var_0 is not None:
        raise Exception('failed to lowercase with None.')

    int_0 = 100
    var_0 = lenient_lowercase(int_0)
    if var_0 != 100:
        raise Exception('failed to lowercase a integer')




# Generated at 2022-06-24 21:14:44.236442
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # Simple string (expected result: float)
    float_0 = float()
    float_0 = human_to_bytes("0.01")
    assert var_0 == var_0

    # can't interpret following number: 0.01 (original input string: 0.01)
    float_1 = float()
    float_1 = human_to_bytes("0.01")
    assert var_1 == var_1

    # human_to_bytes() failed to convert 0.01 (unit = MB)
    float_2 = float()
    float_2 = human_to_bytes("0.01", "MB")
    assert var_2 == var_2



# Generated at 2022-06-24 21:14:52.094269
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Base case
    result_0 = human_to_bytes('10M')
    assert(result_0 == 10485760)

    # Using 'isbits' argument
    result_1 = human_to_bytes('10M', isbits=True)
    assert(result_1 == 10485760)

    # Base case
    result_2 = human_to_bytes('10')
    assert(result_2 == 10)

    # Using 'default_unit' argument
    result_3 = human_to_bytes('10', default_unit='M')
    assert(result_3 == 10485760)

    # Using 'isbits' argument
    result_4 = human_to_bytes('10', default_unit='M', isbits=True)
    assert(result_4 == 10485760)


# Generated at 2022-06-24 21:14:55.599940
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    float_0 = 0.001
    var_0 = lenient_lowercase(float_0)
    try:
        assert var_0 == float_0
    except AssertionError as e:
        raise(e)


# Generated at 2022-06-24 21:15:02.846247
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_values = [
        (1, None, False, 1),
        (0.001, None, False, 1),
        (1, 'B', False, 1),
        (0.001, 'B', False, 1),
        (1, 'b', True, 1),
        (0.001, 'b', True, 1),
    ]

    for test in test_values:
        num, unit, isbits, expected = test
        result = human_to_bytes(num, unit, isbits)
        assert result == expected, "Expected {} but got {}".format(expected, result)


# Generated at 2022-06-24 21:15:06.044473
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    float_0 = 0.001
    var_0 = lenient_lowercase(float_0)
    print(var_0)
    assert var_0 == float_0



# Generated at 2022-06-24 21:15:07.700483
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    string = "TEST"
    result = lenient_lowercase(string)
    assert result == "test"


# Generated at 2022-06-24 21:15:15.214793
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2000') == 2000  # test for raw integer
    assert human_to_bytes('2K') == 2048  # test for 2K
    assert human_to_bytes('2Kb') == 2048  # test for 2Kb
    assert human_to_bytes('2K', isbits=True) == 2048  # test for 2K
    assert human_to_bytes(2000) == 2000  # test for raw integer
    assert human_to_bytes(2000, isbits=True) == 2000  # test for raw integer
    assert human_to_bytes('2.5K') == 2560  # test for 2.5K
    assert human_to_bytes('2.5M') == 26214400  # test for 2.5M
    assert human_to_bytes('2Mb') == 2097152  # test

# Generated at 2022-06-24 21:15:24.775012
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("20") == 20
    assert human_to_bytes("20b") == 20
    assert human_to_bytes("20B") == 20
    assert human_to_bytes("20Bb") == 20
    assert human_to_bytes("20BB") == 20
    assert human_to_bytes("20kB") == 20 * 1000
    assert human_to_bytes("20kBb") == 20 * 1000
    assert human_to_bytes("20MB") == 20 * 1000 * 1000
    assert human_to_bytes("20bMb") == 20 * 1000 * 1000
    assert human_to_bytes("20MBb") == 20 * 1000 * 1000
    assert human_to_bytes("20MBB") == 20 * 1000 * 1000
    assert human_to_bytes("20MbBb") == 20 * 1000 * 1000

# Generated at 2022-06-24 21:15:30.971669
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('100') == 100
    assert human_to_bytes('100b') == 100
    assert human_to_bytes('100B') == 100
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1KB', default_unit='MB') == 1024
    assert human_to_bytes('1.5Kb') == 1536
    assert human_to_bytes('1.5KB') == 1536
    assert human_to_bytes('1.5KB', default_unit='MB') == 1536
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to

# Generated at 2022-06-24 21:15:40.599705
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('100B') == 100
    assert human_to_bytes('100bytes') == 100
    assert human_to_bytes('100byte') == 100
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1KB', isbits=True) == 8192
    assert human_to_bytes('1Mb', isbits=True) == 8388608
    assert human_to_bytes('1KB', default_unit='B') == 1024
    assert human_to_bytes('1', default_unit='B') == 1
    assert human_to_bytes('100', default_unit='M') == 100 * 1024 * 1024
    assert human_to

# Generated at 2022-06-24 21:16:03.052736
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048, 'AssertionError: 2K != 2048'
    assert human_to_bytes('2KB') == 2048, 'AssertionError: 2KB != 2048'
    assert human_to_bytes('-2K') == -2048, 'AssertionError: -2K != -2048'
    assert human_to_bytes('2.0K') == 2048, 'AssertionError: 2.0K != 2048'
    assert human_to_bytes('2') == 2, 'AssertionError: 2 != 2'
    assert human_to_bytes(2) == 2, 'AssertionError: 2 != 2'
    assert human_to_bytes('-2') == -2, 'AssertionError: -2 != -2'

# Generated at 2022-06-24 21:16:04.500923
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        test_case_0()
        assert True
    except Exception:
        assert False


# Generated at 2022-06-24 21:16:10.257817
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        assert(human_to_bytes("1") == 1)
        assert(human_to_bytes("1b") == 1)
        assert(human_to_bytes("1B") == 1)
    except AssertionError:
        print("AssertionError: Failed test_human_to_bytes")


# Generated at 2022-06-24 21:16:19.153359
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    cases = [
        0.001,
        'ansible',
        'ANSIBLE',
        'AnSiBlE'
    ]

    float_0 = cases[0]
    str_1 = cases[1]
    str_2 = cases[2]
    str_3 = cases[3]

    var_0 = lenient_lowercase(float_0)
    var_1 = lenient_lowercase(str_1)
    var_2 = lenient_lowercase(str_2)
    var_3 = lenient_lowercase(str_3)

    assert var_0 == 0.001
    assert var_1 == 'ansible'
    assert var_2 == 'ansible'
    assert var_3 == 'ansible'


# Generated at 2022-06-24 21:16:21.380313
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024


# Generated at 2022-06-24 21:16:26.413840
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        test_bytes = human_to_bytes('1.2M')
        assert test_bytes == 1258291, "Wrong number of bytes returned for human_to_bytes('1.2M')"
    except ValueError:
        raise AssertionError("Extended test not passed.")

# Generated at 2022-06-24 21:16:34.019663
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    float_0 = 0.001
    assert lenient_lowercase(float_0) == [0.001]
    assert lenient_lowercase("") == ['']
    assert lenient_lowercase('ac') == ['ac']
    assert lenient_lowercase('Ab') == ['ab']
    assert lenient_lowercase('A') == ['a']
    assert lenient_lowercase('A ') == ['a ']
    assert lenient_lowercase('B') == ['b']



# Generated at 2022-06-24 21:16:44.997082
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('0.0001') == 0
    assert human_to_bytes('10.5M') == 11010048
    assert human_to_bytes('1.2Kb') == 122
    assert human_to_bytes('1.2Kb', isbits=True) == 122
    assert human_to_bytes('1.2Kb', isbits=False) == 122880
    assert human_to_bytes('10M', isbits=False) == 10485760
    assert human_to_bytes('.1MB') == 104857.6
    assert human_to_bytes('.1MBb') == 10485760.0
    assert human_to_bytes('.1Mbb') == 10485760.0
    assert human_to_bytes('.1Mb', isbits=True) == 10