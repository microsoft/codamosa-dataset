

# Generated at 2022-06-24 21:06:59.854355
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    r = [1, 'A', 'B', 'C', ['D', 'E', 'F'], 'G', 'H', ['I', 'J', 'K'], 'L', 'M', 'N', 'O', 'P']
    assert lenient_lowercase(r) == [1, 'a', 'b', 'c', ['d', 'e', 'f'], 'g', 'h', ['i', 'j', 'k'], 'l', 'm', 'n', 'o', 'p']



# Generated at 2022-06-24 21:07:07.280459
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2M', 'B') == 2097152
    assert human_to_bytes('2M', 'B') == 2097152
    assert human_to_bytes('2M', 'B') == 2097152
    assert human_to_bytes('2M', 'B') == 2097152
    assert human_to_bytes('2M', 'B') == 2097152

# Generated at 2022-06-24 21:07:13.354761
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_vals = [
        "TEST",
        3,
        1.2345,
        None,
        [],
        "TEST",
        "test",
    ]

    ret = lenient_lowercase(test_vals)

    assert ret == "test"



# Generated at 2022-06-24 21:07:21.624211
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes(1024) == 1024

    assert human_to_bytes('2k') == 2048
    assert human_to_bytes(2, 'k') == 2048

    assert human_to_bytes('1024B') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1M') == 1048576

    assert human_to_bytes('1MBb') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576

    assert human_to_bytes('1mb') == 1048576
    assert human_to_bytes('1mb', isbits=False) == 1048576

    assert human_to_bytes('1MBb') == 1048576
    assert human_

# Generated at 2022-06-24 21:07:32.034206
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1 Mb') == 1048576
    assert human_to_bytes('1 M') == 1048576
    assert human_to_bytes('10 Mb') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10mb', isbits=True) == 10485760
    assert human_to_bytes('10000mb', isbits=True) == 1048576000
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('1M') == 1048576
    assert human

# Generated at 2022-06-24 21:07:42.663450
# Unit test for function human_to_bytes
def test_human_to_bytes():
    bool_0 = True
    assert human_to_bytes(bool_0) == 1
    var_1 = '1MB'
    assert human_to_bytes(var_1) == 1048576
    var_2 = '1.5MB'
    assert human_to_bytes(var_2) == 1572864
    var_3 = '1.5Mb'
    assert human_to_bytes(var_3, isbits=True) == 1572864
    var_4 = '1Mb'
    assert human_to_bytes(var_4, isbits=True) == 1048576
    var_5 = '1.5Mb'
    assert human_to_bytes(var_5, isbits=False) == 1572864
    var_6 = '1.5M'
    assert human_to_

# Generated at 2022-06-24 21:07:50.379911
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_str_0 = '2K'
    bytes_0 = human_to_bytes(test_str_0)
    assert bytes_0 == 2048
    test_str_1 = '10M'
    bytes_1 = human_to_bytes(bytes=test_str_1)
    assert bytes_1 == 10485760
    test_str_2 = '10b'
    bytes_2 = human_to_bytes(test_str_2)
    assert bytes_2 == 10
    test_str_3 = '10B'
    bytes_3 = human_to_bytes(test_str_3)
    assert bytes_3 == 10
    test_str_4 = '10bits'
    bytes_4 = human_to_bytes(test_str_4)
    assert bytes_4 == 10
    test_str

# Generated at 2022-06-24 21:07:58.277264
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1024) == 1024
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1 K') == 1024
    assert human_to_bytes('1 KB') == 1024
    assert human_to_bytes('1 KB', unit='KB') == 1024
    assert human_to_bytes('1 MB') == 1024 ** 2
    assert human_to_bytes('1 MB', unit='KB') == 1024 ** 2
    assert human_to_bytes('1 Mb', unit='b', isbits=True) == 1024 ** 2
    assert human_to_bytes('1 Mb', isbits=True) == 1024 ** 2
    assert human_to_bytes('1 Mb', isbits=False) == 1024
    assert human_to_bytes('1 Mb', unit='B', isbits=False) == 1024
    assert human

# Generated at 2022-06-24 21:08:07.879179
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test body
    assert human_to_bytes('2K', default_unit='B') == 2048
    assert human_to_bytes('2B') == 2
    assert human_to_bytes('3b', isbits=True) == 0.375
    assert human_to_bytes('3G', isbits=True) == 34359738368
    assert human_to_bytes('2B', isbits=True) == 16
    assert human_to_bytes('1M', default_unit='K') == 1024
    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1Kb') == 128
    assert human_to_bytes('1kb') == 128
    assert human_to_bytes('2Mb') == 2097152
    assert human_to_bytes('2MB')

# Generated at 2022-06-24 21:08:14.380497
# Unit test for function human_to_bytes
def test_human_to_bytes():
    success = True
    fail = False
    result = human_to_bytes('10G')
    if result != 10737418240:
        success = fail
    result = human_to_bytes('10M')
    if result != 10485760:
        success = fail
    result = human_to_bytes('10K')
    if result != 10240:
        success = fail
    result = human_to_bytes('1Mb')
    if result != 8388608:
        success = fail
    if success is True:
        print('passed')
    else:
        print('FAILED')



# Generated at 2022-06-24 21:08:26.558563
# Unit test for function human_to_bytes

# Generated at 2022-06-24 21:08:29.608580
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = human_to_bytes('1.5M')
    assert result == 1572864

# Generated at 2022-06-24 21:08:33.891783
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 1, 'C']) == ['a', 1, 'c']
    assert lenient_lowercase(['A', 'B', 'C', None]) == ['a', 'b', 'c', None]


# Generated at 2022-06-24 21:08:37.372212
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b']) == ['a', 'b']
    assert lenient_lowercase([1, 'b']) == [1, 'b']
    assert lenient_lowercase(['A', 'B']) == ['a', 'b']
    assert lenient_lowercase([1, 'B']) == [1, 'b']



# Generated at 2022-06-24 21:08:47.106466
# Unit test for function human_to_bytes
def test_human_to_bytes():
    input_0 = "1B"
    input_1 = 1
    expected_result = 1
    actual_result = human_to_bytes(input_0, input_1)
    assert(expected_result == actual_result)

    input_0 = "1k"
    input_1 = None
    expected_result = 1024
    actual_result = human_to_bytes(input_0, input_1)
    assert(expected_result == actual_result)

    input_0 = "1mb"
    input_1 = None
    expected_result = 1048576
    actual_result = human_to_bytes(input_0, input_1, True)
    assert(expected_result == actual_result)

    input_0 = "1Mb"
    input_1 = None

# Generated at 2022-06-24 21:08:56.358017
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A']) == ['a']
    assert lenient_lowercase(['a']) == ['a']
    assert lenient_lowercase(['A', 'B']) == ['a', 'b']
    assert lenient_lowercase(['a', 'b']) == ['a', 'b']
    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase([1, 'A', 3]) == [1, 'A', 3]
    assert lenient_lowercase([1, 'a', 3]) == [1, 'a', 3]



# Generated at 2022-06-24 21:09:00.195006
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    str_0 = 'string'
    obj_0 = lenient_lowercase(str_0)


# Generated at 2022-06-24 21:09:06.890622
# Unit test for function human_to_bytes
def test_human_to_bytes():

    number_0 = '2K'
    number_1 = '10M'
    number_2 = '1MB'
    default_unit_0 = 'M'
    default_unit_1 = 'kb'
    isbits_0 = False
    isbits_1 = True

    try:
        human_to_bytes(number_0)
    except Exception:
        pass

    try:
        human_to_bytes(number_1)
    except Exception:
        pass

    try:
        human_to_bytes(number_2)
    except Exception:
        pass

    try:
        human_to_bytes(number_2, default_unit=default_unit_0)
    except Exception:
        pass


# Generated at 2022-06-24 21:09:17.515751
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = ['b', 'a', 'c']
    list_1 = ['A', 'b', 'C']
    list_2 = ['a', 1, 'c']
    list_3 = ['A', 1, 'C']
    list_4 = ['a', 'b', 'c']
    list_5 = ['A', 'b', 'C']
    list_6 = lenient_lowercase(list_0)
    list_7 = lenient_lowercase(list_1)
    list_8 = lenient_lowercase(list_2)
    list_9 = lenient_lowercase(list_3)
    list_10 = lenient_lowercase(list_4)
    list_11 = lenient_lowercase(list_5)
    var_0 = list_0
    var_1 = list

# Generated at 2022-06-24 21:09:20.434837
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760



# Generated at 2022-06-24 21:09:26.566273
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["A", 1, 2, 3]) == ["a", 1, 2, 3]



# Generated at 2022-06-24 21:09:37.917861
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    # check that lowercase has no effect on lowercased strings
    result = lenient_lowercase(['abc', 'def'])
    assert result == ['abc', 'def']
    # check that lowercase works on mixed case strings
    result = lenient_lowercase(['aBc', 'deF'])
    assert result == ['abc', 'def']
    # check that lowercase passes non-strings through untouched
    result = lenient_lowercase([1, 'aBc', 'deF'])
    assert result == [1, 'abc', 'def']
    # check that lowercase passes mixed non-strings through untouched
    result = lenient_lowercase([1, 'aBc', object()])
    assert result == [1, 'abc', object()]
    # check that lowercase works on no-strings
    result = len

# Generated at 2022-06-24 21:09:41.265374
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    # Test with some values
    values = [1, 'a', 'B', 'c', [5, 'D', 'e', 'f']]
    output = lenient_lowercase(values)
    assert output == [1, 'a', 'b', 'c', [5, 'd', 'e', 'f']]



# Generated at 2022-06-24 21:09:51.679513
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'MB') == 10485760
    assert human_to_bytes(10, 'm') == 10485760
    assert human_to_bytes(10, 'K') == 10240
    assert human_to_bytes(10, 'KB') == 10240
    assert human_to_bytes(10, 'kb') == 10240
    assert human_to_bytes(10, 'Kb') == 10240
    assert human_to_bytes(10, 'k') == 10240
    assert human_to_bytes(10, 'B') == 10
    assert human_to_bytes(10, 'b') == 10
    assert human_to_bytes(10) == 10

# Generated at 2022-06-24 21:09:52.973692
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase('Kbps')
    assert result == 'kbps'



# Generated at 2022-06-24 21:09:58.339075
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', default_unit='M') == 10485760
    assert human_to_bytes('10', default_unit='M') == 10
    assert human_to_bytes('2K', default_unit='M') == 2048
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2G') == 2147483648
    assert human_to_bytes('2B') == 2
    assert human_to_bytes('2Kb', isbits=True) == 2048
    assert human_to_bytes('2Mb', isbits=True) == 2097152
    assert human_to_bytes('2Gb', isbits=True) == 2147483648

# Generated at 2022-06-24 21:10:00.910980
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 123]) == ['a', 'b', 'c', 123]


# Generated at 2022-06-24 21:10:03.181169
# Unit test for function human_to_bytes
def test_human_to_bytes():
    in_unit = 'MB'
    in_isbit = False
    in_size = '1MB'
    out = 1048576
    assert human_to_bytes('1MB', in_unit, in_isbit) == out



# Generated at 2022-06-24 21:10:08.533381
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1024', 'B') == 1024
    assert human_to_bytes('2M', 'B') == 2097152



# Generated at 2022-06-24 21:10:15.709390
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(42) == 42
    assert human_to_bytes(42, 'B') == 42
    assert human_to_bytes(42, 'KB') == 42 * (1 << 10)
    assert human_to_bytes(42, 'Mb', True) == 42 * (1 << 10)
    assert human_to_bytes('42Mb', True) == 42 * (1 << 20)
    assert human_to_bytes(42.5, 'ZB') == 42.5 * (1 << 70)
    assert human_to_bytes('42.5ZB') == 42.5 * (1 << 70)
    assert human_to_bytes(42.5, 'YB') == 42 * (1 << 80)

# Generated at 2022-06-24 21:10:21.792742
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # This is a default test case. Create your own that you want to run.
    some_list = ['a', 'B', 'c', 'D']
    expected_result = ['a', 'b', 'c', 'd']
    assert(lenient_lowercase(some_list) == expected_result)



# Generated at 2022-06-24 21:10:30.529697
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('Testing function human_to_bytes')

    input_0 = '10B'
    expected_output_0 = 10
    actual_output_0 = human_to_bytes(input_0)
    assert actual_output_0 == expected_output_0

    input_1 = '10b'
    expected_output_1 = 10
    actual_output_1 = human_to_bytes(input_1, isbits=True)
    assert actual_output_1 == expected_output_1

    input_2 = '10k'
    expected_output_2 = 10240
    actual_output_2 = human_to_bytes(input_2)
    assert actual_output_2 == expected_output_2

    input_3 = '10Kb'
    expected_output_3 = 10240

# Generated at 2022-06-24 21:10:34.846277
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase([1, "FOO", "bar", [1, 2], {"a": 1, "b": 2}])
    assert result == [1, "foo", "bar", [1, 2], {"a": 1, "b": 2}]

# Generated at 2022-06-24 21:10:42.652291
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(0) == 0
    assert human_to_bytes('1 MB') == 1048576
    assert human_to_bytes('1 GB') == 1073741824
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1024 KB') == 1048576
    assert human_to_bytes('1024 KB', isbits=True) == 8388608
    assert human_to_bytes('1024 Mb', isbits=True) == 134217728



# Generated at 2022-06-24 21:10:52.060151
# Unit test for function human_to_bytes
def test_human_to_bytes():
    var_0 = human_to_bytes('0.05K')
    assert var_0 == 52
    var_1 = human_to_bytes('0.05M')
    assert var_1 == 52428
    var_2 = human_to_bytes('0.05G')
    assert var_2 == 52428800
    var_3 = human_to_bytes('0.05T')
    assert var_3 == 5497558138880
    var_4 = human_to_bytes('0.05P')
    assert var_4 == 576460752303423000
    var_5 = human_to_bytes('0.05E')
    assert var_5 == 5960464477539062500
    var_6 = human_to_bytes('0.05Z')
    assert var_6 == 6

# Generated at 2022-06-24 21:11:00.696910
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("Testing function human_to_bytes with examples")
    try:
        assert human_to_bytes('100') == 100
        assert human_to_bytes('100', default_unit='B') == 100

    except Exception:
        print("ERROR: human_to_bytes('100') raised unexpected exception")

    # if 'unit' is passed, 'name' and 'default_unit' are ignored
    try:
        assert human_to_bytes('1Mb', default_unit='B', isbits=True) == 1048576
        assert human_to_bytes('1M', default_unit='B') != 1048576
    except AssertionError:
        print("ERROR: human_to_bytes('1Mb', isbits=True) != 1048576")


# Generated at 2022-06-24 21:11:06.153863
# Unit test for function human_to_bytes
def test_human_to_bytes():
    with open('test_human_to_bytes.json') as json_file:
        data = json.load(json_file)
    for human_to_bytes_case in data['human_to_bytes_cases']:
        check_human_to_bytes(human_to_bytes_case)



# Generated at 2022-06-24 21:11:14.859103
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert len(SIZE_RANGES) == 8
    assert human_to_bytes('0') == 0
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1KB', isbits=True) == 8192
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('4K') == 4096
   

# Generated at 2022-06-24 21:11:23.567922
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    var_0 = [
        'a',
        'b',
        'c',
        1,
        2,
        3,
    ]
    var_1 = True
    var_2 = False
    var_3 = True
    var_4 = False
    var_5 = True
    var_6 = True
    var_7 = True

    array_0 = [
        'a',
        'b',
        'c',
        1,
        2,
        3,
    ]
    array_1 = True
    array_2 = False
    array_3 = True
    array_4 = False
    array_5 = True
    array_6 = True
    array_7 = True

    str_0 = 'false'



# Generated at 2022-06-24 21:11:32.955333
# Unit test for function human_to_bytes
def test_human_to_bytes():
    bool_0   = True
    bool_1   = False
    bool_2   = True
    bool_3   = False
    bool_4   = True
    bool_5   = False
    bool_6   = True
    bool_7   = False
    bool_8   = True
    bool_9   = False
    bool_10  = True
    bool_11  = False
    bool_12  = True
    bool_13  = False
    bool_14  = True
    bool_15  = False
    bool_16  = True
    bool_17  = False
    bool_18  = True
    bool_19  = False
    bool_20  = True
    bool_21  = False
    bool_22  = True
    bool_23  = False
    bool_24  = True

# Generated at 2022-06-24 21:11:40.823164
# Unit test for function human_to_bytes
def test_human_to_bytes():
    str_0 = 'B'
    int_0 = human_to_bytes(str_0, 'B')
    assert int_0 == 1


# Generated at 2022-06-24 21:11:43.838207
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['test', 'this', 'function']) == ['test', 'this', 'function']


# Generated at 2022-06-24 21:11:49.965930
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    if lenient_lowercase('foo') != ['foo']:
        raise AssertionError
    if lenient_lowercase(['fOo']) != ['foo']:
        raise AssertionError
    if lenient_lowercase(['fOo', 1]) != ['foo', 1]:
        raise AssertionError



# Generated at 2022-06-24 21:11:57.303662
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    print('Testing lenient_lowercase')
    test_list = [1, 'a', 2, 'b', 3, 'c', 4, 'd', 5, 'e']
    lower_list = lenient_lowercase(test_list)
    assert lower_list == test_list
    test_list = ['A', 'B', 'C', 'D', 1, 2, 3, 4, 5]
    lower_list = lenient_lowercase(test_list)
    expected_result = ['a', 'b', 'c', 'd', 1, 2, 3, 4, 5]
    assert lower_list == expected_result
    test_list = ['A', 'B', 'C', 'D', 1, 2, 3, 4, 5]
    lower_list = lenient_lowercase(test_list)
    expected_result

# Generated at 2022-06-24 21:11:58.495610
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'B', 'c', 'D']) == ['a', 'b', 'c', 'd']



# Generated at 2022-06-24 21:12:03.581063
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert (human_to_bytes('10m') == 10485760)
    assert (human_to_bytes('10M') == 10485760)
    assert (human_to_bytes('10MB') == 10485760)
    assert (human_to_bytes('10Mb') == 13107200)
    assert (human_to_bytes('10MB', isbits=True) == 13107200)



# Generated at 2022-06-24 21:12:10.623628
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("***Unit test for function human_to_bytes***")
    result = human_to_bytes('1M')
    print("Test case 1: result is 1M is", result)
    result = human_to_bytes('10.5M')
    print("Test case 2: result is 10.5M is", result)
    result = human_to_bytes('10.5B')
    print("Test case 3: result is 10.5B is", result)
    result = human_to_bytes('10.5Bb')
    print("Test case 4: result is 10.5Bb is", result)
    result = human_to_bytes('10.5bb')
    print("Test case 5: result is 10.5bb is", result)
    result = human_to_bytes('10.5Mb')

# Generated at 2022-06-24 21:12:16.078070
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert isinstance(human_to_bytes('10M'), int)
    assert isinstance(human_to_bytes(10, 'M'), int)
    assert isinstance(human_to_bytes(10, 'Mb', isbits=True), int)
    assert isinstance(human_to_bytes('10Mb', isbits=True), int)
    # assert isinstance(human_to_bytes('10', isbits=True), int)
    try:
        human_to_bytes('10ZB')
    except ValueError:
        assert True
    try:
        human_to_bytes('10Mb')
    except ValueError:
        assert True
    assert True

# Generated at 2022-06-24 21:12:26.187048
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1M', default_unit='M') == 1000000
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5M', default_unit='M') == 1500000
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5', default_unit='M') == 1500000
    assert human_to

# Generated at 2022-06-24 21:12:36.525955
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test case 1
    assert lenient_lowercase(['a', 'B', 'C', 2, 3]) == ['a', 'B', 'C', 2, 3]

    # Test case 2
    assert lenient_lowercase(['a', 'B', 'C', '2', '3']) == ['a', 'B', 'C', '2', '3']

    # Test case 3
    assert lenient_lowercase(['1', 'B', 'C', '2', '3']) == ['1', 'B', 'C', '2', '3']

    # Test case 4
    assert lenient_lowercase(['2', 3]) == ['2', 3]

    # Test case 5
    assert lenient_lowercase([3]) == [3]

    # Test case 6

# Generated at 2022-06-24 21:12:49.964833
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = 50
    var_0 = lenient_lowercase(int_0)
    assert (type(var_0) is int) or (type(var_0) is float), "Return value var_0 is not type int"
    assert var_0 == 50.0, "Return value var_0 is not 50.0"



# Generated at 2022-06-24 21:12:53.924828
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(int(50)) == int(50))


# Generated at 2022-06-24 21:12:59.662074
# Unit test for function human_to_bytes
def test_human_to_bytes():
    bytes_0 = human_to_bytes('10M')
    assert bytes_0 == 10485760, "human_to_bytes('10M')"
    bytes_1 = human_to_bytes('1K')
    assert bytes_1 == 1024, "human_to_bytes('1K')"
    bytes_2 = human_to_bytes('2E')
    assert bytes_2 == 2.916E+19, "human_to_bytes('2E')"

# Generated at 2022-06-24 21:13:09.008784
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("Testing function human_to_bytes with the following input:")
    print("input: number = bytes")
    print("input: default_unit = None")
    print("input: isbits = False")
    human_to_bytes("bytes", None, False)
    print("Test PASSED")

    print("Testing function human_to_bytes with the following input:")
    print("input: number = bits")
    print("input: default_unit = None")
    print("input: isbits = False")
    human_to_bytes("bits", None, False)
    print("Test PASSED")

    print("Testing function human_to_bytes with the following input:")
    print("input: number = bytes")
    print("input: default_unit = B")
    print("input: isbits = True")
    human_to_

# Generated at 2022-06-24 21:13:19.406106
# Unit test for function human_to_bytes

# Generated at 2022-06-24 21:13:28.732853
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1") == 1
    assert human_to_bytes("10") == 10
    assert human_to_bytes("1B") == 1
    assert human_to_bytes("1b") == 1
    assert human_to_bytes("1.5K") == 1536
    assert human_to_bytes("1.5KB") == 1536
    assert human_to_bytes("1.5Kb") == 1536
    assert human_to_bytes("1.5M") == 1572864
    assert human_to_bytes("1.5Mb") == 1572864
    assert human_to_bytes("1.5G") == 1610612736
    assert human_to_bytes("1.5T") == 17179869184
    assert human_to_bytes("1.5P") == 182536

# Generated at 2022-06-24 21:13:37.249618
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1000000') == 1000000
    assert human_to_bytes('1M') == 1000000
    assert human_to_bytes('1Mb', isbits=True) == 1000000
    assert human_to_bytes('1MB', isbits=True) == 1000000
    assert human_to_bytes('1Mb') == 125000
    assert human_to_bytes('1MB') == 125000
    assert human_to_bytes('1048576') == 1048576
    assert human_to_bytes('1048576b') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 131072
    assert human_to_bytes('1.1M') == 1100000

# Generated at 2022-06-24 21:13:43.589008
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1B', unit='b') == 1
    assert human_to_bytes('1b', unit='B') == 8
    assert human_to_bytes('1B', isbits=True) == 8
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1024B', unit='b') == 8192
    assert human_to_bytes('1024b', unit='B') == 131072
    assert human_to_bytes('1024b', unit='b') == 1024

    assert human_to_bytes('1Kb', isbits=True) == 1024
    assert human_to_bytes('1Kb', unit='B') == 131072

# Generated at 2022-06-24 21:13:45.045934
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_case_0()



# Generated at 2022-06-24 21:13:48.631819
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    int_0 = 50
    var_0 = lenient_lowercase(int_0)
    if var_0 != 50:
        print(var_0)
        print('Length not match')
        print('Test failure')
    else:
        print('Test successed')


# Generated at 2022-06-24 21:14:01.218416
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_case_0()



# Generated at 2022-06-24 21:14:08.813934
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = 50
    assert lenient_lowercase(int_0) == None
    int_1 = 50
    assert lenient_lowercase(int_1) == None
    int_2 = 50
    assert lenient_lowercase(int_2) == None
    str_0 = "50"
    assert lenient_lowercase(str_0) == "50"
    str_1 = "50"
    assert lenient_lowercase(str_1) == "50"



# Generated at 2022-06-24 21:14:10.348777
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """ 
    Call function lenient_lowercase with correct params
    """
    test_case_0()


# Generated at 2022-06-24 21:14:17.621222
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase('Test123'.lower()) == ['test123']
    assert lenient_lowercase('Test123Test123'.lower()) == ['test123test123']
    assert lenient_lowercase(['Test123']) == ['test123']
    assert lenient_lowercase(['Test123', 'Test456']) == ['test123', 'test456']
    assert lenient_lowercase(['Test123', 123456]) == ['test123', 123456]


# Generated at 2022-06-24 21:14:20.473210
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('123') == 123
    assert human_to_bytes('123MB') == 123 * 1024 * 1024
    assert human_to_bytes('123MB', 'B') == 123 * 1024 * 1024
    assert human_to_bytes('123MB', 'b') == 123 * 1024 * 1024 * 8
    assert human_to_bytes('123Mb', 'b', isbits=True) == 123 * 1024 * 1024 * 8

# Generated at 2022-06-24 21:14:29.174120
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    int_0 = 10
    list_1 = ['A', 'B', 'C']
    str_2 = 'abc'

    # test case 0
    if lenient_lowercase(int_0) == '10':
        print('Test case 0 is passed.')
    else:
        print('Test case 0 is failed.')

    # test case 1
    if lenient_lowercase(list_1) == ['a', 'b', 'c']:
        print('Test case 1 is passed.')
    else:
        print('Test case 1 is failed.')

    # test case 2
    if lenient_lowercase(str_2) == 'abc':
        print('Test case 2 is passed.')
    else:
        print('Test case 2 is failed.')


# Generated at 2022-06-24 21:14:33.171768
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_case_0()



# Generated at 2022-06-24 21:14:44.274133
# Unit test for function human_to_bytes

# Generated at 2022-06-24 21:14:50.067785
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(list(range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert lenient_lowercase(["a","b","C","d","e"]) == ["a","b","c","d","e"]
    assert lenient_lowercase([1,2,"a","b","C","d","e"]) == [1,2,"a","b","c","d","e"]



# Generated at 2022-06-24 21:14:58.548388
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes(2, 'GB') == 2147483648
    assert human_to_bytes('1K') == 1000
    assert human_to_bytes('1M') == 1000000
    assert human_to_bytes('1G') == 1000000000
    assert human_to_bytes(2, 'G') == 2000000000


# Generated at 2022-06-24 21:15:27.549615
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('50K') == 51200
    assert human_to_bytes('50K', default_unit='B') == 51200
    assert human_to_bytes('2M', default_unit='B') == 2097152
    assert human_to_bytes('2M', 'B') == 2097152
    assert human_to_bytes('2Mb', isbits=True) == 2097152
    assert human_to_bytes('2Mb', 'B', isbits=True) == 2097152
    try:
        human_to_bytes('2Bb', isbits=True)
        assert 0
    except ValueError:
        assert 1

# Test legacy function

# Generated at 2022-06-24 21:15:37.606912
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes(1) == 1

    assert human_to_bytes('1K') == 1024
    assert human_to_bytes(1, 'K') == 1024
    assert human_to_bytes('1K') == human_to_bytes(1, 'K')

    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1M', 'M') == 1048576
    assert human_to_bytes('1M') == human_to_bytes(1, 'M')

    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1G', 'G') == 1073741824
    assert human_to_bytes('1G') == human_to_bytes(1, 'G')

# Generated at 2022-06-24 21:15:43.981001
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10M', 'K') == 10
    assert human_to_bytes('10M', 'M') == 10485760


# Generated at 2022-06-24 21:15:54.150434
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # converting string representation into integer of bytes, MB, GB
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('1GB') == 1073741824
    # converting string representation into integer of bits, Gb
    assert human_to_bytes('1.5Gb', isbits=True) == 157286400
    # converting string representation into integer but with default unit,
    # and checking that bytes identifier is not mandatory in the string
    assert human_to_bytes('1', default_unit='b', isbits=True) == 8
    # checking that the suffix can be lowercase
    assert human_to_bytes('10gb', isbits=True) == 10737418240
    assert human_to_bytes('1mb') == 1048576


# Generated at 2022-06-24 21:15:56.791535
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = 50
    var_0 = lenient_lowercase(int_0)
    assert (var_0 == 50), 'lenient_lowercase(50) is expected to equal 50'



# Generated at 2022-06-24 21:16:03.373632
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("2K") == 2 * 1024
    assert human_to_bytes("1M") == 2 * 1024 * 1024
    assert human_to_bytes("1GB") == 2 * 1024 * 1024 * 1024
    assert human_to_bytes("1GC") == 2 * 1024 * 1024 * 1024
    assert human_to_bytes("1G", "B") == 2 * 1024 * 1024 * 1024
    assert human_to_bytes("1B") == 1
    assert human_to_bytes("1b") == 1
    assert human_to_bytes("1024") == 1024
    assert human_to_bytes("2KB") == 2 * 1024
    assert human_to_bytes("1MB") == 2 * 1024 * 1024
    assert human_to_bytes("1GB") == 2 * 1024 * 1024 * 1024
    assert human_to_bytes

# Generated at 2022-06-24 21:16:14.222013
# Unit test for function human_to_bytes

# Generated at 2022-06-24 21:16:25.626309
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1K') == 1 << 10
    assert human_to_bytes('1Kb') == 1 << 10
    assert human_to_bytes('1Kb', isbits=True) == 1 << 10
    assert human_to_bytes('1M') == 1 << 20
    assert human_to_bytes('1Mb') == 1 << 20
    assert human_to_bytes('1Mb', isbits=True) == 1 << 20
    assert human_to_bytes('1G') == 1 << 30
    assert human_to_bytes('1Gb') == 1 << 30

# Generated at 2022-06-24 21:16:34.195364
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase('foo') == 'foo'
    assert lenient_lowercase(['foo', 'bar']) == ['foo', 'bar']
    assert lenient_lowercase(['Foo', 'bAr']) == ['foo', 'bar']
    assert lenient_lowercase(['foo', 10]) == ['foo', 10]
    assert lenient_lowercase(('Foo', 'bAr')) == ('foo', 'bar')
    assert lenient_lowercase((10, 'foo')) == (10, 'foo')



# Generated at 2022-06-24 21:16:42.326947
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = [50]
    var_0 = lenient_lowercase(int_0)
    assert var_0 == [50]
    int_0 = ['50']
    var_0 = lenient_lowercase(int_0)
    assert var_0 == ['50']
    int_0 = [50, '50']
    var_0 = lenient_lowercase(int_0)
    assert var_0 == [50, '50']

