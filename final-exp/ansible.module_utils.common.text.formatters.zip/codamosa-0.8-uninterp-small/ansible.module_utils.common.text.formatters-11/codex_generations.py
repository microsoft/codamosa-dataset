

# Generated at 2022-06-24 21:06:48.160450
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("\nIn test_human_to_bytes")

    n = str(15)
    assert human_to_bytes(n) == 15

    n = str(0)
    assert human_to_bytes(n) == 0

    n = str('0')
    assert human_to_bytes(n) == 0

    n = str('0b')
    assert human_to_bytes(n) == 0

    n = str('1.5b')
    assert human_to_bytes(n) == 1.5

    n = str('1.5B')
    assert human_to_bytes(n) == 1.5

    n = str('1B')
    assert human_to_bytes(n) == 1

    n = str('1b')

# Generated at 2022-06-24 21:06:58.219197
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('2B') == 2
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('2G') == 2147483648
    assert human_to_bytes('2T') == 2199023255552
    assert human_to_bytes('2P') == 2251799813685248
    assert human_to_bytes('2E') == 2305843009213693952
    assert human_to_bytes('2Z') == 2361183241434822606848
    assert human_to_bytes('2Y') == 2417851639229258349412352



# Generated at 2022-06-24 21:07:04.717343
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1M") == 1048576
    assert human_to_bytes("100K") == 102400
    assert human_to_bytes("1M", "B") == 1048576
    assert human_to_bytes("100K", "B") == 102400
    assert human_to_bytes("1M", "b") == 8388608
    assert human_to_bytes("100K", "b") == 819200
    assert human_to_bytes("1M", isbits=True) == 8388608
    assert human_to_bytes("100K", isbits=True) == 819200
    assert human_to_bytes("1Mb")  == 8388608
    assert human_to_bytes("100Kb") == 819200


# Generated at 2022-06-24 21:07:06.962713
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = 2437
    var_0 = lenient_lowercase(int_0)
    assert len(var_0) > 0


# Generated at 2022-06-24 21:07:17.164584
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("Testing human_to_bytes function:")

    # Testing without default unit
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10M') == 10485760

    # testing with default unit
    assert human_to_bytes('10', 'G') == 10737418240

    # testing with leading whitespace
    assert human_to_bytes(' 10') == 10
    assert human_to_bytes('10 ') == 10
    assert human_to_bytes(' 10 ') == 10

    # testing with missing integer
    assert human_to_bytes('M') == 1048576

    # testing with non-integer
    assert human_to_bytes('10.5K') == 10752

    # testing without default unit and with no unit
    assert human_to_bytes('10', None) == 10

   

# Generated at 2022-06-24 21:07:22.055289
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1KB') == 1024



# Generated at 2022-06-24 21:07:32.185563
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print(human_to_bytes('1.6Kb'))
    print(human_to_bytes('1.6K'))
    print(human_to_bytes('1.6 Mb'))
    print(human_to_bytes('1.6Mb'))
    print(human_to_bytes('1.6M'))
    print(human_to_bytes('1.6Gb'))
    print(human_to_bytes('1.6G'))
    print(human_to_bytes('1.6 Tb'))
    print(human_to_bytes('1.6 T'))
    print(human_to_bytes('1.6 Pb'))
    print(human_to_bytes('1.6 P'))
    print(human_to_bytes('1.6 Eb'))

# Generated at 2022-06-24 21:07:36.195798
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase('STRING') == 'string'
    assert lenient_lowercase(1) == 1


# Generated at 2022-06-24 21:07:41.886473
# Unit test for function human_to_bytes
def test_human_to_bytes():

    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1.536Mb', isbits=True) == 2044160



# Generated at 2022-06-24 21:07:50.346454
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
    list_1 = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
    list_2 = [[1, 1, 1], [0, 0, 0], [0, 0, 0]]
    list_3 = [[1, 0, 1], [0, 0, 0], [0, 0, 0]]
    list_4 = [1, 2, 'F']

    assert list_0 == lenient_lowercase(list_1)
    assert not list_1 == lenient_lowercase(list_2)
    assert not list_2 == lenient_lowercase(list_3)
    assert list_2 == lenient_lowercase(list_4)


# Generated at 2022-06-24 21:07:58.069052
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("-->Test Start")
    print("---->test_case_0")
    int_0 = '1K'
    var_0 = human_to_bytes(int_0)
    print("---->test_case_1")
    int_1 = '1Kb'
    var_1 = human_to_bytes(int_1, isbits=True)
    print("---->test_case_2")
    int_2 = '2MB'
    var_2 = human_to_bytes(int_2)
    print("---->test_case_3")
    int_3 = '2Mb'
    var_3 = human_to_bytes(int_3, isbits=True)
    print("---->test_case_4")
    int_4 = '3G'

# Generated at 2022-06-24 21:08:08.169597
# Unit test for function human_to_bytes

# Generated at 2022-06-24 21:08:16.082019
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert str(2437) == '2437'
    assert str(2437, base=2) == '100101101101'
    assert str(2437, base=6) == '6275'
    assert str(2437, base=7) == '5262'
    assert str(2437, base=8) == '4675'
    assert str(2437, base=9) == '4050'
    assert str(2437, base=10) == '2437'
    assert str(2437, base=11) == '20b1'
    assert str(2437, base=12) == '1a75'
    assert str(2437, base=13) == '17b3'
    assert str(2437, base=14) == '152b'
    assert str(2437, base=15)

# Generated at 2022-06-24 21:08:26.256874
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = 2437
    var_0 = lenient_lowercase(int_0)
    if int_0 != var_0:
        raise AssertionError("Expected %s, got %s" % (int_0, var_0))

    float_0 = 2437.0
    float_1 = lenient_lowercase(float_0)
    if float_0 != float_1:
        raise AssertionError("Expected %s, got %s" % (float_0, float_1))

    list_0 = ['EquUS', 'Camel', 'hOnEy', 'Bee', 'RuMBLE', 2437]
    list_1 = lenient_lowercase(list_0)
    list_2 = ['equus', 'camel', 'honey', 'bee', 'rumble', 2437]

# Generated at 2022-06-24 21:08:33.958345
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    string_0 = 'SGHZTsymz'
    expected_0 = 'sghztsymz'
    var_0 = lenient_lowercase(string_0)
    assert var_0 == expected_0

    expected_1 = '2437'
    int_0 = 2437
    var_1 = lenient_lowercase(int_0)
    assert var_1 == expected_1

    expected_2 = 'SGHZTsymz'
    string_0 = 'SGHZTsymz'
    var_2 = lenient_lowercase(string_0)
    assert var_2 == expected_2



# Generated at 2022-06-24 21:08:44.295510
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # check the default value of default_unit
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    # check uppercase 'B' as byte identifier
    assert human_to_bytes('1MB') == 1048576
    # check single 'B' as byte identifier (unit is None)
    assert human_to_bytes('1B') == 1
    # check lowercase 'b' as bit identifier with 'isbits' params
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    # unittest.assertRaises(ValueError, human_to_bytes, '1Mb')
    # unittest.assertRaises(ValueError, human_to_bytes, '1MB', True)
    # check unit with more than one character
    assert human_

# Generated at 2022-06-24 21:08:45.843994
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = 2437
    assert lenient_lowercase(int_0) == [2437]



# Generated at 2022-06-24 21:08:56.000593
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('2K', 'B') == 2048)
    assert(human_to_bytes('1ZB') == 1 << 70)
    assert(human_to_bytes('1E') == 1 << 60)
    assert(human_to_bytes('1P') == 1 << 50)
    assert(human_to_bytes('1T') == 1 << 40)
    assert(human_to_bytes('1G') == 1 << 30)
    assert(human_to_bytes('1M') == 1 << 20)
    assert(human_to_bytes('1K') == 1 << 10)
    assert(human_to_bytes('1B') == 1)
    assert(human_to_bytes('1.2K') == 1.2 * 1024)

# Generated at 2022-06-24 21:08:59.826643
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(2) == 2



# Generated at 2022-06-24 21:09:05.890537
# Unit test for function human_to_bytes
def test_human_to_bytes():
    desired = 1536
    target = human_to_bytes('1.5K')
    assert target == desired, "Test failed: human_to_bytes('1.5K') != %d" % desired
    assert human_to_bytes('1.5k') == 1536, "Test failed: human_to_bytes('1.5k') != 1536"
    assert human_to_bytes('1.5kb') == 1536, "Test failed: human_to_bytes('1.5k') != 1536"
    assert human_to_bytes('1536') == 1536, "Test failed: human_to_bytes('1536') != 1536"
    assert human_to_bytes('1.5Mb') == 1572864, "Test failed: human_to_bytes('1.5Mb') != 1572864"

# Generated at 2022-06-24 21:09:19.955529
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == human_to_bytes(1, 'M')
    assert human_to_bytes('1M', isbits=True) == human_to_bytes(1, 'M', isbits=True)
    assert human_to_bytes('1', 'G') == human_to_bytes(1, 'G')
    assert human_to_bytes('1', 'M', True) == human_to_bytes(1, 'M', True)
    assert human_to_bytes('1048576') == human_to_bytes(1048576, 'b')
    assert human_to_bytes('1Kb', True) == human_to_bytes(1, 'Kb', True)
    assert human_to_bytes('1kb', True) == human_to_bytes(1, 'kb', True)


# Generated at 2022-06-24 21:09:25.107797
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.5KB') == 1536
    assert human_to_bytes('1.5KB', default_unit='M', isbits=False) == 1572864
    assert human_to_bytes(10, 'M', isbits=False) == 10485760
    assert human_to_bytes('1.5MB') == 1572864
    assert human_to_bytes('1.5MB', isbits=True) == 1610612736
    assert human_to_bytes('1.5Mb') == 1572864
    assert human_to_bytes('1.5Mb', isbits=True) == 1610612736
    assert human_to_bytes('1.5KB') == 1536
    assert human_to_bytes('1.5KB', isbits=True) == 12288
    assert human_

# Generated at 2022-06-24 21:09:33.862255
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == "1.00 Byte"
    assert bytes_to_human(1, unit='B') == "1.00 Byte"
    assert bytes_to_human(1, unit='Byte') == "1.00 Byte"
    assert bytes_to_human(1, unit='Bytes') == "1.00 Bytes"
    assert bytes_to_human(1, unit='byte') == "1.00 Byte"
    assert bytes_to_human(1, unit='bytes') == "1.00 Bytes"
    assert bytes_to_human(1, unit='KB') == "1.00 KB"
    assert bytes_to_human(1, unit='MB') == "1.00 MB"
    assert bytes_to_human(1, unit='GB') == "1.00 GB"
    assert bytes

# Generated at 2022-06-24 21:09:43.796303
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert (bytes_to_human(1024) == '1.00 KBytes')
    assert (bytes_to_human(1024, isbits=True) == '1.00 KBits')
    assert (bytes_to_human(1024, unit='B') == '1.00 B')
    assert (bytes_to_human(1024, isbits=True, unit='KB') == '1.00 KBits')
    assert (bytes_to_human(1024, unit='KB') == '1.00 KB')
    assert (bytes_to_human(1024, isbits=True, unit='B') == '1.00 KBits')
    assert (bytes_to_human(1024, unit='KBits') == '1.00 KBits')

# Generated at 2022-06-24 21:09:50.418389
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1000000) == '976.56 KiB'
    assert bytes_to_human(1024) == '1.00 KiB'
    assert bytes_to_human(1023) == '1023.00 Bytes'
    assert bytes_to_human(1023, isbits=True) == '8186.40 bits'
    assert bytes_to_human(1023, unit='b') == '8186.40 bits'
    assert bytes_to_human(1023, isbits=True, unit='b') == '8186.40 bits'


# Generated at 2022-06-24 21:09:53.028758
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(2437) == ['2', '4', '3', '7']

test_case_0.test_lenient_lowercase = test_lenient_lowercase

# Generated at 2022-06-24 21:09:59.742316
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes('10b') == 1
    assert human_to_bytes('1.5Mb') == 1572864
    assert human_to_bytes(1, 'Mb') == 1048576
    assert human_to_bytes(1, 'MB') == 1048576
    assert human_to_bytes(1, 'b', isbits=True) == 1
    assert human_to_bytes('1', 'Mb', isbits=True) == 1048576
    assert human_to_bytes('1.5Mb', isbits=True) == 1572864


# Generated at 2022-06-24 21:10:11.151922
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("Testing bytes_to_human")
    int_0 = 2437

# Generated at 2022-06-24 21:10:17.525636
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2.5M') == 262144
    assert human_to_bytes('0.5G') == 524288000
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('.5') == 0
    assert human_to_bytes('2') == 2
    assert human_to_bytes(10, 'K') == 10240
    assert human_to_bytes(15.1, 'm') == 15
    assert human_to_bytes(2.5, 'G') == 2500000000
    assert human_to_bytes(12, 'B') == 12
    assert human_to_bytes(12, 'b') == 12
    assert human_to_bytes(10, 'Kb') == 10240
    assert human

# Generated at 2022-06-24 21:10:20.065354
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    int_0 = 2437
    var_0 = lenient_lowercase(int_0)
    if var_0 != 2437:
        failure = True
    else:
        failure = False

    assert(failure is False)



# Generated at 2022-06-24 21:10:33.179252
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = 2437
    assert lenient_lowercase(int_0) == int_0
    str_0 = "Oyez"
    assert lenient_lowercase(str_0) == 'oyez'
    list_0 = ["Oyez", 10, "3.33e-3"]
    assert lenient_lowercase(list_0) == ['oyez', 10, "3.33e-3"]
    tuple_0 = ("Oyez", 10, "3.33e-3")
    assert lenient_lowercase(tuple_0) == ('oyez', 10, "3.33e-3")
    empty_str = ""
    assert lenient_lowercase(empty_str) == empty_str
    none_str = None
    assert lenient_lowercase(none_str) == none_

# Generated at 2022-06-24 21:10:41.449622
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    log = []
    class Test(object):
        def __init__(self, value):
            self.value = value
        def lower(self):
            return self.value.lower()

    list_0 = [1, 2, 3, "test", Test("TEST")]
    list_1 = lenient_lowercase(list_0)
    log.append(list_1[3] == "test")
    log.append(list_1[4].value == "test")
    log.append(list_1[4].lower() == "test")
    if False in log:
        raise AssertionError
    print("Passed test")


# Generated at 2022-06-24 21:10:50.212806
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Success case:
    assert human_to_bytes("2K") == 2048
    assert human_to_bytes("2M") == 2097152
    assert human_to_bytes("2G") == 2147483648
    assert human_to_bytes("2T") == 2199021056256
    assert human_to_bytes("2P") == 2251799813685248

    assert human_to_bytes("2k") == 2048
    assert human_to_bytes("2m") == 2097152
    assert human_to_bytes("2g") == 2147483648
    assert human_to_bytes("2t") == 2199021056256
    assert human_to_bytes("2p") == 2251799813685248

    assert human_to_bytes("2Kb") == 2048
    assert human_to_

# Generated at 2022-06-24 21:11:00.470417
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1', 'B') == 1
    assert human_to_bytes('1', 'KB') == 1000
    assert human_to_bytes('1', 'MB') == 1000 * 1000
    assert human_to_bytes('1', 'GB') == 1000 * 1000 * 1000
    assert human_to_bytes('1', 'TB') == 1000 * 1000 * 1000 * 1000
    assert human_to_bytes('1', 'PB') == 1000 * 1000 * 1000 * 1000 * 1000
    assert human_to_bytes('1', 'EB') == 1000 * 1000 * 1000 * 1000 * 1000 * 1000
    assert human_to_bytes('1', 'ZB') == 1000 * 1000 * 1000 * 1000 * 1000 * 1000 * 1000
    assert human_to_bytes('1', 'YB') == 1000 * 1000 * 1000 * 1000 * 1000 * 1000 * 1000

# Generated at 2022-06-24 21:11:08.608899
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1TB') == 1099511627776
    assert human_to_bytes('1TB', isbits=True) == 1099511627776
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', 'B') == 10485760
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10MB', isbits=True) == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'Mb', isbits=True) == 10485760

# Generated at 2022-06-24 21:11:17.571838
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('Test 1: 1024')
    assert human_to_bytes('1024') == 1024
    print('Test 2: 1048576')
    assert human_to_bytes('1M') == 1048576
    print('Test 3: 1073741824')
    assert human_to_bytes('1G') == 1073741824
    print('Test 4: 1099511627776')
    assert human_to_bytes('1T') == 1099511627776
    print('Test 5: 1125899906842624')
    assert human_to_bytes('1P') == 1125899906842624
    print('Test 6: 1152921504606846976')
    assert human_to_bytes('1E') == 1152921504606846976
    print('Test 7: 1180591620717411303424')


# Generated at 2022-06-24 21:11:27.587166
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # check None input
    try:
        assert human_to_bytes(None) == 0
    except Exception as e:
        print('Error in test_human_to_bytes (1): {}'.format(e))
    try:
        assert human_to_bytes(None, None, True) == 0
    except Exception as e:
        print('Error in test_human_to_bytes (2): {}'.format(e))

    # check 'B' type
    try:
        assert human_to_bytes('1B', None, 2) == 1
    except Exception as e:
        print('Error in test_human_to_bytes (3): {}'.format(e))

    # check 'B' type

# Generated at 2022-06-24 21:11:38.312950
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ########################################################################
    # test 1
    result = human_to_bytes('1Y')
    assert(result == 1 << 80)

    # test 2
    result = human_to_bytes('1.1Y')
    assert(result == 1.1 * (1 << 80))

    # test 3
    result = human_to_bytes('100.10E')
    assert(result == 100.1 * (1 << 60))

    # test 4
    result = human_to_bytes('1B', default_unit='B')
    assert(result == 1)

    # test 5
    result = human_to_bytes('1KB', default_unit='B')
    assert(result == 1 << 10)

    # test 6
    result = human_to_bytes('1MB', default_unit='B')

# Generated at 2022-06-24 21:11:44.438030
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        tst_case = test_case_0()
    except Exception as e:
        raise Exception('FAILED: test_case_0 threw an error: {}'.format(e))

    if not isinstance(tst_case, str):
        raise Exception('FAILED: test_case_0 did not return an str object, returned: {}'.format(type(tst_case)))

    if tst_case != '2437':
        raise Exception('FAILED: test_case_0 did not return the expected response. '
                        'Expected: {}, Received: {}'.format('2437', tst_case))
    else:
        print('PASSED: lenient_lowercase returned: {}'.format(tst_case))



# Generated at 2022-06-24 21:11:53.747718
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Human-readable string to integer (bits).
    assert human_to_bytes('10Mb', isbits=True) == 10485760, "human_to_bytes('10Mb') != 10485760"

    # Human-readable string to integer (bytes).
    assert human_to_bytes('10M') == 10485760, "human_to_bytes('10M') != 10485760"

    # Passing 'b' as a part of unit should not raise an exception.
    assert human_to_bytes('2.5Kb', default_unit='b') == 2560, "human_to_bytes('2.5Kb') != 2560"

    # Passing 'B' as a suffix of unit should not raise an exception.

# Generated at 2022-06-24 21:11:56.998266
# Unit test for function human_to_bytes
def test_human_to_bytes():
    int_0 = 2437
    var_0 = human_to_bytes(int_0)
    assert var_0 == 2437


# Generated at 2022-06-24 21:12:05.534294
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(None) == 1
    assert human_to_bytes('') == 1
    # assert human_to_bytes(-1) == 1
    # assert human_to_bytes('-1') == 1
    # assert human_to_bytes('0.') == 1
    # assert human_to_bytes('.0') == 1
    # assert human_to_bytes('0') == 1
    # assert human_to_bytes('0.0') == 1
    # assert human_to_bytes('0.0.') == 1
    # assert human_to_bytes('0.0.0') == 1
    assert human_to_bytes('B') == 1
    assert human_to_bytes('B', 'M') == 1048576
    assert human_to_bytes('1B') == 1
    assert human_

# Generated at 2022-06-24 21:12:08.477183
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        result = human_to_bytes('10M')
        print(result)
    except ValueError as e:
        print(e.message)

    try:
        result = human_to_bytes('10M', True)
        print(result)
    except ValueError as e:
        print(e.message)



# Generated at 2022-06-24 21:12:10.988413
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test = ['A', 'List', 'With', 'Mixed', 'Case', 'Strings', 1, 2, 3]
    expected = ['a', 'list', 'with', 'mixed', 'case', 'strings', 1, 2, 3]
    assert(lenient_lowercase(test) == expected)


# Generated at 2022-06-24 21:12:12.951619
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase("aBcD") == "abcd"
    assert lenient_lowercase([1, 2, 3, 4]) == [1, 2, 3, 4]


# Generated at 2022-06-24 21:12:14.912679
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(2437) == []
    assert lenient_lowercase('wed') == 'wed'
    assert lenient_lowercase(['Wed']) == ['wed']



# Generated at 2022-06-24 21:12:17.961705
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = 13
    var_0 = lenient_lowercase(int_0)
    assert var_0 == 13
    int_1 = 2437
    var_1 = lenient_lowercase(int_1)
    assert var_1 == 2437


# Generated at 2022-06-24 21:12:21.713153
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('3M') == 3145728
    assert human_to_bytes('3M', None, False) == 3145728
    assert human_to_bytes('3M') == 3145728
    assert human_to_bytes('3M', 'M', False) == 3145728
    assert human_to_bytes('3M') == 3145728
    assert human_to_bytes('3M', None, True) == 3145728
    assert human_to_bytes('3M') == 3145728
    assert human_to_bytes('3M', 'M', True) == 3145728
    assert human_to_bytes('3M') == 3145728
    assert human_to_bytes('3b') == 3
    assert human_to_bytes('3b', None, False) == 3
    assert human_to

# Generated at 2022-06-24 21:12:33.310174
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('0') == 0
    assert human_to_bytes('0.0') == 0
    assert human_to_bytes('0.0K') == 0
    assert human_to_bytes('0.1') == 0
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0Kb') == 1024

# Generated at 2022-06-24 21:12:43.139213
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(2437) == 2437)
    assert(lenient_lowercase("test") == "test")
    assert(lenient_lowercase(['test', 'test']) == ['test', 'test'])
    assert(lenient_lowercase(['test', 2437]) == ['test', 2437])
    assert(lenient_lowercase(['TEST', 'TEST']) == ['test', 'test'])
    assert(lenient_lowercase({'test': 'test'}) == {'test': 'test'})
    assert(lenient_lowercase(['TEST', 2437]) == ['test', 2437])


# Generated at 2022-06-24 21:12:47.736938
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        test_case_0()
    except Exception as e:
        return False

    return True



# Generated at 2022-06-24 21:12:53.750818
# Unit test for function human_to_bytes
def test_human_to_bytes():
    int_0 = 2437
    bytes_0 = human_to_bytes(int_0, default_unit='b')
    bytes_1 = human_to_bytes('2437')
    bytes_2 = human_to_bytes('2437K')
    bytes_3 = human_to_bytes('2437KB')

    assert bytes_0 == bytes_1 == bytes_2 == bytes_3

    bytes_4 = human_to_bytes('2437KiB')
    bytes_5 = human_to_bytes('2437Kib')
    bytes_6 = human_to_bytes('2437kib')
    assert bytes_4 == bytes_5 == bytes_6

    bytes_7 = human_to_bytes('1MB')
    bytes_8 = human_to_bytes(1, 'MB')

# Generated at 2022-06-24 21:13:02.246687
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        human_to_bytes('1MB', False)
    except ValueError:
        pass
    else:
        raise AssertionError("ValueError should be raised in case the function input '1MB' is of wrong format")

    try:
        human_to_bytes('1234', False)
    except ValueError:
        pass
    else:
        raise AssertionError("ValueError should be raised in case the function input '1234' is of wrong format")

    try:
        human_to_bytes('1MB', True)
    except ValueError:
        pass
    else:
        raise AssertionError("ValueError should be raised in case the function input '1MB' is of wrong format")

    assert human_to_bytes(1, False) == 1

# Generated at 2022-06-24 21:13:03.333185
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = 2437
    assert lenient_lowercase(int_0) == [2437]


# Generated at 2022-06-24 21:13:08.684976
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input = ["Test", 1234, None]
    output = ['test', 1234, None]
    assert lenient_lowercase(input) == output


# Generated at 2022-06-24 21:13:19.227150
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('100Mb', isbits=True) == 104857600
    assert human_to_bytes('100Mb') == 104857600
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1Gb', isbits=True) == 1073741824
    assert human_to_bytes('1Gb') == 1073741824
    assert human_to_bytes('1TB') == 1099511627776
    assert human_to_bytes('1Tb', isbits=True) == 1099511627776
    assert human_to

# Generated at 2022-06-24 21:13:28.421581
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = 2437
    var_0 = lenient_lowercase(int_0)
    assert var_0 == 2437
    var_0 = lenient_lowercase('!@#$;:')
    assert var_0 == '!@#$;:'
    var_0 = lenient_lowercase('YTcGKj')
    assert var_0 == 'ytcgkj'
    var_0 = lenient_lowercase('J')
    assert var_0 == 'j'
    var_0 = lenient_lowercase('IR')
    assert var_0 == 'ir'
    var_0 = lenient_lowercase('4')
    assert var_0 == '4'
    var_0 = lenient_lowercase('aiVu')
    assert var_0 == 'aivu'
    var_

# Generated at 2022-06-24 21:13:37.043573
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5M', 'K') == 1572864
    assert human_to_bytes('1.5M', 'K', True) == 1572864
    assert human_to_bytes('1.5M', isbits=True) == 1572864
    assert human_to_bytes('1.5MB') == 1572864
    assert human_to_bytes('1.5MB', 'b') == 1572864
    assert human_to_bytes('1.5MB', 'b', True) == 1572864
    assert human_to_bytes('1.5MB', isbits=True) == 1572864
    assert human_to_bytes('1.5Mb') == 1572864

# Generated at 2022-06-24 21:13:45.623352
# Unit test for function human_to_bytes
def test_human_to_bytes():
    #Test when isbits is False
    #Test when input is MB
    #Input
    input_0 = '1MB'
    expected_0 = 1048576
    #Test Case
    actual_0 = human_to_bytes(input_0)
    #Assert
    assert actual_0 == expected_0
    #Test when input is KB
    #Input
    input_1 = '1KB'
    expected_1 = 1024
    #Test Case
    actual_1 = human_to_bytes(input_1)
    #Assert
    assert actual_1 == expected_1
    #Test when input is K
    #Input
    input_2 = '1K'
    expected_2 = 1024
    #Test Case
    actual_2 = human_to_bytes(input_2)
    #Assert
    assert actual

# Generated at 2022-06-24 21:13:53.084581
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test with fail condition
    with pytest.raises(ValueError):
        human_to_bytes('Mb', isbits=False)
    # Test with fail condition
    with pytest.raises(ValueError):
        human_to_bytes(23, default_unit='G', isbits=False)
    # Test with fail condition
    with pytest.raises(ValueError):
        human_to_bytes('Mb', isbits=True)
    # Check for bytes conversion (bytes -> bytes)
    assert human_to_bytes('7B', isbits=False) == 7
    # Check for bytes conversion (bytes -> bits)
    assert human_to_bytes('7B', isbits=True) == 56
    # Check for bytes conversion (bytes -> bytes)

# Generated at 2022-06-24 21:13:58.932366
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1Mb', isbits=False) == 128000



# Generated at 2022-06-24 21:14:10.812386
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['Vlan1', 'Gi1/0/1']
    res = ['vlan1', 'gi1/0/1']
    assert res == lenient_lowercase(lst)
    # Test when input is a dict
    dict_in = {'vl': ['Vlan1', 'Gi1/0/1'], 'po': ['Po1']}
    dict_out = {'vl': ['vlan1', 'gi1/0/1'], 'po': ['po1']}
    assert dict_out == lenient_lowercase(dict_in)
    # Test when input is a dict of dict
    dict_in = {'vl': {'type': ['Vlan1', 'Gi1/0/1'], 'num': ['1', '2']}, 'po': ['Po1']}
    dict_

# Generated at 2022-06-24 21:14:22.119553
# Unit test for function human_to_bytes
def test_human_to_bytes():
    bool_0 = True
    bool_1 = False

    float_0 = float(0)
    float_1 = float(-1)
    float_2 = float(16386)
    float_3 = float(0.8)
    float_4 = float(-17.1)

    int_0 = int(0)
    int_1 = int(-1)
    int_2 = int(16386)
    int_3 = int(254)
    int_4 = int(-17)

    str_0 = str('-17.1')
    str_1 = str('')
    str_2 = str('16386')
    str_3 = str('-1')
    str_4 = str('0.8')
    str_5 = str('16386.8')
    str_6 = str('0')

# Generated at 2022-06-24 21:14:32.147827
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("-" * 20)
    print("Unit Test:   human_to_bytes")
    l_start = 125
    l_end = 126

    # Unit test for function human_to_bytes
    for i in range(l_start, l_end):
        l_input = i
        l_unit = None
        l_isbits = False
        l_expected = i

        test_case_0()
        print("Unit Test:   Input: {} Unit: {} isbits: {}".format(l_input, l_unit, l_isbits))
        l_result = human_to_bytes(l_input, l_unit, l_isbits)
        print("Unit Test:   Expected: {} Result: {}".format(l_expected, l_result))
        assert l_expected == l_result


# Generated at 2022-06-24 21:14:37.053803
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    x = ['A', 'B', 'C', 'd', 'E', 1]
    test = [1, 'd', 'A', 'B', 'C', 'E']
    assert lenient_lowercase(x) == test


# Generated at 2022-06-24 21:14:46.338553
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('Testing human_to_bytes function')
    try:
        print('- Test case #1:')
        print(human_to_bytes('2048'))
        bool_0 = True
    except Exception as e:
        print(e)
        bool_0 = False
    assert bool_0 == True
    try:
        print('- Test case #2:')
        print(human_to_bytes('10MB'))
        bool_1 = True
    except Exception as e:
        print(e)
        bool_1 = False
    assert bool_1 == True
    try:
        print('- Test case #3:')
        print(human_to_bytes('2048', 'K'))
        bool_2 = True
    except Exception as e:
        print(e)
        bool_2 = False


# Generated at 2022-06-24 21:14:53.910767
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('\n----------------------------')
    print('Unit test for function human_to_bytes')
    print('----------------------------')
    test_case_num = 0
    print('Test Case %d' % (test_case_num + 1))
    input = '1MB'
    output = human_to_bytes(input)
    print('Res: %d' % output)
    print('Expected: %d' % 1048576)
    if output == 1048576:
        test_case_num += 1
        print('Pass\n')
    else:
        print('Fail\n')

    print('Test Case %d' % (test_case_num + 1))
    input = '1KB'
    output = human_to_bytes(input)
    print('Res: %d' % output)

# Generated at 2022-06-24 21:14:56.344091
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["one", 2, 3, {4, "five", 6}]) == ["one", 2, 3, {4, "five", 6}]


# Generated at 2022-06-24 21:15:04.597481
# Unit test for function human_to_bytes
def test_human_to_bytes():
    bool_0 = True
    if bool_0:
        i_1 = human_to_bytes('10M')
        i_2 = human_to_bytes('10MB')
        i_3 = human_to_bytes('10mB')
        i_4 = human_to_bytes('10Mb', isbits=True)
        i_5 = human_to_bytes('10Mb')
        i_6 = human_to_bytes('10Kb', isbits=True)
        i_7 = human_to_bytes('10KB', isbits=True)
        i_8 = human_to_bytes('10Kb')
        i_9 = human_to_bytes('10KB')
        i_10 = human_to_bytes('10K')
        i_11 = human_to_bytes('10kb')


# Generated at 2022-06-24 21:15:12.132232
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print(human_to_bytes('1000b'))
    print(human_to_bytes('1000B'))
    print(human_to_bytes('1kb'))
    print(human_to_bytes('1KB'))
    print(human_to_bytes('1mb'))
    print(human_to_bytes('1MB'))
    print(human_to_bytes('1gb'))
    print(human_to_bytes('1GB'))
    print(human_to_bytes('1tb'))
    print(human_to_bytes('1TB'))
    print(human_to_bytes('1pb'))
    print(human_to_bytes('1PB'))
    print(human_to_bytes('1eb'))
    print(human_to_bytes('1EB'))
    print

# Generated at 2022-06-24 21:15:25.669044
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10K') == 10 * 1 << 10
    assert human_to_bytes('10K') == 10 * 1 << 10
    assert human_to_bytes('10K') == 10 * 1 << 10
    assert human_to_bytes('10M') == 10 * 1 << 20
    assert human_to_bytes('10G') == 10 * 1 << 30
    assert human_to_bytes('10T') == 10 * 1 << 40
    assert human_to_bytes('10P') == 10 * 1 << 50
    assert human_to_bytes('10E') == 10 * 1 << 60

# Generated at 2022-06-24 21:15:32.715254
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    input_0 = ['A', 'B', 'C', 'D']
    output_0 = lenient_lowercase(input_0)
    assert output_0 == ['a', 'b', 'c', 'd']

    input_1 = ['apples', 'Bananas', 'Cherries', 1, 2, 3, 4]
    output_1 = lenient_lowercase(input_1)
    assert output_1 == ['apples', 'bananas', 'cherries', 1, 2, 3, 4]


# Generated at 2022-06-24 21:15:35.030422
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['aBCdEfG', 1, True]) == ['abcdefg', 1, True]


# Generated at 2022-06-24 21:15:46.523214
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    assert lenient_lowercase([]) == []

    assert lenient_lowercase([1, 2, 3]) == [1, 2, 3]
    assert lenient_lowercase(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'B', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['A', 'b', 'C']) == ['a', 'b', 'c']
    assert lenient_lowercase(['a', 2, 'C']) == ['a', 2, 'c']
    assert lenient_lowercase([1, 'B', 3]) == [1, 'b', 3]

# Generated at 2022-06-24 21:15:49.731549
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_case_0(lenient_lowercase("dracut.conf"))


# Generated at 2022-06-24 21:15:51.821168
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['A','B','C','D']) == ['a','b','c','d']


# Generated at 2022-06-24 21:16:02.114660
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert 1 == human_to_bytes('1')
    assert 1 == human_to_bytes('1b')
    assert 1 == human_to_bytes('1bits')
    assert 8 == human_to_bytes('1bits', isbits=True)
    assert 1 == human_to_bytes('1B')
    assert 1 == human_to_bytes('1byte')
    assert 1 == human_to_bytes('1Bytes')
    assert 1 == human_to_bytes('1B', default_unit='B')
    assert 1 == human_to_bytes('1B', default_unit='byte')
    assert 1 == human_to_bytes('1B', default_unit='Bytes')
    assert 1 == human_to_bytes('1bit', default_unit='b', isbits=True)

# Generated at 2022-06-24 21:16:06.157198
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    src = ['TEST', 2, None, '', 'test']
    expected = ['test', 2, None, '', 'test']
    result = lenient_lowercase(src)
    assert result == expected


# Generated at 2022-06-24 21:16:11.422837
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    list_0 = [
        "string",
        1,
        2,
        3,
        4,
    ]
    result = lenient_lowercase(list_0)
    assert result == ['string', 1, 2, 3, 4]



# Generated at 2022-06-24 21:16:20.325482
# Unit test for function lenient_lowercase

# Generated at 2022-06-24 21:16:35.659252
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(1, 'M') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1mb') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('.5M') == 524288
    assert human_to_bytes('.5') == 0
    assert human_to_bytes('.5MB') == 524288
    assert human_to_bytes('.5Mb') == 524288
    assert human_

# Generated at 2022-06-24 21:16:46.109399
# Unit test for function human_to_bytes
def test_human_to_bytes():
    unit_string = '1mb'
    unit_bit = '1b'
    unit_byte = '1B'
    unit_byte2 = '2K'
    unit_bytes = '2Kb'
    unit_none = '4'

    assert human_to_bytes(unit_string, isbits=True) == 1048576
    assert human_to_bytes(unit_bit, isbits=True) == 1
    assert human_to_bytes(unit_byte, isbits=True) == 8
    assert human_to_bytes(unit_byte2, isbits=True) == 16384
    assert human_to_bytes(unit_bytes, isbits=True) == 2048
    assert human_to_bytes(unit_none, isbits=True) == 4

    assert human_to_bytes(unit_string) == 10