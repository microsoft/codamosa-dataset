

# Generated at 2022-06-24 21:07:00.093713
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1000') == 1000
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB', isbits=True) == 8388608
    assert human_to_bytes('1MB', isbits=False) == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 8388608
    assert human_to_bytes('1Gb', isbits=True) == 8589934592
    assert human_to_bytes('1Mb', isbits=False) == 8388608
    assert human_to_bytes('1Gb', isbits=False) == 8388608
    assert human_to_bytes('1Gb', 'B') == 8589934592
    assert human_to

# Generated at 2022-06-24 21:07:07.562826
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        test_case_0()
    except Exception as err:
        print("Test case 0 failed: " + str(err))
    else:
        print("Test case 0 passed")

if __name__ == '__main__':
    """ This program is used to unit test function lenient_lowercase in module_utils/common.py
    """
    # test_lenient_lowercase()

# Generated at 2022-06-24 21:07:17.794801
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test case 0
    test_case_0_name = 'Test case 0: null value'
    test_case_0_result = human_to_bytes(None)
    print(test_case_0_name)
    print('Expected result: ValueError')
    print('Actual result:')
    try:
        print(test_case_0_result)
        print('Failed!')
    except ValueError as e:
        print('Expected exception: ' + str(e))
        print('Passed!')
    print()

    # Test case 1
    test_case_1_name = 'Test case 1: empty string'
    test_case_1_result = human_to_bytes('')
    print(test_case_1_name)
    print('Expected result: ValueError')
    print

# Generated at 2022-06-24 21:07:28.419909
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('5') == 5
    assert human_to_bytes('1.2') == 1
    assert human_to_bytes('5KB') == 5000
    assert human_to_bytes('5Kb') == 5000
    assert human_to_bytes('5K', isbits=True) == 5000
    assert human_to_bytes('5Kb', isbits=True) == 5000
    assert human_to_bytes('1.2K') == 1200
    assert human_to_bytes('1.2Kb') == 1200
    assert human_to_bytes('1.2K', isbits=True) == 1200
    assert human_to_bytes('1.2Kb', isbits=True) == 1200
    assert human_to_bytes('5MB') == 5000000
    assert human_to_bytes('5Mb')

# Generated at 2022-06-24 21:07:30.487418
# Unit test for function human_to_bytes
def test_human_to_bytes():
    value = human_to_bytes("1M")
    print("convert value is: " + str(value))


# Generated at 2022-06-24 21:07:31.608403
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_case_0()

# Unit tests for function human_to_bytes

# Generated at 2022-06-24 21:07:35.814483
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """
    For this test program, call function lenient_lowercase()
    """
    test_case_0()


# Generated at 2022-06-24 21:07:45.962636
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = human_to_bytes('3')
    assert result == 3, "human_to_bytes('3') result is not 3"
    result = human_to_bytes('3.0')
    assert result == 3, "human_to_bytes('3.0') result is not 3"
    result = human_to_bytes('3.2')
    assert result == 3, "human_to_bytes('3.2') result is not 3"
    result = human_to_bytes('3e0')
    assert result == 3, "human_to_bytes('3e0') result is not 3"
    result = human_to_bytes('3E0')
    assert result == 3, "human_to_bytes('3E0') result is not 3"
    result = human_to_bytes('3.2B')
    assert result

# Generated at 2022-06-24 21:07:54.892634
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K', default_unit=None, isbits=False) == 2048
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10.0, 'M') == 10485760.0
    assert human_to_bytes(10, 'K') == 10240
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes(1024) == 1024
    assert human_to_bytes(1024, 'M') == 1048576
    assert human_to_bytes('10.2M') == 10485760
    assert human_to_bytes('0.5M') == 524288
    assert human_to_bytes('100') == 100
    assert human_

# Generated at 2022-06-24 21:07:56.180202
# Unit test for function human_to_bytes
def test_human_to_bytes():
    str_1 = '1MB'
    result = human_to_bytes(str_1)
    assert isinstance(result, int)
    assert result == 1048576



# Generated at 2022-06-24 21:08:04.464744
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test case 0
    str_0 = '\n    For this test program, call function lenient_lowercase()\n    '
    new_str_0 = str_0
    try:
        lenient_lowercase(new_str_0)
    except Exception:
        print('AssertionError: assert lenient_lowercase() failed')

    # Call assert lenient_lowercase()
    try:
        assert lenient_lowercase(new_str_0)
    except Exception:
        print('AssertionError: assert lenient_lowercase() failed')
    return str_0


# Generated at 2022-06-24 21:08:13.584590
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    str_0 = 'This test with no lowercase\n'
    str_1 = 'with lowercase'
    str_2 = 'with UPPERCASE'
    str_3 = 'With Mixed CaSe'
    str_4 = 'WITH ALL CAPS'

    int_0 = 0
    int_1 = 1

    list_0 = [str_0, str_1, str_2, str_3, str_4, int_0, int_1]
    list_1 = list_0[:]

    result_1 = lenient_lowercase(list_0)
    if result_1 != list_1:
        print('failed test_case_1')

    str_1 = str_1.lower()
    str_2 = str_2.lower()
    str_3 = str_3.lower()


# Generated at 2022-06-24 21:08:21.485530
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert(lenient_lowercase(['A', 'B']) == ['a', 'b'])
    assert(lenient_lowercase(['a', 'b']) == ['a', 'b'])
    assert(lenient_lowercase(['a', 'B']) == ['a', 'b'])
    assert(lenient_lowercase(['A', 'b']) == ['a', 'b'])
    assert(lenient_lowercase([1, 2, 3]) == [1, 2, 3])
    assert(lenient_lowercase(test_case_0) == test_case_0)


# Generated at 2022-06-24 21:08:30.636859
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1024K') == 1024*1024
    assert human_to_bytes('1024KB') == 1024*1024
    assert human_to_bytes('1024Kb') == 1024*1024
    assert human_to_bytes('1048576') == 1048576

    # Test cases for byte and bit identifier
    assert human_to_bytes('1024B') == 1024
    assert human_to_bytes('1024b') == 1024
    assert human_to_bytes('8b') == 1
    assert human_to_bytes('1000b', isbits=True) == 1000

# Generated at 2022-06-24 21:08:36.457300
# Unit test for function bytes_to_human
def test_bytes_to_human():

    examples = [
        (2, '2 bytes'),
        (2048, '2.00 KB'),
        (2048 * 1024, '2.00 MB'),
        (2048 * 1024 * 1024, '2.00 GB'),
        (2048 * 1024 * 1024 * 1024, '2.00 TB'),
        (1048575.5, '1023.99 KB'),
        (1048576, '1.00 MB'),
    ]

    for bytes_value, expected_human_value in examples:
        human_value = bytes_to_human(bytes_value)
        assert human_value == expected_human_value


# Generated at 2022-06-24 21:08:46.374230
# Unit test for function human_to_bytes
def test_human_to_bytes():
    inp_0 = '1Mb'
    out_0 = 1048576
    assert human_to_bytes(inp_0, isbits=True) == out_0, 'Test case failed: input = %s, expected output = %d' % (inp_0, out_0)
    inp_1 = '1MB'
    out_1 = 1048576
    assert human_to_bytes(inp_1) == out_1, 'Test case failed: input = %s, expected output = %d' % (inp_1, out_1)
    inp_2 = '1b'
    out_2 = 1

# Generated at 2022-06-24 21:08:53.105592
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        assert lenient_lowercase(['A', 'b', 'C', 1, 3]) == ['a', 'b', 'c', 1, 3]
    except AssertionError:
        return False
    return True


# Generated at 2022-06-24 21:09:01.431471
# Unit test for function human_to_bytes
def test_human_to_bytes():
    in_str = ''
    byte_value = 0

    print('Unit test for function human_to_bytes()')
    print('\tInput string: %s, expected value: %d' % (in_str, byte_value))
    test_value = human_to_bytes(in_str)
    if test_value == byte_value:
        print('\tTest passed.\n')
    else:
        print('\tTest failed.\n')
        exit()

    in_str = '0'
    byte_value = 0
    print('\tInput string: %s, expected value: %d' % (in_str, byte_value))
    test_value = human_to_bytes(in_str)
    if test_value == byte_value:
        print('\tTest passed.\n')


# Generated at 2022-06-24 21:09:04.446391
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(2048, unit='KB') == '2.00 KB'
    assert bytes_to_human(1099511627776, unit='Tb') == '1.00 Tb'
    assert bytes_to_human(1099511627776, isbits=True, unit='Tb') == '8.00 Tb'


# Generated at 2022-06-24 21:09:13.071604
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1MB', 'B') == 1048576
    assert human_to_bytes('1MB', 'B') == 1048576
    assert human_to_bytes('1m', 'B') == 1048576
    assert human_to_bytes('1MB', 'm') == 1048576
    assert human_to_bytes('1MB', 'm') == 1048576
    assert human_to_bytes('1m', 'B') == 1048576
    assert human_to_bytes('1MB', 'B') == 1048576
    assert human_to_bytes('1MB', 'B') == 1048576

# Generated at 2022-06-24 21:09:20.078909
# Unit test for function bytes_to_human
def test_bytes_to_human():
    human_str = bytes_to_human(2048)
    if human_str != "2 KB":
        raise ValueError("test_bytes_to_human: failed to convert 2048 bytes to human readable format")
    return True

# Generated at 2022-06-24 21:09:28.855947
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test string
    a = []
    a.append('\n    For this test program, call human_to_bytes() with\n    number = 75, unit = G, unit should be MB or Mb.\n    ')
    # test number
    b = []
    b.append(75)
    # test unit
    c = []
    c.append('G')

    for i in range(len(a)):
        try:
            print("\na = {0}, b = {1}, c = {2}".format(a[i], b[i], c[i]))
            human_to_bytes(number=b[i], default_unit=c[i])
        except ValueError as e:
            print("Catch ValueError: {0}".format(e))



# Generated at 2022-06-24 21:09:39.321192
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest

    # Throws an exception if expected value is different from actual value
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2k') == 2048
    assert human_to_bytes('2M') == 2048 * 1024
    assert human_to_bytes('2m') == 2048 * 1024
    assert human_to_bytes('2G') == 2048 * 1024 * 1024
    assert human_to_bytes('2g') == 2048 * 1024 * 1024
    assert human_to_bytes('2T') == 2048 * 1024 * 1024 * 1024
    assert human_to_bytes('2t') == 2048 * 1024 * 1024 * 1024
    assert human_to_bytes('2P') == 2048 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('2p') == 2048 * 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-24 21:09:46.056662
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("\n****** Case 1 ******")
    num = '10.5M'
    unit = 'M'
    res = human_to_bytes(num)
    print("human_to_bytes(%s) returned %s" % (num, res))
    assert res == 10.5 * SIZE_RANGES[unit]

    print("\n****** Case 2 ******")
    num = '10.5Mb'
    unit = 'M'
    res = human_to_bytes(num, isbits=True)
    print("human_to_bytes(%s, isbits=True) returned %s" % (num, res))
    assert res == 10.5 * SIZE_RANGES[unit]

    print("\n****** Case 3 ******")
    num = "10.5M"

# Generated at 2022-06-24 21:09:56.583007
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Case 1: test human_to_bytes without unit
    number = '0'
    expected_result = 0
    result = human_to_bytes(number)
    assert result == expected_result
    # Case 2: test human_to_bytes with unit
    number = '2G'
    expected_result = 2 * (1 << 30)
    result = human_to_bytes(number)
    assert result == expected_result
    # Case 3: test human_to_bytes with unit and default_unit
    number = '10M'
    expected_result = 10 * (1 << 20)
    result = human_to_bytes(number, 'M')
    assert result == expected_result
    # Case 4: test human_to_bytes with space
    number = '10 MB  '

# Generated at 2022-06-24 21:10:04.913966
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['lOwErCaSe', 'lowercase', 'lowercase']) == ['lowercase', 'lowercase', 'lowercase']
    assert lenient_lowercase(['UPPERCASE', 'UPPERCASE', 'UPPERCASE']) == ['uppercase', 'uppercase', 'uppercase']
    # Failure case
    assert lenient_lowercase(['UPPERCASE', 'UPPERCASE', 'UPPERCASE']) == ['UPPERCASE', 'UPPERCASE', 'UPPERCASE']

# Generated at 2022-06-24 21:10:15.349159
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print(str(human_to_bytes('1', 'B')) == str(1))
    print(str(human_to_bytes('1', 'b', True)) == str(1))
    print(str(human_to_bytes('1', 'M')) == str(1000000))
    print(str(human_to_bytes('1', 'M', True)) == str(1000000))
    print(str(human_to_bytes('1MB')) == str(1048576))
    print(str(human_to_bytes('1MB', True)) == str(1048576))
    print(str(human_to_bytes('1Mb', True)) == str(1048576))
    print(str(human_to_bytes('1KB')) == str(1024))

# Generated at 2022-06-24 21:10:22.806756
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(10, unit='B') == '10.00 Bytes'
    assert bytes_to_human(10) == '10.00 Bytes'
    assert bytes_to_human(10, unit='b') == '80.00 bits'
    assert bytes_to_human(10, unit='b', isbits=True) == '80.00 bits'
    assert bytes_to_human(10, isbits=True) == '80.00 bits'

    assert bytes_to_human(1024, unit='B') == '1024.00 Bytes'
    assert bytes_to_human(1024, isbits=True) == '8192.00 bits'
    assert bytes_to_human(1024, unit='b', isbits=True) == '8192.00 bits'


# Generated at 2022-06-24 21:10:34.531931
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1) == '1 Bytes'
    assert bytes_to_human(2) == '2 Bytes'
    assert bytes_to_human(1024) == '1 KB'
    assert bytes_to_human(1024*1024) == '1 MB'
    assert bytes_to_human(1024*1024*1024) == '1 GB'
    assert bytes_to_human(1024*1024*1024*1024) == '1 TB'
    assert bytes_to_human(1024*1024*1024*1024*1024) == '1 PB'
    assert bytes_to_human(1024*1024*1024*1024*1024*1024) == '1 EB'
    assert bytes_to_human(1024*1024*1024*1024*1024*1024*1024) == '1 ZB'

# Generated at 2022-06-24 21:10:41.496562
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase('\n    For this test program, call function lenient_lowercase()\n    ') == ['\n    for this test program, call function lenient_lowercase()\n    ']
    assert lenient_lowercase(['A','B','C','D','E','F','G','H','I','J']) == ['a','b','c','d','e','f','g','h','i','j']

# Generated at 2022-06-24 21:10:54.076116
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase('') == [], 'input string is empty'
    assert lenient_lowercase(['Hi']) == ['hi'], 'input list contains string'
    assert lenient_lowercase([1,2,3]) == [1,2,3], 'input list contains numbers'
    assert lenient_lowercase([1,'Hi',3]) == [1,'hi',3], 'input list contains both string and numbers'
    assert lenient_lowercase([1, 'Hi', '', 3, False, True]) == [1, 'hi', '', 3, False, True], 'input list contains numbers, string, boolean and null'
    assert lenient_lowercase(["Hi", "Yo", "My"]) == ["hi", "yo", "my"], 'input list contains multiple string'

# Generated at 2022-06-24 21:10:59.394861
# Unit test for function human_to_bytes
def test_human_to_bytes():

    print('\n--- Start unit test for function human_to_bytes() ---')

    try:
        int_0 = human_to_bytes('\n    For this test program, call function lenient_lowercase()\n    ', '', False)
    except Exception as e:
        print('\nFunction human_to_bytes() unit test failed: ', e)
    else:
        print('\nFunction human_to_bytes() unit test successful ', int_0)

    try:
        int_0 = human_to_bytes(str(''), str(''), False)
    except Exception as e:
        print('\nFunction human_to_bytes() unit test failed: ', e)
    else:
        print('\nFunction human_to_bytes() unit test successful ', int_0)


# Generated at 2022-06-24 21:11:08.561944
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # unit
    str_2 = '2'
    str_2B = '2B'
    str_2K = '2K'
    str_2M = '2M'
    str_2G = '2G'
    str_2TB = '2TB'
    str_2E = '2E'
    str_2P = '2P'
    str_2Z = '2Z'
    str_2Y = '2Y'
    str_2b = '2b'
    str_2Kb = '2Kb'
    str_2Mb = '2Mb'
    # float number
    str_2point5 = '2.5'
    str_2point5K = '2.5K'
    str_2point5Kb = '2.5Kb'


# Generated at 2022-06-24 21:11:12.371454
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = ['A', 'b', 'c', 1, 2, 3]
    result_list = ['a', 'b', 'c', 1, 2, 3]
    assert lenient_lowercase(test_list) == result_list


# Generated at 2022-06-24 21:11:20.376558
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # subtest 00
    try:
        human_to_bytes(str_0)
    except TypeError as e:
        print("Subtest 00 failed: " + str(e))
    else:
        print("Subtest 00 passed")

    # subtest 01
    if human_to_bytes(1) != 1:
        print("Subtest 01 failed")
        print("\tReturned " + str(human_to_bytes(1)) + " instead of 1")
    else:
        print("Subtest 01 passed")

    # subtest 02
    if human_to_bytes("2K") != 2 * (1 << 10):
        print("Subtest 02 failed")
        print("\tReturned " + str(human_to_bytes("2K")) + " instead of 2048")

# Generated at 2022-06-24 21:11:31.737143
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('13M') == 134217728, "human_to_bytes('13M') != 134217728"
    assert human_to_bytes('13M', isbits=True) == 10485760, "human_to_bytes('13M', isbits=True) != 10485760"
    assert human_to_bytes('13MB') == 134217728, "human_to_bytes('13MB') != 134217728"
    assert human_to_bytes('13MB', isbits=True) == 10485760, "human_to_bytes('13MB', isbits=True) != 10485760"
    assert human_to_bytes('13m') == 134217728, "human_to_bytes('13m') != 134217728"

# Generated at 2022-06-24 21:11:35.802155
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase(['A', 'B', 'C', 'D', 'E', 'F'])
    assert type(result) == list
    assert len(result) == 6
    assert 'a' in result
    assert 'b' in result
    assert 'c' in result
    assert 'd' in result
    assert 'e' in result
    assert 'f' in result


# Generated at 2022-06-24 21:11:45.798013
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Positive test case 0
    str_0 = '\n    For this test program, call function human_to_bytes()\n    '
    ret_0 = human_to_bytes(str_0, 'M', True)
    print(ret_0)
    # Positive test case 1
    str_0 = '\n'
    ret_0 = human_to_bytes(str_0, 'MB', False)
    print(ret_0)
    # Positive test case 2
    str_0 = '10M'
    ret_0 = human_to_bytes(str_0, 'MB', False)
    print(ret_0)
    # Positive test case 3
    str_0 = '10Mb'
    ret_0 = human_to_bytes(str_0, 'Mb', False)

# Generated at 2022-06-24 21:11:54.923383
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert 1048576 == human_to_bytes('1MB')
    assert 1073741824 == human_to_bytes('1GB')
    assert 1099511627776 == human_to_bytes('1TB')
    assert 1125899906842624 == human_to_bytes('1PB')
    assert 1152921504606846976 == human_to_bytes('1EB')
    assert 1180591620717411303424 == human_to_bytes('1ZB')
    assert 1208925819614629174706176 == human_to_bytes('1YB')
    assert 1048576 == human_to_bytes('1048576B', default_unit='B')
    assert 1048576 == human_to_bytes('1048576', default_unit='B')

# Generated at 2022-06-24 21:11:58.478471
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('2.5Mb') == 3145728
    assert human_to_bytes('1.00Kb') == 128
    assert human_to_bytes('-1') == -1
    assert human_to_bytes('-1K') == -1024
    assert human_to_bytes('-1.00Kb') == -128


# Generated at 2022-06-24 21:12:08.568560
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test case 0
    str_0 = '\n    For this test program, call function lenient_lowercase()\n    '
    val_lenient_lowercase_0 = lenient_lowercase(str_0)
    assert val_lenient_lowercase_0 == '\n    for this test program, call function lenient_lowercase()\n    ', 'Expected %s but got %s' % (repr('\n    for this test program, call function lenient_lowercase()\n    '), repr(val_lenient_lowercase_0))


# Generated at 2022-06-24 21:12:18.877208
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # default_unit is not set, it should raise an error
    try:
        human_to_bytes('1')
    except ValueError as e:
        if 'require any unit' not in str(e):
            print('Failed for test for default_unit is not set')
            print('Received: %s\nExpected: require any unit' % (e))
    else:
        assert False, "Expected an exception"

    # isbits is not set, it should equal to 1048576

# Generated at 2022-06-24 21:12:21.324274
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['blah', 1, 'FOO', 'bar']) == ['blah', 1, 'foo', 'bar']



# Generated at 2022-06-24 21:12:32.663281
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['AaAa', 'A', 'a', 'Aa', 'AA']) == ['aaaa', 'A', 'a', 'Aa', 'AA']
    assert lenient_lowercase(['AaAa', 'A', 'a', 'Aa', 'AA', 7]) == ['aaaa', 'A', 'a', 'Aa', 'AA', 7]
    assert lenient_lowercase(['AaAa', 'A', 'a', 'Aa', 'AA', 'a']) == ['aaaa', 'A', 'a', 'Aa', 'AA', 'a']

# Generated at 2022-06-24 21:12:43.449437
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # pass an int as a param
    assert human_to_bytes(100) == 100
    # pass a string without a number
    try:
        human_to_bytes('')
    except ValueError as e:
        assert "can't interpret following string" in str(e)
    # pass a string with a number and 'Mb' as a unit
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    # pass a string with a number and 'MB' as a unit
    try:
        human_to_bytes('1MB', isbits=True)
    except ValueError as e:
        assert "expect Mb or bit" in str(e)
    # pass a string with a number and 'b' as a unit

# Generated at 2022-06-24 21:12:54.722975
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB', isbits=True) == 1048576
    assert human_to_bytes('16K') == 16384
    assert human_to_bytes('16KB') == 16384
    assert human_to_bytes('16Kb') == 16384
    assert human_to_bytes('16KB', isbits=True) == 16384
    assert human_to_bytes('0') == 0
    assert human_to_bytes('0B') == 0
    assert human_to_bytes('0b') == 0
    assert human_to_bytes('0b', isbits=True) == 0
    assert human

# Generated at 2022-06-24 21:13:02.800828
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_cases = {
        '1': 1,
        '2K': 2048,
        '2k': 2048,
        '2KB': 2048,
        '2kb': 2048,
        '2M': 2097152,
        '2MB': 2097152,
        '2mb': 2097152,
        '2G': 2147483648,
        '2GB': 2147483648,
        '2gb': 2147483648,
        '2T': 2199023255552,
        '2TB': 2199023255552,
        '2tb': 2199023255552,
    }
    for input_str, expected_bytes in test_cases.items():
        result = human_to_bytes(input_str)
        assert result == expected_bytes


# Generated at 2022-06-24 21:13:12.665630
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test cases
    str_1 = "1234"
    str_2 = "1234kB"
    str_3 = "1234KB"
    str_4 = "1234Kb"
    str_5 = "1234kb"

    str_6 = "1234Mb"
    str_7 = "1234MB"
    str_8 = "1234Mb"
    str_9 = "1234mb"

    str_10 = "1234b"
    str_11 = "1234B"

    # Output
    out_1 = str_1
    out_2 = str_2
    out_3 = str_3
    out_4 = str_4
    out_5 = str_5

    out_6 = str_6
    out_7 = str_7
    out_8

# Generated at 2022-06-24 21:13:21.367320
# Unit test for function human_to_bytes

# Generated at 2022-06-24 21:13:25.378192
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_list = [0, 1, 2, 'TEST', 'TEST22', ('TesT', u'TEST', 'TEST33')]
    test_result = lenient_lowercase(test_list)
    expected_result = [0, 1, 2, 'test', 'test22', ('TesT', u'test', 'test33')]

    return test_result == expected_result


# Generated at 2022-06-24 21:13:36.546020
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes(1, 'b') == 1
    assert human_to_bytes(1, 'b', isbits=True) == 1
    assert human_to_bytes(1, 'bit') == 1
    assert human_to_bytes(1, 'bit', isbits=True) == 1
    assert human_to_bytes('10MB', isbits=True) == 10485760
    assert human_to_bytes('10Mb') == 10485760
    try:
        human_to_bytes('10Mb', isbits=True)
    except ValueError:
        pass
    else:
        assert False

    # errors in string


# Generated at 2022-06-24 21:13:44.992184
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    temp_0 = ()
    str_0 = '\n    For this test program, call function lenient_lowercase()\n    '
    result_0 = lenient_lowercase(str_0)
    temp_0 += (result_0,)
    str_1 = '\n    For this test program, call function lenient_lowercase()\n    '
    result_1 = lenient_lowercase(str_1)
    temp_0 += (result_1,)
    str_2 = '\n    For this test program, call function lenient_lowercase()\n    '
    result_2 = lenient_lowercase(str_2)
    temp_0 += (result_2,)
    result = temp_0
    return result


# Generated at 2022-06-24 21:13:48.239338
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['abc', 'def', 'ghi']) == ['abc', 'def', 'ghi']
    assert lenient_lowercase(['abc', 'def', 42]) == ['abc', 'def', 42]
    test_case_0()


# Generated at 2022-06-24 21:13:59.147388
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1b', isbits=True) == 1)
    assert(human_to_bytes('1B', isbits=True) == 1)
    assert(human_to_bytes('1b') == 1)
    assert(human_to_bytes('1B') == 1)
    assert(human_to_bytes('1bit') == 1)
    assert(human_to_bytes('1Bit') == 1)
    assert(human_to_bytes('1byte') == 1)
    assert(human_to_bytes('1Byte') == 1)
    assert(human_to_bytes('1') == 1)
    assert(human_to_bytes('2.5M') == int(2.5 * (1 << 20)))

# Generated at 2022-06-24 21:14:10.850506
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # default unit is byte
    assert(human_to_bytes("10G") == 10737418240)
    # string byte representation ('KB') was passed
    assert(human_to_bytes("10KB") == 10240)
    # string bit representation ('Kb') was passed
    assert(human_to_bytes("10Kb", True) == 10240)
    # string with bit identifier (B) was passed
    assert(human_to_bytes("10B") == 10)
    # string with bit identifier (b) was passed
    assert(human_to_bytes("10b", True) == 10)
    # string without identifier was passed
    assert(human_to_bytes("10") == 10)
    # string with identifier (E) was passed
    assert(human_to_bytes("10E") == 100000000000000000)
    # string

# Generated at 2022-06-24 21:14:22.158854
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # test case 0
    str_0 = "10M"
    result_0 = human_to_bytes(str_0)
    if(1048576 == result_0):
        assert True
    else:
        assert False

    # test case 1
    str_1 = '10Mb'
    result_1 = human_to_bytes(str_1, isbits=True)
    if(1048576 == result_1):
        assert True
    else:
        assert False

    # test case 2
    str_2 = '10Mb'
    result_2 = human_to_bytes(str_2)
    if(1048576 == result_2):
        assert True
    else:
        assert False

    # test case 3
    str_3 = '10Ma'
    result_3 = human_to

# Generated at 2022-06-24 21:14:30.772611
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1M', unit='K') == 1024
    assert human_to_bytes('1m', isbits=True) == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('1Mb', unit='kb', isbits=True) == 1024
    assert human_to_bytes('1M', unit='kb') == 1024
    assert human_to_bytes('1M', unit='Kb') == 8388608

    # this should always return None
    assert human_to_bytes(None) is None
    assert human_to_bytes('') is None
    assert human_to_bytes(None, 'M') is None

# Generated at 2022-06-24 21:14:33.669160
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    # test case 0
    str_0 = '\n    For this test program, call function lenient_lowercase()\n    '
    print(lenient_lowercase(str_0))

    # test case 1
    str_1 = '\n    For this test program, call function lenient_lowercase()\n    '
    print(lenient_lowercase(str_1))

# Generated at 2022-06-24 21:14:40.254327
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(["Axa", "aAaA", "AAaA", 9, {9: 9}, ["AxA"]]) == ["axa", "aa", "aa", 9, {9: 9}, ["AxA"]]


# Generated at 2022-06-24 21:14:49.120261
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test byte conversion
    # Test string input with unit identifier
    assert human_to_bytes('10M') == 10485760
    # Test string input with unit identifier
    assert human_to_bytes('10MB') == 10485760

    # Test string input without unit identifier, using default unit
    assert human_to_bytes('10', 'MB') == 10485760

    # Test string input with unit identifier in lowercase
    assert human_to_bytes('2k') == 2048

    # Test decimal number string without unit identifier, using default unit
    assert human_to_bytes('20.48', 'MB') == 214958080

    # Test decimal number string without unit identifier, using default unit
    assert human_to_bytes(20.48, 'MB') == 214958080

    # Test number input with default unit
    assert human_

# Generated at 2022-06-24 21:15:01.976851
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_str_0 = '1Mb'
    test_str_1 = '1MB'
    test_str_2 = '2Kb'
    test_str_3 = '2KB'
    test_str_4 = '1b'
    test_str_5 = '1B'
    test_str_6 = '2b'
    test_str_7 = '2B'
    test_str_8 = '3b'
    test_str_9 = '3B'
    test_str_10 = '1Mb'
    test_str_11 = '1MB'
    test_str_12 = '2Kb'
    test_str_13 = '2KB'
    test_str_14 = '1b'
    test_str_15 = '1B'
    test_

# Generated at 2022-06-24 21:15:12.303851
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('Starting function: human_to_bytes()')
    h2b = human_to_bytes
    assert h2b(10, 'M') == 10485760, 'Error: Failed for 10M'
    assert h2b('10M') == 10485760, 'Error: Failed for \'10M\''
    assert h2b('10MB') == 10485760, 'Error: Failed for \'10MB\''
    assert h2b('10Mb', isbits=True) == 134217728, 'Error: Failed for \'10Mb\''
    assert h2b(10, 'm', isbits=True) == 134217728, 'Error: Failed for 10m'

# Generated at 2022-06-24 21:15:23.459856
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # Testing for positive integer value with positive and negative test. For positive test,
    # we are checking whether the output is correct or not.
    # For negative test, we are checking whether the exception
    # ValueError is raised or not.

    # Positive test case
    assert human_to_bytes('1Mb') == 1048576

    # Negative test case
    try:
        human_to_bytes('1.1Mb')
        assert False
    except Exception:
        assert True

    # Positive test case
    assert human_to_bytes('1.0Mb') == 1048576

    # Negative test case
    try:
        human_to_bytes('1.0Mb', 'Kb')
        assert False
    except Exception:
        assert True

    # Positive test case
    assert human_to_bytes('1.0')

# Generated at 2022-06-24 21:15:35.681161
# Unit test for function human_to_bytes
def test_human_to_bytes():

    print(human_to_bytes('10M'))
    print(human_to_bytes(10, 'M'))
    print(human_to_bytes('10M', default_unit='K'))
    print(human_to_bytes(10, default_unit='K'))

    value = human_to_bytes('10Mb', isbits=True)
    print(value)

    value = human_to_bytes('10B', isbits=True)
    print(value)

    value = human_to_bytes(10, unit='MB')
    print(value)
    print(bytes_to_human(value))

    value = human_to_bytes('10Mb')
    print(value)
    print(bytes_to_human(value))


# Generated at 2022-06-24 21:15:40.952401
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10K') == 10 * 2**10
    assert human_to_bytes(10, 'K') == 10 * 2**10
    assert human_to_bytes('10K') == 10 * 2**10
    assert human_to_bytes(10, 'K', isbits=True) == 10 * 2**10
    assert human_to_bytes('10Kb', isbits=True) == 10 * 2**10

# Generated at 2022-06-24 21:15:48.372891
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Function test for function human_to_bytes
    str_0 = '\n    For this test program, call function human_to_bytes()\n    '
    str_1 = '\n    For each test case, if the case is passed, print "OK".\n    '
    test_str = str_0 + str_1
    print(test_str)
    res_0 = human_to_bytes('10', default_unit='M')
    res_1 = human_to_bytes('10M')
    res_2 = human_to_bytes('10Mb', isbits=True)
    res_3 = human_to_bytes('10Mb')
    # case_0:
    str_case0 = 'Test case 0: 10M'
    print(str_case0)

# Generated at 2022-06-24 21:15:50.468049
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([]) == []
    l = ['string', 'String', 'STRING', '123', 123, (1, 2, 3), {'a': 1}]
    assert lenient_lowercase(l) == ['string', 'string', 'string', '123', 123, (1, 2, 3), {'a': 1}]



# Generated at 2022-06-24 21:15:54.053542
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    str_input = ['\n    For this test program, call function lenient_lowercase()\n    ']
    result = lenient_lowercase(str_input)
    print('This is the result: ', result)


# Generated at 2022-06-24 21:16:01.622709
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    """
    unit test function: execute lenient_lowercase()
    """
    str0 = '\n    For this test program, call function lenient_lowercase()\n    '
    assert lenient_lowercase(str0) == str0.lower()
    str1 = str0.lower()
    assert lenient_lowercase(str1) == str1
    list0 = ['\n    For this test program, call function lenient_lowercase()\n    ']
    assert lenient_lowercase(list0) == list0[0].lower()
    list1 = [list0[0].lower()]
    assert lenient_lowercase(list1) == list1
    tuple0 = ('\n    For this test program, call function lenient_lowercase()\n    ',)

# Generated at 2022-06-24 21:16:09.516849
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert 4 == human_to_bytes(4)
    assert 128 == human_to_bytes(128)
    assert 1024 == human_to_bytes(1024)
    assert 1024 == human_to_bytes('1k')
    assert 1024 == human_to_bytes('1K')
    assert 1024 == human_to_bytes('1K', isbits=False)
    assert 2048 == human_to_bytes('1K', isbits=True)
    assert 98304 == human_to_bytes('1M')
    assert 1048576 == human_to_bytes('1M', isbits=False)
    assert 7864320 == human_to_bytes('1M', isbits=True)
    assert 1048576 == human_to_bytes('1 MB')
    assert 1073741824 == human_to_bytes('1GB')
    assert 10995

# Generated at 2022-06-24 21:16:17.294683
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()


# Generated at 2022-06-24 21:16:22.537960
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    str_0 = '\n    For this test program, call function lenient_lowercase()\n    '
    assert lenient_lowercase(str_0) == '\n    for this test program, call function lenient_lowercase()\n    ', "Function 'lenient_lowercase()' does not return expected results"



# Generated at 2022-06-24 21:16:26.715381
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    str_0 = '\n    For this test program, call function lenient_lowercase()\n    '
    result_0 = lenient_lowercase(str_0)
    assert result_0 == '\n    for this test program, call function lenient_lowercase()\n    '


# Generated at 2022-06-24 21:16:32.715081
# Unit test for function human_to_bytes
def test_human_to_bytes():
    #  test1
    assert human_to_bytes('2K') == '2048'

    #  test2
    assert human_to_bytes('1M') == '1048576'

    #  test3
    assert human_to_bytes('1.3M') == '1376256'

    #  test4
    assert human_to_bytes('1.25M') == '1310720'

    #  test5
    assert human_to_bytes('1.5M') == '1572864'

    #  test6
    assert human_to_bytes('1B') == '1'

    #  test7
    assert human_to_bytes('2K', 'B') == '2048'

    #  test8
    assert human_to_bytes('1M') == '1048576'

    #

# Generated at 2022-06-24 21:16:44.869661
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2k') == 2048
    assert human_to_bytes('2k', 'B') == 2048
    assert human_to_bytes('2kB') == 2048
    assert human_to_bytes('2k', 'B') == 2048
    assert human_to_bytes('2Kb') == 2048 * 8
    assert human_to_bytes('2Kb', 'b') == 2048 * 8
    assert human_to_bytes('2kb', 'b') == 2048 * 8
    assert human_to_bytes('2kb', isbits=True) == 2048 * 8
    assert human_to_bytes('2kb', isbits=False) == 2048
    assert human_to_bytes('2kb', 'b', isbits=True) == 2048 * 8