

# Generated at 2022-06-24 21:07:02.810603
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("Testing function human_to_bytes")
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1kb', isbits=True) == 1024
    assert human_to_bytes('0.8K') == 819
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1m', isbits=True) == 1048576
    assert human_to_bytes('0.8M') == 838860
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1g') == 1073741824
    assert human_to_bytes('1g', isbits=True) == 107

# Generated at 2022-06-24 21:07:08.367790
# Unit test for function human_to_bytes
def test_human_to_bytes():
    #  Invalid string passed, raises ValueError
    try:
        human_to_bytes('this is a test')
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError')

    #  Invalid string passed, raises ValueError
    try:
        human_to_bytes('-10B')
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError')

    #  Invalid size range key passed, raises ValueError
    try:
        human_to_bytes('10B', default_unit='S')
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError')

    #  Valid string passed, correctly handled

# Generated at 2022-06-24 21:07:18.204231
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1, 'Error: unexpected answer'
    assert human_to_bytes('1K') == 1024, 'Error: unexpected answer'
    assert human_to_bytes('1M') == 1048576, 'Error: unexpected answer'
    assert human_to_bytes('1G') == 1073741824, 'Error: unexpected answer'
    assert human_to_bytes('1T') == 1099511627776, 'Error: unexpected answer'
    assert human_to_bytes('1P') == 1125899906842624, 'Error: unexpected answer'
    assert human_to_bytes('1E') == 1152921504606846976, 'Error: unexpected answer'
    assert human_to_bytes('1Z') == 1180591620717411303424, 'Error: unexpected answer'


# Generated at 2022-06-24 21:07:28.476827
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print('Testcase 1: human_to_bytes():')
    print('Test: #1')
    print('Input: "10M"')
    print('Expected Output: 10485760')
    print('Actual Output:', human_to_bytes('10M'))
    print('Test: #2')
    print('Input: "1.5M"')
    print('Expected Output: 1572864')
    print('Actual Output:', human_to_bytes('1.5M'))
    print('Test: #3')
    print('Input: "1.5M1B"')
    print('Expected Output: 1572865')
    print('Actual Output:', human_to_bytes('1.5M1B'))
    print('Test: #4')

# Generated at 2022-06-24 21:07:35.052926
# Unit test for function bytes_to_human
def test_bytes_to_human():
    assert bytes_to_human(1, False) == '1 Byte'
    assert bytes_to_human(1, True) == '1 bit'
    assert bytes_to_human(1, False, 'B') == '1 Byte'
    assert bytes_to_human(1, True, 'b') == '1 bit'
    assert bytes_to_human(1, False, 'b') == ValueError
    assert bytes_to_human(1, True, 'B') == ValueError
    assert bytes_to_human(1, True, 'K') == '0.00 Kbits'
    assert bytes_to_human(1, False, 'k') == '0.00 KBytes'


# Generated at 2022-06-24 21:07:45.691670
# Unit test for function bytes_to_human
def test_bytes_to_human():
    result = bytes_to_human(1, isbits=False, unit='K')
    assert result == '0.00 KBytes'
    result = bytes_to_human(1, isbits=False, unit='b')
    assert result == '0.00 Bytes'
    result = bytes_to_human(1, isbits=False, unit='M')
    assert result == '0.00 MBytes'
    result = bytes_to_human(1024, isbits=False, unit='K')
    assert result == '1.00 KBytes'
    result = bytes_to_human(1048576, isbits=False, unit='M')
    assert result == '1.00 MBytes'
    result = bytes_to_human(1073741824, isbits=False, unit='G')

# Generated at 2022-06-24 21:07:46.727832
# Unit test for function human_to_bytes
def test_human_to_bytes():
    pass


# Generated at 2022-06-24 21:07:55.407420
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b', isbits=True) == 10
    assert human_to_bytes('10Kb', isbits=True) == 10240
    assert human_to_bytes('10 Mb', isbits=True) == 10485760
    assert human_to_bytes('10 Mb') == 10485760
    assert human_to_bytes('10 MB') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10Mb') == 10485760
    assert human_to_bytes('10 MB', isbits=True) == 10485760

# Generated at 2022-06-24 21:07:57.373115
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    with pytest.raises(AttributeError) as excinfo:
        test_case_0()
    the_exception = excinfo.value
    assert the_exception
    assert 'has no attribute' in str(the_exception)


# Generated at 2022-06-24 21:08:02.350580
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = -818
    var_0 = lenient_lowercase(int_0)
    assert var_0 == -818

    str_0 = 'sTkX'
    var_0 = lenient_lowercase(str_0)
    assert var_0 == 'stkx'


# Generated at 2022-06-24 21:08:13.548441
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    var_0 = []
    var_1 = ['','','','','','','','','','','']
    var_2 = ['','','','','','','','','']
    var_3 = ['']
    var_4 = ['','','','','','','','','','','']
    var_5 = ['','','','','','','','','']
    var_6 = ['']
    var_7 = ['','','','','','','','','','','']
    var_8 = ['','','','','','','','','']
    var_9 = ['']
    var_10 = ['','','','','','','','','','','']
    var_11 = ['','','','','','','','','']
    var_12 = ['']

# Generated at 2022-06-24 21:08:20.085579
# Unit test for function human_to_bytes

# Generated at 2022-06-24 21:08:25.074396
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Test for function human_to_bytes"""

    # assert human_to_bytes('0') == 0
    # assert human_to_bytes('10') == 10
    # assert human_to_bytes('1M') == 1048576
    # assert human_to_bytes('1M', 'Mb') == 1048576
    # assert human_to_bytes('1M', 'MB') == 1048576
    # assert human_to_bytes('1Mb', 'Mb') == 1048576
    # assert human_to_bytes('1Mb', 'MB') == 1048576
    # assert human_to_bytes('1mB', 'MB') == 1048576
    # assert human_to_bytes('1MB', 'MB') == 1048576
    # assert human_to_bytes('1mB') == 1048576

# Generated at 2022-06-24 21:08:34.994882
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1e3, 'b') == 8192
    assert human_to_bytes('1e3') == 1e3
    assert human_to_bytes('1e3', unit='b') == 8192 # Should be: '10Mbit = 8MBytes'
    assert human_to_bytes(1e3, unit='b') == 8192
    assert human_to_bytes('10GB') == 10 * (1 << 30)
    assert human_to_bytes(10, 'GB') == 10 * (1 << 30)
    assert human_to_bytes('10Gb') == 10 * (1 << 30)
    assert human_to_bytes('10GB', isbits=True) == 10 * (1 << 30)

# Generated at 2022-06-24 21:08:36.269567
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_case_0()



# Generated at 2022-06-24 21:08:41.650019
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10k') == 10240
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'k') == 10240
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('10kb') == 10240
    assert human_to_bytes('2Mb') == 2097152
    assert human_to_bytes('2kb') == 2048


# Generated at 2022-06-24 21:08:44.837467
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    var_0 = ['Pi', 'is', 3.14]
    expected = ['pi', 'is', 3.14]
    assert lenient_lowercase(var_0) == expected


# Generated at 2022-06-24 21:08:50.639226
# Unit test for function human_to_bytes

# Generated at 2022-06-24 21:09:00.239707
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(0 == human_to_bytes("0"))
    assert(0 == human_to_bytes("0B"))
    assert(1 == human_to_bytes("1"))
    assert(1 == human_to_bytes("1b", isbits=True))
    assert(1 == human_to_bytes("1B"))
    assert(1 == human_to_bytes("1b"))
    assert(1023 == human_to_bytes("1023"))
    assert(1023 == human_to_bytes("1023b", isbits=True))
    assert(1023 == human_to_bytes("1023B"))
    assert(1023 == human_to_bytes("1023b"))
    assert(1023 == human_to_bytes("1023.0b", isbits=True))

# Generated at 2022-06-24 21:09:06.952332
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1024) == 1024
    assert human_to_bytes(1024, default_unit='b') == 1024
    assert human_to_bytes('1M', default_unit='B') == 1048576
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1KB') == 1024 * 1024
    assert human_to_bytes('1Mb') == 1024 * 1024
    assert human_to_bytes('1G', isbits=True) == 1024 * 1024 * 1024
    assert human_to_bytes('1.5G', isbits=True) == (1024 * 1024 * 1024) + (1024 * 1024 * 512)
    assert human_to_bytes('1.5G', isbits=False) == (1024 * 1024 * 1024) + (1024 * 1024 * 512)
    assert human_to

# Generated at 2022-06-24 21:09:15.028871
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1.1M') == 1146880
    assert human_to_bytes('1.23M') == 1289984
    assert human_to_bytes('1.1Mb', isbits=True) == 1146880
    assert human_to_bytes('1.23Mb', isbits=True) == 1289984
    assert human_to_bytes('1.1MB', isbits=True) == human_to_bytes('1.1Mb', isbits=True)
    assert human_to_bytes('1.23MB', isbits=True) == human_to_bytes('1.23Mb', isbits=True)
    assert human_to_bytes('1.1MB') == human_to_bytes('1.1M')

# Generated at 2022-06-24 21:09:26.427243
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(12) == [12]
    assert lenient_lowercase('HELLO') == ['hello']
    assert lenient_lowercase('hello') == ['hello']
    assert lenient_lowercase(['hello', 'A', 'a', 'B', 'b', 'C']) == ['hello', 'A', 'a', 'B', 'b', 'C']
    assert lenient_lowercase(['hello', 'A', 12, 'B', 'b', 'C']) == ['hello', 'A', 12, 'B', 'b', 'C']

# Generated at 2022-06-24 21:09:37.758618
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('2MB') == 2097152
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('2GB') == 2147483648
    assert human_to_bytes('1TB') == 1099511627776
    assert human_to_bytes('2TB') == 2199023255552
    assert human_to_bytes('2.5GB') == 2684354560
    assert human_to_bytes('1Mb', True) == 1048576
    assert human_to_bytes('1Gb', True) == 1073741824
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1Gb') == 1073741824
    assert human

# Generated at 2022-06-24 21:09:48.039176
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # First test case (human_to_bytes('10M') <=> human_to_bytes(10, 'M'))
    # First test case with 'input as bytes'
    assert human_to_bytes(10, 'M') == human_to_bytes('10M')
    # First test case with default_unit argument
    assert human_to_bytes(10, default_unit='M') == human_to_bytes('10M')
    # First test case with decimal
    assert human_to_bytes(1.5, 'M') == human_to_bytes('1.5M')
    assert human_to_bytes(1.5, default_unit='M') == human_to_bytes('1.5M')
    # First test case with negative numbers
    assert human_to_bytes(-1.5, 'M') == human_to

# Generated at 2022-06-24 21:09:58.101791
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = human_to_bytes('42G')
    assert result == 45097156608
    result = human_to_bytes('1.1K')
    assert result == 1126
    result = human_to_bytes('KG', default_unit='B')
    assert result == 1024
    result = human_to_bytes('KB', default_unit='B')
    assert result == 1000
    result = human_to_bytes('MB', default_unit=None)
    assert result == 1048576
    result = human_to_bytes('Mb', isbits=True)
    assert result == 1048576
    result = human_to_bytes('10Mb', isbits=True)
    assert result == 10485760
    result = human_to_bytes('10', unit='Mb')
    assert result == 10485760


# Generated at 2022-06-24 21:10:05.531824
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['a', 'b', 'C'] == ['a', 'b', 'c'])
    assert lenient_lowercase([1, 'a', 'b', 'C'] == [1, 'a', 'b', 'c'])
    assert lenient_lowercase(['a', 'A', 'aAa'] == ['a', 'a', 'aAa'])
    assert lenient_lowercase(['a', 2, 'A'] == ['a', 2, 'a'])
    assert lenient_lowercase(['a', [], 'A'] == ['a', [], 'a'])


# Generated at 2022-06-24 21:10:10.190302
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes(3.14, default_unit='G') == 3.14e+09
    assert human_to_bytes('2Mb', isbits=True) == 2097152


# Generated at 2022-06-24 21:10:16.889517
# Unit test for function human_to_bytes
def test_human_to_bytes():

    try:
        human_to_bytes('')
        assert False
    except ValueError as ve:
        assert str(ve) == "human_to_bytes() can't interpret following string: "
        print("Test case 0 passed")

    try:
        human_to_bytes(None)
        assert False
    except ValueError as ve:
        assert str(ve) == "human_to_bytes() can't interpret following string: None"
        print("Test case 1 passed")

    try:
        human_to_bytes('1M', isbits=True)
        assert False
    except ValueError as ve:
        assert str(ve) == "human_to_bytes() failed to convert 1M (unit = M). The suffix must be one of Y, Z, E, P, T, G, M, 'K', B"
        print

# Generated at 2022-06-24 21:10:23.840610
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("***** Unit Test for function human_to_bytes *****")
    print("Test of human_to_bytes function with valid string as input")
    assert human_to_bytes("1M") == 1048576
    assert human_to_bytes("1b") == 1
    assert human_to_bytes("1kb") == 1024
    assert human_to_bytes("1kb", isbits=True) == 1000
    assert human_to_bytes("1Tb", isbits=True) == 1000000000000
    assert human_to_bytes("1", default_unit="k") == 1024
    assert human_to_bytes("1", default_unit="k", isbits=True) == 1000
    assert human_to_bytes("1", default_unit="b") == 1
    print("Test of human_to_bytes function with invalid string as input")

# Generated at 2022-06-24 21:10:28.170226
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Passed arguments
    speed = '10Mb'
    # Expected return value
    expReturn = 10485760
    # Call the function
    retValue = human_to_bytes(speed)
    # Return value check
    assert retValue == expReturn


# Generated at 2022-06-24 21:10:35.034905
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    # Positive test of lenient_lowercase
    test_case_0()

    # Negative test of lenient_lowercase
    try:
        test_case_0()
    except Exception as e:
        if not isinstance(e, TypeError):
            print('Test case failed, incorrect Exception thrown')
            raise



# Generated at 2022-06-24 21:10:45.726252
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.3K') == 1327
    assert human_to_bytes('1.3k') == 1327
    assert human_to_bytes('1.3M') == 1363148
    assert human_to_bytes('1.3G') == 137438953472
    assert human_to_bytes('1.3T') == 13953726574011
    assert human_to_bytes('1.3P') == 1416869000755968
    assert human_to_bytes('1.3E') == 1441151898800868992
    assert human_to_bytes('1.3Z') == 14671858948638048256
    assert human_to_bytes('1.3Y') == 149321949568014628864

# Generated at 2022-06-24 21:10:53.901006
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('0') == 0 == human_to_bytes('0', unit='B') == human_to_bytes('0', unit='K')
    assert human_to_bytes('1') == 1 == human_to_bytes('1', unit='B') == human_to_bytes('1', unit='K')
    assert human_to_bytes('-1') == -1 == human_to_bytes('-1', unit='B') == human_to_bytes('-1', unit='K')
    assert human_to_bytes(1) == 1 == human_to_bytes(1, unit='B') == human_to_bytes(1, unit='K')
    assert human_to_bytes(-1) == -1 == human_to_bytes(-1, unit='B') == human_to_bytes(-1, unit='K')

# Generated at 2022-06-24 21:10:59.278685
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Unit tests for human_to_bytes"""
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1b', isbits=True) == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.5B') == 2
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 16777216
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 172837977472220160
    assert human

# Generated at 2022-06-24 21:11:00.655175
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    for i in range(10):
        test_case_0()

# Generated at 2022-06-24 21:11:08.628505
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # no value passed
    try:
        human_to_bytes()
    except Exception as e:
        assert isinstance(e, TypeError)

    # integer value is passed
    int_0 = -818
    try:
        human_to_bytes(int_0)
    except Exception as e:
        assert isinstance(e, ValueError)

    # float value is passed
    float_0 = -51.59
    assert human_to_bytes(float_0) == -51

    # string value is passed
    str_0 = 'bye'
    try:
        human_to_bytes(str_0)
    except Exception as e:
        assert isinstance(e, ValueError)

    # string value is passed
    str_1 = '12GB'

# Generated at 2022-06-24 21:11:17.601367
# Unit test for function human_to_bytes
def test_human_to_bytes():
    int_0 = "1K"
    ret_0 = human_to_bytes(int_0)
    if ret_0 != 1024:
        raise Exception('Wrong answer')
    int_1 = "1Kb"
    ret_1 = human_to_bytes(int_1, isbits=True)
    if ret_1 != 1024:
        raise Exception('Wrong answer')
    int_2 = "1Kb"
    ret_2 = human_to_bytes(int_2, isbits=True)
    if ret_2 != 1024:
        raise Exception('Wrong answer')
    int_3 = "1KB"
    ret_3 = human_to_bytes(int_3)
    if ret_3 != 1024:
        raise Exception('Wrong answer')
    int_4 = "1MB"
   

# Generated at 2022-06-24 21:11:20.861257
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('0') == 0
    assert human_to_bytes('100') == 100
    assert human_to_bytes('1.6M') == 1600000
    assert human_to_bytes('2.5k') == 2560



# Generated at 2022-06-24 21:11:32.184430
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("134") == 134
    assert human_to_bytes("134.64") == 135
    assert human_to_bytes("134b") == 134
    assert human_to_bytes("134B") == 134
    assert human_to_bytes("134MB") == 142606336
    assert human_to_bytes("134Gb") == 14987980800
    assert human_to_bytes("1M") == 1048576
    assert human_to_bytes("1M", default_unit='M') == 1048576
    assert human_to_bytes("1.1k") == 1024
    assert human_to_bytes("1.1k", default_unit='M') == 1024
    assert human_to_bytes("1.1K") == 1024

# Generated at 2022-06-24 21:11:40.596892
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K', 'B') == 2048
    assert human_to_bytes('1.5M', 'B') == 1572864
    assert human_to_bytes('2.5k', 'B') == 2560
    assert human_to_bytes('1.5G', 'B') == 1610612736
    assert human_to_bytes('1m', 'B') == 1048576
    assert human_to_bytes('2G') == 2147483648
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5Mb', isbits=True) == 1572864
    assert human_to_bytes('1.5Mb', isbits=True, default_unit='b') == 1572864

# Generated at 2022-06-24 21:11:53.205627
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # Example from module docs
    assert human_to_bytes('1Ki') == 1024

    # Negative numbers
    assert human_to_bytes('-1Ki') == -1024

    # no unit - return integer
    assert human_to_bytes('10') == 10

    # Fractions from 1 to 10
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1.5
    assert human_to_bytes('2') == 2
    assert human_to_bytes('3') == 3
    assert human_to_bytes('4') == 4
    assert human_to_bytes('5') == 5
    assert human_to_bytes('6') == 6
    assert human_to_bytes('7') == 7
    assert human_to_bytes('8') == 8
    assert human_

# Generated at 2022-06-24 21:12:03.543431
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Unit test for human_to_bytes.
    '''
    # Default unit case
    int_0 = '10M'
    var_0 = human_to_bytes(int_0)
    assert var_0 == 10485760
    # Default unit case, with unit argument
    int_0 = 10
    str_0 = 'M'
    var_0 = human_to_bytes(int_0, str_0)
    assert var_0 == 10485760
    # Lowercase check
    int_0 = '10mb'
    var_0 = human_to_bytes(int_0, isbits=True)
    assert var_0 == 10485760
    # Byte case
    int_0 = '1B'
    var_0 = human_to_bytes(int_0)
   

# Generated at 2022-06-24 21:12:05.853171
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(-818) == -818
    assert lenient_lowercase('VYz') == 'vyz'


# Generated at 2022-06-24 21:12:12.225085
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Unit test for human_to_bytes()"""
    # Non-string input
    try:
        human_to_bytes(10)
        raise Exception('Exception not thrown')
    except ValueError:
        pass

    # Invalid
    try:
        human_to_bytes('10A')
        raise Exception('Exception not thrown')
    except ValueError:
        pass
    try:
        human_to_bytes('10')
        raise Exception('Exception not thrown')
    except ValueError:
        pass

    # Valid
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10G') == 10737418240
    assert human_to_bytes('10T')

# Generated at 2022-06-24 21:12:19.047247
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2M') == 1048576, "Failed on '2M'"
    assert human_to_bytes('12G') == 12884901888, "Failed on default_unit 'G' ('12G')"
    assert human_to_bytes('2.6T') == 281474976710656, "Failed on '2.6T'"
    assert human_to_bytes('.5P') == 562949953421312, "Failed on '0.5P'"
    assert human_to_bytes(1.5) == 1, "Failed on float"
    assert human_to_bytes(5) == 5, "Failed on int"
    assert human_to_bytes(-5) == -5, "Failed on negative int"

# Generated at 2022-06-24 21:12:30.203988
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # one byte (lowercase 'b')
    assert human_to_bytes(1, default_unit='B') == 1
    assert human_to_bytes(1, default_unit='b') == 1
    # one byte (uppercase 'B')
    assert human_to_bytes(1, default_unit='b') == 1
    assert human_to_bytes(1, default_unit='B') == 1
    # one kilobyte (lowercase 'b')
    assert human_to_bytes(1, default_unit='KB') == 1024
    assert human_to_bytes(1, default_unit='Kb') == 1024
    # one megabyte (uppercase 'B')
    assert human_to_bytes(1, default_unit='MB') == 1024 * 1024

# Generated at 2022-06-24 21:12:31.169482
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_case_0()



# Generated at 2022-06-24 21:12:40.110201
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert 1048576 == human_to_bytes("1MB")
    assert 1048576 == human_to_bytes("1", "MB")
    assert 1048576 == human_to_bytes("1M")
    assert 1048576 == human_to_bytes("1M")
    assert 1048576 == human_to_bytes("1m")
    assert 1048576 == human_to_bytes("1mB")
    assert 1048576 == human_to_bytes("1Mb")
    assert 1048576 == human_to_bytes("1", "Mb")
    assert 1048576 == human_to_bytes("1.0Mb")
    assert 10485760 == human_to_bytes("10Mb", isbits=True)
    assert 1048576 == human_to_bytes("10Mb", isbits=False)


# Generated at 2022-06-24 21:12:49.376360
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2k') == 2048
    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('2G') == 2147483648
    assert human_to_bytes('2T') == 2199023255552
    assert human_to_bytes('2P') == 2251799813685248
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('K') == 1
    assert human_to_bytes('100B') == 100
    assert human_to_bytes('0.0032K') == 3
    assert human_to_bytes('0.0032KB') == 3
    assert human_to_bytes('0.0032KB', default_unit='B') == 0

# Generated at 2022-06-24 21:12:57.765324
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = human_to_bytes('1M')
    assert result == 1048576
    result = human_to_bytes('1')
    assert result == 1
    result = human_to_bytes('1K')
    assert result == 1024
    result = human_to_bytes('1Kb')
    assert result == 1024
    result = human_to_bytes('1Kb', True)
    assert result == 8192
    result = human_to_bytes('1M', 'Kb')
    assert result == 8192

# Generated at 2022-06-24 21:13:19.466759
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10KB') == 10240
    assert human_to_bytes('10MB') == 10485760
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    assert human_to_bytes('5KB') == 5120
    assert human_to_bytes('5KB') == 5120
    assert human_to_bytes('5KB') == 5120
    assert human_to_bytes('5KB') == 5120
    assert human_to_bytes('5KB') == 5120
    assert human_to_bytes('5KB') == 5120
    assert human_to_bytes('5KB') == 5120
    assert human_to_bytes('5KB') == 5120
    assert human_to_bytes('5KB') == 5120

# Generated at 2022-06-24 21:13:24.869434
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = human_to_bytes('2K')
    assert result == 2048
    assert human_to_bytes(3, 'M') == 3145728
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('10m') == 10485760
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('10m') == 10485760
    assert human_to_bytes('1gb') == 1073741824



# Generated at 2022-06-24 21:13:29.406818
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = 0
    var_0 = lenient_lowercase(int_0)


# unit test for function human_to_bytes
int_0 = 0
TUP_0 = (int_0,)
TUP_0 = bytes_to_human(*TUP_0)



# Generated at 2022-06-24 21:13:34.256939
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(None) is None
    assert lenient_lowercase([1, 2, 'Three', 'four', 'FIVE']) == [1, 2, 'Three', 'four', 'FIVE']
    assert lenient_lowercase([1, 2, 'Three', 'four', 'FIVE']) != [1, 2, 'Three', 'four', 'five']



# Generated at 2022-06-24 21:13:40.813430
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    print('# Unit test for function lenient_lowercase')
    try:
        test_case_0()
    except Exception as e:
        print(str(e))
    else:
        print('test case 0 passed')
    print('')



# Generated at 2022-06-24 21:13:49.051320
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576, "Value of human_to_bytes('1M') should be 1048576."
    assert human_to_bytes('1K') == 1024, "Value of human_to_bytes('1K') should be 1024."

    try:
        human_to_bytes('1A')
    except ValueError:
        assert True
    except Exception:
        assert False

    try:
        human_to_bytes('1Mb')
    except ValueError:
        assert True
    except Exception:
        assert False


# Generated at 2022-06-24 21:13:52.900680
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 21:13:55.298991
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Instances of int have no method lower
    try:
        test_case_0()
    except AttributeError:
        pass
    else:
        assert False, 'ExpectedException not raised'

# Generated at 2022-06-24 21:14:01.583310
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1024, 'b', isbits=True) == 1024, "Expected 1024"
    assert human_to_bytes(1024, 'b') == 8192, "Expected 8192"
    assert human_to_bytes(1024, 'B', isbits=True) == 8192, "Expected 8192"
    assert human_to_bytes(1024, 'B') == 1024, "Expected 1024"
    assert human_to_bytes(1024, 'Mb') == 1048576, "Expected 1048576"
    assert human_to_bytes(1024, 'Mb', isbits=True) == 1048576, "Expected 1048576"
    assert human_to_bytes(1024, 'MB') == 1048576, "Expected 1048576"

# Generated at 2022-06-24 21:14:11.781001
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10B', default_unit='B') == 10
    assert human_to_bytes('10b', isbits=True) == 10
    assert human_to_bytes('10b', isbits=True, default_unit='B') == 10
    assert human_to_bytes('10.0', default_unit='B') == 10
    assert human_to_bytes('10,0', default_unit='B') == 10

    assert human_to_bytes('10k') == 10240
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('10Kb') == 10240
    assert human_to_

# Generated at 2022-06-24 21:14:23.344231
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase([u'asdf', 2]) == [u'asdf', 2]
    assert lenient_lowercase(['asdf', 2]) == ['asdf', 2]
    assert lenient_lowercase(u'asdf') == u'asdf'
    assert lenient_lowercase('asdf') == 'asdf'
    assert lenient_lowercase(['asdf', 'asdf']) == ['asdf', 'asdf']


# Generated at 2022-06-24 21:14:25.518387
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test case 0
    test_case_0()

    # Validate test case 0
    assert var_0 is None, 'var_0 is not None'


# Generated at 2022-06-24 21:14:30.411448
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = -818
    var_0 = lenient_lowercase(int_0)
    assert var_0 == int_0
    str_0 = u'\u0432\u0430\u0436\u0430\u043C'
    var_1 = lenient_lowercase(str_0)
    assert var_1 == 'важам'


# Generated at 2022-06-24 21:14:40.422362
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10MB') == 10485760, "Unit test for function human_to_bytes failed!"
    assert human_to_bytes(10, 'M') == 10485760, "Unit test for function human_to_bytes failed!"
    assert human_to_bytes('10Mb', isbits=True) == (1048576 * 8), "Unit test for function human_to_bytes failed!"
    assert human_to_bytes(10, 'M', isbits=True) == (1048576 * 8), "Unit test for function human_to_bytes failed!"


# Generated at 2022-06-24 21:14:49.271024
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # pass
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('2.5M') == 262144
    # case sensivity
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1Mb', isbits=True) == 1048576
    # suffix case sensivity
    assert human_to_bytes('1Mb', isbits=False) == 1048576
    assert human_to_bytes('1MB', isbits=True) == 1048576
    # default unit
    assert human_to_bytes('100', default_unit='M') == 104857600
    assert human_to_bytes('100', default_unit='M', isbits=False) == 1048

# Generated at 2022-06-24 21:14:54.955771
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase("A") == "a"
    assert lenient_lowercase(1) == 1
    assert lenient_lowercase(['A', 1]) == ['a', 1]



# Generated at 2022-06-24 21:14:59.621144
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test with bad input
    #assert lenient_lowercase(2) == '2'
    #assert lenient_lowercase([1, '1a']) == ['1', '1a']

    # Test with good input
    assert lenient_lowercase(['1', '1a']) == ['1', '1a']



# Generated at 2022-06-24 21:15:09.836717
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1kB') == 1000
# Test case 0
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1Kb', default_unit='b') == 1024
    assert human_to_bytes('1Kb', default_unit='B') == 1000
    assert human_to_bytes('1K', default_unit='b') == 1024
    assert human_to_bytes('1K', default_unit='B') == 1000
    assert human_to_bytes('1kb', default_unit='b') == 1024
    assert human_to_bytes('1kb', default_unit='B') == 1000
   

# Generated at 2022-06-24 21:15:16.395471
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase('abcd').lower() == 'abcd'
    assert lenient_lowercase([]).lower() == []
    assert lenient_lowercase([1, 2, 3, 4]).lower() == [1, 2, 3, 4]
    assert lenient_lowercase(['abcd', 'efgh']).lower() == ['abcd', 'efgh']
    assert lenient_lowercase(['abcd', [1, 2], 3, 4]).lower() == ['abcd', [1, 2], 3, 4]
    assert lenient_lowercase(['abcd', [1, 2], 3, 'EFGhi']).lower() == ['abcd', [1, 2], 3, 'EFGhi']


# Generated at 2022-06-24 21:15:20.417623
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # print('\nTest start test_lenient_lowercase')
    assert lenient_lowercase(['aa', 'bb', 'Cc', 44]) == ['aa', 'bb', 'Cc', 44]
    # print('\nTest end test_lenient_lowercase')


# Generated at 2022-06-24 21:15:41.896745
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes(1.5) == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0G') == 1073741824
    assert human_to_bytes('1.0T') == 1099511627776
    assert human_to_bytes('1.0P') == 1125899906842624
    assert human_to_bytes('1.0E') == 1152921504606846976
    assert human_to_bytes('1.0Z') == 118059162071741130

# Generated at 2022-06-24 21:15:49.822472
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'G') == 10737418240
    assert human_to_bytes(10, 'E') == 10995116277760
    assert human_to_bytes(10, 'P') == 11258999068426240
    assert human_to_bytes(8, 'bits') == 1
    assert human_to_bytes('8b') == 1
    assert human_to_bytes('8kb') == 8192
    assert human_to_bytes(8, 'Kb') == 8192
    assert human_to_bytes('8mb') == 8388608
    assert human_to_bytes('8MB') == 8388608
    assert human_to_

# Generated at 2022-06-24 21:15:58.410616
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    int_0 = -818
    var_0 = lenient_lowercase(int_0)
    assert var_0 == int_0, "lenient_lowercase function failed for value {0}".format(int_0)

    str_0 = 'ABCDefGH'
    var_0 = lenient_lowercase(str_0)
    assert var_0 == 'abcdefgh' , "lenient_lowercase function failed for value {0}".format(str_0)

    int_0 = -818
    var_0 = lenient_lowercase(int_0)
    assert var_0 == -818, "lenient_lowercase function failed for value {0}".format(int_0)

    str_0 = 'ABCDefGH'
    var_0 = lenient_lowercase(str_0)


# Generated at 2022-06-24 21:16:07.675455
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    assert(isinstance(lenient_lowercase([]), list), 'lenient_lowercase([]) return not a list')
    assert(lenient_lowercase(['a', 'b']) == ['a', 'b'], 'lenient_lowercase(["a", "b"]) return not ["a", "b"]')
    assert(lenient_lowercase(['a', 'B']) == ['a', 'b'], 'lenient_lowercase(["a", "B"]) return not ["a", "b"]')
    assert(lenient_lowercase(['a', 1]) == ['a', 1], 'lenient_lowercase(["a", 1]) return not ["a", 1]')

# Generated at 2022-06-24 21:16:17.947636
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('   -42.7 Mb  ', isbits=True) == -44451840
    assert human_to_bytes('  -0.000001b  ', isbits=True) == -1
    assert human_to_bytes('  -0.000001 B ', isbits=False) == -1
    assert human_to_bytes(1) == 1
    assert human_to_bytes(' 1 ') == 1
    assert human_to_bytes('10 B') == 10
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('10bit') == 10
    assert human_to_bytes('10bits') == 10
    assert human_to_bytes('10bitS') == 10

# Generated at 2022-06-24 21:16:26.663425
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase('2K') == '2k'
    assert lenient_lowercase('10M') == '10m'
    assert lenient_lowercase('1MB') == '1mb'
    assert lenient_lowercase('10MB') == '10mb'
    assert lenient_lowercase('1Mb') == '1mb'
    assert lenient_lowercase('1M') == '1m'
    assert lenient_lowercase('10Mb') == '10mb'
    assert lenient_lowercase('1E') == '1e'
    assert lenient_lowercase('1K') == '1k'
    assert lenient_lowercase('1KB') == '1kb'
    assert lenient_lowercase('1KBb') == '1kb'

# Generated at 2022-06-24 21:16:32.692654
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert str(lenient_lowercase(-818)) == '-818'
    assert str(lenient_lowercase('test')) == 'test'
    assert str(lenient_lowercase('TEST')) == 'test'
    assert str(lenient_lowercase('TeSt')) == 'test'
    assert str(lenient_lowercase(u'žluťoučký kůň')) == u'žluťoučký kůň'
    assert str(lenient_lowercase(u'ŽLUŤOUČKÝ KŮŇ')) == u'žluťoučký kůň'

# Generated at 2022-06-24 21:16:44.871601
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """Test function human_to_bytes()"""
    # 1 MB
    test_case_0()
    assert 1 == human_to_bytes('1M')
    assert 1 == human_to_bytes('1', 'M')
    assert 1048576 == human_to_bytes('1MB')
    assert 1048576 == human_to_bytes('1', 'MB')
    assert 1048576 == human_to_bytes(1, 'MB')
    assert 1048576 == human_to_bytes(1, 'Mb', isbits=True)
    assert 1048576 == human_to_bytes(1, 'M', isbits=True)
    assert 1048576 == human_to_bytes('1Mb')
    assert 1048576 == human_to_bytes('1MB', isbits=True)
    assert 1048576 == human