

# Generated at 2022-06-24 21:06:47.683505
# Unit test for function human_to_bytes
def test_human_to_bytes():
    raise NotImplementedError()


# Generated at 2022-06-24 21:06:53.861902
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """
    Tests human_to_bytes function
    """
    int_0 = -679
    var_0 = human_to_bytes(int_0)
    assert var_0 == -679

    int_1 = 0
    var_1 = human_to_bytes(int_1)
    assert var_1 == 0

    int_2 = 679
    var_2 = human_to_bytes(int_2)
    assert var_2 == 679

    int_3 = 679
    var_3 = human_to_bytes(int_3)
    assert var_3 == 679

    str_0 = "679"
    var_4 = human_to_bytes(str_0)
    assert var_4 == 679

    str_0 = u"K"
    str_1 = u"1"


# Generated at 2022-06-24 21:07:02.681740
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('10B') == 10
    assert human_to_bytes('100B') == 100

    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('10K') == 10 * 1024
    assert human_to_bytes('10k') == 10 * 1024
    assert human_to_bytes('100K') == 100 * 1024
    assert human_to_bytes('100k') == 100 * 1024

    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1m') == 1024 * 1024
    assert human_to_bytes('10M') == 10 * 1024 * 1024
    assert human_to_bytes('10m') == 10 * 1024

# Generated at 2022-06-24 21:07:08.334434
# Unit test for function human_to_bytes
def test_human_to_bytes():
    int_0 = -679
    var_0 = human_to_bytes(int_0)

    if var_0 != -679:
        raise AssertionError("bytes_to_human() failed to convert %s to %s. Got %s" % (int_0, -679, var_0))

    int_1 = '2k'
    var_1 = human_to_bytes(int_1)

    if var_1 != 2048:
        raise AssertionError("bytes_to_human() failed to convert %s to %s. Got %s" % (int_1, 2048, var_1))

    int_2 = ''
    var_2 = human_to_bytes(int_2)


# Generated at 2022-06-24 21:07:12.180016
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        lenient_lowercase(None)
    except:
        pass

# Generated at 2022-06-24 21:07:13.855109
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1M") == 1048576, "'1M' return 1048576"



# Generated at 2022-06-24 21:07:21.882719
# Unit test for function human_to_bytes
def test_human_to_bytes():
    var_0 = human_to_bytes('0')
    var_1 = human_to_bytes('0', 'B')
    var_2 = human_to_bytes('0', 'bit', True)
    var_3 = human_to_bytes('1')
    var_4 = human_to_bytes('1', 'B')
    var_5 = human_to_bytes('1', 'bit', True)
    var_6 = human_to_bytes('10', 'bits', True)
    var_7 = human_to_bytes('10', 'bit', True)
    var_8 = human_to_bytes('10', 'b', True)
    var_9 = human_to_bytes('10B')
    var_10 = human_to_bytes('10MB')

# Generated at 2022-06-24 21:07:24.512773
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("Test case 0: ")
    test_case_0()

# Generated at 2022-06-24 21:07:29.428237
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    ret = lenient_lowercase(['Foo', 'Bar'])
    assert ret == ['foo', 'bar']


# Generated at 2022-06-24 21:07:31.646222
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Function parameters
    lst = None

    # Returned value
    returned = lenient_lowercase(lst)
    assert (returned is None)



# Generated at 2022-06-24 21:07:43.570074
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    import random
    import string
    import json

    # generate random strings
    test_input = ["".join(random.choice(string.ascii_uppercase) for i in range(6)) for i in range(10)]

    # test for lowercase
    test_output = lenient_lowercase(test_input)
    assert type(test_input) == list, "Input must be of type list"
    assert type(test_output) == list, "Output must be of type list"

    for i, val in enumerate(test_output):
        assert type(val) == str, "All elements in the output list must be of type string"
        assert val.lower() == val, "All elements in the output list must be all lowercase"

# Generated at 2022-06-24 21:07:51.054120
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        var_0 = lenient_lowercase(['Test String', 'Another String', 'Another String'])
        assert var_0 == 'Test String', 'var_0 returned wrong value'
        var_1 = lenient_lowercase([1, 2, 3])
        assert var_1 == 1, 'var_1 returned wrong value'
    except Exception as e:
        print(e)
        var_1 = False
        var_0 = False

    try:
        assert var_0 and var_1, 'lenient_lowercase() failed the asserts'
    except Exception as e:
        print(e)

# Generated at 2022-06-24 21:07:53.071028
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        var_0 = test_case_0()
    except Exception:
        var_0 = NotImplementedError()
    return var_0

# Generated at 2022-06-24 21:08:00.125737
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # No fivth param
    assert human_to_bytes(1) == 1

    # String
    assert human_to_bytes("1") == 1
    assert human_to_bytes("1B") == 1

    # Empty
    assert human_to_bytes("", "foo") is None

    # Unit lower case
    assert human_to_bytes("1b") == 1
    assert human_to_bytes("1b", "b") == 1
    assert human_to_bytes("1b", "B") == 0
    assert human_to_bytes("1B", "b") == 0

    # Bit
    assert human_to_bytes("1", "b", True) == 1
    assert human_to_bytes("1", "B", True) == 0

    # Bits

# Generated at 2022-06-24 21:08:04.870646
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # This is dummy test, please feel free to edit it
    var_0 = human_to_bytes(2, 'K')
    var_1 = NotImplementedError()
    var_2 = NotImplementedError()
    assert var_0 == var_2


# Generated at 2022-06-24 21:08:13.846809
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5m') == 1572864
    assert human_to_bytes('1.5MB') == 1572864
    assert human_to_bytes('1.5Mb', isbits=True) == 1572864
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10Mb', isbits=True) == 10485760
    assert human_to_bytes('10mb', isbits=True) == 10485760
   

# Generated at 2022-06-24 21:08:18.985366
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    var_0 = ['A', 'B', 'C', 'D', 'E', 1, 2, 3, 4, 5]
    var_1 = ['a', 'b', 'c', 'd', 'e', 1, 2, 3, 4, 5]
    assert var_1 == lenient_lowercase(var_0)


# Generated at 2022-06-24 21:08:26.856993
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    import collections

    var_0 = -2739
    ret_0 = lenient_lowercase(var_0)
    assert ret_0 == -2739

    var_1 = 3709
    ret_1 = lenient_lowercase(var_1)
    assert ret_1 == 3709

    var_2 = collections.UserList()
    ret_2 = lenient_lowercase(var_2)
    assert isinstance(ret_2, collections.UserList)

    var_3 = collections.UserDict()
    ret_3 = lenient_lowercase(var_3)
    assert isinstance(ret_3, collections.UserDict)



# Generated at 2022-06-24 21:08:36.690244
# Unit test for function human_to_bytes
def test_human_to_bytes():
    var_0 = NotImplementedError()
    var_1 = NotImplementedError()
    var_2 = NotImplementedError()
    var_3 = NotImplementedError()
    var_4 = NotImplementedError()
    var_5 = NotImplementedError()
    var_6 = NotImplementedError()
    var_7 = NotImplementedError()
    var_8 = NotImplementedError()
    var_9 = NotImplementedError()
    var_10 = NotImplementedError()
    var_0 = NotImplementedError()
    var_1 = NotImplementedError()
    var_2 = NotImplementedError()
    var_3 = NotImplementedError()
    var_4 = NotImplementedError()
    var_5 = NotIm

# Generated at 2022-06-24 21:08:43.855574
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['1', '2', '3']) == ["1", "2", "3"]
    assert lenient_lowercase(['1', 2, '3']) == ['1', 2, '3']
    assert lenient_lowercase(['1', '2', 3]) == ["1", "2", 3]
    assert lenient_lowercase(['1', '2']) == ["1", "2"]
    assert lenient_lowercase([1, '2', 3]) == [1, '2', 3]


# Generated at 2022-06-24 21:08:48.477504
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['test', 'Test']) == ['test', 'Test']
    assert lenient_lowercase(['test', 'Test', NotImplementedError()]) == ['test', 'Test', NotImplementedError()]


# Generated at 2022-06-24 21:08:51.060310
# Unit test for function human_to_bytes
def test_human_to_bytes():
    var_0 = 15
    var_1 = 'B'
    assert human_to_bytes(var_0,var_1) == NotImplementedError()


# Generated at 2022-06-24 21:08:57.696033
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    var_0 = ["foo", "FOO", "Foo", "bar", 42, 42.0, "42", "42.0", "baz", "bAz"]
    expected = ["foo", "FOO", "Foo", "bar", 42, 42.0, "42", "42.0", "baz", "bAz"]
    actual = lenient_lowercase(var_0)
    assert actual == expected, "Returned unexpected: %s" % actual


# Generated at 2022-06-24 21:08:59.980771
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert callable(lenient_lowercase)


# Generated at 2022-06-24 21:09:03.190269
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert len(lenient_lowercase([1, 2, 3])) == 3
    assert len(lenient_lowercase(['a', 'B', 'C'])) == 3
    assert len(lenient_lowercase([['a', 'b'], ['c', 'd']])) == 2


# Generated at 2022-06-24 21:09:06.621249
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    if lenient_lowercase(var_0) != var_0:
        raise Exception()


# Generated at 2022-06-24 21:09:17.373135
# Unit test for function human_to_bytes

# Generated at 2022-06-24 21:09:28.207304
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        assert human_to_bytes(10) == 10
        assert human_to_bytes(10, 'M') == 10 * 1024 * 1024
        assert human_to_bytes('1MB') == 1024 * 1024
        assert human_to_bytes('1MiB') == 1024 * 1024
        assert human_to_bytes('1KB') == 1000
        assert human_to_bytes('1KiB') == 1024
        assert human_to_bytes('10M') == 10 * 1024 * 1024
        assert human_to_bytes('10Mb') == 10485760
        assert human_to_bytes('10MB', unit='b') == 10485760
        assert human_to_bytes('10b', unit='M') == 10485760
    except AssertionError:
        pass


# Generated at 2022-06-24 21:09:34.462690
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    try:
        list = ['1', '2', 5]
        list_re = ['1', '2', '5']
        assert lenient_lowercase(list) == list_re
    except AssertionError as e:
        print('Test failed!')
        print('Expected: %s' % list_re)
        print('Got: %s' % lenient_lowercase(list))


# Generated at 2022-06-24 21:09:38.354136
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Input variables
    in_val_0 = [ 0.0, 'Foobar' ]
    expected_result = [ 0.0, 'foobar' ]

    # Perform the test
    result = lenient_lowercase(in_val_0)

    assert result == expected_result


# Generated at 2022-06-24 21:09:51.045047
# Unit test for function human_to_bytes

# Generated at 2022-06-24 21:09:57.067149
# Unit test for function human_to_bytes
def test_human_to_bytes():
    true_val = 1024
    # Human => Bytes
    print("1KB = %d Bytes" % human_to_bytes('1KB'))
    assert human_to_bytes('1KB') == true_val

    # Human => Bytes
    print("1K = %d Bytes" % human_to_bytes('1K'))
    assert human_to_bytes('1K') == true_val

    # Human => Bytes
    print("1Kb = %d Bytes" % human_to_bytes('1Kb', isbits=True))
    assert human_to_bytes('1Kb', isbits=True) == true_val

    # Human => Bytes
    print("1Mb = %d Bytes" % human_to_bytes('1Mb', isbits=True))
    assert human_to_

# Generated at 2022-06-24 21:10:06.012877
# Unit test for function human_to_bytes
def test_human_to_bytes():
    var_0 = human_to_bytes("2K")
    assert var_0 == 2048
    var_1 = human_to_bytes("2Kb")
    assert var_1 == 2048
    var_2 = human_to_bytes("2KB")
    assert var_2 == 2048
    var_3 = human_to_bytes("2Kb", isbits=True)
    assert var_3 == 16384
    var_4 = human_to_bytes("2KB", isbits=True)
    assert var_4 == 2048
    var_5 = human_to_bytes("2k", isbits=True)
    assert var_5 == 16384
    var_6 = human_to_bytes("2K")
    assert var_6 == 2048

# Generated at 2022-06-24 21:10:10.205314
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Input parameters
    lst = [1, 'A', 'B', 'C']

    # get expected result
    test_case_0()
    expected = ['a', 'b', 'c']

    # get actual result
    actual = lenient_lowercase(lst)

    # Compare expected with actual result
    assert actual == expected


# Generated at 2022-06-24 21:10:17.601181
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """
    Test function human_to_bytes
    """

# Generated at 2022-06-24 21:10:24.110723
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    str_0 = 'test'
    float_0 = float(-2.895)
    str_1 = 'test'
    str_2 = 'test'
    bool_0 = bool(False)
    int_0 = NotImplementedError()
    str_3 = 'test'
    str_4 = 'test'
    str_5 = 'test'
    int_1 = NotImplementedError()
    str_6 = 'test'
    float_1 = float(-1.101)
    float_2 = float(-1.905)
    float_3 = float(-1.819)
    str_7 = 'test'
    str_8 = 'test'
    int_2 = NotImplementedError()
    str_9 = 'test'
    float_4 = float(-2.963)


# Generated at 2022-06-24 21:10:25.366046
# Unit test for function lenient_lowercase
def test_lenient_lowercase():

    var_0 = NotImplementedError()



# Generated at 2022-06-24 21:10:37.727143
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test with string representation of number
    number = '1.4M'
    exp_val = 1468006
    assert human_to_bytes(number) == exp_val, "Expected value for %s is %d, but got %d" % (number, exp_val, human_to_bytes(number))
    # Test with string representation of number
    number = '1.5k'
    exp_val = 1536
    assert human_to_bytes(number) == exp_val, "Expected value for %s is %d, but got %d" % (number, exp_val, human_to_bytes(number))
    # Test with int representation of number
    number = 6
    exp_val = 6

# Generated at 2022-06-24 21:10:47.052417
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2M') == 2*1024**2
    assert human_to_bytes('2G') == 2*1024**3
    assert human_to_bytes('-2G') == -2*1024**3
    assert human_to_bytes('2.5G') == int(2.5*1024**3)
    assert human_to_bytes('1.0E') == 1 * SIZE_RANGES['E']
    assert human_to_bytes('1.0Z') == 1 * SIZE_RANGES['Z']
    assert human_to_bytes('1.0Y') == 1 * SIZE_RANGES['Y']
    assert human_to_bytes('1.0P') == 1 * SIZE_RANGES['P']


# Generated at 2022-06-24 21:10:54.731841
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1m') == 1048576

    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1mb') == 1048576

    assert human_to_bytes('1kb', isbits=True) == 1024
    assert human_to_bytes('1mb', isbits=True) == 1048576

    assert human_to_bytes('.5M') == 524288
    assert human_to_bytes('.5K') == 512
    assert human_to

# Generated at 2022-06-24 21:11:04.967316
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # simple case
    var_0 = human_to_bytes('100K')
    assert var_0 == 102400

    # simple case
    var_0 = human_to_bytes('100k')
    assert var_0 == 102400

    # simple case
    var_0 = human_to_bytes('100KB')
    assert var_0 == 102400

    # simple case
    var_0 = human_to_bytes('100Kb')
    assert var_0 == 102400

    # simple case
    var_0 = human_to_bytes('100kbit')
    assert var_0 == 102400

    # simple case
    var_0 = human_to_bytes('100kbit', isbits=True)
    assert var_0 == 102400

    # simple case

# Generated at 2022-06-24 21:11:13.372808
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(10, None, None) == 10
    assert human_to_bytes('10', None, None) == 10
    assert human_to_bytes('10M', None, None) == 10485760
    assert human_to_bytes('10.5M', None, None) == 10947955
    assert human_to_bytes('10 M', None, None) == 10485760
    assert human_to_bytes('10.5 MB', None, None) == 10947955
    assert human_to_bytes('10.5MB', 'M', None) == 10947955


# Generated at 2022-06-24 21:11:20.925619
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test case 0
    var_0 = '2K'
    assert(human_to_bytes(var_0) == 2048)
    assert(human_to_bytes(var_0, isbits=True) == 2048)

    # Test case 1
    var_1 = '10M'
    assert(human_to_bytes(var_1) == 10485760)
    assert(human_to_bytes(var_1, isbits=True) == 10485760)

    # Test case 2
    var_2 = '10Kb'
    assert(human_to_bytes(var_2) == 10240)
    assert(human_to_bytes(var_2, isbits=True) == 81920)

    # Test case 3
    var_3 = '10MB'

# Generated at 2022-06-24 21:11:23.834606
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
  try:
    assert callable(lenient_lowercase)
  except AssertionError:
    raise AssertionError("Function `lenient_lowercase` is not defined.")


# Generated at 2022-06-24 21:11:35.456976
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # default_unit=None, isbits=False
    assert human_to_bytes("10M") == 10485760
    assert human_to_bytes("10MB") == 10485760
    assert human_to_bytes("10MBb") == 10485760
    assert human_to_bytes("10Mb") == 10485760
    assert human_to_bytes("10") == 10
    # default_unit='M', isbits=False
    assert human_to_bytes("10M", "M") == 10485760
    assert human_to_bytes("10", "M") == 10485760
    assert human_to_bytes("10Mb", "M") == 10485760
    # isbits=True
    assert human_to_bytes("10Mb", isbits=True) == 10485760


# Generated at 2022-06-24 21:11:39.414401
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    var_0 = lenient_lowercase(lenient_lowercase)
    var_1 = lenient_lowercase(var_0)
    try:
        var_2 = lenient_lowercase(var_1)
    except Exception:
        var_2 = lenient_lowercase(var_1)


# Generated at 2022-06-24 21:11:43.837441
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("2M") == 2097152
    assert human_to_bytes("2K") == 2048
    assert human_to_bytes("2G") == 2147483648


# Generated at 2022-06-24 21:11:49.074359
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase.__name__ == "lenient_lowercase"
    var_0 = [1, 2, 'a', 'B', 'C']
    return lenient_lowercase(var_0)


# Generated at 2022-06-24 21:11:52.525385
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    var_0 = [1,'a',('a','b'),['a','b']]
    # lenient_lowercase
    assert lenient_lowercase(var_0) == [1,'a',('a','b'),['a','b']]


# Generated at 2022-06-24 21:12:03.055035
# Unit test for function human_to_bytes
def test_human_to_bytes():
    number = "1"
    default_unit = "M"
    isbits = False
    # Call human_to_bytes
    human_to_bytes(number, default_unit, isbits)

    # Call human_to_bytes
    number = "1"
    default_unit = "M"
    isbits = True
    # Call human_to_bytes
    human_to_bytes(number, default_unit, isbits)

    # Call human_to_bytes
    number = "1Mb"
    default_unit = None
    isbits = True
    # Call human_to_bytes
    human_to_bytes(number, default_unit, isbits)

    # Call human_to_bytes
    number = "1Mb"
    default_unit = "M"
    isbits = True
    # Call human

# Generated at 2022-06-24 21:12:07.982319
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['ABC', 'def', 3, 'GHI']
    result = lenient_lowercase(lst)
    assert result == ['abc', 'def', 3, 'ghi']


# Generated at 2022-06-24 21:12:13.975539
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test that the function raises an error when the suffix is not in a map of supported sizes
    try:
        human_to_bytes('1W')
    except ValueError as e:
        assert 'failed to convert 1W' in str(e)

    # Test that the function raises an error when the suffix is not given
    try:
        human_to_bytes('1')
    except ValueError as e:
        assert 'can\'t interpret' in str(e)

    # Test that the function raises an error when the number is not given
    try:
        human_to_bytes('K')
    except ValueError as e:
        assert 'can\'t interpret' in str(e)

    # Test with a missing unit and different default units
    assert human_to_bytes('1', default_unit='M') == 1 << 20
    assert human

# Generated at 2022-06-24 21:12:15.834424
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    result = lenient_lowercase([10, 'wlan', 'WLAN', 'Dfs'])
    assert result == [10, 'wlan', 'WLAN', 'Dfs']


# Generated at 2022-06-24 21:12:21.895210
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(12) == 12
    assert lenient_lowercase("123") == "123"
    assert lenient_lowercase(NotImplementedError()) == NotImplementedError()


# Generated at 2022-06-24 21:12:25.160911
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase('b') == ['b']
    assert lenient_lowercase(['a', 1]) == ['a', 1]


# Generated at 2022-06-24 21:12:35.688728
# Unit test for function human_to_bytes
def test_human_to_bytes():
    if var_0.case_0():
        assert human_to_bytes('2K') == 2048 and human_to_bytes('2k') == 2048 and human_to_bytes('2Kb') == 2048 and human_to_bytes('2Kb', isbits=True) == 2048
    if var_0.case_1():
        assert human_to_bytes('2M') == 2 * 1024 * 1024 and human_to_bytes('2Mb') == 2 * 1024 * 1024 and human_to_bytes('2Mb', isbits=True) == 2 * 1024 * 1024
    if var_0.case_2():
        assert human_to_bytes('2G') == 2 * 1024 * 1024 * 1024 and human_to_bytes('2Gb', isbits=True) == 2 * 1024 * 1024 * 1024

# Generated at 2022-06-24 21:12:43.919956
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    from ansible.module_utils import basic
    argument_spec = dict(
        numbers=dict(type='list', required=False),
        strs=dict(type='list', required=False),
        mixed=dict(type='list', required=False),
        unicode_strs=dict(type='list', required=False),
        val=dict(type='str', required=False),
        ints=dict(type='list', required=False),
        floats=dict(type='list', required=False),
    )
    module = basic.AnsibleModule(argument_spec=argument_spec)
    numbers = module.params.get("numbers")
    strs = module.params.get("strs")
    mixed = module.params.get("mixed")

# Generated at 2022-06-24 21:12:47.587332
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    lst = ['1', 2, '3']
    assert ['1', 2, '3'] == lenient_lowercase(lst)


# Generated at 2022-06-24 21:12:55.736519
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # default value for default_unit
    assert human_to_bytes("2K") == 2048
    assert human_to_bytes("2M") == 2097152
    assert human_to_bytes("2G") == 2147483648
    assert human_to_bytes("2T") == 2199023255552
    assert human_to_bytes("2P") == 2251799813685248
    assert human_to_bytes("2E") == 2.32471947403315e+16
    assert human_to_bytes("2Z") == 2.3620928688064423e+17
    assert human_to_bytes("2Y") == 2.398942267881256e+18

    assert human_to_bytes("2b") == 2
    assert human_to_bytes("2kb") == 2048
   

# Generated at 2022-06-24 21:13:03.188054
# Unit test for function human_to_bytes
def test_human_to_bytes():
    var_1 = "10M"
    var_2 = 10485760.0

    assert(human_to_bytes(var_1, 'B', False) == var_2)

    # Try converting '1Mb' to bytes. This should fail
    try:
        human_to_bytes("1Mb", 'B', False)
    except ValueError:
        pass

    # Try converting '1Mb' to bits. This should work
    var_2 = 1048576.0
    assert(human_to_bytes("1Mb", 'b', True) == var_2)

    var_3 = '5.1 M'
    var_4 = 5324032.0
    assert(human_to_bytes(var_3) == var_4)

    # no unit given

# Generated at 2022-06-24 21:13:16.896549
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test case for function human_to_bytes where unit is None
    try:
        test_case_0()
    except Exception as e:
        exc = e
    assert str(exc) == '''NotImplementedError()'''


# Generated at 2022-06-24 21:13:26.238906
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Empty string
    result = human_to_bytes('')
    assert result is None, "Result was: %s" % result
    # String: 'Not a number'
    result = human_to_bytes('Not a number')
    assert result is None, "Result was: %s" % result
    # String: '1'
    result = human_to_bytes('1')
    assert result == 1, "Result was: %s" % result
    # String: '1.0kB'
    result = human_to_bytes('1.0kB')
    assert result == 1024, "Result was: %s" % result
    # String: '1.0MB'
    result = human_to_bytes('1.0MB')
    assert result == 1048576, "Result was: %s" % result
    # String:

# Generated at 2022-06-24 21:13:35.455447
# Unit test for function human_to_bytes
def test_human_to_bytes():
    print("Testing human_to_bytes")
    assert human_to_bytes('1b', isbits = True) == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1Kb', isbits = True) == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1Mb', isbits = True) == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1Gb', isbits = True) == 1073741824
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes(1.5, 'MB') == 1572864
    assert human_to_bytes('1.5MB') == 1572864
    assert human_to_

# Generated at 2022-06-24 21:13:44.580161
# Unit test for function human_to_bytes
def test_human_to_bytes():
    var_1 = '0'
    var_2 = 1
    var_3 = 'K'
    var_4 = 'MB'
    var_5 = 'b'
    var_6 = 'tb'
    var_7 = 'k'
    var_8 = '2'
    var_9 = '3.3'
    var_10 = '5.5'
    var_11 = '6.6'
    var_12 = False
    var_13 = True
    if (not (var_1 == var_2)):
        raise ValueError("%s != %s" % (var_1, var_2))


# Generated at 2022-06-24 21:13:47.171830
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    var_0 = ["Abc", 123, "ZYx"]
    var_1 = lenient_lowercase(var_0)
    assert var_1 == ['abc', 123, 'ZYx']


# Generated at 2022-06-24 21:13:52.297862
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    test_not_string_list = [1, 2, 3]
    assert lenient_lowercase(test_not_string_list) == test_not_string_list
    test_string_list = ["AbC123", "dEF", "ghi"]
    assert lenient_lowercase(test_string_list) == ["abc123", "def", "ghi"]
    test_list_mix = ["A", 1]
    assert lenient_lowercase(test_list_mix) == ["a", 1]


# Generated at 2022-06-24 21:14:00.468721
# Unit test for function human_to_bytes
def test_human_to_bytes():
    """
    A sample test to get started.
    """

# Generated at 2022-06-24 21:14:05.985812
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    var_0 = ['Hello', 'WORLD', 1, {'A': 1, 'B': 2}]
    var_1 = ['hello', 'world', 1, {'A': 1, 'B': 2}]
    var_2 = lenient_lowercase(var_0)

    assert var_1 == var_2


# Generated at 2022-06-24 21:14:11.277711
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test 1 - non string passed
    # Should fail
    var_0 = human_to_bytes(None)
    assert var_0 == None


# Generated at 2022-06-24 21:14:22.577526
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Expected output: 1048576
    # Actual output: 1048576
    var_0 = human_to_bytes(1000000)
    assert var_0 == 1048576

    # Expected output: 5242880
    # Actual output: 5242880
    var_0 = human_to_bytes(5)*1024**2

    assert var_0 == 5242880

    # Expected output: 1048576
    # Actual output: 1048576
    var_0 = human_to_bytes(1048.576)
    assert var_0 == 1048576

    # Expected output: 1048576
    # Actual output: 1048576
    var_0 = human_to_bytes('1048576')
    assert var_0 == 1048576

    # Expected output: 1048576
    # Actual output:

# Generated at 2022-06-24 21:14:36.952059
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1K') == 1024)
    assert(human_to_bytes('1MiB') == 1048576)
    assert(human_to_bytes('1Mib') == 1048576)
    assert(human_to_bytes('1Mb') == 1048576)
    assert(human_to_bytes('1MB') == 1048576)
    assert(human_to_bytes('1Kib') == 1024)
    assert(human_to_bytes('1KiB') == 1024)
    assert(human_to_bytes(1024) == 1024)
    assert(human_to_bytes('1') == 1)
    assert(human_to_bytes('1 b') == 1)
    assert(human_to_bytes('1 b') == 1)

# Generated at 2022-06-24 21:14:40.247634
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Test function human_to_bytes
    '''
    # Test case 0
    try:
        test_case_0()
    except Exception as exp:
        print(exp)

    print("Tests completed successfully")

# Generated at 2022-06-24 21:14:41.045092
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert False, "This test needs an implementation"


# Generated at 2022-06-24 21:14:44.892702
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    pass
    # Case 0
    var_0 = ['1234', 'kilo', 'MEGA', 'GigA']
    expected_0 = ['1234', 'kilo', 'mega', 'giga']
    assert lenient_lowercase(var_0) == expected_0, 'Failed case 0'


# Generated at 2022-06-24 21:14:52.127245
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == human_to_bytes(10, 'M')
    assert human_to_bytes(10, 'M') == 10485760
    assert human_to_bytes(10, 'MB') == 10485760
    assert human_to_bytes(10, 'Mb', isbits=False) == 10485760
    assert human_to_bytes(10, 'Mb', isbits=True) == 134217728
    assert human_to_bytes(10, 'M', isbits=True) == 134217728
    assert human_to_bytes(10, 'b', isbits=True) == 10
    assert human_to_bytes(10, 'b', isbits=False) == 1
    assert human_to_bytes(10) == 10

# Generated at 2022-06-24 21:15:02.058079
# Unit test for function human_to_bytes
def test_human_to_bytes():
    err = ValueError
    a = '10K'
    b = '10M'
    c = '10G'
    d = '10KB'
    e = '10MB'
    f = '10GB'
    g = '10kb'
    h = '10Mb'
    i = '10Gb'
    result = human_to_bytes(a)
    assert result == 10240

    result = human_to_bytes(b)
    assert result == 10485760

    result = human_to_bytes(c)
    assert result == 10737418240

    result = human_to_bytes(d)
    assert result == 10240

    result = human_to_bytes(e)
    assert result == 10485760

    result = human_to_bytes(f)
    assert result == 10737418

# Generated at 2022-06-24 21:15:05.338251
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(['HELLO', 99, 'WORLD']) == ['hello', 99, 'world']


# Generated at 2022-06-24 21:15:08.079638
# Unit test for function human_to_bytes
def test_human_to_bytes():
    try:
        human_to_bytes(test_case_0)
    except Exception as err:
        assert isinstance(err, NotImplementedError)


# Generated at 2022-06-24 21:15:13.401181
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    # Test parameters
    lst = [1, "A", 2]

    # Perform test
    test_result = lenient_lowercase(lst)

    # Verify results
    assert test_result == [1, "a", 2], 'Expected ["1", "a", "2"], but got: %s' % test_result


# Generated at 2022-06-24 21:15:24.157870
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1K', default_unit='B') == 1024
    assert human_to_bytes('1M', default_unit='B') == 1048576
    assert human_to_bytes('1K', unit='B') == 1024
    assert human_to_bytes('1M', unit='B') == 1048576
    assert human_to_bytes('1Kb') == 1000
    assert human_to_bytes('1Mb') == 1000000
    assert human_to_bytes('1Kb', default_unit='b') == 1000
    assert human_to_bytes('1Mb', default_unit='b') == 1000000

# Generated at 2022-06-24 21:15:39.314710
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Check b -> B
    assert human_to_bytes('10b') == 10
    assert human_to_bytes('10B') == 10

    # Check k -> K
    assert human_to_bytes('10k') == 10 * 2 ** 10
    assert human_to_bytes('10k') == 10 * 1024
    assert human_to_bytes('10K') == 10 * 2 ** 10

    # Check m -> M
    assert human_to_bytes('10m') == 10 * 2 ** 20
    assert human_to_bytes('10m') == 10 * 1024 * 1024
    assert human_to_bytes('10M') == 10 * 2 ** 20

    # Check g -> G
    assert human_to_bytes('10g') == 10 * 2 ** 30
    assert human_to_bytes('10g') == 10 * 1024 * 1024 * 1024

# Generated at 2022-06-24 21:15:43.252378
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    float_0 = 5100.8801
    var_0 = lenient_lowercase(float_0)
    print(var_0)

test_case_0()

# Generated at 2022-06-24 21:15:53.995113
# Unit test for function human_to_bytes
def test_human_to_bytes():
    number = '10M'
    print(human_to_bytes(number=number))
    number = '10Mb'
    print(human_to_bytes(number=number, isbits=True))
    number = '10Mb'
    print(human_to_bytes(number=number, default_unit='b'))
    number = '10MB'
    print(human_to_bytes(number=number, default_unit='b'))
    # '''
    # This will raise ValueError
    # '''
    # number = '10MB'
    # print(human_to_bytes(number=number, isbits=True))
    number = '10.5Mb'
    print(human_to_bytes(number=number, isbits=True))


# Generated at 2022-06-24 21:16:01.592733
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Fail case
    try:
        human_to_bytes('1B', 'K')
    except ValueError:
        pass
    try:
        human_to_bytes('1MB')
    except ValueError:
        pass

    # Working cases
    result = human_to_bytes('1K')
    assert result == 1024
    result = human_to_bytes('1Kb', isbits=True)
    assert result == 1024
    assert human_to_bytes(10, 'Y') == float_0
    result = human_to_bytes(10, 'Y', isbits=True)
    assert result == float_0
    assert human_to_bytes('2.5M') == 2560000
    result = human_to_bytes('2.5Mb', isbits=True)
    assert result == 2560000
    assert human

# Generated at 2022-06-24 21:16:05.240817
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    assert lenient_lowercase(5100.8801) == [5100.8801]


# Generated at 2022-06-24 21:16:16.549233
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2K') == 2048
    assert human_to_bytes('2M') == 2097152
    assert human_to_bytes('2G') == 2147483648
    assert human_to_bytes('2T') == 2199023255552
    assert human_to_bytes('2P') == 2251799813685248
    assert human_to_bytes('2E') == 2305843009213693952
    assert human_to_bytes('2Z') == 2361183241434822606848
    assert human_to_bytes('2Y') == 2417851639229258349412352
    assert human_to_bytes('256E-3Y') == 2417851639229258349412352


# Generated at 2022-06-24 21:16:20.296601
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    float_0 = 5100.8801
    # Expected result
    value = '5100.8801'
    # Testing lenient_lowercase
    assert lenient_lowercase(float_0) == value


# Generated at 2022-06-24 21:16:22.685116
# Unit test for function lenient_lowercase
def test_lenient_lowercase():
    float_0 = 5100.8801
    var_0 = lenient_lowercase(float_0)


# Generated at 2022-06-24 21:16:32.973808
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # Test case: 0
    test_number = '5.26727E'
    test_unit = 'P'
    expected_integer = int(round(float(test_number) * SIZE_RANGES[test_unit.upper()]))
    result = human_to_bytes(test_number, test_unit)
    assert expected_integer == result
    # Test case: 1
    test_number = '0.3E'
    test_unit = 'Z'
    expected_integer = int(float(test_number) * SIZE_RANGES[test_unit.upper()])
    result = human_to_bytes(test_number, test_unit)
    assert expected_integer == result
    # Test case: 2
    test_number = '0.6E'
    test_unit = 'Z'
   

# Generated at 2022-06-24 21:16:39.636828
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # case 0
    print('test case 0')
    str_0 = '1Mb'
    num_0 = human_to_bytes(str_0)
    num_1 = human_to_bytes(str_0, 'b')
    print('%s %s' % (num_0, num_1))

    # case 1
    print('test case 1')
    str_1 = '2G'
    num_2 = human_to_bytes(str_1)
    num_3 = human_to_bytes(str_1, 'B')
    print('%s %s' % (num_2, num_3))

    # case 2
    print('test case 2')
    str_2 = '3Kb'
    num_4 = human_to_bytes(str_2, isbits=True)