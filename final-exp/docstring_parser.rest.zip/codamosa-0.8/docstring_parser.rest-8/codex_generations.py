

# Generated at 2022-06-11 21:37:04.685925
# Unit test for function parse
def test_parse():
	docstring = 'This is the short description.\n\nThis is the long description.\n\n:param arg_name: description\n:type arg_name: type_name\n:returns: "" \n:rtype: str'
	docstring_parsed = parse(docstring)
	print(docstring_parsed)
	print(docstring_parsed.meta[0])
	print(docstring_parsed.meta[1])


if __name__ == '__main__':
	test_parse()

# Generated at 2022-06-11 21:37:13.792845
# Unit test for function parse
def test_parse():
    """ Parse simple docstring and print back the elements of
    the parsed docstring
    """
    docstring = '''
    Test function

    :param arg1: The first argument
    :param arg2: The second argument
    :param arg3: The third argument
    :returns: a variable with the result of the addition.
    '''
    parsed_docstring = parse(docstring)

    assert parsed_docstring.short_description == 'Test function'
    assert parsed_docstring.long_description == ''
    assert parsed_docstring.blank_after_short_description
    assert not parsed_docstring.blank_after_long_description


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:37:19.425576
# Unit test for function parse
def test_parse():
    text = '''
        :param str name:
        Some description
    '''

    docstring = parse(text)

    assert len(docstring.meta) == 1
    assert docstring.meta[0].arg_name == 'name'
    assert docstring.meta[0].description == 'Some description'

# Generated at 2022-06-11 21:37:30.537336
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Test docstring.") == Docstring(
        "Test docstring.", None, False, False, None
    )
    assert parse("Test docstring.\n") == Docstring(
        "Test docstring.", None, True, False, None
    )
    assert parse("Test docstring.\n\n") == Docstring(
        "Test docstring.", None, True, True, None
    )
    assert parse("Test docstring.\n\nLonger description.") == Docstring(
        "Test docstring.",
        None,
        True,
        False,
        "Longer description.",
    )

# Generated at 2022-06-11 21:37:36.833293
# Unit test for function parse
def test_parse():
    doc = """
    :param arg1:
    :param arg2:
    :returns:
    """
    parsed = parse(doc)
    assert parsed.short_description == ""
    assert parsed.blank_after_short_description
    assert parsed.long_description is None
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 2
    assert parsed.meta[0].type_name is None
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].is_optional is None
    assert parsed.meta[0].default is None
    assert parsed.meta[1].type_name is None
    assert parsed.meta[1].arg_name == "arg2"
    assert parsed.meta[1].is_optional is None

# Generated at 2022-06-11 21:37:45.380799
# Unit test for function parse

# Generated at 2022-06-11 21:37:52.517370
# Unit test for function parse
def test_parse():
    text = """
    Test function for parse function
    
    Test function for 
        parse function
    
    :returns: 
        A string value `s`
    """
    result = parse(text)
    assert result.short_description == "Test function for parse function"
    assert result.long_description == "Test function for parse function"
    assert result.blank_after_short_description
    assert not result.blank_after_long_description
    assert result.meta[0].description == "A string value `s`"

# Generated at 2022-06-11 21:38:04.186234
# Unit test for function parse
def test_parse():
    text='''Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    '''
    res=parse(text)
    assert res.short_description == 'Parse the ReST-style docstring into its components.'
    assert res.long_description == 'returns: parsed docstring'
    assert res.blank_after_short_description == False
    assert res.blank_after_long_description == False
    assert len(res.meta) == 1
    assert res.meta[0].args == ['returns']
    assert res.meta[0].description == 'parsed docstring'

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:38:16.452076
# Unit test for function parse
def test_parse():
    # Setup test data
    str = """
    summary
    :param a: Description of parameter a
    :param b: Description of parameter b
    :param c: Description of parameter c"""
    result = parse(str)
    assert result.short_description == "summary", "Got {} instead".format(result.short_description)
    assert len(result.meta) == 3, "Got {} instead".format(result.meta)
    assert result.meta[0].arg_name == "a", "Got {} instead".format(result.meta[0].arg_name)
    assert result.meta[0].description == "Description of parameter a", "Got {} instead".format(result.meta[0].description)
    assert result.meta[1].arg_name == "b", "Got {} instead".format(result.meta[1].arg_name)


# Generated at 2022-06-11 21:38:24.317825
# Unit test for function parse
def test_parse():

    from . import parse as rst_parse
    from . import parse_napoleon as nap_parse
    import pytest

    @pytest.mark.parametrize("parse", [None, rst_parse, nap_parse])
    def _eq(first: str, second: str, parse=None):
        if parse is None:
            parse = rst_parse
        return parse(first).pprint_rst() == second

    def _re(first: str, second: str, parse=rst_parse):
        return parse(first).pprint_rst()


# Generated at 2022-06-11 21:38:45.576254
# Unit test for function parse
def test_parse():
    """Test function parse"""
    a_docstring = '''
    This function does parse a docstring.

    Parameters
    ----------
    arg1 : int
        An integer.
   '''
    parsed = parse(a_docstring)
    assert isinstance(parsed.meta[0], DocstringParam)
    assert parsed.long_description.strip() == "This function does parse a docstring."
    assert parsed.short_description == "This function does parse a docstring."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description is False

    a_docstring = '''
    Docstring with an error.
    :param arg1 int
        An integer.
   '''

# Generated at 2022-06-11 21:38:53.424873
# Unit test for function parse
def test_parse():
    text = inspect.cleandoc(
        """
    This is the description.

    This is the long description.

    :param optional arg_name: description here
    :type arg_name: str
    :param required arg_name: description here
    :param required arg_name: description here
    :type arg_name: str
    :param type_name? arg_name defaults to default_value.
    :returns: description here
    :rtype: type_name
    :yields: description here
    :raises TypeError: description here
    :raises: description here
    """
    )

# Generated at 2022-06-11 21:39:02.756395
# Unit test for function parse
def test_parse():
    docstring = parse('''Module to parse a reStructuredText-style docstring into
a dictionary of its all components.

Parameters
----------
arg1 : int
    Description of `arg1` in two lines.
    Second line is indented by 4 spaces.
arg2 : str
    Description of `arg2`.
arg_kwonly : str, optional
    Description of `arg_kwonly`. Defaults to "spam".

Returns
-------
str
    Description of return value.

Raises
------
TypeError
    If any of the arguments is not a string.
LookupError
    If the operation is unsuccessful.
''')
    assert docstring.short_description == "Module to parse a reStructuredText-style docstring into a dictionary of its all components."
    assert docstring.blank_after_short_description == False
   

# Generated at 2022-06-11 21:39:15.171977
# Unit test for function parse
def test_parse():
    doc = inspect.cleandoc("""
    :param message: The message to send
    :param optional: The message to send
    :param type_name: The message to send
    :param defaults to: The message to send
    :param message: The message to send
    :param defaults to: The message to send
    """)

    ret = parse(doc)
    assert ret.short_description is None
    assert ret.long_description is None
    assert ret.blank_after_short_description is False
    assert ret.blank_after_long_description is False
    assert len(ret.meta) == 3
    assert ret.meta[0].arg_name == "message"
    assert ret.meta[0].type_name is None
    assert ret.meta[0].is_optional is None
    assert ret.meta[0].default

# Generated at 2022-06-11 21:39:21.933517
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    parse("""\
        test
        :param a:
            1.
        :param b:
        :type a: int
        :rtype: int
        :return:
        :raises:
        :yield:
        :yields:
    """)

    try:
        parse("""\
            a:
                b:
        """)
        assert False
    except ParseError:
        pass

# Generated at 2022-06-11 21:39:29.475145
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(
        short_description=None,
        blank_after_short_description=None,
        long_description=None,
        blank_after_long_description=None,
        meta=[],
    )
    assert parse("hello world") == Docstring(
        short_description="hello world",
        blank_after_short_description=None,
        long_description=None,
        blank_after_long_description=None,
        meta=[],
    )
    assert parse("hello world\n==========") == Docstring(
        short_description="hello world",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=None,
        meta=[],
    )
    assert parse("hello world\n\nTest function.") == Doc

# Generated at 2022-06-11 21:39:39.319823
# Unit test for function parse
def test_parse():
    text = """\
    Docstring
    ---------
    Short description.

    Long description.

    :param type_name arg_name: description
    :raises SomeError: description
    :returns: description
    """


# Generated at 2022-06-11 21:39:51.497610
# Unit test for function parse
def test_parse():
    docstring = """
        First line of the summary

        More detailed description, if necessary.  Wrap it to about 72
        characters or so.
        """
    ds = parse(docstring)
    test_docstring = Docstring(short_description='First line of the summary',
                               long_description='More detailed description, if necessary.  Wrap it to about 72\ncharacters or so.',
                               blank_after_short_description=True,
                               blank_after_long_description=True,
                               meta=[])
    assert ds == test_docstring

    docstring = """
        Summary

        Yields:
            int: the next number in the Fibonacci sequence
            If the keyword argument recursive is True, yields
            FibonacciRecursive instead.
        """
    ds = parse(docstring)
   

# Generated at 2022-06-11 21:39:59.071567
# Unit test for function parse
def test_parse():
    docstring = """One line summary.
    Two line summary.

    One line description.

    Two line description.

    :type x: type
    :param x: description
    :param y: description
    :raises ValueError: description
    :returns: description
    :rtype: int
    """
    expected = parse(docstring)

# Generated at 2022-06-11 21:40:07.751533
# Unit test for function parse
def test_parse():
    doc = '''
    This is a test docstring.
    '''

    assert parse(doc).short_description == 'This is a test docstring.'
    assert parse(doc).long_description is None

    doc = '''
    This is a test docstring.

    This is the long description.
    '''

    assert parse(doc).short_description == 'This is a test docstring.'
    assert parse(doc).long_description == 'This is the long description.'
    assert parse(doc).blank_after_long_description is True
    assert parse(doc).blank_after_short_description is True

    doc = '''
    This is a test docstring.
    And this is the long description.
    '''

    assert parse(doc).short_description == 'This is a test docstring.'

# Generated at 2022-06-11 21:40:23.889841
# Unit test for function parse
def test_parse():
    # Empty text
    text = ''
    assert parse(text).short_description is None
    assert parse(text).long_description is None
    assert parse(text).blank_after_short_description is False
    assert parse(text).blank_after_long_description is False
    assert parse(text).meta == []

    # Only short description
    text = 'The first line'
    ret = parse(text)
    assert ret.short_description == 'The first line'
    assert ret.long_description is None
    assert ret.blank_after_short_description is False
    assert ret.blank_after_long_description is False
    assert ret.meta == []

    # Short and long descriptions
    text = 'The first line\n\nThe second line'
    ret = parse(text)

# Generated at 2022-06-11 21:40:34.982492
# Unit test for function parse
def test_parse():
    """Parse the ReST-style docstring into its components."""

# Generated at 2022-06-11 21:40:45.557236
# Unit test for function parse
def test_parse():
    text = """
        This is a short description.
        
        This is a long description.
        
        :param arg1: This is argument 1
        :param arg2: This is argument 2
        :param arg3: This is argument 3
        :type arg3: int, optional
        :param arg4: This is argument 4
        :type arg4: int, optional
        :param arg5: This is argument 5
        :type arg5: int, optional
        :param arg6: This is argument 6
        :type arg6: int, optional
        :returns: This is a return
        :rtype: int
        :raises keyError: This is an exception
        """

    docstring = parse(text)
    print(docstring)
    return docstring
    
    
docstring = test_parse()

# Generated at 2022-06-11 21:40:51.445835
# Unit test for function parse
def test_parse():
    text = """short description.

long description.

:param arg_name: arg description.
:param arg_name: arg description.
:param arg_name: arg description.
:param arg_name: arg description.
:param arg_name: arg description.
:param arg_name: arg description.
:param arg_name: arg description.
:param arg_name: arg description.
"""
    assert isinstance(parse(text), Docstring)

# Generated at 2022-06-11 21:41:02.172776
# Unit test for function parse

# Generated at 2022-06-11 21:41:13.037949
# Unit test for function parse
def test_parse():
    doc = parse('''\
    blah blah blah
    blah blah blah
    blah blah blah

    :param arg1: description 1
    :param arg2: description 2
    :param arg3: description 3

    :returns: type 1
    ''')
    assert(doc.short_description == 'blah blah blah')
    assert(doc.long_description == 'blah blah blah\nblah blah blah')
    assert(doc.blank_after_short_description == True)
    assert(doc.blank_after_long_description == False)
    assert(len(doc.meta) == 3)
    assert(doc.meta[0].args == ['param', 'arg1'])
    assert(doc.meta[0].description == 'description 1')
    assert(len(doc.meta) == 3)

# Generated at 2022-06-11 21:41:23.764216
# Unit test for function parse
def test_parse():
    text = """
    A short description of the function.

    A long description.

    :param arg: description of arg
    :type arg: int
    :param arg2: description of arg2
    :type arg2: int
    :returns: description of return value
    :rtype: int
    :raises: some exception
    """
    ret = parse(text)
    assert ret.short_description == "A short description of the function."
    assert ret.long_description == "A long description."
    assert ret.blank_after_short_description == False
    assert ret.blank_after_long_description == False
    assert len(ret.meta) == 4
    assert isinstance(ret.meta[0], DocstringParam)
    assert ret.meta[0].args == ["param", "arg"]
    assert ret.meta

# Generated at 2022-06-11 21:41:35.404226
# Unit test for function parse
def test_parse():
    docstring = """
    This is a summary.

    This is a long description.

    :param x: This is an argument.
    :type x: str
    :param y: This is an optional argument.
    :type y: int, optional
    :param z: This argument has a default value.
    :type z: int
    :returns: This is a return value description.
    :rtype: str
    :raises ValueError: This is a raised exception description.
    """

# Generated at 2022-06-11 21:41:46.568079
# Unit test for function parse
def test_parse():
    docstring = """
    Function Foo to bar.

    :param foo: Foo to convert
    :param bar: Bar
    :type foo: str
    :type bar: bool
    :returns: Converted foo
    :rtype: str
    :raises ValueError: If foo is bad
    """
    parsed = parse(docstring)

    assert parsed.short_description == "Function Foo to bar."
    assert not parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert parsed.long_description is None
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ["param", "foo", "bar", "type", "foo", "type", "bar"]
    assert parsed.meta[0].description == "Foo to convert"
    assert parsed.meta

# Generated at 2022-06-11 21:41:49.835738
# Unit test for function parse
def test_parse():
    """Run doctests on function parse"""
    import doctest
    from . import rst
    return doctest.testmod(rst)

if __name__ == "__main__":
    import sys

    sys.exit(test_parse())

# Generated at 2022-06-11 21:42:05.358033
# Unit test for function parse
def test_parse():
    """ Unit test for function parse.

    :return: None
    """
    assert parse("Nothing special.") == Docstring(
        short_description="Nothing special.",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse("First line.\n\nSecond line.") == Docstring(
        short_description="First line.",
        long_description="Second line.",
        blank_after_short_description=False,
        blank_after_long_description=True,
        meta=[],
    )

# Generated at 2022-06-11 21:42:14.829663
# Unit test for function parse

# Generated at 2022-06-11 21:42:19.900021
# Unit test for function parse
def test_parse():
    def func(index1: int, index2: int = 0, *, key: int):
        """
        First sentence of function docstring

        Second sentence of function docstring
        """
        pass

    docstring = parse(func.__doc__)
    print(docstring)


# Generated at 2022-06-11 21:42:30.653576
# Unit test for function parse
def test_parse():
    text = """
    The short description.

    :param int x: This is a parameter.
    :param int y: This is a parameter with a long description.

    One more line here.
    """
    doc = parse(text)
    assert doc.short_description == "The short description."
    assert doc.long_description == "One more line here."
    assert doc.blank_after_long_description
    assert doc.blank_after_short_description
    assert len(doc.meta) == 2
    assert isinstance(doc.meta[0], DocstringParam)
    assert doc.meta[0].arg_name == "x"
    assert doc.meta[0].type_name == "int"
    assert doc.meta[0].description == "This is a parameter."

# Generated at 2022-06-11 21:42:39.822728
# Unit test for function parse
def test_parse():
    from .common import Docstring, DocstringMeta, DocstringParam, DocstringReturns, DocstringRaises
    import unittest
    import typing as T

    class TestDocstringParse(unittest.TestCase):
        def test_empty(self):
            sut = parse("")
            self.assertIsNone(sut.short_description)
            self.assertEqual(sut.long_description, "")
            self.assertEqual(sut.meta, [])

        def test_basic(self):
            sut = parse(
                """\
                short description

                longer description goes here.

                :param foo: description of foo
                :param bar: description of bar"""
            )

            self.assertEqual(sut.short_description, "short description")

# Generated at 2022-06-11 21:42:49.756707
# Unit test for function parse
def test_parse():
    # docstring with all elements
    text = """
    Return X to the power of Y.

    :param int x: the base
    :param int y: the exponent
    :returns: X to the power of Y
    :raises ValueError: if X is negative

    This is an example of a function that contains
    multiple lines of documentation for each section.
    """
    docstring = parse(text)

    assert docstring.short_description == 'Return X to the power of Y.'
    assert docstring.long_description == 'This is an example of a function that contains\nmultiple lines of documentation for each section.'
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == True
    assert not docstring.meta

# Generated at 2022-06-11 21:42:58.724051
# Unit test for function parse
def test_parse():
    """ Tests that the parse function works as expected.
    """

    # Test the parse function with an empty docstring
    docstr_empty = parse("")
    assert docstr_empty.short_description == None
    assert docstr_empty.blank_after_short_description == False
    assert docstr_empty.long_description == None
    assert docstr_empty.blank_after_long_description == False
    assert docstr_empty.meta == []

    # Test the parse function with a simple docstring
    docstr_normal = parse("""\
    This is a normal docstring.
    It has only a short description.
    """)
    assert docstr_normal.short_description == "This is a normal docstring."
    assert docstr_normal.blank_after_short_description == False
    assert docstr_normal.long_

# Generated at 2022-06-11 21:43:10.339388
# Unit test for function parse
def test_parse():
    docstring = """\
        short_description

        longer_description

        :keyword arg1: Desc 1.
        :keyword arg2: Desc 2.
        :keyword arg3: Desc 3.

        :returns: Desc 4
        """
    d = parse(docstring)
    assert d.short_description == "short_description"
    assert d.long_description == "longer_description"
    assert len(d.meta) == 4
    assert d.meta[0].description == "Desc 1."
    assert d.meta[0].args == ["keyword", "arg1"]
    assert d.meta[1].description == "Desc 2."
    assert d.meta[1].args == ["keyword", "arg2"]
    assert d.meta[2].description == "Desc 3."

# Generated at 2022-06-11 21:43:20.293186
# Unit test for function parse
def test_parse():
    text = """
    Example docstring.

    This is a long description.

    :param a: this is a a
    :param b: this is a b
    :type a: int
    :type b: bool
    :returns int
    """

    # Test with complete docstring
    doc = parse(text)
    assert doc.short_description == "Example docstring."
    assert doc.long_description == "This is a long description."
    print(doc.meta)
    assert len(doc.meta) == 4
    assert isinstance(doc.meta[0], DocstringParam)
    assert doc.meta[0].arg_name == "a"
    assert doc.meta[0].type_name == None
    assert doc.meta[0].description == "this is a a"


# Generated at 2022-06-11 21:43:28.576595
# Unit test for function parse
def test_parse():
    text = '''
        The title of the description
        a description

        :param basestring name: name of the object
        :returns: the name
        '''
    doc = parse(text)
    assert doc.short_description == "The title of the description"
    assert doc.long_description == "a description"
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ['param', 'basestring', 'name']
    assert doc.meta[1].args == ['returns']
    assert isinstance(doc.meta[0], DocstringParam)
    assert isinstance(doc.meta[1], DocstringReturns)

# Test parse with bad docstring

# Generated at 2022-06-11 21:43:40.858334
# Unit test for function parse
def test_parse():
    text = """
        This is a short description.

        This is a long description.
        """
    doc = parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description is True
    assert doc.blank_after_long_description is False

    text = """
        This is a short description.

        This is a long description.

        """
    doc = parse(text)
    assert doc.blank_after_short_description is True
    assert doc.blank_after_long_description is True

    text = """
        This is a short description.

        This is a long description.

        :returns: a value
        """
    doc = parse(text)

# Generated at 2022-06-11 21:43:53.397764
# Unit test for function parse
def test_parse():
    # Test 1
    docstring = """Example script.
    
    :param int arg1: a command line arg
    :param str arg2: another arg
    :param bool arg3: another arg
    :return: return type
    :raises ValueError: raise exception
    """
    docstring = parse(docstring)
    assert len(docstring.meta) == 4
    assert docstring.short_description == "Example script."
    assert docstring.long_description == None

    # Test 2
    docstring = """Example script.
    
    An extended docstring.
    
    :param int arg1: a command line arg
    :param str arg2: another arg
    :param bool arg3: another arg
    :return: return type
    """
    docstring = parse(docstring)

# Generated at 2022-06-11 21:44:06.051738
# Unit test for function parse
def test_parse():
    print("test_parse")
    print("----------")
    doc = parse("""
    This is a short description of the function.

    Long description with some extras:

    * item1
    * item2

    :param p1: description for p1
    :param p2: description for p2
    :param p3: description for p3
    :param p4: description for p4
    :rtype: returns description
    :returns: returns description
    :yields: yields description
    :raises: raises description

    More text.

    And more text.
    """)

    print("Short desc:")
    print("-----------")
    print(doc.short_description)

    print("Long desc:")
    print("----------")
    print(doc.long_description.rstrip("\n"))


# Generated at 2022-06-11 21:44:14.741686
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('    ') == Docstring()
    assert parse('\n\n') == Docstring()
    assert parse('Foo.\n') == Docstring(
        short_description='Foo.', long_description=None, blank_after_short_description=True, blank_after_long_description=True, meta=[],
    )
    assert parse('Foo.\n\n') == Docstring(
        short_description='Foo.', long_description=None, blank_after_short_description=False, blank_after_long_description=True, meta=[],
    )

# Generated at 2022-06-11 21:44:24.217608
# Unit test for function parse
def test_parse():
    """Test parsing of ReST-style docstring.

    These are the ReST-style docstrings we need to parse:
    """
    assert parse("") == Docstring()

# Generated at 2022-06-11 21:44:34.858302
# Unit test for function parse
def test_parse():
    doc = parse('Example docstring.')
    assert doc.short_description == 'Example docstring.'
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.long_description == None

    doc = parse('''Example docstring.
    This is the long description.
    With multiple lines.''')
    assert doc.short_description == 'Example docstring.'
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.long_description == 'This is the long description. With multiple lines.'

    doc = parse('''Example docstring.

    This is the long description.
    With multiple lines.''')
    assert doc.short_description == 'Example docstring.'

# Generated at 2022-06-11 21:44:43.372036
# Unit test for function parse
def test_parse():
    ret = parse("""
    Test function.

    :param str x: test x
    :param str y: test y
    :return: test return
    :rtype: int
    :raises ValueError: exception
    """)

    assert ret.short_description == 'Test function.'
    assert ret.blank_after_short_description
    assert ret.long_description == None
    assert not ret.blank_after_long_description

    meta = ret.meta
    assert len(meta) == 4

    assert meta[0].description == 'test x'
    assert isinstance(meta[0], DocstringParam)
    assert meta[0].arg_name == 'x'
    assert meta[0].type_name == 'str'
    assert meta[0].is_optional == False
    assert meta[0].default == None

   

# Generated at 2022-06-11 21:44:53.417167
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a test function.

    :param arg1: the first argument
    :type arg1: str
    :param arg2: the second argument
    :type arg2: int
    :raises Exception: if anything goes wrong.
    :returns: a string
    :rtype: str
    '''

# Generated at 2022-06-11 21:45:06.136955
# Unit test for function parse
def test_parse():
    text = '''
    Short summary
    --------------------------------------------------------------------------------
    Long summary

    :param arg1: an arg
    :param arg2: an arg
    :param arg3: another arg
    :param arg4: the last arg
    :param arg5: maybe an arg?
    :param arg6: an arg that defaults to True.
    :param arg7: an arg that defaults to True.
    :param arg8: an arg that defaults to True.
    :type arg1: type1
    :type arg2: type2
    :returns: x
    :rtype: type1
    :raises: E1, E2
    :raises: E3, E4
    '''
    d = parse(text)
    assert d.short_description == 'Short summary'

# Generated at 2022-06-11 21:45:18.320113
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert (
        parse("Parse the *docstring* into its components.")
        == Docstring(short_description="Parse the *docstring* into its components.")
    )
    assert (
        parse("Parse the *docstring* into its components.\n\nThis function ...")
        == Docstring(
            short_description="Parse the *docstring* into its components.",
            long_description="This function ...",
            blank_after_short_description=True,
            blank_after_long_description=False,
        )
    )

# Generated at 2022-06-11 21:45:32.090836
# Unit test for function parse

# Generated at 2022-06-11 21:45:41.073235
# Unit test for function parse
def test_parse():
    """test docstring parse"""
    test_docstring = """
    test name:
    args: int test_arg
    args: str test_arg_1
    returns: dict
    returns: HttpResponse
    raises: test_except
    raises: test_except_1
    returns: str
    returns: int
    yields:
    """

    assert parse(test_docstring).meta[0].arg_name == "test_arg"
    assert parse(test_docstring).meta[1].arg_name == "test_arg_1"
    assert parse(test_docstring).meta[2].type_name == "dict"
    assert parse(test_docstring).meta[3].type_name == "HttpResponse"
    assert parse(test_docstring).meta[4].type_name == "test_except"
   

# Generated at 2022-06-11 21:45:51.308936
# Unit test for function parse
def test_parse():
    docstring = inspect.getdoc(parse)
    assert docstring is not None
    parsed = parse(docstring)
    assert parsed.short_description == "Parse the ReST-style docstring into its components."
    assert parsed.long_description
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert parsed.meta
    assert parsed.meta[0].args[0] == "text"
    assert parsed.meta[0].description == "docstring to parse"
    assert parsed.meta[0].arg_name == "text"
    assert parsed.meta[0].type_name == "str"
    assert not parsed.meta[0].is_optional
    assert not parsed.meta[0].default
    assert parsed.meta[1].args[0] == "returns"
   

# Generated at 2022-06-11 21:46:02.472764
# Unit test for function parse
def test_parse():
    from .common import function_signature
    from .common import DocstringReturns
    from .common import DocstringParam
    from .common import DocstringRaises
    assert parse("foo bar") == Docstring(
        short_description="foo bar",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse("foo\nbar") == Docstring(
        short_description="foo",
        long_description="bar",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-11 21:46:14.606432
# Unit test for function parse

# Generated at 2022-06-11 21:46:16.293720
# Unit test for function parse
def test_parse():
    return True


# Generated at 2022-06-11 21:46:23.456800
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring('', '')
    assert parse('заголовок') == Docstring('заголовок', '')
    assert parse('заголовок\n\nтекст') == Docstring('заголовок', 'текст')
    assert parse('заголовок\n\nтекст\n\n') == Docstring('заголовок', 'текст')
    assert parse('заголовок\nтекст') == Docstring('заголовок', 'текст')

   

# Generated at 2022-06-11 21:46:30.449202
# Unit test for function parse
def test_parse():
    text = """\
    Short description.

    Long description.

    :param arg1: description
    :param arg2: description
    :param arg3: description
    :param arg4: description\n\n"""

    expected = """
    Short description.

    Long description.

    :param arg1: description
    :param arg2: description
    :param arg3: description
    :param arg4: description
    """

    assert expected == parse(text).to_string()

# Generated at 2022-06-11 21:46:40.262183
# Unit test for function parse
def test_parse():
    # Basic parsing of docstring
    assert parse("") == Docstring()
    assert parse("Hello world.") == Docstring(
        short_description="Hello world.",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

    assert parse("Hello world.\nAnd\nthe world") == Docstring(
        short_description="Hello world.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="And\nthe world",
        meta=[],
    )
