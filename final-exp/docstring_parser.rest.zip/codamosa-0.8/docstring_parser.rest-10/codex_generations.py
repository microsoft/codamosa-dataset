

# Generated at 2022-06-11 21:36:50.848451
# Unit test for function parse
def test_parse():
    a_docstring = "QQQ\n    QQQ \n    QQQ \n    :WOW:QQQQ\n    :WOW:QQQ\n    :WOW:QQ"

    print(parse(a_docstring))

# Generated at 2022-06-11 21:36:57.729079
# Unit test for function parse
def test_parse():
    """Function to test module func parse."""
    text = """Docstring summary line.

    Extended description.

    :param str param_one: Description for param_one.
    :param int param_two: This is a parameter with a default value.
        Defaults to 2.
    :default param_three: 3
        This is a parameter with a default value. Defaults to 3.
    :raises ValueError: Wheeeeeeee.
    :raises TypeError: You can also set a default value on a raised error
        with the :default option.
    :rtype: str
    :returns: Nothing.
    """

# Generated at 2022-06-11 21:37:06.878990
# Unit test for function parse
def test_parse():
    docstring = Docstring(
        short_description="Test",
        long_description="this is a test",
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[
            DocstringReturns(
                args=["returns"],
                description="string",
                type_name="str",
                is_generator=False,
            ),
            DocstringParam(
                args=["param", "str", "a"],
                description="a is a string",
                arg_name="a",
                type_name="str",
                is_optional=False,
                default=None,
            ),
        ],
    )

# Generated at 2022-06-11 21:37:18.963850
# Unit test for function parse
def test_parse():
    def func():
        """This is a docstring with meta information.

        This function serves no purpose other than being a test case for
        :py:mod:`~.rest`.

        :param one: this is the first param
        :param str two: this is the second param
        :param :py:class:`~.Foo` three: this is the third argument
        :param four: this is the fourth argument; it defaults to ``"none"``
        :param five: this is the fifth argument
        :returns: the return value
        :rtype: str
        :raises Exception: if something goes wrong
        :raises ValueError: if something goes really wrong
        """


# Generated at 2022-06-11 21:37:30.266545
# Unit test for function parse
def test_parse():
    text = """\
    One line summary.
    This is a longer description.

    :param arg1: Parameter description
    :param arg2: Parameter description
    :param arg3: This arg has a default of 5.

    :return: Return description
    """
    ds = parse(text)
    assert ds.short_description == "One line summary."
    assert ds.blank_after_short_description
    assert ds.long_description == "This is a longer description."
    assert ds.blank_after_long_description

# Generated at 2022-06-11 21:37:38.248387
# Unit test for function parse
def test_parse():
    """docstring"""
    class_s = inspect.getdoc(Dummy)
    function_s = inspect.getdoc(Dummy.foo)
    
    assert len(parse(class_s).meta) == 3
    assert parse(function_s).short_description == "foo"
    assert parse(function_s).long_description.startswith("Do foo.")
    assert parse(function_s).meta[0].type_name == "int"
    assert parse(function_s).meta[1].arg_name == "b"
    assert parse(function_s).meta[2].type_name == "float"



# Generated at 2022-06-11 21:37:46.653086
# Unit test for function parse

# Generated at 2022-06-11 21:37:54.343747
# Unit test for function parse
def test_parse():
    doc = '''
    Args:
        x: the number of eggs.
        y: the number of eggs, defaults to 10. Optional.

    Raises:
        ValueError: if eggs are not available.
        TypeError: if x is not an int.

    Returns:
        The total number of eggs.
    '''

    docstring = parse(doc)
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['Args']
    assert docstring.meta[1].args == ['Raises']
    assert docstring.meta[2].args == ['Returns']

# Generated at 2022-06-11 21:38:05.864084
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

# Generated at 2022-06-11 21:38:17.081026
# Unit test for function parse
def test_parse():
    example = """
    Example function.

    This function outputs a random number along with a
    message.

    :param int n: maximum number to output (defaults to 10)
    :param str msg: message to print
    :raises ValueError: if input not greater than 0
    :returns: generated random number and message printed
    """
    docstring = parse(example)
    assert docstring.short_description == "Example function."
    assert docstring.long_description == (
        "This function outputs a random number along with a\n"
        "message."
    )
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is True
    assert len(docstring.meta) == 4

# Generated at 2022-06-11 21:38:35.742751
# Unit test for function parse
def test_parse():
    text = """
    Bla bla bla.

    :param a:
    :type a: int
    :param b:
    :type b: list
    :rtype: int | None
    """
    ret = parse(text)

# Generated at 2022-06-11 21:38:46.461483
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    doc = parse("""\
    Short description.

    Long description.

    :param arg: Description for arg.
    :type arg: str
    :return: Description for return value.
    """)


# Generated at 2022-06-11 21:38:50.142020
# Unit test for function parse
def test_parse():
    def f():
        """short description

        long description
        """

    assert parse(f.__doc__).short_description == "short description"
    assert (
        parse(f.__doc__).long_description == "long description"
    )



# Generated at 2022-06-11 21:39:02.116489
# Unit test for function parse
def test_parse():
    """test_parse whitespace"""
    assert Docstring().short_description is None
    assert Docstring().long_description is None
    assert Docstring().blank_after_short_description is False
    assert Docstring().blank_after_long_description is False

    """test_parse"""
    doc = parse("""
    : param : Foo
        Kooz
    """)
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert len(doc.meta) == 1
    assert doc.meta[0].arg_name == "Foo"
    assert doc.meta[0].description == "Kooz"
    assert doc.meta[0].is_optional is None


# Generated at 2022-06-11 21:39:06.310544
# Unit test for function parse
def test_parse():
    parse_test_text = """\
    Test function

    Some test

    :param name: A test
    :type name: int
    :yields: A value
    """

    docstring = parse(parse_test_text)

# Generated at 2022-06-11 21:39:11.304860
# Unit test for function parse
def test_parse():
    """Unit test for parse()."""
    import os
    import tempfile

    original = """
    The short description
    with an ' in it.

    The long
    description.
    """
    parsed = parse(original)

    assert original == parsed.reconstruct()



# Generated at 2022-06-11 21:39:23.156885
# Unit test for function parse
def test_parse():
    s = '''Short description.

This is a long description.

:param str arg1: First arg.
:param int arg2: Second arg.
:return: Return value.
:rtype: str
'''
    ret = parse(s)
    assert ret.short_description == "Short description."
    assert (
        ret.long_description
        == "This is a long description.\n\n    :param str arg1: First arg.\n    :param int arg2: Second arg.\n    :return: Return value.\n    :rtype: str\n    "
    )
    assert len(ret.meta) == 3
    assert ret.meta[0].args == ["param", "str", "arg1"]
    assert ret.meta[0].description == "First arg."

# Generated at 2022-06-11 21:39:27.331440
# Unit test for function parse
def test_parse():
    text = '''First line.
        Second line.


        :param name: Name.
        :type name: str
        :param age: Optional age.
        :type age: str
        :param score:
            score
            Score.
        :type score: int, optional

        :param what:
            What.
            Two lines.
        :default what: A

        :returns: A return.
        :rtype: str
    '''
    parse(text)
    return

# Generated at 2022-06-11 21:39:29.103583
# Unit test for function parse
def test_parse():

    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-11 21:39:39.127598
# Unit test for function parse
def test_parse():
    s = "Short description\n\nLong description\n\n:param type name: description\n:returns: description\n:raises TypeError: description\n"
    docstring = parse(s)
    assert docstring.short_description == "Short description"
    assert docstring.long_description == "Long description"
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is False
    assert docstring.meta[0].args == ["param", "type", "name"]
    assert docstring.meta[0].description == "description"
    assert docstring.meta[0].arg_name == "name"
    assert docstring.meta[0].type_name == "type"
    assert docstring.meta[0].is_optional is False

# Generated at 2022-06-11 21:39:54.242126
# Unit test for function parse

# Generated at 2022-06-11 21:40:04.731840
# Unit test for function parse
def test_parse():
    docstring_01 = """
    A function to do test.

    Parameters
    ----------
    a : that
    b : which
    c : for

    Returns
    -------
    str: A string.
    """
    parsed_docstring = parse(docstring_01)
    assert parsed_docstring.short_description == "A function to do test."
    assert len(parsed_docstring.meta) == 3
    assert parsed_docstring.meta[0].key == "param"
    assert parsed_docstring.meta[0].params[0] == "a"
    assert parsed_docstring.meta[0].params[1] == "that"
    assert parsed_docstring.meta[0].arg_name == "a"
    assert parsed_docstring.meta[0].type_name == "that"
   

# Generated at 2022-06-11 21:40:14.638444
# Unit test for function parse
def test_parse():
    d = """Summary line.

    Longer
    description
    (covering several
    lines).

    :param x: First bla bla bla.
    :type x: int
    :param y: Second bla bla bla.
    :type y: float
    :returns: (x+y)^2
    :rtype: float
    """
    parsed = parse(d)
    assert parsed.short_description == "Summary line."
    assert parsed.blank_after_short_description is True
    assert parsed.blank_after_long_description is True
    assert parsed.long_description == (
        "Longer\ndescription\n(covering several\nlines)."
    )
    assert len(parsed.meta) == 3
    assert parsed.meta[0].key == "param"

# Generated at 2022-06-11 21:40:24.590094
# Unit test for function parse
def test_parse():
    test_docstring = """
        Short description
        
        Long description
        
        :param arg: Arg description
        :type arg: str
        :returns: str
        :returns: NoneType
        :raises ValueError: If something goes wrong
        """
    doc = parse(test_docstring)
    
    assert doc.short_description == 'Short description'
    assert doc.long_description == 'Long description'
    
    assert doc.meta[0].arg_name == 'arg'
    assert doc.meta[0].type_name == 'str'
    assert doc.meta[0].is_optional is False
    assert doc.meta[0].default is None
    
    assert doc.meta[1].type_name == 'str'
    assert doc.meta[1].is_generator is False

# Generated at 2022-06-11 21:40:35.545691
# Unit test for function parse
def test_parse():
    """Testing parse"""
    assert parse("\n\n") == Docstring()
    assert parse("fdsafdsa fdsa fdsafdsa") == Docstring(
        short_description="fdsafdsa fdsa fdsafdsa", blank_after_short_description=True
    )
    assert parse("fdsafdsa\nfdsa\nfdsafdsa") == Docstring(
        short_description="fdsafdsa",
        blank_after_short_description=True,
        long_description="fdsa\nfdsafdsa",
        blank_after_long_description=True,
    )

# Generated at 2022-06-11 21:40:46.157652
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("     ") == Docstring()
    assert parse("Hello") == Docstring(
        short_description="Hello", blank_after_short_description=False,
        long_description=None, blank_after_long_description=False,
        meta=[]
    )
    assert parse("Hello\n\n    ") == Docstring(
        short_description="Hello", blank_after_short_description=True,
        long_description=None, blank_after_long_description=False,
        meta=[]
    )
    assert parse("Hello\n\n    world") == Docstring(
        short_description="Hello", blank_after_short_description=True,
        long_description="world", blank_after_long_description=False,
        meta=[]
    )


# Generated at 2022-06-11 21:40:54.630857
# Unit test for function parse
def test_parse():
    doc = parse(
        """
        Short description.

        Long description.

        :param arg1: The first argument.
        :type arg1: int
        :param arg1: The second argument.
        :type arg1: bool
        :key arg3:
            The third argument.
            A really long description.
            Maybe even multiple lines.
        :default arg3: 42
        :return: None
        :rtype: None
        :raises ValueError: The exception is raised.
        """
    )

    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."

    assert doc.blank_after_short_description
    assert doc.blank_after_long_description

    assert doc.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-11 21:41:05.654346
# Unit test for function parse
def test_parse():
    def f1(a):
        """This line exists, so that 'inspect.getsource(f1)'
        doesn't return None.

        :param a: an integer
        :type  a: int
        :returns: the value of argument a plus 1
        :rtype:   int
        """
        pass

    def f2(a, b=3):
        """This line exists, so that 'inspect.getsource(f2)'
        doesn't return None.

        :param a: an integer
        :type a: int
        :param b: an optional integer defaulting to 3
        :type b: int

        :returns: the sum of argument a and b
        :rtype:   int
        """
        pass


# Generated at 2022-06-11 21:41:16.220888
# Unit test for function parse
def test_parse():
    docstring = """Summary line.

        Extended description of function.
        Extended description continues here.

        :param name: The name to use.
        :param state: Current state to be in.
        :rtype: int
        :rtype: str
        :returns:  int if used as a classmethod. str if not.
        :raises keyError: Raises an exception
        :raises AttributeError: Raises when an unexpected attribute is accessed


        """
    parsed = parse(docstring)

    assert parsed.short_description == "Summary line."
    assert parsed.long_description == (
        "Extended description of function. Extended description continues here."
    )

    assert len(parsed.meta) == 5

    assert parsed.meta[0].args == ["param", "name"]

# Generated at 2022-06-11 21:41:23.703666
# Unit test for function parse
def test_parse():
    assert parse(None) == Docstring()
    assert parse("") == Docstring()
    assert parse("short") == Docstring(short_description="short")
    assert parse("short\n") == Docstring(short_description="short")
    assert parse("short\n\n") == Docstring(short_description="short")
    assert parse("short\nlong") == Docstring(
        short_description="short",
        blank_after_short_description=False,
        long_description="long",
        blank_after_long_description=False,
    )
    assert parse("short\n\nlong") == Docstring(
        short_description="short",
        blank_after_short_description=True,
        long_description="long",
        blank_after_long_description=False,
    )

# Generated at 2022-06-11 21:41:40.783900
# Unit test for function parse
def test_parse():
    doc = """Single line description.

This docstring has a longer description, which spans over several
lines.  It is followed by an empty line.

:param arg1:  The first argument.
:type arg1:  int

:param arg2:  The second argument.
:type arg2:  str
:default arg2:  default value

:returns:  a description of what is returned.
:rtype:  int

:raises Exception:  when an exception is raised.
    """

    parsed = parse(doc)

    assert parsed.short_description == "Single line description."

    assert parsed.long_description == """This docstring has a longer description, which spans over several
lines.  It is followed by an empty line.
"""

    assert parsed.blank_after_short_description == True
    assert parsed.blank

# Generated at 2022-06-11 21:41:50.179812
# Unit test for function parse
def test_parse():
    docstring = parse.__doc__

    assert( isinstance( docstring, Docstring ) )

    # short description
    assert( docstring.short_description == "Parse the ReST-style docstring into its components." )

    # long description
    assert( docstring.long_description == ":returns: parsed docstring\n" )

    # blank after short description
    assert( docstring.blank_after_short_description )

    # blank after long description
    assert( docstring.blank_after_long_description )

    # meta
    assert( len( docstring.meta ) == 1 )

    meta = docstring.meta[0]

    assert( isinstance( meta, DocstringReturns ) )

    assert( meta.args == ["returns"] )

    assert( meta.description == "parsed docstring" )



# Generated at 2022-06-11 21:42:00.842162
# Unit test for function parse
def test_parse():
    text = """
        short

        long

        :type arg1: string
        :arg1 arg1: some arg
        :type arg2: int
        :arg2 arg2: some arg

        :type arg1: string
        :arg1 arg1: some arg
        :yields: string
        :yields: int
    """
    docstring = parse(text)
    assert docstring.short_description == "short"
    assert docstring.long_description == "long"
    assert docstring.meta[0].description == "some arg"
    assert docstring.meta[0].type_name == "string"
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[1].description == "some arg"

# Generated at 2022-06-11 21:42:11.837839
# Unit test for function parse
def test_parse():
    text = '''
A short description of the function

    :param key1: description of the first argument
    :type key1: str
    :param key2: description of the second argument
    :type key2: str
    :returns: description of the return value
    :rtype: str
    :raises ValueError: if something went wrong
        '''
    print(parse(text))

    text = '''
A short description of the function

    :param key1: description of the first argument
    :type key1: str

    :param key2: description of the second argument, defaults to 123 for some
    :type key2: str

    :returns: description of the return value
    :rtype: str
        '''
    print(parse(text))


if __name__ == "__main__":
    test_

# Generated at 2022-06-11 21:42:13.186612
# Unit test for function parse
def test_parse():

    docstring = '''
    Args:
      a: int
      b:
    '''
    assert parse(docstring) == parse(docstring)

# Generated at 2022-06-11 21:42:23.255532
# Unit test for function parse
def test_parse():
    string = """short description.

:param type_name arg_name: description
:param type_name? arg_name: description defaults to something.
:param arg_name: description
:returns: something.
:rtype: type_name
:returns type_name: something.
:raises: something
:raises type_name: something
:yields: something
:yields type_name: something
"""
    docstring = parse(string)
    assert docstring.short_description == "short description."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-11 21:42:31.231678
# Unit test for function parse
def test_parse():
    # Simple test.
    def test():
        """A simple docstring.

        A long description.
        """

    d = parse(test.__doc__)
    assert d.short_description == "A simple docstring."
    assert d.long_description == "A long description."
    assert d.blank_after_short_description
    assert d.meta == []
    assert d.blank_after_long_description

    # No short description.
    def test():
        """
        A long description
        """

    d = parse(test.__doc__)
    assert d.short_description is None
    assert d.long_description == "A long description"
    assert not d.blank_after_short_description
    assert d.meta == []
    assert not d.blank_after_long_description

    # No long description

# Generated at 2022-06-11 21:42:36.786536
# Unit test for function parse
def test_parse():
    """unit test for parse
    """
    docstring = """
        :param name: (str) the name
        :param age: (int) age of person
        :param status: (str) the status of person
        :return:
        """
    print(parse(docstring))
    print(parse(docstring).meta)
    print(parse(docstring).meta[0])
    print(parse(docstring).meta[0].arg_name)

# Generated at 2022-06-11 21:42:38.053368
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-11 21:42:42.133900
# Unit test for function parse
def test_parse():
    docstring = """
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """
    assert parse(docstring).short_description == 'Parse the ReST-style docstring into its components.'

# Generated at 2022-06-11 21:42:51.658091
# Unit test for function parse
def test_parse():
    import pytest
    with pytest.raises(ParseError) as err:
        parse("foo\nbar")
    assert str(err.value) == "Error parsing meta information near 'bar'."

# Generated at 2022-06-11 21:42:57.264280
# Unit test for function parse
def test_parse():
    docstring = '''\
        short
        long

        :param str arg1: Argument 1
        :param arg2: Argument 2
        :return: None
        :raises ValueError: if something bad happens
        '''
    res = parse(docstring)
    assert res.short_description == "short"
    assert res.long_description == "long"
    assert res.blank_after_short_description == False
    assert res.blank_after_long_description == False



# Generated at 2022-06-11 21:43:08.595585
# Unit test for function parse
def test_parse():
    text = """
    Short description

    Long description.

    :arg: a:
    :param b: (optional)
    :type b: int
    :param c: (optional, defaults to x)
    :returns:
    :rtype: y
    :yields:
    :raises:
    """

# Generated at 2022-06-11 21:43:14.574278
# Unit test for function parse
def test_parse():
    test_str = """
    Short description.
    
    Long description.
    """
    expected = Docstring(
        short_description="Short description.",
        blank_after_short_description=False,
        long_description="Long description.",
        blank_after_long_description=True,
        meta=[],
    )
    ret = parse(test_str)
    assert ret == expected

    test_str = """
    Short description.
    :param type_name arg_name: argument description
    """

# Generated at 2022-06-11 21:43:19.662014
# Unit test for function parse
def test_parse():
    text = """
    Test parse
    ----------

    a docstring for test parse.

    :param int a: integer for test
    :param str b: string for test
    :param test_class c: test class for test

    :returns: str
    :rtype: str

    :return: int
    :rtype: int
    """
    print(repr(parse(text)))
    print(parse(text))


# Generated at 2022-06-11 21:43:28.851256
# Unit test for function parse
def test_parse():
    text = """Test.
    :param str arg1: Arg1.
    :param arg2: Arg2.
    :type arg2: str
    :param arg3: Arg3.
    :type arg3: int
    :rtype: bool
    :returns: Returns a bool.
    """
    doc = parse(text)
    assert doc.short_description == "Test."
    assert doc.blank_after_short_description is True
    assert doc.blank_after_long_description is True
    assert doc.long_description is None
    assert len(doc.meta) == 6

    assert doc.meta[0].key == "param"
    assert doc.meta[0].args == ["param", "str", "arg1"]
    assert doc.meta[0].description == "Arg1."

# Generated at 2022-06-11 21:43:41.650299
# Unit test for function parse
def test_parse():
    t = parse("""Test docstring.

    This is a test.

    :param test: The test
    :returns: the test, again
    """)
    assert t.meta[0].args == ['param', 'test']
    assert t.meta[0].description == 'The test'
    t = parse("""Test docstring.

    This is a test.

    :param test: The test
    :returns: the test, again
    :returns: another test
    """)
    assert t.meta[0].args == ['param', 'test']
    assert t.meta[0].description == 'The test'
    assert t.meta[1].args == ['returns']

# Generated at 2022-06-11 21:43:49.110172
# Unit test for function parse
def test_parse():
    text = """
    Summary line.

    Extended description.

    :param arg1: first arg
    :type arg1: int
    :param arg2: second arg
    :type arg2: string
    :raises TypeError: if incorrect type.
    :returns: None
    :rtype: int

    :param arg3: third arg
    :type arg3: None
    """
    assert parse(text) is not None



# Generated at 2022-06-11 21:43:58.077968
# Unit test for function parse
def test_parse():
    doc = parse("""
    This is the short description.

    This is the long description.
    """)

    assert doc.short_description == "This is the short description."
    assert doc.long_description == "This is the long description."
    assert doc.blank_after_short_description is True
    assert doc.blank_after_long_description is False

    doc = parse("""
    This is the short description.
    This is the long description.
    """)

    assert doc.short_description == "This is the short description."
    assert doc.long_description == "This is the long description."
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False

    doc = parse("This is the short description.")

# Generated at 2022-06-11 21:44:09.978785
# Unit test for function parse
def test_parse():
    docstring='''
    This is the short description
    This is the long description
    :param arg1: This is param arg1
    :type arg1: str
    :param arg2: This is param arg2
    :type arg2: str
    :param arg3: This is param arg3
    :type arg3: str
    :returns: This is return

    '''

# Generated at 2022-06-11 21:44:24.917308
# Unit test for function parse
def test_parse():
    a = "A\nB\nC\n"
    b = "A\n\nB\nC\n\n"
    c = "A\nB\n\nC\n\n"
    d = "A\n\n\nB\n\n\nC\n\n\n"
    e = "A\n\nB\n\n\nC\n\n\n"
    f = "A\n\n\nB\n\nC\n\n\n"
    assert inspect.cleandoc(a) == "A\nB\nC"
    assert inspect.cleandoc(b) == "A\nB\nC"
    assert inspect.cleandoc(c) == "A\nB\nC"
    assert inspect.cleand

# Generated at 2022-06-11 21:44:35.612441
# Unit test for function parse
def test_parse():
    text = """
    This is the short description.  It is typically one line long.

    Here is the long description.  It can be multiple lines long.  This
    particular description has two paragraphs.  It is separated
    from the short description by a blank line.

    :param int foo: This is a parameter description.  It can be
                    multiple lines.

    :param bytes bar: This is a multi-line parameter description for
                      ``bar``.  The second line of ``:param`` arguments
                      is indented with a single space.

    :param str spam: This is an optional parameter description.  It
                     also has a default value.

                     Defaults to ``'ham'``.
    """
    assert parse(text).short_description == "This is the short description."

# Generated at 2022-06-11 21:44:43.835501
# Unit test for function parse
def test_parse():
    text = """
    Parse the ReST-style docstring into its components.

    :param str text: docstring

    :returns: parsed docstring
    :rtype: Docstring
    """
    ret = parse(text)
    assert ret.short_description == "Parse the ReST-style docstring into its components."
    assert ret.long_description == ("Parametres\n----------\ntext : str\n    docstring")
    assert ret.blank_after_short_description is True
    assert ret.blank_after_long_description is True  
    assert ret.meta[0].args == ['param', 'str', 'text']
    assert ret.meta[0].description == 'docstring'
    assert ret.meta[0].arg_name == 'text'

# Generated at 2022-06-11 21:44:45.022686
# Unit test for function parse
def test_parse():
    docstring = Docstring()


# Generated at 2022-06-11 21:44:54.052303
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param x: First parameter.
    :type x: int or None
    :param y: Second parameter.
    :type y: int
    :param z: Parameter with a long description that would span multiple lines.
    :type z: int
    :param int bar: Parameter with a type on the left side.
    :return: Return value.
    :rtype: int
    :raises ValueError: If x is negative.
    """
    doc = parse(text)

    assert doc.short_description == "This is a test function."
    assert doc.long_description == ""
    assert doc.blank_after_short_description is True
    assert doc.blank_after_long_description is False


# Generated at 2022-06-11 21:45:06.641596
# Unit test for function parse
def test_parse():
    ds = Docstring()

# Generated at 2022-06-11 21:45:18.758406
# Unit test for function parse
def test_parse():
    doc = """
    This is the short description.

    This is the long description.

    This is a very long description which contains paragraphs.

    :param a: int
        This is the description for a.

    :param b: int, optional
        This is the description for b.

    :returns: int
        This is the description for return.
        This is the second line of the description for return.

    :raises ValueError: if validation fails
    """


# Generated at 2022-06-11 21:45:29.152406
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = """
        Compute the mean of a sequence of values.

        :param x:  Sequence of values 
        :type x: sequence of numbers
        :param axis: The axis along which the mean is computed.
                    If None, compute the mean of the flattened array.
        :type axis: int, optional, defaults to None
        :param out: The destination array.
        :type out: array_like, optional
        :returns:  Mean of values."""
    parsed = parse(text)
    assert parsed.short_description == "Compute the mean of a sequence of values."
    assert parsed.blank_after_short_description
    assert parsed.long_description == None
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3

# Generated at 2022-06-11 21:45:39.196556
# Unit test for function parse
def test_parse():
    assert parse("text") == Docstring(short_description="text")
    assert parse("text\n") == Docstring(short_description="text")
    assert parse("") == Docstring()

    assert parse("text\n\n  long") == Docstring(
        short_description="text",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="long",
    )

    assert parse("text\nlong") == Docstring(
        short_description="text",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description="long",
    )


# Generated at 2022-06-11 21:45:50.061145
# Unit test for function parse
def test_parse():
    t = '''
    This is a short summary.

    This is a long summary. A long summary can span multiple lines.

    :param str arg1: The first positional argument.
    :param arg2: (optional) The second positional argument.
    :type arg2: int
    :param keyword_arg: (optional) A keyword argument.
    :type keyword_arg: str
    :param keyword_arg_with_default: (optional) Another keyword argument.
        Defaults to 'spam'.
    :type keyword_arg_with_default: str
    :returns: The return value.
    :rtype: int
    :raises Exception: An exception is raised.
    '''

    d = parse(t)
    assert d.short_description == 'This is a short summary.'

# Generated at 2022-06-11 21:46:04.277764
# Unit test for function parse

# Generated at 2022-06-11 21:46:16.751211
# Unit test for function parse

# Generated at 2022-06-11 21:46:23.728388
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc("""
    Return the value of the given attribute of an object.

    :param obj: object in which to look for the attribute
    :type obj: object
    :param name: the attribute name
    :type name: str
    :raises AttributeError: if the attribute can't be found
    :returns: the value of the given attribute
    :rtype: object
    """)

# Generated at 2022-06-11 21:46:26.322847
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    return


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:46:36.895262
# Unit test for function parse
def test_parse():
    text = '''
    :param str arg_name: the name of the argument
    :param None? type_name: the type of the argument
    :param False default: the default value of the argument
       A long description of the parameter.
    :yields int: a number

    A docstring.
    '''
    docstring = parse(text)
    assert docstring.short_description == "A docstring."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.long_description is None
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "str", "arg_name"]