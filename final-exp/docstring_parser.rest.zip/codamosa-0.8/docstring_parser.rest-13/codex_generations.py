

# Generated at 2022-06-11 21:37:06.678374
# Unit test for function parse
def test_parse():
    do_test = lambda text: parse(inspect.cleandoc(text))

    assert do_test("") == Docstring()
    assert do_test("Test.") == Docstring(
        short_description="Test.",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    assert do_test("Test.") == Docstring(
        short_description="Test.",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

# Generated at 2022-06-11 21:37:18.692677
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc("""
    This is a long description. It can be multiple lines long.

    :param a_param: This is a parameter.
    :param b_param: This is another parameter.
    :param c_param: This is yet another param with a type, :class:`int`.
    :returns: This is what is returned.
    :raises ValueError: this is because of this.
    """)

# Generated at 2022-06-11 21:37:27.649441
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a summary.

    This is a description.

    :param int a: This is a.
    :param str b: This is b.
    :param dict c: This is c.
    :returns dict: Description of return value.
    :raises ValueError: Description of what causes a.
    :raises MyError: Description of what causes b.
    :raises: Description of what causes c.
    '''
    doc = parse(docstring)
    print(doc)

# Generated at 2022-06-11 21:37:34.694259
# Unit test for function parse
def test_parse():
    """Parsing a ReST-style docstring."""


# Generated at 2022-06-11 21:37:42.731114
# Unit test for function parse
def test_parse():
    string = """
    This is a docstring with some meta information. This is the short description.

    This is the long description, of arbitrary length.

    :param name: the name of the user
    :param other: another parameter

    :returns: something that is returned
    :raises ValueError: if a value was invalid
    :raises IOError: if there was a problem accessing file

    :yields: a generator object
    :yields str: the next item in the generator
    """

    result = parse(string)
    import pprint
    pprint.pprint(result)
    print(result.short_description)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:37:52.517488
# Unit test for function parse
def test_parse():
    # pylint: disable=missing-docstring
    from .common import DocstringMeta, DocstringParam, DocstringReturns

    # pylint: disable=line-too-long
    def assert_parse(text, expected_short=None, expected_long=None, expected_meta=None):
        result = parse(text)
        assert result.short_description == expected_short
        assert result.long_description == expected_long
        assert result.meta == expected_meta

    assert_parse(
        "Compute the result.",
        expected_short="Compute the result.",
    )

    assert_parse(
        "Compute the result.\n\nLong description.",
        expected_short="Compute the result.",
        expected_long="Long description.",
    )


# Generated at 2022-06-11 21:38:00.247400
# Unit test for function parse
def test_parse():
    parse("""
    test
    :param foobar: test of docstring
    :raises Exception: test of docstring
    :returns: test of docstring
    """)

if __name__ == "__main__":
    print(parse("""
    test
    :param foobar: test of docstring
    :raises Exception: test of docstring
    :returns: test of docstring
    """))

# Generated at 2022-06-11 21:38:09.696967
# Unit test for function parse
def test_parse():
    docstring = Docstring()
    docstring.short_description = 'Example of docstring'
    docstring.blank_after_short_description = True
    docstring.blank_after_long_description = True
    docstring.long_description = None
    docstring.meta = [
        DocstringMeta(
            args=[':param type name:', 'description', 'of', 'the', 'parameter'],
            description=None,
        ),
        DocstringParam(
            args=[':param type name:', 'description', 'of', 'the', 'parameter'],
            description=None,
        ),
    ]
    assert parse('') == Docstring()
    assert parse('No short description') == Docstring(
        short_description='No short description',
    )
    assert parse('\nNo short description') == Doc

# Generated at 2022-06-11 21:38:20.525211
# Unit test for function parse
def test_parse():
    assert parse(
        """ tests the parse function
        """
    ) == Docstring(
        short_description="tests the parse function",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    assert parse(
        """ first line
        second line
        """
    ) == Docstring(
        short_description="first line",
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description="second line",
        meta=[],
    )

# Generated at 2022-06-11 21:38:32.029860
# Unit test for function parse

# Generated at 2022-06-11 21:38:49.005276
# Unit test for function parse
def test_parse():
    docstr = """\
    Superclass for all web parameters.

    :param name: the parameter name
    :param kind: the type of the parameter; either 'query',
     'path', 'body', or 'form'
    :param description: description of the parameter 
      as a string; optional
    :param required: True if a value for this parameter
     is required, False otherwise; optional
    :param deprecated: True if this parameter is
     deprecated, False otherwise; optional
    :param schema: the schema for the parameter; optional
    :param allowEmptyValue: True if the parameter
     can be sent without a value, False otherwise;
     False by default
    """


# Generated at 2022-06-11 21:39:01.268623
# Unit test for function parse
def test_parse():
    assert parse('line1\nline2') == Docstring(
        short_description='line1',
        blank_after_short_description=False,
        long_description='line2',
        blank_after_long_description=False,
        meta=[]
    )
    assert parse('line1\n\nline2') == Docstring(
        short_description='line1',
        blank_after_short_description=True,
        long_description='line2',
        blank_after_long_description=False,
        meta=[]
    )

# Generated at 2022-06-11 21:39:06.257852
# Unit test for function parse
def test_parse():
    """Test function parse."""
    doc = """
    :return: Returns the value of the function.
    :rtype: String
    """
    assert parse(doc).meta[0].type_name == 'String'
    assert parse(doc).meta[0].description == 'Returns the value of the function.'

# Generated at 2022-06-11 21:39:17.000066
# Unit test for function parse
def test_parse():
    assert parse(None) == Docstring()
    assert parse("") == Docstring()

    # Single line short description
    text = "I am batman."
    assert parse(text) == Docstring(
        short_description="I am batman.",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )

    # Single line short description with a trailing blank line
    text = "I am batman.\n"
    assert parse(text) == Docstring(
        short_description="I am batman.",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

    # Single line short description with two trailing blank lines
    text = "I am batman.\n\n"

# Generated at 2022-06-11 21:39:21.813104
# Unit test for function parse
def test_parse():
    docstring = parse("""\
        This is the short description.

        This is the long description. It can span multiple lines.

        :yields str: description of the yielded thing
        :param bool x: description of the x parameter
        :param int y: description of the y parameter
        :raises ValueError: if x < 0
        :raises RuntimeError: if y < 0
        :returns: description of the returned object
        :returns int: description of the returned object of type int
        :yields: description of the yielded object
        :yields int: description of the yielded object of type int
        :param z: description of the z parameter
        :params int z: description of the z parameter
        :type z: str
        :type z: int
        :arg z: description of the z parameter
        """)

   

# Generated at 2022-06-11 21:39:29.429810
# Unit test for function parse
def test_parse():
    # basic test
    # the docstring comes from function test function in test_parser.py
    # the function returns false, so there are no returns description
    docstring = '''
    This is the short description

    This is the long description.
    It continues here.

    It has blank lines before and after.

    :param str arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    :raises ValueError: For invalid input.
    :raises TypeError: For invalid input types.
    :raises KeyError: When the input is not found.
    :raises: Any other exception.
    :other: Some random meta.
    '''
    assert parse(docstring).short_description == "This is the short description"

# Generated at 2022-06-11 21:39:34.570083
# Unit test for function parse
def test_parse():
    docstring = """
    Do something.

    :param x: first parameter
    :param y: second parameter

    :returns: something
    """

    doc = parse(docstring)

    assert doc.short_description == "Do something."
    assert doc.long_description == ""
    assert doc.meta

# Generated at 2022-06-11 21:39:43.846812
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Longer description.

    :param arg1: This is the first argument.
    :type arg1: str
    :param arg2: This is the second argument.
    :type arg2: str
    :returns: This is a description of the return value.
    :rtype: str
    :raises arg1: This is an error raised by arg1.
    :raises arg2: This is an error raised by arg2.

    """

# Generated at 2022-06-11 21:39:54.603975
# Unit test for function parse
def test_parse():
    assert isinstance(parse(""), Docstring)
    assert isinstance(
        parse(
            """\
        An example docstring.

        :param param1: The first parameter.
        :param param2: The second parameter.
        :returns: Description of return value.
        :raises keyError: raises an exception
        """
        ),
        Docstring,
    )
    assert parse("Test parsing") == Docstring(
        short_description="Test parsing",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-11 21:40:05.023699
# Unit test for function parse
def test_parse():
    text = '''
        This function does something amazing.

        It's long description may explain in detail
        how it does it.

        :param int a: first parameter
        :param b: second parameter
        :type a: int
        :type b: str
        :param c: third parameter (optional)
        :type c: str
        :param d: fourth parameter (with a really long
            description that continues
            over multiple lines)
        :param e: Answer to the Ultimate Question of Life,
            the Universe, and Everything

        :returns:
            Description of the things returned.

        :raises ValueError: when things go wrong
    '''
    docstring = parse(text)
    assert docstring.short_description == "This function does something amazing."

# Generated at 2022-06-11 21:40:19.289529
# Unit test for function parse
def test_parse():
    content = """
    a short description

    a long description

    :param arg1: this is the first argument
    :param str arg2: this is the second argument
    :param str arg3: this is the third argument
    :param str arg4=None: this is the fourth argument

    """

    d = parse(content)
    print(d)
    print("\n")
    for m in d.meta:
        print(m)
    print("\n")
    print("\n")
    print("\n")


# Generated at 2022-06-11 21:40:27.188280
# Unit test for function parse
def test_parse():
    text_full = """This is a full docstring with long
description, parameters and return types.

    :param foo:
        foo bar
    :param baz:
        baz qux
    :returns int:
        returns quux
    :raises ValueError: if
        anything goes wrong
"""
    text_empty = ""
    text_short = "This is a short docstring."
    text_long = "This is a short docstring.\n\nThis is a long docstring."
    text_meta_short = "This is a docstring with a parameter.\n\n    :param foo:"
    text_meta_long = """This is a docstring with a parameter and long
description.

    :param foo:
        foo bar
"""

# Generated at 2022-06-11 21:40:37.012869
# Unit test for function parse
def test_parse():
    docstring_text = '''One-line summary.

    More lengthy description.

    :param int x: Param x
    :param list[int] y:
        Param y
    :returns: The return type
    :return:
    :rtype:
    :yields:
    '''
    docstring = parse(docstring_text)
    assert docstring.short_description == 'One-line summary.'
    assert docstring.long_description == 'More lengthy description.'
    assert len(docstring.meta) == 8
    docstring_text = '''One-line summary.

    :param int x: Param x
    :param list[int] y:
        Param y
    :returns: The return type
    :return:
    :rtype:
    :yields:
    '''
    doc

# Generated at 2022-06-11 21:40:41.796245
# Unit test for function parse
def test_parse():
    docstring = """
    Sums two numbers and returns the result.

    :param x: first integer
    :param y: second integer
    :returns: sum of the two integers
    :rtype: integer
    """
    assert parse(docstring).meta[-1].arg_name == "y"


# Generated at 2022-06-11 21:40:43.209090
# Unit test for function parse
def test_parse():
    text = """
    This is a short description.

    This is a long description.
    """
    print(parse(text))



# Generated at 2022-06-11 21:40:52.733597
# Unit test for function parse
def test_parse():
    docstring = parse("""
        This is a long description.

        :param arg: The argument.
        :param arg?: The optional argument.
        :param arg?: The optional argument.
        :param arg: The argument.
        :param arg?: The optional argument. default is 123.
        :returns: The return value.
        :returns int: The return value.
        :return: The return value.
        :return int: The return value.
        :yields: The yield value.
        :yields int: The yield value.
        :raises: The exception.
        :raises int: The exception.
        :type item: The item's type.
        :type item?: The item's type.
    """)

    assert docstring.short_description == "This is a long description."
    assert docstring.long

# Generated at 2022-06-11 21:40:58.116236
# Unit test for function parse
def test_parse():
    import pprint
    sample_file = open('../test/test_docstring_parser.py')
    sample_docstring = sample_file.read()
    pprint.pprint(vars(parse(sample_docstring)))


# run tests for this module
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:41:07.377680
# Unit test for function parse
def test_parse():
    import textwrap as tw


# Generated at 2022-06-11 21:41:17.846530
# Unit test for function parse
def test_parse():
    docstring = """
        Short description.

        Long description.

        :param arg1: argument 1
        :type arg1: int
        :param arg2: argument 2
        :type arg2: str
        :param arg3: argument 3
        :type arg3: float
        :raises Exception1: error1
        :raises Exception2: error2
        :returns: None
    """

# Generated at 2022-06-11 21:41:26.503097
# Unit test for function parse
def test_parse():
    print("Function: test_parse()")
    docstring = '''
    Compute the x and y coordinates for points on a sine curve

    :param int n: The number of points to create
    :param float t: The length of the curve
    :returns: a list of tuples, containing the x and y coordinates of the points on the curve
    '''
    ret = parse(docstring)
    assert ret.short_description == "Compute the x and y coordinates for points on a sine curve"
    assert ret.long_description == "The number of points to create\nThe length of the curve"
    assert ret.blank_after_short_description
    assert not ret.blank_after_long_description
    assert len(ret.meta) == 2
    assert isinstance(ret.meta[0], DocstringParam)

# Generated at 2022-06-11 21:41:41.113330
# Unit test for function parse
def test_parse():
    text = """
    One line summary.

    Long description.

    :param arg1: description of arg1
    :param arg2: description of arg2
    :param arg3: description of arg3

    :returns: description of return value
    :raises ValueError: if something goes wrong
    """
    docstring = parse(text)
    print("short description:", docstring.short_description)
    print("long description:", docstring.long_description)
    for param in docstring.params:
        print("param:", param.arg_name, param.description)
    for returns in docstring.returns:
        print("returns:", returns.description)
    for raises in docstring.raises:
        print("raises:", raises.description)


# Generated at 2022-06-11 21:41:51.241917
# Unit test for function parse
def test_parse():
    test_input = """
    Short description.

    Long description.

    :param arg1: The first argument.
    :param arg2: The second argument. This can be very,
                 very long.
    :param arg3: The third argument.
    :param arg4: The fourth argument.
    :param arg5: The fifth argument.
    :param arg6: The sixth argument.
    :param arg7: The seventh argument.
    :param arg8: The eighth argument.
    :param arg9: The ninth argument.
    """

# Generated at 2022-06-11 21:42:01.791675
# Unit test for function parse
def test_parse():
    docstring_text = """Short summary.
    Extended summary.

    :param foo: Bar.
    :param filter: Filter.
    :param filter: Filter.
    :param bar: Baz.
    :param bar: Baz.
    :param bar: Baz.
    :returns: Return value.
    :return: Return value.
    :return: Return value.
    :rtype: int
    :yields: Yield value.
    :yield: Yield value.
    :yield: Yield value.
    :raises ValueError: For an invalid value.
    """
    docstring = parse(docstring_text)
    assert docstring.short_description == "Short summary."
    assert docstring.long_description == "Extended summary."
    assert docstring.blank_after_short_description == False


# Generated at 2022-06-11 21:42:10.329241
# Unit test for function parse
def test_parse():
    text = """
    This is a description.
    
    
    :param first_arg: first arg
    :param second_arg: second arg
    """
    result = parse(text)
    assert result.short_description == "This is a description."
    assert result.long_description is None
    assert result.blank_after_short_description
    assert not result.blank_after_long_description

    assert len(result.meta) == 2
    assert result.meta[0].arg_name == "first_arg"
    assert result.meta[1].arg_name == "second_arg"

    text = """
    :type param1: str
    :type param2:
        str
    :type param2:
        str"""
    result = parse(text)
    assert len(result.meta) == 3

# Generated at 2022-06-11 21:42:21.863568
# Unit test for function parse
def test_parse():
    res = parse('''
        Short description

        Long description
    ''')
    assert res == Docstring(
        short_description='Short description',
        long_description='Long description',
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[]
    )

    res = parse('''
        Short description

            Long description
    ''')
    assert res == Docstring(
        short_description='Short description',
        long_description='Long description',
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[]
    )

    res = parse('''
        :param str foo: Foo''')


# Generated at 2022-06-11 21:42:26.579746
# Unit test for function parse
def test_parse():
    string1 = "This is docstring 1."
    string2 = "This is docstring 2."
    string3 = "This is docstring 3."
    string4 = "This is docstring 4."

    docstring = parse("")
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    print("Passed test case: test_parse 1")

    docstring = parse("This is docstring 1.")
    assert docstring.short_description == string1
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-11 21:42:36.829594
# Unit test for function parse
def test_parse():
    text1 = """
        """
    d1 = parse(text1)
    assert d1.short_description is None
    assert d1.long_description is None
    assert d1.blank_after_short_description is False
    assert d1.blank_after_long_description is False
    assert len(d1.meta) == 0
    assert d1.meta == []

    text2 = """First line

        """
    d2 = parse(text2)
    assert d2.short_description == "First line"
    assert d2.long_description is None
    assert d2.blank_after_short_description is True
    assert d2.blank_after_long_description is False
    assert len(d2.meta) == 0
    assert d2.meta == []

    text3 = """First line
        """

# Generated at 2022-06-11 21:42:46.972239
# Unit test for function parse
def test_parse():
    d = """**foo**

    :param a Something :type a: int
    """
    assert parse(d) == Docstring(
        short_description="**foo**",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[
            DocstringParam(
                args=['param', 'a', 'Something'],
                description='type a: int',
                arg_name='a',
                type_name='int',
                is_optional=None,
                default=None,
            )
        ]
    )


# Generated at 2022-06-11 21:42:57.369186
# Unit test for function parse

# Generated at 2022-06-11 21:43:09.172175
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("a") == Docstring(
        short_description="a",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert parse("a\n") == Docstring(
        short_description="a",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert parse("a\nb") == Docstring(
        short_description="a",
        long_description="b",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )

# Generated at 2022-06-11 21:43:29.319278
# Unit test for function parse
def test_parse():
    text = """
    split the string in words

    :param str text: text to split
    :returns: a list of word
    :rtype: list of str
    """
    doc = parse(text)

    assert doc.short_description == "split the string in words"
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert len(doc.meta) == 2
    assert doc.meta[0].key == "param"
    assert doc.meta[0].arg_name == "text"
    assert doc.meta[0].type_name == "str"
    assert doc.meta[0].is_optional is False
    assert doc.meta[0].default is None

# Generated at 2022-06-11 21:43:41.853649
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a docstring
    '''
    parsed = parse(docstring)
    assert parsed.short_description.strip() == "This is a docstring"

    docstring = '''
    This is a docstring


    This is the long description
    '''
    parsed = parse(docstring)
    assert parsed.short_description.strip() == "This is a docstring"
    assert parsed.long_description.strip() == "This is the long description"

    docstring = '''
    This is a docstring

    :param type_name arg_name: This is a description.
    '''
    parsed = parse(docstring)
    assert parsed.short_description.strip() == "This is a docstring"
    assert len(parsed.meta) == 1
    assert parsed.meta

# Generated at 2022-06-11 21:43:45.986283
# Unit test for function parse
def test_parse():
    text = '''
    Get the current date and time.

    Returns the current date and time,
    as an integer.
    :returns int: the current date and time
    '''
    #assert parse(text) == True



# Generated at 2022-06-11 21:43:56.122481
# Unit test for function parse
def test_parse():
    test_docstring = """`func` is just a wrapper for `func2` and `func3`.\n
    :param arg1: an argument\n
    :param arg2 (int): a second argument, defaults to `21`.\n
    :returns: the result of `func2`\n
    :raises TypeError: if `arg1` is not a string.\n
    :raises ValueError: if `arg2` is not a number."""
    ds = parse(test_docstring)
    print(ds.short_description)
    print(ds.long_description)
    for kw in ds.meta:
        print(kw)
        print()


# Generated at 2022-06-11 21:44:07.910297
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('hi') == Docstring(short_description='hi')
    assert parse('hi\n\nbye') == Docstring(short_description='hi', long_description='bye')
    assert parse('hi\nbye') == Docstring(short_description='hi', blank_after_short_description=True, long_description='bye')
    assert parse('hi\n\nbye\n') == Docstring(short_description='hi', long_description='bye', blank_after_long_description=True)
    assert parse('hi\n:a: b') == Docstring(
        short_description='hi',
        meta=[DocstringMeta(args=['a'], description='b')]
    )
    assert parse('hi\n\nbye\n:a: b') == Docstring

# Generated at 2022-06-11 21:44:16.165890
# Unit test for function parse
def test_parse():
    test_docstring = """Function to square a number.
    
    This function just squares a number.

    :param n: The number to square.
    :type n: int
    :param m: The number to multiply by.
    :type m: int, optional
    :returns: The square of n.
    :rtype: int

    """

    parsed_docstring = parse(test_docstring)

    print(parsed_docstring.short_description)
    print(parsed_docstring.blank_after_short_description)
    # print(parsed_docstring.blank_after_long_description)
    print(parsed_docstring.long_description)
    print(parsed_docstring.meta[0].args)

# Generated at 2022-06-11 21:44:26.848500
# Unit test for function parse
def test_parse():
    s = """\
Hello world.

This is a longer description of
what this thing does.

:param foo: Param description
  goes here.
:yields: yield description
:returns: return description
:raises ValueError: This is some more
  text.
:param bar: Another param description.
:raises NameError: This is some more
  text.
:yields: yield description
:yields: yield description
:returns: return description
"""

# Generated at 2022-06-11 21:44:38.088714
# Unit test for function parse
def test_parse():
    print("Function parse")
    docstring = """The remove() method removes the item which is passed as an argument.

    :param x:

    The remove() method removes the item at the given index or
    the first occurrence of the given element.

    :param y:
    :type y: int
    :param z:
    :type z: int
    :param t:
    :type t: int
    :returns: The list after performing the remove operation.
    :rtype: list
    """

    answers = """The remove() method removes the item which is passed as an argument.

    The remove() method removes the item at the given index or
    the first occurrence of the given element.

    """

# Generated at 2022-06-11 21:44:43.877506
# Unit test for function parse
def test_parse():
    doc = """\
        hello() method

        hello to all

        :param x: first argument
        :type x: int
        :param y: second argument
        :type y: int
        :returns: int
        :raises ValueError: always
        :returns: int
        """
    parsed_doc = parse(doc)
    print(parsed_doc)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:44:53.654244
# Unit test for function parse
def test_parse():
    doc = parse("""\

    This is the summary.

    This is the first line of the description.

    And this is the second line.

    :param int param: This is a parameter
    :param str name: This is a name

    :returns: This is the return statement
    :rtype: str

    """)
    assert doc.short_description == "This is the summary."
    assert doc.long_description == (
        "This is the first line of the description.\n"
        "And this is the second line."
    )
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is True
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ["param", "int", "param"]

# Generated at 2022-06-11 21:45:09.085077
# Unit test for function parse
def test_parse():
    TEST_DOCSTRING_1 = ''
    TEST_DOCSTRING_2 = '''
    :returns: None
    '''
    TEST_DOCSTRING_3 = '''
    :returns: None
    :rtype: str
    '''
    TEST_DOCSTRING_4 = '''
    :returns: None
                              ...
    '''
    TEST_DOCSTRING_5 = '''
    :returns: None
                              ...
    :raises: None
    '''
    TEST_DOCSTRING_6 = '''
    :returns: None
    '''
    TEST_DOCSTRING_7 = '''
    '''
    TEST_DOCSTRING_8 = '''
    '''
    TEST_DOCSTRING_9 = '''
    '''

    assert parse

# Generated at 2022-06-11 21:45:21.019658
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a test function.
    
    :param some_arg: a description
    :type some_arg: int
    '''
    docstring = parse(docstring)
    assert len(docstring.meta) == 2
    assert docstring.meta[0].arg_name == 'some_arg'
    assert docstring.meta[0].type_name == None
    assert docstring.meta[0].description == 'a description'

    assert docstring.meta[1].arg_name == None
    assert docstring.meta[1].type_name == 'int'
    assert docstring.meta[1].description == None

    docstring = '''
    This is a test function.
    
    :return: a return value
    :type: int
    '''

# Generated at 2022-06-11 21:45:30.450562
# Unit test for function parse
def test_parse():
    s = """The short description.

The long description.

:param p1: a parameter
:param p2: another parameter

:returns ``int``: an integer value

:other: Anything else.
"""
    doc = parse(s)

    assert doc.short_description == "The short description."
    assert doc.long_description == "The long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description

    assert len(doc.meta) == 3
    assert doc.meta[0].keyword == "param"
    assert doc.meta[0].arg_name == "p1"
    assert doc.meta[0].description == "a parameter"
    assert doc.meta[1].keyword == "param"

# Generated at 2022-06-11 21:45:40.038852
# Unit test for function parse
def test_parse():
    test_string = """
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
        veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
        commodo consequat.

        :param int test_param: This is a test parameter
        :raises TypeError: When the test raises
        :return: Some test return text
        :yield: Some text yielded by the test

        Donec ullamcorper nulla non metus auctor fringilla. Sed posuere consectetur
        est at lobortis.
    """

# Generated at 2022-06-11 21:45:50.736876
# Unit test for function parse
def test_parse():
    doc = """
    Test parsing of a docstring.

    This is a longer description.

    :param param - a parameter
    :type param - str
    :param param2 - optional parameter
    :type param2 - str?
    :param param3 - parameter with default
    :type param3 - int
    :defaults to 0
    :param param4 - parameter without type
    :raises RuntimeError - a runtime error
    :raises RuntimeError? - an optional runtime error
    :raises RuntimeError2 - a runtime error without type
    :returns - a return value
    :rtype - str
    :yields - a yielded value
    :ytype - str
    """

    docstring = parse(doc)
    assert docstring.short_description == "Test parsing of a docstring."
    assert docstring.long_description

# Generated at 2022-06-11 21:46:02.034933
# Unit test for function parse
def test_parse():
    def foo():
        """This is a docstring.

        :param x: A parameter.
        :returns: A return value.
        :raises: An exception.

        :param y: Another parameter.
        :returns: Another return value.

        This is the end.
        """
        pass


# Generated at 2022-06-11 21:46:12.849386
# Unit test for function parse
def test_parse():
    MODULES_DIR = os.path.dirname(os.path.abspath(__file__))
    filename = os.path.join(MODULES_DIR, "test_files/test_parse")
    test_file = open(filename, "r")
    docstring = test_file.read()
    result = parse(docstring)
    assert len(result.meta) == 2
    assert len(result.meta[0].args) == 3
    assert result.meta[0].type_name == "int"
    assert result.meta[0].arg_name == "x"
    assert result.meta[1].type_name == "int"

# Generated at 2022-06-11 21:46:23.690854
# Unit test for function parse
def test_parse():
    assert parse("f()") == Docstring()
    assert parse("f()") == Docstring()
    assert parse("f() \n") == Docstring()
    assert parse("f() \n  \n") == Docstring()

    assert parse("f():") == Docstring()
    assert parse("f()\n:") == Docstring()
    assert parse("f() \n :") == Docstring()
    assert parse("f() \n \n :") == Docstring()
    assert parse("f()\n:  ") == Docstring()
    assert parse("f()\n:\n    ") == Docstring()
    assert parse("f()\n:\n\n        ") == Docstring()
    assert parse("f()\n:\n    \n        ") == Docstring()


# Generated at 2022-06-11 21:46:34.454711
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    doc_string = """
        :param int foo: First parameter name.
        This is more description.

        :param type_name? arg_name: Optional parameter.
        """
    doc_dict = parse(doc_string)

    assert len(doc_dict.meta) == 2
    assert doc_dict.meta[0].args == ["param", "int", "foo"]
    assert doc_dict.meta[0].description == ("First parameter name.\n"
                                            "This is more description.")
    assert doc_dict.meta[0].type_name == "int"
    assert doc_dict.meta[0].arg_name == "foo"



# Generated at 2022-06-11 21:46:42.404064
# Unit test for function parse
def test_parse():
    text = """\
        Puts text0 in the clipboard
        :param text: Text to put in the clipboard
        :type text: str
        :returns: The text in the clipboard
        :rtype: str
        """
    lines = text.split('\n')