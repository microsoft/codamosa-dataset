

# Generated at 2022-06-11 21:36:57.026471
# Unit test for function parse
def test_parse():
    text = """
    Expects one argument.

    :param arg: some argument
    """
    assert parse(text) == Docstring(
        short_description="Expects one argument.",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[
            DocstringParam(
                args=["param", "arg"],
                description="some argument",
                arg_name="arg",
                type_name=None,
                is_optional=None,
                default=None,
            )
        ],
    )

    text = """
    Expects one argument.

    :type arg: str|int
    """

# Generated at 2022-06-11 21:37:06.328658
# Unit test for function parse
def test_parse():
    text = '''
    :param N: the state size
    :param steps: the steps for rendering
    :param H: the size of the latent space
    :param D: the size of the input
    :param sigma: the value to use for the noise used in the E-step
    :type sigma: float
    :param lr: the learning rate
    :param bs: the batch size
    :param epochs: the number of epochs to train for
    :param print_every: how often to print the loss
    :return: the loss after training
    :rtype: float
    :raises ValueError: in case of a negative input
    '''
    print(parse(text))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:37:18.266121
# Unit test for function parse
def test_parse():
    docstring = """
    Summary line.

    Extended description.
    """
    assert parse(docstring).short_description == "Summary line."
    assert parse(docstring).long_description == "Extended description."

    docstring = """
    Summary line.

    Extended description.
    :param arg1: description
    :type arg1: int
    :raises RuntimeError: if something bad happens
    """
    assert parse(docstring).meta[0].arg_name == "arg1"
    assert parse(docstring).meta[0].description == "description"
    assert parse(docstring).meta[0].type_name == "int"
    assert parse(docstring).meta[1].arg_name == "RuntimeError"
    assert parse(docstring).meta[1].description == "if something bad happens"

# Generated at 2022-06-11 21:37:30.265372
# Unit test for function parse

# Generated at 2022-06-11 21:37:32.219711
# Unit test for function parse
def test_parse():
    text = inspect.getdoc(parse)
    assert text is not None
    expected = parse(text)
    actual = parse(text)
    assert expected == actual

# Generated at 2022-06-11 21:37:42.479108
# Unit test for function parse

# Generated at 2022-06-11 21:37:50.430266
# Unit test for function parse
def test_parse():
    docstring = """A docstring.

:param int param: a parameter.
:returns: return value.
:raises TypeError: raises.

A separte paragraph.
"""

# Generated at 2022-06-11 21:37:58.377865
# Unit test for function parse
def test_parse():
    docstring_text = """
        Summary line.

        Extended description of function.

        :param x: Description of parameter `x`.
        :type x: int
        :param y: Description of parameter `y`.
        :type y: float, optional
        :returns: Description of return value.
        :rtype: float
        :raises ValueError: When invalid input is supplied.
    """
    docstring = parse(docstring_text)
    assert docstring.short_description == "Summary line."
    assert docstring.long_description == """Extended description of function."""
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "x"]


# Generated at 2022-06-11 21:38:08.165569
# Unit test for function parse
def test_parse():
    assert parse('test') == Docstring(short_description='test')
    assert parse('test\n') == Docstring(short_description='test')
    assert parse('test\n\n') == Docstring(short_description='test')
    assert parse('test\n\n\n') == Docstring(short_description='test')
    assert parse('test\n\n\n\n') == Docstring(short_description='test')
    assert parse('test\n\n  \n\n') == Docstring(short_description='test')
    assert parse('test\n\n  This is long!') == Docstring(
        short_description='test',
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description='This is long!',
    )

# Generated at 2022-06-11 21:38:14.662534
# Unit test for function parse

# Generated at 2022-06-11 21:38:32.585020
# Unit test for function parse
def test_parse():
    text1 = """
    This is the short description.

    The long description begins here.

    :param arg1: first argument
    :param arg2: second argument
    :param arg3: third arg, defaults to '3'.
    :type arg3: int
    :param arg4: fourth arg, type int
    :param arg5: fifth arg
    :type arg5: str
    :param arg6: sixth arg, type str
    :returns: None
    :raises KeyError: raises KeyError
    :raises ValueError: raises ValueError
    :raises RuntimeError: raises RuntimeError
    :raises: raises RuntimeError
    :raises: raises ValueError
    :return: None
    :return:
    :return: 
    """

    parse(text1)



# Generated at 2022-06-11 21:38:40.393548
# Unit test for function parse
def test_parse():
    doc = parse("""
    A short description.

    A long description.

    :param a: The first param.
    :type a: str.
    :param b: A second param.
    :type b: str.
    :raises ValueError: When things go wrong.
    :raises RuntimeError: When things go very wrong.
    :returns: A beautiful result.
    :rtype: str.
    :returns: Nothing.
    """)
    assert doc.short_description.strip() == "A short description."
    assert doc.long_description.strip() == "A long description."
    assert len(doc.meta) == 7
    assert doc.meta[0].arg_name == "a"
    assert doc.meta[0].description == "The first param."
    assert doc.meta[1].arg_

# Generated at 2022-06-11 21:38:44.240118
# Unit test for function parse
def test_parse():
    """Test the parse function."""
    docstring = parse(
        """
    This is a short description.

    This is a *long* description.

    :param int arg1: This is an argument description.

    :param arg2: This is another argument description.

    :param arg3: This has a default value (defaults to 3.1415).
    :type arg3: float

    :param arg4: This one is optional (defaults to None).
    :type arg4: str
    :optional arg4:

    :param arg5?: This is also optional (defaults to None).
    :type arg5?: int

    :returns: This is the return value description.
    """
    )

    assert str(docstring.short_description) == "This is a short description."

# Generated at 2022-06-11 21:38:52.702614
# Unit test for function parse
def test_parse():
    # part 1: simple tests
    docstring = """
    A function that does nothing.

    :param arg1: The first argument.
    :type arg1: int, optional
    :param arg2: The second argument.
    :type arg2: str, optional
    :retype: None

    :raises EOFError: Indicates an EOF condition.
    :raises TypeError: Raised when a built-in operation or function receives
        an argument that has the right type but an inappropriate value.
    """
    parse(docstring)


# Generated at 2022-06-11 21:39:01.037800
# Unit test for function parse
def test_parse():
    Docstring = parse("""
    Unit test for method parse
    :param arg1: this is arg1, defaults to None.
    :type arg1: str, int
    :param arg2: this is arg2, defaults to '0'.
    :type arg2: str, optional
    :param arg3: this is arg3, defaults to None.
    :type arg3: str, optional, None
    :param arg4: this is arg4, defaults to ''
    :type arg4: str, optional
    :returns: hello, world.
    :rtype: string
    """)


# Generated at 2022-06-11 21:39:02.029765
# Unit test for function parse
def test_parse():
    # TODO
    assert 1 == 1

# Generated at 2022-06-11 21:39:02.593335
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-11 21:39:15.070605
# Unit test for function parse

# Generated at 2022-06-11 21:39:24.988459
# Unit test for function parse
def test_parse():
    class Test:
        def test(self):
            """This is a multi-line docstring
            of a Test class member function.

            :param int y: second integer.
            :param x: first integer.
            :type x: int, optional
            :raises TypeError: if x not int
            :returns: x+y
            :rtype: int

            """

    t = Test()
    d = parse(t.test.__doc__)

    assert d.short_description == "This is a multi-line docstring of a Test class member function."
    assert d.long_description == \
"""
of a Test class member function.

"""
    assert d.blank_after_long_description
    assert d.blank_after_short_description
    assert len(d.meta) == 4
    assert d.meta

# Generated at 2022-06-11 21:39:37.497625
# Unit test for function parse
def test_parse():
    docstring = '''
        Summary line.

        Extended description of function.

        Parameters
        ----------
        arg1 : int
            Description of arg1
        arg2 : str
            Description of arg2

        Returns
        -------
        str
            Description of return value.
        '''
    result = parse(docstring)
    assert result.short_description == 'Summary line.'
    assert result.long_description == 'Extended description of function.'
    assert result.blank_after_short_description
    assert result.blank_after_long_description
    assert len(result.meta) == 2
    assert result.meta[0].key == 'param'
    assert result.meta[0].args[1] == 'arg1'
    assert result.meta[0].arg_name == 'arg1'

# Generated at 2022-06-11 21:39:53.082143
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc('''

        Short description
        -----------------

        Long description.

        :param x: x
        :type x: int
        :returns: y
        :rtype: int
        ''')
    doc = parse(docstring)

    assert doc.short_description is not None
    assert doc.long_description is not None
    assert doc.blank_after_short_description is not None
    assert doc.blank_after_long_description is not None


# Generated at 2022-06-11 21:39:59.622600
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("foo") == Docstring(
        short_description="foo",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse("foo\nbar") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        long_description="bar",
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-11 21:40:08.051037
# Unit test for function parse
def test_parse():
    assert parse("foo") == Docstring(
        short_description="foo",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    assert parse(" foo bar baz") == Docstring(
        short_description="foo bar baz",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    assert parse("\nfoo bar baz\n") == Docstring(
        short_description="foo bar baz",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

# Generated at 2022-06-11 21:40:12.039495
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    docstring = parse("""
        Function parse.

        :param name: string
        :returns: string
        :raises ValueError: if ...

        Some other stuff.

        Extra!
    """)
    print("docstring:", docstring)


# Generated at 2022-06-11 21:40:22.139719
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    d = parse("""desc
              :arg a: desc
              :type a: str
            """)

    assert d.short_description == "desc"
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert len(d.meta) == 2
    assert d.meta[0].arg_name == "a"
    assert d.meta[0].description == "desc"
    assert d.meta[1].type_name == "str"

    d = parse("""desc
            :param a: desc
            :type a: str""")

    assert d.short_description == "desc"
    assert d.long_description is None
    assert d.blank_after_short_

# Generated at 2022-06-11 21:40:28.742353
# Unit test for function parse
def test_parse():
    docstring = """
        Short description of the function. (No line break)

        Long description of the function.
        Second line.
        Line after empty line.

        :param a: The first parameter.
        :param b: The second parameter. Defaults to 42.

        :raises NameError: If no parameter a is given.
        :returns: Whatever.
        :yields: Stuff.
    """

    r = parse(docstring)
    print(r)
    # assert r.short_description == "Short description of the function."
    # assert r.long_description == "Long description of the function.\nSecond line.\nLine after empty line."
    # assert r.blank_after_short_description
    # assert r.blank_after_long_description
    # assert r.meta[0].__class__ ==

# Generated at 2022-06-11 21:40:37.721377
# Unit test for function parse
def test_parse():
    text = """
    Calculate the square of a number.

    Parameters
    ----------
    a : int, required
        The number to be squared.

    Returns
    -------
    int
        The squared number.

    Raises
    ------
    ValueError
        If the number is negative.
    """

# Generated at 2022-06-11 21:40:47.770820
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('    ') == Docstring()
    assert parse('Hello, world!\n') == Docstring(
        short_description='Hello, world!',
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=None,
        meta=[],
    )

# Generated at 2022-06-11 21:40:55.297173
# Unit test for function parse
def test_parse():
    """Test parse() by brute-force testing all cases."""
    import itertools
    import sys

    def _test_one(text: str) -> None:
        try:
            # N.b.: if we use parse_docstring.parse(text), this will recurse
            # infinitely
            d = parse(text)
        except ParseError as e:
            if "--ignore-parse-errors" in sys.argv:
                print("parse_docstring.parse('{}') failed with error {}".format(text, e))
                return
            else:
                raise
        s = str(d)
        if text != s:
            print("raw docstring:")
            print(text)
            print("parsed docstring:")
            print(s)
            print("^ not equal")
            sys.exit

# Generated at 2022-06-11 21:41:06.422142
# Unit test for function parse
def test_parse():
    text = """\
    This is an example function.

    :param foo: This is foo.
    :param bar: This is bar.
    :returns: This is returns.
    """

    doc = parse(text)
    assert isinstance(doc, Docstring)
    assert doc.short_description == "This is an example function."
    assert doc.long_description == "This is an example function."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert isinstance(doc.meta[0], DocstringParam)
    assert doc.meta[0].description == "This is foo."
    assert doc.meta[0].arg_name == "foo"
    assert doc.meta[0].type_name is None

# Generated at 2022-06-11 21:41:23.338184
# Unit test for function parse
def test_parse():
    def sample(x: int, y: int, z: str) -> (int, bool):
        """This is a sample function

        This is a long description, that should be stripped of
        leading whitespace.

        :param x: This is a parameter x.
        :type x: int
        :param int y: This is a parameter y.
        :param bool z: This is a parameter z.
        :returns: This is the return value.
        :rtype: tuple
        :raises TestException: This is a test exception.
        """
        return x, y, z

    doc = parse(sample.__doc__)
    assert doc.short_description == "This is a sample function"
    assert doc.blank_after_short_description

# Generated at 2022-06-11 21:41:34.743380
# Unit test for function parse
def test_parse():
    from .test_common import assert_docstrings_equal

    # Arrange
    text1 = """
        Short description
        Long description about this function.

        :param: myarg
        :type_name myarg: int
        :param myarg2:
        :returns:
        :rtype: str
        :raises: SomeError"""
    text2 = """
        Short description
        Long description about this function.

        :param myarg:
        :type myarg: int
        :param myarg2:
        :returns:
        :rtype: str
        :raises SomeError"""
    text3 = """
        Short description
        Long description about this function.

        :param myarg:
        :param myarg2:
        :returns:
        :rtype: str
        :raises SomeError"""

# Generated at 2022-06-11 21:41:45.373539
# Unit test for function parse
def test_parse():
    def _test(docstring, expected):
        try:
            result = parse(docstring)
            assert expected == result
        except Exception as e:
            print("Failed: '{}': {}".format(docstring, e))

# Generated at 2022-06-11 21:41:55.995435
# Unit test for function parse
def test_parse():
    docstring = """
    :returns: Some return statement.
    """
    assert parse(docstring).meta[0].description == 'Some return statement.'

    docstring = """
    :param int blah: Some parameter statement.
    """
    assert parse(docstring).meta[0].description == 'Some parameter statement.'

    docstring = """
    :param int blah:
    """
    assert parse(docstring).meta[0].description == ''

    docstring = """
    :param int blah:
    :param int bah:
    """
    assert parse(docstring).meta[1].description == ''

    docstring = """
    :param int blah:

    Some parameter statement.
    """
    assert parse(docstring).meta[0].description == 'Some parameter statement.'


# Generated at 2022-06-11 21:42:06.058474
# Unit test for function parse
def test_parse():
    text = """
    Multiline description.

    :param a: One.
    :param b: Two.
    :type b: int.
    :param c: Three defaults to None.

    :returns: Four.
    :rtype: str.
    """
    result = parse(text)
    # print(result.short_description)
    # print(result.long_description)
    # print(result.blank_after_short_description)
    # print(result.blank_after_long_description)
    # print(result.meta)
    # assert type(result.meta) is list
    # assert type(result.meta[0]) is DocstringParam
    # assert type(result.meta[1]) is DocstringParam
    # assert type(result.meta[2]) is DocstringReturns

# Generated at 2022-06-11 21:42:15.585068
# Unit test for function parse
def test_parse():
    def foo(bar, baz=None):
        """A short description.

        A long decription
        """

    docstring = parse(foo.__doc__)
    assert docstring.short_description == 'A short description.'
    assert docstring.long_description == 'A long decription'
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.meta[0] == DocstringParam(
        ["param", "bar"], desc='', arg_name='bar', type_name=None, is_optional=None, default=None
    )

# Generated at 2022-06-11 21:42:23.985037
# Unit test for function parse
def test_parse():
    """Try to run parse function with this docstring and compare with the code"""
    text = """\
    docstring

    :param x:
    :param y:
    :param z:
    :returns:
    :raises:
    :yields:
    :param type x:
    :param type y:
    :param type z:
    :returns type:
    :raises type:
    :yields type:
    :param type x: description
    :param type y: description
    :param type z: description
    :returns type: description
    :raises type: description
    :yields type: description
    """
    result = parse(text)
    print(result)
    assert result.blank_after_long_description == True
    assert result.blank_after_short_description

# Generated at 2022-06-11 21:42:28.364758
# Unit test for function parse
def test_parse():
    assert parse("") == parse("")
    assert parse("Desc") == parse("Desc") == parse("Desc\n\n") == parse("Desc\n")
    assert parse("Desc\n\nMore desc") == parse("Desc\n\nMore desc")
    assert parse("Desc\n\nMore desc\n") == parse("Desc\n\nMore desc\n")
    assert parse("Desc\n\nMore desc\n\n") == parse("Desc\n\nMore desc\n\n")

    assert parse("Desc\n\n") == parse("Desc\n") == parse("Desc\n\n")
    assert parse("Desc\n\n") != parse("Desc\n\nMore desc")
    assert parse("Desc\n\n") != parse("Desc\n\nMore desc\n")

# Generated at 2022-06-11 21:42:37.828210
# Unit test for function parse
def test_parse():
    t = """
    This is a short description.

    This is part of the long description.
    It continues over multiple lines.

    :param x: this is a parameter
    :type x: int
    :param y: this is another parameter
    :type y: str
    :param z: this is another parameter
    :type z: str
    :param w: this is another parameter
    :type w: str
    :returns: This is the return description.
    :rtype: str
    :return: This is the return description.
    :rtype: str
    :raises ValueError: if the value is not valid
    :yields: this is a generator
    :yield: this is a generator
    """
    return parse(t)

# Generated at 2022-06-11 21:42:48.879010
# Unit test for function parse
def test_parse():
    test_string = inspect.cleandoc("""Test docstring

This is a **test docstring**.

:param arg: The first argument.
:param arg2: The second argument. Defaults to 3.

:param arg3:
    The third argument.

:param arg4:
    The fourth argument.

:param arg5:
    The fifth argument.

:param arg6:
    The sixth argument.

:returns: Some stuff.
:raises Exception: Some exception.
:yields: Some other stuff.
:see: Doctest docstring below.
:todo: Finish the tests.
:note: Some note.
""")
    ds = parse(test_string)

    assert ds.short_description == "Test docstring"
    assert ds.blank_after_short_description

# Generated at 2022-06-11 21:43:09.852263
# Unit test for function parse
def test_parse():
    """Test parse function."""
    d = parse('Unittest function parse.\n\n' +
              ':param str arg1: Unittest arg1.\n' +
              ':param int arg2: Unittest arg2.\n' +
              ':returns:\n' +
              ':rtype: str\n' +
              ':returns: Unittest return.\n' +
              ':yields: Unittest yield.')
    print(d)

# Generated at 2022-06-11 21:43:13.801792
# Unit test for function parse
def test_parse():
    """Test_parse"""
    text="""Test_parse
    :param: bla
    :param type: integer
    fregg
    :param type?: integer
    :param type?: fregg
    :param: bla2
    :param type: integer
    :returns: bla3
    :returns type: integer
    :returns: bla3
    :returns type: integer
    :yields: bla3
    :yields type: integer
    :yields: bla3
    :yields type: integer"""
    return parse(text)

# Generated at 2022-06-11 21:43:22.097370
# Unit test for function parse
def test_parse():
    docstring = """
    Summarize the number of things.

    One day, I realized that there were too many things. I felt a real need
    to count them. So I can tell you that there are exactly 42 things.

    :param things: The things to count.
    :returns: The number of things.
    :raises ValueError: if there are not enough things.
    :raises TypeError: if the things are not countable.
    :meta first-name: John
    :meta last-name: Smith
    :meta age: 42
    :meta:
        """
    parsed = parse(docstring)
    assert parsed.short_description == "Summarize the number of things."

# Generated at 2022-06-11 21:43:29.772035
# Unit test for function parse
def test_parse():
    # setup
    text = "This is a docstring.\n    it is spread over\n    multiple lines.\n\n:param name: type?\n    defaults to None.\n"
    expected = """docstr:
    short_desc: This is a docstring.
    long_desc: it is spread over
               multiple lines.
    blank_after_short_desc: False
    blank_after_long_desc: False
    meta:
        - args: ['param', 'name', 'type?']
          description: defaults to None.
          arg_name: name
          type_name: type?
          is_optional: True
          default: None
"""
    # execute
    docstr = parse(text)
    result = str(docstr)
    print(result)
    # verify

# Generated at 2022-06-11 21:43:36.130525
# Unit test for function parse
def test_parse():
    """Test function parse"""
    doc_string = """Test function parse
    """
    assert parse('') == Docstring()
    assert parse(doc_string) == Docstring(
        short_description='Test function parse',
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[])

# Generated at 2022-06-11 21:43:45.164955
# Unit test for function parse
def test_parse():
    #Test short description
    text = parse("Test docstring")
    assert text.short_description == "Test docstring"

    #Test long description
    text = parse("Test docstring\n\nThis is a longer description with more info")
    assert text.short_description == "Test docstring"
    assert text.long_description == "This is a longer description with more info"
    assert text.blank_after_short_description == True
    assert text.blank_after_long_description == False

    #Test blank after long description
    text = parse("Test docstring\n\nThis is a longer description with more info\n\n")
    assert text.short_description == "Test docstring"
    assert text.long_description == "This is a longer description with more info"
    assert text.blank_after_short_description == True

# Generated at 2022-06-11 21:43:56.375748
# Unit test for function parse
def test_parse():
    text = '''\
    short description
    
    long description
    
    :param a: this is a
    :type a: int
    :returns: whatever
    :raises: an exception
    '''
    result = parse(text)
    assert result.short_description == 'short description'
    assert result.blank_after_short_description == True
    assert result.long_description == 'long description'
    assert result.blank_after_long_description == True

# Generated at 2022-06-11 21:44:08.221974
# Unit test for function parse
def test_parse():
    r = parse(
        """
  This is a long-multi-line \
  docstring.
  
  :param int i:
    Blah blah blah.
    
    Blah blah blah.
  
  :param str j:
    Blah blah blah.
  
  :returns: str
    Blah blah blah.
    
    Blah blah blah.
    """
    )

# Generated at 2022-06-11 21:44:10.058407
# Unit test for function parse
def test_parse():
    import doctest
    doctest.run_docstring_examples(parse, globals(), verbose=True)

# Generated at 2022-06-11 21:44:14.647772
# Unit test for function parse
def test_parse():
    docstr = '''
    This is a short description.

    This is a long description.
    '''

    doc = parse(docstr)
    assert doc.short_description == 'This is a short description.'
    assert doc.long_description == 'This is a long description.'
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert not doc.meta


# Generated at 2022-06-11 21:44:28.949712
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: description
    :type arg1: int
    :param arg2: description
    :param arg3: description
    :rtype: str
    :returns: description
    :raises ValueError: description
    :raises TypeError: description
    """
    assert parse(docstring) == parse(inspect.cleandoc(docstring))
    assert parse(docstring).short_description == "Short description."
    assert parse(docstring).long_description == "Long description."
    assert parse(docstring).blank_after_short_description
    assert parse(docstring).blank_after_long_description

# Generated at 2022-06-11 21:44:39.923978
# Unit test for function parse
def test_parse():
    def func():
        """
        This is the summary line.

        This is the description.
        :param int x: parameter description
        :type str y: parameter description
        :returns: return description
        :raises: a, b, c
        :yields: x
        """
        pass

    ds = parse(inspect.getdoc(func))
    assert ds.short_description == "This is the summary line."
    assert ds.long_description == "This is the description."
    assert ds.blank_after_short_description
    assert ds.blank_after_long_description
    assert len(ds.meta) == 4
    assert ds.meta[0].key == "param"
    assert ds.meta[0].arg_name == "x"

# Generated at 2022-06-11 21:44:45.916227
# Unit test for function parse
def test_parse():
    """This function provides unit tests for function parse.
    
    The function print 'OK' if all the tests pass, otherwise it prints the messages of the failed tests.
    """

# Generated at 2022-06-11 21:44:54.384783
# Unit test for function parse
def test_parse():
    text = '''\
    Short summary.

    This is the long description, which can span multiple lines.

    :param arg: The first argument.
    :type arg: str
    :param arg2: The second argument. Defaults to "default".
    :param arg2: str

    :returns: Nothing.
    :rtype: None
    '''
    docstring = parse(text)
    assert docstring.short_description == "Short summary."
    assert docstring.long_description == ("This is the long description, "
                                          "which can span multiple lines.")
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.meta[0].arg_name == "arg"
    assert docstring.meta[0].type_name == "str"


# Generated at 2022-06-11 21:45:06.858114
# Unit test for function parse
def test_parse():
    text = '''
    This is a short description.
    
    Params:
        arg1 (str): This is argument 1.
        arg2 (int, optional): This is argument 2, defaults to 3.
        arg3 (str):
            This is a long description for argument 3. It goes over
            multiple lines.
    
    Yields:
        int: A yield value.
    
    
    
    
    
    
    
    
    
    
        '''
    docstring = parse(text)
    assert docstring.short_description == "This is a short description."

# Generated at 2022-06-11 21:45:12.770535
# Unit test for function parse
def test_parse():
    doc = """One-line summary.
    Very long description here.
    Useful when you want to test the function parse.
    Returns the parsed docstring.

    :param text: ReST-style docstring
    :type text: str
    :rtype: Docstring
    """
    print(parse(doc))


# Generated at 2022-06-11 21:45:21.675680
# Unit test for function parse
def test_parse():
    text = """\
    This is the short description.

    This is the long description. It continues onto another
    line.

    :param int foo: Description of "foo". This can continue onto
        another line.
    :param str bar: Description of "bar".

    :returns: Description of what is returned.
    :rtype: str
    """

    docstring = parse(text)

    assert not docstring.blank_after_short_description
    assert docstring.short_description == "This is the short description."
    assert not docstring.blank_after_long_description



# Generated at 2022-06-11 21:45:30.790718
# Unit test for function parse
def test_parse():
    # test case 1
    docstr = """A short description.
    A longer description.

    :param arg1: DocstringMeta
    :param arg2: DocstringMeta
    :raises Exception: DocstringRaises
    :returns: DocstringReturns
    :rtype: DocstringReturns
    :yields: DocstringReturns
    """
    docstr = parse(docstr)
    assert docstr.short_description == "A short description."
    assert docstr.long_description == "A longer description."
    assert len(docstr.meta) == 7
    assert isinstance(docstr.meta[0], DocstringMeta)
    assert isinstance(docstr.meta[1], DocstringMeta)
    assert isinstance(docstr.meta[2], DocstringRaises)

# Generated at 2022-06-11 21:45:40.303270
# Unit test for function parse
def test_parse():
    example = """
    An example function.
    :param string template_id:
        The ID of the template to use as the base for this survey.
    :param string name:
        The name of the survey.
    :param string description:
        A description of the survey.
    :param string language:
        The language to use for the survey.
    :returns:
        The ID of the newly created survey.
    :raises:
        :exc:`~qualtrics.exceptions.QualtricsError`
            If something went wrong while communicating with the Qualtrics API.
    """

# Generated at 2022-06-11 21:45:50.934559
# Unit test for function parse

# Generated at 2022-06-11 21:46:04.052555
# Unit test for function parse
def test_parse():
    # General
    text = '''
    short
    long
    :arg k: des
    :kwarg k: des
    :param k: des
    '''
    doc = parse(text)
    assert doc.short_description == 'short'
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert doc.long_description == 'long'
    assert doc.meta[0].args == ['arg', 'k']
    assert doc.meta[0].description == 'des'
    assert doc.meta[1].args == ['kwarg', 'k']
    assert doc.meta[1].description == 'des'
    assert doc.meta[2].args == ['param', 'k']
    assert doc.meta[2].description == 'des'

    # short

# Generated at 2022-06-11 21:46:16.584372
# Unit test for function parse
def test_parse():
    # No docstring
    docstring = parse(None)
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False

    # Blank docstring
    docstring = parse("")
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False

    # Short description only
    docstring = parse("Short description.")
    assert docstring.short_description == "Short description."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long

# Generated at 2022-06-11 21:46:23.640145
# Unit test for function parse
def test_parse():
    text = '''
    Produces items in a range.

    :param int start: the first number in the range
    :param int stop: the first number greater than or equal to start
        not to include.
    :param int step: the difference between items in the range.
        Defaults to 1.
    :raises ValueError: if step is zero.
    :yields: the items in the given range.
    '''


# Generated at 2022-06-11 21:46:27.020523
# Unit test for function parse
def test_parse():
    """Test parse()."""
    doc = inspect.getdoc(parse)
    assert parse(doc).short_description == doc.split("\n", 1)[0]



# Generated at 2022-06-11 21:46:37.384472
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Short.\n\nLong.") == Docstring(
        short_description="Short.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="Long.",
    )
    assert parse("Short.\nLong.") == Docstring(
        short_description="Short.",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description="Long.",
    )
    assert parse("Short.\n\n\nLong.") == Docstring(
        short_description="Short.",
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description="Long.",
    )