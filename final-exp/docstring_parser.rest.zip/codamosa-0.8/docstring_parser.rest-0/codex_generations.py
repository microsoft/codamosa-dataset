

# Generated at 2022-06-11 21:37:07.682718
# Unit test for function parse
def test_parse():
    x = """summary line
    extended description

    :param arg1: description of arg1
    :type arg1: str
    :returns: description of return value
    :rtype: int
    :raises keyError: description of exception
    """
    result = parse(x)
    assert result.short_description == "summary line"
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert result.long_description == "extended description"
    assert result.meta[0].description == "description of arg1"
    assert result.meta[0].type_name == "str"
    assert result.meta[0].arg_name == "arg1"
    assert result.meta[0].args[0] == "param"

# Generated at 2022-06-11 21:37:16.481696
# Unit test for function parse
def test_parse():
    docstring = '''\
    This is the short description.

    This is the long description.

    And this is the meta description.

    Another line of meta description.

    And one more.
    '''

    ds = parse(docstring)
    assert ds.short_description == "This is the short description."
    assert ds.long_description == "This is the long description."
    assert ds.meta == [DocstringMeta(args=[], description="And this is the meta description.\n\nAnother line of meta description.\n\nAnd one more.")]



# Generated at 2022-06-11 21:37:25.315281
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :rtype: List[str]
    :returns: the list of strings
    :raises ValueError: if the value is invalid
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description."
    assert parsed.meta[0].type_name == "List[str]"
    assert parsed.meta[0].description == "the list of strings"
    assert parsed.meta[1].type_name == "ValueError"
    assert parsed.meta[1].description == "if the value is invalid"

# Generated at 2022-06-11 21:37:34.009924
# Unit test for function parse

# Generated at 2022-06-11 21:37:43.207615
# Unit test for function parse
def test_parse():
    docstring = (
    """
    A summary sentence.

    A longer description.

    Parameters
    ----------
    param1: str
        some description.
    param2: int?
        some description.
    """
    )
    results = parse(docstring)
    assert results.short_description == "A summary sentence."
    assert results.long_description == "A longer description."
    assert results.blank_after_short_description == False
    assert results.blank_after_long_description == True
    assert results.meta[0].args == ["param1", "str"]
    assert results.meta[0].type_name == "str"
    assert results.meta[0].arg_name == "param1"
    assert results.meta[0].is_optional == False
    assert results.meta[0].default == None


# Generated at 2022-06-11 21:37:46.796766
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param str name: first argument
    :param str id: second argument
    :param str age: third argument
    :returns: (int, int)
    :raises NotFound: not found!
    """
    parse(docstring)

# Generated at 2022-06-11 21:37:56.019082
# Unit test for function parse
def test_parse():
    assert parse(_test_docstring) == _test_result

# this is the test docstring used in the unit test above

# Generated at 2022-06-11 21:38:06.402567
# Unit test for function parse

# Generated at 2022-06-11 21:38:13.631607
# Unit test for function parse
def test_parse():
    text = """
    docstring object
    """
    assert parse(text).short_description == "docstring object"

    text = """
    docstring object

    Long description
    """
    ret = parse(text)
    assert ret.short_description == "docstring object"
    assert ret.long_description == "Long description"
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == False

    text = """
    docstring object

    Long description
    """
    ret = parse(text)
    assert ret.short_description == "docstring object"
    assert ret.long_description == "Long description"
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == False


# Generated at 2022-06-11 21:38:22.955246
# Unit test for function parse
def test_parse():
    docstring = """
    Hello.
    :param arg1: This is the first argument
    :type arg1: int
    :param arg2: This is the second argument
    :type arg2: str
    :param arg3: This is the third argument
    :type arg3: str
    :returns: this is what is returned
    :rtype: int
    """
    p = parse(docstring)
    assert p.short_description == "Hello."
    assert p.long_description.strip() == ''
    assert len(p.meta) == 5
    assert p.meta[0].description == 'This is the first argument'
    assert p.meta[0].type_name == 'int'
    assert p.meta[1].description == 'This is the second argument'
    assert p.meta[1].type_name

# Generated at 2022-06-11 21:38:39.270723
# Unit test for function parse
def test_parse():
    docstring = '''\
summary

description

:Args:
    a: int.
    b: int.
    c: int.

:Returns:
    int.

:Raises:
    Exception.
    IOError.

:Yields:
    int.
'''
    doc = parse(docstring)
    assert doc.short_description == 'summary'
    assert doc.long_description == 'description'
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 1
    assert doc.meta[0].args == ['Args', 'a:', 'int.', 'b:', 'int.', 'c:', 'int.']
    assert doc.meta[0].description == 'int.'
   

# Generated at 2022-06-11 21:38:44.684433
# Unit test for function parse
def test_parse():
    docstring = """
    This is a description.

    Parameters
    ----------
    arg1 : int
        This is arg1.
    arg2 : int
        This is arg2.

    Raises
    ------
    ValueError
        If something bad happened.

    Returns
    -------
    str
        This is a return description.
    """
    assert parse(docstring)

# Generated at 2022-06-11 21:38:52.928650
# Unit test for function parse
def test_parse():
    from pytest import raises
    from .common import DocstringRaises

    docstring = """A short description.

A long description.

:param str arg1: Description for arg1.
:param str arg2: Description for arg2.
:raises Exception: When something goes wrong.
"""
    ret = parse(docstring)

    assert ret.short_description == "A short description."
    assert ret.long_description == "A long description."
    assert len(ret.meta) == 3

    assert ret.meta[0].args == ["param", "str", "arg1"]
    assert ret.meta[0].description == "Description for arg1."
    assert ret.meta[1].args == ["param", "str", "arg2"]
    assert ret.meta[1].description == "Description for arg2."
    assert isinstance

# Generated at 2022-06-11 21:39:02.645822
# Unit test for function parse

# Generated at 2022-06-11 21:39:15.106477
# Unit test for function parse
def test_parse():
    assert parse("")
    assert parse("No description.") == Docstring(
        short_description="No description.", blank_after_short_description=False
    )
    assert parse("Description.") == Docstring(
        short_description="Description.", blank_after_short_description=False
    )
    assert parse("""
    Description.
    """) == Docstring(
        short_description="Description.", blank_after_short_description=True
    )
    assert parse("""
    Description.

    Longer description.
    """) == Docstring(
        short_description="Description.",
        long_description="Longer description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

# Generated at 2022-06-11 21:39:25.017461
# Unit test for function parse
def test_parse():
    import os
    import random
    import string
    import tempfile
    import textwrap

    # Test that the parse returns error given an empty string
    docstring = ""
    assert parse(docstring) == Docstring()

    # Test that the parse handles the various combinations of
    # short_description, long_description, blank_after_short_description,
    # and blank_after_long_description as expected
    for _ in range(100):
        # Fill out each combination with random characters
        short_description = (
            "".join(random.choice(string.ascii_lowercase) for _ in range(25))
        )  # noqa: E501
        long_description = (
            "".join(random.choice(string.ascii_lowercase) for _ in range(100))
        )  # noqa:

# Generated at 2022-06-11 21:39:37.497280
# Unit test for function parse

# Generated at 2022-06-11 21:39:49.698890
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()

    docstring = Docstring(
        short_description="Short description.",
        long_description="Long description.",
        meta=[
            DocstringParam(
                args=["param", "int", "arg"],
                description="Description.",
                arg_name="arg",
                type_name="int",
                is_optional=True,
                default="None",
            ),
            DocstringReturns(
                args=["returns"],
                description="Description.",
                type_name=None,
                is_generator=False,
            ),
        ],
    )

# Generated at 2022-06-11 21:39:57.461974
# Unit test for function parse
def test_parse():
    # Empty docstring
    assert Docstring() == parse("")

    # Short description only
    assert Docstring(
        short_description="This function does something."
    ) == parse("This function does something.")

    # Short description with surrounding whitespace
    assert Docstring(
        short_description="This function does something."
    ) == parse("   This function does something.    ")

    # Short description with long description
    assert Docstring(
        short_description="This function does something.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="It is meant to be used like this.",
    ) == parse(
        """
This function does something.

It is meant to be used like this.
"""
    )

    # Short description with long description and multiple lines

# Generated at 2022-06-11 21:40:06.856373
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Parses ReST-style docstrings.") == Docstring(
        short_description="Parses ReST-style docstrings.",
        blank_after_short_description=True,
        long_description=None,
    )
    assert parse('Parses ReST-style docstrings.\n\nMore description.') == Docstring(
        short_description="Parses ReST-style docstrings.",
        blank_after_short_description=True,
        long_description="More description.",
        blank_after_long_description=True,
    )

# Generated at 2022-06-11 21:40:24.511345
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("""
        Short description.

        Long description.
    """).__dict__ == {
        "short_description": "Short description.",
        "blank_after_short_description": True,
        "long_description": "Long description.",
        "blank_after_long_description": True,
        "meta": [],
    }

    assert parse("""
        Short description.

        Long description.
        On more than one line.
    """).__dict__ == {
        "short_description": "Short description.",
        "blank_after_short_description": True,
        "long_description": "Long description.\nOn more than one line.",
        "blank_after_long_description": True,
        "meta": [],
    }


# Generated at 2022-06-11 21:40:35.474641
# Unit test for function parse
def test_parse():
    doc = """
    One line short description.

    Long description of the module. This can span multiple lines.

    :param int x: the x coordinate
    :param int y: the y coordinate. defaults to 2.
    :returns: the sum of the coordinates
    :raises ValueError: if x is less than 0

    This can be followed by arbitrary text.
    """
    parsed = parse(doc)

# Generated at 2022-06-11 21:40:46.115109
# Unit test for function parse
def test_parse():
    assert parse("TEST") == Docstring(
        short_description = "TEST",
        long_description = None,
        meta = []
    )
    assert parse("TEST\n") == Docstring(
        short_description = "TEST",
        long_description = None,
        meta = []
    )
    assert parse("TEST\n\n") == Docstring(
        short_description = "TEST",
        long_description = None,
        meta = []
    )
    assert parse("\n  \t\nTEST\n\n") == Docstring(
        short_description = "TEST",
        long_description = None,
        meta = []
    )

# Generated at 2022-06-11 21:40:55.927317
# Unit test for function parse
def test_parse():
    test_docstring = inspect.cleandoc("""
    A short description
    Long description line 1
    Long description line 2

    :param str name: A name.
    :param int age: Age.
    :param str? gender: Gender. Defaults to 'male'.
    :returns int: A non-negative integer.
    :raises OverflowError: Never.
    :raises: Never.
    :raises TypeError: Never.
    :yields: No values.
    :yields int: No values.
    :yields int item: No values.
    :yields int item: No values, but lots of stuff.
        Like this.

        And this.

    :returns str: Yo.
    """)
    test_docstring_lines = test_docstring.split("\n")

# Generated at 2022-06-11 21:41:01.225041
# Unit test for function parse
def test_parse():
    doc = """
    .. test docstring parse
    :param:
    """
    parsed = parse(doc)
    assert len(parsed.meta) == 0
    assert parsed.short_description is None
    assert parsed.long_description is None
    assert parsed.blank_after_short_description is False
    assert parsed.blank_after_long_description is True

# Generated at 2022-06-11 21:41:10.955591
# Unit test for function parse
def test_parse():
    text = '''This is a long description.
    
    :param parameter: Parameter description.
    :type parameter: str
    :returns: Return value description.
    :rtype: int
    :raises ValueError: Raised if the argument is out of range.
    '''
    doc = parse(text)
    assert doc.short_description == 'This is a long description.'
    assert doc.long_description == 'Parameter description.\nReturn value description.\nRaised if the argument is out of range.'
    assert doc.blank_after_long_description == False
    assert doc.blank_after_short_description == True
    assert type(doc.meta[0]) == DocstringParam
    assert type(doc.meta[1]) == DocstringReturns
    assert type(doc.meta[2]) == DocstringRaises

# Generated at 2022-06-11 21:41:17.777179
# Unit test for function parse
def test_parse():
    def d(desc):
        return parse(desc)

    assert d("foo") == Docstring(
        short_description="foo",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

    assert d("foo\n") == Docstring(
        short_description="foo",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    assert d("foo\n\n") == Docstring(
        short_description="foo",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[],
    )


# Generated at 2022-06-11 21:41:26.476999
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('  ') == Docstring()
    docstring = '\n'.join([
        'This is a short description.',
        '',
        'This is a long description.',
        'It can have multiple lines,',
        'even with a blank line in between.',
        '',
        ':param int x: this is a parameter',
        ':param y: this is a parameter without a type',
        ':type y: bool',
        ':rtype: str',
        ':return: nothing',
        ':raises ValueError: if something bad happens',
        '',
    ])
    parsed = parse(docstring)
    assert parsed.short_description == 'This is a short description.'

# Generated at 2022-06-11 21:41:37.584719
# Unit test for function parse
def test_parse():
    # Simple docstring
    test_docstring = """
        This is a simple docstring.

        :param a: description of a
        :type a: int

        :param b: description of b
        :type b: bool
        :raises Exception: we can raise exceptions
        :returns: Description of return value.
        :rtype: str
    """
    docstring = parse(test_docstring)
    assert docstring.short_description == "This is a simple docstring."
    assert docstring.long_description == None
    assert len(docstring.meta) == 4
    assert [type(meta) for meta in docstring.meta] == [DocstringParam, DocstringParam,
                                                       DocstringRaises, DocstringReturns]

    assert docstring.meta[0].arg_name == "a"
    assert doc

# Generated at 2022-06-11 21:41:48.461846
# Unit test for function parse

# Generated at 2022-06-11 21:41:56.819189
# Unit test for function parse
def test_parse():
    docstring = """Return an object with the following attributes:

:var x: X coordinate of the point
:var y: Y coordinate of the point
:var z: Z coordinate of the point

:raises ValueError: if x,y,z is not a valid point.
"""

    print(parse(docstring))

# Generated at 2022-06-11 21:42:06.720309
# Unit test for function parse
def test_parse():
    s = """
    Example
    """
    d = parse(s)
    assert d.short_description == "Example"
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.long_description == None
    assert len(d.meta) == 0

    s = """
    Example

    """
    d = parse(s)
    assert d.short_description == "Example"
    assert d.blank_after_short_description == True
    assert d.blank_after_long_description == False
    assert d.long_description == None
    assert len(d.meta) == 0

    s = """
    Example:

    """
    d = parse(s)
    assert d.short_description == "Example"
    assert d.blank_after

# Generated at 2022-06-11 21:42:15.701832
# Unit test for function parse
def test_parse():
    a = "Hello World"
    print(parse(a) == Docstring(short_description="Hello World", long_description=None, meta=[]))

    b = "Hello World.\n\nLong description string."
    print(parse(b) == Docstring(
        short_description="Hello World",
        long_description="Long description string.",
        meta=[]
    ))

    c = "Hello World.\n\n:param name: The name parameter.\n:type name: str\n:param age: The age parameter.\n:type age: int"

# Generated at 2022-06-11 21:42:26.632841
# Unit test for function parse
def test_parse():
    """Test parsing of docstring."""
    docstring = """This is a description about the function.
    It can go on for several lines.

    :param str something: This is a parameter. This description can go on for
        several lines.

    :returns: This is the return type.

    :raises ValueError: In case of error.
"""
    ds = parse(docstring)
    assert ds.short_description == "This is a description about the function."
    assert ds.long_description == """It can go on for several lines."""
    assert ds.blank_after_short_description
    assert ds.blank_after_long_description
    assert len(ds.meta) == 3
    assert ds.meta[0].args == ["param", "str", "something"]

# Generated at 2022-06-11 21:42:37.030223
# Unit test for function parse
def test_parse():
    text = """
        Return the module name stored in the file.
        This function is used on Python < 3.4 to
        extract the module name from the file.
        :raises AttributeError: if it's not able to find the name
        :returns: the module name
        """

    docst = parse(text)

    assert docst.short_description == "Return the module name stored in the file."
    assert docst.blank_after_short_description == False
    assert docst.long_description == """
        This function is used on Python < 3.4 to
        extract the module name from the file.
        """
    assert docst.blank_after_long_description == True
    assert len(docst.meta) == 2
    assert isinstance(docst.meta[0], DocstringRaises)
    assert docst

# Generated at 2022-06-11 21:42:48.593718
# Unit test for function parse
def test_parse():
    text = """
    Test Test Test
    """
    result = parse(text)
    assert result.short_description == 'Test Test Test'

    text = """
    Test Test Test
    Test Test Test
    """
    result = parse(text)
    assert result.short_description == 'Test Test Test'

    text = """
    Test Test Test
    Test Test Test
    """
    result = parse(text)
    assert result.short_description == 'Test Test Test'

    text = """
    Test Test Test
    Test Test Test

    Test Test Test
    Test Test Test
    """
    result = parse(text)
    assert result.short_description == 'Test Test Test'
    assert result.long_description == 'Test Test Test\nTest Test Test'


# Generated at 2022-06-11 21:42:58.005779
# Unit test for function parse
def test_parse():
    #Test 1:
    docstring = """This is a short description.

This is a long description.

:param str arg1: The first argument
:param int arg2: The second argument
:returns: The return value"""

    assert parse(docstring).short_description == "This is a short description."
    assert parse(docstring).long_description == "This is a long description."
    assert parse(docstring).meta[0].args == ['param', 'str', 'arg1']
    assert parse(docstring).meta[0].description == "The first argument"
    assert parse(docstring).meta[1].args == ['param', 'int', 'arg2']
    assert parse(docstring).meta[1].description == "The second argument"
    assert parse(docstring).meta[2].args == ['returns']
   

# Generated at 2022-06-11 21:43:09.811512
# Unit test for function parse

# Generated at 2022-06-11 21:43:15.025148
# Unit test for function parse
def test_parse():
    doc = """
        Description of what it does.
        :param: arg1
        :type arg1: str
        :param arg2: The second argument.
        :param arg3:
        :type arg3: str, optional
        :param arg4:
        :default arg4: True
        :returns: None
        :rtype: None
        """

# Generated at 2022-06-11 21:43:22.540879
# Unit test for function parse
def test_parse():
    # Empty docstring
    assert parse("") == Docstring()
    assert parse("  ") == Docstring()
    assert parse(None) == Docstring()

    # docstring with just short description
    assert parse("Hello") == Docstring(
        short_description="Hello",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse("Hello world") == Docstring(
        short_description="Hello world",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    # docstring with just long description

# Generated at 2022-06-11 21:43:37.657152
# Unit test for function parse
def test_parse():
    """Function testing whether the docstring of the parse function has been parsed correctly"""
    func = parse.__doc__
    assert parse(func) == Docstring(
        short_description="Parse the ReST-style docstring into its components.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="""\
:returns: parsed docstring""",
        meta=[
            DocstringMeta(
                args=["returns"], description="parsed docstring"
            )
        ],
    )



# Generated at 2022-06-11 21:43:44.649589
# Unit test for function parse
def test_parse():
    """Test parse()."""
    def f(
        arg1: str,
        arg2: T.Optional[int] = 1,
        arg3: bool = True,
    ) -> T.Dict[str, int]:
        """This is a test function.

        :param arg1: The first argument.
        :type arg1: str
        :param arg2: The second argument.
        :type arg2: int or None
        :param arg3: The third argument.
        :type arg3: bool
        :returns: a dictionary
        :rtype: dict[str, int]
        """
        pass

    d = parse(f.__doc__)
    assert d.short_description == "This is a test function."
    assert d.long_description == "The first argument.\nThe second argument."
   

# Generated at 2022-06-11 21:43:56.270191
# Unit test for function parse
def test_parse():
    text = """
    Parse the ReST-style docstring into its components.

    :param str name: The name to use (defaults to ``"World"``).
    :returns: parsed docstring
    :raises TypeError: if parse(...) is called
    """
    docstring = parse(text)
    assert docstring.short_description == "Parse the ReST-style docstring into its components."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.long_description == None
    assert len(docstring.meta) == 3

# Generated at 2022-06-11 21:44:07.911752
# Unit test for function parse
def test_parse():
    test_str = """Test function.

:param x: Left side of the operator.
:type x: int
:param y: Right side of the operator.
:type y: int
:returns: The result of the operation.
:rtype: int
:raises TypeError: If the arguments are not numbers.

"""

    parsed = parse(test_str)
    assert parsed.short_description == "Test function."
    assert parsed.long_description == ""
    assert len(parsed.meta) == 4

    assert parsed.meta[0].args == ["param", "x"]
    assert parsed.meta[0].description == "Left side of the operator."
    assert parsed.meta[0].arg_name == "x"
    assert parsed.meta[0].type_name == "int"

# Generated at 2022-06-11 21:44:16.165969
# Unit test for function parse

# Generated at 2022-06-11 21:44:25.077879
# Unit test for function parse
def test_parse():
    docstring = """
    A short description.

    And a long description.

    :param arg1: description of arg1
    :param arg2: description of arg2
    :rtype: str
    """
    doc = parse(docstring)

    assert doc.short_description == "A short description."
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == True
    assert doc.long_description == "And a long description."

    assert len(doc.meta) == 3
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "description of arg1"
    assert doc.meta[1].args == ["param", "arg2"]
    assert doc.meta[1].description == "description of arg2"
   

# Generated at 2022-06-11 21:44:32.474654
# Unit test for function parse
def test_parse():
    docstring = """
    Args:
        a: This is argument 'a'.
        b: This is argument 'b'.

    """
    # print (parse(docstring))
    assert parse(docstring).short_description is None
    assert parse(docstring).meta[0].args[0] == "Args"
    assert parse(docstring).meta[0].description == ""
    assert parse(docstring).meta[1].args[0] == "a"
    assert parse(docstring).meta[1].description == "This is argument 'a'."
    assert parse(docstring).meta[2].args[0] == "b"
    assert parse(docstring).meta[2].description == "This is argument 'b'."


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:44:42.181986
# Unit test for function parse
def test_parse():
    """Test for ReST parsing of docstring"""
    text = """
        parse(text: str) -> Docstring

        Parse the ReST-style docstring into its components.
        
        :param text: the docstring to parse
        :type text: str
        :returns: parsed docstring
        :rtype: Docstring
        """
    docstring = parse(text)
    assert docstring.short_description == "Parse the ReST-style docstring into its components."
    assert docstring.long_description == ":param text: the docstring to parse\n:type text: str\n:returns: parsed docstring\n:rtype: Docstring"
    assert type(docstring.meta[0]) == DocstringParam
    assert type(docstring.meta[1]) == DocstringReturns

# Generated at 2022-06-11 21:44:47.662031
# Unit test for function parse
def test_parse():
    result = parse(
        """\
        Short description.

        Long description.
        """
    )

    assert result.short_description == "Short description."
    assert result.blank_after_short_description is False
    assert result.long_description == "Long description."
    assert result.blank_after_long_description is True
    assert result.meta == []



# Generated at 2022-06-11 21:44:54.824008
# Unit test for function parse
def test_parse():
    docstring = '''
    Lorem ipsum dolor sit amet, consectetur adipiscing elit.

    :param width: The width of the rectangle
    :type width: int
    '''
    ds = parse(docstring)
    assert ds.short_description == "Lorem ipsum dolor sit amet, consectetur adipiscing elit."
    assert ds.long_description == None
    assert len(ds.meta) == 1
    assert isinstance(ds.meta[0], DocstringParam)
    assert ds.meta[0].arg_name == 'width'
    assert ds.meta[0].type_name == 'int'


# Generated at 2022-06-11 21:45:08.051680
# Unit test for function parse
def test_parse():
    # Test empty docstring
    assert parse("") == Docstring()

    # Test empty docstring with extra whitespace
    assert parse(" ") == Docstring()

    # Test very short docstring
    assert parse("a") == Docstring(short_description="a")

    # Test short docstring followed by multiline empty lines
    assert (
        parse("a\n\n\n") == Docstring(short_description="a", blank_after_short_description=True)
    )

    # Test docstring with a very long line

# Generated at 2022-06-11 21:45:17.647753
# Unit test for function parse
def test_parse():
    text = inspect.cleandoc("""
    Short description.

    Long description begins here.

    :param arg_name: description
    :type arg_name: type
    :param arg_name: description
    :type arg_name: type
    :param arg_name: description
    :type arg_name: type""")
    ds = parse(text)
    assert len(ds.meta) == 3
    assert ds.meta[0].arg_name == "arg_name"
    assert ds.meta[1].arg_name == "arg_name"
    assert ds.meta[2].arg_name == "arg_name"

# Generated at 2022-06-11 21:45:26.805998
# Unit test for function parse
def test_parse():
    text = """
    Compute the mean.

    :param a: An input array.
    :param a_name: An input array.
    :type a: numpy.ndarray
    :type a_name: numpy.ndarray
    :some_param: a parameter
    :some_param type: float
    :param b: Another input array.
    :type b: numpy.ndarray
    :returns: a+b
    :returns: param c: a+b
    :returns: type c: float
    :returns: The mean of the inputs.
    :raises KeyError: Raises an exception.
    """
    assert parse(text)

# Generated at 2022-06-11 21:45:36.730610
# Unit test for function parse
def test_parse():
    docstr = """To be, or not to be, that is the question:
    Whether 'tis Nobler in the mind to suffer
    The Slings and Arrows of outrageous Fortune,
    Or to take Arms against a Sea of troubles,
    And by opposing end them: to die, to sleep
    No more; and by a sleep, to say we end
    The Heart-ache, and the thousand Natural shocks
    That Flesh is heir to? 'Tis a consummation
    Devoutly to be wish'd. To die, to sleep,
    To sleep, perchance to Dream; aye, there's the rub,
    For in that sleep of death, what dreams may come,
    When we have shuffled off this mortal coil,
    Must give us pause."""

    docstring = parse(docstr)

# Generated at 2022-06-11 21:45:49.289751
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(
        short_description=None,
        blank_after_short_description=None,
        blank_after_long_description=None,
        long_description=None,
        meta=[],
    )
    assert parse("\n") == Docstring(
        short_description=None,
        blank_after_short_description=None,
        blank_after_long_description=None,
        long_description=None,
        meta=[],
    )
    assert parse("short") == Docstring(
        short_description='short',
        blank_after_short_description=None,
        blank_after_long_description=None,
        long_description=None,
        meta=[],
    )

# Generated at 2022-06-11 21:45:50.876863
# Unit test for function parse
def test_parse():
    """Tests parsing docstring with PyTest."""
    pass

# Generated at 2022-06-11 21:46:00.099414
# Unit test for function parse
def test_parse():
    example_str = """
    Compute the Levenshtein distance between two strings.

    ------------------------------
    :param str x: First string.
    :param str y: Second string.
    :param int max_distance: Maximum distance to calculate.

    :returns: Levenshtein distance between `x` and `y`
    :rtype: int

    :raises MemoryError: Insufficient memory to run `fuzzywuzzy`.

    :raises ValueError: If max_distance is negative.

    ==============================
    """
    print(parse(example_str))


# Generated at 2022-06-11 21:46:12.803942
# Unit test for function parse
def test_parse():
  docstring = """
  Single line summary.

  Single line extended description.

  Args:
    arg1: The first argument.
    arg2: The second argument.
  Returns:
    The return value. True for success, False otherwise.
  """
  parsed = parse(docstring)
  assert parsed.short_description == 'Single line summary.'
  assert parsed.long_description == 'Single line extended description.'
  assert parsed.blank_after_short_description
  assert parsed.blank_after_long_description
  assert parsed.meta[0].args == ['arg1:', 'The', 'first', 'argument.']
  assert parsed.meta[0].description == 'The first argument.'
  assert parsed.meta[1].args == ['arg2:', 'The', 'second', 'argument.']

# Generated at 2022-06-11 21:46:23.604324
# Unit test for function parse
def test_parse():
    assert parse("""
        Short desc

        Long desc
        Continuing
    """) == Docstring(
        short_description="Short desc",
        long_description="Long desc\nContinuing",
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[],
    )


# Generated at 2022-06-11 21:46:35.392238
# Unit test for function parse