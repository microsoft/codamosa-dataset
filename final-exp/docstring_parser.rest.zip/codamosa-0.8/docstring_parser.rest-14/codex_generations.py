

# Generated at 2022-06-11 21:36:58.617458
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc("""
    Converts a value to a boolean. 
    :param x: value to be converted
    :returns: value of x converted to bool
    :raises ValueError: when x cannot be converted to bool
    """)

    doc = parse(docstring)

    assert doc.short_description == "Converts a value to a boolean."
    assert doc.long_description is None
    assert doc.blank_after_short_description is True
    assert doc.blank_after_long_description is False

    assert len(doc.meta) == 3

    assert doc.meta[0].args[0] == "param"
    assert doc.meta[0].args[1] == "x"
    assert doc.meta[0].description == "value to be converted"

# Generated at 2022-06-11 21:37:07.802366
# Unit test for function parse
def test_parse():
    text = """First line of description.
Second paragraph of description.

    :arg param1: Some description
    :type param1: str
    :arg param2: Some description
    :type param2: int
    :arg param3: Some description
    :type param3: bool
    :param param4: Some description
    :type param4: float
    :param param5: Some description
    :type param5: None
    :returns: Foo
    :rtype: str
    :returns: Bar
    :rtype: int
    :returns: Baz
    :rtype: bool
    :returns: Bad
    :rtype: None
    :raises AttributeError: If foo.
    :raises ValueError: If bar.
    :raises TypeError: If baz.
"""

    ds = parse

# Generated at 2022-06-11 21:37:19.388122
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param x: Parameter x.
    :param y: Parameter y.
    :return: Return value.
    :raises ValueError: If `x` is not positive.
    :raises TypeError: If `y` is not an int.
    """
    actual = parse(docstring)

# Generated at 2022-06-11 21:37:23.025992
# Unit test for function parse
def test_parse():
    parse("""
    This is a simple docstring
    """)
    """
    The docstring of docstring.parse
    """

# Generated at 2022-06-11 21:37:33.036375
# Unit test for function parse
def test_parse():
    from .common import Docstring

    docstring = inspect.cleandoc(
        """
    Short description.

    Long description.

    :param int param: Param description.
    :type param: int
    :param optional param2: Param description.
    :param param3: Param description.
    :raises: TypeError
    :rtype: None
    :return: Returns description
    :yields: Yields description
    :yields int: Yields description
    :yields int, int: Yields description
    """
    )

# Generated at 2022-06-11 21:37:42.670570
# Unit test for function parse
def test_parse():
    my_doc_string = '''
    This docstring should be fully parsed.

    :param a: this is the 1st param
    :type a: int
    :param b: this is the 2nd param
    :type b: str
    :param c: this is the 3rd param

    :returns: this is the return string
    :rtype: str
    '''

    result = parse(my_doc_string)
    print(result)
    assert result.short_description == 'This docstring should be fully parsed.'

# Generated at 2022-06-11 21:37:52.417735
# Unit test for function parse
def test_parse():
    text = inspect.cleandoc("""\
    Short description.

    Long description.

    :param name: Name of this thing.
    :param path: Path to where it is.
    :return: An instance of this thing.
    """)
    doc = parse(text)
    print(doc)
    assert len(doc.meta) == 3
    assert isinstance(doc.meta[0], DocstringParam)
    assert doc.meta[0].arg_name == "name"
    assert doc.meta[0].description == "Name of this thing."
    print(doc.meta[0])
    assert isinstance(doc.meta[1], DocstringParam)
    assert doc.meta[1].arg_name == "path"
    assert doc.meta[1].description == "Path to where it is."

# Generated at 2022-06-11 21:38:05.237592
# Unit test for function parse
def test_parse():
    # Test to make sure the doctstring gets parsed correctly.
    doc = parse("""
        Single-line description.

        Multi-line description.

        :param str param1: Description of *param1*
            with line breaks.
        :param int param2: Description of *param2*.
        :param param3: Description of *param3*.
        :rtype str: Description of the return value.
            Another line break.
        :raise ValueError: Description of exception.
    """)

    assert doc.short_description == "Single-line description."
    assert doc.long_description == "Multi-line description."
    assert doc.blank_after_long_description is True
    assert doc.meta[0].args == ["param", "str", "param1"]

# Generated at 2022-06-11 21:38:13.935110
# Unit test for function parse
def test_parse():
    docstring = parse("""Importance sampling on a quadratic function

Parameters
----------
x: int
    The value at which to evaluate the median.
""")
    # print(docstring)
    # print(docstring.short_description)
    # print(docstring.long_description)
    # print(docstring.blank_after_short_description)
    # print(docstring.blank_after_long_description)
    
    for i in range(len(docstring.meta)):
        print(docstring.meta[i].args)
        print(docstring.meta[i].description)

# Generated at 2022-06-11 21:38:23.114984
# Unit test for function parse

# Generated at 2022-06-11 21:38:36.995870
# Unit test for function parse
def test_parse():
    # text should be a string
    assert parse("") == Docstring()
    # text is empty
    assert parse("") == Docstring()
    # text is not empty
    assert parse(
        "Some short description.\n\nSome long description. ") == Docstring(
            short_description='Some short description.',
            blank_after_short_description=True,
            long_description='Some long description.',
            blank_after_long_description=True)
    # text is not empty and has some meta

# Generated at 2022-06-11 21:38:47.976796
# Unit test for function parse
def test_parse():
    """Unittest for parse function"""

# Generated at 2022-06-11 21:38:49.329011
# Unit test for function parse
def test_parse():
    pass


# Generated at 2022-06-11 21:39:01.481350
# Unit test for function parse
def test_parse():
    """Test the parse function with a variety of input."""
    assert parse("") == Docstring()


# Generated at 2022-06-11 21:39:14.038853
# Unit test for function parse
def test_parse():
    expected = Docstring(
        short_description="Test the parse() function.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="This is a more detailed description of the parse() function.\nIt may contain multiple paragraphs.",
        meta=[
            DocstringParam(
                args=["param", "str", "text"],
                arg_name="text",
                type_name="str",
                is_optional=False,
                default="None",
                description="The docstring to parse into its parts.",
            ),
            DocstringReturns(
                args=["returns", "Docstring"],
                type_name="Docstring",
                is_generator=False,
                description="The parsed docstring.",
            )
        ],
    )


# Generated at 2022-06-11 21:39:24.462263
# Unit test for function parse

# Generated at 2022-06-11 21:39:34.750935
# Unit test for function parse
def test_parse():
    expected = Docstring(
        short_description='Hello World',
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=True,
        meta=[DocstringParam(
            args=['param', 'str', 'name'],
            description='Full name of target person.',
            arg_name='name',
            type_name='str',
            is_optional=False,
            default=None
        )],
    )
    assert parse('Hello World\n\n:param str name: Full name of target person.') == expected


# Generated at 2022-06-11 21:39:37.282414
# Unit test for function parse
def test_parse():
    docstring = """
        A docstring with a type error.

        :param int: -1
        :returns int:
    """
    try:
        parse(docstring)
    except ParseError as e:
        assert e.message == 'Error parsing meta information near ":param int: -1\n"'


# Generated at 2022-06-11 21:39:49.438649
# Unit test for function parse
def test_parse():
    """
    Unit test for function parse
    """
    # test 1
    text = """
    A single-line docstring.
    """
    parsed = parse(text)
    assert parsed.short_description == "A single-line docstring."
    assert parsed.long_description is None
    assert list(parsed.meta) == []

    # test 2
    text = """
    A docstring with multiple lines.

    Here's the second paragraph.
    """
    parsed = parse(text)
    assert parsed.short_description == "A docstring with multiple lines."
    assert parsed.long_description == (
        "Here's the second paragraph."
    )
    assert list(parsed.meta) == []

    # test 3

# Generated at 2022-06-11 21:39:58.055519
# Unit test for function parse
def test_parse():
    docstring_1 = parse.__doc__
    expected_1 = """
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """
    assert docstring_1 == expected_1

    docstring_2 = Docstring.__doc__
    expected_2 = """
    A docstring's parsed components.

    :ivar description: description
    :ivar meta: meta data
    """
    assert docstring_2 == expected_2

    docstring_3 = DocstringMeta.__doc__
    expected_3 = """
    A docstring's meta data.

    :ivar args: tuple of args
    :ivar description: description
    """
    assert docstring_3 == expected_3

    docstring_4 = DocstringParam.__doc__

# Generated at 2022-06-11 21:40:14.479763
# Unit test for function parse
def test_parse():
    # docstring string
    text = """
        Summary line.

        Extended description.

        :param arg1: Description of `arg1`
        :type arg1: <type 'str'>
        :param arg2: Description of `arg2`
        :type arg2: <type 'str'>
        :returns: Description of return value
        :rtype: <type 'str'>
        :raises ValueError: Description of exception
    """
    p = parse(text)
    # short description
    assert p.short_description == "Summary line."
    # long description
    assert p.long_description == "Extended description."
    # whether there is a blank line after short description
    assert p.blank_after_short_description
    # whether there is a blank line after long description
    assert p.blank_after_long_description


# Generated at 2022-06-11 21:40:24.432176
# Unit test for function parse
def test_parse():
    # Normal docstring
    normal_docstring = """\
    Normal docstring.

    :param a: integer
    :return: nothing
    """

# Generated at 2022-06-11 21:40:35.404116
# Unit test for function parse
def test_parse():
    text = inspect.cleandoc("""
    Computed the sum of two numbers.

    :param x: First number.
    :type x: :class:`int`
    :param y: Second number.
    :type y: :class:`int`
    :returns: The sum.
    :rtype: :class:`int`
    :raises NotImplementedError: If the addition is not implemented.

    """)


# Generated at 2022-06-11 21:40:46.030827
# Unit test for function parse
def test_parse():
    args = [
        "arg1 (int) - first argument",
        "arg2 (str) - second argument",
        "arg3 (bool) - third argument",
        "arg4 (Optional[int]) - fourth argument",
        "arg5 (int = 10) - fifth argument",
    ]
    docstring = """
    Short description.

    Long description having multiple lines.
    """ + "\n:\n    ".join(args)

    doc = parse(docstring)
    assert doc.short_description == "Short description."
    assert doc.long_description == (
        "Long description having multiple lines."
    )
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 5

    d = doc.meta[0]

# Generated at 2022-06-11 21:40:54.574498
# Unit test for function parse
def test_parse():
    """Test for parse"""
    assert parse("Hello") == Docstring(
        short_description="Hello", long_description=None, meta=[]
    )

    assert parse('Hello\n\nThis is a docstring') == Docstring(
        short_description="Hello",
        long_description="This is a docstring",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    # :param str name: Description of name.
    # :param str address: Description of address.

# Generated at 2022-06-11 21:41:05.603302
# Unit test for function parse
def test_parse():
    assert parse("""
    Something to describe
    """.strip()) == Docstring(
        short_description="Something to describe",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse("""
    Something to describe
    the long description
    """.strip()) == Docstring(
        short_description="Something to describe",
        long_description="the long description",
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-11 21:41:16.170599
# Unit test for function parse
def test_parse():
    example_docstring = """
    :param name: The name to say hello to
    :type name: str
    :param loud: True if the name should be said in an extra loud voice
    :type loud: bool
    :raises RuntimeError: if name is empty
    :returns: str to say
    """
    doc = parse(example_docstring)
    assert doc.short_description == ""
    assert len(doc.meta) == 4
    assert doc.meta[0].key == "param"
    assert doc.meta[0].description == "The name to say hello to"
    assert doc.meta[0].arg_name == "name"
    assert doc.meta[0].type_name == "str"
    assert doc.meta[1].key == "type"

# Generated at 2022-06-11 21:41:23.668715
# Unit test for function parse
def test_parse():
    import textwrap

# Generated at 2022-06-11 21:41:35.174209
# Unit test for function parse
def test_parse():
    assert not parse("")
    assert parse("foo") == Docstring(short_description="foo")
    assert parse("foo\n\n") == Docstring(
        short_description="foo", blank_after_short_description=True
    )
    assert parse("foo\n\n  bar\n\n") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        long_description="bar",
        blank_after_long_description=True,
    )
    assert parse("foo\n\nbar") == Docstring(
        short_description="foo", blank_after_short_description=True, long_description="bar"
    )

# Generated at 2022-06-11 21:41:46.140539
# Unit test for function parse
def test_parse():
    from .common import DocstringParam, DocstringReturns, DocstringRaises, DocstringMeta
    text = '''
    """ help for function

    :param int name: name help
    :param str title: title help
    :returns: returns help
    """
    '''
    f = parse(text)
    assert f.short_description == "help for function"
    assert f.long_description == None
    assert f.blank_after_short_description == True
    assert f.blank_after_long_description == False

# Generated at 2022-06-11 21:42:02.845536
# Unit test for function parse
def test_parse():
    """Unit testing for function parse."""
    docstring = """The quick brown fox.

This fox was very quick and very brown.

: param int a: the quickness of the brown fox
: param str b: the brownness of the quick fox
: returns: int
: raises AttributeError: if you mess up
"""
    d = parse(docstring)
    assert d.short_description == "The quick brown fox."
    assert d.long_description == "This fox was very quick and very brown."
    assert d.meta[0].description == "the quickness of the brown fox"
    assert d.meta[1].description == "the brownness of the quick fox"
    assert d.meta[2].args[0] == "returns"
    assert d.meta[3].args[0] == "raises"
    assert d

# Generated at 2022-06-11 21:42:11.051810
# Unit test for function parse
def test_parse():
    def f(x: int) -> str:
        """\
        This is a function docstring.

        Returns a string.

        :param x: The integer variable to double.
        :type x: int
        :param y: The optional variable to double.
        :raises ValueError: If x is not an integer.
        :returns: The doubled variable, x.
        :rtype: str
        """
        pass

    docstr = parse(f.__doc__)

    assert docstr.short_description == "This is a function docstring."
    assert docstr.long_description == "Returns a string."
    assert docstr.blank_after_short_description
    assert docstr.blank_after_long_description

    assert len(docstr.meta) == 3
    param1, param2, raises = docstr.meta

# Generated at 2022-06-11 21:42:22.121459
# Unit test for function parse
def test_parse():

    docstring = r'''
    Short description.

    Full description.

    :param foo: Foo parameter.
    :type foo: str
    :param bar: Bar parameter.
    :type bar: str
    :raises ValueError: Foo value is invalid.
    :raises AttributeError: Bar attribute is invalid.
    :yields: [str] Yield values.
    :returns: str return value.
    '''


# Generated at 2022-06-11 21:42:26.886700
# Unit test for function parse
def test_parse():
    # Add some testing here
    # use the sample bellow
    docstring = """Single-line docstring.

    :param int start: The position to start.
    :param int end: The position to end (non-inclusive).
    :param str format: The format of the returned string.
    :rtype: str

    .. _Google Python Style Guide:
       http://google.github.io/styleguide/pyguide.html

    .. _`PEP 257`:
       https://www.python.org/dev/peps/pep-0257/

    Long-form description.

    :raises ValueError: If the string is too long.
    """

    if __name__ == '__main__':  # <- Avoid this when testing
        docstring = parse(docstring)
        # Edit print for your needs
       

# Generated at 2022-06-11 21:42:34.544504
# Unit test for function parse
def test_parse():
    text = inspect.cleandoc("""\
    Method to parse the ReST-style docstring into its components.

    :param x: One-character string.
    :returns: The integer ordinal for the character.
    """)
    assert parse(text).short_description == "Method to parse the ReST-style docstring into its components."
    assert parse(text).long_description == ""
    assert parse(text).meta[0] == DocstringParam("x")
    assert parse(text).meta[1] == DocstringReturns()

# Generated at 2022-06-11 21:42:48.017534
# Unit test for function parse
def test_parse():
    def test(ds, short_description, long_description, params, return_type,
             raises, is_generator):
        print("\n")
        print("-"*10)
        print("Input:", ds)
        parsed = parse(ds)
        print("Output:", parsed)
        assert parsed.short_description == short_description
        assert parsed.long_description == long_description
        assert len(parsed.meta) == len(params) + len(return_type) + len(raises)
        for i in range(len(params)):
            param = params[i]
            assert parsed.meta[i].args[0] == "param"
            assert parsed.meta[i].args[-1] == param[1]
            assert parsed.meta[i].type_name == param[0]
           

# Generated at 2022-06-11 21:42:57.602383
# Unit test for function parse
def test_parse():
    docstring = """:param a: test
    :param int b: test
    :param str c=1: test

    :returns: test
    :returns int: test
    :returns str: test

    :raises ExceptType: test
    :raises Exception: test

    :yields: test
    :yields int: test
    :yields str: test
    """

# Generated at 2022-06-11 21:43:09.435531
# Unit test for function parse
def test_parse():
    # pylint: disable=unused-variable

    def f(a, b=None, c="foo"):
        """This is a short description.

        This is the first line of a long description.

        This is the second line of a long description.

        :type a: int
        :param b: This is the description for argument b. It
            may span multiple lines.
        :type b: int
        :param c: This is the description for argument c. It
            defaults to "foo".
        :returns: A string representation of a.
        """
        return str(a)

    doc = parse(f.__doc__)
    assert doc.short_description == "This is a short description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description

# Generated at 2022-06-11 21:43:18.633220
# Unit test for function parse
def test_parse():
  d = parse("""
  :param a: 
  :type b: str
  :yield c:
  :rtype d: int
  :returns: return value
  :raises e: e value
  :raises f:
    f value
  """)
  assert d.meta[0].args == ['param', 'a']
  assert d.meta[0].description == ''
  assert d.meta[0].arg_name == 'a'
  assert d.meta[0].type_name == None
  assert d.meta[0].is_optional == None
  assert d.meta[0].default == None

  assert d.meta[1].args == ['type', 'b']
  assert d.meta[1].description == 'str'
  assert d.meta[1].type_name == None
 

# Generated at 2022-06-11 21:43:25.927126
# Unit test for function parse
def test_parse():
    docstr = """
        Parse the ReST-style docstring into its components.

        :returns: parsed docstring
    """
    assert parse(docstr).short_description == "Parse the ReST-style docstring into its components."
    assert parse(docstr).meta[0].description == "parsed docstring"
    #assert parse(docstr).meta[0].args[0] == "returns"
    #assert parse(docstr).meta[0].args[1] == None

# Generated at 2022-06-11 21:43:43.199751
# Unit test for function parse
def test_parse():
    # No docstring
    assert parse("") == Docstring()

    # Description with no meta information
    doc = parse("""
        Description.

        Long description.

        """)
    assert doc.short_description == "Description."
    assert doc.long_description == "Long description."
    assert not doc.blank_after_short_description
    assert not doc.blank_after_long_description
    assert doc.meta == []

    # Description with normal parameters
    doc = parse("""
        Description.

        :param type_name arg_name: description

        """)
    assert doc.short_description == "Description."
    assert not doc.long_description
    assert not doc.blank_after_short_description
    assert not doc.blank_after_long_description
    assert isinstance(doc.meta[0], DocstringParam)

# Generated at 2022-06-11 21:43:55.635141
# Unit test for function parse
def test_parse():
    def func(arg1, arg2=3):
        """Short description.

        Longer description.

        :param arg1: The first argument.
        :param arg2: The second argument (defaults to 3).
        :returns: None
        :raises ValueError: Some exception detail.
        """
        pass

    docstring = parse(func.__doc__)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Longer description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert not docstring.meta
    assert docstring.params[0]
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].type_name is None

# Generated at 2022-06-11 21:43:58.718603
# Unit test for function parse
def test_parse():
    res = parse('''\
        Args:
          foo: A python object.
          bar: Another python object.
        Returns:
          None
        ''')
    asse

# Generated at 2022-06-11 21:44:10.500482
# Unit test for function parse
def test_parse():
    test1 = '''
    Function do nothing
    '''
    assert parse(test1).summary == "Function do nothing"

    test2 = '''
    Function do nothing

    This function is only for testing.
    '''
    output = parse(test2)
    assert output.summary == "Function do nothing"
    assert output.blank_after_short_description == False
    assert output.blank_after_long_description == True
    assert output.short_description == "Function do nothing"
    assert output.long_description == "This function is only for testing."

    test3 = '''
    Function do nothing.

    :param num: a number.
    :param name: a string.
    '''
    output = parse(test3)
    assert type(output.meta) == list
    assert len(output.meta)

# Generated at 2022-06-11 21:44:17.473656
# Unit test for function parse
def test_parse():
    # basic one
    docstring = """\
    This function adds two numbers together.

        :param x: The first number.
        :param y: The second number.
        :returns: The sum of the two numbers.
    """
    # test
    docstring_parsed = parse(docstring)
    # assert result

# Generated at 2022-06-11 21:44:26.260140
# Unit test for function parse

# Generated at 2022-06-11 21:44:37.796884
# Unit test for function parse
def test_parse():
    doc = parse("""
    Short description.

    Long description.
    """)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False

    doc = parse("""
    Short description.

    Long description.


    """)
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True

    doc = parse("""
    Short description.

    :param arg1: First arg.
    :param arg2: Second arg.
    :param arg3: Third arg.

    Long description.

    """)
    assert len(doc.meta) == 3

# Generated at 2022-06-11 21:44:48.708808
# Unit test for function parse

# Generated at 2022-06-11 21:44:55.699307
# Unit test for function parse
def test_parse():
    d = parse("""
            Calculates the sum of two numbers.

            :param a: first number
            :type a: int
            :param b: second number
            :type b: int
            :return: first number + second number
            :rtype: int

            .. code-block::

                >>> sum_of_two_numbers(1, 2)
                3
            """)
    assert d.short_description == "Calculates the sum of two numbers."
    assert d.long_description == "::\n\n    >>> sum_of_two_numbers(1, 2)\n    3"
    assert len(d.meta) == 3
    assert d.meta[0].args == ['param', 'a', 'first number']
    assert d.meta[0].arg_name == 'a'

# Generated at 2022-06-11 21:45:07.265967
# Unit test for function parse
def test_parse():
    """Should have consistent parsing of docstrings."""
    text = """Short description.

    Long description.

    :param int a: First parameter.
    :param b: Second parameter.
    :raises ValueError: In case of failure.
    :return: Something.
    """

# Generated at 2022-06-11 21:45:22.508164
# Unit test for function parse
def test_parse():
    docstring = """

    Function parse.
    :returns: parsed docstring    
    """

    assert parse(docstring)
    assert parse(docstring).short_description == "Function parse."
    assert parse(docstring).meta[0].args == ["returns"]
    assert parse(docstring).meta[0].description == "parsed docstring"

    # Test for missing docstring
    assert not parse("")

    # Test for invalid entry in docstring
    try:
        parse("""

        Function parse
        :returns:
        """)
    except ParseError:
        assert True

# Generated at 2022-06-11 21:45:31.244434
# Unit test for function parse
def test_parse():
    def test(doc):
        return parse(doc)

    def short(text):
        return test(text).short_description

    def long(text):
        return test(text).long_description

    def meta(text):
        return test(text).meta

    assert short("") is None
    assert short("hello") == "hello"
    assert long("hello\nworld") == "world"
    assert len(meta("")) == 0
    assert len(meta(":hello\n")) == 1
    assert len(meta(":hello\n:world\n")) == 2

    # Check parsing of param and type information
    desc = ":param str foo: Foo bar.\n"

# Generated at 2022-06-11 21:45:40.616284
# Unit test for function parse

# Generated at 2022-06-11 21:45:51.111127
# Unit test for function parse
def test_parse():
    test_string = """Summary line here.

This is a longer description of the code.  It can span multiple paragraphs,
comma-separated lists::

- bulleted
- bulleted
- bulleted

:param str x: This is the first parameter.
:param int y: This is the second parameter.
:returns: None
:raises: :class:`TypeError` if x is not an int

More description stuff here.  This is a *longer* description of the code.
"""

# Generated at 2022-06-11 21:46:02.311409
# Unit test for function parse
def test_parse():
    # test parse()
    text = '''
    short_description

    long_description
    '''

    docstring_parts = parse(text)
    assert docstring_parts.short_description == "short_description"
    assert docstring_parts.long_description == "long_description"
    assert not docstring_parts.meta

    text = '''
    short_description

    long_description

    :param arg: description
    '''

    docstring_parts = parse(text)
    assert len(docstring_parts.meta) == 1
    param = docstring_parts.meta[0]
    assert param.arg_name == "arg"
    assert param.description == "description"
    assert param.default is None


# Generated at 2022-06-11 21:46:14.567961
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description.
    """
    d = parse(text)

    assert d.short_description == "Short description."
    assert d.long_description == "Long description."

    assert d.blank_after_short_description is True
    assert d.blank_after_long_description is False

    text = """
    Short description.

    Long description.

    """
    d = parse(text)

    assert d.short_description == "Short description."
    assert d.long_description == "Long description."

    assert d.blank_after_short_description is True
    assert d.blank_after_long_description is True


# Generated at 2022-06-11 21:46:26.379033
# Unit test for function parse

# Generated at 2022-06-11 21:46:33.984821
# Unit test for function parse
def test_parse():
    print("Input: ", "Arguments: x, y -- Positional arguments.\n")
    doc = parse("Arguments: x, y -- Positional arguments.\n")
    print("Output: ", doc.short_description)


    print("Input: ", "Arguments: x, y -- Positional arguments.\n")
    doc = parse("Arguments: x, y -- Positional arguments.")
    print("Output: ", doc.short_description)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:46:41.449897
# Unit test for function parse
def test_parse():
    from . import test_extract

    for key, text in test_extract.EXAMPLES.items():
        docstring = parse(text)
        assert docstring.short_description == test_extract.EXAMPLES_SHORT[key]
        assert docstring.long_description == test_extract.EXAMPLES_LONG[key]
        assert docstring.blank_after_short_description == test_extract.EXAMPLES_BLANK1[key]
        assert docstring.blank_after_long_description == test_extract.EXAMPLES_BLANK2[key]
        assert docstring.meta == test_extract.EXAMPLES_META[key]