

# Generated at 2022-06-11 21:37:20.271947
# Unit test for function parse
def test_parse():
    assert parse("This is a short description.") == Docstring(
        short_description="This is a short description.",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description="",
        meta=[],
    )

    assert parse("This is a short description.\n") == Docstring(
        short_description="This is a short description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="",
        meta=[],
    )


# Generated at 2022-06-11 21:37:23.025593
# Unit test for function parse
def test_parse():
    """Run doctests on parse."""
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:37:33.036363
# Unit test for function parse
def test_parse():
    parse("Hello")

    with pytest.raises(ParseError):
        parse(": Invalid Syntax")

    # Test that we parse and handle multiline docstrings
    dstr = parse("""Hello World
    :param x:
    :returns:
    :raises ValueError:
    """)
    assert dstr.short_description == "Hello World"
    assert dstr.blank_after_short_description
    assert dstr.long_description is None
    assert dstr.blank_after_long_description
    assert [p.arg_name for p in dstr.meta] == ["x", None, None]

    # Test that we handle the case when there is no short description
    dstr = parse(":param x:")
    assert dstr.short_description is None
    assert not dstr.blank_after

# Generated at 2022-06-11 21:37:42.671739
# Unit test for function parse
def test_parse():
    """Test 'parse' function."""
    text = """This is a short description.

    This is a long description.

    :param arg1: argument 1
    :type arg1: int
    :param arg2: argument 2
    :type arg2: bool
    :returns: return value
    :rtype: str
    :raises: Exception
    """
    doc = parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.blank_after_short_description
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_long_description
    assert doc.meta[0].__class__ == DocstringParam
    assert doc.meta[0].arg_name == "arg1"

# Generated at 2022-06-11 21:37:50.547728
# Unit test for function parse
def test_parse():
    s = """
    A function that does some stuff.

    This is a long description.

    :param arg_a: A parameter that only takes ints.
    :param arg_b: A parameter with a default. Defaults to 1.
    :param arg_c: A parameter with a default. Defaults to 1.
    :param arg_d: A parameter without a type.
    :param arg_e: A parameter with a type and a default.
    :type arg_e: int
    :param arg_f: A parameter with a type and a default. Defaults to 3.
    :type arg_f: int
    :returns: Something that is returned.
    :raises: An exception.
    :raises TypeError: A type error.
    """

# Generated at 2022-06-11 21:37:58.439218
# Unit test for function parse
def test_parse():
    """Unit test for the function parse."""
    def example_function(a: int, b: int = 0, c: str = "a"):
        """Example for unit test of parse.

        :param int a: This is a parameter.
        :param int? b: This is another parameter that has a default value.

        .. note::

            This is a note.


        :returns: Returns nothing.
        """
        pass

    doc = parse(example_function.__doc__)

    assert doc.short_description == "Example for unit test of parse."
    assert doc.blank_after_short_description is False

    assert doc.long_description == "This is a note."
    assert doc.blank_after_long_description is True

    assert len(doc.meta) == 3

    assert doc.meta[0].arg_

# Generated at 2022-06-11 21:38:07.582487
# Unit test for function parse
def test_parse():
    text = '''\
    Parse the ReST-style docstring into its components.

    :param int x: the x coordinate
    :param int y: the y coordinate
    :returns: the distance
    :rtype: float
    '''

    result = parse(text)
    assert result.short_description == 'Parse the ReST-style docstring into its components.'
    assert result.long_description == 'the distance'
    assert len(result.meta) == 3
    assert result.meta[0].args == ['param', 'int', 'x']
    assert result.meta[0].description == 'the x coordinate'
    assert result.meta[2].args == ['rtype', 'float']
    assert result.meta[2].description == ''

# Generated at 2022-06-11 21:38:18.837465
# Unit test for function parse
def test_parse():
    text = "Foo the bar.\n\n:param str x: Foo.\n\n:param int y: Bar.\n\n:raises ValueError: Bad value.\n:raises RuntimeError: Runtiming.\n\n:returns: Nothing."
    result = parse(text)
    assert result.short_description == "Foo the bar."
    assert result.blank_after_short_description
    assert result.long_description is None
    assert result.blank_after_long_description
    assert len(result.meta) == 4
    assert result.meta[0].__class__.__name__ == "DocstringParam"
    assert result.meta[0].type_name == "str"
    assert result.meta[0].is_optional is False

# Generated at 2022-06-11 21:38:23.919497
# Unit test for function parse
def test_parse():
    import pprint

    pprint.pprint(parse.__annotations__)
    doc = parse(inspect.getdoc(parse))
    pprint.pprint(doc)
    print(doc.signature)
    assert 'parse(text: str)' == doc.signature
    assert 'ReST-style docstring parsing.' == doc.short_description
    assert ':returns: parsed docstring' in doc.long_description
    print(doc)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:38:29.886371
# Unit test for function parse
def test_parse():
    assert parse('test_parse()\n\nThis is a test.') == Docstring(
        short_description='test_parse()',
        long_description='This is a test.',
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[]
    )


# Generated at 2022-06-11 21:38:47.733778
# Unit test for function parse

# Generated at 2022-06-11 21:38:49.921402
# Unit test for function parse
def test_parse():
    # test kwargs=defaults is broken
    # test kwargs with no default works
    pass

# Generated at 2022-06-11 21:39:01.958629
# Unit test for function parse
def test_parse():
    """Test function parse."""
    text = """
    parse(text: str) -> Docstring:
        Parse the ReST-style docstring into its components.

        :returns: parsed docstring

        :param text: Docstring to be parsed.
        :type text: str
        :param input: Input
        :type input: str

        :raises TypeError: if a non-string is passed in
    """

    doc = parse(text)

    assert doc.short_description == "Parse the ReST-style docstring into its components."
    assert doc.blank_after_short_description == False
    assert doc.long_description == ":returns: parsed docstring\n\n:param text: Docstring to be parsed.\n:type text: str"
    assert doc.blank_after_long_description == False


# Generated at 2022-06-11 21:39:14.492500
# Unit test for function parse

# Generated at 2022-06-11 21:39:15.893792
# Unit test for function parse
def test_parse():
  # FIXME: implement!
  return True

# Generated at 2022-06-11 21:39:25.388974
# Unit test for function parse

# Generated at 2022-06-11 21:39:31.700164
# Unit test for function parse
def test_parse():
    from genotype.tests.helpers import get_test_case_path
    import yaml

    with open(get_test_case_path("parse.yaml")) as fh:
        cases = yaml.safe_load(fh)
        for case in cases:
            actual = parse(case["doc"])
            assert actual == case["result"]

# Generated at 2022-06-11 21:39:40.169598
# Unit test for function parse
def test_parse():
    docstring = '''
    Hello world.

    :param str arg1: first argument
    :param int arg2: second argument
    :returns: something
    :raises: some error
    '''
    docstring_parser = parse(docstring)
    assert docstring_parser.short_description == 'Hello world.'
    assert docstring_parser.long_description == None
    assert docstring_parser.blank_after_short_description == True
    assert docstring_parser.blank_after_long_description == False
    assert docstring_parser.meta[0].description == 'first argument'
    assert docstring_parser.meta[1].description == 'second argument'
    assert docstring_parser.meta[2].description == 'something'
    assert docstring_parser.meta[3].description == 'some error'

# Generated at 2022-06-11 21:39:51.692501
# Unit test for function parse
def test_parse():
    src = """
    Short description

    Long description that spans
    multiple lines.

    :arg int x: The x coordinate.
    :arg int y: The y coordinate.
    :param bool foo: Does foo?
    :param bar: Some bar.
    :raises error: An Exception.
    :returns: The sum of x and y.
    :rtype: int
    :return: The sum of x and y.
    :yields: The product of x and y.
    :yields int: The product of x and y.
    :seealso: Some other func.
    :see: Some other func.
    :class:`str`
    :func:`str`
    """

# Generated at 2022-06-11 21:39:59.173028
# Unit test for function parse
def test_parse():
    def foo(a: int, b: int) -> int:
        """
        Example function.

        :param a: integer argument
        :param b: integer argument
        :raises ValueError: when b is 0
        :returns: a + b
        :returns: int
        """
        raise NotImplementedError

    d = parse(foo.__doc__)
    assert d.short_description == "Example function."
    assert d.long_description == ":param a: integer argument\n:param b: integer argument\n:raises ValueError: when b is 0\n:returns: a + b\n:returns: int"
    assert len(d.meta) == 2

    p = d.meta[0]
    assert isinstance(p, DocstringParam)

# Generated at 2022-06-11 21:40:12.672507
# Unit test for function parse
def test_parse():
    """Test docstring parsing"""
    docstring = """Simple function.

    Function with description and a parameter.

    :param param: parameter description
    """
    docstrings = Docstring()
    docstrings.short_description = "Simple function."
    docstrings.long_description = "Function with description and a parameter."
    docstrings.blank_after_short_description = True
    docstrings.blank_after_long_description = False
    docstrings.meta.append(DocstringMeta(["param", "param"],
                                          "parameter description"))
    assert parse(docstring) == docstrings

# Generated at 2022-06-11 21:40:22.440773
# Unit test for function parse
def test_parse():
    text = """Find the largest palindrome made from the product of two 3-digit numbers.

    :param int digits: number of digits to consider
    :raises ValueError: digits must be > 0
    :returns: the largest palindrome
    """

    doc = parse(text)
    #print(dir(doc))
    assert doc.short_description == "Find the largest palindrome made from the product of two 3-digit numbers."
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.long_description == ""
    assert len(doc.meta) == 2
    for item in doc.meta:
        print(item.args)
        print(item.get_key())


# Generated at 2022-06-11 21:40:33.673541
# Unit test for function parse
def test_parse():
    assert parse('''
    Parse the ReST-style docstring into its components.
    ''') == Docstring(
        short_description='Parse the ReST-style docstring into its components.',
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )


# Generated at 2022-06-11 21:40:44.314637
# Unit test for function parse
def test_parse():
    """Basic tests for parse"""
    text = """
    This is a ReST-style docstring.

    This is the long description.

    :param name: this is the parameter name

    :param desc: this is the parameter description
    """
    parsed = parse(text)
    assert len(parsed.meta) == 2
    assert parsed.meta[0].args == ['param', 'name']
    assert parsed.meta[0].description == "this is the parameter name"
    assert parsed.meta[1].args == ['param', 'desc']
    assert parsed.meta[1].description == "this is the parameter description"

    text = """
    This is a ReST-style docstring.

    This is the long description.

    :param name: this is the parameter name

    :param desc: this is the parameter description
    """


# Generated at 2022-06-11 21:40:53.601395
# Unit test for function parse

# Generated at 2022-06-11 21:41:04.195205
# Unit test for function parse
def test_parse():
    from .core import (
        Docstring,
        DocstringMeta,
        DocstringParam,
        DocstringRaises,
        DocstringReturns,
        ParseError,
    )
    # Basic test
    example = """short description.
    Long description.
    :param foo: a parameter.
    :returns: the return value.
    :raises Exception: an exception.
    """
    ret = parse(example)
    assert type(ret) == Docstring
    assert ret.short_description == "short description."
    assert ret.long_description == "Long description."
    assert type(ret.meta[0]) == DocstringParam
    assert ret.meta[0].args == ["param", "foo"]
    assert ret.meta[0].description == "a parameter."
    assert type(ret.meta[1]) == Doc

# Generated at 2022-06-11 21:41:14.063592
# Unit test for function parse
def test_parse():
    text = """\
    short_description

    long_description.
    """
    doc = parse(text)
    assert doc.short_description == "short_description"
    assert doc.long_description == "long_description."
    assert doc.meta == []

    text = """\
    short_description

    long_description.
    :param type_name arg_name: description.
    """
    doc = parse(text)
    assert doc.short_description == "short_description"
    assert doc.long_description == "long_description."
    assert len(doc.meta) == 1
    meta = doc.meta[0]
    assert isinstance(meta, DocstringParam)
    assert meta.key == "param"
    assert meta.arg_name == "arg_name"

# Generated at 2022-06-11 21:41:15.050253
# Unit test for function parse
def test_parse():
    parse('This is short description.\n\nThis is long description.')

# Generated at 2022-06-11 21:41:18.806867
# Unit test for function parse
def test_parse():
    text = """ 
    test parse function
    
    :param a: the first param
    
    :param b: the second param
      
    :returns: 
    """
    ret = parse(text)
    print(ret)

test_parse()

# Generated at 2022-06-11 21:41:26.968441
# Unit test for function parse
def test_parse():
    class A:
        """Test docstring.

        :param x: Some param.
        :type x: int
        :param y: Another param. Defaults to 2.
        :type y: str, optional

        This is some long description.
        See [1]_ for more details.

        References
        ----------
        [1] test

        """
        pass
    a = A()
    ds = parse(a.__doc__)
    ds.short_description == 'Test docstring.'
    ds.blank_after_short_description == False
    ds.long_description == 'This is some long description.\nSee [1]_ for more details.'
    ds.blank_after_long_description == False
    print(ds.meta)

# Generated at 2022-06-11 21:41:41.219215
# Unit test for function parse
def test_parse():
    docstring = """
    Test function.

    This is a test function, with a longer description.

    :param foo: This is the parameter.
    :type foo: int
    :returns: None
    :raises Exception: Test exception.

    """

    expected = Docstring()
    expected.meta.append(DocstringParam(
        args=["param", "foo"],
        arg_name="foo",
        type_name=None,
        is_optional=False,
        default=None,
        description="This is the parameter.",
    ))
    expected.meta.append(DocstringParam(
        args=["type", "foo", "int"],
        type_name="int",
        is_optional=False,
        description="",
        arg_name="foo",
        default=None,
    ))

# Generated at 2022-06-11 21:41:51.376403
# Unit test for function parse
def test_parse():
    """Function for testing parse function.
    Note :
        the docstring below should match the indicated function format exactly.
    """

    def test(a: int, b, c: int = 1, d: int = 1) -> None:
        """This is a test function to test the docstring parser.

        :param a: First variable is a mandatory integer variable.
        :param b: Second variable is also mandatory.
        :param c: Third variable is an optional integer variable.
        :param d: Fourth variable is an optional integer variable.
        """
        pass

    docstring = parse(test.__doc__)
    assert docstring.short_description == "This is a test function to test the docstring parser."
    assert docstring.blank_after_short_description is False
    assert docstring.long_description is None
    assert docstring.blank

# Generated at 2022-06-11 21:42:01.922189
# Unit test for function parse

# Generated at 2022-06-11 21:42:10.432644
# Unit test for function parse
def test_parse():
    docstring = """
    Short summary.

    This is a long
    multiline summary.

    :param arg1 str: first argument
    :param arg2: second argument
    :returns: whatever
    :raises AssertionError: if anything goes wrong
    :raises EDocError: some error
    """
    result=parse(docstring)
    assert result is not None
    assert result.short_description == "Short summary."
    assert result.long_description == "This is a long\nmultiline summary."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert len(result.meta) == 4
    arg1 = result.meta[0]
    assert arg1.arg_name == "arg1"
    assert arg1.type_

# Generated at 2022-06-11 21:42:21.938608
# Unit test for function parse
def test_parse():
    docstring_to_parse = """
    Short description.
    Description continued.
    :param int x: Description of x default.
    :param str y: Description of y.
    :type y: str
    :returns: Description of return.
    :rtype: str
    :raises ValueError: when something bad happens.
    :yields int: Description of yield.
    """
    parsed = parse(docstring_to_parse)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == (
        "Description continued."
    )
    assert parsed.blank_after_short_description is True
    assert parsed.blank_after_long_description is False
    assert len(parsed.meta) == 5

    param = parsed.meta[0]

# Generated at 2022-06-11 21:42:30.804406
# Unit test for function parse
def test_parse():
    testdoc = """
    Short summary.

    Longer summary.

    :param some_param: Some parameter
    :param some_param2: Some parameter2
    :type some_param2: int
    :returns: int
    :rtype: int
    :raises: ValueError
    """
    obj = parse(testdoc)
    assert obj.short_description == "Short summary."
    assert obj.long_description == "Longer summary."
    assert len(obj.meta) == 3
    assert obj.meta[0] == DocstringMeta(
        args=["param", "some_param"], description="Some parameter"
    )

# Generated at 2022-06-11 21:42:35.267051
# Unit test for function parse
def test_parse():
    # Test case for no docstring
    assert parse("") == Docstring()

    # Test case for short docstring
    assert parse("test short description") == Docstring(
        short_description="test short description"
    )

    # Test case for short description paragraph
    assert parse("test short description\n\ntest long description paragraph") == Docstring(
        short_description="test short description",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="test long description paragraph",
    )

    # Test case for long description paragraph

# Generated at 2022-06-11 21:42:48.290498
# Unit test for function parse
def test_parse():
    text = """Summary line.
        Details.
        :param arg1: Type of arg1
        :param arg2: Type of arg2.
        :param arg3: Type of arg3.
        :raises ValueError: Error-message.
        :returns: Value.
        :returns: None.
    """

# Generated at 2022-06-11 21:42:51.570191
# Unit test for function parse
def test_parse():
    s = '''
    Get the name of the current level
    
    This function returns the name of the current level.
    
    :returns: The name of the current level
    '''
    print(parse(s))

# Generated at 2022-06-11 21:42:59.317479
# Unit test for function parse
def test_parse():
    test_doc_string = '''
    This is the test function for testing parse function. It takes one positional argument and returns True.
    :param arg1: first argument
    :returns: True
    '''
    assert parse(test_doc_string)
    assert parse(test_doc_string).short_description == 'This is the test function for testing parse function. It takes one positional argument and returns True.'
    assert parse(test_doc_string).long_description == None
    assert parse(test_doc_string).blank_after_short_description == True
    assert parse(test_doc_string).blank_after_long_description == False
    assert len(parse(test_doc_string).meta) == 1
    assert type(parse(test_doc_string).meta[0]) == DocstringParam

# Generated at 2022-06-11 21:43:14.574739
# Unit test for function parse
def test_parse():
    assert Docstring.parse("") == Docstring()

    text = """
    A short description.

    A *long* description.

    :keyword argument: Description of an argument.
    """
    d = Docstring.parse(text)
    expected = Docstring(
        short_description="A short description.",
        blank_after_short_description=False,
        long_description="A *long* description.",
        blank_after_long_description=False,
        meta=[
            DocstringMeta(
                args=["keyword", "argument"], description="Description of an argument."
            )
        ],
    )
    assert d == expected

    text = """
    A short description.

    A *long* description.

    :param name: Description of an argument.
    """
    d = Docstring.parse(text)
   

# Generated at 2022-06-11 21:43:22.375951
# Unit test for function parse
def test_parse():
    docstring = parse(
    """\
    sample docstring

    :param kw1: description
    :param kw2: description
    :param kw3: description
    :returns: description
    :raises TypeError: description
    """)

    assert(docstring.short_description == "sample docstring")
    assert(docstring.blank_after_short_description == True)
    assert(docstring.blank_after_long_description == True)
    assert(docstring.long_description == None)

    assert(docstring.meta[0].keyword == 'param')
    assert(docstring.meta[0].arg_name == 'kw1')
    assert(docstring.meta[0].description == 'description')
    assert(docstring.meta[1].keyword == 'param')

# Generated at 2022-06-11 21:43:29.868780
# Unit test for function parse
def test_parse():
    assert parse(None) == Docstring()
    assert parse("") == Docstring()
    assert parse("test") == Docstring(
        short_description="test",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description=None,
        meta=[],
    )

# Generated at 2022-06-11 21:43:31.097994
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    pass

# Generated at 2022-06-11 21:43:42.811001
# Unit test for function parse
def test_parse():
    from pprint import pprint

    docstring = """
    Short description.
    
    Long description.
    
    :param arg1: This is the first parameter.
    :type arg1: str
    :param arg2: This is a second parameter.
    :type arg2: bool, optional
    :returns: This is a description of what is returned.
    :rtype: int, str
    :raises keyError: Why this can raise an exception.
    :raises ImportError: Why this can also raise an exception.
    """

    pprint(parse(docstring))
    # Docstring(
    #     blank_after_long_description=True,
    #     blank_after_short_description=True,
    #     long_description='Long description.',
    #     meta=[
    #         DocstringParam(

# Generated at 2022-06-11 21:43:55.363077
# Unit test for function parse
def test_parse():
    """Test parse function"""
    source = """A short summary.

A longer description. This can take multiple lines.
Without a blank line after it.

:param int arg_name: A description of a parameter.
:param float arg_name: A description of a parameter.
:param float arg_name2: A description of a parameter.
:param float arg_name3: A description of a parameter.
:returns: A description of the return value.
:raises: An error class.
:raises: Another error class.
"""

    docstring = parse(source)

    assert docstring.short_description == "A short summary."
    assert docstring.long_description == "A longer description. This can take multiple lines.\nWithout a blank line after it."
    # test_parse_meta

# Generated at 2022-06-11 21:44:05.541592
# Unit test for function parse
def test_parse():
    docstring = """
    A helper function that allows to use the same
    user and password for different backends.

    :param kwargs: keyword arguments supplied to the backends
    :returns: dictionary with user/password arguments per backend
    """
    doc = parse(docstring)
    assert doc.short_description == "A helper function that allows to use the same user and password for different backends."
    assert doc.long_description == None
    assert len(doc.meta) == 1
    assert doc.meta[0].args == ["param", "kwargs"]
    assert doc.meta[0].description == "keyword arguments supplied to the backends"

# Generated at 2022-06-11 21:44:14.617774
# Unit test for function parse
def test_parse():
    docstring = """Takes two numbers and adds them together.

    :param a: The first number (int)
    :param b: The second number (int)
    :raises TypeError: if inputs are invalid types
    :returns: The two numbers added together (int)
    """

    result = parse(docstring)

    assert len(result.meta) == 3
    assert result.short_description.strip() == "Takes two numbers and adds them together."
    assert not result.blank_after_short_description
    assert result.long_description == """\
                                                                                 The first number (int)
                                                                                 The second number (int)"""
    assert result.blank_after_long_description
    assert result.meta[0].arg_name == "a"
    assert result.meta[0].type_name

# Generated at 2022-06-11 21:44:24.179436
# Unit test for function parse
def test_parse():
    ds = parse("""
    short desc
    long desc.

    :param verbose: desc
    :type verbose: bool
    :param name: desc
    :type name: str
    """)
    assert ds.short_description == "short desc"
    assert ds.long_description == "long desc."
    assert ds.blank_after_short_description
    assert ds.blank_after_long_description
    assert ds.meta[0].arg_name == "verbose"
    assert ds.meta[0].description == "desc"
    assert ds.meta[1].arg_name == "name"
    assert ds.meta[1].description == "desc"
    assert ds.meta[0].type_name == "bool"
    assert ds.meta[1].type_name

# Generated at 2022-06-11 21:44:34.770566
# Unit test for function parse
def test_parse():
    doc = """
    This function is great.

    :param foo: the foo argument
    :param bar: the bar argument, defaults to 1.
    :type bar: int
    :param xyzzy: an optional argument
    :param baz?: this argument has an optional type
    :param boo: and this one defaults to 2
    :type boo: int, defaults to 2
    :raises BarError: when something bad happens
    :return: a value
    :returns: a value
    :returns int: a value
    :yield: a value
    :yields: a value
    :yields int: a value
    """

    parsed = parse(doc)

    # Test short_description
    assert parsed.short_description == "This function is great."

    # Test blank_after_short_description
    assert parsed

# Generated at 2022-06-11 21:44:51.760567
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    test_text = """Something about this module.

    A longer description of the stuff in this module.

    :param int foo: Foo is a parameter that does foo.
    :param bar: Bar is a parameter that does bar.
    :return: something
    :raises Exception: no reason
    """
    docstring = parse(test_text)
    assert docstring.short_description == "Something about this module."
    assert docstring.long_description == (
        "A longer description of the stuff in this module."
    )
    assert len(docstring.meta) == 4
    assert isinstance(docstring.meta[0], DocstringParam)
    assert isinstance(docstring.meta[1], DocstringParam)
    assert isinstance(docstring.meta[2], DocstringReturns)

# Generated at 2022-06-11 21:45:02.391121
# Unit test for function parse
def test_parse():
    docstring = """Description of the function.
    :param int foo: First parameter
    :param str bar: Second parameter
    :raises ValueError: If something bad happens.
    :returns: None"""
    x = parse(docstring)
    assert x.short_description == "Description of the function."
    assert x.long_description == None
    assert x.meta[0].arg_name == "foo"
    assert x.meta[1].arg_name == "bar"
    assert x.meta[2].type_name == "ValueError"
    assert x.meta[3].type_name == None

# Generated at 2022-06-11 21:45:09.698219
# Unit test for function parse
def test_parse():
    from pyleri import Grammar, Keyword, Regex

    class T(Keyword):
        pass

    class N(Regex):
        regex = r"\d+"

    class E(Regex):
        regex = r"\d+"

    class R(Regex):
        regex = r"\d+"

    class D(Regex):
        regex = r"\d+"

    class DocstringParser(Grammar):
        grammar = T("return") + ": " + (N | (N, "-", N)) + R("\n") + D("\n")

    assert DocstringParser.parse_text(
        """

        :return: 123 asd
        123 asd
        """
    ).is_valid


# Generated at 2022-06-11 21:45:21.772379
# Unit test for function parse

# Generated at 2022-06-11 21:45:30.847241
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    assert parse("Short description here.") == Docstring(
        short_description="Short description here.",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse("Short description here.\n\nLong description here.") == Docstring(
        short_description="Short description here.",
        long_description="Long description here.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-11 21:45:40.330470
# Unit test for function parse

# Generated at 2022-06-11 21:45:43.549386
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    print(parse.__name__)
    text = "This is a test doc string"
    print(parse(text))


# Generated at 2022-06-11 21:45:52.232143
# Unit test for function parse
def test_parse():
    input_docstring_1 = """This is a short description.
It spans multiple lines.

:param  int  x: a param
:returns: a return
:raises ValueError: any error
:yields: a yield
"""
    output_docstring = parse(input_docstring_1)
    assert output_docstring.short_description == "This is a short description."
    assert output_docstring.long_description == """
It spans multiple lines.
""".strip()
    assert output_docstring.blank_after_short_description
    assert output_docstring.blank_after_long_description
    assert isinstance(output_docstring.meta[0], DocstringParam)
    assert output_docstring.meta[0].args == ["param", "int", "x"]

# Generated at 2022-06-11 21:46:02.818350
# Unit test for function parse
def test_parse():
    test_text = """This is the short description.

This is the first line of the long description.
This is the second line.
:param foo: this is foo
:param int bar: this is an integer bar
:return: This is the return value
:rtype: int"""
    parsed = parse(test_text)
    assert parsed.short_description == "This is the short description."
    assert parsed.long_description == "This is the first line of the long description.\nThis is the second line."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].arg_name == "foo"
    assert parsed.meta[0].type_name == None
    assert parsed.meta[1].arg_name

# Generated at 2022-06-11 21:46:14.721201
# Unit test for function parse
def test_parse():
    doc = """test
    :param x: test
    :type x: int
    :raises: test"""

# Generated at 2022-06-11 21:46:31.949412
# Unit test for function parse
def test_parse():
    docstring = parse("""\
        Short description.
        
        Long description.
        
        :param type_name: Description.
        :param arg_name: Description. Defaults to one.
        :param arg_name?: Description. Defaults to two.
        :return: Description.
        :returns: Description.
        :raises: Description.
        :raises type_name: Description.
        :yields: Description.
        :yields type_name: Description.
        :other: Description.
        :other arg_name: Description.
        :other arg_name?: Description.
    """)

    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_

# Generated at 2022-06-11 21:46:41.197356
# Unit test for function parse
def test_parse():
    # Parse an empty docstring
    text = ""
    assert parse(text) == Docstring()
    # Parse a docstring without metadata
    text = "A docstring."
    assert parse(text) == Docstring(
        short_description="A docstring.",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    # Parse a docstring with metadata after a blank line
    text = "A docstring.\n\n:returns: The docstring."