

# Generated at 2022-06-11 21:36:57.561010
# Unit test for function parse
def test_parse():
    doc = """
    A very short description.

    A very long description.

    :param arg1: description
    :param arg2: description
    :raises ValueError: description
    :raises RuntimeError: description
    :returns: description"""


# Generated at 2022-06-11 21:37:01.027807
# Unit test for function parse
def test_parse():
    import docstringhints

    def foo(a,b):
        """Short description.
        
        This is a longer description.
        """
        pass

    test=docstringhints.parse(foo.__doc__)
    print(test)

# Generated at 2022-06-11 21:37:09.407761
# Unit test for function parse
def test_parse():
    def testDecorate(func):
        d = parse(func.__doc__)
        func = d.verify_func(func)
        return func

    @testDecorate
    def func(a, b, c=1, d=2):
        """A short description.

        A long description.

        :param a: a parameter
        :type a: int
        :param b: a parameter
        :type b: str
        :param c: a parameter
        :param d: a parameter, defaults to 2
        """
        pass

    print(func)
    return func


if __name__ == "__main__":
    ff = test_parse()

# Generated at 2022-06-11 21:37:20.481272
# Unit test for function parse
def test_parse():
    print("Testing function parse")
    
    docstring = """\
    This is a one-line summary.
    """
    docstring_parsed = Docstring(
        short_description = 'This is a one-line summary.',
        blank_after_short_description = True,
        blank_after_long_description = False,
        long_description = None,
        meta = []
    )

    docstring_parsed_result = parse(docstring)
    
    assert docstring_parsed == docstring_parsed_result

    docstring = """\
    This is a one-line summary.
    
    And this is a paragraph.
    """

# Generated at 2022-06-11 21:37:29.886537
# Unit test for function parse
def test_parse():
    text = '''
        This is a docstring
        :param x: parameter x
        :type x: int
        :param y: parameter y
        :type y: str
        :returns: whatever
        :rtype: int
        :raises: ValueError
        '''
    ret = parse(text)
    assert ret.short_description == 'This is a docstring'
    assert ret.blank_after_short_description
    assert ret.long_description is None
    assert ret.blank_after_long_description
    assert len(ret.meta) == 4
    for m in ret.meta:
        assert m.line_number is None



# Generated at 2022-06-11 21:37:36.467189
# Unit test for function parse
def test_parse():
    docstring = """
    Test the parse function.

    :param: firstname
    :param str lastname:

    :returns: True
    """


# Generated at 2022-06-11 21:37:40.459096
# Unit test for function parse
def test_parse():
    from .tests.test_parse import TEST_DOCSTRINGS
    for docstring, expected in TEST_DOCSTRINGS:
        actual = parse(docstring)
        if actual != expected:
            print("***")
            print(docstring)
            print(actual)
            print(expected)
            print("***")



# Generated at 2022-06-11 21:37:49.596864
# Unit test for function parse

# Generated at 2022-06-11 21:37:53.329991
# Unit test for function parse
def test_parse():
    test_text = """Test function.
    :param int x: X-parameter.
    :param int y: Y-parameter.
    :raises ValueError: when x is negative."""
    assert isinstance(parse(test_text), Docstring)


# Generated at 2022-06-11 21:38:05.575896
# Unit test for function parse
def test_parse():
    docstring = """\
Parses line information from a PDB file.

        :param str path: Path to PDB file.
        :param strings line_prefixes: List of one or more
            prefixes. If provided, will only parse the lines
            starting with one of these prefixes.
        :param bool has_header: Whether the PDB file has a header
            line. Default: False.
        :returns: a list of dictionaries containing the fields
            extracted from each line.
"""
    obj = parse(docstring)
    print(obj)
    assert obj.short_description == 'Parses line information from a PDB file.'
    assert obj.long_description == 'a list of dictionaries containing the fields extracted from each line.'
    assert obj.meta[0].arg_name == 'path'

# Generated at 2022-06-11 21:38:20.786609
# Unit test for function parse
def test_parse():
    docstring = Docstring()
    docstring2 = parse(
        """
        test to parse a docstring.

        :param a: a function parameter
        :param b: another function parameter
        :returns: return value
        :raises: ValueError
        """
    )
    parse_docstring = (
        [
            "test to parse a docstring.",
            ":param a: a function parameter\n:param b: another function parameter",
            ":returns: return value\n:raises: ValueError",
        ]
    )
    assert docstring2.short_description == parse_docstring[0]
    assert docstring2.long_description == parse_docstring[1]
    assert docstring2.meta == parse_docstring[2]

# Generated at 2022-06-11 21:38:23.666163
# Unit test for function parse
def test_parse():
    docstring = inspect.getdoc(parse)
    assert parse(docstring).as_dict() == {'long_description': '\nParse the ReST-style docstring into its components.\n\n:returns: parsed docstring\n', 'short_description': 'Parse the ReST-style docstring into its components.', 'meta': [{'args': ['returns'], 'description': 'parsed docstring'}], 'blank_after_short_description': True, 'blank_after_long_description': True}

# Generated at 2022-06-11 21:38:34.488019
# Unit test for function parse
def test_parse():
    """
    Unit test for function parse
    """
    from .common import DocstringParam

    # test parser
    doc = "test the parser"
    docstring = parse(doc)
    assert docstring.short_description == "test the parser"
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []

    # test parser with \n
    doc = "test the parser \n with new line"
    docstring = parse(doc)
    assert docstring.short_description == "test the parser"
    assert (
        docstring.long_description == "with new line"
    )
    assert docstring.blank_after_short_description is True
    assert docstring.blank_

# Generated at 2022-06-11 21:38:45.715925
# Unit test for function parse
def test_parse():
    docstr = parse("""
    Some Short Description

    More long description, which
    is not a continuation of the
    short one.

    :param str arg1: Description of arg1
    :param int arg2: Description of arg2
    :raises ValueError: If something bad happens
    """)
    assert docstr.short_description == "Some Short Description"
    assert docstr.long_description == "More long description, which\nis not a continuation of the\nshort one."

    assert docstr.meta[0].arg_name == "arg1"
    assert docstr.meta[0].type_name == "str"
    assert docstr.meta[0].description == "Description of arg1"
    assert docstr.meta[0].is_optional is False
    assert docstr.meta[0].default is None


# Generated at 2022-06-11 21:38:50.504145
# Unit test for function parse
def test_parse():
    """Test if parse function works as intended"""
    docstring = """This is a test

    :param name1: something
    :type name1: bool or str
    :param name2: something
    :type name2: bool or str
    :returns: something
    :rtype: bool or str
    """
    result = parse(docstring)
    return

# Generated at 2022-06-11 21:39:02.299079
# Unit test for function parse
def test_parse():
    docstring = parse(inspect.cleandoc('''
        Short summary.

        This is a long
        description.

        :param foo: this is foo
        :type foo: int
        :param bar: this is bar
        :type bar: str
        :returns: something
        :rtype: bool
        :raises ValueError: when things go wrong
    '''))
    assert docstring.short_description == "Short summary."
    assert docstring.long_description == "This is a long\ndescription."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "foo"]
    assert docstring.meta[0].description == "this is foo"

# Generated at 2022-06-11 21:39:14.811871
# Unit test for function parse
def test_parse():
    """Unit test for parse()."""
    docstring = """This is a short description
    This is a long description
    :param foo: description of foo
    :type foo: str
    :param bar: description of bar
    :type bar: unknown
    :param baz: description of baz
    :type baz: int, optional
    :param qux: description of qux
    :type qux: int, defaults to 42
    :returns: type
    :rtype: str
    :yields: type"""
    doc = parse(docstring)
    assert doc.short_description == "This is a short description"
    assert doc.long_description == "This is a long description"
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description

    param_foo, param_

# Generated at 2022-06-11 21:39:24.836078
# Unit test for function parse
def test_parse():
    d = parse("""
        One line summary.

        More detailed description.

        :param a: Parameter a is added here.
        :type a: int
        :param b: Parameter b is added here.
        :param c: Parameter c is added here.
        :type c: str
        :param d: Parameter d is added here.
        :type d: str
        :raises ValueError: If the value error is raised.
        :returns: Return type should be put here.
    """)

    assert d.short_description == "One line summary."
    assert d.blank_after_short_description
    assert d.long_description == "More detailed description."
    assert d.blank_after_long_description
    assert d.meta[0].args == ["param", "a", "b"]
    assert d

# Generated at 2022-06-11 21:39:37.417567
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse(" ") == Docstring()
    assert parse("  ") == Docstring()
    assert parse("  \n") == Docstring()

    # Multi-line descriptions capitalized
    assert parse("  \n  \n").description == ""
    assert parse("hello\nworld").description == "Hello. World."
    assert parse("a\nb\nc").description == "A. B. C."

    # Blank lines included in description
    assert parse("  \n  \n").description == ""
    assert parse("hi\n\nthere").description == "\nHi.\n There."
    assert parse("  \na\n  \nb\n  \n").description == "\n\nA.\n\nB."

    #

# Generated at 2022-06-11 21:39:49.694159
# Unit test for function parse

# Generated at 2022-06-11 21:40:05.166025
# Unit test for function parse
def test_parse():
    import time
    import random
    from random import randint
    from random import randrange
    from random import shuffle
    from random import choice
    from random import choices
    from random import sample

    from .common import (
        PARAM_KEYWORDS,
        RAISES_KEYWORDS,
        RETURNS_KEYWORDS,
        YIELDS_KEYWORDS,
        Docstring,
        DocstringMeta,
        DocstringParam,
        DocstringRaises,
        DocstringReturns,
        ParseError,
    )

    # Test empty docstring
    docstring = parse('')
    assert docstring.short_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.long_description == None
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-11 21:40:14.668363
# Unit test for function parse
def test_parse():
    text = """
    red_ball()
    
        Get a red ball.
    
        :param int radius: The radius of the ball.
        :param Color color: The color of the ball. Defaults to red.
        :returns Ball: The ball.
        :raises ValueError: If radius is non-positive.
    """
    docstring = parse(text)

# Generated at 2022-06-11 21:40:24.590124
# Unit test for function parse
def test_parse():
    """Sanity check for function parse."""
    assert parse("") == Docstring()

    text = "A short description.\n\n" "A long description."
    assert parse(text) == Docstring(
        short_description="A short description.", long_description="A long description."
    )

    assert parse("A short description with no new lines.") == Docstring(
        short_description="A short description with no new lines."
    )

    text = (
        "A short description.\n"
        "A long description with no blank line\n"
        "between the short and long descriptions."
    )

# Generated at 2022-06-11 21:40:35.546464
# Unit test for function parse
def test_parse():
    doc = parse("")
    assert doc.to_text() == ""

    doc = parse("Hello world!")
    assert doc.to_text() == "Hello world!"
    assert doc.short_description == "Hello world!"
    assert not doc.long_description
    assert doc.long_description_is_blank
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description

    doc = parse("Hello world!\n\n")
    assert doc.to_text() == "Hello world!\n\n"
    assert doc.short_description == "Hello world!"
    assert not doc.long_description
    assert doc.long_description_is_blank
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description


# Generated at 2022-06-11 21:40:40.809964
# Unit test for function parse
def test_parse():
    text = """Get a list of all the existing endpoints.
    :rtype: list"""
    assert parse(text).meta[0].description == "Get a list of all the existing endpoints."
    assert parse(text).meta[0].type_name == "list"


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:40:48.605246
# Unit test for function parse
def test_parse():
    """Test the parse function"""
    text = """Test function parse

    :param b: parameter b
    :returns: nothing
    """

    parsed_doc = parse(text)
    assert parsed_doc.short_description == "Test function parse"
    assert parsed_doc.long_description == None
    assert parsed_doc.meta[0].arg_name == "b"
    assert parsed_doc.meta[0].description == "parameter b"
    assert parsed_doc.meta[1].description == "nothing"

# Generated at 2022-06-11 21:40:59.142883
# Unit test for function parse

# Generated at 2022-06-11 21:41:10.215539
# Unit test for function parse
def test_parse():
    text = """
    Docstring.

    :param str a: First parameter.  Defaults to None.
    :returns: The return value.
    :rtype: str
    """


# Generated at 2022-06-11 21:41:20.611005
# Unit test for function parse
def test_parse():
    def f(a: T.List[int], b: "b", c="c", *args: T.List[str], **kwargs: T.List[float]):
        """
            :param a: a
            :type a: list of int
            :param b: b
            :type b: str
            :param c: c
            :type c: str, defaults to `c`
            :param args: args
            :type args: list of str
            :param kwargs: kwargs
            :type kwargs: list of float
            :returns: returns
            :rtype: str
            :returns: returns
            :yields: yields
            :ytype: str
            :raises AssertionError: AssertionError
            :raises Exception: Exception
        """


# Generated at 2022-06-11 21:41:27.799409
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    assert parse("foo") == Docstring(
        short_description="foo",
        long_description=None,
        meta=[]
    )

    assert parse("\nfoo") == Docstring(
        short_description="foo",
        long_description=None,
        meta=[],
        blank_after_short_description=True
    )

    assert parse("""
        foo
        """) == Docstring(
        short_description="foo",
        long_description=None,
        meta=[],
    )

    assert parse("""
        foo

        """) == Docstring(
        short_description="foo",
        long_description=None,
        meta=[],
        blank_after_long_description=True
    )


# Generated at 2022-06-11 21:41:41.289427
# Unit test for function parse
def test_parse():
    import pytest
    sample = """
    This is an example function with a docstring.
    
    Args:
        a: An integer
        b: A string
        c: An optional string
        d: An optional string, defaults to None
        e: An optional string
        f: An optional string
        g: An optional string
        h: An optional string, defaults to None
        i: An optional string
        j: An optional string
        k: An optional string
    
    Returns:
        A string
    
    Raises:
        ValueError: An exception
    """
    result = parse(sample)
    assert isinstance(result, Docstring) == True
    assert result.short_description == "This is an example function with a docstring."
    assert result.blank_after_short_description == True
    assert result.blank

# Generated at 2022-06-11 21:41:51.419046
# Unit test for function parse
def test_parse():
    docstring = """Single line docstring.
    """
    assert parse(docstring) == Docstring(
        short_description="Single line docstring.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )
    docstring = """Single line docstring."""
    assert parse(docstring) == Docstring(
        short_description="Single line docstring."
    )
    docstring = """Single line docstring.

    Long description.
    """
    assert parse(docstring) == Docstring(
        short_description="Single line docstring.",
        blank_after_short_description=True,
        long_description="Long description.",
        blank_after_long_description=True,
    )

# Generated at 2022-06-11 21:42:01.964409
# Unit test for function parse
def test_parse():
    # Test empty docstring
    d1 = parse("")
    assert d1 and isinstance(d1, Docstring)
    assert d1.short_description is None
    assert d1.long_description is None
    assert not d1.meta

    # Test docstring with short description only
    d2 = parse("Hello, world!")
    assert d2 and isinstance(d2, Docstring)
    assert d2.short_description == "Hello, world!"
    assert d2.long_description is None
    assert not d2.meta

    # Test docstring with short description and long description
    d3_text = "Hello, world!\n\nThis is a test."
    d3 = parse(d3_text)
    assert d3 and isinstance(d3, Docstring)
    assert d3.short_description

# Generated at 2022-06-11 21:42:10.469365
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param str arg1: The first argument.
    :param int arg2: The second argument.
    :returns: Description returns.
    :rtype: str
    """
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == "Short description."
    assert parsed_docstring.long_description == "Long description."
    assert parsed_docstring.meta[0].description == "The first argument."
    assert parsed_docstring.meta[0].arg_name == "arg1"
    assert parsed_docstring.meta[0].type_name == "str"
    assert parsed_docstring.meta[0].is_optional == False
    assert parsed_docstring.meta[0].default is None
    assert parsed_docstring

# Generated at 2022-06-11 21:42:21.977482
# Unit test for function parse
def test_parse():
    docstring = """
    This is the first line of the docstring.
    This is the second line of the docstring.

    :param arg1: This is a description of arg1.
    :type arg1: int
    :param arg2: This is a description of arg1.
    :type arg2: list
    :param arg3: This is a description of arg1.
    :type arg3: dict
    :param arg4: This is a description of arg1.
    :type arg4: str
    :param arg5: This is a description of arg1.
    :type arg5: bool
    :returns: Nothing
    :rtype: None
    """
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == 'This is the first line of the docstring.'

# Generated at 2022-06-11 21:42:30.803726
# Unit test for function parse
def test_parse():
    text = """\
    This is the short description.

    This is the long one.

    :param x: a number
    :type x: int
    :param b: a boolean
    :type b: bool
    :raises RuntimeError: if bad things happen
    :returns: None
    """
    docstring = parse(text)
    assert not docstring.blank_after_short_description
    assert docstring.short_description == "This is the short description."
    assert not docstring.blank_after_long_description
    assert docstring.long_description == "This is the long one."

# Generated at 2022-06-11 21:42:34.452415
# Unit test for function parse
def test_parse():
    ds = parse("""
    Short description.

    Long description.

    :param arg1: The first argument.

    :param arg2: The second argument.
    """)
    assert ds.short_description == "Short description."
    assert ds.blank_after_short_description is False
    assert ds.long_description == "Long description."
    assert ds.blank_after_long_description is True
    assert ds.meta == [
        DocstringParam(["param", "arg1"], "The first argument."),
        DocstringParam(["param", "arg2"], "The second argument."),
    ]



# Generated at 2022-06-11 21:42:41.323173
# Unit test for function parse
def test_parse():
    # test double colon
    try:
        parse(": :")
        raise Exception("double colon check failed")
    except ValueError:
        print("Passed: double colon check passed")

    # test single colon
    try:
        parse(": ")
        raise Exception("single colon check failed")
    except ValueError:
        print("Passed: single colon check passed")

    # test no colon
    try:
        parse("::")
        raise Exception("no colon check failed")
    except ValueError:
        print("Passed: no colon check passed")

    # test indented colon
    try:
        parse(":   : ")
        raise Exception("indented colon check failed")
    except ValueError:
        print("Passed: indented colon check passed")

    # test missing keywords

# Generated at 2022-06-11 21:42:50.397379
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a description
    of the function.
    :param x: Description of x.
    :type x: int
    :param y: Description of y.
    :type y: int
    :default x: 3
    :default y: 4
    :raises ValueError: This is an error.
    :raises KeyError: This is another error.
    :returns: Something.
    :rtype: int
    '''
    ds = parse(docstring)
    assert ds.short_description == 'This is a description of the function.'
    assert ds.long_description is None
    assert len(ds.meta) == 8

# Generated at 2022-06-11 21:42:58.940466
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    docString = """
    """
    assert parse(docString) == Docstring()

    docString = """
	
	"""
    assert parse(docString) == Docstring(short_description=None,
                                         long_description=None,
                                         meta=[])

    docString = """
	
	
	"""
    assert parse(docString) == Docstring(short_description=None,
                                         long_description=None,
                                         meta=[])

    docString = """
	:
	"""
    assert parse(docString) == Docstring(short_description=None,
                                         long_description=None,
                                         meta=[])

    docString = """
	a
	"""
    assert parse(docString) == Docstring(short_description='a')

    docString

# Generated at 2022-06-11 21:43:14.248927
# Unit test for function parse
def test_parse():
    """Parse the ReST-style docstring into its components."""

# Generated at 2022-06-11 21:43:19.231829
# Unit test for function parse
def test_parse():
    text = """
    Parses a ReST-style docstring into its components.

    :param path: path to the file
    :type path: str
    :param mode: mode
    :type mode: int, optional
    :raises IOError: if a file does not exist
    :returns: parsed docstring
    """
    t = parse(text)
    return t


# Generated at 2022-06-11 21:43:28.576764
# Unit test for function parse
def test_parse():
    docstring = r"""
    This is a very short description.

    This is a
    much longer description.

    :param arg1: This is the first parameter.
    :type arg1: str
    :param arg2: This is the second parameter.
    :type arg2: str, optional
    :param arg3: This is the third parameter.
    :type arg3: str
    :raises: RuntimeError
    :raises: OtherError
    :raises KeyError, ValueError, TypeError:
      This is all part of one raises.
    :return: This is the return docstring.
    :rtype: str
    """
    parse_result = parse(docstring)
    assert parse_result.short_description == 'This is a very short description.'

# Generated at 2022-06-11 21:43:41.569341
# Unit test for function parse
def test_parse():
    doc = """
    This is a short description.

    This is the long description.

    :param int x: this is x
    :param list y: this is y
    :param bool z: this is z
    :type z: bool
    :returns: something
    :raises AttributeError: when something bad happens
    :raises AttributeError: when something bad happens
    :raises BaseException: when something bad happens
    :raises: when something bad happens
    """
    docstring = parse(doc)
    assert docstring.short_description == 'This is a short description.'
    assert docstring.long_description == 'This is the long description.'
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-11 21:43:50.272529
# Unit test for function parse
def test_parse():
    """Test docstring parsing with examples."""
    code = inspect.cleandoc(r"""
    This is the short description.
    
    This is the long description. It can have multiple lines.
    
    :param arg1: the first argument
    :param arg2: the second argument
    :param arg3: the third argument, defaults to True.
    :returns: description of the return value
    :raises ValueError: if something bad happens.
    """)
    signature = inspect.signature(parse)
    assert parse(code).signature == signature

# Generated at 2022-06-11 21:43:53.221023
# Unit test for function parse
def test_parse():
    assert (
        "first line and a second line"
        == parse("first line\n\nand a second line").short_description
    )



# Generated at 2022-06-11 21:44:05.791703
# Unit test for function parse
def test_parse():
    def f(x: int, y: int = 3) -> int:
        """Short blah blah blah.

        Long blab blah blah.
        :param x: first param
        :param y: second param
        :returns: returns this or that
        """

    doc = parse(inspect.getdoc(f))
    assert(doc.short_description == "Short blah blah blah.")
    assert(doc.blank_after_short_description == False)
    assert(doc.long_description == "Long blab blah blah.")
    assert(doc.blank_after_long_description == True)
    assert(len(doc.meta) == 3)
    assert(doc.meta[0].description == "first param")
    assert(doc.meta[0].arg_name == "x")

# Generated at 2022-06-11 21:44:14.575866
# Unit test for function parse
def test_parse():
    docstring = """Short description.

Longer description.

:param str arg1: This is first argument.
:param int arg2: This is second argument.
:returns: Function returns int.
:raises KeyError: Raise if x > 10.
"""
    ret = parse(docstring)

    assert ret.short_description == "Short description."
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == True
    assert ret.long_description == "Longer description."

    assert len(ret.meta) == 4

    assert ret.meta[0].args == ["param", "str", "arg1"]
    assert ret.meta[0].description == "This is first argument."
    assert ret.meta[0].arg_name == "arg1"
    assert ret.meta

# Generated at 2022-06-11 21:44:24.178214
# Unit test for function parse
def test_parse():
    text = '''\
    Parses the ReST-style docstring into its components.

    :param text: The text to parse
    :raises ParseError: If it can't parse the text
    :returns: parsed docstring
    '''
    doc = parse(text)
    assert doc.short_description == 'Parses the ReST-style docstring into its components.'
    assert doc.long_description == 'The text to parse'
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == True
    assert doc.meta[0].arg_name == 'text'
    assert doc.meta[0].type_name == 'str'
    assert doc.meta[0].default == 'None'
    assert doc.meta[1].type_name == 'ParseError'

# Generated at 2022-06-11 21:44:34.818304
# Unit test for function parse
def test_parse():
    sample_code = """\
        Summary line. Extended description of function.

        :param arg1: Description of arg1
        :type arg1: int, optional
        :param arg2: Description of arg2
        :type arg2: str, optional
        :returns: Description of return value.
        :rtype: bool

        """
    docstring = parse(sample_code)
    assert docstring.short_description == "Summary line. Extended description of function."
    assert docstring.blank_after_short_description == False
    assert docstring.long_description == None
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 3
    assert str(docstring.meta[0]) == ':param arg1: Description of arg1'
    assert str(docstring.meta[1])

# Generated at 2022-06-11 21:44:46.050126
# Unit test for function parse
def test_parse():
    docstring = """A docstring.

:param str x: A string.

:param int y: An integer.

:param: A parameter.

:returns: Nothing

:raises ValueError: In case of error.

:raises: In case of error.

:yields int: A number.

:yields: A number.

:rtype: int

"""


# Generated at 2022-06-11 21:44:54.411346
# Unit test for function parse

# Generated at 2022-06-11 21:45:06.864321
# Unit test for function parse
def test_parse():
    # empty string
    assert parse("") == Docstring()
    assert parse(" ") == Docstring()

    # no meta
    assert parse("foo") == Docstring(
        short_description="foo", blank_after_short_description=True
    )
    assert parse("foo\nbar") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="bar",
    )

    # one meta
    assert parse(":type foo: int") == Docstring(meta=[DocstringMeta(args=["type", "foo", "int"])])

# Generated at 2022-06-11 21:45:19.049831
# Unit test for function parse

# Generated at 2022-06-11 21:45:29.306002
# Unit test for function parse
def test_parse():
    docstring = """
    This is an example docstring.

    This is a "long" description that spans multiple lines and includes
    examples of :code:`inline code` and :math:`inline math`.

    The short description is needed for a table of contents.

    :param x: A float
    :param y: A float, defaults to 2.0
    :returns: Float

    :raises: :exc:`ZeroDivisionError`
    """
    print(parse(docstring))
    # Docstring(
    #     short_description='This is an example docstring.',
    #     blank_after_short_description=True,
    #     blank_after_long_description=False,
    #     long_description='This is a "long" description that spans multiple '
    #                     'lines and includes examples of inline code and

# Generated at 2022-06-11 21:45:32.419356
# Unit test for function parse
def test_parse():
    from docstr_coverage.tests._constants import RE_DOCSTRING
    from docstr_coverage.tests.test_common import assert_docstring

    assert_docstring(parse(RE_DOCSTRING), RE_DOCSTRING)

# Generated at 2022-06-11 21:45:39.426605
# Unit test for function parse
def test_parse():
    """
    Test the parse function
    """
    text = """
    Test the parse function

    :param a: test param
    :arg a: test arg
    :raises Exception: raises exception
    """
    doc = parse(text)
    assert doc.short_description == "Test the parse function"
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "a"
    assert doc.meta[1].arg_name == "a"
    assert doc.meta[2].type_name == "Exception"

# Generated at 2022-06-11 21:45:50.215754
# Unit test for function parse
def test_parse():
    def f():
        """
        Short description.

        Long description.

        :param arg1: This is a arg1
        :type arg1: int or float
        :param arg2: This is a arg2
        :type arg2: str
        :param arg3: This is a arg3
        :type arg3: float
        :param arg4: This is a arg4
        :type arg4: True or False
        :return: This returns something which is a str.
        :rtype: str
        :raise "Exception": raises an exception.
        """
        pass


# Generated at 2022-06-11 21:46:01.522660
# Unit test for function parse
def test_parse():
    docstring = parse("""
        one
        two
        :param x: This is x
        :param y: This is y
        :type y: float
        :param z: This is z
        :type z: float
        :returns: description of the return value
        :returns: another description of the return value
        :returns: int
        :raises ValueError: if x is 0
        """)

    assert docstring.short_description == "one\ntwo"
    assert docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert docstring.long_description is None

    assert len(docstring.meta) == 6

    _, y, z, return_value, return_value2, raise_value = docstring.meta


# Generated at 2022-06-11 21:46:14.054537
# Unit test for function parse
def test_parse():
    text = """
        Short description.

        Long description.

        :param foo: Bar
        :param goo: Goo
        :rtype: int
        :returns: number
        :raises RuntimeError: if error
    """

    parsed = parse(text)
    assert parsed.short_description == "Short description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == True
    assert parsed.long_description == "Long description."

# Generated at 2022-06-11 21:46:28.235924
# Unit test for function parse
def test_parse():
    doc = parse(
        """
    A docstring.
    
    :param thing1: foo
    :type thing1: int
    :type thing2: int"""
    )
    assert doc.short_description == "A docstring."
    assert doc.long_description == ''
    assert doc.meta[0].arg_name == 'thing1'
    assert doc.meta[0].type_name == 'int'
    assert doc.meta[1].arg_name == 'thing2'
    assert doc.meta[1].type_name == 'int'
    assert str(doc) == doc.__doc__

# Generated at 2022-06-11 21:46:38.047516
# Unit test for function parse
def test_parse():
    doc = """Summary line.
    Description of the function/class/module...

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : float
        Description of arg2.
    arg3 : bool, optional
        Description of arg3 (defaults to True).
    arg4 : bool, optional (see below)
        Description of arg4 (defaults to False).
        blah blah blah.

    Returns
    -------
    str
        Description of the return value.

    Raises
    ------
    Exception
        If an exception is raised.
    """

    expected = Docstring()
    expected.short_description = "Summary line."
    expected.long_description = """Description of the function/class/module..."""