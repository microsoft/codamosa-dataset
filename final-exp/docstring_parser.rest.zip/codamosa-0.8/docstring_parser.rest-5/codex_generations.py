

# Generated at 2022-06-11 21:37:06.678833
# Unit test for function parse
def test_parse():
    import textwrap

    code = """
        This is a short description.

        This is a longer description.
        Some more lines.

        :return: Returns something.
        :type: (dict, list)
    """

    docstring = parse(code)
    assert docstring.short_description == "This is a short description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.long_description == textwrap.dedent(
        """\
        This is a longer description.
        Some more lines."""
    )
    assert docstring.meta == [
        DocstringReturns(
            ['return', '(dict, list)'],
            'Returns something.',
            '(dict, list)',
            False,
        )
    ]


# Generated at 2022-06-11 21:37:18.692650
# Unit test for function parse
def test_parse():
    test_docstring = """\
    Short description
    
    Long description
    
    :param str arg_name: The name of the argument.
    
    :param: The next argument
    :type: Optional[str]
    :returns int: The max value.
    :rtype: int
    """

    docstring = parse(test_docstring)

    assert docstring.short_description == "Short description"
    assert docstring.long_description == "Long description"
    assert len(docstring.meta) == 4
    assert isinstance(docstring.meta[0], DocstringParam)
    assert isinstance(docstring.meta[1], DocstringParam)
    assert isinstance(docstring.meta[2], DocstringReturns)
    assert isinstance(docstring.meta[3], DocstringReturns)

    assert doc

# Generated at 2022-06-11 21:37:29.926403
# Unit test for function parse
def test_parse():
    text = '''
    Short description.

    Long description.

    :param arg1
    :param arg2: Argument 2.
    :param arg3: Argument 3. This is default.
        It has multiple lines
    :param arg4: Argument 4. It has multiple lines
    :param arg5: Argument 5.
        It has multiple lines
    :param arg6: Argument 6. It has multiple lines.
        It has multiple lines.
    :param arg7: Argument 7. It has multiple lines.

        It has multiple lines.
    :param arg8: Argument 8. It has multiple lines.


        It has multiple lines.
    :returns: None
    :yields: None
    :raises: None

    :rtype: None

    '''
    print(parse(text))

# Generated at 2022-06-11 21:37:30.444807
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-11 21:37:36.238348
# Unit test for function parse
def test_parse():
    docstring = """\
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """
    answer = Docstring(
        short_description = "Parse the ReST-style docstring into its components.",
        blank_after_short_description = False,
        blank_after_long_description = True,
        long_description = None,
        meta = [
            DocstringReturns(
                args=['returns'],
                description='parsed docstring',
                type_name=None,
                is_generator=False
            )
        ]
    )
    result = parse(docstring)
    assert result == answer
    


# Generated at 2022-06-11 21:37:41.619066
# Unit test for function parse
def test_parse():
    def foo(x):
        """Short description.

        Long description.

        :param int x: the x parameter
        :returns: the return value
        """
        pass

    foo_parse = parse(foo.__doc__)
    print(foo_parse)

    print(foo_parse.short_description)

    print(foo_parse.long_description)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:37:49.947058
# Unit test for function parse

# Generated at 2022-06-11 21:37:58.049851
# Unit test for function parse
def test_parse():
    """Unit test function for function parse"""
    # Test case: empty docstring
    assert parse("") == Docstring()

    # Test case: no meta
    docstring = Docstring()
    docstring.short_description = "Short description."
    docstring.long_description = "Long description line one.\nLong description line two."
    docstring.blank_after_short_description = False
    docstring.blank_after_long_description = True
    assert parse("Short description.\n\nLong description line one.\nLong description line two.") == docstring

    # Test case: bad meta

# Generated at 2022-06-11 21:38:07.899063
# Unit test for function parse
def test_parse():
    text = '''Create an empty table with a name and a metadata
    :param name: name of the table
    :param meta: metadata of columns of the table
    :returns: a Table object
    '''
    doc = parse(text)
    assert doc.short_description == 'Create an empty table with a name and a metadata'
    assert doc.long_description == None
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ['param', 'name']
    assert doc.meta[0].description == 'name of the table'
    assert doc.meta[1].args == ['returns']
    assert doc.meta[1].description == 'a Table object'


# Generated at 2022-06-11 21:38:19.053404
# Unit test for function parse
def test_parse():
    print("Test parsing ReST docstrings")

# Generated at 2022-06-11 21:38:36.856497
# Unit test for function parse
def test_parse():
    """Make sure the parsing result is correct."""
    # Basic test
    def foo():
        """A simple function.

        :param foo: A parameter named foo.
        :type foo: int
        :returns: None
        :raises Exception: The exception raised.
        """
        pass

    result = parse(foo.__doc__)
    assert result.short_description == "A simple function."
    assert len(result.meta) == 3
    assert result.meta[0].arg_name == "foo"
    assert result.meta[0].type_name == "int"
    assert result.meta[1].type_name is None
    assert result.meta[2].type_name == "Exception"

    # Multi-line parameter

# Generated at 2022-06-11 21:38:47.874367
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    docstr = '''Parse the ReST-style docstring into its components.\n
    :returns: parsed docstring
    :raises ParseError: if the docstring is malformed
    :returns: parsed docstring
    :returns: parsed docstring
    '''
    assert parse(docstr).short_description == "Parse the ReST-style docstring into its components."
    assert len(parse(docstr).meta) == 4
    assert parse(docstr).meta[0].description == "if the docstring is malformed"
    assert parse(docstr).meta[1].description == "parsed docstring"
    assert parse(docstr).meta[3].description == "parsed docstring"

# Generated at 2022-06-11 21:38:49.236756
# Unit test for function parse
def test_parse():
    """
    :return:
    """


# Generated at 2022-06-11 21:38:55.277459
# Unit test for function parse
def test_parse():
    docstring = parse.__doc__
    assert docstring is not None
    assert docstring.short_description == "Parse the ReST-style docstring into its components."
    assert docstring.long_description.startswith("Parse the ReST-style docstring into its")

# Generated at 2022-06-11 21:39:02.286138
# Unit test for function parse
def test_parse():
    """Tests method `parse` in this module."""

# Generated at 2022-06-11 21:39:14.810577
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc(
        """This is a test

        :arg test_arg1: awoid
        :type test_arg1: int
        :arg test_arg2: awoid defaults to 1.
        :type test_arg2: int

        :returns: awoid
        :rtype: int
        :returns: awoid
        :rtype: int
        :returns: awoid
        :rtype: int

        :raises test_arg1: awoid
        :raises test_arg2: awoid
        :raises test_arg3: awoid

        :yields test_arg1: awoid
        :yields test_arg2: awoid
        :yields test_arg3: awoid
        """
    )
    test = parse(docstring)


# Generated at 2022-06-11 21:39:24.867801
# Unit test for function parse
def test_parse():
    text = """
        This is the short description.

        This is the long description.
        It can be of multiple lines.

        :keys1:
            This is the description of keys1.
        :keys2:
            This is the description of keys2.
    """
    doc = parse(text)
    assert doc.short_description == "This is the short description."
    assert doc.long_description == "This is the long description.\nIt can be of multiple lines."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert doc.meta[0] == DocstringMeta(args=['keys1'], description='This is the description of keys1.')

# Generated at 2022-06-11 21:39:37.458326
# Unit test for function parse
def test_parse():
    text = """\
Unit test for function parse.

:param x:

:param y:

:type x: int

:type y: int

:returns: x + y

:rtype: int

:raises ValueError: value error
"""

# Generated at 2022-06-11 21:39:45.608469
# Unit test for function parse
def test_parse():
    text = """\
    A description.

    :param name:        Optional description
    :type name:         str
    :param value:       Optional description
    :type value:        int
    :returns:           Optional description
    :rtype:             list(str)
    :raises Exception:  Optional description
    """
    assert str(parse(text)) == text

# vim: fileencoding=utf-8 et ts=4 sts=4 sw=4 tw=0

# Generated at 2022-06-11 21:39:55.462448
# Unit test for function parse
def test_parse():
    assert(parse("") == Docstring())
    assert(parse("foo") == Docstring(short_description='foo'))
    assert(parse("foo\n") == Docstring(short_description='foo'))
    assert(parse("foo\n\n") == Docstring(short_description='foo', blank_after_short_description=True))
    assert(parse("foo\n \n") == Docstring(short_description='foo', blank_after_short_description=True))
    assert(parse("foo\nbar\n") == Docstring(short_description='foo', long_description='bar'))
    assert(parse("foo\nbar\n \n") == Docstring(short_description='foo', long_description='bar', blank_after_long_description=True))

# Generated at 2022-06-11 21:40:14.670661
# Unit test for function parse
def test_parse():
    docstring = '''\
        This is an example.
        :param x: This is an example.
        :rtype: This is an example.
        :keyword y: This is an example.
        '''

# Generated at 2022-06-11 21:40:19.681210
# Unit test for function parse
def test_parse():
    doc = """
    Prints date

    :param date: date to print
    :type date: int
    :returns: printed date
    :rtype: str

    >>> parse("")
    """
    d = parse(doc)
    assert d.short_description == "Prints date"
    assert d.blank_after_short_description == True
    assert d.blank_after_long_description == True
    assert d.long_description == None
    assert isinstance(d.meta[0], DocstringParam)
    assert d.meta[0].args == ["param", "date", "date"]
    assert d.meta[0].arg_name == "date"
    assert d.meta[0].type_name == "date"
    assert d.meta[0].is_optional == False

# Generated at 2022-06-11 21:40:27.421029
# Unit test for function parse
def test_parse():
    def f():
        """Simple function.

        :param x: integer
        :param y: integer, defaults to 0
        """
        pass


# Generated at 2022-06-11 21:40:36.244164
# Unit test for function parse
def test_parse():
    global parse
    docstring = """
    :param arg1: This is a first argument
    :type arg1: dict
    :param arg2: This is a second argument
    :type arg2: str.
    :param arg3: This is a third argument.
    :type arg3: str. defaults to "default".
    :raises TypeError: if arg3 and arg4 are both specified
    :yields arg4: This is a fourth argument
    :return: This is a return value of the function.
    :rtype: dict
    """
    print("\n", docstring)
    parse(docstring)
# test_parse()


# Generated at 2022-06-11 21:40:43.655802
# Unit test for function parse
def test_parse():
    docstring = parse("""\
    Hello

    arg: arg_name: arg_type

    returns: type

    raises: type

    yields: type

    Other
    """)

    assert docstring.short_description == "Hello"
    assert docstring.blank_after_short_description == False
    assert docstring.long_description == "Other"
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].keyword == "arg"



# Generated at 2022-06-11 21:40:53.916442
# Unit test for function parse
def test_parse():
    docstring = """Single-line short description.

Single-line long description.

    :param foo: Description of foo.
    :type foo: str
    :param bar: Description of bar.
    :param baz: Description of baz.
    """

# Generated at 2022-06-11 21:41:02.368312
# Unit test for function parse
def test_parse():
    docstring = """A short description.

:param x: an int var.
:param y: a float var.
:param z: a bool var.
:returns: bool.
    """
    result = parse(docstring)
    assert result.meta[0].arg_name == 'x'
    assert result.meta[0].type_name == 'int'
    assert result.meta[1].arg_name == 'y'
    assert result.meta[1].type_name == 'float'
    assert result.meta[2].arg_name == 'z'
    assert result.meta[2].type_name == 'bool'
    assert result.meta[3].type_name == 'bool'

# Generated at 2022-06-11 21:41:13.224571
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring for get_files.

    :param path: The path to the directory
    :type path: str
    :param extensions: The extensions of the files to get
    :type extensions: list

    This is a long description.

    :rtype: list
    :returns: The list of files
    """

# Generated at 2022-06-11 21:41:23.959317
# Unit test for function parse
def test_parse():
    doc = "Short description.\n\nLong description.\n\n:param arg: arg description.\n:returns: return description."
    assert parse(doc).short_description == 'Short description.'
    assert parse(doc).long_description == 'Long description.'
    assert parse(doc).meta[0].arg_name == 'arg'
    assert parse(doc).meta[0].description == 'arg description.'
    assert parse(doc).meta[0].key == 'param'
    assert parse(doc).meta[0].type_name is None
    assert parse(doc).meta[0].is_optional is None
    assert parse(doc).meta[1].key == 'returns'
    assert parse(doc).meta[1].description == 'return description.'
    assert parse(doc).meta[1].type_name is None
   

# Generated at 2022-06-11 21:41:32.599190
# Unit test for function parse
def test_parse():
    # :param str username: the user's name
    assert parse(':param str username: the user\'s name\n')
    # :returns: the result
    assert parse(':returns: the result\n')
    # :raises Exception: if an error occurred
    assert parse(':raises Exception: if an error occurred\n')
    # :rtype: list
    assert parse(':rtype: list\n')
    # :yields: a value
    assert parse(':yields: a value\n')
    # :type username: str
    assert parse(':type username: str\n')

# Generated at 2022-06-11 21:41:52.369986
# Unit test for function parse

# Generated at 2022-06-11 21:42:02.808057
# Unit test for function parse
def test_parse():
    """Test helper for parse."""
    docstring = """Summary line.

This is a long description.

Params:
    foo: description for foo
    bar (string): description for bar
    baz (int): description for baz, defaults to 42
    qux (int, optional): description for qux, defaults to None
    zoop (string?, optional): description for zoop, defaults to 'yes'

Yields:
    int: next fibonacci number

Raises:
    ValueError: sometimes

Note:
    This is a note.

See Also:
    Something else
"""
    d = parse(docstring)
    assert d.short_description == "Summary line."
    assert d.long_description  == "This is a long description."
    assert d.blank_after_short_description

# Generated at 2022-06-11 21:42:11.021962
# Unit test for function parse
def test_parse():
    class Test:
        """
        This is the short description.

        This is the long description.
        It includes a link, :py:class:`module.package.name`.

        :param url: URL of web page
        :type url: str
        :param encoding: encoding of page
        :type encoding: str, defaults to utf-8.
        :param get: Retrieve page data
        :type get: bool, defaults to False.

        :returns: str
        """

        def __init__(self, url, encoding="utf-8", get=False):
            pass

    text = inspect.getdoc(Test)
    docstring = parse(text)
    assert docstring.short_description == "This is the short description."
    assert docstring.blank_after_short_description == True
    assert docstring.long_

# Generated at 2022-06-11 21:42:21.505565
# Unit test for function parse
def test_parse():
    text = """\
        Converts a string to a float.

        :param str value: The string to be converted.
        :param str format: The format of the input string (default 'f').

        :returns: The float representation of value.
        :raises ValueError: If the string is not a valid float.
    """
    expected = """\
        Converts a string to a float.

        :param str value: The string to be converted.
        :param str format: The format of the input string (default 'f').

        :returns: The float representation of value.
        :raises ValueError: If the string is not a valid float.
    """
    result = str(parse(text))
    assert result == expected



# Generated at 2022-06-11 21:42:30.777947
# Unit test for function parse
def test_parse():
    text1 = """\
        """
    text2 = """\
        This is the short description.

        This is the long description.
        """
    text3 = """\
        One arg.

        :param arg: the name of the arg.
        :type arg: str
        """
    text4 = """\
        Two args.

        :param arg_one: the name of the first argument.
        :type arg_one: str
        :param arg_two: the name of the second argument.
        :type arg_two: int, required
        """
    text5 = """\
        Yields a value.

        :yields: a value
        :yields type: int
        :raises ValueError: if no value is yielded
        :raises: ValueError
        """

# Generated at 2022-06-11 21:42:39.823620
# Unit test for function parse
def test_parse():
    """Unit tests."""

    docstring = """
        Short description.

        Long description.

        :param foo: Description for foo.
        :type foo: int
        :param bar: Description for bar.
        :type bar: int, optional
        :returns: Description of return value.
        :rtype: int
        :raises ValueError: Description of exception.
    """

    ret = parse(docstring)

    assert ret.short_description == "Short description."
    assert ret.long_description == "Long description."
    assert ret.blank_after_short_description
    assert ret.blank_after_long_description

    assert len(ret.meta) == 4

# Generated at 2022-06-11 21:42:44.513750
# Unit test for function parse
def test_parse():
    docstring = """
    short description.
        long description.
        :param str name:
        :param int id:
        :return: a string
        :rtype: str
    """
    result = parse(docstring)
    print(result)

# test_parse()

# Generated at 2022-06-11 21:42:51.240880
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse(":one: Two.") == Docstring(
        short_description="",
        meta=[DocstringMeta(args=["one"], description="Two.")]
    )
    assert parse("One.") == Docstring(
        short_description="One.",
        meta=[],
    )
    assert parse("One.\n\nTwo.") == Docstring(
        short_description="One.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="Two.",
        meta=[],
    )

# Generated at 2022-06-11 21:42:56.639094
# Unit test for function parse
def test_parse():
    result = parse.__doc__
    meta = parse(result)
    print(result)
    print(meta)
    print(meta.params[0].type_name)
    print(meta.params[0].arg_name)
    print(meta.params[0].description)
    print(meta.params[0].default)
    assert meta.short_description == "Parse the ReST-style docstring into its components."



# Generated at 2022-06-11 21:43:07.813500
# Unit test for function parse
def test_parse():
    docstring = """Test docstring
    
    :param a: Parameter A
    :type a: str
    :param b: Parameter B
    :type b: int
    :returns: nothing
    """
    docstring_obj = parse(docstring)
    print(docstring_obj.long_description)
    print(docstring_obj.short_description)
    for meta in docstring_obj.meta:
        print(meta)
    for param in docstring_obj.params:
        print(param)
    for param in docstring_obj.returns:
        print(param)
    for param in docstring_obj.yields:
        print(param)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:43:28.104748
# Unit test for function parse
def test_parse():  # noqa: D103
    docstring = """
    The function parses a docstring into its components.

    This is the short description.

    This is the long description.

    :param x: The first parameter.
    :param y: The second parameter.
    :returns: The return value.
    :raises RuntimeError: If an error occurred.

    :arg z: The third parameter.
    :returns: The return value.
    :raises RuntimeError: If an error occurred.

    Extra stuff.
    """
    ret = parse(docstring)

    assert ret.short_description == "The function parses a docstring into its components."
    assert (
        ret.long_description
        == "This is the long description.\n\nExtra stuff."
    )
    assert ret.blank_after_short_description


# Generated at 2022-06-11 21:43:41.341714
# Unit test for function parse
def test_parse():
    d = Docstring()
    d.short_description = "THIS IS A SHORT DESCRIPTION"
    d.long_description = "this is a long description"
    d.blank_after_short_description = True
    d.blank_after_long_description = True
    d.meta.append(DocstringMeta(["m1"], "meta1"))
    d.meta.append(DocstringMeta(["m2"], "meta2"))
    d.meta.append(DocstringParam(["param", "str", "a"], "param a"))
    d.meta.append(DocstringRaises(["raises", "ValueError"], "raised with error"))
    d.meta.append(DocstringReturns(["return", "int"], "returned int"))


# Generated at 2022-06-11 21:43:53.783225
# Unit test for function parse
def test_parse():
    from .mypy import MyPyDocstring, MyPyDocstringParam
    docstring = parse(
    """
    Test

    :param foo:
    :type foo: str
    :param bar:
    :type bar: str
    :param baz:
    :type baz: str
    """
    )

# Generated at 2022-06-11 21:44:06.617309
# Unit test for function parse
def test_parse():
    # this is a multi-line docstring
    # which will be parsed as such
    # """
    # :param a:
    # :param b:
    # :returns c:
    # """
    def myFunction(a, b):
        return c
    # this is how we will call our function
    text = myFunction.__doc__
    # this is how we will validate our output
    input = [
        "this is a multi-line docstring",
        "which will be parsed as such",
        "",
        "",
        "param a:",
        "param b:",
        "returns c:",
        "",
        "",
    ]
    output = [text, input]
    # this is how we will call our function
    assert parse(text) == output
    # this is how we

# Generated at 2022-06-11 21:44:11.727940
# Unit test for function parse
def test_parse():
	docstring = """
		Short description.

		Long description.

		:param type arg_name: description
		:returns int: description
	"""
	d = parse(docstring)
	assert d.short_description == "Short description."
	assert d.long_description == "Long description."
	assert d.meta[0].description == "description"
	assert d.meta[0].arg_name == "arg_name"

# Generated at 2022-06-11 21:44:22.051249
# Unit test for function parse
def test_parse():
  docstring = """
Calculates the cdf of a Beta random variable.

:param float x: input
:param float a: alpha parameter
:param float b: beta parameter
:returns: cdf of Beta random variable
"""
  assert parse(docstring).short_description == "Calculates the cdf of a Beta random variable."
  assert parse(docstring).long_description == None
  assert parse(docstring).blank_after_short_description
  assert not parse(docstring).blank_after_long_description
  assert len(parse(docstring).meta) == 1
  assert isinstance(parse(docstring).meta[0], DocstringParam)
  assert parse(docstring).meta[0].descripton == "cdf of Beta random variable"

# Generated at 2022-06-11 21:44:31.608626
# Unit test for function parse

# Generated at 2022-06-11 21:44:41.715895
# Unit test for function parse
def test_parse():
    text1 = '''
    Docstring of parse function.

    :type var1: int
    :param var1: Description of var1

    :returns: Description of return.
    '''
    assert parse(text1).short_description == 'Docstring of parse function.'
    assert parse(text1).long_description == (
        'type var1: int\n' +
        'param var1: Description of var1\n'
        'returns: Description of return.'
    )
    assert parse(text1).blank_after_short_description == True
    assert parse(text1).blank_after_long_description == False
    assert parse(text1).meta[0].args == ['type']
    assert parse(text1).meta[0].arg_name == 'var1'

# Generated at 2022-06-11 21:44:52.517659
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    # Test for function
    doc_string = """Module-level variables:
    Variable1 : variable1 description
    Variable2 : variable2 description
    Variable3 : variable3 description"""
    ret = parse(doc_string)
    assert isinstance(ret, Docstring)
    assert ret.short_description == 'Module-level variables:'
    assert ret.long_description == 'Variable1 : variable1 description\nVariable2 : variable2 description\nVariable3 : variable3 description'

    # Test for function
    doc_string = """Function1 : function1 description
    :param arg1: arg1 description
    :param arg2: arg2 description
    :returns: return description
    :raises error: raise description
    """
    ret = parse(doc_string)
    assert isinstance(ret, Docstring)

# Generated at 2022-06-11 21:45:03.694001
# Unit test for function parse
def test_parse():
    import yaml
    b = """
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """
    a = Docstring()
    a.short_description = 'Parse the ReST-style docstring into its components.'
    a.blank_after_short_description = True
    a.blank_after_long_description = False
    a.long_description = 'parsed docstring'
    a.meta = [DocstringReturns(args = ['returns'], description = 'parsed docstring', type_name = None, is_generator = False)]
    assert a == parse(b)

# Generated at 2022-06-11 21:45:25.218497
# Unit test for function parse
def test_parse():
    """Test ReST-style docstring parsing."""

# Generated at 2022-06-11 21:45:32.517494
# Unit test for function parse

# Generated at 2022-06-11 21:45:41.290962
# Unit test for function parse
def test_parse():
    """Goes through the parse function and makes sure the string is parsed 
    the way expected.
    """

    # Test that a string with no docstring returns a Docstring object with
    # no description and no metadata
    test_string = ""
    parsed_doc_string = parse(test_string)
    assert parsed_doc_string.short_description == None
    assert parsed_doc_string.blank_after_short_description == None
    assert parsed_doc_string.blank_after_long_description == None
    assert parsed_doc_string.long_description == None
    assert parsed_doc_string.meta == []

    # Test that a string with only whitespace returns a Docstring object with
    # no description and no metadata
    test_string = "\n"
    parsed_doc_string = parse(test_string)
    assert parsed

# Generated at 2022-06-11 21:45:51.390589
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

# Generated at 2022-06-11 21:46:02.534853
# Unit test for function parse
def test_parse():
    # simple case
    s = inspect.cleandoc("""
        This is a test.

        This is a longer description.
        """)
    assert (parse(s) ==
            Docstring(
                short_description="This is a test.",
                long_description="This is a longer description.",
                blank_after_short_description=True,
                blank_after_long_description=False,
            ))

    # no blank after short desc, no long desc
    s = inspect.cleandoc("""
        This is a test.""")
    assert (parse(s) ==
            Docstring(
                short_description="This is a test.",
                long_description=None,
                blank_after_short_description=False,
                blank_after_long_description=None,
            ))

    # no short desc, no long desc

# Generated at 2022-06-11 21:46:14.605710
# Unit test for function parse
def test_parse():
    '''
    This function tests the class function parse.
    '''

    text = """
    Short description.

    Long description.

    First paragraph of long description.

    Second paragraph of long description.

    :param int param1: The first parameter.
    :param str param2: The second parameter.
    :param param3: The third one.
    :type param3: int
    :param int? param4: Blah.
    :param: The fifth one.
    :returns: Nothing.
    :rtype: None
    :raises ExceptionType: Why the exception is raised.

    More stuff.

    """

# Generated at 2022-06-11 21:46:20.562217
# Unit test for function parse
def test_parse():
    docstring = '''\
Operations with the keyboard.

:param key: string or keyboard keys.
:type key: `str`, `KeyboardKey`, `KeySequence`
:param modifiers: modifier keys.
:type modifiers: `list` of `KeyboardModifier`
:param key_down: `True` for to press the key down, `False` for to release it.
:type key_down: `bool`
:param presses: number of times to press the key.
:type presses: `int`
:param interval: number of seconds between key presses.
:type interval: `float`
'''
    parsed_docstring = parse(docstring)

# Generated at 2022-06-11 21:46:31.904545
# Unit test for function parse
def test_parse():
    assert parse("A docstring.") == Docstring(
        short_description="A docstring.",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("A docstring.\n\nWith some details.") == Docstring(
        short_description="A docstring.",
        long_description="With some details.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[],
    )


# Generated at 2022-06-11 21:46:41.173858
# Unit test for function parse
def test_parse():
    import mock
    import unittest
    
    # Test with an empty string
    test_function = mock.Mock()
    test_function.__doc__ = ""
    d = parse(test_function.__doc__)
    assert d.short_description == None
    assert d.long_description == None
    assert d.meta == []
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    
    # Test with only a short description
    test_function.__doc__ = "Short description"
    d = parse(test_function.__doc__)
    assert d.short_description == "Short description"
    assert d.long_description == None
    assert d.meta == []
    assert d.blank_after_short_description == False
    assert d