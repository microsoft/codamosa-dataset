

# Generated at 2022-06-11 21:37:08.900984
# Unit test for function parse

# Generated at 2022-06-11 21:37:11.558382
# Unit test for function parse
def test_parse():
    doc = """\
    Read a list of integers from a text file.

    Parameters
    ----------
    path: str
        Path of the file.

    Raises
    ------
    FileNotFoundError
        If file not found.

    Returns
    -------
    list
        List of int.
    """

    assert parse(doc)
    return True

# Generated at 2022-06-11 21:37:20.940421
# Unit test for function parse
def test_parse():
    # Test if parse function works on all docstrings
    from . import introspection

    # Test how it parses it back and forth
    obj = introspection.lookup("")
    meta = introspection.build(obj, force_type_comments=True)
    doc = introspection.build_docstring(meta, obj)
    print(meta)
    print("------------------------------")
    print(doc)
    print("------------------------------")
    parsed = parse(doc)

    # Test that parsed results are identical
    assert meta == parsed
    print("+++++++++++++++++++++++++++++++")
    print("Identical!")
    print("+++++++++++++++++++++++++++++++")


# Test the parse function
test_parse()

# Generated at 2022-06-11 21:37:31.144123
# Unit test for function parse
def test_parse():
    '''Test Parse Function'''
    text1 = inspect.cleandoc('''
    This is a test
    ''')
    print("\nText 1:\n" + text1)
    # test1 = parse(text1)
    # print("\nTest 1:\n" + str(test1))
    # print("\nTest 1 Metas:\n" + str(test1.meta))

    text2 = inspect.cleandoc('''
    This is a test with a param
    :param x:
    ''')
    print("\nText 2:\n" + text2)
    test2 = parse(text2)
    print("\nTest 2:\n" + str(test2))
    print("\nTest 2 Metas:\n" + str(test2.meta))

    text3

# Generated at 2022-06-11 21:37:37.164569
# Unit test for function parse
def test_parse():
    func_text = """
    Function to test parse
    Parameters
    ----------
    x : float
        Explanation of parameter x
    y : float
        Explanation of parameter x
    Returns
    -------
    float
        Result of x to the power y
    """
    d = parse(func_text)

    assert (
        d.short_description == "Function to test parse"
    ), "Short Description of parse incorrect"
    assert (
        d.long_description == "Explanation of parameter x\nExplanation of parameter x"
    ), "Long Description of parse incorrect"

    assert len(d.meta) == 2
    assert isinstance(d.meta[0], DocstringParam)
    assert d.meta[0].key == "Parameters"
    assert d.meta[0].args == ["x", "float"]


# Generated at 2022-06-11 21:37:47.717058
# Unit test for function parse
def test_parse():
    my_str = """
    My function

    Keyword arguments:
    arg -- some arg
    arg1 -- some arg
    arg2 -- some arg

    :param arg0: some arg
    :param type arg1: some arg

    Returns:
    str -- returns some string

    :returns: some string
    :rtype: str

    :raises ValueError: if some error
    :type str: if some error

    """


# Generated at 2022-06-11 21:37:50.562875
# Unit test for function parse
def test_parse():
    doc = """
    Single line docstring.
    :param int val: Value to square.
    """
    o = parse(doc)
    print(o)



# Generated at 2022-06-11 21:37:58.439909
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    ret = parse(
        """\
    Test parsing ReST-style docstrings.

    This is a longer description.

    :arg size: This is a parameter description.
       Defaults to "small".
    :param type str snowman: This is another param description.
    :returns: This is a return description.
    :rtype: int
    :raises KeyError: This is an exception description.
    :yields: This is a generator description.
    :yields type: str
    :param type int: This is a param description.
       Defaults to "small".
    """
    )
    assert ret.short_description == "Test parsing ReST-style docstrings."
    assert ret.long_description == "This is a longer description."
    assert ret.blank_after_

# Generated at 2022-06-11 21:38:08.201774
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.
    Long description.

    :param int num: Number
    :param float num2: Number 2
    """
    result = parse(docstring)
    assert result.short_description == "Short description."
    assert result.long_description == "Long description."
    assert len(result.meta) == 2
    assert result.meta[0].key == "param"
    assert result.meta[0].args == ["param", "int", "num"]
    assert result.meta[0].type_name == "int"

    assert result.meta[1].key == "param"
    assert result.meta[1].args == ["param", "float", "num2"]
    assert result.meta[1].type_name == "float"


# Generated at 2022-06-11 21:38:19.307091
# Unit test for function parse
def test_parse():
    doc = """
        Returns the sum of two numbers.

        >>> assert add(1, 1) == 2

        :param a: The first number.
        :param b: The second number.
        :type a: int
        :type b: int
        :returns: The sum of the parameters.
        :rtype: int
    """
    docstring = parse(doc)
    assert docstring.short_description == "Returns the sum of two numbers."
    assert docstring.long_description == """\
        >>> assert add(1, 1) == 2"""
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    assert docstring.meta[1].arg_name == "a"
    assert docstring.meta[1].description

# Generated at 2022-06-11 21:38:36.353386
# Unit test for function parse
def test_parse():
    docstring = """Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """
    docstring_dict = parse(docstring)
    assert docstring_dict.short_description == "Parse the ReST-style docstring into its components."
    assert docstring_dict.blank_after_short_description == True
    assert docstring_dict.long_description == "returns: parsed docstring"
    assert docstring_dict.blank_after_long_description == False
    assert docstring_dict.meta == [DocstringReturns(args=['returns'], description='parsed docstring', type_name=None, is_generator=False)]


# Generated at 2022-06-11 21:38:47.743125
# Unit test for function parse
def test_parse():
    docstring = """
First line of short description.

First line of long description.

Continued second line of long description.
"""
    doc = parse(docstring)
    assert doc.short_description == "First line of short description."
    assert doc.long_description == (
        "First line of long description.\n\nContinued second line of long "
        "description."
    )
    assert doc.blank_after_long_description is True
    assert doc.blank_after_short_description is False
    assert len(doc.meta) == 0


# Generated at 2022-06-11 21:39:00.605764
# Unit test for function parse
def test_parse():
    doc = """\
    This function does something.

    :param number: a number
    :type number: int, float
    :param another_number: another number
    :type another_number: float
    :returns: the absolute value of number
    :rtype: float

    """


# Generated at 2022-06-11 21:39:12.689608
# Unit test for function parse
def test_parse():
    """

    :param text:
    :return:
    """

# Generated at 2022-06-11 21:39:18.370916
# Unit test for function parse
def test_parse():
    print("Testing parse")
    f = open("tests/testcases/parse_testcases.txt", "r")
    while True:
        line = f.readline()
        if not line:
            break
        expected = f.readline().rstrip("\n")
        print("Testing: " + line.rstrip("\n") + "Expected: " + expected)
        assert expected == str(parse(line)), "Failed. Expected: " + expected + " but got " + str(parse(line))

test_parse()

# Generated at 2022-06-11 21:39:26.180262
# Unit test for function parse
def test_parse():
    assert(parse("") == Docstring())
    assert(parse("a") == Docstring(short_description="a"))
    assert(parse("a\nb\n") == Docstring(short_description="a", long_description="b"))
    assert(parse("a\n\nb\n") == Docstring(short_description="a", long_description="b"))
    assert(parse("a\n\nb\n\n") == Docstring(short_description="a", long_description="b"))
    assert(parse("a\nb\n\n") == Docstring(short_description="a", long_description="b"))
    assert(parse("a\n:b c\n") == Docstring(short_description="a", meta=[DocstringMeta(args=["b", "c"], description="")]))

# Generated at 2022-06-11 21:39:36.545629
# Unit test for function parse
def test_parse():
    ds = parse(
        """Parses a ReST-style docstring into its components.

    :returns: parsed docstring
    :rtype: dict
    :raises ParserError: if the line is invalid
    """
    )
    assert ds.short_description == "Parses a ReST-style docstring into its components."
    assert isinstance(ds.meta[0], DocstringReturns)
    assert isinstance(ds.meta[1], DocstringRaises)
    assert ds.meta[0].args == ["returns", "dict"]
    assert ds.meta[1].args == ["raises", "ParserError"]



# Generated at 2022-06-11 21:39:48.442495
# Unit test for function parse

# Generated at 2022-06-11 21:39:57.505674
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Parse the ReST-style docstring into its components.

    :param text:  docstring
    :type text: str
    :param key:
    :param key2:
    :raises ValueError:
    :raises KeyError:
    :returns:
    :rtype: string
    """

    d = parse(docstring)
    print(d.short_description)
    print(d.long_description)
    print(d.meta[0].args)
    print(d.meta[0].description)
    print(d.meta[1].args)
    print(d.meta[1].description)
    print(d.meta[2].args)
    print(d.meta[2].description)
    print(d.meta[3].args)

# Generated at 2022-06-11 21:40:06.884086
# Unit test for function parse
def test_parse():
    text = """
        Function that does something

        :param arg1: This is arg1
        :type arg1:  int
        :param arg2: This is arg2
        :type arg2:  int
        :returns:    This is the return
        :rtype:      int
    """.strip()
    doc = parse(text)
    assert doc.short_description == "Function that does something"
    assert doc.long_description == "This is arg1\nThis is arg2\nThis is the return"
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is True
    assert doc.meta[0].args == ["param", "arg1", "arg2"]
    assert doc.meta[0].description == "This is arg1\nThis is arg2"


# Generated at 2022-06-11 21:40:17.004240
# Unit test for function parse
def test_parse():
    docstring = parse.__doc__
    print(docstring)
    # print(parse(docstring))

# Generated at 2022-06-11 21:40:25.934704
# Unit test for function parse

# Generated at 2022-06-11 21:40:30.776142
# Unit test for function parse
def test_parse():
    assert inspect.cleandoc(
        """
    header

    line1
    line2

    returns type_name:
    description
    """
    ) == parse(
        """
    header

    line1
    line2

    :returns type_name: description
    """
    ).docstring



# Generated at 2022-06-11 21:40:38.624947
# Unit test for function parse
def test_parse():
    docstring_to_parse = """Unit test function.

    This function is used to perform unit tests on function parse().

    :param arg1: The first argument.
    :type arg1: str
    :param arg2: The second argument.
    :type arg2: bool, optional
    :raises AttributeError: The ``Raises`` section is a list of all exceptions
        that are relevant to the interface.
    :returns: Output of function
    :rtype: str
    """
    assert parse(docstring_to_parse).short_description == "Unit test function."
    assert (
        parse(docstring_to_parse).long_description
        == """This function is used to perform unit tests on function parse().
    """
    )
    docstring_parsed = parse(docstring_to_parse)

# Generated at 2022-06-11 21:40:45.461408
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.  First line.

    Second line.

    :param arg1: <description>
    :type arg1: <type>
    :param arg2: <description>
    :type arg2: <type>
    :return: <description>
    :rtype: <type>
    :raises ValueError: if <something>
    """
    print(docstring)
    parsed = parse(docstring)
    print(parsed)

# Generated at 2022-06-11 21:40:54.482969
# Unit test for function parse

# Generated at 2022-06-11 21:41:01.529885
# Unit test for function parse
def test_parse():
    """Unit test for function parse

    testing
    """
    def add(num1: "First number", num2: "Second number", return_num: "Returned number" = None) -> "None":
        """Add two numbers

        :param num1: First number
        :param num2: Second number
        :param return_num: Returned number
        :returns: None
        """
        return None
    d = parse(add.__doc__)
    print(d)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:41:11.141401
# Unit test for function parse
def test_parse():
    """Test docstring"""
    docstring = """
    Example docstring.

    This can be a longer description
    consisting of multiple paragraphs.

    :param arg1: Description of arg1
    :type arg1: str
    :param arg2: Description of arg2
    :type arg2: int, optional
    :returns: Description of return value
    :rtype: str
    """

    parsed_docstring = parse(docstring)

    assert parsed_docstring.short_description == "Example docstring."
    assert parsed_docstring.long_description == """\
This can be a longer description
consisting of multiple paragraphs.
"""
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_docstring.blank_after_long_description == True

    assert parsed_docstring.meta[0].args

# Generated at 2022-06-11 21:41:17.850085
# Unit test for function parse

# Generated at 2022-06-11 21:41:23.764959
# Unit test for function parse
def test_parse():
    assert len(parse("Sums two numbers")) == 0
    assert len(parse("Sums two numbers:\n\n:param a: first arg").meta) == 1
    assert len(parse("Sums two numbers:\n\n:param a: first arg\n:returns: ").meta) == 2
    assert len(parse("Sums two numbers:\n\n:param a: first arg\n:returns: \n:param c: second arg").meta) == 3

# Generated at 2022-06-11 21:41:39.737856
# Unit test for function parse
def test_parse():

    # Test 1
    test_text = '''This function modifies the input array.
    :param list nums: list of integers.
    :returns: None
    '''
    res = parse(test_text)
    # print('Test 1: \n', res.short_description)
    # print('Test 1: \n', res.long_description)
    # print('Test 1: \n', res.blank_after_short_description)
    # print('Test 1: \n', res.blank_after_long_description)
    # print('Test 1: \n', res.meta)

    # Test 2
    test_text = '''This function modifies the input array.

    :param list nums: list of integers.
    :returns: None
    '''
    res = parse(test_text)


# Generated at 2022-06-11 21:41:49.579387
# Unit test for function parse
def test_parse():
    docstring = parse(
        r'"""\n'
        r'Symmetric binary relation.\n'
        r'\n'
        r'If the relation is symmetric, returns ``True``.\n'
        r'\n'
        r':param relation: binary relation\n'
        r':type relation: callable\n'
        r':returns: ``True`` if the relation is symmetric else ``False``\n'
        r':rtype: bool\n'
        r'"""\n'
    )

# Generated at 2022-06-11 21:42:00.350542
# Unit test for function parse
def test_parse():
    text1 = "blah blah\n\nFirst line of long description.\n\n:param str arg1: this is arg1\n:type arg1: str\n:param arg2: this is arg2\n:type arg2: str\n:returns: None\n:rtype: None\n:raises keyError:\n    for for fun.\n:raises keyError:\n    for for fun."
    result1 = parse(text1)
    param1 = result1.meta[0]
    param2 = result1.meta[1]
    param3 = result1.meta[2]
    param4 = result1.meta[3]
    assert param1.arg_name == "arg1"
    assert param1.type_name == "str"

# Generated at 2022-06-11 21:42:11.530687
# Unit test for function parse
def test_parse():
    s = """
    :param int x: foo.
    :param str? y: bar.
    :param z: baz.
    :returns: retval.
    :raises ValueError: If a value error occurs.
    :raises ImportError: import.

    Short description.

    Long description.
    """
    docstring = parse(s)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 7
    assert docstring.meta[0].args == ["param", "int", "x"]
    assert docstring.meta[0].description == "foo."

# Generated at 2022-06-11 21:42:22.387229
# Unit test for function parse
def test_parse():
    doc1 = """
    some kind of docstring
    """
    assert parse(doc1) == Docstring(
        short_description="some kind of docstring",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    doc2 = """
    some kind of docstring

    a paragraph

    another paragraph
    """
    assert parse(doc2) == Docstring(
        short_description="some kind of docstring",
        long_description="a paragraph\n\nanother paragraph",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-11 21:42:28.689529
# Unit test for function parse
def test_parse():
    full_docstring = """
        Short description.

        Long description.

        :param arg1: Description of arg1.
        :arg1 type: str
        :param arg2: Description of arg2.
        :param arg3: Description of arg3.
        :arg3 type: int
        :param arg4: Description of arg4.
        :arg4 type: str
        :returns: Description of return value.
        :returns type: str
        :raises TypeError: If bad things happen.
    """
    assert parse(full_docstring)

# Generated at 2022-06-11 21:42:38.571783
# Unit test for function parse
def test_parse():

    text = """\
doc for class

:param int x: This is the x.
:param str y: This is the y.
:param list[int] z: This is the z.
:param list[int]? u: This is the u?.
:param dict[str,str] v: This is the v.
:param dict[str,str]? w: This is the w?.
:param dict[str,str]* x: This is the x*.
:rtype: int
:rtype: str
:rtype: list[int]
:returns int: This is the return.
:yields int: This is the yield.
:raises ValueError: This is the value error.
:raises RuntimeError: This is the runtime error.
    """

    print(parse(text))


# Generated at 2022-06-11 21:42:49.286135
# Unit test for function parse
def test_parse():
    def func1(test_arg1, test_arg2: '2nd arg', *test_arg3, **test_arg4):
        """A ReST-style docstring."""

    def func2(a, b):
        """
        A ReST-style docstring.
        """

    assert parse('') == \
        Docstring(short_description=None,
                  long_description=None,
                  blank_after_short_description=None,
                  blank_after_long_description=None,
                  meta=[])

# Generated at 2022-06-11 21:42:55.409398
# Unit test for function parse
def test_parse():
    docstring = """\
    Function to get the current betting round.

    :returns: the betting round
    """
    print(parse(docstring))
    # expected output: Docstring(short_description='Function to get the current betting round.', long_description=None, meta=[DocstringMeta(args=['returns'], description='the betting round')])


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:43:06.734300
# Unit test for function parse
def test_parse():
    docstring = '''
    This is the docstring.

  :param str foo: This is foo.
  :param int bar: This is bar.
  :param bool some_bool: This is some bool.
  :returns: This is the return line.
  :rtype: str
    '''
    doc = Docstring.parse(docstring)
    assert isinstance(doc, Docstring)

# Generated at 2022-06-11 21:43:19.450470
# Unit test for function parse
def test_parse():
    # test with non-empty docstring
    doc = parse('''
AUTHOR
    Rafael
DESCRIPTION
    This function is useful for counting the number of 
    characters in an ASCII string.
Inputs
    text: string
        Text itself.
Outputs
    length: int
        Number of characters in text
''')
    print(doc.short_description)
    print(doc.long_description)
    print(doc.meta)
    
    

# Generated at 2022-06-11 21:43:28.730162
# Unit test for function parse
def test_parse():
    import pytest
    
    # Docstring with no metadata
    text = """
    This is a docstring
    """
    actual = parse(text)
    expected = Docstring(
        short_description='This is a docstring',
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None
    )
    assert actual == expected

    # Docstring with no metadata and trailing newlines
    text = """
    This is a docstring
    """
    actual = parse(text)
    expected = Docstring(
        short_description='This is a docstring',
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None
    )
    assert actual == expected

    # Docstring with no metadata and

# Generated at 2022-06-11 21:43:38.376945
# Unit test for function parse
def test_parse():
    docstring = """
    This is the first line.

    This is the second line.

    :Example:

    :Args:

    :Returns:
    Blah blah blah.
    """
    result = parse(docstring)
    assert result.short_description == 'This is the first line.'
    assert result.long_description == 'This is the second line.'
    assert result.meta[0].description == 'Blah blah blah.'
    assert result.meta[0].args[0] == 'Returns'
    assert result.meta[0].args[1:] == []

# Generated at 2022-06-11 21:43:44.852215
# Unit test for function parse
def test_parse():
    def get_test_strings():
        yield (
            "Short description\nLong description\n\n:t1: d1\n\n:t2: d2\n\n"
            ":t3 d3: d3\n:t4 d4 d4.1: d4\n:t5 d5 d5.1 d5.2: d5\n"
        )
        yield ""
        yield "Short description."
        yield "Short description\n\nLong description."
        yield ": t1: d1."
        yield "Short description\n\nLong description.\n\n: t2: d2."
        yield ": t3 d3: d3."
        yield ": t4 d4 d4.1: d4."

# Generated at 2022-06-11 21:43:56.269851
# Unit test for function parse
def test_parse():
    text = '''
    Short description.

    Long description.

    :param arg1:
    :param arg2: Descriptive text.
        Descriptive text continued.
    :type arg2:
    '''
    parsed = parse(text)
    assert parsed.short_description == "Short description."
    assert parsed.blank_after_short_description == False
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_long_description == True
    assert len(parsed.meta) == 2
    assert isinstance(parsed.meta[0], DocstringParam)
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[1].arg_name == "arg2"

# Generated at 2022-06-11 21:44:06.916312
# Unit test for function parse
def test_parse():
    # Asserts that the docstring is parsed as expected
    test_doc_string = '''
    Short description.

    Long description.

    :param arg1: argument1
    :type arg1: str
    :param arg2: argument2
    :type arg2: list
    :param arg3: argument3
    :type arg3: int, default to 2
    :raises: Exception, if ...
    :yields: int, the next ...
    :yields: str, the next ...
    :return: int, the return value
    '''
    parsed_doc_string = parse(test_doc_string)
    import pprint
    pprint.pprint(parsed_doc_string)

# Generated at 2022-06-11 21:44:15.260534
# Unit test for function parse
def test_parse():
    # Test basic function
    assert parse("\n") == Docstring()

    # Test short description and description
    assert parse("This is a short description.") == Docstring(
        short_description="This is a short description.",
        long_description=None,
        blank_after_long_description=False,
        blank_after_short_description=False,
        meta=[],
    )
    assert parse("This is a short description.\n\nThis is a long description.") == Docstring(
        short_description="This is a short description.",
        long_description="This is a long description.",
        blank_after_long_description=False,
        blank_after_short_description=False,
        meta=[],
    )

# Generated at 2022-06-11 21:44:24.356037
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    example_docstring = """This function adds two numbers.

:param int arg1: The first number. Defaults to 1.
:param int arg2: The second number.
:raises TypeError: If either arg1 or arg2 is not a number.
:returns: The sum of arg1 and arg2.
:rtype: int

Additional details that may span multiple lines.
"""

    actual_output = parse(example_docstring)

# Generated at 2022-06-11 21:44:32.087719
# Unit test for function parse
def test_parse():
    text = '''
    Test a parameterized function.

    :param num: The number to test.
    :param str: The string to test.

    :raises ValueError: If the argument is too large.
    '''

# Generated at 2022-06-11 21:44:42.050792
# Unit test for function parse
def test_parse():
    doc = "Simple function with no parameters\n\n:return: Nothing"
    assert parse(doc) == Docstring(
        short_description="Simple function with no parameters",
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description=None,
        meta=[
            DocstringMeta(
                args=["return"], description="Nothing",
            )
        ],
    )

    doc = """
        Simple function with no parameters
        :return: Nothing
    """

# Generated at 2022-06-11 21:44:54.675886
# Unit test for function parse
def test_parse():
    doc = parse("""
        Args:
            x: length of the square
            y: width of the square
        Returns
            The area of the square
    """)
    
    assert doc.short_description == "Args:"
    assert len(doc.meta) == 2
    assert doc.meta[0].arg_name == "x"
    assert doc.meta[0].type_name == None
    assert doc.meta[0].is_optional == None
    assert doc.meta[0].default == None
    assert doc.meta[0].description == "length of the square"
    assert doc.meta[1].arg_name == "y"
    assert doc.meta[1].type_name == None
    assert doc.meta[1].is_optional == None
    assert doc.meta[1].default == None
    assert doc

# Generated at 2022-06-11 21:44:58.452218
# Unit test for function parse
def test_parse():
    text = ':foo: bar\n:baz:\n    qux'
    p = parse(text)
    print(p)

# Generated at 2022-06-11 21:44:59.405737
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-11 21:45:08.558498
# Unit test for function parse

# Generated at 2022-06-11 21:45:20.461392
# Unit test for function parse
def test_parse():
    ds = parse(
        """
        :param str q: A string
        :param float x: A float
        :raises TypeError: This could raise
        :type y: str
        :returns: NoneType
        :rtype: int
        """
    )
    assert len(ds.meta) == 4
    assert ds.meta[0] == DocstringParam(
        args=["param", "str", "q"],
        description="A string",
        arg_name="q",
        type_name="str",
        is_optional=False,
        default=None,
    )

# Generated at 2022-06-11 21:45:30.216750
# Unit test for function parse
def test_parse():
    assert parse(None) == Docstring()
    assert parse("") == Docstring()

    assert parse("Test function.") == Docstring(
        short_description="Test function."
    )

    assert parse(
        """
        Test function with
        long description.
        """
    ) == Docstring(
        short_description="Test function with",
        long_description="long description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

    assert parse(
        """
        Test function with
        long description.

        """
    ) == Docstring(
        short_description="Test function with",
        long_description="long description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )


# Generated at 2022-06-11 21:45:39.942607
# Unit test for function parse

# Generated at 2022-06-11 21:45:50.664266
# Unit test for function parse
def test_parse():
    doc = parse("""
    Some sort of function

    :param int x: The x value. Does something.
    :param int y: defaults to 1.
    :returns: None
    :raises ValueError: always
    """)
    
    assert doc.short_description=="Some sort of function"
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 3
    param = doc.meta[0]
    assert param.keyword == "param"
    assert param.arg_name == "x"
    assert param.type_name == "int"
    assert param.is_optional == False
    assert param.default == None

# Generated at 2022-06-11 21:46:01.958663
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description.

    :param type_1: description_1
    :param type_2: description_2

    :returns: description_3

    :param type_3:
        description_4

    :raises type_4: description_5
    """


# Generated at 2022-06-11 21:46:14.523115
# Unit test for function parse
def test_parse():
    from .common import Docstring, DocstringMeta


# Generated at 2022-06-11 21:46:31.337371
# Unit test for function parse
def test_parse():
    docstring = \
"""A short description.

A long description.

You can have multiple paragraphs in the long description if you like.

:param string arg1: the first argument
:type arg1: str
:param string arg2: the second argument
:param arg3: the third argument
:returns: something
:raises Exception: for some reason
"""
    ds = parse(docstring)

    assert ds.short_description == "A short description."
    assert ds.long_description == "A long description.\n\nYou can have multiple paragraphs in the long description if you like."
    assert ds.blank_after_short_description is True
    assert ds.blank_after_long_description is False

    assert len(ds.meta) == 4


# Generated at 2022-06-11 21:46:41.406127
# Unit test for function parse
def test_parse():
    docstring = """
    An example.

    :param a: The first argument.
    :param b: The second argument.
    :return: The return value.
    :raises KeyError: A key error.
    """

    parsed = parse(docstring)

    assert parsed.short_description == "An example."
    assert parsed.long_description is None
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description is True

    assert len(parsed.meta) == 3
    assert parsed.meta[0] == DocstringParam(
        args=["param", "a"],
        description="The first argument.",
        arg_name="a",
        type_name=None,
        is_optional=None,
        default=None,
    )
    assert parsed.meta[1]