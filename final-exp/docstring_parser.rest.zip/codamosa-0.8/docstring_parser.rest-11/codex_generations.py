

# Generated at 2022-06-11 21:37:10.786702
# Unit test for function parse

# Generated at 2022-06-11 21:37:21.618280
# Unit test for function parse
def test_parse():
    from .common import Docstring, DocstringParam, DocstringReturns, DocstringRaises, DocstringMeta

    param_list = []
    param_list.append(DocstringParam(
        args=["param", "str", "foo"],
        description="   A foo\n   Multiline\n",
        arg_name="foo",
        type_name="str",
        is_optional=False,
        default=None,
    ))

    param_list.append(DocstringParam(
        args=["param", "str?", "bar"],
        description="A bar",
        arg_name="bar",
        type_name="str",
        is_optional=True,
        default=None,
    ))


# Generated at 2022-06-11 21:37:23.542387
# Unit test for function parse
def test_parse():
    docstring = """
    This is a function
    this au

    """

# Generated at 2022-06-11 21:37:33.196522
# Unit test for function parse
def test_parse():
    """Simple unit test for function parse."""
    docstring = """Short summary.

    Longer summary.

    Args:
        arg1: First argument.
        arg2: Second argument (defaults to "default value").
        arg3 (int): Third argument (defaults to 3).
        arg4:
            Fourth argument.

            It spans multiple lines.

    Returns:
        int

    Raises:
        ValueError: In case no arguments are passed.

    """
    assert parse(docstring) == parse_doctest(docstring)
    assert parse(docstring).short_description == "Short summary."
    assert parse(docstring).long_description == "Longer summary."
    assert parse(docstring).meta[0].arg_name == "arg1"

# Generated at 2022-06-11 21:37:39.076189
# Unit test for function parse
def test_parse():
    src = """
    This is the short description.

    This is the long description.
    """

    result = parse(src)

    assert result == Docstring(
        short_description="This is the short description.",
        long_description="This is the long description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )



# Generated at 2022-06-11 21:37:49.446383
# Unit test for function parse
def test_parse():
    doc = parse(
        """Parse the ReST-style docstring into its components.

        :param x: integer
        :param y: integer of the same type as x
        :param z: integer
        :raises ValueError: if x and y are different
        :returns: x + y
        """
    )

    assert doc
    assert doc.short_description == "Parse the ReST-style docstring into its components."
    assert doc.blank_after_short_description is False
    assert doc.long_description == ""
    assert doc.blank_after_long_description is True
    assert len(doc.meta) == 4
    assert isinstance(doc.meta[0], DocstringParam)
    assert doc.meta[0].arg_name == "x"
    assert doc.meta[0].type_name is None

# Generated at 2022-06-11 21:37:57.669171
# Unit test for function parse
def test_parse():
    docstring = """
    This is the first line
    of the docstring.

    This is the second line
    of the docstring.
    """

    assert parse(docstring) == Docstring(
        short_description='This is the first line of the docstring.',
        blank_after_short_description=True,
        long_description='This is the second line of the docstring.',
        blank_after_long_description=False,
        meta=[]
    )

    docstring = """
    This is the first line
    of the docstring.

    :param foo: the foo argument
    :param bar: the bar argument

    This is the second line
    of the docstring.
    """


# Generated at 2022-06-11 21:38:07.632781
# Unit test for function parse
def test_parse():
    # test case 1
    docstring = "Print a string and an integer."
    result = parse(docstring)
    assert result.short_description == "Print a string and an integer."
    # test case 2
    docstring = "Print a string and an integer.\n\nThis function does some math."
    result = parse(docstring)
    assert result.short_description == "Print a string and an integer."
    assert result.long_description == "This function does some math."
    # test case 3
    docstring = "Print a string and an integer.\n\nThis function does some math.\n\n:param str string: the string to print\n:param int integer: the integer to print"
    result = parse(docstring)
    assert result.short_description == "Print a string and an integer."
    assert result

# Generated at 2022-06-11 21:38:14.384028
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: description
    :param arg2: description
    :type arg1: type description
    :type arg2: tuple description
    :returns: description
    :rtype: type description
    :raises exception1: description
    :raises exception2: description
    :raises: description
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 5
    assert isinstance(parsed.meta[0], DocstringParam)

# Generated at 2022-06-11 21:38:23.371588
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("short description") == Docstring(
        short_description="short description",
        long_description=None,
        blank_after_short_description=None,
        blank_after_long_description=None,
        meta=[],
    )
    assert parse("short description\n\nlong description") == Docstring(
        short_description="short description",
        long_description="long description",
        blank_after_short_description=True,
        blank_after_long_description=None,
        meta=[],
    )

# Generated at 2022-06-11 21:38:40.326064
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert (
        parse(
            """
            Short description.

            Long description: No blank lines here.
            """
        )
        == Docstring(
            short_description="Short description.",
            long_description="Long description: No blank lines here.",
            blank_after_short_description=False,
            blank_after_long_description=False,
            meta=[],
        )
    )
    assert (
        parse(
            """
            Short description.

            Long description.

            """
        )
        == Docstring(
            short_description="Short description.",
            long_description="Long description.",
            blank_after_short_description=False,
            blank_after_long_description=True,
            meta=[],
        )
    )

# Generated at 2022-06-11 21:38:46.562327
# Unit test for function parse
def test_parse():
    docstring = parse("""
    This is a test docstring.

    This is a long description.

    This is a long description.

    :param test: This is a test
    """)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == 'This is a long description.\n\nThis is a long description.'
    assert len(docstring.meta) == 1

# Generated at 2022-06-11 21:38:50.983742
# Unit test for function parse
def test_parse():
    text = """
    :param int a: bleh
    :raises ValueError: something
    :returns: ok
    """
    docstr = parse(text)
    assert isinstance(docstr.meta[0], DocstringParam)
    assert isinstance(docstr.meta[1], DocstringRaises)
    assert isinstance(docstr.meta[2], DocstringReturns)

# Generated at 2022-06-11 21:39:00.960996
# Unit test for function parse
def test_parse():
    doc = """
    Short summary.

    This is a long summary which may contain several paragraphs.

    Paragraphs are separated by blank lines.

    :param x: bla bla bla
    """
    d = parse(doc)
    assert d.short_description == "Short summary."
    assert d.long_description == "This is a long summary which may contain several paragraphs."
    assert d.blank_after_short_description == True
    assert d.blank_after_long_description == False
    assert d.meta[0].args[0] == "param"
    assert d.meta[0].description == "bla bla bla"

# Generated at 2022-06-11 21:39:13.032739
# Unit test for function parse
def test_parse():
    assert parse("""\
        Short description.

        Long description.
    """) == Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        long_description="Long description.",
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("Short description.") == Docstring(
        short_description="Short description.",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-11 21:39:23.994498
# Unit test for function parse
def test_parse():
    import datetime
    from .docblockr import parse
    res = parse("""
    """
        )
    assert res == {'short_description': None, 'long_description': None,
                   'blank_after_short_description': False, 'blank_after_long_description': False,
                   'meta': []}
    res = parse("""
    This is a very short description.
    """)
    assert res == {'short_description': 'This is a very short description.',
                   'long_description': None,
                   'blank_after_short_description': False, 'blank_after_long_description': False,
                   'meta': []}
    res = parse("""
    This is a very short description.

    This is the long description.
    """)

# Generated at 2022-06-11 21:39:30.122253
# Unit test for function parse
def test_parse():
    text = """A short description
A longer description.

    Args:
        arg1 (bool): This is arg1.
        arg2 (bool): This is arg2.
            Defaults to False.

    Returns:
        bool: Something.

    Raises:
        AttributeError: the sky is falling.
        TypeError: no it isn't!
    """
    doc = parse(text)
    assert doc.short_description == "A short description"
    assert doc.long_description == "A longer description."
    assert doc.blank_after_short_description
    assert not doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[1].arg_name == "arg2"
    assert doc.meta

# Generated at 2022-06-11 21:39:39.495914
# Unit test for function parse
def test_parse():
    # Test docstrings with one keyword (`param`, `return`, `raises`)
    docstring = """\
        Test parameters.

        :param c: test parameter c
        :type c: int
        """
    assert parse(docstring).meta == [
        DocstringParam(
            arg_name="c",
            type_name="int",
            description="test parameter c",
            is_optional=False,
            default=None,
        )
    ]

    docstring = """\
        Test yield.

        :yield: test yield
        """
    assert parse(docstring).meta == [
        DocstringReturns(
            type_name=None,
            description="test yield",
            is_generator=True,
        )
    ]


# Generated at 2022-06-11 21:39:46.050290
# Unit test for function parse
def test_parse():
    """
    Test ReST-style docstring parsing

    :param text: ReST-style docstring
    :type text: str
    :returns: parsed docstring
    :rtype: Docstring
    """
    print(parse(test_parse.__doc__))
    return


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:39:55.690363
# Unit test for function parse
def test_parse():
    docstring = """
    Parse the docstring into its components.
    :param arg1:
    :param arg2:
    :type arg2: float
    :param arg3:
    :type arg3:
    :raises ValueError
    :returns: parsed docstring
    """


# Generated at 2022-06-11 21:40:14.445944
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(
        short_description=None,
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("Function description.") == Docstring(
        short_description="Function description.",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("Function description.\nMore description.") == Docstring(
        short_description="Function description.",
        blank_after_short_description=False,
        long_description="More description.",
        blank_after_long_description=True,
        meta=[],
    )


# Generated at 2022-06-11 21:40:24.432249
# Unit test for function parse
def test_parse():
    text = """Dummy docstring.

Long description.

:param arg_name: A variable to pass
:type arg_name: int

:raises Exception:
    An exception is raised if...
    
:yields: int"""
    doc = parse(text)
    assert doc.short_description == "Dummy docstring."
    assert doc.long_description == "Long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "arg_name"
    assert doc.meta[0].type_name == "int"
    assert doc.meta[1].type_name == "Exception"
    assert doc.meta[1].args == ["raises", "Exception"]


# Generated at 2022-06-11 21:40:35.403997
# Unit test for function parse
def test_parse():
    assert parse("") is None
    assert parse("This is a test string") == Docstring(short_description="This is a test string")
    assert parse("This is a test string\nAnd some more\n") == Docstring(short_description="This is a test string\nAnd some more\n")
    assert parse("This is a test string\nAnd some more\n\n") == Docstring(short_description="This is a test string\nAnd some more\n", blank_after_short_description=False, blank_after_long_description=True, long_description=None)

# Generated at 2022-06-11 21:40:46.030000
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    :param x: Description of parameter `x`.
    :type x: str
    :param y: Description of parameter `y`.
    :type y: int
    :param z: Description of parameter `z`.
    :type z: list
    :returns: Description of return value.
    :rtype: bool
    :raises KeyError: if key not in dict.
    """


# Generated at 2022-06-11 21:40:54.574322
# Unit test for function parse
def test_parse():
    doc = """
    Parse the ReST-style docstring into its components.

    :param foo: (optional)
        This is foo's long description which spans multiple lines.
    :type foo: str
    :param bar: baz
    :returns: parsed docstring
    :raises ValueError: when text is None
    """


# Generated at 2022-06-11 21:41:05.600168
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring = """
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """
    ret = parse(docstring)
    assert ret.short_description == "Parse the ReST-style docstring into its components."
    assert ret.long_description == ":returns: parsed docstring"
    assert ret.blank_after_short_description
    assert not ret.blank_after_long_description

    docstring = """
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """

    ret = parse(docstring)
    assert ret.short_description == "Parse the ReST-style docstring into its components."
    assert ret.long_description == ":returns: parsed docstring"

# Generated at 2022-06-11 21:41:16.171356
# Unit test for function parse
def test_parse():
    text = """
    :param str path:
        Path to the file to open.
    :param int mode:
        Mode to open file with. Defaults to ``'r'``.
    :param bool buffering:
        If ``False``, no buffering is performed.
    :returns: file handle
    """
    d = parse(text)
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is True
    assert d.blank_after_long_description is False
    assert len(d.meta) == 3

# Generated at 2022-06-11 21:41:21.172404
# Unit test for function parse
def test_parse():
    text = r'''\
    :param type_name1 arg_name1: description1
    :param type_name2 arg_name2: description2
    :param type_name3 arg_name3: description3
    :returns: description4
    :rtype: type_name4
    :raises: type_name5
    :yields: type_name6
    :yield: type_name7
    '''
    print(parse(text))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:41:27.920274
# Unit test for function parse
def test_parse():
    # Test with a string of docstring
    ds = parse("""\
    This is a function test.

    This function is used to demonstrate how to parse a docstring.

    :param name: The name of the user
    :param age: The age of the user
    :returns: int
    """)
    assert ds.short_description == "This is a function test."
    assert ds.long_description == "This function is used to demonstrate how \
                                   to parse a docstring."

# Generated at 2022-06-11 21:41:38.485385
# Unit test for function parse
def test_parse():
    text = """
    Function to add two numbers
    :param a: First number
    :type a: int
    :param b: Second number
    :type b: int
    :returns: Sum of the given numbers
    :rtype: int
    """
    res = parse(text)
    assert res.short_description == "Function to add two numbers"
    assert res.meta[0].args[0] == "param"
    assert res.meta[0].args[1] == "a"
    assert res.meta[0].args[2] == "First number"
    assert res.meta[1].args[0] == "type"
    assert res.meta[1].args[1] == "a"
    assert res.meta[1].args[2] == "int"
    assert res.meta[2].args

# Generated at 2022-06-11 21:41:57.434894
# Unit test for function parse
def test_parse():
    docstring = """Summary line.

    Extended description of function.

    :param arg1: Description of arg1
    :type arg1: str
    :param arg2: Description of arg2
    :type arg2: int, optional
    :returns: Description of return value.
    :rtype: bool
    :raises keyError: raises an exception
    """

    result = parse(docstring)

    assert result.short_description == 'Summary line.'
    assert result.long_description == 'Extended description of function.'

# Generated at 2022-06-11 21:42:07.023827
# Unit test for function parse
def test_parse():
    docstring = '''Define several polynomials.
    Args:
        x: The generator
        xmin: Lower bound
        xmax: Upper bound
    Returns:
        y: Value of the polynomial at x
    Raises:
        TypeError: if input is not a number or Numpy array
    '''
    result = parse(docstring)
    assert result.short_description == 'Define several polynomials.'

    assert result.meta[0].description == 'The generator'
    assert result.meta[1].description == 'Lower bound'
    assert result.meta[2].description == 'Upper bound'
    assert result.meta[3].description == 'Value of the polynomial at x'
    assert result.meta[4].description == 'if input is not a number or Numpy array'


# Generated at 2022-06-11 21:42:15.812878
# Unit test for function parse
def test_parse():
    assert parse("this is a short description") == Docstring(
        short_description="this is a short description", meta=[]
    )
    assert parse("this is a short description\n") == Docstring(
        short_description="this is a short description", meta=[]
    )
    assert parse("this is a short description\n\n") == Docstring(
        short_description="this is a short description",
        blank_after_short_description=True,
        meta=[],
    )
    assert parse("this is a short description\n\nthat goes on and on") == Docstring(
        short_description="this is a short description",
        blank_after_short_description=True,
        long_description="that goes on and on",
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-11 21:42:26.714516
# Unit test for function parse

# Generated at 2022-06-11 21:42:36.899127
# Unit test for function parse
def test_parse():
    docstring = '''

    :param arg1: argument 1
    :type arg1: str
    :raises Exception: if there is an error
    '''


# Generated at 2022-06-11 21:42:48.556199
# Unit test for function parse
def test_parse():
    assert parse(
        """
    The quick brown fox jumps over the lazy dog.
    
    :param foo: This is foo.
    :param bar: This is bar.
    :returns: Nothingness.
    """
    )

    assert parse(
        """
    The quick brown fox jumps over the lazy dog.
    
    :param foo: This is foo.
    :param bar: This is bar.
    :returns: Nothingness.
    :returns: Somethingness.
    """
    )


# Generated at 2022-06-11 21:42:57.977630
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("   ") == Docstring()

    assert parse("a short description") == Docstring(
        short_description="a short description",
        blank_after_short_description=True,
    )

    assert parse("  a short description  ") == Docstring(
        short_description="a short description",
        blank_after_short_description=True,
    )

    assert parse("a short description\n\none line of long description.") == Docstring(
        short_description="a short description",
        blank_after_long_description=True,
        long_description="one line of long description",
    )

    #
    # Test meta
    #

# Generated at 2022-06-11 21:43:09.770342
# Unit test for function parse
def test_parse():
    docstring = """
        This method does stuff.

        And some more stuff.

        :param foo: The foo argument.
        :param bar: The bar argument.
        :param baz: baz with default value 5. defaults to 5.

        :returns: Nothing

        :raises KeyError: when the key is invalid

        :raises ValueError: when the value is invalid

        :raises: on general exceptions
        """
    ret = parse(docstring)
    assert ret.short_description == "This method does stuff."
    assert ret.blank_after_short_description
    assert ret.long_description == "And some more stuff."
    assert ret.blank_after_long_description
    assert len(ret.meta) == 4
    assert ret.meta[0].key == "param"

# Generated at 2022-06-11 21:43:19.333917
# Unit test for function parse
def test_parse():
    docstring = """This
    is an example docstring.

    :param name: The name to use.
    :type name: str
    :param state: Current state to be in.
    :type state: int, optional
    :param f: A function.
    :param f2: A 2nd function, with a very long description that
    should be wrapped to the next line.

    :returns: None
    :rtype: None
    :raises ValueError: If `name` is empty.
    :raises Exception: If something else goes wrong.
    """

    print(parse(docstring))


"""
Typed decorators
"""
from inspect import Parameter, Signature, signature
import functools
from inspect import getfullargspec, isfunction, ismethod, ismethoddescriptor, istraceback, isframe, iscode

# Generated at 2022-06-11 21:43:28.656335
# Unit test for function parse
def test_parse():
    # Test docstring parsing
    assert parse("Short description.\n\nLong description.") == Docstring(
        short_description="Short description.",
        long_description="Long description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse("Short description.\nLong description.") == Docstring(
        short_description="Short description.",
        long_description="Long description.",
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-11 21:43:45.563964
# Unit test for function parse
def test_parse():
    def test_func(a, b=2, *vargs, **kwargs):
        '''function that test docstring parsing

        :param a: the first parameter
        :type a: int
        :param b: the second parameter
        :type b: int
        :param *vargs: the parameters passed as a list
        :type *vargs: list
 
        :returns: the sum of the 2 first parameters
        :rtype: int
        :returns: the concatenation of the 2 first parameters
        :rtype: string
        :returns: the list of all the passed parameters
        :rtype: list
        '''
        return a + b, str(a) + str(b), [a, b] + vargs

    test_func_docstring = parse(test_func.__doc__)

# Generated at 2022-06-11 21:43:56.642588
# Unit test for function parse
def test_parse():

    """Test that we match the expected output of the function parse.

        1. input:

            """

# Generated at 2022-06-11 21:44:08.462945
# Unit test for function parse
def test_parse():
    """
    Test function parsing
    """
    text_parse = """
    Add two numbers together

    Returns
    -------
    sum: int
        The sum of x and y
    """
    doc = parse(text_parse)
    assert doc.short_description == "Add two numbers together"
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.long_description is None
    assert len(doc.meta) == 1
    assert doc.meta[0].args == ['Returns', 'int']
    assert doc.meta[0].description == "The sum of x and y"


# Generated at 2022-06-11 21:44:16.688041
# Unit test for function parse
def test_parse():
    text = """
    This is the description/short description.

    And this is the long description.
    """
    text = inspect.cleandoc(text)
    match = re.search("^:", text, flags=re.M)
    if match:
        desc_chunk = text[: match.start()]
        meta_chunk = text[match.start() :]
    else:
        desc_chunk = text
        meta_chunk = ""

    parts = desc_chunk.split("\n", 1)
    short_desc = parts[0] or None
    if len(parts) > 1:
        long_desc_chunk = parts[1] or ""
        blank_after_short_description = long_desc_chunk.startswith("\n")

# Generated at 2022-06-11 21:44:25.590679
# Unit test for function parse
def test_parse():
    """Test the parse function."""
    from . import common
    from . import numpydoc

    _skip_in_doctest([common, numpydoc])

    text = """\
    Example docstring.

    This is a long description.

    :param request: The request object.
    :type request: `rest_framework.request.Request`
    :param args: The view arguments.
    :param kwargs: The view keyword arguments.
    :returns: JSON
    :rtype: `rest_framework.response.Response`
    :raises permission_denied_exception: If permission is denied.
    """

    ret = parse(text)
    assert ret.short_description == "Example docstring."
    assert ret.long_description == "This is a long description."
    assert ret.blank_after_

# Generated at 2022-06-11 21:44:36.496438
# Unit test for function parse
def test_parse():
    docstring = parse("""
    Hello world.
    """)
    assert docstring.short_description == "Hello world."
    assert docstring.long_description is None

    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 0

    # Test long description
    docstring = parse("""
    Hello world.
    Long description.""")

    assert docstring.short_description == "Hello world."
    assert docstring.long_description == "Long description."

    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 0

    # Test metadata

# Generated at 2022-06-11 21:44:42.975197
# Unit test for function parse
def test_parse():
    try:
        text = """
        Parse the ReST docstring into its components.

        :param arg1: the first argument
        :type arg1: int
        :param arg2: the second argument
        :type arg2: ``str``
        :type arg3: ``str``
        :raises ValueError: if something bad happened
        :return: True, if successful, False otherwise
        :rtype: bool

        """
        print(parse(text))
        print()
    except ParseError as e:
        print(e)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:44:51.421455
# Unit test for function parse
def test_parse():
    docstring = """
        Purpose of this function.
        :param A: type_a
        :param B: type_b
        :param C: type_c
    """

# Generated at 2022-06-11 21:44:56.636720
# Unit test for function parse

# Generated at 2022-06-11 21:45:07.462180
# Unit test for function parse
def test_parse():
    docstring = """This is the short decription.
    This is the first line of the long description.
    This is the second line of the long description \
        that continues onto a new line.
    :param param1: The first parameter.
    :type param1: str
    :param param2: The second parameter. Defaults to ``'world'``.
    :type param2: str
    :returns: None
    :raises ValueError: If ``param2`` is equal to ``'hello'``.
    """

# Generated at 2022-06-11 21:45:26.765363
# Unit test for function parse
def test_parse():
    docstring = '''This is a cool function.
    :param a: argument a
    :param b: optional argument b with default ``1``
    :param c: optional argument c with default ``'hello'``

    See also `test`_

    .. _`test`: http://example.com
    '''
    test_docstring = parse(docstring)
    assert test_docstring.short_description == 'This is a cool function.'
    assert test_docstring.long_description == "See also `test`_\n\n.. _`test`: http://example.com"
    assert len(test_docstring.meta) == 3

# Generated at 2022-06-11 21:45:33.221644
# Unit test for function parse

# Generated at 2022-06-11 21:45:41.621821
# Unit test for function parse
def test_parse():
    from .common import (
        PARAM_KEYWORDS,
        RAISES_KEYWORDS,
        RETURNS_KEYWORDS,
        YIELDS_KEYWORDS,
        Docstring,
        DocstringParam,
        DocstringRaises,
        DocstringReturns,
        ParseError,
    )
    import pytest

    docstring = parse.__doc__
    result = parse(docstring)
    assert (
        result.short_description == "Parse the ReST-style docstring into its components."
    )
    assert result.blank_after_short_description
    assert (
        result.long_description
        == """
    :returns: parsed docstring
    """
    )
    assert result.blank_after_long_description

    assert len(result.meta) == 4
   

# Generated at 2022-06-11 21:45:51.441334
# Unit test for function parse

# Generated at 2022-06-11 21:46:02.596699
# Unit test for function parse
def test_parse():
    docstring = """Summary line.

Description of function.

:param int arg1: The first argument, defaults to 1.
:param arg2: The second argument, defaults to 'spam'.
:param arg3: This argument has no default, so it must be specified.
:raise Exception: An exception is raised if something goes wrong.
:returns: This is the return value.
:return: This is another return value.
:rtype: str

"""
    ds = parse(docstring)
    assert ds.short_description == "Summary line."
    assert ds.blank_after_short_description == True
    assert ds.long_description == "Description of function."
    assert ds.blank_after_long_description == False

    assert len(ds.meta) == 7

# Generated at 2022-06-11 21:46:14.606108
# Unit test for function parse
def test_parse():
    doc = """
    Returns 1 + 2.

    Args:
        a (int): x
        b (int): y

    Returns:
        The sum of a + b.
        y

    Raises:
        TypeError: if unsupported type.

    """
    docstring = parse(doc)
    assert docstring.short_description == "Returns 1 + 2."
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 4
    assert docstring.meta[0].description == "x"
    assert docstring.meta[0].arg_name == "a"
    assert docstring.meta[1].description == "y"
    assert docstring.meta[1].arg_name == "b"

# Generated at 2022-06-11 21:46:26.426335
# Unit test for function parse
def test_parse():
    doc = parse(
        """
        Say a greeting.

        This is a multi-line description of what this function does.  It also
        explains how to use it.

        :param name: The name of the person to use in the greeting.
        :param age: The age of the person.
        :type age: int, optional
        :param pet: The name of their pet.
        :type pet: str, optional
        :returns: The greeting text.
        :rtype: str

        Additional meta info.
        """
    )

    assert doc.short_description == "Say a greeting."
    assert doc.long_description == (
        "This is a multi-line description of what this function does.  It "
        "also explains how to use it."
    )
    assert len(doc.meta) == 2
    assert doc

# Generated at 2022-06-11 21:46:37.002998
# Unit test for function parse