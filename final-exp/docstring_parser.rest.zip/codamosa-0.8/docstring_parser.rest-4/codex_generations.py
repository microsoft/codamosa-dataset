

# Generated at 2022-06-11 21:37:16.479198
# Unit test for function parse
def test_parse():
    test_docstring = """Docstring for the function

:param arg1: Description of arg1.
:param arg2: Description of arg2.

:returns: Description of the return value.

:raises Exception: Description of the exception.
"""
    assert parse(test_docstring)

# Generated at 2022-06-11 21:37:24.601700
# Unit test for function parse
def test_parse():
    docstring = '''
One-line summary.

    extended description.

    :param arg: arg description.
    :type arg: str
    :param arg2: arg description. Defaults to ``'arg2'``.
    :type arg2: str
    :returns: return description.
    :rtype: int
    :raises: :class:`RuntimeError` if an error occurs.
    :raises Exception: another error
    '''
    print(parse(docstring))
    #    desc_start_lineno = 3
    #    desc_lines = [
    #        'One-line summary.',
    #        '',
    #        'extended description.',
    #        '',
    #    ]
    #    meta = {
    #        'arg': [
    #            DocstringMeta(

# Generated at 2022-06-11 21:37:27.668064
# Unit test for function parse
def test_parse():
    text = """\
    Returns a copy of the string with trailing whitespace removed.

    :returns: copy of string

    :param str str:
    """
    print(parse(text))



# Generated at 2022-06-11 21:37:35.356576
# Unit test for function parse
def test_parse():
    docstring = """
    :param a: a
    :type a: int
    :param b: b
    :type b: str
    :param c: c (defaults to False.)
    :param d: d
    :type d: str
    :returns: e
    :rtype: int
    :yields: f
    :ytype: str
    """
    result = parse(docstring)
    # print(result.__dict__)
    assert result.short_description == ''
    assert result.long_description is None
    assert result.blank_after_short_description
    assert result.blank_after_long_description
    assert len(result.meta) == 6

    assert result.meta[0].args == ['param', 'a']

# Generated at 2022-06-11 21:37:44.027156
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    doc = r'''
    A function to test the doctype docstring parser.

    This function is not very useful.
    :param name: Your name. (defaults to "World")
    :type name: str
    :returns: The greeting.
    :rtype: str

    '''
    result = parse(doc)
    assert result.short_description == "A function to test the doctype docstring parser."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert result.long_description == "This function is not very useful."
    assert len(result.meta) == 2
    assert isinstance(result.meta[0], DocstringParam)
    assert result.meta[0].description == "Your name."

# Generated at 2022-06-11 21:37:46.653109
# Unit test for function parse
def test_parse():
    """Ensure that doctest strings are parsed correctly"""
    from .test_common import test_parse
    test_parse(parse)
    test_parse(parse, "")



# Generated at 2022-06-11 21:37:54.031069
# Unit test for function parse
def test_parse():
    text = """
    This is a description.

    :param arg1: This is a description.
    :type arg1: str
    :param arg2: Optional description.
    :type arg2: str?
    :param arg3: Optional description.
    :type arg3: str?
    :param arg4: Optional description.
    :type arg4: str?
    :param arg4: Optional description.
           Defaults to None.
    :type arg5: str?

    :returns: Description.
    :rtype: str
    """
    assert parse(text)

# Generated at 2022-06-11 21:38:05.744387
# Unit test for function parse
def test_parse():
    """
    Test the parse function

    >>> import pdoc
    >>> doc = pdoc.parse("""


# Generated at 2022-06-11 21:38:16.993158
# Unit test for function parse
def test_parse():
    """Tests for function parse"""

# Generated at 2022-06-11 21:38:23.810924
# Unit test for function parse
def test_parse():
    docstring = """
        Single line summary.

        Extended description.

        :param arg1: First argument description.
        :type arg1: str
        :param arg2: Second argument description.
        :type arg2: int, optional
        :param arg3: Third argument description.
        :type arg3: str, optional
        :param arg4: Fourth argument description.
        :type arg4: str, optional, defaults to None.
        :rtype: str
        :raises: ValueError
        :raises: TypeError, if incorrect argument type.
    """

    print(parse(docstring))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:38:40.457325
# Unit test for function parse
def test_parse():
    """ Test function parse """
    text = '''\
    Test parser.

    :param  arg_name: arg_name
    :type  arg_name: arg_type
    :rtype: r_type
    :returns: returns type
    :raises: raises type
    :yields: yields type
    '''

    docstring = parse(text)

    print(docstring.short_description)
    print(docstring.long_description)

    for item in docstring.meta:
        print("{0}: {1}".format(item.args, item.description))

    # Expected output
    # Test parser.
    # None
    # ['param', 'arg_name', 'arg_type']: arg_name
    # ['rtype']: r_type
    # ['returns']: returns type

# Generated at 2022-06-11 21:38:44.308067
# Unit test for function parse
def test_parse():
    text = """
        This is a valid docstring for a function.
    
        :param str arg1: The first argument.
        :param int arg2: The second argument (defaults to 2).
        :raises ValueError: If something bad happens.
        :returns: The return value.
        :rtype: str
        """

    doc = parse(text)
    assert doc.short_description == "This is a valid docstring for a function."
    assert doc.long_description == None
    assert doc.blank_after_short_description == True

    meta = doc.meta
    assert len(meta) == 4
    assert meta[0].args == ['param', 'str', 'arg1']
    assert meta[0].key == 'param'
    assert meta[0].arg_name == 'arg1'

# Generated at 2022-06-11 21:38:49.266963
# Unit test for function parse
def test_parse():

    text = """
    This is a docstring for a single line.
    :param str arg1: The first argument, a string.
    :return: No return.
    :rtype: None
    """
    print(parse(text))

    print("\n----\n")
    text = """
    This is a docstring for a single line.
    :param str arg1: The first argument, a string.
    :returns: No return.
    :rtype: None
    """
    print(parse(text))
    print("\n----\n")

    text = """
    This is a docstring for a single line.
        :param str arg1: The first argument, a string.
    :returns: No return.
    """
    print(parse(text))

    print("\n----\n")


# Generated at 2022-06-11 21:39:01.447236
# Unit test for function parse
def test_parse():
    def test_function():
        """A test function.

        :param a: first argument.
        :type a: str
        :param b: second argument.
        :type b: int
        :raises ValueError: on an error.

        :returns: something.
        :rtype: str
        """
        pass

    docstring = parse(inspect.getdoc(test_function))

    assert docstring.short_description == "A test function."
    assert docstring.long_description is None
    assert docstring.blank_after_short_description
    assert not docstring.blank_after_long_description

    assert len(docstring.meta) == 3
    assert isinstance(docstring.meta[0], DocstringParam)

# Generated at 2022-06-11 21:39:07.554683
# Unit test for function parse
def test_parse():
    parse("""
        Short summary.

        Long
        description.

        :param arg1: argument 1
        :type arg1: str
        :param arg2: argument 2
        :type arg2: str
        :param arg3: argument 3
        :type arg3: str
        :raises TypeError: if the ``arg2`` is not string
        """)

# Generated at 2022-06-11 21:39:14.960492
# Unit test for function parse
def test_parse():
    print("test parse")
    text = """\
    Sums two numbers.

    This is a longer description.

    :param x: first number
    :param y: second number
    :type x: int
    :type y: int
    :returns: the numbers summed up
    :rtype: int
    """
    print("text =",text)
    print("Docstring =",parse(text))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:39:19.371572
# Unit test for function parse
def test_parse():
    assert parse("Function title") == Docstring(
        short_description="Function title",
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )



# Generated at 2022-06-11 21:39:26.621297
# Unit test for function parse
def test_parse():
    assert (
        parse("""
        Short description.

        Long description.

        :return: None
        :rtype: None
        """)
        == Docstring(
            short_description="Short description.",
            blank_after_short_description=False,
            long_description="Long description.",
            blank_after_long_description=False,
            meta=[
                DocstringReturns(
                    args=["return", None],
                    description=None,
                    type_name=None,
                    is_generator=False,
                )
            ],
        )
    )

# Generated at 2022-06-11 21:39:38.159089
# Unit test for function parse
def test_parse():
    text = """Triple-quoted string.

    :param str foo: Is foo.
    :param str bar: Is bar.
    :param str baz: Is baz.
    """

    docstring = parse(text)

    assert docstring.short_description == "Triple-quoted string."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].arg_name == "foo"
    assert docstring.meta[0].type_name == "str"
    assert docstring.meta[0].is_optional == False
    assert docstring.meta[0].default == None
    assert docstring.meta[0].description

# Generated at 2022-06-11 21:39:50.145926
# Unit test for function parse
def test_parse():
    assert Docstring() == parse("")
    assert Docstring(short_description=None, long_description=None) == parse(None)
    assert Docstring(short_description="") == parse("\n")
    assert Docstring(short_description="   \n") == parse("   \n")
    assert Docstring(short_description="   \n   ") == parse("   \n   ")
    assert Docstring(short_description="\n") == parse("\n\n")
    docstring = Docstring(
        short_description="A\nmultiline\nshort description.",
        blank_after_short_description=False,
        long_description="A\nmultiline\nlong description.",
        blank_after_long_description=False,
    )

# Generated at 2022-06-11 21:40:07.903452
# Unit test for function parse
def test_parse():
    from .common import returns
    from .common import raises
    from .common import param
    from .common import yields
    from .common import BlankLine
    from .common import DocstringRaises

    assert isinstance(parse(""), Docstring)
    assert isinstance(parse(""), Docstring)
    assert parse("").short_description is None
    assert isinstance(parse("test docstring"), Docstring)
    assert parse("test docstring").short_description == "test docstring"

    test_docstring = """
    Short description.

    Long description.

    :param int age: The age to test.
    :returns: Description of the return value.
    :raises ValueError: If `age` is negative.

    """
    parsed = parse(test_docstring)

# Generated at 2022-06-11 21:40:16.574053
# Unit test for function parse
def test_parse():
    s = """
    Parse the ReST-style docstring text into its components.

    :param a: First argument.
    :type a: str
    :param b: Second argument.
    :type b: int

    :returns: A string.
    :rtype: str

    :raises ValueError: If something bad happens.
    """

    doc = parse(s)

    assert doc.short_description == "Parse the ReST-style docstring text into its components."
    assert doc.long_description == (
        "First argument.\n"
        "\n"
        "Second argument.\n"
        "\n"
        "A string."
    )
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert doc.meta[0] == Docstring

# Generated at 2022-06-11 21:40:25.681583
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse(" \n") == Docstring()
    assert parse(" \n\n") == Docstring()

    assert parse("foo") == Docstring(
        short_description="foo", long_description=None, meta=[]
    )
    assert parse("foo\n") == Docstring(
        short_description="foo", long_description=None, meta=[]
    )
    assert parse("foo\n\n") == Docstring(
        short_description="foo", long_description=None, meta=[]
    )

# Generated at 2022-06-11 21:40:36.243288
# Unit test for function parse

# Generated at 2022-06-11 21:40:46.763176
# Unit test for function parse
def test_parse():
    s = """package.module:
:param arg1: a 1st arg
:param arg2: a 2nd arg
:param arg3: a 3rd arg
:returns: a return value
"""
    p = parse(s)
    assert (p.short_description, p.meta[0].description) == (
        "package.module",
        "a 1st arg",
    )
    assert p.meta[0].arg_name == "arg1"
    assert (p.meta[1].arg_name, p.meta[1].description) == ("arg2", "a 2nd arg")
    assert (p.meta[2].arg_name, p.meta[2].description) == ("arg3", "a 3rd arg")
    assert p.meta[3].description == "a return value"
    assert p.meta

# Generated at 2022-06-11 21:40:56.960434
# Unit test for function parse
def test_parse():

    my_test_docstring =  """
        This is a test docstring

        This is the long description of the test docstring.

        :arg str test_arg: This is a test argument
        :arg list[int] int_list: This is a test argument
        :arg int: This is a test argument
        :returns tuple[str]: This is a test argument

        """
    
    test_parse = parse(my_test_docstring)
    assert test_parse.short_description == "This is a test docstring"
    assert test_parse.blank_after_short_description == True
    assert test_parse.blank_after_long_description == True
    assert test_parse.long_description == "This is the long description of the test docstring."

# Generated at 2022-06-11 21:41:02.078217
# Unit test for function parse
def test_parse():
    d = """\
    A function

    This is a test
    """

    data = parse(d)
    assert data.short_description == "A function"
    assert data.blank_after_short_description is False
    assert data.long_description == "This is a test"
    assert data.blank_after_long_description is False
    assert data.meta == []



# Generated at 2022-06-11 21:41:12.960599
# Unit test for function parse
def test_parse():
    docstring = """
    Foo bar.

    :param bar: bar
    :type bar: string
    :param baz: baz
    :type baz: int
    :returns: returns bar
    :rtype: string
    :Example:
        >>> Foobar(10)
        "bar"
    """
    result = parse(docstring)
    assert len(result.meta) == 4
    assert result.short_description == "Foo bar."
    assert result.long_description == \
        ":Example: >>> Foobar(10) \"bar\""
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True

    r = docstring
    r = re.sub('\n', '', r)

# Generated at 2022-06-11 21:41:19.134465
# Unit test for function parse
def test_parse():
    text = """
    This is a short description.

    And this is some more information.

    :param str name: This is a name variable
    :keyword int age: This is another variable
    :param bool done: This variable is boolean
    :returns: A string
    :rtype: str
    :raises KeyError: Always raises this error
    """
    assert parse(text)

# -------------------

# Generated at 2022-06-11 21:41:27.148330
# Unit test for function parse

# Generated at 2022-06-11 21:41:47.677812
# Unit test for function parse
def test_parse():
    """Test function parse."""
    text = """
    This is the short description.

    And this is the long description.

    :param str arg: With a description
        that has some formattting.

    :param int x: Some other argument.

    :raises:
        a: Meaningless container
        b: Another meaningless container
        Exception: Real exception
            With a multiline description

    :return:
        str: The return value
        is a string.

    :yield int: A generator.
    """

    docstring = parse(text)

    assert docstring.short_description == "This is the short description."
    assert docstring.blank_after_long_description is True
    assert docstring.short_description == docstring.long_description
    assert len(docstring.meta) == 4


# Generated at 2022-06-11 21:41:48.313335
# Unit test for function parse

# Generated at 2022-06-11 21:41:54.018390
# Unit test for function parse
def test_parse():
    text = """\
    This is the short description.

    This is the long description.

    :param str foo: This is a parameter.
    :param int bar: This is another parameter.
    :returns: This is what is returned.
    :raises ValueError: This is why it's raised.
    """

    expected = parse(text)
    actual = ""
    assert(expected == actual)

# Generated at 2022-06-11 21:42:04.260700
# Unit test for function parse
def test_parse():
    docstring = """
    Multi-line docstring.

    :param a: First parameter.
    :type a: str
    :param b: Second parameter.
    :type b: int
    :returns: A value.
    :rtype: dict
    """

# Generated at 2022-06-11 21:42:12.077906
# Unit test for function parse

# Generated at 2022-06-11 21:42:22.670842
# Unit test for function parse

# Generated at 2022-06-11 21:42:30.940949
# Unit test for function parse
def test_parse():

    """
    Test that the parse function properly parses docstrings.
       """


# Generated at 2022-06-11 21:42:39.880108
# Unit test for function parse
def test_parse():
    # Setup
    docstring = """One-line summary.

The rest of the one line summary.
More description.

:param arg1: description for arg1
:type arg1: string
:param arg2: description for arg2
:type arg2: string
:returns: description of return value
:rtype: string
:raises keyError: raises an exception
:raises ImportError: raises an exception
"""

# Generated at 2022-06-11 21:42:49.821248
# Unit test for function parse

# Generated at 2022-06-11 21:42:58.773440
# Unit test for function parse
def test_parse():
    assert parse('foo') == Docstring('foo', None, None, [])
    assert parse('foo\nbar') == Docstring('foo', 'bar', None, [])
    assert parse('foo:\nbar') == Docstring('foo', 'bar', None, [])
    assert parse('foo:\n  bar') == Docstring('foo', 'bar', None, [])
    assert parse('foo:\n  bar\n  baz') == Docstring('foo', 'bar\n\nbaz', None, [])
    assert parse(':param x: foo') == Docstring('', None, None, [DocstringParam([':param', 'x'], 'foo')])

# Generated at 2022-06-11 21:43:14.020414
# Unit test for function parse

# Generated at 2022-06-11 21:43:22.178080
# Unit test for function parse
def test_parse():
    text = """
    This is a short description of the function.

    This is a long description of the function.
    The short description is on its own line while
    the long description spans multiple lines.

    :Parameters:

    - **param_a** (type?) - Description of param_a.
    - **param_b**: Description of param_b.

    :Returns:

    - type? - Description of what the function returns.

    :Raises:

    - Exception: Description of exceptions that can be raised.
    """

    ds = parse(text)

    assert ds.short_description == "This is a short description of the function."

# Generated at 2022-06-11 21:43:29.811914
# Unit test for function parse

# Generated at 2022-06-11 21:43:42.134318
# Unit test for function parse
def test_parse():
    docstring = '''Single-line docstring.'''
    assert parse(docstring) == Docstring(
        short_description='Single-line docstring.',
        blank_after_short_description=True,
        blank_after_long_description=True)

    docstring = '''Single line docstring.'''
    assert parse(docstring) == Docstring(
        short_description='Single line docstring.',
        blank_after_short_description=True,
        blank_after_long_description=True)

    docstring = '''Single-line docstring.

    Multi-line docstring.'''

# Generated at 2022-06-11 21:43:54.648012
# Unit test for function parse
def test_parse():
    sample = """
        A bar.

        :param foo: foo
        :type foo: str
        :keyword bar: bar
        :returns: a
        :rtype: int
        """

    result = parse(sample)
    assert result.short_description == "A bar."
    assert result.long_description == "foo\nbar\na"
    assert result.blank_after_short_description is True
    assert result.blank_after_long_description is False

    assert result.meta[0] == DocstringParam(
        args=["foo", "str"],
        description="foo",
        arg_name="foo",
        type_name="str",
        is_optional=None,
        default=None,
    )

# Generated at 2022-06-11 21:43:55.829085
# Unit test for function parse
def test_parse():
    # TODO
    pass

# Generated at 2022-06-11 21:44:07.865741
# Unit test for function parse
def test_parse():
    doc = "Verify the login credentials.\n"  # short_description
    doc += "\n"  # blank_after_short_description
    doc += ":param username: The username to authenticate.\n"  # meta
    doc += ":type username: str\n"  # meta
    doc += ":param password: The password for the user.\n"  # meta
    doc += ":type password: str\n"  # meta
    doc += "\n"  # blank_after_long_description
    doc += ":raises LoginFailure: If the username and password don't match."
    #: :type LoginFailure: io.LoginFailure
    # meta
    doc += ":raises NetworkFailure: If the authentication service is down."
    #: :type NetworkFailure: io.NetworkFailure
    # meta
    doc

# Generated at 2022-06-11 21:44:16.167010
# Unit test for function parse
def test_parse():
    # check to see if it raises an error if there is no match
    import pytest
    func = parse('nonsense')
    assert func == Docstring()
    # test if there are multiple lines of description
    func = parse('first line\n\nmore description here\n\n:return: nothing')
    assert func.short_description == 'first line'
    assert func.blank_after_short_description == True
    assert func.blank_after_long_description == False
    assert func.long_description == 'more description here'
    # test if there is a single line of description
    func = parse('description here')
    assert func.short_description == 'description here'
    assert func.blank_after_short_description == False
    assert func.long_description is None
    # test if there is no description at all
    func

# Generated at 2022-06-11 21:44:26.850042
# Unit test for function parse
def test_parse():
    docstring = """
    A simple function
    to test parsing
    of docstring
    """

    output = parse(docstring)
    assert output.short_description == 'A simple function\nto test parsing\nof docstring'
    assert output.long_description == None
    assert output.blank_after_short_description == None
    assert output.blank_after_long_description == None
    assert output.meta == []

    docstring = """
    A simple function
    to test parsing
    of docstring

    Args:
        a (int): First param

    Returns:
        int: An integer
    """

    output = parse(docstring)
    assert output.short_description == 'A simple function\nto test parsing\nof docstring'
    assert output.long_description == ''
    assert output.blank_

# Generated at 2022-06-11 21:44:38.089820
# Unit test for function parse
def test_parse():
    """Test for parse(text)"""
    docstring = """
    This is a test
    :param arg1: a test
    :param arg2: another test
    :param arg3: a test
    :type arg3: test
    :param arg4: a test
    :type arg4: test
    :returns: a test
    :rtype: test
    :raises TypeError: if test
    """

    ds = parse(docstring)
    assert ds.short_description == "This is a test"
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is False
    assert ds.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-11 21:44:54.436040
# Unit test for function parse
def test_parse():
    docstring = parse(docstrings.simple_function)
    print(docstring)
    assert docstring.short_description == "This is a basic function."
    assert docstring.long_description == "The first sentence here."
    assert docstring.meta[0].arg_name == "foo"
    assert docstring.meta[0].description == "Foo takes an integer."
    assert docstring.meta[1].arg_name == "bar"
    assert docstring.meta[1].type_name == "str"
    assert docstring.meta[2].description == "The return value is an integer."

    docstring = parse(docstrings.function_with_blank_description)
    print(docstring)
    assert docstring.short_description == "This is a basic function."
    assert docstring.long_description is None

# Generated at 2022-06-11 21:45:06.890322
# Unit test for function parse
def test_parse():
    text = \
""":param key:
    The key is the (x,y) coordinate of the cell.
:param default:
    The default value when the cell is accessed but not set yet.
    Defaults to 0.
:raises KeyError:
    If the key is invalid.
:returns:
    The value stored in the specified cell."""

    doc = parse(text)
    assert doc.short_description is None
    assert doc.long_description is None
    assert len(doc.meta) == 4
    assert doc.meta[0] == DocstringParam(
        ["param", "key", "key"],
        "The key is the (x,y) coordinate of the cell.",
        "key",
        default=None,
        is_optional=None,
        type_name=None,
    )
    assert doc

# Generated at 2022-06-11 21:45:17.979280
# Unit test for function parse
def test_parse():
    """
    test parse function
    """
    print("Testing Parse Function")
    doc = parse("this is a test")
    d = DirObj()
    d.short_description = doc.short_description
    d.blank_after_short_description = doc.blank_after_short_description
    d.blank_after_long_description = doc.blank_after_long_description
    d.long_description = doc.long_description
    d.meta = doc.meta
    assert d.short_description == "this is a test"
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.long_description == None
    assert d.meta == []



# Generated at 2022-06-11 21:45:28.682593
# Unit test for function parse
def test_parse():

    def test_func():
        """
        This is a test function with its ReST docstring.
        :param name: The name keyword
        :type name: str
        """
        pass

    assert parse('This is a ReST docstring.') == Docstring(
        short_description='This is a ReST docstring.')

    assert parse('This is a ReST docstring.\n\nMore description.') == Docstring(
        short_description='This is a ReST docstring.',
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description='More description.',
        meta=[],
    )


# Generated at 2022-06-11 21:45:38.921367
# Unit test for function parse
def test_parse():
    doc = r'''toto
    :param x: xxx
    :param y: yyy
    toto'''

    d = parse(doc)
    
    assert d.short_description == 'toto'
    assert d.long_description == 'toto'
    assert d.meta[0].description == 'xxx'
    assert d.meta[0].arg_name == 'x'
    assert d.meta[1].description == 'yyy'
    assert d.meta[1].arg_name == 'y'

    doc = r'''toto
    toto
    :param x: xxx
    :param y: yyy
    toto'''

    d = parse(doc)
    
    assert d.short_description == 'toto'

# Generated at 2022-06-11 21:45:49.941191
# Unit test for function parse
def test_parse():

    def assertDocstringEqual(d1, d2):
        assert d1.short_description == d2.short_description, "short description"
        assert d1.long_description == d2.long_description, "long description"
        assert d1.blank_after_short_description == d2.blank_after_short_description, "blank after short description"
        assert d1.blank_after_long_description == d2.blank_after_long_description, "blank after long description"
        assert len(d1.meta) == len(d2.meta), "number of metadata"
        for m1, m2 in zip(d1.meta, d2.meta):
            assert isinstance(m1, type(m2)), "meta type"
            assert m1.args == m2.args, "meta args"
           

# Generated at 2022-06-11 21:46:01.360258
# Unit test for function parse
def test_parse():
    """Test fct parse"""

    test1 = """\
    A nice little docstring
    :param a: first input parameter
    :type a: int
    :returns: returns cosine
    """

    doc = parse(test1)
    assert doc.short_description == "A nice little docstring"
    assert doc.long_description is None
    assert len(doc.meta) == 2
    assert doc.meta[0].arg_name == "a"
    assert doc.meta[0].type_name == "int"
    assert doc.meta[1].arg_name is None
    assert doc.meta[1].type_name == "returns cosine"


# Generated at 2022-06-11 21:46:13.887217
# Unit test for function parse
def test_parse():
    docstring = parse("""
    A docstring.

    :param arg1: First arg.
    :param arg2: Second arg.
    :return: None.
    """)
    assert docstring.short_description == "A docstring."
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].arg_name == 'arg1'
    assert docstring.meta[0].type_name == None
    assert docstring.meta[0].is_optional == None
    assert docstring.meta[0].default == None
    assert docstring.meta[0].description == 'First arg.'

# Generated at 2022-06-11 21:46:17.889847
# Unit test for function parse
def test_parse():
    txt = """
    This is a module.
    :param a: this is text.
    :param b: this is more text.
    :param c: this is more text.
    :returns: something.
    """
    assert(parse(txt))

# Generated at 2022-06-11 21:46:29.589097
# Unit test for function parse