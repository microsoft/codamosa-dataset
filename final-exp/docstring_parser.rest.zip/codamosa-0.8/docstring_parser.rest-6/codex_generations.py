

# Generated at 2022-06-11 21:37:11.495737
# Unit test for function parse
def test_parse():
    import sys
    import os.path

    # Add package dir to sys.path
    this_file = os.path.realpath(__file__)
    this_dir = os.path.dirname(this_file)
    parent_dir = os.path.dirname(this_dir)
    sys.path.append(parent_dir)

    from .examples import parse
    from .examples import SimpleClass
    from .examples import InheritedClass
    from .examples import OrderedDict
    from .examples import ParsedFunction
    from .examples import ParsedFunctionWithReferences
    from .examples import ParsedFunctionWithRaises

    # Unit test for example of function parse
    parse_doc = parse.__doc__
    parse_docstring = parse(parse_doc)
    assert parse_docstring.short_

# Generated at 2022-06-11 21:37:22.016476
# Unit test for function parse
def test_parse():
    docstring = '''
    More detailed description.
    :param x: the first parameter
    :type x: str
    :param y: the second parameter
    :type y: str
    :param z: the third parameter (defaults to None)
    :type z: str
    :param a?: the fourth parameter (defaults to None)
    :type a?: str
    :param b?: the fifth parameter (defaults to None)
    :type b?: str
    :returns: A Class
    :rtype: Class
    :raises: :exc:`~exceptions.Exception` when a request fails
    '''

    parsed = parse(docstring)
    assert parsed.short_description == 'More detailed description.'

    assert parsed.meta[2].arg_name == 'z'
    assert parsed.meta[2].type_

# Generated at 2022-06-11 21:37:33.036627
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("  \n") == Docstring()
    assert parse("Short description.\n") == Docstring(
        short_description="Short description."
    )
    assert parse("Short description.\n\n") == Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )
    assert parse("Short description.\n\nLong description.\n") == Docstring(
        short_description="Short description.",
        long_description="Long description.",
    )

# Generated at 2022-06-11 21:37:34.245332
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:37:43.304611
# Unit test for function parse
def test_parse():
    text = '''\
    Test string.
    Bla bla bla.

    :param str arg1: Argument 1
    :return: Test value
    :rtype: str
    :raises: TestError
    '''
    result = parse(text)
    assert result.short_description == 'Test string.'
    assert result.blank_after_short_description
    assert result.long_description == 'Bla bla bla.'
    assert result.blank_after_long_description
    assert len(result.meta) == 3
    assert result.meta[0].keyword == 'param'
    assert result.meta[0].arg_name == 'arg1'
    assert result.meta[0].type_name == 'str'
    assert result.meta[0].description == 'Argument 1'
    assert result.meta

# Generated at 2022-06-11 21:37:53.206720
# Unit test for function parse
def test_parse():
    """
    Test the docstring parsing
    """
    assert parse("") == Docstring()

    docstring = Docstring()
    docstring.short_description = "Parse the ReST-style docstring into its components."
    docstring.long_description = """
        :returns: parsed docstring
        """
    assert parse(docstring.long_description) == docstring

    docstring = parse(docstring.long_description)
    docstring.short_description = "Parse the ReST-style docstring into its components."
    assert parse(docstring.short_description) == docstring

    docstring = parse(docstring.short_description)
    docstring.long_description = docstring.short_description
    assert parse(docstring.long_description) == docstring


# Generated at 2022-06-11 21:38:05.534341
# Unit test for function parse
def test_parse():
    text = """\
    This function converts a string s to an integer.  If
    base is provided, then the conversion will be in that
    base.  If base is not provided, the base defaults to 10.

    :param s: The string to convert to an integer.
    :param base: The base in which to interpret s;
        default is 10.
    :raises ValueError: If the string cannot be parsed as
        an integer.
    :returns: The integer represented by the string.

    """
    expected = parse(text)
    expected.short_description = "This function converts a string s to an integer.  If\nbase is provided, then the conversion will be in that\nbase.  If base is not provided, the base defaults to 10."
    expected.blank_after_short_description = False
    expected.blank_after_

# Generated at 2022-06-11 21:38:16.814295
# Unit test for function parse
def test_parse():
    f = open('tests/docstring.txt', 'r')
    docstring = f.read()
    f.close()

    parsed_docstring = parse(docstring)
    for m in parsed_docstring.meta:
        if isinstance(m, DocstringParam):
            print("key: {}, type: {}, is_optional: {}, default: {}".format(m.key, m.type_name, m.is_optional, m.default))
        elif isinstance(m, DocstringRaises):
            print("key: {}, type_name: {}, is_generator: {}".format(m.key, m.type_name, m.is_generator))
    print("---\n{}".format(parsed_docstring.long_description))

# test_parse()

# Generated at 2022-06-11 21:38:24.500074
# Unit test for function parse
def test_parse():
    docstring = """Summarize the first paragraph
    
    This is the long description.
    """
    assert parse(docstring) == Docstring(
        short_description="Summarize the first paragraph",
        blank_after_short_description=False,
        long_description="This is the long description.",
        blank_after_long_description=True,
        meta=[],
    )

    docstring = 'Summarize the first paragraph\n\n    This is the long description.\n'
    assert parse(docstring) == Docstring(
        short_description="Summarize the first paragraph",
        blank_after_short_description=True,
        long_description="This is the long description.",
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-11 21:38:35.310084
# Unit test for function parse
def test_parse():
    """Unit tests for function parse"""
    text = """
    Short description.

    Long description.

    :param type arg_name: arg description
    :returns: return description
    :raises Exception: raise description
    :param type? arg_name2: arg description 2
    """

# Generated at 2022-06-11 21:38:51.709076
# Unit test for function parse

# Generated at 2022-06-11 21:39:02.385050
# Unit test for function parse
def test_parse():
    test_str = """
        Shor_description

        Long_description

        :type arg_name: type
        :param arg_name: description

        :returns: type

        :yields: type

        :raises: type
    """
    doc = parse(test_str)
    assert doc.short_description == "Shor_description"
    assert doc.long_description == "Long_description"
    assert doc.meta[0] == DocstringParam(
        args=["type", "arg_name", "type"],
        description="description",
        arg_name="arg_name",
        type_name="type",
        is_optional=None,
        default=None,
    )

# Generated at 2022-06-11 21:39:14.886786
# Unit test for function parse
def test_parse():
    desc = """
    Short description.

    Long description.

    :param arg_name: description
    :type arg_name: type name
    """
    doc = parse(desc)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert len(doc.meta) == 1
    assert doc.meta[0].arg_name == "arg_name"
    assert doc.meta[0].type_name == "type name"
    assert doc.meta[0].description == "description"

    desc = """
    Short.

    Long.

    :param arg_name: description
    :type arg_name: type name
    :param arg_name2: description
    :type arg_name2: type name
    """
    doc = parse(desc)

# Generated at 2022-06-11 21:39:24.868830
# Unit test for function parse
def test_parse():
    """
    Tests if everything is working properly.
    """
    text = """
    Returns a cute unicorn.
    
    This is a long description.

    What this is is a unicorn that returns something.

    :type a: int
    :rtype: str
    :raises ValueError: If input is incorrect.
    :returns: Cute string.
    """
    doc = parse(text)
    assert doc.short_description == "Returns a cute unicorn."
    assert doc.long_description == "This is a long description.\n\n" + \
        "What this is is a unicorn that returns something."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3

# Generated at 2022-06-11 21:39:37.462951
# Unit test for function parse
def test_parse():
    docstring = '''
        Helper function to parse numpy docstrings.

        Parameters
        ----------
        text : str
            Docstring to parse.

        Returns
        -------
        parsed : `Docstring`
            Parsed docstring into its components
        '''
    ret = parse(docstring)
    assert ret.short_description == 'Helper function to parse numpy docstrings.'
    assert ret.blank_after_short_description
    assert ret.long_description == 'Parameters\n--------\ntext : str\n    Docstring to parse.\n\nReturns\n-------\nparsed : `Docstring`\n    Parsed docstring into its components'
    assert not ret.blank_after_long_description

# Generated at 2022-06-11 21:39:49.695635
# Unit test for function parse
def test_parse():
    docstring_text = """
    Describe your function here.
    :param type_name arg_name: Describe this parameter.
    :param AnotherType name: Another description
    :returns: describe return value
    :raises ExceptionName: describe an exception
    """
    docstring_object = parse(docstring_text)

    assert docstring_object.short_description == "Describe your function here."
    assert docstring_object.blank_after_short_description is False
    assert docstring_object.long_description == ""
    assert docstring_object.blank_after_long_description is False
    assert len(docstring_object.meta) == 4
    assert docstring_object.meta[0].args == ["param", "type_name", "arg_name"]


# Generated at 2022-06-11 21:39:58.218422
# Unit test for function parse
def test_parse():
    print("Test function parse: start")
    doc = """
    This function adds two numbers together

    :param a: The first number
    :param b: The second number
    :param c: The third number
    :raise TypeError: When either argument is not a number
    :returns: Sum of a and b
    """

# Generated at 2022-06-11 21:40:07.329068
# Unit test for function parse
def test_parse():
    """Tests the parse function."""
    func = '''
    """Tests the parse function.

    :param x: a sample parameter
    :type x: int
    :param y: another sample parameter, defaults to 5.
    :returns: a result
    :rtype: float
    :raises StopIteration: if it's bad
    """
    '''
    # func = x.__doc__
    func = func.strip()
    actual = parse(func)
    assert not actual.short_description
    assert not actual.long_description
    assert actual.blank_after_short_description
    assert actual.blank_after_long_description
    assert len(actual.meta) == 3
    assert actual.meta[0].description == "a sample parameter" and actual.meta[0].type_name == "int"


# Generated at 2022-06-11 21:40:16.271916
# Unit test for function parse
def test_parse():
    text = """\
    Sum of arguments.

    :param int x1: Some argument.
    :param x2: Another argument. Defaults to 10.
    :param int x3? Some optional argument.
    """

# Generated at 2022-06-11 21:40:22.655287
# Unit test for function parse
def test_parse():
    text="""\
    Short description.

    Long description.
    """
    print(parse(text))

    text="""\
    Short description.

    Long description.

    :yields: Yields description.
    """
    print(parse(text))

    text="""\
    Short description.

    Long description.

    :param type_name? arg_name: Param description.
    """
    print(parse(text))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:40:37.467611
# Unit test for function parse
def test_parse():
    def test_parse_inner(doc, pyh):
        pyh_file = open(pyh, 'r')
        pyh = pyh_file.read()
        pyh_file.close()
        assert parse(doc) == parse(pyh)

    test_parse_inner('"""This is a docstring"""', 'test/test_doc.pyh')

# Generated at 2022-06-11 21:40:47.671552
# Unit test for function parse
def test_parse():
    """Test function parse."""
    doc = parse("""\
        This is a description.

        Parameters
        ----------
        arg: str
            A string parameter.
        arg2: int
            An integer parameter.
        arg3 : unicode
            A unicode parameter.
        arg4 : str, optional
            An optional str parameter.
        arg5 : str?
            An optional str parameter.

        Returns
        -------
        None
            A return value.

        Raises
        ------
        Exception
            An exception.
        """)
    assert doc.short_description == "This is a description."
    assert doc.blank_after_short_description == False

# Generated at 2022-06-11 21:40:55.297551
# Unit test for function parse
def test_parse():
    for test in tests:
        assert str(parse(test)) == str(test_outputs[tests.index(test)])


# Generated at 2022-06-11 21:40:59.803910
# Unit test for function parse
def test_parse():
    print(parse('''
    This is the title

    This is the comment.

    :param name: This is the name
    :param username: This is the username
    :keyword name: This is the name
    :return: This is the return value
    :raises: Exception
    :raises ValueError:
    '''))


# Generated at 2022-06-11 21:41:07.281177
# Unit test for function parse
def test_parse():
    d = parse(test_parse.__doc__)
    assert d.short_description == 'Unit test for function parse'
    assert d.long_description == ':param s: a string'
    assert d.blank_after_long_description == True
    assert d.blank_after_short_description == False
    assert d.meta[0].keyword == 'param'
    assert d.meta[0].arg_name == 's'
    assert d.meta[0].type_name == 'str'


# Generated at 2022-06-11 21:41:07.957916
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-11 21:41:18.289277
# Unit test for function parse
def test_parse():
    docstring = "Documentation for a function.\nWith a second line." \
    "\n\n:param arg1: The first parameter.\n:type arg1: str\n" \
    "\n\n:returns: None\n:rtype: NoneType\n" 
    docstring_parsed = parse(docstring)
    docstring_parsed_expected = Docstring()
    docstring_parsed_expected.short_description = "Documentation for a function."
    
    docstring_parsed_expected.blank_after_short_description = False
    docstring_parsed_expected.blank_after_long_description = True
    
    docstring_parsed_expected.long_description = "With a second line."

# Generated at 2022-06-11 21:41:26.779229
# Unit test for function parse
def test_parse():
    doc = parse("""
    Args:
        foo
        bar: This is a description.
        baz (int): This is a description.
        quux: Optional[Union[int, str]]: This is a description.
        quuz: str: This is a description.
    """
    )
    assert len(doc.meta) == 5
    assert len(doc.meta[0].args) == 1
    assert doc.meta[0].description is None
    assert doc.meta[1].description == "This is a description."
    assert len(doc.meta[2].args) == 3
    assert doc.meta[2].type_name == 'int'
    assert doc.meta[3].type_name == 'Optional[Union[int, str]]'
    assert doc.meta[4].type_name == 'str'



# Generated at 2022-06-11 21:41:37.835729
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("   ") == Docstring()
    assert parse("foo") == Docstring(
        short_description="foo", blank_after_short_description=False,
    )
    assert parse("foo\n") == Docstring(
        short_description="foo", blank_after_short_description=True,
    )
    assert parse("foo\n\n") == Docstring(
        short_description="foo", blank_after_short_description=True,
    )
    assert parse("foo\nbar") == Docstring(
        short_description="foo",
        blank_after_short_description=False,
        long_description="bar",
        blank_after_long_description=False,
    )

# Generated at 2022-06-11 21:41:48.711408
# Unit test for function parse
def test_parse():
    assert parse(None) == Docstring()
    assert parse("") == Docstring()
    assert parse("\n") == Docstring(blank_after_short_description=True)
    assert parse("\n\n") == Docstring(blank_after_short_description=True)
    assert parse("\n\n\n") == Docstring(blank_after_short_description=True)
    assert parse("foo") == Docstring(short_description="foo")
    assert parse("foo\n") == Docstring(
        short_description="foo", blank_after_short_description=True
    )
    assert parse("foo\n\n") == Docstring(
        short_description="foo", blank_after_short_description=True,
    )

# Generated at 2022-06-11 21:42:07.020713
# Unit test for function parse
def test_parse():
    docstring = '''First line of docstring.
    :param str name:
        The name. Defaults to "John".
    :param int age: The age.
    :param bool is_happy:
        Is the person happy?
    :returns:
        bool: True if the person is happy,
        False otherwise.
    '''
    test1 = parse(docstring)
    assert test1.short_description == 'First line of docstring.'
    assert test1.blank_after_short_description == True
    assert test1.blank_after_long_description == True
    assert test1.long_description is None
    assert len(test1.meta) == 3
    assert test1.meta[0].args[0] == 'param'
    assert test1.meta[0].args[1] == 'str'


# Generated at 2022-06-11 21:42:11.721640
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.
    """

    res = parse(docstring)
    assert len(res.short_description) > 0
    assert len(res.long_description) > 0



# Generated at 2022-06-11 21:42:16.854726
# Unit test for function parse
def test_parse():
    s = """simple docstring.
    
    :Args:
      x: the x coord
      y: the y coord
      
    :Returns:
      x+y
    """

    ds = parse(s)
    assert len(ds.meta) == 2
    assert ds.meta[0].tag == 'Args'
    assert ds.meta[0].args == ['x', 'the x coord']
    assert ds.meta[0].description == 'the x coord'
    assert ds.meta[1].tag == 'Returns'
    assert ds.meta[1].args == ['x+y']
    assert ds.meta[1].description == 'x+y'
    assert ds.short_description == 'simple docstring.'
    assert ds.long_description == 'the y coord'



# Generated at 2022-06-11 21:42:21.385808
# Unit test for function parse
def test_parse():
    import unittest

    class ParseTest(unittest.TestCase):

        def test_basic(self):
            text = """A short description.

            This is a long description. The short description is up above.

            :param foo: A foo parameter.
            :param bar: A bar parameter.
            """

            doc = parse(text)

            self.assertEqual(
                doc.short_description, "A short description."
            )
            self.assertTrue(doc.blank_after_short_description)
            self.assertEqual(
                doc.long_description,
                "This is a long description. The short description is up above.",
            )
            self.assertTrue(doc.blank_after_long_description)

            self.assertEqual(len(doc.meta), 2)
            self.assertEqual

# Generated at 2022-06-11 21:42:28.904849
# Unit test for function parse
def test_parse():
    # :raises TypeError: if the integer is not even
    docstring = """\
        Add two numbers together.

        :param x: The first number.
        :type x: int
        :param y: The second number.
        :type y: int
        :returns: The result.
        :rtype: int
        :raises TypeError: If the passed arguments are not numbers.
        :returns: The result.
        :rtype: int
        """
    print(parse(docstring))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:42:35.725291
# Unit test for function parse
def test_parse():
    result = parse("""
    This is a test docstring.

    It has a short description.

    And a long one.
    """)


    assert result.short_description == "This is a test docstring."
    assert result.long_description == "It has a short description.\nAnd a long one."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert len(result.meta) == 0

# Generated at 2022-06-11 21:42:48.405783
# Unit test for function parse
def test_parse():
    """Tests for ReST-style docstring parsing."""


# Generated at 2022-06-11 21:42:57.891001
# Unit test for function parse
def test_parse():
    docstring = """Single line docstring.

This is a longer description of the function.
:param int parameter1 : This is first parameter.
:param bool parameter2: This is second parameter.
:returns: This is return.
:raises ValueError: This raises ValueError.
:yields: This yields.
:yields: This yields with type.
:raises: This raises.
:raises: This raises with type.
:param parameter3: This is third parameter without type.
"""

# Generated at 2022-06-11 21:43:09.690975
# Unit test for function parse

# Generated at 2022-06-11 21:43:19.035535
# Unit test for function parse
def test_parse():
    simple_docstring = "This is a python docstring\n" \
                       "\n" \
                       ":type param1: str\n" \
                       ":param param1: some param\n" \
                       ":type param2: str\n" \
                       ":param param2: some other param\n" \
                       ":returns: list of strings\n" \
                       ":raises ReturnError: when some error occurs"
    simple_docstring_obj = parse(simple_docstring)

    assert type(simple_docstring_obj.meta) is list
    assert type(simple_docstring_obj.meta[0]) is DocstringMeta
    assert simple_docstring_obj.meta[0].args == ["type", "param1", "str"]
    assert simple_docstring_obj.meta[0].description

# Generated at 2022-06-11 21:43:41.609917
# Unit test for function parse

# Generated at 2022-06-11 21:43:49.060478
# Unit test for function parse
def test_parse():
    """Test function parse."""
    # Not checking everything here, just a few items
    docstring = parse(__doc__)
    assert docstring.short_description == "ReST-style docstring parsing."

    # Iterate through all items in the meta list
    for item in docstring.meta:
        # Check we can access some attributes of the object
        assert hasattr(item, "args")
        assert hasattr(item, "description")

# Generated at 2022-06-11 21:43:58.077604
# Unit test for function parse
def test_parse():
    assert inspect.cleandoc(parse('foo\n').short_description) == 'foo'
    assert inspect.cleandoc(parse('foo\n\n').long_description) == ''
    assert inspect.cleandoc(parse('foo:bar\n').short_description) == 'foo'
    assert inspect.cleandoc(parse('foo:bar\n').meta[0].description) == 'bar'
    assert inspect.cleandoc(parse('foo:bar\n\n').long_description) == ''
    assert inspect.cleandoc(parse('foo\n\nbar\n').long_description) == 'bar'
    assert inspect.cleandoc(parse('foo\n\nbar\n\nbaz\n').long_description) == 'bar\nbaz'

# Generated at 2022-06-11 21:44:09.979239
# Unit test for function parse

# Generated at 2022-06-11 21:44:13.460357
# Unit test for function parse
def test_parse():
    # String of Code
    code = """
    Simple function definition.

    :param a:
    :param b:
    :type  b: int
    :returns: a+b
    :rtype: int

    More elaborate description of what happens here.

    >>> code(1)
    2
    """
    parse(code)


# Generated at 2022-06-11 21:44:18.861710
# Unit test for function parse
def test_parse():

    # ************
    # test cases
    # ************
    # pass-case 1
    doc1 = """
    Short single line description

    More detailed description.

    :param x: Description of x
    :param y: Description of y
    :returns: Description of return value
    :raises KeyError: Description of KeyError
    """

# Generated at 2022-06-11 21:44:28.753173
# Unit test for function parse
def test_parse():
    docstring = """Function summary line goes here.
    Longer description goes here.

    :param int x: Parameter description
    :raises Exception: Raises description
    :returns: Returns description
    :rtype: str
    """

# Generated at 2022-06-11 21:44:39.849609
# Unit test for function parse

# Generated at 2022-06-11 21:44:45.873935
# Unit test for function parse
def test_parse():
    docstring = parse(text)
    assert docstring.short_description == 'My custom library'
    assert docstring.long_description is not None
    assert docstring.long_description == 'This is my library for doing great things.\n\nIt has a lot of neat features!'
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].key == 'param'
    assert docstring.meta[0].arg_name == 'my_param'
    assert docstring.meta[0].default == '1'
    assert docstring.meta[1].type_name == 'str'


# Example of ReST-style Docstring

# Generated at 2022-06-11 21:44:54.331502
# Unit test for function parse
def test_parse():
    docstring = """  Single-line docstring.

    :param arg: description of arg
    """

    parsed = parse(docstring)
    # Test attributes
    assert parsed.short_description == "Single-line docstring."
    assert not parsed.blank_after_short_description
    assert parsed.long_description == None
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 1
    # Test parsing of meta
    assert parsed.meta[0].args == ["param", "arg"]
    assert parsed.meta[0].description == "description of arg"
    # Test parsing of a non-empty docstring
    assert parsed.__str__() == docstring


# Generated at 2022-06-11 21:45:05.159341
# Unit test for function parse
def test_parse():
    if parse:
        return
    if True:
        parse = parse



# Generated at 2022-06-11 21:45:10.570227
# Unit test for function parse
def test_parse():
    docstring = """\
    Short description.

    Long description.

    :param arg: This is the first argument.
    :type arg: This is a type, which may span multiple lines.
      Following lines will be indented by 4 spaces.

    :param int arg: This argument has type and description.
      The description continues here.
      And here.

    :return: This is something, which is returned.
    :rtype: int

    :raises AttributeError: The __init__() method should raise
                            AttributeError when ...
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description."
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ["param", "arg"]

# Generated at 2022-06-11 21:45:17.564940
# Unit test for function parse
def test_parse():
    docstring = """
The one-line description.

The detailed description.

:param foo: First parameter.
:param bar: Second parameter.
:param baz: Third parameter, defaults to None.
:return: None
:rtype: None
:raises ValueError: If `foo` is not equal to `bar`.
:raises AttributeError: If `baz` is None.
"""
    print(parse(docstring))


# Generated at 2022-06-11 21:45:28.265207
# Unit test for function parse
def test_parse():
    doc = "Test of the parse function\n"
    doc += ":param int arg1: test arg\n"
    doc += ":param str arg2: test arg\n"
    doc += ":param int arg3: optional test arg\n"
    doc += ":rtype: str"
    p = parse(doc)

    assert p.short_description == "Test of the parse function"
    assert p.long_description is None
    assert p.blank_after_short_description is False
    assert p.blank_after_long_description is False

    assert len(p.meta) == 4
    assert p.meta[0].key == "param"
    assert p.meta[0].arg_name == "arg1"
    assert p.meta[0].type_name == "int"

# Generated at 2022-06-11 21:45:38.523366
# Unit test for function parse
def test_parse():
    sample_docstring = """\
Parse the ReST-style docstring into its components.

:param str foo: this is a foo
:param int bar: this is a bar
:returns: parsed docstring
:rtype: Docstring
"""
    docstring = parse(sample_docstring)

    # Test the Docstring.__eq__ method

# Generated at 2022-06-11 21:45:49.700561
# Unit test for function parse
def test_parse():
    # The docstring below is copied from the module sphinx
    docstring = '''
    Parse a docstring into its constituent parts.

    :param str text: the raw docstring text
    :returns: a Docstring, whose attributes correspond to the
        sections of the docstring. A docstring section is a
        list of lines in that section; the attributes include
        all sections that were found in the docstring, even
        those that were empty.
    :raises ParseError: if an error occurred while parsing
        the docstring.

    .. versionadded:: 1.4
    '''
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == 'Parse a docstring into its constituent parts.'

# Generated at 2022-06-11 21:46:01.318973
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstr = '''
    Short desc.

    Really long desc.

    :param int x: X-coordinate.
    :param int y: Y-coordinate.
    :param str color: color of the field.
    :return: color of the field.
    :rtype: str
    '''

# Generated at 2022-06-11 21:46:13.845745
# Unit test for function parse
def test_parse():
    docstring = '''Check if all items in the iterable are true (or if the iterable is empty).

Args:
    iterable: The iterable to check.

Returns:
    bool: True if all items in the iterable are true (or if the iterable is empty).

Raises:
    TypeError: If iterable is not iterable.
    Args:
        iterable: The iterable which could not be used.
    Description:
        An exception was raised trying to use the iterable.
'''
    ret = parse(docstring)
    print(ret)
    print(ret.short_description)
    print(ret.long_description)
    print(ret.blank_after_short_description)
    print(ret.blank_after_long_description)
    print(ret.meta)

# Generated at 2022-06-11 21:46:25.564344
# Unit test for function parse
def test_parse():
    docstr = """Short description

    Long description.

    :param a: First parameter
    :type a: int
    :param b: Second parameter
    :type b: dict
    :returns: A tuple
    :rtype: (int, dict)
    :raises: Exception
    """

    doc = parse(docstr)
    assert doc.short_description == "Short description"
    assert doc.long_description == "Long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True

    assert doc.meta[0].arg_name == "a"
    assert doc.meta[0].type_name == "int"
    assert doc.meta[0].description == "First parameter"
    assert doc.meta[0].default is None
    assert doc.meta

# Generated at 2022-06-11 21:46:36.326334
# Unit test for function parse
def test_parse():
    test_docstring = """
    Short description.

    Long description.

    :param x: foo
    :param y: bar
    :raises: TypeError for bad x
    :raises IndexError for bad y
    """
    ds = parse(test_docstring)
    assert ds.short_description == "Short description."
    assert ds.long_description == "Long description."
    assert not ds.blank_after_short_description
    assert not ds.blank_after_long_description
    assert len(ds.meta) == 4
    for v in ds.meta:
        if v.arg_name == "x":
            assert v.description == "foo"
        elif v.arg_name == "y":
            assert v.description == "bar"