

# Generated at 2022-06-11 21:36:59.746161
# Unit test for function parse
def test_parse():
    doc = parse("""\
    This is a short description.

    This is a long description.

    :param str name: The name of a person.  Defaults to ``'world'``.
    :raises ValueError: The name must not be empty.
    :returns: The greeting.
    """)

    assert doc.short_description == "This is a short description."

    assert doc.long_description == "This is a long description."

    meta = doc.meta

    assert len(meta) == 2
    assert meta[0].args == ["param", "str", "name"]
    assert meta[0].description == "The name of a person.  Defaults to ``'world'``."
    assert meta[0].arg_name == "name"
    assert meta[0].type_name == "str"

# Generated at 2022-06-11 21:37:09.112393
# Unit test for function parse

# Generated at 2022-06-11 21:37:20.306496
# Unit test for function parse
def test_parse():
    assert parse("This is a function. (With one sentence.)") == Docstring(
        short_description="This is a function.",
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description=None,
        meta=[],
    )
    assert parse("This is a function.\n\n(With two paragraphs.)") == Docstring(
        short_description="This is a function.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="(With two paragraphs.)",
        meta=[],
    )

# Generated at 2022-06-11 21:37:29.242595
# Unit test for function parse
def test_parse():

    text = """Test parsing

    :param key:
    :param value:

    :returns:
    :rtype:
    """

    ds = parse(text)

    print(ds.short_description)

    print(ds.long_description)

    print(ds.blank_after_short_description)

    print(ds.meta)

    print(ds.meta[0])

    print(ds.meta[0].arg_name, ds.meta[0].type_name)

    print(ds.meta[1])

    print(ds.meta[1].type_name)


# Generated at 2022-06-11 21:37:35.678039
# Unit test for function parse

# Generated at 2022-06-11 21:37:44.174258
# Unit test for function parse

# Generated at 2022-06-11 21:37:54.344014
# Unit test for function parse
def test_parse():
    docstring = """\
        A short description of the function.

        A long description of the function.

        :param name: description of name param
        :param surname: description of surname param
        :type surname: str
        :return: description of return value
        :rtype: int
        :raises ValueError: description of exception
        :raises KeyError: description of another exception
        :returns: description of function return value
        :yields: description of yield value
        :yields string: description of yielded string
        :returns: description of return value
        :yields str: description of return value
        :param name: description of name parameter
        :param name: description of name parameter
        """
    parsed_string = parse(docstring)
    args = ['name', 'description of name param']
    meta1 = Doc

# Generated at 2022-06-11 21:38:05.863638
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc("""
    Short description
    Long description

    :param x: short desc
    :param y: short desc
    :param z: short desc
    :raises ValueError: short desc
    :returns: short desc
    :returns int: short desc

    """)

    par = parse(docstring)
    assert par.short_description == 'Short description'
    assert par.long_description == 'Long description'
    assert par.blank_after_short_description == True
    assert par.blank_after_long_description == False

    assert par.meta[0].arg_name == 'x'
    assert par.meta[0].type_name is None
    assert par.meta[0].is_optional is None
    assert par.meta[0].default is None
    assert par.meta

# Generated at 2022-06-11 21:38:17.080703
# Unit test for function parse
def test_parse():
    """Parse docstring """

    import unittest
    import textwrap

    #import lib.rstdoc as liubr

    class TestParse(unittest.TestCase):

        def setUp(self):
            self.docstring = textwrap.dedent(
                """\
            Spam, spam & spam

            :param eggs: A number of eggs
            :type eggs: int
            :param toast: Slice of toast
            :param ham: Ham

            :Returns: A dict of ingredients.
            :Return type: dict

            :Raises ValueError: If the args are wrong.

            :param bool bacon: Bacon
            :return: Eggs, toast and ham
            :rtype: dict
            :raises KeyError: If there is no ham.
            """
            )


# Generated at 2022-06-11 21:38:23.203161
# Unit test for function parse
def test_parse():
    text = '''
    Decodes a Base64 encoded string into a byte string.

    :param base64_input: Base64 encoded string to be decoded
    :type base64_input: str
    :returns: Decoded byte string
    :raises: binascii.Error
    '''
    result = parse(text)
    assert len(result.meta) == 3
    assert isinstance(result.meta[0], DocstringParam)
    assert isinstance(result.meta[1], DocstringReturns)
    assert isinstance(result.meta[2], DocstringRaises)

# Generated at 2022-06-11 21:38:39.624446
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    docstring = """Single line docstring.

    Multiline and indented docstring."""
    assert parse(docstring).dump() == """{
    "short_description": "Single line docstring.",
    "long_description": "Multiline and indented docstring.",
    "blank_after_short_description": false,
    "blank_after_long_description": false,
    "meta": []
}"""

    docstring = """Single line docstring.

    :returns: The last line."""

# Generated at 2022-06-11 21:38:50.097271
# Unit test for function parse
def test_parse():
    docstring = parse("""
    Hello, world!

    :param name: The name of the person.
    :param age: Person's age

    :returns:
        The output of the function
        for the given input.

    :raises StopIteration: if the data is exhausted.
    """)
    assert docstring.short_description == 'Hello, world!'
    assert docstring.long_description is not None
    assert docstring.long_description == """
    The output of the function
    for the given input."""
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is False
    assert docstring.meta[0].description == 'The name of the person.'
    assert docstring.meta[1].description == "Person's age"
    assert docstring.meta

# Generated at 2022-06-11 21:39:02.085214
# Unit test for function parse
def test_parse():
    docstring = '''
    Short description.

    Long description.

    :param abc: bla.
    :param type: bla? defaults to True.
    :type abc: str
    :returns: this is the return value.
    :rtype: bool
    '''
    doc = parse(docstring)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ['param', 'abc']
    assert doc.meta[0].description == 'bla.'
    assert doc.meta[1].args == ['type', 'abc']

# Generated at 2022-06-11 21:39:14.615080
# Unit test for function parse

# Generated at 2022-06-11 21:39:24.803881
# Unit test for function parse

# Generated at 2022-06-11 21:39:37.377208
# Unit test for function parse
def test_parse():
    """
    Test that the parsed docstring is being parsed correctly.
    """

    docstring = inspect.cleandoc(
        """
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """
    )

    # Perform checks on the resulting docstring
    parse_docstring = parse(docstring)

    # Check that the short description is correct
    assert parse_docstring.short_description == "Parse the ReST-style"
    # Check that the long description is correct
    assert parse_docstring.long_description == "docstring into its components."
    # Check that the meta information is correct
    assert parse_docstring.meta[0].args == ["returns"]
    assert parse_docstring.meta[0].description == "parsed docstring"
    # Check that the

# Generated at 2022-06-11 21:39:49.694856
# Unit test for function parse
def test_parse():
    """The following text is the example in the docstring"""
    text = """Short description.

Long description. Long description. Long description. Long description.

:param test: test param description
:type test: int
:returns: test returns description
:rtype: str
:raises test: test raises description

"""
    docstring = parse(text)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description. Long description. Long description. Long description."
    assert docstring.meta[0].args[0] == "param"
    assert docstring.meta[0].args[1] == "test"
    assert docstring.meta[0].args[2] == "int"
    assert docstring.meta[0].description == "test param description"

# Generated at 2022-06-11 21:39:58.218455
# Unit test for function parse
def test_parse():
    text = '''\
    This method adds two numbers and returns their sum.

    :param a: first addend
    :param b: second addend
    :type a: float
    :type b: float
    :returns: a + b
    :rtype: float
    '''

# Generated at 2022-06-11 21:40:07.334861
# Unit test for function parse
def test_parse():
    docstring = r"""
    This function does something.
    
    :param x: An integer.
    :returns: x + 1
    
    >>> parse('Nothing')
    >>> parse('Something')
    
    
    
    """
    result = parse(docstring)
    assert result.long_description == 'This function does something.'
    assert len(result.meta) == 1
    assert isinstance(result.meta[0], DocstringParam)
    assert result.meta[0].arg_name == 'x'
    assert result.meta[0].type_name == 'An integer.'
    assert result.meta[0].is_optional is None
    assert result.meta[0].default is None
    assert result.meta[0].description == 'x + 1'
    assert result.short_description == 'This function does something.'

# Generated at 2022-06-11 21:40:16.297997
# Unit test for function parse
def test_parse():
    func_docstring = (
        "This is a test docstring which is \n"
        "a little longer than usual.\n"
        "\n"
        ":param str var1: this is a variable\n"
        ":ivar int var2: this is a variable again\n"
        ":returns :\n"
        "   The return value."
        ":raises ValueError: if invalid value\n"
        ":meta bool whatever: True if it works"
    )
    docstring = parse(func_docstring)
    assert docstring.short_description == "This is a test docstring which is"
    assert docstring.long_description == "a little longer than usual."
    assert docstring.blank_after_short_description == True

# Generated at 2022-06-11 21:40:32.887783
# Unit test for function parse

# Generated at 2022-06-11 21:40:43.971459
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Function with no docstring.") == Docstring(
        short_description="Function with no docstring."
    )

    assert parse("Function with a short docstring.\n") == Docstring(
        short_description="Function with a short docstring."
    )

    assert parse("\nFunction with a short docstring followed by blank line.") == Docstring(
        short_description="Function with a short docstring followed by"
        " blank line.",
        blank_after_short_description=True
    )

    assert parse("\n""Function with a short docstring preceded by blank line.""") == Docstring(
        short_description="Function with a short docstring preceded by"
        " blank line."
    )


# Generated at 2022-06-11 21:40:54.014481
# Unit test for function parse
def test_parse():
    assert parse('Takes input, performs computation and returns an output.') == Docstring(
        short_description="Takes input, performs computation and returns an output.",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse('Takes input, performs computation and returns an output.\n  This algorithm is based on LALR(1).\n') == Docstring(
        short_description="Takes input, performs computation and returns an output.",
        long_description="This algorithm is based on LALR(1).",
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-11 21:41:02.456858
# Unit test for function parse
def test_parse():
    docstring = """\
This is a test function.

:param foo: This is foo.
:type foo: int
:param bar: This is bar.
:type bar: str
:param baz: This is baz.
:return: This is oops.
"""
    actual = parse(docstring)
    print(actual)
    assert actual.short_description == "This is a test function."
    assert len(actual.meta) == 4
    assert actual.meta[0].description == "This is foo."
    assert actual.meta[1].description == "This is bar."
    assert actual.meta[2].description == "This is baz."
    assert actual.meta[3].description == "This is oops."

# Generated at 2022-06-11 21:41:06.122839
# Unit test for function parse
def test_parse():
    s = """
        foo_bar: foo
        """
    docstring = parse("")
    assert docstring == Docstring()



# Generated at 2022-06-11 21:41:10.962521
# Unit test for function parse
def test_parse():
    s = r"""
    Args:
        a: a
        b: b
    """
    assert parse(s).meta[0].description == "a"
    s = r"""
    Args:
        a: a
        b: b
    Retunrs:
        c: c
    """
    assert parse(s).meta[1].description == "c"

# Generated at 2022-06-11 21:41:15.944365
# Unit test for function parse
def test_parse():
    assert parse('hello') == parse('hello\n')
    assert parse('hello') == parse('hello\n\n')
    assert parse('hello\nw') == parse('hello\n\nw')
    assert parse('hello\nw') == parse('hello\n\nw\n')
    assert parse('hello\nw') == parse('hello\n\nw\n\n')
    assert parse('hello\nw') == parse('\nhello\n\nw\n\n')



# Generated at 2022-06-11 21:41:23.559551
# Unit test for function parse
def test_parse():
    docstr = """
    Example.

    :param int age: Age.
    :param int weight: Weight.
    """
    parsed = parse(docstr)
    # should have an int age argument with no default
    assert parsed.meta[0].arg_name == 'age'
    assert parsed.meta[0].type_name == 'int'
    assert parsed.meta[0].default == None
    # should have an int weight argument with no default
    assert parsed.meta[1].arg_name == 'weight'
    assert parsed.meta[1].type_name == 'int'
    assert parsed.meta[1].default == None
    # should have a short description and no long description
    assert parsed.short_description == 'Example.'
    assert parsed.long_description == None


# Generated at 2022-06-11 21:41:35.034602
# Unit test for function parse
def test_parse():
    doc = (
        "This is a short description\n\n"
        "A paragraph can be put here. Leading and trailing whitespace are "
        "stripped.\n"
        "And it can be several lines long.\n\n"
        "This paragraph is not indented like this one is.\n"
        "This means the previous paragraph is separate.\n\n"
        ":param x: the x parameter\n"
        ":type x: str\n\n"
        ":param y: the y parameter\n"
        ":returns: returns a value\n"
        ":raises ValueError: when something goes wrong\n"
        ":raises TypeError: when another thing goes wrong\n"
    )

# Generated at 2022-06-11 21:41:45.952866
# Unit test for function parse
def test_parse():
    docstring = """first line
    Second line
    with stuff in the middle
    :param para: first para
    :param para2: second para
    :return ret: return value
    :raises TypeError:
    """
    docobj = parse(docstring)
    assert docobj.short_description == "first line"
    assert docobj.long_description == "Second line\nwith stuff in the middle"
    assert len(docobj.meta) == 4
    assert docobj.meta[0].args[0] == "para"
    assert docobj.meta[1].args[0] == "para2"
    assert docobj.meta[2].args[0] == "ret"
    assert docobj.meta[3].args[0] == "raises"

# Generated at 2022-06-11 21:42:02.997098
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring(short_description=None)
    assert parse("\n\n") == Docstring(short_description=None)
    assert parse("foo\n") == Docstring(short_description="foo")
    assert parse("foo\n\n") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )
    assert parse("foo\n\nbar") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        long_description="bar",
    )

# Generated at 2022-06-11 21:42:11.169439
# Unit test for function parse
def test_parse():
    # one line for short and long
    # one line for param
    # one line for return
    text = """\
    short
    long
    :param a: a desc
    :return: nothing
    """
    assert parse(text) == Docstring(
        short_description="short",
        long_description="long",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[
            DocstringParam(
                arg_name="a",
                arg_type=None,
                arg_optional=None,
                arg_default=None,
                description="a desc",
            ),
            DocstringReturns(arg_type=None, description="nothing"),
        ],
    )

    # define everything in one line

# Generated at 2022-06-11 21:42:22.122459
# Unit test for function parse
def test_parse():
    d = parse("hello")
    assert d.short_description == "hello"

    d = parse("hello\nworld")
    assert d.short_description == "hello"
    assert d.long_description == "world"

    d = parse("hello\nworld\n")
    assert d.short_description == "hello"
    assert d.long_description == "world"
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False

    d = parse("hello\n\nworld")
    assert d.short_description == "hello"
    assert d.long_description == "world"
    assert d.blank_after_short_description is True
    assert d.blank_after_long_description is False

    d = parse("hello\n\nworld\n")

# Generated at 2022-06-11 21:42:26.853750
# Unit test for function parse
def test_parse():
    """Function to unit test function parse()"""
    source_code = '''\
        """Test how the function parse() parses the docstrings.

        This function takes three arguments:
        :param a: first argument
        :type a: int
        :param b: second argument
        :type b: bool, optional
        :param c: third argument, defaults to True.
        :type c: bool, optional

        :returns: fourth argument
        :rtype: str

        :raises: ValueError

        :yields:

        """
        '''
    parsed_docstring = parse(source_code)
    assert parsed_docstring.short_description == "Test how the function parse() parses the docstrings."
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_docstring.long_description

# Generated at 2022-06-11 21:42:33.413555
# Unit test for function parse
def test_parse():
    text = """Summary line.

    Extended description of function. Optional: more description.

    :param arg1: Description
    :type arg1: str
    :param arg2: Description
    :type arg2: int
    :returns: Description
    :rtype: bool
    :raises RuntimeError: Description
    :raises ValueError: Description
    :raises MyCustomException: Description

    """
    print(parse(text))



# Generated at 2022-06-11 21:42:40.794961
# Unit test for function parse
def test_parse():
    # Test empty docstring
    assert parse("") == Docstring()
    # Test simple one-line docstring with short description only
    doc = parse("Test short description only.")
    assert doc.short_description == "Test short description only."
    assert doc.blank_after_short_description is False
    # Test simple one-line docstring with short description ending with period
    doc = parse("Test short description only ending with period.")
    assert doc.short_description == "Test short description only ending with period."
    assert doc.blank_after_short_description is False
    # Test simple one-line docstring ending with period
    doc = parse('Test short description only. "Test long description"')
    assert doc.short_description == 'Test short description only.'
    assert doc.blank_after_short_description is True
    assert doc.long_description

# Generated at 2022-06-11 21:42:50.206685
# Unit test for function parse
def test_parse():
    docstring = '''\
        Compute the greatest common divisor (GCD) of two integers.
    
        This is the largest positive integer that divides both integers.
    
        :type a: int
        :type b: int
        :param a: First integer.
        :param b: Second integer.
        :returns: GCD of a and b.
        :rtype: int
    
        '''

# Generated at 2022-06-11 21:42:58.938192
# Unit test for function parse

# Generated at 2022-06-11 21:43:10.378935
# Unit test for function parse
def test_parse():
    code_exp = """
    :param str param1: This is the first parameter.
    :param int param2: This is the second parameter.
    :returns: This is a description of what is returned.
    :rtype: int
    """
    # test get_docstring_meta
    code_test = parse(code_exp)
    para1 = DocstringParam(args=['param1', 'str', 'param1'], description='This is the first parameter.', arg_name='param1', type_name='str', is_optional=False, default=None)
    para2 = DocstringParam(args=['param2', 'int', 'param2'], description='This is the second parameter.', arg_name='param2', type_name='int', is_optional=False, default=None)

# Generated at 2022-06-11 21:43:20.325216
# Unit test for function parse
def test_parse():
    """
    Test if can properly parse a doc string.
    """

# Generated at 2022-06-11 21:43:40.962528
# Unit test for function parse
def test_parse():
    s = """
    Short description.

    Long description.

    :param arg1: First argument.
    :type arg1: str
    :param arg2: Second argument.
    :type arg2: int
    :returns: A random string.
    :rtype: str
    :raises NameError: If the name is not found.
    """
    doc = parse(s)

    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert len(doc.meta) == 4
    assert doc.meta[0].key == "param"
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type_name == "str"
    assert doc.meta[0].description == "First argument."

# Generated at 2022-06-11 21:43:53.397403
# Unit test for function parse
def test_parse():
    """
    >>> result = parse("""

# Generated at 2022-06-11 21:44:06.047205
# Unit test for function parse
def test_parse():
    doc = """
    Short description.

    Long description.

    :param arg1: description
    :param arg2: description
    :rtype: description
    :returns: description
    :raises Exception: description
    """


# Generated at 2022-06-11 21:44:14.760627
# Unit test for function parse

# Generated at 2022-06-11 21:44:20.314501
# Unit test for function parse
def test_parse():
    print(parse('test parse'))
    print(parse(":param arg1: description for param arg1\n:param arg2: description for param arg2\n:return: description for return\n:raises: description for raise\n"))
    print(parse(":param arg1: description for param arg1\n:param arg2: description for param arg2\n:return:\n:raises:\n"))



# Generated at 2022-06-11 21:44:29.331406
# Unit test for function parse
def test_parse():
    class TestClass:
        """Summary.
        
        :param a: a parameter
        :type a: int
        :param b: another parameter
        :type b: str
        :returns: something
        :rtype: str

        Test. This is a test. Test test."""

    doc = parse(TestClass.__doc__)
    assert doc.short_description == "Summary."
    assert doc.long_description == "Test. This is a test. Test test."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 3
    assert isinstance(doc.meta[0], DocstringParam)
    assert isinstance(doc.meta[1], DocstringParam)

# Generated at 2022-06-11 21:44:40.052321
# Unit test for function parse
def test_parse():
    docstring = "Short description.\n\nLong description."
    doc = parse(docstring)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."

    docstring = "Must be a non-negative integer."
    doc = parse(docstring)
    assert doc.short_description == "Must be a non-negative integer."
    assert doc.long_description is None

    docstring = ":param foo: The foo parameter\n:type foo: int\n"
    doc = parse(docstring)

# Generated at 2022-06-11 21:44:43.754739
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    test = parse(
        """
    Test function.

    :param a: this is a
    :param b: this is b
    :returns: string
    """
    )

    assert len(test.meta) == 2
    assert test.meta[0].description == "this is a"
    assert test.meta[1].description == "string"



# Generated at 2022-06-11 21:44:53.613414
# Unit test for function parse
def test_parse():
    test_docstring_content = """
    This is a test docstring.
    It has an empty line.

    :param arg1: some argument.
    :param arg2: another argument.
    :returns: the return value
    :raises ValueError: if something bad happened

    """

    test_docstring = parse(test_docstring_content)
    assert test_docstring.short_description == 'This is a test docstring.'
    assert test_docstring.long_description == 'It has an empty line.'
    assert test_docstring.blank_after_short_description
    assert test_docstring.blank_after_long_description    
    assert len(test_docstring.meta) == 3 # two args and one return

    assert test_docstring.meta[0].args == ['param', 'arg1']
   

# Generated at 2022-06-11 21:45:06.303895
# Unit test for function parse
def test_parse():
    """test function parse"""
    text = """
    :param a:
    :param b:
    :param c:
    :return:
    :returns:
    :yield:
    :yields:
    :raises:
    :except:
    """

# Generated at 2022-06-11 21:45:24.871315
# Unit test for function parse
def test_parse():
    s = """Parse the ReST-style docstring into its components.

:param arg1: description
:type arg1: str
:param arg2: description
:param arg3: description
:param arg4: description
:param arg5: description
:type arg5: str
:returns: parsed docstring
:rtype: Docstring
:raises ValueError: description
:raises ValueError: description
"""
    d = parse(s)
    assert d.short_description == "Parse the ReST-style docstring into its components."
    assert len(d.long_description.split()) == 10
    assert len(d.meta) == 8
    assert d.meta[0].key == "param"
    assert d.meta[0].arg_name == "arg1"
    assert d.meta[0].type_

# Generated at 2022-06-11 21:45:31.995521
# Unit test for function parse
def test_parse():
    assert bool(parse("")) == False
    assert bool(parse(" ")) == False
    assert bool(parse("\n")) == False
    assert bool(parse("\n\n")) == False
    assert parse("def f():\n    pass") == Docstring(
        short_description="def f():",
        long_description="pass",
        meta=[],
    )
    assert parse("def f():\n    pass\n") == Docstring(
        short_description="def f():",
        long_description="pass",
        meta=[],
    )
    assert parse("def f():\n    pass\n\n") == Docstring(
        short_description="def f():",
        long_description="pass",
        meta=[],
    )

# Generated at 2022-06-11 21:45:41.049264
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("hello") == Docstring(
        short_description="hello",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert parse("hello\n") == Docstring(
        short_description="hello",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert parse("hello\nworld") == Docstring(
        short_description="hello",
        long_description="world",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

# Generated at 2022-06-11 21:45:42.538754
# Unit test for function parse
def test_parse():
    # TODO
    return



# Generated at 2022-06-11 21:45:51.802301
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""

# Generated at 2022-06-11 21:46:02.741778
# Unit test for function parse
def test_parse():
    assert parse(None) == Docstring()
    assert parse("") == Docstring()
    assert parse("     ") == Docstring()
    assert parse("\n") == Docstring(short_description=None,
                                    long_description=None,
                                    blank_after_short_description=True,
                                    blank_after_long_description=True)
    assert parse("\n\n\n") == Docstring(short_description=None,
                                        long_description=None,
                                        blank_after_short_description=True,
                                        blank_after_long_description=True)

# Generated at 2022-06-11 21:46:14.682846
# Unit test for function parse

# Generated at 2022-06-11 21:46:26.519042
# Unit test for function parse
def test_parse():
    docstring = '''
    Hello, world!

    This is the long description.

    :param arg1: first arg
    :param arg2: second arg
    :returns: None
    :raises ValueError: if arg1 is wrong
    :raises TypeError: if arg2 is wrong
    '''
    doc = parse(docstring)
    assert doc.short_description == 'Hello, world!'
    assert doc.long_description == 'This is the long description.'
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ['param', 'arg1']
    assert doc.meta[0].description == 'first arg'

# Generated at 2022-06-11 21:46:35.227268
# Unit test for function parse
def test_parse():
    text = """
    This is the first line.

    This is the second line.

    :param type_name arg_name: optional description of param
    :param type_name? arg_name: optional description of param

    :returns: optional description of return value"""

    docstring = parse(text)
    assert docstring.short_description == "This is the first line."
    assert docstring.long_description == """\
This is the second line.

:param type_name arg_name: optional description of param
:param type_name? arg_name: optional description of param

:returns: optional description of return value"""

# Generated at 2022-06-11 21:46:45.787407
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring = parse("""
    Some text.

    :param arg1: First arg.
    :param arg2: Second arg. Default: 3.
    :returns: The sum.
    """)

    assert docstring.short_description == "Some text."
    assert docstring.long_description == "First arg.\nSecond arg. Default: 3."
    assert isinstance(docstring.meta[0], DocstringParam)
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].description == "First arg."
    assert docstring.meta[1].arg_name == "arg2"
    assert docstring.meta[1].description == "Second arg. Default: 3."