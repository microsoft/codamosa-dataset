

# Generated at 2022-06-11 21:37:10.390191
# Unit test for function parse
def test_parse():
    docstring = """\
        Render HTML template with context.

        Args:
          tmpl_path: path of the template.
          context: a dictionary of values used to fill up the template.
          request: optional request object.

        Returns:
          A rendered HTML text.
        """

    ## Expect
    expect_short_desc = "Render HTML template with context."
    expect_long_desc = "Args:\n" \
                       "  tmpl_path: path of the template.\n" \
                       "  context: a dictionary of values used to fill up the template.\n" \
                       "  request: optional request object.\n" \
                       "Returns:\n" \
                       "  A rendered HTML text."

    ## Result
    result = parse(docstring)
    print(result.meta)

    ## Assert

# Generated at 2022-06-11 21:37:21.301679
# Unit test for function parse
def test_parse():
  docstring = """
    This is a multi-line example.

    :param x: parameter x
    :param y: parameter y (defaults to 0)
    :param z: parameter z
    :returns: None
    :raises ValueError: if x is less than zero
  """
  doc = parse(docstring)
  print(doc.short_description)
  print(doc.long_description)
  print(doc.blank_after_short_description)
  print(doc.blank_after_long_description)
  print(doc.meta[0].arg_name)
  print(doc.meta[2].arg_name)
  print(doc.meta[3].type_name)
  print(doc.meta[4].type_name)
  print(doc.meta[1].default)

# Unit test

# Generated at 2022-06-11 21:37:31.279037
# Unit test for function parse
def test_parse():
    test_string = """
    Sum the numbers in a list and return the result.

    Long multi-line description of what this function does.
    This is where the complicated stuff is explained.

    :param x: The list of numbers to sum.
    :type x: list of int
    :param y: An optional second list of numbers to sum.
    :type y: list of int
    :param z: An optional third list of numbers to sum.
    :type z: list of int
    :returns: Sum of the numbers in x.
    :rtype: int
    """
    doc = parse(test_string)
    assert doc.short_description == "Sum the numbers in a list and return the result."
    assert doc.blank_after_short_description == True

# Generated at 2022-06-11 21:37:42.099445
# Unit test for function parse
def test_parse():
    docstring = '''This module provides a few utilities that can be used to \
    implement command line interfaces (CLIs).  For example, it provides a \
    class to implement an option parser that parses command line arguments \
    and stores their values in instance variables.
    :param arg1: argument 1
    :param arg2: argument 2
    :returns: return value
    :raises Exception: Exception'''
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == "This module provides a few utilities that can be used to implement command line interfaces (CLIs)."
    assert parsed_docstring.long_description == "For example, it provides a class to implement an option parser that parses command line arguments and stores their values in instance variables."
    assert parsed_docstring.blank_after_short_description == False
   

# Generated at 2022-06-11 21:37:50.219768
# Unit test for function parse

# Generated at 2022-06-11 21:37:58.264165
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    
    '''
    docstring = "This is a test"
    docstring = parse(docstring)
    assert docstring.short_description == 'This is a test'
    assert docstring.long_description == ''
    assert docstring.blank_after_long_description == False
    assert docstring.blank_after_short_description == False
    '''

# Generated at 2022-06-11 21:38:08.052761
# Unit test for function parse
def test_parse():
    text = r"""
    Test the parsing of this docstring.

    This test is for the `parse` function.

    :param int a: The parameter a.
    :param str b: The parameter b.
    :param list c (optional): The parameter c.
    :returns: The return value.
    :rtype: int
    :raises ValueError: If something goes wrong.
    """

    output = parse(text)
    assert output.short_description == "Test the parsing of this docstring."
    assert (
        output.long_description
        == "This test is for the `parse` function."
    )
    assert len(output.meta) == 4
    assert output.meta[0].description == "The parameter a."
    assert output.meta[0].arg_name == "a"

# Generated at 2022-06-11 21:38:11.489381
# Unit test for function parse
def test_parse():
    expected = '''\
    This is a multi-line docstring.

    -----------------------
    Meta information here.
    -----------------------

    This is the end.'''
    expected = inspect.cleandoc(expected)

# Generated at 2022-06-11 21:38:12.996688
# Unit test for function parse
def test_parse():
    param = parse.__annotations__['return']
    assert param == Docstring

# Generated at 2022-06-11 21:38:22.530211
# Unit test for function parse

# Generated at 2022-06-11 21:38:38.517101
# Unit test for function parse
def test_parse():
    """
    Unit test for function parse
    """
    import pytest
    doc = """
    Scan the atoms.

    :param atoms: The atoms to scan.
    :type atoms: list of :class:`ase.Atom`

    :param user: The user that is scanning.
    :type user: :class:`UserAccount`

    :returns: The atoms that have been scanned.
    :rtype: list of :class:`ase.Atom`
    """
    docstring = parse(doc)
    assert docstring.short_description == "Scan the atoms."

# Generated at 2022-06-11 21:38:49.088542
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    docstring = parse.__doc__
    assert parse(docstring) == parse(dedent(docstring))

    docstring = """\
    Short description.

        Long description.

            Sub-list item 1
            Sub-list item 2

            Sub-list item 3 continued

        Long description continued.
    """
    assert parse(docstring) == parse(dedent(docstring))

    docstring = """\
    Short description.

        Long description.

            Sub-list item 1
            Sub-list item 2

            Sub-list item 3 continued

        Long description continued.

    :keyword: metadata
    """
    assert parse(docstring) == parse(dedent(docstring))


# Generated at 2022-06-11 21:39:01.341373
# Unit test for function parse
def test_parse():
    docstring = inspect.getdoc(parse)
    assert docstring.short_description == "Parse the ReST-style docstring into its components."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.long_description == ":returns: parsed docstring"
    assert len(docstring.meta) == 1
    assert docstring.meta[0].key == "returns"
    assert docstring.meta[0].arg_name is None
    assert docstring.meta[0].type_name == "Docstring"
    assert docstring.meta[0].is_optional is False
    assert docstring.meta[0].description == "parsed docstring"
    assert docstring.meta[0].default is None


# Check whether parse can parse its own doc

# Generated at 2022-06-11 21:39:13.758761
# Unit test for function parse
def test_parse():
    
    input = inspect.cleandoc("""
    This function takes three input parameters.
    
    :param x: This param is the first.
    :param y: This param is the second.
    :type x: str
    :type y: int
    :param z: This param is the third.
    :type z: int
    :returns: The results.
    :raises: This function might throw an exception.
    """)
    result = parse(input)
    
    assert len(result.meta) == 4
    assert result.meta[0].args == ['param', 'x']
    assert result.meta[0].description == "This param is the first."
    assert result.meta[1].args == ['param', 'y']
    assert result.meta[1].description == "This param is the second."
   

# Generated at 2022-06-11 21:39:18.224130
# Unit test for function parse
def test_parse():
    assert isinstance(
        parse(""),
        Docstring
    ) == True
    assert isinstance(
        parse("function hello()"),
        Docstring
    ) == True


# Generated at 2022-06-11 21:39:21.975247
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    doc = parse(__doc__)
    assert doc.short_description == "ReST-style docstring parsing."
    assert doc.long_description.startswith("Parse ReST-style docstrings.")
    assert len(doc.meta) == 4



# Generated at 2022-06-11 21:39:29.485451
# Unit test for function parse
def test_parse():
    docstring = '''
    This is the short description.

    This is the long description.

    :param arg1: the first argument
    :type arg1: int
    :param arg2: the second argument
    :type arg2: str
    :returns: description of return value
    :rtype: int
    :raises keyError: raises an exception
    :raises TypeError: does not raise an exception
    '''
    result = parse(docstring)
    assert result.short_description == "This is the short description."
    assert result.long_description == "This is the long description."
    assert len(result.meta) == 4
    assert isinstance(result.meta[3], DocstringRaises) 
    assert result.meta[3].type_name == "TypeError"


# Generated at 2022-06-11 21:39:39.317502
# Unit test for function parse
def test_parse():
    text = "test"
    assert parse(text) == Docstring()

parse("""
Does something.

- Does something small.
- Does something big.

:param name: The name.
:type name: str
:param int age: The age.
:param float weight: The weight in kg.
:raises ValueError: In case of an invalid value.
:returns: Nothing.
:rtype: None
:yields: Something.
:yield type: int
:yields: Something else.
:yield type: str
:yields: And also something else.
:yield type: float
""")


# Generated at 2022-06-11 21:39:51.496362
# Unit test for function parse
def test_parse():
    text = """
        Summary line.

        Extended description.

        Parameters
        ----------
        arg1 : int
            Description of `arg1`.
        arg2 : str
            Description of `arg2`.

        Returns
        -------
        int
            Description of return value.
    """

    doc = parse(text)
    assert doc.short_description == 'Summary line.'
    assert doc.long_description == 'Extended description.'

    assert len(doc.meta) == 3
    assert doc.meta[0].args == ['Parameters']
    assert doc.meta[1].args == ['arg1', 'int', 'arg1']
    assert doc.meta[1].description == 'Description of `arg1`.'
    assert doc.meta[2].args == ['arg2', 'str', 'arg2']


# Generated at 2022-06-11 21:39:59.072088
# Unit test for function parse
def test_parse():
    """
        Run tests for parse function
    """
    test_fails = 0
    test_pass = 0
    test_exceptions = 0
    def _test_parse(f, result, exceptions=None,):

        global test_fails
        global test_exceptions
        global test_pass
        try:
            res = parse(f)
            if str(res) == str(result):
                test_pass += 1
            else:
                test_fails += 1
            return res
        except Exception as e:
            if not exceptions and isinstance(e, exceptions):
                test_pass += 1
            else:
                test_fails += 1
                test_exceptions += 1
            return e

    print("Testing parse function.")

    print("\nTest 1: Empty Docstring:")
    assert _test_parse

# Generated at 2022-06-11 21:40:14.694142
# Unit test for function parse
def test_parse():
    """Test the parse function"""
    from textwrap import dedent
    from .dump import _dump

    sample = dedent(
        """\
        short description of the function.

        Long description of the function

        :param arg1: first argument
        :type arg1: str
        :param arg2: second argument
        :type arg2: list
        :param arg3: third argument
        :param arg4: fourth argument
        :type arg4: list
        :default arg4: [1]
        :raises ValueError: when something goes wrong
        :returns: something
        :rtype: int
        :yields: something else
        :ytype: str
        :yields: another thing
        :ytype: int
        """
    )
    ret = parse(sample)

# Generated at 2022-06-11 21:40:24.628208
# Unit test for function parse
def test_parse():
    docstring = """\
    :param a: First argument
    :type a: str
    :param b: Second argument
    :type b: int
    :returns: sum of arguments
    :rtype: int
    :raises ValueError: if arguments are of wrong type
    """
    doc = parse(docstring)
    assert len(doc.meta) == 4
    assert doc.meta[0] == DocstringParam(
        arg_name= "a", type_name= "str",
        description= "First argument",
        is_optional= False, default= None
    )
    assert doc.meta[1] == DocstringParam(
        arg_name="b", type_name= "int",
        description= "Second argument",
        is_optional= False, default= None
    )

# Generated at 2022-06-11 21:40:35.580109
# Unit test for function parse

# Generated at 2022-06-11 21:40:46.196464
# Unit test for function parse
def test_parse():
    """Test the parsing functions."""
    docstring_text = """
    The first line is a one-line summary that does not use
    full sentence.
    The second line a blank line.
    The third is a paragraph that may span multiple lines
    and contain formatting information.
    It may also be multiple paragraphs, each separated by
    a blank line.

    :param arg1: its description
    :param arg2: its description
    :param arg3: its description
    :type arg1: int
    :type arg2: str
    :rtype: int
    :return: the return value of the function
    """
    docstring = parse(docstring_text)
    assert docstring.short_description == "The first line is a one-line summary that does not use full sentence."

# Generated at 2022-06-11 21:40:54.658695
# Unit test for function parse
def test_parse():
    doc_normal = '''
    test string
    : paream 1
    : param 2
    : retuens:
    :     name : test
    : raies:
    : 		test
    : 		test2
    '''
    ret = parse(doc_normal)

    assert ret.short_description is 'test string'
    assert ret.long_description is None
    assert len(ret.meta) is 3
    for item in ret.meta:
        print(item.args)
        print(item.description)
        print(item.arg_name)


# Generated at 2022-06-11 21:41:05.707567
# Unit test for function parse
def test_parse():
    foo = '''\
    :param str bar: parameter
    :type bar: str
    :param int count: this is a counter
    
    This is a long description
    :type arg: arg type
    :param arg: long description
    :type arg2: arg2 type
    :raises ValueError: if
    :returns: the output
    :rtype: str
    :param str other: another parameter
    '''


# Generated at 2022-06-11 21:41:16.269916
# Unit test for function parse
def test_parse():
    print("Unit test for function parse")
    assert parse("") == \
    Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[]
    )
    assert parse("Short description.") == \
    Docstring(
        short_description="Short description.",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[]
    )

# Generated at 2022-06-11 21:41:25.304989
# Unit test for function parse

# Generated at 2022-06-11 21:41:32.704500
# Unit test for function parse
def test_parse():
    s = "This function solves all your problems.\n\n:param a: an argument\n"
    assert parse(s) == Docstring(
        short_description="This function solves all your problems.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="",
        meta=[
            DocstringMeta(
                args=["param", "a"],
                description="an argument",
            )
        ],
    )

# Generated at 2022-06-11 21:41:41.034850
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('   ') == Docstring()
    assert parse(None) == Docstring()

    docstring = "Short description."
    assert parse(docstring) == Docstring(
        short_description="Short description",
        blank_after_short_description=False,
    )

    docstring = "Short description.\n    "
    assert parse(docstring) == Docstring(
        short_description="Short description",
        blank_after_short_description=False,
    )

    docstring = "Short description\n\nLong description."
    assert parse(docstring) == Docstring(
        short_description="Short description",
        blank_after_short_description=False,
        long_description="Long description.",
        blank_after_long_description=False,
    )

# Generated at 2022-06-11 21:41:58.151907
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    # Short description
    assert parse("Do awesome stuff.") == Docstring()

    # Long description
    assert parse("""
        Do awesome stuff.

        This is the long description. It can be multiple
        lines long and includes paragraph breaks.

        This is the second paragraph.
        """) == Docstring(
        short_description="Do awesome stuff.",
        blank_after_short_description=True,
        long_description="This is the long description. It can be multiple\nlines long and includes paragraph breaks.\n\nThis is the second paragraph.",
        blank_after_long_description=True
    )

    # Meta

# Generated at 2022-06-11 21:42:08.568871
# Unit test for function parse
def test_parse():
    s = """
    Returns the number of occurrences of substring sub in
    string s[start:end].  Optional arguments start and end are
    interpreted as in slice notation.

    :param str sub: substring to be searched for
    :param str s: string to search in
    :param int start: start of slice in s to search
    :param int end: end of slice in s to search
    :returns: number of non-overlapping occurrences of substring sub in
              string s[start:end]
    :raises ValueError: if the substring is not found

    Return the number of (non-overlapping) occurrences of substring sub in
    string s[start:end].  Optional arguments start and end are interpreted as
    in slice notation.

    """
    ret = parse(s)

# Generated at 2022-06-11 21:42:14.728115
# Unit test for function parse
def test_parse():
    correct_meta_args = [
        "param",
        "type",
        "number",
        "returns",
        "type",
        "type",
        "value",
        "raises",
        "type",
        "type",
        "error",
        "type",
        "type",
        "AnError",
        "type",
        "type",
        "erroneous",
    ]

# Generated at 2022-06-11 21:42:23.845683
# Unit test for function parse

# Generated at 2022-06-11 21:42:31.470536
# Unit test for function parse
def test_parse():
    # test parsing a docstring that includes no additional meta-information
    text = """\
    This is the short description.

    This is the
    long description."""
    result = parse(text)
    assert result.short_description == "This is the short description."
    assert not result.blank_after_short_description
    assert result.long_description == "This is the\nlong description."
    assert result.blank_after_long_description
    assert len(result.meta) == 0

    # test parsing a docstring that includes additional meta-information

# Generated at 2022-06-11 21:42:39.908195
# Unit test for function parse
def test_parse():
  text = '''Function to add two numbers
  
  Second line of the function description
  
  :param x: first number
  :param y: second number
  :returns: sum of x and y
  
  '''
  doc = parse(text)
  assert(doc.short_description == 'Function to add two numbers')
  assert(doc.long_description == 'Second line of the function description')
  assert(doc.blank_after_short_description == True)
  assert(doc.blank_after_long_description == False)
  assert(isinstance(doc.meta[0], DocstringParam))
  assert(doc.meta[0].description == 'first number')
  assert(doc.meta[1].description == 'second number')
  assert(isinstance(doc.meta[2], DocstringReturns))

# Generated at 2022-06-11 21:42:49.811420
# Unit test for function parse
def test_parse():
    code = """\
        Parse the ReST-style docstring into its components.

        Parameters
        ----------
        text : str
            Description of text

        Returns
        -------
        Docstring
            Description of Docstring
        """
    assert parse(code).describe() == """\
        Parse the ReST-style docstring into its components.

        Parameters
        ----------
        text : str
            Description of text
        Returns
        -------
        Docstring
            Description of Docstring"""

    code = """\
        Parse the ReST-style docstring into its components.

        :param text: str
            Description of text
        :returns: Docstring
            Description of Docstring
        :rtype: Docstring"""

# Generated at 2022-06-11 21:42:58.750137
# Unit test for function parse
def test_parse():
    parsed = parse(
        """Short description.

        Long description.

        :param arg1: First argument.
        :type arg1: str
        :param arg2: Second argument.
        :type arg2: str
        :param arg3: Third argument.
        :type arg3: str
        :returns: Nothing.
        :rtype: None

        More description.
        """
    )

    assert parsed.short_description == "Short description."
    assert parsed.long_description == (
        "Long description.\n\nMore description."  # always a newline
    )

    assert len(parsed.meta) == 3

    assert isinstance(parsed.meta[0], DocstringParam)
    assert parsed.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-11 21:43:10.340972
# Unit test for function parse
def test_parse():
    # Single line docstring
    single_line = """This is a single line docstring"""
    single_line_ast = parse(single_line)
    assert single_line_ast.short_description == "This is a single line docstring"
    assert single_line_ast.long_description is None
    assert single_line_ast.blank_after_short_description is False
    assert single_line_ast.blank_after_long_description is False
    assert len(single_line_ast.meta) == 0

    # Multiple line docstring
    multiple_line = """This is a multiple\nline docstring"""
    multiple_line_ast = parse(multiple_line)
    assert multiple_line_ast.short_description == "This is a multiple"
    assert multiple_line_ast.long_description == "line docstring"
   

# Generated at 2022-06-11 21:43:20.294354
# Unit test for function parse
def test_parse():
    short_docstring = '''\
short docstring test
'''
    assert parse(short_docstring).short_description == 'short docstring test'

    long_docstring = '''\
short docstring

long docstring test
'''
    doc = parse(long_docstring)
    assert doc.short_description == 'short docstring'
    assert doc.long_description == 'long docstring test'

    short_docstring = '''\
short docstring
:arg: test
'''
    assert parse(short_docstring).short_description == 'short docstring\n:arg: test'

    long_docstring = '''\
short docstring

long docstring test
:arg: test
'''
    doc = parse(long_docstring)

# Generated at 2022-06-11 21:43:40.909720
# Unit test for function parse
def test_parse():
    text = """
    :type x: int
    :raises ValueError: if x is negative
    """

    expected = Docstring()
    expected.short_description = None
    expected.blank_after_short_description = True
    expected.blank_after_long_description = True
    expected.long_description = None
    expected.meta.append(DocstringParam(
        args=['type', 'x', 'int'],
        description=None,
        arg_name='x',
        type_name='int',
        is_optional=False,
        default=None
    ))
    expected.meta.append(DocstringRaises(
        args=['raises', 'ValueError'],
        description='if x is negative',
        type_name='ValueError'
    ))

    actual = parse(text)

# Generated at 2022-06-11 21:43:49.879979
# Unit test for function parse
def test_parse():
    text = """\
    This is the short description.

    This is the long description.

    This is part of the long description.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == """\
This is the long description.

This is part of the long description.
"""
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is True
    assert len(docstring.meta) == 0



# Generated at 2022-06-11 21:43:58.447388
# Unit test for function parse

# Generated at 2022-06-11 21:44:10.261908
# Unit test for function parse
def test_parse():
    docstring = """First line.

Second line.

:param name: the name to say hello to
:type name: str
:returns: None
"""
    assert parse(docstring) == Docstring(
        short_description='First line.',
        long_description='Second line.',
        meta=[
            DocstringParam(
                args=['param', 'name', 'the name to say hello to'],
                description='the name to say hello to',
                arg_name='name',
                type_name='str',
                is_optional=False,
                default=None
            ),
            DocstringReturns(
                args=['returns', 'None'],
                description='None',
                type_name='None',
                is_generator=False,
            )
        ]
    )

# Generated at 2022-06-11 21:44:18.526303
# Unit test for function parse
def test_parse():
    text = \
"""Test function.
    :param a: first param.
    :type a: int.
    :param b: second param.
    :type b: str.
    :raises Exception: if something bad happens.

    """
    doc_string = parse(text)
    print(doc_string.__dict__)

# Generated at 2022-06-11 21:44:28.420786
# Unit test for function parse
def test_parse():
    doc = r'''Short description.

    Long description.

    :param str foo: Foo parameter.
    :param str bar=None: Bar parameter.
    :returns: Something to return.
    '''
    ret = parse(doc)

# Generated at 2022-06-11 21:44:39.502846
# Unit test for function parse
def test_parse():
    text = '''
        The first line is brief explanation, which may be completed with 
        a longer one.
        :param str par1: Parameter 1.
        :type par1: str
        :param int par2: Parameter 2.
        :param str par3: Parameter 3.
        :param int par4: Parameter 4.
        :raises ValueError: The person was not found.
        :return: a list of persons
    '''
    doc = parse(text)
    assert doc.short_description == 'The first line is brief explanation, which may be completed with'
    assert doc.long_description == 'a longer one.'
    assert doc.meta[0].args == ['par1', 'str']
    assert doc.meta[0].arg_name == 'par1'
    assert doc.meta[0].type

# Generated at 2022-06-11 21:44:49.642607
# Unit test for function parse
def test_parse():
    # A basic example
    docstring = '''One line summary.
    
    Extended description.
    
    :arg x: int.
    :arg y: str, optional. Defaults to "Y".
    :return: x+y.
    :raises TypeError: when x is not an integer.
    :yields: x+y.
    '''
    parsed = parse(docstring)
    assert parsed.short_description == "One line summary."
    assert parsed.blank_after_short_description is True
    assert parsed.long_description == "Extended description."
    assert parsed.blank_after_long_description is True
    assert len(parsed.meta) == 4

# Generated at 2022-06-11 21:44:55.819326
# Unit test for function parse
def test_parse():

    def _build(text: str) -> Docstring:
        return parse(text)

    # --- Helper Test Functions ---
    def _check_consecutive_blanks(doc: Docstring, num_blanks: int):
        if num_blanks == 0:
            assert not doc.blank_after_short_description, "Too many consecutive blanks in docstring."
            assert not doc.blank_after_long_description, "Too many consecutive blanks in docstring."
        elif num_blanks == 1:
            assert doc.blank_after_short_description, "Too few consecutive blanks in docstring."
            assert not doc.blank_after_long_description, "Too many consecutive blanks in docstring."

# Generated at 2022-06-11 21:45:07.268396
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring summary.

    This is a docstring description.

    :param str name: Name of the object
    :param bool active: Whether the object is active
    :param int count: Number of times this line was called
    :param: This is a single line description
    :rtype: dict
    :returns: a dictionary with args
    :raises: ValueError if count is less than 0
    :raises: TypeError if name is None
    :raises TypeError: If the value is of the wrong type
    """


# Generated at 2022-06-11 21:45:21.123639
# Unit test for function parse
def test_parse():
    from .common import DocstringReturns, DocstringParam, DocstringRaises, DocstringMeta

    docstr = '''
    This is a test docstring

    This is the long description

    :param a: description of arg a
    :param b: description of arg b
    :return: description of return
    :rtype: int
    :raises ValueError: description of exception
    :raises TypeError: description of exception
    '''


# Generated at 2022-06-11 21:45:24.128633
# Unit test for function parse
def test_parse():
    test_docstring = """Test function.
    
    Arguments:
        name:

    Returns:
        None
    """
    print(parse(test_docstring))

# Generated at 2022-06-11 21:45:31.996894
# Unit test for function parse
def test_parse():
    doc = """
        Short summary.

        More text.
        """
    res = parse(doc)
    assert res.short_description == "Short summary."
    assert res.long_description == "More text."
    assert res.blank_after_short_description == True
    assert res.blank_after_long_description == False

    doc = """
        Short summary.

        More text.
        :param arg: The argument
        with whitespace.
        :type arg: str
        :raises Exception:
        :rtype: str
        :returns: some text
        :returntype: str
        :yields: some other text
        :yieldtype: str

        Yet more text.
        """
    res = parse(doc)
    assert res.short_description == "Short summary."

# Generated at 2022-06-11 21:45:41.022627
# Unit test for function parse

# Generated at 2022-06-11 21:45:51.279671
# Unit test for function parse
def test_parse():
    """Unit test for parse function"""
    test_text = inspect.cleandoc(
        """
        This is a short desc

        This is a long desc.

        :param x: first number
        :param y: second number
        :returns: the sum of x and y
        """
    )
    test_docstring = parse(test_text)
    assert test_docstring.short_description == "This is a short desc", "No short description"
    assert test_docstring.long_description == "This is a long desc.", "No long description"
    assert test_docstring.blank_after_short_description == True, "Blank line after short description"
    assert test_docstring.blank_after_long_description == True, "Blank line after long description"


# Generated at 2022-06-11 21:46:02.440783
# Unit test for function parse
def test_parse():
    test_doc = '''\
        Hello there!
        :arg a: this is the arg.
        :type a: int
        :param b: this is the param.
        :type b: str
        :param c: this is another param.
        :raises TypeError: blah blah blah
        :return: nothing
        :rtype: None'''
    test_result = parse(test_doc)
    assert test_result.short_description == "Hello there!"
    assert test_result.long_description == None
    assert len(test_result.meta) == 7
    assert isinstance(test_result.meta[1], DocstringParam)
    assert test_result.meta[1].arg_name == "a"
    assert test_result.meta[1].type_name == "int"

# Generated at 2022-06-11 21:46:06.049314
# Unit test for function parse
def test_parse():
    doc_str ="""
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """

    doc = parse(doc_str)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:46:18.260453
# Unit test for function parse
def test_parse():
    # Test without text
    assert parse('') == Docstring()

    # Test with invalid text
    try:
        parse(':')
    except ParseError:
        pass
    try:
        parse(': :')
    except ParseError:
        pass
    try:
        parse(': : :')
    except ParseError:
        pass
    try:
        parse(':\n:')
    except ParseError:
        pass
    try:
        # The first `:` is missing
        parse(':Args:\n\tparam 1\n\nDescription.')
    except ParseError:
        pass

    # Test with valid text
    short_desc = 'A short description.'
    long_desc = 'First line of long description.\n\nSecond paragraph.'
    param_desc = 'A parameter.'

# Generated at 2022-06-11 21:46:29.965391
# Unit test for function parse
def test_parse():
    docstring = """Parses the docstring.
    :param x: The x parameter.
    :type x: int | float
    :param y: The y parameter.
    :type y: int | float
    :return: The return value.
    :rtype: int | float
    :raises RuntimeError: if there's a runtime error.
    :raises ValueError: if there's a value error.
    """

# Generated at 2022-06-11 21:46:39.922419
# Unit test for function parse
def test_parse():
    assert str(parse("function")) == "function()\n"
    assert str(parse("function().")) == "function()\n"
    print(parse("function()\n  ."))
    assert str(parse("function()\n  .")) == "function()\n"
    assert str(parse("Function.\n\n   Arguments:\n      words")) == "Function()\n"
    print(parse("Function.\n\n   Arguments:\n      words"))
    assert (
        str(parse("Function.\n\n   Arguments:\n\n      words"))
        == "Function()\nArguments:\n    words"
    )