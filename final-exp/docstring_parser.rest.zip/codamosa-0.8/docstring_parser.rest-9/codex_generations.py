

# Generated at 2022-06-11 21:37:16.279012
# Unit test for function parse
def test_parse():
  from .common import ParseError
  parse('')
  try:
    parse('    :keyword arg text')
    assert False
  except ParseError:
    pass
  try:
    parse(':keyword: :keyword text')
    assert False
  except ParseError:
    pass
  docstr = parse(':keyword arg: text\n')
  assert docstr.short_description is None
  assert docstr.long_description is None
  assert docstr.meta[0].args == ['keyword', 'arg']
  assert docstr.meta[0].description == 'text'
  docstr = parse('first line\n')
  assert docstr.short_description == 'first line'
  assert docstr.long_description is None
  assert not docstr.meta

# Generated at 2022-06-11 21:37:17.330181
# Unit test for function parse
def test_parse():
    assert parse

# Generated at 2022-06-11 21:37:30.266026
# Unit test for function parse
def test_parse():
    parsed = parse("Parse the ReST-style docstring into its components.\n\n"
    ":param str text: input ReST-style docstring\n:returns:\n:rtype: Docstring\n")
    assert parsed.short_description == 'Parse the ReST-style docstring into its components.'
    assert parsed.blank_after_short_description == False
    assert parsed.blank_after_long_description == True
    assert parsed.long_description is None
    assert parsed.meta[0].arg_name == 'text'
    assert parsed.meta[0].description == 'input ReST-style docstring'
    assert parsed.meta[0].type_name == 'str'
    assert parsed.meta[0].is_optional == False
    assert parsed.meta[0].default is None

# Generated at 2022-06-11 21:37:39.929662
# Unit test for function parse

# Generated at 2022-06-11 21:37:46.598173
# Unit test for function parse
def test_parse():
    import phial.parser
    doc = """summary

:param something: description
:param something2: description2
"""

    docstring = phial.parser.parse(doc)

    assert docstring.short_description == "summary"
    assert docstring.long_description == None
    assert docstring.meta[0].args == ["param", "something"]
    assert docstring.meta[1].args == ["param", "something2"]

# Generated at 2022-06-11 21:37:48.743596
# Unit test for function parse
def test_parse():
    src = inspect.getsource(parse)
    assert ":returns:" in src
    assert ":yields:" not in src


# Generated at 2022-06-11 21:37:54.187814
# Unit test for function parse
def test_parse():
    docstring = '''Short summary.

Longer summary
across multiple
lines.
:param foo: the foo parameter.
:param bar: the bar parameter. defaults to baz.
:raises FooError: when fooing goes wrong.
:returns: stuff!
'''
    parsed = parse(docstring)
    print(parsed)


if __name__=="__main__":
    test_parse()

# Generated at 2022-06-11 21:38:05.824661
# Unit test for function parse
def test_parse():
    # docstring for the function itself
    doc = parse.__doc__
    assert doc.short_description == 'Parse the ReST-style docstring into its components.'
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert doc.long_description == ':returns: parsed docstring'
    assert len(doc.meta) == 1
    assert doc.meta[0].key == 'returns'
    assert doc.meta[0].type_name == 'Docstring'

    # make sure it works with various docstring styles
    doc_rst = '''
    :param int foo: the foo value
    :returns: the foo value
    '''
    doc = parse(doc_rst)
    assert doc.short_description is None

# Generated at 2022-06-11 21:38:16.722902
# Unit test for function parse
def test_parse():
    docstr = '''\
    This is the short description.
    This is the long description.

    :param foo: This is foo.
    :param str name: The name.
    :type name: str
    '''

    assert parse(docstr).short_description == 'This is the short description.'
    assert parse(docstr).long_description == 'This is the long description.'

    assert parse(docstr).meta[0].arg_name == 'foo'
    assert parse(docstr).meta[0].description == 'This is foo.'

    assert parse(docstr).meta[1].arg_name == 'name'
    assert parse(docstr).meta[1].description == 'The name.'
    assert parse(docstr).meta[1].type_name == 'str'

# Generated at 2022-06-11 21:38:24.455904
# Unit test for function parse

# Generated at 2022-06-11 21:38:47.829476
# Unit test for function parse
def test_parse():
    from . import common
    from .common import Docstring

    docstring = common.Docstring(
        short_description="short description",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[
            common.DocstringMeta(
                args=["throws"], description="some description\n some description"
            )
        ],
    )

    assert isinstance(parse("short description:\n  :throws: some description\n "
                            " some description"), Docstring)
    assert isinstance(parse("short description:"), Docstring)
    assert isinstance(parse("short description:\n  :throws: some description"), Docstring)
    assert docstring.short_description == "short description"

# Generated at 2022-06-11 21:39:00.645244
# Unit test for function parse

# Generated at 2022-06-11 21:39:12.780037
# Unit test for function parse
def test_parse():
  docstring = """This is a short description.

  This is a long description.

  :param argname: description of the argument.
  :param str age: description of the argument.
  :keyword kwargname: description of the keyword argument.
  :keyword str kwage: description of the keyword argument.
  :raises Exception: description of an exception.
  :raises IOError: description of an exception.
  :returns: description of the return value.
  :rtype: str
  :returns int: description of the return value.
  :returns: description of the return value.
  :yields: description of the yielded value.
  :yields str: description of the yielded value.
  """
  res = parse(docstring)
  assert isinstance(res.short_description, str)

# Generated at 2022-06-11 21:39:19.964473
# Unit test for function parse
def test_parse():
    docstring = parse(None)
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False

    docstring = parse("")
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False

    docstring = parse("Hello")
    assert docstring.short_description == "Hello"
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False

    docstring = parse("Hello\nWorld")
    assert doc

# Generated at 2022-06-11 21:39:25.900015
# Unit test for function parse
def test_parse():
    docstring = """One line summary.

    Extended description.

    :param param1: Description of param1
    :param param2: Description of param2,
        which spans multiple lines
    :type param2: str
    :returns: Description of return
    :rtype: int
    :raises keyError: raises an exception
    """
    docstr = parse(docstring)
    print("Summary: ", docstr.short_description)
    print("Extended description: ", docstr.long_description)
    for m in docstr.meta:
        print("Param: ",m)

#test_parse()

# Generated at 2022-06-11 21:39:37.648635
# Unit test for function parse
def test_parse():
    sample_docstring = """First line
    
    :param name:The name
    :type name:str
    :param type: The type
    :type: str
    :uses: this, that"""
    parsed_docstring = parse(sample_docstring)
    if parsed_docstring.short_description != 'First line':
        raise ValueError('Failed to parse docstring')
    if parsed_docstring.long_description != 'None':
        raise ValueError('Failed to parse docstring')
    if parsed_docstring.meta[0].arg_name != 'name':
        raise ValueError('Failed to parse docstring')
    if parsed_docstring.meta[0].type_name != 'str':
        raise ValueError('Failed to parse docstring')

# Generated at 2022-06-11 21:39:49.696379
# Unit test for function parse
def test_parse():
    ret = Docstring()
    text='''
    Parameter for some things
    :param type_name arg_name: This describes the first argument which
        has a rather long description.

    :param type_name: The type of the second argument. This
        description also spans several lines.

    :param arg_name?: The third argument is optional.

    :param type_name arg_name=default: The fourth argument has a
        default value.
    '''
    ret=parse(text) 
    assert ret.meta[2].arg_name == "arg_name"
    assert ret.meta[2].arg_name == "arg_name"
    assert ret.meta[2].type_name == None


# Generated at 2022-06-11 21:39:57.417078
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    assert parse("foo") == Docstring(
        short_description="foo",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("foo\nbar") == Docstring(
        short_description="foo",
        long_description="bar",
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("foo\nbar\n") == Docstring(
        short_description="foo",
        long_description="bar",
        blank_after_short_description=False,
        blank_after_long_description=True,
        meta=[],
    )


# Generated at 2022-06-11 21:40:06.792375
# Unit test for function parse

# Generated at 2022-06-11 21:40:15.898722
# Unit test for function parse
def test_parse():
    assert parse("Simple docstring") == Docstring(
        "Simple docstring", None, True, True
    )
    assert parse("Simple docstring\n") == Docstring(
        "Simple docstring", None, True, True
    )
    assert parse("Simple docstring\n\n") == Docstring(
        "Simple docstring", None, False, True
    )
    assert parse("Simple docstring\n\n\n") == Docstring(
        "Simple docstring", None, False, False
    )
    assert parse('Simple docstring\n\n"""Docstring"""') == Docstring(
        "Simple docstring", '"""Docstring"""', False, True
    )

# Generated at 2022-06-11 21:40:34.287559
# Unit test for function parse
def test_parse():
    test_data = """Test parsing
    :param arg1: description of arg1
    :type arg1: int
    :param arg2: description of arg2
    :default arg2: 42

    Short description
    :returns: int
    :return: int
    :rtype: int
    :yields: int
    :yield: int
    :ytype: int
    :raises: ValueError"""

# Generated at 2022-06-11 21:40:44.784548
# Unit test for function parse
def test_parse():
    text = """Single line short description.

    Multi line long description.  This is the first paragraph.

    This is the second paragraph.

    :param foo: description of parameter foo
    :type foo: str
    :param bar: description of parameter bar
    :type bar: int
    :param baz: description of parameter baz
    :type baz: bool
    :raises ValueError: if baz is False
    :returns: description of return value
    :rtype: int
    :returns: description of return value
    """

    docstring = parse(text)
    meta = docstring.meta

    assert docstring.short_description == "Single line short description."
    assert docstring.long_description == "Multi line long description.  This is the first paragraph.\n\nThis is the second paragraph."
    assert docstring

# Generated at 2022-06-11 21:40:53.749943
# Unit test for function parse
def test_parse():
    """Test function parse."""
    f = inspect.getsource(test_parse)
    d = parse(f)
    assert d.short_description == 'Test function parse.'
    assert d.blank_after_short_description
    assert d.long_description == ':returns: name'
    assert d.blank_after_long_description
    assert d.meta
    assert len(d.meta) == 1
    assert d.meta[0].description == 'description'
    assert len(d.meta[0].args) == 1
    assert d.meta[0].args == ['returns']
    assert isinstance(d.meta[0], DocstringReturns)
    assert d.meta[0].type_name == 'name'



# Generated at 2022-06-11 21:41:04.339280
# Unit test for function parse
def test_parse():
    # test for empty docstring
    assert parse("") == Docstring()

    # test for a short description and no verbose description
    docstring = parse(
        """
    This is a short description and no verbose description.
    """
    )
    assert docstring == Docstring(
        short_description="This is a short description and no verbose description."
    )

    # test for a short description and an empty verbose description
    docstring = parse(
        """
    This is a short description and an empty verbose description.

    """
    )
    assert docstring == Docstring(
        short_description="This is a short description and an empty verbose description.",
        long_description="",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

    # test for a

# Generated at 2022-06-11 21:41:15.158283
# Unit test for function parse

# Generated at 2022-06-11 21:41:20.112301
# Unit test for function parse
def test_parse():
    text = """\
Examples
--------

Tests an example of documentation.
"""
    result = parse(text)

    assert result.short_description
    assert result.long_description
    assert result.long_description.startswith("Tests")
    assert isinstance(
        result.long_description, str
    ), "long description should be a string"



# Generated at 2022-06-11 21:41:26.200956
# Unit test for function parse
def test_parse():
    with open('deuce/tests/resources/test_rest_style_docstring_parse.py', 'r') as f:
        text_func=f.read()
        code_obj=compile(text_func, 'deuce/tests/resources/test_rest_style_docstring_parse.py', 'exec')
        func_obj=code_obj.co_consts[0]
        print(parse(func_obj.__doc__))
        #assert(str(parse(func_obj.__doc__)) == str(func_obj.return_value))

# Generated at 2022-06-11 21:41:37.434157
# Unit test for function parse

# Generated at 2022-06-11 21:41:42.348758
# Unit test for function parse
def test_parse():
    test_docstring = '''
    A simple code for testing.
    :param str name: A name.
    :param int age: The age.
    '''
    doc = parse(test_docstring)
    print(doc)

test_parse()

# Generated at 2022-06-11 21:41:43.928574
# Unit test for function parse
def test_parse():
    doc = """
    short description

    long description
    """

    print(parse(doc))


# Generated at 2022-06-11 21:41:55.540929
# Unit test for function parse
def test_parse():
    docstring = """
        First line
        Second line

        :param str foo: the foo parameter
        :param bar: bar parameter
        :return:
    """

    result = parse(docstring)
    assert result.short_description == "First line\nSecond line"
    assert result.long_description == None
    assert len(result.meta) == 2

# Generated at 2022-06-11 21:42:05.519515
# Unit test for function parse
def test_parse():
    """
    Unit test for parse.
    """

# Generated at 2022-06-11 21:42:14.882944
# Unit test for function parse

# Generated at 2022-06-11 21:42:23.940862
# Unit test for function parse
def test_parse():
    ds = """\
    This is a docstring.

    This is the long description.

    :param x: the x value
    :param y: the y value, defaults to 4.
    :returns: the x value multiplied by the y value, which defaults to 4
    """
    doc = parse(ds)

# Generated at 2022-06-11 21:42:31.487257
# Unit test for function parse
def test_parse():
    docstring = """
    A useful function.

    This function does something useful. It's very clever.

    It also accepts a parameter, n.

    :param n: number of things to do
    :type n: int
    :rtype: None

    :returns: this is obsolete.
    :r: this is also obsolete.
    :yields: this is the correct way to provide a hint.
    :y: tricky!

    :returns: None
    :return: this should raise an error.

    :raises NotImplementedError: when n > 10

    :raises: this should raise an error.
    """

# Generated at 2022-06-11 21:42:39.174066
# Unit test for function parse
def test_parse():
    _text = """Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """
    _docstring = Docstring()
    _docstring.short_description = 'Parse the ReST-style docstring into its components.'
    _docstring.long_description = 'parsed docstring'
    _docstring.blank_after_short_description = False
    _docstring.blank_after_long_description = False
    _meta = DocstringMeta()
    _meta.args = [':returns']
    _meta.description = 'parsed docstring'
    _docstring.meta.append(_meta)
    assert _docstring == parse(_text)


# Generated at 2022-06-11 21:42:49.594920
# Unit test for function parse
def test_parse():
    from .common import DocstringReturns, Docstring, DocstringMeta, DocstringRaises, DocstringParam

    def example_function_no_docstring():
        """ """
        pass

    def example_function():
        """A function.

        :param int x:
        :param y: defaults to 42.
        :rtype: int
        :returns: 42
        """
        pass

    def example_function_no_returns():
        """A function.

        :param int x:
        :param y: defaults to 42.
        :rtype: int
        """
        pass


# Generated at 2022-06-11 21:42:56.635831
# Unit test for function parse
def test_parse():
    text = """\
        Docstring for MyClass.

        This is a very long
        description of MyClass that spans
        multiple lines.

        :param a: first parameter
        :type a: int
        :param b: second parameter
        :type b: str
        :param c: third parameter
        :type c: float
        :param d: fourth parameter
        :type d: bool
        :return: something
        :rtype: None
        :raises TypeError: if input params are of wrong type
        """
    docstring = parse(text)

# Generated at 2022-06-11 21:43:08.490495
# Unit test for function parse
def test_parse():
    """Unit test for parse"""
    docstring = """
        Short description.

        Long description.

        :param a: A parameter.
        :raises ValueError: Raised if `a` is not valid.

        """

# Generated at 2022-06-11 21:43:14.509183
# Unit test for function parse

# Generated at 2022-06-11 21:43:29.322957
# Unit test for function parse
def test_parse():
    docstring = parse(__doc__)
    assert docstring.long_description.startswith('ReST-style docstring')
    assert docstring.meta[1].description == 'text to parse'
    assert docstring.meta[4].arg_name == 'extract_from'
    assert docstring.meta[4].type_name == 'str'
    assert docstring.meta[4].default == 'docstring object'
    assert docstring.long_description.endswith('parse docstrings.')
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

    # Test with an empty string
    docstring = parse('')
    assert docstring.short_description is None
    assert docstring.long_description is None

# Generated at 2022-06-11 21:43:41.853208
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    import io
    import pprint

    def f(x: int, y: int, z: int = 0) -> T.List[int]:
        """
        :param x: The x.
        :type x: int.
        :param y: The y.
        :type y: int.
        :param z: The z.
        :type z: int.
        :param z: Defaults to 0.
        :rtype: list of int.
        """
        return [x, y, z]

    fstring = io.StringIO()
    pprint.pprint(parse(f.__doc__), fstring)

# Generated at 2022-06-11 21:43:54.365222
# Unit test for function parse
def test_parse():
    doc = """
    Find one rectangle in given image.
    :param image: The image given by user.
    :type image: numpy.ndarray
    :param rects: The rects given by user.
    :type rects: list
    :param min_neighbors: how many neighbors each candidate rectangle should have to retain it.
    :type min_neighbors: int
    :returns: Found rectangles
    :rtype: numpy.ndarray
    """

# Generated at 2022-06-11 21:44:06.958439
# Unit test for function parse
def test_parse():
	assert inspect.cleandoc(parse.__doc__) == 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring'
	
	assert parse('') == Docstring(long_description=None, short_description=None, meta=[])
	
	assert parse('my_function()') == Docstring(long_description=None, short_description='my_function()', meta=[])
	
	assert parse('short\n\nThis is a long description.\n\nThis is the end of the long description') == Docstring(long_description='This is a long description.\n\nThis is the end of the long description', short_description='short', blank_after_short_description=False, blank_after_long_description=True, meta=[])
	

# Generated at 2022-06-11 21:44:11.030586
# Unit test for function parse
def test_parse():
    ds = """
    Just a simple test::

        a = 1
        b = 2

    Yields nothing.
    """
    assert parse(ds).long_description == 'Just a simple test::\n\n    a = 1\n    b = 2'
    assert parse(ds).meta[0].description == 'Yields nothing.'

# Generated at 2022-06-11 21:44:17.735131
# Unit test for function parse
def test_parse():
    import pytest

    def assert_parsed_equals(
        text: str,
        expected: T.Union[str, int, bool],
        attr_name: str
    ) -> None:
        try:
            text = inspect.cleandoc(text)
        except Exception as e:
            print(e)
            print("Unable to parse:")
            print(text)
            pytest.fail("Unable to parse.")
        parsed = parse(text)
        try:
            assert getattr(parsed, attr_name) == expected
        except AssertionError:
            print("Parsed docstring:")
            print(parsed)
            pytest.fail("Parsed docstring")


# Generated at 2022-06-11 21:44:26.398909
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Hi") == Docstring(
        short_description="Hi", blank_after_short_description=True
    )
    assert parse("Hi\n") == Docstring(
        short_description="Hi", blank_after_short_description=True
    )
    assert parse("Hi\n\n") == Docstring(
        short_description="Hi",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )
    assert parse("Hi\n\n\n") == Docstring(
        short_description="Hi",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

# Generated at 2022-06-11 21:44:37.880314
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring = """First line.
    Second line

    :param arg1: This is argument 1
    :raises AttributeError: Raised when foo is bar

    More text here.
    """


# Generated at 2022-06-11 21:44:48.708888
# Unit test for function parse
def test_parse():
    d = parse(inspect.cleandoc("""\
   test_parse(arg1:int, arg2:int=3, arg3:type='default') -> bool
   
   test_parse docstring
   
   :param arg1: arg1 docstring
   :param arg2: arg2 docstring, default to 3
   :param arg3: arg3 docstring (default to "default")
   :return: return docstring
   :rtype: bool
   :raises: raise docstring"""))
    # test that all fields were parsed
    assert d.short_description == "test_parse docstring"
    assert d.long_description == None
    assert d.blank_after_short_description == True
    assert d.blank_after_long_description == False
    # test that meta were parsed

# Generated at 2022-06-11 21:44:55.699368
# Unit test for function parse
def test_parse():
    # test empty strings
    assert parse("") == Docstring()

    # test string with only a short description
    doc = parse("This is a short description")
    assert doc == Docstring(short_description="This is a short description")

    # test docstring with short and long description, but no meta
    doc = parse("This is a short description.\n\nThis is a long description.")
    assert doc == Docstring(
        short_description="This is a short description.",
        long_description="This is a long description.",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )

    # test docstring with short, long and meta information

# Generated at 2022-06-11 21:45:20.463384
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    assert parse("""\
    """
    ) == Docstring()

    assert parse("""\
    foo
    """
    ) == Docstring(
        short_description="foo",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

    assert parse("""\
    foo
    bar
    """
    ) == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="bar",
        meta=[],
    )


# Generated at 2022-06-11 21:45:30.216539
# Unit test for function parse
def test_parse():
    s = """\
    Test parse

    This is a test of parse.

    :param a: parameter a
    :param b: parameter b, defaults to 5.
    :param c?: parameter c, defaults to 7?.
    :returns: return value
    :rtype: str
    :raises IOError: if open fails
    :yields: parameter d
    """
    assert parse(s).short_description == "Test parse"
    assert parse(s).long_description == """\
This is a test of parse."""
    assert parse(s).meta[0].arg_name == "a"
    assert parse(s).meta[1].arg_name == "b"
    assert parse(s).meta[1].default is None
    assert parse(s).meta[2].arg_name == "c?"

# Generated at 2022-06-11 21:45:39.943201
# Unit test for function parse
def test_parse():
    assert parse("").short_description == None
    assert parse("").long_description == None
    assert parse("").meta == []
    assert parse("\nfoo\n").short_description == None
    assert parse("\nfoo\n").long_description == None
    assert parse("\nfoo\n").meta == []
    assert parse(":foo: bar").short_description == None
    assert parse(":foo: bar").long_description == None
    assert parse(":foo: bar").meta == []
    assert parse("\nfoo\n\nbar").short_description == "foo"
    assert parse("\nfoo\n\nbar").long_description == "bar"
    assert parse("\nfoo\n\nbar").meta == []
    assert parse("\nfoo\n\nbar\n\n").short_description

# Generated at 2022-06-11 21:45:50.665151
# Unit test for function parse
def test_parse():
    os.chdir(r"C:\Users\aashu\Desktop\bprinter\src\bprinter")

    docstring = parse(test.__doc__)

    assert docstring.short_description == "This is a test function"
    assert docstring.blank_after_short_description == True
    assert docstring.long_description == "This is a long description\nThis is a long description"
    assert docstring.blank_after_long_description == False
    
    assert docstring.meta[0].keyword == "Parameters"
    assert docstring.meta[0].args == ['Parameters', 'a', ':']
    assert docstring.meta[0].description == "This is a"
    assert docstring.meta[0].arg_name == "a"

# Generated at 2022-06-11 21:46:00.249409
# Unit test for function parse
def test_parse():
    d = parse.__doc__
    assert parse(d) == Docstring(
        short_description=(
            "Parse the ReST-style docstring into its components."
        ),
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description="""\
:returns: parsed docstring""",
        meta=[
            DocstringMeta(
                args=["returns"],
                description="parsed docstring",
            ),
        ],
    )


if __name__ == "__main__":
    pass
    # globals().get(sys.argv[1], lambda: None)()

# Generated at 2022-06-11 21:46:13.028885
# Unit test for function parse
def test_parse():
    text = """
    This is a short description.

    This is a long description.
    """
    doc = parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.meta == []

    text = """
    This is a short description.
    """
    doc = parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description is None
    assert doc.meta == []

    text = """
    :param int x: The X coordinate.
    :returns: The Y coordinate.
    """
    doc = parse(text)
    assert doc.short_description is None
    assert doc.long_description is None

# Generated at 2022-06-11 21:46:23.821495
# Unit test for function parse
def test_parse():
    # Test 1
    test_docstring = """
    This is a docstring
    :param a: 1
    :param a: 2
    :param b: 3
    :param c: 3
    :param x: 4
    """
    docstring = parse(test_docstring)
    assert docstring.short_description == "This is a docstring"
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.long_description == None

# Generated at 2022-06-11 21:46:35.590379
# Unit test for function parse
def test_parse():
    """
    Unit test for function parse.
    """
    text = """
        Hello.
        :param a: something
        :param b: something else
        :returns: retval
    """
    docstring = parse(text)
    assert docstring.short_description == "Hello."
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == True
    assert docstring.long_description == ""


# Generated at 2022-06-11 21:46:45.933679
# Unit test for function parse
def test_parse():
    # Test for empty docstring.
    assert parse("") == Docstring()

    # Test for a short docstring only.
    assert parse("Hello world") == Docstring(
        short_description="Hello world",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
    )

    # Test for a docstring with a period at the end of the first line, and
    # trailing whitespace after the period.
    assert parse("Hello world.  \n") == Docstring(
        short_description="Hello world.",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
    )

    # Test for a docstring with a period at the end of the first line, and
    # trailing