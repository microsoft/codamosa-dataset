

# Generated at 2022-06-17 18:27:27.318170
# Unit test for function parse

# Generated at 2022-06-17 18:27:37.080914
# Unit test for function parse

# Generated at 2022-06-17 18:27:47.993891
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :returns: This is a description of the return value.
    :raises Exception: This is a description of the exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == True
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:27:58.669739
# Unit test for function parse

# Generated at 2022-06-17 18:28:08.835516
# Unit test for function parse

# Generated at 2022-06-17 18:28:20.746259
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :type arg1: str
    :param arg2: This is arg2.
    :type arg2: int
    :returns: This is return value.
    :rtype: str
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "This is arg1."
    assert doc.meta

# Generated at 2022-06-17 18:28:31.594571
# Unit test for function parse

# Generated at 2022-06-17 18:28:42.680782
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].keyword == "param"
    assert doc.meta[0].arg_name == "arg1"
    assert doc

# Generated at 2022-06-17 18:28:55.598183
# Unit test for function parse

# Generated at 2022-06-17 18:29:02.767051
# Unit test for function parse

# Generated at 2022-06-17 18:29:19.665153
# Unit test for function parse

# Generated at 2022-06-17 18:29:31.679011
# Unit test for function parse

# Generated at 2022-06-17 18:29:38.103118
# Unit test for function parse

# Generated at 2022-06-17 18:29:47.281347
# Unit test for function parse

# Generated at 2022-06-17 18:30:00.337091
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:30:12.603090
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a description of arg1.
    :type arg1: str
    :param arg2: This is a description of arg2.
    :type arg2: int
    :returns: This is a description of the return value.
    :rtype: str
    :raises ValueError: This is a description of the exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 4

# Generated at 2022-06-17 18:30:16.601420
# Unit test for function parse

# Generated at 2022-06-17 18:30:28.714351
# Unit test for function parse

# Generated at 2022-06-17 18:30:38.508744
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a param.
    :param arg2: This is another param.
    :type arg2: str
    :returns: This is a return.
    :rtype: int
    :raises AttributeError: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:30:49.193471
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: int
    :param arg2: this is arg2
    :type arg2: str, optional
    :returns: None
    :rtype: int
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type_name == "int"
    assert doc.meta[0].is_optional

# Generated at 2022-06-17 18:31:06.055762
# Unit test for function parse

# Generated at 2022-06-17 18:31:16.573016
# Unit test for function parse

# Generated at 2022-06-17 18:31:22.679966
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a parameter.
    :type arg1: str
    :param arg2: This is a parameter with a default value.
    :param arg3: This is a parameter with a default value.
                 Defaults to True.
    :type arg3: bool
    :returns: None
    :rtype: None
    :raises keyError: This is an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False

# Generated at 2022-06-17 18:31:31.978063
# Unit test for function parse

# Generated at 2022-06-17 18:31:37.784753
# Unit test for function parse

# Generated at 2022-06-17 18:31:46.599979
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :type arg1: int
    :param arg2: This is arg2.
    :type arg2: str
    :param arg3: This is arg3.
    :type arg3: bool
    :returns: This is return value.
    :rtype: str
    :raises Exception: This is exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert len(doc.meta) == 4
    assert doc.meta

# Generated at 2022-06-17 18:31:57.490907
# Unit test for function parse

# Generated at 2022-06-17 18:32:08.561401
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n\n") == Docstring()

    assert parse("foo") == Docstring(
        short_description="foo",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    assert parse("foo\n") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

# Generated at 2022-06-17 18:32:20.022558
# Unit test for function parse

# Generated at 2022-06-17 18:32:31.833015
# Unit test for function parse

# Generated at 2022-06-17 18:32:44.607531
# Unit test for function parse

# Generated at 2022-06-17 18:32:55.661901
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: int
    :param arg2: this is arg2
    :type arg2: str
    :param arg3: this is arg3
    :type arg3: str
    :returns: None
    :rtype: None
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:33:07.968013
# Unit test for function parse

# Generated at 2022-06-17 18:33:20.565635
# Unit test for function parse

# Generated at 2022-06-17 18:33:27.630999
# Unit test for function parse

# Generated at 2022-06-17 18:33:38.849668
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n\n") == Docstring()
    assert parse("\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:33:49.990330
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :type arg1: int
    :param arg2: This is a second argument.
    :type arg2: str
    :param arg3: This is a third argument.
    :type arg3: str
    :returns: This is a return value.
    :rtype: int
    :raises ValueError: This is a exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False

# Generated at 2022-06-17 18:34:02.684912
# Unit test for function parse

# Generated at 2022-06-17 18:34:08.004791
# Unit test for function parse

# Generated at 2022-06-17 18:34:15.271922
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a param.
    :type arg1: str
    :param arg2: This is a param with a default value.
    :param arg3: This is a param with a default value.
        Defaults to True.
    :type arg2: int, optional
    :type arg3: bool, optional
    :returns: This is a return.
    :rtype: int
    :raises keyError: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description

# Generated at 2022-06-17 18:34:33.151661
# Unit test for function parse

# Generated at 2022-06-17 18:34:43.435883
# Unit test for function parse

# Generated at 2022-06-17 18:34:56.824820
# Unit test for function parse

# Generated at 2022-06-17 18:35:09.028484
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :type arg1: str
    :param arg2: This is arg2.
    :type arg2: int
    :returns: This is a return.
    :rtype: int
    """
    docstring = parse(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].type_name == "str"

# Generated at 2022-06-17 18:35:21.221791
# Unit test for function parse

# Generated at 2022-06-17 18:35:29.699850
# Unit test for function parse

# Generated at 2022-06-17 18:35:41.345821
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring = """
    Short description.

    Long description.

    :param arg1: This is arg1.
    :type arg1: int
    :param arg2: This is arg2.
    :type arg2: str
    :param arg3: This is arg3.
    :type arg3: str
    :returns: None
    :rtype: None
    """
    docstring_obj = parse(docstring)
    assert docstring_obj.short_description == "Short description."
    assert docstring_obj.long_description == "Long description."
    assert docstring_obj.blank_after_short_description == True
    assert docstring_obj.blank_after_long_description == False
    assert len(docstring_obj.meta) == 4
    assert docstring_

# Generated at 2022-06-17 18:35:52.015549
# Unit test for function parse

# Generated at 2022-06-17 18:36:04.637262
# Unit test for function parse

# Generated at 2022-06-17 18:36:13.798124
# Unit test for function parse

# Generated at 2022-06-17 18:36:26.064052
# Unit test for function parse

# Generated at 2022-06-17 18:36:36.290743
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:36:47.569967
# Unit test for function parse

# Generated at 2022-06-17 18:36:57.757716
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :returns: This is the return value.
    :raises Exception: This is the exception.
    """
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == "This is a short description."
    assert parsed_docstring.long_description == "This is a long description."
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_docstring.blank_after_long_description == False
    assert parsed_docstring.meta[0].arg_name == "arg1"
    assert parsed_docstring.meta[0].description == "This is the first argument."

# Generated at 2022-06-17 18:37:07.577360
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.
    """
    assert parse(docstring) == Docstring(
        short_description="This is a short description.",
        blank_after_short_description=True,
        long_description="This is a long description.",
        blank_after_long_description=True,
        meta=[],
    )

    docstring = """
    This is a short description.

    This is a long description.
    """
    assert parse(docstring) == Docstring(
        short_description="This is a short description.",
        blank_after_short_description=True,
        long_description="This is a long description.",
        blank_after_long_description=True,
        meta=[],
    )
