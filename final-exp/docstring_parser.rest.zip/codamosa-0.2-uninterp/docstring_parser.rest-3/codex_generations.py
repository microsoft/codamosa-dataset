

# Generated at 2022-06-17 18:27:30.336228
# Unit test for function parse

# Generated at 2022-06-17 18:27:39.800601
# Unit test for function parse

# Generated at 2022-06-17 18:27:53.286411
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :param arg3: This is the third argument.
    :returns: This is the return type.
    :raises: This is the exception type.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a test docstring."
    assert parsed.long_description == "This is the first argument.\nThis is the second argument.\nThis is the third argument."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:28:03.545910
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param int a: This is the first parameter.
    :param str b: This is the second parameter.
    :param c: This is the third parameter.
    :returns: This is the return value.
    :rtype: int
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 4
    assert doc.meta[0].arg_name == "a"
    assert doc.meta[0].type_name == "int"
    assert doc.meta

# Generated at 2022-06-17 18:28:11.537777
# Unit test for function parse

# Generated at 2022-06-17 18:28:18.060197
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:28:24.709838
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is the first argument.
    :type arg1: str
    :param arg2: This is the second argument.
    :type arg2: int, optional
    :returns: This is the return value.
    :rtype: int
    """
    result = parse(docstring)
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert result.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:28:35.069205
# Unit test for function parse

# Generated at 2022-06-17 18:28:43.937286
# Unit test for function parse

# Generated at 2022-06-17 18:28:56.289560
# Unit test for function parse

# Generated at 2022-06-17 18:29:11.992662
# Unit test for function parse

# Generated at 2022-06-17 18:29:21.055705
# Unit test for function parse

# Generated at 2022-06-17 18:29:32.136162
# Unit test for function parse

# Generated at 2022-06-17 18:29:40.249131
# Unit test for function parse

# Generated at 2022-06-17 18:29:53.669008
# Unit test for function parse

# Generated at 2022-06-17 18:30:05.052502
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: int
    :param arg2: this is arg2
    :type arg2: str, optional
    :returns: None
    :rtype: int
    """

# Generated at 2022-06-17 18:30:13.891924
# Unit test for function parse

# Generated at 2022-06-17 18:30:23.508260
# Unit test for function parse

# Generated at 2022-06-17 18:30:34.824553
# Unit test for function parse

# Generated at 2022-06-17 18:30:47.159351
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param int x: This is a test parameter.
    :param str y: This is another test parameter.
    :returns: This is a test return value.
    :rtype: int
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == "This is a test docstring."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["param", "int", "x"]
    assert doc.meta[0].description == "This is a test parameter."
    assert doc.meta[0].arg_name == "x"

# Generated at 2022-06-17 18:31:04.445466
# Unit test for function parse

# Generated at 2022-06-17 18:31:15.686009
# Unit test for function parse

# Generated at 2022-06-17 18:31:25.756749
# Unit test for function parse

# Generated at 2022-06-17 18:31:37.131711
# Unit test for function parse

# Generated at 2022-06-17 18:31:46.240555
# Unit test for function parse

# Generated at 2022-06-17 18:31:57.376026
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is the first argument.
    :type arg1: str
    :param arg2: This is the second argument.
    :type arg2: int
    :returns: This is the return value.
    :rtype: bool
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].type_name == "str"

# Generated at 2022-06-17 18:32:08.400397
# Unit test for function parse

# Generated at 2022-06-17 18:32:19.937932
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ['param', 'arg1']
    assert doc.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:32:31.465588
# Unit test for function parse

# Generated at 2022-06-17 18:32:42.309705
# Unit test for function parse

# Generated at 2022-06-17 18:32:59.343804
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.
    """
    assert parse(docstring) == Docstring(
        short_description="This is a short description.",
        blank_after_short_description=True,
        long_description="This is a long description.",
        blank_after_long_description=False,
        meta=[],
    )

    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a description of arg1.
    :param arg2: This is a description of arg2.
    :param arg3: This is a description of arg3.
    :returns: This is a description of the return value.
    :rtype: str
    """

# Generated at 2022-06-17 18:33:06.545236
# Unit test for function parse

# Generated at 2022-06-17 18:33:19.159584
# Unit test for function parse

# Generated at 2022-06-17 18:33:26.664408
# Unit test for function parse

# Generated at 2022-06-17 18:33:37.899558
# Unit test for function parse

# Generated at 2022-06-17 18:33:49.651837
# Unit test for function parse

# Generated at 2022-06-17 18:34:02.462357
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a param.
    :type arg1: str
    :param arg2: This is a param with a default value.
    :param arg3: This is a param with a default value.
        Defaults to True.
    :type arg3: bool
    :returns: This is a return.
    :rtype: int
    :raises keyError: This is an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False

# Generated at 2022-06-17 18:34:11.607415
# Unit test for function parse

# Generated at 2022-06-17 18:34:21.715435
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :type arg1: int
    :param arg2: This is a second argument.
    :type arg2: str
    :param arg3: This is a third argument.
    :type arg3: str
    :param arg4: This is a fourth argument.
    :type arg4: str
    :returns: This is a description of what is returned.
    :rtype: int
    :raises keyError: raises an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True

# Generated at 2022-06-17 18:34:32.667829
# Unit test for function parse

# Generated at 2022-06-17 18:34:46.565948
# Unit test for function parse

# Generated at 2022-06-17 18:34:58.125339
# Unit test for function parse

# Generated at 2022-06-17 18:35:10.626637
# Unit test for function parse

# Generated at 2022-06-17 18:35:23.089155
# Unit test for function parse

# Generated at 2022-06-17 18:35:36.323350
# Unit test for function parse

# Generated at 2022-06-17 18:35:48.803065
# Unit test for function parse

# Generated at 2022-06-17 18:35:55.859880
# Unit test for function parse

# Generated at 2022-06-17 18:36:06.745066
# Unit test for function parse
def test_parse():
    docstring = """
    Test function.

    :param arg1: The first argument.
    :type arg1: str
    :param arg2: The second argument.
    :type arg2: int, optional
    :returns: Description of return value.
    :rtype: int
    :raises keyError: raises an exception
    """
    doc = parse(docstring)
    assert doc.short_description == "Test function."
    assert doc.long_description == "The first argument.\nThe second argument."
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "The first argument."
    assert doc.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:36:15.337318
# Unit test for function parse

# Generated at 2022-06-17 18:36:22.805440
# Unit test for function parse

# Generated at 2022-06-17 18:36:39.224705
# Unit test for function parse

# Generated at 2022-06-17 18:36:50.801715
# Unit test for function parse

# Generated at 2022-06-17 18:37:00.066827
# Unit test for function parse

# Generated at 2022-06-17 18:37:08.637561
# Unit test for function parse