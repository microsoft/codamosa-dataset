

# Generated at 2022-06-17 18:27:28.009805
# Unit test for function parse

# Generated at 2022-06-17 18:27:37.565666
# Unit test for function parse

# Generated at 2022-06-17 18:27:48.117922
# Unit test for function parse

# Generated at 2022-06-17 18:27:58.670679
# Unit test for function parse

# Generated at 2022-06-17 18:28:08.834843
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :type arg1: str
    :param arg2: This is a second argument.
    :type arg2: int
    :returns: This is a return value.
    :rtype: str
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type_name == "str"


# Generated at 2022-06-17 18:28:20.746182
# Unit test for function parse

# Generated at 2022-06-17 18:28:30.951743
# Unit test for function parse

# Generated at 2022-06-17 18:28:42.486565
# Unit test for function parse

# Generated at 2022-06-17 18:28:55.482817
# Unit test for function parse

# Generated at 2022-06-17 18:29:02.696308
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is the first argument.
    :type arg1: str
    :param arg2: This is the second argument.
    :type arg2: int
    :returns: This is the return value.
    :rtype: bool
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type_name == "str"

# Generated at 2022-06-17 18:29:17.592196
# Unit test for function parse

# Generated at 2022-06-17 18:29:29.887617
# Unit test for function parse

# Generated at 2022-06-17 18:29:39.679189
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].description == "This is a first argument."
    assert parsed.meta[1].args == ["param", "arg2"]
    assert parsed.meta

# Generated at 2022-06-17 18:29:48.486377
# Unit test for function parse

# Generated at 2022-06-17 18:30:01.361227
# Unit test for function parse

# Generated at 2022-06-17 18:30:12.743878
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False

    docstring = """
    This is a short description.

    This is a long description.

    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == True


# Generated at 2022-06-17 18:30:21.449573
# Unit test for function parse

# Generated at 2022-06-17 18:30:30.075885
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n\n") == Docstring()
    assert parse("\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:30:39.185258
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :type arg1: int
    :param arg2: This is arg2.
    :type arg2: str, optional
    :param arg3: This is arg3.
    :type arg3: str, optional, defaults to 'hello world'.
    :returns: This is a description of what is returned.
    :rtype: int
    :raises keyError: This is a description of what raises this exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_

# Generated at 2022-06-17 18:30:49.315825
# Unit test for function parse

# Generated at 2022-06-17 18:31:06.500093
# Unit test for function parse

# Generated at 2022-06-17 18:31:16.992861
# Unit test for function parse

# Generated at 2022-06-17 18:31:26.155296
# Unit test for function parse

# Generated at 2022-06-17 18:31:37.643740
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: Description of arg1.
    :param arg2: Description of arg2.
    :returns: Description of return value.
    :raises ValueError: Description of exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].description == "Description of arg1."
    assert parsed.meta[1].args == ["param", "arg2"]

# Generated at 2022-06-17 18:31:46.529045
# Unit test for function parse

# Generated at 2022-06-17 18:31:57.414297
# Unit test for function parse

# Generated at 2022-06-17 18:32:08.498861
# Unit test for function parse

# Generated at 2022-06-17 18:32:20.022235
# Unit test for function parse

# Generated at 2022-06-17 18:32:26.781333
# Unit test for function parse
def test_parse():
    from .common import Docstring
    from .common import DocstringMeta
    from .common import DocstringParam
    from .common import DocstringRaises
    from .common import DocstringReturns
    from .common import ParseError
    from .common import PARAM_KEYWORDS
    from .common import RAISES_KEYWORDS
    from .common import RETURNS_KEYWORDS
    from .common import YIELDS_KEYWORDS
    from .common import _build_meta
    from .common import parse
    from .common import test_parse
    from .common import typing as T
    from .common import inspect
    from .common import re
    import inspect
    import re
    import typing as T


# Generated at 2022-06-17 18:32:33.435895
# Unit test for function parse

# Generated at 2022-06-17 18:32:48.109428
# Unit test for function parse

# Generated at 2022-06-17 18:32:59.088521
# Unit test for function parse

# Generated at 2022-06-17 18:33:10.056869
# Unit test for function parse

# Generated at 2022-06-17 18:33:21.340337
# Unit test for function parse

# Generated at 2022-06-17 18:33:28.202808
# Unit test for function parse

# Generated at 2022-06-17 18:33:39.282018
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """

    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:33:50.299025
# Unit test for function parse

# Generated at 2022-06-17 18:34:02.728506
# Unit test for function parse

# Generated at 2022-06-17 18:34:11.795336
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return.
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:34:21.890739
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :returns: This is the return value.
    :raises Exception: This is the exception.
    """
    docstring = parse(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].description == "This is the first argument."

# Generated at 2022-06-17 18:34:39.501645
# Unit test for function parse

# Generated at 2022-06-17 18:34:47.639590
# Unit test for function parse

# Generated at 2022-06-17 18:34:58.451124
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 4
    assert parsed.meta[0].keyword == "param"
    assert parsed.meta[0].arg_name == "arg1"
   

# Generated at 2022-06-17 18:35:10.672149
# Unit test for function parse

# Generated at 2022-06-17 18:35:23.143181
# Unit test for function parse

# Generated at 2022-06-17 18:35:36.369199
# Unit test for function parse

# Generated at 2022-06-17 18:35:48.847913
# Unit test for function parse

# Generated at 2022-06-17 18:36:01.760997
# Unit test for function parse

# Generated at 2022-06-17 18:36:12.915505
# Unit test for function parse

# Generated at 2022-06-17 18:36:23.029945
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str, optional
    :returns: Description of return value.
    :rtype: int
    """

# Generated at 2022-06-17 18:36:38.685656
# Unit test for function parse

# Generated at 2022-06-17 18:36:53.178922
# Unit test for function parse

# Generated at 2022-06-17 18:37:01.337925
# Unit test for function parse