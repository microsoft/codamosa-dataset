

# Generated at 2022-06-17 18:27:40.376576
# Unit test for function parse

# Generated at 2022-06-17 18:27:53.354752
# Unit test for function parse

# Generated at 2022-06-17 18:28:03.548210
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: description
    :param arg2: description
    :param arg3: description
    :type arg1: str
    :type arg2: int
    :type arg3: bool
    :returns: description
    :rtype: str
    :raises TypeError: description
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].args == ['param', 'arg1']
    assert parsed.meta[0].description == 'description'

# Generated at 2022-06-17 18:28:11.516894
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :param arg2: this is arg2
    :param arg3: this is arg3
    :returns: None
    :raises keyError: raises an exception
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "this is arg1"
    assert doc.meta[1].args == ["param", "arg2"]
    assert doc.meta[1].description == "this is arg2"
   

# Generated at 2022-06-17 18:28:22.106513
# Unit test for function parse

# Generated at 2022-06-17 18:28:32.714669
# Unit test for function parse

# Generated at 2022-06-17 18:28:43.084251
# Unit test for function parse

# Generated at 2022-06-17 18:28:55.807170
# Unit test for function parse

# Generated at 2022-06-17 18:29:07.261210
# Unit test for function parse

# Generated at 2022-06-17 18:29:18.101821
# Unit test for function parse

# Generated at 2022-06-17 18:29:34.204019
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :returns: This is a description of the return value.
    :raises keyError: This is a description of a raised exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:29:41.782556
# Unit test for function parse

# Generated at 2022-06-17 18:29:54.240251
# Unit test for function parse

# Generated at 2022-06-17 18:30:05.640310
# Unit test for function parse

# Generated at 2022-06-17 18:30:15.909899
# Unit test for function parse

# Generated at 2022-06-17 18:30:28.369221
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a parameter.
    :type arg1: str
    :param arg2: This is a parameter with a default value.
    :param arg3: This is a parameter with a default value.
                 Defaults to 0.
    :type arg3: int
    :returns: None
    :rtype: None
    :raises keyError: This is an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 4
    assert parsed

# Generated at 2022-06-17 18:30:38.298974
# Unit test for function parse

# Generated at 2022-06-17 18:30:49.160447
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: int
    :param arg2: this is arg2
    :type arg2: str, optional
    :returns: None
    :rtype: int
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type_name == "int"
    assert doc.meta[0].is_optional

# Generated at 2022-06-17 18:30:57.072006
# Unit test for function parse

# Generated at 2022-06-17 18:31:06.433287
# Unit test for function parse

# Generated at 2022-06-17 18:31:21.685528
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: description of arg1
    :type arg1: int
    :param arg2: description of arg2
    :type arg2: str
    :returns: description of return value
    :rtype: bool
    :raises ValueError: if arg1 is not an int
    """
    doc = parse(docstring)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].keyword == "param"
    assert doc.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:31:31.281716
# Unit test for function parse

# Generated at 2022-06-17 18:31:42.365675
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 3
    assert parsed.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:31:48.357483
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: int
    :param arg2: this is arg2
    :type arg2: str, optional
    :returns: None
    :rtype: int
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type_name == "int"
    assert doc.meta[0].is_optional == False

# Generated at 2022-06-17 18:31:58.053581
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """

# Generated at 2022-06-17 18:32:09.569915
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:32:20.628064
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: description
    :param arg2: description
    :returns: description
    :raises Exception: description
    """
    doc = parse(docstring)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "description"
    assert doc.meta[1].args == ["param", "arg2"]
    assert doc.meta[1].description == "description"

# Generated at 2022-06-17 18:32:27.017322
# Unit test for function parse

# Generated at 2022-06-17 18:32:33.456510
# Unit test for function parse

# Generated at 2022-06-17 18:32:43.491805
# Unit test for function parse

# Generated at 2022-06-17 18:33:03.387910
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :type arg1: int
    :param arg2: This is arg2.
    :type arg2: str
    :param arg3: This is arg3.
    :type arg3: str
    :returns: This is a description of what is returned.
    :rtype: int
    :raises keyError: raises an exception
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert len(doc.meta) == 4
   

# Generated at 2022-06-17 18:33:11.706290
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a parameter.
    :type arg1: str
    :param arg2: This is a parameter with a default value.
    :param arg3: This is a parameter with a default value.
                 The default value is ``True``.
    :type arg3: bool
    :returns: This is a return value.
    :rtype: int
    :raises keyError: This is a possibility of a KeyError.
    """

# Generated at 2022-06-17 18:33:22.044841
# Unit test for function parse

# Generated at 2022-06-17 18:33:28.696403
# Unit test for function parse

# Generated at 2022-06-17 18:33:39.490549
# Unit test for function parse

# Generated at 2022-06-17 18:33:50.372659
# Unit test for function parse

# Generated at 2022-06-17 18:34:02.730493
# Unit test for function parse

# Generated at 2022-06-17 18:34:14.471392
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a param.
    :type arg1: int
    :param arg2: This is a param with a default value.
    :param arg3: This is a param with a default value.
        The default value is ``True``.
    :type arg3: bool
    :returns: This is a return.
    :rtype: int
    :raises keyError: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description

# Generated at 2022-06-17 18:34:23.423587
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :returns: This is a description of the return value.
    :raises keyError: This is a description of a raised exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == True
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].type_name == None
    assert parsed.meta[0].is_optional == None

# Generated at 2022-06-17 18:34:33.921349
# Unit test for function parse

# Generated at 2022-06-17 18:34:55.174938
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Nothing.
    :raises Exception: If something bad happens.
    """
    doc = parse(docstring)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[1].arg_name == "arg2"
    assert doc.meta[2].type_name == "Exception"


# Generated at 2022-06-17 18:35:01.578788
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: Description of arg1.
    :type arg1: str
    :param arg2: Description of arg2.
    :type arg2: str
    :returns: Description of return value.
    :rtype: str
    :raises ValueError: Description of exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 4
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].type_name == "str"
    assert parsed.meta

# Generated at 2022-06-17 18:35:12.540456
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a test function."
    assert parsed.long_description == None
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].args == ['param', 'x', 'x']
    assert parsed.meta[0].description == 'x'
    assert parsed.meta[0].arg_name == 'x'
    assert parsed.meta[0].type_name == 'int'

# Generated at 2022-06-17 18:35:24.585890
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """

# Generated at 2022-06-17 18:35:36.548911
# Unit test for function parse

# Generated at 2022-06-17 18:35:48.973918
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == True
    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:35:55.954465
# Unit test for function parse

# Generated at 2022-06-17 18:36:00.234114
# Unit test for function parse

# Generated at 2022-06-17 18:36:11.460406
# Unit test for function parse

# Generated at 2022-06-17 18:36:21.674347
# Unit test for function parse

# Generated at 2022-06-17 18:36:37.931347
# Unit test for function parse

# Generated at 2022-06-17 18:36:49.447339
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a description of arg1.
    :param arg2: This is a description of arg2.
    :param arg3: This is a description of arg3.
    :type arg1: str
    :type arg2: int
    :type arg3: float
    :returns: This is a description of the return value.
    :rtype: str
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 6
    assert doc

# Generated at 2022-06-17 18:36:59.105402
# Unit test for function parse

# Generated at 2022-06-17 18:37:07.950761
# Unit test for function parse