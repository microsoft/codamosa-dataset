

# Generated at 2022-06-17 18:27:29.650988
# Unit test for function parse

# Generated at 2022-06-17 18:27:39.497995
# Unit test for function parse

# Generated at 2022-06-17 18:27:53.334353
# Unit test for function parse

# Generated at 2022-06-17 18:28:03.550405
# Unit test for function parse

# Generated at 2022-06-17 18:28:11.517700
# Unit test for function parse

# Generated at 2022-06-17 18:28:22.102762
# Unit test for function parse

# Generated at 2022-06-17 18:28:31.568804
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param int x: The x parameter.
    :param int y: The y parameter.
    :returns: The sum of x and y.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ["param", "int", "x"]
    assert doc.meta[0].description == "The x parameter."
    assert doc.meta[1].args == ["param", "int", "y"]

# Generated at 2022-06-17 18:28:42.684316
# Unit test for function parse

# Generated at 2022-06-17 18:28:49.495624
# Unit test for function parse

# Generated at 2022-06-17 18:29:00.482178
# Unit test for function parse

# Generated at 2022-06-17 18:29:16.614418
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:29:28.836406
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n\n") == Docstring()
    assert parse("\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:29:39.569776
# Unit test for function parse
def test_parse():
    """Test the parse function."""

# Generated at 2022-06-17 18:29:48.428255
# Unit test for function parse

# Generated at 2022-06-17 18:30:01.319668
# Unit test for function parse

# Generated at 2022-06-17 18:30:12.744053
# Unit test for function parse

# Generated at 2022-06-17 18:30:21.450770
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring = """
    This is a test docstring.

    :param foo: The foo parameter.
    :type foo: str
    :param bar: The bar parameter.
    :type bar: int
    :returns: The return value.
    :rtype: str
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""
    assert doc.blank_after_short_description
    assert not doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "foo"
    assert doc.meta[0].type_name == "str"
    assert doc.meta[0].description == "The foo parameter."
   

# Generated at 2022-06-17 18:30:30.079033
# Unit test for function parse

# Generated at 2022-06-17 18:30:39.185874
# Unit test for function parse
def test_parse():
    """Test function parse"""
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :type arg1: int
    :param arg2: This is a second argument.
    :type arg2: str
    :returns: This is a description of what is returned.
    :rtype: int
    :raises keyError: raises an exception
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:30:49.316558
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :type arg1: int
    :param arg2: This is a second argument.
    :type arg2: str
    :param arg3: This is a third argument.
    :type arg3: str
    :param arg4: This is a fourth argument.
    :type arg4: str
    :returns: This is a description of what is returned.
    :rtype: int
    :raises keyError: raises an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description

# Generated at 2022-06-17 18:31:08.737689
# Unit test for function parse

# Generated at 2022-06-17 18:31:18.522572
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:31:28.283428
# Unit test for function parse

# Generated at 2022-06-17 18:31:34.987725
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:31:40.586693
# Unit test for function parse

# Generated at 2022-06-17 18:31:54.667577
# Unit test for function parse

# Generated at 2022-06-17 18:31:59.860439
# Unit test for function parse

# Generated at 2022-06-17 18:32:11.821663
# Unit test for function parse
def test_parse():
    docstring = """
    This function does something.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str, optional
    :returns: Description of return value.
    :rtype: int
    """

# Generated at 2022-06-17 18:32:22.207890
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :param arg2: This is arg2.
    :type arg2: str
    :param arg3: This is arg3.
    :type arg3: str, optional
    :param arg4: This is arg4.
    :type arg4: str, optional
    :param arg5: This is arg5.
    :type arg5: str, optional, defaults to 'hello world'.
    :returns: This is a description of what is returned.
    :rtype: int
    :returns: This is another description of what is returned.
    :rtype: int
    :raises keyError: raises an exception
    :raises keyError2: raises an exception
    """
    doc

# Generated at 2022-06-17 18:32:34.251469
# Unit test for function parse

# Generated at 2022-06-17 18:32:46.629361
# Unit test for function parse
def test_parse():
    text = """
    This is a short description.

    This is a long description.

    :param x: This is a parameter.
    :type x: int
    :param y: This is another parameter.
    :type y: str
    :returns: This is what is returned.
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "x"]
    assert docstring.meta[0].description == "This is a parameter."
    assert doc

# Generated at 2022-06-17 18:32:57.733726
# Unit test for function parse

# Generated at 2022-06-17 18:33:09.008722
# Unit test for function parse

# Generated at 2022-06-17 18:33:21.362451
# Unit test for function parse

# Generated at 2022-06-17 18:33:28.139126
# Unit test for function parse

# Generated at 2022-06-17 18:33:38.726077
# Unit test for function parse

# Generated at 2022-06-17 18:33:49.949095
# Unit test for function parse
def test_parse():
    """Test the parse function."""

# Generated at 2022-06-17 18:34:02.685484
# Unit test for function parse

# Generated at 2022-06-17 18:34:11.762787
# Unit test for function parse

# Generated at 2022-06-17 18:34:21.825009
# Unit test for function parse

# Generated at 2022-06-17 18:34:35.652690
# Unit test for function parse

# Generated at 2022-06-17 18:34:44.884032
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is another parameter.
    :type bar: int
    :returns: This is what is returned.
    :rtype: bool
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "foo"
    assert doc.meta[0].type_name == "str"

# Generated at 2022-06-17 18:34:57.472145
# Unit test for function parse

# Generated at 2022-06-17 18:35:10.113844
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:35:22.261628
# Unit test for function parse

# Generated at 2022-06-17 18:35:30.229805
# Unit test for function parse

# Generated at 2022-06-17 18:35:41.854679
# Unit test for function parse

# Generated at 2022-06-17 18:35:55.032801
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str, optional
    :returns: Description of return value.
    :rtype: int
    """

# Generated at 2022-06-17 18:36:06.106717
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :param arg2: This is arg2.
    :type arg2: int
    :param arg3: This is arg3.
    :type arg3: int, optional
    :param arg4: This is arg4.
    :type arg4: int, optional
        defaults to 42.
    :returns: This is return value.
    :rtype: int
    :raises ValueError: This is raised when value error.
    :raises TypeError: This is raised when type error.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc

# Generated at 2022-06-17 18:36:14.527977
# Unit test for function parse

# Generated at 2022-06-17 18:36:30.170411
# Unit test for function parse

# Generated at 2022-06-17 18:36:40.924002
# Unit test for function parse

# Generated at 2022-06-17 18:36:54.407172
# Unit test for function parse

# Generated at 2022-06-17 18:36:59.223867
# Unit test for function parse

# Generated at 2022-06-17 18:37:08.069892
# Unit test for function parse