

# Generated at 2022-06-17 18:27:22.077754
# Unit test for function parse

# Generated at 2022-06-17 18:27:30.973430
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param int x: The x coordinate.
    :param int y: The y coordinate.
    :returns: The distance.
    :raises ValueError: If x or y is negative.
    """

# Generated at 2022-06-17 18:27:37.443309
# Unit test for function parse

# Generated at 2022-06-17 18:27:47.910276
# Unit test for function parse

# Generated at 2022-06-17 18:27:58.603264
# Unit test for function parse

# Generated at 2022-06-17 18:28:08.128341
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param int x: This is a parameter.
    :param str y: This is another parameter.
    :returns: This is a return value.
    :rtype: str
    """

# Generated at 2022-06-17 18:28:15.384143
# Unit test for function parse

# Generated at 2022-06-17 18:28:23.716298
# Unit test for function parse

# Generated at 2022-06-17 18:28:33.691103
# Unit test for function parse

# Generated at 2022-06-17 18:28:43.382835
# Unit test for function parse

# Generated at 2022-06-17 18:29:01.412831
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:29:12.740059
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: description
    :param arg2: description
    :param arg3: description
    :returns: description
    :raises Exception: description
    """
    assert parse(docstring).short_description == "Short description."
    assert parse(docstring).long_description == "Long description."
    assert parse(docstring).meta[0].arg_name == "arg1"
    assert parse(docstring).meta[1].arg_name == "arg2"
    assert parse(docstring).meta[2].arg_name == "arg3"
    assert parse(docstring).meta[3].type_name == "None"
    assert parse(docstring).meta[4].type_name == "Exception"

# Generated at 2022-06-17 18:29:21.519291
# Unit test for function parse

# Generated at 2022-06-17 18:29:32.472362
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :returns: This is a description of the return value.
    :raises keyError: This is a description of a raised exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:29:40.556240
# Unit test for function parse

# Generated at 2022-06-17 18:29:53.843692
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :returns: This is a description of the return value.
    :raises keyError: This is a description of a raised exception.
    """

# Generated at 2022-06-17 18:30:05.311002
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :type arg1: str
    :param arg2: This is arg2.
    :type arg2: int
    :returns: This is return.
    :rtype: str
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].args == ['param', 'arg1']
    assert parsed.meta[0].description == "This is arg1."

# Generated at 2022-06-17 18:30:14.117218
# Unit test for function parse

# Generated at 2022-06-17 18:30:27.433638
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a param.
    :type arg1: int
    :param arg2: This is a param with a default value.
    :param arg3: This is a param with a default value.
    :type arg3: str
    :default arg3: foo
    :param arg4: This is a param with a type and a default value.
    :type arg4: str
    :default arg4: foo
    :param arg5: This is a param with a type and a default value.
    :type arg5: str
    :default arg5: foo
    :returns: This is a return.
    :rtype: int
    :raises keyError: This is an exception.
    """

# Generated at 2022-06-17 18:30:37.645357
# Unit test for function parse

# Generated at 2022-06-17 18:30:56.222511
# Unit test for function parse

# Generated at 2022-06-17 18:31:05.808465
# Unit test for function parse

# Generated at 2022-06-17 18:31:16.261370
# Unit test for function parse
def test_parse():
    text = """
    This is a short description.

    This is a long description.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :param arg3: This is the third argument.
    :returns: This is the return value.
    :raises Exception: This is the exception.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:31:25.453904
# Unit test for function parse

# Generated at 2022-06-17 18:31:36.771931
# Unit test for function parse

# Generated at 2022-06-17 18:31:46.024551
# Unit test for function parse

# Generated at 2022-06-17 18:31:57.294991
# Unit test for function parse

# Generated at 2022-06-17 18:32:02.755173
# Unit test for function parse
def test_parse():
    """Test parse function."""
    docstring = """
    Short description.

    Long description.

    :param arg1: description of arg1
    :type arg1: int
    :param arg2: description of arg2
    :type arg2: str
    :returns: description of return value
    :rtype: int
    :raises ValueError: if something bad happens
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:32:15.114629
# Unit test for function parse

# Generated at 2022-06-17 18:32:24.212192
# Unit test for function parse

# Generated at 2022-06-17 18:32:48.493063
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:32:56.630242
# Unit test for function parse

# Generated at 2022-06-17 18:33:08.439975
# Unit test for function parse

# Generated at 2022-06-17 18:33:20.759636
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param int arg1: Description of arg1.
    :param str arg2: Description of arg2.
    :param arg3: Description of arg3.
    :returns: Description of return value.
    :rtype: int
    :raises ValueError: Description of exception.
    """

# Generated at 2022-06-17 18:33:27.768465
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """

    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:33:38.965027
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ['param', 'arg1']
    assert doc.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:33:50.031910
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :param arg2: this is arg2
    :param arg3: this is arg3
    :type arg1: int
    :type arg2: str
    :type arg3: bool
    :returns: None
    :rtype: None
    :raises keyError: raises KeyError
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ['param', 'arg1']
    assert doc.meta

# Generated at 2022-06-17 18:34:02.686500
# Unit test for function parse

# Generated at 2022-06-17 18:34:11.763287
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :type arg1: str
    :param arg2: This is arg2.
    :type arg2: int
    :returns: This is the return value.
    :rtype: str
    :raises ValueError: This is the exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type

# Generated at 2022-06-17 18:34:16.381442
# Unit test for function parse

# Generated at 2022-06-17 18:34:43.876072
# Unit test for function parse

# Generated at 2022-06-17 18:34:57.045075
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:35:09.402946
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param int x: This is a parameter.
    :param str y: This is another parameter.
    :returns: This is a return value.
    :rtype: int
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ["param", "int", "x"]
    assert doc.meta[0].description == "This is a parameter."
    assert doc.meta[0].arg_name == "x"

# Generated at 2022-06-17 18:35:21.456131
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "This is a first argument."
    assert doc.meta[1].args == ["param", "arg2"]
    assert doc.meta

# Generated at 2022-06-17 18:35:29.812147
# Unit test for function parse

# Generated at 2022-06-17 18:35:41.442967
# Unit test for function parse

# Generated at 2022-06-17 18:35:52.047508
# Unit test for function parse

# Generated at 2022-06-17 18:36:04.633683
# Unit test for function parse

# Generated at 2022-06-17 18:36:13.799487
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: int
    :param arg2: this is arg2
    :type arg2: str, optional
    :returns: None
    :rtype: int
    """
    ret = parse(docstring)
    assert ret.short_description == "This is a short description."
    assert ret.long_description == "This is a long description."
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == False
    assert len(ret.meta) == 3
    assert ret.meta[0].arg_name == "arg1"
    assert ret.meta[0].type_name == "int"

# Generated at 2022-06-17 18:36:23.790626
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    result = parse(docstring)
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert result.meta[0].args == ['param', 'arg1']
    assert result.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:36:54.612389
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :returns: This is the return value.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "This is the first argument."
    assert doc.meta[1].args == ["param", "arg2"]

# Generated at 2022-06-17 18:37:05.258536
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring = """
    This is a short description.

    This is a long description.

    :param int x: This is a parameter.
    :param str y: This is another parameter.
    :returns: This is a return value.
    :rtype: int
    """