

# Generated at 2022-06-17 18:27:36.865775
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :returns: None
    :raises keyError: raises an exception
    """
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == "This is a short description."
    assert parsed_docstring.long_description == "This is a long description."
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_docstring.blank_after_long_description == False
    assert parsed_docstring.meta[0].arg_name == "arg1"
    assert parsed_docstring.meta[0].description == "This is a first argument."
    assert parsed_doc

# Generated at 2022-06-17 18:27:47.887315
# Unit test for function parse

# Generated at 2022-06-17 18:27:58.604100
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return.
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ['arg1', 'This', 'is', 'a', 'first', 'argument.']

# Generated at 2022-06-17 18:28:08.800365
# Unit test for function parse

# Generated at 2022-06-17 18:28:20.746195
# Unit test for function parse

# Generated at 2022-06-17 18:28:31.628820
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param str name: The name of the person.
    :param int age: The age of the person.
    :param bool is_cool: Whether the person is cool.
    :returns: The person's name and age.
    :rtype: str
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].arg_name == "name"
    assert parsed.meta[0].type_name == "str"
    assert parsed

# Generated at 2022-06-17 18:28:35.526249
# Unit test for function parse

# Generated at 2022-06-17 18:28:44.175849
# Unit test for function parse

# Generated at 2022-06-17 18:28:56.398734
# Unit test for function parse

# Generated at 2022-06-17 18:29:03.037756
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: description
    :type arg1: str
    :param arg2: description
    :type arg2: int
    :param arg3: description
    :type arg3: float
    :param arg4: description
    :type arg4: str
    :param arg5: description
    :type arg5: int
    :param arg6: description
    :type arg6: float
    :returns: description
    :rtype: str
    :raises Exception: description
    :raises ValueError: description
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_short_description == True

# Generated at 2022-06-17 18:29:19.109904
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is a raised exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:29:31.408929
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :type arg1: str
    :param arg2: This is arg2.
    :type arg2: str
    :returns: This is a return.
    :rtype: str
    :raises ValueError: This is a raise.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description

# Generated at 2022-06-17 18:29:39.861848
# Unit test for function parse

# Generated at 2022-06-17 18:29:45.360973
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :returns: This is the return value.
    """

# Generated at 2022-06-17 18:29:55.494113
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Longer description.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str, optional
    :returns: Description of return value.
    :rtype: int
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Longer description."
    assert parsed.blank_after_short_description is True
    assert parsed.blank_after_long_description is False
    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].description == "The first argument."
    assert parsed.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:30:06.429923
# Unit test for function parse

# Generated at 2022-06-17 18:30:16.281767
# Unit test for function parse

# Generated at 2022-06-17 18:30:28.470527
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:30:38.368913
# Unit test for function parse

# Generated at 2022-06-17 18:30:49.193312
# Unit test for function parse

# Generated at 2022-06-17 18:31:05.451228
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :param arg3: This is the third argument.
    :returns: This is the return value.
    :raises Exception: This is the exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:31:15.976417
# Unit test for function parse

# Generated at 2022-06-17 18:31:22.471186
# Unit test for function parse

# Generated at 2022-06-17 18:31:31.831883
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a param.
    :type arg1: int
    :param arg2: This is a param with a default value.
    :param arg3: This is a param with a default value.
    :type arg3: str
    :default arg3: foo
    :param arg4: This is a param with a type and a default value.
    :type arg4: str
    :default arg4: foo
    :param arg5: This is a param with a type and a default value.
    :type arg5: str
    :default arg5: foo
    :returns: This is a return.
    :rtype: int
    :raises keyError: This is an exception.
    """

# Generated at 2022-06-17 18:31:42.833319
# Unit test for function parse

# Generated at 2022-06-17 18:31:48.526312
# Unit test for function parse

# Generated at 2022-06-17 18:31:58.524052
# Unit test for function parse

# Generated at 2022-06-17 18:32:10.117653
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :returns: This is the return value.
    :raises Exception: This is the exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].description == "This is the first argument."

# Generated at 2022-06-17 18:32:21.086262
# Unit test for function parse

# Generated at 2022-06-17 18:32:33.090369
# Unit test for function parse

# Generated at 2022-06-17 18:32:53.572009
# Unit test for function parse

# Generated at 2022-06-17 18:33:02.546584
# Unit test for function parse

# Generated at 2022-06-17 18:33:08.527509
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a parameter.
    :type arg1: str
    :param arg2: This is a parameter with a default value.
    :param arg3: This is a parameter with a default value.
    :type arg2: int, optional
    :type arg3: int, optional
    :returns: This is a return value.
    :rtype: int
    :raises keyError: This is an exception.
    """

# Generated at 2022-06-17 18:33:20.759299
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :returns: This is a description of the return value.
    :raises keyError: This is a description of a raised exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:33:27.736548
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :type arg1: int
    :param arg2: This is arg2.
    :type arg2: str
    :returns: This is return value.
    :rtype: bool
    """

# Generated at 2022-06-17 18:33:38.929174
# Unit test for function parse

# Generated at 2022-06-17 18:33:49.990721
# Unit test for function parse

# Generated at 2022-06-17 18:34:02.692040
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param x: This is a parameter.
    :type x: int
    :param y: This is another parameter.
    :type y: str
    :returns: This is a return value.
    :rtype: bool
    :raises ValueError: This is a raised exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].arg_name == "x"
    assert doc.meta[0].type_name == "int"

# Generated at 2022-06-17 18:34:11.761605
# Unit test for function parse

# Generated at 2022-06-17 18:34:16.336592
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n\n") == Docstring()

    assert parse("short") == Docstring(
        short_description="short",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    assert parse("short\n") == Docstring(
        short_description="short",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

# Generated at 2022-06-17 18:34:29.323281
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :type arg1: int
    :param arg2: This is arg2.
    :type arg2: str, optional
    :returns: This is a return.
    :rtype: int
    """
    docstring_parsed = parse(docstring)
    assert docstring_parsed.short_description == "This is a short description."
    assert docstring_parsed.long_description == "This is a long description."
    assert docstring_parsed.blank_after_short_description
    assert docstring_parsed.blank_after_long_description
    assert docstring_parsed.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:34:39.315588
# Unit test for function parse

# Generated at 2022-06-17 18:34:47.561286
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: This is a first argument.
    :type arg1: int
    :param arg2: This is a second argument.
    :type arg2: str
    :param arg3: This is a third argument.
    :type arg3: str
    :returns: None
    :rtype: None
    """
    docstring = parse(docstring)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:34:58.433964
# Unit test for function parse

# Generated at 2022-06-17 18:35:10.670574
# Unit test for function parse

# Generated at 2022-06-17 18:35:23.139257
# Unit test for function parse
def test_parse():
    docstring = """
    This is the short description.

    This is the long description.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :returns: This is the return value.
    :raises Exception: This is the exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is the short description."
    assert doc.long_description == "This is the long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].keyword == "param"
    assert doc.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:35:27.931824
# Unit test for function parse

# Generated at 2022-06-17 18:35:40.083920
# Unit test for function parse
def test_parse():
    """Test the parse function."""

# Generated at 2022-06-17 18:35:51.285511
# Unit test for function parse

# Generated at 2022-06-17 18:36:03.975853
# Unit test for function parse
def test_parse():
    # Test parsing of docstring with no meta information
    docstring = parse("""
    This is a short description.

    This is a long description.
    """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert not docstring.meta

    # Test parsing of docstring with meta information

# Generated at 2022-06-17 18:36:16.101642
# Unit test for function parse

# Generated at 2022-06-17 18:36:23.742286
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is a raised exception.
    """
    ret = parse(docstring)
    assert ret.short_description == "This is a short description."
    assert ret.long_description == "This is a long description."
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == False
    assert len(ret.meta) == 3
    assert ret.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:36:34.766280
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: description
    :type arg1: str
    :param arg2: description
    :type arg2: int
    :param arg3: description
    :type arg3: str
    :returns: description
    :rtype: str
    :raises Exception: description
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].args == ['param', 'arg1']
    assert parsed.meta[0].description == 'description'

# Generated at 2022-06-17 18:36:44.809709
# Unit test for function parse

# Generated at 2022-06-17 18:36:56.302539
# Unit test for function parse

# Generated at 2022-06-17 18:37:03.422434
# Unit test for function parse
def test_parse():
    docstring = """
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """
    assert parse(docstring).short_description == "Parse the ReST-style docstring into its components."
    assert parse(docstring).long_description == "parsed docstring"
    assert parse(docstring).meta[0].args == ['returns']
    assert parse(docstring).meta[0].description == "parsed docstring"
    assert parse(docstring).meta[0].type_name == None
    assert parse(docstring).meta[0].is_generator == False
    assert parse(docstring).meta[0].arg_name == None
    assert parse(docstring).meta[0].is_optional == None

# Generated at 2022-06-17 18:37:15.406760
# Unit test for function parse