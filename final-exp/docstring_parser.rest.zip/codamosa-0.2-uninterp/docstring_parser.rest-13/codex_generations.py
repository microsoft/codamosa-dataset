

# Generated at 2022-06-17 18:27:30.461150
# Unit test for function parse

# Generated at 2022-06-17 18:27:39.837588
# Unit test for function parse

# Generated at 2022-06-17 18:27:53.333695
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n\n") == Docstring()
    assert parse("\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:28:03.546492
# Unit test for function parse
def test_parse():
    docstring = '''
    Short description.

    Long description.

    :param arg1: Description of arg1.
    :param arg2: Description of arg2.
    :param arg3: Description of arg3.
    :returns: Description of return value.
    :raises ValueError: Description of exception.
    '''
    parsed = parse(docstring)
    assert parsed.short_description == 'Short description.'
    assert parsed.long_description == 'Long description.'
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ['param', 'arg1']
    assert parsed.meta[0].description == 'Description of arg1.'

# Generated at 2022-06-17 18:28:11.515834
# Unit test for function parse

# Generated at 2022-06-17 18:28:22.104445
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :type arg1: int
    :param arg2: This is arg2.
    :type arg2: str
    :param arg3: This is arg3.
    :type arg3: str
    :param arg4: This is arg4.
    :type arg4: str
    :param arg5: This is arg5.
    :type arg5: str
    :returns: This is a description of what is returned.
    :rtype: int
    :raises keyError: raises an exception
    """
    result = parse(docstring)
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."


# Generated at 2022-06-17 18:28:32.712040
# Unit test for function parse

# Generated at 2022-06-17 18:28:43.084267
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """

# Generated at 2022-06-17 18:28:55.807483
# Unit test for function parse

# Generated at 2022-06-17 18:29:07.261761
# Unit test for function parse

# Generated at 2022-06-17 18:29:27.719744
# Unit test for function parse

# Generated at 2022-06-17 18:29:38.217461
# Unit test for function parse
def test_parse():
    text = """
    This is a short description.

    This is a long description.

    :param foo: This is a parameter.
    :param bar: This is another parameter.
    :returns: This is a return value.
    :raises AttributeError: This is an exception.
    """
    doc = parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "foo"
    assert doc.meta[0].description == "This is a parameter."
    assert doc.meta[1].arg_name == "bar"
    assert doc

# Generated at 2022-06-17 18:29:47.391784
# Unit test for function parse

# Generated at 2022-06-17 18:30:00.337313
# Unit test for function parse

# Generated at 2022-06-17 18:30:12.602999
# Unit test for function parse

# Generated at 2022-06-17 18:30:21.358922
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :returns: None
    :raises keyError: raises an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].description == "This is a first argument."
    assert parsed.meta[1].arg_name == "arg2"
    assert parsed.meta[1].description

# Generated at 2022-06-17 18:30:32.757742
# Unit test for function parse

# Generated at 2022-06-17 18:30:44.725633
# Unit test for function parse

# Generated at 2022-06-17 18:30:55.580764
# Unit test for function parse

# Generated at 2022-06-17 18:31:05.449534
# Unit test for function parse

# Generated at 2022-06-17 18:31:21.845632
# Unit test for function parse

# Generated at 2022-06-17 18:31:31.387945
# Unit test for function parse

# Generated at 2022-06-17 18:31:42.449235
# Unit test for function parse

# Generated at 2022-06-17 18:31:48.437997
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring = """
    Short description.

    Long description.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str, optional
    :returns: Description of return value.
    :rtype: int
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].type_name == "int"

# Generated at 2022-06-17 18:31:58.453840
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:32:10.066062
# Unit test for function parse

# Generated at 2022-06-17 18:32:21.043873
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param int x: The x coordinate.
    :param int y: The y coordinate.
    :returns: The distance.
    :raises ValueError: If x or y is negative.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].args == ["param", "int", "x"]
    assert parsed.meta[0].description == "The x coordinate."

# Generated at 2022-06-17 18:32:33.091462
# Unit test for function parse

# Generated at 2022-06-17 18:32:43.340430
# Unit test for function parse

# Generated at 2022-06-17 18:32:55.257325
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a description of arg1.
    :type arg1: str
    :param arg2: This is a description of arg2.
    :type arg2: int
    :param arg3: This is a description of arg3.
    :type arg3: str
    :param arg4: This is a description of arg4.
    :type arg4: int
    :returns: This is a description of the return value.
    :rtype: str
    :raises Exception: This is a description of the exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."

# Generated at 2022-06-17 18:33:09.443706
# Unit test for function parse

# Generated at 2022-06-17 18:33:21.231009
# Unit test for function parse

# Generated at 2022-06-17 18:33:28.126137
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:33:39.249971
# Unit test for function parse

# Generated at 2022-06-17 18:33:50.262114
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :type arg1: int
    :param arg2: This is a second argument.
    :type arg2: str
    :param arg3: This is a third argument.
    :type arg3: str
    :returns: This is a description of what is returned.
    :rtype: int
    :raises keyError: This is a description of what raises.
    """

# Generated at 2022-06-17 18:33:57.455053
# Unit test for function parse

# Generated at 2022-06-17 18:34:07.527949
# Unit test for function parse

# Generated at 2022-06-17 18:34:14.967437
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :type arg1: str
    :param arg2: This is arg2.
    :type arg2: int
    :param arg3: This is arg3.
    :type arg3: float
    :returns: This is return value.
    :rtype: str
    :raises ValueError: This is ValueError.
    :raises TypeError: This is TypeError.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.blank_after_short_description == True
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_long_description == False
   

# Generated at 2022-06-17 18:34:23.742863
# Unit test for function parse

# Generated at 2022-06-17 18:34:34.205840
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :type arg1: int
    :param arg2: This is a second argument.
    :type arg2: str
    :returns: This is a return value.
    :rtype: int
    """

# Generated at 2022-06-17 18:34:47.389488
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :returns: This is a description of the return value.
    :raises keyError: This is a description of a raised exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].type_name is None
    assert parsed.meta[0].is_optional is None

# Generated at 2022-06-17 18:34:58.390768
# Unit test for function parse

# Generated at 2022-06-17 18:35:10.682240
# Unit test for function parse

# Generated at 2022-06-17 18:35:23.139893
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """

# Generated at 2022-06-17 18:35:36.370067
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :returns: This is a description of what is returned.
    :raises keyError: This is a description of what raises this exception.
    """

# Generated at 2022-06-17 18:35:48.848239
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :type arg1: str
    :param arg2: This is a second argument.
    :type arg2: int
    :returns: This is a return value.
    :rtype: str
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ['param', 'arg1']
    assert doc.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:36:01.760913
# Unit test for function parse

# Generated at 2022-06-17 18:36:12.916171
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: int
    :param arg2: this is arg2
    :type arg2: str, optional
    :returns: None
    :rtype: int
    """
    docstring = parse(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "this is arg1"

# Generated at 2022-06-17 18:36:23.029951
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a description of arg1.
    :param arg2: This is a description of arg2.
    :param arg3: This is a description of arg3.
    :returns: This is a description of the return value.
    :raises Exception: This is a description of the exception.
    """

# Generated at 2022-06-17 18:36:34.059614
# Unit test for function parse

# Generated at 2022-06-17 18:36:54.236577
# Unit test for function parse

# Generated at 2022-06-17 18:37:02.165960
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: int
    :param arg2: this is arg2
    :type arg2: str, optional
    :returns: None
    :rtype: int
    """
    docstring = parse(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].type_name == "int"
    assert docstring.meta[0].is_

# Generated at 2022-06-17 18:37:10.139952
# Unit test for function parse