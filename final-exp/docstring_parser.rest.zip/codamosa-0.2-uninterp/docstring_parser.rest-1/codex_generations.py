

# Generated at 2022-06-17 18:27:30.672380
# Unit test for function parse

# Generated at 2022-06-17 18:27:39.842110
# Unit test for function parse
def test_parse():
    docstring = """
    This is the short description.

    This is the long description.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :returns: This is a description of the return value.
    :raises Exception: Because you shouldn't have done that.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is the short description."
    assert parsed.long_description == "This is the long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].description == "This is the first argument."

# Generated at 2022-06-17 18:27:53.310789
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    ds = parse(docstring)
    assert ds.short_description == "This is a short description."
    assert ds.long_description == "This is a long description."
    assert ds.blank_after_short_description == True
    assert ds.blank_after_long_description == False
    assert len(ds.meta) == 4
    assert ds.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:28:03.546499
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :type arg1: str
    :param arg2: This is arg2.
    :type arg2: int
    :returns: This is the return value.
    :rtype: str
    :raises ValueError: This is the exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type

# Generated at 2022-06-17 18:28:11.517062
# Unit test for function parse

# Generated at 2022-06-17 18:28:22.103283
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:28:32.714999
# Unit test for function parse

# Generated at 2022-06-17 18:28:43.084033
# Unit test for function parse

# Generated at 2022-06-17 18:28:55.806396
# Unit test for function parse

# Generated at 2022-06-17 18:29:07.261735
# Unit test for function parse

# Generated at 2022-06-17 18:29:20.278134
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n\n") == Docstring()
    assert parse("\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n") == Docstring()

    assert parse("a") == Docstring(
        short_description="a",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-17 18:29:31.832106
# Unit test for function parse

# Generated at 2022-06-17 18:29:38.202022
# Unit test for function parse

# Generated at 2022-06-17 18:29:47.392601
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring = """
    Short description.

    Long description.

    :param foo: foo description
    :type foo: str
    :param bar: bar description
    :type bar: int
    :returns: return description
    :rtype: str
    :raises ValueError: if foo is not a string
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].args == ["param", "foo"]
    assert parsed.meta[0].description == "foo description"

# Generated at 2022-06-17 18:30:00.337687
# Unit test for function parse

# Generated at 2022-06-17 18:30:10.096178
# Unit test for function parse

# Generated at 2022-06-17 18:30:19.293016
# Unit test for function parse

# Generated at 2022-06-17 18:30:26.906832
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: int
    :param arg2: this is arg2
    :type arg2: str, optional
    :returns: None
    :rtype: int
    :raises keyError: raises an exception
    """
    print(parse(docstring))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:30:37.240618
# Unit test for function parse

# Generated at 2022-06-17 18:30:48.294481
# Unit test for function parse

# Generated at 2022-06-17 18:31:04.160807
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: str
    :param arg2: this is arg2
    :type arg2: int
    :param arg3: this is arg3
    :type arg3: int
    :returns: None
    :rtype: None
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ['param', 'arg1']
    assert doc.meta[0].description == "this is arg1"

# Generated at 2022-06-17 18:31:15.641797
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a parameter.
    :type arg1: str
    :param arg2: This is a parameter with a default value.
    :param arg3: This is a parameter with a default value.
                 Defaults to True.
    :type arg3: bool
    :param arg4: This is a parameter with a default value.
                 Defaults to None.
    :type arg4: str
    :returns: This is a return value.
    :rtype: int
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."

# Generated at 2022-06-17 18:31:25.656643
# Unit test for function parse

# Generated at 2022-06-17 18:31:37.082278
# Unit test for function parse

# Generated at 2022-06-17 18:31:46.212722
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:31:57.375837
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param int x: This is a parameter.
    :param str y: This is another parameter.
    :param str z: This is a third parameter.
    :returns: This is a return value.
    :rtype: str
    """

# Generated at 2022-06-17 18:32:08.400396
# Unit test for function parse

# Generated at 2022-06-17 18:32:19.936944
# Unit test for function parse

# Generated at 2022-06-17 18:32:31.414081
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :returns: This is a description of the return value.
    :raises keyError: This is a description of a raised exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "This is a first argument."


# Generated at 2022-06-17 18:32:42.309382
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a parameter.
    :type arg1: int
    :param arg2: This is a parameter with a default value.
    :param arg3: This is a parameter with a default value.
    :type arg3: str
    :default arg3: foo
    :param arg4: This is a parameter with a type and a default value.
    :type arg4: str
    :default arg4: foo
    :returns: This is a return value.
    :rtype: int
    :raises: This is an exception.
    :raises: This is another exception.
    """
    result = parse(docstring)
    assert result.short_description == "This is a short description."
    assert result.long

# Generated at 2022-06-17 18:33:01.542809
# Unit test for function parse

# Generated at 2022-06-17 18:33:11.064245
# Unit test for function parse

# Generated at 2022-06-17 18:33:21.588520
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a param.
    :type arg1: str
    :param arg2: This is a param with a default value.
    :param arg3: This is a param with a default value.
        Defaults to True.
    :type arg3: bool
    :returns: None
    :rtype: None
    :raises keyError: This is an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False

# Generated at 2022-06-17 18:33:33.204485
# Unit test for function parse

# Generated at 2022-06-17 18:33:41.519453
# Unit test for function parse

# Generated at 2022-06-17 18:33:54.884464
# Unit test for function parse

# Generated at 2022-06-17 18:34:05.505416
# Unit test for function parse

# Generated at 2022-06-17 18:34:17.602008
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a param.
    :type arg1: str
    :param arg2: This is a param with a default value.
    :param arg3: This is a param with a default value.
        Defaults to True.
    :type arg3: bool
    :returns: This is a return.
    :rtype: int
    :raises keyError: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description

# Generated at 2022-06-17 18:34:29.160731
# Unit test for function parse

# Generated at 2022-06-17 18:34:39.290407
# Unit test for function parse

# Generated at 2022-06-17 18:34:58.618436
# Unit test for function parse

# Generated at 2022-06-17 18:35:10.669626
# Unit test for function parse

# Generated at 2022-06-17 18:35:23.139302
# Unit test for function parse

# Generated at 2022-06-17 18:35:36.369848
# Unit test for function parse

# Generated at 2022-06-17 18:35:48.847891
# Unit test for function parse

# Generated at 2022-06-17 18:35:55.883411
# Unit test for function parse

# Generated at 2022-06-17 18:36:06.787083
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: str
    :param arg2: this is arg2
    :type arg2: int, optional
    :returns: description of return value
    :rtype: int
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].type_name == "str"

# Generated at 2022-06-17 18:36:15.361090
# Unit test for function parse

# Generated at 2022-06-17 18:36:25.826927
# Unit test for function parse

# Generated at 2022-06-17 18:36:36.100004
# Unit test for function parse

# Generated at 2022-06-17 18:37:05.903340
# Unit test for function parse