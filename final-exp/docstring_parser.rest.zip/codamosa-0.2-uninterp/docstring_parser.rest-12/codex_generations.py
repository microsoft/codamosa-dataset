

# Generated at 2022-06-17 18:27:22.427114
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """

# Generated at 2022-06-17 18:27:31.137311
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.
    """
    assert parse(docstring) == Docstring(
        short_description="This is a short description.",
        blank_after_short_description=True,
        long_description="This is a long description.",
        blank_after_long_description=True,
        meta=[],
    )

    docstring = """
    This is a short description.

    This is a long description.
    """
    assert parse(docstring) == Docstring(
        short_description="This is a short description.",
        blank_after_short_description=True,
        long_description="This is a long description.",
        blank_after_long_description=True,
        meta=[],
    )


# Generated at 2022-06-17 18:27:37.620250
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :returns: This is what is returned.
    :raises keyError: This is a deliberate key error.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].description == "This is a first argument."
    assert parsed.meta[1].arg_name == "arg2"


# Generated at 2022-06-17 18:27:47.994570
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a parameter.
    :type arg1: str
    :param arg2: This is a parameter with a default value.
    :param arg3: This is a parameter with a default value.
                 Defaults to False.
    :returns: None
    :raises keyError: raises an exception
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type_name

# Generated at 2022-06-17 18:27:58.671378
# Unit test for function parse

# Generated at 2022-06-17 18:28:08.845122
# Unit test for function parse

# Generated at 2022-06-17 18:28:20.748659
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str, optional
    :returns: Description of return value.
    :rtype: int
    :raises keyError: raises an exception
    """
    doc = parse(docstring)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type_name == "int"

# Generated at 2022-06-17 18:28:31.596705
# Unit test for function parse

# Generated at 2022-06-17 18:28:42.681547
# Unit test for function parse
def test_parse():
    """Test the parse function."""
    # Test empty docstring
    assert parse("") == Docstring()

    # Test short description only
    assert parse("Short description.") == Docstring(
        short_description="Short description.",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

    # Test short description and long description
    assert parse("Short description.\n\nLong description.") == Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="Long description.",
        meta=[],
    )

    # Test short description and long description with extra blank line

# Generated at 2022-06-17 18:28:49.495224
# Unit test for function parse

# Generated at 2022-06-17 18:29:12.692439
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: Description of arg1.
    :type arg1: int
    :param arg2: Description of arg2.
    :type arg2: str
    :param arg3: Description of arg3.
    :type arg3: str
    :returns: Description of return value.
    :rtype: int
    :raises ValueError: Description of exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 4
    assert doc.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:29:21.492583
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :returns: This is a description of the return value.
    :raises Exception: This is a description of the exception.
    """

# Generated at 2022-06-17 18:29:32.435110
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param a: this is a
    :param b: this is b
    :param c: this is c
    :returns: this is returns
    :raises Exception: this is raises
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "a"]
    assert doc.meta[0].description == "this is a"

# Generated at 2022-06-17 18:29:40.488882
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:29:53.808891
# Unit test for function parse

# Generated at 2022-06-17 18:30:05.263096
# Unit test for function parse

# Generated at 2022-06-17 18:30:14.082062
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :returns: This is a description of the return value.
    :raises keyError: This is a description of a raised exception.
    """

# Generated at 2022-06-17 18:30:27.433631
# Unit test for function parse

# Generated at 2022-06-17 18:30:37.644697
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param int x: The x coordinate.
    :param int y: The y coordinate.
    :returns: The distance.
    """

# Generated at 2022-06-17 18:30:48.648677
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: int
    :param arg2: this is arg2
    :type arg2: str, optional
    :returns: None
    :rtype: int
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type_name == "int"

# Generated at 2022-06-17 18:31:07.779387
# Unit test for function parse

# Generated at 2022-06-17 18:31:17.856806
# Unit test for function parse

# Generated at 2022-06-17 18:31:27.137698
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: int
    :param arg2: this is arg2
    :type arg2: str, optional
    :returns: None
    :rtype: int
    :raises keyError: raises an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 4
    assert parsed.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:31:38.568750
# Unit test for function parse

# Generated at 2022-06-17 18:31:46.897822
# Unit test for function parse

# Generated at 2022-06-17 18:31:57.640704
# Unit test for function parse

# Generated at 2022-06-17 18:32:08.795276
# Unit test for function parse

# Generated at 2022-06-17 18:32:20.105610
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param foo: this is a parameter
    :type foo: int
    :param bar: this is another parameter
    :type bar: str
    :returns: this is what is returned
    :rtype: dict
    :raises keyError: raises an exception
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].arg_name == "foo"
    assert doc.meta[0].type_name == "int"
    assert doc

# Generated at 2022-06-17 18:32:26.817927
# Unit test for function parse

# Generated at 2022-06-17 18:32:38.990683
# Unit test for function parse

# Generated at 2022-06-17 18:32:56.596860
# Unit test for function parse

# Generated at 2022-06-17 18:33:08.398040
# Unit test for function parse

# Generated at 2022-06-17 18:33:20.761280
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:33:27.736721
# Unit test for function parse

# Generated at 2022-06-17 18:33:38.929156
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a parameter.
    :type arg1: str
    :param arg2: This is a parameter with a default value.
    :param arg3: This is a parameter with a default value.
                 Defaults to False.
    :returns: This is a return value.
    :rtype: int
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:33:49.992022
# Unit test for function parse

# Generated at 2022-06-17 18:34:02.685463
# Unit test for function parse

# Generated at 2022-06-17 18:34:11.761452
# Unit test for function parse

# Generated at 2022-06-17 18:34:17.979145
# Unit test for function parse

# Generated at 2022-06-17 18:34:25.362500
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :param arg2: this is arg2
    :returns: None
    :raises keyError: depends on input
    """

# Generated at 2022-06-17 18:34:44.655723
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :type arg1: str
    :param arg2: This is arg2.
    :type arg2: int
    :returns: This is return value.
    :rtype: str
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "This is arg1."


# Generated at 2022-06-17 18:34:57.366157
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: int
    :param arg2: this is arg2
    :type arg2: str, optional
    :returns: None
    :rtype: int
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].type_name == "int"
    assert parsed.meta[0].is_optional == False

# Generated at 2022-06-17 18:35:09.929669
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:35:22.003450
# Unit test for function parse

# Generated at 2022-06-17 18:35:30.102663
# Unit test for function parse

# Generated at 2022-06-17 18:35:41.756529
# Unit test for function parse

# Generated at 2022-06-17 18:35:55.344122
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a param.
    :type arg1: str
    :param arg2: This is a param with a default value.
    :param arg3: This is a param with a default value.
        Defaults to True.
    :type arg3: bool
    :returns: This is a return.
    :rtype: int
    :raises keyError: This is an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 4

# Generated at 2022-06-17 18:36:06.365334
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: int
    :param arg2: this is arg2
    :type arg2: str, optional
    :returns: None
    :rtype: int
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].type_name == "int"

# Generated at 2022-06-17 18:36:14.718570
# Unit test for function parse

# Generated at 2022-06-17 18:36:25.188854
# Unit test for function parse

# Generated at 2022-06-17 18:36:45.271599
# Unit test for function parse

# Generated at 2022-06-17 18:36:56.668201
# Unit test for function parse

# Generated at 2022-06-17 18:37:07.230023
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param int x: This is a parameter.
    :param str y: This is another parameter.
    :returns: This is a return value.
    :rtype: int
    """