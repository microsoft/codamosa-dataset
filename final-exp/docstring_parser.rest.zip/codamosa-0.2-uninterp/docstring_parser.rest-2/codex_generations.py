

# Generated at 2022-06-17 18:27:37.086128
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param int x: This is a parameter.
    :param str y: This is another parameter.
    :returns: This is a return value.
    :rtype: int
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 2
    assert parsed.meta[0].arg_name == "x"
    assert parsed.meta[0].type_name == "int"
    assert parsed.meta[0].description == "This is a parameter."

# Generated at 2022-06-17 18:27:47.959238
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param int x: This is a parameter.
    :param str y: This is another parameter.
    :return: This is a return value.
    :rtype: int
    """

# Generated at 2022-06-17 18:27:58.638195
# Unit test for function parse
def test_parse():
    """Test the function parse."""
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a parameter.
    :type arg1: str
    :param arg2: This is another parameter.
    :type arg2: int
    :returns: This is what is returned.
    :rtype: bool
    :raises keyError: This is an exception.
    """

# Generated at 2022-06-17 18:28:08.835337
# Unit test for function parse
def test_parse():
    docstring = '''
    Short description.

    Long description.

    :param arg1: description
    :type arg1: str
    :param arg2: description
    :type arg2: int
    :param arg3: description
    :type arg3: int
    :returns: description
    :rtype: str
    :raises ValueError: description
    '''

# Generated at 2022-06-17 18:28:20.746248
# Unit test for function parse

# Generated at 2022-06-17 18:28:31.629521
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:28:42.680626
# Unit test for function parse

# Generated at 2022-06-17 18:28:55.598164
# Unit test for function parse

# Generated at 2022-06-17 18:29:07.015711
# Unit test for function parse

# Generated at 2022-06-17 18:29:17.870231
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == True
    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:29:33.414822
# Unit test for function parse

# Generated at 2022-06-17 18:29:41.277600
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :param arg3: This is the third argument.
    :returns: This is the return value.
    :raises ValueError: This is the exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:29:54.138738
# Unit test for function parse

# Generated at 2022-06-17 18:30:05.593116
# Unit test for function parse

# Generated at 2022-06-17 18:30:14.287930
# Unit test for function parse

# Generated at 2022-06-17 18:30:27.433513
# Unit test for function parse

# Generated at 2022-06-17 18:30:37.646191
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("hello") == Docstring(
        short_description="hello",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    assert parse("hello\nworld") == Docstring(
        short_description="hello",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="world",
        meta=[],
    )
    assert parse("hello\nworld\n") == Docstring(
        short_description="hello",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="world",
        meta=[],
    )

# Generated at 2022-06-17 18:30:48.642627
# Unit test for function parse

# Generated at 2022-06-17 18:31:00.514517
# Unit test for function parse

# Generated at 2022-06-17 18:31:04.710783
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is what is returned.
    :raises Exception: This is what is raised.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:31:26.259762
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].args == ['param', 'arg1']
    assert parsed.meta[0].description == "This is a first argument."
    assert parsed.meta[1].args == ['param', 'arg2']
   

# Generated at 2022-06-17 18:31:37.823750
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :param arg2: this is arg2
    :param arg3: this is arg3
    :returns: None
    :raises keyError: raises an exception
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert doc.meta[0].args == ['arg1']
    assert doc.meta[0].description == 'this is arg1'
    assert doc.meta[1].args == ['arg2']

# Generated at 2022-06-17 18:31:42.895010
# Unit test for function parse

# Generated at 2022-06-17 18:31:48.824945
# Unit test for function parse

# Generated at 2022-06-17 18:31:58.602977
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test function.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str, optional
    :returns: Description of return value.
    :rtype: int
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a test function."
    assert doc.long_description == "The first argument.\nThe second argument."
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type_name == "int"
    assert doc.meta[1].arg_name == "arg2"
    assert doc.meta[1].type_name == "str"
    assert doc.meta[1].is_optional == True

# Generated at 2022-06-17 18:32:10.226183
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :param arg4: This is a fourth argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == True
    assert parsed.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:32:21.169888
# Unit test for function parse

# Generated at 2022-06-17 18:32:33.092586
# Unit test for function parse

# Generated at 2022-06-17 18:32:43.341585
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:32:54.027876
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :param arg2: this is arg2
    :param arg3: this is arg3
    :type arg1: int
    :type arg2: str
    :type arg3: bool
    :returns: None
    :rtype: None
    :raises keyError: raises KeyError
    """
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == "This is a short description."
    assert parsed_docstring.long_description == "This is a long description."
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_docstring.blank_after_long_description == False
    assert parsed_docstring.meta

# Generated at 2022-06-17 18:33:19.115933
# Unit test for function parse

# Generated at 2022-06-17 18:33:26.633611
# Unit test for function parse

# Generated at 2022-06-17 18:33:37.904969
# Unit test for function parse

# Generated at 2022-06-17 18:33:49.650958
# Unit test for function parse

# Generated at 2022-06-17 18:34:02.462305
# Unit test for function parse

# Generated at 2022-06-17 18:34:11.608012
# Unit test for function parse

# Generated at 2022-06-17 18:34:21.713937
# Unit test for function parse

# Generated at 2022-06-17 18:34:32.623378
# Unit test for function parse

# Generated at 2022-06-17 18:34:42.764948
# Unit test for function parse

# Generated at 2022-06-17 18:34:49.521493
# Unit test for function parse