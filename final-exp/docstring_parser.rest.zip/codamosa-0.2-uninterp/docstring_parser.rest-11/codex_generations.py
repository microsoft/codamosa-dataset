

# Generated at 2022-06-17 18:27:27.394269
# Unit test for function parse

# Generated at 2022-06-17 18:27:37.080756
# Unit test for function parse

# Generated at 2022-06-17 18:27:47.923855
# Unit test for function parse

# Generated at 2022-06-17 18:27:58.605531
# Unit test for function parse

# Generated at 2022-06-17 18:28:08.128582
# Unit test for function parse

# Generated at 2022-06-17 18:28:15.383972
# Unit test for function parse

# Generated at 2022-06-17 18:28:23.717828
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :type arg1: int
    :param arg2: This is a second argument.
    :type arg2: str
    :param arg3: This is a third argument.
    :type arg3: str
    :returns: This is a return value.
    :rtype: int
    :raises ValueError: This is a exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc

# Generated at 2022-06-17 18:28:33.691331
# Unit test for function parse

# Generated at 2022-06-17 18:28:43.384327
# Unit test for function parse

# Generated at 2022-06-17 18:28:55.952166
# Unit test for function parse

# Generated at 2022-06-17 18:29:11.845270
# Unit test for function parse

# Generated at 2022-06-17 18:29:20.964310
# Unit test for function parse

# Generated at 2022-06-17 18:29:32.100086
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: int
    :param arg2: this is arg2
    :type arg2: str, optional
    :returns: None
    :rtype: int
    :raises keyError: raises an exception
    """

# Generated at 2022-06-17 18:29:38.368572
# Unit test for function parse

# Generated at 2022-06-17 18:29:47.535190
# Unit test for function parse

# Generated at 2022-06-17 18:30:00.380323
# Unit test for function parse

# Generated at 2022-06-17 18:30:12.602024
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a parameter.
    :type arg1: str
    :param arg2: This is a parameter with a default value.
    :param arg3: This is a parameter with a default value.
                 Defaults to False.
    :type arg3: bool
    :returns: This is a return value.
    :rtype: int
    :raises keyError: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta)

# Generated at 2022-06-17 18:30:21.358219
# Unit test for function parse

# Generated at 2022-06-17 18:30:32.758535
# Unit test for function parse
def test_parse():
    docstring = parse("""
    Short description.

    Long description.

    :param arg1: description
    :type arg1: str
    :param arg2: description
    :type arg2: str
    :param arg3: description
    :type arg3: str
    :returns: description
    :rtype: str
    :raises ValueError: description
    """)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "description"
    assert docstring.meta

# Generated at 2022-06-17 18:30:44.726102
# Unit test for function parse

# Generated at 2022-06-17 18:30:56.885279
# Unit test for function parse

# Generated at 2022-06-17 18:31:06.294186
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :type arg3: str
    :returns: This is a return value.
    :rtype: int
    """

# Generated at 2022-06-17 18:31:16.818027
# Unit test for function parse

# Generated at 2022-06-17 18:31:25.816014
# Unit test for function parse

# Generated at 2022-06-17 18:31:37.183359
# Unit test for function parse

# Generated at 2022-06-17 18:31:46.270872
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1
    :param arg2: This is arg2
    :param arg3: This is arg3
    :type arg1: int
    :type arg2: str
    :type arg3: bool
    :returns: None
    :rtype: None
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 6
    assert parsed.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:31:57.375130
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: int
    :param arg2: this is arg2
    :type arg2: str, optional
    :returns: None
    :rtype: int
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 3
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].type_name == "int"
    assert parsed.meta

# Generated at 2022-06-17 18:32:08.400094
# Unit test for function parse

# Generated at 2022-06-17 18:32:19.937419
# Unit test for function parse

# Generated at 2022-06-17 18:32:26.737893
# Unit test for function parse

# Generated at 2022-06-17 18:32:42.711111
# Unit test for function parse

# Generated at 2022-06-17 18:32:48.872422
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: int
    :param arg2: this is arg2
    :type arg2: str, optional
    :returns: None
    :rtype: int
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].type_name == "int"

# Generated at 2022-06-17 18:32:59.267203
# Unit test for function parse

# Generated at 2022-06-17 18:33:10.166512
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a parameter.
    :type arg1: int
    :param arg2: This is a parameter with a default value.
    :param arg3: This is a parameter with a default value.
    :type arg2: str, optional
    :type arg3: str, optional
    :default arg2: foo
    :default arg3: bar
    :raises ValueError: if arg2 == arg3
    :returns: None
    :rtype: int
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank

# Generated at 2022-06-17 18:33:21.340311
# Unit test for function parse

# Generated at 2022-06-17 18:33:28.203154
# Unit test for function parse

# Generated at 2022-06-17 18:33:39.312911
# Unit test for function parse

# Generated at 2022-06-17 18:33:50.335514
# Unit test for function parse

# Generated at 2022-06-17 18:34:02.728834
# Unit test for function parse

# Generated at 2022-06-17 18:34:11.793662
# Unit test for function parse

# Generated at 2022-06-17 18:34:29.141179
# Unit test for function parse

# Generated at 2022-06-17 18:34:39.217140
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a param.
    :type arg1: str
    :param arg2: This is a param with a default value.
    :param arg3: This is a param with a default value.
        Defaults to True.
    :type arg3: bool
    :returns: This is a return.
    :rtype: int
    :raises keyError: This is an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False

# Generated at 2022-06-17 18:34:47.504046
# Unit test for function parse

# Generated at 2022-06-17 18:34:58.438726
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:35:10.669737
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :param arg2: This is arg2.
    :returns: This is return.
    :raises Exception: This is exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].description == "This is arg1."

# Generated at 2022-06-17 18:35:23.140127
# Unit test for function parse

# Generated at 2022-06-17 18:35:36.371039
# Unit test for function parse

# Generated at 2022-06-17 18:35:48.850622
# Unit test for function parse

# Generated at 2022-06-17 18:36:01.761557
# Unit test for function parse

# Generated at 2022-06-17 18:36:13.154151
# Unit test for function parse
def test_parse():
    docstring = """
    Test function for parse.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Test function for parse."
    assert parsed.long_description == None
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ['param', 'x']
    assert parsed.meta[0].description == 'x'
    assert parsed.meta[1].args == ['type', 'x']
    assert parsed.meta[1].description == 'int'

# Generated at 2022-06-17 18:36:25.646582
# Unit test for function parse

# Generated at 2022-06-17 18:36:35.987407
# Unit test for function parse

# Generated at 2022-06-17 18:36:47.196315
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :returns: This is a description of the return value.
    :raises keyError: This is a description of a raised exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:36:55.855349
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :returns: This is a description of the return value.
    :raises Exception: This is a description of the exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:37:03.151315
# Unit test for function parse