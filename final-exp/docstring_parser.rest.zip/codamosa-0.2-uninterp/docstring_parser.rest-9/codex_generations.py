

# Generated at 2022-06-17 18:27:28.578805
# Unit test for function parse

# Generated at 2022-06-17 18:27:38.037873
# Unit test for function parse
def test_parse():
    doc = parse("""
    This is a short description.

    This is a long description.

    :param arg1: This is a description of arg1.
    :param arg2: This is a description of arg2.
    :param arg3: This is a description of arg3.
    :returns: This is a description of the return value.
    :raises Exception: This is a description of the exception.
    """)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:27:48.027087
# Unit test for function parse

# Generated at 2022-06-17 18:27:58.671863
# Unit test for function parse

# Generated at 2022-06-17 18:28:08.165292
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring.

    This is the long description.

    :param arg1: This is arg1.
    :param arg2: This is arg2.
    :returns: This is what is returned.
    :raises Exception: This is what is raised.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a docstring."
    assert doc.long_description == "This is the long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "This is arg1."

# Generated at 2022-06-17 18:28:20.065545
# Unit test for function parse

# Generated at 2022-06-17 18:28:30.762014
# Unit test for function parse

# Generated at 2022-06-17 18:28:42.289501
# Unit test for function parse

# Generated at 2022-06-17 18:28:55.396366
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a parameter.
    :type arg1: int
    :param arg2: This is a parameter with a default value.
    :param arg3: This is a parameter with a default value.
    :type arg3: str
    :returns: This is a return value.
    :rtype: bool
    """

# Generated at 2022-06-17 18:29:02.643132
# Unit test for function parse

# Generated at 2022-06-17 18:29:18.669288
# Unit test for function parse

# Generated at 2022-06-17 18:29:30.937630
# Unit test for function parse

# Generated at 2022-06-17 18:29:40.448979
# Unit test for function parse

# Generated at 2022-06-17 18:29:53.778506
# Unit test for function parse

# Generated at 2022-06-17 18:30:05.262086
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :param arg2: this is arg2
    :param arg3: this is arg3
    :returns: None
    :raises keyError: raises an exception
    """

# Generated at 2022-06-17 18:30:14.087085
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :returns: This is the return value.
    :raises Exception: This is the exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].description == "This is the first argument."

# Generated at 2022-06-17 18:30:27.433174
# Unit test for function parse

# Generated at 2022-06-17 18:30:33.774263
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:30:38.901869
# Unit test for function parse

# Generated at 2022-06-17 18:30:49.256244
# Unit test for function parse

# Generated at 2022-06-17 18:31:05.775270
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a description of arg1.
    :param arg2: This is a description of arg2.
    :param arg3: This is a description of arg3.
    :type arg3: str
    :param arg4: This is a description of arg4.
    :type arg4: str
    :param arg5: This is a description of arg5.
    :type arg5: str
    :param arg6: This is a description of arg6.
    :type arg6: str
    :returns: This is a description of the return value.
    :rtype: str
    :raises ValueError: This is a description of the exception.
    """
    print(parse(docstring))


# Generated at 2022-06-17 18:31:16.262296
# Unit test for function parse
def test_parse():
    """Test the parse function."""
    docstring = """
    Short description.

    Long description.

    :param arg1: This is arg1.
    :param arg2: This is arg2.
    :param arg3: This is arg3.
    :returns: None
    :raises keyError: depends on input
    """
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == "Short description."
    assert parsed_docstring.long_description == "Long description."
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_docstring.blank_after_long_description == False
    assert len(parsed_docstring.meta) == 4
    assert parsed_docstring.meta[0].arg_name == "arg1"
    assert parsed

# Generated at 2022-06-17 18:31:25.453924
# Unit test for function parse

# Generated at 2022-06-17 18:31:36.772651
# Unit test for function parse

# Generated at 2022-06-17 18:31:46.025257
# Unit test for function parse

# Generated at 2022-06-17 18:31:57.336182
# Unit test for function parse

# Generated at 2022-06-17 18:32:08.399674
# Unit test for function parse

# Generated at 2022-06-17 18:32:19.936820
# Unit test for function parse

# Generated at 2022-06-17 18:32:26.738257
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a parameter.
    :param arg2: This is another parameter.
    :returns: This is what is returned.
    :raises keyError: This is a exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].description == "This is a parameter."

# Generated at 2022-06-17 18:32:38.937285
# Unit test for function parse

# Generated at 2022-06-17 18:33:02.036119
# Unit test for function parse

# Generated at 2022-06-17 18:33:11.265221
# Unit test for function parse

# Generated at 2022-06-17 18:33:21.753668
# Unit test for function parse

# Generated at 2022-06-17 18:33:28.482969
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :type arg1: str
    :param arg2: This is arg2.
    :type arg2: int
    :param arg3: This is arg3.
    :type arg3: str
    :returns: This is return.
    :rtype: str
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 4
    assert parsed

# Generated at 2022-06-17 18:33:39.401953
# Unit test for function parse

# Generated at 2022-06-17 18:33:50.372716
# Unit test for function parse

# Generated at 2022-06-17 18:34:02.727964
# Unit test for function parse
def test_parse():
    docstring = parse("""
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :type arg1: int
    :param arg2: This is arg2.
    :type arg2: str, optional
    :returns: None
    :rtype: None
    :raises keyError: raises an exception
    """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 4
    assert docstring.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:34:11.793672
# Unit test for function parse

# Generated at 2022-06-17 18:34:18.006202
# Unit test for function parse
def test_parse():
    """Test parse function."""

# Generated at 2022-06-17 18:34:30.055942
# Unit test for function parse
def test_parse():
    text = """
    This is a short description.

    This is a long description.

    :param int x: This is a parameter.
    :param int y: This is another parameter.
    :param int z: This is a third parameter.
    :returns: This is a return value.
    :rtype: int
    """
    doc = parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ["param", "int", "x"]
    assert doc.meta[0].description == "This is a parameter."

# Generated at 2022-06-17 18:34:56.819337
# Unit test for function parse

# Generated at 2022-06-17 18:35:09.026396
# Unit test for function parse

# Generated at 2022-06-17 18:35:21.221574
# Unit test for function parse

# Generated at 2022-06-17 18:35:29.699348
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """

# Generated at 2022-06-17 18:35:41.352696
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is another parameter.
    :type bar: int
    :returns: This is what is returned.
    :rtype: bool
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].args == ["param", "foo"]
    assert parsed.meta[0].description == "This is a parameter."

# Generated at 2022-06-17 18:35:52.016361
# Unit test for function parse

# Generated at 2022-06-17 18:36:04.632930
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    docstring = parse(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description

# Generated at 2022-06-17 18:36:13.798657
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: str
    :param arg2: this is arg2
    :type arg2: int, optional
    :param arg3: this is arg3
    :type arg3: int, optional
    :param arg4: this is arg4
    :type arg4: int, optional
    :param arg5: this is arg5
    :type arg5: int, optional
    :returns: None
    :rtype: int
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True

# Generated at 2022-06-17 18:36:19.584331
# Unit test for function parse

# Generated at 2022-06-17 18:36:25.646017
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring = """
    This is a short description.

    This is a long description.

    :param int x: This is a parameter.
    :param str y: This is another parameter.
    :returns: This is a return value.
    :raises ValueError: This is a raised exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].arg_name == "x"
    assert parsed.meta[0].type_name == "int"
    assert parsed.meta

# Generated at 2022-06-17 18:36:52.752271
# Unit test for function parse

# Generated at 2022-06-17 18:37:03.833397
# Unit test for function parse

# Generated at 2022-06-17 18:37:15.832361
# Unit test for function parse