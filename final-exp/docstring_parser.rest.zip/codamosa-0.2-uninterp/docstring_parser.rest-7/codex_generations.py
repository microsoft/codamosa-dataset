

# Generated at 2022-06-17 18:27:29.720615
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :type arg2: int
    :param arg3: This is a third argument.
    :type arg3: str
    :param arg4: This is a fourth argument.
    :type arg4: str
    :param arg5: This is a fifth argument.
    :type arg5: str
    :returns: This is a description of the return value.
    :rtype: int
    """
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == "This is a short description."
    assert parsed_docstring.long_description == "This is a long description."
    assert parsed_doc

# Generated at 2022-06-17 18:27:39.575017
# Unit test for function parse

# Generated at 2022-06-17 18:27:53.263017
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a description of arg1.
    :param arg2: This is a description of arg2.
    :returns: This is a description of the return value.
    :raises Exception: This is a description of the exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 3
    assert parsed.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:28:01.793112
# Unit test for function parse

# Generated at 2022-06-17 18:28:10.430605
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring.

    :param str name: The name of the person.
    :param int age: The age of the person.
    :returns: The person's name and age.
    :rtype: str
    """

# Generated at 2022-06-17 18:28:21.218702
# Unit test for function parse

# Generated at 2022-06-17 18:28:31.998793
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param foo: This is a foo.
    :type foo: str
    :param bar: This is a bar.
    :type bar: int
    :returns: This is a return.
    :rtype: bool
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == "This is a foo.\nThis is a bar."
    assert doc.meta[0].arg_name == "foo"
    assert doc.meta[0].type_name == "str"
    assert doc.meta[1].arg_name == "bar"
    assert doc.meta[1].type_name == "int"
    assert doc.meta[2].type_name == "bool"

# Generated at 2022-06-17 18:28:42.748933
# Unit test for function parse

# Generated at 2022-06-17 18:28:55.632408
# Unit test for function parse

# Generated at 2022-06-17 18:29:07.016030
# Unit test for function parse

# Generated at 2022-06-17 18:29:21.674264
# Unit test for function parse

# Generated at 2022-06-17 18:29:32.579269
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:29:40.623035
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :returns: This is a description of what is returned.
    :raises keyError: This is a description of what raises.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 3
    assert parsed.meta[0].args == ['param', 'arg1']
    assert parsed.meta[0].description == 'This is a first argument.'

# Generated at 2022-06-17 18:29:53.878032
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: description of arg1
    :param arg2: description of arg2
    :returns: description of return value
    :raises Exception: description of exception
    """

    d = parse(docstring)
    assert d.short_description == "Short description."
    assert d.long_description == "Long description."
    assert d.blank_after_short_description
    assert d.blank_after_long_description

    assert len(d.meta) == 3
    assert d.meta[0].args == ["param", "arg1"]
    assert d.meta[0].description == "description of arg1"
    assert d.meta[1].args == ["param", "arg2"]

# Generated at 2022-06-17 18:30:05.358163
# Unit test for function parse

# Generated at 2022-06-17 18:30:14.151148
# Unit test for function parse

# Generated at 2022-06-17 18:30:27.436126
# Unit test for function parse

# Generated at 2022-06-17 18:30:37.645219
# Unit test for function parse

# Generated at 2022-06-17 18:30:48.642314
# Unit test for function parse

# Generated at 2022-06-17 18:30:56.909682
# Unit test for function parse

# Generated at 2022-06-17 18:31:19.051567
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: Description of arg1.
    :type arg1: int
    :param arg2: Description of arg2.
    :type arg2: str
    :returns: Description of return value.
    :rtype: bool
    :raises ValueError: Description of exception.
    """

# Generated at 2022-06-17 18:31:28.454279
# Unit test for function parse

# Generated at 2022-06-17 18:31:40.249727
# Unit test for function parse

# Generated at 2022-06-17 18:31:54.552809
# Unit test for function parse

# Generated at 2022-06-17 18:32:01.497804
# Unit test for function parse

# Generated at 2022-06-17 18:32:13.817066
# Unit test for function parse

# Generated at 2022-06-17 18:32:23.459575
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param str name: The name of the person.
    :param int age: The age of the person.
    :param bool is_cool: Whether the person is cool. Defaults to False.
    :returns: The person's name and age.
    :rtype: str
    :raises ValueError: If the person is too old.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 4
    assert parsed.meta[0].arg_name == "name"

# Generated at 2022-06-17 18:32:35.726111
# Unit test for function parse

# Generated at 2022-06-17 18:32:45.015036
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a param.
    :param arg2: This is a param.
    :param arg3: This is a param.
    :returns: This is a return.
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "This is a param."

# Generated at 2022-06-17 18:32:56.409282
# Unit test for function parse

# Generated at 2022-06-17 18:33:21.055123
# Unit test for function parse

# Generated at 2022-06-17 18:33:27.951560
# Unit test for function parse

# Generated at 2022-06-17 18:33:39.146853
# Unit test for function parse

# Generated at 2022-06-17 18:33:50.184234
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :param arg2: This is arg2.
    :type arg2: str
    :param arg3: This is arg3.
    :type arg3: int, optional
    :param arg4: This is arg4.
    :type arg4: int, optional
    :param arg5: This is arg5.
    :type arg5: int, optional, defaults to 5.
    :returns: This is a return.
    :rtype: str
    :raises keyError: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."

# Generated at 2022-06-17 18:33:57.427222
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring = """
    This is a short description.

    This is a long description.

    :param x: This is a parameter.
    :type x: int
    :param y: This is another parameter.
    :type y: str
    :returns: This is a return value.
    :rtype: bool
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ['param', 'x']
    assert doc.meta[0].description == "This is a parameter."

# Generated at 2022-06-17 18:34:07.369282
# Unit test for function parse

# Generated at 2022-06-17 18:34:18.965370
# Unit test for function parse

# Generated at 2022-06-17 18:34:30.802283
# Unit test for function parse

# Generated at 2022-06-17 18:34:41.910010
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:34:56.512435
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """

# Generated at 2022-06-17 18:35:21.021579
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a param.
    :type arg1: str
    :param arg2: This is a param with a default value.
    :param arg3: This is a param with a default value.
        Defaults to True.
    :type arg3: bool
    :returns: None
    :rtype: None
    :raises keyError: This is an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False

# Generated at 2022-06-17 18:35:29.584066
# Unit test for function parse

# Generated at 2022-06-17 18:35:41.253428
# Unit test for function parse

# Generated at 2022-06-17 18:35:54.885602
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:35:59.478480
# Unit test for function parse

# Generated at 2022-06-17 18:36:09.109635
# Unit test for function parse

# Generated at 2022-06-17 18:36:20.926358
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """

# Generated at 2022-06-17 18:36:32.148989
# Unit test for function parse

# Generated at 2022-06-17 18:36:42.396137
# Unit test for function parse

# Generated at 2022-06-17 18:36:54.378543
# Unit test for function parse