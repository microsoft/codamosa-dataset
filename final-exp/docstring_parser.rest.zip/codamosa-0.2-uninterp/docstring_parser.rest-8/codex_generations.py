

# Generated at 2022-06-17 18:27:26.924075
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:27:37.009506
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a param.
    :type arg1: str
    :param arg2: This is a param with a default value.
    :param arg3: This is a param with a default value.
        Defaults to True.
    :type arg3: bool
    :returns: This is a return.
    :rtype: int
    :raises keyError: This is an exception.
    """

# Generated at 2022-06-17 18:27:47.994591
# Unit test for function parse

# Generated at 2022-06-17 18:27:58.671306
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    result = parse(docstring)
    assert result.short_description == "This is a short description."
    assert result.blank_after_short_description == True
    assert result.long_description == "This is a long description."
    assert result.blank_after_long_description == False
    assert len(result.meta) == 4
    assert result.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:28:08.836252
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a param.
    :type arg1: str
    :param arg2: This is a param with a default value.
    :param arg3: This is a param with a default value.
    :type arg2: int, optional
    :type arg3: int, optional
    :default arg2: 42
    :default arg3: 42
    :raises ValueError: if something bad happens.
    :returns: description of return value
    :rtype: int
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc

# Generated at 2022-06-17 18:28:20.746337
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param int a: This is a parameter.
    :param str b: This is a parameter.
    :param c: This is a parameter.
    :return: This is a return value.
    :rtype: int
    :raises ValueError: This is an exception.
    """

# Generated at 2022-06-17 18:28:31.597049
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param int x: This is a parameter.
    :param str y: This is another parameter.
    :returns: This is a return value.
    :rtype: str
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "x"
    assert doc.meta[0].type_name == "int"
    assert doc.meta[0].description == "This is a parameter."

# Generated at 2022-06-17 18:28:42.680587
# Unit test for function parse

# Generated at 2022-06-17 18:28:55.598038
# Unit test for function parse

# Generated at 2022-06-17 18:29:02.767307
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a param.
    :type arg1: str
    :param arg2: This is a param with a default value.
    :param arg3: This is a param with a default value.
        Defaults to True.
    :type arg3: bool
    :returns: This is a return.
    :rtype: int
    :raises keyError: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False

# Generated at 2022-06-17 18:29:19.629422
# Unit test for function parse

# Generated at 2022-06-17 18:29:31.679935
# Unit test for function parse

# Generated at 2022-06-17 18:29:41.794216
# Unit test for function parse

# Generated at 2022-06-17 18:29:54.268215
# Unit test for function parse

# Generated at 2022-06-17 18:30:05.643209
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a parameter.
    :type arg1: str
    :param arg2: This is a parameter with a default value.
    :param arg3: This is a parameter with a default value.
                 Defaults to True.
    :type arg3: bool
    :returns: None
    :rtype: None
    :raises keyError: This is an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 4
    assert parsed

# Generated at 2022-06-17 18:30:15.950620
# Unit test for function parse

# Generated at 2022-06-17 18:30:28.372366
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a description of arg1.
    :param arg2: This is a description of arg2.
    :param arg3: This is a description of arg3.
    :returns: This is a description of the return value.
    :raises Exception: This is a description of the exception.
    """

# Generated at 2022-06-17 18:30:38.298740
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is the first argument.
    :type arg1: str
    :param arg2: This is the second argument.
    :type arg2: int
    :returns: This is the return value.
    :rtype: str
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].description == "This is the first argument."

# Generated at 2022-06-17 18:30:49.160054
# Unit test for function parse

# Generated at 2022-06-17 18:31:01.421281
# Unit test for function parse

# Generated at 2022-06-17 18:31:17.596699
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a param.
    :type arg1: str
    :param arg2: This is another param.
    :type arg2: int
    :returns: This is a return.
    :rtype: bool
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].description == "This is a param."
    assert parsed

# Generated at 2022-06-17 18:31:27.133067
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is a parameter with a default value.
    :type bar: int
    :default bar: 42
    :raises ValueError: This is a possibility.
    :returns: This is a return value.
    :rtype: int
    """

# Generated at 2022-06-17 18:31:34.202766
# Unit test for function parse

# Generated at 2022-06-17 18:31:44.414023
# Unit test for function parse

# Generated at 2022-06-17 18:31:56.311621
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Nothing.
    :raises Exception: For no reason.
    """

# Generated at 2022-06-17 18:32:02.295382
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: Description of arg1.
    :type arg1: str
    :param arg2: Description of arg2.
    :type arg2: int
    :returns: Description of return value.
    :rtype: bool
    """
    doc = parse(docstring)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type_name == "str"
    assert doc.meta[1].arg_name == "arg2"

# Generated at 2022-06-17 18:32:14.669231
# Unit test for function parse

# Generated at 2022-06-17 18:32:23.970254
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].description == "This is a first argument."

# Generated at 2022-06-17 18:32:36.295582
# Unit test for function parse

# Generated at 2022-06-17 18:32:45.380584
# Unit test for function parse

# Generated at 2022-06-17 18:33:01.051510
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :type arg1: str
    :param arg2: This is a second argument.
    :type arg2: int
    :param arg3: This is a third argument.
    :type arg3: bool
    :returns: This is a return value.
    :rtype: str
    :raises ValueError: This is a exception.
    """
    result = parse(docstring)
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert len(result.meta) == 4

# Generated at 2022-06-17 18:33:10.831354
# Unit test for function parse

# Generated at 2022-06-17 18:33:21.524911
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param int foo: This is a parameter.
    :param str bar: This is a parameter.
    :returns: This is a return value.
    :rtype: str
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 3
    assert parsed.meta[0].args == ["param", "int", "foo"]
    assert parsed.meta[0].description == "This is a parameter."

# Generated at 2022-06-17 18:33:28.357184
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :returns: This is a description of what is returned.
    :raises keyError: This is a description of what is raised.
    """

    parsed = parse(docstring)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].description == "This is the first argument."
    assert parsed.meta[1].arg_name == "arg2"

# Generated at 2022-06-17 18:33:39.344864
# Unit test for function parse

# Generated at 2022-06-17 18:33:50.336540
# Unit test for function parse
def test_parse():
    text = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :type arg1: str
    :param arg2: This is arg2.
    :type arg2: int
    :returns: This is the return value.
    :rtype: bool
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:34:02.729546
# Unit test for function parse

# Generated at 2022-06-17 18:34:14.471606
# Unit test for function parse

# Generated at 2022-06-17 18:34:20.047289
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :returns: Nothing.
    :raises keyError: raises an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 3
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].type_name == None
    assert parsed.meta[0].is_optional == None

# Generated at 2022-06-17 18:34:32.180528
# Unit test for function parse

# Generated at 2022-06-17 18:34:47.448112
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :param arg2: this is arg2
    :param arg3: this is arg3
    :returns: None
    :raises keyError: raises an exception
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].description == "this is arg1"

# Generated at 2022-06-17 18:34:58.412391
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is arg1.
    :param arg2: This is arg2.
    :type arg2: int
    :param arg3: This is arg3.
    :type arg3: int, optional
    :param arg4: This is arg4.
    :type arg4: int, optional
        defaults to 42.
    :param arg5: This is arg5.
    :type arg5: int, optional
        defaults to 42.
    :returns: This is what is returned.
    :rtype: int
    :raises ValueError: If something bad happens.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description

# Generated at 2022-06-17 18:35:10.684441
# Unit test for function parse

# Generated at 2022-06-17 18:35:23.139750
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: this is arg1
    :type arg1: int
    :param arg2: this is arg2
    :type arg2: str, optional
    :returns: None
    :rtype: int
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].type_name == "int"
    assert parsed.meta[0].is_optional == False

# Generated at 2022-06-17 18:35:36.369708
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a param.
    :type arg1: str
    :param arg2: This is a param with a default value.
    :param arg3: This is a param with a default value.
        Defaults to True.
    :type arg3: bool
    :returns: This is a return.
    :rtype: int
    :raises keyError: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description

# Generated at 2022-06-17 18:35:48.849369
# Unit test for function parse

# Generated at 2022-06-17 18:36:01.760995
# Unit test for function parse

# Generated at 2022-06-17 18:36:12.915528
# Unit test for function parse

# Generated at 2022-06-17 18:36:23.029897
# Unit test for function parse
def test_parse():
    doc = parse("""
    This is a short description.

    This is a long description.

    :param foo: This is foo.
    :type foo: int
    :param bar: This is bar.
    :type bar: str
    :returns: This is the return value.
    :rtype: str
    :raises ValueError: This is the exception.
    """)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "foo"]
    assert doc.meta[0].description == "This is foo."

# Generated at 2022-06-17 18:36:34.059321
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is another parameter.
    :type bar: int
    :returns: This is what is returned.
    :rtype: bool
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].args == ['param', 'foo']
    assert parsed.meta[0].description == "This is a parameter."
    assert parsed.meta[0].arg_name == "foo"


# Generated at 2022-06-17 18:36:52.764861
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a first argument.
    :param arg2: This is a second argument.
    :param arg3: This is a third argument.
    :returns: This is a return value.
    :raises Exception: This is an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:37:03.833444
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.

    :param arg1: This is a description of arg1.
    :type arg1: int
    :param arg2: This is a description of arg2.
    :type arg2: str
    :returns: This is a description of the return value.
    :rtype: int
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type