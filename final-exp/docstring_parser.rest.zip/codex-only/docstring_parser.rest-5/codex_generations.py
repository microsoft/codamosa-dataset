

# Generated at 2022-06-23 17:16:28.929789
# Unit test for function parse
def test_parse():
    text = inspect.cleandoc(
    """
    A docstring for ``my_func``.

    :param x: the first param
    :type x: str
    :param y: a second param, optional
    :type y: int?
    :returns: the return value
    :rtype: float
    """
    )

# Generated at 2022-06-23 17:16:38.660659
# Unit test for function parse
def test_parse():
    assert parse("Test docstring.") == Docstring(
        short_description="Test docstring.", long_description=None, meta=[]
    )

    assert parse("Test\ndocstring.") == Docstring(
        short_description="Test",
        long_description="docstring.",
        meta=[],
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

    assert parse(
        """
    Test docstring.

    This is a longer description.
    """
    ) == Docstring(
        short_description="Test docstring.",
        long_description="This is a longer description.",
        meta=[],
        blank_after_short_description=False,
        blank_after_long_description=True,
    )


# Generated at 2022-06-23 17:16:47.063018
# Unit test for function parse
def test_parse():
    docstring = """
    Sum up everything.

    :param integer a: left hand integer
    :param integer b: right hand integer
    :returns: sum
    :raises ValueError: if a is negative
    """

# Generated at 2022-06-23 17:16:58.129599
# Unit test for function parse
def test_parse():
    docstring = """
        This is the short desc

        This is the long desc

        :param a: this is argument a's docstring
        :type a: number
        :param b: this is argument b's docstring
        :type b: number
        :returns: a + b
        :rtype: number
        :raises ValueError: if a or b is not a number
    """

    doc = parse(docstring)
    assert doc.short_description == "This is the short desc"
    assert doc.long_description == "This is the long desc"
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 4
    assert isinstance(doc.meta[0], DocstringParam)

# Generated at 2022-06-23 17:17:05.765568
# Unit test for function parse
def test_parse():
    foo = inspect.cleandoc(
        """
    Short description.

    Long description (may span multiple lines).

    :param x: description of x
    :type x: int
    :param y: description of y
    :type y: bool
    :param z: description of z
    :type z: str

    :returns: description of return value
    :rtype: float
    """
    )


# Generated at 2022-06-23 17:17:07.909587
# Unit test for function parse
def test_parse():
    from .test_common import parse_test

    return parse_test(parse)

# Generated at 2022-06-23 17:17:13.089528
# Unit test for function parse
def test_parse():
    doc = parse("""
        :param str s: The width of the box.
        :returns: The area of the box.
    """)
    assert len(doc.meta) == 2
    assert isinstance(doc.meta[0], DocstringParam)
    assert isinstance(doc.meta[1], DocstringReturns)
    assert doc.meta[0].arg_name == "s"
    assert doc.meta[0].type_name == "str"

# Generated at 2022-06-23 17:17:25.649258
# Unit test for function parse
def test_parse():
    # test_parse: 8
    docstring1 = """This is a short description.

This is a long description."""
    doc = parse(docstring1)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta == []

    # test_parse: 9
    docstring2 = """This is a short description.

This is a long description.

:a: kwarg 1
:b: kwarg 2"""
    doc = parse(docstring2)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."

# Generated at 2022-06-23 17:17:31.877276
# Unit test for function parse
def test_parse():
    s = """\
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    :rtype: :class:`Docstring`
    """

    assert str(parse(s)) == """\
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    :rtype: :class:`Docstring`"""

# Generated at 2022-06-23 17:17:42.260616
# Unit test for function parse
def test_parse():
    docstring = """
    Testing parse function

    :param x: a parameter
    :type x: int
    :param y: another parameter
    :param z: a third parameter
    :type z: list

    :param ?name: name of the object
    :type ?name: str
    :param id: id of the object, defaults to 0
    :type id: int

    :returns: x + y + z
    :returns: ? the sum of x and y
    :rtype: int

    :yields: x + y + z
    :yields: ? the sum of x and y
    :ytype: int

    Raises:

    :raises ValueError: if y is too high
    :raises TypeError: if x is not an int
    """
    pd = parse(docstring)


# Generated at 2022-06-23 17:17:52.666309
# Unit test for function parse
def test_parse():
    from .common import Docstring, \
        DocstringLongDescription,\
        DocstringMeta,\
        DocstringParam,\
        DocstringRaises,\
        DocstringReturns

    assert parse("") == Docstring()


# Generated at 2022-06-23 17:18:00.026576
# Unit test for function parse
def test_parse():
    doc = parse('''Single line short description.

Single line long description.''')
    assert doc.short_description == 'Single line short description.'
    assert doc.long_description == 'Single line long description.'
    assert len(doc.meta) == 0
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is True


# Generated at 2022-06-23 17:18:10.604060
# Unit test for function parse

# Generated at 2022-06-23 17:18:16.011524
# Unit test for function parse
def test_parse():
    text = """
    First line.

    Second line.
    """

    docstring = parse(text)
    assert len(docstring.meta) == 0
    assert docstring.short_description == "First line."
    assert docstring.long_description == "Second line."
    assert docstring.blank_after_short_description
    assert not docstring.blank_after_long_description



# Generated at 2022-06-23 17:18:25.808821
# Unit test for function parse
def test_parse():
    docstring = """
    Function to assign a value of an
    :param arg1: name of the argument
    :type arg1: str
    :param arg2: value of the argument
    :type arg2: str
    :returns: List of argument value
    :rtype: List[int]
    :raises: IndexError, KeyError
    """
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == "Function to assign a value of an"
    assert parsed_docstring.long_description == None
    assert len(parsed_docstring.meta) == 6
    assert parsed_docstring.meta[0].args == ['param', 'arg1']
    assert parsed_docstring.meta[0].description == "name of the argument"

# Generated at 2022-06-23 17:18:33.831015
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("This is a docstring.") == Docstring(
        short_description="This is a docstring."
    )
    assert parse("Hello.\nThis is a docstring.\n\n    ") == Docstring(
        short_description="Hello.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="This is a docstring.",
    )
    assert parse(
        "Hello.\n This is a docstring.\n\n    "
    ) == Docstring(
        short_description="Hello.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="This is a docstring.",
    )

# Generated at 2022-06-23 17:18:45.057522
# Unit test for function parse

# Generated at 2022-06-23 17:18:56.472490
# Unit test for function parse
def test_parse():
    docstring = """First line of the description.
    Second line.

    :param int a: First argument.

    :param str b: Second argument.
    :type b: str

    :type t: int

    :returns: a + b
    :rtype: int

    :raises DefinitelyNotAnException: if everything went wrong.
    """

# Generated at 2022-06-23 17:19:08.374631
# Unit test for function parse
def test_parse():
    text = """
    This is a brief description.

    This is a long description.
    """
    assert parse(text).short_description == "This is a brief description."
    assert parse(text).long_description == "This is a long description."

    # For this to work, the code should not use re.M
    text = """
    This is a brief description.

    This is a long description and this should be split
    """ 
    assert parse(text).short_description == "This is a brief description."
    assert parse(text).long_description == None

    text = """
    This is a brief description.
    :arg type arg_name: description
    """
    assert parse(text).short_description == "This is a brief description."
    assert parse(text).meta[0].type_name == "type"

# Generated at 2022-06-23 17:19:17.274591
# Unit test for function parse
def test_parse():

    sample = """\
    parse_docstring

    This function is used to parse docstring into components.

    :param str text: docstring to be parsed
    :returns: parsed docstring
    :raises:  TypeError, if type of text is not string
    """


# Generated at 2022-06-23 17:19:27.702628
# Unit test for function parse

# Generated at 2022-06-23 17:19:37.410625
# Unit test for function parse
def test_parse():
    input_1 = """A function that adds two numbers.
    :param int x: The first numnber.
    :param int y: The second number.
    """
    assert parse(input_1) == Docstring(
        short_description='A function that adds two numbers.',
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[
            DocstringMeta(
                args=['param', 'int', 'x'],
                description='The first numnber.',
            ),
            DocstringMeta(
                args=['param', 'int', 'y'],
                description='The second number.',
            ),
        ],
    )



# Generated at 2022-06-23 17:19:43.585603
# Unit test for function parse
def test_parse():
    src = inspect.getsource(parse)
    docstring = parse(src)
    assert docstring.short_description == "Parse the ReST-style docstring into its components."
    assert docstring.long_description == ":returns: parsed docstring"
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args == ['returns']
    assert docstring.meta[0].description == 'parsed docstring'
    # noinspection PyUnresolvedReferences
    assert isinstance(docstring.meta[0], DocstringReturns)

test_parse()

# Generated at 2022-06-23 17:19:54.666772
# Unit test for function parse
def test_parse():
    doc = parse.__doc__
    parsed = parse(doc)
    assert parsed == Docstring(
        short_description=(
            r"Parse the ReST-style docstring into its components."
        ),
        long_description=(
            r":returns: parsed docstring"
        ),
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[
            DocstringParam(
                args=['returns'], description=(
                    r"parsed docstring"
                ), arg_name=(
                    "parsed"
                ), type_name=(
                    "Docstring"
                ), is_optional=False, default=None
            )
        ]
    )



# Generated at 2022-06-23 17:20:06.465610
# Unit test for function parse
def test_parse():
    rest = """\
    First line of the docstring.

    :param s: The string to be checked.
    :type s: str
    :param bool case_sensitive: A flag to control case sensitivity
        (defaults to `False`).
    :returns: `True` if the string contains any alphanumeric character(s),
        `False` otherwise.
    """

# Generated at 2022-06-23 17:20:10.663395
# Unit test for function parse
def test_parse():
    doc = """This is first sentence.\nThis is second sentence.\n\nThis is the third sentence.\n\n:param str name: The name of the project.\n:param str version: The version string."""
    x = parse(doc)
    return x

# Generated at 2022-06-23 17:20:19.849704
# Unit test for function parse
def test_parse():
    func = parse
    doc = inspect.getdoc(func)
    docstring = parse(doc)
    assert docstring.short_description == "ReST-style docstring parsing."
    assert docstring.blank_after_short_description == True
    assert docstring.long_description == """\
    ``reST``-style docstring parsing.

    ``reST`` is an acronym for *ReStructured Text*. This is a markup language
    that is similar to ``Markdown``. It is used primarily in the documentation
    of Python projects.
    """
    assert type(docstring.meta[0]) is DocstringMeta
    assert docstring.meta[0].args == ['key', "value"]
    assert docstring.meta[0].description == "Lorem Ipsum."
    assert type(docstring.meta[1]) is DocstringReturns


# Generated at 2022-06-23 17:20:31.182331
# Unit test for function parse
def test_parse():
    assert parse("This is a short description.\n\n\tThis is a long description.") == Docstring(
        short_description = "This is a short description.",
        blank_after_short_description = True,
        blank_after_long_description = False,
        long_description = "This is a long description.",
        meta = list()
    )

    assert parse("This is a short description:\n\n\tThis is a long description.") == Docstring(
        short_description = "This is a short description:",
        blank_after_short_description = True,
        blank_after_long_description = False,
        long_description = "This is a long description.",
        meta = list()
    )

    assert parse("This is a short description.\n\n:returns: foo\n\tReturns a description.")

# Generated at 2022-06-23 17:20:41.092166
# Unit test for function parse
def test_parse():
    docstring = parse("""
    Runs command and prints output.

    :param arg1: description 1
    :param arg2: description 2

    :returns: str -- command output
    :raises IOError: if command fails
    """)

    # print(docstring)

    if not docstring.short_description == "Runs command and prints output.":
        print("ERROR: short_description:", docstring.short_description)

    if docstring.blank_after_short_description:
        print("ERROR: blank_after_short_description: True")

    if not docstring.long_description == "param arg1: description 1\nparam arg2: description 2":
        print("ERROR: long_description:", docstring.long_description)


# Generated at 2022-06-23 17:20:53.013631
# Unit test for function parse
def test_parse():
    def func1():
        """One-line docstring.

        This function is useless.
        :param x: input
        """

    text = '''One-line docstring.

This function is useless.
:param x: input
'''

    ds = parse(text)
    result = (
        ds.short_description == "One-line docstring."
        and not ds.blank_after_short_description
        and ds.long_description == "This function is useless."
        and not ds.blank_after_long_description
        and not ds.meta
    )
    assert result, ds

    ds = parse(func1.__doc__)

# Generated at 2022-06-23 17:21:00.949387
# Unit test for function parse
def test_parse():
    text = """
    Test the ReST-style docstring into its components.

    :param n: This is a test.
    :type n: int
    :returns: parsed docstring
    :rtype: Docstring
    """
    doc = parse(text)
    assert doc.short_description == 'Test the ReST-style docstring into its components.'
    assert doc.meta == [DocstringParam(args=['param', 'n', 'This'], description='is a test.', arg_name='This', type_name='n', is_optional=False, default=None), DocstringReturns(args=['returns', 'parsed'], description='docstring', type_name='parsed', is_generator=False)]

# Generated at 2022-06-23 17:21:13.014186
# Unit test for function parse
def test_parse():
    assert parse("hello") == Docstring(
        short_description="hello",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("hello\nworld") == Docstring(
        short_description="hello",
        long_description="world",
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

    # Include the blank lines in the description unless they are on the first
    # two lines.

# Generated at 2022-06-23 17:21:24.536720
# Unit test for function parse
def test_parse():
    docstring = parse("""This is a function.

:param str foo: Some parameter.
:param str bar: Optional parameter with default value. Defaults to 1.
:returns: something.
:rtype: bool
:raises ImportError: This function raises ImportError sometimes.
""")
    assert docstring.short_description == "This is a function."
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == True
    assert docstring.long_description == None
    assert len(docstring.meta) == 4
    assert docstring.meta[0].keyword == 'param'
    assert docstring.meta[0].params == ['param', 'str', 'foo']
    assert docstring.meta[0].description == 'Some parameter.'

# Generated at 2022-06-23 17:21:35.344990
# Unit test for function parse
def test_parse():
    """Test parse function ."""
    docstring = inspect.cleandoc("""
    Docstring

    :param a: some param
    :param b: some param
    """)
    result = parse(docstring)
    assert result.long_description is None
    assert len(result.meta) == 2
    assert result.meta[0].key == "param"
    assert result.meta[0].arg_name == "a"
    assert result.meta[1].key == "param"
    assert result.meta[1].arg_name == "b"


# Generated at 2022-06-23 17:21:39.364866
# Unit test for function parse
def test_parse():
    text = '''
    Returns feature to its serialized form.

    :param obj ~typing.Any:
        Object to be serialized.

    :raises TypeError:
        If a serializer is not found.
    '''

    assert text == str(parse(text))

# Generated at 2022-06-23 17:21:45.011268
# Unit test for function parse
def test_parse():
    doc = "Parse the ReST-style docstring into its components.\n"
    doc += "\n"
    doc += "Returns:\n"
    doc += "    parsed docstring\n"
    doc += ":rtype: Docstring\n"

    assertDocstring(parse(doc), short_description=doc[:8])
    assert parse(doc).long_description == doc[9:42]



# Generated at 2022-06-23 17:21:56.193517
# Unit test for function parse
def test_parse():
    docstring_text = """
        Parse the ReST-style docstring into its components.

        This function parses the ReST-style docstring and returns the
        parsed content.

        :param text: ReST-style docstring text
        :type text:  str
        :param indent: indentation to use
        :type indent: int or None
        :returns: parsed docstring
        :rtype:  Docstring
        :raises ValueError: if an error is encountered while parsing
        """
    fmt = "{type_name} {arg_name}: {description}"
    docstring = parse(docstring_text)
    parameters = [parameter.description for parameter in docstring.meta if parameter.type_name == 'param']
    parameters = '\n'.join(parameters)

# Generated at 2022-06-23 17:22:06.769682
# Unit test for function parse
def test_parse():
    text = """
    Converts an integer to a string.

    :param int integer: Number to be converted.
    :param int base: Base of the output string, between 2 and 36.
        Defaults to 10.
    :raises ValueError: If base is outside the range [2, 36].

    :returns: The string representation of ``integer`` in the given base.
    :rtype: str
    """

    ds = parse(text)

# Generated at 2022-06-23 17:22:16.663670
# Unit test for function parse
def test_parse():
    text = '''
        Test function.

        :param int x: Test parameter
        :returns: Test return

        Test docstring.

        :param int x: Test parameter
        :returns: Test return
        '''
    docstring = parse(text)
    assert docstring.short_description == "Test function."
    assert docstring.blank_after_short_description
    assert docstring.long_description == 'Test docstring.'
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].description == 'Test parameter'
    assert docstring.meta[1].description == 'Test return'

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:22:21.722728
# Unit test for function parse
def test_parse():
    docstring = '''
    Short summary.

    Args:
        a_string (str): A string
        a_list (List[int], optional): A list of integers. Defaults to [].

    Yields:
        int: The next integer in the sequence.
    '''

    assert parse(docstring).long_description == '''
    Args:
        a_string (str): A string
        a_list (List[int], optional): A list of integers. Defaults to [].

    Yields:
        int: The next integer in the sequence.'''

# Generated at 2022-06-23 17:22:33.575738
# Unit test for function parse

# Generated at 2022-06-23 17:22:45.534936
# Unit test for function parse
def test_parse():
    d = """Summarize the function.

    Paragraph 1
    Paragraph 2 (a continuation of paragraph 1)

    :param arg1: Argument 1, a string\n
                 and the second line.
    :param arg2: Argument 2.
    :type arg2: string
    :raises ValueError: When arg2 is not a valid string.
    :returns: arg1 - arg2
    :rtype: int
    """
    assert parse(d).short_description == "Summarize the function."
    assert parse(d).blank_after_short_description == False
    assert parse(d).blank_after_long_description == True
    assert parse(d).long_description == "Paragraph 1\nParagraph 2 (a continuation of paragraph 1)"

# Generated at 2022-06-23 17:22:56.912304
# Unit test for function parse
def test_parse():
    docstring = '''This function does some very interesting things.
        :param x: a number, the x coordinate
        :type x: int
        :param y: a number, the y coordinate
        :type y: int
        :returns: None
        :raises InvalidInputError: if any of x or y are too high.
'''
    doc = parse(docstring)
    assert len(doc.meta) == 4
    assert doc.meta[0].description == "a number, the x coordinate"
    assert doc.meta[0].type_name == "int"
    assert doc.meta[1].description == "a number, the y coordinate"
    assert doc.meta[1].type_name == "int"
    assert doc.meta[2].description == None
    assert doc.meta[2].type_name == None
   

# Generated at 2022-06-23 17:23:07.726818
# Unit test for function parse
def test_parse():
    input_text = """
    Create a new instance of `Test`.

    :param str a: foo
    :param str b: bar
    :param str c: baz
    :param int i: int
    :param float f: float
    :param list l: list
    :param Test t:
    :param Test t2:
    :returns: the new instance
    :rtype: Test
    """
    docstring = parse(input_text)
    assert docstring.short_description == "Create a new instance of `Test`."
    assert docstring.long_description is None
    assert docstring.blank_after_long_description is False
    assert docstring.blank_after_short_description is True
    assert len(docstring.meta) == 9
    assert docstring.meta[0].description == "foo"


# Generated at 2022-06-23 17:23:18.255393
# Unit test for function parse
def test_parse():
    # The parameter "text" of the function parse() is changed from str to typing.Any
    def test(text: str, expected: T.Any) -> None:
        result_dict = parse(text).to_dict()
        expected_dict = expected.to_dict()

        assert result_dict == expected_dict


# Generated at 2022-06-23 17:23:30.098274
# Unit test for function parse
def test_parse():
    example = """
    This is a short description.
    
    
    This is a long description.
    
    :param abc: Name of the thing.
    :type abc: str
    :param def: Number of the thing.
    :type def: int
    :default def: 1
    
    
    
    
    
    
    :returns: string
    :raises Exception: If some error occurs.
    :raises: If some other error occurs.
    :raises: If something occurs.
    
    
    
    
    
    
    
    
    
    
    """

    parsed = parse(example)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description

# Generated at 2022-06-23 17:23:40.529456
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse(":") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("x\n") == Docstring()
    assert parse("x\n\n") == Docstring()
    assert parse("x\nx\n") == Docstring()
    assert parse("x\nx\n\n") == Docstring()

    assert parse("x") == Docstring("x", "")
    assert parse("x\n") == Docstring("x", "")
    assert parse("x\nx") == Docstring("x", "x")
    assert parse("x\nx\n") == Docstring("x", "x")
    assert parse("x\nx\n\n") == Docstring("x", "x")


# Generated at 2022-06-23 17:23:49.887766
# Unit test for function parse
def test_parse():
    '''
    Unit test for parse function
    '''
    from .common import DOCSTRING_METADATA
    from .doctest import convert_namespace
    from .numpy import extract_from_numpy_docstring
    from .google import extract_from_google_docstring

    for ns, namespace in DOCSTRING_METADATA.items():
        docstrings = []
        for namespace_function in namespace:
            #print(namespace_function)
            if ns == 'numpy':
                docstrings.append(extract_from_numpy_docstring(namespace_function))
            if ns == 'google':
                docstrings.append(extract_from_google_docstring(namespace_function))

        # Handling numpy namespace because numpy documentation style
        # doesn't have a blank space between parameters and return


# Generated at 2022-06-23 17:24:00.592475
# Unit test for function parse
def test_parse():
    text = "Foo bar\n\n" \
           "Baz\n" \
           ":param str foo: Foo bar\n" \
           ":param int bar: Baz\n" \
           ":raises ValueError: Foo bar baz\n" \
           ":returns: Foo bar\n" \
           ":returns int: Baz\n" \
           ":yields: foo\n" \
           ":yields: bar, baz\n" \
           ":yields: foo bar, baz bar"

    v = parse(text)

    assert v.short_description == "Foo bar"
    assert v.long_description == "Baz"
    assert len(v.meta) == 6


# Generated at 2022-06-23 17:24:05.486390
# Unit test for function parse
def test_parse():
    text = r"""
    :param str name:
        The name of the new record to add.

    :raises TypeError:
        If a record with the same name exists.

    :return:
        The new record.

    :rtype: Record
    """
    assert parse(text).meta[0].arg_name == "name"
    assert parse(text).meta[0].is_optional == None
    assert parse(text).meta[0].default == None
    assert parse(text).meta[0].type_name == "str"
    assert parse(text).meta[0].args[0] == "param"
    assert parse(text).meta[0].args[1] == "str"
    assert parse(text).meta[0].args[2] == "name"
    assert parse(text).meta[1].arg_

# Generated at 2022-06-23 17:24:16.110988
# Unit test for function parse
def test_parse():
    """This function test the function parse
    """
    text = """
    This function adds two numbers.

    :param x: The first number.
    :type x: int
    :param y: The second number.
    :type y: int
    :param z: The third number.
    :type z: int
    :raises TypeError: if x or y are not numbers
    :return: The sum of x and y
    :rtype: int
    """
    parse(text)

    text = """
    This function adds two numbers.

    :param x: The first number.
    :type x: int
    :param y: The second number.
    :raises TypeError: if x or y are not numbers
    :return: The sum of x and y
    :rtype: int
    """
    parse(text)

# Generated at 2022-06-23 17:24:27.123525
# Unit test for function parse
def test_parse():
    assert parse("Hello World") == Docstring(
        short_description="Hello World",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description=None,
        meta=[],
    )
    assert parse("Hello World\n  This is the long description.") == Docstring(
        short_description="Hello World",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="This is the long description.",
        meta=[],
    )

# Generated at 2022-06-23 17:24:37.390220
# Unit test for function parse
def test_parse():
    from .common import DocstringMeta

    doc = """
    Short description
    Long description

    :param foo arg1: first arg
    :param bar arg2: second arg
    :param bar arg3: test arg
    :return: True
    """

    docstring = parse(doc)
    assert docstring.short_description == "Short description"
    assert docstring.long_description == "Long description"
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is True
    assert len(docstring.meta) == 4
    assert docstring.meta[0].__class__.__name__ == "DocstringParam"
    assert docstring.meta[1].__class__.__name__ == "DocstringParam"

# Generated at 2022-06-23 17:24:47.674088
# Unit test for function parse
def test_parse():
    docstring = """A function that receives a string and returns it unchanged.

:param str message: The string to return.
:returns: The same string.
"""
    print(parse(docstring))
    assert parse(docstring).short_description == "A function that receives a string and returns it unchanged."
    assert parse(docstring).long_description == None
    assert parse(docstring).blank_after_short_description == True
    assert parse(docstring).blank_after_long_description == False

# Generated at 2022-06-23 17:24:50.935003
# Unit test for function parse
def test_parse():
    assert parse("returns: int") == Docstring(
        meta=[DocstringReturns(args=["returns", "int"], description=None)]
    )


# vim:et sw=4 ts=4

# Generated at 2022-06-23 17:24:59.138377
# Unit test for function parse

# Generated at 2022-06-23 17:25:10.785769
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring = """
        This function is an example

        Args:
            arg1 (int): The first value
            arg2 (int): The second value. This is a, b, c
            arg3 (str): The third value
        Returns:
            int: The result
        """
    parsed = parse(docstring)
    assert parsed.short_description == "This function is an example"
    assert parsed.long_description == \
        "Args:\n" \
        "    arg1 (int): The first value\n" \
        "    arg2 (int): The second value. This is a, b, c\n" \
        "    arg3 (str): The third value\n" \
        "Returns:\n" \
        "    int: The result"
    assert parsed.blank

# Generated at 2022-06-23 17:25:19.433367
# Unit test for function parse
def test_parse():
    doc = parse.__doc__
    assert 'parse the ReST-style docstring' in doc
    assert ':returns:' in doc
    assert 'parsed docstring' in doc
    docstring = parse(doc)
    assert not docstring.short_description
    assert docstring.blank_after_short_description
    assert  not docstring.blank_after_long_description
    assert docstring.long_description
    assert len(docstring.meta) == 1
    assert docstring.meta[0].arg_name == 'text'
    assert docstring.meta[0].type_name == 'str'
    assert docstring.meta[0].is_optional == False
    assert docstring.meta[0].default is None

# Generated at 2022-06-23 17:25:27.419850
# Unit test for function parse
def test_parse():
    def test_func():
        """
        This is a fucntion with a docstring.
        """
        pass

    assert parse(test_func.__doc__) == Docstring(
        short_description="This is a fucntion with a docstring.",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )



# Generated at 2022-06-23 17:25:30.456338
# Unit test for function parse
def test_parse():
    docstring = '''Example
    :param model: -
    :type model: -
    :param n_batches: -
    :return: -
    :rtype: -
    '''
    assert parse(docstring)

test_parse()

# Generated at 2022-06-23 17:25:40.285723
# Unit test for function parse
def test_parse():
    text = """\
        Short description

        Long description.
        - item 1
        - item 2

        :param one: first param
        :param two: second param
        :returns: value
        :side effect: modifies state
        :raises CustomException: if invalid

        Final paragraph.
        """
    docstring = parse(text)
    assert docstring.short_description == "Short description"
    assert docstring.blank_after_short_description is True
    assert docstring.long_description == textwrap.dedent("""
            Long description.
            - item 1
            - item 2
            """)
    assert docstring.blank_after_long_description is False
    assert docstring.meta[0].args == ["param", "one", "first param"]

# Generated at 2022-06-23 17:25:52.200277
# Unit test for function parse
def test_parse():
    doc1 = """Return index and value of the minimum element.

    :param int a: A positive integer
    :param str[10] b: An array of 10 strings
    :returns: index and value of minimum element as a tuple
    :rtype: (int, float)
    :raises ValueError: if `a` is negative

    If the minimum element is repeated, the first one is returned.
    """
    doc2 = """\
    :type a: int
    :type b: str[10]
    :returns: index and value of minimum element as a tuple
    :rtype: (int, float)
    :raises ValueError: if `a` is negative
    """

# Generated at 2022-06-23 17:25:58.254084
# Unit test for function parse
def test_parse():

    test_string = """Example docstring
    :param x: description of x
    :param y (int): description of y
    :param z (bool)=False: description of z
    :param w: no type, defaults to 1
    :param q (int): a param with a long description that continues on
    the next line
    :param r (str): default is ''

    :param s: a param that has a long description that continues on the
    next line and then a second line

    :param t: a param that has a multi line description that continues
    on the next line and then a second line.
    """


# Generated at 2022-06-23 17:26:08.207131
# Unit test for function parse
def test_parse():
    code = """Example docstring.

:param foo: a string
:returns: a list of strings
:raises ValueError: in case of an error
:returns: a list of strings
"""
    result=parse(code)
    assert result.short_description == "Example docstring."
    assert result.long_description == None
    assert result.blank_after_long_description == True
    assert result.blank_after_short_description == True
    assert len(result.meta) == 3
    assert isinstance(result.meta[0],DocstringParam)
    assert result.meta[0].keyword == "param"
    assert result.meta[0].type_name == None
    assert result.meta[0].arg_name == "foo"
    assert result.meta[0].description == "a string"

# Generated at 2022-06-23 17:26:17.010256
# Unit test for function parse

# Generated at 2022-06-23 17:26:25.323802
# Unit test for function parse
def test_parse():
    """docstring for test_parse"""
    from .numpy import parse
    import inspect
    import pprint
    from .numpy import Docstring

    def a():
        """first line
        
        second line
        """
        pass
    print(parse(inspect.getdoc(a)))
    assert parse(inspect.getdoc(a)) == Docstring(
        short_description='first line',
        long_description='second line',
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )
