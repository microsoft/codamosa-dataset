

# Generated at 2022-06-23 17:16:32.283812
# Unit test for function parse
def test_parse():
    t = parse.__doc__
    x = parse(t)
    assert x.short_description == "Parse the ReST-style docstring into its components."
    assert x.long_description == ":\n    :param text: docstring\n    :type text: str\n    :returns: parsed docstring"
    assert x.meta[0].arg_name == 'text'
    assert x.meta[0].type_name == 'str'
    assert x.meta[1].type_name == ':class:`Docstring`'
    assert len(x.meta) == 3

# Generated at 2022-06-23 17:16:39.849037
# Unit test for function parse
def test_parse():
    class_comment = """
    A test class

    Some text describing the test class.
    
    :param str name: A string parameter.
    :param bool test: A bool parameter.
    :param int count: A int parameter.
    :returns: The return value
    :rtype: int
    """
    d = parse(class_comment)
    assert d.short_description == "A test class"
    assert isinstance(d.meta[0], DocstringParam)
    assert d.meta[0].args == ['param','str','name'] 
    assert d.meta[0].description == "A string parameter."
    assert d.meta[0].arg_name == "name"
    assert d.meta[0].type_name == "str"
    assert d.meta[0].is_optional == False
    assert d

# Generated at 2022-06-23 17:16:45.799333
# Unit test for function parse
def test_parse():
    # Arrange
    text = """
    The hello function.

    :param str name: The name of the person.
    :return: The hello message.
    :raises RuntimeError: If something bad happens.
    """

    # Act
    docstring = parse(text)

    # Assert
    assert docstring.short_description == "The hello function."
    assert docstring.blank_after_short_description == False
    assert docstring.long_description == None
    assert docstring.blank_after_long_description == True



# Generated at 2022-06-23 17:16:56.651567
# Unit test for function parse
def test_parse():
    document_string = """
    This is a document string
    of a function in IM
    that has a long description
    and multiple lines.

    :param int a:
        This is the first argument of the function
        with a description that also takes up
        multiple lines
    :param str b: This is the second argument of the function
    :param c: This is the third argument of the function
    :param d: This is the fourth argument of the function
    :return:
    :rtype:
    """
    x = parse(document_string)
    assert x.short_description == "This is a document string of a function in IM that has a long description and multiple lines."
    assert x.meta[0].description == "This is the first argument of the function with a description that also takes up\nmultiple lines"

# Generated at 2022-06-23 17:17:04.141719
# Unit test for function parse
def test_parse():
    docstring = """One-line summary.

    More detailed description. May be several paragraphs long.
    - list item
    - list item

    :param foo: Description of `foo` argument.
    :type foo: int
    :param bar: Description of `bar` argument.
    :type bar: str
    :param baz: Description of `baz` argument.
    :type baz: None
    :returns: Description of return value.
    :rtype: None
    :raises ValueError: If an error occurred.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "One-line summary."
    assert parsed.long_description == """More detailed description. May be several paragraphs long.
- list item
- list item"""
    assert len(parsed.meta) == 4
    assert parsed

# Generated at 2022-06-23 17:17:12.862645
# Unit test for function parse
def test_parse():
    docstring_text = """
    This function does something.

    Args:
        arg1 (str): This is arg1.
        arg2 (int): This is arg2.

    Return:
        bool: The return value. True for success, False otherwise.
    """

    ds = parse(docstring_text)
    assert ds.short_description == "This function does something."
    assert ds.blank_after_short_description
    assert ds.long_description == ""
    assert ds.blank_after_long_description
    assert ds.meta is not None
    assert ds.meta[0].args is not None
    assert ds.meta[1].args is not None

# Generated at 2022-06-23 17:17:13.652655
# Unit test for function parse
def test_parse():
    parse_docstring('test')
    

# Generated at 2022-06-23 17:17:25.934685
# Unit test for function parse

# Generated at 2022-06-23 17:17:31.877479
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.
    """

    expected = Docstring(
        short_description='Short description.',
        long_description='Long description.',
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse(docstring) == expected

# Generated at 2022-06-23 17:17:39.373252
# Unit test for function parse
def test_parse():
    func_name = "test"
    text = """one line summary

    long
    description

    :param int x: 1st param
    :param y: 2nd param
    :type y: int
    :returns: something
    :rtype: str
    :raises ValueError: if an error occurs
    """

    ret = parse(text)
    param = ret.meta.pop(0)
    assert param.key == "param"
    assert param.arg_name == "x"
    assert param.type_name == "int"
    assert param.description == "1st param"

    param = ret.meta.pop(0)
    assert param.key == "param"
    assert param.arg_name == "y"
    assert param.type_name is None
    assert param.descriptio

# Generated at 2022-06-23 17:17:48.101612
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    assert parse("") == Docstring()

    s = "Returns True if and only if the underlying reader is at EOF\n"
    s += "\n"
    s += ":returns:\n"
    s += "    :obj:`bool`: True if the underlying reader is at EOF; False\n"
    s += "        otherwise."
    doc = parse(s)
    assert doc.short_description == "Returns True if and only if the underlying reader is at EOF"
    assert doc.blank_after_short_description is True
    assert doc.blank_after_long_description is True
    assert doc.long_description is None
    assert len(doc.meta) == 1

# Generated at 2022-06-23 17:17:58.222950
# Unit test for function parse
def test_parse():
    """
    This function tests the parse function which parses a ReST-style docstring into its parts
    The tests are ReST-style docstrings and the expected outputs are the expected output of the
    Docstring object returned from parse
    """

    test_inputs = [
        """
        Short description
        ~~~~~~~~~~~~~~~~~

        Long description
        """
    ]

    test_outputs = [
        Docstring(
            short_description="Short description",
            blank_after_short_description=True,
            long_description="Long description",
            blank_after_long_description=True,
        )
    ]
    for i in range(len(test_inputs)):
        assert parse(test_inputs[i]) == test_outputs[i]


# Generated at 2022-06-23 17:18:09.031095
# Unit test for function parse
def test_parse():
    ex_docstr = """This method calculates the volume of a sphere.

:param radius: radius of the sphere
:type radius: int
:returns: the volume
:rtype: float

Raises:
  ValueError: If radius is negative."""

    docstr = parse(ex_docstr)
    assert docstr.short_description == "This method calculates the volume of a sphere."
    assert docstr.blank_after_short_description == True
    assert docstr.blank_after_long_description == True
    assert docstr.long_description == None

# Generated at 2022-06-23 17:18:18.956072
# Unit test for function parse

# Generated at 2022-06-23 17:18:30.595090
# Unit test for function parse
def test_parse():
    docstring_str = """
    This is a function to calculate the sum of two numbers.

    :param x: The first number.
    :param y: The second number.
    :type x: int
    :type y: float
    :returns: The result of sum.
    :rtype: float
    :raises TypeError: If wrong type, raise a TypeError.

    Usage::

        result = sum_two_numbers(3, 4.0)
    """
    docstring = parse(docstring_str)
    print(docstring.short_description)
    print(docstring.blank_after_short_description)
    print(docstring.long_description)
    print(docstring.blank_after_long_description)
    print(docstring.meta)


# Generated at 2022-06-23 17:18:42.701766
# Unit test for function parse
def test_parse():
    example_docstring = \
    """A single-line description.
    - List item 1
    - List item 2
    - List item 3
    :param arg1: Description of arg1
    :param arg2: Description of arg2
    :type arg2: str
    :param arg3: Description of arg3
    :param arg4: Description of arg4
    :returns: Description of return value
    :rtype: str
    :raises Exception: Description of exception
    :raises AssertionError: Description of exception
    """
    docstring = parse(example_docstring)

    assert isinstance(docstring.long_description, str)
    assert isinstance(docstring.meta, list)
    assert isinstance(docstring.short_description, str)

# Generated at 2022-06-23 17:18:50.205130
# Unit test for function parse
def test_parse():
    text = '''
    Short description

    Long description starts here.

    :keyword1:
    :keyword2 arg1 arg2:
    '''

    doc = parse(text)
    assert doc.short_description == 'Short description'
    assert doc.long_description == 'Long description starts here.'
    assert doc.meta == [
        DocstringMeta(args=['keyword1'], description=''),
        DocstringMeta(args=['keyword2', 'arg1', 'arg2'], description='')
    ]



# Generated at 2022-06-23 17:18:59.664956
# Unit test for function parse
def test_parse():
    doc1 = '''
        Short description.

        Long description.

        :param arg1: arg1 description
        :param arg2: arg2 description
        :param arg3: arg3 description
        :param arg4: arg4 description
        :raises:
        :returns:
    '''
    doc2 = '''
        Short description.

        Long description.

        :param arg1: arg1 description
        :param arg2: arg2 description
        :param arg3: arg3 description
        :param arg4: arg4 description
        :raises:
        :returns:
        '''

# Generated at 2022-06-23 17:19:11.751492
# Unit test for function parse
def test_parse():
    text = """
        test
        
        :param my_name: name of the person
        :param age: age of the person
        :param str address: address of the person

        :returns: list of persons
        :yields: list of persons

        :rtype: Person

        :raises ValidationError: when field is not valid
        :raises RuntimeError: when there is a runtime error

        :returns: object of a person
        """
    docsting = parse(text)
    # Check the description
    assert docsting.short_description == "test"
    assert docsting.long_description == "list of persons\n"
    assert docsting.blank_after_long_description == True
    assert docsting.blank_after_short_description == True

    # Check the docstring meta
   

# Generated at 2022-06-23 17:19:19.174484
# Unit test for function parse
def test_parse():
    text = """
    Short description
    
    Long description

    :param foo: Foo does something.
    :type foo: str
    :param bar: Bar does something.
    :default bar: 43
    :type bar: int
    :return: Returns nothing.
    :rtype: None
    :raises ZeroDivisionError: When you divide by zero.
    """
    doc = parse(text)
    assert doc.short_description == "Short description"
    assert doc.long_description == "Long description"
    assert len(doc.meta) == 4

    param, ret, raises = doc.meta[:3]
    assert param.__class__.__name__ == "DocstringParam"
    assert param.arg_name == "foo"
    assert param.type_name == "str"


# Generated at 2022-06-23 17:19:28.487358
# Unit test for function parse
def test_parse():
    assert parse("def foo()") == Docstring()

    assert parse("def foo():") == Docstring()
    assert parse("def foo():    ") == Docstring()

    assert parse("""def foo():
        """
                 ) == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[],
    )

    assert parse("def foo():\n\n   bar") == Docstring(
        short_description=None,
        long_description="bar",
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[],
    )


# Generated at 2022-06-23 17:19:37.739547
# Unit test for function parse
def test_parse():
    def test_func(a: int, b: str, c: int = 7, d: str = "none") -> str:
        """Some function.

        :param a: Arg A
        :type a: int

        :param b: Arg B
        :type b: str

        :param c: Arg C defaults to 7.
        :type c: int

        :param d: Arg D defaults to "none".
        :type d: str?

        :returns: the answer, which is 42.
        :rtype: int

        :raises ValueError: on bad values.
        :raises KeyError: on missing key.
        """
        pass

    result = parse(test_func.__doc__)

# Generated at 2022-06-23 17:19:43.115853
# Unit test for function parse
def test_parse():
    text = '''
    Returns a value.
    
    :param name: the name
    :type name: string
    :param value: the value
    :type value: int
    :returns: a string
    :raises SomeError: if there was an error
    
    '''

    d = parse(text)
    assert(d.short_description == "Returns a value.")
    assert(d.long_description == None)
    assert(d.blank_after_short_description == True)
    assert(d.blank_after_long_description == False)
    assert(len(d.meta) == 5)

# Generated at 2022-06-23 17:19:49.832647
# Unit test for function parse
def test_parse():
    desc = """This is a short description.

    This is a long description.
    """

    doc = parse(desc)
    assert doc.short_description == "This is a short description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.long_description == "This is a long description."


# Generated at 2022-06-23 17:19:58.344397
# Unit test for function parse
def test_parse():
    text = """This function does something.

:param int x: the x coordinate
:param int y: the y coordinate
:returns: point
:raises ValueError: if x > 10
:raises ValueError: if y > 10

And this is the rest of the docstring.
"""
    d = parse(text)
    assert d.short_description == "This function does something."
    assert d.long_description == "And this is the rest of the docstring."
    assert d.blank_after_short_description
    assert d.blank_after_long_description
    assert len(d.meta) == 4
    assert d.meta[0].args == ["param", "int", "x"]
    assert d.meta[0].description == "the x coordinate"

# Generated at 2022-06-23 17:20:09.580032
# Unit test for function parse
def test_parse():
    """Test function parse with quite a lot of test cases."""
    assert parse("") == Docstring()
    assert parse("   \n  \n \n") == Docstring()

    assert parse("short") == Docstring(short_description="short")
    assert parse("short\nlong") == Docstring(
        short_description="short",
        long_description="long",
        blank_after_short_description=False,
        blank_after_long_description=True,
    )
    assert parse("short\nlong\n\n") == Docstring(
        short_description="short",
        long_description="long",
        blank_after_short_description=False,
        blank_after_long_description=True,
    )

# Generated at 2022-06-23 17:20:19.134300
# Unit test for function parse
def test_parse():
    # Test meta-data
    test_docstring = """Summary line.

Description

:param arg1:
:param arg2:
:return:
:raises ValueError:
    When something fails.

"""
    d = parse(test_docstring)
    assert d.short_description == "Summary line."
    assert d.long_description == "Description"
    assert d.meta[0].key == "param"
    assert d.meta[0].arg_name == "arg1"
    assert d.meta[1].arg_name == "arg2"
    assert d.meta[2].key == "return"
    assert d.meta[3].key == "raises"
    assert d.meta[3].type_name == "ValueError"
    assert d.meta[3].description == "When something fails."

# Generated at 2022-06-23 17:20:24.292497
# Unit test for function parse
def test_parse():
    docstring = """one line summary.
    
    :param filename: path to the file
    :type filename: str
    :returns: file object
    :rtype: file object
    """

    parsed_docstring = parse(docstring)

# Generated at 2022-06-23 17:20:33.938049
# Unit test for function parse
def test_parse():
    docstring="""This is a test.
    b':\n    This is another test.'
    :param x: int, the value
    :param e: exception
    :param y: str, an optional one
    :raises: Exception
    :return: str
    :return: None
    """
    expected_return='This is a test.\n\n    b\':\n        This is another test.\'\n\n    :param x: int, the value\n    :param e: exception\n    :param y: str, an optional one\n    :raises: Exception\n    :return: str\n    :return: None'
    assert parse(docstring).__str__()==expected_return

# Generated at 2022-06-23 17:20:42.665851
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("foo") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
    )

    assert parse("foo\n\n") == Docstring(
        short_description="foo",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

    # Test with blank lines in the short description
    assert parse("foo\n\nbar") == Docstring(
        short_description="foo",
        long_description="bar",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )


# Generated at 2022-06-23 17:20:53.971669
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    assert parse("") == Docstring()

    text = """\
        This is the short description.

        This is the long description.

        :param foo: This is a parameter.
        :param bar: This is a parameter.
        :returns: Return value.
        :raises ValueError: If something bad happens.
        :raises TypeError: If something bad happens.
        """

    docstring = parse(text)
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description

    assert docstring.meta[0].arg_name == "foo"
    assert docstring.meta[0].type_name is None

# Generated at 2022-06-23 17:21:05.371634
# Unit test for function parse
def test_parse():
    test_docstring = """Finds the sum of all the multiples of 3 or 5 below 1000.

    :param int limit: The upper bound to sum until.
    :param int num1: The first multiplying number.
    :param int num2: The second multiplying number.
    :return: The sum of all multiples of ``num1`` and ``num2`` below ``limit``.
    :rtype: int
    """

    ds = parse(test_docstring)

    assert isinstance(ds.short_description, str)
    assert isinstance(ds.long_description, str)

    assert len(ds.meta) == 4
    assert ds.meta[0].key == "param"
    assert ds.meta[0].arg_name == "limit"

# Generated at 2022-06-23 17:21:16.405042
# Unit test for function parse
def test_parse():
    docstring = '''
    Short description.

    More detailed description of what this function does.
    And some random other stuff.

    :param param1: Description of the first parameter.
    :type param1: :class:`bool`

    :param param2: Description of the second parameter.
    :type param2: :class:`str`

    :returns: Description of the return value
    :rtype: :class:`str`
    '''

    result = parse(docstring)

    assert result.short_description == 'Short description.'
    assert result.long_description == 'More detailed description of what this function does. And some random other stuff.'
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False

# Generated at 2022-06-23 17:21:23.763259
# Unit test for function parse
def test_parse():
    doc = """\
        Short description.

        Long description.

        :param x: The first param.
        :type x: str
        :param y: The second param.
        :type y: int
        :returns: Nothing.
        :raises ValueError: If something bad happens.

        This is outside of the meta.
        """
    parsed = parse(doc)
    return parsed

if __name__ == "__main__":
    print(test_parse())

# Generated at 2022-06-23 17:21:35.036468
# Unit test for function parse
def test_parse():
    docstring = r"""This is a short description.

This is the long description. It should consist of multiple lines.

These lines
should be indented
to the same level.

:param str foo: This is a required parameter.
:param bar: This is an optional parameter.
    It has a long description
    that connects multiple lines.
:returns: The return value.
:raises TypeError: For some reason.
:rtype: int

With a blank line between description and meta information.

:param str baz: Another param.
:param quux: Another param.
:raises: Another exception.
    And another description.
"""


# Generated at 2022-06-23 17:21:44.016434
# Unit test for function parse
def test_parse():
    import pandas as pd
    import pandas.util.testing as tm
    
    # get docstring from pandas
    func = pd.DataFrame.equals
    doc = parse(inspect.getdoc(func))
    
    # set the expected docstring
    expected = Docstring()
    expected.short_description = "Test whether two objects contain the same elements.\n\n        The comparison uses :func:`np.array_equal` to compare the\n        `values`.\n        \n        NA/NaN values are treated as equal (including ``0 * NA``).\n        "
    expected.blank_after_short_description = True
    expected.blank_after_long_description = True
    expected.long_description = None

# Generated at 2022-06-23 17:21:55.401105
# Unit test for function parse
def test_parse():
    d = """
    Short description.

    Long description.
    
    :param param1: description1
    :type param1: int
    :param param2: description2
    :type param2: str
    :param param3: description3
    :type param3: str
    :returns: description4
    :raises type3: if x
    """
    doc = parse(d)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert len(doc.meta) == 4
    assert type(doc.meta[0]) == DocstringParam
    assert type(doc.meta[1]) == DocstringParam
    assert type(doc.meta[2]) == DocstringParam
    assert type(doc.meta[3]) == DocstringRaises

# Generated at 2022-06-23 17:22:06.628254
# Unit test for function parse
def test_parse():
    text = '''
    My first line
    My second line
    :param a: This is the a param
    :param b: This is a documentation for b
    :param c: This is a documentation for c
    '''
    parsed_docstring = parse(text)
    assert(len(parsed_docstring.meta) == 3)
    assert(parsed_docstring.meta[0].args == ['param', 'a'])
    assert(parsed_docstring.meta[0].description == 'This is the a param')
    assert(parsed_docstring.meta[1].args == ['param', 'b'])
    assert(parsed_docstring.meta[1].description == 'This is a documentation for b')

# Generated at 2022-06-23 17:22:17.589886
# Unit test for function parse
def test_parse():
    docstring = parse("""
    short description
    """)

    assert docstring.short_description == "short description"
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False

    docstring = parse("""
    short description

    blah blah blah

    blah blah blah
    """)

    assert docstring.short_description == "short description"
    assert docstring.long_description == "blah blah blah\n\nblah blah blah"
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

    docstring = parse("""
    short description

    blah blah blah
    blah blah blah
    """)

    assert docstring.short_description

# Generated at 2022-06-23 17:22:30.620339
# Unit test for function parse
def test_parse():
    my_docstring = "This is my docstring.\n\n:param x: This is a short description.\n:type x: int\n:raises ValueError: This is an exception.\n\nThis is the long description.\n\n"
    parsed = parse(my_docstring)

    assert parsed.short_description == 'This is my docstring.'
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == True
    assert parsed.long_description == 'This is the long description.'
    assert parsed.meta[0].args == ['param', 'x']
    assert parsed.meta[0].description == 'This is a short description.'
    assert parsed.meta[0].arg_name == 'x'

# Generated at 2022-06-23 17:22:34.117405
# Unit test for function parse
def test_parse():
    docstring = "hello\n    world"
    ret = parse(docstring)
    assert ret.short_description == "hello"
    assert ret.long_description == "world"


# Generated at 2022-06-23 17:22:41.235629
# Unit test for function parse
def test_parse():
    import json

    docstring = """\
    This is a short description. Followed by a lot of text.

    :param message: The message to log
    :type message: str

    :param level: The log level.
    :type level: int

    :raises RuntimeError: On error
    :raise ValueError: On error

    :return: Some value
    :rtype: str

    :yields: A value
    :ytype: str
    """

# Generated at 2022-06-23 17:22:49.468188
# Unit test for function parse
def test_parse():
    doc_string = 'short desc\long desc.\n:type name a: parameter a\n:raises ValueError: if a == 0'
    docstring = parse(doc_string)

    assert docstring.short_description == 'short desc'
    assert docstring.long_description == 'long desc.'
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert isinstance(docstring.meta[0], DocstringMeta)
    assert docstring.meta[0].args == []
    assert docstring.meta[0].description == 'short desc'
    assert isinstance(docstring.meta[1], DocstringMeta)
    assert docstring.meta[1].args == []

# Generated at 2022-06-23 17:22:57.538995
# Unit test for function parse
def test_parse():
    example = """
    Short description.

    Long description.

    :param my_arg: This is my argument.
    :type my_arg: int
    :returns int: the result of the computation.
    """
    d = parse(example)
    assert d.short_description == "Short description."
    assert d.long_description == "Long description."
    assert d.meta[0].arg_name == "my_arg"
    assert d.meta[0].type_name == "int"
    assert d.meta[1].type_name == "int"


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:23:07.827692
# Unit test for function parse
def test_parse():
    docstring = parse('''
    Compute the mean value of a given column

    Parameters
    ----------
    column : str
        The column we want to average
    df : DataFrame
        The dataframe to use
    ''')
    assert docstring.short_description == 'Compute the mean value of a given column'
    assert docstring.blank_after_short_description
    assert not docstring.long_description
    assert not docstring.blank_after_long_description
    assert docstring.meta[0] == DocstringParam(['column', 'str'], 'The column we want to average', 'column', 'str', False, None)
    assert docstring.meta[1] == DocstringParam(['df', 'DataFrame'], 'The dataframe to use', 'df', 'DataFrame', False, None)

    doc

# Generated at 2022-06-23 17:23:18.311476
# Unit test for function parse
def test_parse():
    text = """
    Finds and counts the number of times a substring occurs in a string.

    :param str text: The string to search.
    :param str sub: The substring to search for.
    :param bool case_sensitive: Whether to consider the case of
        the strings when matching.
    """
    docstring = parse(text)
    assert docstring.short_description == "Finds and counts the number of times a substring occurs in a string."
    assert docstring.blank_after_short_description == False
    assert docstring.long_description == None
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].arg_name == "text"
    assert docstring.meta[0].type_name == "str"
    assert docstring.meta[0].is_optional == False

# Generated at 2022-06-23 17:23:30.189429
# Unit test for function parse
def test_parse():
    assert parse("I am a function") == Docstring(
        short_description="I am a function",
        long_description=None,
        blank_after_short_description=None,
        blank_after_long_description=None,
        meta=[],
    )

    assert parse("I am a function\n\nAnd I am its description") == Docstring(
        short_description="I am a function",
        long_description="And I am its description",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-23 17:23:40.696472
# Unit test for function parse

# Generated at 2022-06-23 17:23:46.381040
# Unit test for function parse
def test_parse():
    # TODO: Need a good unit-test
    docstring = """
    My short description.

    My longer description.
    """
    doc = parse(docstring)
    assert doc.short_description == "My short description."
    assert doc.long_description == "My longer description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False

# Generated at 2022-06-23 17:23:48.876630
# Unit test for function parse
def test_parse():
    text = """
    My function does one thing.

    It does that one thing very well.
    """
    print(parse(text))



# Generated at 2022-06-23 17:24:00.224512
# Unit test for function parse
def test_parse():
    doc = inspect.cleandoc(parse.__doc__)
    assert parse(doc) == (
        Docstring(
            short_description="Parse the ReST-style docstring into its components.",
            blank_after_short_description=True,
            blank_after_long_description=True,
            long_description=":returns: parsed docstring",
            meta=[
                DocstringMeta(
                    args=["returns"],
                    description="parsed docstring",
                )
            ],
        )
    )
    assert parse("") == Docstring()


# Generated at 2022-06-23 17:24:11.472027
# Unit test for function parse
def test_parse():
    s = """
    This is a short description.

    This is a longer
    description. It may have
    several lines.
    :param x: A parameter named x
    :param y: A parameter named y
    :type x: int
    :type y: int
    :returns: The sum of x and y
    :rtype: int
    """
    doc = parse(s)

# Generated at 2022-06-23 17:24:18.737646
# Unit test for function parse
def test_parse():
    docstring = """
    Parse the ReST-style docstring into its components.

    :param i: the first integer
    :type i: int
    :param j: the second integer
    :type j: int
    :returns: the sum of the two integers
    :rtype: int
    :raises TypeError: if i or j are not integers
    """
    parsed = parse(docstring)
    print(parsed.short_description)
    print(parsed.long_description)
    print(parsed.meta[0].arg_name)
    print(parsed.meta[1].arg_name)
    print(parsed.meta[2].return_type)
    print(parsed.meta[3].exception_type)


# Generated at 2022-06-23 17:24:28.015664
# Unit test for function parse
def test_parse():
    from textwrap import dedent
    from . import common
    ds = dedent('''
    This is the short description of a function.

    This is the long description of a function.

    :param arg_one: one
    :type arg_one: int
    :param arg_two: two
    :type arg_two: str
    :param arg_three: three
    :type arg_three: bool
    :returns: Yes

    :raises ValueError: is raised if things go wrong.
    :raises KeyError: is raised if oops
    ''')

# Generated at 2022-06-23 17:24:37.624117
# Unit test for function parse
def test_parse():
    text = '''
    Short description.

    :param a: Foo bar.
    :param b: Baz bang.
    :type a: int
    :type b: int, optional
    :returns: The answer to life and universe.
    :rtype: int
    '''

    docstring = parse(text)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == None

# Generated at 2022-06-23 17:24:47.734170
# Unit test for function parse
def test_parse():
    doc = parse("""
This is a test docstring.

:param x: This is a parameter.
:param y: This one is optional.
:param z: This one has a default value.
:param foo: This one is a foo.
""")
    assert doc.short_description == 'This is a test docstring.'
    assert doc.long_description == 'This is a test docstring.'
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is True
    assert len(doc.meta) == 4
    assert doc.meta[0].arg_name == 'x'
    assert doc.meta[0].description == 'This is a parameter.'
    assert doc.meta[1].arg_name == 'y'

# Generated at 2022-06-23 17:24:57.834893
# Unit test for function parse
def test_parse():
    # Sample docstring
    doc = """
    This is a sample docstring.

    The general format for docstrings follows the parameter below.

    Parameters
    ----------
    arg1 : str
        The first argument. It can be an optional argument,
        depending on where you put the question mark. arg1? : str
        defaults to "hello".

    arg2
        The second argument.

    arg3 : int, optional
        The third argument.

    Returns
    -------
    bool
        True if the function works.

    Raises
    ------
    Exception
        If anything goes wrong.

    See Also
    --------
    This is where you put references to related functions.
    """

    # Expected parsed docstring

# Generated at 2022-06-23 17:25:09.187359
# Unit test for function parse
def test_parse():
    docstring = """
    Test for parse function.

    Parameters
    ----------
    text: str
        Input docstring

    Returns
    -------
    Docstring
        Parsed docstring
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Test for parse function."
    assert parsed.blank_after_short_description == False
    assert parsed.long_description == (
        "Parameters\n----------\ntext: str\n    Input docstring\n\nReturns\n"
        "-------\nDocstring\n    Parsed docstring"
    )
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].args == ["text", "str"]
    assert parsed.meta[0].description == "Input docstring"

# Generated at 2022-06-23 17:25:16.309839
# Unit test for function parse
def test_parse():
    docstr = parse.__doc__
    to_compare = Docstring(
        short_description="Parse the ReST-style docstring into its components.",
        long_description=(
            ":returns: parsed docstring\n"
        ),
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[
            DocstringMeta(args=['returns'], description="parsed docstring")
        ]
    )
    assert parse(docstr) == to_compare


# Generated at 2022-06-23 17:25:27.553641
# Unit test for function parse
def test_parse():
    """Unit test for function parse
    """
    from .dummy import DummyClass
    docstr = DummyClass.__init__.__doc__
    obj = parse(docstr)
    # print(obj.long_description)
    assert obj.long_description == \
        """This is a long description for the constructor. It goes over multiple
        lines.

        Parameters
        ----------
        a : int
            This is a parameter called a.
        b : bool
            This is a parameter called b.
        c : str
            This is a parameter called c.

        Returns
        -------
        bool
            True if everything worked.

        Raises
        ------
        Exception
            If something went wrong."""


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:25:34.686572
# Unit test for function parse
def test_parse():
    def do_test(s,sres):
        res = parse(s)
        assert sres == str(res)

    do_test("""
    test
    ""","""short_description: test
long_description: None
blank_after_short_description: False
blank_after_long_description: False
meta: []
""")
    do_test("""
    test
    test2
    ""","""short_description: test
long_description: test2
blank_after_short_description: False
blank_after_long_description: False
meta: []
""")

# Generated at 2022-06-23 17:25:41.909497
# Unit test for function parse
def test_parse():
    text = """
    First line of docstring.

    Some additional information.

    :param arg1: The first argument.
    :param arg2 int: The second argument.
    :returns: None
    :raises ValueError: If something bad happens.
    :raises: UnicodeError
    """
    result = parse(text)
    assert result.short_description == "First line of docstring."
    assert result.long_description == "Some additional information."
    assert result.blank_after_short_description
    assert result.blank_after_long_description
    assert len(result.meta) == 4
    assert result.meta[0].key == "param"
    assert result.meta[0].arg_name == "arg1"
    assert result.meta[0].type_name is None

# Generated at 2022-06-23 17:25:52.904236
# Unit test for function parse
def test_parse():
    source = """
    Function title."""
    expected = """
    Function title."""

    assert parse(source).short_description == expected

    source = """
    Function title.


    """

    expected = """
    Function title.


    """

    assert parse(source).short_description == expected

    source = """
    Function title.

    Long description.
    """

    expected = """
    Function title.

    Long description.
    """

    assert parse(source).short_description == expected

    source = """
    Function title.


    Long description.
    """

    expected = """
    Function title.


    Long description.
    """

    assert parse(source).short_description == expected

    source = """
    Function title.

    Long description."""


# Generated at 2022-06-23 17:26:03.995906
# Unit test for function parse
def test_parse():
    def target():
        """A test parse.

        :param a: b
        :param x: y
        :param c: d
        :returns: returns
        """


# Generated at 2022-06-23 17:26:13.916211
# Unit test for function parse
def test_parse():
    text = (
        'foo(x: int, y: int) -> int\n'
        '\n'
        'Short description.\n'
        '\n'
        ':param x: First number.\n'
        ':type x: int\n'
        ':param y: Second number.\n'
        ':type y: int\n'
        ':returns: Sum of ``x`` and ``y``.\n'
        ':rtype: int\n'
    )

    docstring = parse(text)

# Generated at 2022-06-23 17:26:18.562180
# Unit test for function parse

# Generated at 2022-06-23 17:26:27.594162
# Unit test for function parse
def test_parse():
    docstring = """Single line description.

    Multiline description.

    :type foo: str
    :rtype: str

    """
    doc = parse(docstring)
    assert doc.short_description == "Single line description."
    assert doc.long_description == "Multiline description."
    assert len(doc.meta) == 2
    assert doc.meta[0].description == "Multiline description."
    assert doc.meta[0].arg_name == "foo"
    assert doc.meta[0].type_name == "str"
    assert doc.meta[1].is_generator is False