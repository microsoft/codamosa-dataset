

# Generated at 2022-06-23 17:16:34.026033
# Unit test for function parse
def test_parse():
    """
    >>> test_parse()
    :param name: Parameter name.
    :type name: str
    :keyword age: Parameter age. Defaults to 0.
    :type age: int
    :returns: Something.
    :rtype: str
    :raises ValueError: If something goes wrong.
    :raises TypeError: If something goes wrong.
    :yields: Something.
    :ytype: str
    :yields: Something.
    :ytype: str
    """

# Generated at 2022-06-23 17:16:41.770152
# Unit test for function parse
def test_parse():
    docstring_str = """\
    :return: a number
    :rtype: int
    """
    docstring = parse(docstring_str)
    assert len(docstring.meta) == 2
    for meta in docstring.meta:
        assert meta.description == 'a number'
        assert meta.args[0] == 'return' or meta.args[0] == 'rtype'
        if meta.args[0] == 'return':
            assert meta.args[1] is None
        else:
            assert meta.args[1] == 'int'



# Generated at 2022-06-23 17:16:44.165667
# Unit test for function parse
def test_parse():
    docstring = '''\
    Short description.

    Longer description.

    :returns: nothing.
    :rtype: None
    '''
    ret = parse(docstring)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:16:48.329611
# Unit test for function parse
def test_parse():
    s = '''
    ReST-style docstring parsing.

    This module contains a single function, :func:`parse`.
    '''
    print(parse(s))

test_parse()

# Generated at 2022-06-23 17:17:00.228591
# Unit test for function parse

# Generated at 2022-06-23 17:17:11.992095
# Unit test for function parse
def test_parse():
    print('test function: test_parse')
    print('-----------------------------')
    def f():
        """
        Short description.

        The first line is short description. The next lines until
        a blank line are the long description. The rest is parsed as
        meta-information.

        Meta-information is a set of key-value pairs, separated by a
        blank line.

        :param arg1: the first argument
        :param arg2: another argument
        :keyword kw1: the first keyword
            which can span multiple lines.
        :keyword kw2 kw3 kw4: several keywords
        :returns: the return value, which can be a
            multiline description.
        :raises SomeError: if an error occurs
        """


# Generated at 2022-06-23 17:17:14.652457
# Unit test for function parse
def test_parse():
    print('test parse')
    s = """\
    Short description.

    Long description.

    :param int param1: Parameter 1
    :param str param2: Parameter 2
    :returns: None
    :raises ValueError:
    """
    print(parse(s))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:17:26.740304
# Unit test for function parse
def test_parse():
    s = """
    This is a sample docstring.

    One or two lines of description.

    :param foo: parameter foo
    :param bar: parameter bar
    :returns: return value
    :raises IOError: if there is an IO error
    """
    d = parse(s)
    assert d.short_description == "This is a sample docstring."
    assert d.long_description == ("One or two lines of description.")
    assert d.meta[0].args == ("param", "foo")
    assert d.meta[0].description == "parameter foo"
    assert d.meta[0].arg_name is None
    assert d.meta[0].type_name is None
    assert d.meta[0].is_optional is None
    assert d.meta[0].default is None

# Generated at 2022-06-23 17:17:36.971847
# Unit test for function parse
def test_parse():
    assert parse('function():\n  """This is a docstring."""') == Docstring(
        short_description='function',
        blank_after_short_description=False,
        long_description='This is a docstring.',
        blank_after_long_description=False,
        meta=[],
    )
    assert parse('function():\n  """This is a docstring.\n\n  """') == Docstring(
        short_description='function',
        blank_after_short_description=False,
        long_description='This is a docstring.',
        blank_after_long_description=True,
        meta=[],
    )

# Generated at 2022-06-23 17:17:38.442564
# Unit test for function parse
def test_parse():
    """Test parse."""
    parse("")

# Generated at 2022-06-23 17:17:47.937609
# Unit test for function parse
def test_parse():
    doc = parse("")
    assert doc.__dict__ == {
        "short_description": None,
        "long_description": None,
        "blank_after_short_description": False,
        "blank_after_long_description": False,
        "meta": [],
    }
    doc = parse("Message body:\n")
    assert doc.__dict__ == {
        "short_description": "Message body:",
        "long_description": None,
        "blank_after_short_description": False,
        "blank_after_long_description": False,
        "meta": [],
    }
    doc = parse("Message body:\n\n")

# Generated at 2022-06-23 17:17:58.074662
# Unit test for function parse
def test_parse():
    # Added a test for this function
    # test the text of null
    text = None
    ret = parse(text)
    assert ret.short_description == None
    assert ret.long_description == None
    assert ret.meta == []

    # test the text of docstring
    text = inspect.cleandoc("This is short description.")
    ret = parse(text)
    assert ret.short_description == "This is short description."
    assert ret.long_description == None
    assert ret.meta == []

    text = inspect.cleandoc("This is short description. \nThis is long description.\n")
    ret = parse(text)
    assert ret.short_description == "This is short description."
    assert ret.long_description == "This is long description."
    assert ret.meta == []


# Generated at 2022-06-23 17:18:08.889588
# Unit test for function parse
def test_parse():
    str_parse = """
        Short summary.

        More details.

        :param str arg: arg description
        :param int arg2: arg2 description
        :param type arg3: defaults to 1.
        :type arg4: int
        :type arg5: int, defaults to 2.
        :returns int: return description
        :returns: return description
        :raises ValueError: raise description
        :raises: raise description
        :yield int: yield description
        :yields: yield description
        :yields int: yield description
        :example:
            print(1)
    """
    result = parse(str_parse)

    assert result.short_description == "Short summary."
    assert result.long_description == "More details."
    assert result.blank_after_short_description is False

# Generated at 2022-06-23 17:18:16.024263
# Unit test for function parse
def test_parse():
    doc = """Summary line.

Extended description.

:param str arg1: The first argument.
:param str arg2: The second argument.
:returns: Description of return value.
:rtype: bool
"""
    ret = parse(doc)
    assert ret.short_description == "Summary line."
    assert ret.long_description == "Extended description."
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == False
    assert len(ret.meta) == 3
    assert ret.meta[0].arg_name == "arg1"
    assert ret.meta[0].type_name == "str"
    assert ret.meta[0].description == "The first argument."
    assert ret.meta[1].arg_name == "arg2"

# Generated at 2022-06-23 17:18:21.708233
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc(
        """
    This is a test docstring.

    :param foo: bar
    :type foo: str
    """
    )
    ret = parse(docstring)
    assert not ret.short_description.endswith("\n")
    assert ret.short_description == "This is a test docstring."
    assert ret.blank_after_short_description
    assert ret.long_description is None
    assert ret.blank_after_long_description
    assert len(ret.meta) == 1



# Generated at 2022-06-23 17:18:32.411617
# Unit test for function parse
def test_parse():
    doc = """Short description.
    Long description.
    """

    assert parse(doc) == Docstring(
        short_description="Short description.",
        long_description="Long description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert parse("") == Docstring()

    doc = """Short description.
    Long description.

    :Keyword Type: Description.
    :Second keyword: Description.
    """


# Generated at 2022-06-23 17:18:39.415594
# Unit test for function parse
def test_parse():
    docstr = parse('''
        This is a test docstring.

            :param arg1: this is arg1
            :type arg1: int
            :param arg2: this is arg2
            :type arg2: str
            :returns: None
            :raises KeyError: raises an exception
    ''')
    assert docstr.short_description == 'This is a test docstring.'

# Generated at 2022-06-23 17:18:48.522611
# Unit test for function parse

# Generated at 2022-06-23 17:18:54.279535
# Unit test for function parse
def test_parse():
    ret = parse('Test Declaration\n:param int a: param a\n:raises TypeError: raises test\n:returns str: returns test\n')
    assert ret.short_description == 'Test Declaration'
    assert len(ret.meta) == 3
    assert type(ret.meta[0]) == DocstringParam
    assert type(ret.meta[1]) == DocstringRaises
    assert type(ret.meta[2]) == DocstringReturns

# Generated at 2022-06-23 17:19:01.237277
# Unit test for function parse
def test_parse():
    docstring = """
    :param str arg1: This is a first argument.
    :param int arg2: This is a second argument.
    """
    assert parse(docstring) == Docstring(
        short_description='',
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[
            DocstringMeta(
                DocstringMeta(
                    args=['param', 'str', 'arg1'],
                    description='This is a first argument.',
                ),
                DocstringMeta(
                    args=['param', 'int', 'arg2'],
                    description='This is a second argument.',
                ),
            ),
        ],
    )



# Generated at 2022-06-23 17:19:12.510410
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    docstring = parse(
        """\
        Short.

        Long.
        """
    )
    assert docstring.short_description == "Short."
    assert docstring.long_description == "Long."
    assert not docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.meta == []

    docstring = parse(
        """\
        Short.

        :param arg_name:
        """
    )
    assert len(docstring.meta) == 1
    param = docstring.meta[0]
    assert param.args == ["param", "arg_name"]
    assert param.description == ""


# Generated at 2022-06-23 17:19:19.546046
# Unit test for function parse
def test_parse():
    doc = parse("""\
    Some test docstring.

    This is the long description.

    :param arg: A test argument
    :type arg: str
    :param opt: A test optional argument
    :type opt: dict, defaults to {}
    :returns: The return value
    :rtype: bool
    :raises ValueError: A test exception
    """)
    assert str(doc) == """\
    Some test docstring.

    This is the long description.
    :param arg: A test argument
    :type arg: str
    :param opt: A test optional argument
    :type opt: dict, defaults to {}
    :returns: The return value
    :rtype: bool
    :raises ValueError: A test exception
    """


if __name__ == "__main__":
    doc = parse

# Generated at 2022-06-23 17:19:28.651190
# Unit test for function parse
def test_parse():
    """
    Testing for the parse function.
    """
    # Testing if the whole thing works
    test_text = """
    This is a test
    :param str a: See test_below
    :param int b: See test_below
    :defaults to int c: See test_below
    :returns str: See test_below
    :raises TypeError: See test_below
    """
    test_result = parse(test_text)

    expected = Docstring()
    expected.short_description = "This is a test"
    expected.blank_after_short_description = True
    expected.blank_after_long_description = True
    expected.long_description = None

# Generated at 2022-06-23 17:19:37.904763
# Unit test for function parse

# Generated at 2022-06-23 17:19:44.612730
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    doc = """
    First line.

    Second line.
    """
    res = parse(doc)
    assert isinstance(res, Docstring)
    assert res.short_description == "First line."
    assert res.long_description == "Second line."
    assert len(res.meta) == 0
    #
    doc = """
    First line.

     Second line.

    :param foo: Foo.
    :type foo: Bar
    """
    res = parse(doc)
    assert isinstance(res, Docstring)
    assert res.short_description == "First line."
    assert res.long_description == "Second line."
    assert len(res.meta) == 1
    assert isinstance(res.meta[0], DocstringParam)

# Generated at 2022-06-23 17:19:55.737219
# Unit test for function parse
def test_parse():
    # Test empty docstring
    assert parse("") == Docstring([])

    # Test short description
    assert parse("Docstring for this function.") == Docstring(
        short_description="Docstring for this function."
    )

    # Test short description with newlines
    assert parse("Docstring for\nthis function.") == Docstring(
        short_description="Docstring for this function."
    )

    # Test short description with newlines, indented
    assert parse("  Docstring for\n  this function.") == Docstring(
        short_description="Docstring for this function."
    )

    # Test docstring only
    to_parse = """
    Parse the ReST-style docstring into its components.

      :returns: parsed docstring
    """

# Generated at 2022-06-23 17:20:07.117366
# Unit test for function parse
def test_parse():
    text = """Summary line.

This is a multiline description.  The second line is indented to
demonstrate that fact.  This description can contain any amount of
text.  If it does, the first sentence ends when the first period
is encountered.

:param int a: This is parameter a's description.  It can contain as
    much text as it needs to.

    The next paragraph is indented to show that it's a continuation
    of this one.  It can contain as many paragraphs as necessary.
    The first sentence ends when the first period is encountered.

:param str b: This is parameter b.  It has a single line description.

:returns int: This is the return value.

:raises ValueError: On invalid input.
"""
    docstring = parse(text)
    assert docstring
    assert docstring.short

# Generated at 2022-06-23 17:20:17.233473
# Unit test for function parse
def test_parse():
    """Test parsing of ReST-style docstrings."""

    def example_func(a, b=3, c=5):
        """A ReST-style docstring.

        :param a: first parameter
        :type a: int
        :param b: second parameter, optional
        :type b: float
        :param c:

          - third parameter, optional
          - with a multiline description

        :type c: str
        :returns: sum of a, b, c
        :rtype: float

        More details here.
        """
        pass

    ds = parse(example_func.__doc__)
    assert ds.short_description == "A ReST-style docstring."
    assert ds.long_description == (
        "More details here."
    )
    assert ds.blank_after_

# Generated at 2022-06-23 17:20:28.077431
# Unit test for function parse
def test_parse():
    """unit test for parse()"""
    docstring = """
    This function adds two numbers.

    :param num_one: first number
    :param num_two: second number
    :type num_one: number
    :type num_two: number
    :returns: sum of arguments
    :rtype: number

    """
    result = parse(docstring)

# Generated at 2022-06-23 17:20:38.514889
# Unit test for function parse
def test_parse():
    """Quick smoke test for parse."""
    doc_obj = parse("""
    hello, world

    :param foo:
    :param str bar:
    :param baz
    :param bool qux: bool
    :param bool quux?: bool
    :param bool quuux?: bool, defaults to True.
    :param bool corge?: bool, defaults to False.
    :param bool grault:
    :param bool garply:
    :param bool waldo:
    :yields:
    :raises:
    """)
    assert doc_obj.short_description == "hello, world"

    assert doc_obj.meta[0] == DocstringParam(
        args=["param", "foo"], description=""
    )

# Generated at 2022-06-23 17:20:42.672243
# Unit test for function parse
def test_parse():
    text = """Summary line.
    Extended description of function.

    :param foo: Description of `foo` goes here.
    :type foo: int

    :param bar: Description of `bar` goes here.
    :type bar: str
    :raises ValueError: For invalid values of `bar`.

    :returns: Description of return value.
    :rtype: :class:`shapely.geometry.Point`

    :raises SomeException: If something bad happens.

    """
    doc = parse(text)
    assert doc.short_description == "Summary line."
    assert doc.long_description == """Extended description of function.

"""
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 4

# Generated at 2022-06-23 17:20:47.815711
# Unit test for function parse
def test_parse():
    docstring = parse("""
    Return the sum of a and b.

    :param a: the first operand
    :param b: the second operand
    :type a: int
    :type b: int
    :returns: the sum
    :rtype: int
    """)
    docstring.meta[0].as_rst(name='a')
    docstring.meta[1].as_rst(name='b')
    docstring.meta[2].as_rst(name='a')
    docstring.meta[3].as_rst(name='b')
    docstring.meta[4].as_rst(name='returns')
    docstring.meta[5].as_rst(name='rtype')

# Generated at 2022-06-23 17:20:53.013398
# Unit test for function parse
def test_parse():
    text = """
    "{text}"
    """
    result = parse(text())
    expected = Docstring(
        short_description=r'\"{text}\"',
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    assert result == expected



# Generated at 2022-06-23 17:21:00.694152
# Unit test for function parse
def test_parse():
    res = parse(inspect.cleandoc(
        """
        Short description.

        Long description.

        :in_arg_1: in arg 1
        :in_arg_2 str: in arg 2
        :out_arg_1: out arg 1
        :out_arg_2 str: out arg 2
        :raises ValueError: raises ValueError
        :returns: returns
        :returns str: returns str
        :yields: yields
        :yields str: yields str        
    """))
    assert res

# Generated at 2022-06-23 17:21:12.734580
# Unit test for function parse
def test_parse():
    text = '''
        Sum two numbers.

        :param a: number to sum.
        :param b: second number to sum.
        :raises TypeError: if not all arguments are numbers.
        :returns: the sum of the given numbers.
        :rtype: numbers.Integral

        >>> print(add(1, 2))
        3
    '''

# Generated at 2022-06-23 17:21:23.297847
# Unit test for function parse
def test_parse():
    docstring = parse.__doc__
    assert isinstance(docstring, Docstring)
    assert docstring.short_description == "Parse the ReST-style docstring into its components."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.long_description == ":returns: parsed docstring"
    assert isinstance(docstring.meta[0], DocstringReturns)
    assert docstring.meta[0].args == ["returns"]
    assert docstring.meta[0].description == ": parsed docstring"
    assert not docstring.meta[0].type_name
    assert not docstring.meta[0].is_generator

# Generated at 2022-06-23 17:21:29.750880
# Unit test for function parse
def test_parse():
    # Test without args
    test = parse("")
    assert test.short_description is None
    assert test.blank_after_short_description is False
    assert test.long_description is None
    assert test.blank_after_long_description is False
    assert test.meta == []

    # Test short description with no long description
    test = parse("Short description")
    assert test.short_description == "Short description"
    assert test.blank_after_short_description is False
    assert test.long_description is None
    assert test.blank_after_long_description is False
    assert test.meta == []

    # Test long description with no short description
    test = parse("\nLong description")
    assert test.short_description is None
    assert test.blank_after_short_description is False
    assert test.long_description

# Generated at 2022-06-23 17:21:41.112656
# Unit test for function parse
def test_parse():
    docstring = '''
    Short description

    Long description

    :param arg1: description 1
    :param arg2: description 2
        continued
    :type arg2: bla
    :type arg3:
    :returns: nothing
    :raises Exception: whetever
        continued
    :raises Exception2:
        continued
    '''
    parsed: Docstring = parse(docstring)
    assert parsed.short_description == "Short description"
    assert parsed.long_description == "Long description"
    assert len(parsed.meta) == 6
    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].description == "description 1"
    assert parsed.meta[1].args == ["param", "arg2"]

# Generated at 2022-06-23 17:21:42.238239
# Unit test for function parse
def test_parse():
    from .test import parse_test
    parse_test(parse)

# Generated at 2022-06-23 17:21:54.288376
# Unit test for function parse
def test_parse():
    """Unit tests for function parse."""
    from .tests.utils import (
        PARAMS_TEMPLATE,
        RAISES_TEMPLATE,
        RETURNS_TEMPLATE,
        YIELDS_TEMPLATE,
    )

    def test_ok(text: str, as_dict: T.Optional[dict] = None, **kwargs: T.Any):
        """Test when the text is parsed correctly."""
        if as_dict is None:
            as_dict = {}
        as_dict.update(kwargs)
        actual = parse(text)
        assert actual.as_dict() == as_dict, (text, as_dict, actual.as_dict())

    test_ok("Hello world")
    test_ok("Hello world\n")

# Generated at 2022-06-23 17:21:59.309437
# Unit test for function parse
def test_parse():

    lines = """
        This is a short description.
    
        This is a long description.
        It spans multiple lines.
        It can also be blank.
    
        :param foo:
        :param bar: qsnx yxz
        :returns:
    
        """

    print(parse(lines))


# Generated at 2022-06-23 17:22:05.539124
# Unit test for function parse
def test_parse():
    ds = parse(
        """\
        Short description.

        Long description.

            The long description can span many lines.
        """
    )
    assert ds.short_description == "Short description."
    assert ds.long_description == "Long description.\n\nThe long description can span many lines."
    assert ds.blank_after_short_description
    assert ds.blank_after_long_description
    assert not ds.meta


# Generated at 2022-06-23 17:22:16.377638
# Unit test for function parse
def test_parse():
    text = """
    parse()

    :param  a: int
    :param b: str
    :param c: bool
    :returns: dict
    :raises: ValueError, "something went wrong"
    :raises: TypeError
    :yields: list
    """
    doc = parse(text)
    assert doc.short_description == "parse()"
    assert doc.long_description is None
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description

# Generated at 2022-06-23 17:22:16.824015
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-23 17:22:24.690100
# Unit test for function parse

# Generated at 2022-06-23 17:22:35.752687
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    assert parse('Foobar.') == Docstring(
        short_description='Foobar.', long_description=None, meta=[]
    )
    assert parse('Foobar.\n') == Docstring(
        short_description='Foobar.',
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse('Foobar.\n\n') == Docstring(
        short_description='Foobar.',
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[],
    )


# Generated at 2022-06-23 17:22:42.370236
# Unit test for function parse
def test_parse():
    docstring = parse(inspect.getdoc(parse))
    assert docstring.short_description == "Parse the ReST-style docstring into its components."
    assert docstring.blank_after_short_description == False
    assert docstring.long_description == "Returns:\n  parsed docstring"
    assert docstring.blank_after_long_description == True

    assert len(docstring.meta) == 0



# Generated at 2022-06-23 17:22:50.362441
# Unit test for function parse
def test_parse():
    """Test function parse"""
    docstring = "Test function parse\n"
    docstring += "\n"
    docstring += "If this function is removed, the unit tests\n"
    docstring += "will fail."
    docstring += "\n"
    docstring += ":param str test_str1: A test string.\n"
    docstring += ":param str test_str2: Another test string.\n"
    docstring += ":returns str: A test string."
    parsed = parse(docstring)
    assert parsed.short_description == "Test function parse"
    assert parsed.long_description == (
        "If this function is removed, the unit tests\n"
        "will fail."
    )
    assert parsed.blank_after_short_description
    assert not parsed.blank_after_long_

# Generated at 2022-06-23 17:22:59.307295
# Unit test for function parse
def test_parse():
    from .common import Docstring, DocstringMeta, DocstringParam, DocstringRaises

    return parse(
        """
    this is the short description of the function.

    this is the long description of the function.
    it can span multiple paragraphs.

    :param foo: This is first argument docstring.
    :param bar: This is second argument docstring.
    :returns: This is the return value docstring.
    :raises ValueError: This is a ValueError exception.
    """
    )


# Generated at 2022-06-23 17:23:09.316871
# Unit test for function parse
def test_parse():
    from .common import DocstringParam
    from .conftest import T
    from .formats.numpy import parse as numpy_parse

    text = """
    A numpy docstring.

    Allows for different param and return types.

    Parameters
    ----------
    a : int
        The first number to add.
    b : int
        The second number to add.

    Returns
    -------
    int
        The sum of `a` and `b`.

    Raises
    ------
    ValueError
        If the sum of `a` and `b` is less than zero.

    See Also
    --------
    :func:`subtract` - Subtract two numbers.
    """

    # check parse

# Generated at 2022-06-23 17:23:16.257201
# Unit test for function parse
def test_parse():
    test_string_1="""
    This is a test string.

    This is the long description.
    """
    split_test_string_1=Docstring(["This is a test string."],[],["This is the long description."])
    assert(split_test_string_1 == Docstring(short_description="This is a test string.",
                                            long_description="This is the long description."))
    assert(split_test_string_1 == parse(test_string_1))
    assert(split_test_string_1 == split_test_string_1)
    assert(split_test_string_1 != test_string_1)

# Generated at 2022-06-23 17:23:23.952318
# Unit test for function parse
def test_parse():
    docstring = '''
    Short line.
    More short lines.

    Longer paragraph here.

    :param x: Parameter x.
    :type x: int
    :param y: Parameter y.
    :type y: str
    :param z: Parameter z.
    :type z: float
    :returns: Something.
    :rtype: int
    :raises: TypeError
    '''
    ds = parse(docstring)
    assert ds.short_description == 'Short line.'
    assert ds.long_description == 'More short lines.\n\nLonger paragraph here.\n'
    assert ds.blank_after_short_description
    assert not ds.blank_after_long_description
    
    meta_list = ds.meta

# Generated at 2022-06-23 17:23:34.369384
# Unit test for function parse
def test_parse():
    """Test parse()."""
    test_inputs = (
        """
        Short description.

        Long description.
        """,
        """
        Short description.

        Long description.


        :param x: Description of x.
        :type x: str
        :param y: Description of y.
        :type y: int
        """,
        """
        Short description.

        Long description.

        .. code-block:: python

            >>> import sys
            >>> sys.exit(1)

        :param x: Description of x.
        :type x: str
        :param y: Description of y.
        :type y: int
        :returns: Description of return value.
        """,
    )

# Generated at 2022-06-23 17:23:45.671236
# Unit test for function parse
def test_parse():
    text = '''
    Short description.

    Long description.
    '''

    ret = parse(text)
    assert ret.short_description == "Short description."
    assert ret.long_description == "Long description."
    assert ret.blank_after_short_description is True
    assert ret.blank_after_long_description is True
    assert len(ret.meta) == 0

    text = '''
    Short description.

    Long description.

    :param arg1: The first argument.
        Multiline
    :type arg1: str
    :param arg2: The second argument.
    :type arg2: int'''

    ret = parse(text)
    assert len(ret.meta) == 2
    assert isinstance(ret.meta[0], DocstringParam)
    assert ret.meta[0].arg_

# Generated at 2022-06-23 17:23:57.418421
# Unit test for function parse

# Generated at 2022-06-23 17:24:08.698824
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc(
    """One-line summary.

    Longer description.

    :param type_name arg_name: description
    :raises ValueError: description
    :returns: description
    :rtype: str
    """
    )

# Generated at 2022-06-23 17:24:17.821924
# Unit test for function parse
def test_parse():
    # Basic docstring with no keywords
    docstring = '''
    A short description.
    '''
    assert parse(docstring) == Docstring(
        short_description='A short description.',
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

    # Basic docstring with no keywords, but with a blank line after the
    # short description
    docstring = '''
    A short description.

    '''
    assert parse(docstring) == Docstring(
        short_description='A short description.',
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

    # Basic docstring with a long

# Generated at 2022-06-23 17:24:27.859265
# Unit test for function parse
def test_parse():
    """Test the parse function"""
    result = parse(
        """
        This is a test docstring.

        Parameters
        ----------
        x: int
            x-axis.
        y: int
            y-axis.

        Returns
        -------
        int
            The product of x and y.

        Raises
        ------
        ValueError
            If both x or y are negative.
        """
    )
    assert result.short_description == "This is a test docstring."
    assert result.long_description == "Parameters\n----------\nx: int\n    x-axis.\ny: int\n    y-axis.\n\nReturns\n-------\nint\n    The product of x and y.\n\nRaises\n------\nValueError\n    If both x or y are negative."


# Generated at 2022-06-23 17:24:37.549804
# Unit test for function parse
def test_parse():
    docstring = """A short description.

    A longer description, which starts on another line.

    :param param1: The first parameter.
    :param param2: The second parameter.
    :returns: a return value explained.
    """
    doc = parse(docstring)

    assert doc.short_description == "A short description."
    assert doc.blank_after_short_description is False
    assert "\nA longer description, which starts on another line.\n" in doc.long_description
    assert doc.blank_after_long_description is True

    assert len(doc.meta) == 3

    assert doc.meta[0].keyword == "param"
    assert doc.meta[0].arg_name == "param1"
    assert doc.meta[0].type_name is None
    assert doc.meta[0].description

# Generated at 2022-06-23 17:24:47.704320
# Unit test for function parse
def test_parse():
    # Incomplete docstring
    test_docstring = '"""One line docstring."""'
    try:
        assert parse(test_docstring).short_description == 'One line docstring.'
        assert parse(test_docstring).long_description is None
        assert parse(test_docstring).meta == list()
    except:
        print('test_parse: parse(test_docstring 1) did not parse correctly.')
        assert False

    # Simple docstring
    test_docstring = """
    This is a test docstring.
    """


# Generated at 2022-06-23 17:24:55.025503
# Unit test for function parse
def test_parse():
    '''
    Test function `parse` in module `rst_docstring`.
    '''
    docstring = '''
        Short description.
        
        Longer description.
        And it still goes on and on.
        :param arg1: the first argument
        :param arg2: the second argument
        :type arg3: the type of arg3
        :raises Exception: when things go wrong
        '''
    docstrings = parse(docstring)
    assert len(docstrings.meta) == 3
    for m in docstrings.meta:
        assert m.description
    assert docstrings.meta[0].arg_name == 'arg1'
    assert docstrings.meta[1].arg_name == 'arg2'
    assert docstrings.meta[2].type_name == 'Exception'

# Generated at 2022-06-23 17:25:02.441126
# Unit test for function parse
def test_parse():
    text = """Summary line.

    Extended description of function.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    int
        Description of return value
    """

# Generated at 2022-06-23 17:25:13.918281
# Unit test for function parse
def test_parse():
    """test function parse"""
    docstr = parse(
        """
    This is the short description.

    This is the long description.  The long description is
    separated from the short description by a blank line.

    :param int count: The number of widgets.
    :param str name: The displayed name of the widget.
    :returns: description
    :rtype: str
    :raises Exception: when something bad happens.
    """
    )

    assert docstr.short_description == "This is the short description."
    assert docstr.long_description == (
        "This is the long description.  The long description is "
        "separated from the short description by a blank line."
    )
    assert docstr.blank_after_short_description
    assert docstr.blank_after_long_description
    arg1 = doc

# Generated at 2022-06-23 17:25:21.668524
# Unit test for function parse
def test_parse():
    test_docstring = """
        short description

        long description

        :param type varname: description

        :returns: description
    """

# Generated at 2022-06-23 17:25:23.948474
# Unit test for function parse
def test_parse():
    parser = parse("")
    assert parser.short_description == None



# Generated at 2022-06-23 17:25:31.548900
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    print(parse.__name__)
    print(docstring.parse('   Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '))
    print(parse(' :param str arg1: The first argument.\n   :type arg1: str\n  '))

# Generated at 2022-06-23 17:25:40.751565
# Unit test for function parse
def test_parse():
    text = '''
    """short_description
    long_description
    :param a: first line of the description

    second line of the description
    :type a: str
    :param b: another parameter, second line of the description
    :type b: int or None
    :param c: another parameter, second line of the description

    third line of the description
    :type c: int or None
    :param d: this parameter defaults to 42.
    :type d: int
    :returns: a description

    second line of the description
    :rtype: int
    :yields: one item of the iterator

    second line of the description
    :ytype: int
    :raises ValueError: when something bad happens

    second line of the description
    """
    '''

    doctree = parse(text)

# Generated at 2022-06-23 17:25:52.236642
# Unit test for function parse
def test_parse():
    # Empty docstring
    assert parse("") == Docstring()
    # Single-line docstring
    assert parse("Short description.") == parse("Short description")
    # Wordwrap
    assert parse("Lorem ipsum dolor sit amet, consectetur adipiscing elit.")
    # Blank after short description
    assert parse(
        "Short description.\n\nLong description."
    ) == Docstring(
        short_description="Short description",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="Long description",
    )
    # Blank after short description

# Generated at 2022-06-23 17:26:03.247134
# Unit test for function parse
def test_parse():
    ## Test null argument
    assert parse(None) == Docstring()
    assert parse('') == Docstring()

    ## Test simple description
    assert parse('A simple description') == Docstring(
        short_description='A simple description',
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

    ## Test simple description with indentation
    assert parse('    A simple description') == Docstring(
        short_description='A simple description',
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

    ## Test simple description with indentation

# Generated at 2022-06-23 17:26:13.139203
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Longer description.

    :param a: A thing.
    :param b: Another thing.
    :raises RuntimeError: Yaaaarrrggghh.
    """

    actual = parse(docstring)
    assert actual.short_description == "Short description."
    assert actual.blank_after_short_description is False
    assert actual.long_description == "Longer description."
    assert actual.blank_after_long_description is True
    assert isinstance(actual.meta[0], DocstringParam)
    assert isinstance(actual.meta[1], DocstringParam)
    assert isinstance(actual.meta[2], DocstringRaises)
    assert actual.meta[0].description == "A thing."
    assert actual.meta[1].description == "Another thing."

# Generated at 2022-06-23 17:26:19.055242
# Unit test for function parse
def test_parse():
    docstring = """Summary line.

    Extended description of function.

    :param int x: Description of `x`.
    :param y: Description of `y` (defaults to 42).
    :returns: Description of return value.
    :raises ValueError: When something bad happens.
    """

    expected = """Summary line.

    Extended description of function.

    :param int x: Description of `x`.
    :param y: Description of `y` (defaults to 42).
    :returns: Description of return value.
    :raises ValueError: When something bad happens.
    """

    assert(str(parse(docstring)) == expected)

# test_parse()

# Generated at 2022-06-23 17:26:30.243092
# Unit test for function parse
def test_parse():
    """Tests a few examples of docstrings, saving the output to file."""
    from .common import parse_docstring_from_file
    from .common import parse_docstring_from_string
    from .common import parse_docstring_from_function
    from .common import print_docstring
    import inspect
    import os.path
    import sys

    def _test(docstring: Docstring, *, filename: str = None) -> None:
        if filename is None:
            filename = "tmp.log"
        print_docstring(
            docstring,
            filename=filename,
            file_mode="w",
            stream=sys.stdout,
            debug=True,
        )
