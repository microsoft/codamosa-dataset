

# Generated at 2022-06-23 17:16:26.358338
# Unit test for function parse
def test_parse():
    from .common import Docstring, DocstringParam, DocstringReturns, DocstringRaises
    from .common import DocstringMeta
    docstring = parse("""
        """
    )


# Generated at 2022-06-23 17:16:36.443604
# Unit test for function parse
def test_parse():
    def w(x):
        print("    {}".format(x))

    def test(text):
        w("")
        w("Input:")
        w(text)
        w("")
        w("Output:")
        w(str(parse(text)))
        w("")

    w("The input text should be a docstring that starts with a triple quote...")
    w("")

# Generated at 2022-06-23 17:16:45.584281
# Unit test for function parse
def test_parse():
    text = """
    Try parsing docstring.

    :param foo: foo description
    :type foo: int
    :param bar: bar description
    :type bar: bool, optional
    :param baz: baz description, defaults to 5.
    :returns: :class:`~tftest.tftest.tftest.tftest`, optional
    :returns: :data:`~tftest.tftest.tftest.tftest`
    :raises ValueError: if value is not valid
    :raises TypeError: if value is not valid type
    :raises RuntimeError: if something goes wrong
    """
    docstring = parse(text)
    print(docstring.short_description)
    assert docstring.short_description == "Try parsing docstring."
    assert docstring.long_

# Generated at 2022-06-23 17:16:47.740018
# Unit test for function parse
def test_parse():
    doc = "Test\nA description\n:param X: int\n"
    res = parse(doc)
    return res

# Generated at 2022-06-23 17:16:55.560139
# Unit test for function parse
def test_parse():
    docstring = r"""
    This function is to test

    - Parsing a docstring
    - To make sure that it is done correctly

    :param name: The name of the student
    :type name: str
    :rtype: str
    :Returns: The name of the student
    :Raises:
    """
    doc = parse(docstring)
    assert doc.short_description == "This function is to test"
    assert doc.long_description == "Parsing a docstring\nTo make sure that it is done correctly"

# Generated at 2022-06-23 17:17:03.676919
# Unit test for function parse
def test_parse():
    """
    """
    raw_docstring = """
    Test docstring.

    Test description.

    :param arg1: Test arg1.
    :type arg1: int

    :param arg2: Test arg2.
    :type arg2: str
    :default arg2: 'test'

    :raises ValueError: Test ValueError.
    :raises TypeError: Test TypeError.

    :return: Test return.
    :rtype: int

    :yield: Test yield.
    :ytype: float
    """

    docstring = parse(raw_docstring)

    assert docstring.short_description == 'Test docstring.'
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-23 17:17:13.269365
# Unit test for function parse
def test_parse():
    # Put the docstring in a multi-line string in the source.
    def foo(bar, baz=42):
        """This is a short description.

        This is a long description.

        :param int bar: description for first parameter
        :param baz: description for second parameter
        :type baz: optional int
        :returns: None
        :raises ValueError: if something bad happens
        :return: None
        :rtype: str
        """

    docstring = parse(inspect.getdoc(foo) or "")
    print(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description is True

# Generated at 2022-06-23 17:17:22.068152
# Unit test for function parse
def test_parse():
    text = """Summarize the function.
    :param x: the value x
    :type x: int
    :param y: the value y
    :type y: numbers.Number
    :returns: the result of adding x and y.
    :rtype: float
    :raises ValueError: if x or y are invalid
    :raises TypeError: if an operation does not support the data types.
    """
    parse(text)

# Sprint4a

# Generated at 2022-06-23 17:17:33.015324
# Unit test for function parse

# Generated at 2022-06-23 17:17:44.319048
# Unit test for function parse
def test_parse():
    text = """
    Parse the ReST-style docstring into its components.

    :param int a: bla bla
    :param int b: bla bla
    :return: the result
    :rtype: bool
    :raises ValueError: If value is invalid.
    """
    doc = parse(text)
    assert doc.short_description == "Parse the ReST-style docstring into its components."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert doc.long_description == None

# Generated at 2022-06-23 17:17:52.776781
# Unit test for function parse
def test_parse():
    text_input = """\
A short summary of the function.

A sentence with some explanation of the function.
"""
    assert parse(text_input).short_description == "A short summary of the function."
    assert parse(text_input).long_description == "A sentence with some explanation of the function."
    assert parse(text_input).blank_after_long_description == False

    text_input = """\
A short summary of the function.

A sentence with some explanation of the function.

"""
    assert parse(text_input).short_description == "A short summary of the function."
    assert parse(text_input).long_description == "A sentence with some explanation of the function."
    assert parse(text_input).blank_after_long_description == True


# Generated at 2022-06-23 17:18:00.092878
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc("""
    This is a docstring

    Args:
        arg1: The first argument
        arg2: The second argument

    Returns:
        The return value.

    Raises:
        Exception: If something went wrong.

    Yields:
        int: The next integer in the Fibonacci sequence.
    """)

    result = parse(docstring)
    assert result.short_description == "This is a docstring"
    assert result.long_description is None
    assert result.blank_after_short_description is False
    assert result.blank_after_long_description is False
    assert len(result.meta) == 3


# Generated at 2022-06-23 17:18:09.806843
# Unit test for function parse
def test_parse():
    docstring = """
    First line of a function or method.
    
    Extended description, everything here is a description as long as
    there are no two blank lines.
    
    :param name: Description of the first parameter.
    :type name: string
    :param age: Description of the second parameter.
    :type age: integer
    :returns: Description of what is returned.
    :rtype: string
    :raises keyError: raises an exception
    :raises ImportError: If something cannot be imported

    Finally anything after the two blank lines as a closing paragraph.
    """
    d = parse(docstring)
    assert d.short_description == 'First line of a function or method.'
    assert d.long_description.startswith('Extended description')
    assert d.blank_after_short_description
    assert d

# Generated at 2022-06-23 17:18:17.559957
# Unit test for function parse
def test_parse():
    example_doc = """first line
    
    Second line
    
    :param t: parameter t
    :type t: int
    :param a: parameter a
    :param b: parameter b
    :return:
    :rtype: int
    
    :returns:
    :rtype: int
    
    :returns:
    :yields:
    :rtype: str
    :raises:
    """
    parse(example_doc)

parse(inspect.getdoc(parse))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:18:24.668713
# Unit test for function parse
def test_parse():
    source = r"""
    Prints 'Hello World' to the console.

    :returns: prints 'Hello World' to the console
    """
    result = parse(source)
    assert result.short_description == "Prints 'Hello World' to the console."
    assert result.long_description == None
    assert result.blank_after_short_description
    assert not result.blank_after_long_description
    assert len(result.meta) == 1
    assert isinstance(result.meta[0], DocstringReturns)
    assert result.meta[0].description == "prints 'Hello World' to the console"

    source = r"""
    Prints 'Hello World' to the console.

    :returns: prints 'Hello World' to the console

    This is a test
    """
    result = parse(source)

# Generated at 2022-06-23 17:18:35.255174
# Unit test for function parse

# Generated at 2022-06-23 17:18:36.125758
# Unit test for function parse
def test_parse():
    parse('test string')

# Generated at 2022-06-23 17:18:37.925011
# Unit test for function parse
def test_parse():
    '''
    Simple test docstring
    '''
    print(parse(test_parse.__doc__))

# Generated at 2022-06-23 17:18:46.785340
# Unit test for function parse
def test_parse():
    """Test the parse function!"""
    from .parse import parse

    docstring = parse.__doc__
    docstring_dict = parse(docstring)

    assert docstring_dict.meta[0].args[0] == 'type_name'
    assert docstring_dict.meta[1].args[0] == 'returns'
    assert docstring_dict.meta[1].args[1] == 'str'
    assert docstring_dict.short_description == """ReST-style docstring parsing."""
    assert docstring_dict.long_description == """\nReST-style docstring parsing.\n\n:param type_name: a type\n:returns: a string"""

# Generated at 2022-06-23 17:18:57.883812
# Unit test for function parse
def test_parse():
    docstring_in_one_line = "Sample docstring"
    docstring_with_blank_lines = "\n\nSample docstring\n\n"
    multi_line_docstring = "Sample docstring\n\n" + "Additional line\n"
    docstring_with_return_type = "Sample docstring\n\nReturns:\n\n" + \
        "    float: float value\n"
    docstring_with_yields = "Sample docstring\n\nYields:\n\n" + \
        "    int: integer value\n"
    docstring_with_raises = "Sample docstring\n\nRaises:\n\n" + \
        "    ValueError: error msg\n"

# Generated at 2022-06-23 17:19:10.158014
# Unit test for function parse
def test_parse():
    docstring = """A function for testing.

    :param hi: gimme a string
    :type hi: str
    :param bu: a float
    :type bu: float
    :raises TypeError: when the type is wrong
    :returns: int -- the return code
    """

    parsed_docstring = parse(docstring)
    assert len(parsed_docstring.meta) == 4

    meta0 = parsed_docstring.meta[0]
    assert meta0.arg_name == "hi"
    assert meta0.type_name == "str"

    meta1 = parsed_docstring.meta[1]
    assert meta1.arg_name == "bu"
    assert meta1.type_name == "float"

    meta2 = parsed_docstring.meta[2]
    assert meta2.type

# Generated at 2022-06-23 17:19:18.256442
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("foo") == Docstring(
        short_description="foo", blank_after_short_description=True
    )
    assert parse("foo\nbar") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="bar",
    )
    assert parse("foo\nbar\n\nbaz") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="bar\nbaz",
    )

# Generated at 2022-06-23 17:19:27.024310
# Unit test for function parse
def test_parse():
    # Test 1
    docstring = '''
    This is a short description.

    This is a long description.
    '''

    # Test 2
    docstring = '''
    :param a: first parm
    :param b: second parm
    '''
    parsed = parse(docstring)

    # Test 3
    docstring = '''
    :param a: first parm
    :param b: second parm
    :return: a return value
    '''
    parsed = parse(docstring)

    # Test 4
    docstring = '''
    :raises Exception: on error
    '''
    parsed = parse(docstring)
    #pass

# Generated at 2022-06-23 17:19:37.641847
# Unit test for function parse

# Generated at 2022-06-23 17:19:44.459795
# Unit test for function parse
def test_parse():
    """Test case for function parse()"""
    test_text = """
        This function is to test the functionality of function docs.par.parse().
        It will take an argument arg0 and return arg0 + 1.

        :param int arg0: an integer to be added
        :returns: arg0 + 1
        :rtype: int
    """
    result = parse(test_text)
    if result.short_description != "This function is to test the functionality of function docs.par.parse().":
        return False
    if result.long_description != "It will take an argument arg0 and return arg0 + 1.":
        return False
    if result.blank_after_short_description != False:
        return False
    if result.blank_after_long_description != True:
        return False

# Generated at 2022-06-23 17:19:55.389408
# Unit test for function parse
def test_parse():
    docstring_text = '''\
    Short summary.

    Longer description.

    :param arg1: The first argument.
    :param arg2: The second argument. Defaults to None.
    :param arg3: The third argument.
    :type arg3: str
    :param arg4: The fourth argument.
    :type arg4: str or None
    :param arg5: The fifth argument. Defaults to 'example'.
    :type arg5: str
    :param arg6: The sixth argument.
    :type arg6: None or str or int
    :returns: Description of return value.
    :raises ValueError: In case of an exception.
    '''
    docstring = parse(docstring_text)
    print(docstring)

# Generated at 2022-06-23 17:20:04.959273
# Unit test for function parse
def test_parse():
    text = '''
    Arbitrary docstring.
    :param arg1: Description of the first positional argument.'''

    test_docstring = parse(text)
    assert test_docstring.short_description == "Arbitrary docstring."
    assert test_docstring.meta[0].args == ['param', 'arg1']
    assert test_docstring.meta[0].description == "Description of the first positional argument."
    # Test the default values
    assert test_docstring.long_description is None
    assert test_docstring.blank_after_long_description is None
    assert test_docstring.blank_after_short_description is None

# Generated at 2022-06-23 17:20:11.419927
# Unit test for function parse
def test_parse():
    import pprint
    import testfixtures

    text = """\
A short summary.

    A longer summary.

    :param   arg1:
             description of arg1

    :param   arg2:
             description of arg2

    :returns:
             description of return
    """


# Generated at 2022-06-23 17:20:20.413423
# Unit test for function parse
def test_parse():
    parse_normal = parse(""""
        Short description.

        Long description.
""")
    assert(parse_normal.short_description == "Short description.")
    assert(parse_normal.long_description == "Long description.")

    parse_normal_multiline = parse("""
        Short description.

        Long description.
        This description has multiple lines.
""")
    assert(parse_normal_multiline.short_description == "Short description.")
    assert(parse_normal_multiline.long_description == """Long description.
This description has multiple lines.""")

    parse_no_long_desc = parse("""
        Short description.
""")
    assert(parse_no_long_desc.short_description == "Short description.")
    assert(parse_no_long_desc.long_description is None)

    parse_multi

# Generated at 2022-06-23 17:20:31.870446
# Unit test for function parse
def test_parse():
    from . import common
    text = (
        'This is a long description.\n'
        '\n'
        'This is a long description continued.\n'
        '\n'
        ':param str x: This is a long description of a parameter.\n'
        ':param y: And we can omit the type.'
    )
    actual = parse(text)

# Generated at 2022-06-23 17:20:41.433540
# Unit test for function parse
def test_parse():
    docstring = parse(docstring_example)
    # Check the help of the function
    assert docstring.short_description == "Function that would be use for test parse"
    assert docstring.long_description == \
    "This function is meant to be used for testing the parse function.\n" \
    "\n" \
    "Note that is also docstring!"
    # Check the metas
    assert docstring.meta[0].keyword == "param"
    assert docstring.meta[0].arg_name =="param1"
    assert docstring.meta[0].type_name =="str"
    assert docstring.meta[0].is_optional == True
    assert docstring.meta[0].default == "None"
    assert docstring.meta[0].description == "Description of parameter 1"


# Generated at 2022-06-23 17:20:43.424945
# Unit test for function parse
def test_parse():
    parse(__doc__)

# Generated at 2022-06-23 17:20:54.433567
# Unit test for function parse

# Generated at 2022-06-23 17:21:05.781585
# Unit test for function parse
def test_parse():
    '''Test the docstring parsing functionality'''

    assert(parse("""This is a description.

    :param arg: description of arg
    :type arg: str
    :param arg2: description of arg2
    :type arg2: int
    :returns: description of return value
    :rtype: long
    :raises ValueError: description of when a ValueError is raised
    """).module_description == "This is a description.")

    assert(parse("""This is a description.

    :param arg: description of arg
    :type arg: str
    :param arg2: description of arg2
    :type arg2: int
    :returns: description of return value
    :rtype: long
    :raises ValueError: description of when a ValueError is raised
    """).short_description == "This is a description.")

# Generated at 2022-06-23 17:21:12.230842
# Unit test for function parse
def test_parse():
    doc_string = """

This is a documentation string.

:returns: a variable.
    """
    docstring = parse(doc_string)
    assert docstring.short_description == "This is a documentation string."
    assert docstring.long_description == ""
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-23 17:21:20.448767
# Unit test for function parse
def test_parse():
    docstring = parse.__doc__
    result = parse(docstring)
    assert result.short_description == "Parse the ReST-style docstring into its components."
    assert result.long_description == ":returns: parsed docstring"
    assert result.blank_after_short_description
    assert result.blank_after_long_description
    assert len(result.meta) == 1
    assert result.meta[0].args == ['returns']
    assert result.meta[0].description == 'parsed docstring'
    assert result.meta[0].type_name is None
    assert result.meta[0].arg_name is None
    assert result.meta[0].is_optional is None
    assert result.meta[0].default is None
    assert result.meta[0].is_generator is None

#

# Generated at 2022-06-23 17:21:28.441822
# Unit test for function parse
def test_parse():
    def func():
        """
        This is a function.

        :param arg: a string
        :returns: a string
        """
        pass

    doc_string = parse(func.__doc__)

    assert doc_string.short_description == "This is a function."
    assert doc_string.long_description == None
    assert doc_string.blank_after_short_description == True
    assert doc_string.blank_after_long_description == False

    assert doc_string.meta[0].args == ['param', 'arg:', 'a string']
    assert doc_string.meta[0].arg_name == 'arg:'
    assert doc_string.meta[0].type_name == 'a string'
    assert doc_string.meta[0].is_optional == False

# Generated at 2022-06-23 17:21:39.945508
# Unit test for function parse
def test_parse():
    """"""
    parts = parse("""\
        Short description.

        Long description.

        :param arg: First argument
        :param arg: Second argument
        :type arg: str
        :type arg: int
        :return: Value.
        :rtype: int
        :raises ValueError: On error.
        """)
    assert parts.short_description == "Short description."
    assert parts.long_description == "Long description."
    assert len(parts.meta) == 4

    # First field is a normal parameter.
    first_param = parts.meta[0]
    assert isinstance(first_param, DocstringParam)
    assert first_param.arg_name == "arg"
    assert first_param.type_name is None
    assert first_param.is_optional is None

# Generated at 2022-06-23 17:21:51.050332
# Unit test for function parse
def test_parse():
    print(parse("""
    Parse the ReST-style docstring into its components.

    :param str arg1: the arg1 description
    :param str arg2: the arg2 description
    :param str arg3: the arg3 description
    :returns: parsed docstring"""))
    print(parse("""
    Parse the ReST-style docstring into its components.

    :param arg1: the arg1 description
    :param arg2: the arg2 description
    :param arg3: the arg3 description
    :returns: parsed docstring"""))

# Generated at 2022-06-23 17:21:54.841338
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    print(type(parse.__doc__))
    print(parse.__defaults__)
    print(inspect.signature(parse))
    print(help(parse))

test_parse()

# Generated at 2022-06-23 17:22:05.855476
# Unit test for function parse

# Generated at 2022-06-23 17:22:16.502360
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

# Generated at 2022-06-23 17:22:24.498832
# Unit test for function parse
def test_parse():
    import pytest
    from .common import ParseError
    from .custom import parse as myparse

    def check(text, short_desc, long_desc=None):
        text = inspect.cleandoc(text)
        obj = myparse(text)
        assert obj.short_description == short_desc
        if long_desc is None:
            assert not obj.long_description
        else:
            assert obj.long_description == inspect.cleandoc(long_desc)

    # Basic description
    check("", "")
    check("foo", "foo")
    check(
        "foo bar\n\nblah boz", "foo bar", "blah\nboz"
    )

# Generated at 2022-06-23 17:22:32.006228
# Unit test for function parse
def test_parse():
    docstring = """Short description.
    
    Long description.
    
    This is an example of meta block
    
    :arg x: First argument.
    :param y: Second argument.
    :type y: str
    :keyword z: Third argument.
    :type z: bool
    :return: Return value.
    :rtype: int
    :returns: Return value.
    :raises ValueError:
    """

    print(parse(docstring))

# test_parse()

# Generated at 2022-06-23 17:22:40.179347
# Unit test for function parse
def test_parse():
    docstring = parse('''
    short description
    long description
    :key: value
    ''')
    assert docstring.short_description == 'short description'
    assert docstring.long_description == 'long description'
    assert docstring.meta[0].args == ['key', 'value']
    assert docstring.meta[0].description == ''

    docstring = parse('''
    short description
    long description

    :key: value
    ''')
    assert docstring.short_description == 'short description'
    assert docstring.long_description == 'long description'
    assert docstring.meta[0].args == ['key', 'value']
    assert docstring.meta[0].description == ''


# Generated at 2022-06-23 17:22:49.015876
# Unit test for function parse
def test_parse():
    docstring = '''This is a sample docstring.

And this is the extended description.

:param a: an integer
:type a: int
:param b: a float
:type b: float
:param c: a boolean (defaults to True)
:type c: bool
:param d: a boolean (defaults to False)
:type d: bool
:returns: a sample return value
:rtype: int
'''
    doc = parse(docstring)
    assert doc.short_description == 'This is a sample docstring.'
    assert doc.long_description == 'And this is the extended description.'
    assert len(doc.meta) == 5
    for m in doc.meta:
        if m.keyword == 'param':
            if m.arg_name == 'a':
                assert m.type_name

# Generated at 2022-06-23 17:22:58.583127
# Unit test for function parse
def test_parse():
    def test_func(a, b='foo'):
        """Short description.

        Long description.

        :param a: a description
        :type a: str | None
        :param b: b description
        :type b: str
        :returns: return description
        :rtype: int
        :raises ZeroDivisionError: if error
        """

    assert parse(inspect.getdoc(test_func)) == parse(test_func.__doc__)
    # Example 1
    # Calling the function with a docstring with both short and long descriptions.
    docstring_text = '''Example docstring.
                    
                    Another line.'''

# Generated at 2022-06-23 17:23:08.545444
# Unit test for function parse
def test_parse():
    # Test with one line
    docstring = "Parse the ReST-style Docstring."
    expected_output = Docstring(
        short_description="Parse the ReST-style Docstring.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    assert parse(docstring) == expected_output

    # Test with empty docstring
    docstring = ""
    expected_output = Docstring()
    assert parse(docstring) == expected_output

    # Test with two lines
    docstring = (
        "Parse the ReST-style Docstring.\n"
        "This function is intended to be used as a docstring."
    )

# Generated at 2022-06-23 17:23:18.724551
# Unit test for function parse
def test_parse():
    parsed = parse("""
    Short description.

    Runs a test.

    :param x: Something.
    :type x: str
    :raises RuntimeError: If bad things happen.
    :returns: Something else.
    """)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Runs a test."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description

    assert parsed.meta[0] == DocstringParam(
        args=["param", "x", "Something"],
        description="Type: str",
        arg_name="x",
        type_name="str",
        is_optional=False,
        default=None,
    )

# Generated at 2022-06-23 17:23:27.811396
# Unit test for function parse
def test_parse():
    assert parse("""
    Blah blah.

    :param x: the value for x
    :type x: int
    :param y: the value for y, defaults to 42.
    :param z: the value for z, defaults to 1.
    :returns: the value x + y + z
    :rtype: int
    :raises IOError: if an I/O error occurs
    :raises OSError: if a system error occurs
    :raises ValueError: if an invalid value is used
    :raises KeyError: if a key error occurs
    """) is not None

# Generated at 2022-06-23 17:23:36.693873
# Unit test for function parse
def test_parse():
    docstring = """Sums an arbitrary number of numbers.
    A single number or an iterable of numbers are both valid
    inputs.

    :param numbers: The numbers to sum
    :type numbers: float, int or iterable of numbers
    :param start: The value to start summing at.
    Defaults to ``0``.
    :type start: float, int
    :raises TypeError: If no number-like items are found in ``numbers`` and
    ``start`` is not specified.
    :returns: The sum of the numbers.
    """
    print("#" * 50)
    print("Testing docstring 'parse'...")
    parsed_docstring = parse(docstring)

# Generated at 2022-06-23 17:23:47.353186
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description.
    """

    doc = parse(text)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert not doc.blank_before_short_description
    assert not doc.blank_after_short_description
    assert not doc.blank_after_long_description

    doc = parse("")
    assert doc.short_description == None
    assert doc.long_description == None
    assert not doc.blank_before_short_description
    assert not doc.blank_after_short_description
    assert not doc.blank_after_long_description

    doc = parse("short description\n")
    assert doc.short_description == "short description"
    assert doc.long_description == None
    assert not doc.blank_before

# Generated at 2022-06-23 17:23:53.704879
# Unit test for function parse
def test_parse():
    def funcWithEmptyDocString():
        """
        """
    d = parse(inspect.getdoc(funcWithEmptyDocString))
    assert d.short_description == None
    assert d.long_description == None
    assert len(d.meta) == 0
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False

    def funcWithDocString():
        """
        Hi.
        """
    d = parse(inspect.getdoc(funcWithDocString))
    assert d.short_description == "Hi."
    assert d.long_description == None
    assert len(d.meta) == 0
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False


# Generated at 2022-06-23 17:24:02.242741
# Unit test for function parse
def test_parse():
    import unittest
    import textwrap

    class TestParse(unittest.TestCase):
        def test_simple(self):
            text = "Hello, world."
            res = parse(text)
            self.assertEqual(res.short_description, "Hello, world.")
            self.assertEqual(res.long_description, None)
            self.assertEqual(res.meta, [])

        def test_long_description_without_meta(self):
            text = "Hello, world.\nThis is a longer description."
            res = parse(text)
            self.assertEqual(res.short_description, "Hello, world.")
            self.assertEqual(res.long_description, "This is a longer description.")
            self.assertEqual(res.meta, [])


# Generated at 2022-06-23 17:24:14.154870
# Unit test for function parse
def test_parse():
    text = """Hello world.

This is a long description.

:param str foo: Foo description.
:param int bar: Bar description.
:returns: Return description.
:rtype: int
:raises ValueError: If baz is invalid.
"""
    res = parse(text)
    assert res.short_description == "Hello world."
    assert res.long_description == "This is a long description."
    assert res.blank_after_short_description is True
    assert res.blank_after_long_description is True
    assert res.meta[0].arg_name == "foo"
    assert res.meta[0].type_name == "str"
    assert res.meta[0].description == "Foo description."
    assert res.meta[1].arg_name == "bar"

# Generated at 2022-06-23 17:24:24.019795
# Unit test for function parse
def test_parse():
    docstring = """This function adds two numbers

Args:
    a: first value
    b: second value

Returns:
    sum of a and b
"""
    obj = parse(docstring)
    assert isinstance(obj, Docstring)

    docstring = """This function adds two numbers

Args:
    a: first value
    b: second value

Raises:
    TypeError: when either a or b is not a number

Returns:
    sum of a and b
"""
    obj = parse(docstring)
    assert isinstance(obj, Docstring)

# Generated at 2022-06-23 17:24:32.999167
# Unit test for function parse
def test_parse():
    docstring = """
        This is a longer description of the function.

        :param int count: number of items to fetch.
        :returns: a list of items with the specified length.
        """
    assert(parse(docstring).short_description == "This is a longer description of the function.")
    assert(parse(docstring).long_description == "a list of items with the specified length.")
    assert(parse(docstring).meta[0].arg_name == "count")
    assert(parse(docstring).meta[0].type_name == "int")



# Generated at 2022-06-23 17:24:44.230131
# Unit test for function parse
def test_parse():
    docstr = """
    Short description.

    Long description.

    :param arg1: Description of arg1
    :type arg1: Optional[str]
    :param int arg2: Description of arg2
    :param arg3: Description of arg3 with a default
        value.  Defaults to 42.
    :param arg4: Description of arg4.  
        Defaults to None.
    :raises ValueError: if arg3 lies outside
        of our sexy range
    :raises LookupError: 
    :returns: str
    :yields: int
    """
    doc = parse(docstr)
    assert doc.short_description == "Short description."
    assert doc.blank_after_long_description
    assert doc.meta[-1].args == ["yields", "int"]

# Generated at 2022-06-23 17:24:55.002253
# Unit test for function parse
def test_parse():
    docstring = """Simple function.

    :param foo: the foo
    :type foo: str
    :param bar: the bar
    :type bar: int
    :param baz: the baz
    :type baz: bool
    :returns: the return value
    :rtype: str

    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
    eiusmod tempor incididunt ut labore et dolore magna aliqua.
    """
    doc = parse(docstring)
    print (doc.__dict__)

# Generated at 2022-06-23 17:24:55.576295
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-23 17:25:02.593012
# Unit test for function parse
def test_parse():
    """Test function parse"""
    docstring_object = parse("This is a docstring.\nWith another line.")
    assert docstring_object.short_description == "This is a docstring."
    assert docstring_object.long_description == "With another line."
    assert docstring_object.blank_after_short_description
    assert docstring_object.blank_after_long_description

    docstring_object = parse("Short only.")
    assert docstring_object.short_description == "Short only."
    assert docstring_object.long_description is None
    assert not docstring_object.blank_after_short_description
    assert not docstring_object.blank_after_long_description

    docstring_object = parse("  \t  \n  \n")
    assert docstring_object.short_description is None


# Generated at 2022-06-23 17:25:14.185725
# Unit test for function parse
def test_parse():
    docstring = parse("""
        Very short description
        
        Very long description
        
        :param foo: This is an int
        :type foo: int
        
        :param bar: This is a float
        :type bar: float
        
        :param baz: This is a bool
        :type baz: bool
        
        :returns: The return
        :type returns: float
        """)

    assert docstring.short_description == "Very short description"
    assert docstring.long_description == "Very long description"
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description

    assert len(docstring.meta) == 3

    assert docstring.meta[0].arg_name == "foo"

# Generated at 2022-06-23 17:25:25.645670
# Unit test for function parse
def test_parse():
    assert Docstring(
        short_description="Hello",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="World",
        meta=[
            DocstringParam(
                args=["param", "str", "hello"],
                description="A hello greeting.",
                arg_name="hello",
                type_name="str",
                is_optional=False,
                default=None,
            )
        ],
    ) == parse("""\
        Hello

        World

        :param str hello: A hello greeting.
    """)


# Generated at 2022-06-23 17:25:35.077529
# Unit test for function parse
def test_parse():
    # Test ReST docstring
    class TestClass:
        """This is a test docstring.

        This is a long description of the docstring.

        :param int n: An integer.
        :param word: A str.
        :rtype: :class:`TestClass`
        :returns: :class:`~TestClass`
        :raises ValueError: If `n` is not even.
        """

    doc = parse(TestClass.__doc__)
    assert doc.short_description == "This is a test docstring."
    assert doc.blank_after_short_description
    assert doc.long_description == ("This is a long description of the docstring.")
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3


# Generated at 2022-06-23 17:25:39.713308
# Unit test for function parse
def test_parse():
    text = """Summary line.

Description of the method.

:param param_name: The name of the param.
:type param_name: str, optional
:param unknown:
:type unknown:

:returns: The return value of the method.
:rtype: str

:raises AttributeError: Does not exist.
:raises RuntimeError: Not ready.
"""
    parse(text)

# Generated at 2022-06-23 17:25:45.708898
# Unit test for function parse
def test_parse():
    """
    :type YOLO
    """

# Generated at 2022-06-23 17:25:55.571448
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("test") == Docstring(
            short_description="test", 
            long_description=None, 
            meta=[]
    )
    assert parse(
        """test
        test
        """
    ) == Docstring(
            short_description="test", 
            long_description="test", 
            meta=[]
    )
    assert parse(
        """test
        test2

        test3
        
        test4
        """
    ) == Docstring(
            short_description="test", 
            long_description="""test2
            
            test3
            
            
            test4""", 
            meta=[]
    )
    assert parse(
        """test

        test2

        test3
        
        test4
        """
    )

# Generated at 2022-06-23 17:26:06.600694
# Unit test for function parse
def test_parse():
    docstring = "This is a test docstring.\n\nThis is the long description.\n:param int arg_one:\n        This is the first argument.\n        It has multiple lines.\n"
    parsed = parse(docstring)
    assert parsed.short_description == "This is a test docstring."
    assert parsed.long_description == "This is the long description."
    assert parsed.meta == [DocstringParam(args=['param', 'int', 'arg_one'], arg_name='arg_one', description='This is the first argument.\nIt has multiple lines.', is_optional=False, type_name='int', default=None)]
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False

# Generated at 2022-06-23 17:26:09.925105
# Unit test for function parse
def test_parse():
    # Check the docstring of the parse() function itself
    # (which currently doesn't contain any meta entries)
    assert isinstance(parse(parse.__doc__), Docstring)

test_parse()

# Generated at 2022-06-23 17:26:17.932771
# Unit test for function parse
def test_parse():
    docstring = """Test head parsing
    The next line is blank

    This needs to be the long description.
    
    
    :param a: the A
    :param b: the B
    :returns: the return
    :raises X: raises X
    :keyword keyword: the keyword
    """

    parsed_docstring = parse(docstring)

    assert parsed_docstring.short_description == "Test head parsing"
    assert parsed_docstring.long_description == "This needs to be the long description."
    assert parsed_docstring.blank_after_short_description is True
    assert parsed_docstring.blank_after_long_description is False
    assert len(parsed_docstring.meta) == 4

    assert isinstance(parsed_docstring.meta[0], DocstringParam)
    assert parsed

# Generated at 2022-06-23 17:26:29.204944
# Unit test for function parse