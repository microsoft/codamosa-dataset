

# Generated at 2022-06-23 17:16:34.981283
# Unit test for function parse
def test_parse():
    text1 = '''
    A module comment.

    :param int a: A parameter.

    '''
    print(parse(text1).meta[0].args)
    print(parse(text1).meta[0].arg_name)
    print(parse(text1).meta[0].type_name)

    text2 = '''
    A function comment.

    :param a: A parameter.
    :type a: int

    '''
    print(parse(text2).meta[0].type_name)

    text3 = '''
    A class comment.

    :param a: A parameter.
    :type: int

    '''
    print(parse(text3).meta[0].type_name)


# Generated at 2022-06-23 17:16:41.509062
# Unit test for function parse
def test_parse():
    docstring=parse('''Sorts list in-place and returns it.

    :param list lst:
        The list to sort.
    :param int order:
        1 ascending (default), 0 descending

    :returns:
        The sorted list.

    :raises TypeError:
        If list is not a list or order is not an int.
    ''')
    assert docstring.short_description=='Sorts list in-place and returns it.'
    assert not docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.long_description is None
    assert len(docstring.meta)==2


# Generated at 2022-06-23 17:16:47.223362
# Unit test for function parse
def test_parse():
    docstring = "Example::\n\n    >>> x = 1\n    >>> x\n    1\n"
    docstring = parse(docstring)
    docstring_expected = Docstring(
        short_description='Example',
        blank_after_short_description = True,
        blank_after_long_description = True,
        long_description='>>> x = 1\n>>> x\n1',
        meta=[]
    )
    assert docstring == docstring_expected


# Generated at 2022-06-23 17:16:58.316897
# Unit test for function parse

# Generated at 2022-06-23 17:17:05.170442
# Unit test for function parse
def test_parse():
    docstring = r'''
Parse the docstring into its components.

:param x: description of x
:type x: str

:param\ y: description of y
:type\ y: str

:returns: description of return value
:rtype: str

:returns: description of another return value
:rtype: int

:raises RuntimeError: if something bad happens

:Example:
    >>> example_func(1, 2)
    42
'''
    parsed = parse(docstring)
    assert parsed.short_description == "Parse the docstring into its components."
    assert parsed.blank_after_short_description
    assert parsed.long_description == ":Example:\n    >>> example_func(1, 2)\n    42"
    assert parsed.blank_after_long_description

# Generated at 2022-06-23 17:17:15.516968
# Unit test for function parse
def test_parse():
    text = """
    This is a summary.

    This is a long description.
    See :func:`parse` for details.

    :param str text: bla
    :param int width: defaults to 80.
    :raises ValueError: hi
    :yields str:
    """
    x = parse(text)
    assert x.short_description == "This is a summary."
    assert x.long_description == "This is a long description.\nSee :func:`parse` for details."
    assert x.meta[2].type_name == "ValueError"
    assert x.meta[2].description == "hi"
    assert x.meta[3].type_name == "str"
    assert x.meta[3].description == ""
    assert x.meta[3].is_generator == True

# Generated at 2022-06-23 17:17:27.100807
# Unit test for function parse
def test_parse():
    assert repr(parse("")) == repr(
        Docstring(
            short_description=None,
            blank_after_short_description=True,
            blank_after_long_description=False,
            long_description=None,
            meta=list(),
        )
    )
    assert repr(parse("Description\n")) == repr(
        Docstring(
            short_description="Description",
            blank_after_short_description=False,
            blank_after_long_description=False,
            long_description=None,
            meta=list(),
        )
    )

# Generated at 2022-06-23 17:17:37.315190
# Unit test for function parse
def test_parse():
    param1 = DocstringParam(args=['param', 'str', 'name'], description='Name of the person.', arg_name='name', type_name='str', is_optional=False, default=None)
    param2 = DocstringParam(args=['param', 'int', 'age'], description='Age of the person in years.', arg_name='age', type_name='int', is_optional=False, default=None)
    param3 = DocstringParam(args=['param', 'Optional[str]', 'address'], description='Street address. Defaults to "123 Main St".', arg_name='address', type_name='Optional[str]', is_optional=True, default="\'123 Main St\'")

# Generated at 2022-06-23 17:17:47.173192
# Unit test for function parse
def test_parse():
    ts = parse.__doc__
    assert ts.short_description == "Parse the ReST-style docstring into its components."
    assert ":returns:" in ts.long_description
    assert ts.blank_after_short_description
    assert ts.blank_after_long_description
    assert ts.meta[0].arg_name == "text"
    assert ts.meta[0].type_name == "str"
    assert ts.meta[0].description == "The docstring to parse."
    assert ts.meta[0].default is None
    assert ts.meta[0].is_optional is False
    assert ts.meta[1].arg_name is None
    assert ts.meta[1].type_name is None
    assert ts.meta[1].description == "parsed docstring"

# Generated at 2022-06-23 17:17:52.908652
# Unit test for function parse
def test_parse(): 
    print(parse('Test for fit_transform.\n\n:type X: numpy array of shape [n_samples, n_features]\n:param X: Input data that will be transformed.\n:type y: array-like  of shape (n_samples,)\n:param y: Target values.\n:rtype: numpy array of shape [n_samples, n_components]\n:return: A copy of the input array with the features generated by PCA.\n:raises ValueError: if `y` is not None and has not the same length as `X`.\n:raises ValueError: if number of features (`n_features`) different from `len(X[0])`.\n'))


# Generated at 2022-06-23 17:18:04.459598
# Unit test for function parse

# Generated at 2022-06-23 17:18:12.892575
# Unit test for function parse
def test_parse():
    doc = """
    This is a docstring.

    This is the first paragraph of the long description.

    This is the second paragraph of the long description.

    :param arg: argument description
    :type arg: str
    :rtype: Optional[int]
    :returns: the return value description
    :raises TypeError: if bad things happen
    """
    assert parse(doc).short_description == "This is a docstring."
    assert parse(doc).long_description == """
This is the first paragraph of the long description.

This is the second paragraph of the long description.""".strip()
    assert parse(doc).blank_after_short_description
    assert parse(doc).blank_after_long_description

# Generated at 2022-06-23 17:18:21.609341
# Unit test for function parse
def test_parse():
    doc = '''
        :param foo: First argument
        :type foo: int
        :param bar: Second argument
        :param baz: Third argument
        :type baz: Optional[str]
        :raises: First Error
        :raise: Second Error
        :returns: Something
        :return: Something else
        :yield: A generator
        :yields: Another generator
        :yields int: Yet another generator
        :returns str: A string
    '''
    ds = parse(doc)
    assert ds.meta[0].arg_name == 'foo'
    assert ds.meta[0].type_name == 'int'
    assert ds.meta[0].key == 'param'
    assert ds.meta[1].arg_name == 'bar'

# Generated at 2022-06-23 17:18:32.382744
# Unit test for function parse
def test_parse():
    from .format import format
    from .format import __version__

    text = format(
        """
        Test function

        :param int a: A parameter
        :param b: A parameter with no type
        :rtype: str
        :returns: stuff
        :raises ValueError: if test fails
        :yields: stuff also
        :yield param int count: this yield param
        """,
        __version__
    )
    doc = parse(text)

    assert doc.short_description == "Test function"
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is True
    assert doc.long_description is None
    assert len(doc.meta) == 6

    assert doc.meta[0].args == ["param", "int", "a"]

# Generated at 2022-06-23 17:18:44.459923
# Unit test for function parse
def test_parse():
    def str_to_doc(s: str) -> Docstring:
        """
        Convert a docstring string to a docstring object.
        """
        return parse(s)

    assert str_to_doc("""
        Test if, when given a docstring string of a function,
        it can return a docstring object
        """
    ).short_description == "Test if, when given a docstring string of a function, it can return a docstring object"

    assert str_to_doc("""
        Test if, when given a docstring string of a function,
        it can return a docstring object
        """
    ).long_description == None


# Generated at 2022-06-23 17:18:55.272088
# Unit test for function parse
def test_parse():
    ret = Docstring()
    text = """\
        This is a long description.

        :param int a: This is some parameter.
        :param b: This is another parameter.
        :param str c: This is a third parameter.
        :return:
        :rtype:
        :returns:
        :rtype int:
        :yields:
        :yields int:
        :raises ValueError:
        :raises:
        :raises str:
        :raises ValueError "message":
        :raises ValueError "message": This is a raised ValueError.
        :raises MyError "message", defaults to "...": This is a raised MyError.
    """
    ret = parse(text)
    assert ret.short_description == "This is a long description."
    assert ret.blank_

# Generated at 2022-06-23 17:19:01.932474
# Unit test for function parse

# Generated at 2022-06-23 17:19:03.614669
# Unit test for function parse
def test_parse():
    assert parse.__doc__ == parse(parse.__doc__).short_description

# Generated at 2022-06-23 17:19:13.808309
# Unit test for function parse
def test_parse():
    """
    Test the parse function.
    """
    docstring = """
    Some function, which does something.

    :param arg1: The first argument.
                 Defaults to None.
    :param arg2: The second argument.
    :param arg3: The third argument.

    In the meta information you can start a new paragraph,
    which will be indented like this.

    :returns: The return value.
              Which has a second line.
    """
    doc = parse(docstring)
    assert doc.short_description == "Some function, which does something."
    assert (
        doc.long_description
        == "In the meta information you can start a new paragraph,\n"
        "which will be indented like this."
    )

    param_doc = doc.meta[0]

# Generated at 2022-06-23 17:19:21.811424
# Unit test for function parse
def test_parse():
    doc = """
    Short description of the function.

    Long description may be several lines.

    :param arg1: Description of arg1.
    :type arg1: str|int|float
    :param arg2: Description of arg2.
    :type arg2: str
    :return: Description of the return value.
    :rtype: int

    """

    print("parse function")
    print("parsed: ", parse(doc))
    print("parsed: ", parse(""))

# Generated at 2022-06-23 17:19:31.208665
# Unit test for function parse
def test_parse():
    # test empty docstring
    assert parse('') == Docstring()

    # test short description is correct
    docstr = """One line."""
    assert parse(docstr).short_description == "One line."
    
    # test absence of long description
    docstr = """One line.

    """
    assert parse(docstr).long_description == None

    # test long description
    docstr = """One line.

    Two
    lines.

    """
    assert parse(docstr).long_description == "Two\nlines."

    # test absence of blank after short description
    docstr = """One line.

    Two
    lines.

    """
    assert parse(docstr).blank_after_short_description == False

    # test absence of blank after long description

# Generated at 2022-06-23 17:19:35.052147
# Unit test for function parse
def test_parse():
    s = '''
    Short description.
    Long description.

    :param arg1: argument 1
    :param arg2: argument 2
    :returns: something
    :raises: KeyError
    '''
    print(parse(s))

# Generated at 2022-06-23 17:19:42.607602
# Unit test for function parse
def test_parse():
    # parse
    docstring = """Short summary.

Long summary.

:param b: parameter
:param a: parameter and :func:`function <some.function>`
:param c: one more parameter
:type c: str
:returns: the result
:rtype: int
:raises: exc1, exc2
"""
    res = parse(docstring)
    assert len(res.meta) == 3
    param = res.meta[0]
    assert isinstance(param, DocstringParam)
    assert param.arg_name == "b"
    assert param.description == "parameter"
    param = res.meta[1]
    assert isinstance(param, DocstringParam)
    assert param.arg_name == "a"

# Generated at 2022-06-23 17:19:50.792602
# Unit test for function parse
def test_parse():
    text = """\
        Test parse function.

        :param str a: Test a
        :param str b: Test b
        :return: Test return
    """
    result = parse(text)
    text = (
        "Test parse function.\n"
        "\n"
        ":param str a: Test a\n"
        ":param str b: Test b\n"
        ":return: Test return"
    )
    assert result.dump() == text



# Generated at 2022-06-23 17:19:58.806886
# Unit test for function parse
def test_parse():
    from .common import Docstring
    import inspect
    import os

    cur_dir = os.path.dirname(__file__)
    cur_file = os.path.basename(__file__)

    with open(os.path.join(cur_dir, cur_file), "r") as f:
        content = f.read()
        docstring = inspect.getdoc(test_parse)

# Generated at 2022-06-23 17:20:09.627683
# Unit test for function parse
def test_parse():
    docstring = '''
    Short summary line.

    Long description line.

    :param arg1: description of parameter arg1
    :type arg1: int or str

    :param arg2: description of parameter arg2
    :type arg2: int or str

    :returns: description of return value
    :rtype: int or str

    :raises: ValueError, KeyError
    :raises: TypeError
    '''
    ret = parse(docstring)
    assert ret.short_description == "Short summary line."
    assert ret.long_description == "Long description line."

    # :param
    meta = ret.meta[0]
    assert meta.args == ["param", "arg1"]
    assert meta.description == "description of parameter arg1"
    assert meta.type_name == "int or str"



# Generated at 2022-06-23 17:20:18.605195
# Unit test for function parse
def test_parse():
    """Test function parse"""
    text = """
    A short description.

    A long description.

    :param  arg1: Any argument 1
    :param  arg2: (int) argument 2
    :param  arg3: (str) argument 3
    :yields: (str) yields str
    :returns: (str) returns str
    :raises: (Exception) raises Exception
    """
    doc = parse(text)
    assert doc.short_description == "A short description."
    assert doc.long_description == "A long description."
    assert len(doc.meta) == 4
    assert doc.meta[0] == DocstringParam(
        ["param", "arg1", "Any"],
        "argument 1",
        "arg1",
        "Any",
        False,
        None,
    )


# Generated at 2022-06-23 17:20:29.756345
# Unit test for function parse
def test_parse():
    def f():
        """
        f()

        :param a: this is a
        :return:
        """
        pass

    print(parse(f.__doc__))
    def f():
        """
        f()

        :param a: this is a
        :yields:
        """
        pass

    print(parse(f.__doc__))
    def f():
        """
        f()

        :param a: this is a
        :param b: this is b
        :return:
        """
        pass

    print(parse(f.__doc__))
    def f():
        """
        f()

        :param a: this is a
        :defaults to a:
        :return:
        """
        pass

    print(parse(f.__doc__))

# Generated at 2022-06-23 17:20:32.712117
# Unit test for function parse
def test_parse():
    # Test parse.
    print(parse(text))

    # Test parse.
    print(parse(text1))

# Test if function parse parse the docstring correctly if it is None.

# Generated at 2022-06-23 17:20:42.052967
# Unit test for function parse
def test_parse():

    docstring = r"""Return the sum of the two arguments.
    Args:
        arg_1 (int): First argument.
        arg_2 (int): Second argument.
    Returns:
        int: The sum of the arguments.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Return the sum of the two arguments."
    assert parsed.long_description == "Args:\n" \
                                      "    arg_1 (int): First argument.\n" \
                                      "    arg_2 (int): Second argument.\n" \
                                      "Returns:\n" \
                                      "    int: The sum of the arguments."
    assert parsed.blank_after_long_description
    assert parsed.blank_after_short_description
    assert len(parsed.meta) == 2
    assert parsed

# Generated at 2022-06-23 17:20:53.881563
# Unit test for function parse
def test_parse():
    """Run unit test for function parse.
    """
    assert parse("foo") == Docstring(
        short_description="foo",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    assert parse("foo\nbar\n") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="bar",
        meta=[],
    )

# Generated at 2022-06-23 17:21:01.844269
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""


# Generated at 2022-06-23 17:21:06.224219
# Unit test for function parse
def test_parse():
    text = """
    Parse the ReST-style docstring into its components.

    :param x: A parameter.
    :type x: int
    :param y: A parameter.
    :type x: int
    :returns: parsed docstring
    """
    assert parse(text)

# Generated at 2022-06-23 17:21:16.753572
# Unit test for function parse
def test_parse():
    # empty docstring
    text = ""
    ret = parse(text)
    assert ret.short_description is None
    assert ret.long_description is None
    assert ret.blank_after_short_description is None
    assert ret.blank_after_long_description is None
    assert ret.meta == []

    # short only
    text = "Test short only."
    ret = parse(text)
    assert ret.short_description == "Test short only."
    assert ret.long_description is None
    assert ret.blank_after_short_description is None
    assert ret.blank_after_long_description is None
    assert ret.meta == []

    # longer docstring
    text = """
    Test longer docstring.

    This is a test.
    """
    ret = parse(text)
    assert ret.short_

# Generated at 2022-06-23 17:21:22.743084
# Unit test for function parse
def test_parse():
    # TODO: Add more tests

    d = parse(__doc__)
    assert d.short_description == "ReST-style docstring parsing."
    assert len(d.meta) == 1
    assert d.meta[0].args == ["param", "text", "str"]
    assert d.meta[0].description == "ReST-style docstring to parse"


# Generated at 2022-06-23 17:21:29.542222
# Unit test for function parse
def test_parse():
    text = '''
    Blah blah blah
    :param name: Name
    :type name: str
    :param age: Age
    '''
    text2 = '''
    Blah blah blah
    :param name: Name
    :type name: str
    :param age: Age
    :return: age?

    :returns: age
    '''
    result = parse(text)
    result2 = parse(text2)
    print(result.short_description)
    print(result.blank_after_short_description)
    print(result.long_description)
    print(result.blank_after_long_description)
    print(result.meta)
    print("Result2:")
    print(result2.short_description)
    print(result2.blank_after_short_description)
    print

# Generated at 2022-06-23 17:21:40.958859
# Unit test for function parse
def test_parse():
    """
    >>> a = parse("""

# Generated at 2022-06-23 17:21:47.401852
# Unit test for function parse
def test_parse():
    if __name__ == '__main__':
        text="""
        short description

        long description

        :param arg1: this is the first argument
        :param arg2: this is a second argument

        :raises AttributeError: if arg2 is not given
        :raises KeyError: if arg1 is not given

        :returns: the return value

        :returns: the return value
        """
        parsed = parse(text)
        print(parsed)

# Generated at 2022-06-23 17:21:57.665581
# Unit test for function parse
def test_parse():
    code = """
    This is an example of a function which takes an optional parameter and
    returns a value.

    :param x: This parameter represents the x coordinate of the point.

    :param y: This parameter represents the y coordinate of the point.
    """
    out = parse(code)
    assert isinstance(out, Docstring)
    assert out.short_description == "This is an example of a function which takes an optional parameter and returns a value."
    assert out.long_description == "This parameter represents the y coordinate of the point."
    assert out.blank_after_short_description == False
    assert out.blank_after_long_description == False
    assert isinstance(out.meta[0], DocstringParam)
    assert out.meta[0].arg_name == "x"

# Generated at 2022-06-23 17:22:05.104230
# Unit test for function parse
def test_parse():
    docstring = parse("""\
    Short description.

    Long description.

    :returns: description
    :rtype: string
    """)
    print(docstring)

    docstring = parse("""\
    Short description.

    :param arg1: description
    :type arg1: string
    :param arg2: description
    :type arg2: string
    :return: description
    :rtype: string
    """)
    print(docstring)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:22:15.859803
# Unit test for function parse
def test_parse():
    docstring = parse(
        """
        This is a test.

        :param arg1: This is a parameter.
        :param arg2: This is another parameter.
        :type arg2: int
        :returns: None
        :raises AttributeError: if something bad happens.
        """
    )
    assert docstring.short_description == "This is a test."

    assert docstring.long_description == "This is a test."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description

    assert len(docstring.meta) == 4

    m = docstring.meta[0]
    assert m.key == "param"
    assert m.type_name is None
    assert m.arg_name == "arg1"

# Generated at 2022-06-23 17:22:22.995945
# Unit test for function parse
def test_parse():
    def foo(a: str, b: int = 0, c=None):  # noqa
        """Short description.

        Long description of foo.

        :param a: Explanation of parameter a.
        :type a: str
        :param b: (Optional) Explanation of parameter b.
        :type b: int, defaults to 0.
        :param c: (Optional) Explanation of parameter c. Default: 'None'.
        :type c: str
        :yields: Explanation of the first value.
        :rtype: str
        :raises ValueError: If a conversion fails.

        """
        pass

    ds = parse(foo.__doc__)
    assert ds.short_description == "Short description."
    assert ds.blank_after_short_description is True
    assert ds.long_description

# Generated at 2022-06-23 17:22:29.107824
# Unit test for function parse
def test_parse():
    s = """
    Test Parse

    :param int a: Test 1
    :param int b
    :param string c
    :param string? d
    :param string e: Test 2
    :param string? f: Test 3
    :param string? g: Test 4
    :param int h: Test 5
    :param int? i: Test 6
    :param int? j: Test 7

    :returns: Test 8
    :rtype: int
    :returns int: Test 9
    :rtype string: Test 10
    :returns string? k: Test 11
    :rtype string? l: Test 12
    """
    print(parse(s))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:22:38.598628
# Unit test for function parse
def test_parse():
    s = """
    This is a very simple function.

    :param x: some integer
    :type x: int
    :param y: some other integer
    :type y: int
    :param z: some optional integer
    :type z: int?
    :return: sum of all numbers
    :rtype: int"""

# Generated at 2022-06-23 17:22:47.928934
# Unit test for function parse
def test_parse():
    assert (
        parse('"This is a test docstring for parse."') ==
        Docstring(
            short_description="This is a test docstring for parse.",
            blank_after_short_description=False,
            long_description=None,
            blank_after_long_description=False,
            meta=[],
        )
    )
    assert (
        parse('"This is a test docstring for parse.\n\n\tThis is the long desc."')
        ==
        Docstring(
            short_description="This is a test docstring for parse.",
            blank_after_short_description=True,
            long_description="This is the long desc.",
            blank_after_long_description=False,
            meta=[],
        )
    )

    # Test for void return type

# Generated at 2022-06-23 17:22:56.566136
# Unit test for function parse
def test_parse():
    test_str = """
    Function summary line.
    line 2.

    :param x: type: int
        Line 1.
        Line 2.

    :param y: type: int
        Line 1.
        Line 2.
    """
    x = parse(test_str)
    assert len(x.meta) == 2
    assert x.meta[0].args == ["param", "x", "type: int"]
    assert x.meta[0].description == "Line 1.\nLine 2."
    assert x.meta[1].args == ["param", "y", "type: int"]
    assert x.meta[1].description == "Line 1.\nLine 2."

# Generated at 2022-06-23 17:23:07.690892
# Unit test for function parse
def test_parse():
    """
    This docstring tests parse method
    Args:
        x (int): An integer

    Returns:
        bool
    """
    docstring_text = "This docstring tests parse method\n\nArgs:\n    x (int): An integer\n\nReturns:\n    bool\n"
    docstring = parse(docstring_text)

# Generated at 2022-06-23 17:23:18.223413
# Unit test for function parse
def test_parse():
    """Test the docstring parse function"""

# Generated at 2022-06-23 17:23:30.053469
# Unit test for function parse
def test_parse():
    """Function that tests the parse function"""
    assert parse("") == Docstring()
    assert parse("hello") == Docstring(
        short_description="hello", long_description=None
    )
    assert parse("hello\nworld") == Docstring(
        short_description="hello",
        long_description="world",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert parse("hello\n\nworld") == Docstring(
        short_description="hello",
        long_description="world",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

# Generated at 2022-06-23 17:23:38.153810
# Unit test for function parse
def test_parse():
    # Tests for docstring comments with description and metadata
    assert(parse("Return value n! (1 * 2 * ... * n).") == Docstring(
        short_description='Return value n! (1 * 2 * ... * n).',
        long_description=None,
        meta=[],
        blank_after_short_description=False,
        blank_after_long_description=False,
    ))

    assert(parse("Return value n! (1 * 2 * ... * n).\n") == Docstring(
        short_description='Return value n! (1 * 2 * ... * n).',
        long_description=None,
        meta=[],
        blank_after_short_description=False,
        blank_after_long_description=True,
    ))


# Generated at 2022-06-23 17:23:41.121785
# Unit test for function parse
def test_parse():
    docstring = '''Makes a GET request to /posts/1.
    :rtype: int
    :returns: The key_id of the value
    :raises ValueError: If value is not integer
    '''
    parse(docstring)

# Generated at 2022-06-23 17:23:50.354140
# Unit test for function parse
def test_parse():
    # Parse single-line docstring
    assert parse("Single-line docstring").short_description == "Single-line docstring"

    # Parse multi-line docstring
    docstring = parse("""
        The first sentence.

        The rest of the docstring.
    """)

    assert docstring.short_description == "The first sentence."
    assert docstring.long_description == "The rest of the docstring."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description

    # Parse docstring with parameters

# Generated at 2022-06-23 17:23:57.272181
# Unit test for function parse
def test_parse():

    text = '''
    This is a test function.

    :param x:
    :returns:
    '''
    result = parse(text)
    assert type(result) == Docstring
    assert result.short_description == 'This is a test function.'
    assert len(result.meta) == 2
    assert result.meta[0].arg_name == 'x'
    assert result.meta[1].is_generator == False

# Generated at 2022-06-23 17:24:08.699866
# Unit test for function parse
def test_parse():
    test1 = """
    This is a test doc string.

    :param int variable: variable description
    :return: return description
    :param variable2: variable2 description, defaults to "default".
    :raises Exception: exception description
    :yields: yields description
    :rtype: string
    """
    docstring = parse(test1)
    assert docstring.short_description == "This is a test doc string."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.long_description == "None"

    assert len(docstring.meta) == 4
    assert isinstance(docstring.meta[0], DocstringParam)
    assert docstring.meta[0].type_name == "int"
    assert docstring.meta[0].arg_

# Generated at 2022-06-23 17:24:17.821548
# Unit test for function parse
def test_parse():
    d = parse("hi")
    assert d.short_description == "hi"
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert len(d.meta) == 0

    d = parse('"hi"')
    assert d.short_description == '"hi"'
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert len(d.meta) == 0

    d = parse("hi\n")
    assert d.short_description == "hi"
    assert d.long_description is None
    assert d.blank_after_short_description is True

# Generated at 2022-06-23 17:24:23.563691
# Unit test for function parse
def test_parse():

    # Test basic structure
    # TODO
    assert False

    # Test parameter extraction
    # TODO
    assert False

    # Test return extraction
    # TODO
    assert False

    # Test raise/er extraction
    # TODO
    assert False

    # Test that errors are raised
    # TODO
    assert False

# Generated at 2022-06-23 17:24:35.373334
# Unit test for function parse
def test_parse():
    doc = parse("\nShort summary.\n\nLong description.\n")
    assert doc.short_description == 'Short summary.'
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == True
    assert doc.long_description == 'Long description.'
    doc = parse("\nShort summary.\nLong description.\n")
    assert doc.short_description == 'Short summary.'
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.long_description == 'Long description.'
    doc = parse("\nShort summary.\n\n\nLong description.\n")
    assert doc.short_description == 'Short summary.'
    assert doc.blank_after_short_description == True
   

# Generated at 2022-06-23 17:24:46.124779
# Unit test for function parse
def test_parse():
    parse_result = parse('this is a short description\n\nthis is a long description.\n\n'
                         + ':param name: this is a short parameter description.\n'
                         + 'this is a long parameter description.\n'
                         + 'this is a long parameter description.\n\n'
                         + ':param str type: type\n'
                         + ':returns: this is a short return description.\n'
                         + ':raises Exception: this is a short raise description.\n'
                         + ':raises ValueError: this is a short raise description.\n'
                         + ':yields: this is a short yield description.\n')
    print(parse_result)
    assert parse_result.short_description == 'this is a short description'
    assert parse_result.blank_

# Generated at 2022-06-23 17:24:56.911699
# Unit test for function parse
def test_parse():
    txt = "Hi, hello\n\n:returns: the best\n:rtype: str\n\n" + \
          "Goodbye\n\n:returns: the worst\n:rtype: int\n\n"
    result = parse(txt)
    assert result.short_description == "Hi, hello"
    assert result.long_description == "Goodbye"
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert len(result.meta) == 2
    assert result.meta[0].args == ["returns", "the best"]
    assert result.meta[0].description == "the best"
    assert result.meta[0].type_name == "str"

# Generated at 2022-06-23 17:25:02.545403
# Unit test for function parse
def test_parse():
    input_string = """unit test for function parse

    :param int a: first parameter
    :param float b: second parameter
    :param str c: third parameter
    :param anything else: this the else case, if else is provided
    :returns: Unit test success or failure
    """
    parse_string = parse(input_string)
    print(parse_string.__dict__)
    assert parse_string.__dict__ == {}

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:25:14.092979
# Unit test for function parse
def test_parse():
    test_docstring = """\
        Single-line short description.

        Full
        multi-line
        long description.
        
        """
    test_obj = parse(test_docstring)
    assert test_obj.short_description == "Single-line short description."
    assert test_obj.blank_after_short_description == False
    assert test_obj.long_description == "Full\nmulti-line\nlong description."
    assert test_obj.blank_after_long_description == False
    assert len(test_obj.meta) == 0

    test_docstring = """\
        Single-line short description.


        Full
        multi-line
        long description.
        
        """
    test_obj = parse(test_docstring)

# Generated at 2022-06-23 17:25:25.645409
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description. It can be long, and span multiple lines.

    :param str name: The name of the person.
    :param bool is_male: If the person is a male.
    :param int age: The age of the person. Optional, defaults to 18.
    :param friends: The list of friends.
    :type friends: List[Person]
    :returns: The number of friends.
    :rtype: int
    :raises ValueError: If `name` is the empty string.
    """

# Generated at 2022-06-23 17:25:33.899841
# Unit test for function parse
def test_parse():
    import docstring_parser
    docstring = docstring_parser.parse('Test docstring\n:param arg1: param arg1\n:param arg2: param arg2\n:returns: return_value\n:raises Exception: Exception')
    print('docstring:',docstring,'\n')
    #docstring:
    #<docstring_parser.common.Docstring object at 0x7efdeeb9a9b0>
    print('docstring.short_description:',docstring.short_description,'\n')
    #docstring.short_description: Test docstring
    print('docstring.long_description:',docstring.long_description,'\n')
    #docstring.long_description: None

# Generated at 2022-06-23 17:25:43.441570
# Unit test for function parse
def test_parse():
    import typing
    import hypothesis.strategies as st
    import plumbum.cli.testing as cli_testing
    from hypothesis import given
    from .testing import test_parse as base_test_parse


# Generated at 2022-06-23 17:25:51.072494
# Unit test for function parse
def test_parse():
    docstring = """A very short description.

    A longer description of the function which can run
    to multiple lines.

    :param arg_1: First argument.
    :param arg_2: Second argument.
    :rtype: int
    :returns: The number of items processed.
    """
    print(parse(docstring))

# Unit tests for class Docstring

# Generated at 2022-06-23 17:25:55.797572
# Unit test for function parse
def test_parse():
    docstring = parse.__doc__
    assert docstring.short_description == "Parse the ReST-style docstring into its components."
    assert docstring.blank_after_short_description == True
    assert docstring.long_description.startswith("\n\n.. code-block:: python")
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["returns:"]
    assert docstring.meta[0].description.startswith("parsed docstring")

# Generated at 2022-06-23 17:26:06.729584
# Unit test for function parse

# Generated at 2022-06-23 17:26:16.140971
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    docstring = inspect.cleandoc(
        """
            This is a short description.

            This is a long description.
            This is a long description.
            This is a long description.

            :param int bar:
                This is a param description.
                This is a param description.

            :param int foo: This is a param description.

            :param int baz: This is a param description.
                This is a param description.
        """
    )

    result = parse(docstring)

    assert len(result.meta) == 3
    assert result.meta[0].arg_name == "bar"
    assert result.meta[0].is_optional == False
    assert result.meta[1].arg_name == "foo"
    assert result.meta[1].is_optional == False


# Generated at 2022-06-23 17:26:27.466301
# Unit test for function parse
def test_parse():
    text = """This is a short description.

    This is a long description.

    :param arg1: this is the first parameter
    :type arg1: int
    :param arg2: this is the second parameter
    :type arg2: str, optional
    :param arg3: this is the third parameter
    :type arg3: dict, optional
    :returns: xxx
    :rtype: int
    :return: yyy
    :raises ValueError: if the value is incorrect
    """
    doc = parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.blank_after_short_description is True
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_long_description is False