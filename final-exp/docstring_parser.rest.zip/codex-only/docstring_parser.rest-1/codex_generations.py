

# Generated at 2022-06-23 17:16:33.368302
# Unit test for function parse
def test_parse():
    text = """
    parse the ReST-style docstring into its components.

    :param arg1:
    :type arg1:
    :param arg2:
    :type arg2:

    :returns: parsed docstring

    :raises Exception: not found

    :returns: parsed docstring 2

    :rtype: parsed docstring 2

    :param arg3:
    :type arg3:
    :type arg4:
    :returns: parsed docstring 3

    :raises Exception: not found 2

    :raises Exception: not found 3
    """
    output = parse(text)
    assert output.short_description == "parse the ReST-style docstring into its components."
    assert len(output.meta) == 9
    assert output.meta[0].arg_name == "arg1"

# Generated at 2022-06-23 17:16:43.690744
# Unit test for function parse
def test_parse():
    docstring = "One line short description.\n\nOne line long description."
    assert str(parse(docstring))== str(Docstring(short_description='One line short description.', blank_after_short_description=False, long_description='One line long description.', blank_after_long_description=False, meta=[]))

# Generated at 2022-06-23 17:16:49.876844
# Unit test for function parse
def test_parse():
    def case(txt: str, expected: T.Any) -> None:
        actual = parse(txt)
        assert actual == expected
        assert parse(str(actual)).meta == actual.meta

    case(
        """\
        Short description
        """,
        Docstring(short_description="Short description"),
    )
    case(
        """\
        Short
        description
        """,
        Docstring(
            short_description="Short",
            long_description="description",
            blank_after_short_description=False,
            blank_after_long_description=False,
        ),
    )

# Generated at 2022-06-23 17:17:01.255612
# Unit test for function parse
def test_parse():
    text = """
    This is the short description.

    This is the long description.

    Args:
        a (str): This is a.
        b (int): This is b.

    Returns:
        str: This is the return value.

    Raises:
        ValueError: If something wrong happens.
    """
    ret = Docstring()
    ret.short_description = "This is the short description."
    ret.blank_after_short_description = False
    ret.long_description = "This is the long description."
    ret.blank_after_long_description = True

# Generated at 2022-06-23 17:17:12.170832
# Unit test for function parse
def test_parse():
    text = """
    Parse the ReST-style docstring into its components.

    This function uses regexes to parse the docstring into its
    components.  Consider using a real ReST parser if speed
    is an issue.

    :param text: The text of the docstring to parse.
    :param cached: If True, do not parse but only return the cached
        docstring from the previous call to this function.
    :returns: parsed docstring
    """

    p = parse(text)
    assert p.short_description == "Parse the ReST-style docstring into its components."
    assert p.long_description == "This function uses regexes to parse the docstring into its\ncomponents.  Consider using a real ReST parser if speed\nis an issue."
    assert p.blank_after_short_description is True

# Generated at 2022-06-23 17:17:19.766184
# Unit test for function parse
def test_parse():
    def func_with_docstring(param1):
        """Function with a docstring.

        This function should demonstrate that the parsed output of a docstring
        is correct.

        :param param1:
            First parameter.
        :type param1:
            int
        :returns:
            Some return value.
        :rtype:
            str

        """


# Generated at 2022-06-23 17:17:25.416352
# Unit test for function parse
def test_parse():
    docstring = """this is a function
    :param int tt: 3
    :returns: int
    """
    assert parse(docstring).short_description == "this is a function"
    assert parse(docstring).meta[0].args[0] == "param"
    assert parse(docstring).meta[1].args[0] == "returns"


# Generated at 2022-06-23 17:17:35.843589
# Unit test for function parse

# Generated at 2022-06-23 17:17:46.213280
# Unit test for function parse

# Generated at 2022-06-23 17:17:52.487319
# Unit test for function parse
def test_parse():
    s = """
    Short description.

    Long description.

    :param y: The Y parameter.
    :type y: int
    :param z: The Z parameter.
    :type z: str
    :returns: no return value
    :rtype: None
    """
    result = parse(s)
    assert result.short_description == "Short description."
    assert result.long_description == "Long description."
    assert result.meta[0].arg_name == "y"
    assert result.meta[0].type_name == "int"
    assert result.meta[1].arg_name == "z"
    assert result.meta[1].type_name == "str"
    assert result.meta[2].type_name == "None"

# Generated at 2022-06-23 17:17:59.934596
# Unit test for function parse
def test_parse():
    import pytest
    from docstrings import parse as dparse
    docstring = """ """
    ds = dparse(docstring)
    assert ds.short_description == None, "Short description should be None"
    assert ds.long_description == None, "Long description should be None"
    assert ds.blank_after_short_description == False, "blank after short description should be False"
    assert ds.blank_after_long_description == False, "blank after long description should be False"
    assert not ds.meta, "meta should be empty"

    docstring = """
    """
    ds = dparse(docstring)
    assert ds.short_description == None, "Short description should be None"
    assert ds.long_description == None, "Long description should be None"

# Generated at 2022-06-23 17:18:10.506488
# Unit test for function parse
def test_parse():
    from pathlib import Path
    from .test_parsers import test_file_to_docstring as tfd
    from .test_parsers import TEST_DATA_DIR

    for language in ["python", "julia", "php", "fortran", "c"]:
        fname = TEST_DATA_DIR / language / "parse_test.py"
        test_str = Path(fname).read_text()
        if language == 'python':
            ds = parse(test_str)
            assert tfd(test_str) == ds
        if language == 'julia':
            # ds = parse_julia(test_str)
            # assert tfd(test_str) == ds
            pass

# Generated at 2022-06-23 17:18:20.014188
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    This is a longer description.
    """
    print(inspect.cleandoc(text))
    print(parse(text))
    print("\n")
    
    text = """
    Short description.

    This is a longer description.

    :param arg1: foo
    :type arg1: str
    :param arg2: bar
    :type arg2: int
    """
    print(inspect.cleandoc(text))
    print(parse(text))
    print("\n")
    
    text = """
    Short description.

    This is a longer description.

    :return: the answer
    :rtype: int
    """
    print(inspect.cleandoc(text))
    print(parse(text))
    print("\n")
    


# Generated at 2022-06-23 17:18:29.140210
# Unit test for function parse
def test_parse():
    docstring = "This is a function with a docstring.\n:param int x: The x coordinate.\n:param int y: The y coordinate.\n:returns: None\n:raises ValueError: If x is negative, or y is negative."
    parsed_docstring = parse(docstring)
    print(parsed_docstring.short_description)
    print(parsed_docstring.long_description)
    for meta in parsed_docstring.meta:
        print(meta.args, meta.description)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:18:31.809174
# Unit test for function parse
def test_parse():
    """Test parse."""
    print(parse("""
    Yields the next output.

    :rtype: int
    :yields int: the next output
    """))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:18:32.926422
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()



# Generated at 2022-06-23 17:18:35.063893
# Unit test for function parse
def test_parse():
    #Tests if function is defined
    assert callable(parse)



# Generated at 2022-06-23 17:18:46.037279
# Unit test for function parse
def test_parse():
    m = inspect.ModuleSpec("test", None)
    m.__doc__ = """\
            Short description.

            Long description.

            :param arg1:
                This is the first argument.

            :param int arg2:
                This is the second argument.

            :returns:
                This function returns something.

            :returns: int
                This function returns an integer.

            :raises Exception:
                This function can raise an exception.

            :raises TypeError:
                This function raises a type error.

            """

# Generated at 2022-06-23 17:18:57.506497
# Unit test for function parse

# Generated at 2022-06-23 17:19:09.581699
# Unit test for function parse
def test_parse():
    assert parse("") == \
        Docstring(
            short_description=None,
            long_description=None,
            blank_after_short_description=False,
            blank_after_long_description=False,
            meta=[],
        )

    assert parse("Short description.") == \
        Docstring(
            short_description="Short description.",
            long_description=None,
            blank_after_short_description=False,
            blank_after_long_description=False,
            meta=[],
        )

    assert parse("Short description\n\nLong description.") == \
        Docstring(
            short_description="Short description",
            long_description="Long description.",
            blank_after_short_description=True,
            blank_after_long_description=False,
            meta=[],
        )

    assert parse

# Generated at 2022-06-23 17:19:17.924437
# Unit test for function parse
def test_parse():
    assert parse('') == parse.__annotations__['return']()
    assert parse('Short') == parse.__annotations__['return']('Short', None)
    assert parse('Short\nLong') == parse.__annotations__['return'](
        'Short', 'Long')
    assert parse('Short\n\nLong') == parse.__annotations__['return'](
        'Short', '\nLong')
    assert parse(':param arg: arg description') == parse.__annotations__['return'](
        '', None, [parse.DocstringParam(
            ['param', 'arg', 'arg'], 'arg description')])

# Generated at 2022-06-23 17:19:22.106356
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    # Short description only
    assert parse("hello") == Docstring(
        short_description="hello", blank_after_short_description=True
    )
    assert parse("hello\n") == Docstring(
        short_description="hello", blank_after_short_description=True
    )
    assert parse("hello\nthere") == Docstring(
        short_description="hello",
        blank_after_short_description=True,
        long_description="there",
        blank_after_long_description=False,
    )

# Generated at 2022-06-23 17:19:33.962047
# Unit test for function parse
def test_parse():
    from .common import Docstring
    from .common import DocstringMeta
    from .common import DocstringParam
    from .common import DocstringRaises
    from .common import DocstringReturns
    from .common import ParseError
    from .common import RETURNS_KEYWORDS
    from .common import RAISES_KEYWORDS


# Generated at 2022-06-23 17:19:42.255484
# Unit test for function parse
def test_parse():
    text = """Docstring for a sample function.

:param arg1: the first parameter
:param int arg2: the second parameter
:param type arg3: the third parameter
:type arg4: the fourth parameter
:raises KeyError: when a key is not found
:returns: Description of what is returned
:rtype: int

:Example:
    In this first example, we show how to
    perform an operation.

.. code-block:: python

    print('hello world')

In this second example, we show how to
perform another operation.

.. code-block:: python

    print('goodbye')

Returns:
    Description of what is returned
"""
    result = parse(text)
    assert result.short_description == "Docstring for a sample function."
    assert result.blank_after_short_description


# Generated at 2022-06-23 17:19:54.459705
# Unit test for function parse

# Generated at 2022-06-23 17:20:06.329876
# Unit test for function parse
def test_parse():
    t = """\
    short description
    long description

    :param arg1: description 1
    :type arg1: str
    :param arg2: description 2 with
        two lines

    :return: return_1
    :rtype: int
    :raises ValueError: always raises an error
    """

    ds = parse(t)

    assert ds.short_description == "short description"
    assert ds.long_description == "long description"
    assert ds.blank_after_short_description
    assert ds.blank_after_long_description
    assert len(ds.meta) == 3

    assert str(ds.meta[0]) == "param arg1: description 1 (type: str)"
    assert str(ds.meta[1]) == "return: return_1 (type: int)"
    assert str

# Generated at 2022-06-23 17:20:16.506269
# Unit test for function parse
def test_parse():
    doc_string = """
    Short description.
    
    This is a longer description.
    
    :param fruit: name of a fruit
    :type fruit: str
    :return: fruit name
    :rtype: str
    :example:
    >>> x = "apple"
    """
    doc = parse(doc_string)
    assert doc.short_description == "Short description."
    assert doc.long_description == "This is a longer description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].arg_name == "fruit"
    assert doc.meta[0].type_name == "str"
    assert doc.meta[0].description == "name of a fruit"

# Generated at 2022-06-23 17:20:27.693267
# Unit test for function parse
def test_parse():
    fn = parse(
        '''
        Example usage::
            >>> foo = bar()
            >>> foo.baz()
        '''
    )
    assert fn.short_description == "Example usage:"
    assert fn.long_description == "::\n    >>> foo = bar()\n    >>> foo.baz()"
    assert fn.blank_after_short_description
    assert fn.blank_after_long_description
    assert len(fn.meta) == 0

    fn = parse("")
    assert fn.short_description is None
    assert fn.long_description is None
    assert not fn.blank_after_short_description
    assert not fn.blank_after_long_description
    assert len(fn.meta) == 0


# Generated at 2022-06-23 17:20:38.166110
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse(" \n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n   \n") == Docstring()
    assert parse("\n  \n ") == Docstring()

    assert parse("one").short_description == "one"
    assert parse("one").long_description is None
    assert parse("one\n").short_description == "one"
    assert parse("one\n  \n").short_description == "one"
    assert parse("one\n  \n").long_description is None
    assert parse("one\n  \n\n ").short_description == "one"
    assert parse("one\n  \n\n ").long_description is None



# Generated at 2022-06-23 17:20:42.528352
# Unit test for function parse

# Generated at 2022-06-23 17:20:53.967772
# Unit test for function parse
def test_parse():
    docstring = '''short description.

Long description of my function.

:param int x: parameter x.
:param str y: parameter y.
:param bool z: parameter z.
:returns: None

:raises ValueError: if something goes wrong.
'''


# Generated at 2022-06-23 17:21:02.112898
# Unit test for function parse
def test_parse():
    """
    A function to test parse function
    """
    assert parse("""\
This is a short description of something

    This is another paragraph
    as part of the long description.
    """) == Docstring(
        short_description="This is a short description of something",
        blank_after_short_description=False,
        long_description="This is another paragraph\nas part of the long description.",
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-23 17:21:13.781667
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc("""
    This is a sample docstring.

    Parameters
    ----------
    x: int
       This is the x parameter.

    y: float
       This is the y parameter.
    """)
    result = parse(docstring)
    assert result.short_description == "This is a sample docstring."
    assert result.long_description == """
    This is a sample docstring.
    """
    assert result.meta[0].args == ["int", "x"]
    assert result.meta[1].args == ["float", "y"]
    assert result.meta[0].arg_name == "x"
    assert result.meta[1].arg_name == "y"
    assert result.meta[0].description == "This is the x parameter."
    assert result.meta[1].description

# Generated at 2022-06-23 17:21:21.916063
# Unit test for function parse
def test_parse():
    docstring = parse("Single line description")
    assert docstring.short_description == "Single line description"
    assert docstring.blank_after_short_description == False
    assert docstring.long_description == None
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 0

    docstring = parse("Single line description\n")
    assert docstring.short_description == "Single line description"
    assert docstring.blank_after_short_description == True
    assert docstring.long_description == None
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 0

    docstring = parse("Single line description\n\n")
    assert docstring.short_description == "Single line description"
    assert docstring.blank_after_

# Generated at 2022-06-23 17:21:29.174801
# Unit test for function parse
def test_parse():
    docstring = '''
    Short description.

    Long description.
    '''
    docstring = Docstring(
        short_description='Short description.',
        long_description='Long description.',
    )

    docstring = parse(docstring)
    assert docstring.short_description == 'Short description.'
    assert docstring.long_description == 'Long description.'
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []




    docstring = '''
    Short description.

    Long description.

    :param x: a parameter
    '''

# Generated at 2022-06-23 17:21:38.548934
# Unit test for function parse
def test_parse():
    def function():
        """A nice introductory sentence.
        
        This is a longer description.

        :param arg1: description of arg1
        :param arg2: description of arg2
        :param arg3: optional arg3, defaults to zero.
        :return: description of return value, with a long line that should be broken.
        :raises ValueError: if something goes wrong.
        """
        pass

    docstring = parse(function.__doc__)
    print(docstring)
    print(docstring.is_valid())
    assert docstring.is_valid()


# Generated at 2022-06-23 17:21:45.888280
# Unit test for function parse
def test_parse():
    """Test the parse function."""
    docstring = "A short description.\n\n"
    docstring += "And now a longer description.\n"
    docstring += "Which can continue for as long as required."
    docstring += ":param type name: A parameter.\n"
    docstring += ":type name: str\n"
    docstring += ":type name: int\n"
    docstring += ":param name2: Another parameter.\n"
    docstring += ":return: A return.\n"
    docstring += ":rtype: str\n"
    docstring += ":raises Exception: An exception.\n"
    docstring += ":yields: A generator.\n"
    docstring += ":yield: int\n"


# Generated at 2022-06-23 17:21:56.800125
# Unit test for function parse
def test_parse():
    expected = Docstring()

    expected.short_description = "Do something."
    expected.blank_after_short_description = False
    expected.long_description = "It does\n\nsomething."
    expected.blank_after_long_description = False

    expected.meta.append(
        DocstringReturns(["returns", "str"], "returned value.", "str")
    )
    expected.meta.append(
        DocstringParam(
            args=["raises", "ValueError"],
            description="when something goes wrong.",
            arg_name="TypeError",
            type_name="ValueError",
            is_optional=None,
            default=None,
        )
    )

# Generated at 2022-06-23 17:22:01.864820
# Unit test for function parse
def test_parse():
    # TODO: Test all edge cases for function parse
    assert parse("bla bla\nsecond line") == Docstring(
        short_description="bla bla",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description="second line",
        meta=[],
    )

# Generated at 2022-06-23 17:22:10.725305
# Unit test for function parse

# Generated at 2022-06-23 17:22:15.859804
# Unit test for function parse
def test_parse():
    text = (
        "Test docstring.\n\n"
        "Line two of test docstring.\n\n"
        ":param str foo: Foo is a string.\n"
        ":param bar: Bar is a string too.\n"
        ":returns: We don't care.\n"
        ":raises KeyError: This is an error.\n"
    )
    assert str(parse(text)) == text

# Generated at 2022-06-23 17:22:22.994528
# Unit test for function parse
def test_parse():
    docstring = """Single line docstring

    Additional info
    """

    assert parse(docstring) == Docstring(
        short_description='Single line docstring',
        blank_after_short_description=True,
        long_description='Additional info',
        blank_after_long_description=False,
        meta=[],
    )

    docstring = """    Single line docstring

    Additional info
    """
    assert parse(docstring) == Docstring(
        short_description='Single line docstring',
        blank_after_short_description=True,
        long_description='Additional info',
        blank_after_long_description=False,
        meta=[],
    )

    docstring = """
    Single line docstring

    Additional info
    """

# Generated at 2022-06-23 17:22:29.728179
# Unit test for function parse
def test_parse():
    docstring = parse(
        """
    Single-line docstring
    """
    )
    assert(docstring.short_description == "Single-line docstring")

    docstring = parse(
        """
    Single-line docstring

    Long
    multi-line
    docstring
    """
    )
    assert(docstring.short_description == "Single-line docstring")
    assert(docstring.long_description == "Long\nmulti-line\ndocstring")

    docstring = parse(
        """
    Single-line docstring
    

    Long
    multi-line
    docstring
    """
    )
    assert(docstring.short_description == "Single-line docstring")
    assert(docstring.long_description == "Long\nmulti-line\ndocstring")


# Generated at 2022-06-23 17:22:39.027049
# Unit test for function parse
def test_parse():

    docstring = """
        Testing a docstring.

        Bla bla

        :type bar: dict
        :param bar: dict with value
        :type foo: dict
        :param foo: dict with value
        :rtype: string
        :returns: string
        :raises: ValueError
        :raises ValueError: raise

        extra paragraph
        """


# Generated at 2022-06-23 17:22:48.221021
# Unit test for function parse

# Generated at 2022-06-23 17:22:49.667874
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-23 17:22:58.959615
# Unit test for function parse
def test_parse():
    doc = """
    This is a test

    First line of long description.

    Second line of long description.

    :param arg: first parameter
    :param arg2: second parameter
    :param type arg3: third parameter
    :param str arg4: fourth parameter
    :param str? arg5: optional fifth parameter
    :param arg6: sixth parameter defaults to "".
    :param arg7: seventh parameter that defaults to "default"
    :param arg8: eighth parameter that
    defaults to "default".
    :rtype: int
    :return: a return value
    :raises StopIteration: exception that may be raised
    """
    d = parse(doc)
    print(d)
    assert d.short_description == "This is a test"

# Generated at 2022-06-23 17:23:06.728426
# Unit test for function parse
def test_parse():
    src = r"""
    Test the parser with a complicated docstring.

    The short description.

    And now the long description.

    :param int i: The first parameter.
    :param str a: The second parameter.
    :param bar b: The last parameter.
    :param optional some_optional_parameter: This parameter is optional,
        and defaults to something.
    :returns: Some kind of returned value.
    :raises ValueError: Something went wrong.
    """
    doc = parse(src)
    assert str(doc) == src



# Generated at 2022-06-23 17:23:17.832547
# Unit test for function parse
def test_parse():
    text = """
        Test function:

        :param a: this is a parameter
        :type a: int

        :param b: this is an optional parameter with default 42
        :type b: int
        :default b: 42

        :return: the result
        :rtype: int

        :return: the other result
        :rtype: str

        :raises Exception: when something goes wrong
        :raises ValueError: when something else goes wrong
        """

    assert str(parse(text)) == text

    #
    # Test for differing whitespace
    #


# Generated at 2022-06-23 17:23:29.919470
# Unit test for function parse
def test_parse():
    import unittest
    import textwrap

    class TestParse(unittest.TestCase):
        """
        Unit test for docstring parser.

        This should be run using py.test on an installed version of
        pydocstyle.
        """

        def test_blank(self):
            self.assertEqual(parse(""), Docstring())

        def test_simple_function(self):
            ds = parse("""This is a test function.
            """)
            self.assertEqual(ds.short_description, "This is a test function.")

        def test_blank_after_short_desc(self):
            ds = parse("""This is a test function.
            """)
            self.assertTrue(ds.blank_after_short_description)


# Generated at 2022-06-23 17:23:40.150739
# Unit test for function parse
def test_parse():
    # This is a test for the docstring parser. It tests that the parser can
    # handle a wide range of inputs sucessfully.
    #
    # Args:
    #   arg1: This is arg1
    #   arg2: This is arg2
    # Returns:
    #   None
    # Raises:
    #   ValueError: This is a custom error
    string = """
    This is a test for the docstring parser. It tests that the parser can
    handle a wide range of inputs sucessfully.
    :param arg1: This is arg1
    :param arg2: This is arg2
    :returns: None
    :raises ValueError: This is a custom error
    """
    docstring = parse(string)

    # Test docstring class

# Generated at 2022-06-23 17:23:47.825522
# Unit test for function parse
def test_parse():
    docstring = """Summary line.

Description of function.

:param str arg1: Description of ``arg1``.
:param str arg2: Description of ``arg2``.
:param int arg3: Description of ``arg3``.

:returns: Description of return value.
:rtype: int

:raises RuntimeError: Description of exception raised.
"""
    docstring_return = parse(docstring)
    assert docstring_return.short_description == "Summary line."
    assert docstring_return.long_description == "Description of function."
    assert docstring_return.blank_after_short_description == True
    assert docstring_return.blank_after_long_description == True
    assert docstring_return.meta[0].args == ["param", "str", "arg1"]
    assert docstring_return

# Generated at 2022-06-23 17:23:59.120861
# Unit test for function parse
def test_parse():
    assert parse("Hello world.") == Docstring(
        short_description="Hello world."
    )

    assert parse("Hello world.\n\nThis is the long description.") == Docstring(
        short_description="Hello world.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="This is the long description.",
    )

    assert parse("Hello world.\n\nThis is the long description.\n\n") == Docstring(
        short_description="Hello world.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="This is the long description.",
    )


# Generated at 2022-06-23 17:24:07.970438
# Unit test for function parse
def test_parse():
    """Testing ReST-style docstring parsing.

    This docstring is intended to be parsed by the ReST parser.
    """
    parsed = parse(test_parse.__doc__)
    assert parsed.short_description == "Testing ReST-style docstring parsing."
    assert parsed.long_description == "This docstring is intended to be " +\
        "parsed by the ReST parser."
    assert parsed.blank_after_short_description is True
    assert parsed.blank_after_long_description is False

    assert parsed.meta == []

# Generated at 2022-06-23 17:24:17.289362
# Unit test for function parse
def test_parse():
    text = """\
    Header
    
    Args:
        foo: Foo.
        bar: Bar.
        baz: Baz.
    Keyword Arguments:
        qux: Qux.
        quux: Quux.
        quuz: Quuz.
    Returns:
        ret: Ret.
    Raises:
        err: Error.
    Yields:
        y: Yield.
    
    Footer.
    """

# Generated at 2022-06-23 17:24:27.649275
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    # test with no docstring
    print(parse(""))
    # test with docstring without keyword
    print(parse("""A thin wrapper around urllib.request
    
    
    
    
    
    
    """))
    print(repr(parse("""A thin wrapper around urllib.request
    
    
    
    
    
    
    """)))
    # test with docstring with keyword
    print(parse("""A thin wrapper around urllib.request
    
    :param str url:
    
    
    
    
    
    
    """))
    print(repr(parse("""A thin wrapper around urllib.request
    
    :param str url:
    
    
    
    
    
    
    """)))
    # test with

# Generated at 2022-06-23 17:24:34.847432
# Unit test for function parse
def test_parse():
    docstring = parse(
        """
    This is a docstring.

    :param name: The name.
    :type name: str
    :returns: Whether the name is valid.
    :rtype: bool
    """
    )
    assert docstring.short_description == "This is a docstring."
    meta = docstring.meta
    assert len(meta) == 2
    assert meta[0].arg_name == "name"
    assert meta[0].type_name == "str"
    assert not meta[0].is_optional
    assert meta[1].arg_name is None
    assert meta[1].type_name == "bool"
    assert not meta[1].is_optional


# Generated at 2022-06-23 17:24:45.794871
# Unit test for function parse
def test_parse():
    docstring = """
    Parse the ReST-style docstring into its components.
    
    :returns: parsed docstring
    """
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == "Parse the ReST-style docstring into its components."
    assert parsed_docstring.long_description == None
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_docstring.blank_after_long_description == None
    assert parsed_docstring.meta[0].args == ['returns']
    assert parsed_docstring.meta[0].description == 'parsed docstring'
    assert parsed_docstring.meta[0].type_name == None
    assert parsed_docstring.meta[0].is_generator == False


# Generated at 2022-06-23 17:24:56.621084
# Unit test for function parse
def test_parse():
    """
    Unit test for function parse
    """
    doc_string = """\
            Insert val into the array, maintaining heap invariant.

            Parameter
            ----------
            val
                the value to be inserted

            Returns
            -------
            the index of the inserted val
            """
    doc = parse(doc_string)
    print(doc)

    doc_string = """\
            Insert val into the array, maintaining heap invariant.

            Parameters
            ----------
            val
                the value to be inserted

            Returns
            -------
            the index of the inserted val
            """
    doc = parse(doc_string)
    print(doc)


# Generated at 2022-06-23 17:25:03.208508
# Unit test for function parse

# Generated at 2022-06-23 17:25:14.325324
# Unit test for function parse
def test_parse():
    # Note: Any changes to this function should be reflected in README.rst
    doc = parse.__doc__

    parsed_doc = parse(doc)
    assert parsed_doc.short_description == "Parse the ReST-style docstring into its components."
    assert parsed_doc.long_description == ":returns: parsed docstring"
    assert parsed_doc.blank_after_short_description
    assert parsed_doc.blank_after_long_description
    meta_list = [DocstringMeta(['returns', 'parsed', 'docstring'], '')]
    assert parsed_doc.meta == meta_list


# Generated at 2022-06-23 17:25:25.837200
# Unit test for function parse
def test_parse():
    docstr = """
    This is the short desc
    
    This is the long desc
    
    :param int times:
    :param str name: The name param
    :param str age: The name of the person
    :param int? age: The age of the person
    :param int age3: The age of the person, defaults to 18.
    :yields: The next item in the container
    :returns: True
    :returns int:
    :raises RuntimeError: If there is an error
    :raises: If there is an error
    """
    ds = parse(docstr)
    assert ds.short_description == "This is the short desc"
    assert ds.blank_after_short_description == True
    assert ds.blank_after_long_description == True
    assert ds

# Generated at 2022-06-23 17:25:33.998225
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc("""
    Short description.

    Long description.

    :arg1: some argument
    :arg2: another argument
    :returns: None
    :raises ValueError: if something bad happens
    """)


# Generated at 2022-06-23 17:25:39.679354
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is the long description.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :params arg3 Optional arg.
    :raises Exception Sample exception.

    :return: This is the return value.
    :rtype: Return type.
    """
    parsed = parse(docstring)
    for i in range(4):
        print(parsed.meta[i])
    return parsed

# Generated at 2022-06-23 17:25:45.650392
# Unit test for function parse
def test_parse():
    docstring = """
        This is a short description.

        This is the long description.

        Raises
        ------
        ValueError
            If x is not a string

        Returns
        -------
        int
            A number.
    """
    expected = Docstring(
        short_description="This is a short description.",
        blank_after_short_description=False,
        long_description="This is the long description.",
        blank_after_long_description=False,
        meta=[
            DocstringRaises(
                args=["Raises", "ValueError"],
                description="If x is not a string",
                type_name="ValueError",
            ),
            DocstringReturns(
                args=["Returns", "int"],
                description="A number.",
                type_name="int",
            ),
        ],
    )



# Generated at 2022-06-23 17:25:55.571757
# Unit test for function parse

# Generated at 2022-06-23 17:26:06.601235
# Unit test for function parse
def test_parse():
    docstring = """
    Create a new object.

    :param name: The name of the object
    :param description: A short description of the object
    :returns: The newly created object
    """
    d = parse(docstring)

    assert d.short_description == "Create a new object."
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert len(d.meta) == 2
    assert d.meta[0].arg_name == "name"
    assert d.meta[1].arg_name == "description"
    assert d.meta[1].type_name is None
    assert d.meta[1].is_generator is False
    assert d.meta[1].is_optional is None

# Generated at 2022-06-23 17:26:16.034528
# Unit test for function parse

# Generated at 2022-06-23 17:26:23.522687
# Unit test for function parse
def test_parse():
    def f(x):
        """
        Short description.

        Long description.

        :param x: this is a x
        :type x: int
        :returns: this is a y
        :rtype: int
        """
        return x + 1

    # TODO: function f raise error:
    # raise ParseError("Unrecognized keyword args: ['x'].")
    # => In parse.py:174:
        # raise ParseError("Unrecognized keyword args: %r." % args)

test_parse()