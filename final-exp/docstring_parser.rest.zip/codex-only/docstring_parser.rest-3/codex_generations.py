

# Generated at 2022-06-23 17:16:33.908414
# Unit test for function parse
def test_parse():
    def func_with_docstring(a, b='b', *args, c=False, d=None, **kwargs):
        """This is the summary line for a function.

        This is the first paragraph of the docstring. It's indented
        to show that it's a continuation of the summary line.

        :param a: The first parameter.
        :type a: int
        :param b: The second parameter.
        :type b: str
        :param c: A flag parameter.
        :type c: boolean
        :param d: Optional parameter.
        :type d: float
        :param kwargs: Optional keyword parameters.
        :type kwargs: dict
        :returns: The return value.
        :rtype: bool

        """
        print(a, b, args, c, d, kwargs)


# Generated at 2022-06-23 17:16:44.076748
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc(
    r'''
    Short description.
    Long description.

    :param int arg1: The first parameter.
    :param int arg2: The second parameter.

    :raises TypeError: When no arguments are supplied.
    :returns: None
    '''
    )
    doc = parse(docstring)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert len(doc.meta) == 3

# Generated at 2022-06-23 17:16:53.614420
# Unit test for function parse
def test_parse():
    text = """
    Sum up the numbers in the iterable.
    
    :param x: A number
    :type x: int
    :param y: A number
    :type y: int
    :returns: The sum
    :rtype: int
    :raises ValueError: If x or y is not an int
    """

    result = parse(text)
    assert result.short_description == "Sum up the numbers in the iterable."
    assert result.long_description == """A number
    
A number
    
The sum
    
If x or y is not an int"""

# Generated at 2022-06-23 17:17:03.246967
# Unit test for function parse

# Generated at 2022-06-23 17:17:12.934416
# Unit test for function parse
def test_parse():
    assert parse(None) == Docstring()
    assert parse("") == Docstring()

    assert parse("short description") == Docstring(
        short_description="short description",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

    assert parse("short description\n\nlong description") == Docstring(
        short_description="short description",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="long description",
        meta=[],
    )


# Generated at 2022-06-23 17:17:20.200973
# Unit test for function parse

# Generated at 2022-06-23 17:17:31.688380
# Unit test for function parse
def test_parse():
    text = parse("test docstring")
    assert text.short_description == "test docstring"
    assert text.long_description is None
    assert text.blank_after_long_description is False
    assert text.blank_after_short_description is False
    assert len(text.meta) == 0
    text = parse("test docstring\n\nwith long description")
    assert text.short_description == "test docstring"
    assert text.long_description == "with long description"
    assert text.blank_after_long_description is True
    assert text.blank_after_short_description is False
    assert len(text.meta) == 0
    text = parse("test docstring\nwith long description")
    assert text.short_description == "test docstring"
    assert text.long_description == "with long description"

# Generated at 2022-06-23 17:17:39.275308
# Unit test for function parse

# Generated at 2022-06-23 17:17:48.101262
# Unit test for function parse
def test_parse():
    doc = parse("""Hello World
    :param nums: numbers
    :type nums: list of int
    :param name: name
    :type name: str
    :param key: key
    :type key: str, optional
    :param opt: opt
    :type opt: int, defaults to 2.
    :return:
    :rtype: int
    :raises:
    :returns:
    """)

    assert len(doc.meta) == 4
    assert doc.meta[0] == DocstringParam(
        args=["param", "nums", "numbers"],
        arg_name="nums",
        type_name="list of int",
        is_optional=None,
        default=None,
        description="numbers",
    )
    assert doc.meta[1] == DocstringParam

# Generated at 2022-06-23 17:17:58.223217
# Unit test for function parse
def test_parse():
    docstring = '''
        This is a test.
        Don't mind me.
        :param name: The name of whatever.
                     Defaults to 'Fred'
        :raises CustomError: When Fred is not given
        :returns: The length of the name.
    '''
    doc = parse(docstring)
    assert doc.short_description == "This is a test.\nDon't mind me."
    assert doc.long_description == "The length of the name."
    assert doc.meta[0].arg_name == 'name'
    assert doc.meta[0].type_name is None
    assert doc.meta[0].is_optional is False
    assert doc.meta[0].default == "Fred"
    assert doc.meta[1].type_name == 'CustomError'

# Generated at 2022-06-23 17:18:09.030311
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description.

    :param a: description.
    :type a: int
    :raises RuntimeError: description.
    :returns: description.
    :rtype: str
    :yields: description.
    """

# Generated at 2022-06-23 17:18:18.997816
# Unit test for function parse
def test_parse():
    docstring = """ First line
        Second line
    """
    expected = Docstring(
        short_description="First line",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="Second line",
        meta=[],
    )
    assert parse(docstring) == expected

    docstring = """First line
        Second line

    """

    expected = Docstring(
        short_description="First line",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="Second line",
        meta=[],
    )

    assert parse(docstring) == expected

    docstring = """First line
        Second line

    Other things"""


# Generated at 2022-06-23 17:18:30.676490
# Unit test for function parse
def test_parse():
    text = inspect.cleandoc("""
        Bar
        ===

        :param a: foo
        :param b: bar
        :rtype: list
        :returns:
             The list [a, b]
        :raises ValueError:
             in case of error

        This is the longer description.
    """)


# Generated at 2022-06-23 17:18:42.801853
# Unit test for function parse
def test_parse():
    def f(a: int, b: str, c: T.List[int] = None, d: "An Optional Argument" = "..."):
        """Short description.

        A long description.
        It goes on...

            :param a: First parameter
            :type a: int
            :param b: Second parameter
            :type b: str
            :param c: Third parameter
            :type c: int
            :param d: An optional argument
            :type d: str
            :returns: a + b + len(c)
            :rtype: int
            :raises ValueError: If a is not an int
            :raises TypeError: If a is not an int
        """
        return a + b + c
    docstring = parse(f.__doc__)

# Generated at 2022-06-23 17:18:53.792340
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("short desc.") == Docstring(
        short_description="short desc."
    )

    ds = parse("""
    short desc.

    long desc.
    """
    )
    assert ds == Docstring(
        short_description="short desc.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="long desc.",
    )

    ds = parse("""
    short desc.

    long desc.

    """
    )
    assert ds == Docstring(
        short_description="short desc.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="long desc.",
    )


# Generated at 2022-06-23 17:19:00.234869
# Unit test for function parse
def test_parse():
    docstring = parse.__doc__
    assert docstring.short_description == "Parse the ReST-style docstring into its components."
    assert docstring.long_description.split('\n')[0] == ":param text: ReST docstring"
    assert docstring.long_description.split('\n')[1] == ":type text: str"
    assert docstring.long_description.split('\n')[2] == ":returns: parsed docstring"
    assert docstring.long_description.split('\n')[3] == ":rtype: Docstring"

# Generated at 2022-06-23 17:19:12.113532
# Unit test for function parse
def test_parse():
    d = Docstring()
    d.short_description = 'Hello world'
    d.blank_after_short_description = True
    d.long_description = None
    d.blank_after_long_description = False

# Generated at 2022-06-23 17:19:19.352332
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Test.") == Docstring(
        short_description="Test.",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert parse("Test\n.\n") == Docstring(
        short_description="Test",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert parse("Test\n.\nAnother line.") == Docstring(
        short_description="Test",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="Another line.",
    )

# Generated at 2022-06-23 17:19:28.569917
# Unit test for function parse
def test_parse():
    docstring = """
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """
    doc = parse(docstring)
    assert doc.short_description == "Parse the ReST-style docstring into its components."
    assert doc.blank_after_short_description
    assert not doc.blank_after_long_description
    assert doc.long_description == "returns: parsed docstring"
    assert len(doc.meta) == 1
    assert isinstance(doc.meta[0], DocstringReturns)
    assert doc.meta[0].args == ['returns']
    assert doc.meta[0].description == 'parsed docstring'
    assert doc.meta[0].type_name is None
    assert not doc.meta[0].is_generator


# Unit test

# Generated at 2022-06-23 17:19:38.660830
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description.

    :param x: First parameter.
    :type x: int
    :param y: Second parameter.
    :type y: str
    :keyword d:
        Keyword parameter.
    :returns:
        Something.
    :raises ValueError:
        If something's wrong.
    """


# Generated at 2022-06-23 17:19:47.057458
# Unit test for function parse
def test_parse():
    docstring = """
        Short description.

        Long description.
    """
    expected_str = """
        Short description.

        Long description.
    """
    expected = Docstring(short_description="Short description.",
                         long_description="Long description.",
                         blank_after_short_description=True,
                         blank_after_long_description=True,
                         meta=[])
    assert parse(docstring) == expected, f"Unexpected output {parse(docstring)}"
    assert str(parse(docstring)) == expected_str, f"Unexpected str output {parse(docstring)}"


# Generated at 2022-06-23 17:19:56.989203
# Unit test for function parse

# Generated at 2022-06-23 17:20:08.403000
# Unit test for function parse

# Generated at 2022-06-23 17:20:10.300681
# Unit test for function parse
def test_parse():
    assert parse.__doc__ == inspect.getdoc(parse)

# Generated at 2022-06-23 17:20:19.737777
# Unit test for function parse
def test_parse():
    text = """
    The short description
    goes here.

    The long description
    goes here.

    A paragraph.

    Again, a paragraph.

    :param type arg_name: description
    :param type arg_name: description
    :returns: description
    :raises: description
    """
    docstring = parse(text)
    assert docstring.short_description == "The short description goes here."
    assert docstring.blank_after_short_description
    assert docstring.long_description.strip() == "The long description goes here.\n\nA paragraph.\n\nAgain, a paragraph."
    assert docstring.blank_after_long_description

    params = docstring.meta[:2]
    returns = docstring.meta[2:3]
    raises = docstring.meta[3:]

   

# Generated at 2022-06-23 17:20:23.157962
# Unit test for function parse
def test_parse():
    from .common import inspect_spec

    spec = inspect_spec(parse)
    assert spec.signature.return_annotation.name == "Docstring"
    assert spec.docstring.short_description == "Parse the ReST-style docstring into its components."
    for param in spec.docstring.meta:
        if param.arg_name == "text":
            assert param.type_name == "str"
            assert param.description.startswith(
                "The ReST-style docstring to be parsed."
            )
            break


__all__ = ["parse"]

# Generated at 2022-06-23 17:20:34.669485
# Unit test for function parse
def test_parse():
    docstring = """\
    Short summary.

    Longer description.

    :param param: Description of param.
    :param foo: Description of foo.
    :param baz: Description of baz (defaults to None).
    :returns: Description of return value.
    :returns: Another description of return value.
    :raise Exception: Description of exception.
    """
    d = parse(docstring)

# Generated at 2022-06-23 17:20:43.033978
# Unit test for function parse
def test_parse():
    docstring = parse("""First sentence.
    Second sentence.
    
    :param arg1: First arg.
    :param arg2: Second arg.
    :returns: Something
    :raises ValueError: If something
    """)
    print("----")
    print(docstring)
    print("----")
    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.meta[0])
    print(docstring.meta[1])
    print(docstring.meta[2])
    print(docstring.meta[3])
    #print(docstring.long_description)
    #print(docstring.blank_after_short_description)
    #print(docstring.blank_after_long_description)
    #print(docstring.meta[0].

# Generated at 2022-06-23 17:20:54.290678
# Unit test for function parse
def test_parse():
    s = """\
first line

second line
    
    :param int a: parameter a
    :raises ValueError: in case of things
    """
    doc = parse(s)

    assert doc.short_description == "first line"
    assert doc.long_description == "second line"
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False

    assert len(doc.meta) == 2
    assert doc.meta[0].keyword == "param"
    assert doc.meta[0].args == ["param", "int", "a"]
    assert doc.meta[0].description == "parameter a"
    assert doc.meta[1].keyword == "raises"
    assert doc.meta[1].args == ["raises", "ValueError"]
   

# Generated at 2022-06-23 17:21:02.256734
# Unit test for function parse
def test_parse():
    text = """\
    Test function docstring.

    :param arg1: some arg
    :param arg2: some other arg
    :returns: the return value
    :rtype: int

    :raises ValueError: in case of a problem
    :raises TypeError: if a parameter has the wrong type
    """
    doc = parse(text)

    assert doc.short_description == "Test function docstring."
    assert doc.long_description == (
        "the return value\n"
        "in case of a problem\n"
        "if a parameter has the wrong type"
    )

    assert isinstance(doc.meta[0], DocstringParam)
    assert doc.meta[0].keyword == "param"
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta

# Generated at 2022-06-23 17:21:08.368421
# Unit test for function parse
def test_parse():
    doc = parse.__doc__
    parsed_doc = parse(doc)
    assert parsed_doc.short_description == "Parse the ReST-style docstring into its components."
    assert parsed_doc.blank_after_short_description == True
    assert parsed_doc.blank_after_long_description == False
    assert parsed_doc.long_description == ":returns: parsed docstring"

# Generated at 2022-06-23 17:21:13.011738
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    docstring = inspect.getdoc(parse)
    print(parse(docstring))

    docstring = inspect.getdoc(Docstring)
    print(parse(docstring))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:21:24.553848
# Unit test for function parse
def test_parse():
    # TODO: Add test cases for unexpected inputs
    docstring_input = """\
Test docstring

This is a test docstring
"""

    docstring = parse(docstring_input)

    assert docstring.short_description == "Test docstring"
    assert docstring.long_description == "This is a test docstring"
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert not docstring.meta
    # assert docstring.empty == False

    docstring_input = """\
Test docstring

:param arg_name: Some arg
:type arg_name: str
"""

    docstring = parse(docstring_input)

    assert docstring.short_description == "Test docstring"
    assert len(docstring.meta) == 1

   

# Generated at 2022-06-23 17:21:35.344920
# Unit test for function parse
def test_parse():
    docstring = """
    Create an object of given type.

    :param type: The type of the object to create.
    :param optional: Is this object optional? Defaults to False.
    :raises TypeError: If an object of the specified type cannot be created.
    :returns: The created object.
    """

    doc = parse(docstring)

    assert doc.short_description == "Create an object of given type."
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False

    assert len(doc.meta) == 4
    assert doc.meta[0].description == "The type of the object to create."
    assert isinstance(doc.meta[0], DocstringParam)
    assert doc.meta[0].arg_name

# Generated at 2022-06-23 17:21:44.173834
# Unit test for function parse
def test_parse():
    """Test parse()"""
    docstring = '''Single line description.

    First paragraph of long description.
    Second paragraph of long description.

    :arg: description of arg
    :returns: description of return value
    :raises: description of exception
    :yields: description of yielded value
    '''
    # [TODO] Add more unit tests

# Generated at 2022-06-23 17:21:55.524565
# Unit test for function parse
def test_parse():
    doctext = """Find the nearest neighbors of a set of points.
:param points: NxK array of N points in K dimensions
:type points: array-like, dtype=float
:param neighbors: Number of neighbors to get (default 10).
:type neighbors: int
:param return_distances: Whether or not to return the distances (default False).
:type return_distances: bool
:returns: Two arrays of size (NxK) and (Nxneighbors) if return_distances is 
    False, otherwise a tuple of (points, distances)."""


# Generated at 2022-06-23 17:22:06.629969
# Unit test for function parse
def test_parse():
    """Unit test for function parse
    """

# Generated at 2022-06-23 17:22:11.975422
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring = '''
    This is a description.

    This is a longer description.

    :param arg1: This is the description for arg1.
    '''
    print(parse(docstring))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:22:20.456622
# Unit test for function parse
def test_parse():
    text = """
        This is a short description.

        This is a long description.

        This is a long description line 2.

        :param name: a name
        :type name: str
        :param age: an age
        :type age: int
        :returns: something
        :rtype: str

        This is a line after meta info.

        This is a line after meta info #2.
    """
    doc = parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description is None
    assert doc.blank_after_short_description
    assert not doc.blank_after_long_description

# Generated at 2022-06-23 17:22:27.150153
# Unit test for function parse
def test_parse():
    text="""
    Short function description.

    Function long description.

    :param arg1: argument 1.
    :param arg2: argument 2.
    :type arg1: something
    :type arg2: something else
    :raises KeyError: when a key error is raised
    :returns: the return value.
    """
    docstring = parse(text)
    print(docstring)


# Generated at 2022-06-23 17:22:37.354229
# Unit test for function parse
def test_parse():
    sample_docstring = """
    This is a sample docstring, it is used by unit test.

    This is the second line.
    This is the third line.

    :param a: This is parameter a, it has no type.
    :param b: This is parameter b, it is of type int.
    :param c: This is parameter c, it is optional (x==y)
    :param d: This is parameter d, it is optional with default value y.
    :param e: This is parameter e, it is optional with non-literal default value len(a)
    :yields: This is a yield statement.
    :returns: This is the return value.
    """
    ret = parse(sample_docstring)
    assert ret.short_description == "This is a sample docstring, it is used by unit test."


# Generated at 2022-06-23 17:22:46.909353
# Unit test for function parse
def test_parse():
    text = """
    Computes the XYZ coordinates of a point based on its latitude, longitude, and
    altitude.

    :param lat: The latitude in degrees.
    :type lat: float
    :param lon: The longitude in degrees.
    :type lon: float
    :param alt: The altitude in meters.
    :type alt: float
    :returns: The XYZ coordinates of the point as a tuple.
    :rtype: tuple
    :raises ValueError: If the latitude or longitude is out of range.
    """


# Generated at 2022-06-23 17:22:57.390032
# Unit test for function parse
def test_parse():
    docstring = """\
    Tests the classifier function with a single string
    :param str text: input string
    :return: The output labels.
    """
    doc = parse(docstring)
    assert doc.short_description == "Tests the classifier function with a single string"
    assert doc.meta[0].args == ['param', 'str', 'text']
    assert doc.meta[0].description == "input string"
    assert doc.meta[0].arg_name == "text"
    assert doc.meta[0].type_name == "str"
    assert doc.meta[0].is_optional is None
    assert doc.meta[0].default is None
    assert doc.meta[1].args == ['return']
    assert doc.meta[1].description == "The output labels."

# Generated at 2022-06-23 17:23:07.763858
# Unit test for function parse
def test_parse():
    # pylint: disable=missing-function-docstring
    # pylint: disable=line-too-long
    # pylint: disable=invalid-name
    import textwrap
    from .common import DocstringReturns, DocstringParam, DocstringRaises
    from .common import DocstringMeta, Docstring

    def _assert_parse(input_, expected_docstring):
        actual = parse(textwrap.dedent(input_))
        if actual != expected_docstring:
            print(actual)
            assert False


# Generated at 2022-06-23 17:23:16.252698
# Unit test for function parse
def test_parse():
    assert parse("\n") == Docstring()
    assert parse("Foo bar.\n") == Docstring(
        short_description="Foo bar.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description=None,
    )
    assert parse("Foo bar.\n\n") == Docstring(
        short_description="Foo bar.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description=None,
    )

# Generated at 2022-06-23 17:23:19.763351
# Unit test for function parse
def test_parse():
    test_docstring = '/Users/niall/Documents/PhD/Coding/GitHub/EvoBias/src/evobias/experiment/evaluate_logistic_regression_prediction.py'
    assert(parse(test_docstring))


# Generated at 2022-06-23 17:23:31.342525
# Unit test for function parse
def test_parse():
    # Test for:
    #   Docstring with
    #       Blank description
    #       Short description with no trailing whitespace
    #       Long description with two leading newlines and single trailing newline
    #       Possible meta lines with arguments (named, unnamed) and description


    x = parse(
        """This function parses a ReST-style docstring into its components.

:param what: this is what
:param type_name: optional type name
:param arg_name: optional argument name, defaults to yes.
:param is_optional: this is a keyword argument
:returns: parsed docstring
:rtype: int
:yields: a generator
:yields type_name: optional type name
:raises: ValueError
:raises type_name: optional type name
:author: Me"""
    )

    assert x.short

# Generated at 2022-06-23 17:23:39.182256
# Unit test for function parse
def test_parse():
    text = """short desc

    long desc

    :param foo: function foo
    :type foo: bool
    :param bar: function bar
    :return: return of the function

    more description
    """


# Generated at 2022-06-23 17:23:42.926053
# Unit test for function parse
def test_parse():
    example = """Docstring for a function.
    :param arg: A string
    :returns: The input string
    """
    parsed = parse(example)
    assert parsed.short_description == "Docstring for a function."
    param_exists = False
    returns_exists = False
    for meta in parsed.meta:
        if isinstance(meta, DocstringParam):
            param_exists = True
        if isinstance(meta, DocstringReturns):
            returns_exists = True
    assert param_exists and returns_exists

# Generated at 2022-06-23 17:23:48.180981
# Unit test for function parse

# Generated at 2022-06-23 17:23:49.892946
# Unit test for function parse
def test_parse():
    import doctest
    return doctest.testmod(verbose=True)

# Generated at 2022-06-23 17:24:00.610363
# Unit test for function parse
def test_parse():
    class Class1():
        """Short description on one line        
        :param param_1: The first parameter.
        :type param_1: string
        :param param_2: The second parameter
        :returns: Description of return value
        :rtype: string
        
        Long description on multiple lines
        
        ..
        
        :param param_3: The third parameter.
        :type param_3: string, optional
        :param param_4: The fourth parameter.
        :rtype: string, optional
        :returns: Description of return value
        :raises: An exception
        :except Exception: If an exception occurs.        
        """
        pass


# Generated at 2022-06-23 17:24:05.818401
# Unit test for function parse
def test_parse():
    doc = parse("""
    This is the short description.

    This is the long description.

    :param foo: what a foo
    :type foo: str
    :param bar: what a bar
    :type bar: int
    :param baz: what a baz
    :type baz: bool
    :returns: something
    :rtype: bool
    :raises ValueError: if it fails
    """)

    assert not doc.blank_after_short_description
    assert not doc.blank_after_long_description
    assert doc.short_description == "This is the short description."
    assert doc.long_description == "This is the long description."

    assert len(doc.meta) == 5
    assert doc.meta[0].arg_name == "foo"
    assert doc.meta[0].type_name

# Generated at 2022-06-23 17:24:16.309394
# Unit test for function parse

# Generated at 2022-06-23 17:24:24.227245
# Unit test for function parse
def test_parse():
    test_text = """
    Short description.

    Long description.

    :param int foo: Documentation for foo.
    """
    parsed_text = parse(test_text)
    assert parsed_text.short_description == "Short description."
    assert parsed_text.long_description == "Long description."
    assert isinstance(parsed_text.meta[0], DocstringParam)
    assert parsed_text.meta[0].description == "Documentation for foo."



# Generated at 2022-06-23 17:24:35.752905
# Unit test for function parse
def test_parse():
    def foo(a: int, b: int = 5) -> int:
        """
        This is a description.
        :param int a:
        :param int b: defaults to 5
        :returns: returns the result
        """
        pass
    docstring = foo.__doc__
    result = parse(docstring)
    assert len(result.meta) == 2
    assert result.meta[0].keyword == "param"
    assert result.meta[0].arg_name == "a"
    assert result.meta[0].type_name == "int"
    assert result.meta[1].keyword == "param"
    assert result.meta[1].arg_name == "b"
    assert result.meta[1].type_name == "int"
    assert result.meta[1].is_optional
    assert result

# Generated at 2022-06-23 17:24:46.526564
# Unit test for function parse
def test_parse():
    test_string = """
    This is a short description.

    This is a long description.

    :param x int: Name of x.
    :param y: Name of y.
    :returns: nothing
    """
    actual = parse(test_string)
    assert actual.short_description == "This is a short description."
    assert actual.long_description == "This is a long description."
    assert actual.blank_after_short_description
    assert actual.blank_after_long_description
    #Print the actual parsed docstring
    print(actual)
    assert len(actual.meta) == 2
    assert isinstance(actual.meta[0], DocstringParam)
    assert actual.meta[0].arg_name == "x"
    assert actual.meta[0].type_name == "int"
    assert actual.meta

# Generated at 2022-06-23 17:24:53.449112
# Unit test for function parse
def test_parse():
    docstring = parse.__doc__
    doc = parse(docstring)

    assert doc is not None
    assert doc.short_description is not None
    assert doc.long_description is not None
    assert doc.short_description == "Parse the ReST-style docstring into its components."
    assert doc.long_description.strip() == ":returns: parsed docstring"
    assert doc.blank_after_short_description is True
    assert doc.blank_after_long_description is False



# Generated at 2022-06-23 17:25:01.552087
# Unit test for function parse
def test_parse():
    from .common import Docstring
    assert(parse('') == Docstring())

    docstring = Docstring(short_description='A very short description.',
                          blank_after_short_description=True,
                          long_description=None,
                          blank_after_long_description=False,
                          meta=[])
    assert(parse('A very short description.') == docstring)

    docstring.short_description = None
    docstring.blank_after_short_description = False
    docstring.long_description = 'A very long description.'
    docstring.blank_after_long_description = False
    docstring.meta = []
    assert(parse('\nA very long description.') == docstring)

    docstring.short_description = 'A very short description.'
    docstring.blank_after_short_

# Generated at 2022-06-23 17:25:12.992304
# Unit test for function parse
def test_parse():
    doc = parse('''
    This is a sample docstring with no meta information

    This is a sample long description
    ''')
    assert len(doc.meta) == 0
    assert doc.short_description == 'This is a sample docstring with no meta information'
    assert doc.long_description == 'This is a sample long description'
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False

    doc = parse('''
    This is a sample docstring

    :key: value
    :key: value

    This is a sample long description
    ''')
    assert len(doc.meta) == 1
    assert doc.meta[0].args == ['key']
    assert doc.meta[0].description == 'value'


# Generated at 2022-06-23 17:25:21.289060
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    assert parse('"""foo"""') == Docstring(
        short_description='foo',
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse('"""\nfoo\n"""') == Docstring(
        short_description='foo',
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-23 17:25:32.062869
# Unit test for function parse
def test_parse():
    docstring = """
    A method to multiply two numbers
    :param x: number to multiply
    :type x: int
    :param y: number to multiply
    :type y: int
    :return: x multiplied by y
    :rtype: int
    """
    assert parse(docstring).short_description == 'A method to multiply two numbers'
    assert parse(docstring).long_description == None
    assert parse(docstring).meta[0].args[0] == 'param'
    assert parse(docstring).meta[0].args[1] == 'x'
    assert parse(docstring).meta[0].args[2] == 'int'
    assert parse(docstring).meta[0].description == 'number to multiply'
    assert parse(docstring).meta[1].args[0] == 'param'

# Generated at 2022-06-23 17:25:41.784004
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description.

    :param x: param1
    :returns: param2
    """
    ds = parse(text)
    assert len(ds.meta) == 2
    assert ds.short_description == 'Short description.'
    assert ds.long_description == 'Long description.'
    assert ds.blank_after_short_description == True
    assert ds.blank_after_long_description == False
    assert ds.meta[0].arg_name == 'x'
    assert ds.meta[1].type_name == 'param2'

# Generated at 2022-06-23 17:25:52.834473
# Unit test for function parse
def test_parse():
    def f():
        """Short desc

        Long 
        desc.

        :param a: param a
        :type a: int
        :param b: param b with a long description.
        :type b: int
        :type b: float
        :param c?: param c
        :param d: param d defaults to True.
        :type e:
        :raises IndexError: if ...
        :raises KeyError:
        :return: return value
        :rtype: int
        :yield: yields something
        :yields: yields something
        """
        pass

    doc = parse(f.__doc__)

    print(doc.short_description)
    print(doc.blank_after_short_description)
    print(doc.blank_after_long_description)

# Generated at 2022-06-23 17:26:03.951461
# Unit test for function parse
def test_parse():
    """
    Verify that the parse function extracts the correct information for
    a given docstring
    """
    doc = parse(
        """A function with many different types of docstrings.
        :param arg1: this argument is a string
        :param arg2: this one is an optional int with a default of 10
        :param arg3: this is a list of strings
        :param arg4: this is an optional list of ints
        :returns: this should be an int
        :raises Exception: if something bad happens"""
    )
    print(doc)

    assert doc.short_description == "A function with many different types of docstrings."
    assert doc.long_description == None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False

    first_meta = doc.meta

# Generated at 2022-06-23 17:26:09.124464
# Unit test for function parse
def test_parse():
    doc = parse("""
        This is a short description.
         
        This is a long description.
        It can be multiple lines.
    
        :param x: first positional argument
        :type x: int
        :param y: second positional argument
        :type y: str
    """)
    print(doc)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:26:17.469663
# Unit test for function parse
def test_parse():
    test_code = inspect.cleandoc(
        """\
    Test doc string in ReST format

    :param int a: Test data 1, for input
    :param str b: Test data 2, for input
    :return: Test data 3, for output.
    :raise ValueError: If value is not valid.
    """
    )
    doc = parse(test_code)

# Generated at 2022-06-23 17:26:19.861175
# Unit test for function parse
def test_parse():
    assert parse('"""\nThis is a test.\n"""') == \
    Docstring(
        short_description='This is a test.',
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description=None,
        meta=[],
    )


# Generated at 2022-06-23 17:26:31.844575
# Unit test for function parse