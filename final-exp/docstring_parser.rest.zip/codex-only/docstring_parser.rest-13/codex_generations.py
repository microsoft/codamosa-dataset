

# Generated at 2022-06-23 17:16:33.677527
# Unit test for function parse
def test_parse():
    assert parse.__doc__ == parse(parse.__doc__).short_description
    assert parse.__doc__ == parse(parse.__doc__).long_description
    assert parse.__doc__ == (
        parse(parse.__doc__).short_description
        + "\n"
        + parse(parse.__doc__).long_description
    )
    assert parse.__doc__ == parse(parse.__doc__).short_description
    assert parse.__doc__ == (
        parse(parse.__doc__).short_description
        + "\n"
        + parse(parse.__doc__).long_description
    )
    assert parse.__doc__ == parse(parse.__doc__).short_description

# Generated at 2022-06-23 17:16:40.463525
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("    ") == Docstring()
    assert parse("x y z") == Docstring(
        short_description="x y z",
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description=None,
        meta=[],
    )

    assert parse("x y z\n\nfoo bar") == Docstring(
        short_description="x y z",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="foo bar",
        meta=[],
    )


# Generated at 2022-06-23 17:16:44.239848
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a function that multiplies two numbers.
    
    :param a: One number
    :type a: int
    :param b: Another number
    :type b: int
    :returns: The product
    :rtype: int
    '''
    print(parse(docstring))

# Generated at 2022-06-23 17:16:56.350319
# Unit test for function parse
def test_parse():
    def f(x, y, *z):
        '''
        This is a short description.

        This is a long description.

        :param x: A parameter with a description.
        :param y?: A parameter with a description and a type name.
        :param z: A parameter with a description and an argument name.
        '''
        pass

    docstr = parse(f.__doc__)

    assert docstr.short_description == "This is a short description."
    assert docstr.long_description == "This is a long description."
    assert docstr.blank_after_short_description
    assert docstr.blank_after_long_description

    params = docstr.params
    assert len(params) == 3
    assert isinstance(params, list)
    assert params[0].key == "param"

# Generated at 2022-06-23 17:17:04.946557
# Unit test for function parse
def test_parse():
    text = '''This function counts the number of vowels in a given phrase.

:param str phrase: The phrase to be analyzed
:param bool vowels_too: If True, then a list of all the vowels will be returned,
    otherwise the number of vowels will be returned.
:returns: int or list
:raises ValueError: if the given phrase is not a string

'''

# Generated at 2022-06-23 17:17:14.870847
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description
    with multiple lines.

    :param int a: Description of parameter a.
    :param int b: Description of parameter b.
    :returns: Description of the return value.
    :raises ValueError: Description of the exception.
    """
    ret = parse(text)
    assert ret.short_description == "Short description."
    assert ret.long_description == "Long description\nwith multiple lines."
    assert ret.blank_after_short_description == False
    assert ret.blank_after_long_description == True
    assert len(ret.meta) == 3
    assert ret.meta[0].arg_name == "a"
    assert ret.meta[0].type_name == "int"
    assert ret.meta[0].is_optional == None
    assert ret

# Generated at 2022-06-23 17:17:26.934926
# Unit test for function parse
def test_parse():
    docstring_one = """
        Args:
            x (int): A number
            y (str, optional): Another number
        Returns:
            int: The return value.
        """
    docstring = parse(docstring_one)
    assert len(docstring.meta) == 3
    assert docstring.meta[0].keyword == "Args"
    assert docstring.meta[1].keyword == "Returns"
    assert docstring.meta[2].keyword == "Docstring"

    assert docstring.meta[0].description.strip() == "The return value."
    assert docstring.meta[1].description.strip() == "Another number"
    assert docstring.meta[2].description.strip() == "A number"

    assert docstring.meta[0].args == ["Args", "int", "x"]
   

# Generated at 2022-06-23 17:17:37.180295
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc('''\
    parse(text)
    Parse the ReST-style docstring into its components.
    
    :param text:
    :type text: str
    :returns: parsed docstring
    :rtype: xxx.xxx.Docstring
    ''')
    assert parse(docstring).short_description == "parse(text)"
    assert parse(docstring).long_description == "Parse the ReST-style docstring into its components."
    assert parse(docstring).blank_after_short_description == True
    assert parse(docstring).blank_after_long_description == False
    print(parse(docstring).meta)
    assert parse(docstring).meta[0].description == "xxx.xxx.Docstring"
    assert parse(docstring).meta[0].type

# Generated at 2022-06-23 17:17:44.931671
# Unit test for function parse
def test_parse():
    docstring = parse.__doc__
    assert docstring.short_description == 'Parse the ReST-style docstring into its components.'
    assert docstring.long_description == ':returns: parsed docstring'
    assert docstring.meta[0].description == 'parsed docstring'
    assert docstring.meta[0].arg_name == 'parsed docstring'
    assert docstring.meta[0].type_name is None
    assert docstring.meta[0].is_optional is None
    assert docstring.meta[0].default is None

# Generated at 2022-06-23 17:17:52.801327
# Unit test for function parse
def test_parse():
    import pytest
    assert(parse("test") == Docstring())
    assert(parse(":param name: The name of the user.") == Docstring(
        [ DocstringParam(
            args=['param', 'name'],
            description='The name of the user.',
            arg_name='name',
            type_name=None,
            is_optional=None,
            default=None
        ) ]
    ))
    with pytest.raises(ParseError):
        parse(":param wrongarg: The name of the user.")
    with pytest.raises(ParseError):
        parse(":param parameter name: The name of the user.")

# Generated at 2022-06-23 17:18:04.282281
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    d = Docstring()
    d.short_description = 'test short description'
    d.long_description = 'test long description'
    d.meta.append(DocstringParam(args=['param', 'int', 'arg'],
                                 description='test param',
                                 arg_name='arg',
                                 type_name='int',
                                 is_optional=False,
                                 default=None,
                                 ))

    d.meta.append(DocstringReturns(args=['return', 'int'],
                                   description='test return',
                                   type_name='int',
                                   is_generator=False,
                                   ))


# Generated at 2022-06-23 17:18:09.916885
# Unit test for function parse
def test_parse():
    text = """
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """
    assert parse(text).short_description == 'Parse the ReST-style docstring into its components.'
    assert parse(text).meta[0].key == 'returns'
    assert parse(text).meta[0].description == 'parsed docstring'
    assert parse(text).meta[0].type_name is None


# Generated at 2022-06-23 17:18:19.647514
# Unit test for function parse
def test_parse():
    """Test the parse function."""
    # Array of the two following variables
    # - docstring text
    # - expected parsed Docstring

# Generated at 2022-06-23 17:18:30.147002
# Unit test for function parse
def test_parse():
    class Test:
        """\
        Test func
        :param a: param a
        :type a: Optional[str]
        :raises TestError:
        """
        pass

    s = parse(Test.__doc__)
    assert s.short_description == "Test func"
    assert len(s.meta) == 2
    assert isinstance(s.meta[0], DocstringReturns)
    assert s.meta[0].type_name is None
    assert isinstance(s.meta[1], DocstringParam)
    assert s.meta[1].arg_name == "a"
    assert s.meta[1].type_name == "Optional[str]"
    assert s.meta[1].default is None

test_parse()

# Generated at 2022-06-23 17:18:42.135243
# Unit test for function parse
def test_parse():
    # test valid docstring
    source = '''
    :param str arg1: Doc for arg1
    :param str arg2: Doc for arg2
    :type str type for arg1:
    :returns: Return value is docstring
    :rtype: str
    :raises ValueError: If value error occurred
    :yields: Yield value is docstring
    :ytype: str
    :raises: Raises
    :yields: Yields
    :meta: Meta
    '''
    t1 = parse(source)
    assert t1.short_description == ''
    assert t1.long_description is None
    assert t1.blank_after_short_description is True
    assert t1.blank_after_long_description is False

# Generated at 2022-06-23 17:18:50.386033
# Unit test for function parse
def test_parse():
    docstring = '''
    The quick brown fox jumps over the lazy dog.

    Args:
        foo: str
            This is a very long description.

        bar: int=1
            The default value is 1.

        baz: List[int]

    Returns:
        str

    Raises:
        ValueError: If the value is invalid.
    '''
    docstring_parsed = parse(docstring)
    assert docstring_parsed.short_description == 'The quick brown fox jumps over the lazy dog.'

# Generated at 2022-06-23 17:18:59.787207
# Unit test for function parse
def test_parse():
    _parse = parse
    @_parse
    def f(a, b="hello"):
        """This is f.

        :param a: blah blah blah
        :param b: blah blah blah, defaults to hello
        :type b: str
        :raises ValueError: if blah blah blah
        :returns: blah blah blah
        :return: blah blah blah
        :yields: blah blah blah
        :yield: blah blah blah
        """
        pass

    print(f.short_description)
    print(f.long_description)
    print(f.meta)
    print(f.meta[0])
    print(f.meta[0].args)
    print(f.meta[0].description)
    print(f.meta[0].is_optional)

# Generated at 2022-06-23 17:19:11.838842
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1:
        Description of `arg1`
    :type arg1: str
    :param arg2:
        Description of `arg2`
    :type arg2: int
    :returns:
        Description of return value
    :rtype: float
    """

# Generated at 2022-06-23 17:19:17.924862
# Unit test for function parse
def test_parse():
    doc = """
    Basic docstring
    More docstring
    :type x: int
    :param x: bla-bla-bla
    """
    expected_doc = Docstring(
        short_description='Basic docstring',
        long_description='More docstring',
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[
            DocstringMeta(
                args=['type', 'x', 'int'],
                description='bla-bla-bla',
            )
        ],
    )
    assert parse(doc) == expected_doc

# Generated at 2022-06-23 17:19:23.949721
# Unit test for function parse
def test_parse():
    from .pytest_helper import run_function_tests, TestData, assert_docstring

    func_name = "parse"
    test_data = TestData(func_name)
    run_function_tests(test_data, parse, assert_docstring)


if __name__ == "__main__":  # pragma: no cover
    print("Use pytest to run unit tests.")

# Generated at 2022-06-23 17:19:26.165583
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:19:36.972013
# Unit test for function parse

# Generated at 2022-06-23 17:19:43.998213
# Unit test for function parse
def test_parse():
  docstring = 'an example docstring'
  docstring_ret = parse(docstring)
  assert docstring_ret.short_description == docstring
  assert docstring_ret.blank_after_short_description == False
  assert docstring_ret.long_description == None

  docstring = 'an example docstring\n\n'
  docstring_ret = parse(docstring)
  assert docstring_ret.short_description == 'an example docstring'
  assert docstring_ret.blank_after_short_description == True
  assert docstring_ret.long_description == None

  docstring = 'an example docstring\n\n\nan example docstring'
  docstring_ret = parse(docstring)
  assert docstring_ret.short_description == 'an example docstring'

# Generated at 2022-06-23 17:19:55.675447
# Unit test for function parse

# Generated at 2022-06-23 17:20:01.543306
# Unit test for function parse
def test_parse():
    docstring = """
    This docstring should have meta info.

    :param foo: Bar.
    :type foo: str
    :param baz: Quux.
    :type baz: Optional[int]
    :param blah: Blah blah.
    """
    ret = parse(docstring)
    assert len(ret.meta) == 3

# Generated at 2022-06-23 17:20:06.610815
# Unit test for function parse
def test_parse():
    docstring = ("\n    This is a docstring.\n\n    :param str a: A.\n    :param b: B.\n    :type b: int")
    doc = parse(docstring)
    assert doc.short_description == "This is a docstring."
    assert doc.long_description == None
    assert len(doc.meta) == 2


# Generated at 2022-06-23 17:20:16.737905
# Unit test for function parse
def test_parse():
    code = '''
    This is the short description.

    This is the long
    description. It can
    have multiple lines.

    :param foo: explanation
        of parameter foo
    :type foo: int
    :param bar: explanation of parameter bar
    :type bar: bool
    :param baz: explanation of parameter baz

        that spans multiple lines
    :type baz: str
    :param qux: explanation of parameter qux
    :type: qux: object
    :raises ValueError: if `value` is invalid.
    :returns: Description of return value.
    :rtype: str
    '''

    parsed = parse(code)
    assert " ".join(parsed.meta[0].args) == "param foo"
    assert parsed.meta[0].type_name == "int"
   

# Generated at 2022-06-23 17:20:22.459509
# Unit test for function parse
def test_parse():
    text = """
    This function inserts text before the first occurrence of a substring
    :param str text: The text to insert into
    :param str sub: The substring to insert before
    :param str word: The text to insert
    :returns: Updated text.
    :raises ValueError: If the text does not contain the substring.
    """


# Generated at 2022-06-23 17:20:34.029810
# Unit test for function parse
def test_parse():
    import json
    import os
    import pprint
    import re
    import sys
    import tempfile

    def _expand_path(path):
        return os.path.join(os.path.dirname(os.path.abspath(__file__)), path)

    def _get_docstring(module, func_name):
        """Get the docstring from a module function."""
        return getattr(module, func_name).__doc__

    def _parse_docstring(doc):
        return parse(doc)

    def _indent(s, n):
        return re.sub("\n", "\n" + n * " ", s)

    def _parse_docstring_test_case(path):
        with open(path) as f:
            data = json.load(f)


# Generated at 2022-06-23 17:20:42.719531
# Unit test for function parse

# Generated at 2022-06-23 17:20:49.128351
# Unit test for function parse
def test_parse():
    docstring = """\
This is a short description of the function.

This is the long description of the function.

:param a: This is the first parameter of the function.
:param int b: This is a parameter with type.  `b` must be a number.
:return: Nothing
:raise Exception: This function may raise exceptions.
:raises Exception: This function may also raise exceptions.
"""
    parsed = parse(docstring)
    print(parsed)
    assert parsed.raw_docstring == docstring
    assert parsed.short_description == "This is a short description of the function."
    assert parsed.long_description == "This is the long description of the function."
    assert parsed.meta[0].args == ["param", "a"]
    assert parsed.meta[1].args == ["param", "int", "b"]

# Generated at 2022-06-23 17:20:53.055958
# Unit test for function parse
def test_parse():
    docstring = """My sample docstring.

:param str foo: the foo argument.
:param str bar: the bar argument.
:param int baz: the baz argument.
:returns: the foo argument.
"""
    print(parse(docstring))


# Generated at 2022-06-23 17:21:01.485061
# Unit test for function parse
def test_parse():
    """
    Tests if the function parse is working fine

    """

# Generated at 2022-06-23 17:21:13.154930
# Unit test for function parse
def test_parse():
    class Foo(object):
        """Sample docstring with ReST markup.

        :param foo: An argument.
        :type foo: :obj:`int`
        :param bar: Another argument.
        :type bar: :obj:`str`, optional
        :param baz: Yet another arg.
        :type baz: :obj:`str`, defaults to None.

        :returns: Something.
        :rtype: :obj:`int`

        :raises: :obj:`Exception`
        """
        pass

    d = parse(Foo.__doc__)
    assert d.short_description == "Sample docstring with ReST markup."
    assert d.blank_after_short_description
    assert d.blank_after_long_description

# Generated at 2022-06-23 17:21:24.694149
# Unit test for function parse
def test_parse():
    def test_func():
        """Test docstring.

        :param arg1:
            Description of arg1
        :type arg1:
            str
        :param arg2:
            Description of arg2
        :type arg2:
            int
            |float
        :param arg3: (optional)
            Description of arg3
        :type arg3: int
        :param arg4: (optional)
            Description of arg4. Defaults to 2.
        :type arg4: int

        :returns:
            Description of return value
        :rtype: str
        """
        pass

    def test_func_no_type():
        """Test docstring.

        :param arg1:
            Description of arg1
        :param arg2:
            Description of arg2
        """
        pass


# Generated at 2022-06-23 17:21:35.403393
# Unit test for function parse
def test_parse():
	dummy_text = """
	This is the first line of the desctiption

	the second line of the description
	"""
	dummy_doc = parse(dummy_text)
	assert(dummy_doc.short_description == 'This is the first line of the desctiption')
	assert(dummy_doc.blank_after_short_description == False)
	assert(dummy_doc.blank_after_long_description == True)
	assert(dummy_doc.long_description == 'the second line of the description')
	assert(dummy_doc.meta == [])
	
	dummy_text = """
	This is the first line of the desctiption

	the second line of the description
	"""
	dummy_doc = parse(dummy_text)

# Generated at 2022-06-23 17:21:38.905173
# Unit test for function parse
def test_parse():
    docstring = '''
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    '''
    assert parse(docstring).short_description == "Parse the ReST-style docstring into its components."
    assert parse(docstring).long_description == "parsed docstring"

# Generated at 2022-06-23 17:21:44.576053
# Unit test for function parse
def test_parse():
    """Test function parse"""
    text = """\
        Short description.

        Some more description.

        :param str arg1: Description of arg1
        :param int arg2: Description of arg2
        :param bool arg3: Description of arg3
        :return: Description of return value
        :raises TypeError: If invalid argument is passed
        """
    doc = parse(text)
    assert str(doc) == text

# Generated at 2022-06-23 17:21:53.113941
# Unit test for function parse
def test_parse():
    text = """
    Test the ReST-style docstring into its components

    Parameters:
        random_example (int): This is a random example
        kwargs (dict): dictionary of keyword arguments
    """
    parsed_docstring = parse(text)
    meta = [
        DocstringParam(None, "random_example", "int", None, None, "This is a random example"),
        DocstringParam(None, "kwargs", "dict", None, None, "dictionary of keyword arguments")
    ]
    assert parsed_docstring.meta == meta

# Generated at 2022-06-23 17:21:59.898738
# Unit test for function parse

# Generated at 2022-06-23 17:22:08.959373
# Unit test for function parse
def test_parse():
    docstring = parse(
        """
        >>> some_function(foo, bar)
        >>>
        Some function blah blah.
        """
    )
    assert docstring.meta == []
    assert docstring.short_description == ">>> some_function(foo, bar)"
    assert docstring.long_description == None
    assert docstring.blank_after_long_description == False
    assert docstring.blank_after_short_description == True
    print((docstring.short_description, docstring.long_description, docstring.blank_after_long_description, docstring.blank_after_short_description))

    docstring = parse(
        """
        >>> some_function(foo, bar)
        >>>
        Some function blah blah.
        """
    )
    assert docstring.meta == []
    assert docstring.short

# Generated at 2022-06-23 17:22:17.665633
# Unit test for function parse
def test_parse():
    doc = parse(
        """
        Test function.

        :param a: first param
        :param b: does things

        :returns: MyThing
        """
    )
    print(doc)
    assert doc.meta == [
        DocstringParam('a', 'first param', None, None, None),
        DocstringParam('b', 'does things', None, None, None),
        DocstringReturns(['returns', 'MyThing'], None, None, None)
    ]
    assert doc.short_description == 'Test function.'
    assert not doc.blank_after_short_description
    assert not doc.blank_after_long_description
    assert doc.long_description is None


# Generated at 2022-06-23 17:22:30.620863
# Unit test for function parse
def test_parse():
    s = '''short description

    long description of this function is here.

    :param arg1: description of arg1
    :param arg2: description of arg2
    :param arg3: description of arg3
        with long lines
    :returns: description of the return value
        with long lines
    :rtype: str
    :raises ValueError: if arg3 == 3
    :raises ValueError: if arg3 == 4
    '''

    res = parse(s)
    assert res
    print(res)
    assert 'arg1' in [p.arg_name for p in res.meta
                      if isinstance(p, DocstringParam)]
    assert 'arg2' in [p.arg_name for p in res.meta
                      if isinstance(p, DocstringParam)]

# Generated at 2022-06-23 17:22:39.563664
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    doc = parse("""\
    :param int a: this is a
    :param str y: this is y
    :kwargs x: this is x
    :returns int: this is return
    :raises Exception: this is raise
    :yields str: this is yield
    """)

    assert doc.short_description is None
    assert doc.blank_after_short_description is False
    assert doc.long_description is None
    assert doc.blank_after_long_description is False

# Generated at 2022-06-23 17:22:48.614678
# Unit test for function parse

# Generated at 2022-06-23 17:22:58.327137
# Unit test for function parse
def test_parse():
    assert parse("Test docstring.") == \
        Docstring(short_description="Test docstring.")
    assert parse("Test docstring.\n\nExtra.") == \
        Docstring(short_description="Test docstring.",
                  blank_after_short_description=True,
                  blank_after_long_description=True,
                  long_description="Extra.")
    assert parse("") == Docstring()
    assert parse("Indented short\ndescription.") == \
        Docstring(short_description="Indented short\n"
                                    "description.")


# Generated at 2022-06-23 17:23:08.382837
# Unit test for function parse
def test_parse():
    docstring = '''
    Short description.

    Long description. Metadata:

    :param arg1: this is arg1
    :type arg1: str
    :param arg2: this is arg2, and it has a longer
        description that spans multiple lines
    :type arg2: str
    :param arg3: this is arg3
    :type arg3: str, optional
    :param arg4: this is arg4, with a default value
    :type arg4: str, optional
    :param arg5: this is arg5, with a default value
    :type arg5: int, optional

    :returns: None
    :rtype: None
    '''
    doc = parse(docstring)
    assert doc.short_description == 'Short description.'
    assert doc.long_description == 'Long description.'

# Generated at 2022-06-23 17:23:18.654957
# Unit test for function parse
def test_parse():
    ds = "test docstring"
    parsed = parse(ds)
    assert ds == parsed.short_description
    assert None == parsed.long_description
    assert parsed.meta == []

    ds = "test docstring\n\nno blank line\n"
    parsed = parse(ds)
    assert "test docstring" == parsed.short_description
    assert "no blank line" == parsed.long_description
    assert parsed.meta == []

    ds = "test docstring\n\nno blank line"
    parsed = parse(ds)
    assert "test docstring" == parsed.short_description
    assert "no blank line" == parsed.long_description
    assert parsed.meta == []

    ds = "test docstring\n\n\nno blank line\n"
    parsed = parse(ds)

# Generated at 2022-06-23 17:23:30.622188
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("A short description.") == Docstring(
        short_description="A short description."
    )
    assert parse(":param a:") == Docstring(meta=[DocstringParam(args=["param", "a"])])
    assert parse(":param a: b\n") == Docstring(
        meta=[DocstringParam(args=["param", "a"], description="b")]
    )
    assert parse(":param a: b\n  c") == Docstring(
        meta=[DocstringParam(args=["param", "a"], description="b\nc")]
    )

# Generated at 2022-06-23 17:23:38.550174
# Unit test for function parse
def test_parse():
    source = """
    Short description of the function.

    This is a long description of the function

    :param int x: first argument
    :param str y: a string argument
    :param list z: a list argument
    :returns: (int, str, list)
    :raises ValueError: when x or y is incorrect
    """
    d = parse(source)
    assert d.short_description == "Short description of the function."
    assert d.long_description == "This is a long description of the function"
    assert d.blank_after_short_description is True
    assert d.blank_after_long_description is False
    assert d.meta
    assert len(d.meta) == 4

# Generated at 2022-06-23 17:23:48.217439
# Unit test for function parse
def test_parse():
    text = """This is a doc string
            
            :param: name A string specifying a name.
            :type: name str

            :param: count An integer.
            :type: int

            :returns: count multiplied by 2.

            """

# Generated at 2022-06-23 17:23:59.522697
# Unit test for function parse
def test_parse():
    src_docstring = '''\
    One line summary.

    :param name: Name of the hello world example.
    :type name: str
    :returns: Dictionary with key "hello" and value of the name parameter.
    :rtype: dict
    '''
    doc = Docstring()
    doc.short_description = 'One line summary.'
    doc.long_description = ''
    doc.meta.append(DocstringParam(
        args=['param', 'name'],
        arg_name='name',
        type_name=None,
        is_optional=None,
        default=None,
        description='Name of the hello world example.'
    ))

# Generated at 2022-06-23 17:24:11.157863
# Unit test for function parse
def test_parse():
    import pytest
    from textwrap import dedent

    def getsig(func):
        return inspect.signature(func)

    def test(docstring, func):
        d = parse(docstring)
        assert d == Docstring.from_object(func)
        if docstring:
            assert d.signature(callable=func) == getsig(func)

    def test_raises(text, exc):
        with pytest.raises(exc):
            parse(text)

    test(None, lambda: 1)
    test_raises(None, TypeError, getsig)

    test(
        "Short desc. Long desc.",
        lambda: 1,
    )

    test(
        """
        Short desc.

        Long desc.
        """,
        lambda: 1,
    )

# Generated at 2022-06-23 17:24:18.569488
# Unit test for function parse
def test_parse():
    docstring = '''
    Short Description
    -----------------

    Long Description
    Line 2


    :param arg1:  Description1.
    :param arg2:  Description2.
    :param arg3:  Description3.
    :param arg4:  Description4.
    :returns:  Description for return value.
    :rtype:  type description.
    :raises X:  Description for X.
    :raises Y:  Description for Y.
    :raises Z:  Description for Z.
    '''

# Generated at 2022-06-23 17:24:23.830278
# Unit test for function parse
def test_parse():
    def fn():
        """One-line docstring.

        :param int arg1: First arg.
        :param arg2: Second arg.
        :type arg2: str
        :raises ValueError: if things go wrong
        :rtype: str
        :returns: nothing
        """

    docstring = parse(inspect.getdoc(fn))
    assert docstring.long_description is None
    assert docstring.short_description == "One-line docstring."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description

    assert len(docstring.meta) == 4
    arg1, arg2, raises, returns = docstring.meta

    assert arg1.description == "First arg."
    assert arg1.arg_name == "arg1"
    assert arg1

# Generated at 2022-06-23 17:24:35.564908
# Unit test for function parse
def test_parse():
    def t(text, docstring):
        assert parse(text) == docstring


# Generated at 2022-06-23 17:24:44.643301
# Unit test for function parse
def test_parse():
    code = """
    Add a and b

    :param a: First integer
    :param b: Second integer
    :returns: a + b
    """
    docstr = parse(code)
    assert docstr.short_description == "Add a and b"
    assert docstr.meta[0].arg_name == "a"
    assert docstr.meta[0].type_name == "First integer"
    assert docstr.meta[1].arg_name == "b"
    assert docstr.meta[1].type_name == "Second integer"
    assert docstr.meta[2].type_name == "a + b"

# Generated at 2022-06-23 17:24:55.355580
# Unit test for function parse
def test_parse():
    
    docstr = """
        Summary line.

        Extended description of function.

        :param int x: Description of x
        :param y: Description of y
        :returns: Description of return value
        :raises ValueError: if x is negative
    """
    parsed = parse(docstr)
    print(parsed)
    print(parsed.short_description)
    print(parsed.long_description)
    print(parsed.meta[0])
    print(parsed.meta[1])
    print(parsed.meta[2])
    print(parsed.meta[3])
    assert parsed.short_description == "Summary line."
    assert parsed.long_description == "Extended description of function."

# Generated at 2022-06-23 17:25:02.568933
# Unit test for function parse
def test_parse():
    def _parse_raise(self):
        parse(None)
    self.assertRaises(ParseError, _parse_raise(self))
    docstring = """class
    docstring
    """
    parsed1 = parse(docstring)
    self.assertEqual(parsed1.long_description, "class\n    docstring")
    self.assertEqual(parsed1.short_description, "class")
    self.assertFalse(parsed1.blank_after_long_description)
    self.assertFalse(parsed1.blank_after_short_description)
    self.assertEqual(len(parsed1.meta), 0)
    docstring = """class
    docstring

    """
    parsed2 = parse(docstring)

# Generated at 2022-06-23 17:25:06.746074
# Unit test for function parse
def test_parse():
    import json

    code = parse.__code__
    f_globals = code.co_consts[1]
    assert json.loads(f_globals)


# Unit tests for function parse

# Generated at 2022-06-23 17:25:17.067071
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("A short desc.") == Docstring(short_description="A short desc.")
    assert (
        parse("A short desc.\n\nAnd a long one.")
        == Docstring(
            short_description="A short desc.",
            long_description="And a long one.",
            blank_after_short_description=False,
            blank_after_long_description=False,
        )
    )

# Generated at 2022-06-23 17:25:26.336937
# Unit test for function parse
def test_parse():
    docstring = """
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """
    #print(parse(docstring).to_dict())
    obj = parse(docstring)

    assert obj.short_description == 'Parse the ReST-style docstring into its components.'

    assert obj.blank_after_short_description is True
    assert obj.blank_after_long_description is False
    assert obj.long_description == ''

    assert len(obj.meta) == 1
    assert obj.meta[0].description == 'parsed docstring'

# Generated at 2022-06-23 17:25:32.165707
# Unit test for function parse
def test_parse():
    text = '''
    Test docstring parsing.
    :param a: parameter a
    :param b: parameter b
    :type b: int
    :yields: returns the average of a and b
    '''
    doc = parse(text)
    assert doc.short_description == 'Test docstring parsing.'
    assert doc.long_description == None
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 3

# Generated at 2022-06-23 17:25:40.776668
# Unit test for function parse
def test_parse():
    # To test for ValueError
    assert parse("") == Docstring("", None, False, False, None, [])
    # To test for AttributeError
    assert parse("hey") == Docstring("hey", None, False, False, None, [])
    # To test for ParseError
    assert parse("hey:") == Docstring("hey", None, False, False, None, [])
    # Normal cases
    assert parse("hey:he:hi") == Docstring("hey", None, False, False, None, [])
    assert parse("hey:he:h:") == Docstring("hey", None, False, False, None, [])
    assert parse("hey:he:h:hi") == Docstring("hey", None, False, False, None, [])

# Generated at 2022-06-23 17:25:47.563170
# Unit test for function parse
def test_parse():
    docstring = "This is a short description.\n\nAnd this is the long description.\n\n:param str bar: This is description for bar.\n:param foobar baz: string, optional. This is description for baz. Defaults to 'baz'.\n:returns: This is description for returns.\n"
    assert parse(docstring)

# Generated at 2022-06-23 17:25:51.827314
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    # Simple case: short description only.
    assert parse("short desc.") == Docstring(
    short_description="short desc.",
    )

    # Long description.
    assert parse("short desc.\n\nlong desc.") == Docstring(
        short_description="short desc.",
        blank_after_short_description=True,
        long_description="long desc.",
        blank_after_long_description=True,
    )

    # Long description.
    assert parse("short desc.\n\nlong desc.\n") == Docstring(
        short_description="short desc.",
        blank_after_short_description=True,
        long_description="long desc.",
        blank_after_long_description=True,
    )

    # Long description followed by meta.
    assert parse

# Generated at 2022-06-23 17:25:57.828042
# Unit test for function parse
def test_parse():
    text =  """This is a test docstring.
    This is a test docstring.
    This is a test docstring.

    :param str test1: This is a test docstring.
    :param str test2: This is a test docstring.
    :param str test3: This is a test docstring.
    :raises RuntimeError: This is a test docstring.
    :raises TypeError: This is a test docstring.

    This is a test docstring.
    This is a test docstring.

    :returns: This is a test docstring.
    """
    s = parse(text)
    assert s.short_description == "This is a test docstring."
    assert s.blank_after_short_description == True
    assert s.blank_after_long_description == False
    assert s.long_

# Generated at 2022-06-23 17:26:07.819525
# Unit test for function parse
def test_parse():

    text = """\
            This is a short_description.
            
            This is a long description.
            """
    print("test_parse:")
    result = parse(text)
    assert isinstance(result, Docstring)
    assert result.short_description == "This is a short_description."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    print(result)

    text = """\
            :param arg1: This is a desc
            :param arg2: This is another desc
            :param arg3: This is a desc
              with a newline
            """
    print("test_parse:")
    result = parse(text)
    assert isinstance(result, Docstring)


# Generated at 2022-06-23 17:26:16.761521
# Unit test for function parse
def test_parse():
    assert parse("Test parse.\n") == Docstring(short_description='Test parse.')
    assert parse("Test parse.\n\nTest long description.") == Docstring(short_description='Test parse.', blank_after_short_description=True, blank_after_long_description=False, long_description='Test long description.')
    assert parse("Test parse.\n\nTest long description.\n\n") == Docstring(short_description='Test parse.', blank_after_short_description=True, blank_after_long_description=True, long_description='Test long description.')

# Generated at 2022-06-23 17:26:25.819981
# Unit test for function parse
def test_parse():
    docstring = """This is a test docstring.

A longer description.
    :param a: first param
    :param b: second param
    :param c?: optional param
    :returns: some description
        with multiple lines
    :raises: an error"""
    parsed = parse(docstring)
    assert parsed.short_description == "This is a test docstring."
    assert parsed.long_description == "A longer description."
    assert len(parsed.meta) == 3
    assert parsed.meta[0].arg_name == "a"
    assert parsed.meta[1].arg_name == "b"
    assert parsed.meta[2].type_name == "an error"