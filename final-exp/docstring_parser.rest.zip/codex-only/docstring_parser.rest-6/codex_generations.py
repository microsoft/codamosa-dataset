

# Generated at 2022-06-23 17:16:34.935260
# Unit test for function parse
def test_parse():
    t="""
    read pid
    
    Read PID value
    
    :param str pid: PID file
    :returns: read PID
    """
    t2="""
    read pid
    
    Read PID value
    
    :param str pid: PID file
    :returns: read PID
    
    
    
    
    
    
    
    """
    d = parse(t2)
    assert d.short_description == "read pid"
    assert d.long_description == "Read PID value"
    assert d.blank_after_short_description
    assert d.blank_after_long_description
    assert d.meta[0].arg_name == "pid"
    assert d.meta[0].description == "PID file"

# Generated at 2022-06-23 17:16:44.795384
# Unit test for function parse
def test_parse():
    """Test for function parse, with different docstring format."""

# Generated at 2022-06-23 17:16:56.390445
# Unit test for function parse
def test_parse():
    text = """
    This is short description.
    This is long description.
    :param object obj: This is a object.
    :param int a: This is a int number.
    :returns: This is a return value.
    :rtype: str
    """

# Generated at 2022-06-23 17:17:04.954923
# Unit test for function parse
def test_parse():
    docstring = """
    This is short description.

    This is long description.

    :param x: parameter x
    :param y: parameter y
    :type y: str
    :raises TypeError: if y is str
    :returns: nothing
    :rtype: None
    """


# Generated at 2022-06-23 17:17:10.379841
# Unit test for function parse
def test_parse():
    docstring = """
    This is the short description.
    This is the first line of the long description.
    :param str? foo: The foo argument.  Defaults to 'foofoo'.
    :param str bar: The bar argument.
    :param c: The c argument.
    :returns: This is the return value description.
    :raises ValueError: If something went wrong.
    """

# Generated at 2022-06-23 17:17:19.407814
# Unit test for function parse
def test_parse():
    assert parse("Test parse") == Docstring(
        short_description="Test parse", long_description=None, meta=[]
    )

    assert parse("Test parse\n  with multiple lines\n") == Docstring(
        short_description="Test parse",
        long_description="with multiple lines",
        meta=[],
    )

    assert parse("Test parse\n\n with multiple lines") == Docstring(
        short_description="Test parse",
        long_description="with multiple lines",
        meta=[],
    )

    assert parse("Test parse\n\n with multiple lines") == Docstring(
        short_description="Test parse",
        long_description="with multiple lines",
        meta=[],
    )


# Generated at 2022-06-23 17:17:23.674836
# Unit test for function parse
def test_parse():
    doc = """
        This is a module docstring.

        This it the long description.

        :param i: integer input
        :returns: integer
        :raises ValueError: if i is zero
    """
    actual = parse(doc)

# Generated at 2022-06-23 17:17:34.347118
# Unit test for function parse
def test_parse():
    text = """
Single-line short description.

Single-line long description.

:param name:
    Single-line parameter description.

    Single-line argument description.
:type name:
    str

:returns:
    Single-line returns description.

:rtype:
    int
    """

    result = parse(text)
    expected = Docstring()
    expected.short_description = "Single-line short description."
    expected.long_description = "Single-line long description."
    expected.blank_after_short_description = False
    expected.blank_after_long_description = True

# Generated at 2022-06-23 17:17:45.291012
# Unit test for function parse
def test_parse():
    """Tests the parse function"""
    # Given a docstring
    good_docstring = """
    Short description.
    Long description
    

    :param int first_param: This is the first parameter
    """
    # When we parse it
    parsed_docstring = parse(good_docstring)
    assert parsed_docstring.short_description == "Short description."
    assert parsed_docstring.long_description == "Long description"
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_docstring.blank_after_long_description == False
    assert parsed_docstring.meta == [DocstringParam(["param", "int", "first_param"],
                                   "This is the first parameter", "first_param", "int",
                                   False, None)]

# Generated at 2022-06-23 17:17:52.824493
# Unit test for function parse
def test_parse():
    text = """
    :short: Docstring short description line.
    :long:  Docstring long description line.
    :param name:  Name of person.
    :type name:  str
    :param age:  Age of person.
    :type age:  int
    :param bool:  Whether bool.
    :return:  None
    """

    docstring = parse(text)
    print(docstring)
    assert docstring.short_description == "Docstring short description line."
    assert len(docstring.meta) == 3
    assert docstring.meta[0].arg_name == "name"
    assert docstring.meta[1].arg_name == "age"
    assert not docstring.meta[1].default
    assert docstring.meta[2].arg_name == "bool"

# Generated at 2022-06-23 17:18:04.283392
# Unit test for function parse
def test_parse():
    test_text = inspect.cleandoc(
        """
    This is a docstring for the function.

    :param str name: Name of the function.
    :param float optional_name=1.0: Description of optional argument.
    :param float? optional_name: Description of optional argument.
    :param optional_name=1.0: Description of optional argument.
    :yields: int: The number 1.
    :raises ValueError: If negative value encountered.
    :raises: If negative value encountered.

    This is the long description.
    """
    )
    docstring = parse(test_text)

    # Test the fields
    assert docstring.short_description == "This is a docstring for the function."
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after

# Generated at 2022-06-23 17:18:12.795375
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse(None) == Docstring()
    assert parse(" \n ") == Docstring()

    assert parse("""
    Short description.

    Long description.
    """) == Docstring(
        short_description="Short description.",
        long_description="Long description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

    assert parse("""
    Short description.

        Long description.
    """) == Docstring(
        short_description="Short description.",
        long_description="Long description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )


# Generated at 2022-06-23 17:18:21.576157
# Unit test for function parse
def test_parse():
    text = """
    short_description

    long description
    """
    assert parse(text) == Docstring(
        short_description="short_description",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="long description",
        meta=[],
    )

    text = """
    short_description

    long description

    :kw1 foo: doc1
    :kw2: doc2

    """

# Generated at 2022-06-23 17:18:31.613545
# Unit test for function parse
def test_parse():
    text = '''
    Short description.

    Long description line one.
    Long description line two.

    :param param_name: Parameter description
    :type param_name: str
    :param param_name2: Parameter description
    :type param_name2: int
    :param param_name3: Parameter description
    :type param_name3: dict
    :returns: Return description
    :rtype: str
    :returns: Return description
    :rtype: None
    :yields: Yield description
    :yieldtype: str
    '''

    print(parse(text))


if __name__ == '__main__':
    test_parse()

# EOF

# Generated at 2022-06-23 17:18:43.946924
# Unit test for function parse
def test_parse():
    docstring = '''
    Simple docstring.

    :param str arg: the argument
    :param arg2: the second argument
    '''

# Generated at 2022-06-23 17:18:52.596186
# Unit test for function parse
def test_parse():
    res = parse("""
    This is a short description

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :type arg2: str
    :returns: This is what is returned.
    :rtype: int

    This is a long description.
    It can go on for multiple lines.
    """)
    assert res.short_description == "This is a short description"
    assert res.long_description == "This is a long description.\nIt can go on for multiple lines."
    assert res.blank_after_short_description
    assert res.blank_after_long_description
    assert len(res.meta) == 4
    assert res.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-23 17:18:59.131175
# Unit test for function parse
def test_parse():
    def foo(a=1):
        """Compute some value.

        :param a: First argument
        :type a: int
        :returns: computed value
        :raises ValueError: when something is wrong
        """


# Generated at 2022-06-23 17:19:11.347206
# Unit test for function parse

# Generated at 2022-06-23 17:19:18.953401
# Unit test for function parse
def test_parse():
    import unittest

    class Testcases(unittest.TestCase):
        def check(self, docstring, expected):
            ret = parse(docstring)
            self.assertEqual(ret, expected)

        # No description, no metadata
        def test_parse_no_desc_no_meta(self):
            self.check("", Docstring())

        # No description, metadata

# Generated at 2022-06-23 17:19:24.356854
# Unit test for function parse
def test_parse():
    text = '''
    short description.

    long description.

    :param name: The name.
    :type name: str
    :param id: The unique identifier.
    :type list: list
    :param int: The integer.
    :type int: int

    :returns: integer.
    :rtype: int
    '''
    assert str(parse(text)) == text

# Generated at 2022-06-23 17:19:36.292500
# Unit test for function parse
def test_parse():
    docstring = '''
        Example of a function docstring

        :param param1: This describes the parameter, param1
        :type param1: int
        :return: None
        :rtype: None
        '''
    parsed_docstring = parse(docstring)
    assert(len(parsed_docstring.meta) == 2)
    assert(parsed_docstring.meta[0].arg_name == 'param1')
    assert(parsed_docstring.meta[0].type_name == 'int')
    assert(parsed_docstring.meta[0].description == 'This describes the parameter, param1')
    assert(parsed_docstring.meta[1].arg_name is None)
    assert(parsed_docstring.meta[1].type_name is None)

# Generated at 2022-06-23 17:19:45.949158
# Unit test for function parse
def test_parse():
    d = Docstring()

    # Basic docstring
    text = ("Basic docstring\n"
            "\n"
            "\n"
            "Some longer text here.\n"
            "\n"
            ":param x: Some param.\n"
            ":type x: int\n"
            "\n"
            ":returns: Something.\n"
            ":rtype: str\n")

    crude = parse(text)
    assert crude == d

    # Basic docstring with type hints

# Generated at 2022-06-23 17:19:49.927084
# Unit test for function parse
def test_parse():
    doc = parse("""
:param int a: blah blah blah
:param int b: blah blah blah
""")
    print(doc)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:19:58.396907
# Unit test for function parse
def test_parse():
    from .common import Docstring
    from .tests.strings import docstring_string_rest as docstring_string
    ds = parse(docstring_string)

# Generated at 2022-06-23 17:20:09.579902
# Unit test for function parse
def test_parse():
    def f():
        """This is my docstring.

        :param type_name foo: This describes the parameter foo.
        :param bar: This describes the parameter bar (which has no name).
        :type bar: int
        :returns: No description
        :rtype: int
        """

    d = parse(f.__doc__)
    assert d.short_description == "This is my docstring."
    assert d.blank_after_short_description is True
    assert d.long_description == (
        "This describes the parameter foo.\n\nThis describes the parameter bar "
        "(which has no name).\n\nNo description"
    )
    assert d.blank_after_long_description is True
    assert len(d.meta) == 3

    mp = d.meta[0]
    assert isinstance

# Generated at 2022-06-23 17:20:18.573224
# Unit test for function parse
def test_parse():
    def test_func():
        """
        A test function.

        :param arg1: first argument
        :param arg2: second argument
        :type arg2: str
        :raises ValueError: if something goes wrong
        :returns: something
        :rtype: str
        """

    docstring = parse(test_func.__doc__)
    assert docstring.short_description == "A test function."
    assert docstring.long_description == "first argument\n\nsecond argument"
    print(docstring)
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["raises", "ValueError"]
    assert docstring.meta[0].type_name == "ValueError"
    assert docstring.meta[1].args == ["returns"]

# Generated at 2022-06-23 17:20:25.508923
# Unit test for function parse
def test_parse():
    docstring = parse.__doc__
    print(docstring)
    ds = parse(docstring)
    assert ds.short_description
    assert ds.long_description
    assert len(ds.meta) == 1
    assert ds.meta[0].args == ['returns']
    assert ds.meta[0].description
    print("\n", ds, "\n")


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:20:32.993006
# Unit test for function parse
def test_parse():
    """
    >>> doc = parse("""

# Generated at 2022-06-23 17:20:39.864726
# Unit test for function parse
def test_parse():
    doc = """\
    This is the short description.

    This is the long description.
    It exists.

    :param x: This is the description of x.
    :param y: This is the description of y.

    """
    output = parse(doc)
    assert output.short_description == "This is the short description."
    assert output.long_description == "This is the long description.\nIt exists."
    assert output.blank_after_short_description == True
    assert output.blank_after_long_description == False



# Generated at 2022-06-23 17:20:51.857460
# Unit test for function parse
def test_parse():
    text = '''
    Short description.

    Long description.

    :param arg1: parameter description
    :type arg1: str
    :param arg2: parameter description
    :type arg2: str, optional
    :param arg3: parameter description
    :param arg4: parameter description, defaults to 'foo'.
    :param arg5: parameter description
    :type arg5: None, optional
    :param arg6: parameter description
    :type arg6:
    :returns: return description
    :rtype: int
    :raises: something bad
    '''

# Generated at 2022-06-23 17:21:00.652369
# Unit test for function parse
def test_parse():
    str = """Module for testing docstring parsing.

    Usage::

        from docscrape_sphinx import parse

        parse(s)

    Parameters
    ----------
    s : str
        String representation of a docstring.
    """

    doc = parse(str)
    assert doc.short_description == "Module for testing docstring parsing."
    assert doc.long_description == """Usage::

    from docscrape_sphinx import parse

    parse(s)"""
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert len(doc.meta) == 1
    assert doc.meta[0].key == "parameters"
    assert doc.meta[0].args == ["Parameters"]
    assert doc.meta[0].description == "---------"
    assert doc

# Generated at 2022-06-23 17:21:07.485674
# Unit test for function parse
def test_parse():
    docstring = """
        Short description.

        Long description.

        :param foo: foo meta
        """
    assert parse(docstring) == Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        long_description="Long description.",
        blank_after_long_description=True,
        meta=[DocstringMeta(args=["param", "foo"], description="foo meta")],
    )

# Generated at 2022-06-23 17:21:13.408912
# Unit test for function parse

# Generated at 2022-06-23 17:21:21.176607
# Unit test for function parse
def test_parse():
    assert parse('"my function"')
    assert parse("""   my function""")
    assert parse("""\
    my function definition
    """)
    assert parse("""\
    my function
    definition
    """)
    assert parse("""\
    my function definition
    """)
    assert parse("""\

    my function definition
    """)
    assert parse("""\

    my function definition

    """)
    assert parse("""\
    my function definition


    """)

    assert parse("""\
    my function definition

    :raises: NameError
    """)
    assert parse("""\
    my function definition

    :raises NameError:
    """)
    assert parse("""\
    my function definition

    :raises NameError: NameError description
    """)

# Generated at 2022-06-23 17:21:28.837668
# Unit test for function parse
def test_parse():
    text = """
    parse(text: str) -> Docstring

    Parse the ReST-style docstring into its components.

    :param text: docstring text
    :type text: str
    :returns: parsed docstring
    :raises ParseError: if parsing fails
    """

    doc = parse(text)
    assert doc.short_description == "Parse the ReST-style docstring into its components."
    assert doc.long_description == (
        "Parse the ReST-style docstring into its components."
    )
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is True

    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["param", "text", ":"]
    assert doc.meta[0].arg

# Generated at 2022-06-23 17:21:40.357885
# Unit test for function parse
def test_parse():
    text = """
    Test function

    :param argname argtype: Description of what argname is
    :param opt_argname opt_argtype? (optional): Description of what opt_argname is
    :returns: Description of what the function returns
    :raises exception_type_name: Description of the exception
    :yields: Description of what the generator yields
    :yields opt_type_name opt_argname? (optional): Description of what opt_argname is
    """
    assert parse(text).short_description == 'Test function'
    assert parse(text).long_description == 'Description of what argname is\nDescription of what opt_argname is'
    assert parse(text).meta[0].description == 'Description of what argname is'

# Generated at 2022-06-23 17:21:45.011223
# Unit test for function parse
def test_parse():
    docstring = '''
        Short description.
        Long description.

        :param arg: the argument.
        :type arg: int
        
        :raises ValueError: if invalid.
        :returns: description of return value
        :rtype: int
    '''
    parsed = parse(docstring)
    print(parsed)

# Generated at 2022-06-23 17:21:56.192763
# Unit test for function parse

# Generated at 2022-06-23 17:22:06.770933
# Unit test for function parse
def test_parse():
    import unittest
    class ParseTest(unittest.TestCase):
        def test_parse(self):
            docstring = """
            This is a description.

            :param first_arg: 
            :type first_arg: str
            :param second_arg: 
            :param third_arg: 
            :raises RuntimeError: 
            :yields result:
            :returns: 
            """
            res = parse(docstring)

# Generated at 2022-06-23 17:22:17.729084
# Unit test for function parse
def test_parse():
    assert parse("""
    This is a description.
    """) == Docstring(
        short_description="This is a description.",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[]
    )
    assert parse("""
    This is a description.

    This is a long description.
    """) == Docstring(
        short_description="This is a description.",
        long_description="This is a long description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[]
    )

# Generated at 2022-06-23 17:22:30.686713
# Unit test for function parse
def test_parse():
    import inspect
    text = '''
    This is a test.
    
    :param arg1: Test arg1.
    :param arg2: Test arg2.
    :param arg3: Test arg3.
    :type arg1: str
    :type arg2: int
    :type arg3: float
    :return: Test return.
    :rtype: str
    :returns: Test also return.
    :rtype: str
    :yield: Test yield.
    :ytype: str
    :yields: Test also yield.
    :ytype: str
    :raise AttributeError: Test attribute error.
    :raises AttributeError: Test also attribute error.
    '''
    
    test_docstring = parse(text)
    assert len(test_docstring.meta) == 10


# Generated at 2022-06-23 17:22:38.060404
# Unit test for function parse
def test_parse():
    docstring = """
    Parse the ReST-style docstring into its components.

    :param str arg: arg description
    :returns: parsed docstring
    """
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == "Parse the ReST-style docstring into its components."
    assert parsed_docstring.long_description == None
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_docstring.meta == [DocstringParam(["param", "str", "arg:"], "arg description", "arg", "str", False, None)]

# Generated at 2022-06-23 17:22:47.384118
# Unit test for function parse
def test_parse():
    docstr = """
        My short description


        My long description


        :param int foo: Foo is an integer
    """
    result = parse(docstr)
    assert result.short_description == 'My short description'
    assert result.long_description == 'My long description'
    param = result.meta[0]
    assert param.keyword == 'param'
    assert param.arg_name == 'foo'
    assert param.type_name == 'int'
    assert param.description == 'Foo is an integer'
    assert param.is_optional is False
    assert param.default is None

    docstr2 = """
        My short description


        My long description


        :param foo: Foo is an integer
    """
    result = parse(docstr2)

# Generated at 2022-06-23 17:22:50.368257
# Unit test for function parse
def test_parse():
    text = """\
    Initialize self.  See help(type(self)) for accurate signature.\
    \n:param x: \
    """



# Generated at 2022-06-23 17:22:55.434213
# Unit test for function parse
def test_parse():
    sample_docstring = """This is a sample docstring.

    Parameters
    ----------
    x : str
        The name of the variable.
    y : int, optional
        The value of the variable.
        Defaults to 3.
    z : list[int], default=None
        The list of values in the variable.

    Returns
    -------
    int
        The sum of values of x, y and z.

    Raises
    ------
    ValueError
        If the value of x is negative.
        It can also be raised if the value of z is equal to 3.
    TypeError
        If the value of y is not an integer.

    Notes
    -----
    List of notes.
    """
    docsting_obtained = parse(sample_docstring)

# Generated at 2022-06-23 17:23:06.925148
# Unit test for function parse
def test_parse():
    def f():
        """
        Short desc.

        Long desc.

        :param x:
            first param.
        :param y: second param.
            Longer description of second param.
        :param z: (optional)
            third param.
        """

    ds = parse(f.__doc__)

    assert ds.short_description == "Short desc."
    assert ds.blank_after_short_description
    assert ds.long_description == "Long desc."
    assert ds.blank_after_long_description == False

    assert ds.meta[0].key == "param"
    assert ds.meta[0].arg_name == "x"
    assert ds.meta[0].type_name == None
    assert ds.meta[0].is_optional == False
    assert ds

# Generated at 2022-06-23 17:23:17.901660
# Unit test for function parse

# Generated at 2022-06-23 17:23:29.919429
# Unit test for function parse

# Generated at 2022-06-23 17:23:38.060593
# Unit test for function parse
def test_parse():
    """Parse docstrings and ensure they're converted to the proper Docstring object."""
    docstring = parse(
        """
        Short description.

        Long description.

        :param arg1: Description of arg1
        :param arg2: Description of arg2

        :rtype: Description of the return value
        :return: Description of the return value
        """
    )

    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description

    assert len(docstring.meta) == 3

    assert docstring.meta[0].keyword == "param"
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].type

# Generated at 2022-06-23 17:23:43.804478
# Unit test for function parse
def test_parse():
    # TODO: add test for docstrings with desc_chunk and meta_chunk in one line
    text = """
    Short description.

    Long description.

    :param int first: first line of the param description
                      second line of the param description

    :returns: return description
    :rtype: int

    :raises TypeError: raise description
    """
    print(parse(text))



# Generated at 2022-06-23 17:23:46.090783
# Unit test for function parse
def test_parse():
    doc = """
        Short description.
        Long description.
        
        :param int arg: arg description
        :raises ValueError: if something bad happens
    """
    parse(doc)

# Generated at 2022-06-23 17:23:48.002373
# Unit test for function parse
def test_parse():
    print(parse(inspect.getsource(parse)))



# Generated at 2022-06-23 17:23:59.286619
# Unit test for function parse
def test_parse():
    docstring = '''
        This is the short description.

        This is the long description.

        :param int a: Parameter a
        :param int b: Parameter b. Defaults to 3.
        :returns int:
        :raises TypeError: if x is not an int
    '''
    doc = parse(docstring)
    assert doc.short_description == "This is the short description."
    assert doc.long_description == "This is the long description."
    assert doc.blank_after_short_description
    assert not doc.blank_after_long_description

    assert isinstance(doc.meta[0], DocstringParam)
    assert doc.meta[0].arg_name == "a"
    assert doc.meta[0].type_name == "int"
    assert not doc.meta[0].is_

# Generated at 2022-06-23 17:24:10.700973
# Unit test for function parse

# Generated at 2022-06-23 17:24:18.184579
# Unit test for function parse
def test_parse():
    docstr = """\
    This is a simple docstring.

    :param x: something, defaults to 5.
    :type x: int or None, optional

    :raises KeyError: if something goes wrong.
    :returns: x
    :rtype: int
    """ 
    #r"""
    #This is a simple docstring.

    #:param x: something, defaults to 5.
    #:type x: int or None, optional

    #:raises KeyError: if something goes wrong.
    #:returns: x
    #"""
    print(parse(docstr).short_description)
    print(parse(docstr).long_description)
    for meta in parse(docstr).meta:
        print(meta.args)
        print(meta.description)

# Generated at 2022-06-23 17:24:24.779495
# Unit test for function parse
def test_parse():
    text = '''
    Summary line.

    Extended description.

    :param a: parameter a
    :type a: int
    :param b: parameter b
    :type b: str
    :return: return value
    :rtype int:
    :raises TypeError: if a is not a string
    '''
    assert inspect.cleandoc(text) == parse(text).__str__()

# Generated at 2022-06-23 17:24:35.924696
# Unit test for function parse
def test_parse():
    docstring = parse(
        """This is a short description.

This is a longer description.

:param str a: Description of the first argument.
:param b: Description of the second argument.
:returns: description of the return value
:raises ValueError: if something bad happens
"""
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is True
    assert docstring.long_description == "This is a longer description."
    assert len(docstring.meta) == 4
    assert docstring.meta[2].type_name == "str"
    assert docstring.meta[0].description == "Description of the first argument."

# Generated at 2022-06-23 17:24:46.680500
# Unit test for function parse
def test_parse():
    text = '''
        Short description.

        Long description.

        :param arg1: First arg.
        :param arg2: Second arg.
        :type arg2:
        :return: Nothing.
        :rtype: None
        :raises ValueError: When arg2 is None.

        :param arg3: Third arg.
        :type arg3: T.Iterable[int]
            This is a long description. You can span it over several
            lines if you need to.
        :return: Something.
    '''
    # import pdb; pdb.set_trace()
    res = parse(text)
    assert res.short_description == "Short description."
    assert res.long_description == "Long description."
    assert res.meta[0].description == "First arg."

# Generated at 2022-06-23 17:24:57.109952
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a summary.

    This is a full description.

    :param name: required, no default
    :param age: optional, defaults to 42
    :returns: stuff
    '''
    result = parse(docstring)
    assert result.short_description == "This is a summary."
    assert result.long_description == "This is a full description."
    assert result.meta[0].args == ['param', 'name']
    assert result.meta[0].description == 'This is a full description.'
    assert result.meta[0].type_name is None
    assert not result.meta[0].is_optional
    assert result.meta[0].default is None
    assert result.meta[1].args == ['param', 'age']

# Generated at 2022-06-23 17:25:07.806712
# Unit test for function parse

# Generated at 2022-06-23 17:25:18.377391
# Unit test for function parse
def test_parse():
    s = '''short description
    long description

    :param name str: description
    :param even_more str: description
        This is multiline description
    :return: description
    :rtype: str
    :raises Exception: description
    '''
    docstr = parse(s)
    assert docstr.short_description == 'short description'
    assert docstr.long_description == 'long description'
    assert docstr.meta[0].args == ['param', 'name', 'str']
    assert docstr.meta[1].args == ['param', 'even_more', 'str']
    assert docstr.meta[2].args == ['return']
    assert docstr.meta[3].args == ['rtype', 'str']
    assert docstr.meta[4].args == ['raises', 'Exception']

# Generated at 2022-06-23 17:25:30.126125
# Unit test for function parse
def test_parse():
    from docstring_parser import parse

    docstring = """
    The :py:class:`~.Document` class represents a parsed reStructuredText
    document tree.

    :param source: The input text, as unicode or ascii byte string.

    :param settings: Document settings as keyword arguments.  See the
        :doc:`/user/config` for an overview of allowed keyword arguments.
    """

    doc = parse(docstring)

    print (doc.meta[1].default)

    assert doc.short_description == "The :py:class:`~.Document` class represents a parsed reStructuredText\ndocument tree."

# Generated at 2022-06-23 17:25:34.623058
# Unit test for function parse
def test_parse():
    docstring = """
    This function does something.

    :param something: something
    :type something: int

    :param something: something else
    :type something: str
    """
    ret = parse(docstring)
    assert len(ret.meta) == 2


# Generated at 2022-06-23 17:25:41.886294
# Unit test for function parse
def test_parse():
    text = """
:param x: A thing
:param y: Another thing
    """

    assert parse(text) == parse(text.replace("\n", " "))
    assert parse(text) == parse(text.replace("\n", "  "))
    assert parse(text) == parse(text.replace("\n", ""))
    assert parse(text) == parse(text.replace("\n", "   "))
    assert parse(text).short_description == None
    assert parse(text).long_description == None
    assert parse(text).meta[0].args == ["param", "x"]
    assert parse(text).meta[0].description == "A thing"
    assert parse(text).meta[1].args == ["param", "y"]
    assert parse(text).meta[1].description == "Another thing"



# Generated at 2022-06-23 17:25:52.909139
# Unit test for function parse
def test_parse():
    docstr = """
    This is a short description.

    This is a long description.
    """
    d = parse(docstr)
    assert not d.meta
    assert d.short_description == "This is a short description."
    assert d.long_description == "This is a long description."
    assert d.blank_after_short_description
    assert d.blank_after_long_description
    docstr = """
    This is a short description.
    :param foo: This is foo
    :type foo: int
    :returns: This is a return

    This is a long description.
    """
    d = parse(docstr)
    assert len(d.meta) == 2
    param = d.meta[0]
    assert param.args == ["param", "foo"]

# Generated at 2022-06-23 17:26:03.992819
# Unit test for function parse
def test_parse():
    s = """\
    Short summary
    Long summary
    Long summary

    :param abc: abc
    """

    ret = parse(s)
    assert ret.short_description=='Short summary'
    assert ret.long_description=='Long summary\nLong summary'
    assert len(ret.meta)==1
    assert ret.meta[0].arg_name=='abc'
    assert ret.meta[0].description=='abc'

    s = """
    Short summary
    Long summary
    Long summary

    :param x: the x coordinate
    :param: y the y coordinate
    :returns: (x,y)
    """
    ret = parse(s)
    assert len(ret.meta)==3
    assert ret.meta[0].arg_name=='x'

# Generated at 2022-06-23 17:26:13.916318
# Unit test for function parse
def test_parse():
    r = parse("""This is a fn.

    This is the long description.  It is longer than the short description.

    :param x: here is a param of type integer
    :returns: here is the return type
    :raises ValueError: if x is not of type integer""")
    assert r.short_description == "This is a fn."
    assert r.long_description == """This is the long description.  It is longer than the short description."""
    assert len(r.meta) == 3
    assert r.meta[0].keyword == "param"
    assert r.meta[0].args == ["param", "x"]
    assert r.meta[0].arg_name == "x"
    assert r.meta[0].type_name is None
    assert r.meta[0].is_optional is None
   

# Generated at 2022-06-23 17:26:22.806325
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    d = Docstring()
    d.short_description = "Short description"
    d.blank_after_short_description = True
    d.long_description = "Long description"
    d.blank_after_long_description = True
    assert parse("Short description\n\nLong description\n\n") == d
    d.long_description = "Long description\nLine break"
    d.blank_after_long_description = False
    assert parse("Short description\n\nLong description\nLine break\n") == d
    d.short_description = None
    d.blank_after_short_description = False
    d.long_description = "Long description"
    d.blank_after_long_description = True

# Generated at 2022-06-23 17:26:33.322163
# Unit test for function parse
def test_parse():
    s = parse('single line')
    assert s.short_description == 'single line'
    assert s.long_description is None
    assert s.blank_after_long_description is False
    assert s.blank_after_short_description is False
    assert len(s.meta) == 0

    s = parse("""
    first line
    second line
    """)
    assert s.short_description == 'first line'
    assert s.long_description == 'second line'
    assert s.blank_after_long_description is False
    assert s.blank_after_short_description is False
    assert len(s.meta) == 0

    s = parse("""
    
    
    first line
    second line
    """)
    assert s.short_description == 'first line'