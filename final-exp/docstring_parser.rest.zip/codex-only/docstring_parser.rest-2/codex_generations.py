

# Generated at 2022-06-23 17:16:33.767545
# Unit test for function parse
def test_parse():
    """Test function parse using docstring as input."""
    from sys import modules
    from inspect import getdoc
    from .common import DocstringParam
    from .parse import parse
    from .parse_rest import parse as parse_rest
    from .parse_google import parse as parse_google
    docstring = "getItem(key) --> item corresponding to the given key"

# Generated at 2022-06-23 17:16:40.510465
# Unit test for function parse
def test_parse():
    assert parse("hello") == parse("hello   \n")
    assert parse("hello\nworld") == parse("hello\n  world")
    assert parse("hello\nworld\n") == parse("hello\n  world\n")


# Generated at 2022-06-23 17:16:48.170822
# Unit test for function parse
def test_parse():
    text = '''
    Example that parses this docstring.

    Examples
    --------
    This is where you describe how to use the function
    and provide examples of input and output.

    :param name: The name of the variable to assign.

    :param value: The value being assigned to the variable.

    :raises TypeError: If the value is of wrong type.
    '''
    ret = parse(text)
    assert len(ret.meta) == 3
    assert isinstance(ret.meta[0], DocstringMeta)
    assert isinstance(ret.meta[1], DocstringParam)
    assert isinstance(ret.meta[2], DocstringRaises)
    assert ret.meta[1].arg_name == "name"
    assert ret.meta[2].type_name == "TypeError"
    assert ret.long_

# Generated at 2022-06-23 17:16:59.080980
# Unit test for function parse
def test_parse():
    d = """A one-line summary

    A longer description.

    :param str x: Some abbreviation.
    :param int y: Some abbreviation.
    :returns: Something.
    :raises Exception: For some reason.
    """

# Generated at 2022-06-23 17:17:05.632808
# Unit test for function parse
def test_parse():
    text = "Short description.\n\n    Long description."
    result = parse(text)
    assert result.short_description == "Short description."
    assert result.long_description == "Long description."
    assert result.meta == []
    assert not result.blank_after_short_description
    assert not result.blank_after_long_description

    text = "Short description.\n:param str a: A parameter."
    result = parse(text)
    assert result.short_description == "Short description."
    assert result.long_description is None

# Generated at 2022-06-23 17:17:16.081259
# Unit test for function parse
def test_parse():
    docstring = """This is a short description.
This is a long description.

:param str name: The name of the person.
:param int age: The age of the person.
:returns: a Person object
:rtype: Person
:raises ValueError: if age < 0"""


# Generated at 2022-06-23 17:17:27.625147
# Unit test for function parse
def test_parse():
    # These things get parsed
    parse("x")
    parse("x\ny")
    parse("x\n\n\ny")
    parse("x\n\n\n\ny")
    parse("x: a\ny")
    parse("x: a\n: y: b\n    z\n\ny")
    parse("x: a\n: y: b\n\n    z\n\ny")
    parse("x: a\n: y: b\n:   z\n\ny")
    parse("x: a\n: y: b\n:   z")
    parse("x: a\n: y: b\n  z")
    parse("x: a\n  z")
    parse("x: a\n:y: b\n  z")

# Generated at 2022-06-23 17:17:37.737716
# Unit test for function parse
def test_parse():
    docstring = """\
    My function description.

    Here is some detailed description.

    :param arg1: Blah
    :type arg1: int

    :param arg2: Boo
    :type arg2:
        List[bool]

    Extra text is ignored.

    :param arg3: Foo
    :type arg3:
        :class:`MyClass`

    :returns: (optional)
        Some value. If no value, returns None.

    :returns: (optional)
        Some other value.

    """
    doc = parse(docstring)
    assert doc.short_description == "My function description."
    assert doc.long_description == "Here is some detailed description."
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert len

# Generated at 2022-06-23 17:17:42.305450
# Unit test for function parse
def test_parse():
    docstring = '''Returns a single element from the stack.

    :param key: Key name.

    :returns: a single element from the stack.
    '''

    parsed_docstring = parse(docstring)
    print(parsed_docstring.__dict__)

#test_parse()

# Generated at 2022-06-23 17:17:52.707364
# Unit test for function parse
def test_parse():
    docstring = '''one line summary

    :param bar: bar description
    :type bar: str
    :param baz: baz description, defaults to None
    :type baz: int, optional
    :returns: None
    :rtype: NoneType
    :raises ValueError: if bad things happen
    :raises: TypeError
    '''

    doc = parse(docstring)

    assert doc.short_description == 'one line summary'
    assert doc.blank_after_short_description == True
    assert doc.long_description == None
    assert doc.blank_after_long_description == True

    assert doc.meta[0].args == ['param', 'bar']
    assert doc.meta[0].description == 'bar description'
    assert doc.meta[0].arg_name == 'bar'

# Generated at 2022-06-23 17:17:59.264458
# Unit test for function parse
def test_parse():
    doc = '''
    :param key: key
    :type key: int
    :param value: value
    :type value: str
    '''

    assert parse(doc).meta == [
        DocstringParam(
            args=['param', 'key', 'key'],
            description='key',
            arg_name='key',
            type_name='int',
            is_optional=None,
            default=None
        ),
        DocstringParam(
            args=['param', 'value', 'value'],
            description='value',
            arg_name='value',
            type_name='str',
            is_optional=None,
            default=None
        )
    ]

# Generated at 2022-06-23 17:18:10.030786
# Unit test for function parse

# Generated at 2022-06-23 17:18:19.760787
# Unit test for function parse
def test_parse():
    doc = """
    Short description.

    Long description.

    :param  foo: Foo
    """
    assert parse(doc) == Docstring(
        short_description="Short description.",
        long_description="Long description.",
        meta=[
            DocstringParam(
                description="Foo",
                args=["param", "foo"],
                arg_name="foo",
                type_name=None,
                is_optional=None,
                default=None,
            )
        ],
    )
    doc = """
    Short description.

    Long description.

    :type foo: Foo
    """

# Generated at 2022-06-23 17:18:30.869716
# Unit test for function parse

# Generated at 2022-06-23 17:18:43.040054
# Unit test for function parse
def test_parse():
    text = """
    Docstring for a function. The idea is to test the docstring
    parser. It should return the right thing.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :rtype: Nothing.
    :returns: This function returns nothing.
    :raises TypeError: if an invalid type was used.
    :raises NameError: if an invalid name was used.
    """
    parsed_docstring = parse(text)
    assert parsed_docstring.short_description == text.splitlines()[1].strip()
    assert (
        parsed_docstring.long_description.splitlines()[0].strip()
        == "The idea is to test the docstring"
    )
    assert len(parsed_docstring.meta) == 4

# Generated at 2022-06-23 17:18:51.683388
# Unit test for function parse
def test_parse():
    """Test function parse."""
    docstring = parse(
        """
        This is a function to test parsing a docstring.

        :param x: First parameter
        :type x: int
        :param y: Second parameter
        :type y: int
        :returns: Sum of x and y
        :rtype: int
        """
    )
    assert isinstance(docstring, Docstring)
    assert docstring.short_description == "This is a function to test parsing a docstring."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-23 17:18:58.737992
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param any value: Some parameter with a description
    :returns int: Some return description
    :raises ValueError: This raises something
    """
    docstring = parse(docstring)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    param, returns, raises = docstring.meta
    assert isinstance(param, DocstringParam)
    assert param.arg_name == "value"
    assert param.type_name == "any"
    assert param.description == "Some parameter with a description"
    assert param.is_optional is False

# Generated at 2022-06-23 17:19:11.215087
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param path: path in filesystem
    :param flag: reading flag

    :raises RuntimeError: in case of runtime exception
    :returns: True if file exists
    :yields: next line from file
    """
    print("#####")
    print(docstring)
    doc = parse(docstring)
    print("Short Description: {}".format(doc.short_description))
    print("Long Description: {}".format(doc.long_description))
    print("Blank after Short Description: {}".format(doc.blank_after_short_description))
    print("Blank after Long Description: {}".format(doc.blank_after_long_description))
    print("Meta: ")
    for meta in doc.meta:
        print(meta)
   

# Generated at 2022-06-23 17:19:18.878627
# Unit test for function parse
def test_parse():
    test_docstring = """
    This is a test docstring

    This is the long description,
    which has multiple lines.

    :param int arg1: This is the first argument
    :param arg2: This is a second argument
    :return: The return value
    :rtype: int
    :raises ValueError: If any errors occur.
    """
    ret = parse(test_docstring)
    assert ret.short_description == "This is a test docstring"
    assert ret.long_description == (
        "This is the long description,\n"
        "which has multiple lines."
    )
    assert ret.blank_after_short_description
    assert ret.blank_after_long_description
    assert len(ret.meta) == 4

# Generated at 2022-06-23 17:19:28.339258
# Unit test for function parse
def test_parse():

    assert parse("Hello") == Docstring(
        short_description="Hello",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

    assert parse("Hello\n") == Docstring(
        short_description="Hello",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

    assert parse("Hello\n\n") == Docstring(
        short_description="Hello",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description=None,
        meta=[],
    )


# Generated at 2022-06-23 17:19:35.228449
# Unit test for function parse
def test_parse():
    # Interface for input
    input_str = "some_str\n"
    print("User Input: {}".format(input_str))
    # Print the expected output
    print("Expected Output: ")
    print(parse(input_str))
    # Test the function
    print("Output: ")
    test_result = parse(input_str)
    print(test_result)
    return test_result

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:19:43.949211
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    # Simple case
    text = "Sample text."
    assert parse(text).short_description == text

    # Trailing newline
    assert parse(text + "\n").short_description == text

    # Leading, trailing, and internal white space
    assert parse("    " + text + "    ").short_description == text
    assert parse(
        ("    " + text + "    \n \n \n  \n \n \n")
    ).short_description == text

    # Long description
    long_desc_text = "\n".join(["Line 1", "Line 2", "Line 3"])

    docstring = parse(text + "\n\n" + long_desc_text)
    assert docstring.long_description == long_desc_text
    assert docstring.blank_after

# Generated at 2022-06-23 17:19:55.622017
# Unit test for function parse

# Generated at 2022-06-23 17:20:01.917055
# Unit test for function parse
def test_parse():
    text = '''\
    Add numbers together.

    :param x: The first number.
    :param y: The second number.
    :returns: The sum of x and y.

    If either x or y is not a number, then an error is raised.
    '''
    doc = parse(text)
    s = str(doc)
    assert s == text

# Generated at 2022-06-23 17:20:10.838607
# Unit test for function parse
def test_parse():
    import sys
    from . import common

    def test_docstring(text: str) -> T.Tuple[bool, str]:
        try:
            doc = parse(text)
        except common.ParseError as e:
            return False, str(e)
        else:
            return True, repr(doc)

    for name, text in inspect.getmembers(sys.modules[__name__]):
        if name.startswith("_"):
            continue
        status, output = test_docstring(inspect.getdoc(text))
        assert status, output
        print(output)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:20:19.920962
# Unit test for function parse
def test_parse():
    text = """
    """
    assert parse(text) == Docstring()

    text = """
    Short description.
    """
    expected = Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert parse(text) == expected

    text = """
    Short description.

    Long description.
    """
    expected = Docstring(
        short_description="Short description.",
        long_description="Long description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert parse(text) == expected

    text = """
    Short description.

    Long description.

    """

# Generated at 2022-06-23 17:20:31.263440
# Unit test for function parse
def test_parse():
    doc = '''Single line description.

        Long description with a
        continuation.
    '''
    d = parse(doc)
    assert d.short_description == 'Single line description.'
    assert d.blank_after_short_description
    assert d.long_description == 'Long description with a\ncontinuation.'
    assert not d.blank_after_long_description
    assert not d.meta

    doc = '''Single line description.

        :param: one
              Stuff after a blank line.
        :param: two
        :param: three

    '''
    d = parse(doc)
    assert d.short_description == 'Single line description.'
    assert d.blank_after_short_description
    assert not d.long_description
    assert not d.blank_after_long_description

# Generated at 2022-06-23 17:20:41.092729
# Unit test for function parse
def test_parse():
    # Initialize the docstring
    docstring = inspect.getdoc(parse)
    # Check the docstring to see if it is correct
    assert parse(docstring) == Docstring(
        short_description="Parse the ReST-style docstring into its components.",
        blank_after_short_description=True,
        long_description=" :returns: parsed docstring",
        blank_after_long_description=False,
        meta=[
            DocstringMeta(args=["returns"], description="parsed docstring")
        ],
    )
    # Check that there is a blank after the long description
    assert parse(docstring).blank_after_long_description
    # Check that no blank is after the short description
    assert not parse(docstring).blank_after_short_description
    # Check that the long description doesn't have a

# Generated at 2022-06-23 17:20:53.013835
# Unit test for function parse
def test_parse():
    assert parse("a short description") == Docstring(
        "a short description",
        None,
        None,
        False,
        False,
        [],
    )
    assert parse(
        "a short description\n\n    a line of long description\n    another line"
    ) == Docstring(
        "a short description",
        "a line of long description\nanother line",
        True,
        False,
        [],
    )
    assert parse(
        "a short description\n\na line of long description\nanother line"
    ) == Docstring(
        "a short description",
        "a line of long description\nanother line",
        False,
        False,
        [],
    )

# Generated at 2022-06-23 17:21:04.075344
# Unit test for function parse
def test_parse():
    text = """
    a very short description

    a very long description of the function. This can span multiple
    lines, and will be broken into it's own paragraph.

    :param foo: a parameter
    :param bar: another parameter
    :type foo: int
    :type bar: str
    :returns: returns a value
    :raises TypeError: raises an exception
    """

# Generated at 2022-06-23 17:21:15.728187
# Unit test for function parse
def test_parse():
    code = '''
    :param int size: Size of the cache.
    :param bool check: Enable checking. Defaults to False.
    :returns: A value.
    :raises: A value.
    :rtype: float
    :yields: A value.
    :ytype: int
    '''
    docstring = parse(code)
    assert len(docstring.meta) == 6
    assert docstring.meta[0].arg_name == 'size'
    assert docstring.meta[0].type_name == 'int'
    assert docstring.meta[1].arg_name == 'check'
    assert docstring.meta[1].type_name == 'bool'
    assert docstring.meta[1].is_optional == True
    assert docstring.meta[1].default == 'False'
   

# Generated at 2022-06-23 17:21:21.667824
# Unit test for function parse
def test_parse():
    assert parse("""
    Short description.

    Long description.
    """) == Docstring(
        short_description="Short description.",
        long_description="Long description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-23 17:21:27.407524
# Unit test for function parse
def test_parse():
    doc = inspect.cleandoc(
        """
    Arguments
    ---------
    x: float
        A variable.
    y: float
        Another variable.
    z: float
        Yet another variable.
    """
    )
    d = parse(doc)
    assert d
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert len(d.meta) == 3
    assert d.meta[0].description == "A variable."
    assert d.meta[1].description == "Another variable."
    assert d.meta[2].description == "Yet another variable."
    assert d.meta[0].type_name == "float"
    assert d.meta[1].type

# Generated at 2022-06-23 17:21:39.397169
# Unit test for function parse
def test_parse():
    """Test the parse function."""
    def test_parse_function(text, test_func, **kwargs):
        """Test the parse function."""
        try:
            result = parse(text)
        except ParseError as err:
            if "error" in kwargs:
                assert err.__str__() == kwargs["error"]
            else:
                raise err
        else:
            if "error" in kwargs:
                assert False, "Expected ParseError but got no error."
            test_func(result)

    def test_short_description(result, short_description):
        """Apply short description test to parse result."""
        assert result.short_description == short_description

    def test_long_description(result, long_description):
        """Apply long description test to parse result."""
       

# Generated at 2022-06-23 17:21:50.351783
# Unit test for function parse

# Generated at 2022-06-23 17:21:54.150038
# Unit test for function parse
def test_parse():
    text = """Short description.
    
    Long description.
    """
    docstring = parse(text)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."


# Generated at 2022-06-23 17:22:04.739276
# Unit test for function parse
def test_parse():
    assert parse(
        """
    foo bar
    """
    ) == Docstring(
        short_description="foo bar",
        long_description=None,
        meta=[],
        blank_after_short_description=True,
        blank_after_long_description=False,
    )


# Generated at 2022-06-23 17:22:13.864111
# Unit test for function parse
def test_parse():
    docstring = \
    """
    This is a short description of the function.

    This is the long description.

    :param a: This is a description to an argument
    :param b: This is a description to another argument
    :param c: This is a description to a third argument
    :type b: object
    :returns: This is a description of what is returned.
    :raises AttributeError: You get attribute error.

    """
    parsed = parse(docstring)
    assert parsed.short_description == 'This is a short description of the function.'
    assert parsed.long_description == 'This is the long description.'
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False

    assert len(parsed.meta) == 4

# Generated at 2022-06-23 17:22:16.999598
# Unit test for function parse
def test_parse():
    s = '''
        int(x=1)
        :param int x:
    '''
    v = parse(s)
    assert v.meta[0].type_name == 'int'
    assert v.meta[0].arg_name == 'x'
    assert v.short_description == 'int(x=1)'

# Generated at 2022-06-23 17:22:23.597338
# Unit test for function parse
def test_parse():
    docstring = '''\
    This is a short description.

    This is a long description.

    Attributes:
        unique_id: str: Unique identifier of the server.
        last_check_time: int: POSIX timestamp of last check-in.

    :param str unique_id: Unique identifier of the server.
    :param int last_check_time: POSIX timestamp of last check-in.
    '''

    parsed = parse(docstring)
    assert parsed.short_description == 'This is a short description.'
    assert parsed.long_description == 'This is a long description.'
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].keyword == 'Attributes'

# Generated at 2022-06-23 17:22:35.012825
# Unit test for function parse

# Generated at 2022-06-23 17:22:38.060911
# Unit test for function parse
def test_parse():
    doc = """
    Test for parsing docstring.

    This is the long description.
    """

    result = parse(doc)
    assert result.short_description == "Test for parsing docstring."
    assert result.long_description == "This is the long description."

# Generated at 2022-06-23 17:22:43.091150
# Unit test for function parse
def test_parse():
    text = '''\
            Parse a single line docstring.

            :param int x: A integer parameter.
            :param y: A argument without type.
            :return: Value for x.
            :raises ValueError: If x is negative.
            :raises TypeError: If x is not an integer.
            :yields: A value of x.
            '''

    text = inspect.cleandoc(text)

    doc = Docstring()
    doc.short_description = "Parse a single line docstring."
    doc.blank_after_short_description = True
    doc.blank_after_long_description = False
    doc.long_description = None
    doc.meta.append(DocstringMeta(['param', 'int', 'x'], 'A integer parameter.'))

# Generated at 2022-06-23 17:22:48.162732
# Unit test for function parse
def test_parse():
    docstring = """Test parse
    :param name: name of the person
    :type name: string
    :param person: person object
    :type person: Object
    :param is_admin: is admin
    :type is_admin: bool
    :returns: a person object
    :rtype: object
    """
    result = parse(docstring)
    assert result.short_description == "Test parse"
    assert len(result.meta) == 3

# Generated at 2022-06-23 17:22:58.025531
# Unit test for function parse
def test_parse():
    docstring = '''
    The short version.
    
    The long version.

    :param x: The x-coordinate.
    :param y: The y-coordinate.
    :type x: int
    :type y: int
    :param z: The z-coordinate.
    :type z: int, optional
    :param t: The t-coordinate.
    :return: The t-coordinate.
    :raises ValueError: if the value is invalid.
    '''
    parsed = parse(docstring)
    assert parsed.short_description == "The short version."
    assert parsed.long_description == "The long version."
    assert len(parsed.meta) == 6
    assert parsed.meta[0].arg_name == "x"

# Generated at 2022-06-23 17:23:05.906987
# Unit test for function parse
def test_parse():
    test_docstring = """
    Get Dask array from csv file

    :param path: path to load, can be s3, gs, ftp, hdfs
    :param metadata: metadata to include
    :param chunk_size: (str) chunk size to use
    :returns: dask array
    :rtype: dask.array.core.Array
    :raises Exception: in case no path is specified
    :raises RuntimeError: in case of runtime error
    """
    assert parse(test_docstring) == parse.__annotations__["return"]

# Generated at 2022-06-23 17:23:17.691214
# Unit test for function parse
def test_parse():
    docstring_text = """
    A function which does something.

    :param int x: A number.
    :param str y: A string.
    :param str* z: A string list.
    :param int w?: A number?. defaults to 7.
    :returns int: A number.
    :raises KeyError: when something bad happens.
    """
    docstring = parse(docstring_text.lstrip())
    assert docstring.short_description == "A function which does something."
    assert docstring.long_description == None
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "int", "x"]

# Generated at 2022-06-23 17:23:24.660297
# Unit test for function parse

# Generated at 2022-06-23 17:23:30.363040
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    print(parse.__file__)
    print(parse.__name__)
    print(parse.__qualname__)
    print(parse.__package__)
    print(parse.__defaults__)
    print(parse.__code__)
    print(parse.__annotations__)


# test_parse()

# Generated at 2022-06-23 17:23:38.367102
# Unit test for function parse

# Generated at 2022-06-23 17:23:48.059510
# Unit test for function parse
def test_parse():
    """Test main parser."""
    docstring = parse("""
    :param int x: The X coordinate
    :param int y: The Y coordinate
    :rtype: Point
    """)
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert len(docstring.meta) == 3
    assert docstring.meta[0].arg_name == "x"
    assert docstring.meta[0].type_name == "int"
    assert docstring.meta[0].description == "The X coordinate"
    assert docstring.meta[0].default is None
    assert docstring.meta[1].arg_name == "y"
    assert docstring.meta[1].type_name == "int"
    assert docstring.meta[1].description == "The Y coordinate"
    assert doc

# Generated at 2022-06-23 17:23:55.336845
# Unit test for function parse
def test_parse():
    # TODO: Add more tests
    assert parse('''
    a

    b

    c
        d
    e


    ''') == Docstring(
        short_description='a',
        blank_after_short_description=True,
        long_description='b\nc\n    d',
        blank_after_long_description=False,
        meta=[DocstringMeta(args=[], description='e')]
    )

# Generated at 2022-06-23 17:24:03.083891
# Unit test for function parse
def test_parse():
    doc = """
    This is a short description.

    And this is a long
    description.

    :param abc: something
    :param def: something else
    :rtype: the return type
    :raises Exception: if something goes wrong
    :returns: the return value
    """

    ds = parse(doc)
    assert ds.short_description == "This is a short description."
    assert not ds.blank_after_short_description
    assert ds.long_description == "And this is a long\ndescription."
    assert ds.blank_after_long_description
    assert len(ds.meta) == 4
    assert ds.meta[0].description == 'something'
    assert ds.meta[1].description == 'something else'

# Generated at 2022-06-23 17:24:14.769185
# Unit test for function parse
def test_parse():
    input_txt = inspect.cleandoc(r"""
    First line.
    Blank line here.
    Second line.
    :param arg: Parameter name.
    :type arg: str
    :raises ValueError: 
    Raised when it fails.
    :return: Whatever.
    :rtype: None
    :yields: Whatever.
    :ytype: None
    :yields: Whatever.
    :ytype: None
    """)
    expected = Docstring()
    expected.short_description = "First line."
    expected.blank_after_short_description = True
    expected.blank_after_long_description = False
    expected.long_description = (
        "Blank line here.\nSecond line.\n"
    )

# Generated at 2022-06-23 17:24:26.815057
# Unit test for function parse
def test_parse():
    test_string = """\
    Helper function to add an alias for an existing command, for instance,
    "ls" is aliased with "ll" in some shells.

    :param cmd: the original command
    :type cmd: str
    :param alias_name: the alias of the command
    :type alias_name: str
    :returns: None
    """

    test_string2 = """\
    Test function with no parameters

    :returns: None
    """

    test_string3 = """\
    Test function with an optional parameter

    :param cmd: The data to process
    :type cmd: str
    :param alias_name: the alias of the command
    :param alias_name: str?
    :returns: None
    """


# Generated at 2022-06-23 17:24:31.107522
# Unit test for function parse
def test_parse():
    ds = "This is a test\n\n:param x: this is x\n:type x: str"
    dd = parse(ds)
    assert dd.short_description == "This is a test"



# Generated at 2022-06-23 17:24:41.054633
# Unit test for function parse
def test_parse():
    ds = parse(
    """
    Short description.

    Long description.

    :param arg1: Description of arg1.

    :param arg2: Description of arg2.

    :returns: Description of return value.
    """
    )

    assert ds.short_description == "Short description."
    assert ds.blank_after_short_description
    assert ds.long_description == "Long description."
    assert ds.blank_after_long_description
    assert len(ds.meta) == 3
    assert ds.meta[0].arg_name == "arg1"
    assert ds.meta[0].description == "Description of arg1."
    assert ds.meta[0].type_name is None
    assert ds.meta[0].is_optional is None

# Generated at 2022-06-23 17:24:50.075794
# Unit test for function parse

# Generated at 2022-06-23 17:24:58.531455
# Unit test for function parse
def test_parse():
    doc_string = """
        Return the sum of a sequence of numbers.

        :param ret: an iterable
        :returns: :py:class:`int` or :py:class:`float`

        """


# Generated at 2022-06-23 17:25:10.467932
# Unit test for function parse
def test_parse():
    docstring = parse("""
        A simple docstring.

        :param x: A coordinate.
        :type x: ``int``
        :param y: A coordinate.
        :type y: ``int``
        :param z: A coordinate. Defaults to 0.
        :param w: A coordinate. Defaults to 0.
        :returns: The L2 norm for the vector.
        :rtype: ``float``

        :raises RuntimeError: If something nasty happens.
        :raises TypeError: If something even more nasty happens.
    """)


# Generated at 2022-06-23 17:25:19.754814
# Unit test for function parse
def test_parse():
    input_str = """
    my docstring
    :param a: parameter a
    :param b: parameter b
    :return: returns this
    """

    result_str = str(parse(input_str))
    assert ':param: a parameter a' in result_str
    assert ':param: b parameter b' in result_str
    assert ':return: returns this' in result_str

    input_str = """
    my docstring
    :param a: parameter a
    :return: returns this
    """
    result_str = str(parse(input_str))
    assert ':param: a parameter a' in result_str
    assert ':return: returns this' in result_str

    input_str = """
    my docstring
    :return: returns this
    """

# Generated at 2022-06-23 17:25:31.304097
# Unit test for function parse

# Generated at 2022-06-23 17:25:40.655108
# Unit test for function parse
def test_parse():
    text = """
    Return a new array of given shape and type, without initializing entries.
    """
    assert "" == parse(text).short_description
    text = """
    Return a new array of given shape and type, without initializing entries.
    Test new line.
    """
    assert "Return a new array of given shape and type, " + \
        "without initializing entries." == parse(text).short_description
    assert "Test new line." == parse(text).long_description
    assert not parse(text).meta
    text = """
    Return a new array of given shape and type, without initializing entries.

    Test new line.
    """
    assert "" == parse(text).short_description
    assert "Test new line." == parse(text).long_description
    assert not parse(text).meta

# Generated at 2022-06-23 17:25:45.382005
# Unit test for function parse
def test_parse():
    from hypothesis import given, example
    from hypothesis.strategies import text
    @given(text())
    def test_parse(docstring):
        parse(docstring)
    test_parse()

# Generated at 2022-06-23 17:25:55.396188
# Unit test for function parse
def test_parse():
    docstring = """
    A short description.

    This is a long description.

    :param x:
        An argument.

    :param y: An argument with a type.
        The type is int.

    :param z: An argument with an optional type. int?

    :param a:
        An argument with a default.
        Defaults to 10.

    :param b:
        An argument with a default and an optional type. int?
        Defaults to 10.

    :returns:
        A return value.

    :yields:
        A yielded value.

    :raises TypeError:
        When the argument types are wrong.
    """

    assert parse(docstring) == parse(inspect.cleandoc(docstring))
    assert parse("") == Docstring()

    parsed = parse(docstring)
   

# Generated at 2022-06-23 17:26:06.564071
# Unit test for function parse
def test_parse():
    def foo():
        """Short description.

        Long description.
        """
        pass

    d = parse(foo.__doc__)
    assert d.short_description == "Short description."
    assert d.long_description == "Long description."
    assert d.blank_before_long_description is False
    assert d.blank_after_long_description is False

    def foo():
        """Short description.

        Long description.

        """
        pass

    d = parse(foo.__doc__)
    assert d.short_description == "Short description."
    assert d.long_description == "Long description."
    assert d.blank_before_long_description is False
    assert d.blank_after_long_description is True

    def foo():
        """Short description.

        Long description.

        """
        pass

   

# Generated at 2022-06-23 17:26:15.999353
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Hello") == Docstring(
        short_description=":Hello", long_description="", blank_after_long_description=False, blank_after_short_description=False)
    assert parse("Hello\nWorld") == Docstring(
        short_description=":Hello", long_description="\nWorld", blank_after_long_description=False, blank_after_short_description=True)
    assert parse("Hello\n\nWorld") == Docstring(
        short_description=":Hello", long_description="\nWorld", blank_after_long_description=False, blank_after_short_description=True)

# Generated at 2022-06-23 17:26:27.146790
# Unit test for function parse
def test_parse():
    code = '''
    foo function
    :param x: x arg
    :type x: int
    :param y: y arg
    :type y: str
    :raises TypeError: on invalid input
    '''
    doc = parse(code)
    assert doc.short_description == 'foo function'
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert doc.long_description is None
    assert len(doc.meta) == 3
    assert doc.meta[0] == DocstringParam(
        args=['param', 'x'],
        description='x arg',
        arg_name='x',
        type_name='int',
        is_optional=False,
        default=None)
    assert doc.meta[1] == DocstringParam