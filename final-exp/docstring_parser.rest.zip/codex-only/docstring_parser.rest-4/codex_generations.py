

# Generated at 2022-06-23 17:16:34.890173
# Unit test for function parse
def test_parse():
    doc = parse('''
    """
    Short description.

    Long description.

    :param x: Description of x.
    :type x: int
    :param y: Description of y.
    :type y: str
    :returns: Description of what is returned.
    :rtype: str
    """
    ''')
    assert doc.short_description == 'Short description.'
    assert doc.long_description == 'Long description.'
    assert len(doc.meta) == 3
    for meta in doc.meta:
        if meta.args[0] == 'param':
            assert meta.arg_name == 'x'
            assert meta.type_name == 'int'
            assert meta.is_optional == False
            assert meta.default == None
            assert meta.description == 'Description of x.'

# Generated at 2022-06-23 17:16:42.089015
# Unit test for function parse
def test_parse():
    docstring = inspect.getdoc(parse)
    real_docstring = parse(docstring)
    assert real_docstring.short_description == "Parse the ReST-style docstring into its components."
    assert real_docstring.blank_after_short_description
    assert real_docstring.long_description == ":returns: parsed docstring"
    assert real_docstring.blank_after_long_description
    assert real_docstring.meta == [DocstringMeta(args=["returns"], description="parsed docstring")]


# Generated at 2022-06-23 17:16:47.587512
# Unit test for function parse
def test_parse():
  assert parse('') == Docstring()
  assert parse('A docstring.') == Docstring(
    short_description='A docstring.',
    long_description='')
  assert parse('A docstring.\n') == Docstring(
    short_description='A docstring.',
    long_description='',
    blank_after_short_description=True)
  assert parse('\nA docstring.\n') == Docstring(
    short_description='A docstring.',
    long_description='',
    blank_after_short_description=True)

# Generated at 2022-06-23 17:16:57.088510
# Unit test for function parse
def test_parse():
    doc="""This is a test docstring.

    :param int x: x parameter. Blah blah.
    :param int y: y parameter. Blah blah.
    :returns: Something.

    :param int z: x parameter. Blah blah.
    :returns: Something.
    """
    res=parse(doc)
    assert len(res.meta)==4
    assert res.meta[0].args==['param', 'int', 'x']
    assert res.meta[1].args==['param', 'int', 'y']
    assert res.meta[2].args==['returns']
    assert res.meta[3].args==['param', 'int', 'z']

# Generated at 2022-06-23 17:17:04.411460
# Unit test for function parse
def test_parse():
    doc = r"""Test parser.

    :param a: Paragraph.
    :param b:
    :param c c2:
    :returns:
    :raises:
    :raises A:
    :raises B: Paragraph.

    :param d: Paragraph.
    :returns d:
    :returns:
    :raises:
    :raises D:
    :raises E E2:
    :raises E:
    :raises F: Paragraph.

    :returns f:
    :exception g:
    """
    result = parse(doc)
    assert result.short_description == "Test parser."
    assert result.long_description == ""
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == False
   

# Generated at 2022-06-23 17:17:14.209956
# Unit test for function parse
def test_parse():
    """Test parse function."""


# Generated at 2022-06-23 17:17:26.467571
# Unit test for function parse
def test_parse():
    assert Docstring() == parse(None)
    assert Docstring() == parse("")

    expected = Docstring(
        short_description="A short description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="The long description\nwith a list:\n* one\n* two",
    )
    assert expected == parse(
        """\
A short description.
The long description with a list:
* one
* two"""
    )


# Generated at 2022-06-23 17:17:32.795271
# Unit test for function parse
def test_parse():
    #Test with a basic docstring with no meta information
    text = '''
    A basic docstring.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'A basic docstring.'
    assert docstring.long_description is None

    #Test with a basic docstring with no long description
    text = '''
    A basic docstring.

    '''
    docstring = parse(text)
    assert docstring.short_description == 'A basic docstring.'
    assert docstring.long_description is None

    #Test with a basic docstring with a long description
    text = '''
    A basic docstring.

    This is a long description
    that can span multiple lines
    '''
    docstring = parse(text)

# Generated at 2022-06-23 17:17:42.352487
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description.

    :param arg: Description of arg.
    :param arg: Description of arg.
    :type arg: str
    :param arg: Description of arg.
    :type arg: str
    :returns: Description of return value.
    :rtype: int
    :raises: Description of exceptions.
    """
    x = parse(text)
    assert x.short_description == 'Short description.'
    assert x.long_description == 'Long description.'
    assert x.blank_after_short_description == True
    assert x.blank_after_long_description == True
    assert len(x.meta) == 5

# Generated at 2022-06-23 17:17:52.750944
# Unit test for function parse
def test_parse():
    doc = """
        This docstring has no meta information.
    """
    d = parse(doc)
    assert d.short_description == 'This docstring has no meta information.'
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta == []

    doc = """
        This docstring has only the short description.
    """
    d = parse(doc)
    assert d.short_description == 'This docstring has only the short description.'
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta == []


# Generated at 2022-06-23 17:17:54.614001
# Unit test for function parse
def test_parse():
    from .test_parse import DOCSTRING, DOCSTRING_EXPECTED
    assert parse(DOCSTRING) == DOCSTRING_EXPECTED

# Generated at 2022-06-23 17:18:05.915902
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("short description") == Docstring(
        short_description="short description",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )
    assert parse("short description.\n") == Docstring(
        short_description="short description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )
    assert parse("short description\n") == Docstring(
        short_description="short description",
        blank_after_short_description=False,
        blank_after_long_description=True,
    )

# Generated at 2022-06-23 17:18:08.889488
# Unit test for function parse
def test_parse():
    # Test short description, long description and meta information
    assert parse.__doc__ == parse(parse.__doc__).__repr__()



# Generated at 2022-06-23 17:18:18.872393
# Unit test for function parse
def test_parse():
    class A:
        """Simple class to test simple cases.

        No params, no returns, no raises.
        """
        pass

    class B:
        """Params, returns, raises.

        :param a: First argument
        :returns: None
        :raises: Exception
        """
        pass

    class C:
        """Lack of space before ``returns`` and ``raises``.

        :param a: First argument
        :returns: Nothing
        :raises: Exception
        """
        pass

    class D:
        """Arbitrary spacing.

        :    param    a: First argument
        :    returns   : Nothing
        :    raises   : Exception
        """
        pass


# Generated at 2022-06-23 17:18:30.473099
# Unit test for function parse
def test_parse():
    test_string = """\
        test docstring

        :param a: this is parameter a
        :type a: int
        :param b: this is parameter b
        :type b: int
        :param c: this is parameter c
        :type c: int

        :raises A: if something happens
        :raises B: if something happens
        :raises C: if something happens

        :returns: nothing
        """
    result = parse(test_string)
    assert result.short_description == "test docstring"
    assert result.long_description == (
        "this is parameter a\n"
        "this is parameter b\n"
        "this is parameter c\n"
        "if something happens\n"
        "if something happens\n"
        "if something happens"
    )
    assert len

# Generated at 2022-06-23 17:18:42.518155
# Unit test for function parse
def test_parse():
    docstring = """\
    Single-line docstring.

    But it has a blank line above this line, which should be included
    in the long description.

    :param int arg1: Description.
    :param int arg2: Description.
    :param str arg3: Description.
    :param arg4: Description.
    :type arg4: str
    :param arg5: Description.
    :type arg5: str

    :raises ValueError: if something bad happens.
    :returns: nothing.
    :rtype: None
    """

# Generated at 2022-06-23 17:18:43.475410
# Unit test for function parse
def test_parse():
    # TODO: Write test
    pass

# Generated at 2022-06-23 17:18:52.258190
# Unit test for function parse
def test_parse():
    doc1 = """One-line summary.
    More detailed description.
    :param arg1: First argument.
    :param arg2: Second argument."""

    doc2 = """Another one-line summary.
    :param arg1: First argument.
    :param arg2: Second argument.
    :param arg3: Third argument.

    :returns: Some number.
    :rtype: int"""

    doc3 = """One-line summary.
    :return: None

    :param arg1: First argument.
    :param arg2: Second argument.
    :type arg1: str
    :type arg2: int
    :returns: None
    """


# Generated at 2022-06-23 17:18:58.910686
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('\n') == Docstring()


# Generated at 2022-06-23 17:19:04.524898
# Unit test for function parse
def test_parse():
    """
    >>> from foobar import parse
    >>> parse.__doc__ is not None
    True
    >>> parse.__doc__
    'Parse the ReST-style docstring into its components.\\n\\n    :returns: parsed docstring\\n    '
    """

# Generated at 2022-06-23 17:19:05.800752
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:19:15.413829
# Unit test for function parse
def test_parse():
    doc = """\
    A simple function.

    :param x: A parameter.
    :param y: Another parameter.
    """
    result = parse(doc)
    assert result.short_description == "A simple function."
    assert result.blank_after_short_description
    assert result.long_description == None
    assert result.blank_after_long_description
    assert len(result.meta) == 2
    assert result.meta[0].keyword == "param"
    assert result.meta[0].args == ["param", "x"]
    assert result.meta[0].description == "A parameter."
    assert result.meta[1].keyword == "param"
    assert result.meta[1].args == ["param", "y"]
    assert result.meta[1].description == "Another parameter."

# Generated at 2022-06-23 17:19:26.174219
# Unit test for function parse
def test_parse():
    """Test for the parse function"""
    good_doc = (
        """
        First paragraph of the function documentation.

        Second paragraph of the function documentation.

        :param N: (int)

        :param x: (float)

        :param y: (floa)

        :param z: (float)
        """
    )
    return_doc = (
        """
        Calculate the square root.

        :returns: (float) the square root
        """
    )
    yield_doc = (
        """
        Yield the square roots.

        :yields: (float) the square roots
        """
    )
    raise_doc = (
        """
        Raise an exception.

        :raises ValueError: if the value is negative
        """
    )

    doc = parse(good_doc)
   

# Generated at 2022-06-23 17:19:37.013380
# Unit test for function parse
def test_parse():
    """Test the function parse."""
    # Test the function parse
    docstring = parse('Short description.\n\n:param foo: is a variable\n')
    assert docstring.short_description == 'Short description.'
    assert docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert docstring.long_description is None
    assert docstring.meta[0].arg_name == 'foo'
    assert docstring.meta[0].type_name is None
    assert docstring.meta[0].is_optional is None
    assert docstring.meta[0].default is None
    assert docstring.meta[0].description == 'is a variable'
    assert not docstring.meta[0].is_generator


# Generated at 2022-06-23 17:19:47.470038
# Unit test for function parse
def test_parse():
    text = """
    test function
    :param path: A file path
    :param num_lines: Number of lines to fetch.
    :returns: the content of the file
    """

# Generated at 2022-06-23 17:19:57.287834
# Unit test for function parse
def test_parse():
    docstring = """
    This is the short description.

    This is the
    long description.

    :arg int a: description of parameter a
    :param int b: description of parameter b

    :return: description of return value
    :rtype: int

    :raises NotImplementedError: description of exception
    :raises: description of exception

    :yields A: description of yielded value
    :yields: description of yielded value
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is the short description."
    assert parsed.long_description == "This is the long description."

    # Test the params
    assert len(parsed.meta) == 9

    meta_1 = parsed.meta[0]
    meta_2 = parsed.meta[1]
    meta_3

# Generated at 2022-06-23 17:20:08.727894
# Unit test for function parse
def test_parse():
    output = Docstring()
    output.short_description = 'Docstring for the sample function.'
    output.blank_after_short_description = True
    output.blank_after_long_description = False
    output.long_description = 'This is an example of a long description with multiple lines.'

# Generated at 2022-06-23 17:20:18.308473
# Unit test for function parse
def test_parse():
    if __name__ == "__main__":
        # pylint: disable=no-else-return
        # pylint: disable=protected-access
        def _run_test(text: str, expected: Docstring) -> None:
            actual = parse(text)
            assert actual == expected
            actual._freeze()
            assert actual == expected
            assert actual.freeze() == expected


# Generated at 2022-06-23 17:20:29.376036
# Unit test for function parse

# Generated at 2022-06-23 17:20:39.547132
# Unit test for function parse
def test_parse():
    docstring = """\
    this is a docstring

    Some more description.

    :param string name: name description
    :param string? age: age description
    :returns: a string
    :raises ValueError: if something went wrong"""
    expected = Docstring()
    expected.short_description = 'this is a docstring'
    expected.long_description = 'Some more description.'
    expected.blank_after_short_description = True
    expected.blank_after_long_description = True

# Generated at 2022-06-23 17:20:51.448730
# Unit test for function parse

# Generated at 2022-06-23 17:21:02.869988
# Unit test for function parse
def test_parse():
    docstring = """Short description.

Long description which may span multiple
lines.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :returns: This is what is returned.
    :raises keyError: This is an exception.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description which may span multiple\nlines."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].type == "param"
    assert parsed.meta[1].description == "This is the second argument."
    assert parsed.meta[2].type == "return"
    assert parsed.meta[3].description

# Generated at 2022-06-23 17:21:14.590667
# Unit test for function parse
def test_parse():
    text = """
    Parse the ReST-style docstring into its components.

    :param int a: First parameter.
    :param str b: Second parameter.
    :param str c: Third parameter, with a very long description
        that goes across multiple lines.
        This description also contains a list, as follows.
        - item 1
        - item 2
    :return: Description of the return value.
    :rtype: str
    :raises ValueError: If an invalid value is provided.

    The long description may be several paragraphs,
    as shown here.
    """
    # Parse text docstring
    s = parse(text)
    # Expected parsed docstring

# Generated at 2022-06-23 17:21:24.336711
# Unit test for function parse
def test_parse():
    assert Docstring() == parse("")
    assert Docstring() == parse("\n")
    assert parse("short") == Docstring(
        short_description="short",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert parse("\nshort") == Docstring(
        short_description="short",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )

# Generated at 2022-06-23 17:21:35.244578
# Unit test for function parse
def test_parse():
    docstring = """Single line description.

Args:
    name: description
    name2: description2
Returns:
    type: description
    type2: description2
Raises:
    Exception: description
        description

    Exception:
        description

    Exception:
        description
"""

# Generated at 2022-06-23 17:21:44.142123
# Unit test for function parse
def test_parse():
    text ="""
    Short description.

    Long description.

    : param arg1: This is a param.
    : type arg1: str

    : param arg2: This is another param.
    : type arg2: int
    : param arg3: This is a param with a default value.
    : type arg3: int, optional
    : param arg4: This is a param with a default value.
    : type arg4: int, optional
    : returns: This is a return
    :rtype: int
    : raises error: This is an error
    """
    result = parse(text)
    assert result.short_description == 'Short description.'
    assert result.long_description == 'Long description.'
    assert result.blank_after_short_description
    assert result.blank_after_long_description
    assert result.meta

# Generated at 2022-06-23 17:21:55.483032
# Unit test for function parse
def test_parse():
    sd = """Some short description."""

    ld = """\
    Some long description.

    - first item
    - second item
    """


# Generated at 2022-06-23 17:22:06.628649
# Unit test for function parse
def test_parse():
    d = parse.__doc__
    assert parse(d).short_description == "Parse the ReST-style docstring into its components."
    assert parse(d).long_description == ':returns: parsed docstring\n'
    assert parse(d).meta[0].description == 'parsed docstring'
    assert parse('one\ntwo\n\nthree\n\nfour\nfive\n\n') == Docstring(
        short_description='one',
        blank_after_short_description=True,
        long_description='two',
        blank_after_long_description=True,
        meta=[
            DocstringMeta(
                args=[],
                description='three',
            ),
            DocstringMeta(
                args=[],
                description='four',
            ),
        ],
    )

# Generated at 2022-06-23 17:22:17.589247
# Unit test for function parse
def test_parse():
    text = """
        Short description.

        Long description.

        :param  str1: longer description
                   for the str1
        :param str2: short description"""
    docstring = parse(text)
    assert docstring
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'str1']
    assert docstring.meta[0].description == "longer description\nfor the str1"
    assert docstring.meta[0].arg_name == "str1"
    assert docstring.meta[0].type_name is None

# Generated at 2022-06-23 17:22:30.626168
# Unit test for function parse
def test_parse():
    test_docstring = '''
    Initializes a new instance of the class.
    :param int num: number of items.
    :param list items: items of the list.
    :raises ValueError: if something is wrong.
    :returns int: count of items.
    '''
    test_docstring1 = '''
    :param int num: number of items.
    :param list items: items of the list.
    :raises ValueError: if something is wrong.
    '''
    test_docstring2 = '''
    :param int num: number of items.
    :param list items: items of the list.
    :raises ValueError: if something is wrong.
    :returns int: count of items.
    '''

# Generated at 2022-06-23 17:22:35.747658
# Unit test for function parse
def test_parse():
    docstring = """
    This is the short description.

    This is the long description. It can have multiple lines
    and states the details about the object.
    """
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == "This is the short description."
    assert parsed_docstring.long_description == """This is the long description. It can have multiple lines
    and states the details about the object."""
    assert parsed_docstring.blank_after_short_description == False
    assert parsed_docstring.blank_after_long_description == False

    docstring = """
    This is the short description.


    This is the long description. It can have multiple lines
    and states the details about the object.

    """
    parsed_docstring = parse(docstring)
    assert parsed_docstring

# Generated at 2022-06-23 17:22:46.597302
# Unit test for function parse

# Generated at 2022-06-23 17:22:57.352557
# Unit test for function parse
def test_parse():
    text = """
        Test parser

        ------
        Test parser

        test_parse(arg1, arg2):
        This is the descr
        And more descr

        :param arg1: arg1
        :param arg2: arg1
        """
    docstring = parse(text)
    assert docstring.short_description == "Test parser"
    assert docstring.long_description == "Test parser"
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].description == "This is the descr\nAnd more descr"
    assert docstring.meta[1].description == "arg1"
    assert docstring.meta[2].description == "arg1"
    

# Generated at 2022-06-23 17:23:05.730937
# Unit test for function parse
def test_parse():
    assert parse("test_parse") == Docstring()
    assert parse("test_parse\n") == Docstring()
    assert parse("test_parse\n\n") == Docstring()
    assert parse("test_parse\n\nhello") == Docstring()
    assert parse("test_parse\n\nhello\n\n") == Docstring()
    assert parse("test_parse\nhello\n") == Docstring()
    assert parse("test_parse\n\nhello\n") == Docstring()
    assert parse("test_parse\n\nhello\n\n") == Docstring()



# Generated at 2022-06-23 17:23:17.577102
# Unit test for function parse
def test_parse():
    docstring = '''
    This is the short description.

    And this is the long
    description. It spans multiple
    lines.
    '''

    assert parse(docstring) == Docstring(
        short_description="This is the short description.",
        blank_after_short_description=True,
        long_description="And this is the long\ndescription. It spans multiple\nlines.",
        blank_after_long_description=False,
    )

    docstring = '''
    This is the short description.

    And this is the long
    description. It spans multiple
    lines.

    :param int arg1: The first argument.
    :param str arg2: The second argument.
    :return: None
    '''


# Generated at 2022-06-23 17:23:24.593873
# Unit test for function parse
def test_parse():
    assert not parse("")
    assert parse("hello") == Docstring(short_description="hello")
    assert parse("hello\nworld") == Docstring(
        short_description="hello",
        blank_after_short_description=True,
        long_description="world",
    )
    docstring = parse(
        """the quick brown fox
jumps over the lazy dog.

:param req: the WSGI request object
:type req: :class:`req`
:returns: None
"""
    )
    assert docstring.short_description == "the quick brown fox"
    assert not docstring.long_description
    assert docstring.meta[0].arg_name == "req"
    assert docstring.meta[0].type_name == "req"

# Generated at 2022-06-23 17:23:34.819686
# Unit test for function parse
def test_parse():
    example_docstring = "\n".join(
        [
            "This is a function docstring.",
            "",
            "This is the long description.",
            "It can continue beyond this first paragraph.",
            "",
            ":param path: path to the file",
            ":param optional: whether to return an optional",
            "    value",
            ":return: a string",
            ":raises ValueError: if `path` does not exist",
            "",
        ]
    )


# Generated at 2022-06-23 17:23:44.680727
# Unit test for function parse
def test_parse():
    docstring = """
    One-line summary.

    Separate paragraph of description.

    :param arg_name: Argument description
    :type arg_name: str

    :returns: Return value description
    :rtype: str
    """
    doc = parse(docstring)
    assert doc.short_description == "One-line summary."
    assert doc.long_description == "Separate paragraph of description."
    assert len(doc.meta) == 2
    assert doc.meta[0].arg_name == "arg_name"
    assert doc.meta[0].type_name == "str"
    assert doc.meta[1].type_name == "str"

# Generated at 2022-06-23 17:23:52.154575
# Unit test for function parse
def test_parse():
    docstring = parse(
        """\
        Short description.

        Long description.

        :param param_name:  Parameter description.
        :type param_name:   str
        :param int param2:  Parameter 2 description.
        :param bool? optional_param:  Optional parameter.
        :rtype:             int

        :param param3:  Parameter 3 description.
        :param param3:  Parameter 3 description line 2.
        """
    )

    # Test the metadata.
    assert len(docstring.meta) == 5
    assert docstring.meta[0].arg_name == "param_name"
    assert docstring.meta[0].type_name == "str"
    assert docstring.meta[0].description == "Parameter description."

# Generated at 2022-06-23 17:24:01.469304
# Unit test for function parse
def test_parse():
    # code-block:: python
    text = """
        Short description.

        Long description.

                           <-- two blanks here
        :param int param_a: Parameter A.
        :param bool param_b: Parameter B (defaults to False).
        :raises TypeError: raises_a
        :raises ValueError: raises_b
        :returns: returns_a
        :yields: yields_a

        :type param_b: str"""


# Generated at 2022-06-23 17:24:09.651334
# Unit test for function parse
def test_parse():
    docstring = """
    This is a very simple function that gives the sum of two integers.
    :param x: The first integer.
    :type x: int
    :param y: The second integer.
    :type y: int
    :returns: The sum of two integers.
    :rtype: int
    """
    parsed = parse(docstring)
    assert len(parsed.meta) == 2
    assert parsed.meta[1].arg_name == "y"
    assert parsed.meta[1].description == "The second integer."

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:24:18.260208
# Unit test for function parse
def test_parse():
    """ """
    def f(a: int, b=3, c=None) -> float:
        """
        This is the first line of the docstring,
        which will contain the short description.

        Parameter c defaults to None.
        Parameter a has no default value.
        """
        return 8.5

    doc = parse(f.__doc__)

    assert doc.short_description == "This is the first line of the docstring, which will contain the short description."
    assert doc.long_description == "Parameter c defaults to None.\nParameter a has no default value."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "a"

# Generated at 2022-06-23 17:24:20.549755
# Unit test for function parse
def test_parse():
    docstring = """
    Parse the ReST-style docstring into its components.

    :param arg1: the first argument
    :param arg2 the second argument
    :returns: parsed docstring
    :raises KeyError: raises an exception
    """
    print(parse(docstring))


# Run unit test
# test_parse()

# Generated at 2022-06-23 17:24:25.834260
# Unit test for function parse
def test_parse():
    text = "One-line summary\n\nFirst paragraph.  More.\n\n    :param x: The x.\n\nAnother paragraph."
    docstring = parse(text)

    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.meta[0].keyword)
    print(docstring.meta[0].description)


# Generated at 2022-06-23 17:24:28.616876
# Unit test for function parse
def test_parse():
    doc = inspect.cleandoc(inspect.getdoc(parse))
    assert parse(doc) == Docstring.from_str(doc)

# Generated at 2022-06-23 17:24:37.935845
# Unit test for function parse
def test_parse():
    assert parse("Basic docstring") == Docstring(
        short_description="Basic docstring",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=True,
        meta=[],
    )

    assert parse("Basic docstring\n") == Docstring(
        short_description="Basic docstring",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[],
    )


# Generated at 2022-06-23 17:24:48.457982
# Unit test for function parse
def test_parse():
    doc = """Summarize the Router class here.

    Longer description of the Router class.

    :param param1: The first parameter.
    :type param1: str
    :param param2: The second parameter.
    :type param2: Optional[int]
    :param param3: The third parameter.
    :type param3: int, optional
    :default param3: 10
    :default optional?: something
    :rtype: int
    :returns: Return value of the Router class.
    :raises KeyError: When a key error
                                 occurs.
    """
    parsed = parse(doc)
    assert len(parsed.meta) == 6
    assert parsed.short_description == "Summarize the Router class here."

# Generated at 2022-06-23 17:24:58.355332
# Unit test for function parse
def test_parse():
    doctest = '''
    test
    :param type_name arg_name: desc
    :return: desc
    :rtype: type
    '''
    assert parse(doctest) == Docstring(
        short_description="test",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[
            DocstringParam(
                args=["param", "arg_name", "type_name"],
                description="desc",
                arg_name="arg_name",
                type_name="type_name",
                is_optional=False,
                default=None,
            ),
            DocstringReturns(
                args=["return", "type"], description="desc", type_name="type"
            ),
        ],
    )

# Generated at 2022-06-23 17:25:10.202844
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    from . import common

    def f(a: int, b=0.0) -> float:
        """Short description.

        Long description. And a bit more.

        :param a: Parameter a.
        :param b: Parameter b.
        :returns: The sum of a and b.
        """
        # ...

    d = common.build_docstring(f)

    expected = common.Docstring()
    expected.short_description = "Short description."
    expected.long_description = "Long description. And a bit more."
    expected.blank_after_short_description = False
    expected.blank_after_long_description = True


# Generated at 2022-06-23 17:25:19.544845
# Unit test for function parse
def test_parse():
    txt = """\
  A short description.

  A long description.

  :param param: A parameter.
  :type param: int
  :param param2: A parameter.
  :type param2: float
  :returns: A list like [1, 2, 3].
  :returns: Another list like [1, 2, 3].
  :rtype: list
  :returns: A generator yielding numbers.
  :rtype: generator
  :raises ValueError: If an error occurs.
  :raises TypeError: If an error occurs.
  :raises: If an error occurs.
  :raises: If an error occurs.
  :x: A wildcard parameter.
  :y: Another wildcard parameter.
  """

# Generated at 2022-06-23 17:25:31.303944
# Unit test for function parse
def test_parse():
    # Unit test case
    doc = '''
    Some function documentation.

    :param param1: This is a first parameter.
    :param param2: This is a second parameter with a longer description
        that spans multiple lines.
    :type param2: str
    :param param3: This is a third parameter with default "3".
        Defaults to 3.
    :type param3: int, optional
    :returns: Description of return value.
    :raises TypeError: When things go wrong.
    '''

    docstring = parse(doc)
    assert docstring.short_description == "Some function documentation."
    assert docstring.long_description is None
    assert len(docstring.meta) == 4
    assert docstring.meta[0].description == "This is a first parameter."

# Generated at 2022-06-23 17:25:40.653629
# Unit test for function parse
def test_parse():
    text = """
        ReST-style docstring parsing.

        This module contains a parser for ReST (reStructuredText) style docstrings.
        The parser is a port of epydoc's ReST parser.

        :param text:
            Text of the docstring to be parsed.

            .. note::

                This is a multiline note!

        :param line:
            The line number of the docstring in the source.
            This is used only for error messages.
        :raises ValueError: If the given docstring is not valid.
        :returns: parsed docstring
    """
    p = parse(text)
    if p.short_description != "ReST-style docstring parsing.":
        raise Exception('p.short_description != "ReST-style docstring parsing."')

# Generated at 2022-06-23 17:25:52.199566
# Unit test for function parse
def test_parse():
    import os.path
    import unittest

    test_file = os.path.join(os.path.dirname(__file__), 'test_parse.txt')
    with open(test_file) as fp:
        test_str = fp.read()

    test_case = parse(test_str)

    class TestParseDocstring(unittest.TestCase):
        def test_short_description(self):
            self.assertEqual(test_case.short_description, 'Parse docstring')

        def test_blank_after_short_description(self):
            self.assertTrue(test_case.blank_after_short_description)

        def test_blank_after_long_description(self):
            self.assertTrue(test_case.blank_after_long_description)


# Generated at 2022-06-23 17:25:58.256765
# Unit test for function parse
def test_parse():
    '''Test the parse function'''
    docstring = """\
    This function adds two numbers.

        :param - a: the first number
        :param b: the second number
        :type a: int
        :type b: int
        :raises TypeError: if a and b are not integers

        :returns: the sum of a and b
        :rtype: int
    """
    assert parse(docstring).short_description == "This function adds two numbers."
    assert parse(docstring).blank_after_short_description == False

# Generated at 2022-06-23 17:26:06.852440
# Unit test for function parse
def test_parse():
    docstring = parse("""
        Parse the ReST-style docstring into its components.

        :param text: docstring to parse
        :returns: parsed docstring
    """)
    assert docstring.short_description == "Parse the ReST-style docstring into its components."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.long_description == None
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args == ["returns", "parsed docstring"]
    assert docstring.meta[0].description == "parsed docstring"


# Generated at 2022-06-23 17:26:12.691545
# Unit test for function parse
def test_parse():
    source = """
    This is a short description.

    This is the long description, spanning multiple lines.

    :param arg1: The first argument, which is required.
    :param arg2: The second argument, which defaults to 'one'.
    :type arg2: int|string

    :returns: nothing

    :raises ValueError: if things go wrong.
    """

    assert str(parse(source)) == inspect.cleandoc(source)

# Generated at 2022-06-23 17:26:19.633778
# Unit test for function parse
def test_parse():
    # Helpers
    def test(text, expected):
        actual = parse(text)
        assert actual == expected

    def check_meta(**kwargs):
        return Docstring(
            meta=[DocstringMeta(**kwargs)]
        )

    def check_param(**kwargs):
        return Docstring(
            meta=[DocstringParam(**kwargs)]
        )

    def check_returns(**kwargs):
        return Docstring(
            meta=[DocstringReturns(**kwargs)]
        )

    def check_raises(**kwargs):
        return Docstring(
            meta=[DocstringRaises(**kwargs)]
        )

    # Default behavior
    test("", Docstring())

    # Misc
    test("a b c", Docstring(short_description="a b c"))

    # Arguments

# Generated at 2022-06-23 17:26:31.680882
# Unit test for function parse
def test_parse():
    text = """
    This is a short description.

    This is the long description.
    """

    assert parse(text) == Docstring(short_description="This is a short description.", 
                                    long_description="This is the long description.",
                                    blank_after_short_description=True,
                                    blank_after_long_description=False,
                                    meta=[])

    assert parse("") == Docstring(short_description=None, 
                                  long_description=None,
                                  blank_after_short_description=False,
                                  blank_after_long_description=False,
                                  meta=[])
