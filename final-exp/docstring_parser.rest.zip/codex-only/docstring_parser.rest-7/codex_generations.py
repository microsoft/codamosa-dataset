

# Generated at 2022-06-23 17:16:33.550486
# Unit test for function parse
def test_parse():
    d = inspect.cleandoc("""
    Description
    :param x: some parameter to x
    :type x: str
    :returns: something
    :rtype: int
    :raises ValueError: when this is raised
    """)
    r = parse(d)

# Generated at 2022-06-23 17:16:37.114228
# Unit test for function parse
def test_parse():
    docstring = """Short description.
    Long description.
    :param x:  blabla
    :returns:  blabla
    :raises ValueError:  blabla
    :meta key: value
    """
    result = parse(docstring)
    assert isinstance(result, Docstring)



# Generated at 2022-06-23 17:16:46.207578
# Unit test for function parse
def test_parse():
    docstring = '''Write an example
        :param int a:
        :param str b:
        :return:
        '''
    parsed = parse(docstring)
    assert parsed.short_description == 'Write an example'
    assert parsed.long_description == None
    assert parsed.blank_after_short_description, True
    assert parsed.blank_after_long_description, False
    assert len(parsed.meta) == 2
    assert parsed.meta[0].args == ['param', 'int', 'a']
    assert parsed.meta[0].description == None
    assert parsed.meta[0].arg_name == 'a'
    assert parsed.meta[0].type_name == 'int'
    assert parsed.meta[0].is_optional, False
    assert parsed.meta[0].default, None

# Generated at 2022-06-23 17:16:57.088577
# Unit test for function parse
def test_parse():
    '''
    # function parse
    '''
    # 1
    t = Docstring()
    s = '''
    Returns
    -------
    a : int
          the mean (average) value
    '''
    assert(parse(s) == t)

    # 2
    t = Docstring()
    s = '''
    Returns
    -------
    a : int
          the mean (average) value
    '''
    t.short_description = 'Returns'
    t.meta = [DocstringMeta(args=['Returns'], description='Returns'),
              DocstringReturns(args=['a', 'int'], description='the mean (average) value')]
    assert(parse(s) == t)

    # 3
    t = Docstring()

# Generated at 2022-06-23 17:17:04.435986
# Unit test for function parse
def test_parse():
    """Testing module parse"""
    assert parse("") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("  \n\n") == Docstring()

    doc = """
    Some brief description.

    Some long description.
    """

    assert parse(doc) == Docstring(
        short_description="Some brief description.",
        blank_after_short_description=False,
        long_description="Some long description.",
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-23 17:17:10.566097
# Unit test for function parse
def test_parse():
    t1 = """
    Short description, long description.

    :param x: this is x
    :type x: int
    :raises Exception: if something fails.
    """

    ds = parse(t1)
    print(ds.short_description)
    print(ds.long_description)
    print(ds.meta[0].description)
    print(ds.meta[1].description)
    print(ds.meta[2].description)


# Generated at 2022-06-23 17:17:19.408802
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""


# Generated at 2022-06-23 17:17:30.766679
# Unit test for function parse
def test_parse():
    result = parse("""this is a function docstring with a meta field
        :param int a: this is the a field
        :param str b: this is the b field""")
    assert result.short_description == "this is a function docstring with a meta field"
    assert result.long_description is None
    assert result.blank_after_short_description is False
    assert result.blank_after_long_description is False
    assert result.meta[0].args == ["param", "int", "a"]
    assert result.meta[0].description == "this is the a field"
    assert result.meta[0].arg_name == "a"
    assert result.meta[0].type_name == "int"
    assert result.meta[0].is_optional is False
    assert result.meta[0].default is None
   

# Generated at 2022-06-23 17:17:38.904770
# Unit test for function parse
def test_parse():
    docstring = """Short summary.

    Long description.

    Parameters
    ----------
    arg1 : str, optional
        ReST description

    Raises
    ------
    ValueError
        ReST description
    """

    parsed = parse(docstring)

    assert parsed.short_description == "Short summary."
    assert parsed.blank_after_short_description
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_long_description
    assert parsed.meta[0].args == ["Parameters"]
    assert parsed.meta[0].description is None
    assert parsed.meta[1].args == ["arg1", "str,", "optional"]
    assert parsed.meta[1].description == "ReST description"
    assert parsed.meta[2].args == ["Raises"]

# Generated at 2022-06-23 17:17:43.396376
# Unit test for function parse
def test_parse():
    docstring = '''\
    Computes the square of value.
    
    :param value: the value to square
    :type value: int
    :returns: the squared value
    :rtype: int
    :returns: the squared value
    :rtype: int
    '''

# Generated at 2022-06-23 17:17:53.768735
# Unit test for function parse
def test_parse():
    assert parse(
        """
    Short description
    """
    ) == Docstring(
        short_description="Short description",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse(
        """
    Short description

    Long description
    """
    ) == Docstring(
        short_description="Short description",
        blank_after_short_description=False,
        long_description="Long description",
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-23 17:18:00.569964
# Unit test for function parse
def test_parse():
    docstring = '''
        This function does something.

        It is a one-liner.

        :param foo:
            A parameter named foo.
        :param bar:
            A parameter named bar.
            It has a second line.
        :returns:
            A string
    '''
    expected = """
    This function does something.

    It is a one-liner.

    :param foo:
        A parameter named foo.
    :param bar:
        A parameter named bar.
        It has a second line.
    :returns:
        A string
    """
    ret = parse(docstring)
    assert ret.short_description == "This function does something."
    assert ret.long_description == expected
    assert ret.blank_after_short_description == True

# Generated at 2022-06-23 17:18:09.953565
# Unit test for function parse
def test_parse():
    text = """
    This is a test class
    :param str test1: this is a test
    :param bool test2: defaults to True
    :param:
    :param str test3: this is another test
    :raises: exceptions
    :returns: a test
    """
    ds = parse(text)
    assert ds.short_description == "This is a test class"
    assert ds.long_description == None
    assert ds.blank_after_short_description == True
    assert ds.blank_after_long_description == None
    assert len(ds.meta) == 4
    assert ds.meta[0].arg_name == "test1"
    assert ds.meta[0].type_name == "str"

# Generated at 2022-06-23 17:18:19.684867
# Unit test for function parse
def test_parse():
    text = """\
        Short summary.

        Long description.

        :param arg_a: description of arg_a
        :param arg_b: description of arg_b
        :type arg_b: str
        :param arg_c: description of arg_c
            which spans multiple lines
        :param arg_d? : description of arg_d
        :key arg_e?: description of arg_e
        :key arg_f? defaults to 'test'.
        :returns: description of the return value
        :rtype: str
        """

    docstring = parse(text)
    assert docstring.short_description == "Short summary."
    assert docstring.long_description == "Long description."
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert len

# Generated at 2022-06-23 17:18:30.793825
# Unit test for function parse
def test_parse():
    docstring = '''\
Summary line.

This is a longer description.
    '''
    assert parse(docstring) == Docstring(
        short_description='Summary line.',
        long_description='This is a longer description.',
        meta=[],
    )
    docstring = '''\
Summary line.

This is a longer description.

:param str foo: Parameter ``foo``.
:param int bar: Parameter ``bar``.
    '''

# Generated at 2022-06-23 17:18:42.947772
# Unit test for function parse
def test_parse():
    docstring = """\
    Short description.
    Long description.

    :type1: Kwarg1 name.

        Kwarg1 description.

        Kwarg1 description line 2.

    :type2: Kwarg2 name. Kwarg2 description.

    :type3: Kwarg3 name. Kwarg3 description.
    """

    doc_obj = parse(docstring)
    assert doc_obj.short_description == "Short description."
    assert doc_obj.blank_after_short_description is True
    assert doc_obj.blank_after_long_description is False
    assert doc_obj.long_description == "Long description."
    assert doc_obj.meta[0].arg_name == "Kwarg1 name."

# Generated at 2022-06-23 17:18:53.941654
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Hello, world!") == Docstring(
        short_description="Hello, world!",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert parse("Hello, world!\n") == Docstring(
        short_description="Hello, world!",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert parse("\nHello, world!\n") == Docstring(
        short_description="Hello, world!",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )

# Generated at 2022-06-23 17:19:01.428021
# Unit test for function parse
def test_parse():
    from .common import UnionDocstringParam
    from .parser import parse
    from .typing import Type

    # no docstring
    func = lambda: None
    assert parse(func.__doc__) == Docstring(
        short_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

    # one line docstring
    func = lambda: None
    func.__doc__ = "One line docstring."
    assert parse(func.__doc__) == Docstring(
        short_description="One line docstring.",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

    # one line

# Generated at 2022-06-23 17:19:12.553370
# Unit test for function parse
def test_parse():
    import unittest
    from collections import namedtuple

    class ParseTester(unittest.TestCase):
        def _check(self, text: str, expected: T.Dict[str, T.Any]) -> None:
            docstring = parse(text)
            for attr, val in expected.items():
                if callable(val):
                    val(getattr(docstring, attr))
                else:
                    self.assertEqual(getattr(docstring, attr), val)

        def test_no_description(self) -> None:
            text = ""
            expected = {
                "short_description": None,
                "long_description": None,
                "blank_after_short_description": False,
                "blank_after_long_description": False,
                "meta": [],
            }

# Generated at 2022-06-23 17:19:23.756239
# Unit test for function parse
def test_parse():
    # text = ""
    docString = "Hello World.\n    :param x: test\n    :type x: int\n    :return: test\n    :rtype: int \n"
    ret = parse(docString)
    # print(type(ret))
    assert ret.short_description == "Hello World."
    assert ret.long_description == None
    assert ret.blank_after_short_description == False
    assert ret.blank_after_long_description == False
    assert ret.meta[0].arg_name == 'x'
    assert ret.meta[0].type_name == 'int'
    assert ret.meta[0].is_optional == False
    assert ret.meta[0].default == None
    assert ret.meta[1].arg_name == None
    assert ret.meta[1].type

# Generated at 2022-06-23 17:19:35.880766
# Unit test for function parse
def test_parse():
    docstring = """
    This function does something.
        :param arg1: This is the first argument.
        :type arg1: str
        :param arg2: This is the second argument. Defaults to 'foo'.
        :type arg2: optional[str]
        :returns: This is flagged as a `returns` keyword.
        :rtype: int
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This function does something."
    desc = """This is the second argument. Defaults to 'foo'."""
    assert parsed.meta[1].description == desc
    assert parsed.meta[1].arg_name == "arg2"
    assert parsed.meta[1].type_name == "optional[str]"
    assert parsed.meta[1].is_optional

# Generated at 2022-06-23 17:19:45.305420
# Unit test for function parse
def test_parse():
    """Test for parse function."""
    docstring = """Test docstring.

    :param name: this is a first line
                  and this is a second line
    :type name: string
    :param weight: (optional)
    :type weight: int
    :param height: in inches
    :type height: int
    :param red: defaults to 0
    :type red: int
    :param green: defaults to 0
    :type green: int
    :param blue: defaults to 0
    :type blue: int
    :param type: (optional)
    :type type: string
    :returns: a number
    :rtype: int
    :raises ValueError: if x is negative
    """
    doc = parse(docstring)
    assert doc.short_description == 'Test docstring.'
    assert doc.blank_

# Generated at 2022-06-23 17:19:56.276939
# Unit test for function parse
def test_parse():
    from . import rest_common
    import pytest
    from .parsers import parse
    from .common import Docstring


# Generated at 2022-06-23 17:20:07.599753
# Unit test for function parse

# Generated at 2022-06-23 17:20:17.922348
# Unit test for function parse
def test_parse():
    test_string = """
        :param a:
            This is param a.

            It defaults to b.

            aaa
        :type a: int
        :param b:
            This is param b.
        :type b: int
        :raises ValueError:
            If something goes wrong.

        :rtype: None
        """

    parsed = parse(test_string)

    assert parsed.meta[0].description == "This is param a."
    assert parsed.meta[0].default == "b."
    assert parsed.meta[0].type_name == "int"
    assert not parsed.meta[0].is_optional
    assert parsed.meta[0].arg_name == "a"
    assert parsed.meta[0].args == ["param", "a"]


# Generated at 2022-06-23 17:20:28.823395
# Unit test for function parse

# Generated at 2022-06-23 17:20:39.142745
# Unit test for function parse
def test_parse():
    """Unit test for function parse

    This is a test to make sure that the parse function can handle all the docstring formats.
    It has the following test cases:

    1. Parse docstring with single line, long description and meta information.
    2. Parse docstring with single line, long description and meta information
       and see if it appends newline.
    3. Parse docstring with single line, long description and meta information and
       see if it appends new blank line.
    """
    assert parse("Single line docstring") == Docstring(
        short_description="Single line docstring",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse("Single line docstring\n\nLonger description") == Doc

# Generated at 2022-06-23 17:20:50.928302
# Unit test for function parse
def test_parse():
    doc_str = '''\
    This is a super duper docstring.

    :param str name: The name of the user.
    :param int age: The age of the person.
    :param bool is_adult: Whether the person is an adult or not.
                      Defaults to False.
    :returns: The user's name and age in a tuple.
    '''
    doc = parse(doc_str)
    assert doc.short_description == "This is a super duper docstring."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert doc.long_description == None
    assert len(doc.meta) == 3
    assert doc.meta[0].key == "param"
    assert doc.meta[0].arg_name == "name"


# Generated at 2022-06-23 17:21:02.045017
# Unit test for function parse

# Generated at 2022-06-23 17:21:13.737022
# Unit test for function parse
def test_parse():
    text = '''
    This is a description.

    This is a long description.

    :address: IP address of the server
    :port: port of the server
    :arg: argument
    :param see: See also

    '''
    f = parse(text)
    assert f.short_description == 'This is a description.'
    assert f.blank_after_short_description == True
    assert f.blank_after_long_description == False
    assert f.long_description == 'This is a long description.'
    assert f.meta[0].args == ['address']
    assert f.meta[0].description == 'IP address of the server'
    assert f.meta[1].args == ['port']
    assert f.meta[1].description == 'port of the server'

# Generated at 2022-06-23 17:21:19.002477
# Unit test for function parse
def test_parse():
    # type: () -> None
    """
    >>> docstring =Docstring(short_description="Test Docstring",
    ...       meta=[DocstringParam(arg_name="foo"),
    ...             DocstringParam(arg_name="bar", type_name="int",
    ...                             description="A number"),
    ...             DocstringReturns(type_name="str", description="A string")])
    >>> parse(docstring.to_rest()) == docstring
    True
    >>> parse("No short description.") == Docstring(short_description="No short description.")
    True
    """
    pass

# Generated at 2022-06-23 17:21:27.648241
# Unit test for function parse
def test_parse():
    # test for basic functionality
    text = """\
    simple function

    :param a: one parameter
    :return: None
    """
    ds = parse(text)
    assert str(ds) == text

    # test for optional and default parameters
    text = """\
    simple function

    :param a: one parameter
    :param b: another parameter that has a default and is optional
        defaults to 5.
    :return: None
    """
    ds = parse(text)
    assert str(ds) == text
    assert ds.meta[1].type_name is None
    assert ds.meta[1].arg_name == "b"
    assert ds.meta[1].default == "5"
    assert ds.meta[1].is_optional

    # test for wrapping of defaults

# Generated at 2022-06-23 17:21:39.610725
# Unit test for function parse

# Generated at 2022-06-23 17:21:50.654960
# Unit test for function parse
def test_parse():
    string = ''' This is a test
    :param x: this is x
    :type x: int
    :param y: this is y
    :type y: int
    :param z: this is z
    :type z: int
    :returns: the values
    :rtype: dict
    :raises ValueError: Raises ValueError
    '''
    out = parse(string)
    assert out.short_description == "This is a test"
    assert out.long_description == 'the values'
    assert out.blank_after_short_description
    assert out.blank_after_long_description
    assert len(out.meta) == 4
    assert out.meta[0].args[0] == 'param'
    assert out.meta[0].args[1] == 'x'
    assert out.meta

# Generated at 2022-06-23 17:21:58.952828
# Unit test for function parse
def test_parse():

    text = """
    Sums two numbers.

    This is a long description.

    :param a: Addend.
    :type a: int
    :param b: Addend.
    :type b: int
    :returns: The sum.
    :rtype: int
    """

    expected = Docstring()
    expected.short_description = "Sums two numbers."
    expected.long_description = "This is a long description."
    expected.blank_after_short_description = True
    expected.blank_after_long_description = True

    expected.meta.append(
        DocstringParam(
            args=["param", "a", "Addend."],
            arg_name="a",
            type_name="int",
            is_optional=False,
            description="Addend.",
        )
    )


# Generated at 2022-06-23 17:22:05.895830
# Unit test for function parse
def test_parse():
    """docstring for test_parse"""
    text = """
    Docstring for a function.

    Args:
        a: desc for a.
        b (int): desc for b.

    Returns:
        c.

    Raises:
        d: desc for d.
        e.

    """
    print(parse(text).short_description)
    for meta in parse(text).meta:
        print(meta.args)
        print(meta.description)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:22:16.543283
# Unit test for function parse
def test_parse():
    test1 = """Returns the value of x squared.

    :param x: the number to square
    :type x: int
    :rtype: int
    :returns: the square of x
    """
    test2 = """Returns the value of x squared.

    :param x: the number to square
    :type x: int
    :rtype: int
    :returns: the square of x

    This is a test"""
    test3 = """Returns the value of x squared.

    :param x: the number to square
    :type x: int
    :rtype: int
    :returns: the square of x


    This is a test"""

# Generated at 2022-06-23 17:22:19.396184
# Unit test for function parse
def test_parse():
    doc = inspect.getdoc(parse)
    assert doc == 'Parse the ReST-style docstring into its components.\n\n:returns: parsed docstring'


##########################################################################
# Tests
##########################################################################



# Generated at 2022-06-23 17:22:31.311199
# Unit test for function parse

# Generated at 2022-06-23 17:22:39.842709
# Unit test for function parse
def test_parse():
    """Test the parse function."""
    assert parse("one") == Docstring(
        short_description="one",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("one\n\n") == Docstring(
        short_description="one",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[],
    )

    assert parse("one two\n\n") == Docstring(
        short_description="one two",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=True,
        meta=[],
    )

    assert parse

# Generated at 2022-06-23 17:22:48.824681
# Unit test for function parse
def test_parse():
    text = """Measure distance from one point to another.

:param float x1: x value for the first point
:param float y1: y value for the first point
:param float z1: z value for the first point
:param float x2: x value for the second point
:param float y2: y value for the second point
:param float z2: z value for the second point

:returns float: distance between the two points
:raises ValueError: if distance is negative
"""

    ret = parse(text)
    assert ret.short_description == "Measure distance from one point to another."
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == False
    assert ret.long_description == None
    assert len(ret.meta) == 6

# Generated at 2022-06-23 17:22:56.983935
# Unit test for function parse
def test_parse():
    docstring = """
    One-line description.
    
    Extended description.
    
    :param foo: description
    :type foo: str
    :param bar: description
    :type bar: bool, optional
    :returns: description
    :rtype: int
    """
    ds = parse(docstring)
    assert ds.short_description == 'One-line description.'
    assert ds.long_description == 'Extended description.'
    assert ds.meta[1].arg_name == 'bar'
    assert ds.meta[1].type_name == 'bool'
    assert ds.meta[1].is_optional == True

# Generated at 2022-06-23 17:23:07.727394
# Unit test for function parse
def test_parse():
    doc = '''
    This is a short description.

    This is a long description.
    :param arg1: First arg
    :param arg2: Second arg
    :type arg2: str
    :returns: Return value
    :rtype: int
    '''
    result = parse(doc)
    assert result.short_description == 'This is a short description.'
    assert result.long_description == 'This is a long description.'
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert result.meta[0].arg_name == 'arg1'
    assert result.meta[0].description == 'First arg'
    assert result.meta[0].type_name is None
    assert result.meta[0].is_optional is None

# Generated at 2022-06-23 17:23:18.254480
# Unit test for function parse
def test_parse():
    from .common import Docstring, DocstringMeta, DocstringParam, DocstringRaises, DocstringReturns
    from .common import PARAM_KEYWORDS, RAISES_KEYWORDS, RETURNS_KEYWORDS, YIELDS_KEYWORDS

    assert parse("") == Docstring()
    assert parse("foo") == Docstring(short_description="foo")
    assert parse("foo\n\nbar") == Docstring(
        short_description="foo",
        long_description="bar",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

# Generated at 2022-06-23 17:23:28.022503
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    from . import docstrings
    from .parsers import Parser

    def test_parser(string: str, parser: Parser) -> None:
        """Check for expected output of specified parser."""
        doc = parser.parse(string)
        assert doc.__repr__() == docstrings.repr(string)

        yield docstrings.repr(string)

    for string, parser in zip(
        docstrings.strings,
        [docstrings.numpy, docstrings.google, docstrings.arbitrary],
    ):
        for doc in test_parser(string, parser):
            yield doc
    return

# Generated at 2022-06-23 17:23:34.937702
# Unit test for function parse
def test_parse():
    doc = parse(
        '''
    Short description.

    Long description.

    :param str arg1: Argument 1.
    :type arg1: str
    :param arg2: Argument 2. Defaults to None.
    :param arg3=None: Argument 3.
    :param arg4?=None: Argument 4.
    :raises TypeError: Raises TypeError.
    :raises: Raises TypeError.
    :yields int: Yields int.
    :yield: Yield int.
    :returns: Returns list.
    :return: Returns None.
    :returns str: Returns str.
    '''
    )

    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert doc.blank_after_short_description == False

# Generated at 2022-06-23 17:23:45.161516
# Unit test for function parse
def test_parse():
    docstring = """
    Parse the ReST-style docstring into its components.

    :param NumberEqual num: A number value
    :returns: something
    """

    expected = Docstring(
        short_description="Parse the ReST-style docstring into its components.",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[
            DocstringMeta(args=["param", "NumberEqual", "num"], description="A number value"),
            DocstringMeta(args=["returns"], description="something"),
        ],
    )

    d = parse(docstring)

    assert d == expected, "values do not match"

# Generated at 2022-06-23 17:23:56.617655
# Unit test for function parse

# Generated at 2022-06-23 17:24:03.673658
# Unit test for function parse
def test_parse():
    text = """
    Notes
    -----
    This is a docstring.
    """

    p = parse(text)
    assert p.short_description == "Notes"
    assert p.long_description == "This is a docstring."
    assert p.blank_after_short_description == True
    assert p.blank_after_long_description == False

    text = """    This is a docstring."""
    p = parse(text)
    assert p.short_description == "This is a docstring."
    assert p.long_description == None
    assert p.blank_after_short_description == True
    assert p.blank_after_long_description == False

    text = """ This is a docstring."""
    p = parse(text)
    assert p.short_description == "This is a docstring."

# Generated at 2022-06-23 17:24:14.843831
# Unit test for function parse
def test_parse():
    """ Test if the docstring parsing is done correctly. """
    code = """
    Parameters:
        name: The name of the file, or a file-like object.
        opt: option
        opt2: (Optional) option2
        default: defaults to True.
    """
    result = parse(code)
    length = len(result.meta)
    # print(result)
    assert( length == 4)
    assert( result.meta[0].arg_name == 'name')
    assert( result.meta[1].arg_name == 'opt')
    assert( result.meta[2].arg_name == 'opt2')
    assert( result.meta[3].arg_name == 'default')
    #print(result)
    assert(result.meta[3].default == 'True.')
# test_parse()

# Generated at 2022-06-23 17:24:26.884063
# Unit test for function parse
def test_parse():
    text = """
    This is a summary line.

    This is a long description for a function.

    :param first_arg: description for the first argument
    :type first_arg: str
    :param second_arg: description for the second argument
    :type second_arg: int
    :param third_arg: description for the third argument
    :type third_arg: float
    :param fourth_arg: description for the fourth argument
    :type fourth_arg: bool
    :returns: description for the return value
    :rtype: str
    """

# Generated at 2022-06-23 17:24:37.251764
# Unit test for function parse
def test_parse():
    text = """
    Test parse function

    Parameters
    ----------

    :param a:
        Test a
    :type a: int
    :param b?:
        Test b
    :type b?: int
        defaults to c
    :param d:
        Test d
    :type d: int

    Returns
    -------

    :returns: a + b
    :rtype: int

    Raises
    ------

    :raises Error: Error message
    """

    ret = parse(text)
    assert ret.short_description == "Test parse function"
    assert ret.blank_after_short_description

# Generated at 2022-06-23 17:24:47.674248
# Unit test for function parse
def test_parse():
    docstr = """This is a short description.
    
    This is a long description.
    """
    ds = parse(docstr)
    assert ds.short_description == "This is a short description."
    assert ds.long_description == "This is a long description."
    assert ds.blank_after_short_description == True
    assert ds.blank_after_long_description == False
    assert ds.meta == []


    docstr = """This is a short description.
    :param foo: this is foo
    :param bar: this is bar
    :type bar: int
    :returns: this is return
    :rtype: str
    :raises KeyError: when a key error
    """
    ds = parse(docstr)

# Generated at 2022-06-23 17:24:53.106801
# Unit test for function parse
def test_parse():
    doc = Docstring()
    doc.short_description = 'this is short description'
    doc.long_description = 'this is long description'
    doc.blank_after_short_description = False
    doc.blank_after_long_description = False
    doc.meta.append(DocstringRaises(args=['Raises', 'TypeError'],
                                    description='this is raise keyword'))
    my_doc = parse(str(doc))
    assert my_doc == doc
# end



# Generated at 2022-06-23 17:25:01.330835
# Unit test for function parse
def test_parse():
    obj_test = parse("""
        Description of the function.

        Args:
            obj (:obj:`string`, optional): Object string. Defaults to "test".
            obj2 (:obj:`int`, optional): Object integer. 

        Returns:
            :obj:`int`: Test return of integer.

        Raises:
            :obj:`ValueError`: Error for value. 
    """)
    assert obj_test.long_description == """Description of the function."""
    assert obj_test.short_description == """Description of the function."""
    assert obj_test.blank_after_long_description == True
    assert obj_test.blank_after_short_description == False
    assert isinstance(
        obj_test.meta, list
    ), "Returned value is not type list"

# Generated at 2022-06-23 17:25:12.904702
# Unit test for function parse
def test_parse():
    text1 = """Parse the ReST-style docstring into its components.

    :returns: parsed docstring"""
    parsed = parse(text1)
    assert parsed.short_description == "Parse the ReST-style docstring into its components."
    assert parsed.blank_after_short_description == False
    assert parsed.blank_after_long_description == False
    assert parsed.long_description == None
    assert len(parsed.meta) == 1
    assert parsed.meta[0].args == ["returns"]
    assert parsed.meta[0].description == "parsed docstring"

    text2 = """Parse the ReST-style docstring into its components.

    This is a long descrption.

    :returns: parsed docstring"""
    parsed = parse(text2)
    assert parsed.short_

# Generated at 2022-06-23 17:25:21.220345
# Unit test for function parse
def test_parse():
    text = r"""
    Short summary.

    Long summary.

    :param arg1: first arg
    :param arg2: second arg
    :param arg3: third arg

    :returns: something
    :rtype: str

    :returns: something else
    :rtype: bool

    :yields: one
    :ytype: int

    :yields: two

    :raises IOError: raised if something wrong happens.
    :raises OSError: raised if another thing goes wrong.
    :raises OSError: raised if yet another thing goes wrong.
    """
    assert parse(text)

    text = r"""
    Short summary.

    Long summary.

    :param arg1: first arg
    :param arg2: second arg
    :param arg3: third arg
    """

# Generated at 2022-06-23 17:25:32.028040
# Unit test for function parse

# Generated at 2022-06-23 17:25:43.092174
# Unit test for function parse
def test_parse():
    s = """
    Short description.

    Long description.

    :param arg_name repeat: repeats the message.
    """

    expected_result = order_dicts([{
        'short_description': 'Short description.',
        'long_description': 'Long description.',
        'blank_after_long_description': False,
        'blank_after_short_description': True,
        'meta': [{
            'arg_name': 'repeat',
            'type_name': None,
            'is_optional': True,
            'default': None,
            'args': ['param', 'repeat'],
            'description': 'repeats the message.'
        }]
    }])

    assert order_dicts([parse(s).to_dict()]) == expected_result



# Generated at 2022-06-23 17:25:54.873162
# Unit test for function parse
def test_parse():
    assert parse("Hello, world.") == parse("Hello, world.")
    assert parse("Hello, world.\n") == parse("Hello, world.\n")
    assert parse("Hello, world.\n\n") == parse("Hello, world.\n\n")
    assert parse("Hello, world.\n\nMore.") == parse("Hello, world.\n\nMore.")
    assert parse("Hello, world.\n\nMore.\n") == parse("Hello, world.\n\nMore.\n")

    assert parse("") == parse("")
    assert parse("\n") == parse("\n")
    assert parse("\n\n") == parse("\n\n")
    assert parse("\nMore.") == parse("\nMore.")

# Generated at 2022-06-23 17:26:06.274336
# Unit test for function parse

# Generated at 2022-06-23 17:26:12.124352
# Unit test for function parse
def test_parse():
    assert len(parse.__code__.co_varnames) == 1

    # Test case 1
    assert parse("Test function") == Docstring(
        short_description="Test function",
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description=None,
        meta=[],
    )

    # Test case 2
    doc = parse(
        """
    This is a long description.

    This is a long description cont.

    :param x: blabla
    :type x: int
    :param y: blabla
    :type y: int
    :returns: blabla
    :rtype: int
    :raises ValueError: on error
    """
    )

# Generated at 2022-06-23 17:26:19.094431
# Unit test for function parse
def test_parse():
    docstring = """
    
    :param str name: The name of the person.
    """
    ds = parse(docstring)
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is False
    assert len(ds.meta) == 1
    assert ds.meta[0].args == ['param', 'str', 'name']
    assert ds.meta[0].description == 'The name of the person.'
    assert ds.meta[0].arg_name == 'name'
    assert ds.meta[0].type_name == 'str'
    assert ds.meta[0].is_optional
    assert ds.meta[0].default is None

# Generated at 2022-06-23 17:26:30.330573
# Unit test for function parse
def test_parse():
    # parse basic ReST docstring
    text = """
    In all caps.
    :param name: an argument, defaults to None.
    :type name: str
    :raises ValueError: if an invalid value was supplied.
    :returns:
    """