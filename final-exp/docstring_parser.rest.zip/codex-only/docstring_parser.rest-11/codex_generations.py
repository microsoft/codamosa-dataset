

# Generated at 2022-06-23 17:16:34.400054
# Unit test for function parse
def test_parse():
    doc = '''\
        This is a short description.

        This is a long
        description.

        :param name: The name to use.
        :type name: str
        :param int param: The parameter.

        :returns int: The return value.
        :return: A generator.
        :rtype: list[str]
        '''
    parsed_doc = parse(doc)

    assert parsed_doc.short_description == "This is a short description."
    assert parsed_doc.blank_after_short_description
    assert parsed_doc.long_description == "This is a long description."
    assert parsed_doc.blank_after_long_description

    assert len(parsed_doc.meta) == 4
    assert parsed_doc.meta[0].param_name == "name"

# Generated at 2022-06-23 17:16:44.527787
# Unit test for function parse
def test_parse():
    docstr = """\
        Test function for docstring parsing

        Parameters
        ----------
        arg1 : str
            First argument
        arg2 : int, optional
            Second argument (defaults to 1).
        arg3 : list
            Third argument

        Returns
        -------
        dict
            The parsed docstring
        """

# Generated at 2022-06-23 17:16:56.351076
# Unit test for function parse
def test_parse():
    text = inspect.cleandoc('''
    A description
    that spans

    multiple paragraphs.

    :param a: the a parameter
    :param b: the b parameter
    :type b: int

    :keyword c: the c keyword
    :type c: bool, defaults to True.

    :returns: int -- the return value
    :raises KeyError: when a key error
    occurs
    ''')


# Generated at 2022-06-23 17:17:04.944664
# Unit test for function parse

# Generated at 2022-06-23 17:17:10.379936
# Unit test for function parse
def test_parse():
    """Test for function parse."""
    def test_func():
        """
        Short description.

        Long description,
        spanning multiple lines

        :param arg1: first arg
        :param arg2: second arg
        :param arg3: third arg with a default value of :obj:`None`

        :returns: the return value
        """


# Generated at 2022-06-23 17:17:19.407594
# Unit test for function parse
def test_parse():
    docstring = """\
    Short description.

    Longer description.

    :param int arg: Argument description.
    :param str arg2: Argument 2 description.
    :rtype: str
    :returns: Return value description.
    :raises ValueError: If something bad happens.

    :param ClassName arg3: Argument 3 description.
    :returns: Return value description.
    """

    parsed = parse(docstring)

    assert parsed.short_description == "Short description."
    assert parsed.blank_after_short_description is True
    assert parsed.long_description == "Longer description."
    assert parsed.blank_after_long_description is False

    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ["param", "int", "arg"]

# Generated at 2022-06-23 17:17:30.814107
# Unit test for function parse
def test_parse():
    doc_input2 = ("""
    Test function RST.

    Test function RST.

    :param aaa: aaa
    :param bbb: bbb defaults to 5.
    :param ccc?: ccc? defaults to None.
    :returns: returns
    :raises KeyError: raises KeyError
    """)

# Generated at 2022-06-23 17:17:40.266126
# Unit test for function parse
def test_parse():
    doc_string = """Summary line.

Description of function, parameters and their usages.

:param arg1: Description of arg1
:param arg2: Description of arg2
:type arg1: int
:type arg2: list of bool
:returns: Description of return value
:rtype: str
:raises TypeError: If arg1 is not an int.
:raises ValueError: If arg2 is empty.

:param arg3: Description of arg3

"""
    doc = parse(doc_string)
    assert doc.short_description == 'Summary line.'
    assert doc.long_description == 'Description of function, parameters and their usages.'
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 5
   

# Generated at 2022-06-23 17:17:49.689106
# Unit test for function parse
def test_parse():
    result = parse('title\n\ndetails')
    assert result.short_description == 'title'
    assert result.blank_after_short_description
    assert result.blank_after_long_description
    assert result.long_description == 'details'
    assert result.meta == []

    result = parse('title\n    details')
    assert result.short_description == 'title'
    assert not result.blank_after_short_description
    assert not result.blank_after_long_description
    assert result.long_description == 'details'
    assert result.meta == []

    result = parse('title\n    details\n\nmore')
    assert result.short_description == 'title'
    assert not result.blank_after_short_description
    assert result.blank_after_long_description
    assert result.long

# Generated at 2022-06-23 17:17:59.056813
# Unit test for function parse
def test_parse():
    parse_text = '''\
    This is a function docstring.
    :param arg1: arg1 description.
    :type arg1: int
    :arg2 int: arg2 description.
    :returns: None
    :rtype: NoneType
    :return:
    '''

# Generated at 2022-06-23 17:18:00.165093
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-23 17:18:10.693500
# Unit test for function parse

# Generated at 2022-06-23 17:18:20.159229
# Unit test for function parse
def test_parse():
    docstring = parse("this is a docstring")
    assert docstring.short_description == "this is a docstring"

    docstring = parse("")
    assert docstring.short_description == None
    assert docstring.long_description == None

    docstring = parse("""
    Here is a docstring.

    Here is some more of the docstring.
    """)
    assert docstring.short_description == "Here is a docstring."
    assert docstring.long_description == "Here is some more of the docstring."

    docstring = parse("""
    Here is a docstring.
    :param: foo: This is foo.

    Here is some more of the docstring.
    """)
    assert docstring.short_description == "Here is a docstring."

# Generated at 2022-06-23 17:18:31.246238
# Unit test for function parse

# Generated at 2022-06-23 17:18:43.132616
# Unit test for function parse
def test_parse():
    assert parse(
        """
        Test function.

        :param foo: Bar.
        :returns: Baz.
        """
    ) == Docstring(
        short_description="Test function.",
        long_description="Bar.\n",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[
            DocstringParam(
                args=["param", "foo"],
                description="Bar.",
                arg_name="foo",
                type_name=None,
                is_optional=None,
                default=None,
            ),
            DocstringReturns(
                args=["returns"],
                description="Baz.",
                type_name=None,
                is_generator=False,
            ),
        ],
    )

# Generated at 2022-06-23 17:18:50.258234
# Unit test for function parse
def test_parse():
    """Example of how to use parse()"""
    docstring = """This is a docstring
    :param x: this is x
    :type x: int
    :param y: this is y
    :type y: int
    :returns: something"""
    doc = parse(docstring)
    print(doc.short_description)
    print(doc.long_description)
    for meta in doc.meta:
        print(meta.args)
        print(meta.description)
        if isinstance(meta, DocstringParam):
            print(meta.arg_name)
            print(meta.type_name)
            print(meta.is_optional)
            print(meta.default)

# Generated at 2022-06-23 17:18:59.696828
# Unit test for function parse
def test_parse():
    """Testing parsing the docstring."""

# Generated at 2022-06-23 17:19:06.531694
# Unit test for function parse
def test_parse():
    docstring = parse(inspect.getdoc(test_parse))
    assert docstring.short_description == "Unit test for function parse"
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 0


# Generated at 2022-06-23 17:19:15.972879
# Unit test for function parse
def test_parse():
    docstring = '''
    Single line short description
    Single line long description
    '''
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == \
        'Single line short description'
    assert not parsed_docstring.blank_after_short_description
    assert parsed_docstring.long_description == 'Single line long description'
    assert not parsed_docstring.blank_after_long_description
    assert parsed_docstring.meta == []

    docstring = '''
    Multiple
    lines
    short
    description
    Single line long description
    '''
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == \
        'Multiple\nlines\nshort\ndescription'
    assert not parsed_docstring.blank_after_short_

# Generated at 2022-06-23 17:19:26.580002
# Unit test for function parse
def test_parse():
    from .common import Docstring, DocstringMeta, DocstringParam, DocstringReturns
    

# Generated at 2022-06-23 17:19:37.294489
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param str arg1: Arg1 description.
    :param int arg2: Arg2 description.
    """

    d = parse(docstring)

    assert d.short_description == "Short description."
    assert d.blank_after_short_description
    assert d.long_description == "Long description."
    assert d.blank_after_long_description

    assert len(d.meta) == 2

    assert d.meta[0].args == ["param", "str", "arg1"]
    assert d.meta[0].description == "Arg1 description."
    assert isinstance(d.meta[0], DocstringParam)

    assert d.meta[1].args == ["param", "int", "arg2"]

# Generated at 2022-06-23 17:19:43.855420
# Unit test for function parse
def test_parse():
    text = """
    Function that does something, which is really cool.

    :param arg1: the first argument.
    :param arg2: the second argument. defaults to ``3``.
    :raises ValueError: if something bad happens

    Also, this function takes care of some special
    cases.

    :raises RuntimeError: when some other thing goes wrong.
    :returns: None or a string.
    :returns dict: a dictionary.
    """
    print(parse(text))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:19:51.456359
# Unit test for function parse
def test_parse():
    print(
        parse(
            """Parse the ReST-style docstring into its components.

            :param key:
                The dictionary key.

                :type key: str
            :param value:
                The value for the dictionary entry.

                :type value: str | int

            :raises KeyError: If the key is not found."""
        )
    )


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:19:57.186195
# Unit test for function parse
def test_parse():
    docstring = parse("test function\n:param int x:x\n:return: test description\n")
    assert docstring.short_description == "test function"
    assert docstring.long_description == None
    assert docstring.meta[0].arg_name == "x"
    assert docstring.meta[0].description == "x"
    assert docstring.meta[0].type_name == "int"

# Generated at 2022-06-23 17:20:05.223557
# Unit test for function parse
def test_parse():
    doc = "Test function.\n"
    doc += "\n"
    doc += ":raises ValueError: if no path is specified.\n"
    doc += ":param path: The parameter description.\n"
    r = parse(doc)
    for sub in r.meta:
        assert sub.args == ["raises","ValueError"]
        assert sub.description == "if no path is specified."
    assert r.short_description == "Test function."
    assert r.long_description == "The parameter description."

# Generated at 2022-06-23 17:20:12.269002
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    s = "Single-line docstring without meta."
    expected = Docstring(
        short_description=s, blank_after_short_description=True
    )
    assert parse(s) == expected

    s = "Single-line docstring.\n"
    expected = Docstring(
        short_description="Single-line docstring.",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=True,
    )
    assert parse(s) == expected

    s = "Single-line docstring.\n\n"
    assert parse(s) == expected

    s = "Single-line docstring.\n\n\n"

# Generated at 2022-06-23 17:20:20.513764
# Unit test for function parse
def test_parse():
    # Dummy function to test regex
    def _parse_dummy(text: str) -> Docstring:
        """Parse the ReST-style docstring into its components.
        """
        ret = Docstring()
        if not text:
            return ret

        text = inspect.cleandoc(text)
        match = re.search("^:", text, flags=re.M)
        if match:
            desc_chunk = text[: match.start()]
            meta_chunk = text[match.start() :]
        else:
            desc_chunk = text
            meta_chunk = ""

        parts = desc_chunk.split("\n", 1)
        ret.short_description = parts[0] or None

# Generated at 2022-06-23 17:20:31.994136
# Unit test for function parse
def test_parse():
    docstring = """
        Short description.

        Long description.

        :param  type_name: 
        :type type_name: str
        :param bool a_bool: 
        :param str a_str: 
        :type a_str: str
        :returns:
        :rtype: str
        """

    doc = parse(docstring)

    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."

    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False

    assert len(doc.meta) == 3
    assert isinstance(doc.meta[0], DocstringParam)
    assert doc.meta[0].arg_name == "type_name"
    assert doc.meta[0].type_name

# Generated at 2022-06-23 17:20:38.073277
# Unit test for function parse
def test_parse():

    docstring = """
    This is the short description.

    This is the long description.

    :param str value: The value.
    :param int count: The count.
    :param str default_value: The default value.
    :param str name: The name.
    :param bool show_defaults: The show defaults.
    :returns: The return value.
    """

    result = parse(docstring)

    print(result)

# Generated at 2022-06-23 17:20:44.621261
# Unit test for function parse
def test_parse():
    doc1 = """
    Short Description
    Long Description

    :keyword arg1: Description arg1.
    :keyword arg2: Description arg2.
    """
    doc2 = """
    Short Description

    :keyword arg1: Description arg1.
    :keyword arg2: Description arg2.
    """
    doc3 = """
    Short Description
    Long Description

    :keyword arg1: Description arg1.
    :keyword arg2: Description arg2.
    :keyword arg3: Description arg3.
    """
    doc4 = """
    Short Description
    Long Description

    :param arg1: Description arg1.
    :param arg2: Description arg2.
    :param arg3: Description arg3.
    """

# Generated at 2022-06-23 17:20:55.361218
# Unit test for function parse
def test_parse():
    """Test function parse"""
    text = """
    Describe a function.
    
    :param param_name: describe a parameter.
    :param param_type param_name: describe a parameter.
    :param param_type param_name: describe a parameter. Defaults to 1.
    :param param_type param_name?: describe an optional parameter.
    :param param_type param_name?: describe an optional parameter. Defaults to 1.
    :raises Exception: describe an exception.
    :raises Exception: describe an exception:
                       extra long description.
    :returns: describe a return value.
    :yields: describe a yielded value.
    :yields type: describe a yielded value.
    
    Describe other things.
    """
    docstring = parse(text)

# Generated at 2022-06-23 17:21:02.918093
# Unit test for function parse
def test_parse():
    docstring = parse('''
Example docstring

This docstring has no metadata, only a short and long description.
    ''')

    assert docstring.short_description == 'Example docstring'
    assert docstring.long_description == 'This docstring has no metadata, only a short and long description.'
    assert docstring.meta == []
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description

    docstring = parse('''
Example docstring
This docstring has no metadata, only a short and long description.
    ''')

    assert docstring.short_description == 'Example docstring'
    assert docstring.long_description == 'This docstring has no metadata, only a short and long description.'
    assert docstring.meta == []
    assert not docstring.blank_

# Generated at 2022-06-23 17:21:06.889458
# Unit test for function parse
def test_parse():
    docstring_string = """One line summary.
    Immediate new line.
    Two more lines.

    :param str class_name: Class name that you want to instantiate.
    :param bool is_final: Whether the class is final or not.
    :param str base_class: Base class if available.
    :raises ValueError: If class is not in the valid format.
    :returns: Instance of the class if available.
    """
    print(parse(docstring_string))
    return parse(docstring_string)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:21:17.117104
# Unit test for function parse
def test_parse():
    doc = parse("""
    Parse the ReST-style docstring into its components.

    This function takes the docstring text and breaks it up into its
    component parts: short description, long description, blank line
    after short description, blank line after long description, and
    presentation-specific meta information.

    :arg int param: a parameter to the function
    :arg str other: another parameter
    :yields: something that is yielded
    :yields: something else that is yielded
    :returns: something that is returned
    :raises ValueError: a type of exception that is raised
    :raises: a type of exception that is raised without specifying a type
    :returns: a metavar without a type
    :keyword: a keyword without arguments
    :returns: something that is returned
    """)
    assert doc == Doc

# Generated at 2022-06-23 17:21:26.909333
# Unit test for function parse
def test_parse():
    docstring='''

    Parameters
    ----------
    x
        x axis
    y
        y axis

    Raises
    ------
    ValueError
        When x or y is invalid

    Returns
    -------
    list of tuple
        A list of tuples corresponding to (x,y)
    '''
    ret = parse(docstring)
    print(ret)
    assert ret.short_description==''
    assert ret.long_description is None
    assert ret.blank_after_short_description
    assert ret.blank_after_long_description

    assert len(ret.meta)==3
    assert ret.meta[0].args==['Parameters']
    assert ret.meta[0].description is None
    assert len(ret.meta[0].subparams)==2

# Generated at 2022-06-23 17:21:38.819326
# Unit test for function parse
def test_parse():
    import pydocstyle.violations as sut
    from unittest import TestCase

    from .test_common import is_valid_meta_data
    from .test_common import is_valid_info_data

    class TestParse(TestCase):
        def test_return_type(self):
            docstring = """
Returns the sum of two numbers.
:return: The sum.
"""
            info, meta = sut.parse(docstring)

            self.assertTrue(is_valid_meta_data(meta))
            self.assertTrue(is_valid_info_data(info))
            self.assertEqual(
                meta[0].description, "The sum."
            )  # description without newline
            self.assertEqual(meta[0].type_name, None)  # no type


# Generated at 2022-06-23 17:21:46.019472
# Unit test for function parse
def test_parse():
    docstring = parse('Test function.\n:param int a: Test a.\n:param int b: Test b.')
    assert [x.__class__.__name__ for x in docstring.meta] == ['DocstringMeta', 'DocstringParam', 'DocstringParam']

    assert docstring.meta[0].description == 'Test function.'
    assert docstring.meta[0].args == []

    assert docstring.meta[1].description == 'Test a.'
    assert docstring.meta[1].args == ['param', 'int', 'a']

    assert docstring.meta[2].description == 'Test b.'
    assert docstring.meta[2].args == ['param', 'int', 'b']


# Generated at 2022-06-23 17:21:56.901044
# Unit test for function parse
def test_parse():
    module = inspect.getmodule(parse)

    class Dummy:
        """This is a short description.
        This is the first line of the long description.
        This is the second line of the long description.
        This is the third line of the long description.

        :param a: This is a description of ``a``.
        :type a: int
        :param b: This is a description of ``b``.
        :type b: float

        :returns: This is a description of the return value.
        :rtype: str
        """


# Generated at 2022-06-23 17:22:07.189289
# Unit test for function parse
def test_parse():
    source = """
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    
    :rtype: Docstring
    
    :raises ParseError: if there is a parsing error
    """
    result = parse(source)
    print(result)
    assert result.short_description == "Parse the ReST-style docstring into its components."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert result.long_description == None
    assert result.meta[0].description == "parsed docstring"
    assert result.meta[0].arg_name == "returns"
    assert result.meta[0].type_name == None
    assert result.meta[0].is_optional == False

# Generated at 2022-06-23 17:22:18.080695
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    doc = parse("Foo bar.")
    assert doc.short_description == "Foo bar."
    assert not doc.long_description
    assert not doc.meta
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is True

    doc = parse("Foo bar.\n\nBaz qux.")
    assert doc.short_description == "Foo bar."
    assert doc.long_description == "Baz qux."
    assert not doc.meta
    assert doc.blank_after_short_description is True
    assert doc.blank_after_long_description is True

    doc = parse("Foo bar.\nBaz qux.")
    assert doc.short_description == "Foo bar."
    assert doc.long_description

# Generated at 2022-06-23 17:22:30.721889
# Unit test for function parse
def test_parse():
    assert parse("Hello") == Docstring(
        short_description="Hello",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    assert parse("Hello\nthere\n") == Docstring(
        short_description="Hello",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description="there",
        meta=[],
    )
    assert parse("Hello\n\nthere\n") == Docstring(
        short_description="Hello",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="there",
        meta=[],
    )

# Generated at 2022-06-23 17:22:35.841255
# Unit test for function parse
def test_parse():
    input = """
    Testing docstring.

    This is a test.

    :param something other: This is a param.
    :param something other: This is a param.
    :return keyword: This is a keyword.
    :raises SomeError:
    """

    parse_results = parse(input)

    assert parse_results.short_description == "Testing docstring."
    assert parse_results.long_description == "This is a test."
    assert parse_results.blank_after_short_description == False
    assert parse_results.blank_after_long_description == False
    assert len(parse_results.meta) == 3
    assert len(parse_results.params) == 2
    assert len(parse_results.returns) == 1
    assert len(parse_results.raises) == 1

# Generated at 2022-06-23 17:22:46.636031
# Unit test for function parse
def test_parse():
    text = """\
    """
    doc = parse(text)
    assert doc.short_description is None
    assert doc.long_description is None
    assert not doc.meta

    text = """\
    Short description.
    """
    doc = parse(text)
    assert doc.short_description == "Short description."
    assert doc.long_description is None
    assert not doc.meta

    text = """\

    Short description.
    """
    doc = parse(text)
    assert doc.short_description is None
    assert doc.long_description is None
    assert not doc.meta

    text = """\

    Short description.

    """
    doc = parse(text)
    assert doc.short_description is None
    assert doc.long_description is None
    assert not doc.meta


# Generated at 2022-06-23 17:22:57.352712
# Unit test for function parse
def test_parse():
    def sum(a: int, b: int) -> int:
        """
        Args:
            a: the first argument
            b: the second argument
        Returns:
            The sum of the two arguments.
        Raises:
            ValueError: if a is negative
        """
        pass

    docstring = parse(sum.__doc__)
    assert docstring.short_description == 'sum(a: int, b: int) -> int'
    assert docstring.long_description == 'Args:\n    a: the first argument\n    b: the second argument\nReturns:\n    The sum of the two arguments.\nRaises:\n    ValueError: if a is negative'

# Generated at 2022-06-23 17:23:07.764164
# Unit test for function parse
def test_parse():
    s = """
    This is the short description.

    This is the long
    description. It spans multiple
    lines.

    :param int x: This is a parameter.
    :param y: This is another parameter.
    :raise ValueError: if x > 10
    :return: None
    :returns: int
    :raises FileNotFoundError:
    """

# Generated at 2022-06-23 17:23:16.253603
# Unit test for function parse
def test_parse():
    res = parse("""
    :param text: docstring
    :return: the parsed docstring
    """)
    assert res.short_description == ""
    assert res.long_description == None
    assert res.blank_after_short_description
    assert res.blank_after_long_description
    assert len(res.meta) == 2
    assert isinstance(res.meta[0], DocstringParam)
    assert isinstance(res.meta[1], DocstringReturns)
    assert res.meta[0].arg_name == "text"
    assert res.meta[0].type_name == None
    assert res.meta[0].is_optional == None
    assert res.meta[0].default == None
    assert res.meta[1].type_name == "None"
    assert res.meta[1].is_generator

# Generated at 2022-06-23 17:23:23.978648
# Unit test for function parse
def test_parse():
    docstring_1 = """A function

    A function is a block of code which only runs when it
    is called. You can pass data, known as parameters, into a
    function.

    A function can return data as a result.

    e.g.
    def add(x, y=10):
        return x + y
    """


# Generated at 2022-06-23 17:23:34.375549
# Unit test for function parse
def test_parse():
    # TEST 1
    func_one_docstring = '''
    Add two numbers together.

    :param x: first number
    :type x: int
    :param y: second number
    :type y: int
    :returns: the sum of x and y
    :rtype: int
    '''
    # TEST 2
    func_two_docstring = '''
    Create a list of squares of input numbers.

    :param x: a number
    :type x: int
    :returns: a list of squares
    :rtype: list
    '''
    # TEST 3

# Generated at 2022-06-23 17:23:45.670768
# Unit test for function parse
def test_parse():
    docstring = """\
        First line of the short description.

        Extended description of the function. This can be as long as you
        like.

        Parameters
        ----------
        arg1 : str
            Description of `arg1`
        arg2 : int, optional
            Description of `arg2`

        Returns
        -------
        bool
            Description of the return value.

        Other Parameters
        ----------------
        kwarg1
        kwarg2
        kwarg3
        kwarg4 : str, optional
            Description of `kwarg4`
        kwarg5 : bool, optional
            Description of `kwarg5`
            Default: True
        kwarg6, kwarg7
            Description of `kwarg6` and `kwarg7`
    """
    # Check for correct parsing of all the meta info items


# Generated at 2022-06-23 17:23:57.419451
# Unit test for function parse

# Generated at 2022-06-23 17:24:08.700146
# Unit test for function parse
def test_parse():
    from . import parse
    _parse = parse.parse

    docstring = '''This is a description
        """
        :param value: a string
        :type value: str
        :param args:
        :type args:
        :param kwargs:
        :type kwargs:
        """
    '''

# Generated at 2022-06-23 17:24:17.793250
# Unit test for function parse
def test_parse():
    docstring = "foo bar\n\n    :param int a: foo bar.\n"
    docstring2 = "foo bar\n\n    :type a: int foo bar.\n"
    for ds in [docstring, docstring2]:
        d = parse(ds)
        assert d.short_description == 'foo bar'
        assert not d.blank_after_short_description
        assert d.blank_after_long_description
        assert d.long_description is None
        assert len(d.meta) == 1
        assert isinstance(d.meta[0], DocstringParam)
        assert d.meta[0].arg_name == 'a'
        assert d.meta[0].type_name == 'int'
        assert d.meta[0].is_optional is None

# Generated at 2022-06-23 17:24:27.216340
# Unit test for function parse
def test_parse():
    def f():
        """Summary line.

        Extended description.

        :param arg1: Description of arg1
        :param arg2: Description of arg2
        :returns: Description of return value
        :raises Exception1: description of Exception1
        :raises Exception2: description of Exception2
        """

    doc = parse(inspect.getdoc(f))
    for m in doc.meta:
        print(m.key)
    print(doc.short_description)
    print(doc.long_description)
    print(doc.blank_after_short_description)
    print(doc.blank_after_long_description)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:24:37.444577
# Unit test for function parse
def test_parse():
    docstring = '''Function for adding two 
                   numbers
                                                 
                   :param name:   type of the parameter
                   :type name:    int
                   :raises ValueError:
                   :return:       the addition of the two parameters
                   :rtype:        float
                   '''
    docst = parse(docstring)
    assert(docst.short_description == 'Function for adding two numbers')
    assert(docst.long_description == 'the addition of the two parameters')
    assert(len(docst.meta) == 4)
    assert(docst.meta[0].args == ['param', 'name'])
    assert(docst.meta[1].args == ['type', 'name'])
    assert(docst.meta[2].args == ['raises', 'ValueError'])

# Generated at 2022-06-23 17:24:47.673688
# Unit test for function parse
def test_parse():
    source = """
    Test function for function parse.

    :param str test: Test Var.
    :returns: The DocString
    """
    docstring = parse(source)
    assert (docstring.short_description == "Test function for function parse.")
    assert (docstring.blank_after_short_description == False)
    assert (docstring.long_description == None)
    assert (docstring.blank_after_long_description == None)
    assert (docstring.meta[0].args == ['param', 'str', 'test'])
    assert (docstring.meta[0].description == 'Test Var.')
    assert (docstring.meta[0].is_optional == False)
    assert (docstring.meta[0].type_name == 'str')

# Generated at 2022-06-23 17:24:56.494287
# Unit test for function parse
def test_parse():
    doc = '''Multiply two numbers.

Alternately, adds two numbers if you set
`alternate` to `True`.

:param a: The first number.
:type a: number
:param b: The second number.
:param alternate: Default is to multiply.
:type alternate: bool
:default alternate: False
:returns: The product of `a` and `b`.
:rtype: number
:raises ZeroDivisionError: If b is zero.
'''
    # print(parse(doc))
    print()
    print(dir(parse(doc)))
    print()
    print(parse(doc).meta)
    print()


# Generated at 2022-06-23 17:25:02.840190
# Unit test for function parse
def test_parse():
    def foo():
        """
        :param bar: bar boo
        :type bar: foo
        :param baz: baz boo
        :type baz: None
        :returns: returns boo
        :rtype: foo
        :raises: raises boo
        :type raises: str
        :yields: yields boo
        :type yields: int
        :returns: returns foo
        :rtype: None
        :yields: yields foo
        :type yields: None

        Test description for foo bar baz.

        Test description for foo bar baz.


        """

    def bar():
        """
        Test description for foo bar baz.

        Test description for foo bar baz.


        """


# Generated at 2022-06-23 17:25:14.233695
# Unit test for function parse
def test_parse():
    docstr = parse("""
    Return the xrefs for the given object.

    :param object: The object to get xrefs for.
    :returns: List of xrefs.
    """)
    assert docstr.short_description == 'Return the xrefs for the given object.'
    assert docstr.long_description == ''
    assert docstr.blank_after_short_description
    assert docstr.blank_after_long_description
    assert len(docstr.meta) == 1
    docstr_meta = docstr.meta[0]
    assert docstr_meta.args == ['param', 'object']
    assert docstr_meta.description == 'The object to get xrefs for.'
    assert docstr_meta.arg_name is None
    assert docstr_meta.type_name is None

# Generated at 2022-06-23 17:25:15.238616
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:25:26.700862
# Unit test for function parse

# Generated at 2022-06-23 17:25:34.351283
# Unit test for function parse
def test_parse():
    doc = """Hello, world.

    Short description of the class/module/function goes here. It may span
    multiple lines.

    Parameters
    ----------
    p1 : str
        First parameter
    p2 : int, optional
        Second parameter. Defaults to 42.

    Returns
    -------
    str
        Return value description

    Raises
    ------
    RuntimeError
        When the moon is full.

    Examples
    --------
    >>> import foo
    >>> foo.bar(42)
    """
    d = parse(doc)
    assert d.short_description == "Hello, world."
    assert d.blank_after_short_description is True
    assert d.blank_after_long_description is True
    assert d.long_description == 'Short description of the class/module/function goes here. It may span multiple lines.'

# Generated at 2022-06-23 17:25:43.468543
# Unit test for function parse
def test_parse():
    # _build_meta
    # DocstringParam
    docstr = parse("""
    :param int x: The x-coordinate.
    """)
    # TODO(eric.cousineau): Consider moving to a full-fledged test suite that
    # uses pytest, etc.
    # Check DocstringParam.
    assert isinstance(docstr.meta[0], DocstringParam)
    assert docstr.meta[0].type_name == "int"
    assert docstr.meta[0].arg_name == "x"
    assert docstr.meta[0].description == "The x-coordinate."
    # DocstringReturns
    docstr = parse("""
    :returns: This is a test.
    """)
    # Check DocstringReturns.

# Generated at 2022-06-23 17:25:54.873049
# Unit test for function parse
def test_parse():
    """Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """
    ret = Docstring()
    text = 'Parse the ReST-style docstring into its components.\n\n' \
    '    :returns: parsed docstring\n\n' \
    '    :param text: str'
    if not text:
        return ret

    text = inspect.cleandoc(text)
    match = re.search("^:", text, flags=re.M)
    if match:
        desc_chunk = text[: match.start()]
        meta_chunk = text[match.start() :]
    else:
        desc_chunk = text
        meta_chunk = ""

    parts = desc_chunk.split("\n", 1)
   

# Generated at 2022-06-23 17:26:06.269301
# Unit test for function parse
def test_parse():
    # Test basic description
    description = '''
    Test docstring parsing.

    This is a function that,
    when testing,
    tests the test parser.
    '''
    result = parse(description)
    assert result.short_description == "Test docstring parsing."
    assert result.long_description == "This is a function that,\n" \
        "when testing,\n" \
        "tests the test parser."

    # Test :param tag
    param_1 = '''
    :param name: The name of the person.
    '''
    result = parse(param_1)
    assert result.meta[0].arg_name == "name"
    assert result.meta[0].type_name is None
    assert result.meta[0].is_optional is None

# Generated at 2022-06-23 17:26:15.740480
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()


# Generated at 2022-06-23 17:26:21.165092
# Unit test for function parse
def test_parse():
    example_text = '''\
Returns x**2.
See docs for pow() for more info.

:returns: x**2
:rtype: int
:raises ValueError: if x is negative
'''

# Generated at 2022-06-23 17:26:32.586592
# Unit test for function parse
def test_parse():
    docstring = parse("""
        This function does something.

        :param name: name of the person
        :type name: str
        :param age: age of the person
        :type age: int
        :param location: where the person lives
        :type location: str
            defaults to 'Unknown'

        :returns: a full name
        :rtype: str
    """)
    assert isinstance(docstring.short_description, str)
    assert docstring.short_description == 'This function does something.'
    assert isinstance(docstring.blank_after_short_description, bool)
    assert docstring.blank_after_short_description
    assert isinstance(docstring.long_description, str)