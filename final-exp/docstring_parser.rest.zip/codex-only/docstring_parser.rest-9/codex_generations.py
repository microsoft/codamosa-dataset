

# Generated at 2022-06-23 17:16:35.780549
# Unit test for function parse
def test_parse():
    doc = parse("""
    """
)
    assert doc.short_description == None
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.meta == []

    doc = parse("""DESCRIPTION""")
    assert doc.short_description == "DESCRIPTION"
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.meta == []

    doc = parse("""
    DESCRIPTION
    """)
    assert doc.short_description == "DESCRIPTION"
    assert doc.long_description == None
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long

# Generated at 2022-06-23 17:16:41.228414
# Unit test for function parse
def test_parse():
    """Test function parse."""
    docstring = parse(__doc__)
    assert docstring.short_description == "ReST-style docstring parsing."
    assert docstring.long_description is not None
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args == ["return", ":class:`Docstring`"]
    assert docstring.meta[0].description == "parsed docstring"

# Generated at 2022-06-23 17:16:48.569167
# Unit test for function parse
def test_parse():
    text = """
    Example docstring.
    
    :param a: parameter a
    :type a: int
    :param b: parameter b
    :type b: int
    :returns: return values
    :rtype: int
    
    End of docstring.
    """
    assert parse(text).short_description == "Example docstring."
    assert parse(text).long_description == """
    :param a: parameter a
    :type a: int
    :param b: parameter b
    :type b: int
    :returns: return values
    :rtype: int
    """
    assert parse(text).meta[0].arg_name == "a"
    assert parse(text).meta[0].type_name == "int"
    assert parse(text).meta[0].description == "parameter a"

# Generated at 2022-06-23 17:17:00.416805
# Unit test for function parse
def test_parse():
    text = '''
    Function to do something.

    :param arg1: Argument to do something

    something about this function

    :returns: function returns something

    :raises: something

    :yields: something
    '''

    parsed_docstring = parse(text)
    assert(parsed_docstring.short_description == 'Function to do something.')
    assert(parsed_docstring.blank_after_short_description)
    assert(parsed_docstring.long_description == 'something about this function')
    assert(len(parsed_docstring.meta) == 3)
    first_meta = parsed_docstring.meta[0]
    assert(first_meta.args == ['param', 'arg1'])
    assert(first_meta.description == 'Argument to do something')


# Generated at 2022-06-23 17:17:10.228326
# Unit test for function parse
def test_parse():
    import pytest
    docstring = parse("""\
    This function return 1+1.
    :param float x: the float
    :param int y: the int
    :returns: x + y
    """)
    assert docstring.short_description == "This function return 1+1."
    assert docstring.long_description is None
    assert docstring.meta[0].arg_name == "x"
    assert docstring.meta[0].type_name == "float"
    assert docstring.meta[1].type_name == "int"
    assert docstring.meta[2].type_name is None



# Generated at 2022-06-23 17:17:19.350125
# Unit test for function parse
def test_parse():
    doc = parse("""
    :param x: the X value
    :type x: int
    :param y: the Y value
    :type y: int
    :returns: X + Y
    :rtype: int
    """)
    assert doc.short_description is None
    assert doc.long_description is None
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ["param", "x"]
    assert doc.meta[0].description == "the X value"
    assert doc.meta[0].type_name == "int"
    assert doc.meta[1].args == ["type", "x"]
    assert doc.meta[1].description == "int"
    assert doc.meta[1].type_name is None
    assert doc.meta[2].args == ["returns"]


# Generated at 2022-06-23 17:17:30.714040
# Unit test for function parse
def test_parse():

    print("Beginning Testing for parse()")

    assert parse("") == Docstring()

    assert parse("One line.") == Docstring(
        short_description="One line.",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("One line.\n") == Docstring(
        short_description="One line.",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-23 17:17:38.881459
# Unit test for function parse
def test_parse():
    text = """
    A short summary.
    
    A long description.
    
    :param str arg1:
        This is argument 1.
    :raises ValueError: 
        If something goes wrong.
    :returns: 
        The return value.
    """


# Generated at 2022-06-23 17:17:40.042563
# Unit test for function parse
def test_parse():
    for test, want in constants.TESTS:
        got = parse(test)
        assert got.__dict__ == want.__dict__

# Generated at 2022-06-23 17:17:49.382926
# Unit test for function parse
def test_parse():
    text =\
    """This is the first line of the docstring.
    This is the second line of the docstring.
    This is the third line of the docstring.

    :param str arg_name: this is the description for arg_name
    :type arg_name: str
    :param int arg_2: this is the description for arg_2
    :param arg_3: this is the description for arg_3
    :returns: this is the description for return value
    :rtype: str
    :raises Exception: this is the description for the exception
    """
    docstring = parse(text)
    print(docstring)
    print(docstring.short_description)
    print(docstring.blank_after_short_description)
    print(docstring.long_description)

# Generated at 2022-06-23 17:17:58.879479
# Unit test for function parse
def test_parse():
    from .common import Docstring

# Generated at 2022-06-23 17:18:09.768783
# Unit test for function parse
def test_parse():
    docstring_text = '''A one-line summary.

    A longer description. It can span multiple lines.

    :param a: A first parameter.
    :param b: A second parameter.
    :raises ValueError: If anything bad happens.

    :return: Nothing.
    '''
    docstring = parse(docstring_text)
    assert docstring.short_description == 'A one-line summary.'
    assert docstring.blank_after_short_description == True
    assert docstring.long_description == 'A longer description. It can span multiple lines.'
    assert docstring.blank_after_long_description == False

    assert len(docstring.meta) == 3
    assert isinstance(docstring.meta[0], DocstringParam)
    assert docstring.meta[0].arg_name == 'a'

# Generated at 2022-06-23 17:18:17.177244
# Unit test for function parse
def test_parse():
    def f():
        """Parse the ReST-style docstring into its components.

        :returns: parsed docstring
        """
        pass

    expected = Docstring(
        short_description="Parse the ReST-style docstring into its components.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description=None,
        meta=[DocstringReturns(args=["returns"], description="parsed docstring")],
    )

    assert parse(f.__doc__) == expected



# Generated at 2022-06-23 17:18:28.202039
# Unit test for function parse
def test_parse():
    docstring = """
Summary line.

This is the first paragraph.

This is the second paragraph.

:param foo: this is foo
:type foo: Tuple[str, int]
:param bar: this is bar
:type bar: int, optional
:default bar: 42
:raises KeyError: when a key error
:returns: None
"""
    ds = parse(docstring)
    assert ds.short_description == "Summary line."
    assert ds.long_description.startswith("This is the first paragraph.")
    assert ds.blank_after_short_description
    assert ds.blank_after_long_description
    assert len(ds.meta) == 4

    param_meta = ds.meta[0]
    assert isinstance(param_meta, DocstringParam)
    assert param

# Generated at 2022-06-23 17:18:34.987232
# Unit test for function parse
def test_parse():
    # Normal docstring
    text = """\
        Short description.

        Long description.

        :param arg1: Description of arg1
        :type arg1: str
        :param arg2: Description of arg2
        :param arg3: Description of arg3, defaults to value3.
        :raises Exception: because you shouldn't do that.

        :returns: Description of return value
        :rtype: int
        """
    assert parse(text) == parse_numpy(text)

    # Docstring with one-liners

# Generated at 2022-06-23 17:18:38.864504
# Unit test for function parse
def test_parse():
    docstring_text = '''
        Summary line.
        
        Extended description.
        
        :param: app_id
            description of app_id
        :param type_name: type_name
            description of type_name
        :param is_optional: bool -- description of is_optional
        :returns: a_return_value -- description of a_return_value
        :returns: a_return_value -- description of a_return_value
    '''
    parsed_docstring = parse(docstring_text)
    assert not parsed_docstring.blank_after_short_description
    assert parsed_docstring.blank_after_long_description
    assert parsed_docstring.short_description == 'Summary line.'
    assert parsed_docstring.long_description =='''Extended description.'''

# Generated at 2022-06-23 17:18:44.802658
# Unit test for function parse
def test_parse():
    import os
    import json
    with open(os.path.dirname(__file__) + '/res/docstring_parse.json') as f:
        data = json.load(f)

    for i, d in enumerate(data):
        docstring = Docstring(**d)
        docstring_parsed = parse(docstring.text)
        assert docstring == docstring_parsed

# Generated at 2022-06-23 17:18:56.124000
# Unit test for function parse
def test_parse():
    docstring = parse(
        """
        Short description.

        Long description.

        :param arg1: description of first argument.
        :param arg2: description of second argument.
        :type arg2: int
        :raises error1: if it breaks
        :raises error2: if it breaks

        """
    )
    assert docstring.short_description == "Short description."
    assert docstring.blank_after_short_description == False
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-23 17:19:00.915524
# Unit test for function parse
def test_parse():
    string = """
    Test docstring.  This is a very long description.

    :param what: what to test.
    :type what: str
    :param when: when to test it.
    :type when: datetime
    :param why: Why to test it.
    :type why: str
    :return: Result of the test.
    :returns: str
    :raises RuntimeError: If the world doesn't make sense.
    """


# Generated at 2022-06-23 17:19:12.468453
# Unit test for function parse
def test_parse():

    def do_test(original, expected):
        result = parse(original)
        assert (
            result == expected
        ), "result: {}\nexpected: {}\noriginal: {}".format(result, expected, original)


# Generated at 2022-06-23 17:19:18.771262
# Unit test for function parse
def test_parse():
    text = """Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    :rtype: :class:`~typedocs.parser.sd.Docstring`
    """
    expected = Docstring(
        short_description="Parse the ReST-style docstring into its components.",
        long_description=(
            "returns: parsed docstring\n"
            "rtype: :class:`~typedocs.parser.sd.Docstring`"
        ),
        blank_after_short_description=True,
        blank_after_long_description=True,
    )
    assert parse(text) == expected

# Generated at 2022-06-23 17:19:21.555787
# Unit test for function parse
def test_parse():
    docstring = inspect.getdoc(parse)
    parsed = parse(docstring)
    print(parsed)
    print(parsed.meta)


# Generated at 2022-06-23 17:19:31.001427
# Unit test for function parse
def test_parse():
    doc = """
    Short description.

    Long description.

    :param x: Param name.
    :param y: Param name.
    :type y: int
    :param z: Param name.
    :type z: int, optional

    :returns: returns something
    :rtype: str
    :returns: returns something else
    :rtype: int
    :returns: more return values
    :rtype: unknown

    :raises KeyError: when a key error
    :raises KeyError: if a key error
    """
    result = parse(doc)
    assert result.short_description == "Short description."
    assert result.long_description == "Long description."
    assert len(result.meta) == 7
    assert result.meta[0].arg_name == "x"

# Generated at 2022-06-23 17:19:33.457503
# Unit test for function parse
def test_parse():
    """
    This function is for unit test of module parse.
    """
    assert False

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:19:41.615808
# Unit test for function parse
def test_parse():
    docstring = """
    Simple addition.

    Example:

    >>> 2 + 2
    4

    :param x: The first number to add
    :param y: The second number to add
    :returns: The result of the addition
    :raises TypeError: if any of the arguments are not numbers
    """

# Generated at 2022-06-23 17:19:53.631527
# Unit test for function parse
def test_parse():
    from .__about__ import __version__
    f = open("./tests/unit/__init__.py")
    docstring = parse(f.read())
    assert docstring.short_description == "Unit tests for pdoc."
    assert docstring.long_description == (
        "The module ``pdoc.tests.unit`` provides unit tests for "
        "the ``pdoc`` library itself."
    )
    assert not docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 4
    assert isinstance(docstring.meta[0], DocstringParam)
    assert isinstance(docstring.meta[1], DocstringReturns)
    assert isinstance(docstring.meta[2], DocstringRaises)

# Generated at 2022-06-23 17:20:05.677100
# Unit test for function parse
def test_parse():
    docstring = """One line summary.

    Extended description.

    :param str arg1: Description of arg1.
    :param type arg2: Description of arg2.
    :keyword val: Description of val.
    :return:
    :rtype:
    :raises Exception:
    :raises KeyError:
    """


# Generated at 2022-06-23 17:20:15.783438
# Unit test for function parse
def test_parse():
    text = """\
    Some short description
    Another line

    This is some long
    multiline description.

    :param foo: Foo
    :param bar: Bar
    :param baz: Baz
    """

    doc = parse(text)
    assert doc.short_description == "Some short description"
    assert doc.blank_after_short_description
    assert doc.long_description.startswith("This is some long\n    multiline description.")
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0] == DocstringMeta(args=["param", "foo"], description="Foo")
    assert doc.meta[1] == DocstringMeta(args=["param", "bar"], description="Bar")
    assert doc.meta[2] == Docstring

# Generated at 2022-06-23 17:20:22.356167
# Unit test for function parse

# Generated at 2022-06-23 17:20:33.953722
# Unit test for function parse
def test_parse():
    '''
    arguments: None 
    Test cases for parse() function
    '''
    # Check return type and value of None
    assert isinstance(parse(""), Docstring)
    assert parse("") == Docstring()
    # Positive test cases - Check for single line description, 2 line description, 2 line description with empty line,
    # positive test cases for meta information
    # The test cases are given below:
    test_string = "one line description\n"
    assert (
        parse(test_string)
        == Docstring(
            short_description="one line description",
            long_description=None,
            blank_after_short_description=False,
            blank_after_long_description=False,
            meta=[],
        )
    )
    test_string = "first line\nsecond line\n"

# Generated at 2022-06-23 17:20:42.667034
# Unit test for function parse
def test_parse():
    import datetime

# Generated at 2022-06-23 17:20:48.393393
# Unit test for function parse
def test_parse():
    doc = """
    This is the short description.

    This is the long description.

    :param param1: this is a first param
    :param param2: this is a second param
    :return: None
    :rtype: None
    :raises keyError: raises an exception
    """
    print(parse(doc))

# Generated at 2022-06-23 17:20:58.210152
# Unit test for function parse
def test_parse():
    help ="""The ``check_version`` can be called in two ways:

    - If the optional ``check_version`` argument is called with
      ``check_version=True``, it will check if a newer version of the package
      is available and print a message if that's the case.

    - if the ``check_version`` argument is called as a function, it will return
      a boolean specifying whether a newer version is available."""

    doc = parse(help)
    assert len(doc) == 2
    assert doc.meta[0].key == 'short_description'
    assert doc.meta[0].arg_name is None
    assert doc.meta[0].type_name is None
    assert doc.meta[0].description is None

    assert doc.meta[1].key == 'long_description'
    assert doc.meta[1].arg_

# Generated at 2022-06-23 17:21:09.461594
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    docstring = parse("Short description\n\nLong description.")
    assert docstring.short_description == "Short description"
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.long_description == "Long description."
    assert docstring.meta == []

    docstring = parse("Short description\nLong description.")
    assert docstring.short_description == "Short description"
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.long_description == "Long description."
    assert docstring.meta == []

    docstring = parse(
        "Short description\n\nLong description.\n:param x: The value."
    )

# Generated at 2022-06-23 17:21:18.571553
# Unit test for function parse
def test_parse():
    # Test description parsing
    for text in [
        """ \t \nReturn the absolute value of the argument.
        """
    ]:
        plain = parse(text)
        assert plain.short_description == "Return the absolute value of the argument."
        assert plain.long_description is None
        assert not plain.blank_after_short_description
        assert not plain.blank_after_long_description
        assert plain.meta == []
    # Test parameter parsing
    for text in [
        """ \t \nParameters\n----------\narg : int
        """
    ]:
        plain = parse(text)
        assert plain.short_description == "Parameters"
        assert plain.long_description == "----------"
        assert not plain.blank_after_short_description
        assert not plain.blank_after_long_description

# Generated at 2022-06-23 17:21:27.472529
# Unit test for function parse
def test_parse():
    # test empty string
    assert parse("") == Docstring()
    # test no meta
    assert parse("Hello World!") == Docstring(
        short_description="Hello World!",
        long_description=None,
        blank_after_long_description=False,
        blank_after_short_description=False,
    )
    # test with meta

# Generated at 2022-06-23 17:21:39.441088
# Unit test for function parse
def test_parse():
    "Test that the parse function works"
    def foo(a, b, c=1):
        """Short description.
        Long description.
        :param a: Parameter a.
        :type a: str
        :param b: Parameter b.
        :type b: int
        :param c: Parameter c.
        :type c: int
        :returns: The return value.
        :rtype: int
        """
        pass


# Generated at 2022-06-23 17:21:50.404966
# Unit test for function parse
def test_parse():
    assert _build_meta(args=['param', 'a'], desc='desc') == DocstringParam(
        args=['param', 'a'],
        description='desc',
        arg_name='a',
        type_name=None,
        is_optional=False,
        default=None,
    )
    assert _build_meta(args=['param', 'a', 'b'], desc='desc') == DocstringParam(
        args=['param', 'a', 'b'],
        description='desc',
        arg_name='b',
        type_name='a',
        is_optional=False,
        default=None,
    )

# Generated at 2022-06-23 17:21:58.853125
# Unit test for function parse
def test_parse():
    # test function parse
    docstring = """The add_one function adds 1 to some number.

:param x: The number to add 1 to.
:type x: int
:returns: x + 1
:rtype: int

"""
    parsed_docstring = parse(docstring)

    assert parsed_docstring.short_description == "The add_one function adds 1 to some number."
    assert parsed_docstring.blank_after_short_description
    assert parsed_docstring.long_description is None
    assert parsed_docstring.blank_after_long_description
    assert parsed_docstring.meta[0].description == "The number to add 1 to."
    assert parsed_docstring.meta[0].type_name == "int"
    assert parsed_docstring.meta[1].description == "x + 1"
   

# Generated at 2022-06-23 17:22:08.397932
# Unit test for function parse
def test_parse():
    ds = parse("""
    This docstring should have the following elements:

    * A short description
    * A blank line after the short description
    * The long description, which should be indented
    * Another blank line after the long description

    :param arg_name: description
    :type arg_name: str
    :param arg_name2: description
    :type arg_name2: int

    :raises: desc

    :returns: desc
    :rtype: int
    """)
    assert ds.short_description == "This docstring should have the following elements:"
    assert ds.blank_after_short_description == True

# Generated at 2022-06-23 17:22:16.998181
# Unit test for function parse
def test_parse():
    ds = parse("""
        A short description.
    
        A long description.
    
        :param a: An argument.
        :type a: int
        :param b: A second argument.
        :type b: float
        :param c: A third argument.
        :returns: None
        :rtype: None
        :raise ValueError: Raises a ValueError.
        :raises TypeError: Raises a TypeError.
        :raises NotImplementedError: Raises a NotImplementedError.
    """)
    assert ds.short_description == "A short description."
    assert ds.long_description == "A long description."
    assert not ds.blank_after_short_description
    assert not ds.blank_after_long_description

# Generated at 2022-06-23 17:22:24.709234
# Unit test for function parse
def test_parse():
    """ Unit test for function parse """
    # (1) Test for case 1: docstring only has short description
    title1 = "This is a title"
    doc1 = ".. This is a docstring"
    docstring1 = parse(doc1)
    assert docstring1.short_description == title1, "docstring title is incorrect"
    assert docstring1.blank_after_short_description is True, "docstring blank after title is incorrect"
    assert docstring1.blank_after_long_description is False, "docstring blank after long description is incorrect"
    assert docstring1.long_description is None, "docstring long description is incorrect"
    assert docstring1.meta == [], "docstring meta is incorrect"

    # (2) Test for case 2: docstring only has short description and blank line

# Generated at 2022-06-23 17:22:35.750417
# Unit test for function parse
def test_parse():
    docstring = """
    This is the first line of a "short description".
    This is the second line of a "short description".
    
    
    
    
    
    
    This is "the first line of a long description".
    This is the second line of a "long description".


    :param arg1: the first parameter"""
    doc = parse(docstring)
    assert doc.short_description == "This is the first line of a \"short description\".\nThis is the second line of a \"short description\"."

    assert doc.long_description is None

    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False

    assert len(doc.meta) == 1
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta

# Generated at 2022-06-23 17:22:46.597526
# Unit test for function parse
def test_parse():
    ds = """Short description.

Long description."""
    assert parse(ds) == Docstring(
        short_description="Short description.",
        blank_after_short_description=False,
        long_description="Long description.",
        blank_after_long_description=False,
        meta=[],
    )

    ds = """Short description.

Long description.


"""
    assert parse(ds) == Docstring(
        short_description="Short description.",
        blank_after_short_description=False,
        long_description="Long description.",
        blank_after_long_description=True,
        meta=[],
    )

    ds = """Short description.

:yields type: Long description.


"""

# Generated at 2022-06-23 17:22:54.561419
# Unit test for function parse
def test_parse():
    text = """
    Test Docstring

    Args:
        param1 (str): Description
        param2 (str): Description
    """

    docstring = parse(text)
    assert docstring.short_description == 'Test Docstring'
    assert docstring.meta[0].arg_name == 'param1'
    assert docstring.meta[0].type_name == 'str'
    assert docstring.meta[1].arg_name == 'param2'
    assert docstring.meta[1].type_name == 'str'

# Generated at 2022-06-23 17:23:05.834983
# Unit test for function parse
def test_parse():
    # parse a function with a normal docstring
    def test():
        """
        This is short description.

        This is a long description.
        """

    # parse a function with a docstring that doesn't have a blank line
    def test2():
        """This is short description.

        This is a long description.
        """

    def test3():
        """This is short description.

        This is a long description with no trailing newline.
        """

    # parse a function with a short description that ends with a period
    def test4():
        """This is short description.

        This is a long description.
        """

    # parse a function with a short description that doesn't end with a period
    def test5():
        """This is short description

        This is a long description.
        """


# Generated at 2022-06-23 17:23:12.196084
# Unit test for function parse
def test_parse():
    pass
    #import inspect
    #def hello():
    #    """hello
    #
    #    :param name: name
    #        desc
    #    :type name: str
    #    :returns: str
    #        desc
    #        desc
    #    """
    #
    #print(parse(inspect.getdoc(hello)))

# Generated at 2022-06-23 17:23:14.781428
# Unit test for function parse
def test_parse():
	import doctest
	doctest.testmod()	

if __name__ == "__main__":
	test_parse()

# Generated at 2022-06-23 17:23:21.222625
# Unit test for function parse
def test_parse():

    doc = parse(
        """Short description.

    Long description.

    :returns: int -- the answer
    :raises ImportError: if something goes wrong
    """
    )

    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."

    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == True

    assert len(doc.meta) == 2

    assert doc.meta[0].args == ["returns", "int"]
    assert doc.meta[0].description == "the answer"
    assert isinstance(doc.meta[0], DocstringReturns)
    assert doc.meta[0].type_name == "int"

    assert doc.meta[1].args == ["raises", "ImportError"]
    assert doc.meta

# Generated at 2022-06-23 17:23:32.175300
# Unit test for function parse
def test_parse():
    text = inspect.cleandoc("""
        Calculate the sum of a and b.
        
        :param a: The first value.
        :type a: int
        :param b: The second value.
        :type b: int
        :returns: The approximate sum of a and b.
        :rtype: int
    """)

# Generated at 2022-06-23 17:23:38.275875
# Unit test for function parse
def test_parse():
    docstring = """A short summary.

A long description.

:param int foo: The foo parameter.
"""
    assert parse(docstring) == Docstring(
        short_description="A short summary.",
        blank_after_short_description=True,
        long_description="A long description.",
        blank_after_long_description=False,
        meta=[
            DocstringParam(
                args=["param", "int", "foo"],
                description="The foo parameter.",
                arg_name="foo",
                type_name="int",
                is_optional=False,
                default=None,
            )
        ],
    )



# Generated at 2022-06-23 17:23:44.274025
# Unit test for function parse
def test_parse():
    assert parse(
        """\
Summary line.

    Extended description.
"""
    ) == Docstring(
        short_description="Summary line.",
        long_description="Extended description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[],
    )
    assert parse(
        """\
Summary line. Extended description.

Another paragraph."""
    ) == Docstring(
        short_description="Summary line. Extended description.",
        long_description="Another paragraph.",
        blank_after_short_description=False,
        blank_after_long_description=True,
        meta=[],
    )


# Generated at 2022-06-23 17:23:51.892000
# Unit test for function parse

# Generated at 2022-06-23 17:24:01.372484
# Unit test for function parse
def test_parse():
    import textwrap
    docstring = textwrap.dedent("""
    Add demo docstring parse function.

    Args:
        test : int
            Test number one.
        test : str
            Test number two.
        test (str) : Test number three.
        test (str, int) : Test number four.
        test (str, int) : Test number five
            no line break.

    Return:
        int
            Return an int
    """)
    d = parse(docstring)

    assert d.short_description == "Add demo docstring parse function."
    assert d.long_description is None
    assert d.blank_after_short_description
    assert d.blank_after_long_description

    assert len(d.meta) == 5
    assert d.meta[3].arg_name == "test"
   

# Generated at 2022-06-23 17:24:11.575245
# Unit test for function parse
def test_parse():
    text = '''
    Input is a tuple (x, y, z) or a list [x, y, z].

    The coordinates are returned in the form of a tuple (u, v, w).

    :type x: float
    :param x: x coordinate

    :type y: float
    :param y: y coordinate

    :type z: float
    :param z: z coordinate

    :rtype: tuple (u, v, w) :returns: Coordinates u, v, and w.
    '''
    assert parse(text).short_description == 'Input is a tuple (x, y, z) or a list [x, y, z].'
    assert parse(text).blank_after_short_description

# Generated at 2022-06-23 17:24:19.971991
# Unit test for function parse
def test_parse():
    text = '''Sum
    ====

    Compute the sum of all arguments.

    :param x: first argument
    :type x: int > 0
    :param y: second argument
    :type y: int > 0

    :returns int: the sum of all arguments
        This line should not be a part of the return description.

    :raises ValueError: if any argument is negative.
    '''

    expected = parse(text)
    result = parse(str(expected))
    assert (expected == result)

# Generated at 2022-06-23 17:24:28.522689
# Unit test for function parse
def test_parse():
    docstring = '''
    Hello world!
    :param name: First name (e.g. "John").
    :type name: str
    :param age: Age in years (e.g. 21).
    :type age: int
    :returns: A greeting for the given person.
    :rtype: str
    :raises ValueError: If age is less than 0.
    '''

    print(repr(docstring))

    for i in range(3):
        doc = parse(docstring)
        print(repr(doc))
        print()

        print(doc, end="\n\n")
        print(doc.short_description)
        print(doc.long_description)
        print(doc.blank_after_short_description)
        print(doc.blank_after_long_description)


# Generated at 2022-06-23 17:24:37.893863
# Unit test for function parse
def test_parse():
    """Test parse function."""

# Generated at 2022-06-23 17:24:48.429492
# Unit test for function parse
def test_parse():
    docstring = '''Short description.

This is a long description. This is a long description. This is a long
description. This is a long description. This is a long description. This
is a long description.

:param arg_name: Description.
:type arg_name: str
:param type_name: Description.
:type type_name: str
:param last_name: Description.
:type last_name: str
:returns: Description.
:rtype: str
'''

    result = parse(docstring)

    assert len(result.meta) == 4
    assert result.long_description == "This is a long description. This is a long description. This is a long\ndescription. This is a long description. This is a long description. This\nis a long description."
    assert result.short_description == 'Short description.'

# Generated at 2022-06-23 17:24:55.181919
# Unit test for function parse
def test_parse():
    text = """\
    Short description.

    Long description.  Second line.

    :param foo: Foo param description.  With more text.
    :type foo: str | None
    :param bar: Bar param description.
    :type bar: str
    :param int baz: Baz param description.  With more text.  And more.

    :keyword xxx:
        This is a very long keyword.  It wraps to a second line because it's so
        long.
    :keyword yyy: zzz
    :returns: Returns description.
    :return type: str
    :raises ValueError: Raises description.
    """
    docstring = parse(text)
    print(docstring)
    assert docstring.short_description == "Short description."
    assert not docstring.blank_after_short_description


# Generated at 2022-06-23 17:25:02.568862
# Unit test for function parse
def test_parse():
    doc = inspect.cleandoc('''
    Short description.

    Long description.

    :param arg1: first argument.
    :param arg2: second argument.
    :type arg2: str.
    :returns: nothing.
    :raises Exception: This is an exception.
    ''')
    d = parse(doc)
    assert d.short_description == 'Short description.'
    assert d.long_description == 'Long description.'
    assert d.blank_after_short_description
    assert not d.blank_after_long_description
    
    assert len(d.meta) == 4
    arg1, arg2, returns, raises = d.meta
    assert type(arg1) == DocstringParam
    assert arg1.arg_name == 'arg1'
    assert arg1.type_name == None

# Generated at 2022-06-23 17:25:14.093235
# Unit test for function parse
def test_parse():
    s = """
    This is a docstring.

    This is the long description.

    :param a_name str: A description.
    :param b_name: B defaults to True.
    :returns: None.
    :raises TypeError: If the wrong type is given.
    """
    docstring = parse(s)
    assert docstring.short_description == "This is a docstring."
    assert docstring.blank_after_short_description == True
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 4
    assert docstring.meta[0].arg_name == "a_name"
    assert docstring.meta[0].type_name == "str"
    assert docstring.meta

# Generated at 2022-06-23 17:25:15.531029
# Unit test for function parse
def test_parse():
    """
    Test that the parser works
    :return:
    """
    pass

# Generated at 2022-06-23 17:25:27.153600
# Unit test for function parse
def test_parse():
    docstring = """A simple function.

I am the long description.
:param x: number of things
:type x: int
:param y: number of other things
:type y: float
:return: x plus y
:rtype: float
:raises ValueError: if x or y is not a number.
    """

# Generated at 2022-06-23 17:25:34.510586
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    doc_string = """
    Description
    :param: name
    :param: age
    :returns:
    """
    parsed_doc_string_test = parse(doc_string)
    print(parsed_doc_string_test)
    assert parsed_doc_string_test.meta[0].args[0] == "param"
    assert parsed_doc_string_test.meta[0].arg_name == "name"
    assert parsed_doc_string_test.meta[1].args[0] == "param"
    assert parsed_doc_string_test.meta[1].arg_name == "age"
    assert parsed_doc_string_test.meta[2].args[0] == "returns"


# Generated at 2022-06-23 17:25:41.824149
# Unit test for function parse
def test_parse():
    r"""Ensure that we can parse a docstring."""
    class Obj:
        r"""A test object.

        It has a function.
        """

        def func(
            self,
            one: "first argument" = None,
            two: "second argument" = True,
        ):
            r"""The function description.

            :param one: The first argument.
            :type one: str
            :param two: The second argument.
            :type two: bool

            :returns: Nothing.
            :rtype: None
            """
            return None

    doc = parse(inspect.getdoc(Obj.func))
    assert doc
    assert doc.short_description == "The function description."
    assert doc.long_description == "It has a function."
    assert len(doc.meta) == 2
    assert doc

# Generated at 2022-06-23 17:25:52.869622
# Unit test for function parse
def test_parse():
    """Test parse()."""
    ds = parse("Short description\n\nLong description.\n\n:param name: description\n:param: description")
    assert ds.short_description == "Short description"
    assert ds.long_description == "Long description."
    assert ds.blank_after_short_description
    assert ds.meta == [
        DocstringMeta(args=["param", "name"], description="description"),
        DocstringMeta(args=["param"], description="description"),
    ]

    ds = parse("")
    assert ds.short_description is None
    assert ds.long_description is None

    ds = parse("Short\n\nLong")
    assert ds.short_description == "Short"
    assert ds.long_description == "Long"
    assert d

# Generated at 2022-06-23 17:26:03.994106
# Unit test for function parse
def test_parse():
    text = """
    """
    text = inspect.cleandoc(text)
    match = re.search("^:", text, flags=re.M)
    if match:
        desc_chunk = text[: match.start()]
        meta_chunk = text[match.start() :]
    else:
        desc_chunk = text
        meta_chunk = ""

    parts = desc_chunk.split("\n", 1)
    short_description = parts[0] or None
    if len(parts) > 1:
        long_desc_chunk = parts[1] or ""
        blank_after_short_description = long_desc_chunk.startswith("\n")
        blank_after_long_description = long_desc_chunk.endswith("\n\n")
        long

# Generated at 2022-06-23 17:26:13.915794
# Unit test for function parse
def test_parse():
    # test empty string
    print("Test empty string")
    docstring = parse("")
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.meta == []


    # test short description only
    print("Test short description only")
    docstring = parse("Short description.")
    assert "Short description." == docstring.short_description
    assert docstring.long_description is None
    assert docstring.meta == []


    # test short description and long description
    print("Test short description and long description")
    docstring = parse("Short description.\n\nLong description.")
    assert "Short description." == docstring.short_description
    assert "Long description." == docstring.long_description
    assert docstring.meta == []


    # test short description and long description


# Generated at 2022-06-23 17:26:20.182283
# Unit test for function parse

# Generated at 2022-06-23 17:26:32.062015
# Unit test for function parse
def test_parse():
    def f():
        """
    This funciton adds two numbers.
    :param time: time to add
    :param another time: another time to add
    :returns: sum of time and another time
    """
        return

    # :rtype: int
    # :type num: int
    # :type nums: list[int]
    # :raises ValueError: if x is negative
    # :param x: number of lines to print
    # :param y: string to print
    # :returns: None
    # :return: None
    # :yields: None
    # :yield: None
    # :raises: ValueError
    # :return: None
    # :returns: None
    # :raises: ValueError
    # :param bar: bar to print
