

# Generated at 2022-06-23 17:16:33.905444
# Unit test for function parse
def test_parse():
    """
    """
    assert parse("") == Docstring()

    docstring = parse(
        """
        Say hello.

        :param name:
        """
    )
    assert docstring == Docstring(
        short_description="Say hello.",
        long_description=None,
        meta=[
            DocstringParam(["param", "name", "name"], "", "name", None, None, None)
        ],
    )

    docstring = parse(
        """
        Say hello.

        :param name: A name.

        :type name: str
        """
    )

# Generated at 2022-06-23 17:16:44.076608
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a short description.

    This is a long description.

    :param foo: This is the first parameter.
    :param bar: This is another parameter.
    :returns: A dict.
    : > This is actually a sub-heading.
    : > And this is another sub-heading.
    : > :param fob: Third parameter.
    : > :param baz: Final parameter.
    : Raises: KeyError
    : > :param fob: Third parameter.
    : > :param baz: Final parameter.
    '''
    doc = parse(docstring)
    assert doc.short_description == 'This is a short description.'
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == True
    assert doc.long_description

# Generated at 2022-06-23 17:16:56.308583
# Unit test for function parse
def test_parse():

    """
        Test the parse function
    """
    # Test None input
    docstring = parse(None)
    assert docstring.short_description is None
    assert docstring.blank_after_short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_long_description is None

    # Test empty input
    docstring = parse("")
    assert docstring.short_description is None
    assert docstring.blank_after_short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_long_description is None

    # Test simple docstring
    docstring = parse("This is a simple docstring.")
    assert docstring.short_description == "This is a simple docstring."
    assert docstring.blank_after_short_description is None


# Generated at 2022-06-23 17:17:03.975689
# Unit test for function parse
def test_parse():
    """Test function parse"""
    docstring = """Create new instance of the `Rating` class.

:param user_id: User identifier
:type user_id: ``int``
:param movie_id: Movie identifier
:type movie_id: ``int``
:param rating: Rating
:type rating: ``float``
:param timestamp: Timestamp
:type timestamp: ``int``
:raises ValueError: If any of the arguments are not appropriate
"""

    docstring_obj = parse(docstring)

    assert len(docstring_obj.meta) == 5
    assert docstring_obj.meta[0].arg_name == "user_id"
    assert docstring_obj.meta[0].type_name == "int"
    assert docstring_obj.meta[0].is_optional is None
    assert docstring_obj.meta

# Generated at 2022-06-23 17:17:13.890974
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    assert parse.__doc__ is not None
    ds = parse(parse.__doc__)
    assert isinstance(ds, Docstring)
    assert isinstance(ds.short_description, str)
    assert ds.short_description is not None
    assert ds.short_description[0] == ds.short_description[0].lower()
    assert ds.short_description[-1] == "."
    assert ds.long_description is not None
    assert isinstance(ds.long_description, str)
    assert len(ds.long_description) > 0
    assert ds.long_description[0] == ds.long_description[0].lower()
    assert ds.long_description[-1] == "."

# Generated at 2022-06-23 17:17:26.173015
# Unit test for function parse
def test_parse():
    # test that empty docstrings give us the right thing
    assert parse('').__dict__ == Docstring().__dict__
    assert parse('\n').__dict__ == Docstring().__dict__

    # test that a single line docstring gives us the right thing,
    assert parse('Hello.').__dict__ == Docstring(
        short_description='Hello.'
    ).__dict__

    # test that a docstring with whitespace at the beginning
    # gives us the right thing
    assert parse(' Hello.').__dict__ == Docstring(
        short_description='Hello.'
    ).__dict__

    # test that a docstring with whitespace at the end
    # gives us the right thing
    assert parse('Hello. ').__dict__ == Docstring(
        short_description='Hello.'
    ).__dict__

    # test

# Generated at 2022-06-23 17:17:27.890045
# Unit test for function parse
def test_parse():
    import doctest
    failed, total = doctest.testmod(verbose=True)
    assert failed == 0, "{} tests of {} failed".format(failed, total)

# Generated at 2022-06-23 17:17:33.580102
# Unit test for function parse
def test_parse():
    doc = """
    Args:
        name (str):
 
        repeat (int): The number of times to repeat.
        
        is_optional (str, optional): 

    Returns something.
    """
    parsed = parse(doc)
    print(parsed)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:17:40.183772
# Unit test for function parse
def test_parse():
    """
    Tests for parse()
    """
    text = """
    A test function.

    :param arg1: Lorem ipsum
    :param arg2: Lorem ipsum
    :param arg3: defaults to foo.
    :param arg4: Lorem ipsum
    :param arg5: Also lorem ipsum.
    :param arg6?: Lorem ipsum
    :param arg7?: defaults to bar.
    :param arg8: Lorem ipsum
    :raises ValueError:
    :raises TypeError: if the input is not a list
    :yields: The next item in the list.
    :returns: The sum of all the items in the list.
    """
    result = parse(text)
    assert result.short_description == 'A test function.'

# Generated at 2022-06-23 17:17:49.590798
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    docstring = parse('''\
        ''')
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []

    docstring = parse('''
        A short description.
        ''')
    assert docstring.short_description == 'A short description.'
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-23 17:17:58.999568
# Unit test for function parse
def test_parse():
    docstr = """
    Copy files and directories.

    :param str src:
        Path to the source file.  If the `src` is a directory, the
        contents of the directory will be copied recursively.

    :param str dest:
        Path to the destination.

    :type recurse: ``boolean``
    :param recurse:
        Recursively copy contents of directories.  Default is ``True``.

    :type force: ``boolean``
    :param force:
        Do not prompt before overwriting existing files.  Default is ``False``.

    :raises:
        OSError, if either src or dest could not be found, or if
        copying failed.
    """

# Generated at 2022-06-23 17:18:09.900729
# Unit test for function parse
def test_parse():
    test_docstring = """
This is a short description.

This is a longer description.
:param x: integer
:param y: float
:param z: list
:returns: None

"""
    result = parse(test_docstring)
    assert result.short_description == "This is a short description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert result.long_description == "This is a longer description."
    assert result.meta[0].arg_name == "x"
    assert result.meta[0].args[0] == ":param"
    assert result.meta[0].args[1] == "x"
    assert result.meta[0].description == "integer"

# Generated at 2022-06-23 17:18:19.646133
# Unit test for function parse
def test_parse():
    """Test parse
    """

    def function(arg1: int, arg2: int) -> str:
        """
        Short description
        ==================

        Long description.

        :param int arg1: The first argument.
        :param int arg2: The second argument.

        :returns: Return value.
        :rtype: int
        """
        return str(arg1 + arg2)

    docstring = parse(function.__doc__)
    assert docstring.short_description == "Short description"
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args[0] == "param"

# Generated at 2022-06-23 17:18:30.793792
# Unit test for function parse
def test_parse():
    with open("test/docstrings/parse.txt") as fp:
        text = fp.read()
    doc = parse(text)
    print(doc)
    assert doc.short_description == "foo"
    assert doc.long_description == "Long description.\n\nWith line breaks."
    assert doc.meta[0].description == "First parameter."
    assert doc.meta[0].arg_name == "a"
    assert doc.meta[0].type_name is None
    assert doc.meta[0].is_optional is None
    assert doc.meta[0].default is None

    assert doc.meta[1].description == "Second argument"
    assert doc.meta[1].arg_name == "b"
    assert doc.meta[1].type_name is None

# Generated at 2022-06-23 17:18:42.947272
# Unit test for function parse
def test_parse():
    text = """\
        short description

        long description.

        :param int a: a description
        :param int b: b description.
        :param str c: c description. this is a long line,
            so maybe it needs to be wrapped?

        :returns: a description, type is unknown
        :returns: b description, type is str.
        :yields: c description, type is bool.
        :raises ValueError: if this happens.
        :raises Exception: if that happens.
    """
    ds = parse(text)
    assert ds.short_description == "short description"
    assert ds.long_description.startswith("long description.\n\n")
    assert len(ds.meta) == 10

# Generated at 2022-06-23 17:18:51.551725
# Unit test for function parse
def test_parse():
    doc = parse('''\
    This is a module docstring
    and is multi-line.

    This is the second paragraph.
    ''')

    assert doc.short_description == 'This is a module docstring'
    assert doc.blank_after_short_description == True
    assert doc.long_description == 'and is multi-line.\n\nThis is the second paragraph.'
    assert doc.blank_after_long_description == False
    assert doc.meta == []

    doc = parse('''\
    This is a module docstring
    and is multi-line.

    This is the second paragraph.

    :param x: the first param
    :param y: the second param
    :return: no return
    ''')

    assert doc.short_description == 'This is a module docstring'

# Generated at 2022-06-23 17:18:58.668405
# Unit test for function parse
def test_parse():
    """
    Unit test for the parse function.
    """
    test_string = """
    Parse the ReST-style docstring into its components.

    :param name: The name to use in the response.
    :param bool verbatim: use argument as provided
    :param Optional[int] age: the age to use
    :return: the parsed docstring
    :rtype: Docstring
    :raises TypeError: if text is not a string
    """

# Generated at 2022-06-23 17:19:11.127114
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("test") == Docstring(
        short_description="test",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=True,
        meta=[],
    )
    assert parse("test\nlong desc") == Docstring(
        short_description="test",
        blank_after_short_description=False,
        long_description="long desc",
        blank_after_long_description=True,
        meta=[],
    )

# Generated at 2022-06-23 17:19:18.826126
# Unit test for function parse
def test_parse():
    text = """Test name
:param int param1: the first parameter
:param str param2: description for the second parameter
:returns: description for the return value
"""

    ret = parse(text)
    assert ret.short_description == "Test name"
    assert ret.long_description is None
    assert ret.blank_after_short_description is False
    assert ret.blank_after_long_description is False

    assert ret.meta[0].args == ['param1', 'int', 'param2']
    assert ret.meta[0].description == "the first parameter"

    assert ret.meta[1].args == ['param2', 'str', 'param2']
    assert ret.meta[1].description == "description for the second parameter"

    assert ret.meta[2].args == ['returns']

# Generated at 2022-06-23 17:19:28.314048
# Unit test for function parse
def test_parse():

    """
    Test function parse
    """

    import pytest

    # Test with correct parameters
    docstring = ""
    docstring += "function_classification\n"
    docstring += "Compute some classification metrics on a function\n"
    docstring += "\n"
    docstring += "Parameters\n"
    docstring += "----------\n"
    docstring += "y_true : pandas dataframe\n"
    docstring += "    The true labels\n"
    docstring += "y_pred : pandas dataframe\n"
    docstring += "    The predicted labels\n"
    docstring += "method : str\n"
    docstring += "    What method to use.\n"
    docstring += "results : dict\n"
    docstring += "    The result dict\n"


# Generated at 2022-06-23 17:19:38.480658
# Unit test for function parse
def test_parse():
    r"""
    Tests for parse()
    """
    def verify(text: str, expected: typing.List[T.Tuple[str, int]]):
        docstring = parse(text)
        actual = [
            (m.description, m.line)
            for m in docstring.meta
            if isinstance(m, DocstringParam)
        ]
        assert actual == expected

    # case: minimal
    text = "This is a function."
    expected = []
    verify(text, expected)

    # case: single-line parameter
    text = "This is a function.\n:param x: the value of x"
    expected = [("the value of x", 1)]
    verify(text, expected)

    # case: single-line parameter with type

# Generated at 2022-06-23 17:19:43.791754
# Unit test for function parse
def test_parse():
    doc = """\
        A short summary of the function, the first sentence.

        A longer description of the function,
         spanning multiple lines.

        :param name: a name
        :param value: a value

        :returns: None
        """

# Generated at 2022-06-23 17:19:50.787066
# Unit test for function parse
def test_parse():
    docstring = """
    Short description

    Long description

    Examples
    --------
    """

    expected_docstring = Docstring(
        short_description="Short description",
        blank_after_short_description=False,
        long_description="Long description",
        blank_after_long_description=False,
        meta=[],
    )
    assert parse(docstring) == expected_docstring



# Generated at 2022-06-23 17:19:55.644398
# Unit test for function parse
def test_parse():
    docstring = parse(
        """One line summary.
        
        :param int a: description of the first parameter.
        :type int a: description of the parameter type.
        :param str b: description of the second parameter.
        :returns: description of the return value
        :rtype: type description of the return value
        :raises Exception: description of the exception
        :yields: description of the generator
        :yields type str: type description of the yielded value
        :meta:
        """
    )
    assert docstring.short_description == "One line summary."
    assert docstring.long_description == "Second line of summary."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == []

# Generated at 2022-06-23 17:20:07.089087
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short summary.

    This is the longer description.

    :param foo: the first argument
    :param bar: this is the second argument
    :type bar: ``int``
    :returns: the return value of the function
    :rtype: ``str``
    :raises ValueError: if something bad happened.
    """
    result = parse(docstring)


# Generated at 2022-06-23 17:20:17.195280
# Unit test for function parse

# Generated at 2022-06-23 17:20:28.041843
# Unit test for function parse

# Generated at 2022-06-23 17:20:38.473396
# Unit test for function parse
def test_parse():
    docstring = \
        """
        :param arg1: The first argument

        :type arg1: str
        :type arg2: int
        :param arg2: The second argument.
        """
    result = parse(docstring)
    assert not result.short_description
    assert not result.blank_after_short_description
    assert not result.blank_after_long_description
    assert not result.long_description
    assert len(result.meta) == 2
    assert result.meta[0].arg_name == "arg1"
    assert result.meta[0].description == "The first argument"
    assert result.meta[0].type_name == "str"
    assert result.meta[0].is_optional is None
    assert result.meta[0].default is None
    assert result.meta[1].arg_name

# Generated at 2022-06-23 17:20:42.659602
# Unit test for function parse
def test_parse():
    """Test the parse() function."""

    text = """\
        Foo the foos.

        :param foo: The first foo.
        :type foo: :class:`~Foo`
        :param bar: The second foo.
        :type bar: :class:`~Bar`
        :param baz: The last foo.
        :type baz: :class:`~Baz`
        :raises FizzleError: When fizzle goes wrong.
        :returns: The foos.
        :rtype: :class:`~Foo`
        :yields: The first foo.
        :ytype: :class:`~Foo`
        """
    ret = parse(text)

# Generated at 2022-06-23 17:20:47.036468
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("foo\n") == Docstring(short_description="foo")

    doc = parse("foo")
    assert doc.short_description == "foo"
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert doc.meta == []

    doc = parse("foo\nbar")
    assert doc.short_description == "foo"
    assert doc.long_description == "bar"
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert doc.meta == []

    doc = parse("foo\nbar\n\nbaz")
    assert doc.short_description == "foo"
    assert doc.long

# Generated at 2022-06-23 17:20:57.191606
# Unit test for function parse
def test_parse():
    """
    UUT: parse
    """
    text = """Summary line.

    Extended description.

    :param str bar: Description of *bar*.
    :param int baz: Description of `baz` with code block::
    
        print(baz)

    :raises Exception: If an error occurs.
    :returns: Description of return value.
    :rtype: str
    """
    result = parse(text)
    assert result.short_description == "Summary line."
    assert result.blank_after_short_description == True
    assert result.long_description == "Extended description."
    assert result.blank_after_long_description == True
    assert result.meta[0].args == ['param', 'str', 'bar']
    assert result.meta[0].description == "Description of *bar*."
   

# Generated at 2022-06-23 17:21:03.542688
# Unit test for function parse
def test_parse():
    ds = parse("""Short desc.

Long desc.

: param arg: arg description.
: param arg2: arg2 description.
""")

    assert ds.short_description == "Short desc."
    assert ds.long_description == "Long desc."
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is True
    assert len(ds.meta) == 2

    ds = parse("""Short desc.

: param arg:
    arg description.

""")

    assert ds.short_description == "Short desc."
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is True
    assert len(ds.meta) == 1



# Generated at 2022-06-23 17:21:15.261325
# Unit test for function parse
def test_parse():
    docstring = """
    This is the short description.

    This is the first line of the long description.

    This is the second line of the long description.

    :param arg1: This is the first argument.
    :type arg1: str

    :param arg2: This is the second argument.
    :type arg2: int, optional
    :default arg2: 42

    :returns: Description of return value.
    :rtype: int

    :raises keyError: When a key is not found.
    """
    doc = parse(docstring)

    assert doc.short_description == "This is the short description."
    assert doc.long_description == (
        "This is the first line of the long description.\n\n"
        "This is the second line of the long description."
    )

# Generated at 2022-06-23 17:21:26.311901
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""

    def test_func():
        """Docstring for test_func.
        
        :param x: parameter x
        :param y: parameter y
        :returns: function returns
        :raises a: exception a
        :raises b: exception b
        :returns: function returns
        :raises a: exception a
        :raises b: exception b
        """

    docstring = parse(test_func.__doc__)
    assert docstring.short_description == "Docstring for test_func."

# Generated at 2022-06-23 17:21:32.321786
# Unit test for function parse
def test_parse():
    class docstring:
        """
        This is a test

        foo bar
        """

    s = parse(docstring.__doc__)
    assert s.short_description == "This is a test"
    assert s.blank_after_short_description is True
    assert s.blank_after_long_description is True
    assert s.long_description == "foo bar"
    assert len(s.meta) == 0



# Generated at 2022-06-23 17:21:42.700252
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("func() -> int\n    no desc.") == Docstring(
        short_description="func() -> int",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description="no desc.",
        meta=[],
    )
    assert parse("func() -> int\n\n    no desc.") == Docstring(
        short_description="func() -> int",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="no desc.",
        meta=[],
    )

# Generated at 2022-06-23 17:21:54.885203
# Unit test for function parse
def test_parse():
    r = parse('')
    assert r == Docstring()

    r = parse('This is a simple test')
    assert r == Docstring(
        short_description='This is a simple test',
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[]
    )

    r = parse('This is a simple test\n\nwith a long description')
    assert r == Docstring(
        short_description='This is a simple test',
        long_description='with a long description',
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[]
    )

    r = parse('This is a simple test\n\nwith\n\na long description')
    assert r == Doc

# Generated at 2022-06-23 17:22:05.936770
# Unit test for function parse

# Generated at 2022-06-23 17:22:16.605676
# Unit test for function parse
def test_parse():
    rst = """
    Returns the value of the most recent item in the list: either the first or
    last depending on ``pop_first``.

    If the list is empty, this method raises a ``KeyError``.

    :arg str list_name: the name of the list to pop an item from
    :arg bool pop_first: if ``True``, pop the first item; otherwise, pop
        the last item
    :raises KeyError: if the list is empty
    :returns: the last item in the list
    """
    ds = parse(rst)
    assert ds.short_description == "Returns the value of the most recent item in the list: either the first or last depending on ``pop_first``."

# Generated at 2022-06-23 17:22:24.563637
# Unit test for function parse
def test_parse():
    def check_parse(func, s_desc, l_desc, meta):
        doc = parse(inspect.getsourcelines(func)[0][0][4:58])
        return (doc.short_description == s_desc
        and doc.long_description == l_desc
        and doc.meta == meta)
    assert check_parse(
        _build_meta, "Build a DocstringMeta",
        None, []
    )

# Generated at 2022-06-23 17:22:30.620328
# Unit test for function parse
def test_parse():
    def foo(a: int, b: int = 1) -> int:
        """Short description.

        Long description.
        :param a: An integer.
        :param b: Optional, defaults to 1.
        :return: The sum of `a` and `b`.
        """
        return a + b

    docstring = parse(inspect.getdoc(foo))
    print(docstring)

test_parse()

# Generated at 2022-06-23 17:22:39.563476
# Unit test for function parse
def test_parse():
    text = '''
    A docstring for testing.

    This is for testing the fuctions for docstring parsing
    and generation.

    :param int a: Some integer.
    :param int b: Some other integer.
    :returns: This is the return value.
    '''


# Generated at 2022-06-23 17:22:45.749232
# Unit test for function parse
def test_parse():
    docstring = """
        Some summary.

        Some more detail.

        :param int x: int x
        :param int y: int y
        :returns: returns
    """

    doc = parse(docstring)
    assert len(doc.meta) == 2
    assert doc.short_description == 'Some summary.'
    assert len(doc.long_description) >= 6
    assert doc.meta[0].description == 'int x'
    assert doc.meta[1].description == 'returns'

# Generated at 2022-06-23 17:22:57.107734
# Unit test for function parse
def test_parse():
    docstring = """This is a demo docstring.
    :param str A:
    :param str B:
    :returns str:
    """
    result = parse(docstring)
    
    assert result.short_description == "This is a demo docstring."
    assert len(result.meta) == 2
    assert result.meta[0].args == ['param', 'str', 'A']
    assert result.meta[0].description == ""
    assert result.meta[0].arg_name == "A"
    assert result.meta[0].type_name == "str"
    assert result.meta[0].is_optional is None
    assert result.meta[0].default is None
    assert result.meta[1].args == ['returns', 'str']
    assert result.meta[1].description == ""
    assert result

# Generated at 2022-06-23 17:23:07.762349
# Unit test for function parse
def test_parse():
    text = """
    This is an example of parse. It is usually called before
    model fit.

    :param x: input data
    :type x: int
    :returns: a dict
    :rtype: dict
    """
    doc = parse(text)
    assert doc.short_description == 'This is an example of parse.'
    assert doc.long_description == 'It is usually called before model fit.'
    assert doc.meta[0].key == 'param'
    assert doc.meta[0].arg_name == 'x'
    assert doc.meta[0].type_name == 'int'
    assert doc.meta[0].is_optional is False
    assert doc.meta[1].key == 'returns'
    assert doc.meta[1].type_name == 'dict'

# Generated at 2022-06-23 17:23:13.743415
# Unit test for function parse
def test_parse():
    doc_string = '''
                Test function
                :type int: int
                :param int: int
                :var: int
                '''
    doc_string_2 = '''
                Test function
                :type int: int
                :param int: int
                :returns: int
                '''
    doc_string_3 = '''
                    Test function
                    :type string: str
                    :param string: str
                    :var: int
                    :returns: str
                    '''
    print(parse(doc_string))
    print(parse(doc_string_2))
    print(parse(doc_string_3))

# Generated at 2022-06-23 17:23:20.767844
# Unit test for function parse
def test_parse():
    doc = """
    Function to test our parsing
    :param a: blah
    :param b: blah (defaults to None)
    :returns: nothing
    """
    parsed = parse(doc)
    assert parsed.short_description == "Function to test our parsing"
    assert parsed.long_description == None
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 2
    assert parsed.meta[0].key == "param"
    assert parsed.meta[0].arg_name == "a"
    assert parsed.meta[0].type_name == None
    assert parsed.meta[0].is_optional == None
    assert parsed.meta[0].default == None

# Generated at 2022-06-23 17:23:31.759530
# Unit test for function parse
def test_parse():
    text = '''
    Newline at beginning of string

    :param int a: parameter a
    :param int b: parameter b
    :raises ImportError: if something goes wrong
    :returns: poo
    '''
    doc = parse(text)
    assert doc.short_description == 'Newline at beginning of string'
    assert doc.blank_after_short_description
    assert doc.long_description is None
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    param_a, param_b, raises = sorted(doc.meta, key=lambda m: m.args)
    assert param_a.args == ['param', 'a:', 'parameter', 'a']
    assert param_a.description == 'parameter a'

# Generated at 2022-06-23 17:23:39.444911
# Unit test for function parse
def test_parse():
    docstring = """
    Short description for the function.
    Extended description for the function.

    :param x: A necessary parameter for the function.
    :type x: int
    :param y: An optional parameter for the function.
    :type y: int, optional
    :param z:
        A parameter with a default value.

        It can also span multiple lines.
    :type z: str, optional
    :raises Exception: When something goes wrong.
    :returns:
        The return value is a string.

        It can also span multiple lines.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Short description for the function."
    assert parsed.long_description == (
        "Extended description for the function."
    )
    assert parsed.blank_after_short_description
    assert parsed

# Generated at 2022-06-23 17:23:48.964249
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    str1 = """
    :param x: variable x
    :type x: int
    :param y: variable y
    :type y: int
    :returns: The maximum of x and y.
    :rtype: int
    """
    docstr = parse(str1)
    assert docstr.short_description == None
    assert docstr.long_description == None
    assert docstr.blank_after_short_description == True
    assert docstr.blank_after_long_description == False
    assert docstr.meta[0].arg_name == 'x'
    assert docstr.meta[0].is_optional == False
    assert docstr.meta[0].type_name == 'int'
    assert docstr.meta[1].arg_name == 'y'

# Generated at 2022-06-23 17:24:00.238120
# Unit test for function parse
def test_parse():
    fn = r"""
    This is a test docstring.

    This is the long description.

    :param bool OPTION: This is the description of OPTION.
    :param bool OPTION2: This is the description of OPTION2
    :paramtype OPTION: bool
    :paramtype OPTION2: bool
    :returns: Description of return value
    :rtype: bool
    """
    docstr = parse(fn)
    assert(docstr.short_description == 'This is a test docstring.')
    assert(docstr.long_description == 'This is the long description.')

    assert(docstr.meta[0].description == 'This is the description of OPTION.')
    assert(docstr.meta[0].arg_name == 'OPTION')

# Generated at 2022-06-23 17:24:08.875798
# Unit test for function parse
def test_parse():
    str1 = """
    short description
    long description
    :param x: first argument
        more description
    :param y: second argument
    :return: no description
    :return:
    :raises: error
    :raises ValueError
    :raises:
    """
    test = parse(str1)
    assert test.short_description == "short description"
    assert test.long_description == "long description"
    assert test.meta[2].description == "no description"
    assert len(test.meta) == 8


# Generated at 2022-06-23 17:24:17.956797
# Unit test for function parse
def test_parse():
    # type: () -> None
    import pytest
    from .common import parse as parse_common


# Generated at 2022-06-23 17:24:21.674742
# Unit test for function parse
def test_parse():
    docstring = '''
    :param: arg1 arg2 arg3
    '''
    print(dir(parse(docstring)))


# test_parse()

# Generated at 2022-06-23 17:24:29.341801
# Unit test for function parse
def test_parse():

    # Unit Tests for function parse
    def func1(arg1: str, *args: str, other: int = 0, **kwargs) -> int:
        """Function One

        :param arg1: Argument One
        :param *args: Variable arguments
        :param other: Argument Two
        :returns: int
        """
        pass

    def func2(arg1: str, *args: str, other: int = 0, **kwargs) -> int:
        """Function Two

        :param str arg1: Argument One
        :param tuple *args: Variable arguments
        :param int other: Argument Two
        :returns: Integer
        """
        pass


# Generated at 2022-06-23 17:24:38.206463
# Unit test for function parse
def test_parse():
    def f1():
        """
        An example function...

        :param foo:   The foo.
        :type foo:    str
        :param bar:   The bar.
        :type bar:    str
        :param baz:   The baz.
        :type baz:    str
        :param qux?:  The qux.
        :type qux?:   int?
        :param qux2?: The qux2.
        :type qux2?:  int?
        :returns:     Some description of the return value.
        :rtype:       int

        :raises ValueError: If an invalid value was given
        """
        pass


# Generated at 2022-06-23 17:24:48.583775
# Unit test for function parse

# Generated at 2022-06-23 17:24:58.389754
# Unit test for function parse
def test_parse():
    # Arrange
    test_docstring = """
    first line
    second line
    :param arg1: first arg
    :param arg2: second arg
    :param arg3: third arg
    :type arg1: int
    :type arg2: str
    :return: whatever
    """

    # Act
    docstring = parse(test_docstring)

    # Assert
    assert docstring.short_description == "first line\nsecond line"
    assert docstring.long_description is None

    assert len(docstring.meta) == 4
    assert isinstance(docstring.meta[0], DocstringParam)
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].type_name == "int"
    assert docstring.meta[0].is_optional

# Generated at 2022-06-23 17:25:10.305118
# Unit test for function parse
def test_parse():
    docstring1 = inspect.cleandoc(
    """docstring1
    :param arg1: argument 1
    :type arg1: int
    :param arg2: argument 2
    :type arg2: int
    :param arg3?: argument 3, defaults to 3
    :param arg4?: argument 4, defaults to 4
    :param arg5?: argument 5, defaults to 5
    :rtype: str
    :returns: return value
    """
    )

# Generated at 2022-06-23 17:25:19.620212
# Unit test for function parse
def test_parse():
    """
    This is a unit test for the parse() function
    """
    # Unit test for parse error
    def f():
        """
        :param:
        """
        pass

    assert parse(f.__doc__).meta[0].description == ""

    # Unit test for short and long description
    def f():
        """
        This is the short description.

        This is the long description.
        """
        pass

    assert parse(f.__doc__).short_description == "This is the short description."
    assert parse(f.__doc__).long_description == "This is the long description."

    # Unit test for blank after short and long descriptions
    def f():
        """
        This is the short description.

        This is the long description.

        """
        pass


# Generated at 2022-06-23 17:25:31.303091
# Unit test for function parse
def test_parse():
    text = \
    """Computes the loss value for an input batch.
    
    :param pred_boxes: a float tensor with shape [batch_size, #anchors, 4].
    :param pred_logits: a float tensor with shape [batch_size, #anchors, #classes].
    :param gt_boxes: a float tensor with shape [batch_size, MAX_NUM_INSTANCES, 4].
    :param gt_labels: a int tensor with shape [batch_size, MAX_NUM_INSTANCES].
    :returns: loss: a scalar tensor of loss.
    :raises ValueError: if the shape of inputs mismatch.
    """
    doc = parse(text)
    print(doc)


# Generated at 2022-06-23 17:25:40.653715
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short summary.

    This is a longer description that spans multiple lines.

    :param arg: A description of the arg.
    :returns: A description of what is returned.
    """

# Generated at 2022-06-23 17:25:44.756604
# Unit test for function parse
def test_parse():
    doc1 = ':param a: apple\n:param a: banana'
    ret = parse(doc1)


# Generated at 2022-06-23 17:25:55.006675
# Unit test for function parse
def test_parse():
    docstring = parse("""\
        Test function.

        :param a: A parameter.
        :param b: A parameter with a long
            description that spans multiple
            lines.
        :param c: A parameter with a default value. Defaults to 2.
        :param d:
        :returns: Nothing.
        :raises ValueError: If nothing happens.
        """)

    def _assert_meta(
        meta, args, description, arg_name=None, type_name=None, is_optional=None
    ):
        assert [x.args for x in meta] == [args]
        assert [x.description for x in meta] == [description]
        if isinstance(meta[0], DocstringParam):
            assert [x.arg_name for x in meta] == [arg_name]

# Generated at 2022-06-23 17:26:06.437075
# Unit test for function parse
def test_parse():
    import utils
    import os
    import re
    import inspect
    import sys
    import textwrap
    import contextlib
    import io
    from .common import Docstring

    class Expected(object):  # noqa
        def _assert_equal(self, other):
            for attr in dir(self):
                if attr.startswith("_"):
                    continue
                try:
                    assert getattr(self, attr) == getattr(other, attr)
                except AssertionError:
                    msg = "attribute {0} differs: {1} {2}".format(
                        attr, getattr(self, attr), getattr(other, attr)
                    )
                    raise AssertionError(msg)


# Generated at 2022-06-23 17:26:15.889552
# Unit test for function parse
def test_parse():
    text_1 = inspect.cleandoc("""
    Sets a name's value.

    :param int a: The a parameter.
    """)
    ds = parse(text_1)
    assert(ds.short_description == "Sets a name's value.")
    assert(ds.meta[0].arg_name == "a")

    text_2 = inspect.cleandoc("""
    Sets a name's value.

    :param int a: The a parameter.
    :param int b: The b parameter.
    """)
    ds = parse(text_2)
    assert(ds.short_description == "Sets a name's value.")
    assert(ds.meta[0].arg_name == "a")
    assert(ds.meta[1].arg_name == "b")


# Generated at 2022-06-23 17:26:26.957537
# Unit test for function parse
def test_parse():
    docstring = """
    Function
    :type x: int
    :param y: str
    :yields: int
    :raises ValueError: if invalid value
    :raises TypeError
    :returns: int
    :return: str
    """