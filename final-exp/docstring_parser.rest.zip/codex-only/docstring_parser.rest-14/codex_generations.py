

# Generated at 2022-06-23 17:16:33.909418
# Unit test for function parse
def test_parse():
    docstring_0 = "Test for class 0\n" \
                  "\n" \
                  ":param name: name of class\n" \
                  ":param age: age of class\n" \
                  ":param classId: id of class\n" \
                  "\n" \
                  ":returns: a class\n"
    docstring_1 = "Test for class 1\n" \
                  "\n" \
                  ":param name: name of class\n" \
                  ":param age: age of class\n" \
                  ":param classId: id of class\n" \
                  "\n" \
                  ":returns: a class\n"

# Generated at 2022-06-23 17:16:44.077313
# Unit test for function parse
def test_parse():
    """Test for function parse."""
    text = '''
    :param x: a parameter
    :param y: another parameter

    :returns: something

    :raises: Exception
    '''
    doc = parse(text)

    assert doc.short_description is None
    assert doc.long_description is None

    assert len(doc.meta) == 3

    assert doc.meta[0].key == "param"
    assert doc.meta[0].arg_name == "x"
    assert doc.meta[0].description == "a parameter"
    assert doc.meta[0].is_optional is None
    assert doc.meta[0].type_name is None
    assert doc.meta[0].default is None

    assert doc.meta[1].key == "param"

# Generated at 2022-06-23 17:16:55.974387
# Unit test for function parse
def test_parse():
    """Parse the ReST-style docstring into its components.

    ========
    **Args**
    ========

    * **object** : ``object`` \\n
        An object with a docstring.

    * **text** : ``str`` \\n
        A ReST-style docstring.

    * **existing** : `~.Docstring`, optional \\n
        Existing parsed docstring.

    *returns*: ``str`` \\n
        Parsed docstring.
    """

if __name__ == "__main__":
    doc = parse(test_parse.__doc__)
    print(doc.short_description)
    print(doc.long_description)
    for meta in doc.meta:
        print(meta.args, meta.description)

# Generated at 2022-06-23 17:17:03.769218
# Unit test for function parse
def test_parse():
    assert (parse("""\
    This is a test.

    :param arg1: First arg
    :param arg2: Second arg

    :returns: Whatever
    """)) == \
        Docstring(
        short_description="This is a test.",
        long_description="First arg\n\nSecond arg",
        blank_after_short_description=False,
        blank_after_long_description=True,
        meta=[
            DocstringParam(
                args=["param", "arg1"], description="First arg", arg_name="arg1"
            ),
            DocstringParam(
                args=["param", "arg2"], description="Second arg", arg_name="arg2"
            ),
            DocstringReturns(args=['returns'], description="Whatever"),
        ],
    )


# Generated at 2022-06-23 17:17:13.369745
# Unit test for function parse
def test_parse():
    docstring = parse("""
    This is a short description.
    \n
    And now for something completely different:
    \n
    :param x: We expect x to be an int, and it defaults to 4.
    :param y: We expect y to be a float.
    :param z: We expect z to be a float, and it defaults to y.
    \n
    :raises ValueError: when x is None.
    :raises TypeError: when y is not a float.
    \n
    :returns: x + y - z
    """)
    print(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == """\
And now for something completely different:
"""

# Generated at 2022-06-23 17:17:22.083157
# Unit test for function parse

# Generated at 2022-06-23 17:17:26.310720
# Unit test for function parse
def test_parse():
    # Valid docstring
    valid_docstring = """Short description.

Long description.

:param int param1: First parameter
:param param2: Second parameter.
:type param2: str
:return: None.
:rtype: None
:Example:
    >>> print_docstring_example()
    None
:Example:
        >>> print_docstring_example()
        None
    :Example:
            >>> print_docstring_example()
            None
:raises ValueError: If `bar` is equal to `baz`.
:raises: If `bar` is equal to `baz`.
:yields int: Next number in the Fibonacci sequence.
"""

    docstring = parse(valid_docstring)

    # short description
    assert "Short description." == docstring.short_description

    # blank after

# Generated at 2022-06-23 17:17:32.668613
# Unit test for function parse
def test_parse():
    #  case 1
    #  test for parsing empty text
    result = parse("")
    assert result.short_description == None
    assert result.long_description == None
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == False
    assert len(result.meta) == 0

    # case 2
    # test for a one line docstring
    result = parse("one line")
    assert result.short_description == "one line"
    assert result.long_description == None
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == False
    assert len(result.meta) == 0

    # case 3
    # test for a multi line docstring

# Generated at 2022-06-23 17:17:42.166925
# Unit test for function parse
def test_parse():
    text = (
        """\
        Super versatile function.

        :param str name: Full name.
        :param int age: Age.
        :returns:  :py:class:`~.Person` instance.
        """
    )

    docstring = parse(text)
    short_description = docstring.short_description
    long_description = docstring.long_description
    assert short_description == "Super versatile function."
    assert long_description == (
        ":param str name: Full name.\n"
        ":param int age: Age.\n"
        ":returns:  :py:class:`~.Person` instance."
    )

# Generated at 2022-06-23 17:17:47.742012
# Unit test for function parse
def test_parse():
    a_str = '''
        Example function with types documented in the docstring.

        :param int a: The first parameter.
        :param str b: The second parameter.
        :raises ValueError: The error message if invalid parameter.
        :returns: Description of return value.
        :rtype: int

        '''
    docstring = parse(a_str)
    print(docstring)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:17:53.809279
# Unit test for function parse
def test_parse():
    docstring = parse(inspect.cleandoc(
        """
        Short description.

        Long description.

        :param a: first argument
        :param b: second argument
        """
    ))
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert len(docstring.meta) == 2

# Generated at 2022-06-23 17:18:05.703958
# Unit test for function parse
def test_parse(): # pragma: no cover
    doc = inspect.cleandoc(
        """
        This is the short description.

        This is the long description.
        It spans multiple lines.

        :param arg1: the first argument
        :param arg2: the second argument: it defaults to 'foo'
        :raises Exception: if an exception occurs
        :raises IOError: if an I/O error occurs
        :returns: None
        """
    )

    print(parse(doc))


# Generated at 2022-06-23 17:18:06.263253
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-23 17:18:17.177789
# Unit test for function parse
def test_parse():
    class C:
        """short desc\n\nlong desc\n\n:param int x1: description for x1\n:param str x2: description for x2\n"""

    d = parse(C.__doc__)
    assert d.short_description == "short desc"
    assert d.long_description == "long desc"
    assert d.blank_after_short_description == True
    assert d.blank_after_long_description == False

    assert len(d.meta) == 2
    for x in d.meta:
        assert x.keyword in ["param", "param"]
        assert x.arg_name in ["x1", "x2"]
        assert x.type_name in ["int", "str"]
        assert x.description in ["description for x1", "description for x2"]


# Generated at 2022-06-23 17:18:28.201275
# Unit test for function parse
def test_parse():
    from .common import Docstring, DocstringMeta, DocstringParam, DocstringReturns, DocstringRaises
    d = Docstring()
    d.short_description = "Module for testing"
    d.blank_after_short_description = False
    d.long_description = None
    d.blank_after_long_description = False
    # d.meta = [DocstringMeta(args=[], description=''), DocstringMeta(args=['param', 'str', 'a'], description='Description of parameter a.'), DocstringMeta(args=['param', 'str', 'b'], description='Description of parameter b. \nWith multiple lines.'), DocstringMeta(args=['param', 'str', 'c'], description='Description of parameter c. \nWith multiple lines.'), DocstringMeta(args=['returns'], description='Description of return value

# Generated at 2022-06-23 17:18:34.986744
# Unit test for function parse
def test_parse():
    from nose.tools import assert_equal
    import sys
    import os
    if __name__ == "__main__":
        path = os.path.dirname(sys.argv[0])
    else :
        path = os.path.dirname(__file__)

    with open(os.path.join(path, "test_parse.py"), "r") as f:
        text = f.read()
    res = parse(text)
    assert_equal(len(res.meta), 4)
    assert_equal(res.short_description, "Description of function.")
    assert_equal(len(res.long_description.splitlines()), 2)
    assert_equal(res.meta[0].args, ["param", "x"])

# Generated at 2022-06-23 17:18:45.964244
# Unit test for function parse
def test_parse():
    from .docstrings import Docstring

    # Test description parsing
    docstring = parse(
        """A short summary.

        Description can have multiple lines.
        """
    )
    assert docstring.short_description == "A short summary."
    assert docstring.long_description == "Description can have multiple lines."

    # Test meta information parsing
    docstring = parse(
        """A short summary.

        Description can have multiple lines.

        :param int a: The first parameter.
        :param str b: Another one.
        :returns: The output.
        """
    )

# Generated at 2022-06-23 17:18:57.390084
# Unit test for function parse

# Generated at 2022-06-23 17:19:05.524524
# Unit test for function parse
def test_parse():
    text = parse(inspect.getsource(parse))
    assert text.short_description == "Parse the ReST-style docstring into its components."
    assert text.long_description is not None
    assert text.long_description.startswith("""ReST-style docstring parsing.""")

    assert len(text.meta) == 1
    assert text.meta[0].args == ['return', 'Docstring']
    assert text.meta[0].description == "parsed docstring"


# Generated at 2022-06-23 17:19:15.247508
# Unit test for function parse
def test_parse():
    doc = """Summary line.

    Extended description.

    :param arg1: Description of arg1
    :type arg1: int
    :param arg2: Description of arg2
    :type arg2: str, optional
    :returns: Description of return value.
    :rtype: bool
    :raises keyError: raises an exception
    :raises ImportError: when arg2 is imported
    """
    print(parse(doc))

    print(parse(""))
    print(parse("one line\n"))
    print(parse("one line"))
    print(parse("one line\n\nwith a blank line\n"))
    print(parse("one line\n\nwith a blank line"))
    print(parse("\none line"))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:19:26.175203
# Unit test for function parse
def test_parse():
    text = """Function summary

        This is a docstring with meta information.

        :param arg1: description of arg1
        :type arg1: int
        :param arg2: description of arg2
        :type arg2: str
        :param arg3: description of arg3
        :type arg3: bool
        :param arg4: description of arg4 with a long description
            that spans multiple lines.
        :param arg5: description of arg5 with a long description
            that spans multiple lines.
        :param arg6: description of arg6.
        :returns: tuple
        :rtype: dict

        """

    docstring = parse(text)
    assert docstring.short_description == "Function summary"
    assert docstring.long_description == """This is a docstring with meta information."""

# Generated at 2022-06-23 17:19:37.013619
# Unit test for function parse
def test_parse():
    # No docstring
    assert parse("") == Docstring()

    # Short description only
    assert parse("no meta") == Docstring(short_description="no meta")

    # Short description with newlines in it
    assert parse("first line\n\nsecond line") == Docstring(
        short_description="first line",
        long_description="second line",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )

    # One-line meta
    assert parse("one-line meta\n:one: one\n:two: two") == Docstring(
        short_description="one-line meta",
        meta=[
            DocstringMeta(args=["one"], description="one"),
            DocstringMeta(args=["two"], description="two"),
        ],
    )

   

# Generated at 2022-06-23 17:19:47.521808
# Unit test for function parse
def test_parse():
    docstring = '''
    One-line description of the **function**.

    Extended description of the function.

    :param keyword_arg: Argument description, defaults to ``None``.
    :param positional_arg: Argument description, defaults to ``None``.
    :param another_arg: Argument description, defaults to ``None``.
    :raises NotImplementedError: When a situation is not implemented.
    :raises ValueError: When a value is invalid.
    :returns: Value that is returned by the function.
    :returns: Another value.
    '''

    d = parse(docstring)

    assert d.short_description == "One-line description of the function."
    assert (d.long_description ==
        "Extended description of the function.")
    assert d.blank_after_short_description
    assert d

# Generated at 2022-06-23 17:19:57.288099
# Unit test for function parse
def test_parse():
    """
    Test that docstrings are correctly parsed.
    """
    docstring = parse("""
        Single line docstring

        :param a: first param
        :type a: int
        :raises ValueError: if a is negative

        Multi
        line
        docstring
        """)


# Generated at 2022-06-23 17:20:08.731103
# Unit test for function parse
def test_parse():
    # test for a simple docstring
    text = """Returns the database connection object."""

    result = parse(text)
    assert result.short_description == "Returns the database connection object."
    assert result.long_description is None
    assert result.blank_after_short_description is False
    assert result.blank_after_long_description is False
    assert result.meta == []

    # test for a simple docstring with newlines
    text = """Returns the database connection object.
    
    """
    result = parse(text)
    assert result.short_description == "Returns the database connection object."
    assert result.long_description == ""
    assert result.blank_after_short_description is False
    assert result.blank_after_long_description is True
    assert result.meta == []

    # test for a docstring with a new

# Generated at 2022-06-23 17:20:12.535217
# Unit test for function parse

# Generated at 2022-06-23 17:20:20.680850
# Unit test for function parse
def test_parse():
    doc = """This function does something.

Args:
    arg1 (str): The first argument.
    arg2 (str, optional): The second argument. Defaults to 'b'.

Returns:
     str: The return value.

Raises:
    AttributeError: The ``Raises`` section is a list of all exceptions
        that are relevant to the interface.
    ValueError: If `param2` is equal to `param1`.
"""


# Generated at 2022-06-23 17:20:32.164366
# Unit test for function parse
def test_parse():
    r"""Test the function parse"""
    t1 = r'''
    Create table in sqlite3

    The table is composed of the following columns:
        - a: integer
        - b: text
        - c: real
        - d: blob

    :param db: path to the database
    :type db: str
    :param table: table name
    :type table: str
    :param columns: list of column names
    :type columns: list
    :returns: None
    :raises: TypeError
    '''

# Generated at 2022-06-23 17:20:41.632747
# Unit test for function parse

# Generated at 2022-06-23 17:20:53.575043
# Unit test for function parse
def test_parse():
    docstring_1 = parse("""
    This is a test.
    
    :returns: Return
    :raises AnError: raise an error.
    :param a: a
    :type a: str
    :param b: b
    :type b: int
    :param c: c
    :type c: float
    :param d: d
    :type d: bool
    :param e: e
    :type e: None
    
    
    """)

    assert docstring_1.short_description == "This is a test."
    assert docstring_1.long_description is None

    assert len(docstring_1.meta) == 6


# Generated at 2022-06-23 17:21:01.877049
# Unit test for function parse
def test_parse():
    """
    >>> ds = parse("""

# Generated at 2022-06-23 17:21:06.696987
# Unit test for function parse
def test_parse():
    text = inspect.cleandoc("""\
        Short description.

        Further description.

        :param str type_name: Description
        :param str name: Description
        :type name: str
        :param type_name: Description
        :type type_name: str
        :type: str
        :param name: Description
        :type name: str
    """)

    doc = parse(text)

# Generated at 2022-06-23 17:21:16.988866
# Unit test for function parse

# Generated at 2022-06-23 17:21:26.842784
# Unit test for function parse
def test_parse():
    HEADER = """
"""

    BLANK = r"""
    """

    SINGLE_LINE_DESCRIPTION = """
    The description.
    """

    LONG_DESCRIPTION = """
    The description.

    It continues here.
    """

    SHORT_DESCRIPTION_TRAILING_BLANK_LINES = """
    The description.

    """

    LONG_DESCRIPTION_TRAILING_BLANK_LINES = """
    The description.

    It continues here.

    """

    SINGLE_LINE_META = """
    :type arg: int
    """

    MULTI_LINE_META_WITH_DESCRIPTION = """
    :type arg: int
        The argument.
    """


# Generated at 2022-06-23 17:21:38.729747
# Unit test for function parse
def test_parse():
    _test_meta_line(":param int x: The value of x\n", "param", "int", "x")
    _test_meta_line(":param x: The value of x\n", "param", None, "x")
    _test_meta_line(":param int x: The value of x.\n", "param", "int", "x")
    _test_meta_line(
        ":param int x=3: The value of x.\n", "param", "int", "x", default="3"
    )
    _test_meta_line(":param int x=3: The value of x.\n", "param", "int", "x")

# Generated at 2022-06-23 17:21:45.978955
# Unit test for function parse
def test_parse():
    # An empty docstring
    assert parse("") == Docstring()

    # Simple documentation
    doc = parse("""
        Just a normal docstring.
    """)
    assert doc.short_description == "Just a normal docstring."
    assert doc.blank_after_short_description
    assert doc.long_description is None

    # Simple documentation with only a short description.
    doc = parse("Documented.")
    assert doc.short_description == "Documented."
    assert doc.blank_after_short_description
    assert doc.long_description is None

    # Simple documentation with only a short description, no new line.
    doc = parse("Documented")
    assert doc.short_description == "Documented"
    assert not doc.blank_after_short_description
    assert doc.long_description is None

    # Simple documentation with

# Generated at 2022-06-23 17:21:56.868057
# Unit test for function parse
def test_parse():
    docstring = '''
    This is the short description.

    This is the long description.

    :param int x: This is the argument description.
    :param int y: This is the argument description.
    :returns: This is the return description.
    :returns: This is the return description.
    :raises Exception: This is the exception description.
    '''
    parsed_docstring = parse(docstring)

    assert parsed_docstring.short_description == "This is the short description."
    assert parsed_docstring.long_description == "This is the long description."
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_docstring.blank_after_long_description == True
    assert len(parsed_docstring.meta) == 4

# Generated at 2022-06-23 17:22:07.187054
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Foo bar") == Docstring(
        short_description="Foo bar",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert parse("Foo bar\n\n\tMore description") == Docstring(
        short_description="Foo",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="More description",
    )
    assert parse("Foo bar\n\nMore description") == Docstring(
        short_description="Foo bar",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description="More description",
    )

# Generated at 2022-06-23 17:22:18.080910
# Unit test for function parse

# Generated at 2022-06-23 17:22:23.149349
# Unit test for function parse
def test_parse():
    docstring = """First line.
        Second line.
        Third line.
    :param a: First argument.
    :type a: int

    :param b: Second argument.
    :type b: int"""
    assert parse(docstring)


# Generated at 2022-06-23 17:22:34.844748
# Unit test for function parse

# Generated at 2022-06-23 17:22:41.642315
# Unit test for function parse
def test_parse():
    """ReST-style docstring parsing."""
    import pytest

    text = """\
        Short description.

        Long description.

        :param arg1: First argument.
        :type arg1: int
        :param arg2: Second argument.
        :type arg2: str, optional
        :param arg3: Third argument.
        :type arg3: bool, optional
        :param arg4: Fourth argument.
        :param arg5: Fifth argument, defaults to 5.
        :type arg5: int
        :param arg6: Sixth argument.
        :type arg6: int
        :returns: int
        :raises AttributeError: Optional description.
        """

# Generated at 2022-06-23 17:22:49.666922
# Unit test for function parse
def test_parse():

    @parse
    def parse_test(arg1, arg2=None, arg3=1):
        """My test function.

        Short description.

        Long description.

        :param arg1: The first parameter.
        :type arg1: str
        :param int arg2: The second parameter.
        :param int arg3: The third parameter.
        :return:
        :rtype: int
        :returns:
        :raises Exception: if something goes wrong.
        """

    doc = parse_test

    assert doc.short_description == "My test function."
    assert doc.blank_after_short_description is False
    assert doc.long_description == "Long description."
    assert doc.blank_after_long_description is True

    assert len(doc.meta) == 5
    assert doc.meta[0].args

# Generated at 2022-06-23 17:22:58.959854
# Unit test for function parse
def test_parse():
    example_docstring = """Example function with types documented in the docstring.

    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
        TypeError: 
            If `param2` is not a string.
        IndexError: When the index is out of bounds. This line is
        longer than the others to show that the previous line also works.
    """
    example_docstring_doc = parse(example_docstring)
    assert isinstance(example_docstring_doc, Docstring)

# Generated at 2022-06-23 17:23:09.035183
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description.

    :param arg1: first arg.
    :param arg2: second arg. defaults to 1.
    :param arg3: third arg. default is "hello".
    :returns: stuff.
    :raises: stuff.
    :raises type: stuff.
    """

    actual = parse(text)

# Generated at 2022-06-23 17:23:18.857412
# Unit test for function parse
def test_parse():
    '''
    This is the unit test for function parse.
    '''

# Generated at 2022-06-23 17:23:28.034123
# Unit test for function parse
def test_parse():
    print("Unit test for function parse")
    text = """\
    Multi-line description.

    :param name str: Name.
    :param age int: Age.
    """
    ret = parse(text)
    assert ret.short_description == "Multi-line description."
    assert ret.meta[0].args == ["param", "name", "str"]
    assert ret.meta[0].description == "Name."
    assert ret.meta[1].args == ["param", "age", "int"]
    assert ret.meta[1].description == "Age."



# Generated at 2022-06-23 17:23:35.036742
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Short description") == Docstring(
        short_description="Short description"
    )
    assert parse("Short description\nLong description") == Docstring(
        short_description="Short description",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description="Long description",
    )
    assert parse("Short description\n\nLong description") == Docstring(
        short_description="Short description",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="Long description",
    )

# Generated at 2022-06-23 17:23:46.258900
# Unit test for function parse
def test_parse():

    def foo(a, b, c=None, *, d=None):
        """Summary line.

        Extended description of function.

        :param a: Description of arg a
        :type a: str
        :param b: Description of arg b
        :type b: int
        :param c: Description of arg c (defaults to None)
        :param d: Description of arg d (defaults to None).
        :returns: Description of return value
        :rtype: bool
        :raises TypeError: If a or b are not strings

        """
        pass

    print(parse.__name__)
    print(parse.__qualname__)
    print(parse.__annotations__)
    print(parse.__doc__)
    print(parse.__class__)
    print(parse.__module__)
   

# Generated at 2022-06-23 17:23:53.562991
# Unit test for function parse
def test_parse():
    # Test the docstring of function parse
    docstring = inspect.getdoc(parse)
    doc = parse(docstring)

    assert doc.short_description == 'Parse the ReST-style docstring into its components.'
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False

# Generated at 2022-06-23 17:24:02.185543
# Unit test for function parse
def test_parse():
    assert Docstring.from_text(r'''
        A function with a docstring.
        :param foo: Foo.
        :type foo: str
        :raises ValueError: In case of conflict.
        ''') == Docstring.from_text(r'''
        A function with a docstring.
        :param foo: Foo.
        :type foo: str
        :raises ValueError: In case of conflict.
        ''')


# Generated at 2022-06-23 17:24:14.115426
# Unit test for function parse
def test_parse():
    # test for def
    def f():
        """Short description

        Long description
        
        :param x: blah blah
        :param y: blah blah
        :returns: blah blah
        """
        pass

    doc = parse(f.__doc__)
    assert doc.short_description == "Short description"
    assert doc.long_description == "Long description"
    assert doc.meta[0].arg_name == "x"
    assert doc.meta[1].arg_name == "y"
    assert doc.meta[2].is_generator is False

    # test for class
    class C:
        """Short description

        Long description
        
        :param x: blah blah
        :param y: blah blah
        :returns: blah blah
        """
        pass


# Generated at 2022-06-23 17:24:20.113433
# Unit test for function parse
def test_parse():
    def test(docstring : str, expected : Docstring) -> None:
        actual = parse(docstring)
        assert actual == expected

    test(
        """
        Short description.

        Long description.
        """,
        Docstring(
            short_description="Short description.",
            blank_after_short_description=False,
            long_description="Long description.",
            blank_after_long_description=True,
            meta=[],
        ),
    )


# Generated at 2022-06-23 17:24:24.465915
# Unit test for function parse
def test_parse():
    txt = """
    testy
    """

    parsed = parse(txt)
    assert parsed.short_description == "testy"
    assert parsed.long_description == ""
    assert parsed.meta == []
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == True

    txt = """
    testy
    longer testy
    """

    parsed = parse(txt)
    assert parsed.short_description == "testy"
    assert parsed.long_description == "longer testy"
    assert parsed.meta == []
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == True


# Generated at 2022-06-23 17:24:35.792537
# Unit test for function parse
def test_parse():
    # Test for format error
    def assert_parse_error(text: str, error_message: str):
        try:
            parse(text)
        except ParseError as e:
            assert error_message in str(e)
        else:
            raise AssertionError("Expected exception not raised.")

    assert_parse_error(
        text="arg1: x." "\narg1: y.",
        error_message="arg1 is already specified",
    )
    assert_parse_error(
        text="arg1: x." "\narg1: y.",
        error_message="arg1 is already specified",
    )
    assert_parse_error(
        text="arg1: x." "\narg2: arg1: y.",
        error_message="arg1 is already specified",
    )
    assert_parse_

# Generated at 2022-06-23 17:24:46.571391
# Unit test for function parse
def test_parse():
    input_str = """\
        This is short description.

        This is long description.

        :param str a: something.
        :param int b: something else.
        :returns: bla bla
        :returns: bla bla bla
        :raises: IOError
        """
    output = parse(input_str)
    assert output.short_description == "This is short description."
    assert output.long_description == "This is long description."
    assert output.blank_after_short_description
    assert output.blank_after_long_description
    assert output.meta[0].args == ["param", "str", "a"]
    assert output.meta[0].description.strip() == "something."
    assert output.meta[1].args == ["param", "int", "b"]

# Generated at 2022-06-23 17:24:57.109904
# Unit test for function parse
def test_parse():
    assert parse("My short description\n") == Docstring(
        short_description="My short description",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse("My short description\n\nMy long description") == Docstring(
        short_description="My short description",
        long_description="My long description",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-23 17:24:59.531223
# Unit test for function parse
def test_parse():
    docstring = parse("some text \nmy_function(x, y=3, bar=True):\n:param type_name arg_name: some text")
    print("Docstring = " + str(docstring))



# Generated at 2022-06-23 17:25:11.267499
# Unit test for function parse
def test_parse():
    print('Testing parse...', end='')
    source = '''
        The short description.

        The long description.

        :param a: The ``a`` argument.
        :param b b_type: The ``b`` argument.
        :param c c_type? defaults to 10.
            The long description for the ``c`` argument.
    '''

# Generated at 2022-06-23 17:25:20.323688
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Description") == Docstring(
        short_description="Description"
    )
    assert parse("Description\n") == Docstring(
        short_description="Description",
        blank_after_short_description=True,
    )
    assert parse("Description\n\n") == Docstring(
        short_description="Description",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )
    assert parse("Description\n\nLong\ndescription") == Docstring(
        short_description="Description",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="Long\ndescription",
    )

# Generated at 2022-06-23 17:25:31.743230
# Unit test for function parse

# Generated at 2022-06-23 17:25:43.349882
# Unit test for function parse
def test_parse():
    text = '''
	Docstring should be parsed properly here.

	:param argument_name: Should be parsed properly
	:param argument_name2: Can have multiple arguments
	:type argument_name: str
	:type argument_name2: int
	:returns: Should be parsed properly
	:rtype: str
	:raises Exception1: Should be parsed properly
	:raises Exception2: Can have multiple raises
	'''
    parsed_docstring = parse(text)
    # Test short description
    assert parsed_docstring.short_description == "Docstring should be parsed properly here."
    # Test blank_after_short_description and blank_after_long_description
    assert parsed_docstring.blank_after_short_description
    assert parsed_docstring.blank_after_long_description

# Generated at 2022-06-23 17:25:53.239740
# Unit test for function parse
def test_parse():
    text1 = '''
    Super class.

    :returns: nothing
    '''
    assert type(parse(text1).short_description) is str
    assert parse(text1).short_description == 'Super class.'
    assert type(parse(text1).meta[0]) is DocstringReturns
    assert parse(text1).meta[0].description == 'nothing'

    text2 = '''
    Super class.

    :param int a: some number
    :param str b: some string
    :returns: nothing
    '''
    assert parse(text2).short_description == 'Super class.'
    assert type(parse(text2).meta[0]) is DocstringParam
    assert parse(text2).meta[0].arg_name == 'a'

# Generated at 2022-06-23 17:26:04.032083
# Unit test for function parse
def test_parse():
    doc = """
    Short description.

    Long description.

    :param arg1: description for arg1.
    :type arg1: str
    :param arg2: description for arg2.
    :type arg2: str
    :returns: description of what is returned.
    :rtype: str
    """

# Generated at 2022-06-23 17:26:13.957778
# Unit test for function parse
def test_parse():
    doctest_parse = """
        This is a short description.

        This is a long description.

        :param a: this is parameter a.
        :type a: str
        :param b: This is optional parameter b, defaults to None.
        :type b: Optional[bool]
        :raises ValueError: if b is True
        :returns: a + b
        """
    text = doctest_parse

    ret = Docstring()
    if not text:
        return ret

    text = inspect.cleandoc(text)
    match = re.search("^:", text, flags=re.M)
    if match:
        desc_chunk = text[: match.start()]
        meta_chunk = text[match.start() :]
    else:
        desc_chunk = text
        meta_ch

# Generated at 2022-06-23 17:26:22.165879
# Unit test for function parse
def test_parse():
    docstring = """
    Some text describing this function.

    :param str a: Description of parameter 'a' which is a string.
    :param bool b: Description of parameter 'b' which is a boolean.
    :param str c: Description of parameter 'c' which is a string
    :param d: Description of parameter 'd' which has no type.
    :type d: str
    :param e: Description of parameter 'e' which has no type.
    :type e: str
    :returns: Description of what is returned.
    :rtype: string
    :returns: Description of what is returned.
    :rtype: str
    :returns: Description of what is returned.
    :rtype: str
    :returns: Description of what is returned.
    """

    ret = parse(docstring)
    assert len

# Generated at 2022-06-23 17:26:32.759472
# Unit test for function parse
def test_parse():
    cmdoc = _build_meta(
        args=['para', 'int', 'n'],
        desc='An integer number. defaults to 10.'
    )
    assert cmdoc.arg_name == 'n'
    assert cmdoc.description == 'An integer number. defaults to 10.'

    cmdoc = _build_meta(
        args=['para', 'int', 'n'],
        desc='An integer number. defaults to 10.\n\nVery large 10.'
    )
    assert cmdoc.arg_name == 'n'
    assert cmdoc.description == 'An integer number. defaults to 10.\n\nVery large 10.'
    assert cmdoc.get_one_line_desc() == 'An integer number. defaults to 10.'
