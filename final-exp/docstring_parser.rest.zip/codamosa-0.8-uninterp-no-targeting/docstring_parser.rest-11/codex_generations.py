

# Generated at 2022-06-21 11:55:26.565070
# Unit test for function parse
def test_parse():
    # Here is a function to test all examples
    def docstring_examples(examples: T.List[str], verbose=False):
        for example in examples:
            if verbose:
                print("--------------------------------------------")
                print("parse(" + example + ")")
            try:
                docstring = parse(example)
                if verbose:
                    print(docstring)
            except ParseError as e:
                if verbose:
                    print("ParseError:", e)
                assert False, e


# Generated at 2022-06-21 11:55:36.960075
# Unit test for function parse
def test_parse():
    docstring = inspect.getdoc(parse)
    parse_docstring = parse(docstring)

    assert parse_docstring.short_description == 'Parse the ReST-style docstring into its components.'
    assert parse_docstring.blank_after_short_description == True
    assert parse_docstring.blank_after_long_description == True
    assert parse_docstring.long_description == ':returns: parsed docstring'

    assert len(parse_docstring.meta) == 1
    assert parse_docstring.meta[0].args == ['returns']
    assert parse_docstring.meta[0].description == 'parsed docstring'



# Generated at 2022-06-21 11:55:41.883357
# Unit test for function parse
def test_parse():
    # Unit test for function parse
    docstring_text = '''Example docstring.
    :param x: description of x
    :param y: description of y
    :returns: description of return object
    '''
    docstring = parse(docstring_text)
    assert docstring.short_description == 'Example docstring.'
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args ==  ['param', 'x']
    assert docstring.meta[0].description == 'description of x'
    assert docstring.meta[1].args ==  ['param', 'y']
    assert docstring.meta[1].description == 'description of y'
    assert docstring.meta

# Generated at 2022-06-21 11:55:45.762662
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description

    :param x: foo bar
    :type x: int
    :param y: baz qux
    :type y: float
    :returns: None
    """
    assert parse(docstring)

# Generated at 2022-06-21 11:55:57.309677
# Unit test for function parse
def test_parse():
    text = """\
        Test parse docstring function.
        Description.

        :param arg1: Description 1.
        :type arg1: int
        :param arg2: Description 2.
        :type arg2: str
        :return: Description 3.
        :rtype: float
        :raises ValueError: Description 4.
        :raises TypeError: Description 5.

        """
    ret = parse(text)
    assert ret.short_description == "Test parse docstring function."
    assert (
        ret.long_description == "Description.\n\n"
    )
    assert ret.blank_after_short_description
    assert ret.blank_after_long_description
    assert len(ret.meta) == 5
    assert ret.meta[0].arg_name == "arg1"

# Generated at 2022-06-21 11:56:05.848980
# Unit test for function parse
def test_parse():
    docstring = """
:param int x: Description of parameter x
:param int y: Description of parameter y
:param int z: Description of parameter z
    """
    docstring_obj = parse(docstring)
    assert docstring_obj.short_description is None
    assert docstring_obj.long_description == None
    assert docstring_obj.blank_after_short_description == False
    assert docstring_obj.blank_after_long_description == False
    assert len(docstring_obj.meta) == 3

    # parameters
    assert docstring_obj.meta[0].args[0] == "param"
    assert docstring_obj.meta[0].args[1] == "int"
    assert docstring_obj.meta[0].args[2] == "x"

# Generated at 2022-06-21 11:56:11.587560
# Unit test for function parse
def test_parse():
    text ="""
    short description
    long description
    :param type_name arg_name: description
        a multiline description.
    :param type_name arg_name?: description
        a multiline description.
    :param type_name arg_name? defaults to value: description
        a multiline description.
    :returns: description
    :raises: description
    :yields type_name: description
    """
    docstring = parse(text)
    print(docstring)
    assert docstring.short_description == 'short description'
    assert docstring.long_description == 'long description'
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 4

# Generated at 2022-06-21 11:56:23.241356
# Unit test for function parse

# Generated at 2022-06-21 11:56:35.689343
# Unit test for function parse
def test_parse():
    docstring = """
        short description

        long description
        """

    docstring = parse(docstring)
    assert docstring.short_description == 'short description'
    assert docstring.long_description == 'long description'
    assert docstring.meta == []

    docstring = """
        short description

        long description

        :arg str arg1: description
            of parameter
        """
    docstring = parse(docstring)
    assert docstring.short_description == 'short description'
    assert docstring.long_description == 'long description'
    assert docstring.meta[0].args == ['arg', 'str', 'arg1']
    assert docstring.meta[0].description == 'description\nof parameter'


# Generated at 2022-06-21 11:56:41.290324
# Unit test for function parse
def test_parse():
    text = '''
    This is the short description.

    This is the long description.
    It spans multiple lines
    so it can have multiple paragraphs.

    You can put anything in a docstring that you can in rst.

    :type a: int
    :param a: adds the argument a to the function
    :type b: int
    :param b: adds the argument b to the function
    :returns: sum of a and b
    :rtype: int
    '''
    print (parse(text))

# Generated at 2022-06-21 11:56:54.369404
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Longer description.

    :param arg1: First argument
    :type arg1: str
    :param arg2: Second argument
    :type arg2: int=10
    :returns: Return value
    :rtype: int

    Optional continuation of the long description.
    """
    obj = parse(docstring)
    assert obj.short_description == "Short description."
    assert obj.long_description == "Longer description."
    assert obj.blank_after_short_description
    assert not obj.blank_after_long_description
    assert len(obj.meta) == 2
    assert isinstance(obj.meta[0], DocstringParam)
    assert obj.meta[0].arg_name == "arg1"

# Generated at 2022-06-21 11:57:05.365214
# Unit test for function parse
def test_parse():
    # meta description
    text = '''
        Short description.
        Long description.
        :keyword1: value
        :keyword2: value
    '''
    ret = parse(text)
    assert ret.short_description == 'Short description.'
    assert ret.blank_after_short_description == False
    assert ret.long_description == 'Long description.'
    assert ret.blank_after_long_description == False
    assert len(ret.meta) == 2
    assert ret.meta[0].args == ['keyword1']
    assert ret.meta[0].description == 'value'
    assert ret.meta[1].args == ['keyword2']
    assert ret.meta[1].description == 'value'

    # meta description with blank lines

# Generated at 2022-06-21 11:57:13.430759
# Unit test for function parse
def test_parse():
    text = """
        Short description.

        Long description.

        :param a: First argument
        :param b: Second argument
        :return: This returns something.

        :returns: This is another way to express a return.

        :raises: ValueError
        :raises: Exception: This is what it raises.
    """
    doc = parse(text)

    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is True

    assert doc.meta[0].args == ["param", "a"]
    assert doc.meta[0].description == "First argument"
    assert doc.meta[0].arg_name == "a"
    assert doc.meta[0].type

# Generated at 2022-06-21 11:57:25.282253
# Unit test for function parse
def test_parse():
    rest = """
    This is an example of a multiparagraph docstring. The first paragraph
    is a short description. The following paragraph is the long description.

    The first word of the first sentence in the short description should have
    a capital letter followed by a period.
    """

    docstring = parse(rest)

    assert docstring.short_description == (
        "This is an example of a multiparagraph docstring."
        " The first paragraph is a short description."
    )
    assert docstring.long_description == (
        "The following paragraph is the long description.\n\n"
        "The first word of the first sentence in the short description"
        " should have a capital letter followed by a period."
    )
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description




# Generated at 2022-06-21 11:57:30.775804
# Unit test for function parse
def test_parse():
    string = '''
    :param x: The x-value.
    :type x: float
    :param y: The y-value.
    :type y: float
    :param z: The z-value.
    :type z: float
    :param t: The t-value.
    :type t: float
    :param u: The u-value.
    :type u: float
    :returns: None
    :rtype: None
    '''
    print(parse(string))


# Generated at 2022-06-21 11:57:42.916994
# Unit test for function parse
def test_parse():
    docstr = """This is the summary line for a class.

    This is the class description.
    """
    assert parse(docstr) == Docstring(
        short_description="This is the summary line for a class.",
        long_description="This is the class description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    docstr = """This is the summary line for a class.

    This is the class description.

    :param foo: This is a keyword argument.
    :type foo: str
    """

# Generated at 2022-06-21 11:57:52.725093
# Unit test for function parse
def test_parse():
    test_doc = """Return a map ids to the objects with the given ids.

This method takes O(len(objects)) time.

:param list objects: The objects to get ids for.
:param list ids: The ids to look up
:returns: mapping from id to object for objects with that id.
:rtype: dict"""

    doc = parse(test_doc)
    assert doc.short_description == "Return a map ids to the objects with the given ids."
    assert doc.long_description == "This method takes O(len(objects)) time."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "objects"

# Generated at 2022-06-21 11:58:04.047395
# Unit test for function parse
def test_parse():
    """
    Testcase for testing parse() function
    """
    docstr = """This is a short description.

This is a long description.

:Optional argument:
    This is a optional argument
:Returns:
    This is the return value.
"""
    docstr = parse(docstr)
    assert docstr.short_description == "This is a short description"
    assert docstr.long_description == "This is a long description"
    assert docstr.blank_after_short_description == True
    assert docstr.meta[0].args == ["Optional", "argument"]
    assert docstr.meta[0].description == "This is a optional argument"
    assert docstr.meta[0].is_optional == True
    assert docstr.meta[1].args == ["Returns"]

# Generated at 2022-06-21 11:58:19.296013
# Unit test for function parse
def test_parse():
    doc = """\
    This is a short description.

    This is the extended description. It can be multiple paragraphs.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :returns: This is the return value.
    """

# Generated at 2022-06-21 11:58:23.700135
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param type_name arg_name: description
    :param type_name arg_name: description
    :param type_name arg_name: description
    :param type_name arg_name: description
    :param type_name arg_name?: description (defaults to None)
    """

    assert parse(docstring)


# Generated at 2022-06-21 11:58:38.060367
# Unit test for function parse
def test_parse():
    # line below are the source code example
    # """Test function
    # :param name: name of the person
    # """
    text = """Test function
:param name: name of the person"""
    docstring = parse(text)
    assert docstring.short_description == "Test function"
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'name']
    assert docstring.meta[0].description == 'name of the person'
    assert docstring.meta[0].arg_name == 'name'
    assert docstring.meta[0].type_name == None
    assert docstring.meta[0].is_optional == None
    assert docstring

# Generated at 2022-06-21 11:58:50.048000
# Unit test for function parse
def test_parse():
    text = """
    This is the short description.

    This is the long description. It may contain multiple lines.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == "This is the long description. It may contain multiple lines."
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is False

    # No short description
    text = """
    This is the long description. It may contain multiple lines.

    """
    docstring = parse(text)
    assert docstring.short_description == None
    assert docstring.long_description == "This is the long description. It may contain multiple lines."
    assert docstring.blank_after_short_description is False
    assert docstring

# Generated at 2022-06-21 11:58:59.091694
# Unit test for function parse
def test_parse():
    """
    >>> doc = parse("""

# Generated at 2022-06-21 11:59:08.662061
# Unit test for function parse
def test_parse():
    text = """\
    Parses the ReST-style docstring into its components.

    :param text: The docstring to parse.
    :param abc: (Optional) The something. Defaults to None.
    :type abc: str
    :returns: A docstring object
    :rtype: Docstring
    :raises ValueError: If unable to parse the docstring.
    """

    docstring = parse(text)
    assert docstring.short_description == "Parses the ReST-style docstring into its components."
    assert docstring.long_description == "The docstring to parse."
    assert docstring.blank_after_short_description and docstring.blank_after_long_description

    assert len(docstring.meta) == 3
    assert isinstance(docstring.meta[0], DocstringParam)

# Generated at 2022-06-21 11:59:18.037830
# Unit test for function parse
def test_parse():

    test_doc = '''
    This is the short description.

    This is the long description.

    This is a line in the long description.
    
    :param arg1: description for arg1
    :type arg1: str
    :param arg2: description for arg2
    :type arg2: str

    :returns: description for return
    :rtype: str
    :raises ValueError: description for exception ValueError
    '''


# Generated at 2022-06-21 11:59:24.984662
# Unit test for function parse
def test_parse():
    text = """\
    This is the short description.

    This is the long description. It has multiple paragraphs.

    :param type_name arg_name: One line description.
    :param str arg_name: Description with a newline.
    A newline is required before the description.
    :param type_name? arg_name: One line description with an optional arg
    :param type_name arg_name: This argument has a default. It defaults to 0.
    :raises type_name: One line description.
    :raises: One line description with no type.
    :raises type_name: Description with a newline.
    A newline is required before the description.
    :returns type_name: One line description.
    :yields type_name: One line description.
    """
    # pylint: disable=

# Generated at 2022-06-21 11:59:36.854525
# Unit test for function parse
def test_parse():
    assert parse("Short description.") == Docstring(
        short_description="Short description.", meta=[]
    )
    assert parse("Short description.\n\nLong description.") == Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="Long description.",
        meta=[],
    )
    assert parse("Short description.\n\nLong description.\n") == Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="Long description.",
        meta=[],
    )

# Generated at 2022-06-21 11:59:48.479192
# Unit test for function parse

# Generated at 2022-06-21 12:00:00.473762
# Unit test for function parse
def test_parse():
    """Test for parse function."""
    assert parse("") == Docstring()
    assert parse("Short description.") == Docstring(
        short_description="Short description.",
        meta=[],
    )
    assert parse(
        """\
        Short description.

        Long description."""
    ) == Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="Long description.",
        meta=[],
    )

# Generated at 2022-06-21 12:00:07.672690
# Unit test for function parse
def test_parse():
    docstring = """
        This is the short description.

        This is the long description. It may be multi-line.

        :param int x: x coordinate
        :param int y: y coordinate
        :returns: tuple of x and y
        :raises ValueError: when x exceeds 50

        """

    assert parse(docstring).short_description == "This is the short description."
    assert parse(docstring).long_description == "This is the long description. It may be multi-line."
    assert parse(docstring).returns.type_name == "tuple of x and y"
    assert len(parse(docstring).parameters) == 2
    assert parse(docstring).raises.type_name == "ValueError"

# Generated at 2022-06-21 12:00:18.121219
# Unit test for function parse
def test_parse():
    s = inspect.cleandoc("""
    Description.
    
    :param str arg1: Description of arg1.
    :param arg2: Description of arg2.
    :param int? arg3: Description of arg3.
    :param arg4: Description of arg4.
    :param str? arg5: Description of arg5.
    :param arg6: Description of arg6.
    :param arg7: Description of arg7.
    :returns:
    """)
    print(s)
    doc = parse(s)
    print(doc)
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type_name == "str"
    assert doc.meta[1].arg_name == "arg2"
    assert doc.meta[1].type_name is None

# Generated at 2022-06-21 12:00:26.508411
# Unit test for function parse
def test_parse():
    fn = inspect.currentframe().f_code.co_name
    docstring = inspect.getdoc(eval(fn))
    print(docstring)
    parsed = parse(docstring)

    print("short description:", parsed.short_description)
    print("long description: ", parsed.long_description)
    print("blank after short description:", parsed.blank_after_short_description)
    print("blank after long description:", parsed.blank_after_long_description)

    for meta in parsed.meta:
        print("meta:", meta.__dict__)

test_parse()

# Generated at 2022-06-21 12:00:28.558732
# Unit test for function parse
def test_parse():
    from .test_common import some_test_docstring  # type: ignore
    assert parse(some_test_docstring)  # Type: ignore

# Generated at 2022-06-21 12:00:40.175922
# Unit test for function parse

# Generated at 2022-06-21 12:00:48.924724
# Unit test for function parse
def test_parse():
    docstring_text = """
    : {} {} : {}
    : {} {} :{}
    : {}:
    : {}:{}
    """
    docstring_text1 = """
    something
    : {} {} : {}
    : {} {} :{}
    : {}:
    : {}:{}
    """
    docstring_text0 = """
    something
    : {} {} : {}
    : {} {} :{}
    : {}:
    : {}:{}
    """
    if __name__ == "__main__":
        print(docstring_text)
        print(parse(docstring_text))

# Generated at 2022-06-21 12:00:58.764174
# Unit test for function parse
def test_parse():
    text ='''\
    This is a function that does something
    complex
    with many
    things.

    :param arg1: The first thing
    :param arg2: The second thing
    :param arg3: The third thing
    :returns: the answer
    :raises Exception: When something goes wrong
    '''
    assert parse(text)

    text ='''\
    This is a function that does something
    complex
    with many
    things.

    :param arg1: The first thing
    :param arg2: The second thing
    :param arg3: The third thing
    :returns: the answer
    :raises Exception: When something goes wrong
    '''
    assert parse(text).short_description == 'This is a function that does something complex with many things.'
    assert parse(text).long_

# Generated at 2022-06-21 12:01:07.381315
# Unit test for function parse
def test_parse():
    doc_str = '''
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    '''
    meta = DocstringMeta(
        args=["returns"], description="parsed docstring"
    )
    ret = Docstring(
        short_description="Parse the ReST-style docstring into its components.",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[meta],
    )

    assert parse(doc_str) == ret



# Generated at 2022-06-21 12:01:17.922038
# Unit test for function parse
def test_parse():

    short = "this is name"
    long = "this is long description.\nwhat do you expect?"
    test_doc = [
        ":param int a: this is description."
        , ":return: this is description"
        , ":rtype: int"
        , ":raises Test: this is description."
    ]
    test_str = "\n".join([short, long] + test_doc)

    doc = parse(test_str)
    assert doc.short_description == short
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == True
    assert doc.long_description == long
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "int", "a"]

# Generated at 2022-06-21 12:01:25.083520
# Unit test for function parse
def test_parse():
    """This is a test for the function parse(string), which will parse a ReST-style docstring into its components.

    parse(str) ->
    
    :returns: a parsed docstring
    """

    f = open('/Users/Natsume/Documents/Python/testparse.py', 'r')
    text = f.read()
    docstring = parse(text)

    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.meta[0].description)
    print(docstring.meta[1].description)
    print(docstring.meta[2].description)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:01:30.589538
# Unit test for function parse
def test_parse():
    def f():
        """Docstring with no description.

        :param a: This is an a.
        :param b: This is a b.
        """
        pass

    doc = parse(f.__doc__)
    assert not doc.short_description
    assert not doc.long_description
    assert not doc.blank_after_short_description
    assert not doc.blank_after_long_description
    assert len(doc.meta) == 2



# Generated at 2022-06-21 12:01:43.826007
# Unit test for function parse
def test_parse():
    expected = Docstring(
        short_description="Test parse",
        long_description="Long description",
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[
            DocstringMeta(
                args=["Arg1", "Arg2", "Arg3"], description="this is arg1"
            ),
            DocstringMeta(args=["Arg4"], description="this is arg4"),
            DocstringReturns(
                args=["returns"], description="returned value"
            ),
            DocstringRaises(
                args=["raises", "Exception"],
                description="when something goes wrong",
            ),
        ],
    )


# Generated at 2022-06-21 12:01:54.353309
# Unit test for function parse
def test_parse():
    ds = parse(
        """
    This is a test function.

    :param x: the first parameter
    :type x: int

    :param y: the second parameter
    :type y: float
    :default y: 1.0

    :returns: :class:`int`
    :raises: :class:`IndexError`
    """
    )
    assert ds.short_description == "This is a test function."
    assert ds.long_description == "the first parameter\nthe second parameter"
    assert ds.blank_after_short_description is True
    assert ds.blank_after_long_description is False

    assert len(ds.meta) == 2

    param = ds.meta[0]
    assert param.arg_name == "y"

# Generated at 2022-06-21 12:01:56.735046
# Unit test for function parse
def test_parse():
    f = open("test1","r")
    str = f.read()
    print(parse(str))
    f.close()


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:02:03.763929
# Unit test for function parse
def test_parse():
    docstr = parse('This is a test docstring\n\nTest more.\n\n:param str name: The name that will be printed.\n:param int n: The number of times the name will be printed. Default: 2.\n:returns: The name n times.\n:rtype: str\n\n:raises ValueError: If n is not a positive integer.\n')
    print(docstr)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:02:14.197106
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("   \n   ") == Docstring()
    assert parse("    ") == Docstring()
    assert parse("    \n    ") == Docstring()
    assert parse("\n\n") == Docstring()

    assert parse("a short desc") == Docstring(
        short_description="a short desc",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=None,
    )
    assert parse("a short desc\n") == Docstring(
        short_description="a short desc",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=None,
    )
    assert parse

# Generated at 2022-06-21 12:02:23.240693
# Unit test for function parse
def test_parse():
    # Empty docstring
    parse("")

    # Basic short description
    parse("docs")

    # Basic short description with a trailing period
    parse("docs.")

    # Basic short description with a trailing period
    parse("docs.")

    # Basic short description with a trailing period and blank lines
    parse("docs.\n\n")

    # Basic short description with a trailing period and extra whitespace
    parse("docs.  ")

    # Basic short description with a trailing period and no extra whitespace
    parse("docs.  \n")

    # Basic short description with a trailing period and extra whitespace
    parse("docs.  \n\n")

    # Basic short description with indent
    parse("    docs.")

    # Basic long description
    parse("docs\n\nMore docs.")

    # Basic long description

# Generated at 2022-06-21 12:02:26.879508
# Unit test for function parse
def test_parse():
    import doctest
    # doctest.testmod(verbose=True)
    return doctest.testmod()

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:02:36.769247
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Short desc.") == Docstring(short_description="Short desc.")
    assert (
        parse("Short desc.\n\nLong desc.")
        == Docstring(short_description="Short desc.", long_description="Long desc.")
    )
    assert (
        parse("""Short desc.
            \n\nLong desc.""")
        == Docstring(
            short_description="Short desc.",
            long_description="Long desc.",
        )
    )
    assert (
        parse("Short desc.\n\nLong desc.\n")
        == Docstring(
            short_description="Short desc.",
            long_description="Long desc.",
            blank_after_long_description=True,
        )
    )


# Generated at 2022-06-21 12:02:47.212862
# Unit test for function parse
def test_parse():
    """
    This function tests whether the parsing of the docstring works.
    """
    # Example docstring to parse
    docstring = """\
    This is a function that tests parsing of docstrings.

    Args:
        arg1 (int): Description of first argument.
        arg2 (str): Description of second argument.

    Returns:
        bool: Description of return value, including
              optional continuation lines.

    Raises:
        AttributeError: Description of exception.

    """
    # Raises an error if the parsing of the docstring fails
    try:
        _ = parse(docstring)
    except ParseError:
        raise
    else:
        return

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:02:58.413577
# Unit test for function parse
def test_parse():
    docstring = '''
    Example of a docstring with metadata.

    :param arg1: this is arg1
    :param arg2: this is arg2
    :type arg1: int
    :type arg2: (int, float)
    :returns: this is a return
    :rtype: int
    '''
    parsed = parse(docstring)
    assert parsed.short_description == "Example of a docstring with metadata."
    assert parsed.long_description == None
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 5
    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].arg_name == "arg1"

# Generated at 2022-06-21 12:03:15.464014
# Unit test for function parse
def test_parse():
    doc_str = """Short description.

    Long description.

    :param arg1:
        description of arg1
    :type arg1: str
        description of type arg1

        more description of type arg1
    :param arg2: description of arg2
    :type arg2: str
    :returns:
         returns something
    """
    ret = parse(doc_str)
    assert ret.short_description == "Short description."
    assert ret.long_description == "Long description."
    assert ret.blank_after_short_description
    assert ret.blank_after_long_description
    assert len(ret.meta) == 3


# Generated at 2022-06-21 12:03:24.585937
# Unit test for function parse
def test_parse():
    assert parse("Hello world") == Docstring(
        short_description="Hello world",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("Hello world\n\nThis is the long description.") == Docstring(
        short_description="Hello world",
        long_description="This is the long description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[],
    )


# Generated at 2022-06-21 12:03:36.344092
# Unit test for function parse

# Generated at 2022-06-21 12:03:48.387020
# Unit test for function parse
def test_parse():
    doc = """
    A short description.
    And a long description.

    :param foo: The foo parameter.
    :type foo: str
    :returns: The return value.
    :rtype: int
    """

    parsed = parse(doc)

    assert parsed.short_description == "A short description."
    assert parsed.long_description == "And a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description

    meta = parsed.meta
    assert len(meta) == 2
    assert meta[0].args == ["param", "foo"]
    assert meta[0].description == "The foo parameter."
    assert meta[0].arg_name == "foo"
    assert meta[0].type_name == "str"

# Generated at 2022-06-21 12:03:59.279209
# Unit test for function parse
def test_parse():
    assert parse("hello") == parse("hello\n") == parse("hello\n\n")
    assert parse("hello\nworld") == parse("hello\nworld\n") == parse("hello\nworld\n\n")
    assert parse("hello\n\nworld") == parse("hello\n\nworld\n") == parse("hello\n\nworld\n\n")
    assert parse("hello\n\nworld\n\n") == parse("\thello\n\n\tworld\n\n")


# Generated at 2022-06-21 12:04:10.343375
# Unit test for function parse

# Generated at 2022-06-21 12:04:22.185531
# Unit test for function parse

# Generated at 2022-06-21 12:04:27.922300
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.
    """
    
    docstring = parse(docstring)
    
    assert docstring.short_description == 'This is a short description.'
    assert docstring.long_description == 'This is a long description.'
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 0
    
    
    
    

# Generated at 2022-06-21 12:04:35.203522
# Unit test for function parse
def test_parse():
    text='''
    This is a function.
    Basic function.
    :param name: Name of the person
    :returns: Hello message
    '''
    print(parse(text))
    print('=====================')
    print(parse(text).meta[0])
    print('=====================')
    print(parse(text).meta[0].arg_name)
    print('=====================')
    print(parse(text).meta[0].type_name)
    

# Generated at 2022-06-21 12:04:42.581617
# Unit test for function parse
def test_parse():
    the_text = '''This is my sentence
    This is a new one
    
    This is a new line
    :param string: This is a string
    :type string: str
    :param int: This is an optional int
    :type int: int
    :param float: This is an optional float
    :type float: float
    :param bool: This is an optional bool
    :type bool: bool
    :param list: This is an optional list
    :type list: list
    :returns: This is a returns
    :rtype: float
    :raises ValueError: This is a raises
    '''
    the_result = parse(the_text)

    assert the_result.short_description == "This is my sentence"
    assert the_result.blank_after_short_description == True
    assert the_

# Generated at 2022-06-21 12:05:01.928341
# Unit test for function parse
def test_parse():
    docstring = '''
    Purpose of this function is to return the list of strings in string.
    :param str s:   The string to be splitted.
    :return:  the list of splitted strings.
    '''
    res = parse(docstring)
    assert res.short_description == 'Purpose of this function is to return the list of strings in string.' 
    assert res.long_description == None

    docstring = '''
    Purpose of this function is to return the list of strings in string.

    :param str s:   The string to be splitted.
    :return:  the list of splitted strings.
    '''
    res = parse(docstring)
    assert res.short_description == 'Purpose of this function is to return the list of strings in string.' 
    assert res.long_description == None