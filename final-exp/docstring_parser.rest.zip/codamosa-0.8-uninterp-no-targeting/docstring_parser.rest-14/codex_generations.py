

# Generated at 2022-06-21 11:55:24.425026
# Unit test for function parse
def test_parse():
    text = """\
        Converts a Python object containing all the Python
        stack frames to a list of strings.  Each string in the resulting list
        corresponds to the frame info corresponding to the
        function call.  The message indicating whether or not
        the exception was caught is not included.

        :param frames: a list of tuples as returned by ``inspect.stack()``

        :returns: list of strings
        """
    print(text)
    print(parse(text))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:55:30.247107
# Unit test for function parse
def test_parse():
    # Test parse with empty string
    assert parse("") == Docstring()

    # Test parse with empty meta data
    assert parse("""Some description.

    This is a longer description.""") == Docstring("Some description.", "This is a longer description.")

    # Test parse with meta data
    assert parse("""Some description.

    This is a longer description.

    :param arg1: Argument 1
    :param arg2: Argument 2
    :type arg1: str
    :returns: Some return value.""") == Docstring("Some description.", "This is a longer description.", meta=[DocstringParam("param", "arg1", "Argument 1", "str", True), DocstringParam("param", "arg2", "Argument 2"), DocstringReturns("returns", "Some return value")])

    # Test parse with bad meta data

# Generated at 2022-06-21 11:55:40.957419
# Unit test for function parse

# Generated at 2022-06-21 11:55:49.652353
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test function.

    It takes no arguments.

    :rtype First: str
    :rtype Second: int
    :rtype Third: str

    :param Third: Third argument
    :returns: It returns nothing
    """

    doc = parse(docstring)

# Generated at 2022-06-21 11:56:00.947583
# Unit test for function parse
def test_parse():
    """Test that ReST style docstrings can be parsed."""
    docstring = parse(
        """
        Short description.

        Long description.

        :param str arg1: Argument 1.
        :param arg2: Argument 2 (default: 1).
        :returns: The return value.
        :rtype: int
        """
    )
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."

    assert docstring.meta[0].key == "param"
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].type_name == "str"
    assert docstring.meta[0].description == "Argument 1."
    assert docstring.meta[0].is_optional is False
    assert docstring.meta

# Generated at 2022-06-21 11:56:12.966853
# Unit test for function parse
def test_parse():
    from .common import Docstring

    assert parse("") == Docstring()
    assert parse("a") == Docstring(
        short_description="a",
        long_description="",
        meta=[],
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert parse("a\n") == Docstring(
        short_description="a",
        long_description="",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert parse("a\n\n") == Docstring(
        short_description="a",
        long_description="",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )
    assert parse("a\nb") == Docstring

# Generated at 2022-06-21 11:56:19.729635
# Unit test for function parse
def test_parse():
    code = """
    func(a, b):
        Short desc
        Long desc

        :param a: int
        :param b: int
        :returns: nothing
        :raises Exception:
    """
    docstring = parse(code)
    assert docstring.short_description == "func(a, b)"
    assert len(docstring.long_description) >= 2
    assert len(docstring.meta) == 3

# Generated at 2022-06-21 11:56:29.147904
# Unit test for function parse
def test_parse():
    print("Test for parse")
    def foo(x, y, z=3, *, a=1, b=2, **kwargs):
        """The main docstring."""
        orig_x = x
        orig_y = y
        orig_z = z
        orig_kwargs = kwargs
        orig_a = a
        orig_b = b

        x = x + y
        if x > 10:
            y = y + 1
        if x > 15:
            y = y + 1
        else:
            y = y - 2


# Generated at 2022-06-21 11:56:39.752302
# Unit test for function parse
def test_parse():
   text = '''
   Generate/calculate all permutations of a given list.

   :params data: the list for permutations.
   :param key: the key for sorting permutations.
   :param k: the length of returned permutations.
   :param type_: the type of returned permutations.
   :type_: list, tuple
   :returns: list of permutations
   :raises ValueError: if the value is too big
   :raises TypeError: if a type error occurred.
   '''
   result = parse(text)
   assert result.short_description == 'Generate/calculate all permutations of a given list.'

# Generated at 2022-06-21 11:56:50.577249
# Unit test for function parse
def test_parse():
    text = """Summary line.

    Extended description.

    :param int param1: Parameter description for param1.
    :param str param2: Parameter description for param2.
    :return: Return description.
    """

    parsed = parse(text)
    assert parsed.short_description == "Summary line."
    assert parsed.long_description == "Extended description."
    assert len(parsed.meta) == 3
    assert isinstance(parsed.meta[0], DocstringParam)
    assert parsed.meta[0].arg_name == "param1"
    assert parsed.meta[1].arg_name == "param2"
    assert isinstance(parsed.meta[2], DocstringReturns)
    assert parsed.meta[2].description == "Return description."


# Generated at 2022-06-21 11:57:11.004118
# Unit test for function parse
def test_parse():
    """Test for the parse function"""
    text = """\
        This is a one line description.

        This is a longer description.
        It can span multiple lines.

        :param a: parameter a
        :param b: parameter b
        :type a: int
        :type b: int
        :returns: None
        :raises ValueError: error
        """
    docstring = parse(text)
    assert docstring.short_description == "This is a one line description."
    assert docstring.blank_after_short_description is True
    assert docstring.long_description == """\
This is a longer description.
It can span multiple lines.
"""
    assert docstring.blank_after_long_description is True
    assert docstring.meta[0].arg_name == "a"

# Generated at 2022-06-21 11:57:23.565917
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Foo bar.") == Docstring(
        short_description="Foo bar.",
    )
    assert parse("Foo bar.\n") == Docstring(
        short_description="Foo bar.",
        blank_after_short_description=True,
    )

    assert (
        parse("Foo bar.\n\nHello world.")
        == Docstring(
            short_description="Foo bar.",
            blank_after_short_description=True,
            long_description="Hello world.",
            blank_after_long_description=False,
        )
    )


# Generated at 2022-06-21 11:57:29.448670
# Unit test for function parse
def test_parse():
    text = '''
        Short description.

        Long description.

        :param x: blah blah
        :param y: blah
        :return:
        :rtype:
        :raises:
    '''
    d = parse(text)
    assert d.short_description == 'Short description.'
    assert d.long_description == 'Long description.'
    assert len(d.meta) == 4
    assert d.meta[0].arg_name == 'x'
    assert d.meta[1].arg_name == 'y'
    assert d.meta[2].ret_type is None
    assert d.meta[3].type_name is None

# Generated at 2022-06-21 11:57:41.401137
# Unit test for function parse
def test_parse():
    docstring_text = '''
    :param x: this is a param.
    :type x: int
    :param y: this is a param with a default.
    :type y: int
    :param z?: this is a param with an optional type.
    :type z?: int?
    :param u? this is an optional param with an optional type.
    :type u?: int?
    :returns: this is a return value
    :rtype: int
    :raises Exception: This function sometimes fails
    :yields: this is a yield value
    :ytype: int
    '''

    docstring = parse(docstring_text)

    assert docstring.short_description == ""
    assert docstring.blank_after_short_description == True
    assert docstring.long_description == None
    assert doc

# Generated at 2022-06-21 11:57:46.213028
# Unit test for function parse
def test_parse():
    """Test function parse

    Test function parse(text) to make sure that it takes the function parse
    and it's full of docstring and split it into a title, optional parameter,
    details and so on.
    """
    parse(test_parse.__doc__)
    parse(parse.__doc__)


# Generated at 2022-06-21 11:57:53.928353
# Unit test for function parse
def test_parse():
    doc = """First line of description.

Any other description here could be multiple lines in length.

:param name: the name to call yourself by
:type name: str
:param int id: your id
:param int age: your age
:param address: your address
:type address: str
:return: None
"""
    docstring = parse(doc)
    assert docstring.short_description == "First line of description."
    assert docstring.long_description == "Any other description here could be multiple lines in length."
    assert docstring.meta[0].args == ["param", "name", "the", "name", "to", "call", "yourself", "by"]
    assert docstring.meta[0].arg_name == "name"
    assert docstring.meta[0].type_name == "str"
    assert docstring

# Generated at 2022-06-21 11:58:05.433972
# Unit test for function parse
def test_parse():
    from .common import (
        Docstring,
        DocstringMeta,
        DocstringParam,
        DocstringRaises,
        DocstringReturns,
        ParseError,
    )

    assert parse("nothing") == Docstring()
    assert parse("\nnothing\n") == Docstring()

    t = Docstring()
    t.short_description = "short\nline 2"
    t.blank_after_short_description = True
    t.long_description = "long \nline 2\n"
    t.blank_after_long_description = True
    assert parse("short\nline 2\n\nlong \nline 2\n\n") == t

    t = Docstring()
    t.short_description = "short"
    t.blank_after_short_description = True
    t.long_

# Generated at 2022-06-21 11:58:14.288636
# Unit test for function parse
def test_parse():
    code = """
    :param str a: The first argument.
    :param str b: The second argument.
    :returns: The return value.
    """
    d = parse(code)

    assert d.short_description == ""
    assert d.blank_after_short_description == False
    assert d.long_description == ""
    assert d.blank_after_long_description == True
    assert len(d.meta) == 3

    for m in d.meta:
        assert isinstance(m, DocstringMeta)

    first, second, third = d.meta
    assert isinstance(first, DocstringParam)
    assert first.arg_name == "a"
    assert first.type_name == "str"
    assert first.is_optional == False
    assert first.default == None

# Generated at 2022-06-21 11:58:23.550300
# Unit test for function parse
def test_parse():
    def test_func() -> None:
        """This is a test function.

        Does not do anything.

        :param arg1: First arg
        :param arg2: Second arg
        :type arg2: str
        :param arg3: Third arg
        :type arg3: str?
        :param arg4: Fourth arg, defaults to True.
        :param arg5: Fifth arg, defaults to False.
        :returns: None
        :rtype: NoneType
        :raises ValueError: if something goes wrong
        """


    d = parse(test_func.__doc__)
    assert d.short_description == "This is a test function."
    assert d.long_description == "Does not do anything."
    assert d.blank_after_short_description
    assert d.blank_after_long_description
   

# Generated at 2022-06-21 11:58:35.009604
# Unit test for function parse
def test_parse():
    '''
    Unit test for parse() function
    '''

    DOCSTRING = """First sentence.

Second sentence.
"""

    assert parse(DOCSTRING) == Docstring(
        short_description='First sentence.',
        blank_after_short_description=True,
        long_description='Second sentence.',
        blank_after_long_description=False,
        meta=[],
    )
    assert parse('First sentence.\n  Second sentence.\n') == Docstring(
        short_description='First sentence.',
        blank_after_short_description=False,
        long_description='Second sentence.',
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-21 11:58:52.791328
# Unit test for function parse
def test_parse():
    from . import parse
    docstring = """\
    Compute the greatest common divisor of two integers

    This implementation uses Euclid's algorithm.

    :param int a: The first integer
    :param int b: The second integer

    .. math::

       \\operatorname{gcd}(a, b) = \\left\\{
       \\begin{array}{ll}
       a, & \\text{if } a \\ge b, \\\\
       \\operatorname{gcd}(a, b), & \\text{otherwise.}
       \\end{array}\\right.

    :returns: A tuple consisting of the GCD and a tuple of quotients
    :rtype: tuple

    >>> test_parse()
    (1, (1, -2))
    """
    parsed = parse(docstring)
   

# Generated at 2022-06-21 11:59:00.480356
# Unit test for function parse
def test_parse():
    doc = parse(inspect.cleandoc(
        """
        Tests bla bla.

        :param p: Parameter bla bla
        :param type p: int
        :param q: Parameter bla bla. Defaults to 10
        :return r: Return type bla bla
        :return type r: string
        :raises E: Exception bla bla
        :raises type E: Exception
        :yields: Generator bla bla
        :yields type: int
        """
    ))

    assert doc.meta[0].arg_name == "p"
    assert doc.meta[0].type_name == "int"
    assert doc.meta[1].arg_name == "q"
    assert doc.meta[1].type_name is None

# Generated at 2022-06-21 11:59:09.101709
# Unit test for function parse
def test_parse():
    text = ''' test_parse
    short description

    :param name: name of the person
    :type  name: str
    :param age: age of the person
    :type  age: int
    :returns: person
    :rtype: Person
    :raises ZeroDivisionError: age is 0 or smaller
    '''

    docstring = parse(text)

    assert len(docstring.meta) == 3

    meta = docstring.meta[0]
    assert meta.arg_name == "name"
    assert meta.type_name == "str"
    assert meta.is_optional is None
    assert meta.default is None

    meta = docstring.meta[1]
    assert meta.arg_name == "age"
    assert meta.type_name == "int"

# Generated at 2022-06-21 11:59:17.385423
# Unit test for function parse
def test_parse():
    doc = """\
    Very much hello. So, this is just a test.
    
    Returns:
        this is an int
    
    Yields:
        and something else
    """
    parsed = parse(doc)
    assert parsed.short_description == "Very much hello."
    assert parsed.long_description == "So, this is just a test."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 2
    assert parsed.meta[0].args == ["Returns:", "this is an int"]
    assert parsed.meta[1].args == ["Yields:", "and something else"]


# Generated at 2022-06-21 11:59:24.640836
# Unit test for function parse
def test_parse():
    # Test empty string
    assert parse("") == Docstring()

    # Test short description only
    assert parse("this is a short description") == Docstring(
        short_description="this is a short description",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False
    )

    # Test short description and long description
    assert parse("this is a short description\n\nThis is a long description.") == Docstring(
        short_description="this is a short description",
        blank_after_short_description=False,
        long_description="This is a long description.",
        blank_after_long_description=True
    )

    # Test short description and long description with some indentation

# Generated at 2022-06-21 11:59:27.985517
# Unit test for function parse
def test_parse():
    docstring = parse.__doc__

    assert parse(docstring)

    docstring = parse.__annotations__["return"]
    assert str(parse(docstring).long_description) == "parsed docstring"

# Generated at 2022-06-21 11:59:39.335458
# Unit test for function parse
def test_parse():
    doc = parse("""
    A single-line docstring.
    """)
    assert doc.short_description == "A single-line docstring."
    assert doc.long_description is None
    assert doc.blank_after_short_description is True
    assert doc.blank_after_long_description is True
    assert len(doc.meta) == 0

    doc = parse("""
    A single-line docstring.
    With two lines.
    """)
    assert doc.short_description == "A single-line docstring."
    assert doc.long_description == "With two lines."
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is True
    assert len(doc.meta) == 0


# Generated at 2022-06-21 11:59:50.229833
# Unit test for function parse

# Generated at 2022-06-21 12:00:02.209093
# Unit test for function parse
def test_parse():
    text = """
        One-line description.

        Long description explaining what this does in more detail with more
        examples, etc.

        :param str text: Text to use.
        :param int length: How long each line should be.
        :returns: Nothing.
    """

# Generated at 2022-06-21 12:00:13.533238
# Unit test for function parse
def test_parse():
    """Unit testing for function parse."""
    doc = parse("""This is the short description.

    This is the long description.

    :param x: first argument
    :param y: second argument

    :returns: something here.

    :returns: another something here.

    :returns: something else here.
    """)

    assert doc.short_description == "This is the short description."
    assert doc.long_description == "This is the long description."
    assert doc.blank_after_short_description is True
    assert doc.blank_after_long_description is False
    assert len(doc.meta) == 4

    assert doc.meta[0].args == ["param", "x"]
    assert doc.meta[0].arg_name == "x"
    assert doc.meta[0].type_name is None
   

# Generated at 2022-06-21 12:00:29.790490
# Unit test for function parse
def test_parse():
    doc = """One line summary.

    Further description.

    :param arg1: the first argument.
    :type arg1: str
    :param arg2: the second argument.
    :type arg2: str
    :returns: description of return value
    :rtype: int
    :raises keyError: raises an exception
    :raises TypeError: does not raise an exception
    :raise keyError: raises an exception
    :raise TypeError: does not raise an exception

    """

    dd = parse(doc)
    assert dd.short_description == "One line summary."
    assert dd.long_description == "Further description."
    assert dd.blank_after_long_description == True
    assert len(dd.meta) == 8

    assert dd.meta[0].args == ['param', 'arg1']
    assert dd

# Generated at 2022-06-21 12:00:41.212703
# Unit test for function parse
def test_parse():
    text = '''
    short description

    :param arg1:              description of arg1 (with whitespace after colon)
    :param arg2: description of arg2 (with no whitespace after colon)

    :return: description of return value(s)

    :type arg3: int
    :type arg3: str
    :type arg3: int, str

    :returns: description of return value(s)

    :rtype: int
    :rtype: str
    :rtype: int, str

    :raises Exception: description of exception

    :yields: description of yielded value(s)

    :ytype: int
    :ytype: str
    :ytype: int, str
    '''
    assert str(parse(text)) == text



# Generated at 2022-06-21 12:00:47.080319
# Unit test for function parse
def test_parse():
    actual = parse('A short description.\n\n:param x: A nice thing.\n:returns: A nice thing as well.\n')
    expected = Docstring(
        short_description='A short description.', 
        blank_after_short_description=True, 
        blank_after_long_description=False, 
        long_description=None, 
        meta=[DocstringParam(args=['param', 'x'], description='A nice thing.', arg_name='x', type_name=None, is_optional=None, default=None), DocstringReturns(args=['returns'], description='A nice thing as well.', type_name=None, is_generator=False)])
    assert actual == expected

# Generated at 2022-06-21 12:00:57.577690
# Unit test for function parse
def test_parse():
    docstring = """
    Short description without newlines.

    Long description, part 1.
    Long description, part 2.

    :param type_name arg_name: Argument description. Multi-line.
    :param a_other_arg: Argument description.
    :param a_final_arg: Argument description.
    :raises SyntaxError: Description.
    :raises IOError: Description.
    :yields str: Description.
    :returns None: Description.
    :returns: Description.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Short description without newlines."
    assert (
        parsed.long_description
        == "Long description, part 1.\nLong description, part 2."
    )
    assert parsed.blank_after_short_description
    assert parsed.blank

# Generated at 2022-06-21 12:01:09.269640
# Unit test for function parse
def test_parse():
    docstring = Docstring()
    docstring.short_description = "Test"
    docstring.long_description = "This is a test function"
    docstring.blank_after_short_description = True
    docstring.blank_after_long_description = True
    docstring.meta = []
    docstring.meta.append(DocstringParam(args=["param", None, "param1"], arg_name="param1", type_name=None, is_optional=None, default=None, description="This is the first param"))
    docstring.meta.append(DocstringParam(args=["type", "int", "param2"], arg_name="param2", type_name="int", is_optional=False, default=None, description="This is the second param"))

# Generated at 2022-06-21 12:01:19.838105
# Unit test for function parse
def test_parse():
    for s in ["foo bar", " foo bar  ", " foo bar  \n ", "foo bar  \n  baz"]:
        assert parse(s).short_description == "foo bar"

    for s in ["  foo bar", " foo bar  ", " foo bar  \n", "foo bar  \n  baz"]:
        assert parse(s).blank_after_short_description

    for s in ["foo bar\nbaz", "foo bar\n  baz", " foo bar\n  baz  "]:
        assert parse(s).long_description == "baz"


# Generated at 2022-06-21 12:01:26.451157
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""

# Generated at 2022-06-21 12:01:36.386132
# Unit test for function parse
def test_parse():
    # Unit test for function parse
    text = r"""
    One-line description.

    Extended description.
    It can have multiple lines.

    And a final paragraph.

    :param argument: description of argument
    :type argument: str
    :keyword keyword: description of keyword
    :returns: description of return value
    :rtype: str
    :return: description of return value
    :raises ValueError: description of exception
    """
    ds = parse(text)
    assert ds.short_description == "One-line description."
    assert ds.long_description == (
        "Extended description.\nIt can have multiple lines.\n\nAnd a final "
        "paragraph."
    )
    assert ds.blank_after_short_description
    assert ds.blank_after_long_description

# Generated at 2022-06-21 12:01:44.808618
# Unit test for function parse
def test_parse():
    docstring = """
            Short description.

            Longer description.

            :param int non_optional: non optional argument
            :param int optional?: optional argument
            :param int optional_with_default: optional argument with default
                value
            :param str optional_with_default_and_long_description:
                optional argument with default and long description.
            :returns type: returns type
            :returns?: returns nothing
            :raises type: raises type
            :raises?: raises nothing
            """

    result = parse(docstring)

    assert(isinstance(result, Docstring))

    assert(result.short_description == 'Short description.')
    assert(result.long_description == 'Longer description.')
    assert(not result.blank_after_short_description)

# Generated at 2022-06-21 12:01:55.032002
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a multiline docstring.

    :param x:
        The x parameter.
    :type x:
        int
    :return:
        A return value.
    :rtype:
        str
    '''


# Generated at 2022-06-21 12:02:08.473143
# Unit test for function parse
def test_parse():
    text = """
    Parses a set of Text with a regex Pattern.

    The regex pattern `regex` must match the entire text.

    If a group is specified, returns the specified group. Otherwise, returns a
    list of strings corresponding to the extracted fields. If `group` is not
    specified and `extract` is False, returns a list of tuples of strings
    representing the extracted fields.

    A single group can be specified either as `group` or as `extract = group`,
    both forms are accepted.
    """

    docstring = parse(text)
    assert len(docstring.meta) == 0
    assert docstring.short_description == \
        "Parses a set of Text with a regex Pattern."

# Generated at 2022-06-21 12:02:18.361771
# Unit test for function parse
def test_parse():
    text = """\
        This is a summary.

        This is a long description.

        :param arg1: description
        :param arg2: description
        :param arg3: description
        :arg1: description
        :type arg2: str
        :type arg3: str

        :returns: description

        :raises TypeError: description
        :raises ValueError: description

        :other: description
        """
    doc = parse(text)
    assert doc.short_description == "This is a summary."
    assert doc.long_description == "This is a long description."

# Generated at 2022-06-21 12:02:29.965891
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description.

    This is a long description.
    """
    assert str(parse(docstring)) == str(
        Docstring(
            short_description="This is a short description.",
            long_description="This is a long description.",
            blank_after_short_description=True,
            blank_after_long_description=False,
            meta=[],
        )
    )

    docstring = "    This is a short description."
    assert str(parse(docstring)) == str(
        Docstring(
            short_description="This is a short description.",
            long_description=None,
            blank_after_short_description=False,
            blank_after_long_description=False,
            meta=[],
        )
    )


# Generated at 2022-06-21 12:02:38.975360
# Unit test for function parse
def test_parse():
    """Test the parse function."""
    print(parse.__doc__)
    doc = """
    Foo bar baz.  This is a short description.
    There's nothing to see here, move along.

    :param foo: parameter
    :param bar: parameter
    :returns: returns
    """

# Generated at 2022-06-21 12:02:49.073654
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg1: first argument
    :param arg2: second argument
    :type arg2: str
    :return: a value
    :rtype: int
    :raises SystemExit: when everything is not ok

    """
    parsed = parse(docstring)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description

# Generated at 2022-06-21 12:02:54.282488
# Unit test for function parse
def test_parse():
    text = """Constructor

Constructs a new audio source.

Args:
  source (Union[str, bytes, int, io.IOBase]):
    The audio source. For a list of supported types see
    :meth:`pyttsx3.init` documentation.

Returns:
  AudioSource: Audio source.
"""
    parse(text)

# Generated at 2022-06-21 12:03:00.104096
# Unit test for function parse
def test_parse():
    assert(parse('Test\n    Raises:') == Docstring(short_description='Test', blank_after_short_description=True, blank_after_long_description=False, long_description=None, meta=[DocstringRaises(args=['Raises'], description='', type_name=None)]))


if __name__ == "__main__":
    print(parse('Test\n    Raises:'))

# Generated at 2022-06-21 12:03:10.341756
# Unit test for function parse
def test_parse():
    text = '''
    summary

    without tabs

    :param x:

    with tabs.

    :param: keyword only

    :return:
    '''

    d = parse(text)
    assert d.short_description == 'summary'
    assert d.long_description == 'without tabs\n\nwith tabs.'
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == True

    assert len(d.meta) == 2
    assert isinstance(d.meta[0], DocstringParam)
    assert d.meta[0].args == ['param', 'x']
    assert d.meta[0].description == 'without tabs.'
    assert d.meta[0].arg_name == 'x'

    assert isinstance(d.meta[1], DocstringReturns)
   

# Generated at 2022-06-21 12:03:21.146397
# Unit test for function parse
def test_parse():
    s = r'''
    Parses a string for the arguments
    :param arg1: the first argument
    :param arg2: the second argument, defaults to 2
    :param arg3: the third argument
    :type arg3: int
    :raises ValueError: if the value is above 10
    :returns: arg1/arg2
    '''
    ds = parse(s)
    assert ds.short_description == "Parses a string for the arguments"
    assert len(ds.meta) == 4
    assert isinstance(ds.meta[0], DocstringParam)
    assert ds.meta[0].arg_name == "arg1"
    assert ds.meta[0].description == "the first argument"
    assert ds.meta[1].arg_name == "arg2"
    assert d

# Generated at 2022-06-21 12:03:26.461128
# Unit test for function parse
def test_parse():
    docstring_text = """Short description.

    Long description.

    :param arg1: argument 1
    :param arg2: argument 2

    :returns: Nothing.
    """
    assert str(parse(docstring_text)) == docstring_text

# Generated at 2022-06-21 12:03:40.315076
# Unit test for function parse
def test_parse():
    text = """
    Random function to get a random sample.
    :param x: the random sample
    :type x: str
    :param y: the number of random samples
    :type y: int
    :param z: the random sample mean
    :type z: float
    :param a: the random sample median
    :type a: float
    :returns: the random sample
    :rtype: str
    :raises ValueError: if no value is specified.
    :raises TypeError: if an invalid type is specified.
    """
    return parse(text)




# Main function

# Generated at 2022-06-21 12:03:52.082310
# Unit test for function parse

# Generated at 2022-06-21 12:03:58.124694
# Unit test for function parse
def test_parse():
    doc = """
        Short description.

        Long description.
        Can be written over several lines.

        :param type arg_name: arg description
        :yields some_type: description

        :param kwarg: keyword argument description
        :return: description
        :raises type: description

        :param arg_name: arg description
        :yields: description
        :returns: description
        :raises: description

        :param some_type arg_name: arg description
        :yields some_type: description
        :returns some_type: description
        :raises some_type: description
    """


# Generated at 2022-06-21 12:04:09.373017
# Unit test for function parse
def test_parse():
    # This function is a test function to make sure that the parser works correctly
    # There are four test cases with the assertions

    def test_function():
        """Tests docstring parsing.

        This function tests docstring parsing.
        :param p1: parameter 1
        :type p1: str
        :param p2: parameter 2
        :type p2: int
        :param p3: parameter 3 (defaults to 9)
        :raises Exception: on failure
        :returns: None
        :rtype: None
        """
        pass

    d = parse(inspect.getdoc(test_function))
    assert d.short_description == "Tests docstring parsing."
    assert d.blank_after_short_description is False
    assert d.long_description == "This function tests docstring parsing."
    assert d.blank

# Generated at 2022-06-21 12:04:20.396607
# Unit test for function parse
def test_parse():
    s = '''\
        Docstring with the following format:

        :param string foo: The foo.
        :param string bar: The bar.
        :param string baz: The baz.
          Multi-line
          description.

        :return: The docstring.
        :rtype: str
    '''
    docstring = parse(s)
    assert docstring.short_description.strip() == "Docstring with the following format:"
    assert docstring.blank_after_short_description
    assert docstring.long_description.strip() == ""
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    param, param1, returns = docstring.meta
    assert param.tag == "param"
    assert param.arg_name == "foo"

# Generated at 2022-06-21 12:04:29.011206
# Unit test for function parse

# Generated at 2022-06-21 12:04:31.881627
# Unit test for function parse
def test_parse():
    from . import __main__
    import doctest
    doctest.testmod(__main__)
    return


# Generated at 2022-06-21 12:04:39.819663
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    value = parse.__doc__
    assert isinstance(value, str)
    doc_string = parse(value)
    assert doc_string.short_description == 'Parse the ReST-style docstring into its components.'
    assert len(doc_string.meta) == 2
    assert doc_string.meta[0].args[0] == 'returns'
    assert doc_string.meta[0].description == 'parsed docstring'
    assert doc_string.meta[1].args[0] == 'returns'
    assert doc_string.meta[1].description == 'parsed docstring'



# Generated at 2022-06-21 12:04:50.371635
# Unit test for function parse
def test_parse():
    docstring = """
        Args:
            a_str: A string.
            a_list: A list (defaults to [1]).
            an_int: An int (defaults to 5).
            a_float: A float (defaults to 3.14).
            a_bool: A bool (defaults to True).
            a_none: A None (defaults to None).
            no_default: No default.
            a_tuple: A tuple (defaults to (1,2,3)).
        """
    print(parse(docstring))


# Generated at 2022-06-21 12:05:01.398514
# Unit test for function parse
def test_parse():
    """
    Unit test to verify correctness of parse
    """
    text = """\
        Hello, world!

        This is the world's most interesting function.

        :param foo: a foo to be used in the function
        :type foo: int
        :param bar: a bar to be used in the function
        :type bar: str
        :returns: some result from the function
        :rtype: float
        :Yields: results from the function as we go
        """
    doc = parse(text)
    assert doc.short_description=="Hello, world!"
    assert doc.meta[0].args==["param", "foo", "a foo to be used in the function"]
    assert doc.meta[0].description=="a foo to be used in the function"