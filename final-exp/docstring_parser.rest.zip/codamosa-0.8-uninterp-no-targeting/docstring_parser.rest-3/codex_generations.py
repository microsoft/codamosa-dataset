

# Generated at 2022-06-21 11:55:36.520936
# Unit test for function parse
def test_parse():
    ## Test case 1
    test_text = """Demo for the ReST style docstring.
    """
    parse_result = parse(test_text)
    assert parse_result.short_description == 'Demo for the ReST style docstring.'
    assert parse_result.meta == []

    ## Test case 2
    test_text = """Demo for the ReST style docstring.

    **Before the :keyword, the first space is necessary.**
    **(But no space after :)**

    :keyword argument: description
    """
    parse_result = parse(test_text)
    assert parse_result.short_description == 'Demo for the ReST style docstring.'
    assert parse_result.meta[0].args == ['keyword', 'argument']
    assert parse_result.meta[0].description == 'description'

# Generated at 2022-06-21 11:55:41.358133
# Unit test for function parse
def test_parse():
    docstring = """
    This is the first line in the docstring.
    This is the second line in the docstring.

    :param arg1: describes arg1
    :type arg1: int
    :param arg2: describes arg2
    :type arg2: str, required
    :param arg3: describes arg3, defaults to False.
    :param arg4: describes arg4, defaults to True.
    :raises ValueError: if something bad happens
    :returns: None
    :returns: int
    :rtype: int
    :rtype: int
    :yields: int
    :yields int:
    :yields:
    """

# Generated at 2022-06-21 11:55:43.579722
# Unit test for function parse
def test_parse():
    from .utils import docstring_sample, pformat

    print(pformat(parse(docstring_sample)))
    # assert 0, 'stub test'

# Generated at 2022-06-21 11:55:50.939521
# Unit test for function parse
def test_parse():
    input_str = """Short summary.

More detailed summary.

:param x:
  Parameter x.

:param y:
  Parameter y..

:raises ValueError:
  Raise ValueError.

:returns:
  Return something.

:returns:
  Return something else.
    """

    parsed_str = parse(input_str)

    assert len(parsed_str.meta) == 5
    assert parsed_str.meta[0].keyword == "param"
    assert parsed_str.meta[0].arg_name == "x"
    assert parsed_str.meta[0].type_name is None
    assert parsed_str.meta[0].is_optional is None
    assert parsed_str.meta[0].default is None

    assert parsed_str.meta[1].key

# Generated at 2022-06-21 11:55:57.467614
# Unit test for function parse
def test_parse():
    dummy_str = """
    Func

    :param x: x is the parameter of the function
    :type x: int
    :param y: y is the parameter of the function
    :type y: str
    :rtype: None"""
    docstring = parse(dummy_str)
    print(docstring.meta)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:56:05.952693
# Unit test for function parse
def test_parse():
    d = """
        Short description

        Long description

        :param x: the x parameter
        :type x: int
        :param y: the y parameter
        :type y: int
        :returns: the return value
        :rtype: int
        :raises AttributeError: on bad attributes
        """

# Generated at 2022-06-21 11:56:16.731325
# Unit test for function parse
def test_parse():
    test_func = parse
    assert test_func("Hello, world.") == Docstring(
        description="Hello, world.",
    )
    assert test_func("Hello, world.\n") == Docstring(
        description="Hello, world.",
    )
    assert test_func("Hello, world.\n\n") == Docstring(
        description="Hello, world.",
        blank_after_long_description=True,
    )
    assert test_func("Hello, world!\n\n") == Docstring(
        description="Hello, world!",
        blank_after_long_description=True,
    )
    assert test_func("Hello, world!\n\n\n") == Docstring(
        description="Hello, world!",
        blank_after_long_description=True,
    )

# Generated at 2022-06-21 11:56:27.385505
# Unit test for function parse

# Generated at 2022-06-21 11:56:38.127705
# Unit test for function parse
def test_parse():
    # check description and docstring
    text = "The function parses docstrings.\n  Very well indeed!\n"
    doc = parse(text)
    #assert doc.short_description == "The function parses docstrings."
    #assert doc.long_description == "Very well indeed!"
    #assert doc.blank_after_short_description is False
    #assert doc.blank_after_long_description is True
    #assert not doc.meta

    # check optional argument
    text = "The function takes an optional argument.\n  :param x: Description of x.\n"
    doc = parse(text)
    assert len(doc.meta) == 1
    param = doc.meta[0]
    assert param.args == ["param", "x"]
    assert param.description == "Description of x."

# Generated at 2022-06-21 11:56:41.347047
# Unit test for function parse
def test_parse():
    import doctest
    failure_count, test_count = doctest.testmod(verbose=False)
    test_count -= failure_count
    assert test_count == 1
    assert failure_count == 0


__all__ = ["parse"]

# Generated at 2022-06-21 11:56:57.415125
# Unit test for function parse
def test_parse():
    import os
    import sys
    import pytest
    file_path = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(file_path)
    test_path = os.path.join(file_path, 'tests')
    sys.path.append(test_path)
    from test_docstring_parse import test_parse_simple, test_parse_multiple
    from test_docstring_parse import test_parse_extra_whitespace
    from test_docstring_parse import test_parse_complex
    from test_docstring_parse import test_parse_func_with_meta
    from test_docstring_parse import test_parse_func_with_raises
    from test_docstring_parse import test_parse_func_with_returns

# Generated at 2022-06-21 11:57:08.096108
# Unit test for function parse
def test_parse():
    doc = """This function blah blah blah.

:param x:
:param y:
:param z:
:returns:
:rtype:
:raises:
:yields:
"""
    result = parse(doc)
    assert result.short_description == "This function blah blah blah."
    assert result.long_description == None
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert len(result.meta) == 7
    assert result.meta[0].args == ["param", "x"]
    assert result.meta[0].arg_name == "x"
    assert result.meta[0].type_name == None
    assert result.meta[0].is_optional == None
    assert result.meta[0].default == None
    assert result

# Generated at 2022-06-21 11:57:20.216679
# Unit test for function parse
def test_parse():
    doc1 = """A docstring.
    """
    parsed_doc1 = parse(doc1)
    assert parsed_doc1.short_description == "A docstring."
    assert parsed_doc1.long_description == None

    doc2 = """A docstring.
    
    A docstring with
    
    line breaks.
    """
    parsed_doc2 = parse(doc2)
    assert parsed_doc2.short_description == "A docstring."
    assert parsed_doc2.long_description == "A docstring with\n\nline breaks."

    doc3 = """A docstring with :parameter.
    """
    parsed_doc3 = parse(doc3)
    assert parsed_doc3.short_description == "A docstring with :parameter."
    assert parsed_doc3.long_description == None



# Generated at 2022-06-21 11:57:29.844828
# Unit test for function parse
def test_parse():
    """Test function parse."""
    docstring = parse("First line.\n\n:param a: AAA.\n\n:param b: BBB.\n\n:return: r")
    assert docstring.short_description == "First line."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'a']
    assert docstring.meta[0].description == "AAA."
    assert docstring.meta[1].args == ['param', 'b']
    assert docstring.meta[1].description == "BBB."
    assert docstring.meta[2].args == ['return']
    assert docstring.meta[2].description == "r"

# Generated at 2022-06-21 11:57:41.998611
# Unit test for function parse
def test_parse():
    """Test parse function."""

# Generated at 2022-06-21 11:57:52.048181
# Unit test for function parse
def test_parse():
    assert parse("Function docstring.") == Docstring(
        short_description="Function docstring.",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

    # with blank line
    assert parse("Function docstring.\n") == Docstring(
        short_description="Function docstring.",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

    # with blank line and indented

# Generated at 2022-06-21 11:58:03.246364
# Unit test for function parse
def test_parse():
    """Tests for function parse."""
    d = parse("Test function\n")
    assert d.short_description is not None
    assert d.short_description == "Test function"
    assert d.long_description is None
    assert len(d.meta) == 0

    d = parse("Test function\n\nThis function tests parsing, not much else.")
    assert d.short_description is not None
    assert d.short_description == "Test function"
    assert d.long_description is not None
    assert d.long_description == "This function tests parsing, not much else."
    assert d.blank_after_short_description is True
    assert d.blank_after_long_description is False
    assert len(d.meta) == 0


# Generated at 2022-06-21 11:58:12.762619
# Unit test for function parse
def test_parse():
    # Tabular test cases

    from .common import new_tabular_test_case


# Generated at 2022-06-21 11:58:22.456079
# Unit test for function parse

# Generated at 2022-06-21 11:58:34.132667
# Unit test for function parse
def test_parse():
    docstring = "Convert string to hexadecimal numbers.\n\n:param str string: The string to convert.\n\n:returns: An hexadecimal string."

    parsed = parse(docstring)
    assert parsed.short_description == "Convert string to hexadecimal numbers."
    assert parsed.long_description == None
    assert parsed.meta[0].args[0] == "param"
    assert parsed.meta[0].arg_name == "string"
    assert parsed.meta[0].description == "The string to convert."
    assert parsed.meta[0].is_optional == False
    assert parsed.meta[0].type_name == "str"
    assert parsed.meta[0].default == None
    assert parsed.meta[1].args[0] == "returns"
    assert parsed.meta

# Generated at 2022-06-21 11:58:45.312908
# Unit test for function parse
def test_parse():
    try:
        parse("")
    except Exception:
        assert False, "It should return an empty Docstring."
    try:
        parse(None)
    except Exception:
        assert False, "It should return an empty Docstring."

# Generated at 2022-06-21 11:58:48.687256
# Unit test for function parse
def test_parse():
    docstring = inspect.getdoc(parse)
    real_docstring = parse(docstring)
    print(real_docstring)
    # assert real_docstring == real_docstring

# Generated at 2022-06-21 11:58:58.180503
# Unit test for function parse
def test_parse():
    raw = """The add() function adds two numbers together.

    :param int num1: The first number.
    :param int num2: The second number.
    :returns: num1 + num2.
    """
    parsed = parse(raw)
    assert parsed.short_description == "The add() function adds two numbers together."
    assert parsed.long_description == None
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False

# Generated at 2022-06-21 11:59:07.984702
# Unit test for function parse
def test_parse():
    docstring = "'''\nThis is a docstring\nwith multiple lines.\n'''"
    docstring_parsed = parse(docstring)
    assert len(docstring_parsed.meta) == 0
    assert docstring_parsed.short_description == "This is a docstring"
    assert docstring_parsed.blank_after_short_description == False
    assert docstring_parsed.blank_after_long_description == False
    assert docstring_parsed.long_description == "with multiple lines."
    
    docstring = '''
        This is a docstring
        with multiple lines.
        
        This is the long description of the docstring
        with multiple lines.
        '''
    
    docstring_parsed = parse(docstring)

# Generated at 2022-06-21 11:59:13.290986
# Unit test for function parse
def test_parse():
    docstring = '''\
    :param name:
    :type name: str
    :param email:
    :type email: str
    :returns: str
    :raises name: error
    '''
    result = parse(docstring)
    return result


# Unit test
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:59:23.471772
# Unit test for function parse
def test_parse():
    """Test parse function.

    :returns: None
    """
    # Successful case
    docstring = parse("""short desc one line.

long description here.
:param: arg_name type_name description.
:returns: type_name description.
""")
    assert docstring.short_description == "short desc one line."
    assert docstring.long_description == "long description here."
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg_name", "type_name"]
    assert docstring.meta[0].description == "description."
    assert docstring.meta[1].args == ["returns", "type_name"]
    assert docstring.meta[1].description == "description."

    # Error case

# Generated at 2022-06-21 11:59:35.280886
# Unit test for function parse

# Generated at 2022-06-21 11:59:43.621684
# Unit test for function parse
def test_parse():
    test_str = """Functions for getting and setting values in a nested structure
    of dictionaries, tuples and lists.

    :param dict obj: Object to get value from
    :param str path: Path to value in ``obj``
    :param default: Default value. Defaults to None.
    :return: Value at ``path`` in ``obj``
    :rtype: Depends on the value at ``path`` in ``obj``
    """

# Generated at 2022-06-21 11:59:52.460910
# Unit test for function parse
def test_parse():
    text = """\
        Single line summary.
        
        More detailed description of this function.
        
        :param A: First parameter.
        :param B: Second parameter.
        :param C: Third parameter.
        :param D: Fourth parameter.
        :raises Exc: Exception description.

        additional description after blank line
        
        :rtype: None
        :returns: None
    """

    ds = parse(text)
    assert len(ds.meta) == 5
    assert ds.short_description == "Single line summary."
    assert ds.long_description == (
        "More detailed description of this function."
        "\n\nadditional description after blank line"
    )
    assert ds.blank_after_short_description is True
    assert ds.blank_after_long_description is True


# Generated at 2022-06-21 12:00:03.853215
# Unit test for function parse
def test_parse():
    ds = parse("""
    This is the first line of the docstring.
    This is the second line, and it is indented.
    :arg1: this is arg1
    :arg2: this is arg2
    :rtype: None
    :returns: this is the returns section
    :raises ValueError: This is a ValueError
    """)

    assert ds.short_description == "This is the first line of the docstring."
    assert ds.long_description == """
    This is the second line, and it is indented."""

    assert ds.meta[0].args == ["arg1"]
    assert ds.meta[0].description == "this is arg1"
    assert ds.meta[1].args == ["arg2"]

# Generated at 2022-06-21 12:00:16.749738
# Unit test for function parse
def test_parse():
    txt = """Return a random integer N such that a <= N <= b.

    Alias for randrange(a, b+1).

    :param a: The lower bound to sample from
    :param b: The upper bound to sample from
    :rtype: The chosen random int in the range

    """
    result = parse(txt)

    assert result.short_description == "Return a random integer N such that a <= N <= b."
    assert result.long_description == "Alias for randrange(a, b+1)."
    assert result.meta[0].description == "The lower bound to sample from"
    assert result.meta[1].description == "The upper bound to sample from"
    assert result.meta[2].description == "The chosen random int in the range"

# Generated at 2022-06-21 12:00:27.868485
# Unit test for function parse
def test_parse():
    text = """
This is the short description.

    This is the long
    description.  It can
    even have *bold* and
    _italic_ text in it.

    First paragraph.

    Second paragraph.

    :param arg1: First argument.
    :type arg1: str
    :param arg2: Second argument.
    :type arg2: int
    :param arg3: Third parameter.
    :type arg3: float
    :param arg4: Fourth parameter.
    :type arg4: list
    :param arg5: Fifth parameter.
    :type arg5: dict

    :returns: Something
    :rtype: str
    """
    doc = parse(text)
    assert doc.short_description == "This is the short description."

# Generated at 2022-06-21 12:00:33.183635
# Unit test for function parse
def test_parse():
    docstring = '''
    Define a function test.

    :param list args:  The argumenents.
    :param name: The name.
    :returns: The return.
    :raises ValueError: If the value is wrong.
    '''
    print (parse(docstring).__dict__)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:00:44.707071
# Unit test for function parse
def test_parse():
    docstring = '''One line description.

    Longer description with information.

    :param arg1: description of arg1
    :param arg2: description of arg2
    :returns: description of the return value

    '''

    parsed = parse(docstring)
    print(parsed)
    print(parsed.meta)
    assert parsed.short_description == "One line description."
    assert parsed.long_description == "Longer description with information."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == True
    assert parsed.meta[0].args == ['param', 'arg1']
    assert parsed.meta[1].args == ['param', 'arg2']
    assert parsed.meta[2].args == ['returns']

# Generated at 2022-06-21 12:00:56.068856
# Unit test for function parse
def test_parse():
    def mock_func(a, b, c=3, d=None, e=None):
        """Shows off the features of ReST-style docstrings.

        :param a: first argument
        :type a: int
        :param b: second argument
        :type b: str
        :param c: third argument
        :type c: int
        :param d: fourth argument, defaults to None
        :type d: bool
        :param e: fifth argument, defaults to None
        :type e: str
        :param f: sixth argument, defaults to 'f'
        :type f: str
        :raises ZeroDivisionError: if b is zero
        :returns: list
        :returns type: list of int
        """

    src = inspect.getsource(mock_func)
    docstring = parse(src)

# Generated at 2022-06-21 12:01:07.424092
# Unit test for function parse
def test_parse():
    text = """\
    A short summary.

    A long description.

    :param arg1: Blah
    :type arg1: str
    :param arg2: Meh
    :type arg2: int
    :raises: ValueError
    :raises Exception: Fail
    :returns: Nothing
    :returns: int
    :returns: (int, int)
    :rtype: int
    :rtype: tuple(int, str)
    :rtype: int
    :yields: str
    :yields: int
    :yields: (int, int)
    """
    doc = parse(text)
    assert doc.short_description == "A short summary."
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False


# Generated at 2022-06-21 12:01:17.968749
# Unit test for function parse
def test_parse():

    docstring = """
    :param arg1: first arg
    :type arg1: int
    :param arg2: second arg
    :type arg2: str

    Short description.

    Long description.

    :param arg3: third arg
    :type arg3: dict
    :param arg4: fourth arg
    :type arg4: dict
    :return: the return type
    :rtype: dict

    """

    parsed = parse(docstring)

    assert parsed.short_description == "Short description."

    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description

    assert parsed.long_description == "Long description."

    assert len(parsed.meta) == 5

    assert parsed.meta[0].args == ["param", "arg1", "first arg"]
    assert parsed

# Generated at 2022-06-21 12:01:23.362360
# Unit test for function parse
def test_parse():
    ds = parse.__doc__
    assert parse(ds) == Docstring(
        short_description="Parse the ReST-style docstring into its components.",
        blank_after_short_description=False,
        long_description="""\
        :returns: parsed docstring""",
        blank_after_long_description=True,
        meta=[
            DocstringMeta(
                args=["returns"],
                description="parsed docstring",
            )
        ])

# Generated at 2022-06-21 12:01:32.297076
# Unit test for function parse
def test_parse():
    """Test parsing docstring with ReST-style."""
    text = """
    Short description.  Long description.  Long description.

    :param type arg1: Description of `arg1`.
    :param str arg2: Description of `arg2`.
    :returns: Description of the return value.
    :rtype: return type
    :raises Exception: Description of exception.
    :raises: Description of exception.
    :raises Exception: Description of exception.
    """

# Generated at 2022-06-21 12:01:42.558803
# Unit test for function parse
def test_parse():
    # Split text into parts: short description and long description
    def _parse_text(text: str) -> T.Tuple[str, str]:
        lines = text.split("\n")
        short_desc = lines[0] or None
        long_desc = ""
        in_long_desc = False
        for line in lines[1:]:
            if not in_long_desc and line.strip():
                long_desc += line + "\n"
                in_long_desc = True
            elif in_long_desc:
                long_desc += line + "\n"
        if long_desc:
            long_desc = long_desc.rstrip("\n")
        return short_desc, long_desc


# Generated at 2022-06-21 12:01:54.461087
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    doc = parse(
        """\
        Sample function.

        :param int foo: The first argument.
        :param str bar: The second argument.
        :raises ValueError: In case of error.
        :returns: Whatever the function returns.
        :raises: Something else.
        This paragraph is still part of the 'raises' section.
        :return: Something else entirely.
        """
    )
    assert doc.short_description == "Sample function."

# Generated at 2022-06-21 12:01:58.570145
# Unit test for function parse
def test_parse():
    docstring = '''
    Test parse function.

    :param x: integer number
    :param y: integer number
    :returns: an integer number
    :raises: ValueError

    This is just a test.
    '''
    assert len(parse(docstring).meta) == 3



# Generated at 2022-06-21 12:02:09.129216
# Unit test for function parse
def test_parse():
    assert parse("   Hello!  ") == Docstring(
        short_description="Hello!",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )
    assert parse("   Hello!  \nworld.") == Docstring(
        short_description="Hello!",
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description="world.",
    )
    assert parse("   Hello!  \nworld.\n") == Docstring(
        short_description="Hello!",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description="world.",
    )

# Generated at 2022-06-21 12:02:17.139283
# Unit test for function parse
def test_parse():
    function_parse = parse.__code__.co_code
    byte_code = function_parse[0x11:0x15]  # range of bytecode to be replaced
    replace = b'\x06\x00\x00\x00'  # replacement bytecode
    new_byte_code = function_parse.replace(byte_code, replace)
    with open('test.py', 'w') as f:
        f.write(inspect.getsource(parse))
    with open('test.pyc', 'wb') as f:
        f.write(new_byte_code)
    import test
    assert test.parse()

# Generated at 2022-06-21 12:02:20.284619
# Unit test for function parse
def test_parse():
    docstring = '''
    Given a $X$, compute $Y$.

    :param x: The $X$ value.
    :returns: The $Y$ value.
    :raises ValueError: If $X$ less than $10$.
    '''
    expect = parse(docstring)
    print(expect)



# Generated at 2022-06-21 12:02:31.949792
# Unit test for function parse
def test_parse():
    def func0():
        """ Short string. """
        pass

    def func1():
        """ Short string.

        Long string.

        :param name: some name
        :type name: str
        :param arg: arg description
        :type arg: str
        :returns: return description
        :rtype: str
        :raises Exception: if something bad happens
        """
        pass

    def func2():
        """ Short string.

        Long string.

        :returns: return description
        :rtype: str

        :param name: some name
        :type name: str
        :param arg: arg description
        :type arg: str

        :raises Exception: if something bad happens
        """
        pass


# Generated at 2022-06-21 12:02:35.409477
# Unit test for function parse
def test_parse():
    docstring = '''
    Single line doc string.

    :param num1: The first number.
    :param num2: The second number.
    :return: The sum of ``num1`` and ``num2``.
    '''
    print(parse(docstring))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:02:41.919686
# Unit test for function parse
def test_parse():
    string = """This is the short description.

    This is the long description.

    :param type_name arg_name: Argument name.
    :type type_name arg_name: Argument name.
    :param type_name arg_name: Argument name.
    :type type_name arg_name: Argument name.
    :returns: This is a description of what is returned.
    :rtype: str
    :raises keyError: raises an exception
    :raise keyError: raise an exception
    :raises: this is an exception
    :raise: this is an exception
    :raises keyError: raises an exception

    """
    x = parse(string)
    assert x.short_description == "This is the short description."
    assert x.long_description == "This is the long description."
    assert x.blank_after_

# Generated at 2022-06-21 12:02:50.517115
# Unit test for function parse
def test_parse():
    docstring = parse(inspect.cleandoc(
"""
Short line
Long line with more content

:param a: first line
  more content
:param b: second line
:return: returns what was given
"""
    ))
    print(docstring)

# Generated at 2022-06-21 12:03:01.736577
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param foo: description of foo.
    :type foo: str
    :param bar: description of bar.
    :returns: output of the function.
    :rtype: int
    :raises ValueError: if there is an error.
    """
    ds = parse(docstring)

    assert ds.short_description == "Short description."
    assert ds.long_description == "Long description."
    assert len(ds.meta) == 3
    assert isinstance(ds.meta[0], DocstringParam)
    assert isinstance(ds.meta[1], DocstringReturns)
    assert isinstance(ds.meta[2], DocstringRaises)
    assert ds.meta[0].arg_name == "foo"
    assert ds.meta

# Generated at 2022-06-21 12:03:17.734351
# Unit test for function parse
def test_parse():
    docstring = Docstring(short_description = "Parse the ReST-style docstring into its components.",
                  blank_after_short_description = False,
                  blank_after_long_description = False,
                  long_description = "Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring",
                  meta = [
                      DocstringMeta(args = ['returns'], description = 'parsed docstring'),
                      ])

    assert docstring == parse(
        'Parse the ReST-style docstring into its components.\n\n'
        ':returns: parsed docstring')

# Generated at 2022-06-21 12:03:25.760911
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    This is the long description.

    :param x: the x parameter
    :type x: int
    :param y: the y parameter
    :type y: int
    :param z: the z parameter
    :type z: int
    :returns: something
    :rtype: bool
    :raises TypeError
    """
    doc = parse(text)
    assert doc.short_description == "Short description."
    assert doc.long_description == "This is the long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert isinstance(doc.meta[0], DocstringParam)
    assert isinstance(doc.meta[1], DocstringParam)

# Generated at 2022-06-21 12:03:27.597699
# Unit test for function parse
def test_parse():
    # This function unit test function parse
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:03:38.310234
# Unit test for function parse
def test_parse():
    docstring = """
    Hello World test function.
    short description across multiple lines
    """
    docstring = parse(docstring)
    assert docstring.short_description == 'Hello World test function.'
    assert docstring.long_description == 'short description across multiple lines'
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert isinstance(docstring.meta, list)


# Generated at 2022-06-21 12:03:50.132220
# Unit test for function parse
def test_parse():
    """Test if parsing returns the expected result."""
    # Example taken from https://www.python.org/dev/peps/pep-0257/#what-s-the-docstring
    example_docstring = """
    This is a multi-line docstring.

    :param int index: The index.
    :param str type_name: The type name.
    :param bool is_optional: Description of is_optioanl.
    :param str default: Description of default.
    :raises IndexError: Description of exception raised.
    :returns: Description of return value.
    :yields: Description of yielded value.
    """
    docstring = parse(example_docstring)
    meta = docstring.meta
    assert docstring.short_description == "This is a multi-line docstring."
    assert docstring

# Generated at 2022-06-21 12:04:00.992737
# Unit test for function parse
def test_parse():
    docstring = """
   Some short description
   <lines>

   Args:
       arg_1 (int): The first argument
       arg_2 (str, optional): The second argument, defaults to 'foo'.
       arg_3 (str): The third argument.

   Returns:
       bool: The return value. True for success, False otherwise.
       float: Number of success.

   Raises:
       LookupError: When something cannot be found.
       ValueError: When something is wrong.
    """

    parsed = parse(docstring)
    assert parsed.short_description == "Some short description"
    assert parsed.blank_after_short_description is True
    assert parsed.blank_after_long_description is False
    assert parsed.long_description == ""

    first_meta = parsed.meta[0]

# Generated at 2022-06-21 12:04:11.544846
# Unit test for function parse
def test_parse():
    text = """\
    Retrieves the values specified by one or more keys.

    :params key: The name of a key or a list of key paths.
    :type key: str | list

    :params default: The value returned if the key is not found.
    :type default: str

    :returns: The values stored at key.
    :rtype: str
    """
    result = parse(text)
    assert result.short_description == "Retrieves the values specified by one or more keys."
    assert result.long_description == "The values stored at key."
    assert result.blank_after_short_description
    assert not result.blank_after_long_description
    assert len(result.meta) == 3

# Generated at 2022-06-21 12:04:23.020472
# Unit test for function parse

# Generated at 2022-06-21 12:04:30.197700
# Unit test for function parse
def test_parse():
    docstring = """\
    This is a one line summary.

    This is a longer
    and more detailed
    description.

    :param astr: A string.
    :type astr: str
    :param aint: An integer.
    :type aint: int
    :param abool_or_none: A boolean or None.
    :type abool_or_none: bool or None
    :returns: A string.
    :rtype: str
    :raises: AssertionError
    :raises: ValueError
    """

# Generated at 2022-06-21 12:04:39.688797
# Unit test for function parse

# Generated at 2022-06-21 12:04:54.431754
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    t = parse

    assert "abc" == t("abc")
    assert "abc" == t(" abc ")
    assert "abc" == t("\n  abc ")
    assert t("").short_description is None
    assert t("").long_description is None
    assert "abc" == t("abc\n").short_description
    assert t("abc\n").long_description is None
    assert t("abc\n").blank_after_short_description
    assert not t("abc").blank_after_short_description
    assert t("abc\n\n").blank_after_long_description
    assert not t("abc\n").blank_after_long_description
    assert t("abc\n").blank_after_short_description


# Generated at 2022-06-21 12:05:06.102321
# Unit test for function parse
def test_parse():
    # Empty string returns Docstring
    actual = parse("")
    assert actual == Docstring()

    # One-line returns as short_description
    actual = parse("This is a one-line docstring.")
    assert actual.short_description == "This is a one-line docstring."
    assert actual.long_description is None

    # One-line with leading space returns as short_description
    actual = parse(" This is a one-line docstring.")
    assert actual.short_description == "This is a one-line docstring."
    assert actual.long_description is None

    # Leading empty line is ignored
    actual = parse("\nThis is a one-line docstring.")
    assert actual.short_description == "This is a one-line docstring."
    assert actual.long_description is None

    # Multiple leading empty lines are ignored
