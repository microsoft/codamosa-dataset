

# Generated at 2022-06-21 11:55:26.072891
# Unit test for function parse
def test_parse():
    text = """One line short description.

    Possibly more
    lines in the long
    description.

    :param abc: The first parameter.
    :type abc: int
    :arg def: The second parameter.
    :type def: str
    :arg ghi: The third parameter.
    :arg jkl: The fourth parameter.
    :raises RuntimeError: If something goes wrong.
    :yields int: The yielded integer.
    :returns: The return value.
    :rtype: str
    :yields: The yielded value.
    :return: The return value.
    """
    # print(parse(text))

# test_parse()

# Generated at 2022-06-21 11:55:38.013630
# Unit test for function parse
def test_parse():
    text = '''
        """Parse the ReST-style docstring into its components.
        """
    '''
    doc = parse(text)
    assert doc.short_description.strip() == 'Parse the ReST-style docstring into its components.'

    text = '''
        """
        Parse the ReST-style docstring into its components.
        """
    '''
    doc = parse(text)
    assert doc.short_description.strip() == 'Parse the ReST-style docstring into its components.'

    text = '''
        """
        Parse the ReST-style docstring into its components.

        :param: text: str
        :return:
        """
    '''
    doc = parse(text)

# Generated at 2022-06-21 11:55:47.950684
# Unit test for function parse
def test_parse():
    doc = parse("""
    user_login(conn, username, password, database="default")
    
    Logs into a Postgres database.
    
    :param DatabaseConnection conn: database connection
    :param str username: user to log in as
    :param str password: password for user
    :param str database: database to connect to, defaults to 'default'
    :returns: connection to database
    :raises DatabaseError: if username/password is invalid
    
    This is a long description for the user_login function.
    
    Maybe it has multiple paragraphs.
    
    Maybe it mentions *this* and `that`.
    """)

    assert isinstance(doc, Docstring)
    assert doc.short_description == "user_login(conn, username, password, database=\"default\")"

# Generated at 2022-06-21 11:55:59.486664
# Unit test for function parse
def test_parse():
  # Example docstring
  text = """\
Multiline short description of this module.

This is a very long description that should go in a second paragraph.

:param this_arg: This is a param
:param other_arg: With a desc.
:returns: This is the return desc.
:raises ValueError: This function can raise this error.
:raises IndexError: This function can raise this error.
:yields str: This function is a generator that yields strings.
:yields int: This function is a generator that yields ints.
"""
  docstring = parse(text)
  # The result should contain all the meta information
  assert docstring.meta[0]['args'] == ['param', 'this_arg']
  assert docstring.meta[0]['description'] == 'This is a param'

# Generated at 2022-06-21 11:56:07.232298
# Unit test for function parse
def test_parse():
    ds = parse("""
        Short description.

        This is the first line of a longer description.
        And this is the second line.

        :param foo: First argument.
        :type foo: int
        :returns: A value.
        :rtype: str
        :raises ValueError: When value is invalid.

        :param bar: This argument is optional.
        :type bar: int, optional
        :param baz: This argument has a default value.
        :type baz: int, optional
        :default baz: 1

        :param qux: This argument has a default value, a type, and is optional.
        :type qux: int, optional
        :default qux: 1
    """)

    assert ds.short_description == "Short description."
    assert ds.blank_after_short_

# Generated at 2022-06-21 11:56:18.298328
# Unit test for function parse
def test_parse():
    text = """
    This is an example docstring.

    :param x: the x param
    :param y: the y param
    :type y: int
    :param summary: The summary
    :returns: the return value
    :raises ValueError: if something bad happens
    :raises: TypeError
    """

    d = parse(text)

    # Verify the docstring variable
    assert d.short_description == "This is an example docstring."
    assert d.long_description == "the summary"

    # Verify the meta variable
    assert len(d.meta) == 4
    assert d.meta[0].args == ["param", "x"]
    assert d.meta[0].description == "the x param"
    assert d.meta[1].args == ["param", "y", "int"]
    assert d

# Generated at 2022-06-21 11:56:28.324831
# Unit test for function parse
def test_parse():
    """Unit test for function 'parse'"""
    text = """
    Compares two objects and returns an integer based on the outcome.

    The return value is negative if a<b, zero if a==b and strictly
    positive if a>b.

    :param a: first object to compare
    :param b: second object to compare
    :returns: negative, zero or positive number
    """
    doc = parse(text)
    # pylint: disable=protected-access
    assert doc._visible_short_description == "Compares two objects and returns an integer based on the outcome."  # noqa: E501

# Generated at 2022-06-21 11:56:39.081532
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Short desc.") == Docstring(
        short_description="Short desc.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )
    assert parse("Short desc.\nLong desc.") == Docstring(
        short_description="Short desc.",
        blank_after_short_description=False,
        long_description="Long desc.",
        blank_after_long_description=True,
    )
    assert parse("Short desc.\nLong desc.\n\n") == Docstring(
        short_description="Short desc.",
        blank_after_short_description=False,
        long_description="Long desc.",
        blank_after_long_description=False,
    )

# Generated at 2022-06-21 11:56:50.087047
# Unit test for function parse
def test_parse():
    doc = parse(
        """Short description.

        This is a long description.
        """
    )

    assert doc.short_description == "Short description."
    assert doc.long_description == "This is a long description."

    doc = parse(
        """Short description.

        :param foo: ...
        :type foo: str
        :param bar: ... defaults to "bar".
        :type bar: int
        :returns: Description of the return value.
        :rtype: bool

        This is a long description.
        """
    )

    assert doc.short_description == "Short description."
    assert doc.long_description == "This is a long description."


# Generated at 2022-06-21 11:56:57.293187
# Unit test for function parse
def test_parse():
    docstring = """
    function(arg1, arg2)

    summary line

    extended description

    :type arg1: str
    :type arg2: int

    :param arg1: parameter 1
    :param arg2: parameter 2
    :return: nothing
    :rtype: None

    :raises TypeError: if arg2 is not a number
    :raises ValueError: if arg2 is negative
    """
    parsed = parse(docstring)
    assert parsed.short_description == "function(arg1, arg2)"
    assert parsed.long_description == "summary line\n\nextended description"
    assert parsed.blank_after_short_description is False
    assert parsed.blank_after_long_description is True

    assert parsed.meta[0].args == ["type", "arg1", "str"]

# Generated at 2022-06-21 11:57:11.973314
# Unit test for function parse
def test_parse():
    doc = """
    func(a) -> result: Short description.

    Long description.

    :param a:
        Parameter description
    """
    assert (parse(doc).short_description == 'func(a) -> result: Short description.')
    assert (parse(doc).meta[0].description == 'Parameter description')
    assert (parse(doc).meta[0].type_name == 'a')
    assert (parse(doc).meta[0].arg_name == 'a')
    assert (parse(doc).meta[0].is_optional == False)
    assert (parse(doc).meta[0].default == None)


# Generated at 2022-06-21 11:57:24.601316
# Unit test for function parse
def test_parse():
    docstring = """
    Compute square roots using the Babylonian method

    :param x: a positive number
    :type x: float
    :return: square root of x
    :rtype: float
    :raises ValueError: if x is negative
    """
    parsed = parse(docstring)
    assert parsed.short_description.strip() == "Compute square roots using the Babylonian method"
    assert parsed.long_description is None
    assert parsed.blank_after_short_description is True
    assert parsed.meta[0].description.strip() == "a positive number"
    assert parsed.meta[0].arg_name == "x"
    assert parsed.meta[0].type_name == "float"
    assert parsed.meta[0].is_optional == False
    assert parsed.meta[0].default is None



# Generated at 2022-06-21 11:57:32.573715
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("a\n\nb") == Docstring(
        short_description="a",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="b",
    )
    assert parse("a\nb") == Docstring(
        short_description="a",
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description="b",
    )
    assert parse("\n\na\nb\n\n") == Docstring(
        short_description="a",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="b",
    )

# Generated at 2022-06-21 11:57:45.169649
# Unit test for function parse
def test_parse():
    docstring = """short description

    long description

    :param foo: This is foo.
    :type foo: str
    :returns: None
    """
    parsed = parse(docstring)
    assert parsed.short_description == "short description"
    assert parsed.long_description == "long description"
    assert parsed.meta[1].args == ["returns"]
    assert parsed.meta[1].arg_name is None
    assert parsed.meta[1].type_name is None
    assert parsed.meta[1].is_optional is None
    assert parsed.meta[1].default is None
    assert parsed.meta[1].description == ""
    assert parsed.meta[0].args == ["param", "foo"]
    assert parsed.meta[0].arg_name == "foo"
    assert parsed.meta[0].type_name

# Generated at 2022-06-21 11:57:53.901033
# Unit test for function parse
def test_parse():
    # Tests the parse function in this script.
    # First test: very simple docstring with no meta-data.
    d = parse("""\
        This is the short description.

        This is the long description.
        It can span multiple lines.
        """)
    assert d.short_description == "This is the short description."
    assert d.long_description == (
        "This is the long description.\nIt can span multiple lines."
    )
    assert not d.blank_after_short_description
    assert not d.blank_after_long_description
    assert not d.meta

    # Second test: simple docstring with a single non-special argument.

# Generated at 2022-06-21 11:58:05.434615
# Unit test for function parse
def test_parse():
    """
    This function tests for all the possible cases of the docstring
    :return:
    """

    text = "This is a demo docstring"
    parsed = parse(text)
    assert parsed.short_description == text

    text = """This is a short description.

    This is a long description. This is a long description. This is a long description.
    This is a long description. This is a long description. This is a long description.
     This is a long description. This is a long description. This is a long description.
    This is a long description. This is a long description. This is a long description.
    """
    parsed = parse(text)
    assert parsed.short_description == "This is a short description."

# Generated at 2022-06-21 11:58:14.277923
# Unit test for function parse
def test_parse():
    docstring = """Summary line.

Description.

Args:
    arg1:
        Arg1 description.
    arg2:
        Arg2 description.

Returns:
    Return type

Raises:
    An error

"""
    parse(docstring)

    docstring = """Docstring without summary line.

Args:
    arg1:
        Arg1 description.
    arg2:
        Arg2 description.

Returns:
    Return type

Raises:
    An error

"""
    parse(docstring)

    docstring = """Docstring without Args and Returns.

Raises:
    An error

"""
    parse(docstring)

    docstring = """Summary line.

Description.

Args:
    arg1:
        Arg1 description.

"""

# Generated at 2022-06-21 11:58:23.550510
# Unit test for function parse
def test_parse():
    docstring = """\
    short description

    This is the long description.

    :param type_name arg_name: param desc
    :type_name param arg_name: param desc
    :param arg_name: param desc
    :param arg_name: param desc
    :param arg_name: param desc
    :rtype: return desc
    :returns: return desc
    :yields: yield desc
    :raises Exception: exception desc
    :raises Exception: exception desc
    :raises: exception desc
    :other_keyword: other keyword desc
    """
    parsed = parse(docstring)
    assert parsed.short_description == "short description"
    assert parsed.long_description == "This is the long description."
    assert parsed.blank_after_short_description
    assert not parsed.blank_after_

# Generated at 2022-06-21 11:58:35.009369
# Unit test for function parse

# Generated at 2022-06-21 11:58:41.808707
# Unit test for function parse
def test_parse():
    def assert_docstring_metadata(ds_meta, exp_meta):
        assert ds_meta.short_description == exp_meta['short_description']
        assert ds_meta.blank_after_short_description == exp_meta['blank_after_short_description']
        assert ds_meta.blank_after_long_description == exp_meta['blank_after_long_description']
        assert ds_meta.long_description == exp_meta['long_description']
        for idx in range(len(exp_meta['meta'])):
            assert ds_meta.meta[idx].args == exp_meta['meta'][idx]['args']
            assert ds_meta.meta[idx].description == exp_meta['meta'][idx]['description']

# Generated at 2022-06-21 11:58:53.796634
# Unit test for function parse
def test_parse():
    """
Test the ReST parser.
"""
    docstring = """Simple example docstring.

:param int x: First parameter.
:param int y: Second parameter.
:returns: Something.

Long description of something.

More description.
"""

    parsed = parse(docstring)

    print(parsed)

# Generated at 2022-06-21 11:59:06.025165
# Unit test for function parse
def test_parse():
    text = """\
    This is a test.

    Here is an example:
        >>> do_something("hello world")

    :param x1: This is x1.
    :param x2: This is x2.
    :type x2: int
    :param x3: This is x3.

    :param x4: This is x4.
        It has two lines.

    :param x5: This is x5. It has no indentation.
    :param str x6: This is x6.

    """
    ret = parse(text)
    assert ret is not None
    assert ret.short_description == "This is a test."
    assert ret.long_description == """\
Here is an example:
    >>> do_something("hello world")
"""
    assert ret.blank_after_short_description is True

# Generated at 2022-06-21 11:59:08.213687
# Unit test for function parse
def test_parse():
    """
    Make sure this works!
    """
    def func(x,y):
        """
        This function does nothing.
        """
        print(x, y)

# Generated at 2022-06-21 11:59:17.587737
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a short description.

    This is a long description.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :returns: This what is returned.
    :raises exception: This is what happens when this happens.
    '''

    parsed = parse(docstring)
    assert parsed.short_description == 'This is a short description.'
    assert (
        parsed.long_description == 'This is a long description.'
    )
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False

    assert len(parsed.meta) == 3

    assert parsed.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-21 11:59:24.523710
# Unit test for function parse
def test_parse():
    docstring = "This function returns the square of a given number.\n:param a: \n description of a\n:returns: the square of a"
    docstring = parse(docstring)
    assert docstring.short_description == "This function returns the square of a given number."
    assert docstring.long_description == "description of a"
    assert len(docstring.meta) == 2
    assert type(docstring.meta[0]) == DocstringParam
    assert docstring.meta[0].arg_name == "a"
    assert docstring.meta[1].description == "the square of a"
    assert type(docstring.meta[1] == DocstringReturns)
    assert docstring.meta[1].type_name == None

# test for function _build_meta

# Generated at 2022-06-21 11:59:33.097207
# Unit test for function parse
def test_parse():
    def tmpl(src, dest):
        src = inspect.cleandoc(src)
        dest = parse(src)
        assert str(dest) == inspect.cleandoc(dest)

    tmpl("""
        Short description.
        """,
        """
        Short description.
        """
    )

    tmpl("""
        Short description.

        Long description.
        """,
        """
        Short description.
        Long description.
        """
    )


# Generated at 2022-06-21 11:59:42.496227
# Unit test for function parse
def test_parse():
    from . import common
    from . import rst


# Generated at 2022-06-21 11:59:51.731011
# Unit test for function parse
def test_parse():
    from .common import Docstring, DocstringMeta, DocstringReturns, DocstringRaises
    doc = parse("""
    Short description.

    Long description.

    :type arg1: str or int
    :rtype: tuple

    :type arg2: str
    :param arg2: More information.

    :param arg3: More information.
    :keyword arg3: More information.
    :type arg3: str
    :default arg3: 'wow'

    :raises ValueError: if something goes wrong
    :raises: if something goes wrong
    :raises: some exception
    :raises ValueError:
    """)

    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert doc.blank_after_short_description
    assert doc.blank_after

# Generated at 2022-06-21 11:59:54.812759
# Unit test for function parse
def test_parse():
    print(parse("""
    This has no arguments, but may have a few keywords
    ":param name: Name of the person"""))


parse(__doc__)

# Generated at 2022-06-21 12:00:05.346895
# Unit test for function parse
def test_parse():

    #: This is the short desc.
    #:
    #: And this is the long desc.
    #:
    #: :param arg: arg desc

    def fun1():
        """This is the short desc.

        And this is the long desc.

        :param arg: arg desc
        """

    assert parse(inspect.getdoc(fun1)) == parse(fun1.__doc__)

    doc = parse(fun1.__doc__)
    assert doc.short_description == "This is the short desc."
    assert doc.long_description == "And this is the long desc."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert doc.meta[0].args == ["param", "arg"]
    assert doc.meta[0].description == "arg desc"

# Generated at 2022-06-21 12:00:19.825756
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()

    assert parse('description') == Docstring(
        short_description='description',
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description=None,
    )

    assert parse('description\n\nlong description') == Docstring(
        short_description='description',
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description='long description',
    )

    assert parse('description\n\nlong\ndescription') == Docstring(
        short_description='description',
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description='long\ndescription',
    )


# Generated at 2022-06-21 12:00:30.261619
# Unit test for function parse
def test_parse():
    assert parse(None) == Docstring()
    assert parse("") == Docstring()

    assert parse("foo").short_description == "foo"

    ds = parse("foo\n  bar\n")
    assert ds.short_description == "foo"
    assert ds.long_description == "bar"
    assert ds.blank_after_short_description
    assert not ds.blank_after_long_description

    ds = parse("foo\n\n  bar\n")
    assert ds.short_description == "foo"
    assert ds.long_description == "bar"
    assert ds.blank_after_short_description
    assert not ds.blank_after_long_description

    ds = parse("foo\n\n  bar")

# Generated at 2022-06-21 12:00:40.085282
# Unit test for function parse
def test_parse():
    s = """\
        First line.

        Second line.

        :foo:

            Some text.

        :bar:

            Some other text.
    """

    expected = Docstring(
        short_description="First line.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="Second line.",
        meta=[
            DocstringMeta(args=["foo"], description="Some text."),
            DocstringMeta(args=["bar"], description="Some other text."),
        ],
    )

    doc = parse(s)
    assert doc == expected


# Generated at 2022-06-21 12:00:46.311745
# Unit test for function parse
def test_parse():
    text = """
    This is a short description.

    This is a long description.

    :param arg1: This is the first parameter.
    :type arg1: str
    
    :param arg2: This is the second parameter.
    :type arg2: int
    
    :returns: This is the return value.
    :rtype: int, str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."

# Generated at 2022-06-21 12:00:57.053362
# Unit test for function parse
def test_parse():
    assert parse("") == parse.__annotations__["return"](None)

    assert (
        parse("""
    Short description.

    Long description.
    """)
        == parse.__annotations__["return"](
            "Short description.",
            "Long description.",
            True,
            False,
        )
    )

    assert (
        parse("""
    Short description.

    Long description.
    """)
        == parse.__annotations__["return"](
            "Short description.",
            "Long description.",
            True,
            False,
        )
    )

    assert (
        parse("""
    Short description.
    Long description.
    """)
        == parse.__annotations__["return"](
            "Short description.", "Long description.", False, False
        )
    )

   

# Generated at 2022-06-21 12:01:08.724514
# Unit test for function parse
def test_parse():
    """Check if the parser gives correct output for various docstring inputs."""

    assert parse("""
        Summaries
        --------

        Returns the sum of x and y.
    """) == Docstring(
        short_description="Summaries",
        blank_after_short_description=True,
        long_description="Returns the sum of x and y.",
        blank_after_long_description=True,
        meta=[],
    )

    docstring = """
        Returns the sum of x and y.
    """

    assert parse(docstring) == Docstring(
        short_description="Returns the sum of x and y.",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-21 12:01:19.242657
# Unit test for function parse
def test_parse():
    docstring = """
    Write the provided data to the connection.

    Returns the number of bytes written.
    :param data: A str object to send to the remote host.
    :type data: str
    :param timeout: Optional float describing the timeout of the operation.
    :type timeout: float
    :returns: The number of bytes written to the connection.
    :rtype: int
    :raises socket.error: In case of network failure.
    :raises socket.timeout: If the operation exceeds the timeout.
    """
    result = parse(docstring)
    assert result.short_description == "Write the provided data to the connection."
    assert result.long_description == """Returns the number of bytes written."""
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == True


# Generated at 2022-06-21 12:01:26.208084
# Unit test for function parse
def test_parse():
    # length of Docstring list
    assert len(parse("""
    This function is to test whether the docstring parsing is working
    properly.

    The test is done by using the default python unittest""")) == 4

    # Test if attribute `short_description` exists
    assert parse("""
    This function is to test whether the docstring parsing is working
    properly.

    The test is done by using the default python unittest""").short_description == \
           "This function is to test whether the docstring parsing is working\
    properly."

    # Test if attribute `blank_after_short_description` exists
    assert parse("""
    This function is to test whether the docstring parsing is working
    properly.

    The test is done by using the default python unittest""").blank_after_short_description == \
           True

    #

# Generated at 2022-06-21 12:01:36.176735
# Unit test for function parse
def test_parse():
    assert parse(None) == Docstring()
    assert parse("") == Docstring()
    assert parse("Description") == Docstring(
        short_description="Description",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse("Description\n") == Docstring(
        short_description="Description",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-21 12:01:44.666356
# Unit test for function parse
def test_parse():
    docstring1 = r"""
    A simple docstring.
    :param name: The name of this person.
    :type name: str
    :returns: something
    """
    docstring2 = r"""
    A simple docstring.
    :param name: The name of this person.
    :type name: str

    :returns: something"""
    docstring3 = r"""
    A simple docstring.

    :param name: The name of this person.
    :type name: str

    :returns: something"""
    docstring4 = r"""    A simple docstring.
    :param name: The name of this person.
    :type name: str

    :returns: something"""

    assert parse(docstring1).short_description == "A simple docstring."
    assert parse(docstring2).short_description

# Generated at 2022-06-21 12:01:59.678550
# Unit test for function parse
def test_parse():
    s = """
    Docstring for math.hypot

    :param x, y: Specify x and y
    :return: hypotenuse of the triangle
    """
    d = parse(s)

    assert d.short_description == "Docstring for math.hypot"
    assert d.long_description == None
    assert d.blank_after_short_description == True
    assert d.blank_after_long_description == False
    assert d.meta == [DocstringMeta(
        args=['param', 'x,', 'y:'],
        description='Specify x and y',
    ), DocstringMeta(
        args=['return:'],
        description='hypotenuse of the triangle',
    )]



# Generated at 2022-06-21 12:02:09.816074
# Unit test for function parse

# Generated at 2022-06-21 12:02:12.899896
# Unit test for function parse
def test_parse():
    docstring = parse("""
    Short description.

    Long description.
    """)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."


# Generated at 2022-06-21 12:02:19.961995
# Unit test for function parse
def test_parse():
    # test for the function parse
    # test for the return type
    assert isinstance(parse(""), Docstring)
    assert isinstance(parse("1"), Docstring)
    assert isinstance(parse("12"), Docstring)
    assert isinstance(parse("123"), Docstring)

    # test for the returned values
    assert isinstance(Docstring(), Docstring)
    assert parse("").short_description == None
    assert parse("").long_description == None
    assert parse("").blank_after_short_description == False
    assert parse("").blank_after_long_description == False
    assert parse("").meta == []
    assert not DocstringParam().arg_name
    assert not DocstringParam().type_name
    assert not DocstringParam().is_optional
    assert not DocstringReturns().type_name

# Generated at 2022-06-21 12:02:31.660324
# Unit test for function parse
def test_parse():

    text = """
    Short description.

    Long description.

    :param arg1: This is argument 1.
    :type arg1: str
    :param arg2: This is argument 2.
    :type arg2: str
    :returns: None
    :rtype: None
    """


# Generated at 2022-06-21 12:02:35.145487
# Unit test for function parse
def test_parse():
    test_string = """\
        :param str name: Name of the new list.
        :param str user_id: The user ID of the user who owns the list.
        :returns: The newly created list.
        :raises ValueError: If `name` is too long.
        """

    print(parse(test_string))


# Generated at 2022-06-21 12:02:40.399421
# Unit test for function parse
def test_parse():
    text = """Some short description.

Some long description.

:param str email: The e-mail address.
:returns: True if the e-mail address is valid
"""
    doc = parse(text)
    assert doc.short_description == 'Some short description.'
    assert doc.long_description == 'Some long description.'
    assert len(doc.meta) == 2
    assert doc.meta[0].arg_name == 'email'
    assert doc.meta[0].type_name == 'str'
    assert doc.meta[1].type_name == None

# Generated at 2022-06-21 12:02:49.845668
# Unit test for function parse
def test_parse():
    for arg in range(4):
        def f(a: int = arg, b: str = "abc") -> T.Tuple[int, str]:
            """Short description.

            Long description.

            :param a: First param.
            :type a: int
            :param b: Second param.
            :type b: string
            :raises ValueError: if b is empty.
            :returns: a, b
            :rtype: (int, str)
            """
            return a, b

        doc = parse(inspect.getdoc(f))

        assert doc.short_description == "Short description."
        assert doc.long_description == "Long description."
        assert doc.blank_after_short_description
        assert doc.blank_after_long_description

        assert len(doc.meta) == 4

# Generated at 2022-06-21 12:03:00.824391
# Unit test for function parse
def test_parse():
    example = """This is a summary.

    This is a longer description.

    :param int foo: This is foo
    :param str bar: This is bar in two lines

    :returns:
        This is the return description
        in two lines.

    :raises ValueError: This is the exception description.
    """
    parsed = parse(example)

    assert parsed.short_description == "This is a summary."
    assert parsed.long_description == "This is a longer description."
    assert not parsed.blank_after_short_description
    assert parsed.blank_after_long_description

    assert str(parsed) == example

    meta_params = parsed.meta[:2]
    meta_returns = parsed.meta[2]
    meta_raises = parsed.meta[3]


# Generated at 2022-06-21 12:03:10.859436
# Unit test for function parse
def test_parse():
    '''Unit test for function parse'''
    def foo(x: 'int') -> 'float':
        '''foo function

        :param x: x value
        :type x: int
        :returns: x / 2
        :rtype: float
        '''
        return x / 2
    foo_docstring = parse(foo.__doc__)
    assert "foo function" == foo_docstring.get_short_description()

    foo_long_description = (
        "foo function\n"
        "\n"
        ":param x: x value\n"
        ":type x: int\n"
        ":returns: x / 2\n"
        ":rtype: float"
    )
    assert foo_long_description == foo_docstring.get_long_description()
    foo_

# Generated at 2022-06-21 12:03:26.095831
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description.

    :param arg1: Description.
    :type arg1: :class:`str`
    :param arg2: Description.
    :type arg2: :class:`int`
    :returns: Something.
    :rtype: :class:`bool`
    :raises ValueError: If the value is invalid.
    """
    expected = """
    Short description.

    Long description.

    :param arg1: Description.
    :type arg1: :class:`str`
    :param arg2: Description.
    :type arg2: :class:`int`
    :returns: Something.
    :rtype: :class:`bool`
    :raises ValueError: If the value is invalid.
    """

# Generated at 2022-06-21 12:03:37.127105
# Unit test for function parse
def test_parse():
    f = """\
    This function specializes a function.

    The decorated function will only be callable when all of the given
    arguments are specified as keyword arguments.

    For example, if the decorated function takes arguments `a`, `b` and `c`
    but is decorated with arguments `a` and `c` then it can
    only be called with the following arguments: `a=x, c=z`.

    Parameters
    ----------
    *functions
        A single function or a list of functions to specialize.

    *args
        The arguments to specialize on.

    Returns
    -------
    specialized : function
        A specialized version of the function with the given arguments.
    """
    df = parse(f)
    assert df.short_description == "This function specializes a function."

# Generated at 2022-06-21 12:03:49.064520
# Unit test for function parse

# Generated at 2022-06-21 12:03:59.851438
# Unit test for function parse
def test_parse():
    docstring = '''

This is a docstring for a function.

:param arg1: argument 1
:type arg1: str
:param arg2: argument 2
:param arg3: argument 3
:raises ValueError: if something bad happens
:return: None

'''

# Generated at 2022-06-21 12:04:10.772553
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc("""\
    This is a short description.
    This is a long description.

    :param str name: The name of the foo.
    :type str name: The name of the foo.

    :param str name: The name of the foo.
    :type str name: The name of the foo.
    :param int number: The number to be converted.
    :returns: The integer number of the converted number.
    :rtype: int
    :raises: A TypeError if the input value is not a number.
    """)

    doc = parse(docstring)
    assert doc.short_description == 'This is a short description.'
    assert doc.long_description == 'This is a long description.'
    assert len(doc.meta) == 3

# Generated at 2022-06-21 12:04:22.778357
# Unit test for function parse

# Generated at 2022-06-21 12:04:30.090736
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param arg: This is a parameter.
    :type arg: int
    :param arg2: This is a parameter.
    :type arg2: str
    :raises ValueError:
    :returns: This is a return value.
    :rtype: int
    :returns: This is a second return value.
    :rtype: str
    """
    parsed = parse(docstring)

    assert parsed.short_description == "Short description."
    assert parsed.blank_after_short_description is False
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_long_description is True
    assert len(parsed.meta) == 5


# Generated at 2022-06-21 12:04:39.665026
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    This continues on the next line.

    :param arg1: This is an arg
    :param arg2: This is another arg
    :returns: This is a returns section
    """

    ret = parse(text)
    assert ret.long_description == """This is a docstring.

    This continues on the next line."""
    assert ret.short_description == "This is a docstring."
    assert ret.blank_after_short_description == False
    assert ret.blank_after_long_description == True
    assert len(ret.meta) == 3
    assert type(ret.meta[0]) == DocstringParam
    assert ret.meta[0].arg_name == "arg1"
    assert ret.meta[0].description == "This is an arg"
    assert type

# Generated at 2022-06-21 12:04:50.327980
# Unit test for function parse
def test_parse():
    # no docstring
    assert parse("") == Docstring()
    # bad meta information
    try:
        parse("::::")
        assert False, "parse should raise error on malformed docstring."
    except ParseError:
        pass
    # short and long descriptions
    assert (
        parse(
            """This is the short description.

    This is the long description.
    """
        )
        == Docstring(
            short_description="This is the short description.",
            blank_after_short_description=True,
            blank_after_long_description=False,
            long_description="This is the long description.",
            meta=[],
        )
    )
    # no long description

# Generated at 2022-06-21 12:05:00.720578
# Unit test for function parse
def test_parse(): 
    text = """
A docstring is a string literal that occurs as the first statement 
in a module, function, class, or method definition. Such a docstring becomes 
the __doc__ special attribute of that object.

All modules should normally have docstrings, and all functions and classes 
exported by a module should also have docstrings. Public methods (including 
the __init__ constructor) should also have docstrings. A package may be 
documented in the module docstring of the __init__.py file in the package 
directory.
    
:param x: int.
:keyword y: int.
:keyword z: int.
:returns: int
:raises ValueError: if x is out of range.
"""
    print(parse(text))