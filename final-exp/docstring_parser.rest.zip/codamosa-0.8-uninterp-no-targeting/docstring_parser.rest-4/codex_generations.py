

# Generated at 2022-06-21 11:55:33.473177
# Unit test for function parse
def test_parse():
    assert parse("parses plain text") == Docstring(
        short_description="parses plain text",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

    assert parse("parses\n    plain\n    text") == Docstring(
        short_description="parses",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="plain\n    text",
        meta=[],
    )


# Generated at 2022-06-21 11:55:44.127930
# Unit test for function parse
def test_parse():
    doc = """
    This is a test for the function parse().
    It can parse the docstring of a function to a Docstring class.
    :param x: the first parameter
    :type x: int
    :param y: the second parameter
    :type y: int
    :returns: the sum of x and y
    :rtype: int
    """
    d = parse(doc)

# Generated at 2022-06-21 11:55:54.889419
# Unit test for function parse
def test_parse():
    # 1
    doc_string = """
    Returns a string containing the description of the event, as
    passed to the constructor.
    """
    ret = parse(doc_string)
    assert ret.short_description == "Returns a string containing the description of the event, as passed to the constructor."
    assert ret.blank_after_short_description == False
    assert ret.blank_after_long_description == False
    assert ret.long_description == None
    assert ret.meta == []

    # 2

# Generated at 2022-06-21 11:56:04.522642
# Unit test for function parse
def test_parse():
    docstring = """Short description.

Long description.

Long description continued.

:param str user: The user's name
:param int i: the current number
:returns: The result of the operation
:rtype: int
:raises Exception:
:returns: The result of the operation
:rtype: int
:param str user: The user's name
:param int i: the current number
:returns: The result of the operation
:rtype: int
:raises Exception:
:returns: The result of the operation
:rtype: int
"""
    parsed = parse(docstring)
    # Test short description
    assert parsed.short_description == "Short description."
    # Test long description
    assert parsed.long_description == "Long description.\n\nLong description continued."
    # Test blank after short description

# Generated at 2022-06-21 11:56:15.862597
# Unit test for function parse
def test_parse():
    docstring = """\
    This is a docstring.

    This is the second line of the docstring.
    """
    doc = parse(docstring)
    assert doc.short_description == 'This is a docstring.'
    assert doc.blank_after_short_description == True
    assert doc.long_description == 'This is the second line of the docstring.'
    assert doc.blank_after_long_description == False
    assert doc.meta == []

    docstring = """\
    This is a docstring.
    """
    doc = parse(docstring)
    assert doc.short_description == 'This is a docstring.'
    assert doc.long_description == None
    assert doc.meta == []


# Generated at 2022-06-21 11:56:26.676673
# Unit test for function parse
def test_parse():
    def test_parse_fn():
        """Returns the absolute value of the argument.
        
        :param x: number
        :type x: :class:`int`
        
        :returns: absolute value of *x*
        :rtype: :class:`int`
        """
    t = parse(test_parse_fn.__doc__)
    assert t.short_description == 'Returns the absolute value of the argument.'
    assert t.long_description.split('\n') == ['        :param x: number', 
                                              '        :type x: :class:`int`',
                                              '', 
                                              '        :returns: absolute value of *x*',
                                              '        :rtype: :class:`int`']
    assert t.blank_after_short_description is True

# Generated at 2022-06-21 11:56:37.546450
# Unit test for function parse
def test_parse():
    text = """
    :param file: the file
    """
    a = parse(text)

    assert(len(a.meta) == 1)
    assert(a.meta[0].arg_name == 'file')

    text = """
    :param file: the file
    :param str name: the name
    """
    b = parse(text)

    assert(len(b.meta) == 2)
    assert(b.meta[0].arg_name == 'file')
    assert(b.meta[1].arg_name == 'name')

    text = """
    Example description

    :param file: the file
    :param str name: the name
    :yields: the name
    """
    c = parse(text)

    assert(len(c.meta) == 3)

# Generated at 2022-06-21 11:56:48.641005
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Sample docstring") == Docstring(
        short_description="Sample docstring",
    )
    assert parse("Sample docstring\n") == Docstring(
        short_description="Sample docstring",
        blank_after_short_description=True,
    )
    assert parse("Sample docstring\n\n") == Docstring(
        short_description="Sample docstring",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )
    assert parse("Sample docstring\n\nMore description.") == Docstring(
        short_description="Sample docstring",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="More description.",
    )

# Generated at 2022-06-21 11:56:53.089785
# Unit test for function parse
def test_parse():
    text = r'''
Short text.

Long text.
:param x: long
           parameter
           description
:param y: long
           parameter
           description
'''

    doc = parse(text)
    assert isinstance(doc, Docstring)
    print(repr(doc))
    assert len(doc.meta) == 2
    assert doc.meta[0].description == 'long\n           parameter\n           description'


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:56:56.777996
# Unit test for function parse
def test_parse():
    text = """
    Loop over x and y elements and calculate
    the right side of the system of equations.

    :param x: First number
    :param y: Second number
    :returns: 1+1

    """
    docstring = parse(text)
    return docstring

# Generated at 2022-06-21 11:57:19.092639
# Unit test for function parse
def test_parse():
    """Test function parse
    """
    doc = """
    Short summary

    Long summary

    :param x: parameter x
    :param y: parameter y, also supports defaults to 1
    :raises RuntimeError: RuntimeError
    :return: return
    """
    x = parse(doc)
    assert x.short_description == "Short summary"
    assert x.long_description == "Long summary"
    assert x.meta[0].description == "parameter x"
    assert x.meta[1].description == "parameter y, also supports defaults to 1"
    assert x.meta[2].description == "RuntimeError"
    assert x.meta[3].description == "return"


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:57:23.661118
# Unit test for function parse
def test_parse():
    docstring = inspect.getdoc(parse)
    assert docstring == "Parse the ReST-style docstring into its components."
    doc = parse(docstring)
    assert doc.short_description == "Parse the ReST-style docstring into its components."
    assert doc.long_description == None


# Generated at 2022-06-21 11:57:25.062184
# Unit test for function parse
def test_parse():
    # TODO: docstring
    raise NotImplementedError

# Generated at 2022-06-21 11:57:32.859215
# Unit test for function parse
def test_parse():
    # import os
    # docstring = open(os.path.join(os.path.dirname(__file__), '..', 'scrapers', 'scrape_resources', 'helper_functions.py')).read()
    # docstring = docstring.replace('"""', '')
    # print(docstring)
    docstring = '''
    This function checks for the existence of a table in SQLite database.

    :param tableName: table name as string
    :param conn: sqlite3 database connection object
    :returns: True if the table exists, False otherwise
    '''
    parsed_docstring = parse(docstring)
    print(parsed_docstring)

if __name__ == '__main__':
    test_parse()

__all__ = ["parse"]

# Generated at 2022-06-21 11:57:45.405568
# Unit test for function parse
def test_parse():
    doc = """Single line docstring."""
    parsed_doc = parse(doc)
    assert parsed_doc.short_description == "Single line docstring."
    assert parsed_doc.long_description == None
    assert parsed_doc.blank_after_short_description == False
    assert parsed_doc.blank_after_long_description == False

    doc = """
        Multi line docstring.

        With multiple paragraphs.
    """
    parsed_doc = parse(doc)
    assert (
        parsed_doc.short_description
        == "Multi line docstring.\n\nWith multiple paragraphs."
    )
    assert parsed_doc.long_description == None
    assert parsed_doc.blank_after_short_description == True
    assert parsed_doc.blank_after_long_description == False


# Generated at 2022-06-21 11:57:52.645626
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    print(parse.__name__)
    print(parse.__defaults__)
    print(parse.__code__)
    print(parse.__globals__)
    print(parse.__dict__)
    print(parse.__closure__)
    print(parse.__annotations__)
    print(parse.__kwdefaults__)

test_parse()
print(parse("""
Single line with no indent

First line of multi-line text, with some indent
    Second line of multi-line text
        Third line of multi-line text
        """).short_description)

# Generated at 2022-06-21 11:58:03.997230
# Unit test for function parse
def test_parse():
    docstring = """One line summary.

    Long description.

    :param int a: Argument A.
    :param numpy.ndarray? b: Optional argument B. Defaults to zero.
    :param c: Argument C.
    :rtype: str
    :raises ValueError: if something goes wrong.
    :raises: if something else goes wrong.
    :returns: Nothing.
    :yields int: This is a generator.
    """
    doc = parse(docstring)

    assert doc.short_description == "One line summary."
    assert doc.blank_after_short_description
    assert doc.long_description == "Long description."
    assert doc.blank_after_long_description

    assert len(doc.meta) == 7
    assert doc.meta[0].__class__ == DocstringMeta
   

# Generated at 2022-06-21 11:58:09.560404
# Unit test for function parse
def test_parse():
    doc_string = """
    This is the short description.

    This is the long description.

    :param foo: This is a parameter.
    :type foo: int
    :param bar: This is a parameter with a default value.
        Defaults to ``None``.
    :returns: This is a return value.
    :rtype: int
    :raises ValueError: This is a exception
    """
    parse(doc_string)

# Generated at 2022-06-21 11:58:16.446652
# Unit test for function parse
def test_parse():
    x = parse("""
    This is my function.

    :param arg1: The first argument
    :param arg2: The second argument
    :returns: The return value
    """)
    assert x == Docstring(
        short_description="This is my function.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[
            DocstringMeta(args=["param", "arg1"], description="The first argument"),
            DocstringMeta(
                args=["param", "arg2"], description="The second argument"
            ),
            DocstringReturns(
                args=["returns",], description="The return value"
            ),
        ],
    )

# Generated at 2022-06-21 11:58:24.518364
# Unit test for function parse

# Generated at 2022-06-21 11:58:38.026165
# Unit test for function parse
def test_parse():
    res = """
        Tests the parsing of the docstring into its various parts.

        :param arg1: First argument, defaults to 1.
        :type arg1: int
        :param arg2: Second argument, defaults to 2.
        :type arg2: int
        :returns: The sum of the arguments
        :rtype: int
        :raises TypeError: if any arguments are not integers
        
    """

# Generated at 2022-06-21 11:58:50.047216
# Unit test for function parse
def test_parse():
    '''test function'''
    docstr = '''
    This is a valid docstring.
    :param str_p: parameter
    '''
    docstr_meta = parse(docstr)
    assert docstr_meta.short_description == 'This is a valid docstring.'

    docstr = '''
    This is a docstring
    with no meta information.
    '''
    docstr_meta = parse(docstr)
    assert docstr_meta.short_description == 'This is a docstring'
    assert docstr_meta.meta == []

    docstr = '''
    This is a docstring
    with no meta information.

    :param str_p: parameter
    '''
    docstr_meta = parse(docstr)

# Generated at 2022-06-21 11:58:59.090264
# Unit test for function parse
def test_parse():
    def f_test():
        """
        This is a test function, so as to test parse .

        :param a: A is a parameter with no default
        :type a: str
        :param b: optional parameter with default 'bar'.
        :type b: str
        :param c: Optional parameter with default None
        :type c: str
        :param d: optional parameter with default b'foo'
        :type d: bytes
        :returns: returns nothing
        :raises ValueError: always
        :raises TypeError: never
        """
        pass

    docstr = f_test.__doc__
    print('Test parse(str) from docstring to docstring object:\n')
    print('Test docstring: \n%s' % docstr)
    print('\nAfter parsing: \n')

# Generated at 2022-06-21 11:59:08.662789
# Unit test for function parse
def test_parse():
    docstring = """
    Simple example function.

    :param a: first parameter
    :type a: str
    :param b: second parameter
    :type b: int
    """
    docstring_obj = parse(docstring)
    assert docstring_obj.short_description == 'Simple example function.'
    assert docstring_obj.blank_after_short_description == False
    assert docstring_obj.long_description is None
    assert docstring_obj.blank_after_long_description is None
    assert len(docstring_obj.meta) == 2
    assert docstring_obj.meta[0].args == ['param', 'a', 'first parameter']
    assert docstring_obj.meta[0].description == 'first parameter'
    assert docstring_obj.meta[1].args == ['type', 'a', 'str']

# Generated at 2022-06-21 11:59:18.037794
# Unit test for function parse
def test_parse():
    from .common import Docstring
    from .numpy import parse as np_parse
    from .google import parse as google_parse
    from .sphinx import parse as sphinx_parse
    from .recommonmark import parse as recommonmark_parse


# Generated at 2022-06-21 11:59:21.072651
# Unit test for function parse
def test_parse():
    with open('tests/examples/function_with_args.py') as f:
        text = f.read()
        print(text)
        doc = parse(text)
        assert(isinstance(doc, Docstring))
        assert(len(doc.meta))

# Generated at 2022-06-21 11:59:27.139076
# Unit test for function parse
def test_parse():

    # Case: no docstring
    assert parse("") == Docstring()
    assert parse(None) == Docstring()

    # Case: no description
    parsed = parse(":param foo:")
    assert parsed.short_description == None
    assert parsed.long_description == None
    assert parsed.blank_after_short_description == False
    assert parsed.blank_after_long_description == False

    # Case: no description, single parameter
    parsed = parse(":param foo: This is foo.")
    assert parsed.short_description == None
    assert parsed.long_description == None
    assert parsed.blank_after_short_description == False
    assert parsed.blank_after_long_description == False

# Generated at 2022-06-21 11:59:38.734686
# Unit test for function parse
def test_parse():
    doc = parse(
        """**Hello!**
This is a test.

:param integer which: is a test
:param type_name what?: is another test.
:param str source: source of data
:param type_name fallback: fallback source of data
:param type_name key: the key of the file containing the data
:param type_name data: the data to be written to the file specified by key
"""
    )
    assert len(doc.meta) == 6
    assert doc.meta[0].args == ["param", "integer", "which"]
    assert doc.meta[1].args == ["param", "type_name", "what?"]
    assert doc.meta[2].args == ["param", "str", "source"]

# Generated at 2022-06-21 11:59:49.908944
# Unit test for function parse

# Generated at 2022-06-21 12:00:01.859656
# Unit test for function parse
def test_parse():

    from .common import (
        PARAM_KEYWORDS,
        RAISES_KEYWORDS,
        RETURNS_KEYWORDS,
        YIELDS_KEYWORDS,
        Docstring,
        DocstringMeta,
        DocstringParam,
        DocstringRaises,
        DocstringReturns,
        ParseError,
    )


    # (args, desc_chunk, meta_chunk) => Docstring

# Generated at 2022-06-21 12:00:16.781764
# Unit test for function parse
def test_parse():
    # def parse(text):
    #     """Parse the ReST-style docstring into its components.
    #
    #     :param text: the docstring text
    #     :type text: str
    #
    #     :returns: parsed docstring
    #     :rtype: :class:`Docstring`
    #     """
    docstr = '''Parse the ReST-style docstring into its components.

:param text: the docstring text
:type text: str

:returns: parsed docstring
:rtype: :class:`Docstring`
'''
    actual = parse(docstr)
    assert actual.short_description == 'Parse the ReST-style docstring into its components.'
    assert actual.blank_after_short_description == True
    assert actual.blank_after_long

# Generated at 2022-06-21 12:00:27.915249
# Unit test for function parse
def test_parse():
    docstring = parse("""\
        This is a short description.

        This is a long description.
        This is a long description.
        This is a long description.

        :param type_name arg_name: description
        :param type_name arg_name: description
        :param type_name arg_name: description

        :returns: description
        :returns: description

        :raises ValueError: description
        :raises ValueError: description
        """)

    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description.\nThis is a long description.\nThis is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False


# Generated at 2022-06-21 12:00:39.335413
# Unit test for function parse

# Generated at 2022-06-21 12:00:50.691573
# Unit test for function parse
def test_parse():
    signature = "parse(text: str) -> Docstring"
    docstring_str = """\
Parse a ReST-style docstring into its components.

This docstring should be parsed into a Docstring object
representing it.

:param text: The docstring text to parse
:type text: str
:returns: The corresponding parsed Docstring object.
:rtype: :class:`~pydocstring.docstring.Docstring`
"""


# Generated at 2022-06-21 12:00:59.757508
# Unit test for function parse
def test_parse():
    text = """
    This is the short description
    with a line to long.

    Here comes the long description,
    which continues on the next line.

    :param bar: The bar param
    :type bar: int
    :raises TypeError: when bar is not an integer
    
    :param foo: Optional foo param, defaults to 42.
    :type foo: int?
    :defaults to 42
    :raises ValueError: when foo is too big.
    """
    d = parse(text)
    assert d.short_description == "This is the short description with a line to long."
    assert d.long_description == """
    Here comes the long description,
    which continues on the next line.
    """
    assert d.meta[0].arg_name == "bar"
    assert d.meta[0].type

# Generated at 2022-06-21 12:01:10.612629
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("  ") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse(":key: val") == Docstring(
        meta=[DocstringMeta(["key"], "val")]
    )
    assert parse(":key:\n val") == Docstring(
        meta=[DocstringMeta(["key"], "val")]
    )
    assert parse(":key:\n\n val") == Docstring(
        meta=[DocstringMeta(["key"], "val")]
    )
    assert parse(":key\n: val") == Docstring(
        meta=[DocstringMeta(["key:"], " val")]
    )

# Generated at 2022-06-21 12:01:20.817940
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    def test_case(text, **kwargs):
        ret = parse(text)
        expected_idt = ""
        for k, v in kwargs.items():
            assert getattr(ret, k) == v, u"{}{}".format(expected_idt, k)
            expected_idt += "  "

    test_case("Hello, world!",
              short_description='Hello, world!',
              blank_after_short_description=False,
              blank_after_long_description=False,
              long_description=None)
    test_case("Hello, world!\n",
              short_description='Hello, world!',
              blank_after_short_description=True,
              blank_after_long_description=False,
              long_description=None)


# Generated at 2022-06-21 12:01:32.071435
# Unit test for function parse
def test_parse():
    import typing as t
    def test(text, expected):
        actual = parse(text)
        assert actual == expected

    test("""""", Docstring())
    test("""
    Foo.
    """, Docstring(
        short_description="Foo.",
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description=None))

    test("""
    Foo.

    Bar.
    """, Docstring(
        short_description="Foo.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="Bar."))


# Generated at 2022-06-21 12:01:42.296938
# Unit test for function parse
def test_parse():
    text = """
    Args:
        foo (str): foo.
        bar (int): Bar. Defaults to 123.
        baz: This defaults to None.
    """


# Generated at 2022-06-21 12:01:53.168546
# Unit test for function parse
def test_parse():
    text = '''
    Short description.

    Long description.

    :param arg_name: type_name?
        Description.

    :param arg2:
        Description.

    :return: type_name
    '''
    docstring = parse(text)
    assert docstring.meta[0].arg_name == 'arg_name'
    assert docstring.meta[0].type_name == 'type_name'
    assert docstring.meta[0].is_optional == True
    assert docstring.meta[1].arg_name == 'arg2'
    assert docstring.meta[1].type_name == None
    assert docstring.meta[1].is_optional == None
    assert docstring.meta[2].arg_name == 'return'

# Generated at 2022-06-21 12:02:08.003360
# Unit test for function parse
def test_parse():
    docstring = """Convert fahrenheit to celsius.

:type  fahrenheit: float
:param fahrenheit: The temperature in fahrenheit.
:raises ValueError: When fahrenheit is less than -459.67.
:returns: The temperature in celsius.

"""

# Generated at 2022-06-21 12:02:18.157429
# Unit test for function parse
def test_parse():
    text = """
    This method does nothing.

    :param x: The first parameter.
    :param y: The second parameter
    :param z: The third parameter
    :returns: Nothing
    """
    results = parse(text)

    # Testing short description
    assert results.short_description == "This method does nothing."
    assert results.blank_after_short_description == True
    assert results.blank_after_long_description == False
    assert results.long_description == None

    # Testing metadata
    assert results.meta[0].args == ["param", "x"]
    assert results.meta[0].description == "The first parameter."
    assert results.meta[1].args == ["param", "y"]
    assert results.meta[1].description == "The second parameter"

# Generated at 2022-06-21 12:02:19.288117
# Unit test for function parse
def test_parse():
    import doctest
    return doctest.testmod(__import__(__name__))

# Generated at 2022-06-21 12:02:30.989978
# Unit test for function parse
def test_parse():
    docstring = """This is a short description.
    This is a long description.
    :param str arg1: This is an argument.
    :param str arg2: This is another argument.
    :returns: This is what is returned.
    :rtype: int
    """

# Generated at 2022-06-21 12:02:39.685039
# Unit test for function parse
def test_parse():
    text = '''
:param filepath: The path to the image file.
:param crop: Decide whether to crop image or not.
:keyword show: Decide whether to show image.
:param save: Save image or not.
:return: Image object.
'''
    parsed = parse(text)

    assert parsed.meta[0].keyword == "param"
    assert parsed.meta[0].args == ["param", "filepath"]
    assert parsed.meta[0].arg_name == "filepath"
    assert parsed.meta[0].type_name is None
    assert not parsed.meta[0].is_optional
    assert not parsed.meta[0].default
    assert parsed.meta[0].description == "The path to the image file."

    assert parsed.meta[1].keyword == "param"
    assert parsed

# Generated at 2022-06-21 12:02:49.442646
# Unit test for function parse
def test_parse():
    from . import parse_numpy
    from . import parse_google

    parse_func_list = [parse, parse_numpy.parse, parse_google.parse]


# Generated at 2022-06-21 12:03:00.373969
# Unit test for function parse
def test_parse():
    docstring = parse("""
    This is a docstring
    :param x: This is an argument.
    :param y: This is another.
    :type x: str
    :type y: list
    :returns: Something
    :rtype: str|list
    :raises ValueError: if something is wrong
    :returns: Something
    :raises ValueError: if something is wrong
    """)

    assert len(docstring.meta) == 7
    assert docstring.meta[0].args == ['param', 'x']
    assert docstring.meta[1].args == ['param', 'y']
    assert docstring.meta[2].args == ['type', 'x', 'str']
    assert docstring.meta[3].args == ['type', 'y', 'list']

# Generated at 2022-06-21 12:03:10.583260
# Unit test for function parse

# Generated at 2022-06-21 12:03:21.419864
# Unit test for function parse
def test_parse():
    text = """\
    Short description.

    Longer description.
    """
    expected = Docstring(
        short_description="Short description.",
        long_description="Longer description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert parse(text) == expected

    text = """\
    Short description.

    Longer description.

    """
    expected = Docstring(
        short_description="Short description.",
        long_description="Longer description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )
    assert parse(text) == expected

    text = """\
    Short description.

    Longer description.
    """

# Generated at 2022-06-21 12:03:34.265734
# Unit test for function parse
def test_parse():
    text_1 = """
    This is text
    """
    ret_1 = parse(text_1)
    assert ret_1.short_description == 'This is text'
    assert ret_1.long_description == None
    assert len(ret_1.meta) == 0
    assert ret_1.blank_after_short_description == True
    assert ret_1.blank_after_long_description == False

    text_2 = """
    This is text
    =================
    """
    ret_2 = parse(text_2)
    assert ret_2.short_description == 'This is text'
    assert ret_2.long_description == None
    assert len(ret_2.meta) == 0
    assert ret_2.blank_after_short_description == False
    assert ret_2.blank_after_long_

# Generated at 2022-06-21 12:03:51.319776
# Unit test for function parse
def test_parse():
    docstring = """ summary
    description
    :param int a: some description

    :param bool b=True: description2
    :param float c: description3
    :param str d: description4
    :param bytes e: description5
    :type f: int
    :param bytes h: description6
    :type g: int
    :return: None
    :rtype: None
    """

# Generated at 2022-06-21 12:03:57.692676
# Unit test for function parse
def test_parse():
    docstring = """
    A summary of this class.
    
    A longer description of this class.
    
    :param param1: The first parameter.
    :type param1: str
    :param param2: The second parameter.
    :type param2: int, optional

    :returns: Description of return value.
    :rtype: int
    
    :raises TypeError: If an invalid type is passed.
    
    :raises ValueError: If an invalid value is passed.
    """

# Generated at 2022-06-21 12:04:02.304739
# Unit test for function parse
def test_parse():
    text = """first line
second line.
blah blah

:param x str: first param.
:param y str, optional: second param. defaults to 0.
:returns: something
:yields: something
:raises ValueError: if something fails"""

    assert parse(text)

# Generated at 2022-06-21 12:04:11.941265
# Unit test for function parse

# Generated at 2022-06-21 12:04:13.077434
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:04:22.892842
# Unit test for function parse
def test_parse():
    docstring = '''Example docstring

        :param a: this is a param
        :type a: str
        :param b: this is a second param
        :type b: int
        :returns dict:
        :returns: dict
        :raises Exception: when the system is down
    '''
    parsed_docstring = parse(text=docstring)
    assert parsed_docstring.short_description == 'Example docstring'
    assert len(parsed_docstring.meta) == 5
    assert isinstance(parsed_docstring.meta[0], DocstringParam)
    assert isinstance(parsed_docstring.meta[4], DocstringRaises)

# Generated at 2022-06-21 12:04:30.145365
# Unit test for function parse
def test_parse():
    doc='\n'.join(['short description',
                   '',
                   'long description',
                   '',
                   ':par a: description',
                   ':returns: description',
                   ':raises a: description'])

# Generated at 2022-06-21 12:04:31.161773
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:04:40.341080
# Unit test for function parse

# Generated at 2022-06-21 12:04:50.777617
# Unit test for function parse
def test_parse():
    docstring = parse(
        """The summary line for a function.

        This is a multi-line description. The first line starts with a
        capital letter and ends with a dot.  Subsequent lines are indented.
        The whole thing may be arbitrarily long.

        :param int x: The x value to say hello to.
        :returns: The string "hello x".
        """
    )

    assert docstring.short_description == "The summary line for a function."
    assert docstring.long_description == (
        "This is a multi-line description. The first line starts with a "
        "capital letter and ends with a dot.  Subsequent lines are indented. "
        "The whole thing may be arbitrarily long."
    )
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_

# Generated at 2022-06-21 12:05:01.234442
# Unit test for function parse
def test_parse():
    docstring = """
    Parameters
    ----------
    style: str, Style to be applied to the graph
    """

    result = parse(docstring)
    assert len(result.meta) == 1
    param = result.meta[0]
    assert isinstance(param, DocstringParam)
    assert param.arg_name == 'style'
    assert param.type_name == 'str'
    assert param.is_optional is False
