

# Generated at 2022-06-21 11:55:26.272178
# Unit test for function parse
def test_parse():
    doc = """
    Parses a ReST-style docstring into its components.

    :param text: The docstring to parse.
    :type text: str
    :returns: parsed docstring
    :rtype: `Docstring`
    """
    parsed = parse(doc)
    assert parsed
    assert parsed.short_description == "Parses a ReST-style docstring into its components."
    assert parsed.long_description == """
:param text: The docstring to parse.
:type text: str
:returns: parsed docstring
:rtype: `Docstring`
"""
    assert parsed.meta[0].args == ['param', 'text', 'type', 'str']
    assert parsed.meta[1].args == ['returns', 'rtype', 'Docstring']


# Generated at 2022-06-21 11:55:27.861634
# Unit test for function parse
def test_parse():
    # TODO
    assert False

# Generated at 2022-06-21 11:55:39.167933
# Unit test for function parse
def test_parse():
    docstr = """
    This is a short description
    
    This is a long description
    
    :param arg1: Description of argument arg1
    :type arg1: The type of argument
    :param arg2: Description of argument arg2
    :raises exception: Description of exception
    :returns: Description of returns
    :rtype: Type of returns
    """
    doc = parse(docstr)
    assert doc.short_description == "This is a short description"
    assert doc.long_description == "This is a long description"
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-21 11:55:46.063216
# Unit test for function parse
def test_parse():
    """Test function parse"""
    from .common import Docstring
    
    d = Docstring()
    text = """
    This is a test for the parse function. 
    
    It should take a docstring and return a Docstring object.
    
    It raises an error if there's something wrong.
    """
    print(parse(text))
    print(d)
    # assert parse(text) == d, 'parse is not working'


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:55:55.506977
# Unit test for function parse
def test_parse():
    docstring = """Summary line.

    Description of the first paragraph.

    Description of the second paragraph.

    :returns: Description of the return value.
    :rtype: str

    """
    parsed = parse(docstring)
    assert parsed.short_description  == 'Summary line.'
    assert parsed.long_description  == 'Description of the first paragraph.\n\nDescription of the second paragraph.'
    assert len(parsed.meta) == 1
    assert str(parsed.meta[0]) == ":returns:\nDescription of the return value."
    assert parsed.meta[0].arg_name == parsed.meta[0].type_name == None


# Generated at 2022-06-21 11:55:59.856543
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc("""\
        My description

        :param foo: Lorem ipsum
        :type foo: str
        :param bar: Dolor sit amet
        :param baz: Consectetur adipiscing elit.
        :type baz: int
        :raises SomeException: Optional type.
        :raises OtherException: If foo was True and baz was False.
        :yields: Lorem
        :yields: Ipsum
        :yields int: Dolor sit
        :yield int: Amet
        :returns: Consectetur.
        :rtype: str
        """)
    assert docstring == parse(docstring).dump()

# Generated at 2022-06-21 11:56:07.472352
# Unit test for function parse
def test_parse():
    assert parse("""
    Short desc.

    Long desc.
    """) == Docstring(
        short_description="Short desc.",
        long_description="Long desc.",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

    assert parse("""
    Short desc.

    Long desc.


    """) == Docstring(
        short_description="Short desc.",
        long_description="Long desc.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

    assert parse("Short desc.") == Docstring(
        short_description="Short desc.",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
    )


# Generated at 2022-06-21 11:56:13.701999
# Unit test for function parse
def test_parse():
    docstring = """\
        Test function for parsing the docstring.

        :param foo: foo
        :type foo: int
        :param bar: bar
        :type bar: str
        :param optional?: bla bla
        :type optional?: str
        :param defaults_to?: defaults to 42.
        :type defaults_to?: int

        :returns: None
        """
    assert parse(docstring)

# Generated at 2022-06-21 11:56:24.890425
# Unit test for function parse
def test_parse():
    docstring = '''
    Test the docstring parse

    This docstring should be parsed into :
     - short_description
     - long_description
     - meta information

    :param str name:
        The name of something
    :param id id:
        The id of something
    :param obj obj:
        The object of something
    :param obj|None obj_none:
        The object of something that can be None
    :param obj|None obj_none?:
        Another object of something that can be None but is optional
    :param name=None name:
        The name of something with a default
    :raises ValueError:
        If that's the case
    '''

    parsed = parse(docstring)
    assert parsed.short_description == 'Test the docstring parse'

# Generated at 2022-06-21 11:56:36.306344
# Unit test for function parse
def test_parse():
    text = """\
        Test function.
        :returns: bool -- whether the test passed
        :raises ValueError: if it couldn't parse the data
    """
    ret = parse(text)
    assert ret.short_description == "Test function."
    assert not ret.blank_after_short_description
    assert ret.long_description == None
    assert ret.blank_after_long_description
    assert ret.meta[0].keyword == "returns"
    assert ret.meta[0].arg_name == None
    assert ret.meta[0].type_name == "bool"
    assert ret.meta[0].is_generator == False
    assert ret.meta[0].is_optional == False
    assert ret.meta[0].default == None

# Generated at 2022-06-21 11:56:46.157452
# Unit test for function parse
def test_parse():

    docstring = """
        Description of a function

        :param str name: The name of the entity
        :param int age: The age of the entity
        :param str address: The address of the entity
        :return: The status of the entity
        :rtype: str
        :raises: ValueError
    """
    parsed_docstring = parse(docstring)
    print(parsed_docstring)

# Generated at 2022-06-21 11:56:47.634494
# Unit test for function parse
def test_parse():
    assert repr(parse("foo")) == repr(Docstring())



# Generated at 2022-06-21 11:56:55.964549
# Unit test for function parse

# Generated at 2022-06-21 11:57:06.614744
# Unit test for function parse
def test_parse():
    doc = parse(
"""
Function to test parse.

:param s: some string

:param d: dictionary to test parsing

:param e: trivial third option

:param g: some string

:param f: dictionary to test parsing

:param h: trivial third option

"""
    )

    assert doc.short_description == "Function to test parse."
    assert doc.blank_after_short_description
    assert doc.long_description == None
    assert doc.blank_after_long_description
    assert len(doc.meta) == 6
    assert doc.meta[0].args == ['param', 's', 'some string']
    assert doc.meta[0].description == 'some string'
    assert doc.meta[0].arg_name == 'some string'

# Generated at 2022-06-21 11:57:14.024344
# Unit test for function parse
def test_parse():
    """Function to test the parse function."""

# Generated at 2022-06-21 11:57:25.646316
# Unit test for function parse
def test_parse():
    input_ = '''
    :param int a: a is an integer.
    :param b: b is a default str
    :param c: b is a string with possible values [1, 2, 3]
    :type c: str
    
    :returns: return statement.
    :rtype: int
    '''
    output = parse(input_)
    assert len(output.meta) == 4
    for i in output.meta:
        assert i.args == ['param', 'b'] or \
               i.args == ['param', 'c'] or \
               i.args == ['param', 'int', 'a'] or \
               i.args == ['returns']
        assert i.arg_name == 'b' or i.arg_name == 'c' or i.arg_name == 'a'
        assert i

# Generated at 2022-06-21 11:57:33.181534
# Unit test for function parse
def test_parse():
    """Test parsing of docstring."""
    # Test parsing of meta info
    docstring_text = """This is a summary.
        
        This is the description.
        
        :param s: This is a parameter description.
        :type s: str
        :param i: This is a parameter description.
        :type i: int
        """
    docstring = parse(docstring_text)
    assert docstring.short_description == "This is a summary."
    assert docstring.long_description == "This is the description."
    assert len(docstring.meta) == 2
    assert docstring.meta[0].description == "This is a parameter description."
    assert docstring.meta[0].arg_name == "s"
    assert docstring.meta[0].type_name == "str"

# Generated at 2022-06-21 11:57:45.674001
# Unit test for function parse
def test_parse():
    docstring = parse('''
    This is a test function.
    ''')
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == None

    docstring = parse('''
    This is a test function.

    This is a long description.
    ''')
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == 'This is a long description.'


# Generated at 2022-06-21 11:57:53.767364
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description.

    :param x: parameter x
    :type x: int
    :param y: parameter y
    :type y: int
    :param z: parameter z
    :type z: float

    :returns: returns something
    :rtype: str
    :returns: returns another thing
    :rtype: bool

    :raises TypeError: when something bad happens
    """
    doc = parse(text)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert doc.meta[0].args == ["param", "x", "y", "z"]

# Generated at 2022-06-21 11:58:05.243673
# Unit test for function parse
def test_parse():
    def f1():
        """This is a simple function.
        :param a: An obligatory parameter
        :param b: An optional parameter, defaults to c.
        """
        pass

    def f2():
        """This is a simple function.

        :param a: An obligatory parameter
        :param b: An optional parameter, defaults to c.
        """
        pass

    d1 = parse(inspect.getdoc(f1))
    d2 = parse(inspect.getdoc(f2))

    assert d1 == d2

    assert getattr(d1, "short_description") == "This is a simple function."
    assert getattr(d1, "long_description") == None
    assert getattr(d1, "blank_after_short_description") == False

# Generated at 2022-06-21 11:58:16.862329
# Unit test for function parse
def test_parse():
    test_str = inspect.cleandoc("""
        A docstring
    
        :param name: a name
        :param age: an age (defaults to 42)
        :yields: an integer
        """)
    doc = parse(test_str)
    assert doc.short_description == "A docstring"
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ['param', 'name']
    assert doc.meta[0].description == 'a name'
    assert doc.meta[1].args == ['param', 'age']
    assert doc.meta[1].description == 'an age (defaults to 42)'

# Generated at 2022-06-21 11:58:24.900317
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    assert parse("") == Docstring()
    assert (
        parse("""
        One sentence summary.

        More sentences go here.
        """)
        == Docstring(
            short_description="One sentence summary.",
            blank_after_short_description=False,
            blank_after_long_description=True,
            long_description="More sentences go here.",
            meta=[],
        )
    )
    assert (
        parse("One sentence summary.\n")
        == Docstring(
            short_description="One sentence summary.",
            blank_after_short_description=True,
            blank_after_long_description=True,
            long_description=None,
            meta=[],
        )
    )

# Generated at 2022-06-21 11:58:36.041682
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    # short desc + meta
    doc = parse(
        """\
        short desc
        :keyword: argument
        """
    )
    assert doc.short_description == "short desc" \
        and doc.long_description is None \
        and doc.meta[0].args == ["keyword", "argument"]

    # short desc + long desc
    doc = parse(
        """\
        short desc
        long desc
        """
    )
    assert doc.short_description == "short desc" \
        and doc.long_description == "long desc"

    # short desc + long desc + meta
    doc = parse(
        """\
        short desc
        long desc
        :keyword: argument
        """
    )
    assert doc.short_description == "short desc"

# Generated at 2022-06-21 11:58:46.537553
# Unit test for function parse
def test_parse():
    """Parse docstring text and return Docstring object."""
    doc = """\
    This is the short description.

    This is the long description.

    :param int param1: The first parameter.
    :param param2: The second parameter
    :type param2: str
    :returns: None\
    """
    docstring = parse(doc)
    assert type(docstring) is Docstring
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == "This is the long description."
    assert len(docstring.meta) == 3
    meta1 = docstring.meta[0]
    assert meta1.type == "DocstringParam"
    assert meta1.args == ['param1', 'int']
    assert meta1.description == "The first parameter."

# Generated at 2022-06-21 11:58:57.015605
# Unit test for function parse
def test_parse():
    assert parse("   ") == Docstring()
    assert parse(" hi \n \n there ") == Docstring(
        short_description="hi",
        blank_after_short_description=True,
        long_description="there",
        blank_after_long_description=False,
        meta=[],
    )

    with pytest.raises(ParseError):
        parse(" : hi : there")

    with pytest.raises(ParseError):
        parse(" hi : there")

    with pytest.raises(ParseError):
        parse("hi : a\n:a : b")


# Generated at 2022-06-21 11:59:06.695828
# Unit test for function parse
def test_parse():
    test_string = """
    Test docstring for function.
    
    :param test: test
    :returns test: test
    """
    test_parsed = parse(test_string)
    assert test_parsed._short_desc == "Test docstring for function."
    assert test_parsed._long_desc == None
    assert test_parsed._end_with_blank == True
    assert test_parsed._meta[0]._args == ['param', 'test']
    assert test_parsed._meta[0]._desc == 'test'
    assert test_parsed._meta[1]._args == ['returns', 'test']
    assert test_parsed._meta[1]._desc == 'test'

# Generated at 2022-06-21 11:59:16.290540
# Unit test for function parse
def test_parse():
    text = """
    This is a short description.

    This is the long description.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description

    text = "This is an invalid docstring.\n\n"
    docstring = parse(text)
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description

    text = """
    This is a short description. This is the long description.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring

# Generated at 2022-06-21 11:59:24.083566
# Unit test for function parse
def test_parse():
    parse("this is a single line docstring.")
    parse(" ""this is a triple quoted docstring."" ")
    parse("""
    this is a
    multiple line docstring.
    """)
    parse("""
    this is a
        multiple line docstring.
    """)
    parse("""
    this is a
        multiple line
        docstring.
    """)
    parse("""
    this is a
        multiple line
            indented docstring.
    """)
    parse("""this is an
    extremely long docstring
    that turns out to be
    wrapped across multiple
    lines, but was
    actually the product of
    some kind of magic
    source code formatter.
    """)

# Generated at 2022-06-21 11:59:35.906844
# Unit test for function parse
def test_parse():
    ds = parse("""\
        This is a short description.

        This is a long description.

        :param int alpha: A parameter description.

        :param int beta: A parameter description.
        """)

    # Check the short description
    assert ds.short_description == "This is a short description."
    assert ds.blank_after_short_description == True
    assert ds.long_description == "This is a long description."
    assert ds.blank_after_long_description == False

    # Check metadata
    assert len(ds.meta) == 2

    assert isinstance(ds.meta[0], DocstringParam)
    assert ds.meta[0].key == "param"
    assert ds.meta[0].type_name == "int"

# Generated at 2022-06-21 11:59:43.992104
# Unit test for function parse
def test_parse():
    assert parse("""
    This is a function
    """) == Docstring(
        short_description="This is a function",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("""
    This is a function

    This is a long description.

    This is another line in the long description.
    """) == Docstring(
        short_description="This is a function",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="This is a long description.\nThis is another line in the long description.",
        meta=[],
    )


# Generated at 2022-06-21 11:59:56.102401
# Unit test for function parse
def test_parse():
    """
    >>> test_parse()
        True
    """
    text = '''
    >>> parse('abcd')
    Docstring(short_description='abcd', blank_after_short_description=True, long_description=None, blank_after_long_description=True, meta=[])
    '''
    print(locals())
    return True

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:00:00.653061
# Unit test for function parse
def test_parse():
    docstring = """
    A simple test function.

    This function was written for testing *pydocstyle*.

    :param x: first parameter
    :param y: second parameter
    :returns int: a return value

    """
    print("test_parse ->")
    doc = parse(docstring)
    assert doc.short_description == "A simple test function."
    assert doc.long_description == (
        "This function was written for testing *pydocstyle*."
    )
    assert doc.meta
    assert len(doc.meta) == 2
    assert doc.meta[0].arg_name == "x"
    assert doc.meta[0].type_name is None
    assert doc.meta[0].is_optional is None
    assert doc.meta[0].default is None

# Generated at 2022-06-21 12:00:10.317442
# Unit test for function parse
def test_parse():
    func = lambda text: parse(text).__dict__
    assert func("Simple docstring.") == {
        "short_description": "Simple docstring.",
        "long_description": None,
        "meta": [],
        "blank_after_short_description": True,
        "blank_after_long_description": None,
    }

    assert func("Longer\ndocstring.") == {
        "short_description": "Longer",
        "long_description": "docstring.",
        "meta": [],
        "blank_after_short_description": False,
        "blank_after_long_description": True,
    }


# Generated at 2022-06-21 12:00:18.715349
# Unit test for function parse
def test_parse():
    assert parse("Hello, world!") == Docstring(
        short_description="Hello, world!",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse("Hello, world!\n\nfoo\nbar\n\n") == Docstring(
        short_description="Hello, world!",
        long_description="foo\nbar",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-21 12:00:29.467932
# Unit test for function parse
def test_parse():
    d = parse("""
One line description.

:param a: description
:type a:  int
:param b: description
:returns:
:rtype: int
    """)
    assert d.short_description == "One line description."
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert len(d.meta) == 2
    assert d.meta[0].args == ['param', 'a']
    assert d.meta[0].description == 'description'
    assert d.meta[0].arg_name == 'a'
    assert d.meta[0].type_name == 'int'
    assert d.meta[0].is_optional == False
    assert d.meta[0].default == None


# Generated at 2022-06-21 12:00:41.213078
# Unit test for function parse
def test_parse():
    """
    Check parsing for docstrings
    """
    import pytest
    from .common import Docstring

    def f1():
        """
        Print the docstring of a function.
        """
        pass

    def f2():
        """
        Print the docstring of a function.
        :param x: a parameter
        """
        pass

    def f3(x):
        """
        Print the docstring of a function.
        :type x: int
        """
        pass

    def f4(x: int):
        """
        Print the docstring of a function.
        """
        pass

    def f6():
        """
        Print the docstring of a function.
        :param x: a parameter
        :type x: int
        :param y: a parameter
        :type y: int
        """


# Generated at 2022-06-21 12:00:52.893076
# Unit test for function parse
def test_parse():
    docstring = """
    Single line docstring.
    """
    assert parse(docstring) == Docstring(
        short_description="Single line docstring.",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    docstring = """
    Single line docstring.

    And now a longer description.
    """
    assert parse(docstring) == Docstring(
        short_description="Single line docstring.",
        long_description="And now a longer description.",
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-21 12:01:00.778825
# Unit test for function parse
def test_parse():
    header = """
        Test parse docstring

        Test the funciton parse

        :param text: text to parse
        :return: Document object
        :type text: str
        :raises ParseError: if there is a parse error
    """

# Generated at 2022-06-21 12:01:11.900181
# Unit test for function parse
def test_parse():
    docstring = parse(
    """Summary line.

    Extended description.

    :param int count: Number of something.
    :param str name: The name of someone.
    :param bool verified: Was verified? Defaults to False.

    :raises AttributeError: The ``Blah`` attribute is not set
    :returns int: The return value
    :returns: None
    """
    )
    assert docstring.short_description == "Summary line."
    assert docstring.long_description == "Extended description."
    assert len(docstring.meta) == 5
    assert isinstance(docstring.meta[0], DocstringParam)
    assert isinstance(docstring.meta[1], DocstringParam)
    assert isinstance(docstring.meta[2], DocstringParam)

# Generated at 2022-06-21 12:01:21.630463
# Unit test for function parse
def test_parse():
    test1 = (
        """Return the square of a number.

        :param int num: The number to be squared.
        :return: num ^ 2
        """
    )
    doc1 = parse(test1)
    assert len(doc1.meta) == 1
    assert isinstance(doc1.meta[0], DocstringParam)
    assert doc1.meta[0].type_name == "int"
    assert doc1.meta[0].arg_name == "num"
    assert doc1.meta[0].is_optional is None
    assert doc1.meta[0].default is None
    assert doc1.meta[0].description == "The number to be squared."


# Generated at 2022-06-21 12:01:36.515909
# Unit test for function parse
def test_parse():
    """
    Unit test for function parse
    :return:
    """
    doc = """
    This is a test for the parse function
    :param arg1: test arg
    :type arg1: number
    :param arg2: another test arg
    :type arg2: bool
    :returns: A number
    :raises ValueError: if args are invalid
    """
    parsed = parse(doc)
    assert len(parsed.meta) == 3
    assert parsed.short_description == "This is a test for the parse function"
    assert parsed.long_description == "A number\nif args are invalid"
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].type_name == "number"
    assert parsed.meta[0].is_optional == None

# Generated at 2022-06-21 12:01:38.160946
# Unit test for function parse
def test_parse():
    docstring = inspect.getdoc(parse)
    assert docstring == str(parse(docstring))


# Generated at 2022-06-21 12:01:45.892577
# Unit test for function parse

# Generated at 2022-06-21 12:01:56.170481
# Unit test for function parse
def test_parse():
    import inspect
    import shutil
    import tempfile
    import doct
    import os
    import filecmp
    # Test loads doctstring from file, parses it and compares with doct.parse output
    with tempfile.TemporaryDirectory() as tmpdirname:
        temp_file = tempfile.mktemp(suffix='.py', dir = tmpdirname) 
        shutil.copyfile('doct/tests/data/example_00.py', temp_file) 
        doct.parse(temp_file)
        temp_file_parsed = tempfile.mktemp(suffix='.py', dir = tmpdirname) 
        shutil.copyfile('doct/tests/data/example_00_doct_parse.py', temp_file_parsed) 

# Generated at 2022-06-21 12:01:59.751622
# Unit test for function parse
def test_parse():
    result = parse.__doc__
    assert isinstance(result, str)
    assert result == 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring'



# Generated at 2022-06-21 12:02:08.149437
# Unit test for function parse
def test_parse():
    input = """
    Create an empty numpy array

    Create an empty numpy array

    :param: len: array length
    :type len: int
    :returns: numpy array
    """

# Generated at 2022-06-21 12:02:18.198587
# Unit test for function parse
def test_parse():
    docstr = inspect.cleandoc("""
        Function to add two numbers.

        :param x: First number
        :type x: int
        :param y: Second number
        :type y: int
        :returns: Sum of two numbers
        :rtype: int
        """)

# Generated at 2022-06-21 12:02:18.690977
# Unit test for function parse
def test_parse():
    parse("hello world")

# Generated at 2022-06-21 12:02:30.386158
# Unit test for function parse
def test_parse():
    assert parse("Hello World!") == Docstring(
        short_description="Hello World!",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description=None,
        meta=[],
    )

    assert parse("Hello World!\n\nGoodbye World!") == Docstring(
        short_description="Hello World!",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="Goodbye World!",
        meta=[],
    )


# Generated at 2022-06-21 12:02:36.368961
# Unit test for function parse
def test_parse():
    docstring = """
        First line of short description.

        Long description with line break.

        :param arg: arg description.
        :type arg: str
        :param arg2: arg2 description.
        :type arg2: int
        :raises FooError: foo error description.
        :returns: returns description.
        :rtype: str
    """
    assert parse(docstring) is not None

parse.__test__ = False  # type: ignore

# Generated at 2022-06-21 12:02:56.952484
# Unit test for function parse
def test_parse():
    # Test creates a variety of docstrings which should all be parsed well
    
    # Test for no doc string
    assert parse("") == Docstring([], None, None, False, False, None)

    # Test for doc string with only short description
    assert parse("This is a short description.") == Docstring(
            [], "This is a short description.", None, False, False, None)

    # Test for doc string with short description, blank line, and long description
    assert parse("This is a short description.\n\nThis is a long description.") == Docstring(
            [], 
            "This is a short description.", 
            "This is a long description.",
            True,
            False,
            None
            )

    # Test for doc string with short description, blank line, long description, two blank lines

# Generated at 2022-06-21 12:03:07.972220
# Unit test for function parse
def test_parse():
    s = inspect.cleandoc("""
        Test function for parse().

        Test parsing a docstring.

        Args:
            arg1 (str, optional): First arg. Defaults to 'abc'.
            arg2 (int, optional): Second arg.
            arg3 (Optional[int]): Third arg.

        Yields:
            bool: Whether the test was successful.
    """)

    result = parse(s)
    assert result.short_description == 'Test function for parse().'
    assert result.blank_after_short_description
    assert result.long_description is None
    assert result.blank_after_long_description

# Generated at 2022-06-21 12:03:15.307570
# Unit test for function parse
def test_parse():
    get_doc = ['Returns', 'returns_user']
    get_doc2 = ['Returns', 'returns_user_2']
    get_doc3 = ['Returns', 'returns_user_3']
    get_doc4 = ['Returns', 'returns_user_4']


# Generated at 2022-06-21 12:03:24.501233
# Unit test for function parse

# Generated at 2022-06-21 12:03:36.235457
# Unit test for function parse
def test_parse():
    docstring = 'This is a short description.\n    This is a long description.\n\n    :param int count: Long description for count\n    :param str name: Long description for name.\n    :raises NotImplementedError: If not implemented.\n    :returns: long description for returns.\n    :rtype: int.\n    '
    result = parse(docstring)
    assert result.short_description == 'This is a short description.'
    assert result.long_description == 'This is a long description.'
    assert result.blank_after_short_description
    assert result.blank_after_long_description
    assert len(result.meta) == 4
    assert result.meta[0].args == ['param', 'int', 'count']

# Generated at 2022-06-21 12:03:48.280561
# Unit test for function parse
def test_parse():
    docstring = """
    Test a docstring.

    This is the long description. See the following meta information.

    Parameters
    ----------
    arg: int
        Test a keyword argument.
    kwarg: str
        Test a keyword argument.
    kwonlyarg: str
        Test a keyword-only argument.
    kwonlyarg2: str
        Test a second keyword-only argument.
    kwonlyarg3: str
        Test a third keyword-only argument.
    """  # noqa


# Generated at 2022-06-21 12:03:59.243933
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    docstring = parse("""
        One-line description.


        One-line empty line above.

        And a multi-line
        extra desc below.

        :param x:
        :type x: int
        :returns:
        :rtype: str

        :param y:
        Description of y.

        :type y: int
        :returns:
        Description of returns.

        :rtype: int

        :param z:
        :type z: int
        :param w:
        :type w: int

        :raises ValueError:
        :raises MyError:
        :raises:
    """)
    assert docstring.short_description == "One-line description."
    assert docstring.blank_after_short_description

# Generated at 2022-06-21 12:04:06.437850
# Unit test for function parse
def test_parse():
    ds = '''
    Here is a description.

    :param user: The name of the user.
    :param age: The age of the user.
    :example:
        some example.
    :returns: A string.
    :rtype: str
    :raises ValueError: If the value is not a number.

    :param action: The action
    '''

    d = parse(ds)
    print(d)

# Generated at 2022-06-21 12:04:14.224381
# Unit test for function parse
def test_parse():
    docstring = """This is the first line of the docstring.
    This is the second line of the docstring.

    :param arg1: this is the first argument
    :param arg2: this is the second argument
    :param arg3: this is the third argument,
    which spans multiple lines.
    :return: return value
    :raises arg4: raised when `arg2` is equal to `arg1`
    """

# Generated at 2022-06-21 12:04:25.552965
# Unit test for function parse
def test_parse():
  assert parse("asdf") == Docstring(
      short_description="asdf",
      blank_after_short_description=False,
      blank_after_long_description=False,
      long_description=None,
      meta=[],
  )
  assert parse("asdf\n\njkl") == Docstring(
      short_description="asdf",
      blank_after_short_description=True,
      blank_after_long_description=False,
      long_description="jkl",
      meta=[],
  )

# Generated at 2022-06-21 12:04:42.684373
# Unit test for function parse
def test_parse():
    docstring = '''\
    This is the docstring.

    :param a: this is a
    :type a: int
    :param b: this is b
    :type b: string
    :param c: this is c
    :type c: list
    :returns: dict

    '''
    doc = parse(docstring)
    assert doc.short_description == 'This is the docstring.'
    assert doc.long_description is None
    assert doc.blank_after_short_description is True
    assert doc.blank_after_long_description is False

    assert len(doc.meta) == 4
    param_a = doc.meta[0]
    assert isinstance(param_a, DocstringParam)
    assert not param_a.is_optional
    assert param_a.description == 'this is a'

# Generated at 2022-06-21 12:04:45.578121
# Unit test for function parse
def test_parse():
    test_string = '    This is a docstring.\n\n    There are two paragraphs.'
    test_doc = parse(test_string)
    assert test_doc.short_description == 'This is a docstring.'
    assert test_doc.blank_after_short_description
    assert test_doc.long_description == 'There are two paragraphs.'
    assert not test_doc.blank_after_long_description


# Generated at 2022-06-21 12:04:48.867400
# Unit test for function parse
def test_parse():
    assert (
        inspect.cleandoc(parse.__doc__)
        == """
        Parse the ReST-style docstring into its components.

        :returns: parsed docstring
        """
    )



# Generated at 2022-06-21 12:05:00.100119
# Unit test for function parse