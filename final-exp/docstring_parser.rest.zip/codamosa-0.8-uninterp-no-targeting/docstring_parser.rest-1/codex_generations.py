

# Generated at 2022-06-21 11:55:32.250372
# Unit test for function parse
def test_parse():
    assert len(parse("""
        Short line.

        Long
        line.

         :param name: The name.
         :param age: The age.
         :type age: int
         :raises TypeError
         :returns: The return value.
         :rtype: int, str
    """).meta) == 4

# Generated at 2022-06-21 11:55:42.838610
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    # Single line short description
    assert parse("Short desc") == Docstring(
        short_description="Short desc",
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    # Single line short description, followed by white space
    assert parse("Short desc    ") == Docstring(
        short_description="Short desc",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )
    # Single line short description, immediately followed by meta description

# Generated at 2022-06-21 11:55:50.608632
# Unit test for function parse
def test_parse():
    construct = Docstring()
    construct.short_description="Takes a Python object and returns a string by parsing the object"
    construct.blank_after_short_description= True 
    construct.blank_after_long_description= True
    construct.long_description="This is a docstring for the method.\nThis is a test method for parsing the docstring."
    param = DocstringParam(args=["param", "obj"], description="The object to be processed", arg_name="obj", type_name="object", is_optional="False", default="None")
    # param = DocstringParam(obj)
    # print(param)
    # construct.meta = construct.meta.append(param)
    # print(construct.meta[0])
    returns = DocstringReturns(args=["returns"], description="String representing the object")
    #

# Generated at 2022-06-21 11:55:52.884298
# Unit test for function parse
def test_parse():
    from .tests.test_parse import test_parse
    test_parse(parse, "ReST")

# Generated at 2022-06-21 11:56:03.118785
# Unit test for function parse
def test_parse():
    text = """
    random docstring
    :param foo: random description
    :param foo2: random description2
    :type foo2: str
    :type foo: a class
    :return: random description 
    :rtype: a class
    :raises: random description
    :raises: random description2
    :raises: random description3
    :raises ValueError: random description4
    """

    docstring = parse(text)
    assert docstring.short_description == "random docstring"
    assert docstring.long_description == "random description\nrandom description2"
    assert docstring.blank_after_long_description is True
    assert docstring.blank_after_short_description is False

    assert isinstance(docstring.meta, list)
    assert len(docstring.meta) == 7
   

# Generated at 2022-06-21 11:56:14.445760
# Unit test for function parse
def test_parse():
    docstring = parse('''
        Test function for the parse function of ReSTParser.

        In the long description, we have these things:

        Args:
            arg1 (int): the first parameter
            arg2 (str): the second parameter

        Returns:
            str: a string

        Raises:
            ValueError: if `param1` is equal to `param2`

        Yields:
            str: a string

        Note:
            This is some note.

        Warning:
            This is some warning.

    ''')

    assert docstring.short_description == 'Test function for the parse function of ReSTParser.'
    assert docstring.long_description == 'In the long description, we have these things:'

    assert isinstance(docstring.meta[0], DocstringParam)

# Generated at 2022-06-21 11:56:19.145456
# Unit test for function parse
def test_parse():
    doc = """
    This is a test docstring

    Test docstring has two paragraphs

    :param name: name
    :param age: age (type int)
    :returns: True
    :raises ValueError: raises

    """
    docstring = parse(doc)
    assert docstring.short_description == "This is a test docstring"
    assert docstring.blank_after_short_description == False
    assert docstring.long_description == "Test docstring has two paragraphs"
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'name']
    assert docstring.meta[0].description == "name"
    assert docstring.meta[1].args == ['param', 'age', 'int']


# Generated at 2022-06-21 11:56:28.882610
# Unit test for function parse
def test_parse():
    def f(a: int = 5, b: T.Union[1, 2, 3] = 2, c: T.Union[1, 2, 3] = 1):
        """Short
        
        Long.
        
        :param a: a description
        :type a: str
        :param b: b description
        :param c: c description
        
        :raises SomeError: description.
        :raises AnotherError: description.
        
        :returns: description
        :rtype: str
        """
        pass

    r = parse(inspect.getdoc(f))
    print(r)
    assert r.short_description == "Short"
    assert r.long_description == "Long."
    assert len(r.meta) == 4

# Generated at 2022-06-21 11:56:30.181091
# Unit test for function parse
def test_parse():
    pass


# when in doubt, use a docstring

# Generated at 2022-06-21 11:56:40.393665
# Unit test for function parse
def test_parse():
    d = parse(
        """
    ``one`` -> ``two``
    :param x: param one
    :type x: str
    :param y: param two
    :type y: str
    :raises ValueError: something
    :returns:
    :rtype: generator
    """
    )
    assert d.short_description == "``one`` -> ``two``"
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta[0] == DocstringParam(
        ['param', 'x', 'param one'], 'param one', 'x', 'str', False, None
    )

# Generated at 2022-06-21 11:56:49.579989
# Unit test for function parse
def test_parse():
    text = """
    Find the factorial of a given number.

    :param int int_arg: An integer argument. 
    :returns: The factorial of int_arg.
    :rtype: int
    :raises TypeError: If int_arg isn't an int.
    """
    doc = parse(text)
    print(doc)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:56:53.799318
# Unit test for function parse
def test_parse():
    # Arrange
    docstring = """
        Simple docstring.
    """

    # Act
    doc = parse(docstring)

    # Assert
    assert doc.short_description == "Simple docstring."
    assert doc.blank_after_short_description is False
    assert doc.long_description is None
    assert doc.blank_after_long_description is True
    assert len(doc.meta) == 0



# Generated at 2022-06-21 11:57:04.560852
# Unit test for function parse
def test_parse():
    # Basic functions
    assert parse("") == Docstring()
    assert parse("A short description.") == Docstring(
        short_description="A short description."
    )
    assert parse("A short description.\n") == Docstring(
        short_description="A short description."
    )
    assert parse("A short description.\n\n") == Docstring(
        short_description="A short description.",
        blank_after_short_description=True
    )
    assert parse("A short description.\n\n\n") == Docstring(
        short_description="A short description.",
        blank_after_short_description=True,
        blank_after_long_description=True
    )

# Generated at 2022-06-21 11:57:13.009390
# Unit test for function parse

# Generated at 2022-06-21 11:57:25.062382
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc(
        """
    Short description.

    Long description.

    :param str name: The name to be used.
    :raises Exception: if something bad happens.
    :returns: None
    :returns: :class:`int`: the return code.
    :rtype: int
    """
    )
    doc = parse(docstring)
    print("docstring: ", docstring)
    print("doc: ", doc)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 5
    assert doc.meta[0].key == "param"
    assert doc.meta[0].args

# Generated at 2022-06-21 11:57:32.859006
# Unit test for function parse
def test_parse():
    doc = """\
    This is a short description.

    This is a more detailed long description.

    :param a1: This is a parameter.
    :type a1: str
    :param a2: This is a parameter.
    :type a2: int
    :keyword k1: This is a parameter.
    :type k1: str
    :keyword k2: This is a parameter.
    :type k2: int

    :raises Exception: This is a description.
    :returns: This is a description.
    :rtype: str
    """

    docstring = parse(doc)
    assert docstring.short_description == "This is a short description.", \
        'parse short description'


# Generated at 2022-06-21 11:57:45.405674
# Unit test for function parse
def test_parse():
    #test for none
    res = parse(None)
    assert len(res.meta) == 0
    assert res.long_description is None
    assert res.short_description is None
    assert res.blank_after_long_description is False
    assert res.blank_after_short_description is False

    #test for empty string
    res = parse("")
    assert len(res.meta) == 0
    assert res.long_description is None
    assert res.short_description is None
    assert res.blank_after_long_description is False
    assert res.blank_after_short_description is False

    #test for one line description
    res = parse("one line description")
    assert len(res.meta) == 0
    assert res.long_description is None
    assert res.short_description == "one line description"


# Generated at 2022-06-21 11:57:54.056701
# Unit test for function parse
def test_parse():
    parse_docstring = parse("""
    This is a sample module.
    
    Description of the keyworkds without default
    
    :param int arg: This is a parameter, without default value
    
    :param str arg_str: this is a parameter with a default value
        defaults to 'hello'
    
    :param type arg_type: this is a parameter with a default value
        defaults to None.
    
    :return: This is a normal return, without a type
    
    :returns: this is a return with a type
    
    :raises: this is a raised exception, without a type
    
    :raises TypeError: this is a raised exception, with a type
    """)

    assert parse_docstring.short_description == "This is a sample module."

    assert len(parse_docstring.meta)

# Generated at 2022-06-21 11:58:05.576573
# Unit test for function parse
def test_parse():
    text = """\
    This is a docstring.
    This is the long description.

    :param name: the name of the file
    :type name: str
    :param index: the index of the file
    :type index: int
    :param output: the output mode
    :type output: str
    :param test: the name of the test
    :type test: str
    :param init: the initialize
    :type init: str
    :returns: an optional list of strings
    :raises: expected a number
    """

    r = parse(text)
    assert r.short_description == "This is a docstring."
    assert r.long_description == "This is the long description."
    assert r.blank_after_short_description
    assert r.blank_after_long_description


# Generated at 2022-06-21 11:58:22.194885
# Unit test for function parse
def test_parse():
    input = """
    ReST-style docstring parsing.

    This module provides a parser for ReST-style docstrings.

    :param str text: the docstring text
    :returns: parsed docstring
    """
    result = parse(input)
    assert result.short_description == "ReST-style docstring parsing."
    assert result.long_description == (
        "This module provides a parser for ReST-style docstrings."
    )
    assert result.blank_after_short_description is False
    assert result.blank_after_long_description is True

    param = result.meta[0]
    assert isinstance(param, DocstringParam)
    assert param.args[0] == "param"
    assert param.args[1] == "str"
    assert param.args[2] == "text"

# Generated at 2022-06-21 11:58:32.232355
# Unit test for function parse
def test_parse():
    docstring = """One-line summary.
    Extended description.
    :param arg1: Description of positional arg1.
    :param arg2: Description of keyword-only arg2 (defaults to
        "nothing").
    :raises: ValueError
    :returns: nothing
    """
    d = parse(docstring)
    print(d)
    # <Docstring
    #   short_description="One-line summary.",
    #   long_description="Extended description.",
    #   blank_after_short_description=True,
    #   blank_after_long_description=False,
    #   meta=[
    #     DocstringParam(
    #       args=['param', 'arg1'],
    #       description='Description of positional arg1.',
    #       arg_name='arg1',
    #      

# Generated at 2022-06-21 11:58:40.400962
# Unit test for function parse
def test_parse():
    parse_docstring = parse(
        """
    Docstring for a function.

    Does something amazing.

    Single-line meta: :param int x: the x parameter
    Multi-line meta:
        :param int y: the y parameter
    Missing description meta: :param int z

    :returns: Something amazing
    :rtype: int
    :return: Something amazing
    :yields: Something amazing
    :raises TypeError: if something bad happens.

    :raises TypeError: if something bad happens.

      (indented)

    :param int a: defaults to 2.
    :param int b:
    :param int c: defaults to None.

    :returns: Something amazing
    :rtype: int
    """
    )
    assert parse_docstring.short_description == "Docstring for a function."

# Generated at 2022-06-21 11:58:46.536941
# Unit test for function parse
def test_parse():
    docstring = """\
    Short description.
    Long description.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str, optional
    :returns: None
    :raises TypeError: If invalid argument types are given.
    """

    assert parse(docstring)



# Generated at 2022-06-21 11:58:57.020110
# Unit test for function parse

# Generated at 2022-06-21 11:58:59.327151
# Unit test for function parse
def test_parse():
    x=parse("""
    test
    :param test1:
    :type test2:
    :return:
    """)
    print(x)

# Generated at 2022-06-21 11:59:08.748071
# Unit test for function parse
def test_parse():
    assert parse("hello") == Docstring(
        short_description="hello",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=True,
        meta=[],
    )

    assert parse("hello\nworld") == Docstring(
        short_description="hello",
        long_description="world",
        blank_after_short_description=False,
        blank_after_long_description=True,
        meta=[],
    )

    assert parse("hello\n\nworld") == Docstring(
        short_description="hello",
        long_description="world",
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[],
    )


# Generated at 2022-06-21 11:59:18.105000
# Unit test for function parse
def test_parse():
    from pprint import pprint
    from .sphinx import extract
    from .numpy import extract as ne
    from .google import extract as ge
    pprint(parse(extract("""
        This is a short description.

        This is a long
        description.

        :param arg1: This is arg1.
        :type arg1: str
        :param arg2: This is arg2.
        :type arg2: int, optional
        :returns: This is a return value.
        :rtype: int
    """)))

# Generated at 2022-06-21 11:59:25.487432
# Unit test for function parse
def test_parse():
    docstring = """
    :param xxx: should be formatted in the type
    :type xxx: str
    :returns: str -- should be formatted in the type
    :rtype: str
    :raises: should be formatted in the type
    :exc: str
    """
    docstring = parse(docstring)
    print(docstring.short_description)
    print(docstring.long_description)
    for meta in docstring.meta:
        print(meta.args)
        print(meta.arg_name)
        print(meta.type_name)
        print(meta.is_optional)
        print(meta.default)
        print(meta.description)
        print(meta.is_generator)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:59:37.326149
# Unit test for function parse
def test_parse():
    text = """
    Docstring for the 'parse' function.

    Short description.

    Long description.

    :param arg1: This is an argument.
    :type arg1: int
    :param arg2: This is another argument.
    :type arg2: str

    :returns: description of returned object.
    :rtype: object
    """
    text = inspect.cleandoc(text)
    parsed = parse(text)
    assert parsed.short_description == "Docstring for the 'parse' function."
    assert parsed.long_description == "Short description.\n\nLong description."
    assert parsed.meta[0].args == ["param", "arg1", "int"]
    assert parsed.meta[1].args == ["param", "arg2", "str"]

# Generated at 2022-06-21 11:59:49.327694
# Unit test for function parse
def test_parse():
    """Testing docstrings."""
    docstring = parse(
        """
        Testing docstrings.
        :param foo: The foo parameter.  (type: str)
        :param bar: The bar parameter.  Defaults to "baz". (type: str, optional)
        :param qux: The qux parameter.  No type specified. (optional)
        :param quux: The quux parameter.  No type specified, or optional.
        :yields: Returns a list of strings. (type: list)
        :returns: A dictionary

        The long description.
        """
    )

    assert docstring.short_description == "Testing docstrings."
    assert docstring.blank_after_short_description is True

# Generated at 2022-06-21 12:00:01.559399
# Unit test for function parse
def test_parse():
    def test(docstring):
        result = parse(docstring)
        print(result.short_description)
        print(result.long_description)
        print(result.blank_after_short_description)
        print(result.blank_after_long_description)
        for i in result.meta:
            print(i.args)
            print(i.description)

    test('''
    This is the short description.

    This is the long description.
    ''')
    print()
    test('''
    This is the short description.

    This is the long description.
    ''')
    print()
    test('''
    This is the short description.

    This is the long description.
    ''')
    print()

# Generated at 2022-06-21 12:00:09.002804
# Unit test for function parse
def test_parse():
    docstring = """
    This is the short description.

    And now the long description.
    """
    assert parse(docstring).short_description == "This is the short description."
    assert parse(docstring).long_description == "And now the long description."

    docstring = """
    The short description is here.

    And now the long description.

    """
    assert parse(docstring).short_description == "The short description is here."
    assert parse(docstring).long_description == "And now the long description."

    docstring = """
    This is the short description.

    And now the long description.
    """
    assert parse(docstring).short_description == "This is the short description."
    assert parse(docstring).long_description == "And now the long description."


# Generated at 2022-06-21 12:00:18.099316
# Unit test for function parse
def test_parse():
    doc = parse(r"""
    Short description.

    Long description, which is multiline.

    :arg1: some argument
    :param arg2: some optional argument with a long
        multi-line description which should be properly
        indented.

    :returns: Some object
    :rtype: str
    :returns: Another object
    :rtype: int
    :yields: Yields some object
    :ytype: list

    :raises: SomeError
    """)
    assert doc.short_description == "Short description."
    assert doc.long_description == """\
Long description, which is multiline."""
    assert doc.meta[0].args == ["arg1"]
    assert doc.meta[0].description == "some argument"

# Generated at 2022-06-21 12:00:28.951708
# Unit test for function parse
def test_parse():
    text = r'''Another short description

A short description.

:param str arg_name:
    A description.
:param int arg_name:
    A description.

:raises ValueError:
    A description.
:raises:
    A description.

:returns:
    A description.
:returns int:
    A description.
:return:
    A description.
'''

    doc = parse(text)

    assert doc.short_description == "A short description."
    assert doc.blank_after_short_description is True

    assert len(doc.meta) == 7

    assert doc.meta[0].keyword == "param"
    assert doc.meta[0].arg_name == "arg_name"
    assert doc.meta[0].is_optional is False
    assert doc.meta

# Generated at 2022-06-21 12:00:40.643366
# Unit test for function parse
def test_parse():
    doc1 = parse(
        """
        This is the short docstring.

        This is the long docstring.

        :arg x: First argument.
        :arg y: Second argument.

        :keyword x: First keyword.
        :keyword y: Second keyword.

        :return: Returns something
        :rtype: str
        """
    )

    assert doc1.short_description == "This is the short docstring."
    assert doc1.blank_after_short_description is False
    assert doc1.long_description == "This is the long docstring."
    assert doc1.blank_after_long_description is True

    assert len(doc1.meta) == 3
    assert doc1.meta[0].args == ["arg", "x", "First", "argument."]
    assert doc1.meta[0].description

# Generated at 2022-06-21 12:00:52.357886
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    doc = parse(test_docstring)
    assert doc.short_description == "Returns the simple value."
    assert doc.blank_after_short_description
    assert not doc.blank_after_long_description
    assert doc.long_description == "That's it."
    assert len(doc.meta) == 4
    assert doc.meta[0].arg_name == "num"
    assert doc.meta[0].type_name == "int"
    assert doc.meta[0].is_optional
    assert doc.meta[0].default == "5"

    assert doc.meta[1].arg_name == "data"
    assert doc.meta[1].type_name == "dict"
    assert not doc.meta[1].is_optional
    assert doc.meta[1].default is None

# Generated at 2022-06-21 12:00:55.794155
# Unit test for function parse
def test_parse():
  """My test function."""

if __name__ == "__main__":

  doc = inspect.getdoc(test_parse)

  print(doc)
  print(parse(doc))
  print(parse(doc).meta)

# Generated at 2022-06-21 12:01:07.090148
# Unit test for function parse

# Generated at 2022-06-21 12:01:17.587764
# Unit test for function parse
def test_parse():

    print(parse.__doc__)
    print(parse.__annotations__)
    
    def foo(a, b, c=1, *args, d=2, **kwargs):
        """
            :param a: the a param
            :type a: int
            :param b: the b param
            :type b: str
            :param c: the c param with a default value
            :param args: variable length argument list
            :param d: keyword only param with a default value
            :param kwargs: arbitrary keyword arguments
            :returns: None
            :raises KeyError: raises an exception
        """
        pass

    docstring = parse(foo.__doc__)

    assert docstring.short_description == "the a param"
    assert docstring.blank_after_short_description

# Generated at 2022-06-21 12:01:25.524795
# Unit test for function parse
def test_parse():
    docstring = """
    Summary line.

    Extended description.

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2
    """

# Generated at 2022-06-21 12:01:41.015744
# Unit test for function parse
def test_parse():
    assert parse("hello world") == Docstring(
            short_description="hello world",
            blank_after_short_description=False,
            blank_after_long_description=False,
            long_description=None,
            meta=[],
    )
    assert parse(":class:`~a.b`") == Docstring(
            short_description=":class:`~a.b`",
            blank_after_short_description=False,
            blank_after_long_description=False,
            long_description=None,
            meta=[],
    )

# Generated at 2022-06-21 12:01:47.271053
# Unit test for function parse
def test_parse():
    testcase = """\
    Short description.

    Long description.

    :param:arg1: Type name.
    :yields: Return type.
    """
    docstring = parse(testcase)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].__class__ == DocstringParam
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].type_name == "Type name."
    assert docstring.meta[1].__class__ == DocstringReturns
    assert docstring.meta[1].is_gener

# Generated at 2022-06-21 12:01:57.234379
# Unit test for function parse
def test_parse():
    import pytest
    from .common import Docstring

    def test_func():
        """This is a test doc string.

        Details about test function.


        :param arg1: First argument.
        :returns: Something.
        """
        pass


# Generated at 2022-06-21 12:02:07.661874
# Unit test for function parse
def test_parse():

    ds = parse(
        """
    '''
    Args:
        text (str): The text to parse.

    Returns:
        Docstring: The parsed docstring.

    Raises:
        ParseError: If the docstring is malformed
    '''
    """
    )
    assert ds.meta[0].arg_name == "text"
    assert ds.meta[0].default is None
    assert ds.meta[0].description == "The text to parse."
    assert ds.meta[0].is_optional is False
    assert ds.meta[0].type_name == "str"
    assert ds.meta[1].arg_name is None
    assert ds.meta[1].description == "The parsed docstring."

# Generated at 2022-06-21 12:02:17.862633
# Unit test for function parse

# Generated at 2022-06-21 12:02:29.289750
# Unit test for function parse

# Generated at 2022-06-21 12:02:38.458277
# Unit test for function parse
def test_parse():

    """
    This is a unit test for the function, parse() in rest_parser.py
    :return:
    """
    import docstring_parser
    import path
    # String for testing
    rest_string = """
    Args:
        param1 (int): The first parameter.
        param2 (str, optional): The second parameter.
            Defaults to "foo".
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.
    """
    # Function call
    rest_doc = docstring_parser.parse(rest_string)
    #
    assert isinstance(rest_doc.meta[0].args, list)

    #
    assert rest_doc.meta[0].arg_name == "param1"
    assert rest_doc.meta[0].description == "The first parameter."

   

# Generated at 2022-06-21 12:02:48.743667
# Unit test for function parse

# Generated at 2022-06-21 12:02:59.657068
# Unit test for function parse
def test_parse():
    doc = parse(
        """
        Test input

        - param1: parameter 1
        - param2: parameter 2
        - param3: parameter 3
        - param4: parameter 4
        """
    )

    assert doc.short_description == "Test input"
    assert doc.long_description is None

# Generated at 2022-06-21 12:03:10.050315
# Unit test for function parse
def test_parse():
    func_str = """
    Gives descriptions of a function.

    :param verbose: If True, gives detail description of the function.
    :param func_name: Name of the function.
    :type func_name: string
    :param param3: description of parameter 3.

    :returns: description of the return value
    :rtype: int
    :returns: description of another return value
    """
    doc = parse(func_str)
    assert(doc.short_description == "Gives descriptions of a function.")
    assert(doc.meta[0].args == ['param', 'verbose'])
    assert(doc.meta[1].args == ['param', 'func_name', 'string'])
    assert(doc.meta[2].args == ['param', 'param3'])

# Generated at 2022-06-21 12:03:20.417772
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("""\
    Line One\n\

    Line Two.
    """) == Docstring(
        short_description="Line One",
        long_description="Line Two.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse("""\
    Line One

    Line Two.
    """) == Docstring(
        short_description="Line One",
        long_description="Line Two.",
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-21 12:03:32.597176
# Unit test for function parse
def test_parse():
    TEXT = """Single line description.

    Multiple
    line
    description.
    :param x: Description of parameter x.
    :param y: Description of parameter y.
    :returns: Description of a return value.
    :rtype: str
    """
    ds = parse(TEXT)
    assert ds.short_description == "Single line description."
    assert ds.long_description == (
        "Multiple\n"
        "line\n"
        "description."
    )
    assert ds.blank_after_short_description
    assert ds.blank_after_long_description
    assert ds.meta[0].args == ["param", "x"]
    assert ds.meta[0].arg_name == "x"
    assert ds.meta[1].args == ["param", "y"]


# Generated at 2022-06-21 12:03:43.910462
# Unit test for function parse
def test_parse():
    # Simple Docstring with Parameters
    def test_function(a, b, c=1):
        r"""
        This is a simple test function
        :param a: The A Parameter
        :type a: int
        :param b: The B Parameter
        :param c: The C Parameter
        :type c: int
        :raises ValueError: If something goes wrong
        """
        pass

    # Simple Docstring with Parameters
    def test_function_with_default(a, b, c=1):
        """
        This is a simple test function
        :param a: The A Parameter
        :type a: int
        :param b: The B Parameter
        :param c: The C Parameter defaults to 1.
        :type c: int
        :raises ValueError: If something goes wrong
        """
       

# Generated at 2022-06-21 12:03:55.459980
# Unit test for function parse
def test_parse():
    import pytest
    class p:
        short_description = None
        blank_after_short_description = None
        long_description = None
        blank_after_long_description = None
        meta = []


    p.short_description = "Summary"
    p.long_description = "Description\n"
    p.blank_after_short_description = True
    p.blank_after_long_description = True

    s = DocstringReturns("returns", description = "something", type_name = "int", is_generator = False)
    p.meta.append(s)

    s = DocstringRaises("raises", description = "some_exception", type_name = "Exception")
    p.meta.append(s)


# Generated at 2022-06-21 12:04:00.890719
# Unit test for function parse
def test_parse():
    parsed_docstring = parse(
"""
short_description

long_description

: param1_name type_name: param1_description
: param2_name : param2_description

: returns type_name: returns_description
: yields type_name: yields_description
: raises type_name: raises_description
"""
)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:04:08.611898
# Unit test for function parse
def test_parse():
	doc = parse.__doc__
	parsed = parse(doc)

	assert parsed.short_description == "Parse the ReST-style docstring into its components."
	assert parsed.blank_after_short_description
	assert parsed.long_description == ':returns: parsed docstring'
	assert not parsed.blank_after_long_description
	assert len(parsed.meta) == 1
	assert parsed.meta[0].description == 'parsed docstring'


# Generated at 2022-06-21 12:04:19.199095
# Unit test for function parse
def test_parse():
    param_text = """
    Create a new instance with the given parameters.

    :param code1: The code1 for the instance.
    :type code1: int
    :param code2: The code2 for the instance.
    :type code2: str
    :param code3: The code3 for the instance.
    :type code3: str

    :returns: A new instance.
    :rtype: CustomError
    """

    params = DocstringParam(
        args=["param", "code1:", "int"],
        description="The code1 for the instance.",
        arg_name="code1",
        type_name="int",
        is_optional=False,
        default=None,
    )


# Generated at 2022-06-21 12:04:28.414004
# Unit test for function parse
def test_parse():
    """Tests the functionality of parse with a proper docstring

    This test is able to parse the following docstring with two type annotations
    :param x: a number
    :type x: int
    :returns: x squared
    :rtype: int

    It is also able to parse the following docstring with a type annotation
    :returns: a list of numbers
    :rtype: list[int]

    """

# Generated at 2022-06-21 12:04:33.449064
# Unit test for function parse
def test_parse():
    docstring = "Test docstring\n\n.. code-block:: bash\n\n    $ ls -a"
    parsed = parse(docstring)
    assert parsed.short_description == "Test docstring"
    assert parsed.long_description == ".. code-block:: bash\n\n    $ ls -a"

# Generated at 2022-06-21 12:04:41.543728
# Unit test for function parse
def test_parse():
    """
    Test the parse function.
    """
    docstring = """Foo the first argument.

Bar the second argument.

The first line is short description.
The next lines until a blank line are long description.
Then, blank line(s),
then any number of ":name: value" lines for parameters, return
values, etc.

:param foo: Foo the first argument.
:param bar: Bar the second argument.

:type foo: str
:type bar: bool, optional

:returns: A twople (2-tuple) of bar, baz
:rtype: tuple

:raises ValueError: if baz not equal to bar.

"""
    ret = parse(docstring)
    # check attributes
    assert ret.short_description == "Foo the first argument."
    assert ret.blank_

# Generated at 2022-06-21 12:04:54.793904
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()

    assert parse('short') == Docstring(
        short_description='short',
        blank_after_short_description=False,
        blank_after_long_description=True,
    )

    assert parse('short desc\n  \n\nlong desc') == Docstring(
        short_description='short desc',
        long_description='long desc',
        blank_after_short_description=True,
        blank_after_long_description=True,
    )


# Generated at 2022-06-21 12:05:06.173313
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    More detailed long description.

    :param int a: Description of parameter 'a'.
    :param str b: Description of parameter 'b'.
    :param c: Description of parameter 'c'.
    :type c: int
    :returns: Description of return value.
    :rtype: str
    :raises TypeError: Description of error raised.
    :raises: Description of error raised.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "More detailed long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 6