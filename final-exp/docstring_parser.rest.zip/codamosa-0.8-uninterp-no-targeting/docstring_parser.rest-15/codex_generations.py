

# Generated at 2022-06-21 11:55:39.614009
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Longer description.

    :param param1: The first parameter.
    :param param2: The second parameter.
    :type param2: str
    :returns: Description of return value.
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "Short description."
    assert docstring.blank_after_short_description is True
    assert docstring.long_description == "Longer description."
    assert docstring.blank_after_long_description is False

    param1, param2, returns = docstring.meta

    assert isinstance(param1, DocstringParam)
    assert param1.arg_name == "param1"
    assert param1.type_name is None
    assert param1.is_optional is False
   

# Generated at 2022-06-21 11:55:44.954837
# Unit test for function parse
def test_parse():
    assert parse(
        """
    Wrap the long line to the next line with 4 leading spaces.

        >>> square(10)
        100
        >>> square(20)
        400
    """
    ) == Docstring(
        short_description="Wrap the long line to the next line with 4 leading spaces.",
        long_description="""
        >>> square(10)
        100
        >>> square(20)
        400
    """.strip(),
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[],
    )

# Generated at 2022-06-21 11:55:56.250939
# Unit test for function parse
def test_parse():
    from .common import (
        PARAM_KEYWORDS,
        RAISES_KEYWORDS,
        RETURNS_KEYWORDS,
        YIELDS_KEYWORDS,
        Docstring,
        DocstringMeta,
        DocstringParam,
        DocstringRaises,
        DocstringReturns,
        ParseError,
    )

    def _build_meta(args: T.List[str], desc: str) -> DocstringMeta:
        key = args[0]
        if key in PARAM_KEYWORDS:
            if len(args) == 3:
                key, type_name, arg_name = args
                if type_name.endswith("?"):
                    is_optional = True
                    type_name = type_name[:-1]
                else:
                    is_optional = False
           

# Generated at 2022-06-21 11:56:05.207131
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    def test_parse_(text: str) -> None:
        parsed = parse(text)
        print("text:")
        print(text)
        print("parsed:")
        print(parsed)
        print("re-parsed:")
        print(parsed.to_str())
        print()

    test_parse_("")
    test_parse_("text")
    test_parse_("text\n")
    test_parse_("text\n\n")
    test_parse_("text\n\nstuff\n")
    test_parse_("text\n\nstuff\n\n")
    test_parse_("text\n\nstuff\n\nmore")

# Generated at 2022-06-21 11:56:11.160871
# Unit test for function parse
def test_parse():
    docstring = """One-line summary.

Long description.
:param argument description
:param type_name argument_name: description
:param type_name? argument_name: description
:param type_name? argument_name?=default_value: description
:param type_name argument_name?=default_value: description
:returns: description
:yields: description
:raises: description
:raises type_name: description
"""
    d = parse(docstring)
    assert len(d.meta) == 8
    assert d.meta[0].args == ["param", "argument", "description"]
    assert d.meta[0].description == "description"
    assert d.meta[0].arg_name is None
    assert d.meta[0].type_name is None
    assert d.meta[0].is_

# Generated at 2022-06-21 11:56:22.884755
# Unit test for function parse
def test_parse():
    doc_string = '''\
Short description.

Long description.

:param int arg1: the first argument (this is not a description).
:param str arg2: the second argument.
:param arg3: the third argument.
:returns: something to return.
:rtype: str
:raises ValueError: when something goes wrong.
:other_keyword: other types of information.
:raises AssertionError, KeyError: multiple exceptions.'''
    x = parse(doc_string)

    assert x.short_description == "Short description."
    assert x.long_description == "Long description."
    assert x.meta[0].description == "the first argument (this is not a description)."
    assert x.meta[1].description == "the second argument."

# Generated at 2022-06-21 11:56:30.653628
# Unit test for function parse
def test_parse():
    docstring = '''\
        Short description
        Long description

        :param x: parameter x
        :type x: str'''
    assert parse(docstring) == Docstring(
        short_description='Short description',
        blank_after_short_description=True,
        long_description='Long description',
        blank_after_long_description=False,
        meta=[
            DocstringParam(
                args=['param', 'x', 'x'],
                description='parameter x',
                arg_name='x',
                type_name='str',
                is_optional=False,
                default=None,
            ),
        ],
    )

    docstring = '''\
        Short description
        Long description

        :param x: parameter x
        :type x: str?
        :param y: parameter y'''

# Generated at 2022-06-21 11:56:40.539340
# Unit test for function parse
def test_parse():
    print('Checking function parse ... ', end='')
    docstring = \
    '''
    This is a short description.

    This is a long
    description.

    :param aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa: Parameter a.
    :param b: Parameter b.
    :raises AttributeError: For no reason.
    :returns: None.
    :return: None.
    '''
    result = parse(docstring)
    assert result.short_description == 'This is a short description.'
    assert result.long_description == 'This is a long\ndescription.'
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert len(result.meta) == 6

# Generated at 2022-06-21 11:56:51.503544
# Unit test for function parse
def test_parse():
    text = """\
        Retrieve a list of all regions.

        :param session: A server-side session.
        :returns: A list of region dicts.

        Example::

            >>> regions = regions_v1.list(session)
            >>> for r in regions:
            ...     print(r)
            {'name' : 'RegionOne', 'id' : '1', 'links' : ... }
            {'name' : 'RegionTwo', 'id' : '2', 'links' : ... }
            ...
            >>> len(regions)
            3

        :raises keystoneauth1.exceptions.http.NotFound: if no regions could be
            found.
        """
    obj = parse(text)
    print(obj)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:57:01.859405
# Unit test for function parse
def test_parse():
    text = """\
    This is a function.

    It does not do anything.

    :param arg1: this is an argument.
    :type arg1: str

    :param arg2: this is an argument.
    :type arg2: str
    :default arg2: one

    :param arg3: this is an argument.
    :type arg3: str
    :default arg3: two

    :rtype: None
    """
    docstring = parse(text)
    assert docstring.short_description.strip() == "This is a function."
    assert docstring.long_description.strip() == "It does not do anything."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 4

# Generated at 2022-06-21 11:57:17.635429
# Unit test for function parse
def test_parse():
    # format of the below string is the same as the format of the docstring:
    # <short description><blank line><long description><blank line><meta info>
    # meta info is of the form <keyword>:<arg1>:<arg2>:<desc>
    long_desc = """\
        This is a long description.

        This function is a function.
        """
    short_desc = "This function is useful."

# Generated at 2022-06-21 11:57:28.073806
# Unit test for function parse
def test_parse():
    # check simple docstring
    text = '''
    short descr
    No Meta.
    '''

    ds = parse(text)

    assert ds.short_description == "short descr"
    assert not ds.meta

    # check more complex one

# Generated at 2022-06-21 11:57:39.595417
# Unit test for function parse
def test_parse():
    import inspect
    
    def test_foo():
        """
        A sample docstring for the test_foo function.

        :param bar: A bar
        :type bar: float
        :returns: A float
        :raises RuntimeError: My runtime error
        """
    
    ds = parse(inspect.getdoc(test_foo))
    assert ds.short_description == "A sample docstring for the test_foo function."
    assert ds.meta[0].description == "A bar"
    
    def test_foo2():
        """
        A sample docstring for the test_foo function.

        :param bar: A bar
        :type bar: float
        :returns: A float
        :raises RuntimeError: My runtime error
        """
    

# Generated at 2022-06-21 11:57:50.449512
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = """
    Example function.

    This is a longer description of the function.

    :param foo: This is a foo parameter.
    :type foo: str
    :param bar: This is a bar parameter.
    :type bar: int
    :returns: int -- the return code.

    """
    print(text)
    docstring = parse(text)
    print(docstring)

# Generated at 2022-06-21 11:57:56.702561
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(
        short_description=None,
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("Short sentence.") == Docstring(
        short_description="Short sentence.",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("Short sentence.\n") == Docstring(
        short_description="Short sentence.",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-21 11:58:08.371561
# Unit test for function parse
def test_parse():
    text = """\
This is the main docstring.

This is the first paragraph.

This is the second paragraph.

:key1 value1
:key2 value2 value3
:key3
    This is a description for the third element.
    This is the second line.
:key4 value4
    This is the description for the fourth element.
"""

# Generated at 2022-06-21 11:58:16.051412
# Unit test for function parse
def test_parse():
    d = parse("""
    This is the short description.

    This is the long description.
    It spans multiple lines.

    :param x: The x paramenter.
    :param y: The y parameter. Optional, defaults to 42.
    :returns: The position (x, y).
    :raises ValueError: If x < 0.
    """)
    assert d.short_description == "This is the short description."
    assert d.blank_after_short_description
    assert d.long_description == (
        "This is the long description.\n" "It spans multiple lines."
    )
    assert d.blank_after_long_description

    assert len(d.meta) == 4
    assert d.meta[0].args == ["param", "x"]

# Generated at 2022-06-21 11:58:24.486557
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description.

    :param first: the first argument
    :param second: the second argument
    :type second: int
    :raises: :class:`Exception`
    :returns: 42
    :rtype: int
    """

    try:
        result = parse(text)
    except ParseError as e:
        print(e.args[0])

    assert result.short_description == "Short description."
    assert result.long_description == "Long description."
    assert result.blank_after_short_description
    assert result.blank_after_long_description

    assert len(result.meta) == 4
    assert result.meta[0].args == ["param", "first"]
    assert result.meta[0].description == "the first argument"
    assert result.meta

# Generated at 2022-06-21 11:58:35.803519
# Unit test for function parse

# Generated at 2022-06-21 11:58:36.971507
# Unit test for function parse
def test_parse():
    from .mypy_formatter import format_meta
    from .gfm_formatter import format_meta



# Generated at 2022-06-21 11:58:53.361943
# Unit test for function parse
def test_parse():
    docstring_str = '''
    This is the short description.

    This is the long description. It can span multiple
    lines.

    :param arg1: This is the first argument.
    :type arg1: int
    :param arg2: This is the second argument.
    :type arg2: int
    :returns: Description of return value.
    :rtype: int
    '''
    assert(parse(docstring_str).short_description == "This is the short description.")
    assert(parse(docstring_str).long_description == "This is the long description. It can span multiple\nlines.")
    assert(parse(docstring_str).meta[0].arg_name == 'arg1')
    assert(parse(docstring_str).meta[0].type_name == 'int')

# Generated at 2022-06-21 11:59:00.764304
# Unit test for function parse

# Generated at 2022-06-21 11:59:09.253842
# Unit test for function parse
def test_parse():
    def round_trip(text):
        assert str(parse(text)) == text
    def round_trip_with_context(context, text):
        assert str(parse(text)) == (context + '\n' + text)

    text = """
       A short description.

       A longer description, possibly
       multi-line.

       :param foo: the first param...
       :type foo: int
       :param bar: the second param...
       :type bar: one or two lines
       :returns: the return type...
       :rtype: str
       """
    round_trip(text)


# Generated at 2022-06-21 11:59:18.300684
# Unit test for function parse
def test_parse():
    """Check to see if the docstring can be parsed as expected."""

    def something():
        """The short description.

        More about the function.

        :params:
            foo (str): The foo parameter.

        :returns:
            Something.

        :raises:
            ValueError: Raised if something is wrong.

        """
        print("Hello World!")

    docstring = parse(something.__doc__)

    # this is a very simple example, so it's probably ok to rely
    # on the order of the returned items, but it's better to be
    # certain
    assert docstring.short_description == "The short description."
    assert docstring.long_description == "More about the function."
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description

# Generated at 2022-06-21 11:59:25.670870
# Unit test for function parse

# Generated at 2022-06-21 11:59:37.462921
# Unit test for function parse
def test_parse():
    text = '''
    Short description.

    Long description.

    :param arg1: First argument.
    :param arg2: Second argument.
    :returns: Something.
    :raises KeyError: When a key is not found.

    :param arg3: Third argument.
    :returns: Something else.
    '''
    doc = parse(text)

    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert len(doc.meta) == 5

    param_types = [type(m) for m in doc.meta]
    assert param_types == [
        DocstringParam,
        DocstringParam,
        DocstringReturns,
        DocstringRaises,
        DocstringParam,
    ]

    # Meta


# Generated at 2022-06-21 11:59:49.405725
# Unit test for function parse
def test_parse():
    doc1 = """
    This function is
    used to test the parsing
    functionality of pyexpect.
    It returns the passed value.

    :param int int_param: An integer parameter.
    :param str str_param: A string parameter.
    :param str param3: Another string parameter.
    :returns: The value passed as an argument.
    :rtype: str
    """

    ret = parse(doc1)
    assert(ret.short_description == "This function is used to test the parsing functionality of pyexpect.")
    assert(ret.blank_after_short_description == False)
    assert(ret.long_description == "It returns the passed value.")
    assert(ret.blank_after_long_description == True) 
    assert(ret.meta[0].arg_name == "int_param")
   

# Generated at 2022-06-21 12:00:01.378044
# Unit test for function parse
def test_parse():
    assert parse("short description.\n\nLong description.") == Docstring(
        short_description="short description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="Long description.",
        meta=[],
    )

    assert parse("\nshort description.\n\nLong description.") == Docstring(
        short_description="short description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="Long description.",
        meta=[],
    )


# Generated at 2022-06-21 12:00:12.203573
# Unit test for function parse

# Generated at 2022-06-21 12:00:18.354092
# Unit test for function parse
def test_parse():
    docstring = "This is a docstring."
    assert parse(docstring) == Docstring(
        short_description=docstring,
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

    docstring = "This is a docstring.\nAnd here is the long description."
    assert parse(docstring) == Docstring(
        short_description="This is a docstring.",
        blank_after_short_description=True,
        long_description="And here is the long description.",
        blank_after_long_description=True,
        meta=[],
    )

    docstring = "This is a short description.\n\nAnd here is the long description.\n\n"

# Generated at 2022-06-21 12:00:25.060023
# Unit test for function parse
def test_parse():
    assert parse("") == parse.__doc__
    assert parse("Hello, docstrings!") == "Hello, docstrings!"
    
    x = Docstring()

# Generated at 2022-06-21 12:00:32.609986
# Unit test for function parse
def test_parse():
    docstring = '''This is a test.
        
        :param str name: Name of the person.
        :raises ValueError: If the name is not valid.
        :return: None.
        '''
    result = parse(docstring)
    assert result.meta[0].keywords == ['param']
    assert result.meta[0].args == ['param', 'str', 'name']
    assert result.meta[0].type_name == 'str'
    assert result.meta[1].keywords == ['raises']
    assert result.meta[1].args == ['raises', 'ValueError']
    assert result.meta[1].type_name == 'ValueError'
    assert result.meta[2].keywords == ['return']
    assert result.meta[2].type_name == None

# Generated at 2022-06-21 12:00:44.203244
# Unit test for function parse
def test_parse():
    # Test basic usage
    doc = parse(r'''
    This is a sample docstring.
    :param type: the type of sample.
    :param param: the parameter.
    :returns: the returns.
    :raises: an exception.
    ''')
    print(doc.short_description)
    print(doc.long_description)

    for item in doc.meta:
        print(item.args, item.description)

    # Test empty input
    doc = parse('')
    assert doc.short_description is None
    assert doc.long_description is None
    assert len(doc.meta) == 0

    # Test docstring without meta information
    doc = parse(r'''
    This is a sample docstring.

    It has two paragraphs
    in the long description.
    ''')
   

# Generated at 2022-06-21 12:00:44.864926
# Unit test for function parse

# Generated at 2022-06-21 12:00:56.186790
# Unit test for function parse
def test_parse():
    from .common import DocstringReturns

    docstring = '''
        Short description

        Long description

        :param int num_people: (optional) Number of people.
        :return: the result.
        :rtype: int
        '''
    output = parse(docstring)
    assert output.short_description == 'Short description'
    assert output.long_description == 'Long description'
    assert output.blank_after_short_description == True
    assert output.meta[0] ==  DocstringParam(args=['param', 'int', 'num_people'], description='Number of people.', arg_name='num_people', type_name='int', is_optional=True, default=None)

# Generated at 2022-06-21 12:01:07.548945
# Unit test for function parse

# Generated at 2022-06-21 12:01:18.107160
# Unit test for function parse
def test_parse():
    def testparse(text):
        print("========================================")
        print("str:", text)
        doc = parse(text)
        print("short:", doc.short_description)
        print("long:", doc.long_description)
        print("blank_after_short_description:", doc.blank_after_short_description)
        print("blank_after_long_description:", doc.blank_after_long_description)
        for meta in doc.meta:
            print("*", meta.args)
            print("**", meta.description)

    testparse("")
    testparse("Short")
    testparse("Short\n\nLong")
    testparse("Short\n\nLong\n")
    testparse("Short\n\nLong\n\n")
    testparse("Short\nLong")
   

# Generated at 2022-06-21 12:01:25.799424
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("long\n\n     desc") == Docstring(
        short_description="long",
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description="desc",
        meta=[],
    )
    assert parse("short desc\nlong\n\n     desc") == Docstring(
        short_description="short desc",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="long\ndesc",
        meta=[],
    )

# Generated at 2022-06-21 12:01:35.814396
# Unit test for function parse
def test_parse():
    """test parse"""
    func = parse(
        """
:param thing: the thing
    """
    )

    assert(func.short_description is None)
    assert(func.meta[0].arg_name == "thing")
    assert(func.meta[0].description == "the thing")

    func = parse(
        """
this thing

:param int thing?

:param int y:
    """
    )
    assert(func.short_description == "this thing")
    assert(func.meta[0].arg_name == "thing")
    assert(func.meta[0].type_name == "int")
    assert(func.meta[0].is_optional)
    assert(func.meta[1].arg_name == "y")

# Generated at 2022-06-21 12:01:42.777261
# Unit test for function parse
def test_parse():
    text = """\
        This is the short description.

        This is the long description.

        :param x: This is a parameter.
        :type x: int
        :returns: This is a return value.
        :rtype: int
        """
    doc = parse(text)
    assert doc.short_description == "This is the short description."
    assert doc.long_description == "This is the long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert doc.meta[0].args == ["param", "x"]


# Generated at 2022-06-21 12:01:51.438027
# Unit test for function parse
def test_parse():
    pass



# Generated at 2022-06-21 12:01:59.338727
# Unit test for function parse

# Generated at 2022-06-21 12:02:09.517810
# Unit test for function parse

# Generated at 2022-06-21 12:02:19.011896
# Unit test for function parse
def test_parse():
    text = """
            Test docstring.

            More description.

            :param x: something
            :param y: something else
            :type y: str
            :returns: nothing
            :rtype: None
            :raises KeyError: if x is 1
            :raises ValidationError: if y is 2
            """

    docstring = parse(text)

    assert docstring.short_description == "Test docstring."
    assert docstring.blank_after_short_description is False
    assert (
        docstring.long_description
        == "More description."
    )
    assert docstring.blank_after_long_description is True

    assert len(docstring.meta) == 5

    param = docstring.meta[0]
    assert isinstance(param, DocstringParam)

# Generated at 2022-06-21 12:02:30.735362
# Unit test for function parse
def test_parse():
    text = '''
    Parse the ReST-style docstring into its components.

    :param x: The x.
    :type x: str
    :param y: The y.
    :type y: str
    :param z: The z.
    :type z: str
    :param w: The w.
    :type w: str
    :returns: parsed docstring
    :rtype: Docstring
    :raises: ParseError
    '''

    actual = parse(text)
    assert actual.short_description == 'Parse the ReST-style docstring into its components.'
    assert actual.blank_after_short_description == False
    assert actual.long_description == None
    assert actual.blank_after_long_description == True

# Generated at 2022-06-21 12:02:39.516864
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()


# Generated at 2022-06-21 12:02:47.212629
# Unit test for function parse
def test_parse():

    from .parse import parse

    text = """\
    Summary line.

    Extended description.

    : param x: Description 1.
    : type x: int
    : param y: Description 2.
    : type y: int
    : param z: Description 3.
    : type z: int
    : returns: Description 4.
    :rtype: bool
    :raises: Description 5.

    Description 6.
    """
    print(parse(text))


# Unit test
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:02:58.414010
# Unit test for function parse
def test_parse():
    text = '''Here is my short description.

Here is my long description. I want to put multiple
lines of text in this description.
It even gets nice whitespace.

:param str arg: Here is the first arg.
:param int arg2: Here is the second arg.
:raises ValueError: if something goes wrong in here.
:returns: The return value description.
'''
    res = parse(text)
    assert res.short_description == 'Here is my short description.'
    assert res.long_description == 'Here is my long description. I want to put multiple\nlines of text in this description.\nIt even gets nice whitespace.'
    assert res.blank_after_short_description
    assert res.blank_after_long_description
    assert len(res.meta) == 4

# Generated at 2022-06-21 12:03:07.278222
# Unit test for function parse
def test_parse():
    doc_string = '''
    ReST-style docstring parsing.

        This function is a parser of ReST-style docstring.
        It will extract the short description, long description,
        meta information and return these information as a
        Docstring object.

    :param text: docstring as text format
    :type text: str
    :returns: parsed docstring
    :rtype: Docstring
    '''

    doc_string = parse(doc_string)
    print(doc_string.short_description)
    print(doc_string.long_description)
    for meta in doc_string.meta:
        print(meta)

# Generated at 2022-06-21 12:03:14.853812
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a docstring!

    This is the long description.

    :param int count: Number of items to show.
    :returns: The result
    '''
    result = parse(docstring)
    assert result.short_description == 'This is a docstring!'
    assert result.blank_after_short_description == True
    assert result.long_description == 'This is the long description.'
    assert result.blank_after_long_description == False
    assert len(result.meta) == 1
    assert result.meta[0].type_name == 'int'
    assert result.meta[0].description == 'Number of items to show.'
    assert result.meta[0].arg_name == 'count'
    assert result.meta[0].is_optional == False

# Generated at 2022-06-21 12:03:25.997405
# Unit test for function parse
def test_parse():
    d = """
    Multiline short description

    Multiline long description

    :param name: Multiline description for the first parameter.
    :type name: str
    :param email: Multiline description for the second parameter.
    :type email: str
    :returns: Multiline description for the return value.
    :rtype: int
    :raises: ValueError
    """

# Generated at 2022-06-21 12:03:37.077114
# Unit test for function parse
def test_parse():
    text = """\
    Summary line.

    Extended description.

    Parameters
    ==========
    x : int
        Hello.
    y : int, optional
        How are you?  Default is 1.

    Returns
    =======
    float
        Clarification.

    Raises
    ======
    RuntimeError
        meh.

    """

    docstring = parse(text)
    assert docstring.short_description == "Summary line."
    assert docstring.long_description == "Extended description."
    assert docstring.blank_after_short_description
    assert not docstring.blank_after_long_description

    assert docstring.meta[0].description == "Hello."
    assert docstring.meta[1].description == "How are you?"
    assert docstring.meta[1].default == "1"
   

# Generated at 2022-06-21 12:03:43.645026
# Unit test for function parse
def test_parse():
    example = """The quick brown fox jumps over the lazy dog.

:param int foo: An integer
:param str bar: A string
"""
    docstring = parse(example)
    assert docstring.short_description == "The quick brown fox jumps over the lazy dog."
    assert docstring.meta[0].arg_name == "foo"
    assert docstring.meta[1].arg_name == "bar"

# Generated at 2022-06-21 12:03:55.216002
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    assert parse("") == Docstring()
    assert parse("Hello, world!") == Docstring(
        short_description="Hello, world!",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert parse("Hello, world!\n") == Docstring(
        short_description="Hello, world!",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

# Generated at 2022-06-21 12:04:06.707670
# Unit test for function parse
def test_parse():
    assert parse(None) == Docstring()
    assert parse("") == Docstring()
    assert parse("\n\n") == Docstring()


# Generated at 2022-06-21 12:04:14.382550
# Unit test for function parse
def test_parse():
    from .common import Docstring, DocstringParam, DocstringRaises, DocstringReturns
    from .docstrings import parse_docstring
    import pytest
    from typing import List, Optional

    def func(name: str, age: Optional[int] = 25) -> str:
        """
        This is a test function.

        :param name: The name of the test.
        :type name: str
        :param age: The age of the test.
        :type age: int | None

        :returns: Whatever you want.
        :rtype: str | int

        :raises ValueError: If there is a problem.
        :raises KeyError: If there is a problem.
        """


# Generated at 2022-06-21 12:04:25.666703
# Unit test for function parse
def test_parse():
    text = """\
        A short summary line.

        Here is a long description.


        :param x: is explained here
        :type x: int
        :param y: is even more explained here
        :type y: float
        :returns: None

        :param some_generator: yields things
        :type some_generator: generator
        :yields: int
        :raises ValueError: if something bad happens
    """
    docstring = parse(text)
    assert docstring.short_description == 'A short summary line.'
    assert docstring.blank_after_short_description is True
    assert docstring.long_description == 'Here is a long description.'
    assert docstring.blank_after_long_description is False
    meta = docstring.meta
    assert len(meta) == 9
    assert meta

# Generated at 2022-06-21 12:04:36.294872
# Unit test for function parse
def test_parse():
    doc = parse("""
    A short description.

    :param arg1:
        A description of arg1.
    :param arg2: A description of arg2.
    :param arg3: A description of arg3.
    :param arg4: A description of arg4.
        Defaults to "hello".
    """)
    assert doc.short_description == "A short description."
    assert doc.blank_after_short_description
    assert doc.long_description is None
    assert doc.blank_after_long_description
    assert doc.meta[0].description == "A description of arg1."
    assert doc.meta[1].description == "A description of arg2."
    assert doc.meta[2].description == "A description of arg3."

# Generated at 2022-06-21 12:04:43.186812
# Unit test for function parse
def test_parse():
    # Docstring with just a short description
    doc = parse("This is the short description")
    assert doc.short_description == "This is the short description"
    assert doc.long_description is None
    assert doc.meta == []

    # Docstring with just a short description and a newline
    doc = parse("This is the short description\n")
    assert doc.short_description == "This is the short description"
    assert doc.long_description is None
    assert doc.meta == []

    # Docstring with a short description and a long description
    doc = parse("This is the short description\nThis is the long description.")
    assert doc.short_description == "This is the short description"
    assert doc.long_description == "This is the long description."
    assert doc.blank_after_short_description

# Generated at 2022-06-21 12:04:48.186395
# Unit test for function parse
def test_parse():
    text = '''
    Top level description.

    :param name: The name of the person to greet.
    :param times: The number of times to greet them (default: 10).
    :param ascii: If set to True, use ASCII art (default: False). This is
                  an example of a long meta-description.
    :returns: The appropriate greeting string.
    :raises ValueError: If number of times to greet is negative.
    '''
    doc = parse(text)
    assert doc.short_description == "Top level description."
    assert doc.long_description == "The appropriate greeting string."

    assert len(doc.meta) == 4
    assert doc.meta[0].keyword == "param"
    assert doc.meta[0].arg_name == "name"

# Generated at 2022-06-21 12:04:54.044896
# Unit test for function parse
def test_parse():
    import doctest
    errors = doctest.testmod()
    assert errors[0] == 0, "Number of failures was non-zero."

# Generated at 2022-06-21 12:05:05.936817
# Unit test for function parse
def test_parse():
    if __name__ == '__main__':
        text = r"""\
        This is a docstring for a function.

        This is a longer description.

        :param arg_a: Blah blah blah
        :param arg_b: Blah blah blah
        :type arg_a: int
        :type arg_b: int
        :returns: Description of the return value
        :rtype: int
        :raises keyError: We never raise KeyError!
    """
        result = parse(text)
        assert result.short_description == "This is a docstring for a function."
        assert result.long_description == "This is a longer description."
        assert result.blank_after_short_description
        assert result.blank_after_long_description