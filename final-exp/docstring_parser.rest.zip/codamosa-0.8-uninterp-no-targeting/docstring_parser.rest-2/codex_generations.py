

# Generated at 2022-06-21 11:55:39.295921
# Unit test for function parse
def test_parse():
    docstring = """
    A short description.
    A long description.

    :param arg_name:   A description for arg_name.
    :param arg_name_2: A description for arg_name_2.
    :type arg_name_2: int
    """

    parsed = parse(docstring)

    assert parsed.short_description == "A short description."
    assert parsed.long_description == "A long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description

    assert len(parsed.meta) == 2
    assert isinstance(parsed.meta[0], DocstringParam)
    assert parsed.meta[0].args == ["param", "arg_name"]
    assert parsed.meta[0].description == "A description for arg_name."

# Generated at 2022-06-21 11:55:44.664787
# Unit test for function parse
def test_parse():
    """Test docstring parsing."""
    doc = parse.__doc__
    r = parse(doc)
    assert len(r.meta) == 1
    r = parse(inspect.cleandoc(doc))
    assert len(r.meta) == 1
    r = parse(inspect.getdoc(parse))
    assert len(r.meta) == 2

# Generated at 2022-06-21 11:55:55.829306
# Unit test for function parse
def test_parse():
    """Test function parse."""
    docstring = """
    Short description.

    Long description.
    """
    assert parse(docstring) == Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        long_description="Long description.",
        blank_after_long_description=False,
        meta=[],
    )

    docstring = """
    Short description.
    Long description.
    """
    assert parse(docstring) == Docstring(
        short_description="Short description.",
        blank_after_short_description=False,
        long_description="Long description.",
        blank_after_long_description=False,
        meta=[],
    )

    docstring = """
    Short description.

    Long description.
    """
    assert parse(docstring) == Docstring

# Generated at 2022-06-21 11:56:00.740916
# Unit test for function parse
def test_parse():
    docstring = """Dummy docstring.

    :param a: some parameter
    :param b: some other parameter
    :type b: int
    :param c: yet another parameter
    :type c: int|str
    :param d: this is optional
    :param e:
    :param f: defaults to 42.
    :type f: int
    :raises ValueError: if param f does not match
    :returns: something
    :returns: some other thing
    :yields: some value

    Multi-line description.

    """
    ret = parse(docstring)
    assert ret.short_description == "Dummy docstring."
    assert ret.long_description == """Multi-line description.

    """
    assert ret.blank_after_short_description
    assert ret.blank_after_long_description

# Generated at 2022-06-21 11:56:12.772672
# Unit test for function parse
def test_parse():
    assert parse("Foo bar.") == Docstring(
        short_description="Foo bar.",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    assert parse("Foo bar.\n    Baz qux.") == Docstring(
        short_description="Foo bar.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="Baz qux.",
        meta=[],
    )

# Generated at 2022-06-21 11:56:24.318461
# Unit test for function parse
def test_parse():
    doc = parse("""
        Test function.
        :param int a: A.
        :param b: B.
        :returns: X
        :returns: Y
        :raises ValueError: if value is invalid.
    """)
    assert doc.short_description == "Test function."
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 4
    assert doc.meta[0].arg_name == "a"
    assert doc.meta[0].type_name == "int"
    assert doc.meta[0].is_optional == False
    assert doc.meta[1].arg_name == "b"
    assert doc.meta[1].type_name == None
   

# Generated at 2022-06-21 11:56:31.631081
# Unit test for function parse
def test_parse():
    text = """Converts a string to an int.

:param str string: string to be converted
:param int base: base of the result
:param dict kwargs: Additional keyword arguments to be passed.

:raises ValueError: If string cannot be converted

:returns: int representation of string
"""
    doc = parse(text)
    assert len(doc.meta) == 4
    assert doc.short_description == "Converts a string to an int."
    assert doc.long_description

# Generated at 2022-06-21 11:56:35.334630
# Unit test for function parse
def test_parse():
    docstring = "this is a test.\n\nthis is a test."
    docstring = parse(docstring)
    assert docstring.short_description == "this is a test."
    assert docstring.long_description == "this is a test."

# Generated at 2022-06-21 11:56:42.927589
# Unit test for function parse

# Generated at 2022-06-21 11:56:53.482159
# Unit test for function parse
def test_parse():
    docstring = """
    Test 1

    :param param_1: Test1
    """
    doc = parse(docstring)
    assert doc.short_description == "Test 1"
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == True
    assert doc.long_description == None
    assert doc.meta[0].args[0] == "param"
    assert doc.meta[0].args[1] == "param_1"
    assert doc.meta[0].description == "Test1"
    assert doc.meta[0].type_name == None
    assert doc.meta[0].arg_name == "param_1"
    assert doc.meta[0].is_optional == None
    assert doc.meta[0].default == None


# Generated at 2022-06-21 11:57:07.225401
# Unit test for function parse
def test_parse():
    def t(text, exp):
        docstring = parse(text)
        if docstring != exp:
            e = Docstring(short_description=exp.short_description,
                        long_description=exp.long_description,
                        blank_after_short_description=exp.blank_after_short_description,
                        blank_after_long_description=exp.blank_after_long_description,
                        meta=exp.meta)
            raise AssertionError(
                "Unexpected result for parse(%r):\n"
                "  expected: %s\n"
                "       got: %s\n" % (text, e, docstring)
            )

    t("", Docstring())
    t(None, Docstring())
    t("one\n", Docstring(short_description="one"))

# Generated at 2022-06-21 11:57:18.403700
# Unit test for function parse
def test_parse():
    import pytest
    text = inspect.cleandoc(r"""
    :param str arg: An argument.
    :returns: A value
    :rtype: str
    """)
    docstr = parse(text)
    assert docstr.short_description == ""
    assert docstr.long_description == ""

# Generated at 2022-06-21 11:57:28.583986
# Unit test for function parse
def test_parse():
    print("test_parse")
    docstring = """
    Short description.

    Long description.

    :param str arg1: The first argument.
    :type arg1: str
    :type arg2: str
    :param str arg2: The second argument.
    :param int arg3: The third argument.
    :type arg3: int
    :param arg4: The fourth argument.

    :keyword arg5: The fifth argument.

    :returns: something

    :rtype: anything

    :raises ValueError: if something bad happens

    :yields: something
    """
    parsed = parse(docstring)
    # print(parsed)
    for line in parsed.meta:
        print(line)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:57:32.760761
# Unit test for function parse
def test_parse():
    my_func = """
    My function.
    :type foo: str
    :param foo: My foo.
    :type bar: bool
    :param bar: My bar.
    :return: None
    :rtype: int
    """
    print(parse(my_func))

# Generated at 2022-06-21 11:57:45.368981
# Unit test for function parse
def test_parse():
    # Example taken from https://github.com/kinverarity1/zaabx
    d = """
    Calculate the maximum length of a defined string.

    :param str s: string.
    :rtype: int
    :returns: length of string.
    """
    parsed = parse(d)


# Generated at 2022-06-21 11:57:54.025977
# Unit test for function parse
def test_parse():
    """Test the parse method"""
    from .common import Docstring

    source = inspect.getsource(test_parse)
    source = source[: source.find("def test_parse()")]
    source += "def test_parse():"
    assert inspect.cleandoc(parse(source).short_description) == "Test the parse method"
    assert not parse("").short_description
    assert not parse("").long_description

    docstring = """
    :param int x: the x value
    :param int y: the y value
    """

# Generated at 2022-06-21 11:58:05.528867
# Unit test for function parse
def test_parse():
	docstring = parse(
	"""Test function.

	:param str a: the first argument
	:param int b: the second argument
	:param float c: the third argument. defaults to 0.0
	:param type d: the fourth argument defaults to None
	
	"""
	)

	assert docstring.short_description == "Test function."
	assert docstring.long_description == None
	assert docstring.blank_after_short_description == True
	assert docstring.blank_after_long_description == False

	assert len(docstring.meta) == 4
	assert docstring.meta[0].description == "the first argument"
	assert docstring.meta[1].description == "the second argument"
	assert docstring.meta[2].description == "the third argument."

# Generated at 2022-06-21 11:58:14.309729
# Unit test for function parse
def test_parse():
    parsed = parse('''
    Test a function with a docstring

    This is a multiline description.

    :param arg1: Argument 1
    :type arg1: int
    :param arg2: Argument 2
    :type arg2: str
    :param arg3: Argument 3
    :type arg3: bool
    :param arg4: Argument 4
    :param arg5: Argument 5
    :returns: None
    :raises ValueError: if something bad happens
    :raises TypeError: if something really bad happens
    ''')

# Generated at 2022-06-21 11:58:15.456545
# Unit test for function parse
def test_parse():
    doc = Docstring()
    print(parse(doc))

# Generated at 2022-06-21 11:58:24.129872
# Unit test for function parse
def test_parse():
    """
    Test the docstring parser.
    """
    global inspect, re
    text = """
    This function returns a string
    that contains a description of the function.

    The docstring may span multiple lines.
    The starting quotes are optional;
    the whitespace before the first line does not matter (work
    around Python's "+-docstring" problem).

    :param bar: a string
    :returns:
        This is the complete return value.

        It can span multiple lines.
    :raises Exception: When this or that.

    """
    assert parse(text) == parse(text)
    assert parse(text) != parse(text + " ")
    assert parse(text) != parse(text[1:])

# Generated at 2022-06-21 11:58:37.539276
# Unit test for function parse
def test_parse():

    text = """
        This is the short description.

        This is the long description.

        :param key: Keyword argument 1 - defaults to 'keyword_value'.
        :keyword keyword: Keyword argument 2 - defaults to 'keyword_value'.
        :type keyword:
        :returns: Integer
    """


# Generated at 2022-06-21 11:58:49.508942
# Unit test for function parse
def test_parse():
    print("Testing function parse")
    print("Testing function parse", end="", flush=True)
    docstring = """A function to parse a string
    :param string:   A string to parse
    :type  string:   string
    :param integer:  An integer to parse
    :type  integer:  int
    :param optional: An optional parameter
    :type  optional: int?
    :param defaults: A parameter defaults to 10
    :type  defaults: int
    :param defaultstr: A string default to 'asdf'
    :type  defaultstr: str
    :returns:        Return a parsed string and integer
    :rtype:          tuple
    :raises:         TypeError if integer is not an int
    """
    print(".", end="", flush=True)
    x = parse(docstring)

# Generated at 2022-06-21 11:58:58.215306
# Unit test for function parse
def test_parse():
    """Test parse function"""

# Generated at 2022-06-21 11:59:08.026845
# Unit test for function parse
def test_parse():
    docstring = """
        A moderately lengthy description of the function.

        :param arg1: description of arg1
        :type arg1: int
        :param arg2: description of arg2
        :type arg2: str
        :param arg3: description of arg3
        :type arg3: float
        :param arg4: description of arg4
        :type arg4: bool
        :returns: description of return value
        :rtype: str
        :raises ValueError: description of the error
        """

    ret = parse(docstring)

    arg1 = ret.meta[0]
    assert arg1.args == ["param", "arg1"]
    assert arg1.description == "description of arg1"
    assert arg1.arg_name == "arg1"
    assert arg1.type_name == "int"

# Generated at 2022-06-21 11:59:17.430659
# Unit test for function parse
def test_parse():
    assert parse(docstring_text) == expected_docstring


docstring_text = """
This is the first line of the docstring.

And this is the second.

This is a paragraph that is separated from the preceding
paragraph by a blank line.

This is a docstring for a function.

:param path: The path being opened.
    If it is a string, open in text mode.
    If it is a binary string, open in binary mode.
:param bufsize: The file bufsize, defaults to 8192.

Short returns description.

:rtype: int
:returns: The file descriptor (a small integer).

Short raises description.

:raises OSError: When an error is raised.
"""


# Generated at 2022-06-21 11:59:24.922928
# Unit test for function parse
def test_parse():
    doc1 = """
    Summary line.

    Extended description of function.

    :param x: Description of x
    :param y: Description of y
    :type x: <type 'int'>
    :type y: <type 'str'>
    :returns: Description of return value
    :rtype: <type 'dict'>
    :raises keyError: Raises KeyError
    """

# Generated at 2022-06-21 11:59:36.804623
# Unit test for function parse
def test_parse():
    docstring_text ="""
    Sums two numbers.

    :param x: first number
    :param y: second number
    :type x: int
    :type y: int
    :returns: sum of ``x`` and ``y``
    :rtype: int
    """

    docstring = parse(docstring_text)

    assert docstring.short_description == "Sums two numbers."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

    assert docstring.meta[0] == DocstringMeta(
        args=["param", "x", "y"],
        description="first number\nsecond number",
    )


# Generated at 2022-06-21 11:59:48.434547
# Unit test for function parse
def test_parse():
    r = parse("""\
    Naive Bayes classifier.

    :param stream_id: The stream_id of the stream to be classified.
                     Default: None
    :param X: The n x m matrix of data, where each row is an observation,
              and each column is an attribute. Each element is an integer
              representing the number of times the attribute was
              experianced.
    :param y: An optional target variable. The labels should be integers
              representing the class.
    :returns: The class predictions.
    :rtype: 1d numpy.array
    """)
    assert r.short_description == "Naive Bayes classifier."

# Generated at 2022-06-21 12:00:00.422644
# Unit test for function parse
def test_parse():
    assert parse("""
        :param a: foo
        :type a: str
        """).meta == [DocstringParam(args=["param", "a"], arg_name="a",
                                     description="foo", type_name="str")]
    assert parse("""
        :keyword a: b
        :type a: int
        """).meta == [DocstringParam(args=["keyword", "a"], arg_name="a",
                                     description="b", type_name="int")]
    assert parse("""
        :param a: foo
        :type a: str?
        """).meta == [DocstringParam(args=["param", "a"], arg_name="a",
                                     description="foo", type_name="str",
                                     is_optional=True)]


# Generated at 2022-06-21 12:00:07.640962
# Unit test for function parse
def test_parse():
    docstring = parse(
        "Short description.\n\n"
        "Long description.\n\n"
        ":param x: Description.\n"
        ":rtype: int\n"
    )
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.meta[0].arg_name == 'x'
    assert docstring.meta[0].description == 'Description.'
    assert docstring.meta[1].type_name == 'int'
    assert docstring.meta[1].description == None


# Generated at 2022-06-21 12:00:17.203371
# Unit test for function parse
def test_parse():
    test_case_0 = """\
        One-liner.

        This is a
        multi-line description.
        """

    test_case_1 = """\
    This is a one-liner.
    """

    test_case_2 = """\
        One-liner.

        This is a
        multi-line description.

        :param foo: the foo
        :param bar: the bar, defaults to None.
        :param baz?: the optional baz
        :returns: the return value
        :raises Exception: when something goes wrong
        """

    test_case_3 = """\
        One-liner.

        This is a
        multi-line description.

        :param foo: the foo
        """


# Generated at 2022-06-21 12:00:24.316594
# Unit test for function parse
def test_parse():
    """Unit test for parse function."""
    text = """Short description.

Long description.

Not meta description.

:param x: X.
:param y: Y.
"""
    doc = parse(text)

    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert len(doc.meta) == 2
    assert doc.meta[0].arg_name == "x"
    assert doc.meta[1].arg_name == "y"

# Generated at 2022-06-21 12:00:32.392779
# Unit test for function parse
def test_parse():
    def dummy():
        """Dummy function for testing

        This is the long description. It is indented, whereas the short
        description is not.

        :param foo: First parameter
        :param bar: Second parameter, defaults to 42.
        :raises ValueError: if all hell breaks loose
        :returns: None
        :yields: Some values
        """
        pass
    doc = parse(dummy.__doc__)
    assert doc.short_description == "Dummy function for testing"
    assert (
        doc.long_description == "This is the long description. It is indented, "
        "whereas the short description is not."
    )
    assert doc.blank_after_short_description is True
    assert doc.blank_after_long_description is True
    assert len(doc.meta) == 4
   

# Generated at 2022-06-21 12:00:43.884842
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    import unittest
    import textwrap

    class ParseTestCase(unittest.TestCase):
        """Test for function parse"""

        def _call_fut(self, text):
            from .restructuredtext import parse

            return parse(text)

        def test_it(self):
            """Test for function parse"""
            d = self._call_fut(
                """\
        Short.

        Long.

        :param a: foo
        :type a: int
        :returns: bar
        :rtype: str
        :raises Exception: baz
        """
            )

            self.assertEqual(d.short_description, "Short.")
            self.assertEqual(d.long_description, "Long.")

# Generated at 2022-06-21 12:00:55.481606
# Unit test for function parse

# Generated at 2022-06-21 12:01:06.831037
# Unit test for function parse

# Generated at 2022-06-21 12:01:17.256141
# Unit test for function parse

# Generated at 2022-06-21 12:01:20.659888
# Unit test for function parse
def test_parse():
    text= """\
    This is a test docstring.
    :param test: a test. defaults to 0.
    :raises: Exception."""
    ret = parse(text)
    assert len(ret.meta) == 2

# Generated at 2022-06-21 12:01:27.585460
# Unit test for function parse
def test_parse():
    s = """
        This is a short string
        This is a long string
        :param x: first arg
        :param y: second arg
        :return: ret
        """
    result = parse(s)
    assert result.short_description == 'This is a short string'
    assert result.long_description == 'This is a long string'
    assert len(result.meta) == 3

# Generated at 2022-06-21 12:01:28.447758
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()



# Generated at 2022-06-21 12:01:40.622198
# Unit test for function parse
def test_parse():
    docstring = \
"""The short_description

The long_description.

:param arg1: The first argument.
:param arg2: The second argument.
:type arg2: int
:param arg3: The second argument.
:type arg3: str
:rtype: int
:returns: doesn't actually return
"""
    print (parse(docstring))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:01:47.085621
# Unit test for function parse
def test_parse():
    text = """
        Summary line.

        (extended description...)
    """

    assert parse(text) == Docstring(
        short_description="Summary line.",
        blank_after_short_description=True,
        long_description="(extended description...)",
        blank_after_long_description=False,
        meta=[],
    )

    text += """
        :param int a:
            First argument.
        :param b: Second argument.
        :raises ValueError: If something bad happens.
        :returns: The return value description.
    """


# Generated at 2022-06-21 12:01:51.009882
# Unit test for function parse
def test_parse():
    docstrings = [
        """
        
        Parameter
        ---------
        
        """
        
    ]
    for docstring in docstrings:
        parse(docstring)

# Generated at 2022-06-21 12:01:59.078291
# Unit test for function parse
def test_parse():
    """Test parse method"""
    docstring = """A short description of the function.

    This would be the long description of the function. It describes it
    completely. Though it can be long, it can go up to multiple paragraphs.

    :param foo: Description of foo
    :type foo: :class:`str`
    :param bar: Description of bar
    :type bar: int
    :returns: Description of return value
    :rtype: :class:`bool`
    :raises ValueError: Never
    """
    parsed = parse(docstring)
    assert parsed.short_description == "A short description of the function."
    assert parsed.long_description == "This would be the long description of the function. It describes it completely. Though it can be long, it can go up to multiple paragraphs."
    assert parsed.blank_after_short_

# Generated at 2022-06-21 12:02:09.367571
# Unit test for function parse
def test_parse():
    docstr = """\
    Example for parsing a docstring without any meta-information.
    
    The last line should be left empty.
    """
    expected = Docstring(
        short_description='Example for parsing a docstring without any meta-information.',
        long_description='The last line should be left empty.',
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[],
    )
    assert expected == parse(docstr)

    docstr = """\
    Example for parsing a docstring without any meta-information.
    """

# Generated at 2022-06-21 12:02:18.912406
# Unit test for function parse
def test_parse():
    text = """\
short desc

:param type_name arg_name:
    long desc.

:param arg_name:
    long desc.

:returns:
    long desc.

:returns: type_name
    long desc.

:raises:
    long desc.

:raises: type_name
    long desc.

:yields:
    long desc.

:yields: type_name
    long desc.

"""

# Generated at 2022-06-21 12:02:20.182765
# Unit test for function parse
def test_parse():
    pass

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:02:31.869098
# Unit test for function parse
def test_parse():
    from pprint import pprint
    import os
    from file_read_backwards import FileReadBackwards
    from .docstring_parser import DocstringParser
    dir_path = os.path.dirname(os.path.realpath(__file__))
    with FileReadBackwards(dir_path + "/cwl_docstring.rst", encoding="utf-8") as rst_file:
        rst_data = rst_file.readlines()
        docstring_text = ''
        for line in rst_data:
            if ".. cwl-docstring" in line:
                break
            docstring_text += line

        docstring_text = docstring_text[::-1]
    # print(docstring_text)


# Generated at 2022-06-21 12:02:40.872912
# Unit test for function parse
def test_parse():

    from .numpydoc import parse

    def f(x):
        """Short description

        Long description
        """

    f.__doc__ = """Short description

    :param x: this is x
    :type x: int
    :returns: this is the return
    :rtype: int
    """

    assert parse(f.__doc__) == parse(inspect.getdoc(f))

    f.__doc__ = """Short description

    :param x: this is x
    :type x: int
    :returns: this is the return
    :rtype: int"""

    assert parse(f.__doc__) == parse(inspect.getdoc(f))


# Generated at 2022-06-21 12:02:50.098793
# Unit test for function parse
def test_parse():
    ds = parse("""
    Short description.

    Long description.

    :param x: The first parameter
    :type x: int
    :returns: The return value
    :rtype: int
    :raises ValueError: The exception
    """)
    assert ds.short_description == "Short description."
    assert ds.long_description == "Long description."

# Generated at 2022-06-21 12:03:07.733781
# Unit test for function parse

# Generated at 2022-06-21 12:03:10.092761
# Unit test for function parse
def test_parse():
    from .test_common import PARSING_TESTS
    for source, expected in PARSING_TESTS.items():
        d = parse(source)
        assert d == expected

# Generated at 2022-06-21 12:03:19.247464
# Unit test for function parse
def test_parse():
    doc = """
    Blah blah

    The long description.

    :param foo: The foo parameter.
    :param bar: The bar parameter. defaults to 'hello world'.
    :type bar: str
    :param baz: The baz parameter.
    :type baz: int?
    :param wiggle: The wiggle parameter. defaults to None.
    :rtype: str
    :returns: The return value.
    :yields: The yielded value.
    :raises ValueError: If things are broken.
    :raises: Another exception.
    """
    from . import base
    base.test_parse(parse, doc)


# Generated at 2022-06-21 12:03:30.533809
# Unit test for function parse

# Generated at 2022-06-21 12:03:41.255603
# Unit test for function parse
def test_parse():
    import re
    from .common import Docstring, DocstringMeta, DocstringParam, DocstringReturns, ParseError
    from pprint import pprint
    from itertools import islice

    def test_parse_re(parse_func):
        def inner(text, expected):
            assert parse_func(text) == expected
        return inner

    # no docstring
    test_parse_re(parse)("", Docstring())

    # one-line descriptions
    test_parse_re(parse)("Test.", Docstring(short_description="Test."))

    # single-line docstrings
    test_parse_re(parse)("Test.\n", Docstring(short_description="Test."))
    test_parse_re(parse)("Test.\n\n", Docstring(short_description="Test."))
    test_

# Generated at 2022-06-21 12:03:50.859517
# Unit test for function parse
def test_parse():
    docstr = "The dog is big\n:param str name: The name of the dog \n:type int: name is a string\n:"
    py40_output = {'short_description': 'The dog is big', 'long_description': None, 'blank_after_short_description': True, 'blank_after_long_description': True, 'meta': [DocstringMeta(args=['param', 'str', 'name'], description='The name of the dog '), DocstringMeta(args=['type', 'int'], description='name is a string')]}
    output = parse(docstr)
    assert output == py40_output



# Generated at 2022-06-21 12:04:01.834083
# Unit test for function parse

# Generated at 2022-06-21 12:04:11.872650
# Unit test for function parse
def test_parse():
    """Function to unit test ReST string parsing."""
    text = """
    Checks whether a data object is valid according to a schema.

    :param data: the data object to validate
    :type data: list or dict
    :param schema: the validation schema
    :type schema: list or dict
    :returns: True or raises ValidationError
    :rtype: bool
    :raises ValidationError: if the data object is invalid
    """

    doc = parse(text)
    assert doc.short_description == "Checks whether a data object is valid according to a schema."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert doc.long_description is None

# Generated at 2022-06-21 12:04:19.843339
# Unit test for function parse
def test_parse():
    def foo(bar, baz=None):
        """Short description.

        Long description

        :param bar: bar description
        :type bar: str
        :param baz: baz description. defaults to None.
        :type baz: int
        :returns: return description
        :rtype: str
        :raises ValueError: raises description
        """
        print("foo")
        pass

    docstring = inspect.getdoc(foo)
    print(docstring)
    print(parse(docstring))


# Generated at 2022-06-21 12:04:26.676701
# Unit test for function parse
def test_parse():
    from src.mypy_boto3_builder.docstring import parse
    text = """test
test test
:test test
:test test test
test
"""
    doc = parse(text)
    assert doc.short_description == "test"
    assert doc.long_description == "test test\n"
    assert doc.meta[0] == DocstringMeta(['test', 'test'], 'test\n')
    assert doc.meta[1] == DocstringMeta(['test', 'test', 'test'], 'test\n')

# Generated at 2022-06-21 12:04:51.401531
# Unit test for function parse
def test_parse():
    text = """Short description.

Long description.

:param arg1: description
:type arg1: int
:param arg2: description
:param arg3: description
:type arg3: str, optional
:param arg4: description
:param arg5: description
:param arg6: description
:type arg6: int, optional
:param arg7: description
:type arg7: int, optional, defaults to 42.
:raises Exception: if something bad happens
:returns: str
:yields: str
:yields: int
:rtype: str
:returns: None
:yields: str
    :raises Exception: if something bad happens
"""
    print(parse(text))

# Generated at 2022-06-21 12:05:02.817207
# Unit test for function parse
def test_parse():
    doc = '''Test docstring
    :param str foo: Foo as a string
    :param int? bar: Bar as an int.
    :param int baz: Bar as an int. 
        Defaults to zero.
    :returns: Test docstring
    '''
    ds = parse(doc)
    assert ds.short_description == "Test docstring"
    assert ds.blank_after_short_description == True
    assert ds.blank_after_long_description == False
    assert ds.long_description == None
    assert ds.meta[0]['arg_name'] == "foo"
    assert ds.meta[0]['is_optional'] == False
    assert ds.meta[0]['default'] == None

# Generated at 2022-06-21 12:05:11.952632
# Unit test for function parse
def test_parse():
    doc_text = """Summary line here.

Extended description here.

:param int arg1: the first value
:param arg2: the second value
:returns: One two.
:raises AttributeError: the answer
"""