

# Generated at 2022-06-21 11:55:22.324453
# Unit test for function parse
def test_parse():
    docstring = """
    Our short description here.

    Our long description here.

    :returns: x
             : int
    :keyword a:
    """
    ds = parse(docstring)
    assert ds.short_description == "Our short description here."
    assert ds.long_description == "Our long description here."
    assert ds.blank_after_short_description
    assert ds.blank_after_long_description
    assert ds.meta[0].args[0] == 'returns'
    assert ds.meta[0].description == 'x'
    assert ds.meta[0].type_name == 'int'
    assert ds.meta[1].args[0] == 'keyword'
    assert ds.meta[1].description == 'a'

# Generated at 2022-06-21 11:55:29.358164
# Unit test for function parse
def test_parse():
    docstring = """This is a short description.
This is a long description.

:param arg1: description for arg1
:param arg2: description for arg2
:type arg2: int
:param arg3: description for arg3
:type arg3: int
:param arg4: description for arg3
:type arg4: int?
:param arg5: description for arg3
:type arg5: str?
:param arg6: description for arg6, defaults to True.
:type arg6: bool
:returns: description for return value
:rtype: int
:raises ValueError: description for exception
:except ValueError: description for exception
:yields: description for generator
:yields int: description for generator

This is a long description.
"""

# Generated at 2022-06-21 11:55:40.233550
# Unit test for function parse
def test_parse():
    code = """Parses a ReST-style docstring into its components.

:param value: description of the value parameter
:type value:  ``str``
:returns:     description of the return value
:rtype:       ``int``
:raises TypeError: if `value` is not a string
"""

    docstring = parse(code)


# Generated at 2022-06-21 11:55:49.270865
# Unit test for function parse
def test_parse():
    test_doc = """
        short description of function

        Long description of function. This can span into multiple lines
        and should be stripped of indents.

        :param arg1: this is arg1
        :type arg1: int
        :param arg2: this is arg2
        :type arg2: str
        :raises KeyError: raises key error
        :returns: returns a value
    """


# Generated at 2022-06-21 11:56:00.699613
# Unit test for function parse
def test_parse():
    print('Testing parse')

# Generated at 2022-06-21 11:56:12.771911
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = """function nargin()
    Description:
    nargin returns the number of function input arguments given in the call to the currently executing function.
    """
    docstr = parse(text)
    assert docstr.long_description == 'nargin returns the number of function input arguments given in the call to the currently executing function.'
    assert docstr.short_description == 'function nargin()'
    assert len(docstr.meta) == 0

# Generated at 2022-06-21 11:56:24.318438
# Unit test for function parse
def test_parse():
    rst_docstring = """\
    One-line summary.
    Caption for this section.
    
    More detailed description, if desired.
    
    :param i: integer.
    :type i: int.
    :param j: string.
    :type j: str.
    :param k: optional string.
    :type k: str, optional.
    :returns: string.
    :rtype: str.
    :raises ValueError: if i < 0.
    """

    docstring = parse(rst_docstring)
    assert len(docstring.meta) == 6
    assert docstring.short_description == 'One-line summary'
    assert docstring.long_description == 'Caption for this section.\nMore detailed description, if desired.'

# Generated at 2022-06-21 11:56:35.945687
# Unit test for function parse
def test_parse():
    text = """This function solves problems :)
    :param foo: The foo
    :type foo: str
    :param bar: The bar defaults to 'baz'.
    :param baz: The baz
    :type baz: bool
    :returns: str
    :raises ValueError: Something went wrong
    """
    doc = parse(text)
    # Meta information
    assert doc.meta[0].args == ['foo', 'str']
    assert doc.meta[0].description == 'The foo'
    assert doc.meta[1].args == ['bar', 'str']
    assert doc.meta[1].description == "The bar defaults to 'baz'."
    assert doc.meta[2].args == ['baz', 'bool']
    assert doc.meta[2].description == 'The baz'
    assert doc.meta

# Generated at 2022-06-21 11:56:40.653043
# Unit test for function parse
def test_parse():
    docstring = '''    Add a number to another.

    Some other explanations about the add function.

    :param int a: The first number.
    :param int b: The second number.
    :return: The result.
    '''
    assert parse(docstring).short_description == 'Add a number to another.'
    assert parse(docstring).meta[2].description == 'The result.'



# Generated at 2022-06-21 11:56:50.882185
# Unit test for function parse
def test_parse():
    from .common import TEST_DOCSTRING_DATA
    from .utils import parse

    for text in TEST_DOCSTRING_DATA:
        try:
            docstring = parse(text)
        except ParseError as err:
            print(err)

    assert docstring
    assert isinstance(docstring.short_description, str)
    assert isinstance(docstring.long_description, str)
    assert isinstance(docstring.meta, list)
    assert isinstance(docstring.meta[0], DocstringMeta)
    assert isinstance(docstring.meta[1], DocstringParam)
    assert isinstance(docstring.meta[2], DocstringReturns)
    assert isinstance(docstring.meta[3], DocstringRaises)

# Generated at 2022-06-21 11:57:09.056720
# Unit test for function parse

# Generated at 2022-06-21 11:57:21.624665
# Unit test for function parse
def test_parse():
    docstr = """Short description of function.

    Long description of function.

    :param arg_name: Description of arg_name.
    :type arg_name: str

    :returns: Description of return value.
    :rtype: str
    """
    parsed_dict = parse(docstr)
    # test description section
    assert parsed_dict.short_description == "Short description of function."
    assert parsed_dict.long_description == "Long description of function."
    assert parsed_dict.blank_after_short_description is True
    assert parsed_dict.blank_after_long_description is False
    
    # test meta section
    assert isinstance(parsed_dict.meta[0], DocstringParam)
    assert parsed_dict.meta[0].arg_name == "arg_name"

# Generated at 2022-06-21 11:57:27.108000
# Unit test for function parse
def test_parse():
    doctext = inspect.getdoc(parse)
    d = parse(doctext)

    assert d.short_description == "Parse the ReST-style docstring into its components."
    assert d.long_description is not None
    assert len(d.meta) == 6

    assert isinstance(d.meta[5], DocstringReturns)
    assert d.meta[5].type_name == "`Docstring`"

# Generated at 2022-06-21 11:57:37.799677
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc("""
    Compute the sum of a iterable of numbers (NOT strings) and return the
    result. If the iterable is empty, return zero.

    :param iterable: iterable to sum
    :type iterable: iterable of numbers
    :rtype: numbers.Real
    :returns: the sum
    :raises TypeError: if not all arguments are numbers
    :raises TypeError: if any argument is not an iterable of numbers
    :raises TypeError: if any element of an iterable is not a number
    """)
    result = parse(docstring)
    assert result.short_description == (
        "Compute the sum of a iterable of numbers (NOT strings) "
        "and return the result. If the iterable is empty, return zero."
    )

# Generated at 2022-06-21 11:57:49.087153
# Unit test for function parse
def test_parse():
    assert parse(None) == Docstring()
    assert parse("") == Docstring()

    assert parse("short desc\n") == Docstring(
            short_description='short desc',
            blank_after_short_description=False,
            long_description=None,
            blank_after_long_description=False,
            meta=[]
        )

    assert parse("short desc\n\n") == Docstring(
            short_description='short desc',
            blank_after_short_description=True,
            long_description=None,
            blank_after_long_description=False,
            meta=[]
        )


# Generated at 2022-06-21 11:57:56.181118
# Unit test for function parse
def test_parse():
    assert parse("Test docstring") == Docstring(
        short_description="Test docstring",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse("Test docstring\n\nlong description") == Docstring(
        short_description="Test docstring",
        long_description="long description",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-21 11:58:07.909024
# Unit test for function parse

# Generated at 2022-06-21 11:58:18.733917
# Unit test for function parse
def test_parse():
    doc = """
        Foo.

        Bar.
    """
    res = parse(doc)
    assert(res.short_description == "Foo.")
    assert(res.long_description == "Bar.")
    assert(res.blank_after_short_description == True)
    assert(res.blank_after_long_description == False)
    assert(len(res.meta) == 0)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:58:26.261271
# Unit test for function parse
def test_parse():
    text = '''
        Registers a customizable resource.

        :param partition: the current partition
        :param name: the resource name
        :param type: the resource type (BigIP, GTM)
        :param collection: the collection
        :param config: the resource configuration
        :raises ResourceError: if something goes wrong
        :returns: an instance of the resource
    '''
    result = parse(text)
    assert result.short_description == "Registers a customizable resource."
    assert not result.blank_after_short_description
    assert result.long_description == "the resource configuration"
    assert result.blank_after_long_description
    assert len(result.meta) == 5
    assert isinstance(result.meta[0], DocstringParam)
    assert result.meta[0].arg_name == "partition"


# Generated at 2022-06-21 11:58:35.684698
# Unit test for function parse
def test_parse():
    from .import common
    try:
        ds = parse('''\
        Parse the ReST-style docstring into its components.
        :returns: parsed docstring
        ''')
        assert ds.short_description == 'Parse the ReST-style docstring into its components.'
        assert ds.long_description is None
        assert ds.meta == [
            common.DocstringReturns(
                args=[':returns:'],
                description='parsed docstring',
                type_name=None,
                is_generator=False
            )
        ]
    except Exception as e:
        print(e)
        raise




# Generated at 2022-06-21 11:58:54.570620
# Unit test for function parse
def test_parse():
    """Parse the ReST-style docstring into its components."""
    a_docstring = Docstring()

# Generated at 2022-06-21 11:59:06.303538
# Unit test for function parse
def test_parse():
    docstring_text = """This is a short description.

    This is a long description.
    This is a long description.
    This is a long description.

    :param int a: param a
    :type a: int
    :param int b: param b
    :type b: int
    :param int c: param c
    :type c: int
    :param int d: param d
    :type d: int
    :returns: return value
    :rtype: None
    :raises: exception
    :except: exception
    """
    p = parse(docstring_text)
    assert p.short_description == "This is a short description."
    assert p.long_description == "This is a long description.\n\
This is a long description.\n\
This is a long description."
    assert len

# Generated at 2022-06-21 11:59:15.296209
# Unit test for function parse
def test_parse():
    assert parse("abc\n\n") == Docstring("abc\n ", None)
    assert parse("abc\ndef\n\n") == Docstring("abc", "def")
    assert parse("abc\n\n: type: int\ndef\n\n") == Docstring("abc", "def")
    assert parse("abc\n\n: type: int\ndef\n\n") == Docstring("abc", "def")
    assert parse("abc\n\n: param int x:") == Docstring("abc\n ", [
        DocstringParam(['param', 'int', 'x'], None, 'x', 'int', False, None)])

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:59:23.961921
# Unit test for function parse
def test_parse():
    rst = __doc__

    actual = parse(rst)
    assert actual.short_description == "ReST-style docstring parsing."
    assert actual.blank_after_short_description
    assert actual.long_description == """\
        :param str text: the docstring to parse, excluding the opening quotes
            and closing quotes

        :returns: parsed docstring
    """
    assert actual.blank_after_long_description

    assert len(actual.meta) == 2
    assert actual.meta[0].args == ["param", "str", "text"]
    assert actual.meta[0].description == (
        "the docstring to parse, excluding the opening quotes and "
        "closing quotes"
    )
    assert actual.meta[1].args == ["returns"]

# Generated at 2022-06-21 11:59:35.749174
# Unit test for function parse
def test_parse():
    """Test parse()"""
    assert parse("") == Docstring()
    assert parse(":a: b") == Docstring(meta=[DocstringMeta(args=["a"], description="b")])
    assert parse(":a: b\n") == Docstring(meta=[DocstringMeta(args=["a"], description="b")])
    assert parse(":a: b\n:c: d") == Docstring(meta=[
        DocstringMeta(args=["a"], description="b"),
        DocstringMeta(args=["c"], description="d")
    ])
    assert parse(":a: b\n:c: d\n") == Docstring(meta=[
        DocstringMeta(args=["a"], description="b"),
        DocstringMeta(args=["c"], description="d")
    ])

# Generated at 2022-06-21 11:59:43.903144
# Unit test for function parse
def test_parse():
    docstring = """
    This function does something.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """
    docstring_result = parse(docstring)
    assert docstring_result.short_description == "This function does something."
    assert docstring_result.blank_after_short_description
    assert docstring_result.long_description is None
    assert docstring_result.blank_after_long_description is False
    assert docstring_result.meta[0].arg_name == "arg1"
    assert docstring_result.meta[0].description == "The first argument."
    assert docstring_result.meta[1].arg_name == "arg2"
    assert docstring_result.meta[1].description == "The second argument."


# Generated at 2022-06-21 11:59:52.639262
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring = parse("""
        This is a short description.

        This is the long description.

        :param str arg_name: arg description
        :returns: return description
        :raises TypeError: exception description
        """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is True
    assert docstring.meta[0].type_name == "str"
    assert docstring.meta[0].is_optional is False
    assert docstring.meta[1].type_name is None
    assert docstring.meta[2].type_name == "TypeError"
    assert docstring

# Generated at 2022-06-21 12:00:03.682359
# Unit test for function parse
def test_parse():
    text = '''
        :param arg1 arg1 description
        :type arg1: int
        :param arg2 arg2 description
        :type arg2: str
        :param arg3 arg3 description
        :param arg4 arg4 description
        :type arg4: int
        :param arg5 arg5 description
        :type arg5:
        :param arg6: arg6 description
        :type arg6: str
        :rtype: int
        :return: return description
        :returns: return description
        :yield: yield description
        :yields: yield description
        :raises: raise description
        :raises ValueError: raise description
    '''
    print(parse(text))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:00:15.071972
# Unit test for function parse
def test_parse():
    """Testing method 'parse' of module 'rest_docstring_parser'."""

    # Test a very simple docstring without any meta information
    docstring = """\
        A very simple docstring without any meta information.
        """
    result = parse(docstring)
    assert result.short_description == "A very simple docstring without any meta information."
    assert not result.blank_after_short_description
    assert not result.long_description
    assert not result.blank_after_long_description
    assert len(result.meta) == 0

    # Test a more complicated docstring with meta information
    docstring = """\
        A simple docstring with meta information.

        :keyword argument: specifies the keyword argument.
        :returns: the return value
        """
    result = parse(docstring)

# Generated at 2022-06-21 12:00:26.279272
# Unit test for function parse

# Generated at 2022-06-21 12:00:39.484472
# Unit test for function parse
def test_parse():
    docstring = """
    A short description

    Here is a long description.
    """

    doc = parse(docstring)
    assert doc.short_description == "A short description"
    assert doc.long_description == "Here is a long description."
    assert len(doc.meta) == 0

# Generated at 2022-06-21 12:00:50.911620
# Unit test for function parse
def test_parse():
    doc = """
    Short description.

    Long description.

    :param str foo: Description of `foo`.
    :param int bar: Description of `bar`.
    :param baz: Description of `baz`.
    :returns: Description of the return value.
    :rtype: int
    :raises ValueError: Description of the exception.
    """

    docstring = parse(doc)
    assert docstring.short_description == "Short description."
    assert (
        docstring.long_description == "Long description."
    )
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is True
    assert docstring.meta[0].type_name == "str"
    assert docstring.meta[0].arg_name == "foo"

# Generated at 2022-06-21 12:00:59.376866
# Unit test for function parse
def test_parse():
    text = """short desc
    long desc
    long desc
    :param x: foo
    :param y: bar
    :return: foobar
    """
    res = parse(text)
    assert res.short_description == "short desc"
    assert res.long_description == "long desc\nlong desc"
    assert len(res.meta) == 3
    assert repr(res.meta[0]) == "DocstringMeta(args=['param', 'x'], description='foo')"
    assert repr(res.meta[1]) == "DocstringMeta(args=['param', 'y'], description='bar')"
    assert repr(res.meta[2]) == "DocstringMeta(args=['return'], description='foobar')"

# Generated at 2022-06-21 12:01:02.151829
# Unit test for function parse
def test_parse():
    custom_title = "Custom Title"
    docstring = parse.__doc__
    assert parse(docstring).short_description == custom_title


# Generated at 2022-06-21 12:01:13.019454
# Unit test for function parse

# Generated at 2022-06-21 12:01:22.708247
# Unit test for function parse
def test_parse():
    doc = parse(
        """
    This is a docstring.

    This is the long description of the docstring.

    :param a: foo
    :type a: str
    :param b: bar
    :param c: baz
    :returns: foobar
    :rtype: str
    :raises ValueError: if the foobar is invalid.
    """
    )
    assert doc.short_description == "This is a docstring."

    assert doc.long_description == "This is the long description of the docstring."

    assert doc.blank_after_short_description
    assert doc.blank_after_long_description

    assert len(doc.meta) == 4

    assert doc.meta[0].key == "param"
    assert doc.meta[0].arg_name == "a"

# Generated at 2022-06-21 12:01:32.184764
# Unit test for function parse
def test_parse():
    """Unit tests for the function parse()."""
    ret = parse("")
    assert ret.short_description == ""
    assert ret.long_description == ""
    assert ret.meta == []

    ret = parse("text")
    assert ret.short_description == "text"
    assert ret.long_description == ""
    assert ret.meta == []

    ret = parse("text\n")
    assert ret.short_description == "text"
    assert ret.long_description == ""
    assert ret.meta == []

    ret = parse("text\n\n")
    assert ret.short_description == "text"
    assert ret.long_description == ""
    assert ret.meta == []

    ret = parse("text\n\ntext")
    assert ret.short_description == "text"
    assert ret.long_description

# Generated at 2022-06-21 12:01:42.409815
# Unit test for function parse
def test_parse():
    from .numpydoc_utils import dedent

    def docstring_without_meta(docstring):
        return docstring.split("\n")[0] + "\n"

    assert docstring_without_meta(parse("").__str__()) == ""

    assert docstring_without_meta(
        parse("hello").__str__()
    ) == dedent("""
    hello
    """)

    assert docstring_without_meta(
        parse("hello\n").__str__()
    ) == dedent("""
    hello
    """)

    assert docstring_without_meta(
        parse("hello\n\nworld").__str__()
    ) == dedent("""
    hello

    world
    """)


# Generated at 2022-06-21 12:01:50.537095
# Unit test for function parse
def test_parse():
    rst = """
        A function that does nothing.
        Really.

        :type z: int
        :param z: a test parameter
    """
    docs = parse(rst)
    assert docs.short_description == "A function that does nothing."
    assert docs.long_description == "Really."
    assert docs.blank_after_short_description
    assert not docs.blank_after_long_description
    assert len(docs.meta) == 1
    assert docs.meta[0].arg_name == 'z'
    assert docs.meta[0].type_name == 'int'

# Generated at 2022-06-21 12:01:52.736392
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    assert(parse("") == Docstring())
    print("test_parse: pass")

test_parse()

# Generated at 2022-06-21 12:02:08.960854
# Unit test for function parse
def test_parse():
    docstring = """
    This is the docstring for a function
    """
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == "This is the docstring for a function"

    docstring = """
    This is the docstring for a function
    :param arg_name: param description
    """
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == "This is the docstring for a function"
    assert parsed_docstring.meta[0].arg_name == "arg_name"
    assert parsed_docstring.meta[0].description == "param description"
    assert parsed_docstring.meta[0].type_name is None
    assert parsed_docstring.meta[0].is_optional is None

# Generated at 2022-06-21 12:02:18.620328
# Unit test for function parse
def test_parse():
    text = """This function does something.
    
    :param a: The first parameter.
    :param b: The second parameter.
    :param c: The third parameter.
    :returns: Something
    :raises ValueError: If something bad happens.
    
    Extra comments.
    
    """
    docstring = parse(text)
    assert docstring.short_description == "This function does something."
    assert docstring.long_description == (
        "Extra comments."
    )
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is True
    assert docstring.meta[0].args == ["param", "a"]
    assert docstring.meta[0].description == "The first parameter."

# Generated at 2022-06-21 12:02:26.031349
# Unit test for function parse
def test_parse():
    text = """
    f(x, y):: z: int = 2 -> x + y + z
    """
    doc = parse(text)
    assert doc.short_description == 'f(x, y)'
    assert doc.meta[0].arg_name == 'z'
    assert doc.meta[0].is_optional == True
    assert doc.meta[0].default == '2'
    assert doc.meta[1].type_name == 'int'

# Generated at 2022-06-21 12:02:26.883895
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-21 12:02:36.764861
# Unit test for function parse
def test_parse():
    '''
    Test the functionality and corrrectness of dump and parse
    '''
    from .common import DocstringParam, DocstringReturns, DocstringRaises
    from .common import DocstringParam, DocstringReturns, DocstringRaises, DocstringMeta

# Generated at 2022-06-21 12:02:47.835533
# Unit test for function parse

# Generated at 2022-06-21 12:02:59.164478
# Unit test for function parse
def test_parse():
    # test_normal_docstring
    ds = u"""This is a test for normal docstrings.

    With a multi-line description.
    """
    assert parse(ds).short_description == u"This is a test for normal docstrings."
    assert parse(ds).long_description == u"With a multi-line description."
    assert parse(ds).blank_after_short_description == True
    assert parse(ds).blank_after_long_description == True

    # test_all_arguments_section

# Generated at 2022-06-21 12:03:09.625809
# Unit test for function parse
def test_parse():
    docstring = parse("""Documentation for the top-level parse function.

    This function takes a docstring, which is a string, as its only
    argument.  The docstring is parsed into its parts, and returned
    as an instance of the Docstring class.

    :param docstring: The docstring to be parsed.
    :type docstring: str
    :returns: The parsed docstring.
    :rtype: Docstring
    :raises ParseError: If the docstring is not valid.
    """)
    assert docstring.short_description == "Documentation for the top-level parse function."
    assert docstring.long_description.startswith("This function takes a docstring,")
    assert len(docstring.meta) == 3

# Generated at 2022-06-21 12:03:17.471768
# Unit test for function parse
def test_parse():
    """Test the function parse."""
    data = parse("""
    Short description.

    Long description.

    :rtype: str
    :return: a string
    """)
    assert data.short_description == "Short description."
    assert data.long_description == "Long description."
    assert not data.blank_after_short_description
    assert not data.blank_after_long_description
    assert data.meta[0].args == ["rtype", "str"]
    assert data.meta[1].args == ["return"]
    assert data.meta[1].description == "a string"

# Generated at 2022-06-21 12:03:25.638111
# Unit test for function parse
def test_parse():


    # -------------------- Short Description --------------------
    docstring = """
    This is a short description
    """
    parsed_docstring = parse(docstring)
    assert(parsed_docstring.short_description == "This is a short description")
    assert(len(parsed_docstring.long_description) == 0)
    assert(parsed_docstring.blank_after_short_description == False)
    assert(parsed_docstring.blank_after_long_description == True)
    assert(len(parsed_docstring.meta) == 0)

    # -------------------- Long Description --------------------
    docstring = """
    This is a short description

    This is a long description that is separated from
    the short description by a blank line
    """
    parsed_docstring = parse(docstring)

# Generated at 2022-06-21 12:03:38.542027
# Unit test for function parse
def test_parse():
    doc_string_1 = """

    1. This is the first function.
    2. This function is used to find the sum of two numbers.
    3. It is known to have bugs, and is not to be trusted.

    :param float a: First number
    :param float b: Second number
    :return float: Sum of the two numbres

    """
    doc = parse(doc_string_1)
    assert doc.short_description == "1. This is the first function."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.long_description == "2. This function is used to find the sum of two numbers.\n3. It is known to have bugs, and is not to be trusted."
    assert len(doc.meta) == 3

# Generated at 2022-06-21 12:03:50.346550
# Unit test for function parse
def test_parse():
    text = 'This is test docstring.\n'
    doc = parse(text)
    assert (doc.short_description == 'This is test docstring.')
    assert (doc.long_description is None)

    text = 'This is test docstring.\n\nThis is test long description.'
    doc = parse(text)
    assert (doc.short_description == 'This is test docstring.')
    assert (doc.long_description == 'This is test long description.')
    assert (doc.blank_after_short_description is True)
    assert (doc.blank_after_long_description is False)

    text += '\n'
    doc = parse(text)
    assert (doc.blank_after_long_description is True)
    assert (doc.blank_after_short_description is True)

    text

# Generated at 2022-06-21 12:04:01.142982
# Unit test for function parse
def test_parse():
    import textwrap

    meta_str = textwrap.dedent(
        """\
    :param arg: argument
    :param bool arg: argument
    :param bool arg: defaults to True. argument
    :param bool arg: argument. defaults to True.
    :param arg=True: argument
    :param arg?: argument
    :param arg?: defaults to True. argument
    :param arg?: argument. defaults to True.
    :param arg?: argument. defaults to True.
    :param arg?: defaults to True. argument.
    :param arg: defaults to True. argument
    :param arg: argument. defaults to True.
    :param arg: defaults to True. argument.
    """
    )

    desc_str = textwrap.dedent(
        """\
    Short description.

    Long description.

    """
    )

    result

# Generated at 2022-06-21 12:04:11.582082
# Unit test for function parse
def test_parse():
    docstring_a = """
        A short description.

        A longer description.

        :param arg1: The first argument.
        :type arg1: int
        :param arg2: The second argument.
        :type arg2: str
        :param arg3: The third argument.
        :type arg3: Optional[str]
        :param arg4: The fourth argument, defaults to True.
        :type arg4: bool
        :param arg5: The fifth argument, defaults to "hello".
        :type arg5: str
        :raises ValueError: If arg2 is invalid.
        :returns: None
        """
    docstring_b = """
        A short description.

        A longer description.

        :param arg1: The first argument.
        """

# Generated at 2022-06-21 12:04:23.029199
# Unit test for function parse
def test_parse():
    doc = """
    Short description.
    Long description.

    :param arg1: Description of arg1.
    :type arg1: int
    :param arg2: Description of arg2.
    :type arg2: str
    :param arg3: Description of arg3.
    :type arg3: int?
    :param arg4: Description of arg4. Defaults to 'hello'.
    :return: Description of the return value.
    :rtype: int
    :raises ValueError: Description of a raised error.
    :raises TypeError: Description of another raised error.
    """

    result = parse(doc)
    assert isinstance(result.short_description, str)
    assert isinstance(result.long_description, str)
    assert isinstance(result.blank_after_short_description, bool)

# Generated at 2022-06-21 12:04:28.858970
# Unit test for function parse
def test_parse():
    text = '''
    Test function.
    :param foo: Test argument.
    :type foo: int
    :returns: Test return value.
    :rtype: str
    :raises ValueError: Test exception.
    '''
    doc = parse(text)
    assert doc.short_description == "Test function."
    assert doc.long_description is None
    assert doc.meta[0].description == "Test argument."
    assert doc.meta[1].description == "Test return value."
    assert doc.meta[2].description == "Test exception."

# Generated at 2022-06-21 12:04:39.223536
# Unit test for function parse
def test_parse():
    text = """This is a test function

    A long description of this function

    :param str value: This is the value
    :param int count: This is the number of times to repeat, defaults to 1
    :param bool some_flag: This is a flag
    :returns: A string
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function"
    assert docstring.long_description == "A long description of this function"
    assert not docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    param1, param2, param3 = docstring.meta
    assert isinstance(param1, DocstringParam)
    assert not param1.default
    assert not param1.is_

# Generated at 2022-06-21 12:04:50.118191
# Unit test for function parse
def test_parse():
    # Test example in docstring
    text = 'Return “foo”, optionally multiplied by the number of “foos”.\n\n:param int foos:\n    The number of “foos”.\n:param str symbol:\n    The symbol representing “foo”. Defaults to ``"foo"``.\n:raises ValueError:\n    If ``foos < 0``.\n\n:returns str:\n    The resulting “foo” string.'
    assert parse(text).short_description == "Return “foo”, optionally multiplied by the number of “foos”."

# Generated at 2022-06-21 12:05:01.121408
# Unit test for function parse
def test_parse():
    doc = """\
        This is a test.

        Another paragraph.

        :arg param1: Description of param1. Defaults to 42.
        :arg param2: Description of param2.
        :arg param3: Description of param3.
        :type param2: str
        :type param3: int
        :returns: Description of return value.
        :rtype: int
        :raises ValueError: Description of exception.
        """

    docstr = parse(doc)

    assert docstr.short_description == "This is a test."
    assert docstr.blank_after_short_description is False

    assert docstr.long_description == "Another paragraph."
    assert docstr.blank_after_long_description is True

    assert len(docstr.meta) == 5
