

# Generated at 2022-06-21 11:55:27.345542
# Unit test for function parse

# Generated at 2022-06-21 11:55:38.830562
# Unit test for function parse
def test_parse():
    # Single line docstring
    assert parse('a short description') == Docstring(
        short_description='a short description',
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[]
    )

    # With a blank line after the short description
    assert parse('a short description\n') == Docstring(
        short_description='a short description',
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[]
    )

    # With a blank line before the short description

# Generated at 2022-06-21 11:55:48.564779
# Unit test for function parse
def test_parse():
    """
    Description of a function

    Args:
        arg1 (int): Description of arg1.
        arg2 (List[int]): Description of arg2.
        arg3 (int, optional): Description of arg3, defaults to 3.
        arg4 (int, optional, default=3): Description of arg4.
        arg5 (int): Description of arg5.

    Returns:
        int: Description of return value.

    Yields:
        int: Description of yielded values.

    Raises:
        RuntimeError: Description of exception.
        ValueError: Description of exception.

    Notes:
        Note.
    """


# Generated at 2022-06-21 11:56:00.146935
# Unit test for function parse
def test_parse():
    docstring = """
    One Line Description
    :param name: Description for name.
    :type name: str
    :param age: Description for age.
    :type age: int
    :return: Description for return.
    :rtype: str
    :raises KeyError: Description for KeyError.
    :raises IndexError: Description for IndexError.
    """
    d = parse(docstring)
    assert d.short_description == "One Line Description"
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.long_description == None
    assert d.meta[0].arg_name == "name"
    assert d.meta[0].type_name == "str"
    assert d.meta[1].arg_name == "age"


# Generated at 2022-06-21 11:56:07.795293
# Unit test for function parse
def test_parse():
    text = '''
        Short description.
        Long description.
        :param name: The name to use.
        :type name: str
        :param int verbose: The verbosity level.
        :returns: None
        :raises ValueError: If `name` is empty.
        '''
    doc = parse(text)
    # print(doc)
    assert 0


# Generated at 2022-06-21 11:56:18.990267
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    assert parse("\n") == Docstring()

    docstring = parse("""
Foo bar.

Baz qux.
""")
    assert docstring.short_description == "Foo bar."
    assert docstring.blank_after_short_description
    assert docstring.long_description == "Baz qux."
    assert docstring.blank_after_long_description
    assert not docstring.meta

    docstring = parse("""
Foo bar.

Baz qux.

: param t:
: type t: int
: return:
: rtype: str
: raises:
: except:
: yield:
: yield from:
: yield to:
""")
    assert docstring.short_description == "Foo bar."
    assert docstring.blank_

# Generated at 2022-06-21 11:56:28.781637
# Unit test for function parse
def test_parse():
    assert Docstring(
        short_description="Description",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    ) == parse(":Description:")

    assert Docstring(
        short_description="Description",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    ) == parse(":Description:\n")

    assert Docstring(
        short_description="Description",
        blank_after_short_description=False,
        long_description="Long Description",
        blank_after_long_description=False,
        meta=[],
    ) == parse(":Description:\nLong Description:")


# Generated at 2022-06-21 11:56:35.051025
# Unit test for function parse
def test_parse():
    ds = parse(
    """
    This function returns a new string object with
    its value as argument.

    :param: str: The desired string
    :returns: str: the result string
    """
    )

    assert ds.short_description == "This function returns a new string object with its value as argument."
    assert ds.long_description == "The desired string\n\nthe result string"

# Generated at 2022-06-21 11:56:42.797379
# Unit test for function parse

# Generated at 2022-06-21 11:56:53.359998
# Unit test for function parse
def test_parse():

    docstring = parse("This is a short description.\n\nThis is a long description.")
    assert docstring.short_description == 'This is a short description.'
    assert docstring.long_description == 'This is a long description.'
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []

    docstring = parse("This is a short description.\n\nThis is a long description.\n\nThis is a really really long description.")
    assert docstring.short_description == 'This is a short description.'
    assert docstring.long_description == 'This is a long description.\n\nThis is a really really long description.'
    assert docstring.blank_after_short_description == True
    assert docstring.blank_

# Generated at 2022-06-21 11:57:10.495537
# Unit test for function parse
def test_parse():
    text = """\
    Randomly sample elements from an array.

    :param in_array: Input array.
    :type in_array: ndarray
    :param sample_size: Number of samples to draw.
    :type sample_size: int
    :returns: Array of sampled elements.
    :rtype: ndarray
    """
    ret = Docstring()
    ret.short_description = "Randomly sample elements from an array."
    ret.long_description = """\
    Parameters
    ----------
    in_array : ndarray
        Input array.
    sample_size : int
        Number of samples to draw.

    Returns
    -------
    ndarray
        Array of sampled elements.
    """
    assert parse(text) == ret

# Generated at 2022-06-21 11:57:23.317726
# Unit test for function parse
def test_parse():
    """Test the parse function."""
    docstring = inspect.cleandoc(
        """
    Short description.

    Longer description.

    :param x: This is the first parameter.
    :param y: This is the second parameter.
    :type y: str
    :param z: This is a parameter with a default value.
    :rtype: bool
    :returns: This is what is returned.
    :raises ValueError: If something bad happens.

    """
    )

# Generated at 2022-06-21 11:57:25.726283
# Unit test for function parse
def test_parse():
    test_string =  """
    Compute the square of a number.

    :param int num: A number to compute the square of.
    :returns: The square of the number.

    :Example:
        >>> square(2)
        4
        >>> square(3)
        9
    """

    print(parse(test_string))

# Generated at 2022-06-21 11:57:33.202695
# Unit test for function parse
def test_parse():
    s = '''short description
    :param arg: parameter description
    :returns: return description
    :raises Exception: raises description
    '''
    d = parse(s)
    assert d.short_description == "short description"
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert len(d.meta) == 3
    assert d.meta[0].args == ["param", "arg"]
    assert d.meta[0].description == "parameter description"
    assert d.meta[1].args == ["returns"]
    assert d.meta[1].description == "return description"
    assert d.meta[2].args == ["raises", "Exception"]
    assert d.meta[2].description == "raises description"

# Generated at 2022-06-21 11:57:45.670705
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :type: type
    :param: aaa
    :param bbb:
    :param ccc ddd: eee
    :type: type
    :type fff:
    :param ggg: hhh

    :raises: Error
    :raises ValueError: A value error occurred

    :return:
    :returns int:
    :rtype: bool
    :rtype str:

    :yield:
    :yields bool:
    :ybool:
    """

    parsed = parse(docstring)

# Generated at 2022-06-21 11:57:53.754921
# Unit test for function parse
def test_parse():
    s = inspect.cleandoc("""
        A short summary.

        A longer explanation.

        :param str name: parameter one
        :param int age: parameter two
        :param str<Foo>? name: parameter three

        :returns: returns nothing
        :returns str: returns a string

        :raises: raises a generic exception
        :raises ValueError: raises a value error
    """)

    ds = parse(s)
    assert ds.short_description == "A short summary."
    assert ds.long_description == "A longer explanation."
    assert not ds.blank_after_short_description
    assert ds.blank_after_long_description
    assert ds.meta[0].args == ["param", "str", "name"]

# Generated at 2022-06-21 11:58:05.243792
# Unit test for function parse
def test_parse():
    f = '''
    """
    Test Function

    :param text: docstring text
    :param limit: maximum line length
    :returns: parsed docstring

    Raises: ValueError

    :raises:  ValueError
    :returns: int
    """
    '''
    r = parse(f)
    print(r)
    assert r.short_description == 'Test Function'

    assert r.meta[0].__class__ == DocstringParam
    assert r.meta[0].type_name == 'text'
    assert r.meta[0].arg_name == 'docstring text'
    assert r.meta[1].__class__ == DocstringParam
    assert r.meta[1].type_name == 'limit'
    assert r.meta[1].arg_name == 'maximum line length'


# Generated at 2022-06-21 11:58:14.145279
# Unit test for function parse
def test_parse():
    docstring = parse(
        """
        Short description.

        Long description.

        :param int foo: Foo is an integer.
        :param str bar: Bar is a string.
        :return: No return.
        """
    )

    assert docstring.short_description == "Short description."
    assert docstring.blank_after_short_description
    assert docstring.long_description == "Long description."
    assert not docstring.blank_after_long_description
    assert docstring.meta[0].arg_name == "foo"
    assert docstring.meta[0].type_name == "int"
    assert docstring.meta[0].is_optional is None
    assert docstring.meta[0].default is None
    assert docstring.meta[0].description == "Foo is an integer."


# Generated at 2022-06-21 11:58:23.456331
# Unit test for function parse
def test_parse():
    s = """
First line. 
Second line.
"""
    assert parse(s) == Docstring()

    s = """
First line.
: param arg1: first arg.
: param arg2: second arg.
: type arg3: str
: param arg3: third arg.
"""
    d = Docstring()
    d.short_description = "First line."
    d.long_description = "Second line."
    d.meta.append(DocstringMeta(["param", "arg1"], "first arg."))
    d.meta.append(DocstringMeta(["param", "arg2"], "second arg."))
    d.meta.append(DocstringMeta(["type", "arg3"], "str"))
    d.meta.append(DocstringMeta(["param", "arg3"], "third arg."))

# Generated at 2022-06-21 11:58:35.009580
# Unit test for function parse

# Generated at 2022-06-21 11:58:45.215425
# Unit test for function parse
def test_parse():
    docstr = inspect.getdoc(parse)
    parse(docstr)

test_parse()

# Generated at 2022-06-21 11:58:56.228349
# Unit test for function parse
def test_parse():
    from .test_common import sample_docstring

    docstring = sample_docstring()
    parsed_docstring = parse(docstring)

    # Test short description is parsed correctly
    assert parsed_docstring.short_description == "This is a sample docstring"

    # Test description is parsed correctly
    assert parsed_docstring.long_description == (
        "This is a sample docstring.\nIt is indented.\n\nHere is a line after a blank."
    )

    # Test blank lines between short and long descriptions
    assert parsed_docstring.blank_after_short_description is False
    assert parsed_docstring.blank_after_long_description is False

    # Test parameters are parsed correctly
    arg1_param = parsed_docstring.meta[0]

# Generated at 2022-06-21 11:59:06.849993
# Unit test for function parse
def test_parse():
    doc = \
"""Test function for parse module.

This function does this.
And this.

Params:
    param_1  :  int  param1 description
    param_2  :  str  param2 description
                  with multiple lines.
    param_3?  :  bool  param3 description
                       with multiple lines.
                       Defaults to true.
    param_4?  :  int  param4 description.
                   Defaults to 1.
    param_5  :  float  param5 description with multiple lines.
Returns:
    int  return description
"""
    result = parse(doc)
    assert result.short_description == 'Test function for parse module.'
    assert result.long_description == 'This function does this.\nAnd this.'
    assert result.blank_after_long_description == True
    assert result

# Generated at 2022-06-21 11:59:16.440434
# Unit test for function parse
def test_parse():
    """Test function parse"""
    assert parse('').short_description == None
    assert parse('Example docstring.').short_description == 'Example docstring.'
    assert parse('Example docstring.\n\n    A long description.').short_description == 'Example docstring.'
    assert parse('Example docstring.\n\n    A long description.').long_description == 'A long description.'
    assert parse('Example docstring.\n\n    A long description.').blank_after_short_description == True
    assert parse('Example docstring.\n\n    A long description.').blank_after_long_description == True
    assert parse('Example docstring.\n\n    A long description.').meta == []
    assert parse('Example docstring.\n\n    A long description.').meta == []

# Generated at 2022-06-21 11:59:24.140967
# Unit test for function parse
def test_parse():
    # Test for single line docstring
    assert parse("Test document string").short_description == "Test document string"
    # Test for docstring with long description
    docstring_long = "Test document string\nThis is a long description of test\nstring"
    assert parse(docstring_long).short_description == "Test document string"
    assert parse(docstring_long).long_description == "This is a long description of test\nstring"

    docstring_long_newlines = "Test document string\n\nThis is a long description of test\n\nstring"
    assert parse(docstring_long_newlines).short_description == "Test document string"
    assert parse(docstring_long_newlines).long_description == "This is a long description of test\n\nstring"

# Generated at 2022-06-21 11:59:35.961831
# Unit test for function parse

# Generated at 2022-06-21 11:59:37.084190
# Unit test for function parse
def test_parse():
    # TODO
    pass

# Generated at 2022-06-21 11:59:39.019669
# Unit test for function parse
def test_parse():
    """Unit test for function parse
    """
    assert parse(__doc__).short_description == "ReST-style docstring parsing."

# Generated at 2022-06-21 11:59:50.129005
# Unit test for function parse

# Generated at 2022-06-21 12:00:02.071161
# Unit test for function parse
def test_parse():
    docstring = """
    Prints a message out to the screen.

    :param message: The message to print.
    :type message: str
    :returns: True if successful, False otherwise.
    :rtype: bool
    """
    parsed = parse(docstring)

# Generated at 2022-06-21 12:00:18.533139
# Unit test for function parse

# Generated at 2022-06-21 12:00:29.331951
# Unit test for function parse

# Generated at 2022-06-21 12:00:40.992355
# Unit test for function parse

# Generated at 2022-06-21 12:00:52.659229
# Unit test for function parse
def test_parse():
    """Test Docstring parsing

    :returns: dict of parsed docstrings test
    """
    parsed = {
        'short_description': None, 
        'long_description': None, 
        'blank_after_short_description': None, 
        'blank_after_long_description': None, 
        'meta': []}
    assert (parse("") == parsed)
    assert (parse(" ") == parsed)
    assert (parse("\n") == parsed)
    assert (parse("\n\n") == parsed)
    assert (parse("\n\n\n") == parsed)
    assert (parse("\n \n") == parsed)

# Generated at 2022-06-21 12:01:00.657864
# Unit test for function parse
def test_parse():
    docstring = """
This is a short description.

This is a long description.

:param x: This is the first parameter.
:param y?: This is the second parameter.
:param y?: This is the second parameter.
:param int y?: This is the second parameter.
:param int y? defaults to 3.
:param int y? defaults to 3. This is the second parameter.
:returns str: This is the return
:yields str: This is the yield
:raises ValueError: This is the raise
"""
    # test the basic formatting
    print(docstring)
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")

# Generated at 2022-06-21 12:01:11.856784
# Unit test for function parse
def test_parse():
    assert parse("""
    A short description.

    A long description.
    """).short_description == "A short description."
    assert parse("""
    A short description.

    A long description.
    """).long_description == "A long description."
    assert parse("""
    A short description.

    A long description.

    """).long_description == "A long description."
    assert parse("""
    A short description.

    A long description.

    """).blank_after_long_description is True
    assert parse("""
    A short description.

    A long description.

    """).blank_after_short_description is False

# Generated at 2022-06-21 12:01:21.595017
# Unit test for function parse
def test_parse():
    dstring = ("This is a sample docstring\n"
    "that spans two lines.\n"
    "\n"
    ":param arg1: This is the first positional argument.\n"
    ":param arg2: This is the second positional argument.\n"
    ":param arg3: This is a keyword only argument.\n"
    ":type arg3: This is a keyword only argument.\n"
    ":raises keyError: Raises an exception.\n"
    ":return: Nothing.\n"
    ":rtype: Nothing.\n")
    result = parse(dstring)
    print(result)
    assert result["long_description"] == "This is a sample docstring\n" \
                                        "that spans two lines."

# Generated at 2022-06-21 12:01:32.111833
# Unit test for function parse
def test_parse():
    docString = parse("Parse the ReST-style docstring into its components.")
    assert docString.short_description == "Parse the ReST-style docstring into its components."
    assert docString.long_description is None
    docString = parse("""
    Parse the ReST-style docstring into its components.
    """)
    assert docString.short_description == "Parse the ReST-style docstring into its components."
    assert docString.long_description is None
    docString = parse("""
    Parse the ReST-style docstring into its components.

    :param text: The text to parse.
    """)
    assert docString.short_description == "Parse the ReST-style docstring into its components."
    assert docString.long_description is None

# Generated at 2022-06-21 12:01:42.334490
# Unit test for function parse

# Generated at 2022-06-21 12:01:51.584485
# Unit test for function parse
def test_parse():
    text = '''
    Test function parse in rest.py

    Args:
      param1: Test Param 1
      param2: Test Param 2
      param3 (int): Test Param 3

    Returns:
      Type: Test description

    Yields:
      Test description

    Raises:
      Test description
    '''
    result = parse(text)
    assert len(result.meta) == 4
    assert isinstance(result.meta[0], DocstringParam)
    assert isinstance(result.meta[1], DocstringReturns)
    assert isinstance(result.meta[2], DocstringReturns)
    assert isinstance(result.meta[3], DocstringRaises)

# Generated at 2022-06-21 12:02:17.396665
# Unit test for function parse
def test_parse():
    assert parse("").short_description is None
    assert parse("").long_description is None
    assert parse("").meta == []
    assert parse("").blank_after_short_description
    assert parse("").blank_after_long_description

    assert parse("short sentence\n").short_description == "short sentence"
    assert parse("short sentence\n").long_description is None
    assert parse("short sentence\n").meta == []
    assert parse("short sentence\n").blank_after_short_description
    assert parse("short sentence\n").blank_after_long_description

    assert parse("short sentence\n\n").short_description == "short sentence"
    assert parse("short sentence\n\n").long_description is None
    assert parse("short sentence\n\n").meta == []

# Generated at 2022-06-21 12:02:18.501000
# Unit test for function parse
def test_parse():
  assert False, "Unit test not implemented"


# Generated at 2022-06-21 12:02:19.329429
# Unit test for function parse
def test_parse():
    # TODO
    pass

# Generated at 2022-06-21 12:02:31.033255
# Unit test for function parse
def test_parse():
    import re
    test = inspect.cleandoc(r"""This is a test
                               :param foo: This is foo.

                               :returns: This is a return.
                               """)
    result = inspect.cleandoc(r"""This is a test
                               param foo: This is foo.

                               returns: This is a return.
                               """)
    d = parse(test)
    m = d.meta
    assert len(m) == 2
    assert m[0].__class__ == DocstringParam
    assert m[1].__class__ == DocstringReturns
    assert m[0].description == "This is foo."
    assert m[1].description == "This is a return."
    assert m[1].type_name == None
    assert m[0].type_name == None

# Generated at 2022-06-21 12:02:39.405891
# Unit test for function parse

# Generated at 2022-06-21 12:02:49.305239
# Unit test for function parse
def test_parse():
    s = """
    short_desc
    long description

    :param int x: The value of x
    :param complex y=3j: The value of y
    """


# Generated at 2022-06-21 12:02:49.855349
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-21 12:02:54.383093
# Unit test for function parse
def test_parse():
    docstring = """
        Class docstring
        :param x: description
    """
    ret = parse(docstring)
    assert ret.short_description == 'Class docstring'
    assert ret.meta[0].args == ['param', 'x']
    assert ret.meta[0].description == 'description'

# Generated at 2022-06-21 12:03:05.059709
# Unit test for function parse
def test_parse():
    from .common import Docstring, DocstringMeta
    from .numpydoc import parse as numpydoc_parse

    docstring = """Docstring for this function.

Parameters
----------
x: int
    An integer.
y: bool
    A bool.
"""
    result = parse(docstring)
    print(result)
    assert(isinstance(result, Docstring))
    assert(result.short_description == "Docstring for this function.")
    assert(len(result.meta) == 2)
    assert(all([isinstance(x, DocstringMeta) for x in result.meta]))

    # Check if the numpydoc parser is consistent
    result_numpydoc = numpydoc_parse(docstring)
    assert(result == result_numpydoc)

# Generated at 2022-06-21 12:03:13.267006
# Unit test for function parse
def test_parse():
    """
    Test for parse
    """
    # check for docs
    assert "Test for parse" in parse.__doc__
    # check for return value
    assert isinstance(parse(""), Docstring)
    # check for correct parsing
    data = parse("""
    Example

    :param: `name` -- the name of the person
    :returns: a greeting string
    :raises ValueError: if `name` is not a string
    """)
    assert data.long_description == "Example"
    assert len(data.meta) == 3
    assert isinstance(data.meta[0], DocstringParam)
    assert isinstance(data.meta[1], DocstringReturns)
    assert isinstance(data.meta[2], DocstringRaises)
    # test for incorrect input
    raised = False

# Generated at 2022-06-21 12:03:39.661191
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param int max_length: Enforce a maximum length.
    :param str suffix: The suffix to use.  Defaults to `...`.
    :returns: The truncated string

    :raises ValueError: If the string is too short.
    """
    ret = parse(docstring)
    assert ret.short_description == 'Short description.'
    assert ret.long_description == 'Long description.'
    assert ret.blank_after_long_description == True
    assert ret.blank_after_short_description == False

    assert len(ret.meta) == 3
    arg, ret, raises = ret.meta
    assert isinstance(arg, DocstringParam) == True
    assert isinstance(ret, DocstringReturns) == True

# Generated at 2022-06-21 12:03:51.526622
# Unit test for function parse
def test_parse():
    source = inspect.getsource(parse)
    func = parse
    doc = parse(func.__doc__)
    assert doc.short_description == "Parse the ReST-style docstring into its components."
    assert doc.meta[0].arg_name == "text"
    assert doc.meta[0].type_name == "str"
    assert doc.meta[1].arg_name == "returns"
    assert doc.meta[1].description == "parsed docstring"

    def func():
        """No meta."""

    doc = parse(func.__doc__)
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.long_description == None

    def func():
        """One line only."""


# Generated at 2022-06-21 12:04:02.866886
# Unit test for function parse

# Generated at 2022-06-21 12:04:12.281779
# Unit test for function parse
def test_parse():
    text='''
    Parse ReST-style docstring into its component parts.

    :param username: The user's name.
    :param password: The user's password.
    :type  password: str, optional
    :param email: The user's email address.
    :param url: The user's website.
    :param age: The user's age.
    :type age: int, optional
    :param complex: A complex number.
    :type complex: complex, optional
    :default complex: 3 - 4j

    :raises AttributeError: The ``name`` attribute is read-only.
    :raises KeyError: A key does not exist.

    :returns: A list of formatted names.
    :returns: A list of formatted names.
    :rtype: list[str]
    '''
    docstring

# Generated at 2022-06-21 12:04:24.063043
# Unit test for function parse
def test_parse():
    doc = inspect.cleandoc('''
        Single line summary.

        Longer description.

        This only goes through the first step.

        :param arg1: description alias
        :type arg1: int 
        :param arg2: description of the second parameter
        :type arg2: int
        :param arg3: description of the third parameter
        :type arg3: int
        :param arg4: description of the fourth parameter

        :returns: a return value!
        :rtype: int
        :returns: another return value!
        :rtype: int
        :raises NameError: if name is not in the dictionary
        :raises TypeError: if the argument types are wrong
        :yields: a value
        :yields: another value
    ''')

    docstring = parse(doc)



# Generated at 2022-06-21 12:04:33.449630
# Unit test for function parse
def test_parse():
    doc_string = """
    Get the data

    :param name: the name of the data you want to get
    :type name: str
    :return: the data
    :rtype: dict
    """
    ds = parse(doc_string)
    assert len(ds.meta) == 2
    assert ds.meta[0].arg_name == "name"
    assert ds.meta[0].type_name == "str"
    assert ds.meta[1].type_name == "dict"


if __name__ == "__main__":
    import sys
    import os
    os.system("python -m pytest " + " ".join(sys.argv[1:]))

# Generated at 2022-06-21 12:04:37.421338
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description.
    """
    doc = parse(text)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert doc.blank_after_short_description
    assert not doc.blank_after_long_description
    assert not doc.meta



# Generated at 2022-06-21 12:04:43.706406
# Unit test for function parse
def test_parse():
    docstring = """
    Summary line.

    Extended description of function.

    :param arg1: Description of arg1
    :param arg2: Description of arg2
    :returns: Description of return value
    :raises keyError:
    """
    doc = parse(docstring)
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[1].args == ["param", "arg2"]
    assert doc.meta[2].args == ["returns"]
    assert doc.short_description == "Summary line."
    assert doc.long_description == "Extended description of function."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description

# Generated at 2022-06-21 12:04:52.855888
# Unit test for function parse
def test_parse():
    doc = """
    Test a Docstring parser.

    :param foo: A foo
    :type foo: str
    :param bar: Bar.

    NOTE: this is ignored.

    :param baz: Baz.  Defaults to 3.14.
    :type baz: float
    :return: OK

    A long description
    """
    ds = parse(doc)
    print(ds.short_description)
    print(ds.long_description)
    print(ds.blank_after_long_description)
    print(ds.blank_after_short_description)
    for meta in ds.meta:
        print(meta)

    # Test

# Generated at 2022-06-21 12:05:04.496126
# Unit test for function parse
def test_parse():
    def _test(text: str, expected: T.Optional[Docstring]):
        actual = parse(text)
        assert actual == expected

    def _test_error(text: str, expected_err: str):
        with pytest.raises(ParseError) as excinfo:
            parse(text)
        assert str(excinfo.value).startswith(expected_err)

    _test(None, Docstring())
    _test("", Docstring())
    _test("Hello, world.", Docstring(short_description="Hello, world."))