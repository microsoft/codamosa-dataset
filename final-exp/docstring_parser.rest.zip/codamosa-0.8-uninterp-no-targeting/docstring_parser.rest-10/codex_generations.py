

# Generated at 2022-06-21 11:55:22.792069
# Unit test for function parse

# Generated at 2022-06-21 11:55:29.449450
# Unit test for function parse
def test_parse():
    s = '''
        Small description
        Long description 
        :param type a_param: param desc 
        :param arg: arg desc
        :param type b_param?: param desc with default
        :param arg: arg desc with
            default
        :returns: return desc
        :rtype: type
        :yields: yield desc
        :KeyError: raises desc
        :Exception: raises desc with
            newline
        '''
    d = parse(s)

    assert d.short_description == 'Small description'
    assert d.blank_after_short_description == False
    assert d.long_description == 'Long description'
    assert d.blank_after_long_description == False
    assert len(d.meta) == 5


# Generated at 2022-06-21 11:55:38.497615
# Unit test for function parse
def test_parse():
    docstr = """
        The greet function.

        This function should be used to greet people.

        :param name: The name of the person.
        :param question: The question asked.
        :returns: The answer to your question.
        """
    doc = parse(docstr)
    assert doc.short_description == "The greet function."
    assert doc.long_description == "This function should be used to greet people."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert doc.meta[0].arg_name == "name"
    assert doc.meta[0].description == "The name of the person."

# Generated at 2022-06-21 11:55:46.233852
# Unit test for function parse
def test_parse():
    params = [
        ("short, long\n\n", "[short, long]"),
        ("short", "[short, None]"),
        ("short\n\n", "[short, None]"),
    ]
    for doc, expected in params:
        expected = expected.replace('"', "'")
        docstring = parse(doc)
        assert repr(docstring.short_description) == expected, \
            f'unexpected result for docstring.short_description {repr(docstring.short_description)} != {expected}'
        print(docstring.short_description)

# Generated at 2022-06-21 11:55:57.619694
# Unit test for function parse
def test_parse():
    func = pd.DataFrame.corr
    docstring = parse(func.__doc__)
    assert docstring.short_description == 'Compute pairwise correlation of columns, excluding NA/null values.'
    assert docstring.meta[0].arg_name == 'method'
    assert docstring.meta[0].type_name == 'str'
    assert docstring.meta[0].description == '* "pearson": standard correlation coefficient\n* "kendall": Kendall Tau correlation coefficient\n* "spearman": Spearman rank correlation\n* "cov": linear covariance (based on Numpy)'
    assert docstring.meta[1].arg_name == 'min_periods'
    assert docstring.meta[1].type_name == 'int'

# Generated at 2022-06-21 11:56:01.235778
# Unit test for function parse
def test_parse():
    # test only
    import pprint
    pprint.pprint(parse.__dict__)
    # test only
    print(parse.__doc__)
    # test only
    print(parse.__doc__ == __doc__)
    # test only
    print(__doc__)

# Generated at 2022-06-21 11:56:13.017109
# Unit test for function parse
def test_parse():
    """Unit-test parse.
    TODO: This is a very basic unit test. We will add more cases as real life
    scenarios needs them. Right now, the unit test is only covering two
    scenarios, both of them are very simple.
    """
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.meta == []
    assert d.blank_after_long_description == False
    assert d.blank_after_short_description == False

    d = parse("")
    assert d.short_description == None
    assert d.long_description == None
    assert d.meta == []
    assert d.blank_after_long_description == False
    assert d.blank_after_short_description == False

    d = parse(None)
    assert d.short_

# Generated at 2022-06-21 11:56:15.620869
# Unit test for function parse
def test_parse():
    docstring = \
        """
        docstring rest style
        :param name: argument
        :type name: str
        """

    docstring = parse(docstring)
    assert docstring.short_description == "docstring rest style"
    assert docstring.meta[0].args == ['param', 'name', 'argument']



# Generated at 2022-06-21 11:56:18.247222
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()



# vim:et:ts=4:sw=4:fo-=t

# Generated at 2022-06-21 11:56:24.225221
# Unit test for function parse
def test_parse():
    docstring = """
    short description
    Random module.
    
    :param x:
        A number x.
    :param y:
        A number y.
    :param foobar:
        A boolean that decide whether to do this or that; defaults to True.
    :return:
        A number that is the sum of x and y.
    """
    print(parse(docstring))

# test_parse()

# Generated at 2022-06-21 11:56:41.134757
# Unit test for function parse
def test_parse():
    text = """
    The first line is a short, one-sentence summary.

    This is a longer description.
    """

    assert parse(text) == Docstring(
        short_description="The first line is a short, one-sentence summary.",
        blank_after_short_description=True,
        long_description="This is a longer description.",
        blank_after_long_description=False
    )

    text = """
    The first line is a short, one-sentence summary.

    This is a longer description.
    """

    assert parse(text) == Docstring(
        short_description="The first line is a short, one-sentence summary.",
        blank_after_short_description=True,
        long_description="This is a longer description.",
        blank_after_long_description=False
    )

   

# Generated at 2022-06-21 11:56:45.660536
# Unit test for function parse
def test_parse():
    assert parse('').short_description is None
    assert parse('').long_description is None
    assert parse('    ').short_description is None
    assert parse('    ').long_description is None


    assert parse('a').short_description == 'a'
    assert parse('a').long_description is None
    assert parse('a\n    ').short_description == 'a'
    assert parse('a\n    ').long_description is None
    assert parse('a\n\n    ').short_description == 'a'
    assert parse('a\n\n    ').long_description is None


    assert parse('a\n  b\n').short_description == 'a'
    assert parse('a\n  b\n').long_description == 'b'

# Generated at 2022-06-21 11:56:47.098426
# Unit test for function parse
def test_parse():
    """Parse a ReST-style docstring into its components."""



# Generated at 2022-06-21 11:56:55.685580
# Unit test for function parse
def test_parse():
    docstring = parse("""
        Short summary.

            Long description here.

        :param str s: string to be parsed
        :param bla: ignored param (not supported in this parser)
        :returns: something
        :raises ValueError: when something bad happens
        :raises TypeError: when something really bad happens
        :rtype: str
        :keyword int i: some int
        :keyword NoneType n: some None
        :yields: iterator

        More description.
    """)

    assert docstring.short_description == "Short summary."
    assert docstring.blank_after_short_description == True
    assert docstring.long_description == "Long description here."
    assert docstring.blank_after_long_description == True
    assert docstring.has_meta

# Generated at 2022-06-21 11:57:06.463908
# Unit test for function parse
def test_parse():
    d = """
    function
    --------
    This is a function that does something

    :param str a: The first argument
    :param str b. The second argument
    :param str c: The third argument
    """

# Generated at 2022-06-21 11:57:13.956032
# Unit test for function parse
def test_parse():
    docstring = """
    Class summary line.
    Second line.

    Attributes:
        foo (int): Description of `foo`.
        bar (str, optional): Description of `bar`.
          Defaults to 'baz'.
        baz (Duck, optional): Description of `baz`.

    Raises:
        TypeError: If `bar` is not a string.
        ValueError: If `foo` is equal to `bar`.
    """

# Generated at 2022-06-21 11:57:25.551693
# Unit test for function parse
def test_parse():
    d = inspect.cleandoc('''
    Short description.

    Longer description.
    ''')
    assert parse(d) == Docstring(
        short_description='Short description.',
        long_description='Longer description.',
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[],
    )

    d = inspect.cleandoc('''
    Short description.

    Longer description.
    :param str foo:
    ''')

# Generated at 2022-06-21 11:57:33.137885
# Unit test for function parse
def test_parse():
    docstring = """
    A sample docstring.

    :param optional arg1: An argument.
    :param arg2: A second argument.
    :type arg2: str
    :param ~type.Immutable arg3: An argument.
    :param Optional[type.Immutable] arg4: An argument.
    :raises Exception: when things go wrong.
    :returns: int -- the return value (if any)
    :rtype: int
    :yields: int
    """

    ret = parse(docstring)
    assert ret.short_description == "A sample docstring."
    assert ret.long_description == "An argument."

# Generated at 2022-06-21 11:57:41.789563
# Unit test for function parse
def test_parse():
    docstring = '''
    If *b* is ``None``, returns ``(self.conj().T, None)``,
    otherwise returns a ``(A, B)`` tuple where ``A`` and ``B`` are
    ``self`` and ``b``, respectively, after having been cast to a
    common data type and shape.

    :param c: a complex number or array
    :type z: complex or ndarray
    :returns: (tuple) containing (complex, complex or None)
    '''
    assert parse(docstring)


# Generated at 2022-06-21 11:57:47.841647
# Unit test for function parse
def test_parse():
    docstring = parse(
        inspect.getdoc(parse) or "")
    assert docstring.long_description is None
    assert docstring.short_description == 'Parse the ReST-style docstring into its components.'
    assert not docstring.blank_after_long_description
    assert not docstring.blank_after_short_description
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args == ['returns']

# Generated at 2022-06-21 11:58:06.312955
# Unit test for function parse

# Generated at 2022-06-21 11:58:22.207371
# Unit test for function parse
def test_parse():
    """
    >>> parse("""

# Generated at 2022-06-21 11:58:33.881868
# Unit test for function parse
def test_parse():
    import pathlib
    import re

    cur_dir = pathlib.Path(__file__).parent
    tests_dir = cur_dir / "tests"
    examples_dir = cur_dir / "../examples"

    re_str = r"\s*#.*\n|\s*\n"

    def remove_comments(text: str) -> str:
        return re.sub(re_str, "", text)

    def parse_example(filename: str) -> str:
        with open(filename) as ifile:
            text = ifile.read()
        text = remove_comments(text)
        return str(parse(text))

    def test_example(filename: str, example_name: str) -> None:
        expected_file = tests_dir / (example_name + ".expected")
        actual = parse

# Generated at 2022-06-21 11:58:41.299632
# Unit test for function parse
def test_parse():
    text = inspect.cleandoc('''
    test function
    
    This is a test function.
    
    :param x: the first arg
    :type x: int
    :param y: the second arg
    :type y: str
    :returns: x+y
    :rtype: str
    :raises ValueError: raises ValueError if x is None
    :raises KeyError: raises KeyError if y is None
    ''')
    result = parse(text)
    assert result.short_description == "test function"
    assert result.long_description == "This is a test function."
    assert len(result.meta) == 4
    assert isinstance(result.meta[0], DocstringParam)
    assert result.meta[0].arg_name == "x"

# Generated at 2022-06-21 11:58:53.054519
# Unit test for function parse

# Generated at 2022-06-21 11:58:58.882015
# Unit test for function parse
def test_parse():
    from .common import DocstringRaises
    ds = parse("""\
        :Keyword Arguments:
            keyword -- This is the value.
        :Raises:
            KeyError -- When the value is not in the dictionary.
        """)
    assert len(ds.meta) == 2
    assert ds.meta[0].description == "This is the value."
    assert isinstance(ds.meta[1], DocstringRaises)
    assert ds.meta[1].description == "When the value is not in the dictionary."


# Generated at 2022-06-21 11:59:08.510518
# Unit test for function parse
def test_parse():
    docstring = """
    Compute the XOR of two integers.

    This is an example of a long description.

    :param a: first integer
    :type a: int
    :param b: second integer
    :type b: int
    :returns: XOR of a and b
    :rtype: int
    :raises ValueError: if either argument is not an integer

    >>> xor(a, b)
    c
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Compute the XOR of two integers."
    assert (
        parsed.long_description == "This is an example of a long description."
    )
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
   

# Generated at 2022-06-21 11:59:17.898555
# Unit test for function parse
def test_parse():
    # type: () -> None
    def test(doc):
        # type: (str) -> None
        doc = parse(doc)
        assert isinstance(doc, Docstring)
        assert isinstance(doc.short_description, str)
        assert isinstance(doc.blank_after_short_description, bool)
        assert isinstance(doc.blank_after_long_description, bool)
        assert isinstance(doc.long_description, str)
        assert isinstance(doc.meta, list)
        for meta in doc.meta:
            assert isinstance(meta, DocstringMeta)
            assert isinstance(meta.args, list)
            assert isinstance(meta.description, str)
            if isinstance(meta, DocstringParam):
                assert isinstance(meta.arg_name, str)

# Generated at 2022-06-21 11:59:24.915949
# Unit test for function parse
def test_parse():
    docstring = """
        Short description.

        Longer description.

        :param arg1: the first argument
        :param arg2: the second argument
        :param arg3: the third argument, defaults to False
        :param arg4: the fourth argument (this defaults to True)
        :param arg5: the fifth argument with a type annotation

        :type arg5: bool
        
        :return: None
        :rtype: None
        
        :raises ImportError: when something bad happens
        
        :raises: AttributeError
        
        :yields: len(x)

        :yields int: len(x)

        :returns: :class:`int` - len(x)
    """

# Generated at 2022-06-21 11:59:36.804871
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("A short description.\n") == Docstring(
        short_description="A short description."
    )
    assert parse("A short description.\n:arg\n:returns\n") == Docstring(
        short_description="A short description.",
        meta=[
            DocstringMeta(args=["arg"], description=None),
            DocstringMeta(args=["returns"], description=None),
        ],
    )

# Generated at 2022-06-21 11:59:49.521406
# Unit test for function parse
def test_parse():
    import pytest

    text = """summary
This is a really long sentence that should
be broken up into several lines.
    """
    expected = parse(text)
    assert expected.short_description == "summary"
    assert expected.blank_after_short_description == False
    assert expected.long_description == """This is a really long
sentence that should be broken up into several lines."""
    assert expected.blank_after_long_description == True



# Generated at 2022-06-21 12:00:01.474232
# Unit test for function parse
def test_parse():
    """
    测试方法parse
    """
    docstring = """
    Simplified interface to `audit` that checks whether the first argument is
    callable (i.e., a function or method) and, if so, whether the given arguments
    and keywords pass the 'callable' test.
    :param f: function to be audited
    :param args: arguments to be passed to *f*
    :param kwargs: keyword arguments to be passed to *f*
    :returns: whether the arguments and keywords validate
    """
    re_docstring = parse(docstring)
    print(re_docstring)

# Generated at 2022-06-21 12:00:12.399661
# Unit test for function parse
def test_parse():
    for test_docstring in test_docstrings:
        assert parse(test_docstring) == test_parsed_docstrings[
            test_docstrings.index(test_docstring)
        ]



# Generated at 2022-06-21 12:00:14.129914
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-21 12:00:19.006261
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description.
    """
    parsed = parse(text)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description."
    assert parsed.meta == []
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False


# Generated at 2022-06-21 12:00:29.684442
# Unit test for function parse
def test_parse():
    s = """
    short description of function
    """
    print(repr(parse(s)))

    s = """
    short description of function
    long description of function...
    """
    print(repr(parse(s)))

    s = """
    short description of function

    :param p1: first param
    :param p2: second param
    :rtype: returntype
    """
    print(repr(parse(s)))

    s = """
    short description of function

    :param str p1: first param
    :param p2: second param
    :returns: returntype
    :raises: exc
    :raises ValueError: something
    :yields: yieldstuff
    """
    print(repr(parse(s)))



# Generated at 2022-06-21 12:00:41.458481
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: Arg1 description
    :param arg2: Arg2 description
    :param arg3: Arg3 description
    :param arg4: Arg4 description
    :param arg5: Arg5 description
    :param arg6: Arg6 description
    :returns: Returns description
    :raises ZeroDivisionError: Raises description
    '''
    parsed_docstring = parse(text)

    assert len(parsed_docstring.meta) == 7
    assert parsed_docstring.short_description == 'This is a test docstring.'
    assert parsed_docstring.long_description is None
    assert parsed_docstring.blank_after_short_description is False
    assert parsed_docstring.blank_after_long_description is False

    assert parsed_doc

# Generated at 2022-06-21 12:00:53.082891
# Unit test for function parse
def test_parse():
    doc = parse(inspect.cleandoc('''\
        This is the short description.

        This is the long description.
        It may consist of multiple paragraphs.

        :param str foo:
            This is a parameter description. This is the second line.

        :param str bar: This is a parameter description.

        :returns int: This is a return description.
        '''
    ))

    assert doc.short_description == 'This is the short description.'
    assert doc.long_description == '''\
This is the long description.
It may consist of multiple paragraphs.'''
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description

    assert len(doc.meta) == 2

    param, returns = doc.meta

    assert param.args == ['param', 'str', 'foo']


# Generated at 2022-06-21 12:01:00.868968
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    assert parse("A simple function.") == Docstring(
        short_description="A simple function."
    )

    assert parse("A simple function.\n") == Docstring(
        short_description="A simple function."
    )

    assert parse("A simple function.\n\n") == Docstring(
        short_description="A simple function.",
        blank_after_short_description=True,
    )

    assert parse("A simple function.\n\nWith a\nlong description.") == Docstring(
        short_description="A simple function.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="With a\nlong description.",
    )


# Generated at 2022-06-21 12:01:06.042099
# Unit test for function parse
def test_parse():
    help_text = inspect.getdoc(parse)
    d = parse(help_text)
    assert(not d.short_description)
    assert(d.blank_after_short_description == True)
    assert(d.blank_after_long_description == False)
    assert(d.long_description)
    assert(not d.meta)

# Generated at 2022-06-21 12:01:19.925688
# Unit test for function parse
def test_parse():
    docstring = """
    Short summary.

    Extended description.

    :param str arg1: Name of First Argument
    :param str arg2: Name of Second Argument
    :raises TypeError: if arg1 is None
    :return: Result of process
    :rtype: str
    """
    result = parse(docstring)
    assert result.short_description == "Short summary."
    assert result.long_description == "Extended description."
    assert len(result.meta) == 4
    assert result.meta[1].args == ['param', 'str', 'arg1']
    assert result.meta[1].description == 'Name of First Argument'
    assert result.meta[0].args == ['param', 'str', 'arg2']
    assert result.meta[0].description == 'Name of Second Argument'
    assert result.meta

# Generated at 2022-06-21 12:01:31.834703
# Unit test for function parse
def test_parse():
    text = """
        This is a short description.

        This is a long description.

        :param int x: the x coordinate
        :param int y: the y coordinate
        :returns: description of return value
        :raises ValueError: if `x` is out of range
        """
    doc = parse(text)
    assert doc.short_description == "This is a short description."

    assert doc.long_description == """
        This is a long description.

        :param int x: the x coordinate
        :param int y: the y coordinate
        :returns: description of return value
        :raises ValueError: if `x` is out of range
        """.strip()

    assert doc.blank_after_short_description

    assert doc.blank_after_long_description

    meta = doc.meta

# Generated at 2022-06-21 12:01:42.057959
# Unit test for function parse
def test_parse():
    d = Docstring()
    d.short_description = "id function"
    d.blank_after_short_description = True
    d.long_description = "Returns the identity of an object.\n\n(== operator) if the object has operator.__eq__().\n(is operator) otherwise.\n"   
    d.meta = [
        DocstringParam(
            args=['param', 'arg1:'],
            description='The object.\n',
            arg_name='arg1',
            type_name=':',
            is_optional=True,
            default=None,
        )
    ]

# Generated at 2022-06-21 12:01:53.024894
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc("""
        this is the short description

        this is the long description

        :param bool include_private:
            include private functions
        :param callable test:
            a test
    """)
    doc = parse(docstring)
    assert doc.short_description == 'this is the short description'
    assert doc.long_description == 'this is the long description'
    assert doc.blank_after_short_description
    assert not doc.blank_after_long_description
    assert len(doc.meta) == 2
    assert isinstance(doc.meta[0], DocstringParam)
    assert doc.meta[0].keyword == 'param'
    assert doc.meta[0].arg_name == 'include_private'
    assert doc.meta[0].type_name == 'bool'
   

# Generated at 2022-06-21 12:02:03.673276
# Unit test for function parse

# Generated at 2022-06-21 12:02:14.097717
# Unit test for function parse
def test_parse():
    doc = parse("""
    Short description

    Long description
    """)
    assert doc.short_description == "Short description"
    assert doc.long_description == "Long description"
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False

    doc = parse("""
    Short description

    :param x: This is a positional argument.
    :param y=2: This is a named argument that defaults to 2.
    :param z: None
    :return: The return value.
    :returns: The return value.
    :raises KeyError: If a nonexistent key is given
    :rtype: float
    :returns: the total

    Long description
    """)
    assert doc.short_description == "Short description"

# Generated at 2022-06-21 12:02:18.838894
# Unit test for function parse
def test_parse():
    code = """Example:
        :type arg: str
        :param arg: A string argument.
        :type kwarg: int
        :param kwarg: An integer argument.
        :rtype: None
        :returns: None
        :raises ValueError: If the argument is 'foo'
        """
    print(parse(code))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:02:26.974091
# Unit test for function parse
def test_parse():
    print('====test_parse====')
    text = """
short desc.

Long desc (wrapped).
:return: Returns nothing
"""
    doc = parse(text)
    # print(doc)
    print('short: ', doc.short_description)
    print('long: ', doc.long_description)
    print('meta: ', doc.meta)
    print('blank: ', doc.blank_after_short_description, doc.blank_after_long_description)




# Generated at 2022-06-21 12:02:36.804246
# Unit test for function parse
def test_parse():
    from ..py._compat import builtins
    from .common import DocstringMeta
    from .tests import conftest

    def test():
        """
        This is a short description.

        This is a long description.

        :param arg1:
            This is a parameter description.
        :param arg2:
            This is another parameter description.
            It has two lines.
        :returns:
            This is the return value.

        Non-meta part.
        """


# Generated at 2022-06-21 12:02:47.872354
# Unit test for function parse
def test_parse():
    docstr = """\
        One line summary.

        Extended description.

        :param arg: Description of arg.
        :type arg: str
        :param arg2: Description of arg2.
        :returns: Description of what is returned.
        :rtype: bool
        :raises ValueError: Description of exception.
        :raises TypeError: Description of exception.
        """

# Generated at 2022-06-21 12:03:05.781625
# Unit test for function parse
def test_parse():
    """Test ReST parser"""
    assert parse("") == Docstring()
    assert parse("This is a simple sentence") == Docstring(
        short_description="This is a simple sentence"
    )
    assert parse("This is a simple sentence.\n\nThis is a long description.") == Docstring(
        short_description="This is a simple sentence.",
        long_description="This is a long description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

# Generated at 2022-06-21 12:03:13.816953
# Unit test for function parse
def test_parse():
    f_doc = inspect.getdoc(test_parse)
    ds = parse(f_doc)
    assert isinstance(ds, Docstring)

    assert ds.short_description == 'Unit test for function parse'
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == True
    assert ds.long_description == ':param param1: the original parameter\n:returns: nothing'
    assert len(ds.meta)==2

    assert isinstance(ds.meta[0], DocstringParam)
    assert ds.meta[0].args == [':param', 'param1:', 'the', 'original', 'parameter']
    assert ds.meta[0].description == 'the original parameter'

# Generated at 2022-06-21 12:03:23.715337
# Unit test for function parse
def test_parse():
    """
    Simple example.
    :param arg1: argument one
    :type arg1: str
    :returns: True
    :rtype: bool
    """

# Generated at 2022-06-21 12:03:30.761507
# Unit test for function parse
def test_parse():
    text = """\
    This is a short description.

    This is the long description.
    """

    assert parse(text) == Docstring(
        short_description="This is a short description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="This is the long description.",
        meta=[],
    )



# Generated at 2022-06-21 12:03:41.499723
# Unit test for function parse
def test_parse():
    doc1 = '''
        Short description.
    
        Longer description.
    
        Parameters
        ----------
        x : int
            The first argument.
        y : int
            The second argument.
    
        Returns
        -------
        result: bool
            Result of the computation.
    '''
    doc2 = '''
        Parse the ReST-style docstring into its components.
        
        :returns: parsed docstring
    '''
    doc3 = '''
        Parse the ReST-style docstring into its components.
        
        :returns: parsed docstring
    '''

    # case 1
    d1 = parse(doc1)
    print(d1)
    assert d1.short_description == 'Short description.'
    assert d1.long_description == 'Longer description.'

# Generated at 2022-06-21 12:03:53.388077
# Unit test for function parse
def test_parse():
    from .tk import TkDocstring
    from .google import GoogleDocstring

    def test_func():
        """
        This is a test function for parsing docstring
        This docstring is used for testing
        :param arg1: this is the first argument
        :param arg2: this is the second argument
        :type arg2: string
        :returns: returns the value
        :rtype: bool
        :raises Exception: This exception is raised
        """
        return True
    test_func_google = GoogleDocstring(test_func)
    test_func_tk = TkDocstring(test_func)

    assert test_func_google.args['arg1'].type == test_func_tk.args['arg1'].type
    assert test_func_google.args['arg2'].type == test_func_tk

# Generated at 2022-06-21 12:04:04.864635
# Unit test for function parse
def test_parse():
    # Test empty text
    assert parse("") == Docstring()

    # Test one-liner
    assert parse("One-liner.") == Docstring(
        short_description="One-liner.",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    # Test one-liner with meta information
    assert parse("One-liner. :param x: The x value.") == Docstring(
        short_description="One-liner.",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[DocstringParam(args=["param", "x"], description="The x value.")],
    )

    # Test one-liner with meta information on following line
   

# Generated at 2022-06-21 12:04:07.887126
# Unit test for function parse
def test_parse():
    parse("""
    This returns the result of multiplying a number by 10
    :param int num: The number to multiply

    :returns: The number multiplied by 10.
    """)


# Generated at 2022-06-21 12:04:15.013493
# Unit test for function parse
def test_parse():
    text = """
        Summarize your project with this first docstring line.

        This is a longer description of the docstring. This is a second paragraph
        that hopefully demonstrates how the documentation behaves when it becomes
        longer and longer.

        :param int a: An integer argument.
        :param str b: A string argument.
        :returns: What we are going to return.

        :raises ValueError: If a value is of the wrong type.
        :raises ImportError: if the wrong module is imported.
        :raises RuntimeError: if it runs for too long.


        Hello, this is the end of the docstring.
    """

    p = parse(text)
    # print(p)
    assert p.short_description == "Summarize your project with this first docstring line."


# Generated at 2022-06-21 12:04:26.083960
# Unit test for function parse
def test_parse():
    s = """
    This is the short description.

    This is the long
    description. It can
    have multiple lines.

    :param arg1: This describes arg1.
    :type arg1: str
    :param arg2: This describes arg2.
    :type arg2: int, optional
    :param arg3: This describes arg3.
    :type arg3: bool, optional
    :default arg3: False
    :raises KeyError: This describes a possible error condition.
    :returns: This describes the return value.
    :rtype: bool
    """

    ds = parse(s)

    assert ds.short_description == "This is the short description."
    assert ds.long_description == (
        "This is the long description. It can have multiple lines."
    )
    assert ds

# Generated at 2022-06-21 12:04:46.790863
# Unit test for function parse
def test_parse():

    text = """
        Short description.

        More detailed description.

        :param foo: Description of foo.
        :param bar: Description of bar.
    """
    doc = parse(text)
    assert doc.short_description == "Short description."
    assert doc.long_description == "More detailed description."
    assert len(doc.meta) == 2
    assert doc.meta[0].arg_name == "foo"
    assert doc.meta[1].arg_name == "bar"

# Generated at 2022-06-21 12:04:54.346385
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring = """This function does something
:param str param1: the first possible parameter
:param bool param2: the second possible parameter
:rtype: str
:returns: the return value
"""

# Generated at 2022-06-21 12:05:06.098087
# Unit test for function parse
def test_parse():
    """docstring for test_parse"""
    print("test_parse")