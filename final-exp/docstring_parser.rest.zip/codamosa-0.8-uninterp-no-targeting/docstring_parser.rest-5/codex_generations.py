

# Generated at 2022-06-21 11:55:27.079743
# Unit test for function parse
def test_parse():
    import pytest
    from .common import DocstringReturns
    #Input for the for loop
    s = parse('''
    :param name:
    :param age:
    :param address:
    ''')
    for i in s.meta:
        if isinstance(i, DocstringReturns): 
            assert i.args == ['param', 'name']
        else:
            assert i.args == ['param', 'age']
        assert i.description == ''
        assert i.type_name == None

    with pytest.raises(ValueError): #Because no docstring was passed
        parse('')
        
    with pytest.raises(ParseError):
        parse('''
        :param name:
        :param age:
        :param address:
        :arguments:
        ''')
        

# Generated at 2022-06-21 11:55:38.627396
# Unit test for function parse
def test_parse():
    doc_string = """\
    short description line
    long description line
    :param name: The name of the object
    """
    print(parse(doc_string))

    doc_string = """\
    short description line
    long description line
    :param name: The name of the object
    :type name: str
    """
    print(parse(doc_string))

    doc_string = """\
    short description line
    long description line
    :param arg1: First arg.
    :type arg1: str
    :param arg2: Second arg.
    :type arg2: int
    :raises AttributeError: The :exc:`Exception` raised.
    """
    print(parse(doc_string))


# Generated at 2022-06-21 11:55:47.257800
# Unit test for function parse
def test_parse():
    docstring = """
        Short description.

        Long description.

        :param no_type: No type.
        :param int param_a: With type and A.
        :param List[int] param_b: With type and B.
        :param param_c: No type and C.
        :param param_d: No type and D.
        :returns: A list.
        :rtype: List[int]
        :return: A second list.
        :rtype: List[int]
        :raises ValueError: When ``x`` is negative.
    """
    obj = parse(docstring)
    print(obj)


# test_parse()

# Generated at 2022-06-21 11:55:58.650889
# Unit test for function parse
def test_parse():
    test = Docstring()
    test.short_description = "Here is my test"
    param1 = DocstringParam(args=["param", "int", "value"],
                            description="This is the value",
                            arg_name="value",
                            type_name="int",
                            is_optional=False,
                            default=None)
    param2 = DocstringParam(args=["param", "int", "value"],
                            description="This is the value",
                            arg_name="value",
                            type_name="int",
                            is_optional=True,
                            default=None)

# Generated at 2022-06-21 11:56:06.733982
# Unit test for function parse
def test_parse():
    import json
    import sys
    import typing as T

    if sys.version_info[:2] < (3, 5):
        # This syntax was introduced in Python 3.5
        return
    text = '''\
    Short summary.

    Parameters
    ----------
    x : int
        Descriptive text.

    y : SomeType
        Descriptive text.

    z : Optional[float] = None
        Descriptive text.

    Returns
    -------
    str
        Descriptive text.

    Raises
    ------
    SomeError
        If some condition is met.
    '''

# Generated at 2022-06-21 11:56:13.751146
# Unit test for function parse
def test_parse():
    pass
    # def foo(a: "int" = 3, b: "str") -> "bool?":
    #     """This is foo.
    #
    #     :param int a: First arg.
    #     :param str b: Second arg.
    #     :return bool?: True if foo is executed.
    #
    #     """
    # foo_docstring = inspect.getdoc(foo)
    # print(foo_docstring)
    # print(parse(foo_docstring))

# Generated at 2022-06-21 11:56:24.933334
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    parse_str = """
    """
    result = parse(parse_str)
    print(result)
    assert isinstance(result, Docstring)
    assert result.short_description == None
    assert result.long_description == None
    assert result.meta == []
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == False

    parse_str = """A short description.
    """
    result = parse(parse_str)
    print(result)
    assert isinstance(result, Docstring)
    assert result.short_description == "A short description."
    assert result.long_description == None
    assert result.meta == []
    assert result.blank_after_short_description == True
    assert result.blank_after_long_

# Generated at 2022-06-21 11:56:36.350840
# Unit test for function parse
def test_parse():
    docstring = """Single-line docstring."""
    parsed = parse(docstring)
    assert parsed.short_description == "Single-line docstring."
    assert not parsed.long_description
    assert not parsed.meta

    docstring = """
    Single-line docstring with blank lines
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Single-line docstring with blank lines"
    assert not parsed.long_description
    assert not parsed.meta

    docstring = """Single-line docstring.
    
    With multiple paragraphs."""
    parsed = parse(docstring)
    assert parsed.short_description == "Single-line docstring."
    assert parsed.blank_after_short_description
    assert parsed.long_description == "With multiple paragraphs."
    assert not parsed.blank_after_long

# Generated at 2022-06-21 11:56:46.743961
# Unit test for function parse
def test_parse():
    from .common import DocstringRaises
    docstring = Docstring()
    assert(parse("") == docstring)
    docstring.short_description = "Raises an exception."
    docstring.meta = [DocstringRaises(["Raises"], "an exception.", None)]
    assert(parse("Raises an exception.") == docstring)
    docstring.short_description = "Raises an OSError exception."
    docstring.meta = [DocstringRaises(["Raises"], "OSError.", "OSError")]
    assert(parse("Raises OSError.\n\n  Raises: OSError.") == docstring)
    docstring.short_description = "Raises a ValueError exception."
    docstring.long_description = "Raises a ValueError exception\nwhen x is not None."
   

# Generated at 2022-06-21 11:56:47.354343
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-21 11:57:02.456283
# Unit test for function parse
def test_parse():
    docstring = """\
This is a short description.

This is a long description.

:param a:
  Description of param a.
:type a:
  integer
:param b:
  Description of param b.
:type b:
  integer

:returns:
  Description of return value.
:rtype:
  integer
"""
    #import pprint
    #pprint.pprint(parse(docstring))
    p = parse(docstring)
    #print(p)
    assert p.short_description == "This is a short description."
    assert p.blank_after_short_description == True
    assert p.long_description == "This is a long description."
    assert p.blank_after_long_description == True
    assert len(p.meta) == 4

# Generated at 2022-06-21 11:57:05.914219
# Unit test for function parse
def test_parse():
    from .examples import docstring
    from copy import copy
    dstr = copy(docstring)
    dstr.long_description = dstr.long_description.strip()
    assert parse(docstring.text) == dstr



# Generated at 2022-06-21 11:57:10.495040
# Unit test for function parse

# Generated at 2022-06-21 11:57:23.318168
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    assert parse("Short description.") == Docstring(
        short_description="Short description.", long_description=None
    )

    assert parse("Short description.\n") == Docstring(
        short_description="Short description.",
        long_description=None,
        blank_after_short_description=True,
    )

    assert parse("Short description.\nLong description.") == Docstring(
        short_description="Short description.",
        long_description="Long description.",
        blank_after_short_description=False,
    )


# Generated at 2022-06-21 11:57:31.725718
# Unit test for function parse
def test_parse():
    docstring ="""
    Test function.

    The following keywords are supported:

    :param arg1: first arg
    :param arg2: second arg
    :type arg2: int
    :param argn: last arg

    :keyword keyword1: first keyword
    :keyword keyword2: second keyword
    :type keyword2: int
    :keyword keywordn: last keyword

    :return: xxxxx
    :rtype: int
    :returns: xxxxx
    :returntype: int

    :raises TypeError: if xxxx
    """
    ret = parse(docstring)
    assert ret.short_description == 'Test function.'
    assert ret.long_description == """The following keywords are supported:"""
    assert ret.blank_after_short_description == False
    assert ret.blank_after_long

# Generated at 2022-06-21 11:57:43.525739
# Unit test for function parse

# Generated at 2022-06-21 11:57:50.461598
# Unit test for function parse
def test_parse():
    assert parse('test function\n\nThis function is used to test the docstring parser') == parse(
        'test function\n\nThis function is used to test the docstring parser')
    assert parse('test function\nThis function is used to test the docstring parser') == parse(
        'test function\n\nThis function is used to test the docstring parser')
    assert parse('test function\n\nThis function is used to test the docstring parser\n\n') == parse(
        'test function\n\nThis function is used to test the docstring parser')
    assert parse('test function\n\n:param: a int\n\n') == parse(
        'test function\n\n:param a: int\n\n')

# Generated at 2022-06-21 11:57:59.918611
# Unit test for function parse
def test_parse():
    # test for docstring with meta info
    text = """This is short description

This is long description.

This is a paragraph in long description.
:param arg1: This is long description of arg1.
             This should appear as paragraph.
             This is the second line.
:param arg2: This is long description of arg2.
:type arg1: int
:type arg2: str
:return: This is a long description of return value.
:rtype: float
"""
    parse_result = parse(text)
    assert len(parse_result.meta) == 4
    assert parse_result.short_description == "This is short description"
    assert parse_result.blank_after_short_description == True
    assert parse_result.blank_after_long_description == True

# Generated at 2022-06-21 11:58:11.152862
# Unit test for function parse
def test_parse():
    import os
    import sys

    assert parse("'''short'''") == Docstring(
        short_description="short",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse('"""multi\nline"""') == Docstring(
        short_description="multi\nline",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-21 11:58:18.574261
# Unit test for function parse
def test_parse():
    res = parse(
        "A program that parses ReST-style docstrings.\n"
        ":param x: a parameter\n"
        ":returns: None\n"
        ":raises Exception: with an error\n"
    )
    print(res)
    assert isinstance(res, Docstring)
    assert res.short_description == "A program that parses ReST-style docstrings."
    assert res.blank_after_short_description == True
    assert res.long_description is None
    assert res.blank_after_long_description == False

    assert len(res.meta) == 3

    md = res.meta
    assert len(md) == 3
    assert isinstance(md[0], DocstringParam)
    assert md[0].arg_name == "x"
    assert md

# Generated at 2022-06-21 11:58:35.646549
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()


# Generated at 2022-06-21 11:58:42.095812
# Unit test for function parse
def test_parse():
    t1 = parse('''\
        Example of a one-line description.

        This is the longer description,
        which is still considered the long
        description.

        Another paragraph in the long
        description.

        :param arg1: Description of arg1
        :type arg1: int
        :param arg2: Description of arg2
        :type arg2: str
        :rtype: float

        :raises RuntimeError: if an error occurs
        :returns: the result

        ''')

    assert t1.short_description == "Example of a one-line description."
    assert t1.blank_after_short_description == False
    assert t1.long_description == '''\
        This is the longer description,
        which is still considered the long
        description.

        Another paragraph in the long
        description.'''

# Generated at 2022-06-21 11:58:53.580576
# Unit test for function parse
def test_parse():
    """Some basic unit tests for function parse."""
    docstring = """A one-line summary of the function's purpose.

Longer explanation of the function's purpose.

:param arg1: the first argument
:type arg1: int
:param arg2: the second argument
:type arg2: str
:returns: the return value
:rtype: bool
:raises AttributeError: when the user doesn't have the right attributes
"""
    doc = parse(docstring)

    assert doc.short_description == "A one-line summary of the function's purpose."
    assert doc.blank_after_short_description
    assert doc.long_description == "Longer explanation of the function's purpose."
    assert not doc.blank_after_long_description
    assert len(doc.meta) == 4

    # First meta block

# Generated at 2022-06-21 11:59:06.025956
# Unit test for function parse

# Generated at 2022-06-21 11:59:15.325709
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description.

    :param something: This is a parameter.
    :param int something_else: Another param with an explicit type.
    :raises ValueError: If things go wrong.

    And then we're done.
    
    
    """

    result = parse(text)
    assert result.short_description == "Short description."
    assert result.long_description == "Long description."
    assert result.meta[0].arg_name == "something"
    assert result.meta[1].arg_name == "something_else"
    assert result.meta[1].type_name == "int"
    assert result.meta[2].type_name == "ValueError"
    assert result.meta[2].arg_name is None

# Generated at 2022-06-21 11:59:21.355904
# Unit test for function parse
def test_parse():
    docstring = '''
    This function prints "Hello World".

    :param str a: First argument.
    :returns: True
    :raises RuntimeError: If it fails miserably.
    '''
    parsed = parse(docstring)
    print(parsed.short_description)
    print(parsed.long_description)
    print(parsed.meta)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:59:27.284403
# Unit test for function parse
def test_parse():
    d = parse("""
    Short description.
    
    Long description.
    
    :type param1: type
        Description for param1

    :type param2: type
        Description for param2

    :param param3: type
        Description for param3

    :param param4: type
        Description for param4

    :rtype: type
        Description for return value

    :return: type
        Description for return value

    :raises Exception: type
        Description for exception

    :raises Exception: type
        Description for exception
    """)
    assert d.short_description == 'Short description.'
    assert d.long_description == 'Long description.'
    assert d.blank_after_short_description == True
    assert d.blank_after_long_description == True


# Generated at 2022-06-21 11:59:38.861906
# Unit test for function parse
def test_parse():
    assert parse("nothing") == Docstring()
    assert parse("one line") == Docstring(
        short_description="one line",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse("First line.\nSecond line.") == Docstring(
        short_description="First line.",
        blank_after_short_description=True,
        long_description="Second line.",
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-21 11:59:50.019556
# Unit test for function parse

# Generated at 2022-06-21 12:00:01.962174
# Unit test for function parse
def test_parse():
    def my_function(a, b):
        """
        My function.

        :param int a: This is A.
        :param str b: This is B.
        :returns: a + b.
        :rtype: str
        """
        return a + b
    assert str(parse(my_function.__doc__)) == (
        'My function.\n\nThis is A.\n\n:param int a: This is A.\n'
        ':param str b: This is B.\n:returns: a + b.\n'
        ':rtype: str\n'
    )
    def another_function():
        """
        Another function.

        :returns: Ret value.
        :rtype: str
        """

# Generated at 2022-06-21 12:00:17.463687
# Unit test for function parse
def test_parse():
    assert parse('"""docstring"""') == Docstring(
        short_description=None,
        long_description=None,
        meta=[],
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert parse('"""docstring\n"""') == Docstring(
        short_description="docstring",
        long_description=None,
        meta=[],
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert parse('"""docstring\n\n"""') == Docstring(
        short_description="docstring",
        long_description=None,
        meta=[],
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

# Generated at 2022-06-21 12:00:22.812668
# Unit test for function parse
def test_parse():
    docstr = """Return a string of n spaces.
    :param n: The number of spaces to return
    :type n: int
    :returns: A string of n spaces
    :rtype: str
    """
    result = parse(docstr)
    assert result.short_description == "Return a string of n spaces."
    assert len(result.meta) == 3

# Generated at 2022-06-21 12:00:31.659517
# Unit test for function parse
def test_parse():
    text = '''
        Short description.
        
        Long description.
        
        :param arg1: The first arg.
        :type arg1: int, optional
        :param arg2: The second arg.
        :type arg2: str
        :returns: int
        :raises AttributeError: Raised if something bad happens.
    '''
    doc = parse(text)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert len(doc.meta) == 4
    # :param arg1: The first arg.
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type_name == "int"
    assert doc.meta[0].is_optional is True

# Generated at 2022-06-21 12:00:43.597066
# Unit test for function parse
def test_parse():
    from . import get_test_data_path
    from .common import (
        Docstring,
        ParseError,
    )

    def check_params(doc: Docstring):
        assert len(doc.meta) == 1
        param_meta = doc.meta[0]
        assert param_meta.description == "The index of the item to find."
        assert param_meta.arg_name == "index"
        assert param_meta.type_name == "int"

    doc = parse("Find item.\n\n:param index: The index of the item to find.\n")
    assert doc.short_description == "Find item."
    assert doc.long_description is None
    check_params(doc)


# Generated at 2022-06-21 12:00:55.213191
# Unit test for function parse
def test_parse():
    simple = """
    Simple function.

    :arg: param

    :returns: something
    """

    advanced = """
    This is a more advanced function.

    :param int x: The x value.
    :param str y: The y value.
    :param bool z: The z value.

    :returns: something
    :raises ValueError: when something bad happens

    Longer description goes here.
    """


# Generated at 2022-06-21 12:01:01.692598
# Unit test for function parse
def test_parse():
    """
    >>> docstring = parse('This function does nothing.\n\n:return: nothing.\n:rtype: None')
    >>> docstring.short_description
    'This function does nothing.'
    >>> docstring.long_description
    'nothing.'
    >>> docstring.blank_after_short_description
    True
    >>> docstring.blank_after_long_description
    False
    >>> docstring.meta[0].arg_name
    'return'
    >>> docstring.meta[0].type_name
    None
    >>> docstring.meta[0].is_optional
    False
    >>> docstring.meta[0].default is None
    True
    >>> docstring.meta[0].description
    'nothing.'
    >>> docstring.meta[0].is_generator
    False
    """

# Generated at 2022-06-21 12:01:12.602257
# Unit test for function parse

# Generated at 2022-06-21 12:01:22.167132
# Unit test for function parse
def test_parse():
    """Test the parse function."""

# Generated at 2022-06-21 12:01:32.148573
# Unit test for function parse
def test_parse():
    doc_string = '''
        Short description.

        More detailed description.

        :py:meth:`~foo.Class.method`

        :param int arg1: Description for arg1
        :param int arg2: Description for arg2
        :param foo:
            Description for foo, which is not so short that it can be put on
            the same line as ``:param foo``.

        :raises ValueError:
            If something bad happens.

        :returns:
            The return value.
        '''


# Generated at 2022-06-21 12:01:42.374034
# Unit test for function parse

# Generated at 2022-06-21 12:01:57.476879
# Unit test for function parse
def test_parse():
    """This is a unit test for the parse function"""

# Generated at 2022-06-21 12:02:07.230184
# Unit test for function parse
def test_parse():
    docstr = """Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """
    result = parse(docstr)
    assert isinstance(result, Docstring)
    assert result.short_description == "Parse the ReST-style docstring into its components."
    assert result.long_description is None
    assert result.blank_after_short_description is False
    assert result.blank_after_long_description is True
    assert isinstance(result.meta, list)
    assert isinstance(result.meta[0], DocstringReturns)
    assert result.meta[0].type_name == "parsed docstring"
    assert result.meta[0].is_generator is False



# Generated at 2022-06-21 12:02:17.439194
# Unit test for function parse
def test_parse():
    e = parse("""
    This is the summary line.

    This is the long description.
    """)

    assert e.short_description == "This is the summary line."
    assert e.blank_after_short_description is True
    assert e.long_description == "This is the long description."
    assert e.blank_after_long_description is False

    e = parse("This is the summary line.")

    assert e.short_description == "This is the summary line."
    assert e.blank_after_short_description is True
    assert e.long_description is None
    assert e.blank_after_long_description is False

    e = parse("""This is the summary line.
    This is the long description.""")

    assert e.short_description == "This is the summary line."
    assert e.blank_after_

# Generated at 2022-06-21 12:02:21.921486
# Unit test for function parse
def test_parse():
    docstring = """
    This function returns a Docstring object, given a single- or
    multi-line docstring.

    :type text: str
    :param text: the text of the docstring to parse
    :returns: parsed docstring
    """

    parsed = parse(docstring)
    print(parsed)


# Generated at 2022-06-21 12:02:33.023104
# Unit test for function parse
def test_parse():
    # Dummy docstring
    text = """Parse the ReST-style docstring into its components.

:param foo: The foo parameter
:param bar: The bar parameter defaults to 'baz'.
:returns: parsed docstring
:rtype: Docstring
"""
    result = parse(text)
    assert result.short_description == "Parse the ReST-style docstring into its components."
    assert result.long_description == "The foo parameter\nThe bar parameter defaults to 'baz'."
    assert result.blank_after_short_description is True
    assert result.blank_after_long_description is False
    assert len(result.meta) == 3
    assert result.meta[0].arg_name == 'foo'
    assert result.meta[0].description == 'The foo parameter'

# Generated at 2022-06-21 12:02:40.869910
# Unit test for function parse
def test_parse():
    ds = '''
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    '''
    p = parse(ds)
    assert p.short_description == "Parse the ReST-style docstring into its components."
    assert p.long_description == "returns: parsed docstring"
    assert p.blank_after_short_description == False
    assert p.blank_after_long_description == False

    assert p.meta[0].args == ['returns']
    assert p.meta[0].description == "parsed docstring"
    assert p.meta[0].type_name is None
    assert p.meta[0].is_generator is False


# Generated at 2022-06-21 12:02:50.098417
# Unit test for function parse
def test_parse():
    """Unit test for `parse`."""
    assert parse("") == Docstring()

    # Parse short description
    docstring = parse("Short description.\n\n")
    assert docstring.short_description == "Short description."
    assert not docstring.long_description
    assert not docstring.meta
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description

    # Parse simple long description
    docstring = parse("Short description.\n\nLong description.\n")
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description

    # Parse simple long description with whitespace
   

# Generated at 2022-06-21 12:03:01.217727
# Unit test for function parse
def test_parse():
    assert parse("toto") == Docstring(
        short_description="toto",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("foo\n") == Docstring(short_description="foo")
    assert parse("foo\n\n") == Docstring(short_description="foo")
    assert parse("foo\n\nbar\n") == Docstring(
        short_description="foo", long_description="bar",
    )
    assert parse("foo\n\nbar\n\n") == Docstring(
        short_description="foo", long_description="bar",
    )

# Generated at 2022-06-21 12:03:11.079711
# Unit test for function parse
def test_parse():
    # Ensures no error is raised for an empty string
    parse("")

    # Ensures no error is raised for a simple doc string
    parse("Short description of the function.")

    # Ensures no error is raised for a doc string with a short and long description
    parse("Short description of the function.\n\nLong description of the function.")

    # Ensures no error is raised for a doc string with a short and long description
    parse("Short description of the function.\n\nLong description of the function.\n")

    # Ensures no error is raised for a doc string with one line of meta info
    parse("Documentation for a function.\n\n:param str x: Description of the parameter x.")

    # Ensures no error is raised for a doc string with multiple lines of meta info

# Generated at 2022-06-21 12:03:21.934788
# Unit test for function parse
def test_parse():
    rst = """\
    Short description.

    Long description.
    """
    assert Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="Long description.",
    ) == parse(rst)

    rst = """\
    Short description.

    Long description.

    """
    assert Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="Long description.",
    ) == parse(rst)

    rst = """\
    Short description.

    Long description.

    """

# Generated at 2022-06-21 12:03:38.372850
# Unit test for function parse
def test_parse():
    # Arrange
    expected = Docstring(
        short_description="foo bar",
        long_description="\n".join(["Lorem ipsum", "dolor sit amet"]),
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[DocstringParam(
            args=["parameter", "str", "arg"],
            description="\n".join(["with a typo, the param", "is str"]),
            arg_name="arg",
            type_name="str",
            is_optional=None,
            default=None,
        )],
    )

    # Act

# Generated at 2022-06-21 12:03:50.186843
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""

    test_docstring = """
    Count the number of times `target` appears in `sequence`.

    :param Any target: The object to search for.
    :param Sequence sequence: The sequence to search in.
    :returns int: The number of times the target was found in sequence.
    :raises ValueError: If sequence is not iterable.

    If a string, the target can be a single character or multiple characters.

    .. code-block:: python

        >>> count("a", "banana")
        3
        >>> count("a", "apple")
        1
        >>> count("iss", "mississippi")
        2
    """
    test_docstring_meta = parse(test_docstring)

# Generated at 2022-06-21 12:04:01.046950
# Unit test for function parse
def test_parse():
    test_string = """\
    This is a test sequence.

    This is another test sequence.
    :param name: This is the name
    :type name: str
    :param age: This is the age
    :type age: int
    :param gender: This is the gender
    """

# Generated at 2022-06-21 12:04:11.582609
# Unit test for function parse
def test_parse():
    """
    """
    docstring = """
    One-line description.
    """

    assert parse(docstring).short_description == "One-line description."

    docstring = """
    This is a longer description.  It is indented slightly so that it
    lines up with the first line of the brief description.
    """

    assert parse(docstring).long_description == docstring

    docstring = """
    One-line description.

    This is a longer description.  It is indented slightly so that it
    lines up with the first line of the brief description.
    """

    assert parse(docstring).short_description == "One-line description."
    assert parse(docstring).long_description == "This is a longer description.  It is indented slightly so that it lines up with the first line of the brief description."

    docstring

# Generated at 2022-06-21 12:04:12.666528
# Unit test for function parse
def test_parse():
    assert isinstance(parse(''), Docstring)

# Generated at 2022-06-21 12:04:24.258735
# Unit test for function parse

# Generated at 2022-06-21 12:04:27.619973
# Unit test for function parse
def test_parse():
    """Test parse()"""
    # For the expected values, use the same method as in test.py:
    # parse() -> to_string
    # TODO: Add more tests
    assert parse("hello world").to_string() == "hello world"

# Generated at 2022-06-21 12:04:38.034478
# Unit test for function parse

# Generated at 2022-06-21 12:04:49.436375
# Unit test for function parse
def test_parse():
    doc = """\
    Short description.

    Long description.

    :param arg1: description 1
    :param arg2: description 2
    :type arg2: int
    :param arg3: description 3
    :type arg3: int or str
    :raises Exception: description
    :raises TypeError: description
    :returns: None
    :rtype: int
    """

# Generated at 2022-06-21 12:05:00.516423
# Unit test for function parse
def test_parse():
    """For testing function parse."""
    ex_doc = '''
    Get a value by key.

    :param key: Get a value by key.
    :type key: str
    :returns: A value.
    :rtype: str
    '''
    doc = parse(ex_doc)
    assert doc.short_description == 'Get a value by key.'
    assert doc.long_description == None
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ['param', 'key:', 'Get', 'a', 'value', 'by', 'key.']
    assert doc.meta[0].description == 'A value by key.'
    assert doc.meta[0].arg