

# Generated at 2022-06-21 11:55:28.638919
# Unit test for function parse
def test_parse():
    docstring=parse('''Hello, world.

    This is a rest-style docstring.

    :param name: The name to say hello to
    :type name: str
    :param silent: Whether to say hello or not
    :type silent: bool
    :param fontsize: The font size to use
    :type fontsize: int
    :param fontname: The font family to use
    :type fontname: str
    :returns: str
    :rtype: str
    :raises ValueError: For invalid name
    :raises TypeError: For invalid name length
    
    ''')
    assert docstring.short_description=='Hello, world.'
    assert docstring.long_description=='This is a rest-style docstring.'
    assert docstring.blank_after_short_description==True
    assert doc

# Generated at 2022-06-21 11:55:39.521160
# Unit test for function parse
def test_parse():
    # Test for the short description
    docstring_short_description = '''This is a short description
    This is a short description
    '''
    assert parse(docstring_short_description).short_description == 'This is a short description'

    # Test for the long description
    docstring_long_description = '''This is a short description
    This is a long description
    This is a long description
    '''
    assert parse(docstring_long_description).long_description == 'This is a long description'

    # Test for the blank line
    docstring_short_long_blankline = '''This is a short description

    This is a long description
    '''
    assert parse(docstring_short_long_blankline).blank_after_short_description == False

    # Test for the blank line 2
    docstring_short

# Generated at 2022-06-21 11:55:48.941005
# Unit test for function parse
def test_parse():
    # Test the basic parse function
    assert parse("""\
        Short summary.

        Longer summary. This text is formatted using ReST.
        """) == Docstring(
        short_description="Short summary.",
        blank_after_short_description=True,
        long_description="Longer summary. This text is formatted using ReST.",
        blank_after_long_description=True,
        meta=[],
    )
    # Test that it can handle a single line docstring
    assert parse("Single line doc string") == Docstring(
        short_description="Single line doc string",
        blank_after_short_description=None,
        long_description=None,
        blank_after_long_description=None,
        meta=[],
    )
    # Test that it can handle a single line docstring with no content

# Generated at 2022-06-21 11:56:00.404486
# Unit test for function parse
def test_parse():
    text = inspect.cleandoc("""\
    This is a docstring.

    This is a long description.

    :param a:
        bla bla

    :returns:
        bla bla

    :raises Exception:
        bla bla
    """)


# Generated at 2022-06-21 11:56:07.851075
# Unit test for function parse

# Generated at 2022-06-21 11:56:19.038002
# Unit test for function parse
def test_parse():
    docstring = parse('''
        This is a very long docstring.

        **Args:**

        * `x`
        * `y`
        * `z`

        **Kwargs:**

        * `a` (optional)
        * `b` (optional, defaults to 2)
        * `c` (3)
    ''')
    assert docstring.short_description == "This is a very long docstring."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

    meta_list = docstring.meta
    assert len(meta_list) == 6
    assert meta_list[0].key == "Arg"
    assert meta_list[0].args == ["x"]
    assert meta

# Generated at 2022-06-21 11:56:28.780745
# Unit test for function parse
def test_parse():
    """Main unit test function

    :returns:
    """
    # def test_parse():
    f = inspect.cleandoc(
        """
        Test function
        
        :param dict x: Test
        :param int y: Test
        :param z: Test, defaults to 5
        :raises Exception: Test
        :raises ValueError: Test
        :returns dict: Test
        """
    )
    result = parse(f)
    # print(result)

# Generated at 2022-06-21 11:56:39.422492
# Unit test for function parse
def test_parse():
    test_str = """
    foo bar baz

    :param str message: A message to output.
    :raises ValueError: if no message is received.
    :returns: Nothing.
    """
    docstr = parse(test_str)
    assert docstr.short_description == "foo bar baz"
    assert docstr.long_description == None
    assert docstr.meta[0].args == ['param', 'str', 'message']
    assert docstr.meta[0].description == "A message to output."
    assert docstr.meta[1].args == ['raises', 'ValueError']
    assert docstr.meta[1].description == "if no message is received."
    assert docstr.meta[2].args == ['returns']
    assert docstr.meta[2].description == "Nothing."


# Generated at 2022-06-21 11:56:50.437877
# Unit test for function parse
def test_parse():
    docstring = """
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring

    :param str text: docstring to parse
    :param str ignore: This parameter is ignored.
    :param int important: This one is important.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Parse the ReST-style docstring into its components."
    assert parsed.long_description == ["returns: parsed docstring",
                                       "param str text: docstring to parse",
                                       "param str ignore: This parameter is ignored."
                                       "",
                                       "param int important: This one is important."]
    assert parsed.blank_after_short_description == False
    assert parsed.blank_after_long_description == False

    parsed = parse("")

# Generated at 2022-06-21 11:56:59.697511
# Unit test for function parse
def test_parse():
    docstring = '''
        Short description for function.

        :param param1: First parameter.
        :param param2: Second parameter. Defaults to 2.
        :type param2: int
        :param param3: Third parameter.
        :type param3: bool
        :raises: ValidationError
        :returns: True if successful.
        :rtype: bool
        '''


# Generated at 2022-06-21 11:57:13.835409
# Unit test for function parse
def test_parse():
    doc = """Single line docstring."""
    parsed_doc = parse(doc)
    assert parsed_doc.short_description == "Single line docstring."
    assert parsed_doc.long_description is None

    doc = """
    A short description
    of this function.

    And a more detailed
    description.
    """
    parsed_doc = parse(doc)
    assert parsed_doc.short_description == "A short description of this function."
    assert (
        parsed_doc.long_description
        == "And a more detailed\ndescription."
    )
    assert parsed_doc.blank_after_short_description is True
    assert parsed_doc.blank_after_long_description is True


# Generated at 2022-06-21 11:57:25.463378
# Unit test for function parse
def test_parse():
    """ Test docstring parsing by comparing the parse result to a hand-written
    docstring
    """
    text = """\
    A test function
    This is the first line of the long description
    It should end after this line, but before the following line
    
    :param name: the name
    :type name: str
    :raises SomeError: when things go wrong
    :returns: some results
    """
    result = parse(text)
    assert result.short_description == 'A test function'
    assert result.long_description == text.split('\n')[2]
    assert result.blank_after_short_description
    assert result.blank_after_long_description
    assert len(result.meta) == 3
    assert isinstance(result.meta[0], DocstringParam)

# Generated at 2022-06-21 11:57:33.087933
# Unit test for function parse
def test_parse():
    docstring = """
    Single-line description.

    Long description with emphasis *like this*.

    :param arg1: Description of `arg1`.
    :type arg1: int
    :param arg2: Description of `arg2`,
        which is a long argument.
    :type arg2: str
    :returns: Description of what is returned.
    :rtype: bool
    """

# Generated at 2022-06-21 11:57:45.579989
# Unit test for function parse
def test_parse():
    """Test the function parse of rest_docstring.py"""
    docstring = parse.__doc__
    assert isinstance(docstring, str)


# Generated at 2022-06-21 11:57:54.172028
# Unit test for function parse
def test_parse():
    # Test parse function with good inputs
    print(parse('''
        Short description.

        Long description.
        Line 1.

        Line 2.
    ''').dump())
    print(parse('''
        Short description.

        Long description.
        Line 1.

        Line 2.

        :param arg_name: argument description.
    ''').dump())
    print(parse('''
        Short description.

        Long description.
        Line 1.

        Line 2.

        :param arg_name arg_type: argument description.
    ''').dump())
    print(parse('''
        Short description.

        Long description.
        Line 1.

        Line 2.

        :raises type_name: exception description.
    ''').dump())

# Generated at 2022-06-21 11:58:05.739750
# Unit test for function parse
def test_parse():
    docstring = """
    Short description of function.

    Possibly more detailed description.

    :param arg1:
        a string containing an argument name
    :param int arg2:
        an integer containing a second argument name

    :returns:
        a string containing the return value

    :raises TypeError:
        if a parameter has an inappropriate type
    :raises AttributeError:
        if a parameter has an inappropriate value
    """

    docstring = parse(docstring)
    assert (
        docstring.short_description == "Short description of function."
    ), "short description does not match"
    assert (
        docstring.long_description
        == "Possibly more detailed description."
    ), "long description does not match"

# Generated at 2022-06-21 11:58:22.192463
# Unit test for function parse
def test_parse():
    text = """
        Short description.

        Long description.

        :param x: The x parameter.
        :param y: The y parameter.
        :param z: The z parameter.  optional, defaults to 1.
        :rtype: str
        :returns: The return value.
        :raises: ValueError
        :raises: TypeError
        :raises: KeyError

        """
    parsed = parse(text)
    assert parsed.short_description == "Short description."
    assert (
        parsed.long_description == "Long description."
    ), parsed.long_description
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 5
    for m in parsed.meta:
        assert m.description

# Generated at 2022-06-21 11:58:31.148214
# Unit test for function parse
def test_parse():
    docstr = 'str -> int\n\nThis function does a great job!'
    assert parse(docstr).__dict__ == {'short_description': 'str -> int', 'blank_after_short_description': True, 'blank_after_long_description': False, 'long_description': 'This function does a great job!', 'meta': [DocstringMeta(args=['str', '->', 'int'], description='This function does a great job!')]}

docstr = 'str -> int\n\nThis function does a great job!'
print(parse(docstr).__dict__)

# Generated at 2022-06-21 11:58:39.718572
# Unit test for function parse
def test_parse():
    assert parse("foo") == Docstring(
        short_description="foo",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("foo\nbar") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        long_description="bar",
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("foo\n\nbar") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        long_description="bar",
        blank_after_long_description=True,
        meta=[],
    )


# Generated at 2022-06-21 11:58:51.876802
# Unit test for function parse
def test_parse():
    docstring = """Return a value or raise an exception.

:param int x: A value from 0 to 9.
:raises ValueError: if x is not within the range.
:returns: a value from 0 to 9.
"""

# Generated at 2022-06-21 11:59:08.288320
# Unit test for function parse
def test_parse():
    text = """
    Parses docstring into its components.
    
    :param a: The first param.
    :type a: int, required
    :param b: The second param.
    :type b: bool, optional
    :returns: Something
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "Parses docstring into its components."
    assert docstring.long_description == \
        "The first param.\n\nThe second param."
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "a", "int,"]
    assert docstring.meta[0].arg_name == "a"
    assert doc

# Generated at 2022-06-21 11:59:17.720783
# Unit test for function parse
def test_parse():
    docstr = """
    This is a test docstring for a function.
    There are two lines in this part.
    
    This is the long description.
    
    :param int my_param: The param description.
    :param str my_second_param: And another param.
    :return: Something.
    :rtype: int
    :returns: Something else.
    :raises ValueError: If something bad happens.
    """
    docstring = parse(docstr)
    assert docstring.short_description == 'This is a test docstring for a function.'
    assert docstring.long_description == 'There are two lines in this part.\nThis is the long description.'
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is True

# Generated at 2022-06-21 11:59:24.825166
# Unit test for function parse
def test_parse():
    class Meta:
        def __init__(self, args, description):
            self.args = args
            self.description = description


# Generated at 2022-06-21 11:59:36.708917
# Unit test for function parse
def test_parse():
    text = """
    Get the price for a symbol.
    :param symbol The symbol to find.
    :raises KeyError If symbol does not exist.
    :returns (float): the price.
    """
    docstring = parse(text)
    assert docstring.short_description == "Get the price for a symbol."

    assert docstring.long_description == "the price."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].arg_name == "symbol"
    assert docstring.meta[0].type_name == None
    assert docstring.meta[0].is_optional == None
    assert docstring.meta[0].default == None

# Generated at 2022-06-21 11:59:44.414001
# Unit test for function parse
def test_parse():
    s = """
    Args:
        arg1: The first argument.
        arg2 (str): The second argument.
    Kwargs:
        kwarg1: The first keyword argument.
        kwarg2 (bool): The second keyword argument.
    Returns:
        Return value.
    Raises:
        ValueError: If something goes wrong.
    """
    d = parse(s)
    assert len(d.meta) == 4
    assert d.meta[0].arg_name == "arg1"
    assert d.meta[0].type_name is None
    assert d.meta[0].is_optional is None
    assert d.meta[0].description == "The first argument."

    assert d.meta[1].arg_name == "arg2"

# Generated at 2022-06-21 11:59:52.922836
# Unit test for function parse
def test_parse():
    docstring = parse('''\
    Adds the specified sensor to the specified feed.

    :param int feed_id: the id of the feed to add the sensor to
    :param int sensor_id: the id of the sensor to add to the feed
    :raises: :exc:`ValueError` if the feed_id is less than 0 or the sensor_id is less than 0
    :returns: a new :class:`SensorFeed`.
    ''')

# Generated at 2022-06-21 12:00:04.229627
# Unit test for function parse
def test_parse():
    docstr = """\
Summary line.

    Description of the callable.

    Args:
        arg: The first argument.
        arg2: The second argument (optional, defaults to None).
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.

    Returns:
        Description of the return value.

    Raises:
        AttributeError: The raised error.

    Yields:
        Description of the yielded value.

    Yields:
        Description of the yielded value.

    """
    x = parse(docstr)
    assert x.short_description == "Summary line."
    assert x.long_description == (
        "Description of the callable. "
    )
    assert x.meta[0].key == "Args"

# Generated at 2022-06-21 12:00:15.846381
# Unit test for function parse
def test_parse():
    text = """
    A function that sums two values.

    :param a: the first value to be summed
    :type a: int
    :param b: the second value to be summed
    :type b: int
    :rtype: int

    """
    docstring = parse(text)
    # print("docstring: ")
    # print(docstring)
    # print("short_description: ")
    # print(docstring.short_description)
    # print("long_description: ")
    # print(docstring.long_description)
    # print("meta: ")
    # print(docstring.meta)

    assert docstring.short_description == "A function that sums two values."
    assert docstring.long_description == None

# Generated at 2022-06-21 12:00:27.077426
# Unit test for function parse

# Generated at 2022-06-21 12:00:33.283406
# Unit test for function parse
def test_parse():
    docstring = """
    test-docstring
    :param a: description
    :type a: int
    :return: description of b
    :rtype: bool
    """
    docstring = parse(docstring)
    assert docstring.short_description == "test-docstring"
    assert docstring.long_description == None
    assert docstring.blank_after_long_description == False
    assert docstring.blank_after_short_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].arg_name == "a"
    assert docstring.meta[0].type_name == "int"
    assert docstring.meta[0].description == "description"
    assert docstring.meta[0].is_optional == False
    assert docstring.meta[0].default == None

# Generated at 2022-06-21 12:00:52.199908
# Unit test for function parse
def test_parse():
    func_text1 = '''
    This is a function that does nothing.

    :param arg1: first arg
    :param int arg2: second arg
    :param arg3: third arg
    :returns: a return value
    :returns: None
    :raises ValueError: if nothing happens
    '''
    func_text2 = '''
    This is a function that does nothing.

    :param arg1: first arg
    :param arg2: second arg
    :param arg3: third arg
    :param arg4: fourth arg
    '''
    class_text1 = '''
    This is a class that does nothing.

    :param arg1: first arg
    :param arg2: second arg
    :param arg3: third arg
    :param arg4: fourth arg
    '''

    docstring

# Generated at 2022-06-21 12:01:00.432230
# Unit test for function parse
def test_parse():

    text = """Parse the ReST-style docstring into its components.

    :param target: parse target
    :param bool debug: debug mode
    """

    ret = parse(text)
    assert ret.short_description == 'Parse the ReST-style docstring into its components.'
    assert ret.long_description == None
    assert ret.blank_after_long_description == False
    assert ret.blank_after_short_description == True
    assert len(ret.meta) == 2
    assert isinstance(ret.meta[0], DocstringParam)
    assert ret.meta[0].arg_name == 'target'
    assert ret.meta[0].type_name == None
    assert ret.meta[0].is_optional == None
    assert ret.meta[0].description == 'parse target'

# Generated at 2022-06-21 12:01:11.574039
# Unit test for function parse
def test_parse():
    test_docstring = """Just a test.
    More desc.
    :param bool a: this is a.
    :param: b
    :param str c: c.
    :return: returns.
    :return d: returns d.
    :raises: raises.
    :raises Exception: raises Exception.
    :yields: yields.
    :yields e: yields e.
    """
    print('\n---------------- test_parse ----------------')
    doc = parse(test_docstring)
    print('is parsed: ', doc)
    print('short description: ', doc.short_description)
    print('long description: ', doc.long_description)
    print('blank after short description: ', doc.blank_after_short_description)

# Generated at 2022-06-21 12:01:16.070970
# Unit test for function parse
def test_parse():
    """Testing function parse"""
    print("Testing function parse")
    print("Test1")
    print(parse("""
        Test function parse
        
        :param arg_name: Test function parse
        :returns: Test function parse
        :raises Test function parse : Test function parse
        Test function parse
    """))



# Generated at 2022-06-21 12:01:24.739566
# Unit test for function parse
def test_parse():
    text = """One line summary.
    
    Extended description.
    
    :param arg1: Description of arg1.
    :param arg2: Description of arg2.
    :returns: Description of return value.
    :raises Exception1: Description of exception 1.
    :raises Exception2: Description of exception 2.
    """
    assert parse(text)
    text = """One line summary.
    
    Extended description.
    
    :param arg1: Description of arg1.
    :param arg2: Description of arg2.
    :returns: Description of return value.
    :raises Exception1: Description of exception 1.
    :raises Exception2: Description of exception 2.
    
    
    
    """
    assert parse(text)

# Generated at 2022-06-21 12:01:33.739777
# Unit test for function parse
def test_parse():
    doc = Docstring()
    doc.short_description = "Description."
    doc.blank_after_short_description = True
    doc.blank_after_long_description = True
    doc.long_description = "Description."
    param_doc = DocstringParam(['param', 'name', 'type'], 'description',
        'name', 'type', False, None)
    return_doc = DocstringReturns(['return', 'type'], 'description',
        'type', False)
    meta_doc = DocstringMeta(['meta'], 'description')
    doc.meta = [param_doc, return_doc, meta_doc]

    assert parse("Description.\n\nDescription.\n\n:param name: type\n  description\n:return type\n  description\n:meta\n  description") == doc

# Generated at 2022-06-21 12:01:43.483331
# Unit test for function parse
def test_parse():
    docstring_text = """The 'Quick Brown Fox' module provides a demonstration of
    a properly formatted docstring.

    This module is called 'Quick Brown Fox' because I can't think of anything
    better, just now.

    To use it you should:

    1. Add it to your code
    2. Call it like this:

        >>> import quickbrownfox
        >>> quickbrownfox.do_nothing()
    """
    docstring = parse(docstring_text)
    assert docstring.short_description == "The 'Quick Brown Fox' module provides a demonstration of"

# Generated at 2022-06-21 12:01:54.154136
# Unit test for function parse
def test_parse():
    text = """this is a short description
    
    This is a long description.
    
    :param x: parameter description
    :type x: float
    :param y: long description
        of parameter y.  
    :type y: float
    :param z: parameter description
    
    :returns: something
    :rtype: int
    :raises ValueError: when values are bad
    
    """
    ds = parse(text)
    assert ds.short_description == "this is a short description"
    assert ds.long_description == "This is a long description."
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == True
    
    # meta
    assert len(ds.meta) == 4

# Generated at 2022-06-21 12:01:55.926222
# Unit test for function parse
def test_parse():
    s = """
    >>> parse(text) is None
    True
    """
    raise NotImplementedError("Not implemented test case.")

# Generated at 2022-06-21 12:02:01.771136
# Unit test for function parse
def test_parse():
    def _parse_assert(expected, docstring):
        actual = parse(docstring)
        assert actual.short_description == expected.short_description
        assert actual.long_description == expected.long_description
        assert actual.blank_after_short_description == expected.blank_after_short_description
        assert actual.blank_after_long_description == expected.blank_after_long_description
        assert len(actual.meta) == len(expected.meta)
        for x, y in zip(actual.meta, expected.meta):
            assert x.args == y.args
            assert x.description == y.description
            assert isinstance(x, type(y))
            if isinstance(x, DocstringParam):
                assert x.arg_name == y.arg_name
                assert x.type_name == y.type_name


# Generated at 2022-06-21 12:02:18.357616
# Unit test for function parse
def test_parse():
    """
    Test parse function.
    """
    test_1 = """
    Test docstring for function.

    :param int a: a test parameter
    :param b: another test parameter
    :raises ValueError: if something bad happens
    :returns: the result of the test

    And a long description that goes on and on and on.
    """

    doc = parse(test_1)
    assert doc.short_description == "Test docstring for function."
    assert doc.long_description == (
        "And a long description that goes on and on and on."
    )
    assert doc.blank_after_long_description
    assert doc.blank_after_short_description
    assert len(doc.meta) == 3

# Generated at 2022-06-21 12:02:30.007398
# Unit test for function parse

# Generated at 2022-06-21 12:02:37.090297
# Unit test for function parse
def test_parse():
    import os
    import inspect
    import re
    import pytest
    from collections import defaultdict
    from pylint_plugin.rewriter import _build_meta
    from pylint_plugin.rewriter import _build_astroid_from_code
    
    def _extract_function_names(directory_name, file_name):
        function_name_dict = defaultdict(list)
        with open(os.path.join(directory_name,file_name), "r") as f:
            for line in f.readlines():
                if "def" in line:
                    # Find the first quote
                    first_quote_position = line.find("'")
                    # Find the second quote
                    second_quote_position = line.find("'", first_quote_position + 1)


# Generated at 2022-06-21 12:02:48.055113
# Unit test for function parse
def test_parse():
    docstring = '''
    A single-line description.

    A multi-line description.

    :param foo: an argument
    :type foo: int
    :param bar: an optional argument, defaults to 42
    :type bar: int
    :param baz: a multi-line argument

        Description for the argument.

    :type baz: int
    :returns: the answer
    :rtype: int
    :raises RuntimeError: if all else fails
    :raises Exception: if something else fails
    '''

    parsed_docstring = parse(docstring)

    assert parsed_docstring.short_description == 'A single-line description.'
    assert parsed_docstring.long_description == 'A multi-line description.'
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_doc

# Generated at 2022-06-21 12:02:59.268790
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    from .helpers import parse_py_function

    def mytestfunc():
        """
        My test function docs.

        :param arg1: This is the arg1 arg.
        :param arg2: This is the arg2 arg.  Defaults to 5.
        :type: str

        :returns: this is what returns
        :rtype: int
        """
        return 42

    obj = parse_py_function(mytestfunc)

# Generated at 2022-06-21 12:03:09.716211
# Unit test for function parse
def test_parse():
    docstr = """This is a short description.
    
    This is a long description.
    
    :param arg1: args1
    :param arg2: args2
        args2 continued
    :type arg2: str
    :param arg3: args3
    :type arg3: str
    :param arg4: args4
    :returns: returns
    :raises TypeError: raises
    :yields: yields
    :returns: returns
    """

    def function():
        pass

    function.__doc__ = docstr
    output = parse(docstr)

    assert output.short_description == "This is a short description."
    assert output.blank_after_short_description is True
    assert output.long_description == "This is a long description."
    assert output.blank_after_long_description

# Generated at 2022-06-21 12:03:16.376619
# Unit test for function parse
def test_parse():
    docstring = " :param A: \n   - long param desc"
    ret = parse(docstring)
    assert hasattr(ret, 'meta')
    assert len(ret.meta) == 1
    assert hasattr(ret.meta[0], 'arg_name')
    assert ret.meta[0].arg_name == 'A'
    assert hasattr(ret.meta[0], 'description')
    assert ret.meta[0].description == 'long param desc'


# Generated at 2022-06-21 12:03:25.063766
# Unit test for function parse

# Generated at 2022-06-21 12:03:36.814378
# Unit test for function parse
def test_parse():
    text = """Find the closest value in an ordered list.

The function uses binary search to find the closest value to the given
argument in an ordered list.

Parameters
----------
value : int
    The value to find.

sorted_list : list of int
    The sorted list of items to search through.

Returns
-------
best_match : int
    The closest match to the given value in the sorted list.

Raises
------
TypeError
    If the input values are of the wrong type.
    """


# Generated at 2022-06-21 12:03:38.549524
# Unit test for function parse
def test_parse():
    assert parse(docstr) == parsed

# Unit tests for class Docstring

# Generated at 2022-06-21 12:03:51.982457
# Unit test for function parse
def test_parse():
    docstring = """short desc
    long desc

    :param str s: short desc
    :raises ValueError: short desc"""
    doc = parse(docstring)
    assert doc.short_description == 'short desc'
    assert doc.long_description == 'long desc'
    assert doc.meta[0].key == 'param'
    assert doc.meta[0].arg_name == 's'
    assert doc.meta[0].description == 'short desc'



# Generated at 2022-06-21 12:04:03.562999
# Unit test for function parse
def test_parse():
    str_ = """
    @params x: int
    @params y: float, defaults to 2.
    @params z: bool?
    """
    assert parse(str_)
    str_ = """
    @params x: int
    @params y: float, defaults to 2.
    @params z: bool?
    @params new_param: str, defaults to 'test'
    """
    assert parse(str_)

# Generated at 2022-06-21 12:04:12.580542
# Unit test for function parse

# Generated at 2022-06-21 12:04:24.204561
# Unit test for function parse
def test_parse():
    text = """Summary line here.

This is a multiline description. You should use
this to provide an extended description of the
function's purpose.

:param str name: The name to use.
:param bool state: Current state to be in.
:returns: int -- the return code.
"""

# Generated at 2022-06-21 12:04:34.833663
# Unit test for function parse
def test_parse():
    doc = """A one-line summary of the function.
            A longer description of the function.  The first sentence is
            treated as the summary, and the rest of the description is
            treated as the long description.

            :param arg1: An argument.
            :type arg1: str
            :param arg2: A default-valued argument.
            :type arg2: int, optional
            :param arg3: A keyword-only argument.
            :type arg3: int
            :raises ValueError: if the bar is greater than the foo.
            :returns: The value of the foo.
            :rtype: str
            """
    parse(doc)
    # Test that doc is not empty
    assert(not parse(doc).is_empty())
    # Test that doc is a Docstring

# Generated at 2022-06-21 12:04:40.750308
# Unit test for function parse
def test_parse():
    text = parse("""
    This is a test docstring.

    :param name: The name of the person.
    :param age: Age of the person.
    :returns: None
    """)

    assert text.short_description == "This is a test docstring."
    assert text.long_description is None
    assert len(text.meta) == 2
    assert isinstance(text.meta[0], DocstringParam)
    assert text.meta[0].description == "The name of the person."
    assert isinstance(text.meta[1], DocstringReturns)

# Generated at 2022-06-21 12:04:51.093602
# Unit test for function parse
def test_parse():
  text_1 = '''
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    '''

  text_2 = '''
    Parse the ReST-style docstring into its components.

    :arg type_name arg_name: description
    :arg arg_name: description
    :param arg_name: description
    :type_name arg_name: description
    '''


# Generated at 2022-06-21 12:05:02.563420
# Unit test for function parse
def test_parse():
    docstring = """Test function docstring parse.

    :param str value: A string to parse.
    :returns: Parsed object.
    """
    d = parse(docstring)
    assert len(d.meta) == 2
    param = d.meta[0]
    assert isinstance(param, DocstringParam)
    assert param.keyword == "param"
    assert param.arg_name == "value"
    assert param.type_name == "str"
    assert param.description == "A string to parse."
    return_ = d.meta[1]
    assert isinstance(return_, DocstringReturns)
    assert return_.keyword == "returns"
    assert return_.type_name is None
    assert return_.description == "Parsed object."

