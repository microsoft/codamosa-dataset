

# Generated at 2022-06-21 11:55:33.652449
# Unit test for function parse
def test_parse():
    docstring1 = parse("""
    test docstring
    """)
    assert docstring1.short_description == 'test docstring'
    assert docstring1.long_description == None

    docstring2 = parse("""
    test docstring
    test docstring
    """)
    assert docstring2.short_description == 'test docstring'
    assert docstring2.long_description == 'test docstring'

    docstring3 = parse("""
    test docstring
    :param test: test docstring
    """)
    assert docstring3.short_description == 'test docstring'
    assert docstring3.meta[0].description == 'test docstring'


# Generated at 2022-06-21 11:55:41.436938
# Unit test for function parse
def test_parse():
    text = """
        This is the short description.

        This is the long description.
        It stretches over several lines.

        :param name: The name to use.
        :type name: str
        :param returns: The return value
        :type returns: str
        :param raises: The exception to raise.
        :type raises: Exception
        :param param name: The parameter name.
        :return: specified return type.
        :rtype: int
        :yields: specified yield type.
        """
    print(text)
    result = parse(text)
    print(result)

# Generated at 2022-06-21 11:55:49.899667
# Unit test for function parse
def test_parse():
    assert parse("Refreshes the data source.") == Docstring(
        short_description="Refreshes the data source.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

    assert parse("Refreshes the data source.") == Docstring(
        short_description="Refreshes the data source.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )


# Generated at 2022-06-21 11:56:01.113126
# Unit test for function parse
def test_parse():
    global _build_meta
    global PARAM_KEYWORDS
    global RAISES_KEYWORDS
    global RETURNS_KEYWORDS
    global YIELDS_KEYWORDS
    
    # test _build_meta
    _build_meta = parse._build_meta
    PARAM_KEYWORDS = parse.PARAM_KEYWORDS
    RAISES_KEYWORDS = parse.RAISES_KEYWORDS
    RETURNS_KEYWORDS = parse.RETURNS_KEYWORDS
    YIELDS_KEYWORDS = parse.YIELDS_KEYWORDS
    
    TestDocstrMeta = T.NamedTuple('TestDocstrMeta', [('args', T.List[str]), ('description', str)])


# Generated at 2022-06-21 11:56:13.017446
# Unit test for function parse
def test_parse():
    source = '''
    Hello world.

    :param str name: The name of the hello.
    :param int hello_num: How many hellos.
    :returns: number of hellos.
    '''
    doc = parse(source)

    assert doc.short_description == 'Hello world.'
    assert doc.long_description == 'The name of the hello.\n\nHow many hellos.'
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description

    assert len(doc.meta) == 3
    name, hello_num, returns = doc.meta

    assert name.args == ['param', 'str', 'name']
    assert name.description == 'The name of the hello.'
    assert name.arg_name == 'name'

# Generated at 2022-06-21 11:56:14.913053
# Unit test for function parse
def test_parse():
    import re
    doc = """
    :param x1:
      foo
      bar
    """
    parse(doc)
    doc = """
    :param x2:
    """
    parse(doc)
    doc = """
    :param x3:
      foo
      bar

    """
    parse(doc)

# Generated at 2022-06-21 11:56:23.141311
# Unit test for function parse
def test_parse():
    # add @typecheck
    text = '''
    This is text.
    :param name: name.
    :type name: str
    :returns: .
    '''
    docstring = parse(text)
    assert docstring.long_description == "This is text."
    assert docstring.short_description == "This is text."
    assert docstring.meta[0].arg_name == "name"
    assert docstring.meta[0].type_name == "str"
    assert docstring.meta[1].type_name == None

# Generated at 2022-06-21 11:56:35.638159
# Unit test for function parse
def test_parse():
    import pytest
    
    def func(foo: str, *, bar: int = 0, 
             baz: T.Optional[bool] = None) -> int:
        """This is a doctring.

        :param foo: A string.
        :param bar: An integer.
        :param baz: A bool.
        :param baz: An int.
        :returns: 1
        :raises ValueError: If an invalid value is found.
        """
    

# Generated at 2022-06-21 11:56:42.140346
# Unit test for function parse
def test_parse():
    doc = """
        Single line docstring.
        
        Long description goes here and is separated from short description by a blank line.
        
        :param param1: doc for param1
        :type param1: str
        :param param2: doc for param2
        :type param2: str
        :param param3: doc for param3
        :type param3: str
        
        :returns: doc for return value
        :rtype: str
        
        :raises ValueError: in case an error happened
    """
    d = parse(doc)
    print(d)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:56:52.983918
# Unit test for function parse
def test_parse():
    ds = "Class A.\n    :param a: this is a.\n    :param b: this is b.\nIt is a very nice class."
    ds = parse(ds)
    assert ds.short_description == "Class A."
    assert ds.long_description == "It is a very nice class."
    assert ds.meta[0].arg_name == "a"
    assert ds.meta[0].type_name == None
    assert ds.meta[0].is_optional == None
    assert ds.meta[0].default == None
    assert ds.meta[0].description == "this is a."
    assert ds.meta[1].arg_name == "b"
    assert ds.meta[1].type_name == None

# Generated at 2022-06-21 11:57:08.096215
# Unit test for function parse
def test_parse():
    docstring = "Hello, world!"
    assert parse(docstring) == Docstring(
        short_description="Hello, world!",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

    docstring = """
    Hello, world!

    Docs go here.
    """
    assert parse(docstring) == Docstring(
        short_description="Hello, world!",
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description="Docs go here.",
        meta=[],
    )

    docstring = """
    Hello, world!

    Docs go here.
    """

# Generated at 2022-06-21 11:57:12.144343
# Unit test for function parse
def test_parse():
    _docstring = """
:param str url: url of the page
:param params: Additional arguments to pass to `requests.request`.
:param dict headers: Additional headers to pass to `requests.request`.
:param int timeout: Seconds to wait before timing out on the requests.
"""
    assert parse(_docstring)

# Generated at 2022-06-21 11:57:24.691775
# Unit test for function parse
def test_parse():
    doc = """\
        parses the ReST-style docstring into its components.

        :param str bar: bar description
        :param int baz: baz description
        :param str baz2: baz with *some* :math:`\LaTeX`

        :returns: parsed docstring
        :rtype: Docstring
    """
    docstring = parse(doc)
    assert docstring.short_description == "parses the ReST-style docstring into its components."
    assert docstring.long_description == ":param str bar: bar description\n:param int baz: baz description\n:param str baz2: baz with *some* :math:`\LaTeX`"
    assert docstring.blank_after_short_description is True

# Generated at 2022-06-21 11:57:26.464171
# Unit test for function parse
def test_parse():
    docstring = parse.__doc__
    parsed = parse(docstring)
    print(parsed)

# Generated at 2022-06-21 11:57:33.494071
# Unit test for function parse
def test_parse():
    """Test function parse"""
    text = '''Parse the ReST-style docstring into its components.

:param foo: First parameter, defaults to "bar"
:type foo: str, optional
:param bar: Second parameter
:type bar: int
:raises ValueError: The first parameter is not a `foo`
:raises TypeError: The second parameter is bad
:returns: parsed docstring
:rtype: Docstring
'''

# Generated at 2022-06-21 11:57:45.999869
# Unit test for function parse
def test_parse():
    text=r'''
       该函数功能是什么？该函数如何使用？
      :param a: 这个参数是什么
      :param b: 这个参数是什么
      :type b: int
      :raises KeyError: 如果引发这个错误是什么情况？
      :returns: 返回什么
      :rtype: str
    '''
    print(parse(text))

# Generated at 2022-06-21 11:57:53.825297
# Unit test for function parse

# Generated at 2022-06-21 11:58:05.344689
# Unit test for function parse

# Generated at 2022-06-21 11:58:14.213119
# Unit test for function parse
def test_parse():
    def _test_parse(
        func,
        is_generator=False,
        expects_blank_after_short_desc=False,
        expects_blank_after_long_desc=False,
    ):
        expected_short_desc = "This is a short description."
        expected_long_desc = """
    And here is some long description that spans multiple lines.
    And here is some more.
    """
        actual_meta = parse(inspect.getdoc(func))
        actual_meta.is_generator = is_generator
        # Build the expected side of the comparison.
        expected_meta = Docstring()
        expected_meta.short_description = expected_short_desc
        expected_meta.blank_after_short_description = (
            expects_blank_after_short_desc
        )
        expected_meta

# Generated at 2022-06-21 11:58:23.487603
# Unit test for function parse
def test_parse():
    doc = """
    Lazy substitution for the datetime type.

    :type arg1: str
    :param arg1: The first parameter.
    :type arg2: str
    :param arg2: The second parameter.
    :raises TypeError: An exception
    :returns: None
    :return type: None
    :raises KeyError: When a key error
    :rtype: None
    """
    docstring = parse(doc)

    assert doc == str(docstring)
    assert docstring.short_description == "Lazy substitution for the datetime type."
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 6

# Generated at 2022-06-21 11:58:39.318900
# Unit test for function parse
def test_parse():
    # test normal case
    text='''This is the short description.
    
    This is the long description.
    
    :param name: The name to use.
    :type name: str
    :param state: Current state to be in.
    :type state: bool
    :returns: Description of what is returned.
    :rtype: int
    :returns: Description of what is returned.
    :rtype: int
    :raises keyError: It can raise KeyError
    
    
    
    
    '''
    res=parse(text)

    assert(res.short_description=='This is the short description.')
    assert(res.long_description=='''This is the long description.
    ''')
    assert(res.blank_after_short_description==True)

# Generated at 2022-06-21 11:58:51.531993
# Unit test for function parse
def test_parse():
    text = """Single line summary.
    
    More detailed description.
    
    :param x: Docstring param x.
    :param y: Docstring param y.
    :type y: int
    :param z: Docstring param z.
    :type z: int, optional
    :raises ValueError: If incorrect values are passed in.
    :returns: A constructed object.
    :rtype: Docstring
    """


# Generated at 2022-06-21 11:58:55.309238
# Unit test for function parse
def test_parse():
    """Check whether the docstring is parsed right."""
    teststring = """Test function.
    :param x: What x
    :param y: What y
    :param b: What do you have?
    """
    print(parse(teststring))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:59:00.651457
# Unit test for function parse
def test_parse():
    assert parse('''
"""'
Parse ReST-style docstring into its components.
"""'
    ''') == parse('''Parse ReST-style docstring into its components.''')


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:59:08.016857
# Unit test for function parse

# Generated at 2022-06-21 11:59:17.420131
# Unit test for function parse
def test_parse():
    docstring = """\
    Computes the sum of a list of numbers.

    :param nums: The list of numbers to add

    :type nums: list of int
    :type nums: list of float

    :param sign: The sign to use

    :type sign: int
    :type sign: float

    :returns: The sum

    :returns: The sign-adjusted sum

    :rtype: int
    :rtype: float

    :raises ValueError: If any of the given numbers is negative

    :raises TypeError: If any of the given numbers is not a number
    """
    doc = parse(docstring)
    assert doc.short_description == "Computes the sum of a list of numbers."
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_

# Generated at 2022-06-21 11:59:24.654283
# Unit test for function parse
def test_parse():
    assert parse("summary line\ndescription.") == Docstring(
        short_description="summary line",
        long_description="description.",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )

    assert parse("summary line\n\ndescription.") == Docstring(
        short_description="summary line",
        long_description="description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

    assert parse("summary line\n\ndescription.\n\n") == Docstring(
        short_description="summary line",
        long_description="description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )


# Generated at 2022-06-21 11:59:36.509904
# Unit test for function parse
def test_parse():
    docstring = '''One line summary.
    Longer description.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises Exception: Will be raised if something is wrong.

    '''

# Generated at 2022-06-21 11:59:44.316374
# Unit test for function parse
def test_parse():
    assert parse("hello\n\nfoo: bar: baz") == Docstring(
        short_description='hello',
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[
            DocstringMeta(
                args=['foo', 'bar'],
                description='baz',
            ),
        ],
    )

# Generated at 2022-06-21 11:59:52.877081
# Unit test for function parse
def test_parse():
    text = '''
    This function does something.
    
    :param str name: Name of the something.
    :param int count: Number of something.
    :returns: Things.
    :raises ValueError: If something is wrong.
    '''
    res = parse(text)
    print(res)
    assert res.short_description == 'This function does something.'
    assert res.long_description == 'Name of the something.\nNumber of something.'
    assert len(res.meta) == 3
    assert res.meta[0].arg_name == 'name'
    assert res.meta[0].type_name == 'str'
    assert res.meta[1].arg_name == 'count'
    assert res.meta[1].type_name == 'int'
    assert res.meta[2].type_name

# Generated at 2022-06-21 12:00:07.830891
# Unit test for function parse
def test_parse():
    docstring = """
    This function does something.

    :param a: the first parameter

    :param b: the second parameter

    :type a: int

    :type b: str

    :returns: x + y + z

    :rtype: str

    """
    x = parse(docstring)
    assert x.short_description == "This function does something."
    assert x.meta[0].description == "the first parameter"
    assert x.meta[0].arg_name == "a"
    assert x.meta[1].description == "the second parameter"
    assert x.meta[1].arg_name == "b"
    assert x.meta[2].description == "int"
    assert x.meta[2].type_name == "int"
    assert x.meta[3].description == "str"
   

# Generated at 2022-06-21 12:00:17.553796
# Unit test for function parse
def test_parse():
    #########
    # Parsing docstrings
    ##
    ## The values below are the attributes of the object returned by the function
    ## ``parse``. Each section of the docstring is parsed and converted to an
    ## attribute of the object.
    ##
    ## * ``short_description``

    assert parse("").short_description == None

    ## * ``long_description``

    assert parse("").long_description == None

    ## * ``blank_after_short_description``

    assert parse("").blank_after_short_description == False

    ## * ``blank_after_long_description``

    assert parse("").blank_after_long_description == False

    ## * ``meta``

    assert parse("").meta == []

    ## The docstring can be indented.

    assert parse("  a").short_description == "a"

   

# Generated at 2022-06-21 12:00:28.477206
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    doc = r"""
        short description
        """

    docstring = parse(doc)
    assert docstring.short_description == "short description"
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []

    doc = r"""
        short description

        long description
        """

    docstring = parse(doc)
    assert docstring.short_description == "short description"
    assert docstring.long_description == "long description"
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-21 12:00:40.084262
# Unit test for function parse
def test_parse():
    docstring = parse(
        "Expectation Value of sigma_z\n\n"
        "This function returns the expectation value of the Pauli sigma_z operator "
        "of a wavefunction.\n\n"
        ":param wavefunctions: wavefunction as a NumPy array\n"
        ":type wavefunctions: NumPy array\n"
        ":return: Expectation Value of sigma_z"
    )
    assert (docstring.short_description == "Expectation Value of sigma_z")
    assert (docstring.long_description ==
            "This function returns the expectation value of the Pauli sigma_z operator "
            "of a wavefunction.")
    assert (docstring.blank_after_short_description is True)

# Generated at 2022-06-21 12:00:51.550839
# Unit test for function parse

# Generated at 2022-06-21 12:01:00.216609
# Unit test for function parse
def test_parse():
    assert Docstring() == parse("")

# Generated at 2022-06-21 12:01:11.336053
# Unit test for function parse
def test_parse():
    docstring1 = """
        This is a short description
        And then some random text
        """

    docstring2 = """
        This is a short description
        
        And then some random text
        
        """

    docstring3 = """
        This is a short description
        
        And then some random text
        
        :param type_name arg_name: description
        
        """

    docstring4 = "A function docstring."

    docstring5 = """
        This is a short description
        
        And then some random text
        
        :param type_name? arg_name: description
        
        """

    docstring6 = """
        :param type_name? arg_name: description
        
        """


# Generated at 2022-06-21 12:01:21.170056
# Unit test for function parse
def test_parse():
    docs = """This function converts from feet to meters.
    
    :param feet: Value in feet
    :type feet: float
    :param accuracy: Optional: Decimal places in output (default: 2)
    :type accuracy: int
    :returns: value in meters
    :rtype: float
    :raises (UnitsError, ValueError): if feet is not a number or if accuracy is less than zero
    """
    docstring = parse(docs)
    assert len(docstring.meta) == 4
    assert isinstance(docstring.meta[0], DocstringParam)
    assert docstring.meta[0].type_name == "float"
    assert docstring.meta[1].type_name == "int"
    assert docstring.meta[1].is_optional is True

# Generated at 2022-06-21 12:01:32.110771
# Unit test for function parse

# Generated at 2022-06-21 12:01:42.336240
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param y: y argument
    :type y: int
    :param x: x argument
    :type x: int

    :returns: something
    :rtype: int

    :raises ValueError: if x < 0
    """
    parsed = parse(docstring)

    assert parsed.short_description == "Short description."
    assert parsed.blank_after_short_description is True
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_long_description is True

# Generated at 2022-06-21 12:01:56.551215
# Unit test for function parse
def test_parse():
    s = """the function does something, and returns an integer.

:param x: the first parameter
:param y: the second parameter
:type y: int
:param z: defaults to 0.5
:type z: float
:raises ValueError: in something went wrong
:returns: an integer
:rtype: int
    """
    ds = parse(s)
    assert ds.short_description == "the function does something, and returns an integer."
    assert ds.blank_after_short_description
    assert ds.blank_after_long_description
    assert ds.long_description == "the function does something, and returns an integer."
    assert len(ds.meta) == 4
    assert ds.meta[0].args == ['param', 'x']

# Generated at 2022-06-21 12:02:01.351890
# Unit test for function parse
def test_parse():
    # FIXME(stefan): This function is very difficult to test.  It parses
    # docstrings of the form we have in this library, but this library already
    # uses parse.  We need a docstring that does not come from the library to
    # be able to test.
    return True

# Generated at 2022-06-21 12:02:09.093653
# Unit test for function parse
def test_parse():
    """Test parse function"""

# Generated at 2022-06-21 12:02:18.729612
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description.

    :param arg1: Parameter 1 (required).
    :type arg1: int
    :param arg2: Parameter 2 (defaults to None).
    :param arg3: Parameter 3 defaults to "foo".
    :type arg3: str
    :returns: Return value.
    """

    docstring = parse(text)

    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert not docstring.blank_after_short_description
    assert docstring.blank_after_long_description

    param1 = docstring.meta[0]
    assert isinstance(param1, DocstringParam)
    assert param1.keyword == "param"

# Generated at 2022-06-21 12:02:30.429431
# Unit test for function parse
def test_parse():
    docstring_input = """
    Short description.

    Longer description.

    :param foo: Argument ``foo``.
    :type foo: int
    :param bar: Argument ``bar``.
    :param baz: Argument ``baz``.
    :type baz: str
    :param qux: Argument ``qux``.
    :type qux: optional[str]
    :param quux: Argument ``quux`` with a default value.
    :type quux: int, defaults to 1.
    :returns: Description of return value.
    :raises MyError: If something bad happens.
    """

# Generated at 2022-06-21 12:02:38.488804
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text0 = 'short description\n'
    text0 += '\n'
    text0 += 'This is a long description\n'
    text0 += '\n'
    text0 += ':param x: int\n'
    text0 += ':returns: None\n'
    text0 += ':raises ValueError: if x is bad\n'
    text0 += '\n'

    docst = parse(text0)
    assert docst.short_description == 'short description'
    assert docst.blank_after_short_description
    assert docst.long_description == 'This is a long description'
    assert not docst.blank_after_long_description
    assert len(docst.meta) == 3

# Generated at 2022-06-21 12:02:48.745766
# Unit test for function parse
def test_parse():
    """
    This function provides a unit test for the parse function.

    The function is called while docstring is not empty, with few
    lines of docstring, having meta information and without meta information.

    """
    func1 = parse("This is a simple docstring")
    func2 = parse("This is a docstring \n with two lines")
    func3 = parse("This is a docstring \n :param name: name of the person")
    func4 = parse("This is a docstring \n :param name: name of the person \n :type name: str")

    # Test for docstring with two lines
    assert func2.long_description == "with two lines"
    assert func2.short_description == "This is a docstring"
    assert func2.blank_after_long_description
    assert func2.blank_after_short

# Generated at 2022-06-21 12:02:59.657340
# Unit test for function parse
def test_parse():
    doc = parse('''
    Hello, world!
    : param x: parameter x
    : param y: parameter y
    : param z: parameter z
    : param type_name: type name
    : returns: what is returned
    : type type_name: int
    ''')
    assert doc.short_description == 'Hello, world!'
    assert not doc.blank_after_short_description
    assert doc.long_description is None
    assert doc.blank_after_long_description
    assert len(doc.meta) == 5
    assert doc.meta[0].args == ['param', 'x']
    assert doc.meta[0].description == 'parameter x'
    assert doc.meta[1].args == ['param', 'y']
    assert doc.meta[1].description == 'parameter y'
    assert doc

# Generated at 2022-06-21 12:03:10.050304
# Unit test for function parse
def test_parse():
    text = '''
    short description
    long description
    :param argname: a dummy argument
    :type argname: int
    :param argname2: a dummy argument
    :type argname2: string
    :returns: nothing
    :rtype: None
    :raises ValueError: if something goes wrong
    '''
    parsed = parse(text)
    assert parsed.short_description
    assert parsed.long_description
    found1 = False
    found2 = False
    found3 = False
    found4 = False
    for meta in parsed.meta:
        if isinstance(meta, DocstringParam):
            if meta.arg_name == "argname":
                found1 = True
                assert meta.type_name == "int"
            elif meta.arg_name == "argname2":
                found

# Generated at 2022-06-21 12:03:20.777492
# Unit test for function parse
def test_parse():
    def fn1():
        """
        The short description.

        The long description.
        """

    assert parse(fn1.__doc__).short_description == "The short description."
    assert parse(fn1.__doc__).blank_after_short_description == True
    assert parse(fn1.__doc__).long_description == "The long description."
    assert parse(fn1.__doc__).blank_after_long_description == False

    def fn2():
        return "The short description."

    assert parse(fn2.__doc__).short_description == "The short description."
    assert parse(fn2.__doc__).blank_after_short_description == False
    assert parse(fn2.__doc__).long_description == None
    assert parse(fn2.__doc__).blank_after_long_description

# Generated at 2022-06-21 12:03:30.113768
# Unit test for function parse
def test_parse():
    doc = inspect.getdoc(parse)
    result = parse(doc)
    assert result.short_description == "Parse the ReST-style docstring into its components."
    assert result.long_description.startswith("Parse the ReST-style docstring into its components.\n\n:returns: parsed docstring")

# Generated at 2022-06-21 12:03:40.791241
# Unit test for function parse
def test_parse():
    docstring = """Single line docstring.
    :param arg1: first arg
    :param arg2: the second arg
    :param arg3: the final arg
    :returns: values
    """
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == 'Single line docstring.'
    assert parsed_docstring.long_description is None
    assert parsed_docstring.blank_after_short_description is False
    assert parsed_docstring.blank_after_long_description is False
    assert len(parsed_docstring.meta) == 4

    docstring = """Single line docstring.

    :param arg1: first arg
    :param arg2: the second arg
    :param arg3: the final arg
    :returns: values
    """

# Generated at 2022-06-21 12:03:52.531845
# Unit test for function parse
def test_parse():
    s = '''
    Short description

    Long description
    :param param: Description of param
    :type param: str
    :param param2: Description of param2
    :type param2: int
    :returns: Description of return
    :rtype: tuple
    :raises keyError: Description of exception
    :raises ValueError: Description of value error
    '''
    doc = parse(s)
    assert doc.short_description == "Short description"
    assert doc.long_description == "Long description"
    assert doc.meta[0].args == ['param', 'str']
    assert doc.meta[1].args == ['param2', 'int']
    assert doc.meta[2].args == ['returns', 'tuple']
    assert doc.meta[3].args == ['keyError']

# Generated at 2022-06-21 12:04:04.154384
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    # Short description
    assert parse("Single line.") == Docstring(
        short_description="Single line.", blank_after_short_description=True
    )
    assert parse("Single line without indentation.") == Docstring(
        short_description="Single line without indentation.",
        blank_after_short_description=True,
    )

    # Long description
    assert parse("One line.\n") == Docstring(
        short_description="One line.",
        long_description=None,
        blank_after_short_description=True,
    )


# Generated at 2022-06-21 12:04:07.298767
# Unit test for function parse
def test_parse():
    docstring = None
    with open('test_parse.txt', 'r') as f:
        docstring = f.read()
    print(parse(docstring))
    return
test_parse()

# Generated at 2022-06-21 12:04:14.702688
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.

    :param type1 param1: Description of the first parameter.

    :param type2 param2: Description of the second parameter.
        With a newline.

    :return:
        Description of what is returned.
    """

# Generated at 2022-06-21 12:04:25.821879
# Unit test for function parse
def test_parse():
    docstring = """
    Single line description.

    This is a longer multi-line description.

    :param x: The first parameter.
    :type x: str
    :param y: The second parameter.
    :returns: The return value.
    :rtype: str
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Single line description."
    assert parsed.blank_after_short_description
    assert parsed.long_description == "This is a longer multi-line description."
    assert parsed.blank_after_long_description
    assert parsed.meta[0].description == "The first parameter."
    assert parsed.meta[0].arg_name == "x"
    assert parsed.meta[0].is_optional is None
    assert parsed.meta[0].type_name == "str"
   

# Generated at 2022-06-21 12:04:36.295177
# Unit test for function parse
def test_parse():
    # Example docstring format
    """
    A foldable map.

    :param key_fn: A function that maps values to keys.
    :param value_fn: A function that maps values to values.
    :param default: The default value to use if the key doesn't exist.
        Defaults to None.
    :param values: The values to map into the foldable.
    :returns: A foldable map.

    """
    doc = parse(inspect.cleandoc(test_parse.__doc__))

    # Check top-level docstring fields
    assert doc.short_description == "A foldable map."
    assert doc.long_description == ""
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False

    # Check meta fields

# Generated at 2022-06-21 12:04:48.352250
# Unit test for function parse
def test_parse():
    """
    Tests the parse function
    """

# Generated at 2022-06-21 12:04:52.682478
# Unit test for function parse
def test_parse():
    text = """\
    This is a ReST-style docstring.

    This is the long description.

    :param str path: The path to the file.
    :returns: The data in the file.
    :raises OSError: If the file was not found.
    """

    docstring = parse(text)
    print(docstring)
    #assert docstring
    #assert docstring.short_description == "This is a ReST-style docstring."
    #assert docstring.long_description == "This is the long description."
    #assert docstring.blank_after_short_description
    #assert docstring.blank_after_long_description
    #assert len(docstring.meta) == 3
    #assert docstring.meta[0].key == "param"
    #assert docstring.meta[0

# Generated at 2022-06-21 12:05:06.619012
# Unit test for function parse
def test_parse():
    example_docstring = inspect.cleandoc("""
    Example function

    Parameters
    ----------
    :param arg1: description of arg1
    :param arg2: description of arg2
    :type arg2: str
    :param arg3: description of arg3
    :type arg3: str (optional)
    :param arg4: description of arg4 (defaults to 'foo').

    Raises
    ------
    :raises ValueError: for missing arguments
    :raises TypeError: for incorrect arg types
    :raises: for bugs

    Returns
    -------
    :returns: nothing
    :rtype: None
    """)

    parsed_example_docstring = parse(example_docstring)

    assert parsed_example_docstring.short_description == 'Example function'
    assert parsed_example_docstring