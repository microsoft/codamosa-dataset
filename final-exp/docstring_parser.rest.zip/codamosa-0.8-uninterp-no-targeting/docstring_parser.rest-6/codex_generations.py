

# Generated at 2022-06-21 11:55:38.933990
# Unit test for function parse
def test_parse():
    docstring = """This is a short summary.
This is a long description.

:param str arg_name:
:param int type_name: (Optional)
:returns:
:rtype: str
:raises ValueError:

This is a short summary.

This is a long description.

:param arg_name:
:type arg_name: str
:param type_name: (Optional)
:type type_name: int
:returns:
:rtype: str
:raises ValueError:
    """
    parsed = parse(docstring)
    print(parsed.short_description)
    print(parsed.long_description)
    for meta in parsed.meta:
        print(meta)

# Generated at 2022-06-21 11:55:46.280229
# Unit test for function parse
def test_parse():
    # failing
    text = """
    Does something awesome.

    :param arg_name: The meaning of life.
    :type arg_name: int
    :para: The meaning of life.
    """
    parse(text)

    # assert docstring.short_description == 'Does something awesome.'
    # assert docstring.long_description == 'The meaning of life.'
    # assert docstring.meta[0].keyword == 'param'
    # assert docstring.meta[0].arg_name == 'arg_name'


# Generated at 2022-06-21 11:55:57.669770
# Unit test for function parse
def test_parse():
    docstr = """A small spaceship
    that can travel billions of lightyears in a fraction of a second.
    The spaceship only have one seat, so there is no need for
    a pilot's license.
    :param fuel: amount of fuel in litres
    :type fuel: int
    :param destination: name of the destination
    :type destination: str
    :param lightspeed: factor of lightspeed
    :type lightspeed: int
    :returns: travel time in hours
    :rtype: float
    :raises DestinationUnknownError: unknown destination
    :raises ValueError: invalid lightspeed
    """

    result = parse(docstr)

    assert result.short_description == "A small spaceship"
    assert not result.blank_after_short_description

# Generated at 2022-06-21 11:56:06.089114
# Unit test for function parse

# Generated at 2022-06-21 11:56:10.535238
# Unit test for function parse
def test_parse():
    doc1 = inspect.cleandoc(
        """Single line summary

        Single line description"""
    )
    assert repr(parse(doc1)) == repr(
        Docstring(
            short_description="Single line summary",
            long_description="Single line description",
            blank_after_short_description=True,
        )
    )

    doc2 = inspect.cleandoc(
        """Single line summary

        :param arg1: description of arg1
        :type arg1: str

        :returns: description of return value
        :rtype: int"""
    )

# Generated at 2022-06-21 11:56:22.148660
# Unit test for function parse
def test_parse():
  text = """\
  This is a test module.

  Args:
    required (str): A required argument.
    optional (str, optional): An optional argument with a default value.
        Defaults to "bar".
    also_optional (str?) : An optional arg with no default.

  Yields:
    str : A string.

  Raises:
    ValueError : When something bad happens.
    SyntaxError : When something else bad happens.

  Returns:
    str : A string.
  """

# Generated at 2022-06-21 11:56:30.303629
# Unit test for function parse
def test_parse():
    # def test_parse(self):
    basic_docstring = """
    This is a simple docstring.
    """
    self.assertEqual(
        parse(basic_docstring),
        Docstring(
            short_description="This is a simple docstring."
        ),
    )

    basic_docstring_without_newline = """
    This is a simple docstring."""
    self.assertEqual(
        parse(basic_docstring_without_newline),
        Docstring(
            short_description="This is a simple docstring."
        ),
    )

    basic_docstring_with_long_description = """
    This is a docstring.

    With a multiline description.
    """

# Generated at 2022-06-21 11:56:40.392057
# Unit test for function parse

# Generated at 2022-06-21 11:56:51.332941
# Unit test for function parse

# Generated at 2022-06-21 11:57:01.591470
# Unit test for function parse
def test_parse():
    def foo():
        """This is a really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really long description."""
        pass

    result = parse(foo.__doc__)

# Generated at 2022-06-21 11:57:13.224586
# Unit test for function parse

# Generated at 2022-06-21 11:57:25.196119
# Unit test for function parse
def test_parse():
    docstring = """
This is a short description.

This is a long description.

:param int count: Number of times to repeat text
:returns: Repeated text

:param str text: Text to be repeated
"""

# Generated at 2022-06-21 11:57:32.939561
# Unit test for function parse

# Generated at 2022-06-21 11:57:45.456225
# Unit test for function parse
def test_parse():
    docstring = parse(r'''
    """Test function.

    This function is used to test the ``parse`` function.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Open`` class has no ``write`` method.

    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.
    arg3 :
        The third argument.

    Returns
    -------
    bool
        The return value. True for success, False otherwise.

    Raises
    ------
    AttributeError
        The ``Open`` class has no ``write`` method.

    """
    ''')
    assert docstring.short

# Generated at 2022-06-21 11:57:54.085691
# Unit test for function parse
def test_parse():
    test_case = """
    """
    try:
      parse(test_case)
    except ParseError:
      pass
    else:
      assert False

    test_case = """Simple example docstring.
    """
    assert parse(test_case) == Docstring([], "Simple example docstring.", None, False, False)

    test_case = """
    Simple example docstring.
    """
    assert parse(test_case) == Docstring([], "Simple example docstring.", None, False, False)

    test_case = """Simple example docstring.
    """
    assert parse(test_case) == Docstring([], "Simple example docstring.", None, False, False)

    test_case = """

    Simple example docstring.
    """

# Generated at 2022-06-21 11:58:05.632945
# Unit test for function parse
def test_parse():
    assert parse(None) == Docstring()
    assert parse("") == Docstring()
    assert parse(" ") == Docstring(
        short_description="",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description="",
    )
    assert parse("not whitespace") == Docstring(
        short_description="not whitespace",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description="",
    )
    assert parse("not just whitespace\n") == Docstring(
        short_description="not just whitespace",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="",
    )


# Generated at 2022-06-21 11:58:22.192982
# Unit test for function parse
def test_parse():
    docstring = r"""
    This is a docstring.

    This can be a long description.

    :param a: this is a description of a
    :type a: str
    :param b: this is a description of b
    :type b: bool
    :param c: this is a description of c
    :type c: dict

    :returns:
    :rtype: bool

    :raises AttributeError: if the object attribute doesn't exist
    """

    parsed = parse(docstring)
    print("Short description: ", parsed.short_description)
    print("Blank after short description: ", parsed.blank_after_short_description)

    print("Long description: ", parsed.long_description)
    print("Blank after long description: ", parsed.blank_after_long_description)

    print("Parameters:")


# Generated at 2022-06-21 11:58:33.874975
# Unit test for function parse
def test_parse():
    """Test the ReST-style docstring parsing functionality."""
    text = """\
    Test function.

    :param int param1: Test parameter 1
    :param str param2: Test parameter 2
    :returns: Test return type
    :rtype: str
    """
    docstring = parse(text)
    print(docstring)
    assert len(docstring.meta) == 2, "Expected two meta sections"
    assert docstring.meta[0].args[1] == "param1", "Expected first arg to be param1"
    assert docstring.meta[0].type_name == "int", "Expected param1 type to be int"
    assert docstring.meta[1].args[1] == "param2", "Expected first arg to be param2"
    assert docstring.meta[1].type_

# Generated at 2022-06-21 11:58:41.299782
# Unit test for function parse
def test_parse():
    doc_string = '''
    This is a quick method to compute a value.

    This method is quick and generally useful.

    :param x: The x value
    :type x: int
    :param y: The y value
    :type y: int
    :rtype: int
    '''
    ret = parse(doc_string)
    assert ret.short_description == "This is a quick method to compute a value."
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == True
    assert ret.long_description == "This method is quick and generally useful."
    assert len(ret.meta) == 3
    assert ret.meta[0].args == ["param", "x", "x"]
    assert ret.meta[0].type_name == "int"
    assert ret

# Generated at 2022-06-21 11:58:53.053899
# Unit test for function parse
def test_parse():
    """Test parse"""
    docstr = """
    Short description.

    Long description.

    :param a: Param a.
    :param b: Param b.
    :raises ValueError: if b isn't a number.
    :returns: B squared.

    """
    d = parse(docstr)
    assert d.short_description == "Short description."
    assert d.long_description == "Long description."
    assert d.blank_after_short_description
    assert d.blank_after_long_description
    assert d.meta[0].arg_name == "a"
    assert d.meta[0].description == "Param a."
    assert d.meta[0].is_optional is False
    assert d.meta[0].type_name is None
    assert d.meta[0].default is None

# Generated at 2022-06-21 11:59:09.027428
# Unit test for function parse
def test_parse():
    text = "This is a useless test.\n\nThis is useful:\n:param int x: This is a param that is useless.\n:param int y: Another useless param.\n\nThis is not useful.\n:returns: This is not useful.\n\nThis is not useful."
    doc = parse(text)
    assert doc.short_description == "This is a useless test."
    assert doc.long_description == "This is useful:\n\nThis is not useful.\n\nThis is not useful."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 2
    assert doc.meta[0].arg_name == "x"
    assert doc.meta[0].type_name == "int"

# Generated at 2022-06-21 11:59:18.202102
# Unit test for function parse
def test_parse():
    assert parse(None) == Docstring()
    assert parse("") == Docstring()
    assert parse('"foo"') == Docstring(short_description='"foo"')
    assert parse('"""foo"""') == Docstring(short_description='"""foo"""')
    assert parse('"foo\nbar"') == Docstring(
        short_description='"foo\nbar"',
        blank_after_short_description=True,
        long_description=None,
    )
    assert parse('"""foo\nbar"""') == Docstring(
        short_description='"""foo\nbar"""',
        blank_after_short_description=True,
        long_description=None,
    )

# Generated at 2022-06-21 11:59:25.550683
# Unit test for function parse
def test_parse():
    docstring = """Summarize the Bomb class.
    Sample code:
    bomb = Bomb()
    explode_bomb(bomb)
    :param model: the internal model to use for the bomb
    :type model: str
    :param name: name of the bomb
    :type name: str
    :param serial: serial number of the bomb
    :type serial: int
    :param explode: explode the bomb
    :type explode: bool
    :returns: does not exist
    :rtype: None
    """


# Generated at 2022-06-21 11:59:37.323585
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    assert parse("A short description.") == Docstring(
        short_description="A short description.",
        blank_after_short_description=True,
        long_description=None,
    )

    assert parse(
        """\
    A short description.
    """
    ) == Docstring(
        short_description="A short description.",
        blank_after_short_description=False,
        long_description=None,
    )

    assert parse(
        """\
    A short description.

    A long description.
    """
    ) == Docstring(
        short_description="A short description.",
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description="A long description.",
    )


# Generated at 2022-06-21 11:59:49.323826
# Unit test for function parse
def test_parse():
    """Test parse routine in ReST style"""

# Generated at 2022-06-21 12:00:01.328194
# Unit test for function parse
def test_parse():
    '''Test parse'''
    # Test with empty docstring
    assert parse('') == Docstring()

    # Test with valid docstring

# Generated at 2022-06-21 12:00:08.894988
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    import textwrap
    from .common import DocstringReturns

# Generated at 2022-06-21 12:00:18.043966
# Unit test for function parse
def test_parse():
    docstring = """
    Short desc summary.

    The first paragraph of the long description.

    The second paragraph of the long description.

    :param a: (int) parameter description
    :kwarg b: (str) parameter description
    :type c: str
    :returns: (str) return description
    :rtype: str
    :raises ValueError: when something bad happens
    :yields: (str) generator description
    :yields: (int) generator description
    """
    ret = parse(docstring)
    assert ret.short_description == "Short desc summary."
    assert ret.long_description == "The first paragraph of the long description.\n\nThe second paragraph of the long description."
    assert ret.blank_after_short_description == False
    assert ret.blank_after_long_description == True

# Generated at 2022-06-21 12:00:28.913177
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('a') == Docstring(short_description='a')
    assert parse('a\nb') == Docstring(short_description='a',
                                      long_description='b',
                                      blank_after_short_description=False,
                                      blank_after_long_description=False)
    assert parse('a\nb\nc') == Docstring(short_description='a',
                                         long_description='b\nc',
                                         blank_after_short_description=False,
                                         blank_after_long_description=False)

# Generated at 2022-06-21 12:00:40.643371
# Unit test for function parse

# Generated at 2022-06-21 12:00:59.445915
# Unit test for function parse
def test_parse():
    ret = parse(u"""
        This is the summary.

        This is the long description.

        :param name: A name.
        :type name: str
        :param value: A value.
        :type value: float
        :returns: A float.
        :rtype: float
        :raises Exception: When something bad happens.
    """)

    assert ret.short_description == "This is the summary."
    assert ret.blank_after_short_description
    assert ret.long_description == "This is the long description."
    assert not ret.blank_after_long_description

    assert len(ret.meta) == 4

# Generated at 2022-06-21 12:01:10.260346
# Unit test for function parse
def test_parse():
    docstring = parse('''
    :param int a: an integer.
    :param str b: a string.
    :returns: None
    ''')
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False

# Generated at 2022-06-21 12:01:20.499826
# Unit test for function parse
def test_parse():
    assert parse(""" An introduction to this function.

    More information about interesting things.
    """) == Docstring(
        short_description="An introduction to this function.",
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description="More information about interesting things.",
        meta=[],
    )

    text = """ An introduction to this function.

    More information about interesting things.

    :param foo: The foo argument
    """


# Generated at 2022-06-21 12:01:32.070926
# Unit test for function parse
def test_parse():
    """ test parse():
    test parse() with docstrings that have different formats.
    """

    # Test: no docstring
    docstring0 = parse("")
    assert docstring0.short_description is None
    assert docstring0.long_description is None
    assert len(docstring0.meta) == 0
    assert docstring0.blank_after_short_description is False
    assert docstring0.blank_after_long_description is False

    # Test: a docstring with only a short description
    docstring1 = parse("This is a function.\n")
    assert docstring1.short_description == "This is a function."
    assert docstring1.long_description is None
    assert len(docstring1.meta) == 0
    assert docstring1.blank_after_short_description is False
    assert docstring

# Generated at 2022-06-21 12:01:42.297294
# Unit test for function parse
def test_parse():
    d = parse("""
        short
        long
        :param int a: aap
        :param str b: noot
            :param str c: mies
            :param int d: wim
            :param int e: zus
            :param int f: jet
        :param int g: teun
        :return: the result
            of this
        :rtype: int
        :raises KeyError: if it can't find key
    """)
    assert d.short_description == "short"
    assert d.long_description == "long\nof this"
    assert d.blank_after_short_description is True
    assert d.blank_after_long_description is False

# Generated at 2022-06-21 12:01:53.159085
# Unit test for function parse
def test_parse():
    text = """\
    A short description.
    
    A long description.
    """
    docstring = parse(text)
    assert docstring.short_description == "A short description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.long_description == "A long description."
    assert docstring.meta == []

    text = """\
    A short description.
    
    :param arg1: The first argument
    :type arg1: str
    
    :param arg2: The second argument
    :type arg2: int
    :default [1]
    :defaults to 10.
    
    :returns: None
    
    A long description.
    """
    docstring = parse(text)

# Generated at 2022-06-21 12:02:00.301788
# Unit test for function parse

# Generated at 2022-06-21 12:02:04.377530
# Unit test for function parse
def test_parse():
    docstring = parse("""
    Function to test

    :param arg1: first arg
    :type arg1: int
    :param arg2: second arg
    :type arg2: str
    :raises ValueError:
    """
    )


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:02:14.788150
# Unit test for function parse

# Generated at 2022-06-21 12:02:21.814080
# Unit test for function parse
def test_parse():
    doc = '''
    :param int a: The first parameter
    :param int b: The second parameter
    :type c: str
    :keyword d: The fourth parameter
    :param float e: The fifth parameter, defaults to 5.0
    :param f: The sixth parameter
    :param g: The seventh parameter
    :return: The return
    :rtype: int
    :returns: The return
    '''
    assert len(parse(doc).meta) == 9


if __name__ == "__main__":
    # Test if this file is executed as a script
    test_parse()

# Generated at 2022-06-21 12:02:40.208747
# Unit test for function parse
def test_parse():
    import pytest

    # no docstring
    assert parse("") == Docstring()

    # short description only
    docstring = parse("My short description.")
    assert docstring.short_description == "My short description."
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert docstring.long_description is None
    assert len(docstring.meta) == 0

    # short description and long description
    docstring = parse(
        """My short description.

            My long description.
            Still part of my long description."""
    )
    assert docstring.short_description == "My short description."
    assert not docstring.blank_after_short_description
    assert docstring.blank_after_long_description

# Generated at 2022-06-21 12:02:49.768222
# Unit test for function parse
def test_parse():
    test_str = r'''
    Test function.

    Lists all of the words in the file on separate lines.
    :param str path: The path to the file.
    :param list(str) words: The words to ignore in the file.
    :param bool ignore_case: Whether case is ignored or not.
    :raises FileNotFoundError: If the file doesn't exist.
    :returns None: Nothing is returned.
    '''
    test_out = parse(test_str)

    assert test_out.short_description == 'Test function.'
    assert test_out.long_description == 'Lists all of the words in the file on separate lines.'
    assert test_out.blank_after_short_description == True
    assert test_out.blank_after_long_description == False

# Generated at 2022-06-21 12:03:00.702971
# Unit test for function parse
def test_parse():
    def parse_test(text, short_desc, long_desc=None, **kwargs):
        docstring = parse(text)
        assert docstring.short_description == short_desc
        assert docstring.long_description == long_desc
        assert len(docstring.meta) == len(kwargs)
        for param in docstring.meta:
            assert param.__dict__ in kwargs.values()

# Test with different types of docstrings
    parse_test("This is a short description", "This is a short description")
    long_desc = "This is a long description that\n" \
                "is in multiple lines"
    parse_test("This is a short description\n\n" + long_desc,
               "This is a short description", long_desc)

# Generated at 2022-06-21 12:03:10.822323
# Unit test for function parse
def test_parse():
    docstr ="""
    Summary line.

    Extended description of function.
    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str
    :param arg3: The third argument.
    :type arg3: str
    :returns: None
    :raises customError: why this block succeeds

    """

# Generated at 2022-06-21 12:03:21.640416
# Unit test for function parse
def test_parse():
    from .common import Docstring
    from .common import DocstringMeta
    from .common import DocstringParam
    from .common import DocstringRaises
    from .common import DocstringReturns

    def test_docstring(text, expected_result):
        result = parse(text)
        print("result", result)
        assert result == expected_result

    # Test parse docstring
    test_docstring(
        """
        A short description.
        
        A long descrption.
        """,
        Docstring(
            short_description="A short description.",
            blank_after_short_description=True,
            blank_after_long_description=True,
            long_description="A long descrption.",
            meta=[],
        ),
    )

# Generated at 2022-06-21 12:03:24.955574
# Unit test for function parse
def test_parse():
    print(parse("""Test parse function.
    :param name: str
        test function
    :return: str
    """))


# Generated at 2022-06-21 12:03:36.761463
# Unit test for function parse
def test_parse():
    text = """Short description.

    More detailed description.

    :param arg: Descriptive text.
    :type arg: int
    :returns: description
    :rtype: None
    :param arg2: Descriptive text.
    :type arg2: int
    :returns: description
    :rtype: None

    """
    actual = parse(text)

# Generated at 2022-06-21 12:03:48.759403
# Unit test for function parse
def test_parse():
    text = """
        Test a docstring parser.


        :param int a: a description.

        :param int b: b description.

        :param int c: c description. C defaults to 3.

        :return int:


        :raises ValueError:

        :raises KeyError:

        :raises LookupError:
    """

    docstring = parse(text)
    assert len(docstring.meta) == 7
    assert docstring.short_description == "Test a docstring parser."
    assert docstring.long_description == ""
    assert docstring.blank_after_short_description == True

    params = docstring.params
    assert len(params) == 3
    assert params[0].arg_name == 'a'
    assert params[1].arg_name == 'b'

# Generated at 2022-06-21 12:03:59.616521
# Unit test for function parse
def test_parse():
    text = """\
    My cool function.

    :param foo: The foo.

    :param bar: The bar.
    :param type bar: int

    :yields: Why not.
    :yields int:
    """
    d = parse(text)
    assert d.short_description == "My cool function."
    assert d.blank_after_short_description
    assert d.blank_after_long_description
    assert d.long_description == ":param foo: The foo.\n\n:param bar: The bar.\n" \
        ":param type bar: int\n\n:yields: Why not.\n:yields int:"
    assert len(d.meta) == 3
    assert d.meta[0].args == ["param", "foo"]
    assert d.meta

# Generated at 2022-06-21 12:04:05.106745
# Unit test for function parse
def test_parse():
    docstring = """Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    :raises: some error

    - more stuff
    """

    parsed_docstring = parse(docstring)
    print(parsed_docstring)


test_parse()

# Generated at 2022-06-21 12:04:24.561630
# Unit test for function parse
def test_parse():
    text = """one line description
       second line description
    :param arg1: this is the first argument
    :type arg1: type(arg1)
    :param arg2 arg2: this is the second argument
    :type arg2: type(arg2)
    :param arg3: this is the third argument
    :param arg4 optional: this is the fourth argument
    :param arg5 optional=1: this is the fifth argument
    :type arg4, arg5: type(arg4, arg5)
    :returns: returns nothing
    :rtype: None
    :raises ValueError: this is a ValueError exception
    :yields: some yields
    :ytype: type(yields)
    """
    docstring = parse(text)
    assert docstring.short_description == 'one line description'
   

# Generated at 2022-06-21 12:04:30.924492
# Unit test for function parse
def test_parse():
    docstring = "short desc \n \n long description \n \n :param arg: description"
    assert parse(docstring) == {
        "short_description": "short desc",
        "long_description": "long description",
        "blank_after_short_description": True,
        "blank_after_long_description": False,
        "meta": [{"args": ["param", "arg"], "description": "description"}],
    }

# Generated at 2022-06-21 12:04:40.179423
# Unit test for function parse
def test_parse():
    from . import common
    import docstring_parser.reST as module
    import docstring_parser.tests.reST_test as module_test
    import importlib
    importlib.reload(common)
    importlib.reload(module)
    importlib.reload(module_test)

    def assert_recursive_equals(left, right):
        if isinstance(left, (list, tuple)):
            assert isinstance(right, (list, tuple))
            assert len(left) == len(right)
            for l, r in zip(left, right):
                assert_recursive_equals(l, r)
        elif isinstance(left, dict):
            assert isinstance(right, dict)
            assert sorted(left.keys()) == sorted(right.keys())

# Generated at 2022-06-21 12:04:50.663556
# Unit test for function parse

# Generated at 2022-06-21 12:05:01.399402
# Unit test for function parse
def test_parse():
    import unittest
    
    _docstring = '''
    Test function for parse function
    
    :param a: a is an integer
    :param b: b is an integer
    :param c: c is an integer
    :returns: the sum of a, b and c
    :raises ValueError: If a is not an integer
    :raises ValueError: If b is not an integer
    :raises ValueError: If c is not an integer
    '''
    
    class Test_parse(unittest.TestCase):
        def test_parse(self):
            self.assertIsInstance(parse(_docstring), Docstring)
    
    unittest.main(argv=[''], verbosity=2, exit=False)

# test_parse()