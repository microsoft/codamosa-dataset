

# Generated at 2022-06-25 16:33:47.491033
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:33:58.056081
# Unit test for function parse
def test_parse():

    # No docstring got empty docstring
    assert(parse("") == Docstring())

    # No description got docstring with no description
    assert(parse("\n\n :key some keywords") == Docstring(meta=[]))

    # One line description got one line description
    assert(
        parse("oneline description") ==
        Docstring(short_description="oneline description")
    )
    assert(
        parse("oneline description\n\n") ==
        Docstring(
            short_description="oneline description",
            blank_after_short_description=True,
            long_description=None,
            blank_after_long_description=False,
        )
    )

    # Multi line description got multi line description

# Generated at 2022-06-25 16:34:10.450915
# Unit test for function parse
def test_parse():
    str_0 = 'Function name\n\nDescription\nSecond line\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Function name'
    assert docstring_0.long_description == 'Description\nSecond line'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == False

    str_1 = 'Function name\n\nDescription\nSecond line\n\n'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Function name'
    assert docstring_1.long_description == 'Description\nSecond line'
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank

# Generated at 2022-06-25 16:34:14.578421
# Unit test for function parse
def test_parse():
    docstring_0 = parse('|XzfkBStP')
    assert docstring_0.short_description == '|XzfkBStP'
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.long_description is None
    assert len(docstring_0.meta) == 0

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 16:34:17.120745
# Unit test for function parse
def test_parse():
    pass


# Generated at 2022-06-25 16:34:20.789433
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:34:26.314300
# Unit test for function parse
def test_parse():
    str_0 = '|XzfkBStP'
    docstring_0 = parse(str_0)
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.long_description == None
    assert docstring_0.short_description == 'XzfkBStP'



# Generated at 2022-06-25 16:34:27.195550
# Unit test for function parse
def test_parse():
    assert(True)

# Generated at 2022-06-25 16:34:38.653747
# Unit test for function parse
def test_parse():
    # Base case
    str_0 = '''This is a short description.

    This is a long description.

    :param arg1: This is a parameter.
    :type arg1: The type for this parameter.
    :returns: This is a return.
    :rtype: The type for this return.
    :raises exc1: This is an exception.
    :raises exc2: This is another exception.
    :raises exc3: This is yet another exception.
    :returns: This is a second return.
    :rtype: The type for this second return.
    '''
    ret_0 = parse(str_0)
    assert type(ret_0) is Docstring
    assert type(ret_0.short_description) is str

# Generated at 2022-06-25 16:34:41.118038
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:34:54.283131
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:34:55.528682
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:35:00.524793
# Unit test for function parse
def test_parse():
    pass


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 16:35:01.397933
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:35:02.463087
# Unit test for function parse
def test_parse():
    pass


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 16:35:11.712671
# Unit test for function parse
def test_parse():
    # test case 0
    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'This is a short description.'

# Generated at 2022-06-25 16:35:18.588838
# Unit test for function parse
def test_parse():
    s = """
    A short description.

    A long description.

    :param arg1: This is a parameter.
    :type arg1: The type for this parameter.
    :returns: This is a return.
    :rtype: The type for this return.
    :raises exc1: This is an exception.
    :raises exc2: This is another exception.
    :raises exc3j This is yet another exception.
    :returns: Tis is a second return.
    :rtypy: The type for this second return.
    """
    result = parse(s)
    assert len(result.meta) == 6
    assert len(result.meta[0].args) == 1
    assert result.meta[0].args[0] == "arg1"

# Generated at 2022-06-25 16:35:22.950886
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '
    docstring_0 = parse(str_0)
    assert type(docstring_0) is Docstring
    docstring_1 = docstring_0
    assert docstring_1.short

# Generated at 2022-06-25 16:35:31.828138
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:35:42.105830
# Unit test for function parse
def test_parse():
    assert docstring_0.short_description == 'This is a short description.'
    assert docstring_0.long_description == 'This is a long description.'
    assert docstring_0.blank_after_long_description == True
    assert docstring_0.blank_after_short_description == True
    assert len(docstring_0.meta) == 6

    assert docstring_0.meta[0].args == ['param', 'arg1']
    assert docstring_0.meta[0].description == 'This is a parameter.'
    assert docstring_0.meta[0].arg_name == 'arg1'
    assert docstring_0.meta[0].type_name == 'The type for this parameter.'
    assert docstring_0.meta[0].is_optional == None
    assert docstring_0.meta[0].default

# Generated at 2022-06-25 16:35:51.039502
# Unit test for function parse
def test_parse():
    # Test that the function raises no exception.
    test_case_0()

# Generated at 2022-06-25 16:36:03.001340
# Unit test for function parse

# Generated at 2022-06-25 16:36:08.099163
# Unit test for function parse
def test_parse():
    # Asserts that the function parse successfully parses docstrings.
    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :type arg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3: This is yet another exception.\n    :returns: This is a second return.\n    :rtype: The type for this second return.\n   '
    docstring_0 = parse(str_0)
    assert type(docstring_0) is Docstring
    assert docstring_

# Generated at 2022-06-25 16:36:13.096965
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '

# Generated at 2022-06-25 16:36:25.043241
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n\n    This is a long description.'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == str_0.split('\n')[0]
    assert docstring_0.long_description == str_0.split('\n\n')[1][4:].strip()
    assert len(docstring_0.meta) == 0

    str_1 = '  :param arg1: This is a parameter.'
    docstring_0 = parse(str_1)
    assert len(docstring_0.meta) == 1
    assert isinstance(docstring_0.meta[0], DocstringParam)
    assert docstring_0.meta[0].default is None


# Generated at 2022-06-25 16:36:25.875517
# Unit test for function parse
def test_parse():
    test_case_0()



# Generated at 2022-06-25 16:36:36.174793
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :type arg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3: This is yet another exception.\n    :returns: This is a second return.\n    :rtype: The type for this second return.\n   '

# Generated at 2022-06-25 16:36:43.143929
# Unit test for function parse
def test_parse():
    # Setup args and kwds
    str_1 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '
    result = parse(str_1)

    # Verify results
    assert result.short_description == 'This is a short description.'
    assert result.blank

# Generated at 2022-06-25 16:36:52.104191
# Unit test for function parse
def test_parse():
    str_0 = '''
       This is a short description.

       This is a long description on a new line.

       :param arg1: This is a parameter.
       :type arg1. The type for this parameter.
       :return: This is a return.
       :rtype: The type for this return.
       :raises exc1: This is an exception.
       :raises exc2: This is another exception.
    '''
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:37:02.336445
# Unit test for function parse

# Generated at 2022-06-25 16:37:19.599294
# Unit test for function parse
def test_parse():
    # Meta parsing
    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '
    docstring_0 = parse(str_0)
    assert str(docstring_0.short_description) == 'This is a short description.'

# Generated at 2022-06-25 16:37:28.887554
# Unit test for function parse
def test_parse():
    # Test a docstring with no meta info and no long description
    docstring_0 = parse('This is a short description.')
    assert docstring_0.short_description == 'This is a short description.'
    assert docstring_0.long_description == None
    assert docstring_0.meta == [
        DocstringMeta(
            args=[],
            description=None,
            arg_name=None,
            type_name=None,
            is_optional=None,
            default=None,
            is_generator=None,
        )
    ]
    # Test that an exception is raised for a bad meta keyword

# Generated at 2022-06-25 16:37:37.084074
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'This is a short description.'

# Generated at 2022-06-25 16:37:39.093800
# Unit test for function parse
def test_parse():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()

test_parse()

# Generated at 2022-06-25 16:37:48.286549
# Unit test for function parse
def test_parse():
    str_1 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '

    assert parse(str_1)



# Generated at 2022-06-25 16:37:56.278936
# Unit test for function parse
def test_parse():

    docstring = parse(
        """
    This is a short description.

    This is a long description.

    :param arg1: This is a parameter.
    :type arg1: The type for this parameter.
    :returns: This is a return.
    :rtype: The type for this return.
    :raises exc1: This is an exception.
    :raises exc2: This is another exception.
    :raises exc3: This is yet another exception.
    :returns: This is a second return.
    :rtype: The type for this second return.
"""
    )
    assert docstring.short_description == "This is a short description."
    assert (
        docstring.long_description
        == "This is a long description.\n\n"
    )
    assert docstring.blank_after

# Generated at 2022-06-25 16:38:09.239830
# Unit test for function parse
def test_parse():
    try:
        str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '
        docstring_0 = parse(str_0)
    except Exception as msg:
        docstring_0 = str(msg)


# Generated at 2022-06-25 16:38:18.872898
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '

# Generated at 2022-06-25 16:38:28.990003
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '
    docstring_0 = parse(str_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 16:38:41.284008
# Unit test for function parse
def test_parse():
    desc = "This is the short description.\n\nThis is the long description.\n\n"
    desc += ":param arg1: this is a parameter.\n"
    desc += ":type arg1: int\n"
    desc += ":returns: this is a return.\n"
    desc += ":rtype: str\n"
    desc += ":raises KeyError: raises an exception\n"

    docstring = parse(desc)

    assert docstring.short_description == "This is the short description."
    assert not docstring.blank_after_short_description
    assert docstring.long_description == "This is the long description."
    assert not docstring.blank_after_long_description

    assert len(docstring.meta) == 4

# Generated at 2022-06-25 16:39:04.247769
# Unit test for function parse
def test_parse():
    # Test case 0
    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '
    docstring_0 = parse(str_0)

    assert docstring_0.short_description == 'This is a short description.'

# Generated at 2022-06-25 16:39:09.393653
# Unit test for function parse
def test_parse():
    test_case_0()

# Compiled regex for matching string literals in the docstring
_STRING_PATTERN = re.compile(r"^\s*([\"\']{3}).*\1", flags=re.MULTILINE)



# Generated at 2022-06-25 16:39:21.330581
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'This is a short description.'

# Generated at 2022-06-25 16:39:31.284451
# Unit test for function parse
def test_parse():
    import inspect
    import pprint
    import re

    str_0 = 'This is a short description.  This is a long description.'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'This is a short description.'
    assert docstring_0.long_description == 'This is a long description.'

    str_1 = 'This is a short description.\n\n    This is a long description.\n    '
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'This is a short description.'
    assert docstring_1.long_description == 'This is a long description.'


# Generated at 2022-06-25 16:39:32.401208
# Unit test for function parse
def test_parse():
    print("\nTesting function parse")
    test_case_0()

# Generated at 2022-06-25 16:39:38.803358
# Unit test for function parse
def test_parse():
    docstring_0 = parse('This is a short description.\n')
    assert docstring_0.short_description == 'This is a short description.', 'Failed: short_description'
    assert not docstring_0.meta, 'Failed: no meta data'
    assert docstring_0.blank_after_short_description == True, 'Failed: blank line after desc'
    assert docstring_0.blank_after_long_description == False, 'Failed: True == False'
    assert not docstring_0.long_description, 'Failed: no long description'
    docstring_1 = parse('This is a short description.\nThis is a long description.')
    assert docstring_1.short_description == 'This is a short description.', 'Failed: short_description'

# Generated at 2022-06-25 16:39:48.764021
# Unit test for function parse
def test_parse():
    """Test ReST-style docstring parsing.
    """
    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:39:50.252258
# Unit test for function parse
def test_parse():
    """
    @brief Unit test for function parse()
    """
    test_case_0()

# Generated at 2022-06-25 16:39:52.805079
# Unit test for function parse
def test_parse():
    print("Testing function parse")
    test_case_0()
    print("OK")


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:40:03.694307
# Unit test for function parse
def test_parse():

    assert(parse("This is a normal doc string.") == Docstring(
        docstring_0.short_description,
        docstring_0.long_description,
        docstring_0.blank_after_short_description,
        docstring_0.blank_after_long_description,
        docstring_0.meta))
    assert(parse("") == Docstring(
        None,
        None,
        False,
        False,
        []))
    assert(parse("This is a docstring.\n\n") == Docstring(
        "This is a docstring.",
        None,
        False,
        False,
        []))
    assert(parse(None) == Docstring(
        None,
        None,
        False,
        False,
        []))



# Generated at 2022-06-25 16:40:32.997581
# Unit test for function parse
def test_parse():
    import random
    import yapf.yapflib.yapf_api
    # Input arguments
    args = []
    args.append(
        'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '
    )

# Generated at 2022-06-25 16:40:37.161196
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == "__main__":
    test_parse()
    print("All tests completed successfully!")

# Generated at 2022-06-25 16:40:38.839987
# Unit test for function parse
def test_parse():
    test_case_0()

# Run the unit tests

# Generated at 2022-06-25 16:40:46.652889
# Unit test for function parse
def test_parse():
    docstr = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.'
    docstring = parse(docstr)
    assert docstring.short_description == 'This is a short description.'
    assert docstring.long_description == 'This is a long description.'
    assert docstring.blank

# Generated at 2022-06-25 16:40:55.910033
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'This is a short description.'

# Generated at 2022-06-25 16:41:05.458013
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'This is a short description.'
    assert docstring_0.blank_after_short_

# Generated at 2022-06-25 16:41:14.847951
# Unit test for function parse
def test_parse():
    """Test function parse."""
    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "This is a short description."
    assert docstring_

# Generated at 2022-06-25 16:41:17.577672
# Unit test for function parse
def test_parse():
    test_case_0()

test_parse()

# Generated at 2022-06-25 16:41:26.793311
# Unit test for function parse
def test_parse():
    """
    Unit test for the `parse` function.
    """
    str_1 = 'A help string.'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'A help string.'

    str_2 = 'A :returns: with no type.'
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == 'A :returns: with no type.'
    assert len(docstring_2.meta) == 1
    assert docstring_2.meta[0].args == ['returns']

    str_3 = 'A :returns: with a type.'
    docstring_3 = parse(str_3)
    assert docstring_3.short_description == 'A :returns: with a type.'

# Generated at 2022-06-25 16:41:36.805373
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse("test") == Docstring(
        short_description="test",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse("test\n\n") == Docstring(
        short_description="test",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-25 16:42:08.044653
# Unit test for function parse
def test_parse():
    """
    Check if the DocStructure object is equivalent to the expected object.

    :param docstring_0:
    :param docstring_1:
    :returns: True if the two DocString objects are equivalent. False otherwise.
    :rtype: Boolean
    """


# Generated at 2022-06-25 16:42:09.223349
# Unit test for function parse
def test_parse():
    test_case_0()


# Generated at 2022-06-25 16:42:20.269249
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring(
        short_description=None,
        long_description=None,
        blank_after_long_description=False,
        blank_after_short_description=False,
        meta=[],
    )

    assert parse('This is a short description.\n\n    This is a long description.') == Docstring(
        short_description='This is a short description.',
        long_description='This is a long description.',
        blank_after_long_description=False,
        blank_after_short_description=False,
        meta=[],
    )


# Generated at 2022-06-25 16:42:34.437571
# Unit test for function parse
def test_parse():
    import unittest
    import tempfile
    import os
    import shutil
    import glob
    import sys

    test_dir = os.path.dirname(__file__)
    if not test_dir:
        test_dir = os.getcwd()
    repo_root = os.path.abspath(
        os.path.join(test_dir, "..", "..")
    )


# Generated at 2022-06-25 16:42:44.568932
# Unit test for function parse
def test_parse():

    # Test 0 for parse
    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :type arg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtype: The type for this second return.\n    '
    test_0 = parse(str_0)
    assert test_0.short_description == 'This is a short description.'
    assert test_0.blank_after

# Generated at 2022-06-25 16:42:55.795927
# Unit test for function parse
def test_parse():
    # TestCase 1
    str_1 = ' A short description.\n\n  A long description.\n  '
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'A short description.'
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank_after_long_description == False
    assert docstring_1.long_description == 'A long description.'
    assert len(docstring_1.meta) == 0

    # TestCase 2
    str_2 = 'A short description.\nA long description.\n'
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == 'A short description.'
    assert docstring_2.blank_after_short_description == False
   

# Generated at 2022-06-25 16:43:05.901121
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n\nThis is a long description.\n\n:param arg1: This is a parameter.\n:typearg1: The type for this parameter.\n:returns: This is a return.\n:rtype: The type for this return.\n:raises exc1: This is an exception.\n:raises exc2: This is another exception.\n:raises exc3j This is yet another exception.\n:returns: Tis is a second return.\n:rtypy: The type for this second return.\n'
    docstring_0 = parse(str_0)
    test_0 = docstring_0.short_description
    test_1 = docstring_0.blank_after_short_description
    test_2 = docstring_0.blank

# Generated at 2022-06-25 16:43:14.106431
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n:param arg1: This is a parameter.\n:type arg1: int\n:returns: This is a return.\n:rtype: str\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'This is a short description.'
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 2
    assert isinstance(docstring_0.meta[0], DocstringParam)
    assert docstring_0.meta[0].arg_name == 'arg1'
    assert docstring_0.meta[0].type_

# Generated at 2022-06-25 16:43:24.481605
# Unit test for function parse
def test_parse():
    
    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '
    docstring_0 = parse(str_0)
    
    # Test the short description
    assert docstring_0.short_description == 'This is a short description.'
    #

# Generated at 2022-06-25 16:43:31.910591
# Unit test for function parse
def test_parse():
    # print(__name__)

    str_0 = 'This is a short description.\n\n    This is a long description.\n\n    :param arg1: This is a parameter.\n    :typearg1: The type for this parameter.\n    :returns: This is a return.\n    :rtype: The type for this return.\n    :raises exc1: This is an exception.\n    :raises exc2: This is another exception.\n    :raises exc3j This is yet another exception.\n    :returns: Tis is a second return.\n    :rtypy: The type for this second return.\n   '
    docstring_0 = parse(str_0)

    # Test 1
    assert docstring_0.short_description == 'This is a short description.'