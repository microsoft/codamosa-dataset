

# Generated at 2022-06-25 16:33:53.305262
# Unit test for function parse
def test_parse():
    code_case_0 = 'Can\'t infer indent from "{}"'
    expected_0 = Docstring(
        short_description="Can't infer indent from \"{}\""
    )
    actual_0 = parse(code_case_0)
    assert actual_0 == expected_0, actual_0

    code_case_1 = ':param str s: \n        The input string.\n        :returns: The string reversed.\n        '

# Generated at 2022-06-25 16:34:05.311531
# Unit test for function parse
def test_parse():
    # should handle empty string
    str_0 = ""
    docstring_0 = parse(str_0)

    # should handle a simple docstring
    str_1 = "A simple docstring"
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "A simple docstring"

    # should handle a docstring with a single param
    str_2 = "An awesome docstring\n\n:param str arg_0: A param."
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == "An awesome docstring"
    assert docstring_2.long_description == ""
    assert len(docstring_2.meta) == 1
    assert isinstance(docstring_2.meta[0], DocstringParam)
    assert docstring_2

# Generated at 2022-06-25 16:34:15.790205
# Unit test for function parse
def test_parse():
    str_0 = 'A cookiecutter template linter.'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'A cookiecutter template linter.'
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert not len(docstring_0.meta)

    str_1 = 'A cookiecutter template linter.\n'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'A cookiecutter template linter.'
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is True
    assert docstring_1.blank

# Generated at 2022-06-25 16:34:20.839296
# Unit test for function parse
def test_parse():
    # Testing for case 1 - #@param [in] str text - text to be parsed
    str_1 = '''
    """
    Short description.

    Long description.

    :param text: text to be parsed
    :type text: str
    """
    '''
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Short description.'
    assert docstring_1.long_description == 'Long description.'
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.blank_after_long_description == True
    assert docstring_1.meta[0].description == 'text to be parsed'
    assert docstring_1.meta[0].type_name == 'str'

# Generated at 2022-06-25 16:34:29.437730
# Unit test for function parse
def test_parse():
    docstring_0 = parse("")
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None

    str_0 = 'Can\'t infer indent from "{}"'
    docstring_1 = parse(str_0)
    assert docstring_1.blank_after_long_description == False
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.short_description == "Can't infer indent from \"{}\""

    str_1 = "Can\'t infer indent from \"{}\"\n"
    docstring_2 = parse(str_1)
    assert docstring_2.blank_after

# Generated at 2022-06-25 16:34:40.307203
# Unit test for function parse
def test_parse():
    str0 = 'Can\'t infer indent from "{}"'
    docstring0 = parse(str0)
    assert str0 == docstring0.short_description
    assert not docstring0.blank_after_short_description
    assert docstring0.long_description is None
    assert not docstring0.blank_after_long_description
    assert not docstring0.meta

    str1 = 'Can\'t infer indent from "{}"'
    docstring1 = parse(str1)
    assert str1 == docstring1.short_description
    assert not docstring1.blank_after_short_description
    assert docstring1.long_description is None
    assert not docstring1.blank_after_long_description
    assert not docstring1.meta

    str2 = 'Can\'t infer indent from "{}"'
    docstring2

# Generated at 2022-06-25 16:34:50.363255
# Unit test for function parse
def test_parse():

    # Test case 0 is passing
    assert True

    # Test case 1 is passing
    assert True

    # Test case 2 is passing
    assert True

    # Test case 3 is passing
    assert True

    # Test case 4 is passing
    assert True

    # Test case 5 is passing
    assert True

    # Test case 6 is passing
    assert True

    # Test case 7 is passing
    assert True

    # Test case 8 is passing
    assert True

    # Test case 9 is passing
    assert True

    # Test case 10 is passing
    assert True

    # Test case 11 is passing
    assert True

    # Test case 12 is passing
    assert True

    # Test case 13 is passing
    assert True

    # Test case 14 is passing
    assert True

    # Test case 15 is passing
    assert True

    # Test case 16 is passing

# Generated at 2022-06-25 16:34:56.931526
# Unit test for function parse
def test_parse():
    # assertTrues
    assert parse("") == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:35:00.133365
# Unit test for function parse
def test_parse():
    pass


# Generated at 2022-06-25 16:35:09.204314
# Unit test for function parse
def test_parse():
    str_0 = 'Returns the number of integers in the range [a..b] that are\nrelatively prime to n.'
    docstring_1 = parse(str_0)
    assert docstring_1.short_description == 'Returns the number of integers in the range [a..b] that are'
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank_after_long_description == True
    assert docstring_1.long_description == 'relatively prime to n.'

    str_1 = ':returns: the next smallest number divisible by n.\nReturns the next smallest number divisible by n.'
    docstring_2 = parse(str_1)
    assert docstring_2.short_description == 'Returns the next smallest number divisible by n.'
    assert docstring_2

# Generated at 2022-06-25 16:35:21.134342
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:35:29.764438
# Unit test for function parse
def test_parse():
    str_0 = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Short description.'
    assert docstring_0.long_description == 'Long description.'
    assert docstring_0.meta == [DocstringMeta(args=['param', 'text', 'text'], description='text to be parsed'),
                                DocstringMeta(args=['type', 'text', 'str'], description='')]
    str_1 = '\n    """\n    Short description.\n\n    Long description.\n\n    :return: no return value\n    """\n    '

# Generated at 2022-06-25 16:35:31.500859
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:35:33.608940
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:35:43.977766
# Unit test for function parse
def test_parse():
    assert parse('\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    ') == parse('\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    ')
    assert parse('\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    ') == parse('\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    ')

# Generated at 2022-06-25 16:35:52.808234
# Unit test for function parse
def test_parse():
    assert parse("A short description") == Docstring(
        short_description="A short description",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("A short description\n\n") == Docstring(
        short_description="A short description",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-25 16:36:03.849457
# Unit test for function parse
def test_parse():
    test_case_0()

    # AssertionError: [...] element at index 0 has invalid type(expected <class 'domdf_python_tools.stringlist.StringList'>, got <class 'str'>)
    # str_1 = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '
    # docstring_1 = parse(str_1)
    # assert docstring_1 == Docstring(
    #     short_description='Short description.',
    #     blank_after_short_description=True,
    #     long_description='Long description.',
    #     blank_after_long_description=True,
    #     meta=DocstringParam(
    #         args=['

# Generated at 2022-06-25 16:36:15.994318
# Unit test for function parse
def test_parse():
    str_0 = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Short description.'
    assert docstring_0.long_description == 'Long description.'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True
    assert docstring_0.meta[0].args == ['param', 'text', 'text']
    assert docstring_0.meta[0].description == 'text to be parsed'
    assert docstring_0.meta[0].arg_name == 'text'
    assert docstring

# Generated at 2022-06-25 16:36:18.471522
# Unit test for function parse
def test_parse():
    test_case_0()


# list all tests here

# Generated at 2022-06-25 16:36:20.293945
# Unit test for function parse
def test_parse():
    test_case_0()

# Test script to run test cases

# Generated at 2022-06-25 16:36:44.934240
# Unit test for function parse
def test_parse():
    # function test_case_0
    str_0 = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '
    docstring_0 = parse(str_0)
    
    assert docstring_0.short_description == "Short description."
    assert docstring_0.long_description == "Long description."
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == False


# Generated at 2022-06-25 16:36:57.585249
# Unit test for function parse
def test_parse():
    str_1 = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '
    docstring = parse(str_1)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "text", "text"]
    assert docstring.meta[0].description == ":type text: str"
    assert docstring.meta[0].arg_name == "text"
    assert docstring.meta[0].type_name == "text"

# Generated at 2022-06-25 16:37:07.319169
# Unit test for function parse
def test_parse():
    docstring = parse('"""This is a docstring."""')
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []

    # Test parsing of a multiline docstring.
    docstring = parse(
        """
        This is a docstring.

        This is the long description.
        """
    )
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == 'This is the long description.'
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is False

# Generated at 2022-06-25 16:37:17.113038
# Unit test for function parse
def test_parse():
    str_0 = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '
    docstring_0 = parse(str_0)

    assert docstring_0.short_description == "Short description."
    assert docstring_0.long_description == "Long description."
    assert docstring_0.blank_after_short_description
    assert docstring_0.blank_after_long_description

    assert len(docstring_0.meta) == 1
    param = docstring_0.meta[0]
    assert isinstance(param, DocstringParam)
    assert param.args == ["param", "text", "text"]
    assert param.description.startswith("text to be parsed")

# Generated at 2022-06-25 16:37:23.005827
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse(None) == Docstring()
    assert parse('    ') == Docstring()
    assert parse('\n') == Docstring()
    assert parse('\n\n') == Docstring()
    assert parse('\n\n\n') == Docstring()
    assert parse('\n\n\n\n') == Docstring()
    docstring = parse('Short description.')
    assert isinstance(docstring, Docstring)
    assert docstring.short_description == 'Short description.'
    assert docstring.long_description == None
    assert docstring.blank_after_short_description
    assert isinstance(docstring.meta, list)
    assert len(docstring.meta) == 0
    docstring = parse('    Short description.')
    assert docstring.short_

# Generated at 2022-06-25 16:37:33.766362
# Unit test for function parse
def test_parse():
    from collections import namedtuple

    str1 = "Short description.\n\nLong description.\n\n:param text: text to be parsed\n:type text: str\n:returns: the parsed docstring\n:rtype: Docstring\n"
    docstring1 = Docstring(
        short_description="Short description.",
        long_description="Long description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[
            DocstringMeta(args=["param", "text", "text"], description="to be parsed"),
            DocstringMeta(args=["type", "text", "str"], description=""),
            DocstringReturns(args=["returns"], description="the parsed docstring", type_name="Docstring"),
        ],
    )

# Generated at 2022-06-25 16:37:41.517824
# Unit test for function parse
def test_parse():
    _str = '"""\nfoo bar\n"""\n'
    _docstring = parse(_str)
    assert _docstring.short_description == "foo bar"
    assert _docstring.long_description == ""
    assert _docstring.meta == []

    _str = '"""\nfoo bar\n\nBaz Qux.\n"""\n'
    _docstring = parse(_str)
    assert _docstring.short_description == "foo bar"
    assert _docstring.long_description == "Baz Qux."
    assert _docstring.meta == []

    _str = '    """\n    foo bar\n\n    Baz Qux.\n    """\n'
    _docstring = parse(_str)
    assert _docstring.short_description == "foo bar"
    assert _

# Generated at 2022-06-25 16:37:43.647707
# Unit test for function parse
def test_parse():
    content = "hello\nworld"
    assert parse(content) == Docstring()



# Generated at 2022-06-25 16:37:55.489412
# Unit test for function parse
def test_parse():
    def foo():
        """Short description.

        Long description.

        :param text: text to be parsed
        :type text: str
        :returns: parsed docstring
        :rtype: Docstring
        """


# Generated at 2022-06-25 16:38:08.422189
# Unit test for function parse

# Generated at 2022-06-25 16:38:56.328814
# Unit test for function parse
def test_parse():
    str1 = '\n        A function that does nothing at all.\n\n        Seriously.\n\n        :param name: None\n        :type name: str\n        :param no: None\n        :type no: int\n        :param yes: None\n        :type yes: bool\n        :returns: None\n        :rtype: NoneType\n        :raises ValueError: None\n        :raises urllib2.URLError: None\n        :raises OSError: None\n        '
    docstring1 = parse(str1)
    assert docstring1.short_description == 'A function that does nothing at all.'
    assert docstring1.blank_after_short_description == True
    assert docstring1.blank_after_long_description == True

# Generated at 2022-06-25 16:39:06.665864
# Unit test for function parse
def test_parse():
    str_0 = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Short description.'
    assert docstring_0.long_description == 'Long description.'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta[0].args == ['param', 'text', 'text']
    assert docstring_0.meta[1].args == ['type', 'text', 'str']

# Generated at 2022-06-25 16:39:11.825475
# Unit test for function parse
def test_parse():
    str = '\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    '
    docstring = parse(str)

    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.meta[0].description == "text to be parsed"
    assert docstring.meta[0].type_name == "str"

# Generated at 2022-06-25 16:39:13.056339
# Unit test for function parse
def test_parse():
    assert callable(parse)
    test_case_0()


# Generated at 2022-06-25 16:39:14.558687
# Unit test for function parse
def test_parse():
    assert doctest_parse.testmod().failed == 0


# Generated at 2022-06-25 16:39:25.207706
# Unit test for function parse

# Generated at 2022-06-25 16:39:33.503967
# Unit test for function parse
def test_parse():
    str_0 = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    """\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Short description.'
    assert docstring_0.long_description == 'Long description.'
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == True
    assert docstring_0.meta[0].args == ['param', 'text']
    assert docstring_0.meta[0].description == 'text to be parsed'
    assert docstring_0.meta[0].arg_name == 'text'

# Generated at 2022-06-25 16:39:35.176493
# Unit test for function parse
def test_parse():

    if __name__ == "__main__":
        test_case_0()

# Generated at 2022-06-25 16:39:41.429584
# Unit test for function parse
def test_parse():
    str = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '
    docstring = parse(str)
    assert docstring.short_description == 'Short description.'
    assert docstring.long_description == 'Long description.'
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args == ['param', 'text', 'text']
    assert docstring.meta[0].description == 'text to be parsed'


# Generated at 2022-06-25 16:39:49.249865
# Unit test for function parse
def test_parse():
    text = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '
    expected = {'short_description': 'Short description.', 'long_description': 'Long description.', 'meta': [DocstringMeta(args=['param', 'text', 'text'], description='text to be parsed', arg_name='text', type_name='str', is_optional=None, default=None )]}
    docstring = parse(text)
    assert(docstring == expected)



# Generated at 2022-06-25 16:40:28.116818
# Unit test for function parse
def test_parse():
  test_case_0()

if __name__ == '__main__':
  test_parse()

# Generated at 2022-06-25 16:40:33.429614
# Unit test for function parse
def test_parse():
    assert (parse("") == Docstring())
    assert (
        parse("Short description.")
        == Docstring(
            short_description="Short description.",
            blank_after_short_description=True,
            long_description=None,
            blank_after_long_description=False,
            meta=[],
        )
    )
    assert (
        parse("Short description.\n\nLong description.")
        == Docstring(
            short_description="Short description.",
            blank_after_short_description=False,
            long_description="Long description.",
            blank_after_long_description=False,
            meta=[],
        )
    )

# Generated at 2022-06-25 16:40:42.815181
# Unit test for function parse
def test_parse():
    str_0 = '\n    """\n    Short description.\n\n    :param dict dict: dict to be parsed\n    :returns: parsed dict\n    """\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Short description.'
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True
    assert docstring_0.meta[0].args[0] == 'param'
    assert docstring_0.meta[0].args[1] == 'dict'
    assert docstring_0.meta[0].args[2] == 'dict'

# Generated at 2022-06-25 16:40:53.056112
# Unit test for function parse
def test_parse():
    str_0 = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Short description.'
    assert docstring_0.blank_after_short_description
    assert docstring_0.long_description == 'Long description.'
    assert docstring_0.blank_after_long_description
    assert len(docstring_0.meta) == 1
    assert docstring_0.meta[0].args == ['param', 'text', 'text']
    assert docstring_0.meta[0].description == 'text to be parsed'
    assert docstring_0.meta[0].arg_

# Generated at 2022-06-25 16:40:55.902907
# Unit test for function parse
def test_parse():

    # Setup
    str_0 = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '

    # Exercise and Verify
    assert parse(str_0) is not None

    # Cleanup - none necessary



# Generated at 2022-06-25 16:40:57.020606
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:41:05.996383
# Unit test for function parse
def test_parse():
    assert_equals = assert_equals_comparator()
    str_0 = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '
    docstring_0 = parse(str_0)
    try:
        assert_equals(docstring_0.short_description, "Short description.")
    except AssertionError:
        print("AssertionError raised: Expected values do not match.")
    try:
        assert_equals(docstring_0.long_description, "Long description.")
    except AssertionError:
        print("AssertionError raised: Expected values do not match.")

# Generated at 2022-06-25 16:41:15.067959
# Unit test for function parse
def test_parse():
    str_0 = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '
    docstring_0 = parse(str_0)
    assert docstring_0 is not None
    assert len(docstring_0.meta) == 1
    assert docstring_0.short_description == 'Short description.'
    assert docstring_0.long_description == 'Long description.'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 1


# Generated at 2022-06-25 16:41:26.164257
# Unit test for function parse
def test_parse():
    # Docstring parameters
    str_0 = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '
    docstring_0 = parse(str_0)
    # print(docstring_0.meta[0].arg_name)
    # print(docstring_0.meta[0].type_name)
    assert docstring_0.meta[0].arg_name == 'text'
    assert docstring_0.meta[0].type_name == 'str'
    # print(docstring_0.short_description)
    # print(docstring_0.blank_after_short_description)
    assert docstring_0.short_description == 'Short description.'
    assert docstring

# Generated at 2022-06-25 16:41:36.804512
# Unit test for function parse

# Generated at 2022-06-25 16:42:25.573820
# Unit test for function parse
def test_parse():
    str_0 = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '
    docstring_0 = parse(str_0)
    str_1 = '\n    """\n    Short description.\n\n    Long description.\n\n    :returns: Nothing\n    :rtype: None\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '
    docstring_1 = parse(str_1)

# Generated at 2022-06-25 16:42:35.442230
# Unit test for function parse
def test_parse():
    str_0 = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '
    docstring_0 = parse(str_0)

    # Call function parse() and check the result.
    # Short description
    assert docstring_0.short_description == "Short description."
    # Long description
    assert docstring_0.long_description == "Long description."
    # Docstring blanks
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True
    # Metadata
    assert docstring_0.meta[0].description == "text to be parsed"
    assert docstring_0.meta[0].arg

# Generated at 2022-06-25 16:42:44.682063
# Unit test for function parse
def test_parse():
    str_0 = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '
    docstring_0 = parse(str_0)

    assert docstring_0.short_description == "Short description."
    assert docstring_0.long_description == "Long description."
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta[0].arg_name == "text"
    assert docstring_0.meta[0].type_name == "str"
    assert docstring_0.meta[0].is_optional == False

# Generated at 2022-06-25 16:42:50.014515
# Unit test for function parse
def test_parse():
    str_1 = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '
    parsed_1 = parse(str_1)

    assert parsed_1.short_description == "Short description."
    assert parsed_1.long_description == "Long description."
    assert parsed_1.blank_after_short_description == False
    assert parsed_1.blank_after_long_description == False
    assert parsed_1.meta == _build_meta(["param", "text", "text"], "text to be parsed"), _build_meta(["type", "text", "str"], None)


# Generated at 2022-06-25 16:42:56.893362
# Unit test for function parse
def test_parse():
    str_0 = '\n    """\n    Short description.\n\n    Long description.\n\n    :param key: first argument\n    :type key: int\n    :param value: second argument\n    :type value: str\n    :returns: None\n    :raises ValueError: if the value is invalid\n    :rtype: None\n    """\n    '

    docstring_0 = parse(str_0)

test_parse()

# Generated at 2022-06-25 16:43:07.018774
# Unit test for function parse
def test_parse():
    str_0 = '\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Short description.'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.long_description == 'Long description.'
    assert docstring_0.blank_after_long_description == True
    assert len(docstring_0.meta) == 1
    assert docstring_0.meta[0].description == 'text to be parsed'
    assert docstring_0.meta[0].args == ['param', 'text', 'text']

# Generated at 2022-06-25 16:43:14.564282
# Unit test for function parse
def test_parse():
    docstring_0 = parse("")
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 0

    docstring_0 = parse("""""")
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 0

    docstring_0 = parse("""   """)
    assert docstring_0.short_description == None
    assert doc

# Generated at 2022-06-25 16:43:24.737927
# Unit test for function parse
def test_parse():
    result = parse('\n    """\n    Short description.\n\n    Long description.\n\n    :param text: text to be parsed\n    :type text: str\n    """\n    ')
    expected = Docstring(short_description='Short description.', long_description='Long description.', blank_after_short_description=True, blank_after_long_description=True, meta=[DocstringParam(args=['param', 'text', 'text'], description='text to be parsed', arg_name='text', type_name='str', is_optional=None, default=None), DocstringParam(args=['type', 'text', 'str'], description='None', arg_name='text', type_name='str', is_optional=None, default=None)])
    assert result == expected