

# Generated at 2022-06-25 16:33:53.488586
# Unit test for function parse
def test_parse():
    # Check that the short description and the long description follow
    # the description of the docstring
    assert parse('').short_description is None
    assert parse('short').short_description == 'short'
    assert parse('short\nlong').long_description == 'long'
    assert parse('short\n\nlong').long_description == 'long'
    assert parse('short\n\nlong').blank_after_short_description == True

    # Check that the meta information is parsed correctly
    docstring = parse(':type a: int\n:param a: this is a\n')
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args == ['type', 'a', 'int']
    assert docstring.meta[0].arg_name == 'a'

# Generated at 2022-06-25 16:33:58.703007
# Unit test for function parse
def test_parse():
    test_case_0()
    assert docstring_0.short_description == 'yr!E*'
    assert docstring_0.long_description == None


# Generated at 2022-06-25 16:34:02.670904
# Unit test for function parse
def test_parse():
    assert False

# def main():
#     test_case_0()
#
# if __name__ == '__main__':
#     main()

# Generated at 2022-06-25 16:34:13.267618
# Unit test for function parse
def test_parse():
    str_0 = '''
    Take a sequence of ints and return their sum.

    :param seq: a list or tuple of integers
    :returns: the sum of the integers

    Exceptions can be handled by client code.

    :raises ValueError: if the sequence contains non-ints
    :raises TypeError: if the sequence is of the wrong type
    '''

    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Take a sequence of ints and return their sum.'
    assert docstring_0.long_description == 'Exceptions can be handled by client code.'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True

# Generated at 2022-06-25 16:34:17.992782
# Unit test for function parse
def test_parse():
    docstring_0 = parse("This is a docstring.")
    assert docstring_0.short_description == "This is a docstring."



# Generated at 2022-06-25 16:34:28.983969
# Unit test for function parse
def test_parse():
    str_0 = '''
        hello, world!
    '''
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'hello, world!'
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is True
    assert docstring_0.blank_after_long_description is False
    assert len(docstring_0.meta) == 0

    str_1 = '''
        hello, world!
        this is a long description
        that spans multiple lines.
        
        In this case, it is left-aligned with the short description.
    '''
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'hello, world!'
    assert docstring_1.blank_after

# Generated at 2022-06-25 16:34:40.090887
# Unit test for function parse
def test_parse():
    str_1 = '''
    Amaze your friends with this cool ReST-style docstring parser.

    This parser will parse a docstring into its components and help you maintain
    it in an editor.

    Args:
        i (int): this is an integer
        b (bool): this is a bool

    Returns:
        str: the string "ok"

    Raises:
        Exception: On world war three
    '''
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Amaze your friends with this cool ReST-style docstring parser'
    assert docstring_1.blank_after_short_description is True
    assert docstring_1.blank_after_long_description is False

# Generated at 2022-06-25 16:34:50.246482
# Unit test for function parse
def test_parse():
    # Default case
    assert(parse('Do something.') == 
        Docstring(
            short_description='Do something.',
            long_description=None,
            blank_after_short_description=False,
            blank_after_long_description=False,
            meta=[],
        ))

    # Leading and trailing blanks on the whole string.
    assert(parse(' Do something. ') == 
        Docstring(
            short_description='Do something.',
            long_description=None,
            blank_after_short_description=False,
            blank_after_long_description=False,
            meta=[],
        ))

    # Leading and trailing blanks on short description.

# Generated at 2022-06-25 16:35:01.391756
# Unit test for function parse
def test_parse():
    str_0 = 'hello world.'
    docstring_0 = parse(str_0)
    assert docstring_0.long_description
    assert docstring_0.meta
    assert docstring_0.short_description
    str_1 = ': :param arg1: this is a parameter.\n: :return: nothing.'
    docstring_1 = parse(str_1)
    assert docstring_1.long_description
    assert not docstring_1.meta
    assert docstring_1.short_description
    str_2 = 'nothing.'
    docstring_2 = parse(str_2)
    assert docstring_2.long_description
    assert docstring_2.meta
    assert not docstring_2.short_description
    str_3 = 'nothing.\n\nnothing.'
    docstring_3

# Generated at 2022-06-25 16:35:10.779141
# Unit test for function parse
def test_parse():
    assert(isinstance(parse(None), Docstring))
    assert(isinstance(parse(''), Docstring))
    assert(isinstance(parse('@param arg1 arg1 description.'), Docstring))
    assert(isinstance(parse('@return: return description.'), Docstring))
    assert(isinstance(parse('@return type: return description.'), Docstring))
    assert(isinstance(parse('@rtype: return description.'), Docstring))
    assert(isinstance(parse('@rtype type: return description.'), Docstring))
    assert(isinstance(parse('@raises type: exception description.'), Docstring))
    assert(isinstance(parse('@raise type: exception description.'), Docstring))
    assert(isinstance(parse('@exception type: exception description.'), Docstring))

# Generated at 2022-06-25 16:35:29.441917
# Unit test for function parse
def test_parse():
    str_0 = "Initialize self.\n\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "
    docstring_0 = parse(str_0)

    assert docstring_0.short_description == "Initialize self."
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.long_description == None

# Generated at 2022-06-25 16:35:40.054409
# Unit test for function parse
def test_parse():
    assert parse("Hello world!") == Docstring(
        short_description="Hello world!",
        blank_after_short_description=True,
    )

    assert parse("Hello\n\nworld!") == Docstring(
        short_description="Hello",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="world!",
    )

    assert parse("Hello\nworld!") == Docstring(
        short_description="Hello",
        long_description="world!",
    )

    assert parse("Hello\n\n\nworld!") == Docstring(
        short_description="Hello",
        blank_after_short_description=True,
        long_description="world!",
    )


# Generated at 2022-06-25 16:35:47.342509
# Unit test for function parse
def test_parse():
    import pytest

    with pytest.raises(Exception) as excinfo:
        str_0 = "Initialize self.\n\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "
        docstring_0 = parse(str_0)
    assert str(excinfo.value) == 'Error parsing meta information near ":param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it\'s used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "'


# Generated at 2022-06-25 16:35:58.754702
# Unit test for function parse
def test_parse():
    string_1 = 'Dummy docstring.'
    docstring_1 = parse(string_1)
    assert docstring_1.short_description == 'Dummy docstring.'

    string_2 = 'Dummy docstring.\nThis is the longer description of the docstring.'
    docstring_2 = parse(string_2)
    assert docstring_2.short_description == 'Dummy docstring.'
    assert docstring_2.long_description == 'This is the longer description of the docstring.'

    string_3 = 'Dummy docstring.\n\nThis is the longer description of the docstring.'
    docstring_3 = parse(string_3)
    assert docstring_3.short_description == 'Dummy docstring.'

# Generated at 2022-06-25 16:36:05.788517
# Unit test for function parse
def test_parse():

    # If the docstring is empty, return empty Docstring object
    assert parse("") == Docstring()

    # If no meta data is present in the docstring, return Docstring object with
    # all empty strings

    cases = [
        "",
        "Short description.\n",
        "Short description. No blank after.\nNo blank after.\n",
        "Short description.\n\nLong description. No blank after.\nNo blank after.\n\n",
        "Short description.\n\nLong description.\n\n",
        "Short description.\n\nLong description.\n",
    ]


# Generated at 2022-06-25 16:36:16.171400
# Unit test for function parse
def test_parse():
    from .pycharm_helper import PyCharmHelper
    from .common import Docstring, DocstringMeta, DocstringParam, DocstringRaises, DocstringReturns
    # test_case_0
    str_0 = "Initialize self.\n\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "
    docstring_0 = parse(str_0)
    # test_case_1

# Generated at 2022-06-25 16:36:19.539965
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:36:28.563837
# Unit test for function parse
def test_parse():
    # Test empty docstring
    docstring = parse("")
    assert docstring.short_description is None
    assert not docstring.blank_after_short_description
    assert docstring.long_description is None
    assert not docstring.blank_after_long_description
    assert not docstring.meta

    # Test short-only docstring
    docstring = parse("The quick brown fox.")
    assert len(docstring.short_description) == 24
    assert docstring.short_description == "The quick brown fox."
    assert not docstring.blank_after_short_description
    assert docstring.long_description is None
    assert not docstring.blank_after_long_description
    assert not docstring.meta

    # Test short with trailing space and long docstring

# Generated at 2022-06-25 16:36:39.280887
# Unit test for function parse
def test_parse():
    docstring_0 = parse("This is line one.\n\nThis is line two.\n\n\n")
    # assert docstring_0.short_description == 'This is line one.'
    # assert docstring_0.long_description == 'This is line two.'
    docstring_1 = parse("This is line one.\n\n\nThis is line two.\n")
    # assert docstring_1.short_description == 'This is line one.'
    # assert docstring_1.long_description == 'This is line two.'
    docstring_2 = parse("This is line one.\n\n\nThis is line two.\n\n")
    # assert docstring_2.short_description == 'This is line one.'
    # assert docstring_2.long_description == 'This is line

# Generated at 2022-06-25 16:36:48.127982
# Unit test for function parse
def test_parse():
    str_0 = "Initialize self.\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Initialize self."
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.long_description == None

# Generated at 2022-06-25 16:37:05.250816
# Unit test for function parse
def test_parse():
    str_0 = "Initialize self.\n\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "
    docstring_0 = parse(str_0)

    assert docstring_0.short_description == "Initialize self."
    assert not docstring_0.blank_after_short_description
    assert docstring_0.blank_after_long_description
    assert not docstring_0.long_description
    assert len(docstring_0.meta) == 2
    assert docstring_0.meta[0].args == ['args']

# Generated at 2022-06-25 16:37:06.739897
# Unit test for function parse
def test_parse():
    # call parse
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:37:16.709046
# Unit test for function parse
def test_parse():
    docstring = parse(
        """Test case

        :param params: parameters
        :param other_params: other parameters

        :type params: list of ints
        :type other_params: dict

        :returns: integer

        :rtype: int

        """
    )
    assert docstring.short_description == "Test case"
    assert docstring.long_description is None
    assert (
        docstring.meta[0] == DocstringParam(
            args=["param", "params", None],
            description="parameters",
            arg_name="params",
            type_name=None,
            is_optional=None,
            default=None,
        )
    )

# Generated at 2022-06-25 16:37:28.494229
# Unit test for function parse
def test_parse():
    # random test case
    text = "Generate a random number between 0 and 1.\n\n        :returns: a random number in (0,1)\n        :rtype: float\n        "

# Generated at 2022-06-25 16:37:29.610916
# Unit test for function parse
def test_parse():
    test_case_0()



# Generated at 2022-06-25 16:37:30.393224
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:37:38.009428
# Unit test for function parse
def test_parse():
    str_0 = "Initialize self.\n\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "

# Generated at 2022-06-25 16:37:48.360883
# Unit test for function parse
def test_parse():
    text = (
        "Compute the square of the given number.\n"
        "\n"
        ":param number: Non-negative number\n"
        ":type number: int\n"
        ":returns: The square of ``number``.\n"
        ":rtype: int\n"
        ":raises ValueError: If ``number`` is negative.\n"
        "\n"
        "This function does stuff."
    )

# Generated at 2022-06-25 16:37:57.662234
# Unit test for function parse
def test_parse():
    docstring_0 = parse('')
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is None
    assert docstring_0.blank_after_long_description is None
    assert docstring_0.meta == []
    docstring_1 = parse('Test case:\n')
    assert docstring_1.short_description == 'Test case:'
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.blank_after_long_description is None
    assert docstring_1.meta == []
    docstring_2 = parse('Test case:\n\nTest case\n')
    assert docstring_2.short_

# Generated at 2022-06-25 16:38:07.701126
# Unit test for function parse
def test_parse():
    text_0 = ""
    docstring_0 = parse(text_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert len(docstring_0.meta) == 0

    text_1 = "Short description\n\nLong description."
    docstring_1 = parse(text_1)
    assert docstring_1.short_description == "Short description"
    assert docstring_1.long_description == "Long description."
    assert docstring_1.blank_after_short_description
    assert docstring_1.blank_after_long_description
    assert len(docstring_1.meta) == 0

    text_2 = "Short description\n\nLong description.\n\n:param a: a parameter."
    docstring_2 = parse

# Generated at 2022-06-25 16:38:20.844279
# Unit test for function parse
def test_parse():
    """Test function parse

    This is an automated test.

    To run this test manually, in this directory run:

        python test_parse.py

    """

# Generated at 2022-06-25 16:38:28.296789
# Unit test for function parse
def test_parse():
    str_0 = "Initialize self.\n\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Initialize self."
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == True
    assert docstring_0.long_description == None

# Generated at 2022-06-25 16:38:30.159834
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:38:32.893414
# Unit test for function parse
def test_parse():
    # Test 0 for function parse
    test_case_0()
# Main function that runs all tests for function parse

# Generated at 2022-06-25 16:38:43.189742
# Unit test for function parse
def test_parse():
    assert inspect.cleandoc("this is line 1\n\n    this is line 2") == "this is line 1\n\nthis is line 2"

    assert inspect.cleandoc("this is line 1\n\n\n\nthis is line 2") == "this is line 1\nthis is line 2"

    assert inspect.cleandoc("this is line 1\n\n    this is line 2\n    this is line 3") == "this is line 1\n\nthis is line 2\nthis is line 3"

    assert inspect.cleandoc("this is line 1 then\n    this is line 2") == "this is line 1 then\nthis is line 2"


# Generated at 2022-06-25 16:38:54.390440
# Unit test for function parse
def test_parse():
    # Testing the first example
    str_0 = "Initialize self.\n\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "

# Generated at 2022-06-25 16:38:56.661518
# Unit test for function parse
def test_parse():
    test_case_0()

# Main function, called when the module is run as a script

# Generated at 2022-06-25 16:38:58.756769
# Unit test for function parse
def test_parse():
    # Test Case #0
    test_case_0()

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:39:07.980292
# Unit test for function parse
def test_parse():
    from .common import DocstringMeta
    from .common import DocstringParam
    from .common import DocstringReturns
    from .common import DocstringRaises

    assert parse("") == Docstring()
    assert parse("Function that returns nothing.") == Docstring(
        short_description="Function that returns nothing.",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse("Raises a ``ValueError``.\n") == Docstring(
        short_description="Raises a ``ValueError``.",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-25 16:39:12.518925
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:39:27.447635
# Unit test for function parse
def test_parse():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 16:39:35.486902
# Unit test for function parse
def test_parse():
    str_1 = "Initialize self.\n\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Initialize self.'
    assert docstring_1.blank_after_short_description
    assert docstring_1.long_description == None
    assert len(docstring_1.meta) == 2
    assert docstring_1.meta[0].description == "list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items."


# Generated at 2022-06-25 16:39:40.562149
# Unit test for function parse
def test_parse():
    test_case_0()

# Program: DocstringParser.py

"""ReST-style docstring parsing."""

import inspect
import re
import typing as T

from .common import (
    PARAM_KEYWORDS,
    RAISES_KEYWORDS,
    RETURNS_KEYWORDS,
    YIELDS_KEYWORDS,
    Docstring,
    DocstringParam,
    DocstringRaises,
    DocstringReturns,
    ParseError,
)



# Generated at 2022-06-25 16:39:50.289122
# Unit test for function parse
def test_parse():
    str_1 = """Docstring with only a short description.
    """
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Docstring with only a short description.'
    assert not docstring_1.meta

    str_2 = """Docstring with short and long description.

Long description here.
    """
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == 'Docstring with short and long description.'
    assert docstring_2.long_description == 'Long description here.'


# Generated at 2022-06-25 16:39:58.394563
# Unit test for function parse
def test_parse():
    str_0 = "Initialize self.\n\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "
    docstring = parse(str_0)
    assert docstring.short_description == 'Initialize self.'
    assert docstring.blank_after_short_description == False
    assert docstring.long_description == ':param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it\'s used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.'
    assert docstring.blank_after_long_description == True
    assert len

# Generated at 2022-06-25 16:39:59.323899
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:40:10.215373
# Unit test for function parse
def test_parse():

    str_0 = ''
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == None

    docstring_0 = parse('foo')
    assert docstring_0.short_description == 'foo'

    docstring_0 = parse('foo\n')
    assert docstring_0.short_description == 'foo'

    docstring_0 = parse('foo\nbar')
    assert docstring_0.short_description == 'foo'
    assert docstring_0.long_description == 'bar'

    docstring_0 = parse('foo\n\nbar')
    assert docstring_0.short_description == 'foo'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.long_description == 'bar'
    assert docstring_

# Generated at 2022-06-25 16:40:20.972277
# Unit test for function parse
def test_parse():
    str_0 = "Initialize self.\n\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "
    docstring_0 = parse(str_0)
    assert (docstring_0.short_description == "Initialize self.")
    assert (docstring_0.long_description is None)
    i = 0
    for item in iter(docstring_0.meta):
        assert (item.args == ['param', 'args', 'list'])

# Generated at 2022-06-25 16:40:22.641787
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:40:31.798426
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Just a one-line comment.") == Docstring(
        short_description="Just a one-line comment."
    )
    assert parse("Just a one-line comment.\n") == Docstring(
        short_description="Just a one-line comment.",
        blank_after_short_description=True,
    )
    assert parse("Just a one-line comment.\n\n") == Docstring(
        short_description="Just a one-line comment.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

# Generated at 2022-06-25 16:40:55.887035
# Unit test for function parse
def test_parse():
    str_0 = "Initialize self.\n\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Initialize self."
    assert docstring_0.long_description == "        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "
    assert docstring_0.blank_after_short_description
    assert docstring_0.blank

# Generated at 2022-06-25 16:41:05.430231
# Unit test for function parse
def test_parse():
    str_0 = "Initialize self.\n\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Initialize self."
    assert docstring_0.long_description == ":param args: list of arguments. The exact content of this variable is\ndependent on the kind of docstring; it's used to distinguish between\ncustom docstring meta information items.\n:param description: associated docstring description.\n"
    assert len(docstring_0.meta) == 2

# Generated at 2022-06-25 16:41:14.821943
# Unit test for function parse
def test_parse():
    # Test the docstring of a function
    assert parse(inspect.getdoc(parse)) == parse(inspect.getdoc(parse))
    # Test the docstring of a class
    assert parse(inspect.getdoc(Docstring)) == parse(inspect.getdoc(Docstring))
    # Test the docstring of a module
    assert parse(inspect.getdoc(re)) == parse(inspect.getdoc(re))
    # Test the docstring for an empty docstring
    assert parse(None) == parse(None)
    # Test the docstring for a single line docstring
    assert parse("This is a single line docstring.") == parse("This is a single line docstring.")
    # Test the docstring for a multi line docstring

# Generated at 2022-06-25 16:41:25.965897
# Unit test for function parse
def test_parse():
    str_0 = "Initialize self.\n\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "

# Generated at 2022-06-25 16:41:29.508844
# Unit test for function parse
def test_parse():
    # In this test, TEST_DOCTRING is a docstring that looks like the one in
    #   test_module_0.py.
    TEST_DOCTRING = """Summary line.

This is a longer summary of the function/class. It is separated from the
summary line by a blank line.

Args:
    param1 (int): Description of param1.
    param2 (str, optional): Description of param2. Defaults to "foo".
    param3 (dict, optional): Description of param3. Defaults to {}.
    *args: Variable length argument list.
    **kwargs: Arbitrary keyword arguments.

Returns:
    int: Description of return value.

Raises:
    KeyError: Raises an exception.

Yields:
    str: Description of yielded value.

"""
    docstring

# Generated at 2022-06-25 16:41:39.869443
# Unit test for function parse
def test_parse():
    test_case_0()

    # Test cases:
    # str_0 = ''
    # str_1 = '\n\n'
    # str_2 = '''\n\n'''
    # str_3 = '\n\n\n'
    # str_4 = '''\n\n\n'''
    # str_5 = '\n\n\n\n'
    # str_6 = '''\n\n\n\n'''
    # str_7 = '\n\n\n\n\n'
    # str_8 = '''\n\n\n\n\n'''
    # str_9 = 'This function does nothing.\n\n    '
    # str_10 = '''This function does nothing.\n\n    '''
   

# Generated at 2022-06-25 16:41:49.782328
# Unit test for function parse

# Generated at 2022-06-25 16:41:55.002500
# Unit test for function parse
def test_parse():
    test_case_0()

# Compiles a list of all unit tests in this file
test_list = [ obj for name, obj in locals().items() if callable(obj) and name.startswith("test_") ]

# Prepends the module name on each test.
test_list = [".".join([__name__, test.__name__]) for test in test_list]

if __name__ == "__main__":
    print(" ".join(test_list))

# Generated at 2022-06-25 16:42:03.339686
# Unit test for function parse
def test_parse():
    docstring_0 = parse("")
    assert docstring_0 == Docstring()
    docstring_1 = parse("Initialize self.\n\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        ")
    assert docstring_1.short_description == "Initialize self."
    assert docstring_1.blank_after_short_description is False

# Generated at 2022-06-25 16:42:15.458078
# Unit test for function parse
def test_parse():
    str_0 = "Initialize self.\n\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "
    assert str_0 == str(parse(str_0))

# Generated at 2022-06-25 16:42:52.190466
# Unit test for function parse
def test_parse():
    global str_0, docstring_0
    str_0 = "Initialize self.\n\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "
    docstring_0 = parse(str_0)
    assert len(docstring_0.meta) == 2

test_case_0()
test_parse()

# Generated at 2022-06-25 16:42:55.858507
# Unit test for function parse
def test_parse():
    '''Test parse(text: str)'''
    # Input parameters and expected results
    test_cases = [
        [1, 2],
        [2, 3],
    ]
    # Perform test
    for test_case in test_cases:
        assert test_case[1] == parse(test_case[0])

# Generated at 2022-06-25 16:42:57.555242
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:43:00.527227
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:43:08.583673
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    #
    # docstring = parse("I am a short description.")
    # assert docstring.short_description == "I am a short description."
    # assert docstring.long_description is None
    # assert docstring.blank_after_short_description is False
    # assert docstring.blank_after_long_description is True
    # assert len(docstring.meta) == 0

    docstring = parse(
        """I am a short description.

        And I am a long description.

        :param foo: bar
        """
    )
    assert docstring.short_description == "I am a short description."
    assert docstring.long_description == "And I am a long description."
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_

# Generated at 2022-06-25 16:43:15.468921
# Unit test for function parse
def test_parse():

    str_0 = """\
        Initialize self.\n\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        """


# Generated at 2022-06-25 16:43:25.178160
# Unit test for function parse
def test_parse():
    str_0 = "Initialize self.\n\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "
    docstring_0 = parse(str_0)

    assert docstring_0 is not None
    assert docstring_0.short_description == "Initialize self."
    assert docstring_0.long_description == ":param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "
    assert docstring_0.blank_after_short_description