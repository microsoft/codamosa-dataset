

# Generated at 2022-06-25 16:33:49.287605
# Unit test for function parse
def test_parse():
    str_0 = """
        x = y
        :param x: the x component
        """
    str_1 = 'LkfI#Kg,FGV'
    str_2 = '        x = y\n        :param x: the x component'
    docstring_0 = parse(str_0)
    docstring_1 = parse(str_1)
    docstring_2 = parse(str_2)
    print(docstring_0)
    print(docstring_1)
    print(docstring_2)
    assert type(docstring_0) == Docstring
    assert type(docstring_1) == Docstring
    assert type(docstring_2) == Docstring


# Generated at 2022-06-25 16:33:58.115680
# Unit test for function parse
def test_parse():
    str_0 = 'LkfI#Kg,FGV'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'LkfI#Kg,FGV'
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 0

    str_1 = ' LkfI#Kg,FGV'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'LkfI#Kg,FGV'
    assert docstring_1.long_description == None

# Generated at 2022-06-25 16:34:10.502916
# Unit test for function parse
def test_parse():
    with pytest.raises(ParseError) as excinfo:
        str_0 = 'LkfI#Kg,FGV'
        docstring_0 = parse(str_0)
    with pytest.raises(ParseError) as excinfo:
        str_0 = 'LkfI#Kg,F:GV'
        docstring_0 = parse(str_0)
    with pytest.raises(ParseError) as excinfo:
        str_0 = 'LkfI#Kg,F:\n    GV'
        docstring_0 = parse(str_0)
    with pytest.raises(ParseError) as excinfo:
        str_0 = 'LkfI#Kg,F:G\n    V'

# Generated at 2022-06-25 16:34:20.688427
# Unit test for function parse
def test_parse():
    def test_wrapper(str_0):
        try:
            docstring_0 = parse(str_0)
            del docstring_0
        except:
            pass
        else:
            assert False
    # test case 0
    str_0 = 'LkfI#Kg,FGV'
    test_wrapper(str_0)
    # test case 1

# Generated at 2022-06-25 16:34:22.225280
# Unit test for function parse
def test_parse():
    test_case_0()
    return



# Generated at 2022-06-25 16:34:29.790145
# Unit test for function parse
def test_parse():
    f = open('utils/docstring.txt', 'r')
    str_0 = f.read()
    f.close()
    docstring_0 = parse(str_0)
    assert isinstance(docstring_0, Docstring) == True
    assert docstring_0.short_description == 'Load a .ONNX model.'
    assert docstring_0.blank_after_long_description == True
    assert docstring_0.blank_after_short_description == True

# Generated at 2022-06-25 16:34:40.482760
# Unit test for function parse
def test_parse():
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'LkfI#Kg'
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.long_description == 'FGV'
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 0

    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'LkfI#Kg'
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.long_description == 'FGV'
    assert docstring_1.blank_after_long_description == True
    assert len(docstring_1.meta) == 0

    docstring

# Generated at 2022-06-25 16:34:50.434548
# Unit test for function parse
def test_parse():
    str_0 = "One line short description."
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "One line short description."
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 0
    str_1 = "One line short description.\n\nLong description."
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "One line short description."
    assert docstring_1.long_description == "Long description."
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank_after_long

# Generated at 2022-06-25 16:35:01.390752
# Unit test for function parse
def test_parse():
    str_0 = 'LkfI#Kg,FGV'
    docstring_0 = parse(str_0)
    print(docstring_0)
    str_1 = 'L  fI#Kg,FGV'
    docstring_1 = parse(str_1)
    print(docstring_1)
    str_2 = 'Li fI#Kg,FGV'
    docstring_2 = parse(str_2)
    print(docstring_2)
    str_3 = 'LikfI#Kg,FGV'
    docstring_3 = parse(str_3)
    print(docstring_3)
    str_4 = 'LikfI#Kg, FGV'
    docstring_4 = parse(str_4)
    print(docstring_4)


# Generated at 2022-06-25 16:35:04.764909
# Unit test for function parse
def test_parse():
    str_0 = '"""If true, return information about the newly created user."""'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'If true, return information about the newly created user.'

# Testing the function that calls parse

# Generated at 2022-06-25 16:35:22.163290
# Unit test for function parse
def test_parse():
    assert len(parse('')) == 0
    assert len(parse('string')) == 1
    assert len(parse('string string')) == 1

# Generated at 2022-06-25 16:35:23.642498
# Unit test for function parse
def test_parse():
    print(parse(test_case_0.__doc__))

# Usage of parse
parse(test_case_0.__doc__)

# Generated at 2022-06-25 16:35:26.049604
# Unit test for function parse
def test_parse():
    str_0 = """LkfI#Kg,FGV"""
    ret = parse(str_0)

# def main():
#     test_parse()

# main()

# Generated at 2022-06-25 16:35:33.607852
# Unit test for function parse
def test_parse():
    # Test simple case
    str_0 = "    Parse the ReST-style docstring into its components.\n"
    str_1 = "    :returns: parsed docstring"
    str_0 += str_1
    doc = parse(str_0)
    assert doc is not None
    assert doc.long_description == 'Parse the ReST-style docstring into its components.'
    assert doc.short_description == 'Parse the ReST-style docstring into its components.'
    assert doc.meta[0].key == 'returns'
    assert doc.meta[0].value == 'parsed docstring'
    assert doc.meta[0].description == 'parsed docstring'
    assert doc.meta[0].type_name is None
    assert doc.meta[0].arg_name is None

    #

# Generated at 2022-06-25 16:35:42.693777
# Unit test for function parse
def test_parse():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-25 16:35:48.827402
# Unit test for function parse
def test_parse():
    str_0 = 'LkfI#Kg,FGV'
    str_1 = 'dDpWJNbT3q'
    str_2 = 'o0xAwB0Q2I'
    str_3 = 'U6G3bq3pBc'
    str_4 = 'C0nQ2XROn6'
    str_5 = 'aA1GkI0nQ2'
    str_6 = 'r6XROn6aA1'
    str_7 = '4b'
    str_8 = '4b'
    str_9 = 'EOtQ2Q2XR'

# Generated at 2022-06-25 16:35:51.782684
# Unit test for function parse
def test_parse():
    str_0 = 'LkfI#Kg,FGV'
    assert parse(str_0) == ()


# Generated at 2022-06-25 16:35:56.405481
# Unit test for function parse
def test_parse():
    print('Testing function parse in module parse_docstring')
    ds = parse('Test docstring\n:param a: Test parameter')
    assert len(ds.meta) == 1
    assert ds.meta[0].key == 'param'
    assert ds.meta[0].type_name is None


# Generated at 2022-06-25 16:36:00.523448
# Unit test for function parse
def test_parse():
    assert 0 == 0


# Generated at 2022-06-25 16:36:06.655809
# Unit test for function parse
def test_parse():
    str = """This is some sample code.
    :param int a: The first parameter
    :param b: The second parameter
    :returns: Always None.
    :raises: RuntimeError on error.
    """
    assert parse(str).short_description == 'This is some sample code.'
    assert parse(str).long_description == None
    assert parse(str).blank_after_short_description == 1
    assert parse(str).blank_after_long_description == 1
    assert parse(str).meta[0].args[0] == 'param'
    assert parse(str).meta[0].args[1] == 'int'
    assert parse(str).meta[0].args[2] == 'a'
    assert parse(str).meta[0].description == 'The first parameter'

# Generated at 2022-06-25 16:36:18.230735
# Unit test for function parse

# Generated at 2022-06-25 16:36:19.748759
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:36:22.283151
# Unit test for function parse
def test_parse():
    # Forcefully test for the type of each returned value.
    assert isinstance(parse(''), Docstring)
    # Forcefully test for the type of each attribute.
    assert isinsta

# Generated at 2022-06-25 16:36:31.523596
# Unit test for function parse
def test_parse():
    import pytest
    import sys
    import os
    import random
    import inspect
    import traceback
    import io

    # Prepare argument
    str_0 = 'Wrapper class that stores lists of ``(name, value)`` tuples.\n\n        :param name: The form name.\n        :param form_data: An ordered sequence of name, value pairs.\n        :param encoding: The encoding to use for parameter values.\n        :param errors: The error handling policy, see the ``errors`` argument\n                       to ``str.encode``.\n        '

    # Invoke method
    result = parse(str_0)

    # Check for exception
    if None:
        e = None

# Generated at 2022-06-25 16:36:34.923917
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:36:38.369714
# Unit test for function parse
def test_parse():
    test_case_0()

# Develop test for function parse

# Generated at 2022-06-25 16:36:47.718245
# Unit test for function parse
def test_parse():
    str_first_line = "Dunder method that returns value."
    str_long_desc = "First line of the long description.\n\nSecond line."
    str_meta = ":param text: section body text. Should be cleaned with"
    str_test = str_first_line + "\n" + str_long_desc
    test_str = str_test + "\n" + str_meta
    actual_result = parse(test_str)
    expected_result = DocstringMeta(["text"], "section body text. Should be cleaned with")
    assert actual_result.short_description == str_first_line
    assert actual_result.long_description == str_long_desc
    assert expected_result == actual_result.meta[0]
    
    # Test case when double backslashes are used in the string
    test_

# Generated at 2022-06-25 16:36:49.000848
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:36:50.145225
# Unit test for function parse
def test_parse():
    test_case_0()


# Generated at 2022-06-25 16:36:59.732927
# Unit test for function parse
def test_parse():
    # Test empty strings
    assert parse('') == Docstring()

    # Test short descriptions
    assert parse('short desc').short_description == 'short desc'
    assert parse('short desc\n\n').short_description == 'short desc'
    assert parse('short desc\n\n\n').short_description == 'short desc'

    # Test long descriptions
    assert parse('short desc').long_description == None
    assert parse('short desc\n\nlong\ndesc').long_description == 'long\ndesc'
    assert parse('short desc\n\nlong\ndesc\n\n').long_description == 'long\ndesc'
    assert parse('short desc\n\nlong\ndesc\n\n\n').long_description == 'long\ndesc'

    # Test blanks

# Generated at 2022-06-25 16:37:05.255687
# Unit test for function parse
def test_parse():

    assert True  # TODO: implement your test here



# Generated at 2022-06-25 16:37:09.255430
# Unit test for function parse
def test_parse():
    # Arguments
    text_0 = "Placeholder for the test case"
    # Return type
    expected_output = None
    # Actual
    actual = parse(text_0)

    # Assertion
    assert actual == expected_output


# Generated at 2022-06-25 16:37:18.408139
# Unit test for function parse
def test_parse():
    str_0 = """Parse a ReStructuredText-style docstring into its components.

:param text: the docstring to parse
:returns: parsed docstring

"""
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Parse a ReStructuredText-style docstring into its components."
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True
    assert len(docstring_0.meta) == 2
    assert docstring_0.meta[0].args == ['param', 'text:', 'the docstring to parse']

# Generated at 2022-06-25 16:37:20.963579
# Unit test for function parse
def test_parse():
    assert 1==1

# Generated at 2022-06-25 16:37:31.738538
# Unit test for function parse
def test_parse():
    # Test cases
    str_0 = """Return the input string unchanged.
    
            :param text: The string to return.
            :type text: str
            :rtype: str
            :returns: ``text``
            :raises RuntimeError: if called with no arguments.
            :raises ValueError:
            """
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Return the input string unchanged.'
    assert docstring_0.long_description == """Parse ``DocstringMeta`` objects from the body of this section.\n\n        :param text: section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.\n        """
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank

# Generated at 2022-06-25 16:37:34.037773
# Unit test for function parse
def test_parse():
    # Do all the setup first.
    test_case_0()


if __name__ == "__main__":
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:37:41.656332
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('\n') == Docstring()
    assert parse('\n\n') == Docstring()

    assert str(parse('hello')) == '"hello"'
    assert str(parse('hello\nworld')) == '"hello\\nworld"'
    assert str(parse('hello\n\nworld?')) == '"hello\\n\\nworld?"'
    assert str(parse('hello\n:foo: bar\n\nworld?')) == (
        'Docstring(\n'
        '    short_description="hello",\n'
        '    long_description="world?",\n'
        '    meta=[DocstringMeta(args=["foo"], description="bar")])'
    )

# Generated at 2022-06-25 16:37:51.978268
# Unit test for function parse
def test_parse():
    # Simplest case: no docstring at all
    str_0 = ''
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_long_description == False
    print(docstring_0.meta)
    assert docstring_0.meta == []

    # Only short description
    str_1 = 'An alpha.'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'An alpha.'
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.long_description == None
    assert docstring_1.blank_after

# Generated at 2022-06-25 16:37:54.139408
# Unit test for function parse
def test_parse():
    test_case_0()
    assert True


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:38:07.115779
# Unit test for function parse
def test_parse():
    str_0 = 'Parse ``DocstringMeta`` objects from the body of this section.\n\n        :param text: section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.\n        '
    docstring_0 = parse(str_0)

    str_1 = 'Parse ``DocstringMeta`` objects from the body of this section.\n\n        :param text: section body text. Should be cleaned with ``inspect.cleandoc`` before parsing.\n        '
    docstring_1 = parse(str_1)

    str_2 = 'Parse ``DocstringMeta`` objects from the body of this section.\n\n        :param text: section body text. Should be cleaned with ``inspect.cleandoc`` before parsing.\n\n        '

# Generated at 2022-06-25 16:38:19.417970
# Unit test for function parse
def test_parse():
    t0 = 'Parse ``DocstringMeta`` objects from the body of this section.\n\n        :param text: section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.\n        '
    d0 = parse(t0)
    assert d0.short_description == 'Parse ``DocstringMeta`` objects from the body of this section.'
    assert len(d0.meta) == 1
    assert d0.meta[0].description == 'section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.'
    assert d0.meta[0].arg_name == 'text'


# Generated at 2022-06-25 16:38:29.303554
# Unit test for function parse
def test_parse():
    str_0 = 'Parse ``DocstringMeta`` objects from the body of this section.\n\n        :param text: section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.\n        '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Parse ``DocstringMeta`` objects from the body of this section.'
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description is None
    assert docstring_0.meta[0].args == ['param', 'text']
    assert docstring_0.meta[0].description == 'section body text. Should be cleaned with ``inspect.cleandoc`` before parsing.'


# Generated at 2022-06-25 16:38:41.368262
# Unit test for function parse
def test_parse():
    func_0_str_0 = """
        Write a message to the console.

        :param text: message text.
        :type text: str
        :returns: str -- Text message.
        :raises TypeError: If text is not a string.
        """
    func_0_docstring_0 = parse(func_0_str_0)
    assert func_0_docstring_0.short_description == "Write a message to the console."
    assert func_0_docstring_0.blank_after_short_description == True
    assert func_0_docstring_0.blank_after_long_description == False

# Generated at 2022-06-25 16:38:46.537137
# Unit test for function parse
def test_parse():
    assert callable(parse)
    actual = parse("")
    assert isinstance(actual, Docstring), "parse() should return an instance of class Docstring"
    expected = Docstring()
    assert actual == expected, "parse() returned an unexpected result"

    docstring_0 = parse("Parse ``DocstringMeta`` objects from the body of this section.\n\n        :param text: section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.\n        ")
    assert isinstance(docstring_0, Docstring), "parse() should return an instance of class Docstring"

# Generated at 2022-06-25 16:38:55.940027
# Unit test for function parse
def test_parse():
    str_0 = 'Parse ``DocstringMeta`` objects from the body of this section.\n\n        :param text: section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.\n        '
    docstring_0 = parse(str_0)
    assert len(docstring_0.meta) == 1
    assert str(docstring_0) == str_0
    assert docstring_0.meta[
        0
    ].description == "section body text. Should be cleaned with ``inspect.cleandoc`` before parsing."

# Generated at 2022-06-25 16:38:56.582024
# Unit test for function parse
def test_parse():
    assert False == False

# Generated at 2022-06-25 16:38:59.080578
# Unit test for function parse
def test_parse():
    try:
        test_case_0()
    except Exception:
        print('Error in test case 0')

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:39:08.169666
# Unit test for function parse
def test_parse():
    assert parse("Test function.") == Docstring(
        short_description="Test function.",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

    doc = parse("Test function.\n\n")
    assert doc == Docstring(
        short_description="Test function.",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    doc = parse("Test function.\n\nLong description.")

# Generated at 2022-06-25 16:39:14.966281
# Unit test for function parse
def test_parse():
    print("Testing parse()")
    print("=" * 40)
    test_case_0()
    print("=" * 40)

# unit test or doctest
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:39:25.540447
# Unit test for function parse
def test_parse():
    docstring_0 = parse('')
    docstring_1 = parse('This parameter does not have a type information.')
    docstring_2 = parse(
        'This parameter does not have a type information.\n\n        :param arg_name: argument name\n        :param arg_name2: argument name 2\n        '
    )
    docstring_3 = parse(
        'This parameter does not have a type information.\n\n        :param arg_name: argument name\n        :param arg_name2: argument name 2\n        \n        :type arg_name: int\n        :type arg_name2: str\n        '
    )

# Generated at 2022-06-25 16:39:37.108503
# Unit test for function parse
def test_parse():
    # Test fail cases
    docstring_0 = parse("")
    docstring_0 = parse("Takes two arguments.\n\n    :returns: some text.")
    docstring_0 = parse("Takes two arguments.\n\n    :returns some text.")
    docstring_0 = parse("Takes two arguments.\n\n    :returns: .")
    docstring_0 = parse("Takes two arguments.\n\n    :returns: int")
    docstring_0 = parse("Takes two arguments.\n\n    :returns: int str")
    docstring_0 = parse("Takes two arguments.\n\n    :returns: -100")
    docstring_0 = parse("Takes two arguments.\n\n    :returns: 1.234")
    docstring

# Generated at 2022-06-25 16:39:39.618281
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:39:49.366659
# Unit test for function parse
def test_parse():
    """Test function parse()
    """
    # Tests for short description, long description and blank lines after short and long descriptions
    # (Case 0)
    test_case_0()

    # Tests for short description, long description and blank lines after short and long descriptions
    # (Case 1)
    str_1 = 'Parse ``DocstringMeta`` objects from the body of this section.\n\n        :param text: section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.\n        :type text: str\n        '
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Parse ``DocstringMeta`` objects from the body of this section.'
    assert len(docstring_1.meta) == 1

# Generated at 2022-06-25 16:39:50.209045
# Unit test for function parse
def test_parse():
    # case0
    test_case_0()

# Generated at 2022-06-25 16:39:53.986055
# Unit test for function parse
def test_parse():

    # Initialize arguments with dummy values
    text = 'Parse ``DocstringMeta`` objects from the body of this section.\n\n        :param text: section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.\n        '

    parse(text)


# Generated at 2022-06-25 16:40:03.967600
# Unit test for function parse
def test_parse():
    docstring_0 = parse("")
    docstring_1 = parse("Single line docstring")
    docstring_2 = parse("""
            Multi line docstring


            This is the second paragraph.
        """)
    docstring_3 = parse("""
            Multi line docstring

            This is the second paragraph.
        """)
    docstring_4 = parse("""
            Multi line docstring
            \n

            This is the second paragraph.
        """)
    docstring_5 = parse("""
            Multi line docstring

            :param text: section body text. Should be cleaned with
                         ``inspect.cleandoc`` before parsing.
        """)

# Generated at 2022-06-25 16:40:15.670924
# Unit test for function parse
def test_parse():
    print('Unit test for parse')
    ###

    # Test 0:
    str_0 = 'Parse ``DocstringMeta`` objects from the body of this section.\n\n        :param text: section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.\n        '
    docstring_0 = parse(str_0)
    test_case_0()
    ###

    # Test 1:
    str_1 = 'A test function.\n:param x: an integer\n:returns: an integer\n:rtype: int\n\n'
    docstring_1 = parse(str_1)
    ###

    # Test 2:

# Generated at 2022-06-25 16:40:17.323976
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:40:25.124182
# Unit test for function parse
def test_parse():
    import sys
    import os
    import json
    import pycodestyle
    import coverage

    x = """
    The module's function.
    :param arg1: The first argument.
    :param arg2: The second argument.
    :param arg3: The third argument.
    :param arg4: The fourth argument.
    :param arg5: The fifth argument.
    :param arg6: The sixth argument.
    :param arg7: The seventh argument.
    :param arg8: The eighth argument.
    :param arg9: The ninth argument.
    :param arg10: The tenth argument.
    :returns: Description of return value.
    """
    cov = coverage.coverage()
    cov.start()
    this_file = os.path.abspath(__file__)

# Generated at 2022-06-25 16:40:31.399936
# Unit test for function parse
def test_parse():
    text = 'Parse ``DocstringMeta`` objects from the body of this section.\n\n        :param text: section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.\n        '
    expected_return_value = {'long_description': 'Parse ``DocstringMeta`` objects from the body of this section.', 'short_description': 'Parse ``DocstringMeta`` objects from the body of this section.', 'meta': [DocstringMeta(args=['param', 'text'], description='section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.')]}
    assert_equal(parse(text),expected_return_value)

# Test code for function parse that raises an exception

# Generated at 2022-06-25 16:40:45.258464
# Unit test for function parse
def test_parse():
    assert docstring_0.short_description == 'Parse ``DocstringMeta`` objects from the body of this section.'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True
    assert docstring_0.long_description == None
    assert docstring_0.meta[0].arg_name == 'text'
    assert docstring_0.meta[0].type_name == None
    assert docstring_0.meta[0].is_optional == None
    assert docstring_0.meta[0].default == None
    assert docstring_0.meta[0].description == 'section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.'

# Test without blank line between description and meta-section

# Generated at 2022-06-25 16:40:55.751188
# Unit test for function parse
def test_parse():
    str_1 = (
        "Parse the ReST-style docstring into its components.\n\n:returns: parsed docstring\n"
    )
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "Parse the ReST-style docstring into its components."
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank_after_long_description == False
    assert len(docstring_1.meta) == 1
    assert docstring_1.meta[0].args == [':returns:']
    assert docstring_1.meta[0].description == 'parsed docstring'
    

# Generated at 2022-06-25 16:40:56.877352
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:40:57.982259
# Unit test for function parse
def test_parse():
    assert 1 == 1

# Generated at 2022-06-25 16:41:06.273962
# Unit test for function parse
def test_parse():
    # Test case 0
    str_0 = 'Parse ``DocstringMeta`` objects from the body of this section.\n\n        :param text: section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.\n        '

    expected__0 = DocstringMeta(args=["param", "text"], description="section body text. Should be cleaned with ``inspect.cleandoc`` before parsing.")
    expected__0 = [expected__0]
    expected__1 = "Parse ``DocstringMeta`` objects from the body of this section.\n\n"
    expected__2 = False
    expected__3 = False
    expected = Docstring(expected__0, expected__1, expected__2, expected__3)
    actual = parse(str_0)

    assert actual == expected

    # Test case 1


# Generated at 2022-06-25 16:41:08.120329
# Unit test for function parse
def test_parse():
    assert True == True

# Generated at 2022-06-25 16:41:15.396835
# Unit test for function parse
def test_parse():
    # Function used in parse.py to parse docstring
    def test_func():
        pass
    # testing function parse
    assert(len(parse.__doc__) > 0)
    # testing with function
    assert(parse(test_func.__doc__).short_description == 'test_func()')
    docstring = Docstring(short_description = "test_func()",
                          long_description = 'Unit test for function parse\n        \n        testing function parse\n        testing with function\n        \n        ',
                          blank_after_short_description = False,
                          blank_after_long_description = True,
                          meta = [])
    # testing with string

# Generated at 2022-06-25 16:41:26.397248
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    docstring_0 = parse("Parse ``DocstringMeta`` objects from the body of this section.\n\n            :param text: section body text. Should be cleaned with\n                         ``inspect.cleandoc`` before parsing.\n            ")
    assert docstring_0.short_description == 'Parse ``DocstringMeta`` objects from the body of this section.'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.long_description == ':param text: section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.'
    assert docstring_0.blank_after_long_description == True

# Generated at 2022-06-25 16:41:36.414786
# Unit test for function parse
def test_parse():
    # for the rest of the following tests, the doctest
    # is the long description.
    text = "Parse the ReST-style docstring into its components.\n\n        :returns: parsed docstring\n        "
    ret = parse(text)
    assert ret.short_description == "Parse the ReST-style docstring into its components."
    assert ret.blank_after_short_description is True
    assert ret.long_description == "returns: parsed docstring"
    assert ret.blank_after_long_description is True
    assert len(ret.meta) == 1
    assert ret.meta[0].args == ["returns", "parsed docstring"]
    assert ret.meta[0].description is None



# Generated at 2022-06-25 16:41:46.874966
# Unit test for function parse
def test_parse():
    text = 'short description with a\n\n  continuation line and a\n\n      blockquote\n\nlong description\n\n:param arg1: first arg\n:param arg2: second arg\n:type arg2: :class:`type` or :class:`list`\n:raises: :exc:`RuntimeError`\n:returns: return value\n:rtype: :class:`int`\n:yields: whatever\n'
    assert parse(text).meta[0].arg_name == "arg1"
    assert parse(text).meta[1].arg_name == "arg2"
    assert parse(text).meta[2].type_name == ":class:`type` or :class:`list`"

# Generated at 2022-06-25 16:41:56.280662
# Unit test for function parse
def test_parse():
    # Test cases
    test_case_0()

test_parse()



# Generated at 2022-06-25 16:41:59.188964
# Unit test for function parse
def test_parse():
    print("Test parse()")
    test_case_0()
    print("end")

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:42:02.853086
# Unit test for function parse
def test_parse():
    print('Testing function "parse"')
    test_case_0()
    print('Function "parse" tests passed')


test_parse()

# Generated at 2022-06-25 16:42:14.393037
# Unit test for function parse
def test_parse():

    docstring_0 = parse("This is a short description.")
    assert docstring_0.short_description == "This is a short description."
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.meta == []

    docstring_1 = parse("This is a short description.\n\nThis is a long description.")
    assert docstring_1.short_description == "This is a short description."
    assert docstring_1.long_description == "This is a long description."
    assert docstring_1.blank_after_short_description is False
    assert docstring_1.blank_after_long_description is False
    assert docstring_1.meta == []

# Generated at 2022-06-25 16:42:26.041904
# Unit test for function parse
def test_parse():
    # Test case 0
    text = 'Parse ``DocstringMeta`` objects from the body of this section.\n\n        :param text: section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.\n        '
    docstring_0 = parse(text)
    assert docstring_0.short_description == 'Parse ``DocstringMeta`` objects from the body of this section.'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.long_description == ' param text: section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.'
    assert docstring_0.blank_after_long_description == False
    # TODO: Fix assert statements to test for specific types
    assert docstring_0.meta
    # TODO

# Generated at 2022-06-25 16:42:26.841849
# Unit test for function parse
def test_parse():
    assert()

# Generated at 2022-06-25 16:42:30.273447
# Unit test for function parse
def test_parse():
    from .reflection import test_case_0
    # No exception thrown
    try:
        test_case_0()
    except:
        assert False, "Unexpected exception thrown"
    else:
        assert True, "No exception thrown"

# Generated at 2022-06-25 16:42:39.760527
# Unit test for function parse
def test_parse():
    str_0 = ""
    docstring_0 = parse(str_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert len(docstring_0.meta) == 0

    str_1 = "test_case_0()"
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "test_case_0()"
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is False
    assert docstring_1.blank_after_long_description is False
    assert len(docstring_1.meta)

# Generated at 2022-06-25 16:42:47.239786
# Unit test for function parse
def test_parse():
    # arg3 (text): Parse ``DocstringMeta`` objects from the body of this section.
    str1 = 'Parse ``DocstringMeta`` objects from the body of this section.\n\n        :param text: section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.\n        '
    docstring1 = parse(str1)

    print(docstring1.short_description)

    # arg3 (text): Parse ``DocstringMeta`` objects from the body of this section.
    str2 = 'Parse ``DocstringMeta`` objects from the body of this section.\n\n        :param: section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.\n        '
    docstring2 = parse(str2)
    

# Generated at 2022-06-25 16:42:57.167605
# Unit test for function parse
def test_parse():
    known_values_0 = (
    'Hello, world!',
    Docstring(
        short_description='Hello, world!',
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description=None,
        ),
    )
    known_values_1 = (
    'Hello, world!\n\n    This is a docstring for a test.\n    ',
    Docstring(
        short_description='Hello, world!',
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description='This is a docstring for a test.',
        ),
    )

# Generated at 2022-06-25 16:43:08.290619
# Unit test for function parse
def test_parse():
    print("Testing function parse")
    print("\tTest case #0...", end="")
    test_case_0()
    print("passed!")
    print("\ttests passed!")

# Generated at 2022-06-25 16:43:15.312527
# Unit test for function parse
def test_parse():
    str_0 = 'Parse ``DocstringMeta`` objects from the body of this section.\n\n        :param text: section body text. Should be cleaned with\n                     ``inspect.cleandoc`` before parsing.\n        '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Parse ``DocstringMeta`` objects from the body of this section."
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_long_description == None
    assert docstring_0.meta[0].args == ['param', 'text']
    assert docstring_0.meta[0].arg_name == 'text'

# Generated at 2022-06-25 16:43:25.142061
# Unit test for function parse
def test_parse():
    str_0 = "."
    docstring_0 = parse(str_0)
    str_1 = "."
    docstring_1 = parse(str_1)
    assert docstring_0 == docstring_1
    str_2 = "."
    docstring_2 = parse(str_2)
    assert docstring_0 == docstring_2
    str_3 = "."
    docstring_3 = parse(str_3)
    assert docstring_0 == docstring_3
    str_4 = "."
    docstring_4 = parse(str_4)
    assert docstring_0 == docstring_4
    str_5 = "."
    docstring_5 = parse(str_5)
    assert docstring_0 == docstring_5
    str_6 = "."
    docstring_6