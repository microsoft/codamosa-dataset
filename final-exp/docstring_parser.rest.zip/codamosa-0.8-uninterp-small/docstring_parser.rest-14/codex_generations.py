

# Generated at 2022-06-25 16:33:52.828508
# Unit test for function parse
def test_parse():
    str_1 = 'Docstring example\n:param int a: A value.\n:rtype: int\n:raises ValueError: If a is not valid.\n:return: sqrt(a)\n'
    str_2 = 'Docstring example\n:param array a: A value.\n:return: sqrt(a)\n:rtype: float\n:raises TypeError: If a is not a float.\n'
    str_3 = 'Docstring example\n:param array a: A value.\n:returns: sqrt(a)\n:rtype: float\n:raises TypeError: If a is not a float.\n'

# Generated at 2022-06-25 16:34:05.343136
# Unit test for function parse
def test_parse():
    # 3 inputs
    str_0 = ''
    expected_0 = Docstring()
    computed_0 = parse(str_0)
    assert computed_0 == expected_0

    str_1 = 'PF test function.'
    expected_1 = Docstring(short_description='PF test function.')
    computed_1 = parse(str_1)
    assert computed_1 == expected_1

    str_2 = 'Test function\n:param obj: test object\n:returns: test_returns'

# Generated at 2022-06-25 16:34:15.947062
# Unit test for function parse
def test_parse():
    docstring_0 = parse("This is a short description.\n"
                        "\n"
                        "And this is a thorough long description.\n"
                        "It may span multiple lines, but it will be\n"
                        "trimmed and then folded.\n"
                        "\n"
                        "This is a docstring that has a parameter with a\n"
                        "default value:\n"
                        "\n"
                        ":param x: The x parameter defaults to 123.\n"
                        ":raises Exception: If something goes wrong.\n"
                        ":returns: Nothing.\n"
                        ":rtype: None\n"
                        "")
    assert docstring_0.short_description == "This is a short description."

# Generated at 2022-06-25 16:34:20.934418
# Unit test for function parse
def test_parse():
    assert parse('').short_description is None
    assert parse('').meta == []
    assert parse('').long_description is None
    assert parse('').blank_after_short_description == False
    assert parse('').blank_after_long_description == True
    docstring_0 = parse('a\nb')
    str_1 = 'a\nb'
    assert docstring_0.short_description == str_1
    assert docstring_0.meta == []
    str_2 = 'b'
    assert docstring_0.long_description == str_2
    str_3 = 'b'
    assert parse(str_3).short_description == str_3
    str_4 = 'a\nb'
    assert parse(str_4).long_description is None

# Generated at 2022-06-25 16:34:29.482372
# Unit test for function parse
def test_parse():
    docstring_0 = parse("\n    a\n    b\n    c\n")
    assert docstring_0.short_description == "a"
    assert docstring_0.long_description == "b\n\nc"
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True
    assert not docstring_0.meta

    docstring_1 = parse("Test.\n\n:param int test:\n    Description.\n    More description.\n")
    docstring_meta_0 = docstring_1.meta[0]
    assert docstring_meta_0.args == ["param", "int", "test"]
    assert docstring_meta_0.description == "Description.\n    More description.\n"
   

# Generated at 2022-06-25 16:34:40.332753
# Unit test for function parse
def test_parse():
    str_0 = "Format a text using printf-style % escapes.\n"
    str_1 = "The % escapes available are:\n"
    str_2 = "%s -- string (coerces any Python object using str()).\n"
    str_3 = "%r -- string (coerces any Python object using repr()).\n"
    str_4 = "%c -- character (coerces with ord()).\n"
    str_5 = "%d -- decimal integer.\n"
    str_6 = "%i -- integer.\n"
    str_7 = "%u -- unsigned integer.\n"
    str_8 = "%o -- octal integer.\n"
    str_9 = "%x -- hexadecimal integer (lowercase letters).\n"

# Generated at 2022-06-25 16:34:45.554411
# Unit test for function parse
def test_parse():
    from darglint.analysis import parse

    # Test empty string
    test_str = ""
    result = parse(test_str)

    assert result.short_description is None
    assert result.blank_after_short_description is False
    assert result.long_description is None
    assert result.blank_after_long_description is False
    assert len(result.meta) == 0

    # Test no docstring:
    test_str = "def foo():\n  pass\n"
    result = parse(test_str)

    assert result.short_description is None
    assert result.blank_after_short_description is False
    assert result.long_description is None
    assert result.blank_after_long_description is False
    assert len(result.meta) == 0

    # Test basic parsing:

# Generated at 2022-06-25 16:34:49.554558
# Unit test for function parse
def test_parse():
    assert parse('q31!n+d!`Gt\t"')


# Generated at 2022-06-25 16:35:01.298071
# Unit test for function parse
def test_parse():
    # Test cases
    doc_string = '''
        A test docstring

        :param x: foo
        :type x: bar
        :returns: baz
        '''
    docstring = parse(doc_string)
    assert docstring.short_description == "A test docstring"
    assert len(docstring.meta) == 2
    assert docstring.meta[0].arg_name == "x"
    assert docstring.meta[1].is_generator is False

    doc_string = '''
        A test docstring

        :param x: foo
        :type x: bar
        :return: baz
        '''
    docstring = parse(doc_string)
    assert docstring.short_description == "A test docstring"
    assert len(docstring.meta) == 2
    assert docstring

# Generated at 2022-06-25 16:35:03.604258
# Unit test for function parse
def test_parse():
    docstring_0 = parse("\n")
    docstring_1 = parse("\n")

    assert docstring_0 == docstring_1


# Test parsing short description.

# Generated at 2022-06-25 16:35:14.214119
# Unit test for function parse
def test_parse():
    import sys
    import io

    # Redirect stdout to suppress the output
    saved_stdout = sys.stdout
    try:
        out = io.StringIO()
        sys.stdout = out

        test_case_0()

        sys.stdout = saved_stdout

    finally:
        sys.stdout = saved_stdout

# Generated at 2022-06-25 16:35:15.273180
# Unit test for function parse
def test_parse():
    # Test Cases
    test_case_0()


# Main function for testing

# Generated at 2022-06-25 16:35:28.600420
# Unit test for function parse
def test_parse():

    # sanitized
    assert parse("a\nb").short_description == "a"

    # short_description, long_description
    assert parse("one\n\ntwo\n").short_description == "one"
    assert parse("one\n\ntwo\n").long_description == "two"
    assert parse("one\n\ntwo\n\n").short_description == "one"
    assert parse("one\n\ntwo\n\n").long_description == "two"

    # no long_description
    assert parse("one").long_description is None

    # blank_after_short_description
    assert parse("one\n\ntwo").blank_after_short_description
    assert not parse("one\ntwo").blank_after_short_description

    # blank_after_long_description

# Generated at 2022-06-25 16:35:29.859075
# Unit test for function parse
def test_parse():
    test_case_0()


# Generated at 2022-06-25 16:35:35.830760
# Unit test for function parse
def test_parse():
    # test_case_0:
    str_0 = 'q31!n+d!`Gt\t"'
    docstring_0 = parse(str_0)
    assert isinstance(docstring_0, Docstring), "docstring_0 is not of type Docstring"
    print("Parsed docstring:", docstring_0)



# Generated at 2022-06-25 16:35:46.971621
# Unit test for function parse
def test_parse():
    str_0 = 'a'
    docstring_0 = parse(str_0)
    assert docstring_0.meta == []
    assert docstring_0.short_description == 'a'
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False


    str_1 = 'a\nb'
    docstring_1 = parse(str_1)
    assert docstring_1.meta == []
    assert docstring_1.short_description == 'a'
    assert docstring_1.long_description == 'b'
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.blank_after_long_description == False

    str_2

# Generated at 2022-06-25 16:35:58.755507
# Unit test for function parse
def test_parse():
    str_0 = ""
    docstring_0 = parse(str_0)

    try:
        str_1 = ":hi:"
        docstring_1 = parse(str_1)
    except ParseError as e:
        msg_1 = str(e)
    else:
        msg_1 = "no error"
    assert msg_1 == "Error parsing meta information near ':hi:'."

    try:
        str_2 = ":hi: asdjkfasdf"
        docstring_2 = parse(str_2)
    except ParseError as e:
        msg_2 = str(e)
    else:
        msg_2 = "no error"
    assert msg_2 == "Error parsing meta information near ':hi: asdjkfasdf'."

    str_3 = "short desc"


# Generated at 2022-06-25 16:35:59.890686
# Unit test for function parse
def test_parse():
    test_case_0()
    test_case_1()

# Generated at 2022-06-25 16:36:03.683665
# Unit test for function parse
def test_parse():
    docstring = parse("\nThis is the first line.\n\n:param int x: This is the parameter description.\n:returns: This is the return value description.\n:raises Exception: An exception description.\n")
    test_case_0()

# Generated at 2022-06-25 16:36:15.910696
# Unit test for function parse

# Generated at 2022-06-25 16:36:31.104195
# Unit test for function parse
def test_parse():
    str_0 = (
        "Single-line docstring.\n\n"
        "Meta-data:\n"
        ":param a: Parameter documentation.\n"
        ":returns: Return value documentation.\n\n"
        "Long description goes here.\n"
    )
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Single-line docstring."
    assert docstring_0.blank_after_short_description
    assert docstring_0.long_description == "Long description goes here."
    assert docstring_0.blank_after_long_description
    param_0 = docstring_0.meta[0]
    assert param_0.arg_name == "a"
    assert param_0.description == "Parameter documentation."
    assert iss

# Generated at 2022-06-25 16:36:39.972954
# Unit test for function parse
def test_parse():
    # Input parameters
    text = ":returns: count of how many even numbers are found in the array"
    # Expected output
    # Docstring(short_description=None, long_description=None, blank_after_short_description=False, blank_after_long_description=False, meta=[DocstringMeta(description='count of how many even numbers are found in the array', args=['returns'])])
    output = parse(text)
    assert output.meta[0].description == 'count of how many even numbers are found in the array'

    # Input parameters
    text = ":param int n: an integer"
    # Expected output
    # Docstring(short_description=None, long_description=None, blank_after_short_description=False, blank_after_long_description=False, meta=[DocstringParam(description='

# Generated at 2022-06-25 16:36:48.284845
# Unit test for function parse
def test_parse():
    str_0 = 'Test function parse'
    docstring_0 = parse(str_0)
    assert docstring_0.meta == []
    assert docstring_0.short_description == 'Test function parse'
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description is None

    str_1 = 'This is a test function\nfor parse'
    docstring_1 = parse(str_1)
    assert docstring_1.meta == []
    assert docstring_1.short_description == 'This is a test function'
    assert docstring_1.long_description == 'for parse'
    assert docstring_1.blank_after_short_description == True

# Generated at 2022-06-25 16:36:58.080233
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('return a+b.') == \
        Docstring(short_description='return a+b.',
                  blank_after_short_description=False,
                  long_description=None,
                  blank_after_long_description=False,
                  meta=[
                      DocstringMeta(
                          args=[],
                          description='return a+b.',
                      )
                  ])
    assert parse('return a+b.\n') == \
        Docstring(short_description='return a+b.',
                  blank_after_short_description=True,
                  long_description=None,
                  blank_after_long_description=False,
                  meta=[
                      DocstringMeta(
                          args=[],
                          description='return a+b.',
                      )
                  ])


# Generated at 2022-06-25 16:37:01.745629
# Unit test for function parse
def test_parse():
    # test_case_0
    str_0 = 'q31!n+d!`Gt\t"'
    docstring_0 = parse(str_0)



# Generated at 2022-06-25 16:37:09.081430
# Unit test for function parse
def test_parse():
    assert (parse("string of the docstring")== Docstring())
    assert (parse("string of the docstring")!= Docstring(
        short_description='string of the docstring',
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description=None,
        meta=[])
        )
    assert (parse("string of the docstring\nstring of the docstring")== Docstring(
        short_description='string of the docstring',
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description='string of the docstring\nstring of the docstring',
        meta=[])
        )

# Generated at 2022-06-25 16:37:18.058909
# Unit test for function parse
def test_parse():
    with pytest.raises(ValueError):
        parse(None)
    with pytest.raises(ParseError):
        parse('@param return')
    with pytest.raises(ParseError):
        parse('return:')
    with pytest.raises(ParseError):
        parse('Yields :')
    with pytest.raises(ParseError):
        parse(':type')
    with pytest.raises(ParseError):
        parse(':param x:')
    with pytest.raises(ParseError):
        parse(':param str')
    with pytest.raises(ParseError):
        parse(':param x')
    with pytest.raises(ParseError):
        parse(':param str:')

# Generated at 2022-06-25 16:37:31.265971
# Unit test for function parse
def test_parse():
    str_0 = ''
    assert parse(str_0) == Docstring(
        short_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    str_1 = 'x'
    assert parse(str_1) == Docstring(
        short_description='x',
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    str_2 = 'x\n\n'

# Generated at 2022-06-25 16:37:32.223692
# Unit test for function parse
def test_parse():
    test_case_0()


# Generated at 2022-06-25 16:37:38.609582
# Unit test for function parse

# Generated at 2022-06-25 16:37:55.601946
# Unit test for function parse
def test_parse():
    str_0 = "Test the string parser."
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Test the string parser.'
    assert not docstring_0.blank_after_short_description
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_long_description
    assert not docstring_0.meta

    str_1 = "Test the string parser.\n\n"
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Test the string parser.'
    assert not docstring_1.blank_after_short_description
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_long_description
    assert not docstring_1.meta



# Generated at 2022-06-25 16:38:08.603265
# Unit test for function parse
def test_parse():
    str_0 = 'q31!n+d!`Gt\t"'
    docstring_0 = parse(str_0)
    print("Testing parse...")
    assert parse(str_0) == Docstring(
        short_description="q31!n+d!`Gt\t\"",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse("") == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-25 16:38:18.871123
# Unit test for function parse
def test_parse():
    # Simple case.
    str_0 = 'Test function.'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == str_0
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 0
    # Simple case.
    str_0 = '  Test function.  '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Test function.'
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False

# Generated at 2022-06-25 16:38:29.271791
# Unit test for function parse
def test_parse():
    str_0 = """
    This is a function that does nothing.

    :param name: The name to use.
    :param state: Current state to be in.

    This is a test function.
    """
    assert parse(str_0).short_description == "This is a function that does nothing."
    assert parse(str_0).long_description == "This is a test function."
    assert parse(str_0).blank_after_short_description == True
    assert parse(str_0).blank_after_long_description == True
    str_1 = """
    A function.

    :param name: The name to use.
    :param state: Current state to be in.

    This is a test function.
    """
    assert parse(str_1).short_description == "A function."

# Generated at 2022-06-25 16:38:30.656973
# Unit test for function parse
def test_parse():
    test_case_0()


# Generated at 2022-06-25 16:38:42.149212
# Unit test for function parse
def test_parse():
    str_0 = 'q31!n+d!`Gt\t"'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is True
    assert docstring_0.meta == []

    str_1 = """\
This is a one-line description. 
This is the second line of description.

a: 1
"""
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'This is a one-line description.'
    assert docstring_1.long_description == 'This is the second line of description.'
    assert docstring_1

# Generated at 2022-06-25 16:38:46.756210
# Unit test for function parse
def test_parse():
    import doctest
    doctest.run_docstring_examples(parse, globals())


if __name__ == "__main__":
    import sys

    ret = 1
    if len(sys.argv) == 2:
        ret = 0 if test_parse() else 1
    else:
        sys.stdout.write("Running doctests...\n")
        ret = (0 if test_parse() else 1)
    sys.exit(ret)

# Generated at 2022-06-25 16:38:50.560250
# Unit test for function parse
def test_parse():
    test_case_0()
    test_case_1()
    test_case_2()
    

# Generated at 2022-06-25 16:39:04.129999
# Unit test for function parse
def test_parse():
    str_0 = 'q31!n+d!`Gt\t"'
    docstring_0 = parse(str_0)
    if docstring_0.blank_after_long_description is True:
        print("Test case 0 passed!")
    else:
        print("Test case 0 failed!")
    str_1 = "8x.\t>s@1"
    docstring_1 = parse(str_1)
    if docstring_1.blank_after_short_description is False:
        print("Test case 1 passed!")
    else:
        print("Test case 1 failed!")
    str_2 = '!\t\t1\n:+?V\n\t\t+'
    docstring_2 = parse(str_2)

# Generated at 2022-06-25 16:39:13.609895
# Unit test for function parse
def test_parse():
    docstring = """Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """

    docstring_object = parse(docstring)

    assert docstring_object.short_description == "Parse the ReST-style"
    assert docstring_object.blank_after_short_description is False
    assert docstring_object.blank_after_long_description is False
    assert docstring_object.long_description == "docstring into its components."


# Generated at 2022-06-25 16:39:25.242675
# Unit test for function parse
def test_parse():
    print('test_parse_0')
    var_0 = """
    test_parse_0
    """
    var_1 = parse(var_0)
    print(var_1)



# Generated at 2022-06-25 16:39:30.027105
# Unit test for function parse
def test_parse():
    assert parse('''\
    Example function with types documented in the docstring.

    :param a: The first parameter.
    :type a: int
    :param b: The second parameter.
    :type b: str, optional
    :returns:
        Description of return value
    :rtype: int
    :raises keyError: Raises an exception
    ''') == \
        globals()['var_0']


# Generated at 2022-06-25 16:39:32.493633
# Unit test for function parse
def test_parse():
    var_0 = inspect.getsource(test_case_0)
    var_1 = parse(var_0)
    print(var_1)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:39:37.074359
# Unit test for function parse
def test_parse():
    docstring = '''This is a docstring.

:param x: First arg
:param y: Second arg
:raises SomeError: Because reasons.
:returns: None
'''
    expected = '''This is a docstring.

    :param x: First arg
    :param y: Second arg
    :raises SomeError: Because reasons.
    :returns: None
'''
    actual = inspect.cleandoc(docstring)
    assert expected == actual


# Generated at 2022-06-25 16:39:46.345383
# Unit test for function parse
def test_parse():
    assert __name__ == "__main__"
    

# Generated at 2022-06-25 16:39:56.605638
# Unit test for function parse
def test_parse():
    var_2 = 'test_parse'
    var_6 = """:test_parse:
        :param foo:
            The parameter "foo"

            has a long description, too.
    """
    var_5 = 'test_parse'
    var_4 = """The parameter "foo"

            has a long description, too.
    """
    var_3 = 'param foo'
    var_7 = parse(var_6)
    var_8 = var_7.short_description
    var_9 = var_8 == var_5
    assert var_9
    var_10 = var_7.meta[0].description
    var_11 = var_10 == var_4
    assert var_11

if __name__ == "__main__":
    x = parse.__code__.co_varnames
   

# Generated at 2022-06-25 16:40:02.637871
# Unit test for function parse
def test_parse():
    text = "Return True if the string starts with the prefix, False otherwise."
    ret = parse(text=text)
    assert ret.short_description == "Return True if the string starts with the prefix, False otherwise."
    assert ret.long_description == ''
    assert not ret.blank_after_long_description
    assert not ret.blank_after_short_description
    assert len(ret.meta) == 0


# Generated at 2022-06-25 16:40:08.087825
# Unit test for function parse
def test_parse():

    # Setup
    var = Docstring() 
    doc = ':param a: A parameter.\n'
    doc += ':returns: Returns a value.'
    var.meta = []
    var.meta.append(DocstringMeta(args=['param', 'a'], description='A parameter.'))
    var.meta.append(DocstringMeta(args=['returns'], description='Returns a value.'))

    # Execute
    ret = parse(doc)

    # Assert
    assert ret == var, 'Expected: {}, Actual: {}'.format(var, ret)


# Generated at 2022-06-25 16:40:19.195561
# Unit test for function parse
def test_parse():

    # Test case #0
    print("Running test case #0...")
    text = """
        Parses ReST-style docstrings into a ``docstring`` object,
        containing its components.

        :param one: first param
        :param two: second param
        :type one: an arbitrary Python object
        :type two: ditto
        :returns: whatever you want
        :rtype: str
        """
    e = Docstring()
    e.short_description = "Parses ReST-style docstrings into a ``docstring`` object, containing its components."
    e.long_description = "one: first param\ntwo: second param\none: an arbitrary Python object\ntwo: ditto\nreturns: whatever you want\nrtype: str"
    e.blank_after_short_description = True

# Generated at 2022-06-25 16:40:30.011682
# Unit test for function parse
def test_parse():
    var_0 = parse("""Test docstring.
     
    :param arg1: argument 1
    :type arg1: str
    :param arg2: argument 2
    :type arg2: int"""
    )

    assert var_0.short_description == "Test docstring."
    assert var_0.long_description == None
    assert var_0.blank_after_short_description == True
    assert var_0.blank_after_long_description == False

    assert var_0.meta[0].args == ['param', 'arg1', 'argument 1']
    assert var_0.meta[0].description == 'Test docstring.'
    assert var_0.meta[0].arg_name == 'arg1'
    assert var_0.meta[0].type_name == 'str'
    assert var_0.meta

# Generated at 2022-06-25 16:40:46.019286
# Unit test for function parse
def test_parse():
    # Test when the docstring is empty
    str_0 = ''
    docstring_0 = parse(str_0)
    assert (docstring_0.short_description is None)
    assert (docstring_0.long_description is None)
    assert (not docstring_0.meta)

    # Test when the description is long and does not have meta
    str_1 = 'This is a short description\n\nThis is a long description that may span multiple lines and has\nthe potential to be folded.\n'
    docstring_1 = parse(str_1)
    assert (docstring_1.short_description == 'This is a short description')
    assert (docstring_1.long_description == 'This is a long description that may span multiple lines and has\nthe potential to be folded.')

# Generated at 2022-06-25 16:40:55.885584
# Unit test for function parse
def test_parse():
    str0 = 'This is a short description.\n\nAnd this is a thorough long description.\nIt may span multiple lines, but it will be\ntrimmed and then folded.\n\nThis is a docstring that has a parameter with a\ndefault value:\n\n:param x: The x parameter defaults to 123.\n:raises Exception: If something goes wrong.\n:returns: Nothing.\n:rtype: None\n'
    docstring0 = parse(str0)

    # Test docstring0
    assert docstring0.short_description == 'This is a short description.'
    assert docstring0.long_description == 'And this is a thorough long description. It may span multiple lines, but it will be trimmed and then folded.'
    assert docstring0.blank_after_short_description == True
    assert doc

# Generated at 2022-06-25 16:41:05.430815
# Unit test for function parse
def test_parse():

    str_1 = 'This is a short description.\n\nAnd this is a thorough long description.\nIt may span multiple lines, but it will be\ntrimmed and then folded.\n\nThis is a docstring that has a parameter with a\ndefault value:\n\n:param x: The x parameter defaults to 123.\n:raises Exception: If something goes wrong.\n:returns: Nothing.\n:rtype: None\n'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'This is a short description.'
    assert docstring_1.long_description == 'And this is a thorough long description. It may span multiple lines, but it will be trimmed and then folded.'
    assert docstring_1.blank_after_short_description
    assert docstring_1

# Generated at 2022-06-25 16:41:14.821809
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n\nAnd this is a thorough long description.\nIt may span multiple lines, but it will be\ntrimmed and then folded.\n\nThis is a docstring that has a parameter with a\ndefault value:\n\n:param x: The x parameter defaults to 123.\n:raises Exception: If something goes wrong.\n:returns: Nothing.\n:rtype: None\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'This is a short description.'
    assert docstring_0.long_description == 'And this is a thorough long description.\nIt may span multiple lines, but it will be\ntrimmed and then folded.'

# Generated at 2022-06-25 16:41:25.965542
# Unit test for function parse
def test_parse():
    assert parse('"') == Docstring()
    assert parse("'") == Docstring()
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n\n") == Docstring()
    assert parse("""This is a short description.
    It may span multiple lines, but it will be trimmed and then folded.
    """) == Docstring(
        short_description="This is a short description.",
        long_description="It may span multiple lines, but it will be trimmed and then folded.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

# Generated at 2022-06-25 16:41:31.728719
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("   \n") == Docstring()
    assert parse("This is a short description.") == Docstring(
        short_description="This is a short description."
    )
    assert parse("\nThis is a short description.") == Docstring(
        short_description="This is a short description."
    )
    assert parse("\n\nThis is a short description.") == Docstring(
        short_description="This is a short description."
    )
    assert parse("\n\nThis is a short description.\n\n") == Docstring(
        short_description="This is a short description."
    )

# Generated at 2022-06-25 16:41:37.257416
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n\nAnd this is a thorough long description.\nIt may span multiple lines, but it will be\ntrimmed and then folded.\n\nThis is a docstring that has a parameter with a\ndefault value:\n\n:param x: The x parameter defaults to 123.\n:raises Exception: If something goes wrong.\n:returns: Nothing.\n:rtype: None\n'
    assert str(parse(str_0)) == str_0

# Generated at 2022-06-25 16:41:47.668059
# Unit test for function parse
def test_parse():
    str_1 = 'This is test method for the class.\n\nThis is a detailed description'
    docstring_1 = parse(str_1)
    assert (docstring_1.short_description) == ('This is test method for the class.')
    assert (docstring_1.long_description) == ('This is a detailed description')

    str_2 = 'This is test class for docstring.\n\nThis is a detailed description'
    docstring_2 = parse(str_2)
    assert (docstring_2.short_description) == ('This is test class for docstring.')
    assert (docstring_2.long_description) == ('This is a detailed description')


# Generated at 2022-06-25 16:41:50.972416
# Unit test for function parse
def test_parse():
    test_case_0()
    # Add your own unit test cases here
    # None


if __name__ == "__main__":
    import sys
    print("Testing {}".format(__file__), file=sys.stderr)
    test_parse()
    print("Done testing {}".format(__file__), file=sys.stderr)

# Generated at 2022-06-25 16:41:52.844896
# Unit test for function parse
def test_parse():
    print('Testing function "parse"')
    test_case_0()
    print('Function "parse" is okay')


# Generated at 2022-06-25 16:42:25.058873
# Unit test for function parse
def test_parse():
    docstring_0 = parse('This is a short description.\n\nAnd this is a thorough long description.\nIt may span multiple lines, but it will be\ntrimmed and then folded.\n\nThis is a docstring that has a parameter with a\ndefault value:\n\n:param x: The x parameter defaults to 123.\n:raises Exception: If something goes wrong.\n:returns: Nothing.\n:rtype: None\n')
    assert docstring_0.short_description == 'This is a short description.'
    assert docstring_0.long_description == """And this is a thorough long description.
It may span multiple lines, but it will be
trimmed and then folded.

This is a docstring that has a parameter with a
default value:"""
    assert docstring_0.blank_after

# Generated at 2022-06-25 16:42:35.247122
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n\nAnd this is a thorough long description.\nIt may span multiple lines, but it will be\ntrimmed and then folded.\n\nThis is a docstring that has a parameter with a\ndefault value:\n\n:param x: The x parameter defaults to 123.\n:raises Exception: If something goes wrong.\n:returns: Nothing.\n:rtype: None\n'
    docstring_0 = parse(str_0)
    assert type(docstring_0) == Docstring
    assert docstring_0.short_description == 'This is a short description.'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True
    assert docstring_0.long_description

# Generated at 2022-06-25 16:42:44.686867
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n\nAnd this is a thorough long description.\nIt may span multiple lines, but it will be\ntrimmed and then folded.\n\nThis is a docstring that has a parameter with a\ndefault value:\n\n:param x: The x parameter defaults to 123.\n:raises Exception: If something goes wrong.\n:returns: Nothing.\n:rtype: None\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'This is a short description.'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True

# Generated at 2022-06-25 16:42:52.796811
# Unit test for function parse
def test_parse():
    print('Testing function parse.')
    assert(parse('This is a short description.').short_description == 'This is a short description.')
    assert(parse('This is a short description.\n\n This line has enough whitespace to be regarded a long description.').short_description == 'This is a short description.')
    assert(parse('This is a short description.\n\n This line has enough whitespace to be regarded a long description.').long_description == 'This line has enough whitespace to be regarded a long description.')
    assert(parse('This is a short description.\n\n This line has enough whitespace to be regarded a long description.').long_description == 'This line has enough whitespace to be regarded a long description.')

# Generated at 2022-06-25 16:42:59.981533
# Unit test for function parse
def test_parse():
	str_0 = 'This is a short description.\n\nAnd this is a thorough long description.\nIt may span multiple lines, but it will be\ntrimmed and then folded.\n\nThis is a docstring that has a parameter with a\ndefault value:\n\n:param x: The x parameter defaults to 123.\n:raises Exception: If something goes wrong.\n:returns: Nothing.\n:rtype: None\n'
	docstring_0 = parse(str_0)
	assert len(docstring_0.meta) == 4, "Expected four, got %s" % len(docstring_0.meta)
	
	assert docstring_0.short_description == "This is a short description.", "Incorrect short description parsed"

# Generated at 2022-06-25 16:43:11.098296
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n\nAnd this is a thorough long description.\nIt may span multiple lines, but it will be\ntrimmed and then folded.\n\nThis is a docstring that has a parameter with a\ndefault value:\n\n:param x: The x parameter defaults to 123.\n:raises Exception: If something goes wrong.\n:returns: Nothing.\n:rtype: None\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'This is a short description.'
    assert docstring_0.long_description == 'And this is a thorough long description.\nIt may span multiple lines, but it will be trimmed and then folded.'
    assert docstring_0.blank_after_short_description == True

# Generated at 2022-06-25 16:43:16.983840
# Unit test for function parse

# Generated at 2022-06-25 16:43:19.166814
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:43:30.799084
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short description.\n\nAnd this is a thorough long description.\nIt may span multiple lines, but it will be\ntrimmed and then folded.\n\nThis is a docstring that has a parameter with a\ndefault value:\n\n:param x: The x parameter defaults to 123.\n:raises Exception: If something goes wrong.\n:returns: Nothing.\n:rtype: None\n'
    docstring_0 = parse(str_0)