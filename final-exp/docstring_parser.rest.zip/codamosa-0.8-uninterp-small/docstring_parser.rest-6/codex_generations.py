

# Generated at 2022-06-25 16:34:05.950451
# Unit test for function parse
def test_parse():
    str_0 = 'See Also'
    docstring_0 = parse(str_0)
    assert len(docstring_0.meta) == 1, 'Check length of docstring'
    assert type(docstring_0.meta[0]) == DocstringMeta, 'Check class of docstring meta'
    assert len(docstring_0.meta[0].args) == 1, 'Check length of meta args'
    assert docstring_0.meta[0].args[0] == 'Also'
    assert docstring_0.meta[0].description == 'See', 'Check docstring meta description'
    assert docstring_0.long_description == None, 'Check docstring long_description'
    assert docstring_0.short_description == None, 'Check docstring short_description'

    str_1 = 'Yields'
    doc

# Generated at 2022-06-25 16:34:15.984255
# Unit test for function parse
def test_parse():
    # Test 1
    str_1 = '''Takes a filename and returns a string containing the file's
        contents.'''
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "Takes a filename and returns a string "
    assert docstring_1.long_description == "containing the file's contents."
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.blank_after_long_description == False
    assert docstring_1.meta == []

    # Test 2
    str_2 = '''Get's all of the items in the specified path.'''
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == "Get's all of the items in the specified path."
    assert docstring_2.long

# Generated at 2022-06-25 16:34:27.386800
# Unit test for function parse
def test_parse():
    str_0 = """\
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Parse the ReST-style docstring into its components."
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == [DocstringReturns(args=['returns'], description='parsed docstring', type_name=None, is_generator=False)]


# Generated at 2022-06-25 16:34:29.039897
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:34:34.849042
# Unit test for function parse
def test_parse():
    str1 = '''
    This is a test document string.
    '''
    docstring1 = parse(str1)
    assert docstring1 == Docstring(
        short_description='This is a test document string.',
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )



# Generated at 2022-06-25 16:34:43.233344
# Unit test for function parse
def test_parse():
    str_0 = """
    Lorem ipsum dolor sit amet, consectetuer adipiscing elit.

    :param int x:
        The integer value for the x-coordinate.
        Defaults to 0.
    :param int y: The integer value for the y-
    coordinate. Defaults to 0.
    :type y: int, optional
    :param str color:
        The optional color of the point.
        Can be one of:
        - red
        - green
        - blue
        Defaults to "red".
    :raises ValueError:
        If x or y are negative.
    :rtype : Point
    :returns:
        A :py:class:`Point`.
    :Example:
        >>> a = Point(2, 3)
    """

# Generated at 2022-06-25 16:34:53.931639
# Unit test for function parse
def test_parse():
    # test case 0
    str_0 = ''
    docstring_0 = parse(str_0)
    assert docstring_0 == Docstring(
        short_description=None,
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[]
    )

    # test case 1
    str_1 = '    This is a docstring.\n'
    docstring_1 = parse(str_1)
    assert docstring_1 == Docstring(
        short_description='This is a docstring.',
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[]
    )

    # test case 2

# Generated at 2022-06-25 16:35:02.594032
# Unit test for function parse
def test_parse():
    func = parse
    docstring_0 = parse('')
    docstring_1 = parse('\n')
    assert docstring_0 == docstring_1
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.meta == []
    docstring_2 = parse('Testing')
    assert docstring_2 == Docstring(
        short_description='Testing',
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    docstring_3 = parse('Testing\n\n')
    assert doc

# Generated at 2022-06-25 16:35:11.818211
# Unit test for function parse

# Generated at 2022-06-25 16:35:12.956193
# Unit test for function parse
def test_parse():
    test_case_0()
    print("all tests passed")

# Generated at 2022-06-25 16:35:33.102013
# Unit test for function parse

# Generated at 2022-06-25 16:35:35.443408
# Unit test for function parse
def test_parse():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 16:35:39.587913
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:35:48.132371
# Unit test for function parse
def test_parse():
    assert 'h' in parse('hello')
    assert 'h' in parse('')
    # print(parse(str_0))
    # print(parse(str_0).doc_type)
    # print(parse(str_0).short_description)
    # print(parse(str_0).long_description)
    # print(parse(str_0).blank_after_short_description)
    # print(parse(str_0).blank_after_long_description)
    # print(parse(str_0).meta)
    # print(*parse(str_0).meta, sep='\n')
    # print(parse(str_0).meta[0].arg_name)
    # print(parse(str_0).meta[1].arg_name)
    # print(parse(str_0).meta[2].

# Generated at 2022-06-25 16:35:59.196049
# Unit test for function parse

# Generated at 2022-06-25 16:36:00.913904
# Unit test for function parse
def test_parse():
    assert (isinstance(parse(str_0), Docstring))
    assert (isinstance(parse(""), Docstring))

# Generated at 2022-06-25 16:36:07.175471
# Unit test for function parse
def test_parse():
    from .common import Docstring
    import unittest

# Generated at 2022-06-25 16:36:16.623919
# Unit test for function parse
def test_parse():
    str1 = """\
    Lorem ipsum dolor sit amet, consectetuer adipiscing elit.

    :param int x:
        The integer value for the x-coordinate.
        Defaults to 0.
    :param int y: The integer value for the y-
    coordinate. Defaults to 0.
    :type y: int, optional
    :param str color:
        The optional color of the point.
        Can be one of:
        - red
        - green
        - blue
        Defaults to "red".
    :raises ValueError:
        If x or y are negative.
    :rtype : Point
    :returns:
        A :py:class:`Point`.
    :Example:
        >>> a = Point(2, 3)
"""
    #str1 = """\
   

# Generated at 2022-06-25 16:36:27.539583
# Unit test for function parse
def test_parse():
    print('Testing parse')
    # Call function parse with arguments: str_0
    print('\nCall: parse(str_0)')
    print('\nOutput:')
    print(parse(str_0).short_description)
    print(parse(str_0).long_description)
    for i in parse(str_0).meta:
        print(i.args)
        print(i.description)
        if i.arg_name:
            print(i.arg_name)
        if i.type_name:
            print(i.type_name)
        if i.is_optional:
            print(i.is_optional)
        if i.is_generator:
            print(i.is_generator)
        if i.default:
            print(i.default)
    # Call function parse with

# Generated at 2022-06-25 16:36:37.305210
# Unit test for function parse
def test_parse():
    # Provide example inputs and results here, ending each with a newline
    inputs      = [str_0] 

# Generated at 2022-06-25 16:36:57.620689
# Unit test for function parse
def test_parse():
    str_0 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    res_0 = parse(str_0)
    assert res_0.short_description == 'Parse the ReST-style docstring into its components.'
    assert res_0.blank_after_short_description
    assert res_0.blank_after_long_description
    assert res_0.long_description == ':returns: parsed docstring'
    assert len(res_0.meta)
    assert res_0.meta[0].args == ['returns']
    assert res_0.meta[0].description == 'parsed docstring'



# Generated at 2022-06-25 16:37:01.748895
# Unit test for function parse
def test_parse():
    str_0 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)



# Generated at 2022-06-25 16:37:09.079871
# Unit test for function parse
def test_parse():
    # Test 0
    global str_0
    str_0 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    global docstring_0
    docstring_0 = parse(str_0)
    assert str(docstring_0) == str_0
    assert docstring_0.short_description == "Parse the ReST-style docstring into its components."
    assert docstring_0.long_description == "parsed docstring"
    assert docstring_0.blank_after_short_description
    assert docstring_0.blank_after_long_description

# Generated at 2022-06-25 16:37:11.036775
# Unit test for function parse
def test_parse():
    assert isinstance(parse(str), Docstring)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:37:12.937898
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    # Run the unit tests
    test_parse()

# Generated at 2022-06-25 16:37:19.840767
# Unit test for function parse
def test_parse():
    str_0 = '''
    This is a test function.

    This is the long description.
    '''
    docstring_0 = Docstring(
        short_description=str_0.strip(),
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[]
    )
    assert parse(str_0) == docstring_0

    str_1 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '

# Generated at 2022-06-25 16:37:21.756541
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:37:29.278542
# Unit test for function parse
def test_parse():
    str_0 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Parse the ReST-style docstring into its components.'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.long_description == 'returns: parsed docstring'
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta[0].__class__.__name__ == 'DocstringReturns'
    assert docstring_0.meta[0].is_generator == False
    assert docstring_0.meta[0].args == ['returns', 'parsed', 'docstring']


# Generated at 2022-06-25 16:37:31.482395
# Unit test for function parse
def test_parse():
    test_case_0()
    print("Unit Test Finished Successfully.")


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:37:37.426282
# Unit test for function parse
def test_parse():
    # test case 0
    str_0 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert isinstance(docstring_0, Docstring)
    assert docstring_0.short_description == 'Parse the ReST-style docstring into its components.'
    assert docstring_0.long_description == 'parsed docstring'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == False


# Generated at 2022-06-25 16:37:55.709453
# Unit test for function parse
def test_parse():
    str_0 = """
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """

    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Parse the ReST-style docstring into its components."
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == [DocstringReturns(args=['returns', None], description='parsed docstring', type_name=None, is_generator=False)]
    str_1 = 'Parse the ReST-style docstring into its components.\n\n:returns: parsed docstring\n'
   

# Generated at 2022-06-25 16:38:08.736232
# Unit test for function parse
def test_parse():
    # Sample string
    str_0 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    # Expected value
    expected = Docstring(
        short_description='Parse the ReST-style docstring into its components.',
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[DocstringReturns(['returns', None], 'parsed docstring', None)],
    )
    # Call function
    actual = parse(str_0)
    # Tests
    assert expected == actual
    assert expected.short_description == actual.short_description
    assert expected.blank_after_short_description == actual.blank_after_short_description
    assert expected.blank

# Generated at 2022-06-25 16:38:17.844286
# Unit test for function parse
def test_parse():
    str_0 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Parse the ReST-style docstring into its components.'
    assert docstring_0.blank_after_short_description
    assert docstring_0.blank_after_long_description
    assert docstring_0.long_description is None
    assert len(docstring_0.meta) == 1

    meta_0 = docstring_0.meta[0]
    assert meta_0.name == 'returns'
    assert len(meta_0.args) == 1
    assert meta_0.args[0] == 'returns'


# Generated at 2022-06-25 16:38:29.203105
# Unit test for function parse
def test_parse():
    str_0 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)

    assert docstring_0.short_description == 'Parse the ReST-style docstring into its components.'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_long_description == True
    assert str(docstring_0.meta[0].args) == "['returns']"
    assert docstring_0.meta[0].description == 'parsed docstring'
    assert docstring_0.meta[0].arg_name == None
    assert docstring_0.meta[0].type_name == None

# Generated at 2022-06-25 16:38:41.283874
# Unit test for function parse
def test_parse():
    str_0 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    str_1 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    docstring_1 = parse(str_1)
    str_2 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    docstring_2 = parse(str_2)
    assert docstring_0.short_description == 'Parse the ReST-style docstring into its components.'
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_

# Generated at 2022-06-25 16:38:45.130188
# Unit test for function parse
def test_parse():
    str_0 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    str_1 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n'
    docstring_1 = parse(str_1)
    str_2 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring'
    docstring_2 = parse(str_2)


# Generated at 2022-06-25 16:38:46.171243
# Unit test for function parse
def test_parse():
    test_case_0()



# Generated at 2022-06-25 16:38:47.041673
# Unit test for function parse
def test_parse():
    pass


# Generated at 2022-06-25 16:38:56.238885
# Unit test for function parse
def test_parse():
    str_0 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    str_1 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    \n    :arg foo: Foo\n    :returns: Nothing\n    '
    # Test the above docstrings. The first one should only have a short description,
    # but the second one should have a meta entry for the :arg and :returns.
    for str_val in [str_0, str_1]:
        docstring = parse(str_val)
        assert docstring.short_description == "Parse the ReST-style docstring into its components."
        assert docstring.long_description == None
        assert docstring.blank

# Generated at 2022-06-25 16:39:06.568494
# Unit test for function parse
def test_parse():
    ok, total = test_parse.count_ok, test_parse.count_total

    str_0 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Parse the ReST-style docstring into its components.', f'expected: {["Parse the ReST-style docstring into its components."]}, got: {[docstring_0.short_description]}'
    assert docstring_0.long_description == 'parsed docstring', f'expected: {["parsed docstring"]}, got: {[docstring_0.long_description]}'
    total += 1
    ok += 1
    assert len(docstring_0.meta)

# Generated at 2022-06-25 16:39:26.574685
# Unit test for function parse
def test_parse():
    test_case_0()

#test_parse()

# Generated at 2022-06-25 16:39:34.705071
# Unit test for function parse
def test_parse():
    docstring_0 = parse('')
    assert type(docstring_0) == Docstring
    assert len(docstring_0.meta) == 0
    assert docstring_0.short_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_long_description == False
    str_0 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    docstring_1 = parse(str_0)
    assert type(docstring_1) == Docstring
    assert len(docstring_1.meta) == 1
    assert docstring_1.meta[0].args == ['returns']

# Generated at 2022-06-25 16:39:37.409183
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:39:40.491621
# Unit test for function parse
def test_parse():
    # TODO: add test cases here
    test_case_0()

# Main entry point into script
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:39:50.221658
# Unit test for function parse
def test_parse():
    """
    Tests the parse function

    :return: none
    """

    # Case 0
    # str_0 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    # docstring_0 = parse(str_0)
    str_0 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)

    assert type(docstring_0) == Docstring
    assert docstring_0.short_description == 'Parse the ReST-style docstring into its components.'
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == True
    assert doc

# Generated at 2022-06-25 16:39:58.339599
# Unit test for function parse
def test_parse():
    # Test 1
    str_1 = """\
Returns a thumbnail of the current workspace, using the filename specified.

"""
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "Returns a thumbnail of the current workspace, using the filename specified."
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank_after_long_description == False
    assert docstring_1.meta == []

    # Test 2
    str_2 = "Subtracts the values of the corresponding cells in the arrays and takes the absolute value of the difference."
    docstring_2 = parse(str_2)

# Generated at 2022-06-25 16:40:08.471401
# Unit test for function parse
def test_parse():
    docstring_0 = parse('')
    assert len(docstring_0.meta) == 0

    docstring_0 = parse('Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    ')
    assert docstring_0.short_description == 'Parse the ReST-style docstring into its components.'
    assert docstring_0.meta[0].args == ['returns']
    assert docstring_0.meta[0].description == 'parsed docstring'


# Generated at 2022-06-25 16:40:10.598271
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == '__main__':
    import pytest
    pytest.main(['test_rest.py'])

# Generated at 2022-06-25 16:40:21.201335
# Unit test for function parse
def test_parse():
    str_0 = """\
        The most important thing to remember when using the interpolation
        algorithm is that the original data value must be preserved.

        :param str string: The string in which to find the value.
        :param int start: The index from which to begin searching.

        :returns: The position at which the match was found, or -1 if no
            match was found.

        :raises ValueError: If there is a zero-length match at the beginning
            of the string.

        """
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'The most important thing to remember when using the interpolation algorithm is that the original data value must be preserved.'
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is True

# Generated at 2022-06-25 16:40:29.173698
# Unit test for function parse
def test_parse():
    str_0 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    str_1 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n\n'
    str_2 = 'Parse the ReST-style docstring into its components.'
    str_3 = 'Parse the ReST-style docstring into its components.\n\n    :returns parsed docstring\n\n'
    str_4 = ''
    str_5 = ':returns: parsed docstring\n\n'
    str_6 = 'Parse the ReST-style docstring into its components.\n\n    :returns:\n    :parsed docstring:\n\n'

    #

# Generated at 2022-06-25 16:40:55.910315
# Unit test for function parse
def test_parse():
  print("Test 1")
  str_1 = 'Parse the ReST-style docstring into its components.\n    :returns: parsed docstring'
  docstring_1 = parse(str_1)
  assert(docstring_1.short_description == 'Parse the ReST-style docstring into its components.')
  assert(docstring_1.blank_after_short_description == True)
  assert(docstring_1.blank_after_long_description == False)
  assert(docstring_1.long_description == None)

  print("Test 2")
  str_2 = 'Parse the ReST-style docstring into its components.\n\n:returns: parsed docstring'
  docstring_2 = parse(str_2)

# Generated at 2022-06-25 16:40:59.580122
# Unit test for function parse
def test_parse():
    str = 'Parse the ReST-style docstring into its components.\n\n:returns: parsed docstring\n    '
    docstring = parse(str)
    return docstring


# Generated at 2022-06-25 16:41:10.374013
# Unit test for function parse
def test_parse():
    # Test 1
    str_1 = 'Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    docstring_1 = parse(str_1)

    assert len(docstring_1.meta) == 1

    assert type(docstring_1.meta[0]) == DocstringReturns
    assert len(docstring_1.meta[0].args) == 1
    assert docstring_1.meta[0].args[0] == "returns"
    assert docstring_1.meta[0].type_name == "parsed docstring"
    assert docstring_1.meta[0].is_generator == False
    assert docstring_1.meta[0].description == ": parsed docstring"


# Generated at 2022-06-25 16:41:12.220830
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:41:13.258963
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:41:23.462177
# Unit test for function parse
def test_parse():
    docstring = parse('Parse the ReST-style docstring into its components.\n\n    :returns: parsed docstring\n    ')
    docstring.short_description == 'Parse the ReST-style docstring into its components.'
    docstring.blank_after_short_description == True
    docstring.blank_after_long_description == True
    docstring.long_description == 'parsed docstring'
    docstring.meta[0].args[0] == ':returns:'
    docstring.meta[0].description == 'parsed docstring'
    docstring.meta[0].name is None
    docstring.meta[0].type_name is None
    docstring.meta[0].is_optional is None
    docstring.meta[0].default is None

# Generated at 2022-06-25 16:41:27.117784
# Unit test for function parse
def test_parse():
    global str_0, docstring_0

    str_0 = """Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """
    docstring_0 = parse(str_0)

    print(docstring_0)

# Generated at 2022-06-25 16:41:37.048670
# Unit test for function parse
def test_parse():
    str_0 = """
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Parse the ReST-style docstring into its components.'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.long_description is None
    assert len(docstring_0.meta) == 1
    assert isinstance(docstring_0.meta[0], DocstringReturns)
    assert docstring_0.meta[0].args == ['returns']
    assert docstring_0.meta[0].type_name is None

# Generated at 2022-06-25 16:41:47.546206
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('\n') == Docstring()

    assert parse('Hello world!') == Docstring(
        short_description='Hello world!',
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

    assert parse('Hello world!\n') == Docstring(
        short_description='Hello world!',
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )


# Generated at 2022-06-25 16:41:49.024187
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:42:18.403011
# Unit test for function parse
def test_parse():
    assert parse("Hello world.") == \
    Docstring(short_description="Hello world.",
          long_description=None,
          blank_after_short_description=False,
          blank_after_long_description=False,
          meta=[])
    assert parse("Hello world\n\nSays hello.") == \
    Docstring(short_description="Hello world",
          long_description="Says hello.",
          blank_after_short_description=True,
          blank_after_long_description=False,
          meta=[])
    assert parse("Hello world\n\n\n\nSays hello.") == \
    Docstring(short_description="Hello world",
          long_description="Says hello.",
          blank_after_short_description=True,
          blank_after_long_description=True,
          meta=[])


# Generated at 2022-06-25 16:42:25.615150
# Unit test for function parse
def test_parse():
    str_0 = 'Setup sections.\n\n        :param sections: Recognized sections or None to defaults.\n        :param title_colon: require colon after section title.\n        '
    docstring_0 = parse(str_0)
    assert type(docstring_0) == type(Docstring())
    assert docstring_0.short_description == 'Setup sections.'
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.blank_after_short_description == True
    assert type(docstring_0.meta) == type([])
    assert len(docstring_0.meta) == 2
    assert type(docstring_0.meta[0]) == type(DocstringMeta(args=[""], description=""))

# Generated at 2022-06-25 16:42:35.478793
# Unit test for function parse

# Generated at 2022-06-25 16:42:43.598925
# Unit test for function parse
def test_parse():
    str_1 = 'Setup sections.\n\n        :param sections: Recognized sections or None to defaults.\n        :param title_colon: require colon after section title.\n        '

    # Test parse() method
    expected_short_desc_1 = 'Setup sections.'
    expected_long_desc_1 = 'Recognized sections or None to defaults.\n        require colon after section title.'
    expected_meta_1 = [DocstringParam(args=['param', 'sections', 'title_colon'], description='Recognized sections or None to defaults.\n        require colon after section title.', arg_name='title_colon', type_name=None, is_optional=None, default=None)]

    docstring_1 = parse(str_1)
    assert docstring_1.short_description == expected_short_

# Generated at 2022-06-25 16:42:55.755291
# Unit test for function parse
def test_parse():
    def f_0(x: int = 10, y: int = 20) -> T.Tuple[int, int]:
        '''
        :param x:
        :param y:
        :returns: (x, y)
        '''

    def f_1() -> T.Tuple[int, int]:
        '''
        :param x:
        :param y:
        :returns: (x, y)
        '''

    def f_2() -> T.Tuple[int, int]:
        '''
        :param x:
        :param y:
        '''

    def f_3() -> T.Tuple[int, int]:
        '''
        (x, y)
        '''


# Generated at 2022-06-25 16:42:57.762263
# Unit test for function parse
def test_parse():
    str_0 = ''
    docstring_0 = parse(str_0)
    assert docstring_0.short_description is None


# Generated at 2022-06-25 16:43:01.051979
# Unit test for function parse
def test_parse():
    test_case_0()

# Command-line entry point
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:43:09.401419
# Unit test for function parse
def test_parse():
    print('Testing function "parse"')
    str_0 = 'Parse the ReST-style docstring into its components.\n\n        :returns: parsed docstring\n        '
    docstring_0 = parse(str_0)
    assert docstring_0.meta[0].args == ['returns']
    assert docstring_0.meta[0].arg_name is None
    assert docstring_0.meta[0].type_name is None
    assert docstring_0.meta[0].is_optional is None
    assert docstring_0.meta[0].default is None
    assert docstring_0.meta[0].description == 'parsed docstring'
    assert docstring_0.short_description == 'Parse the ReST-style docstring into its components.'
    assert docstring_0.long_

# Generated at 2022-06-25 16:43:16.056374
# Unit test for function parse
def test_parse():
    str_0 = 'Setup sections.\n\n        :param sections: Recognized sections or None to defaults.\n        :param title_colon: require colon after section title.\n        '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Setup sections.'
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta[0].args[0] == 'param'
    assert docstring_0.meta[0].args[1] == 'sections'
    assert docstring_0.meta[0].arg_name == 'sections'
    assert docstring_0.meta[0].type_name == None


# Generated at 2022-06-25 16:43:20.301675
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    raise SystemExit(
        f"ERROR: not intended to be run as a module: {__file__}"
    )