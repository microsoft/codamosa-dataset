

# Generated at 2022-06-25 16:33:51.589922
# Unit test for function parse
def test_parse():
    str_1 = '''
    Returns the sum of two numbers.

    :param x: the first number
    :param y: the second number
    :type x: int
    :type y: int
    :returns: The sum of two numbers.
    :rtype: int

    :Example:

    >>> add(1, 1)
    2
    '''

    str_2 = '''
    Graph a function.

    :param func: The function to graph.
    :type func: function
    :param str xmin: The minimum value of the X axis.
    :param str xmax: The maximum value of the X axis.
    :raise ValueError: If `xmin` > `xmax`.
    :returns str: The resulting graph.
    '''


# Generated at 2022-06-25 16:33:59.129953
# Unit test for function parse
def test_parse():
    # test_case_0
    str_0 = 'V t'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'V t'
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is True
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.meta == []

    # test_case_1
    str_1 = 'V t\n\n:\n:\n:\n:\n:\n'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'V t'
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is True
    assert doc

# Generated at 2022-06-25 16:34:06.888845
# Unit test for function parse
def test_parse():

    # Test 0
    str_0 = 'V t'
    docstring_0 = parse(str_0)

    str_0_short_description = docstring_0.short_description
    str_0_short_description_expected = 'V t'
    assert str_0_short_description == str_0_short_description_expected

    str_0_blank_after = docstring_0.blank_after_short_description
    str_0_blank_after_expected = False
    assert str_0_blank_after == str_0_blank_after_expected

    str_0_long_description = docstring_0.long_description
    str_0_long_description_expected = None
    assert str_0_long_description == str_0_long_description_expected

    str_0_blank_after_long_

# Generated at 2022-06-25 16:34:09.939772
# Unit test for function parse
def test_parse():
    str_0 = 'V t'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'V t'
    assert docstring_0.long_description is None
    assert docstring_0.meta == []


# Generated at 2022-06-25 16:34:17.271209
# Unit test for function parse
def test_parse():
    str_1 = '''
    "
    V t
    :return:
    "
    '''
    docstring_1 = parse(str_1)
    print(docstring_1)
    assert docstring_1.short_description == 'V t'
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_long_description == False
    assert docstring_1.meta == [DocstringReturns(args=['return'], description=None, type_name=None, is_generator=False)]

    str_2 = '''
    "
    "
    '''
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == ''
    assert docstring_

# Generated at 2022-06-25 16:34:28.931454
# Unit test for function parse
def test_parse():
    # Test 1: clean
    docstring_1 = parse('''
            Short description.

            Long description.
            ''')
    assert docstring_1.short_description == 'Short description.'
    # Long description should have trailing newline stripped.
    assert docstring_1.long_description == 'Long description.'

    # Test 2: dirty
    docstring_2 = parse('''
            Short description.

            Long description.


            ''')
    assert docstring_2.short_description == 'Short description.'
    # Long description should have trailing newlines stripped.
    assert docstring_2.long_description == 'Long description.'

    # Test 3: no short description
    docstring_3 = parse('''
            Long description.
            ''')
    assert docstring_3.short_description == None
   

# Generated at 2022-06-25 16:34:40.034496
# Unit test for function parse
def test_parse():
    str_0 = """
    """
    docstring_0 = parse(str_0)
    assert type(docstring_0) == Docstring
    str_1 = """
        First line.
    
        Second line.
    """
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'First line.'
    assert docstring_1.long_description == 'Second line.'
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank_after_long_description == False

# Generated at 2022-06-25 16:34:45.423036
# Unit test for function parse
def test_parse():
    # Strings for test cases
    str_0 = ''
    str_1 = 'A docstring.'
    str_2 = 'A short description.\n\nA long description.'
    str_3 = 'A short description.\n\nA long description.\n\n'
    str_4 = 'A short description.\n   \nA long description.\n   \n'
    str_5 = 'A short description.\n\n:param A docstring.\n\n'
    str_6 = 'A short description.\n\n:param A docstring.\n\n:param  A docstring.'
    str_7 = ':param A docstring.'
    str_8 = '   :param A docstring.'

# Generated at 2022-06-25 16:34:54.041146
# Unit test for function parse
def test_parse():
    str_0 = 'V t'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'V t'

    str_1 = '    V t\n'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'V t'

    str_2 = '    V t\n    \n'
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == 'V t'

    str_3 = '    V t\n    \n    \n'
    docstring_3 = parse(str_3)
    assert docstring_3.short_description == 'V t'
    assert docstring_3.blank_after_short_description == True


# Generated at 2022-06-25 16:34:59.418830
# Unit test for function parse

# Generated at 2022-06-25 16:35:29.404226
# Unit test for function parse
def test_parse():
    # test with example 0
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'V t'
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.long_description is None
    assert len(docstring_0.meta) == 0

    # test with example 1
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'V t'
    assert docstring_1.blank_after_short_description is True
    assert docstring_1.blank_after_long_description is False
    assert docstring_1.long_description == 'I am'
    assert len(docstring_1.meta) == 0

    #

# Generated at 2022-06-25 16:35:32.517470
# Unit test for function parse
def test_parse():
    str_0 = ""
    docstring_0 = parse(str_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert not docstring_0.meta



# Generated at 2022-06-25 16:35:42.618640
# Unit test for function parse
def test_parse():
    """
    Function to test 'parse' function
    """

    tests = [
        (
            'Întoarce un iterator peste toate broaștele din colecție.',
            [['b', 'Broasca', 'Anaconda.'], ['c', 'Colectie', 'Genul de broaște.'], ['g', 'Generator', 'Un iterator de broaște.']],
        ),
        (
            'V t',
            [['t', 'T', 'T']],
        ),
        (
            'V',
            [['t', 'T', 'T']],
        )
    ]

    for docstring, expected in tests:
        assert(parse(docstring).short_description == expected[0][2])

#test_parse()

# Generated at 2022-06-25 16:35:49.731980
# Unit test for function parse

# Generated at 2022-06-25 16:35:59.424050
# Unit test for function parse
def test_parse():
    docstring_0 = parse("Single-line docstring")
    docstring_1 = parse("Single-line docstring.")
    docstring_2 = parse("Single-line docstring\n")
    docstring_3 = parse("Single-line docstring.\n")
    docstring_4 = parse("Single-line docstring\n\n")
    docstring_5 = parse("Single-line docstring.\n\n")
    docstring_6 = parse("Single-line docstring\n\nLonger description.")
    docstring_7 = parse("Single-line docstring\n\nLonger description.\n\n")
    docstring_8 = parse("Single-line docstring\n\nLonger description.\n")
    docstring_9 = parse("Single-line docstring\n\nLonger description")

# Generated at 2022-06-25 16:36:06.212711
# Unit test for function parse
def test_parse():
    try:
        string = '''
    This is the short description.

    And this is the long description. It extends all the way to
    this point.
    '''
        docstring = parse(string)
        assert docstring.short_description == "This is the short description."
        assert docstring.long_description == "And this is the long description. It extends all the way to this point."
        assert docstring.blank_after_short_description
        assert docstring.blank_after_long_description
        assert docstring.meta == []
    except ParseError as e:
        print(e)
    string = '''
    This is a docstring.

    :param foo: This is a parameter.
    :type foo: int
    :raises ValueError: If something bad happens.
    '''

    docstring = parse

# Generated at 2022-06-25 16:36:12.370600
# Unit test for function parse
def test_parse():
    # Test 1
    string_1 = ' :param name: Name to print\n        :type name: str\n        :param age: Age to print\n        :type age: int\n        :returns: None\n        :rtype: None\n        '
    docstring = parse(string_1)

    assert docstring.short_description == "None"
    assert docstring.long_description == None
    assert docstring.meta[0] == DocstringParam(args=['param', 'name', 'Name to print'], description='None', arg_name='Name to print', type_name='str', is_optional=None, default=None)

# Generated at 2022-06-25 16:36:19.065139
# Unit test for function parse
def test_parse():
    test_case_0()
    str_1 = """q
    w
    e
    r
    t
    y
    """
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'q'
    assert docstring_1.long_description == 'w\ne\nr\nt\ny'
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank_after_long_description == True
    assert docstring_1.meta == []
    str_2 = """q
    w
    e
    r
    t
    :param a: b
    y
    z
    """
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == 'q'
    assert docstring_

# Generated at 2022-06-25 16:36:26.099814
# Unit test for function parse
def test_parse():
    str_0 = 'Test.'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Test.'
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []

    str_1 = '\nTest.'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Test.'
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.blank_after_long_description == False
    assert docstring_1.meta == []


# Generated at 2022-06-25 16:36:36.293603
# Unit test for function parse
def test_parse():
    print("Testing parse()")
    docstring_0 = parse('V t')
    assert docstring_0.short_description == 'V t'
    assert docstring_0.long_description is None
    assert len(docstring_0.meta) == 0
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    docstring_1 = parse('V t\n   \n')
    assert docstring_1.short_description == 'V t'
    assert docstring_1.long_description is None
    assert len(docstring_1.meta) == 0
    assert docstring_1.blank_after_short_description is False
    assert docstring_1.blank_after_long_description is False

# Generated at 2022-06-25 16:36:51.771131
# Unit test for function parse
def test_parse():
    # test case 0
    # Unit tests for parse
    str_0 = 'V t'
    docstring_0 = parse(str_0)
    assert isinstance(docstring_0, Docstring)
    assert docstring_0.short_description == 'V t'
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.meta == [
        DocstringMeta(
            description='',
            args=[],
        ),
    ]

    # test case 1
    str_0 = 'V t\n'
    docstring_0 = parse(str_0)
    assert isinstance(docstring_0, Docstring)
    assert docstring_0.short

# Generated at 2022-06-25 16:37:02.001724
# Unit test for function parse
def test_parse():
    assert parse('V t').short_description == 'V t'
    assert not parse('V t').long_description
    assert parse('V t\n').short_description == 'V t'
    assert parse('V t\n').long_description == ''
    assert not parse('V t\n').blank_after_short_description
    assert not parse('V t\n').blank_after_long_description
    assert parse('V t\n\n').short_description == 'V t'
    assert parse('V t\n\n').long_description == ''
    assert parse('V t\n\n').blank_after_short_description
    assert not parse('V t\n\n').blank_after_long_description
    assert parse('\nV t').short_description == 'V t'

# Generated at 2022-06-25 16:37:09.232299
# Unit test for function parse
def test_parse():
    str_0 = 'Example of Description'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Example of Description'
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []

    str_1 = 'This is a short description and this is the long one\n' \
            '\n' \
            'And this is more of long description'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'This is a short description and this is the long one'
    assert docstring_1.long_description == 'And this is more of long description'
   

# Generated at 2022-06-25 16:37:18.363401
# Unit test for function parse
def test_parse():
    # test docstring_0
    str_0 = 'V t'
    docstring_0 = parse(str_0)

    # test docstring_1
    str_1 = '\n'
    docstring_1 = parse(str_1)

    # test docstring_2
    str_2 = '    V t\n'
    docstring_2 = parse(str_2)

    # test docstring_3
    str_3 = 'V t\n'
    docstring_3 = parse(str_3)

    # test docstring_4
    str_4 = 'V t\n\n'
    docstring_4 = parse(str_4)

    # test docstring_5
    str_5 = '    V t\n    \n'

# Generated at 2022-06-25 16:37:31.298262
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("xyz") == Docstring(
        short_description="xyz", long_description=None
    )
    assert parse("xyz\n\nabc") == Docstring(
        short_description="xyz",
        long_description="abc",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )
    assert parse(" :arg a: xyz") == Docstring(
        meta=[DocstringParam(arg_name="a", type_name=None, description="xyz")]
    )

# Generated at 2022-06-25 16:37:35.364325
# Unit test for function parse
def test_parse():
    str_0 = """V t"""
    docstring_0 = parse(str_0)
    this_0 = Docstring(
        short_description='V t',
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[]
    )
    assert docstring_0 == this_0



# Generated at 2022-06-25 16:37:46.680753
# Unit test for function parse

# Generated at 2022-06-25 16:37:55.899083
# Unit test for function parse
def test_parse():
    str_0 = 'V t'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'V t'
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.meta == []

    str_1 = 'test short description'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'test short description'
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is False
    assert docstring_1.blank_after_long_description is False
    assert docstring_1.meta == []

    str_

# Generated at 2022-06-25 16:38:08.910406
# Unit test for function parse
def test_parse():
    str_1 = 'V t'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'V t'
    str_2 = 'V t\n\nLong Description.'
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == 'V t'
    assert docstring_2.long_description == 'Long Description.'
    str_3 = 'V t\n\nLong Description.\nMore.'
    docstring_3 = parse(str_3)
    assert docstring_3.short_description == 'V t'
    assert docstring_3.long_description == 'Long Description.\nMore.'
    assert docstring_3.blank_after_short_description == True
    assert docstring_3.blank_after_long_

# Generated at 2022-06-25 16:38:18.871432
# Unit test for function parse
def test_parse():
    str_0 = 'V t'
    assert parse(str_0) == Docstring(
        short_description='V t',
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=None,
        meta=[],
    )

    str_0 = 'V t\n    '
    assert parse(str_0) == Docstring(
        short_description='V t',
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[],
    )

    str_0 = 'V t\n\nWhat what'

# Generated at 2022-06-25 16:38:36.616067
# Unit test for function parse
def test_parse():
    docstring_0 = parse(
        """
        This is a description of the docstring."""
    )
    assert (docstring_0.short_description ==
            'This is a description of the docstring.')
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert len(docstring_0.meta) == 0



# Generated at 2022-06-25 16:38:37.581758
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()



# Generated at 2022-06-25 16:38:41.669082
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-25 16:38:44.438278
# Unit test for function parse
def test_parse():
    assert parse('test with no docstring') == None
    assert parse('V t') == None


# Generated at 2022-06-25 16:38:52.341655
# Unit test for function parse
def test_parse():
    """docstring for function test_parse"""
    str0 = 'V t'
    docstring0 = parse(str0)
    assert docstring0.short_description == 'V t'
    assert docstring0.long_description == None
    assert docstring0.meta == []
    assert str(docstring0) == 'V t'
    assert docstring0.format() == "V t"

    str1 = 'V t\n L t'
    docstring1 = parse(str1)
    assert docstring1.short_description == 'V t'
    assert docstring1.long_description == 'L t'
    assert docstring1.meta == []
    assert docstring1.format() == "V t\n\nL t"

    str2 = '\nV t\n L t'
    docstring2

# Generated at 2022-06-25 16:39:04.219179
# Unit test for function parse
def test_parse():
    doc_string_01 = parse('')
    doc_string_01.short_description
    doc_string_01.short_description == None
    doc_string_01.long_description
    doc_string_01.long_description == None
    doc_string_01.meta
    doc_string_01.meta == []

    doc_string_02 = parse('short description')
    doc_string_02.short_description
    doc_string_02.short_description == 'short description'
    doc_string_02.long_description
    doc_string_02.long_description == None
    doc_string_02.meta
    doc_string_02.meta == []


# Generated at 2022-06-25 16:39:13.608296
# Unit test for function parse
def test_parse():
    docstring_1 = parse(
        'This is the docstring for foo.\n'
        '\n'
        ':param str name: Name of the variable to return.\n'
        ':returns: The variable whose name is given.\n'
        ':rtype: Any\n'
        ':raises ValueError: When a variable with the given name does not exist.\n'
    )

    assert docstring_1.short_description == 'This is the docstring for foo.'
    assert docstring_1.blank_after_short_description is False
    assert docstring_1.long_description == ''
    assert docstring_1.blank_after_long_description is True
    assert len(docstring_1.meta) == 3

# Generated at 2022-06-25 16:39:14.705666
# Unit test for function parse
def test_parse():
    test_case_0()



# Generated at 2022-06-25 16:39:25.316948
# Unit test for function parse
def test_parse():
    assert parse('') == parse('\n') == parse('\n\n')
    assert parse('').short_description is None
    assert parse('').long_description is None
    assert parse('foo').short_description == 'foo'
    assert parse('foo').long_description is None
    assert parse('foo\nbar').short_description == 'foo'
    assert parse('foo\nbar').long_description == 'bar'
    assert parse('foo\n\nbar').short_description == 'foo'
    assert parse('foo\n\nbar').long_description == 'bar'
    assert parse('foo\n\n   bar').short_description == 'foo'
    assert parse('foo\n\n   bar').long_description == 'bar'

# Generated at 2022-06-25 16:39:28.183935
# Unit test for function parse
def test_parse():
    print("Unit test for function parse")
    str_0 = 'V t'
    docstring_0 = parse(str_0)
    answer_0 = Docstring()
    assert docstring_0 == answer_0
    print("Passed")

# Test for file

# Generated at 2022-06-25 16:39:38.114327
# Unit test for function parse
def test_parse():
    from pygments.token import Keyword, Name, Text, Comment, Token
    str_0 = '\n    Returns the sum of two numbers.\n\n    :param x: the first number\n    :param y: the second number\n    :tpe x: int\n    :type y: int\n    :returns: Th sum of two numbers.\n    :rtype: int\n\n    :Example:\n\n    >>> add(1, 1)\n    2\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Returns the sum of two numbers."
    assert docstring_0.long_description == '\n\n    :Example:\n\n    >>> add(1, 1)\n    2'
    assert docstring_0.blank_

# Generated at 2022-06-25 16:39:41.545961
# Unit test for function parse
def test_parse():
    assert True


if __name__ == "__main__":
    import os

    basename = os.path.basename(__file__)
    pytest.main([basename, "-s", "--tb=native"])

# Generated at 2022-06-25 16:39:51.540730
# Unit test for function parse
def test_parse():
    str_0 = '\n    Returns the sum of two numbers.\n\n    :param x: the first number\n    :param y: the second number\n    :tpe x: int\n    :type y: int\n    :returns: Th sum of two numbers.\n    :rtype: int\n\n    :Example:\n\n    >>> add(1, 1)\n    2\n    '

    docstring_0 = parse(str_0)
    assert (docstring_0.short_description == "Returns the sum of two numbers.")
    assert (docstring_0.blank_after_short_description == True)
    assert (docstring_0.blank_after_long_description == True)
    assert (docstring_0.long_description == None)

# Generated at 2022-06-25 16:40:03.659927
# Unit test for function parse
def test_parse():
    str_0 = '\n    Returns the sum of two numbers.\n\n    :param x: the first number\n    :param y: the second number\n    :tpe x: int\n    :type y: int\n    :returns: Th sum of two numbers.\n    :rtype: int\n\n    :Example:\n\n    >>> add(1, 1)\n    2\n    '
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:40:09.159951
# Unit test for function parse
def test_parse():
    from .common import Docstring, DocstringMeta, DocstringParam, \
                        DocstringReturns, DocstringRaises
    docstring = parse(
        """
        Docstring summary line.

        This is a longer description. It can contain formatting and inline
        code.

        :param x: The first parameter.
        :param y: The second parameter.
        :type x: int
        :type y: int
        :param *args: Additional parameters.
        :param **kwargs: Additional keyword parameters.
        :returns: The return value.
        :rtype: int
        :raises ImportError: If something goes wrong during import.
        :raises ValueError: If an invalid value is provided.
        :Example:

        >>> add(1, 2)
        3
        """
    )


# Generated at 2022-06-25 16:40:16.667263
# Unit test for function parse
def test_parse():
    """Test function parse
    """

    # Test function parse normal case 1
    # Tests a normal case docstring with everything.

    # Test function parse normal case 2
    # Tests a normal case docstring without any metadata.

    # Test function parse error case 3
    # Tests an error case docstring without a colon.

    # Test function parse error case 4
    # Tests an error case docstring without a colon.

    # Test function parse error case 5
    # Tests an error case docstring with double colons.

    # Test function parse error case 6
    # Tests an error case docstring with double colons.

    # Test function parse error case 7
    # Tests an error case docstring with double colons.

    # Test function parse error case 8
    # Tests an error case docstring with double colons.

    # Test function parse error case 9
    #

# Generated at 2022-06-25 16:40:24.620636
# Unit test for function parse
def test_parse():
    # Test simple case
    str_1 = '\n    Returns the sum of two numbers.\n\n    :param x: the first number\n    :param y: the second number\n    :type x: int\n    :type y: int\n    :returns: Th sum of two numbers.\n    :rtype: int\n\n    :Example:\n\n    >>> add(1, 1)\n    2\n    '
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Returns the sum of two numbers.'
    assert docstring_1.long_description == 'Example:\n\n    >>> add(1, 1)\n    2'
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank_after_

# Generated at 2022-06-25 16:40:25.129734
# Unit test for function parse
def test_parse():
    assert True

# Generated at 2022-06-25 16:40:31.764373
# Unit test for function parse
def test_parse():
    assert docstring_0.long_description == 'Returns the sum of two numbers.\n\n    :Example:\n\n    >>> add(1, 1)\n    2\n    ', 'Expected different value for "docstring_0.long_description"'
    assert docstring_0.short_description == 'Returns the sum of two numbers', 'Expected different value for "docstring_0.short_description"'
    assert docstring_0.blank_after_short_description, 'Expected different value for "docstring_0.blank_after_short_description"'
    assert not docstring_0.blank_after_long_description, 'Expected different value for "docstring_0.blank_after_long_description"'

# Generated at 2022-06-25 16:40:44.139159
# Unit test for function parse
def test_parse():
    """
    test_parse
    """
    str_0 = '\n    Returns the sum of two numbers.\n\n    :param x: the first number\n    :param y: the second number\n    :tpe x: int\n    :type y: int\n    :returns: Th sum of two numbers.\n    :rtype: int\n\n    :Example:\n\n    >>> add(1, 1)\n    2\n    '
    docstring_1 = parse(str_0)
    assert docstring_1.short_description == 'Returns the sum of two numbers.'
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.blank_after_long_description == True

# Generated at 2022-06-25 16:40:56.239537
# Unit test for function parse
def test_parse():
    import unittest
    import doctest
    from .common import Docstring, DocstringMeta, DocstringParam, DocstringRaises, DocstringReturns
    from .rest import parse

    class ParseTest(unittest.TestCase):
        def test_doc1(self):
            """Test a basic docstring"""
            doc1 = 'This is a long\ndescription of a function.\n'
            doc1 += '\nIt also has some\nmulti-line\nsections.\n'
            d = parse(doc1)
            self.assertEqual(d.short_description, 'This is a long')
            self.assertEqual(d.long_description, 'description of a function.\n\nIt also has some\nmulti-line\nsections.')

# Generated at 2022-06-25 16:40:58.125240
# Unit test for function parse
def test_parse():
    test_case_0()

# Calls the above functions with interesting inputs.

# Generated at 2022-06-25 16:41:06.344254
# Unit test for function parse
def test_parse():
    str_0 = '\n    Returns the sum of two numbers.\n\n    :param x: the first number\n    :param y: the second number\n    :tpe x: int\n    :type y: int\n    :returns: Th sum of two numbers.\n    :rtype: int\n\n    :Example:\n\n    >>> add(1, 1)\n    2\n    '
    ret_0 = parse(str_0)

# Generated at 2022-06-25 16:41:15.156985
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse(" ") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n ") == Docstring()
    assert parse(" \n \n ") == Docstring()

    ds = parse("This is a short description")
    assert ds == Docstring(
        short_description="This is a short description",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

    ds = parse("This is a short description.\n")

# Generated at 2022-06-25 16:41:17.856832
# Unit test for function parse
def test_parse():
    test_case_0()


# Main function

# Generated at 2022-06-25 16:41:27.046934
# Unit test for function parse
def test_parse():
    str_1 = '\n    Returns the sum of two numbers.\n\n    :param x: the first number\n    :param y: the second number\n    :type x: int\n    :type y: int\n    :returns: Th sum of two numbers.\n    :rtype: int\n\n    :Example:\n\n    >>> add(1, 1)\n    2\n    '
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Returns the sum of two numbers.'
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank_after_long_description == True
    assert docstring_1.long_description == 'Example:\n\n>>> add(1, 1)\n2'
    doc

# Generated at 2022-06-25 16:41:39.003673
# Unit test for function parse
def test_parse():
    
    # Base test
    print("Base case:")
    print(parse.__doc__)
    print("\n")

    # Edge case 1
    print("Edge case 1:")
    str_1 = ""
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == None
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank_after_long_description == True
    assert docstring_1.meta == []
    print(docstring_1.short_description)
    print(docstring_1.long_description)
    print(docstring_1.blank_after_short_description)
    print(docstring_1.blank_after_long_description)
   

# Generated at 2022-06-25 16:41:49.145729
# Unit test for function parse
def test_parse():
    str_0 = '\n    Returns the sum of two numbers.\n\n    :param x: the first number\n    :param y: the second number\n    :tpe x: int\n    :type y: int\n    :returns: Th sum of two numbers.\n    :rtype: int\n\n    :Example:\n\n    >>> add(1, 1)\n    2\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Returns the sum of two numbers.'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.long_description == 'Example:\n\n>>> add(1, 1)\n2'
    assert docstring_0.blank_after_long_description == True
   

# Generated at 2022-06-25 16:41:56.925219
# Unit test for function parse
def test_parse():

    # Test 1/2/3.
    assert (parse("").short_description == None)
    assert (parse("").long_description == None)
    assert (parse("").meta == [])

    # Test 4/5.
    assert (parse("Hello, world!").short_description == "Hello, world!")
    assert (parse("Hello, world!").long_description == None)

    # Test 6.
    assert (parse("Hello, world!\n\nTest.").short_description == "Hello, world!")
    assert (parse("Hello, world!\n\nTest.").long_description == "Test.")

    # Test 7.
    assert (parse("Hello, world!\n\n\nTest.").short_description == "Hello, world!")

# Generated at 2022-06-25 16:42:01.603163
# Unit test for function parse
def test_parse():
    test_case_0()

# Program entry point
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:42:14.577636
# Unit test for function parse
def test_parse():
    # Test Case 0
    str_0 = '\n    Returns the sum of two numbers.\n\n    :param x: the first number\n    :param y: the second number\n    :tpe x: int\n    :type y: int\n    :returns: Th sum of two numbers.\n    :rtype: int\n\n    :Example:\n\n    >>> add(1, 1)\n    2\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Returns the sum of two numbers."
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_long_description == False

# Generated at 2022-06-25 16:42:26.188582
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring(short_description=None, long_description=None,
                                  blank_after_short_description=False,
                                  blank_after_long_description=False,
                                  meta=[]), 'Empty string'
    assert parse('   ') == Docstring(short_description=None, long_description=None,
                                     blank_after_short_description=False,
                                     blank_after_long_description=False,
                                     meta=[]), 'Empty string'
    assert parse('\n') == Docstring(short_description=None, long_description=None,
                                    blank_after_short_description=False,
                                    blank_after_long_description=False,
                                    meta=[]), 'Empty string'

# Generated at 2022-06-25 16:42:35.737350
# Unit test for function parse
def test_parse():
    str_0 = "Returns the sum of two numbers."
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Returns the sum of two numbers."
    assert docstring_0.long_description is None
    assert not docstring_0.meta

    str_1 = (
        "Returns the sum of two numbers.\n\n    :param x: the first number"
        "\n    :param y: the second number\n    :type x: int"
        "\n    :type y: int\n    :returns: The sum of two numbers."
        "\n    :rtype: int\n\n    :Example:\n\n    >>> add(1, 1)\n    2"
    )
    docstring_1 = parse(str_1)
    assert docstring_1

# Generated at 2022-06-25 16:42:37.890722
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:42:38.869007
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:42:46.592095
# Unit test for function parse
def test_parse():

    str_1 = '\n    Returns the sum of two numbers.\n\n    :param x: the first number\n    :param y: the second number\n    :tpe x: int\n    :type y: int\n    :returns: Th sum of two numbers.\n    :rtype: int\n\n    :Example:\n\n    >>> add(1, 1)\n    2\n    '
    docstring_1 = parse(str_1)
    assert docstring_1.meta[0].arg_name == 'x'
    assert docstring_1.meta[1].arg_name == 'y'
    assert docstring_1.meta[2].arg_name == None
    assert docstring_1.meta[3].arg_name == None

# Generated at 2022-06-25 16:42:56.685502
# Unit test for function parse
def test_parse():
    str_0 = "Simple\n\n"
    docstring_0 = parse(str_0)

    str_1 = "Simple with\n\n"
    docstring_1 = parse(str_1)

    str_2 = "Simple with\n\n\n"
    docstring_2 = parse(str_2)

    str_3 = '\n    Returns the sum of two numbers.\n    '
    docstring_3 = parse(str_3)

    str_4 = '\n    Returns the sum of two numbers.\n\n    >>> add(1, 2)\n    3\n    '
    docstring_4 = parse(str_4)

    str_5 = '\n    Returns the sum of two numbers.\n\n    :param x: The first number\n    '
   

# Generated at 2022-06-25 16:43:06.904330
# Unit test for function parse
def test_parse():
    str_0 = '\n    Returns the sum of two numbers.\n\n    :param x: the first number\n    :param y: the second number\n    :tpe x: int\n    :type y: int\n    :returns: Th sum of two numbers.\n    :rtype: int\n\n    :Example:\n\n    >>> add(1, 1)\n    2\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Returns the sum of two numbers."
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_long_description == False

# Generated at 2022-06-25 16:43:14.508586
# Unit test for function parse

# Generated at 2022-06-25 16:43:24.713679
# Unit test for function parse
def test_parse():
    # Example 0
    str_0 = '\n    Returns the sum of two numbers.\n\n    :param x: the first number\n    :param y: the second number\n    :tpe x: int\n    :type y: int\n    :returns: Th sum of two numbers.\n    :rtype: int\n\n    :Example:\n\n    >>> add(1, 1)\n    2\n    '
    docstring_0 = parse(str_0)