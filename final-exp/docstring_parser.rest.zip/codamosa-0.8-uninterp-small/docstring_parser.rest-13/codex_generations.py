

# Generated at 2022-06-25 16:33:55.742496
# Unit test for function parse
def test_parse():
    str_0 = '&\\Xtfi<eNLmm'
    str_1 = 'Sum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    docstring_0 = parse(str_0)
    docstring_1 = parse(str_1)
    assert docstring_0.short_description == '&\\Xtfi<eNLmm'
    assert docstring_0.long_description == '&\\Xtfi<eNLmm'
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_1.short_description == 'Sum of two numbers.'

# Generated at 2022-06-25 16:34:03.715294
# Unit test for function parse
def test_parse():
    str = 'Returns: str: The title of the report.'
    docstring = parse(str)
    assert(docstring.short_description == None)
    assert(docstring.long_description == None)
    assert(docstring.meta[0].args == ['Returns', 'str'])
    assert(docstring.meta[0].type_name == 'str')
    assert(docstring.meta[0].description == 'The title of the report.')
    assert(docstring.meta[0].is_generator == False)


# Generated at 2022-06-25 16:34:07.009469
# Unit test for function parse
def test_parse():
    str_0 = '"""'
    docstring_0 = parse(str_0)
    # Test for proper creation of the docstring
    assert docstring_0 != None


# Generated at 2022-06-25 16:34:15.095337
# Unit test for function parse
def test_parse():
    # Test 1
    str_0 = 'A trivial example with no metadata'
    docstring_0 = parse(str_0)
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.short_description == 'A trivial example with no metadata'
    assert len(docstring_0.meta) == 0

    # Test 2
    str_0 = 'A trivial example with no metadata\n'
    docstring_0 = parse(str_0)
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == True
    assert docstring_

# Generated at 2022-06-25 16:34:17.454113
# Unit test for function parse
def test_parse():
    test_case_0()

# Generate a list of all the test functions

# Generated at 2022-06-25 16:34:28.966735
# Unit test for function parse
def test_parse():
    str_0 = '&\\Xtfi<eNLmm'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True
    assert len(docstring_0.meta) == 0
    str_1 = ':param: nwjbwpMh\n\nqp'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == None
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short_description == False

# Generated at 2022-06-25 16:34:40.063565
# Unit test for function parse
def test_parse():
    """Test function parse.
    """
    test_case_0()

if __name__ == '__main__':
    import types
    import pydoc
    for name, obj in inspect.getmembers(types.ModuleType(__name__)):
        if isinstance(obj, types.FunctionType):
            if hasattr(obj, '__doc__'):
                obj_name = obj.__doc__.split('\n')[0]
                obj_desc = '\n'.join(obj.__doc__.split('\n')[1:])
                if obj_name == 'test_case_0':
                    print(obj_name)
                    print(obj_desc)
                    obj()
                    print('=' * 20)

# Generated at 2022-06-25 16:34:45.434182
# Unit test for function parse
def test_parse():
    # This test is expected to fail until you fix the parse function.
    str_0 = '&\\Xtfi<eNLmm'
    docstring_0 = parse(str_0)
    try:
        assert docstring_0.short_description is None
        assert docstring_0.long_description is None
        assert docstring_0.blank_after_short_description is False
        assert docstring_0.blank_after_long_description is False
        assert docstring_0.meta == []
    except AssertionError:
        print("short_description is {}, expected None".format(
            docstring_0.short_description))
        print("long_description is {}, expected None".format(
            docstring_0.long_description))

# Generated at 2022-06-25 16:34:54.041127
# Unit test for function parse
def test_parse():
    str_0 = '&\\Xtfi<eNLmm'
    docstring_0 = parse(str_0)

    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert len(docstring_0.meta) == 0


# Generated at 2022-06-25 16:34:59.413170
# Unit test for function parse
def test_parse():
    str_0 = '&\\Xtfi<eNLmm'
    docstring_0 = parse(str_0)
    str_1 = '  okeJz&HZ<:lC,'
    docstring_1 = parse(str_1)
    str_2 = '\n<Uh>YydD`X,\n6qm\n  '
    docstring_2 = parse(str_2)
    str_3 = '}X\\x,BJ]N!@(Z\n-E:s\n  '
    docstring_3 = parse(str_3)
    str_4 = '&z\nK@[uVn-qB\n&V*\n  d'
    docstring_4 = parse(str_4)

# Generated at 2022-06-25 16:35:16.624607
# Unit test for function parse
def test_parse():
    # Test case 0
    str_0 = 'Test function parse.'
    print('str_0 = {}'.format(str_0))
    result = parse(str_0)
    assert result.short_description == 'Test function parse.'
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == False
    assert result.long_description == None
    assert len(result.meta) == 0
    print('Test case 0 passed.')

    # Test case 1
    str_1 = 'Test function parse.\n    '
    print('str_1 = {}'.format(str_1))
    result = parse(str_1)
    assert result.short_description == 'Test function parse.'
    assert result.blank_after_short_description == True
    assert result.blank_after_

# Generated at 2022-06-25 16:35:28.601757
# Unit test for function parse
def test_parse():
    text_0 = "Test function parse.\n"
    text_1 = "Test function parse.\n"
    text_2 = "Test function parse.\n  \n    Test function parse.\n"
    text_3 = "Test function parse.\n  \n    Test function parse.\n  \n"
    text_4 = "Test function parse.\n  \n    Test function parse.\n  \n  \n"
    text_5 = "Test function parse.\n  \n    Test function parse.\n  \n      \n"
    text_6 = "Test function parse.\n  \n    Test function parse.\n  \n"
    text_7 = "Test function parse.\n  \n    Test function parse.\n  \n  \n"
    text_

# Generated at 2022-06-25 16:35:30.166953
# Unit test for function parse
def test_parse():
    test_case_0()
    # TODO: Define unit test

# Generated at 2022-06-25 16:35:40.719965
# Unit test for function parse
def test_parse():
    # Test 0
    str_0 = """
    Test function parse.

    It has a short description and a long one.

    The short description should be in the first one.

    :param a_very_long_name_that_make_the_line_break: a short description.
    :param a_very_long_name_that_make_the_line_break: a long description.
    It is wrapped during parsing.
    """

    result_0 = parse(str_0)
    print(result_0)
    assert result_0.short_description == 'Test function parse.'
    assert result_0.blank_after_short_description == True
    assert result_0.blank_after_long_description == False

# Generated at 2022-06-25 16:35:43.191035
# Unit test for function parse
def test_parse():
    assert parse(str_0) == 'Test function parse.'


if __name__ == '__main__':
    print('Initializing test docstring...')
    print(parse(str_0))

# Generated at 2022-06-25 16:35:50.015498
# Unit test for function parse

# Generated at 2022-06-25 16:35:59.567006
# Unit test for function parse
def test_parse():
    input_0 = 'Test function parse.\n    '
    # output_0 = '    Test function parse.'
    expected_0 = '    Test function parse.'
    actual_0 = inspect.cleandoc(input_0)
    assert actual_0 == expected_0, 'Expected "%s", but got "%s"' %(expected_0, actual_0)
    # print(actual_0)
    input_1 = 'Test function parse.\n'
    actual_1 = inspect.cleandoc(input_1)
    assert input_1 == actual_1, 'Expected "%s", but got "%s"' %(input_1, actual_1)
    # print(actual_1)
    input_2 = 'Test function parse.\n     '
    expected_2 = 'Test function parse.'

# Generated at 2022-06-25 16:36:00.474441
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:36:03.821585
# Unit test for function parse
def test_parse():
    from docstring_parse import parse
    print(parse(inspect.getsource(parse)))
    print(parse(inspect.getsource(test_parse)))
    print(parse(inspect.getsource(test_case_0)))

# Generated at 2022-06-25 16:36:15.994080
# Unit test for function parse
def test_parse():
    print('Test function parse:\n')
    #get parse from function parse, function parse must on the first line.
    str_0 = 'Test function parse.\n    '
    str_1 = 'Test function parse.\n'
    str_2 = 'Test function parse.'
    str_3 = 'Test function parse.  \n'
    str_4 = 'Test function parse.  \n    '
    str_5 = 'Test function parse\n    This is a test function parse.\n'


    print(parse(str_0), '\n')
    print(parse(str_1), '\n')
    print(parse(str_2), '\n')
    print(parse(str_3), '\n')
    print(parse(str_4), '\n')

# Generated at 2022-06-25 16:36:46.991506
# Unit test for function parse
def test_parse():
    assert parse('Test function parse.') == parse('Test function parse.')
    # assert parse('Test function parse.') == parse('Test function parse.')
    # assert parse('Test function parse.\n    ') == parse('Test function parse.\n    ')
    # assert parse('Test function parse.\n    ') == parse('Test function parse.\n    ')
    # assert parse('Test function parse.\n\n    ') == parse('Test function parse.\n\n    ')
    # assert parse('Test function parse.\n\n    ') == parse('Test function parse.\n\n    ')
    # assert parse('Test function parse.\n\n\n    ') == parse('Test function parse.\n\n\n    ')
    # assert parse('Test function parse.\n

# Generated at 2022-06-25 16:36:57.657299
# Unit test for function parse
def test_parse():
    str_0 = 'Test function parse.\n    '
    str_1 = 'Test function parse.\n\n'
    str_2 = 'Test function parse.\n\n:arg arg1: arg1 desc.\n\n'
    str_3 = 'Test function parse.\n\n:arg arg1: arg1 desc.\n:arg arg2: arg2 desc.\n\n'
    str_4 = 'Test function parse.\n\n:arg arg1: arg1 desc.\n:arg arg2: arg2 desc.\n\n:returns: ret desc.'

# Generated at 2022-06-25 16:37:07.349298
# Unit test for function parse
def test_parse():
    str_1 = 'Test function parse.\n    '
    assert(parse(str_1).short_description == 'Test function parse.')
    assert(parse(str_1).long_description is None)
    assert(parse(str_1).blank_after_short_description)
    assert(parse(str_1).blank_after_long_description)

    str_2 = 'Test function parse.\n\nlong desc'
    assert(parse(str_2).long_description == 'long desc')
    assert(parse(str_2).blank_after_long_description)

    str_3 = 'Test function parse.\n\nlong desc\n\n'
    assert(parse(str_3).long_description == 'long desc')
    assert(parse(str_3).blank_after_long_description)



# Generated at 2022-06-25 16:37:16.568435
# Unit test for function parse
def test_parse():
    # Test case 0 [lower bound]
    str_0 = 'Test function parse.\n    '
    doc_0 = parse(str_0)
    print(doc_0.short_description)
    print(doc_0.long_description)
    print(doc_0.blank_after_short_description)
    print(doc_0.blank_after_long_description)
    for meta in doc_0.meta:
        print(meta.args)
        print(meta.description)
        print(meta.arg_name)
        print(meta.type_name)
        print(meta.is_optional)
        print(meta.default)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:37:28.494119
# Unit test for function parse
def test_parse():
    doc = '''
    Test function parse.

    This function does absolutely nothing.

    :param str foo: A string
    :returns str: A string

    '''
    docstring = parse(doc)
    assert docstring.short_description == "Test function parse."
    assert docstring.long_description == "This function does absolutely nothing."
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert isinstance(docstring.meta[0], DocstringParam)
    assert docstring.meta[0].arg_name == "foo"
    assert docstring.meta[0].type_name == "str"
    assert isinstance(docstring.meta[1], DocstringReturns)
    assert docstring.meta

# Generated at 2022-06-25 16:37:36.940383
# Unit test for function parse
def test_parse():
    print('Testing function parse...', end='')
    # test case 0
    str_0 = '''Test function parse.
    '''
    assert parse(str_0) == Docstring(short_description='Test function parse.', long_description=None, blank_after_short_description=True, blank_after_long_description=True, meta=[DocstringMeta(args=[], description=None)])

    # test case 1
    str_1 = '''
    '''
    assert parse(str_1) == Docstring(short_description=None, long_description=None, blank_after_short_description=True, blank_after_long_description=True, meta=[DocstringMeta(args=[], description=None)])

    # test case 2
    str_2 = '''
    '''

# Generated at 2022-06-25 16:37:45.369866
# Unit test for function parse
def test_parse():
    from .common import Docstring, DocstringMeta, DocstringParam, DocstringRaises, DocstringReturns
    from .common import ParseError


# Generated at 2022-06-25 16:37:55.125000
# Unit test for function parse
def test_parse():
    assert parse('Test function parse.\n    ')
    assert parse('Test function parse.\n'
                '    This is a test of the parse function.\n'
                '    :param users: List of names of users.\n'
                '    :return: Number of users.\n    ')
    assert parse('Test function parse with a docstring that\n'
                'spans multiple lines of the source file.\n'
                '    This is a test of the parse function.\n'
                '    :param users: List of names of users.\n'
                '    :return: Number of users.\n    ')
    assert parse('Test function parse.\n    ')

# Generated at 2022-06-25 16:37:57.238182
# Unit test for function parse
def test_parse():
    str_0 = 'Test function parse.\n    '
    doc_string = parse(str_0)
    print(doc_string)


# Generated at 2022-06-25 16:38:05.813303
# Unit test for function parse
def test_parse():
    str_0 = """
    Parse rest style docstrings into Docstring instances.

    :return: parsed docstring
    :rtype: Docstring
    """
    doc = parse(str_0)
    assert doc.short_description == "Parse rest style docstrings into Docstring instances."
    assert doc.long_description == ":return: parsed docstring\n:rtype: Docstring"
    assert doc.meta == [DocstringMeta(args=['return'], description=": parsed docstring"),
                        DocstringMeta(args=['rtype'], description=": Docstring")]


# Generated at 2022-06-25 16:38:27.762415
# Unit test for function parse
def test_parse():
    str_0 = 'Sum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Sum of two numbers.'
    assert docstring_0.long_description == ''
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.blank_after_short_description == True
    assert len(docstring_0.meta) == 3
    assert docstring_0.meta[0].key == 'param'
    assert docstring_0.meta[0].type_name == 'a'
    assert docstring_0.meta[0].description == 'first number'

# Generated at 2022-06-25 16:38:36.682778
# Unit test for function parse
def test_parse():
    # Test with docstring just a short description
    docstring = parse('Sum of two numbers.')
    assert docstring.short_description == 'Sum of two numbers.'
    assert docstring.blank_after_short_description is False
    assert docstring.long_description is None
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []

    # Test with docstring short description with a newline following it
    docstring = parse('Sum of two numbers.\n')
    assert docstring.short_description == 'Sum of two numbers.'
    assert docstring.blank_after_short_description is True
    assert docstring.long_description is None
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []

    # Test with docstring short description with a newline and

# Generated at 2022-06-25 16:38:45.111371
# Unit test for function parse

# Generated at 2022-06-25 16:38:55.251590
# Unit test for function parse
def test_parse():
    print("Test parse")

    # Arrange
    # None docstring
    str_none = ''
    # Simple docstring
    str_simple = 'Simple docstring.'
    # Basic docstring
    str_basic = 'Basic docstring.\n\nDescription of function.'
    # Detailed docstring
    str_detailed = 'Detailed docstring.\n\nDescription of function.\n\n' + \
                   'Long description of function.\n\n:param x: int.\n' + \
                   ':raises TypeError: if x is not an int.\n:returns: True if x > 10.'

    # Act
    docstring_none = parse(str_none)
    docstring_simple = parse(str_simple)
    docstring_basic = parse(str_basic)
    docstring_

# Generated at 2022-06-25 16:38:58.251878
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod(verbose=True)


if __name__ == "__main__":
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:39:06.373159
# Unit test for function parse
def test_parse():
    str_0 = 'Sum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    docstring_0 = parse(str_0)
    str_1 = 'Sum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    docstring_1 = parse(str_1)
    assert docstring_0 == docstring_1

test_parse()

# Generated at 2022-06-25 16:39:07.377833
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:39:14.346680
# Unit test for function parse
def test_parse():
    str_0 = 'Sum of two numbers.\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Sum of two numbers."
    assert len(docstring_0.meta) == 3
    assert docstring_0.meta[0].key == "param"
    assert docstring_0.meta[0].arg_name == "a"
    assert docstring_0.meta[0].type_name == None
    assert docstring_0.meta[0].is_optional == None
    assert docstring_0.meta[0].default == None
    assert docstring_0.meta[0].description == "first number"

# Generated at 2022-06-25 16:39:25.036839
# Unit test for function parse
def test_parse():
    string = 'Sum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    docstring = parse(string)
    assert docstring.short_description == 'Sum of two numbers.'
    assert docstring.long_description == None
    assert docstring.meta[0].args[0] == 'param'
    assert docstring.meta[0].args[1] == 'a'
    assert docstring.meta[0].args[2] == 'first number'
    assert docstring.meta[0].description == 'first number'
    assert docstring.meta[1].args[0] == 'param'
    assert docstring.meta[1].args[1] == 'b'

# Generated at 2022-06-25 16:39:33.283574
# Unit test for function parse
def test_parse():
    # Test case 1
    str_1 = 'Sum of two numbers.\n'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Sum of two numbers.'
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is False
    assert docstring_1.blank_after_long_description is False
    assert docstring_1.meta == []

    # Test case 4
    str_4 = 'Sum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    docstring_4 = parse(str_4)
    assert docstring_4.short_description == 'Sum of two numbers.'
   

# Generated at 2022-06-25 16:39:50.169971
# Unit test for function parse
def test_parse():
    # Test 0
    assert(parse(''))
    # Test 1
    str_0 = '\nSum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    docstring_0 = parse(str_0)
    assert(docstring_0.short_description == 'Sum of two numbers.')
    assert(docstring_0.long_description == None)
    assert(len(docstring_0.meta) == 2)
    assert(len(docstring_0.meta[0].args) == 2)
    assert(docstring_0.meta[0].type_name == None)
    assert(docstring_0.meta[1].type_name == 'sum of a and b')



# Generated at 2022-06-25 16:39:58.328659
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring(
                                 short_description=None,
                                 blank_after_short_description=False,
                                 long_description=None,
                                 blank_after_long_description=False,
                                 meta=[]
                                )
    assert parse('\n') == Docstring(
                                 short_description=None,
                                 blank_after_short_description=False,
                                 long_description=None,
                                 blank_after_long_description=False,
                                 meta=[]
                                )

# Generated at 2022-06-25 16:40:05.376470
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == "__main__":
    test_parse()
"""ReST-style docstring parsing."""

import inspect
import re
import typing as T

from .common import (
    PARAM_KEYWORDS,
    RAISES_KEYWORDS,
    RETURNS_KEYWORDS,
    YIELDS_KEYWORDS,
    Docstring,
    DocstringMeta,
    DocstringParam,
    DocstringRaises,
    DocstringReturns,
    ParseError,
)



# Generated at 2022-06-25 16:40:09.329595
# Unit test for function parse
def test_parse():
    test_case_0()

# Run the test
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:40:10.340562
# Unit test for function parse
def test_parse():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 16:40:12.233684
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:40:21.830409
# Unit test for function parse
def test_parse():
    str_0 = 'Sum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Sum of two numbers.'
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == True
    assert len(docstring_0.meta) == 3
    assert docstring_0.meta[0].args == ['param', 'a', 'first']
    assert docstring_0.meta[0].description == 'number'

# Generated at 2022-06-25 16:40:31.751489
# Unit test for function parse
def test_parse():
    str_0 = 'Sum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    docstring_0 = parse(str_0)
    str_1 = 'Sum of two numbers.\n\n\n    :param a: first number\n    :type a: float\n    :param b: second number\n    :returns: sum of a and b\n\n'
    docstring_1 = parse(str_1)
    str_2 = 'Sum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    docstring_2 = parse(str_2)

# Generated at 2022-06-25 16:40:38.038458
# Unit test for function parse
def test_parse():
    print("Testing function parse")
    input_string = '''
    title

        subtitle

            paragraph
    '''
    print(input_string)
    print(parse(input_string))


# Generated at 2022-06-25 16:40:39.596191
# Unit test for function parse
def test_parse():
    # Test cases
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:40:56.972067
# Unit test for function parse
def test_parse():
    # Checks if the types are correct.

    # self.assertEqual(expected, parse(text))
    raise NotImplementedError(
        "Tests for parse need to be written"
    )

# Generated at 2022-06-25 16:41:05.970353
# Unit test for function parse
def test_parse():
    str_0 = 'Sum of two numbers.\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Sum of two numbers."
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description
    assert not docstring_0.blank_after_long_description
    assert docstring_0.meta[0].arg_name == "a"
    assert docstring_0.meta[1].arg_name == "b"
    assert docstring_0.meta[2].type_name == "sum of a and b"

    str_1 = 'Sum of two numbers.'
    doc

# Generated at 2022-06-25 16:41:09.562594
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    # Run the above test cases
    test_parse()

# Generated at 2022-06-25 16:41:20.066338
# Unit test for function parse
def test_parse():
    res = parse('Sum of two numbers.')
    assert res.short_description == 'Sum of two numbers.'
    assert res.long_description is None
    assert not res.meta
    
    res = parse('Sum of two numbers.\n\nArgs:\n    a: first number\n    b: second number\n\n')
    assert res.short_description == 'Sum of two numbers.'
    assert not res.blank_after_short_description
    assert not res.blank_after_long_description
    assert res.long_description is None
    assert len(res.meta) == 2
    assert res.meta[0].arg_name == 'a'
    assert res.meta[0].description == 'first number'
    assert res.meta[1].arg_name == 'b'
    assert res.meta[1].description

# Generated at 2022-06-25 16:41:28.864136
# Unit test for function parse
def test_parse():
    docstring_0 = parse('Sum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n')
    assert (docstring_0.long_description is None)

    docstring_1 = parse('Sum of two numbers.\n\n\n Usage:\n\n $ python sum.py 1 , 2\n 3\n')
    assert (docstring_1.long_description is None)

    docstring_2 = parse('Sum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n')
    assert (len(docstring_2.meta) == 3)



# Generated at 2022-06-25 16:41:29.811701
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:41:30.318376
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-25 16:41:40.734630
# Unit test for function parse
def test_parse():
    str_0 = 'Sum of two numbers.\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    str_1 = 'Sum of two numbers.\n\n    :param x: first number\n    :param y: second number\n    :returns: sum of x and y\n\n'
    str_2 = 'Sum of two numbers.\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    str_3 = 'Sum of two numbers.\n\n    :param x: first number\n    :param y: second number\n    :returns: sum of x and y\n\n'
    str_

# Generated at 2022-06-25 16:41:50.409354
# Unit test for function parse
def test_parse():
    str_0 = 'Sum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    assert parse(str_0).short_description == r'Sum of two numbers.'
    assert parse(str_0).long_description == r''
    assert parse(str_0).blank_after_short_description == rFalse
    assert parse(str_0).blank_after_long_description == rFalse
    assert parse(str_0).meta[0].args == r'param', r'a'
    assert parse(str_0).meta[0].description == r'first number'
    assert parse(str_0).meta[0].returns == None
    assert parse(str_0).meta[0].param_type

# Generated at 2022-06-25 16:41:57.158071
# Unit test for function parse
def test_parse():
    str_1 = 'Sum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    docstring_1 = parse(str_1)

# Generated at 2022-06-25 16:42:13.159925
# Unit test for function parse
def test_parse():
    str_0 = 'Sum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    result_0 = parse(str_0)
    assert result_0.long_description == 'Sum of two numbers.'


# Generated at 2022-06-25 16:42:14.355893
# Unit test for function parse
def test_parse():
    test_case_0()


# Generated at 2022-06-25 16:42:26.009740
# Unit test for function parse
def test_parse():
    str_0 = 'Sum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Sum of two numbers.', 'Programming error in function parse'
    assert docstring_0.long_description == '\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n', 'Programming error in function parse'
    assert docstring_0.blank_after_short_description == False, 'Programming error in function parse'
    assert docstring_0.blank_after_long_description == False, 'Programming error in function parse'


# Generated at 2022-06-25 16:42:27.248708
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:42:37.179338
# Unit test for function parse
def test_parse():
    str = 'Sum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    docstring_0 = parse(str)
    assert docstring_0.short_description == 'Sum of two numbers.'
    assert docstring_0.long_description == '\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True
    assert isinstance(docstring_0.meta[0], DocstringParam)
    assert isinstance(docstring_0.meta[1], DocstringParam)

# Generated at 2022-06-25 16:42:38.973861
# Unit test for function parse
def test_parse():
    print ('Testing function: parse')
    print ('==================')
    test_case_0()


# Generated at 2022-06-25 16:42:39.861117
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:42:47.309344
# Unit test for function parse
def test_parse():
    """
    Test for the function parse
    """
    docstring_0 = parse('First Bank of the United States.')
    assert docstring_0.short_description == 'First Bank of the United States'
    assert docstring_0.long_description == None

    str_0 = 'Sum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Sum of two numbers'
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == True

# Generated at 2022-06-25 16:42:57.203437
# Unit test for function parse
def test_parse():

    str_0 = 'Sum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:43:07.189792
# Unit test for function parse
def test_parse():
    # test case0
    str_0 = 'Sum of two numbers.\n\n\n    :param a: first number\n    :param b: second number\n    :returns: sum of a and b\n\n'

# Generated at 2022-06-25 16:43:24.087248
# Unit test for function parse
def test_parse():
    test_case_0()



if __name__ == "__main__":
    test_parse()