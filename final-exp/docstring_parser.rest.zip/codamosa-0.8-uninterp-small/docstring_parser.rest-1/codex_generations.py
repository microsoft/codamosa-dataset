

# Generated at 2022-06-25 16:33:53.990283
# Unit test for function parse
def test_parse():
    docstring_0 = parse('Z,')
    docstring_1 = parse('Z,')
    docstring_2 = parse('Z,')
    docstring_3 = parse('Z,')
    docstring_4 = parse('Z,')
    docstring_5 = parse('Z,')
    docstring_6 = parse('Z,')
    docstring_7 = parse('Z,')
    assert docstring_0.short_description == 'Z,'
    assert docstring_1.long_description == None
    assert docstring_2.blank_after_short_description == None
    assert docstring_3.blank_after_long_description == None
    assert docstring_4.meta == []
    assert docstring_5.long_description == None
    assert docstring_6.meta == []
    assert docstring_7

# Generated at 2022-06-25 16:34:05.373690
# Unit test for function parse

# Generated at 2022-06-25 16:34:15.986935
# Unit test for function parse
def test_parse():

    str_1 = '''
    This is a function.
    '''

    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'This is a function.'
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is False
    assert docstring_1.blank_after_long_description is False
    assert docstring_1.meta == list()

    str_1a = '''
    This is a function.\n
    '''

    docstring_1a = parse(str_1a)
    assert docstring_1a.short_description == 'This is a function.'
    assert docstring_1a.long_description is None
    assert docstring_1a.blank_after_short_description is True

# Generated at 2022-06-25 16:34:21.067924
# Unit test for function parse
def test_parse():
    str_0 = 'Z,'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Z,'

# Unit tests for class DocstringMeta

# Generated at 2022-06-25 16:34:24.580270
# Unit test for function parse
def test_parse():
    test_case_0()

# ----
# main
# ----

if __name__ == "__main__":
    test_parse()
    print("Done.")

# Generated at 2022-06-25 16:34:35.188304
# Unit test for function parse

# Generated at 2022-06-25 16:34:43.258529
# Unit test for function parse
def test_parse():
    # Test normal string
    str_0 = """
    Short description.

    Longer description.

    :param name: Parameter name.
    :param type: Parameter type.
    :returns: Return value.
    :rtype: Type of return value.
    """
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Short description."
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.long_description == "Longer description."

# Generated at 2022-06-25 16:34:53.960207
# Unit test for function parse
def test_parse():
    str_0 = ""
    try:
        docstring_0 = parse(str_0)
    except Exception as e:
        docstring_0 = None
    assert docstring_0 is not None
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is None
    assert docstring_0.blank_after_long_description is None
    assert docstring_0.meta == []
    str_1 = "A.\n"
    try:
        docstring_1 = parse(str_1)
    except Exception as e:
        docstring_1 = None
    assert docstring_1 is not None
    assert docstring_1.short_description == "A."
    assert docstring_1.long_description

# Generated at 2022-06-25 16:34:59.351260
# Unit test for function parse
def test_parse():
    str_0 = "foo"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "foo"
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []
    #
    str_1 = "foo\nbar"
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "foo"
    assert docstring_1.long_description == "bar"
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.blank_after_long_description == False
    assert docstring_1.meta == []
   

# Generated at 2022-06-25 16:35:08.862762
# Unit test for function parse

# Generated at 2022-06-25 16:35:29.080050
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()
    test_case_0()

# Generated at 2022-06-25 16:35:39.804636
# Unit test for function parse

# Generated at 2022-06-25 16:35:48.267920
# Unit test for function parse

# Generated at 2022-06-25 16:35:50.437962
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:35:55.268650
# Unit test for function parse
def test_parse():
    docstring_0 = parse(str_0)
    assert docstring_0 is not None
    assert docstring_0.short_description == 'Z,'
    assert docstring_0.blank_after_short_description
    assert docstring_0.blank_after_long_description
    assert docstring_0.long_description is None
    assert len(docstring_0.meta) == 0

# Generated at 2022-06-25 16:35:58.965476
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:36:06.065002
# Unit test for function parse
def test_parse():
    docstring_0 = parse("Short.\n\nLong.\n")
    #print(docstring_0.short_description)
    #print(docstring_0.long_description)
    #assert docstring_0.short_description == "Short."
    #assert docstring_0.long_description == "Long."
    #docstring_1 = parse("Short.")
    #assert docstring_1.short_description == "Short."
    #assert docstring_1.long_description is None
    #docstring_2 = parse("Long.\n")
    #assert docstring_2.short_description is None
    #assert docstring_2.long_description == "Long."
    #docstring_3 = parse("")
    #assert docstring_3.short_description is None
    #assert docstring_3

# Generated at 2022-06-25 16:36:10.114040
# Unit test for function parse
def test_parse():
    str_0 = 'Z,'
    docstring_0 = parse(str_0)
    assert isinstance(docstring_0, Docstring)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is None
    assert docstring_0.blank_after_long_description is None
    assert len(docstring_0.meta) == 0

    str_1 = 'hello, world!\nGoodbye, world!'
    docstring_1 = parse(str_1)
    assert isinstance(docstring_1, Docstring)
    assert docstring_1.short_description == 'hello, world!'
    assert docstring_1.long_description == 'Goodbye, world!'
    assert docstring_1.blank_

# Generated at 2022-06-25 16:36:18.221916
# Unit test for function parse
def test_parse():
    str_0 = 'This function tests the parser'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'This function tests the parser'

    test_case_0()

    str_1 = 'This function tests the parser\nIt is a very important function'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'This function tests the parser'
    assert docstring_1.long_description == 'It is a very important function'

    str_2 = 'This function tests the parser\n\nIt is a very important function'
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == 'This function tests the parser'

# Generated at 2022-06-25 16:36:27.929104
# Unit test for function parse
def test_parse():
    str_0 = ""
    docstring_0 = parse(str_0)
    str_1 = "Returns the value of x."
    docstring_1 = parse(str_1)
    str_2 = "Returns the value of x.\n\n:type x: :class:`int`"
    docstring_2 = parse(str_2)
    str_3 = "Returns the value of x.\n\n:type x: :class:`int`\n:param str y: The name of the object."
    docstring_3 = parse(str_3)
    str_4 = "Returns the value of x.\n\n:type x: :class:`int`\n:param str y: The name of the object.\n       Defaults to 'World'."

# Generated at 2022-06-25 16:36:43.273014
# Unit test for function parse
def test_parse():
    # test case 0
    str_0 = 'Z,'
    docstring_0 = parse(str_0)
    # test case 1
    str_1 = "Z,\n:param x: X\n:returns: R"
    docstring_1 = parse(str_1)
    # test case 2
    str_2 = "\nZ,\n:returns: R"
    docstring_2 = parse(str_2)
    # test case 3
    str_3 = "  Z,\n:returns: R"
    docstring_3 = parse(str_3)
    # test case 4
    str_4 = "Z,\n\n:returns: R"
    docstring_4 = parse(str_4)
    # test case 5

# Generated at 2022-06-25 16:36:44.417342
# Unit test for function parse
def test_parse():
    docstring = '''

    Z,

    '''
    res = parse(docstring)


# Generated at 2022-06-25 16:36:57.547472
# Unit test for function parse
def test_parse():
    
    #test_case_0
    str_0 = 'Z,'
    docstring_0 = parse(str_0)
    assert docstring_0.long_description == 'None'
    
    #test_case_1
    str_1 = ', b: int: B.'
    docstring_1 = parse(str_1)
    assert docstring_1.long_description == 'None'
    
    #test_case_2

# Generated at 2022-06-25 16:36:58.973261
# Unit test for function parse
def test_parse():
    str_0 = 'Z,'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:37:08.174022
# Unit test for function parse
def test_parse():
    str_0 = 'Z,'
    docstring_0 = parse(str_0)
    assert (docstring_0.short_description is None)
    assert (docstring_0.meta == [])
    assert (docstring_0.long_description is None)
    assert (docstring_0.blank_after_short_description)
    assert (docstring_0.blank_after_long_description)

    str_1 = 'Z,\n\n'
    docstring_1 = parse(str_1)
    assert (docstring_1.short_description == '')
    assert (docstring_1.meta == [])
    assert (docstring_1.long_description is None)
    assert (docstring_1.blank_after_short_description)

# Generated at 2022-06-25 16:37:16.388073
# Unit test for function parse
def test_parse():
    """Test function parse."""
    assert parse("") == Docstring()
    assert parse("single line.") == Docstring(
        short_description="single line.",
        long_description=None,
        blank_after_long_description=None,
        blank_after_short_description=None
    )
    assert parse("single line.") == Docstring(short_description="single line.")
    assert parse("first line.\n\nsecond line.") == Docstring(
        short_description="first line.",
        long_description="second line.",
        blank_after_long_description=False,
        blank_after_short_description=True
    )



# Generated at 2022-06-25 16:37:28.468318
# Unit test for function parse
def test_parse():
    str_0 = ':param int a: parameter a.\n  defaults to b.\n'
    docstring_0 = parse(str_0)
    assert docstring_0.meta[0].type_name == 'int'
    assert docstring_0.meta[0].arg_name == 'a'
    assert docstring_0.meta[0].description == 'parameter a.\n  defaults to b.\n'
    assert docstring_0.meta[0].is_optional == None
    assert docstring_0.meta[0].default == 'b'

    str_1 = ':param int? a: parameter a.\n  defaults to b.\n'
    docstring_1 = parse(str_1)
    assert docstring_1.meta[0].type_name == 'int'

# Generated at 2022-06-25 16:37:36.910990
# Unit test for function parse
def test_parse():
    str_0 = 'Z,'
    docstring_0 = parse(str_0)
    assert not hasattr(docstring_0, 'short_description')
    assert not hasattr(docstring_0, 'long_description')
    assert not hasattr(docstring_0, 'blank_after_short_description')
    assert not hasattr(docstring_0, 'blank_after_long_description')
    assert not docstring_0.meta

# Generated at 2022-06-25 16:37:45.339569
# Unit test for function parse
def test_parse():
    str_0 = """
    Sort the items of the list in place (the arguments can be lists, arrays, or other
    sequences).

    :param a:  sequence (e.g. list or tuple)
    :type a:   list, tuple
    :param axis:  Axis along which to sort. Default is -1 (the last axis).
    :type axis:   int
    :param kind:  Sorting algorithm (quicksort, mergesort, heapsort), default quicksort.
    :type kind:   str
    :param order: If a is an array with fields defined, this argument specifies which fields to compare first, second, etc.
    :type order:  str or list of str.
    """

# Generated at 2022-06-25 16:37:55.072623
# Unit test for function parse
def test_parse():
    assert 'short description' in parse("short description").short_description
    assert 'long description' in parse("short description\n\nlong description").long_description
    assert 'text1' in parse("short description\n\n\n- text1\n- text2").long_description
    assert 'text2' in parse("short description\n\n\n- text1\n- text2").long_description
    assert 'param' in parse(":param int param: text").meta[0].args[0]
    assert 'description' in parse(":param int param: text").meta[0].description
    assert 'param' in parse(":param int param: text").meta[0].arg_name
    assert 'int' in parse(":param int param: text").meta[0].type_name

# Generated at 2022-06-25 16:38:09.949474
# Unit test for function parse
def test_parse():
    # Call function directly
    str_0 = '\n    Sort the items of the list in place (the arguments can be lists, arrays, or other\n    sequences).\n\n    :param a:  sequence (e.g. list or tuple)\n    :type a:   list, tuple\n    :param axis:  Axis along which to sort. Default is -1 (the last axis).\n    :type axis:   int\n    :param kind:  Sorting algorithm (quicksort, mergesort, heapsort), default quicksort.\n    :type kind:   str\n    :param order: If a is an array with fields defined, this argument specifies which fields to compare first, second, etc.\n    :type order:  str or list of str.\n    '
    res_0 = parse(str_0)


# Generated at 2022-06-25 16:38:18.898046
# Unit test for function parse
def test_parse():
    str_0 = '\n    Sort the items of the list in place (the arguments can be lists, arrays, or other\n    sequences).\n\n    :param a:  sequence (e.g. list or tuple)\n    :type a:   list, tuple\n    :param axis:  Axis along which to sort. Default is -1 (the last axis).\n    :type axis:   int\n    :param kind:  Sorting algorithm (quicksort, mergesort, heapsort), default quicksort.\n    :type kind:   str\n    :param order: If a is an array with fields defined, this argument specifies which fields to compare first, second, etc.\n    :type order:  str or list of str.\n    '


# Generated at 2022-06-25 16:38:24.833855
# Unit test for function parse

# Generated at 2022-06-25 16:38:36.912162
# Unit test for function parse

# Generated at 2022-06-25 16:38:45.211735
# Unit test for function parse
def test_parse():
    str_0 = '\n    Sort the items of the list in place (the arguments can be lists, arrays, or other\n    sequences).\n\n    :param a:  sequence (e.g. list or tuple)\n    :type a:   list, tuple\n    :param axis:  Axis along which to sort. Default is -1 (the last axis).\n    :type axis:   int\n    :param kind:  Sorting algorithm (quicksort, mergesort, heapsort), default quicksort.\n    :type kind:   str\n    :param order: If a is an array with fields defined, this argument specifies which fields to compare first, second, etc.\n    :type order:  str or list of str.\n    '

# Generated at 2022-06-25 16:38:55.300813
# Unit test for function parse
def test_parse():
    str_0 = '\n    Sort the items of the list in place (the arguments can be lists, arrays, or other\n    sequences).\n\n    :param a:  sequence (e.g. list or tuple)\n    :type a:   list, tuple\n    :param axis:  Axis along which to sort. Default is -1 (the last axis).\n    :type axis:   int\n    :param kind:  Sorting algorithm (quicksort, mergesort, heapsort), default quicksort.\n    :type kind:   str\n    :param order: If a is an array with fields defined, this argument specifies which fields to compare first, second, etc.\n    :type order:  str or list of str.\n    '
    value = parse(str_0)

# Generated at 2022-06-25 16:39:06.061956
# Unit test for function parse
def test_parse():
    str_0 = '\n    Sort the items of the list in place (the arguments can be lists, arrays, or other\n    sequences).\n\n    :param a:  sequence (e.g. list or tuple)\n    :type a:   list, tuple\n    :param axis:  Axis along which to sort. Default is -1 (the last axis).\n    :type axis:   int\n    :param kind:  Sorting algorithm (quicksort, mergesort, heapsort), default quicksort.\n    :type kind:   str\n    :param order: If a is an array with fields defined, this argument specifies which fields to compare first, second, etc.\n    :type order:  str or list of str.\n    '

# Generated at 2022-06-25 16:39:13.850278
# Unit test for function parse
def test_parse():
    docstring = parse(str_0)
    print(repr(docstring))

    assert isinstance(docstring, Docstring)
    assert isinstance(docstring.short_description, str)
    assert isinstance(docstring.long_description, str)
    assert isinstance(docstring.blank_after_short_description, bool)
    assert isinstance(docstring.blank_after_long_description, bool)
    assert isinstance(docstring.meta, list)

    for i in docstring.meta:
        assert isinstance(i, DocstringMeta)
        assert isinstance(i.args, list)
        assert isinstance(i.description, str)

    print("Unit test for function parse passed!")

#
#
#
# if __name__ == "__main__":
#     test_parse()
#

# Generated at 2022-06-25 16:39:15.887305
# Unit test for function parse
def test_parse():
	result = parse(test_case_0())
	assert result == 'python', 'The result should be: python'

test_parse()

# Generated at 2022-06-25 16:39:26.392076
# Unit test for function parse
def test_parse():
    str_0 = '\n    Sort the items of the list in place (the arguments can be lists, arrays, or other\n    sequences).\n\n    :param a:  sequence (e.g. list or tuple)\n    :type a:   list, tuple\n    :param axis:  Axis along which to sort. Default is -1 (the last axis).\n    :type axis:   int\n    :param kind:  Sorting algorithm (quicksort, mergesort, heapsort), default quicksort.\n    :type kind:   str\n    :param order: If a is an array with fields defined, this argument specifies which fields to compare first, second, etc.\n    :type order:  str or list of str.\n    '

# Generated at 2022-06-25 16:39:45.812515
# Unit test for function parse
def test_parse():
    """Test parse()"""

# Generated at 2022-06-25 16:39:49.784336
# Unit test for function parse
def test_parse():
    """Test function parse()."""
    assert parse(test_case_0()) == Docstring()


if __name__ == "__main__":
    test_parse()
    print("No errors found.")

# Generated at 2022-06-25 16:39:58.057729
# Unit test for function parse

# Generated at 2022-06-25 16:40:06.929796
# Unit test for function parse
def test_parse():

    # Call function parse
    result = parse(str_0)

    # Check if result is as expected

# Generated at 2022-06-25 16:40:18.306879
# Unit test for function parse
def test_parse():
    text = """Sort the items of the list in place (the arguments can be lists, arrays, or other
sequences).

:param a:  sequence (e.g. list or tuple)
:type a:   list, tuple
:param axis:  Axis along which to sort. Default is -1 (the last axis).
:type axis:   int
:param kind:  Sorting algorithm (quicksort, mergesort, heapsort), default quicksort.
:type kind:   str
:param order: If a is an array with fields defined, this argument specifies which fields to compare first, second, etc.
:type order:  str or list of str.
"""
    docstr = parse(text)

# Generated at 2022-06-25 16:40:28.960585
# Unit test for function parse

# Generated at 2022-06-25 16:40:38.097502
# Unit test for function parse
def test_parse():
    str_0 = '\n    Sort the items of the list in place (the arguments can be lists, arrays, or other\n    sequences).\n\n    :param a:  sequence (e.g. list or tuple)\n    :type a:   list, tuple\n    :param axis:  Axis along which to sort. Default is -1 (the last axis).\n    :type axis:   int\n    :param kind:  Sorting algorithm (quicksort, mergesort, heapsort), default quicksort.\n    :type kind:   str\n    :param order: If a is an array with fields defined, this argument specifies which fields to compare first, second, etc.\n    :type order:  str or list of str.\n    '
    docstring = parse(str_0)
    assert docstring.short_

# Generated at 2022-06-25 16:40:44.162207
# Unit test for function parse
def test_parse():
    # test_case_0
    str_0 = '\n    Sort the items of the list in place (the arguments can be lists, arrays, or other\n    sequences).\n\n    :param a:  sequence (e.g. list or tuple)\n    :type a:   list, tuple\n    :param axis:  Axis along which to sort. Default is -1 (the last axis).\n    :type axis:   int\n    :param kind:  Sorting algorithm (quicksort, mergesort, heapsort), default quicksort.\n    :type kind:   str\n    :param order: If a is an array with fields defined, this argument specifies which fields to compare first, second, etc.\n    :type order:  str or list of str.\n    '
    res = parse(str_0)



# Generated at 2022-06-25 16:40:45.752540
# Unit test for function parse
def test_parse():
    text = inspect.cleandoc(str_0)
    result = parse(text)
    assert result

# Generated at 2022-06-25 16:40:55.885868
# Unit test for function parse
def test_parse():
    # Test case 0
    str_0 = '\n    Sort the items of the list in place (the arguments can be lists, arrays, or other\n    sequences).\n\n    :param a:  sequence (e.g. list or tuple)\n    :type a:   list, tuple\n    :param axis:  Axis along which to sort. Default is -1 (the last axis).\n    :type axis:   int\n    :param kind:  Sorting algorithm (quicksort, mergesort, heapsort), default quicksort.\n    :type kind:   str\n    :param order: If a is an array with fields defined, this argument specifies which fields to compare first, second, etc.\n    :type order:  str or list of str.\n    '


# Generated at 2022-06-25 16:41:14.628862
# Unit test for function parse

# Generated at 2022-06-25 16:41:16.483121
# Unit test for function parse
def test_parse():
    test_case_0()
#     return

# Generated at 2022-06-25 16:41:26.577718
# Unit test for function parse
def test_parse():
    str_0 = '\n    Sort the items of the list in place (the arguments can be lists, arrays, or other\n    sequences).\n\n    :param a:  sequence (e.g. list or tuple)\n    :type a:   list, tuple\n    :param axis:  Axis along which to sort. Default is -1 (the last axis).\n    :type axis:   int\n    :param kind:  Sorting algorithm (quicksort, mergesort, heapsort), default quicksort.\n    :type kind:   str\n    :param order: If a is an array with fields defined, this argument specifies which fields to compare first, second, etc.\n    :type order:  str or list of str.\n    '

# Generated at 2022-06-25 16:41:38.986178
# Unit test for function parse
def test_parse():
    str_0 = '\n    Sort the items of the list in place (the arguments can be lists, arrays, or other\n    sequences).\n\n    :param a:  sequence (e.g. list or tuple)\n    :type a:   list, tuple\n    :param axis:  Axis along which to sort. Default is -1 (the last axis).\n    :type axis:   int\n    :param kind:  Sorting algorithm (quicksort, mergesort, heapsort), default quicksort.\n    :type kind:   str\n    :param order: If a is an array with fields defined, this argument specifies which fields to compare first, second, etc.\n    :type order:  str or list of str.\n    '
    # Case 0
    doc = parse(str_0)
    assert doc

# Generated at 2022-06-25 16:41:49.103523
# Unit test for function parse
def test_parse():
    """
    :Testcases:
    :returns: Each test case requires a string docstring,
        and produces the Docstring object that should be generated
        as a result.
    """

# Generated at 2022-06-25 16:41:59.631892
# Unit test for function parse
def test_parse():
    test_cases = [
        {"desc": "Simple", "input": "this is the first line\nthis is a second line"},
        {"desc": "Empty", "input": ""},
        {"desc": "Single line", "input": "this is the first line"},
        {"desc": "Simple with meta", "input": str_0},
    ]

    for case in test_cases:
        output = parse(case["input"])
        print(output)
        print("")

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:42:02.398808
# Unit test for function parse
def test_parse():

    # Put test code below
    assert False, "No test implemented yet."

# Generated at 2022-06-25 16:42:14.151981
# Unit test for function parse
def test_parse():
    assert parse("This is a string") == Docstring(
        short_description="This is a string",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[DocstringMeta(args=[], description=None)],
    )

    assert parse("\n    This is a string\n    ") == Docstring(
        short_description="This is a string",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[DocstringMeta(args=[], description=None)],
    )


# Generated at 2022-06-25 16:42:25.848300
# Unit test for function parse
def test_parse():
    str_0 = '\n    Sort the items of the list in place (the arguments can be lists, arrays, or other\n    sequences).\n\n    :param a:  sequence (e.g. list or tuple)\n    :type a:   list, tuple\n    :param axis:  Axis along which to sort. Default is -1 (the last axis).\n    :type axis:   int\n    :param kind:  Sorting algorithm (quicksort, mergesort, heapsort), default quicksort.\n    :type kind:   str\n    :param order: If a is an array with fields defined, this argument specifies which fields to compare first, second, etc.\n    :type order:  str or list of str.\n    '

# Generated at 2022-06-25 16:42:28.203521
# Unit test for function parse
def test_parse():
    test_case_0()
    return


if __name__ == '__main__':
    import sys
    sys.exit(test_parse())

# Generated at 2022-06-25 16:42:37.705709
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:42:39.326883
# Unit test for function parse
def test_parse():
    assert type(parse("")) == Docstring
    assert parse("").short_description == None


# Generated at 2022-06-25 16:42:40.194765
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:42:47.531693
# Unit test for function parse
def test_parse():
    assert (
            parse('\n    Short description.\n')
            ==
            Docstring(
                short_description='Short description.',
                long_description=None,
                blank_after_short_description=True,
                blank_after_long_description=False,
                meta=[],
            )
    )
    assert (
            parse('\n    Short description.\n\n    Longer description.\n')
            ==
            Docstring(
                short_description='Short description.',
                long_description='Longer description.',
                blank_after_short_description=True,
                blank_after_long_description=False,
                meta=[],
            )
    )

# Generated at 2022-06-25 16:42:50.311212
# Unit test for function parse
def test_parse():
    test_case_0()

if (__name__ == '__main__'):
    test_parse()

# Generated at 2022-06-25 16:42:59.639344
# Unit test for function parse
def test_parse():
    # Test case 0
    try:
        str_0 = '\n    Short description.\n\n    Longer description.\n\n    :param name: Parameter name.\n    :param type: Parameter type.\n    :returns: Return value.\n    :rtype: Type of return value.\n    '
        docstring_0 = parse(str_0)
    except ParseError:
        # test failed
        raise AssertionError
    assert docstring_0.short_description == 'Short description.'
    assert docstring_0.blank_after_short_description
    assert docstring_0.long_description == 'Longer description.'
    assert docstring_0.blank_after_long_description

# Generated at 2022-06-25 16:43:02.439174
# Unit test for function parse
def test_parse():
    test_case_0()



# Compiled Object file
import re
DOCSTRING_RECORDING_CACHE = {}

# Begin closures for DOCSTRING_RECORDING_CACHE

# Generated at 2022-06-25 16:43:12.665926
# Unit test for function parse
def test_parse():
    str_0 = '\n    Short description.\n\n    Longer description.\n\n    :param name: Parameter name.\n    :param type: Parameter type.\n    :returns: Return value.\n    :rtype: Type of return value.\n    '
    docstring_0 = parse(str_0)
    print(docstring_0)
    docstring_0 = parse(str_0)
    print(docstring_0)
    docstring_0 = parse(str_0)
    print(docstring_0)
    docstring_0 = parse(str_0)
    print(docstring_0)
    docstring_0 = parse(str_0)
    print(docstring_0)
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:43:14.041336
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:43:21.078907
# Unit test for function parse
def test_parse():
    # Test case 0
    assert docstring_0.short_description == 'Short description.'
    assert docstring_0.long_description == 'Longer description.'
    assert [x.args for x in docstring_0.meta] == [['param', 'name', 'Parameter name.'], ['param', 'type', 'Parameter type.'], ['returns:', 'Return value.'], ['rtype:', 'Type of return value.']]