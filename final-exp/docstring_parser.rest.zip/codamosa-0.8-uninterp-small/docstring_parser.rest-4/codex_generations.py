

# Generated at 2022-06-25 16:33:54.117106
# Unit test for function parse

# Generated at 2022-06-25 16:34:05.373087
# Unit test for function parse
def test_parse():
    # Test 1
    str_0 = 'E'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'E'
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.long_description is None
    assert type(docstring_0.meta) == list
    assert len(docstring_0.meta) == 0

    # Test 2
    str_1 = ''
    docstring_1 = parse(str_1)
    assert docstring_1.short_description is None
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.long_description is None
    assert type(docstring_1.meta) == list
    assert len(docstring_1.meta) == 0

    # Test

# Generated at 2022-06-25 16:34:15.985422
# Unit test for function parse
def test_parse():

    # All whitespace
    str1 = '   '
    docstring1 = parse(str1)
    assert docstring1.short_description is None
    assert docstring1.long_description is None
    assert docstring1.blank_after_short_description is False
    assert docstring1.blank_after_long_description is True
    assert not docstring1.meta

    # Short description only
    str2 = 'Short description.'
    docstring2 = parse(str2)
    assert docstring2.short_description == 'Short description.'
    assert docstring2.blank_after_short_description
    assert docstring2.long_description is None
    assert not docstring2.meta

    # Short description with trailing whitespace
    str3 = 'Short description with trailing\n  whitespace.'

# Generated at 2022-06-25 16:34:27.386866
# Unit test for function parse
def test_parse():
    str_0 = 'short long\n\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'short'
    assert docstring_0.long_description == 'long'
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == True
    str_1 = '\n\n'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == None
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank_after_long_description == True
    str_2 = ':param int x: x coordinate\n'

# Generated at 2022-06-25 16:34:38.914162
# Unit test for function parse
def test_parse():

    # parse() with 0 parameters
    str_0 = """
    reverses a given string and returns the reversed string
    :param string: the string that is to be reversed
    :type string: str
    :returns: The reversed string
    :rtype: str
    """
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'reverses a given string and returns the reversed string'
    assert docstring_0.long_description == None
    assert len(docstring_0.meta) == 2
    assert docstring_0.meta[0].description == 'the string that is to be reversed'
    assert docstring_0.meta[0].arg_name == 'string'
    assert docstring_0.meta[0].type_name == 'str'

# Generated at 2022-06-25 16:34:50.057816
# Unit test for function parse
def test_parse():
    str_0 = 'E'
    docstring_0 = parse(str_0)
    assert docstring_0.blank_after_long_description == None
    assert docstring_0.blank_after_short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.short_description == 'E'
    assert len(docstring_0.meta) == 0

    str_1 = 'E\n'
    docstring_1 = parse(str_1)
    assert docstring_1.blank_after_long_description == None
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.long_description == None
    assert docstring_1.short_description == 'E'
    assert len(docstring_1.meta) == 0

   

# Generated at 2022-06-25 16:35:01.356148
# Unit test for function parse
def test_parse():
    str_1 = """
    Create a new empty list.

    :returns: new empty list
    """
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "Create a new empty list."
    assert docstring_1.long_description is None
    assert not docstring_1.blank_after_short_description
    assert docstring_1.blank_after_long_description
    assert len(docstring_1.meta) == 1
    assert docstring_1.meta[0].args == ["returns"]
    assert docstring_1.meta[0].description == "new empty list"
    assert isinstance(docstring_1.meta[0], DocstringReturns)


# Generated at 2022-06-25 16:35:10.743659
# Unit test for function parse
def test_parse():
    s__0 = 'E'
    assert parse(s__0).short_description == None
    assert parse(s__0).blank_after_short_description == False
    assert parse(s__0).blank_after_long_description == False
    assert parse(s__0).long_description == None
    assert parse(s__0).meta == []
    s__1 = 'E\n'
    assert parse(s__1).short_description == None
    assert parse(s__1).blank_after_short_description == True
    assert parse(s__1).blank_after_long_description == False
    assert parse(s__1).long_description == None
    assert parse(s__1).meta == []
    s__2 = 'E\n\n'
    assert parse(s__2).short_description == None


# Generated at 2022-06-25 16:35:18.138484
# Unit test for function parse
def test_parse():
    # Test long description
    docstring = parse("This is the long description.\n\nAnd this is more")
    assert docstring.short_description == "This is the long description."
    assert docstring.long_description == "And this is more"
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert not docstring.meta

    # Test blank lines
    docstring = parse("This is the long description.\n\n\n")
    assert docstring.short_description == "This is the long description."
    assert not docstring.long_description
    assert not docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert not docstring.meta

    # Test meta

# Generated at 2022-06-25 16:35:20.603791
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:35:43.302448
# Unit test for function parse

# Generated at 2022-06-25 16:35:44.044950
# Unit test for function parse
def test_parse():
    test_case_0()



# Generated at 2022-06-25 16:35:48.825430
# Unit test for function parse
def test_parse():
    str_0 = 'E\n'
    docstring_0 = parse(str_0)
    assert docstring_0.meta == []
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.short_description == 'E'


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:35:59.214989
# Unit test for function parse
def test_parse():
    # Short description and long description
    str_1 = '''A test.
    This is a long description.
    And it continues.
    '''
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'A test.'
    assert docstring_1.long_description == 'This is a long description.\nAnd it continues.'

    # Short description, long description and one docstring meta
    str_2 = '''A test.
    This is a long description.
    And it continues.

    :param param1: A parameter.
    :type param1: int
    '''
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == 'A test.'

# Generated at 2022-06-25 16:36:02.561580
# Unit test for function parse
def test_parse():
    # Test case 0
    str_0 = 'E'
    docstring_0 = parse(str_0)
    expected_output_0 = Docstring()

    assert docstring_0 == expected_output_0


# Generated at 2022-06-25 16:36:07.706153
# Unit test for function parse
def test_parse():
    str_1 = """
        Set the value of an attribute.

        :param name: The name of the attribute to set.
        :type name: str
        :param value: The value to set the attribute to.
        :type value: Any
        :param quiet: Whether to suppress exceptions on a `KeyError` when
            the attribute doesn't exist.
        :type quiet: bool
        :param default: The default value to set the attribute to if
            the attribute does not exist.
        :param default: Any, defaults to `None`
        :raises TypeError: If the attribute already exists and is not a
            property, and a value or default is passed.
        :raises AttributeError: If the attribute already exists and is not
            a property, and neither a value nor default is passed.
        :returns: self
        """
    docstring

# Generated at 2022-06-25 16:36:16.920071
# Unit test for function parse
def test_parse():
    str_0 = 'E'
    docstring_0 = parse(str_0)
    assert (
        docstring_0.short_description == 'E'
    ), "Short description was not parsed properly"
    assert (
        docstring_0.long_description == None
    ), "Long description was not parsed properly"
    assert (
        docstring_0.blank_after_short_description == False
    ), (
        "Blank after short description was not parsed properly"
    )
    assert (
        docstring_0.blank_after_long_description == False
    ), (
        "Blank after long description was not parsed properly"
    )
    assert (
        docstring_0.meta == []
    ), "Meta information was not parsed properly"

    str_1 = '''\
    E
    '''


# Generated at 2022-06-25 16:36:20.339028
# Unit test for function parse
def test_parse():
    test_case_0()

# Program entry point
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:36:24.845793
# Unit test for function parse
def test_parse():
    docstring = parse("""
    Test description
    :one: 1
    :two: 2
    """)

    assert(docstring.short_description == "Test description")
    assert(docstring.blank_after_short_description == True)
    assert(docstring.blank_after_long_description == True)
    assert(len(docstring.meta) == 2)


# Generated at 2022-06-25 16:36:29.923612
# Unit test for function parse
def test_parse():
    str = """\
        Singleton decorator.

        :param cls: (required) Class to be decorated.
        :return: Singleton-ized class.
        """
    docstring = parse(str)
    assert docstring.short_description == "Singleton decorator."
    assert not docstring.long_description
    assert not docstring.meta
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description


# Generated at 2022-06-25 16:36:48.310336
# Unit test for function parse
def test_parse():
    # Test for _build_meta
    assert _build_meta(['result', 'int'], '').value == 'result'
    assert (
        _build_meta(['param', 'name', 'str'], '').value
        == 'param name <type \'str\'> None None'
    )
    assert (
        _build_meta(
            ['param', 'win_or_mac', 'platform', ':param name: The name of'],
            'the attribute to set. :type name: str :param value: The value'
        ).value
        == 'param win_or_mac platform None None'
    )

# Generated at 2022-06-25 16:36:55.758372
# Unit test for function parse
def test_parse():
    """Function to test ReplaceSpecialCharacters function."""

    # Executed when the file name is main
    if __name__ == "__main__":
        docstring_parse=parse(test_case_0())
        assert docstring_parse.short_description== 'Set the value of an attribute.', "Error parsing the docstring."
        assert len(docstring_parse.meta)== 6, "Error parsing the docstring."
        assert docstring_parse.meta[0].arg_name== 'name', "Error parsing the docstring."
        assert docstring_parse.meta[0].type_name== 'str', "Error parsing the docstring."
        assert docstring_parse.meta[0].description== 'The name of the attribute to set.', "Error parsing the docstring."
        assert docstring_parse.meta[0].is_optional== None

# Generated at 2022-06-25 16:37:05.830372
# Unit test for function parse

# Generated at 2022-06-25 16:37:15.840566
# Unit test for function parse

# Generated at 2022-06-25 16:37:28.467696
# Unit test for function parse

# Generated at 2022-06-25 16:37:36.910509
# Unit test for function parse
def test_parse():
    # Tests for function parse
    try:
        assert parse("") == Docstring()
    except AssertionError:
        print("FAILED: parse ''")
        print("Expected:", Docstring())
        raise

    try:
        assert parse("\n") == Docstring(short_description="", blank_after_short_description=True, long_description=None, blank_after_long_description=True)
    except AssertionError:
        print("FAILED: parse '\\n'")
        print("Expected:", Docstring(short_description="", blank_after_short_description=True, long_description=None, blank_after_long_description=True))
        raise


# Generated at 2022-06-25 16:37:45.369801
# Unit test for function parse

# Generated at 2022-06-25 16:37:55.124606
# Unit test for function parse

# Generated at 2022-06-25 16:38:07.929602
# Unit test for function parse
def test_parse():
    # Case 1
    str = '''
        Returns the number of characters in the string.
        '''
    expected = Docstring(
        short_description='Returns the number of characters in the string.',
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=True,
        meta=[],
    )

    assert parse(str) == expected

    # Case 2
    str = '''
        Returns the number of characters in the string.

        :rtype: int
        '''

# Generated at 2022-06-25 16:38:09.986792
# Unit test for function parse
def test_parse():
    for i in range(1):
        str_0 = test_case_0()
        docstring = parse(str_0)
        print(docstring.meta[0].type_name)
        print(docstring.meta[0].default)
        print(docstring.meta[0].is_optional)



# Generated at 2022-06-25 16:38:27.913336
# Unit test for function parse

# Generated at 2022-06-25 16:38:36.756790
# Unit test for function parse

# Generated at 2022-06-25 16:38:42.724492
# Unit test for function parse
def test_parse():
    docstring = parse(test_case_0())
    print(type(docstring))
    print(dir(docstring))
    print(docstring.meta)
    print(docstring.meta[0].arg_name)
    # print(docstring.meta[0].args)
    print(docstring.long_description)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:38:54.160002
# Unit test for function parse
def test_parse():
    from docstamp.common import Docstring
    # test one

# Generated at 2022-06-25 16:39:04.766707
# Unit test for function parse
def test_parse():
    docstring = "This is the description."
    expected = Docstring(
        short_description="This is the description.",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    actual = parse(docstring)
    assert actual == expected

    docstring = "This is the description.\n\nThis is the long description."
    expected = Docstring(
        short_description="This is the description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="This is the long description.",
    )
    actual = parse(docstring)
    assert actual == expected

    docstring = "This is the description.\n\nThis is the long description.\n"

# Generated at 2022-06-25 16:39:13.718540
# Unit test for function parse

# Generated at 2022-06-25 16:39:24.632302
# Unit test for function parse

# Generated at 2022-06-25 16:39:32.825439
# Unit test for function parse

# Generated at 2022-06-25 16:39:39.067295
# Unit test for function parse
def test_parse():
    print("Testing function parse...", end="")

# Generated at 2022-06-25 16:39:48.969345
# Unit test for function parse

# Generated at 2022-06-25 16:40:08.008373
# Unit test for function parse

# Generated at 2022-06-25 16:40:09.153455
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:40:10.500362
# Unit test for function parse
def test_parse():
    # simple case
    test_case_0()

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:40:21.202578
# Unit test for function parse
def test_parse():
    assert parse(None) == Docstring()
    assert parse("") == Docstring()

    docstring = parse(
        "A short description.\nA long description.\n\n:param x: Parameter x\n:type x: int\n:returns: Answer"
    )

# Generated at 2022-06-25 16:40:31.647839
# Unit test for function parse

# Generated at 2022-06-25 16:40:42.681507
# Unit test for function parse
def test_parse():
    from .common import Docstring, DocstringMeta, DocstringParam, DocstringRaises, DocstringReturns, ParseError
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n\n") == Docstring()
    assert parse(" \n \n \n ") == Docstring()

# Generated at 2022-06-25 16:40:52.982127
# Unit test for function parse
def test_parse():
    assert(parse("") == Docstring())
    assert(parse("some funky text") ==
           Docstring(short_description="some funky text",
                     blank_after_short_description=True,
                     long_description=None))
    assert(parse("some funky\ntext") ==
           Docstring(short_description="some funky",
                     blank_after_short_description=False,
                     long_description="text",
                     blank_after_long_description=True))
    assert(parse("some funky\n\ntext") ==
           Docstring(short_description="some funky",
                     blank_after_short_description=True,
                     long_description="text",
                     blank_after_long_description=True))

# Generated at 2022-06-25 16:40:55.734776
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:41:05.372967
# Unit test for function parse
def test_parse():
    str_0 = " This is a short description.\n\n  This is a long description.\n  It contains several lines.\n\n  :param n: The number of iterations to be performed.\n  :type n: int\n  :param x: The number to be used as the multiplier.\n  :type x: float\n  :returns: The result of the calculation.\n  :rtype: float\n  :raises ValueError: If `n` is negative.\n  :raises ValueError: If `x` is zero.\n"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "This is a short description."
    assert docstring_0.long_description == "This is a long description.\nIt contains several lines."
    assert docstring

# Generated at 2022-06-25 16:41:14.794875
# Unit test for function parse

# Generated at 2022-06-25 16:41:26.583409
# Unit test for function parse
def test_parse():
    assert True

# Generated at 2022-06-25 16:41:32.038460
# Unit test for function parse

# Generated at 2022-06-25 16:41:37.352393
# Unit test for function parse
def test_parse():
    # Verify that a docstring with no meta information can be parsed.
    docstring = parse(
        "\nThis is a short description.\n\nThis is a longer description.\n\n"
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a longer description."
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is True
    assert not docstring.meta

    # Verify that a docstring with meta information can be parsed.

# Generated at 2022-06-25 16:41:42.566766
# Unit test for function parse
def test_parse():
    import os
    import sys
    from .common import pretty
    path = os.path.join(os.path.dirname(__file__), "fixtures/test_parse.py")
    with open(path) as f:
        code = f.read()
    result = parse(code)
    sys.stdout.write(pretty(result, width=60))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:41:51.663947
# Unit test for function parse

# Generated at 2022-06-25 16:41:57.549408
# Unit test for function parse

# Generated at 2022-06-25 16:42:07.437987
# Unit test for function parse
def test_parse():
    """
    Ensure that parse returns the expected value for the given inputs
    """
    # Given: Call parse with the following parameter values

# Generated at 2022-06-25 16:42:08.579477
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:42:19.893440
# Unit test for function parse

# Generated at 2022-06-25 16:42:34.438857
# Unit test for function parse
def test_parse():
    str_0 = ""
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:43:06.845651
# Unit test for function parse
def test_parse():
    assert(str(parse("a\nb\n\nc\n")) == "Docstring(short_description='a', blank_after_short_description=True, blank_after_long_description=False, long_description='b\nc')")
    assert(str(parse("a\nb\nc")) == "Docstring(short_description='a', blank_after_short_description=False, blank_after_long_description=False, long_description='b c')")
    assert(str(parse("a\nb\n\nc\n\n")) == "Docstring(short_description='a', blank_after_short_description=True, blank_after_long_description=True, long_description='b\nc')")

# Generated at 2022-06-25 16:43:14.483036
# Unit test for function parse

# Generated at 2022-06-25 16:43:24.713427
# Unit test for function parse

# Generated at 2022-06-25 16:43:34.068151
# Unit test for function parse
def test_parse():
    def test_case_0():
        str_0 = "\nfunc_doc\n\n:param arg1: doc for arg1\n:type arg1: int\n:param arg2: doc for arg2\n:type arg2: str, optional\n:returns: doc for return\n:rtype: int\n"
        docstring_0 = parse(str_0)
        assert docstring_0.short_description == "func_doc"
        assert docstring_0.long_description is None
        assert docstring_0.meta == [
            DocstringParam("param", "arg1", "doc for arg1", "int"),
            DocstringParam("param", "arg2", "doc for arg2", "str", True),
            DocstringReturns("returns", "doc for return", "int"),
        ]

