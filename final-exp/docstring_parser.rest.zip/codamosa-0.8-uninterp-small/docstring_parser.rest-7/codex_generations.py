

# Generated at 2022-06-25 16:33:52.518079
# Unit test for function parse
def test_parse():
    str_0 = 'This is a docstring.'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'This is a docstring.'
    assert len(docstring_0.meta) == 0
    assert docstring_0.long_description is None

    str_0 = "This is a docstring.\n\nThis is a long description"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'This is a docstring.'
    assert len(docstring_0.meta) == 0
    assert docstring_0.long_description == 'This is a long description'

    str_0 = 'This is a docstring.\n\nThis is a long description.\n\n'

# Generated at 2022-06-25 16:33:59.569399
# Unit test for function parse
def test_parse():
    simple_fixture = """
        A simple Jason test fixture.

            Simple Fixture:
                foo: 1
                bar: A.B
            Related Files:
                /tmp/doc/json.jason
    """[
        1:
    ]


# Generated at 2022-06-25 16:34:05.588579
# Unit test for function parse
def test_parse():
    ns = locals()
    for name in ns.keys():
        if name.startswith("test_case_"):
            name = name.split("_", 1)[-1]
            check(name, ns["test_case_%s" % name])


# Generated at 2022-06-25 16:34:09.639512
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:34:11.411021
# Unit test for function parse
def test_parse():
    # Test 0:
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:34:18.193125
# Unit test for function parse
def test_parse():
    docstring_0 = parse(
        'This is a docstring.\n'
        '\n'
        'This is a long description of the function. It might\n'
        'even span multiple lines. This is a long description of\n'
        'the function. It might even span multiple lines. This\n'
        'is a long description of the function. It might even\n'
        'span multiple lines. This is a long description of the\n'
        'function. It might even span multiple lines. This is a\n'
        'long description of the function. It might even span\n'
        'multiple lines. This is a long description of the\n'
        'function. It might even span multiple lines.\n'
        '\n'
    )

# Generated at 2022-06-25 16:34:24.955880
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("   \n\n") == Docstring()

    assert parse("foo") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        meta=[],
    )
    assert parse("   foo   ") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        meta=[],
    )
    assert parse("foo.\n   ") == Docstring(
        short_description="foo.",
        blank_after_short_description=True,
        meta=[],
    )


# Generated at 2022-06-25 16:34:35.216254
# Unit test for function parse
def test_parse():
    str_0 = ';tn\x0bM2<yD'
    docstring_0 = parse(str_0)
    assert(docstring_0.short_description == None)
    assert(docstring_0.blank_after_short_description == False)
    assert(docstring_0.blank_after_long_description == False)
    assert(docstring_0.long_description == None)
    assert(docstring_0.meta == [])

    str_1 = ';tn\x0bM2<yD\n'
    docstring_1 = parse(str_1)
    assert(docstring_1.short_description == None)
    assert(docstring_1.blank_after_short_description == True)
    assert(docstring_1.blank_after_long_description == False)

# Generated at 2022-06-25 16:34:43.281842
# Unit test for function parse
def test_parse():
    assert(parse("") == Docstring())
    assert(parse("\n") == Docstring())
    assert(parse("\n\n") == Docstring())
    assert(parse("A short description.") == Docstring(short_description="A short description."))
    assert(parse("A short desc.\n") == Docstring(short_description="A short desc."))
    assert(parse("A short desc.\n\n") == Docstring(short_description="A short desc."))
    assert(parse("A short desc.\n\nA long desc.") == Docstring(short_description="A short desc.", long_description="A long desc."))

# Generated at 2022-06-25 16:34:54.017601
# Unit test for function parse
def test_parse():
    text = """\
    Foo
    
    
    Bar
    
    
    
    
    
    
    """
    assert parse(text).short_description == "Foo"
    assert parse(text).long_description == "Bar"
    assert parse(text).blank_after_short_description is True
    assert parse(text).blank_after_long_description is True

    text = """\
    Foo
    
    
    Bar
    
    
    
    
    
    
    :param x: x
    :param y: y
    :type y: str
    :returns: Returns something.
    :rtype: str
    :raises: AttributeError
    
    
    
    """
    assert parse(text).short_description == "Foo"
    assert parse(text).long_description

# Generated at 2022-06-25 16:35:09.007122
# Unit test for function parse
def test_parse():
    assert 0 == len(parse("").meta)
    assert 0 == len(parse("\n").meta)
    assert 0 == len(parse("\n\n").meta)
    assert 0 == len(parse(" ").meta)
    assert 0 == len(parse("  ").meta)
    assert 1 == len(parse("\n ").meta)
    assert 1 == len(parse(" \n").meta)
    assert 1 == len(parse("\n\n ").meta)
    assert 1 == len(parse(" \n\n").meta)
    assert 1 == len(parse(" \n ").meta)

    assert ' ' == parse("").short_description
    assert ' ' == parse("\n").short_description
    assert '' == parse("\n\n").short_description
    assert ' ' == parse(" ").short_description

# Generated at 2022-06-25 16:35:16.917335
# Unit test for function parse
def test_parse():
    assert parse(None) == Docstring()
    assert parse("") == Docstring()


# Generated at 2022-06-25 16:35:25.964065
# Unit test for function parse
def test_parse():
    str = """Compute the x and y coordinates of a sine wave.

:param int n: The number of samples to generate.
:param float T: The period of the wave form.
:param int f: The frequency of the wave form.
:param str phase: The phase offset of the wave form.
:returns: The ``x`` and ``y`` coordinates of the wave form.
:raises ValueError: If ``phase`` is not one of ``"rising"``,
    ``"falling"`` or ``"both"``.
"""

# Generated at 2022-06-25 16:35:34.451408
# Unit test for function parse
def test_parse():
    assert parse.__doc__ is not None
    docstring_0 = parse('')
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.meta == [
        DocstringMeta(args=[], description='')
    ]
    docstring_1 = parse('test')
    assert docstring_1.short_description == 'test'
    assert docstring_1.long_description is None
    assert docstring_1.meta == [
        DocstringMeta(args=[], description='')
    ]
    docstring_2 = parse('test\n\nlong')
    assert docstring_2.short_description == 'test'
    assert docstring_2.long_description == 'long'

# Generated at 2022-06-25 16:35:36.442753
# Unit test for function parse
def test_parse():
  print("Testing function: parse")
  test_case_0()

# Program entry point

# Generated at 2022-06-25 16:35:47.005509
# Unit test for function parse
def test_parse():
    str_0 = """\
            Single-line summary.

            Single-line extended description.

            Parameters
            ----------

            Returns
            -------
            """
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Single-line summary."
    assert docstring_0.long_description == "Single-line extended description."
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.params_ordered == True
    assert docstring_0.params_special == True
    assert docstring_0.returns_special == True
    assert docstring_0.yields_special == False
    assert docstring_0.raises_special == False


# Generated at 2022-06-25 16:35:58.753932
# Unit test for function parse
def test_parse():
    str = '''
        short description.

        long description.

        :param x: param x.
        :param y: param y. Defaults to False.
        :returns: returns.
        :rtype: None

        :raises: raises.
        :raises ValueError: raises ValueError.
        :raises Exception: raises Exception.
    '''
    docstring = parse(str)

    assert docstring.short_description == 'short description.'
    assert docstring.blank_after_short_description
    assert docstring.long_description == 'long description.'
    assert docstring.blank_after_long_description

    assert len(docstring.meta) == 4

    param = docstring.meta[0]
    assert isinstance(param, DocstringParam)
    assert param.args == ["param", "x"]


# Generated at 2022-06-25 16:36:05.788687
# Unit test for function parse
def test_parse():
    str_1 = "Hello world"
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "Hello world"
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is False
    assert docstring_1.blank_after_long_description is False
    assert len(docstring_1.meta) == 0

    str_2 = "Hello world\n\nGoodbye world\n"
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == "Hello world"
    assert docstring_2.long_description == "Goodbye world"
    assert docstring_2.blank_after_short_description is True
    assert docstring_2.blank_after_long_description is False


# Generated at 2022-06-25 16:36:08.627030
# Unit test for function parse
def test_parse():
    try:
        test_case_0()
    except ParseError as err:
        print(err)
    else:
        print('Passed!')

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:36:16.955679
# Unit test for function parse
def test_parse():
    assert parse('short desc\n\nlong desc\n\n') == Docstring(
        short_description='short desc',
        blank_after_short_description=True,
        long_description='long desc',
        meta=[],
        blank_after_long_description=True
    )
    assert parse('short desc\n\n\nlong desc\n') == Docstring(
        short_description='short desc',
        blank_after_short_description=True,
        long_description='long desc',
        meta=[],
        blank_after_long_description=False
    )

# Generated at 2022-06-25 16:36:35.379464
# Unit test for function parse
def test_parse():
    # pass
    str_0 = 'Compute the x and y coordinates of a sine wave.\n\n:param int n: The number of samples to generate.\n:param float T: The period of the wave form.\n:param int f: The frequency of the wave form.\n:param str phase: The phase offset of the wave form.\n:returns: The ``x`` and ``y`` coordinates of the wave form.\n:raises ValueError: If ``phase`` is not one of ``"rising"``,\n    ``"falling"`` or ``"both"``.\n'
    str_1 = 'Compute the x and y coordinates of a sine wave.\n\nReturns:\n    The ``x`` and ``y`` coordinates of the wave form.\n'
    # str_2 = """Return a new

# Generated at 2022-06-25 16:36:42.606818
# Unit test for function parse
def test_parse():
    str_0 = 'Compute the x and y coordinates of a sine wave.\n\n:param int n: The number of samples to generate.\n:param float T: The period of the wave form.\n:param int f: The frequency of the wave form.\n:param str phase: The phase offset of the wave form.\n:returns: The ``x`` and ``y`` coordinates of the wave form.\n:raises ValueError: If ``phase`` is not one of ``"rising"``,\n    ``"falling"`` or ``"both"``.\n'
    str_1 = ""
    str_2 = "this is a test\n"
    str_3 = "\n:param int a: the first value.\n"
    str_4 = "This is a test.\n"

    # Test

# Generated at 2022-06-25 16:36:47.067877
# Unit test for function parse
def test_parse():
    test_case_0()
    # assert parse(str_0) == expected_result_0
    print("Test passed!")
    
# Program test

# Generated at 2022-06-25 16:36:48.384249
# Unit test for function parse
def test_parse():
    assert True == True
    # assert True == False

# Test cases


# Generated at 2022-06-25 16:36:55.795545
# Unit test for function parse
def test_parse():
    assert(parse(str_0).short_description == 'Compute the x and y coordinates of a sine wave.')
    assert(parse(str_0).long_description == """The number of samples to generate.\nThe period of the wave form.\nThe frequency of the wave form.\nThe phase offset of the wave form.\nThe ``x`` and ``y`` coordinates of the wave form.\nIf ``phase`` is not one of ``"rising"``,\n    ``"falling"`` or ``"both"``.""")
    assert(parse(str_0).blank_after_short_description == True)
    assert(parse(str_0).blank_after_long_description == False)
    assert(parse(str_0).meta[0].args == ['param', 'int', 'n'])

# Generated at 2022-06-25 16:37:05.864783
# Unit test for function parse
def test_parse():
    print("Testing parse...", end="")

    str_0 = 'Compute the x and y coordinates of a sine wave.\n\n:param int n: The number of samples to generate.\n:param float T: The period of the wave form.\n:param int f: The frequency of the wave form.\n:param str phase: The phase offset of the wave form.\n:returns: The ``x`` and ``y`` coordinates of the wave form.\n:raises ValueError: If ``phase`` is not one of ``"rising"``,\n    ``"falling"`` or ``"both"``.\n'
    str_1 = 'Compute the x and y coordinates of a sine wave.\n\n:param str phase:\n    The phase offset of the wave form.\n'

# Generated at 2022-06-25 16:37:06.706629
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:37:16.675055
# Unit test for function parse
def test_parse():
    str_0 = 'Compute the x and y coordinates of a sine wave.\n\n:param int n: The number of samples to generate.\n:param float T: The period of the wave form.\n:param int f: The frequency of the wave form.\n:param str phase: The phase offset of the wave form.\n:returns: The ``x`` and ``y`` coordinates of the wave form.\n:raises ValueError: If ``phase`` is not one of ``"rising"``,\n    ``"falling"`` or ``"both"``.\n'
    result_0 = parse(str_0)

    assert(result_0.short_description == 'Compute the x and y coordinates of a sine wave.')

# Generated at 2022-06-25 16:37:28.494281
# Unit test for function parse

# Generated at 2022-06-25 16:37:35.661416
# Unit test for function parse
def test_parse():
    str_0 = 'Compute the x and y coordinates of a sine wave.\n\n:param int n: The number of samples to generate.\n:param float T: The period of the wave form.\n:param int f: The frequency of the wave form.\n:param str phase: The phase offset of the wave form.\n:returns: The ``x`` and ``y`` coordinates of the wave form.\n:raises ValueError: If ``phase`` is not one of ``"rising"``,\n    ``"falling"`` or ``"both"``.\n'

    parse(str_0)


# Generated at 2022-06-25 16:37:42.764997
# Unit test for function parse
def test_parse():
    test_case_0()

test_parse()

# Generated at 2022-06-25 16:37:46.914128
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:37:56.015152
# Unit test for function parse
def test_parse():
    text = 'Compute the x and y coordinates of a sine wave.\n\n:param int n: The number of samples to generate.\n:param float T: The period of the wave form.\n:param int f: The frequency of the wave form.\n:param str phase: The phase offset of the wave form.\n:returns: The ``x`` and ``y`` coordinates of the wave form.\n:raises ValueError: If ``phase`` is not one of ``"rising"``,\n    ``"falling"`` or ``"both"``.\n'

# Generated at 2022-06-25 16:37:56.866345
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:37:57.598737
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:38:10.594094
# Unit test for function parse
def test_parse():
    str_0 = 'Compute the x and y coordinates of a sine wave.\n\n:param int n: The number of samples to generate.\n:param float T: The period of the wave form.\n:param int f: The frequency of the wave form.\n:param str phase: The phase offset of the wave form.\n:returns: The ``x`` and ``y`` coordinates of the wave form.\n:raises ValueError: If ``phase`` is not one of ``"rising"``,\n    ``"falling"`` or ``"both"``.\n'
    docstring_0 = parse(str_0)
    str_1 = '\n'
    docstring_1 = parse(str_1)
    str_2 = '\n\n'

# Generated at 2022-06-25 16:38:12.563578
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:38:19.636013
# Unit test for function parse
def test_parse():
    """Empty docstring"""
    str_0 = ''
    expected_meta_0 = []
    expected_short_desc_0 = None
    expected_long_desc_0 = None
    assert_docstring_equal(str_0, expected_meta_0, expected_short_desc_0, expected_long_desc_0)
    """Short description only"""
    str_1 = 'Compute the x and y coordinates of a sine wave.'
    expected_meta_1 = []
    expected_short_desc_1 = 'Compute the x and y coordinates of a sine wave.'
    expected_long_desc_1 = None
    assert_docstring_equal(str_1, expected_meta_1, expected_short_desc_1, expected_long_desc_1)

# Generated at 2022-06-25 16:38:29.396996
# Unit test for function parse
def test_parse():
    str_0 = 'Compute the x and y coordinates of a sine wave.\n\n:param int n: The number of samples to generate.\n:param float T: The period of the wave form.\n:param int f: The frequency of the wave form.\n:param str phase: The phase offset of the wave form.\n:returns: The ``x`` and ``y`` coordinates of the wave form.\n:raises ValueError: If ``phase`` is not one of ``"rising"``,\n    ``"falling"`` or ``"both"``.\n'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:38:30.709476
# Unit test for function parse
def test_parse():
    assert 0, "Test not implemented."

# Generated at 2022-06-25 16:38:58.959412
# Unit test for function parse
def test_parse():
    str_0 = 'Setup sections.\n\n        :param sections: Recognized sections or None to defaults.\n        :type sections: list or None\n        :returns: All registered sections\n        :rtype: dict\n        '
    str_1 = '\n        '
    print(parse(str_0))
    print(parse(str_1))

# Generated at 2022-06-25 16:39:08.100853
# Unit test for function parse
def test_parse():
    # Make sure the docstring parsing works
    #
    # Setup sections.
    #
    # :param sections: Recognized sections or None to defaults.
    #
    str_0 = "Setup sections.\n\n        :param sections: Recognized sections or None to defaults.\n        "
    docstring_0 = parse(str_0)

    assert docstring_0.short_description == "Setup sections."
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 1
    assert docstring_0.meta[0].key == "param"
    assert docstring_0.meta[0].type_name == None
    assert docstring

# Generated at 2022-06-25 16:39:21.016980
# Unit test for function parse
def test_parse():
    import pdb
    # pdb.set_trace()
    docstring_0 = parse('')
    assert docstring_0.long_description is None
    assert docstring_0.short_description is None
    assert docstring_0.meta == []
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    docstring_1 = parse('\n')
    assert docstring_1.long_description is None
    assert docstring_1.short_description is None
    assert docstring_1.meta == []
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.blank_after_long_description == False

# Generated at 2022-06-25 16:39:24.632001
# Unit test for function parse
def test_parse():
    assert True == True

if __name__ == '__main__':
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-25 16:39:29.453626
# Unit test for function parse
def test_parse():
    # TODO: implement unit test for parse
    docstring = parse(
        'Takes a dataset and a list of files.\n\n        :param names: list of file names.\n        :param first_index: int, the index of the first file.\n        '
    )
    return docstring

test_case_0()

# Generated at 2022-06-25 16:39:37.174854
# Unit test for function parse
def test_parse():
    # Setup
    str_0 = "Create a new Section.\n\n        :Example:   \n        \n        :Args:\n            \n            name: str\n                Name of section.\n            attrs: Dict[str, Any]\n                Arbitrary file attributes to be stored in the section.\n            description: str\n                Description of section.\n            \n        :Raises:\n            ValueError:\n                If the section already exists.\n            ValueError:\n                If the section is not standalone.\n            \n        :Returns:\n            Section:\n                The newly created section.\n            \n        :Example:   \n        \n        "

# Generated at 2022-06-25 16:39:46.419984
# Unit test for function parse
def test_parse():
    # Setup
    str_0 = ''
    str_1 = 'Test function should return True.\n\n        '
    str_2 = 'Test function should return True.\n\n        :param arg: Test argument.\n        '
    str_3 = 'Test function should return True.\n\n        :param str arg: Test argument.\n        :rtype: bool\n        '
    str_4 = 'Test function should return True.\n\n        :param str arg: Test argument. Optional and defaults to \'hello\'.\n        :param int limit: Limits the input length. Optional and defaults to 10.\n        :param bool verbose: Verbosity level.\n        :returns: True if the test passes.\n        '

# Generated at 2022-06-25 16:39:56.603769
# Unit test for function parse
def test_parse():
    # test case 0
    str_0 = 'Setup sections.\n\n        :param sections: Recognized sections or None to defaults.\n        '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Setup sections.'
    assert docstring_0.long_description == 'Recognized sections or None to defaults.'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == False
    assert isinstance(docstring_0.meta[0], DocstringParam)
    assert docstring_0.meta[0].arg_name == 'sections'
    assert docstring_0.meta[0].type_name == 'Recognized'
    assert docstring_0.meta[0].is_optional == None
   

# Generated at 2022-06-25 16:39:58.182912
# Unit test for function parse
def test_parse():
    import docstring_parser
    test_case_0()

# Generated at 2022-06-25 16:40:06.981866
# Unit test for function parse
def test_parse():
    assert parse(None) == Docstring()
    assert parse('') == Docstring()
    assert parse(
        'Setup sections.\n\n        :param sections: Recognized sections or None to defaults.\n        '
    ).short_description == 'Setup sections.'
    assert parse(
        'Setup sections.\n\n        :param sections: Recognized sections or None to defaults.\n        '
    ).meta == [DocstringParam(args=['param', 'sections'], arg_name='sections', type_name=None, is_optional=None, default=None, description='Recognized sections or None to defaults.')]
    assert parse('\n    Split a text into several lines, by splitting on\n    :samp:`\\n` or :samp:`\\r\\n`.'
                 ).meta == []

# Generated at 2022-06-25 16:40:20.611986
# Unit test for function parse
def test_parse():
    from .parse import parse
    test_case_0()

# Generated at 2022-06-25 16:40:31.378741
# Unit test for function parse
def test_parse():
    docstring_1 = parse("")
    assert docstring_1.short_description == None
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.blank_after_long_description == False
    assert docstring_1.meta == []

    docstring_2 = parse("Test.\n")
    assert docstring_2.short_description == "Test."
    assert docstring_2.long_description == None
    assert docstring_2.blank_after_short_description == False
    assert docstring_2.blank_after_long_description == False
    assert docstring_2.meta == []

    docstring_3 = parse("Test.\n\n")
    assert docstring_3.short_description == "Test."


# Generated at 2022-06-25 16:40:44.138950
# Unit test for function parse
def test_parse():
    str_0 = 'Setup sections.\n\n        :param sections: Recognized sections or None to defaults.\n        '
    docstring_0, _ = parse(str_0), (51, 52, 1, 49)

# Generated at 2022-06-25 16:40:46.302984
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:40:49.351849
# Unit test for function parse
def test_parse():
  assert(True)


# Generated at 2022-06-25 16:40:50.139337
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:40:51.029500
# Unit test for function parse
def test_parse():
    assert parse == parse


# Generated at 2022-06-25 16:41:04.069630
# Unit test for function parse
def test_parse():
    assert parse(
        'Parse the ReST-style docstring into its components.\n    :returns: parsed docstring\n    '
    ) == Docstring(
        short_description='Parse the ReST-style docstring into its components.',
        long_description='parsed docstring',
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[
            DocstringParam(
                args=['returns'],
                description='parsed docstring',
                arg_name='returns',
                type_name=None,
                is_optional=None,
                default=None,
            )
        ],
    )

# Generated at 2022-06-25 16:41:14.626782
# Unit test for function parse
def test_parse():

    from . import common

    # Case 1
    str_0 = 'Setup sections.\n\n        :param sections: Recognized sections or None to defaults.\n        '
    docstring_0 = parse(str_0)
    assert len(docstring_0.meta) == 1
    assert docstring_0.meta[0].args == ['param', 'sections']
    assert (docstring_0.meta[0].description == 'Recognized sections or None to defaults.')

    # Case 2
    str_1 = 'Setup sections.\n\n        :param sections: Recognized sections or None to defaults.\n        :type sections: dict\n        '
    docstring_1 = parse(str_1)
    assert len(docstring_1.meta) == 1

# Generated at 2022-06-25 16:41:25.802935
# Unit test for function parse
def test_parse():
    str_0 = "    Set or update a value in the configuration.\n\n    :param key: A dotted-notation key string.\n    :param value: A value or value factory.\n    :param repr: The repr of the value or factory.\n    "
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Set or update a value in the configuration."
    assert (
        docstring_0.long_description
        == 'param key: A dotted-notation key string.\n    :param value: A value or value factory.\n    :param repr: The repr of the value or factory.'
    )
    assert isinstance(docstring_0.meta[0], DocstringParam)
    assert docstring_0.meta[0].args == ["param", "key"]
   

# Generated at 2022-06-25 16:42:00.975685
# Unit test for function parse
def test_parse():
    text = 'short description\n\n:param param1: description\n:type param1: :term:`param1 type`\n:returns: description\n:rtype: :term:`return type`\n:raises keyError: raises an exception\n:raises Exception: exception\n:param: param2 descr\n'
    docstring = parse(text)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 16:42:13.989311
# Unit test for function parse
def test_parse():
    str_0 = 'Setup sections.\n\n        :param sections: Recognized sections or None to defaults.\n        '
    docstring_0 = parse(str_0)

    assert docstring_0.short_description == 'Setup sections.'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.long_description == ''
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 1
    assert docstring_0.meta[0].args == ['param', 'sections']
    assert docstring_0.meta[0].description == 'Recognized sections or None to defaults.'

    str_1 = 'Clear all user-defined roots.\n\n        Defaults to the internal root '

# Generated at 2022-06-25 16:42:20.269093
# Unit test for function parse
def test_parse():
    test_case_0()
    # assert docs_0.short_description == 'Setup sections.'
    # assert docs_0.long_description == None
    # assert docs_0.meta[0].arg_name == 'sections'
    # assert len(docs_0.meta) == 1
    # assert docs_0.meta[0].is_optional

test_parse()

# Generated at 2022-06-25 16:42:34.432807
# Unit test for function parse

# Generated at 2022-06-25 16:42:37.010201
# Unit test for function parse
def test_parse():
    test_case_0()

    assert 1==1

# Generated at 2022-06-25 16:42:45.286911
# Unit test for function parse
def test_parse():

    str_0 = 'Setup sections.\n\n        :param sections: Recognized sections or None to defaults.\n        '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Setup sections.'
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description is False
    assert len(docstring_0.meta) == 1
    assert docstring_0.meta[0].args == ['param', 'sections']
    assert docstring_0.meta[0].description == 'Recognized sections or None to defaults.'


    str_1 = 'Setup sections.\n\n:param sections: Recognized sections or None to defaults.\n        '
    docstring

# Generated at 2022-06-25 16:42:49.133604
# Unit test for function parse
def test_parse():
    # Pickling of parse
    import cloudpickle
    import gzip
    str_0 = 'Setup sections.\n\n        :param sections: Recognized sections or None to defaults.\n        '
    docstring_0 = parse(str_0)
    unpickled_docstring_0 = cloudpickle.loads(gzip.zlib.decompress(gzip.compress(cloudpickle.dumps(docstring_0))))
    assert (docstring_0 == unpickled_docstring_0)



# Generated at 2022-06-25 16:42:53.482512
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:42:56.191318
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:43:06.523063
# Unit test for function parse
def test_parse():
    str_0 = ' '
    ret_0 = parse(str_0)
    assert ret_0.short_description is None
    assert not ret_0.blank_after_long_description
    assert ret_0.blank_after_short_description is False
    assert ret_0.long_description is None
    assert not ret_0.meta
    str_1 = "  \n "
    ret_1 = parse(str_1)
    assert ret_1.short_description is None
    assert not ret_1.blank_after_long_description
    assert not ret_1.blank_after_short_description
    assert ret_1.long_description is None
    assert not ret_1.meta