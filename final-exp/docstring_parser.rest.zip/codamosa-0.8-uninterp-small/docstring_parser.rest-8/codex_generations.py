

# Generated at 2022-06-25 16:33:54.056544
# Unit test for function parse

# Generated at 2022-06-25 16:34:05.372986
# Unit test for function parse
def test_parse():
    assert(parse("") == parse(" ") == parse(None))
    assert(parse("") == Docstring())
    assert(parse("a") == Docstring(short_description="a"))
    assert(parse("a\nb") == Docstring(short_description="a", long_description="b"))

    # multi-line short description
    assert (
        parse("a\nb") == Docstring(short_description="a", long_description="b")
    )
    assert (
        parse("a\n\nb")
        == Docstring(
            short_description="a", long_description="b", blank_after_short_description=True
        )
    )

# Generated at 2022-06-25 16:34:13.078853
# Unit test for function parse
def test_parse():
    print("Testing function 'parse'... ", end = "")
    # Check that function returns 'Docstring' type
    assert(type(parse("")) == Docstring)
    # Check that empty input string returns a 'Docstring' with correct
    # default attributes of blank strings
    assert(parse("") == Docstring())
    # Check that function can parse a simple input
    print("Pass!")

########################################################################
# Ignore everything below this line
########################################################################


# Generated at 2022-06-25 16:34:14.178357
# Unit test for function parse
def test_parse():
    assert False #TODO: implement your test here


# Generated at 2022-06-25 16:34:23.603115
# Unit test for function parse
def test_parse():
    source = '''\
    Shuffle an array.

    This is an example of a "long-form" docstring.  It is used to
    demonstrate the use of the \\n\\n blank line to break up the string
    into short-form and long-form parts.

    If the **random** argument is True, the array is shuffled in-place.
    Otherwise, a copy of the array is shuffled.

    :param array: The array to shuffle.
    :type array: list or numpy.ndarray
    :param random: If True, shuffle the array in-place instead of making
        a copy.
    :type random: bool
    :returns: A shuffled copy of the array if **random** is False, or
        None if **random** is True.
    '''
    docstring_1 = parse(source)
   

# Generated at 2022-06-25 16:34:35.182968
# Unit test for function parse
def test_parse():
    str_0 = "x, > 0."
    expected_0 = Docstring(
        short_description='x, > 0.',
        long_description=None,
        meta=[
            DocstringMeta(
                args=[],
                description=''
            )
        ],
        blank_after_short_description=False,
        blank_after_long_description=True
    )
    result_0 = parse(str_0)
    assert result_0 == expected_0

    str_1 = ": Returns:  None."

# Generated at 2022-06-25 16:34:43.233322
# Unit test for function parse
def test_parse():
    global str_0
    # Setup
    str_0 = "Zb#,>2f~S5+\t;ig'^sZb"
    docstring_0 = parse(str_0)
    docstring_1 = parse(str_0)

    # Assertions
    assert docstring_0 is not None
    assert docstring_1 is not None
    assert docstring_0 == docstring_1
    assert docstring_0 != str_0
    assert docstring_1 != str_0
    assert docstring_0 is not str_0
    assert docstring_1 is not str_0
    assert str_0 == docstring_0
    assert str_0 == docstring_1
    assert str_0 is not docstring_0
    assert str_0 is not docstring_1
    assert docstring_

# Generated at 2022-06-25 16:34:51.775871
# Unit test for function parse
def test_parse():
    str_0 = "Bjs;$)7;1i%$'7Vu~"
    docstring_0 = parse(str_0)
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.short_description == "Bjs;$)7;1i%$'7Vu~"
    assert docstring_0.blank_after_long_description is False
    assert len(docstring_0.meta) == 0


# Generated at 2022-06-25 16:35:01.549916
# Unit test for function parse
def test_parse():
    case_0 = "Zb#,>2f~S5+\t;ig'^sZb"
    expected_0 = '''
    ParsedDocstring(
        short_description='Zb#,>2f~S5+\t;ig\'^sZb',
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    '''
    case_1 = "j<F[A\n\"3q:f;W,X^1@$Z\n!3q:f;W,X^1@$Z\nK[A"

# Generated at 2022-06-25 16:35:10.955661
# Unit test for function parse
def test_parse():
    str_0 = "# Parameters\n"
    str_1 = "# :param iris_dataframe: Iris dataset\n"
    str_2 = "# :return: None\n"
    str_3 = "# Raises:\n"
    str_4 = "#   ValueError: If `shape` is not `(150, 5)`\n"
    str_5 = "\n"
    str_6 = "This is a long description.\n"
    str_7 = "Here is another line.\n"
    str_8 = "\n"
    str_9 = "Here is the second paragraph.\n"
    str_10 = "\n"
    str_11 = "In the third paragraph we are going to mention `pandas`_ ."

# Generated at 2022-06-25 16:35:31.591175
# Unit test for function parse
def test_parse():
    from .common import DocstringMeta, DocstringParam, DocstringReturns

    assert parse("") == Docstring()
    assert (
        parse("Short description.") == Docstring(short_description="Short description.")
    )
    assert (
        parse(
            "Short description.\n\nLong description."
        )
        == Docstring(
            short_description="Short description.",
            long_description="Long description.",
            blank_after_short_description=True,
            blank_after_long_description=False,
        )
    )

# Generated at 2022-06-25 16:35:43.267431
# Unit test for function parse

# Generated at 2022-06-25 16:35:49.098345
# Unit test for function parse
def test_parse():
    try:
        assert callable(parse)
    except AssertionError:
        raise AssertionError(f"expected parse to be callable")



# Generated at 2022-06-25 16:35:59.276586
# Unit test for function parse

# Generated at 2022-06-25 16:36:06.202295
# Unit test for function parse

# Generated at 2022-06-25 16:36:16.200491
# Unit test for function parse
def test_parse():
    str_0 = '   hello\n\n     world\n\n\n:param x: xxx\n:param y: yyy\n:returns: zzz\n\nhello\n\n:param x: xxx\n:param y: yyy\n:returns: zzz\n'
    docstring_0 = parse(str_0)
    print(docstring_0.short_description)
    print(docstring_0.blank_after_short_description)
    print(docstring_0.blank_after_long_description)
    print(docstring_0.long_description)
    for meta_0 in docstring_0.meta:
        print(meta_0.type)
        print(meta_0.args)
        print(meta_0.description)


# Generated at 2022-06-25 16:36:27.148421
# Unit test for function parse

# Generated at 2022-06-25 16:36:28.849085
# Unit test for function parse
def test_parse():
    test_case_0()
    print("All tests passed")

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:36:39.343761
# Unit test for function parse

# Generated at 2022-06-25 16:36:48.171904
# Unit test for function parse

# Generated at 2022-06-25 16:37:05.673054
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-25 16:37:15.656710
# Unit test for function parse
def test_parse():
    def test_docstring_0():
        str_0 = '''Shuffle an array.

This is an example of a "long-form" docstring.  It is used to
demonstrate the use of the \\n\\n blank line to break up the string
into short-form and long-form parts.

If the **random** argument is True, the array is shuffled in-place.
Otherwise, a copy of the array is shuffled.

:param array: The array to shuffle.
:type array: list or numpy.ndarray
:param random: If True, shuffle the array in-place instead of making
    a copy.
:type random: bool
:returns: A shuffled copy of the array if **random** is False, or
    None if **random** is True.
'''

# Generated at 2022-06-25 16:37:28.467897
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('\n') == Docstring()
    assert parse('        ') == Docstring()
    assert parse('Simple description.') == \
        Docstring(short_description='Simple description.')
    assert parse('Simple description.\n') == \
        Docstring(short_description='Simple description.')
    assert parse('Simple description.\n\n') == \
        Docstring(short_description='Simple description.')
    assert parse('Simple description.\n\nDescription continues.') == \
        Docstring(
            short_description='Simple description.',
            blank_after_short_description=True,
            blank_after_long_description=True,
            long_description='Description continues.'
        )
    assert parse('Simple description.\n\nDescription continues.\n')

# Generated at 2022-06-25 16:37:36.910298
# Unit test for function parse

# Generated at 2022-06-25 16:37:48.073008
# Unit test for function parse
def test_parse():
    # Assert that the docstring was parsed correctly
    def f(x: int, y: int) -> float:
        '''Computes the average of two numbers.

        :param int x: The first number
        :param int y: The second number
        :raises ValueError: If a number is not finite
        :returns: The average of the two numbers
        :rtype: float
        '''
        # body here
        return 0.0

    docstring_1 = parse(f.__doc__)

    # Assert that the docstring's short description parsed correctly
    assert docstring_1.short_description == "Computes the average of two numbers."

    # Assert that the docstring's long description parsed correctly
    assert docstring_1.long_description == """
    If a number is not finite
    """

    # Ass

# Generated at 2022-06-25 16:37:50.710280
# Unit test for function parse
def test_parse():
    pass  # TODO: Write unit test

# Generated at 2022-06-25 16:37:56.952502
# Unit test for function parse

# Generated at 2022-06-25 16:37:58.181692
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:38:07.888393
# Unit test for function parse

# Generated at 2022-06-25 16:38:11.138394
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:38:39.748897
# Unit test for function parse

# Generated at 2022-06-25 16:38:51.479703
# Unit test for function parse

# Generated at 2022-06-25 16:39:04.168243
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()

# Generated at 2022-06-25 16:39:06.700736
# Unit test for function parse
def test_parse():
    test_case_0()



# Generated at 2022-06-25 16:39:14.086634
# Unit test for function parse
def test_parse():
    print("Testing parse(text)")

    # Test cases

    # Test case 0

# Generated at 2022-06-25 16:39:20.419251
# Unit test for function parse

# Generated at 2022-06-25 16:39:30.791773
# Unit test for function parse

# Generated at 2022-06-25 16:39:35.312823
# Unit test for function parse
def test_parse():
    assert True



# Generated at 2022-06-25 16:39:36.899087
# Unit test for function parse
def test_parse():
    pass

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:39:46.269051
# Unit test for function parse

# Generated at 2022-06-25 16:40:29.418772
# Unit test for function parse
def test_parse():
    # Function call (line 9)
    test_case_0()


if __name__ == "__main__":
    # Unit test for function parse
    test_parse()

# Generated at 2022-06-25 16:40:41.925856
# Unit test for function parse
def test_parse():
    assert docstring_0.short_description == "Shuffle an array."
    assert not docstring_0.blank_after_short_description
    assert docstring_0.blank_after_long_description
    assert docstring_0.long_description == 'This is an example of a "long-form" docstring.  It is used to demonstrate the use of the \\n\\n blank line to break up the string into short-form and long-form parts. If the **random** argument is True, the array is shuffled in-place. Otherwise, a copy of the array is shuffled.'
    assert docstring_0.meta[0].args == ['param', 'array', 'The array to shuffle.']
    assert docstring_0.meta[0].description == 'type array: list or numpy.ndarray'

# Generated at 2022-06-25 16:40:53.136859
# Unit test for function parse

# Generated at 2022-06-25 16:40:57.841261
# Unit test for function parse
def test_parse():
    str_0 = '    '
    docstring_0 = parse(str_0)
    docstring_1 = parse('')
    str_2 = '    Shuffle an array.'
    docstring_2 = parse(str_2)

# Generated at 2022-06-25 16:41:06.212700
# Unit test for function parse
def test_parse():
    # Test with a short-form docstring:
    str_0 = 'Shuffle an array.'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Shuffle an array.'
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == None
    assert docstring_0.meta == []

    # Test with a long-form docstring:

# Generated at 2022-06-25 16:41:09.985622
# Unit test for function parse
def test_parse():
    try:
        assert( parse("foo") ) == "foo"
    except AssertionError:
        raise AssertionError("test_parse")


# Generated at 2022-06-25 16:41:20.455578
# Unit test for function parse

# Generated at 2022-06-25 16:41:21.278675
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:41:29.689375
# Unit test for function parse
def test_parse():
    test = """
    Shuffle an array.

    This is an example of a "long-form" docstring.  It is used to
    demonstrate the use of the \\n\\n blank line to break up the string
    into short-form and long-form parts.

    If the **random** argument is True, the array is shuffled in-place.
    Otherwise, a copy of the array is shuffled.

    :param array: The array to shuffle.
    :type array: list or numpy.ndarray
    :param random: If True, shuffle the array in-place instead of making
        a copy.
    :type random: bool
    :returns: A shuffled copy of the array if **random** is False, or
        None if **random** is True.
    """

    docstring = parse(test)
    assert docstring.short

# Generated at 2022-06-25 16:41:30.689189
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:42:14.072632
# Unit test for function parse

# Generated at 2022-06-25 16:42:16.997588
# Unit test for function parse
def test_parse():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 16:42:20.408390
# Unit test for function parse
def test_parse():
    test_case_0()


# Generated at 2022-06-25 16:42:25.951929
# Unit test for function parse

# Generated at 2022-06-25 16:42:35.612918
# Unit test for function parse

# Generated at 2022-06-25 16:42:44.710566
# Unit test for function parse

# Generated at 2022-06-25 16:42:52.919594
# Unit test for function parse
def test_parse():
    assert callable(parse)
    result = parse("This is a docstring.")
    assert result.short_description == "This is a docstring."
    assert result.long_description is None
    assert result.blank_after_short_description
    assert result.blank_after_long_description
    assert not result.meta
    result = parse(
        """This is a docstring.

    This is the long description.
    """
    )
    assert result.short_description == "This is a docstring."
    assert result.long_description == "This is the long description."
    assert result.blank_after_short_description
    assert result.blank_after_long_description
    assert not result.meta
    result = parse(
        """This is a docstring.

    This is the long description.


    """
    )


# Generated at 2022-06-25 16:43:00.047741
# Unit test for function parse

# Generated at 2022-06-25 16:43:00.933483
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:43:08.904617
# Unit test for function parse
def test_parse():
    from .common import DocstringMeta, DocstringReturns
    docstring = parse("Some docstring.")
    assert docstring.short_description == "Some docstring."
    assert docstring.long_description is None
    assert len(docstring.meta) == 0
    docstring = parse("Shuffle an array.\n\nIf the **random** argument is True, the array is shuffled in-place.\nOtherwise, a copy of the array is shuffled.")
    assert docstring.short_description == "Shuffle an array."
    assert docstring.long_description == "If the **random** argument is True, the array is shuffled in-place.\nOtherwise, a copy of the array is shuffled."
    assert docstring.blank_after_short_description
    assert not docstring.blank_after_long_description