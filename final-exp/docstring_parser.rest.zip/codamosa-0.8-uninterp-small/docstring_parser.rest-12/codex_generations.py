

# Generated at 2022-06-25 16:33:48.421818
# Unit test for function parse
def test_parse():
    str_1 = None
    assert parse(str_1) == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

    str_2 = ""
    assert parse(str_2) == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

    str_3 = "foo bar baz"

# Generated at 2022-06-25 16:33:58.060873
# Unit test for function parse

# Generated at 2022-06-25 16:34:10.477119
# Unit test for function parse
def test_parse():
    # Empty input
    str_0 = None
    docstring_0 = parse(str_0)
    # Empty input - expected output
    short_desc_expected = None
    long_desc_expected = None
    blank_after_short_desc_expected = False
    blank_after_long_desc_expected = False
    meta_expected = []
    assert (
        docstring_0.short_description
        == short_desc_expected
    ), "Short description mismatch"
    assert (
        docstring_0.long_description
        == long_desc_expected
    ), "Long description mismatch"
    assert (
        docstring_0.blank_after_short_description
        == blank_after_short_desc_expected
    ), "Short description spacing mismatch"

# Generated at 2022-06-25 16:34:14.093193
# Unit test for function parse
def test_parse():
    f = open('/Users/gaozeyu/Desktop/test.txt')
    for text in f:
        parse(text)
    print("Success!")

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:34:23.579581
# Unit test for function parse
def test_parse():
    with open("test_files/test_rst_0.rst", 'r') as file:
        str_0 = file.read()
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "test_parse"
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True
    assert len(docstring_0.meta) == 2
    assert isinstance(docstring_0.meta[0], DocstringParam)
    assert docstring_0.meta[0].args == ['param', 'str', 'text']
    assert docstring_0.meta[0].description == 'test_parse'
    assert docstring_0.meta[0].arg_name == 'text'
    assert docstring_0

# Generated at 2022-06-25 16:34:35.183935
# Unit test for function parse
def test_parse():

    assert parse(None).short_description == None
    assert parse(None).long_description == None
    assert parse(None).meta == []
    assert parse(None).blank_after_short_description == False
    assert parse(None).blank_after_long_description == False

    assert parse("").short_description == None
    assert parse("").long_description == None
    assert parse("").meta == []
    assert parse("").blank_after_short_description == False
    assert parse("").blank_after_long_description == False

    assert parse("a").short_description == "a"
    assert parse("a").long_description == None
    assert parse("a").meta == []
    assert parse("a").blank_after_short_description == False
    assert parse("a").blank_after_long_description == False


# Generated at 2022-06-25 16:34:43.272085
# Unit test for function parse
def test_parse():
    import sys
    import pathlib
    sys.path.insert(0, str(pathlib.Path(__file__).parent.parent.parent.absolute()))
    import efrotool.docstring
    str_1 = '''
    Converts the given angle in degrees to radians.

    :param float angle: the angle in degrees

    :returns float: the angle in radians

    >>> degrees_to_radians(90)
    1.5707963267948966
    '''
    docstring_1 = efrotool.docstring.parse(str_1)
    assert docstring_1.short_description == "Converts the given angle in degrees to radians."
    assert docstring_1.blank_after_short_description == False

# Generated at 2022-06-25 16:34:53.989635
# Unit test for function parse
def test_parse():
    res = parse("""
        Single line docstring.
        """)
    assert res.short_description == "Single line docstring."
    assert res.long_description is None
    assert res.blank_after_short_description is False
    assert res.blank_after_long_description is False

    res = parse("""
        Single line docstring.

        With long description.
        """)
    assert res.short_description == "Single line docstring."
    assert res.long_description == "With long description."
    assert res.blank_after_short_description is False
    assert res.blank_after_long_description is True

    res = parse("""
        Single line docstring.

        With long description.

        """)
    assert res.short_description == "Single line docstring."

# Generated at 2022-06-25 16:34:59.408016
# Unit test for function parse
def test_parse():
    str_0 = None
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == None
    assert docstring_0.blank_after_short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_long_description == None
    assert docstring_0.meta == []
    str_1 = """
    "Three blind mice.

    See how they run!
    """
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == '"Three blind mice.'
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.long_description == 'See how they run!'
    assert docstring_1.blank_after_long_description == False
   

# Generated at 2022-06-25 16:35:03.573021
# Unit test for function parse
def test_parse():
    test_docstring = Docstring(
        short_description=None,
        blank_after_short_description=None,
        long_description=None,
        blank_after_long_description=None,
        meta=[
            DocstringMeta(args=[], description=None),
            DocstringMeta(args=[], description=None),
            DocstringMeta(args=[], description=None),
        ],
    )
    assert parse("") == test_docstring



# Generated at 2022-06-25 16:35:20.163893
# Unit test for function parse
def test_parse():
    sampleInput0 = """This function does something.

:param int x: The first parameter.
:param int y: The second parameter.

:returns: The return value.
:rtype: int
    """
    parsedOutput0 = parse(sampleInput0)
    assert parsedOutput0.short_description == "This function does something."
    assert parsedOutput0.long_description == "The first parameter. The second parameter. The return value."
    assert parsedOutput0.meta[1].description == "The return value."
    assert parsedOutput0.meta[1].type_name == "int"
    assert parsedOutput0.meta[0].description == "The first parameter."
    assert parsedOutput0.meta[0].arg_name == "x"
    assert parsedOutput0.meta[0].type_name == "int"
    assert parsedOutput

# Generated at 2022-06-25 16:35:30.364644
# Unit test for function parse
def test_parse():
    def test_case_1():
        """The first testing case."""

    def test_case_2():
        """The
        second test case."""

    def test_case_3():
        """First testing case.

        Expected output:
            The first testing case.
        """

    def test_case_4():
        """First testing case.

        Expected output:

            The first testing case.
        """

    def test_case_5():
        """First testing case.

        Expected output:

            The first testing case.

        """

    def test_case_6():
        """First testing case.

        Expected output:

            The first testing case.


        """

    def test_case_7():
        """First testing case.

        Expected output:
        The first testing case.
        """



# Generated at 2022-06-25 16:35:40.929270
# Unit test for function parse
def test_parse():
    # Tests for docstring parse
    assert parse("") == Docstring()

    # Test for functions with docstring
    assert parse(test_case_0.__doc__) is None
    assert parse(parse.__doc__) == Docstring(
        short_description="Parse the ReST-style docstring into its components.",
        blank_after_short_description=True,
        long_description="Mimics the output of Sphinx's autodoc extension.\n\n"
        ":returns: parsed docstring",
        blank_after_long_description=True,
        meta=[
            DocstringMeta(
                args=["returns"],
                description="parsed docstring",
                arg_name=None,
                type_name=None,
                is_optional=None,
            )
        ],
    )



# Generated at 2022-06-25 16:35:48.348874
# Unit test for function parse
def test_parse():
    text = '''\
        This is the first line of a docstring.
        This is the second line of a docstring.

        Parameters
        ----------

        :param a_b_c: This is the first line of
            This is the second line of
            This is the third line of
            This is the fourth line of
        :param d:
        :param e:
        :type e: this is e
        :param f: f
        :type f: this is f
        :param g: g
        :type g: this is g,
            this is the second line of g

        Other
        -----

        This is other section.
        This is the second line of other section.
        '''
    parse(text)



# Generated at 2022-06-25 16:35:59.193175
# Unit test for function parse
def test_parse():
    var_a = str()
    var_b = str()
    var_c = int()
    var_d = int()
    var_e = float()
    var_f = float()
    var_g = float()
    var_h = float()
    var_i = float()
    var_j = float()
    var_k = float()
    var_l = float()
    var_m = float()
    var_n = float()
    var_o = float()
    var_p = float()
    var_q = float()
    var_r = float()
    var_s = float()
    var_t = float()
    var_u = float()
    var_v = float()
    var_w = float()
    var_x = float()
    var_y = float()

# Generated at 2022-06-25 16:36:03.098067
# Unit test for function parse
def test_parse():
    """Test function parse"""
    source = inspect.getsource(test_case_0)
    func_0 = re.search(r"def.*:\n", source).group()
    docstring = parse(func_0)
    return docstring

docstring = test_parse()
print(docstring)

# Generated at 2022-06-25 16:36:07.989366
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("test\n") == Docstring(
        short_description="test",
        blank_after_short_description=True,
    )
    assert parse("test\ntest\n\n") == Docstring(
        short_description="test",
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description="test",
    )
    assert parse("test\n\nmore test\n\n") == Docstring(
        short_description="test",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="more test",
    )

# Generated at 2022-06-25 16:36:16.846062
# Unit test for function parse
def test_parse():
    d = Docstring()

# Generated at 2022-06-25 16:36:27.781042
# Unit test for function parse
def test_parse():
    param_kw = PARAM_KEYWORDS
    yields_kw = YIELDS_KEYWORDS
    raises_kw = RAISES_KEYWORDS
    returns_kw = RETURNS_KEYWORDS
    # case 0: "int_0 = 0"
    docstring_0 = parse(test_case_0.__doc__)
    assert docstring_0.short_description is None
    assert len(docstring_0.meta) == 0
    # case 1: "Set the delay between each read."
    docstring_1 = parse(test_case_1.__doc__)
    assert docstring_1.short_description == "Set the delay between each read."
    assert docstring_1.blank_after_short_description is True
    assert docstring_1.long_description is None
    assert docstring

# Generated at 2022-06-25 16:36:32.212797
# Unit test for function parse
def test_parse():
    # print(inspect.cleandoc(test_case_0.__doc__))
    print(parse(test_case_0.__doc__))

# Generated at 2022-06-25 16:37:00.230933
# Unit test for function parse
def test_parse():
    func_parse = parse.__code__.co_consts[0]

# Generated at 2022-06-25 16:37:08.647468
# Unit test for function parse
def test_parse():
    def func_0():
        '''
        this is a test function
        :param str name: a name string
        :param int age: a age integer
        :param bool sex: a sex bool
        :param int a?: a a integer
        :raises Exception: A Exception
        :returns: a string of test result
        '''
        pass

    docstring = parse(func_0.__doc__)
    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.blank_after_short_description)
    print(docstring.blank_after_long_description)
    # print(docstring.params)
    print(docstring.returns)
    print(docstring.raises)
    print("*" * 30)

# Generated at 2022-06-25 16:37:09.258844
# Unit test for function parse
def test_parse():
    """parse("""



# Generated at 2022-06-25 16:37:13.442442
# Unit test for function parse
def test_parse():
    import inspect
    import textwrap
    doc = inspect.getdoc(test_case_0)
    assert doc == None
    doc = inspect.getdoc(parse)
    res = parse(doc)
    assert res.short_description == "Parse the ReST-style docstring into its components."
    assert res.long_description == textwrap.dedent("""\
    :returns: parsed docstring""")

# Generated at 2022-06-25 16:37:20.137191
# Unit test for function parse

# Generated at 2022-06-25 16:37:22.573119
# Unit test for function parse
def test_parse():
    text = inspect.getdoc(test_case_0)
    print(parse(text))


# Generated at 2022-06-25 16:37:33.722250
# Unit test for function parse
def test_parse():
    import inspect
    import re
    import typing as T

    from .common import (
        PARAM_KEYWORDS,
        RAISES_KEYWORDS,
        RETURNS_KEYWORDS,
        YIELDS_KEYWORDS,
        Docstring,
        DocstringMeta,
        DocstringParam,
        DocstringRaises,
        DocstringReturns,
        ParseError,
    )

    def _build_meta(args: T.List[str], desc: str) -> DocstringMeta:
        key = args[0]

        if key in PARAM_KEYWORDS:
            if len(args) == 3:
                key, type_name, arg_name = args
                if type_name.endswith("?"):
                    is_optional = True

# Generated at 2022-06-25 16:37:46.499270
# Unit test for function parse
def test_parse():
    msg0 = """Empty docstring
    """
    expect0 = None
    get0 = parse(msg0)
    assert get0 == expect0
    
    msg1 = """ 
    The player can see the hidden state with great effort.
    The other players can see the hidden state.
    """
    expect1 = None
    get1 = parse(msg1)
    assert get1 == expect1
    
    msg6 = """
    The player can see the hidden state with great effort.
    The other players can see the hidden state.
    
    """
    expect6 = None
    get6 = parse(msg6)
    assert get6 == expect6
    

# Generated at 2022-06-25 16:37:55.797172
# Unit test for function parse
def test_parse():
    int_1 = 1
    text = """
    This is a short description.

    This is a long description.

    This is a long description continued from above.

    :param arg1: The first argument
    :param arg2: The second argument
    :returns int: The return value
    :raises ValueError: The exception type
    """
    docstring = parse(text)
    print("short_description: %s" % docstring.short_description)
    assert docstring.short_description == "This is a short description."
    print("blank_after_short_description: %s" % docstring.blank_after_short_description)
    assert docstring.blank_after_short_description == False
    print("long_description: %s" % docstring.long_description)

# Generated at 2022-06-25 16:37:59.087724
# Unit test for function parse
def test_parse():
    text = "Some example docstring."
    # text = ":type i_j: int\n:param i_j: the magnitude of the i-j displacement."
    # text = test_case_0.__doc__
    doc = parse(text)
    print(doc)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:38:06.755687
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:38:16.651029
# Unit test for function parse
def test_parse():
    assert parse(None) == Docstring()

    docstring = parse("")
    assert docstring == Docstring()

    docstring = parse("    ")
    assert docstring == Docstring()

    #

# Generated at 2022-06-25 16:38:28.990044
# Unit test for function parse
def test_parse():
    arg0 = '        This is the first line of a docstring.\n        This is the second line of a docstring.\n\n        Parameters\n        ----------\n\n        :param a_b_c: This is the first line of\n            This is the second line of\n            This is the third line of\n            This is the fourth line of\n        :param d:\n        :param e:\n        :type e: this is e\n        :param f: f\n        :type f: this is f\n        :param g: g\n        :type g: this is g,\n            this is the second line of g\n\n        Other\n        -----\n\n        This is other section.\n        This is the second line of other section.\n        '
    expected_0 = Docstring

# Generated at 2022-06-25 16:38:41.285282
# Unit test for function parse
def test_parse():
    str_0 = '        This is the first line of a docstring.\n        This is the second line of a docstring.\n\n        Parameters\n        ----------\n\n        :param a_b_c: This is the first line of\n            This is the second line of\n            This is the third line of\n            This is the fourth line of\n        :param d:\n        :param e:\n        :type e: this is e\n        :param f: f\n        :type f: this is f\n        :param g: g\n        :type g: this is g,\n            this is the second line of g\n\n        Other\n        -----\n\n        This is other section.\n        This is the second line of other section.\n        '

# Generated at 2022-06-25 16:38:42.148180
# Unit test for function parse
def test_parse():
    test_case_0()


# Generated at 2022-06-25 16:38:44.479317
# Unit test for function parse
def test_parse():
    test_case_0()

# Compare function's output with reference data

# Generated at 2022-06-25 16:38:55.094023
# Unit test for function parse
def test_parse():

    # Setup
    str_0 = "This is a docstring."
    str_1 = """This is a docstring.
    
    Parameters
    ----------
    param1 : this is the first line of description for param1.
    param2 : this is the first line of description for param2.
    param3 : this is the first line of description for param3.
    
    Returns
    -------
    nothing : this is the first line of description for return value.
    """

# Generated at 2022-06-25 16:39:05.958053
# Unit test for function parse

# Generated at 2022-06-25 16:39:13.804027
# Unit test for function parse
def test_parse():
    docstring_0 = parse("")
    docstring_1 = parse(" ")
    docstring_2 = parse("\n")
    docstring_3 = parse("\n\n")
    docstring_4 = parse("This is a docstring.")
    docstring_5 = parse("This is a docstring.\n")
    docstring_6 = parse("This is a docstring.\n\n")
    docstring_7 = parse("This is a docstring.\n    ")
    docstring_8 = parse("This is a docstring.\n\n    ")
    docstring_9 = parse("This is a docstring.\n This is second line of a docstring.")
    docstring_10 = parse("This is a docstring.\n\n This is second line of a docstring.")
    docstring

# Generated at 2022-06-25 16:39:24.672845
# Unit test for function parse
def test_parse():
    docstring = parse('''This is the first line of a docstring.
This is the second line of a docstring.

Parameters
----------

:param a_b_c: This is the first line of
    This is the second line of
    This is the third line of
    This is the fourth line of
:param d:
:param e:
:type e: this is e
:param f: f
:type f: this is f
:param g: g
:type g: this is g,
    this is the second line of g

Other
-----

This is other section.
This is the second line of other section.
''')
    assert len(docstring.meta) == 6
    # Parameters
    assert docstring.meta[0].arg_name == 'a_b_c'
    assert docstring.meta

# Generated at 2022-06-25 16:39:36.998770
# Unit test for function parse
def test_parse():
    """
    Test parse(text: str)

    test case 0
    """
    test_case_0()

# Generated at 2022-06-25 16:39:41.469281
# Unit test for function parse
def test_parse():
    assert inspect.cleandoc(parse.__doc__) == parse.__doc__
    assert parse("") is not None
    assert parse.__name__ == "parse"
    assert len(inspect.getsource(parse)) > 5000
    assert inspect.getsource(parse).count("\n") > 100

# Generated at 2022-06-25 16:39:51.443242
# Unit test for function parse
def test_parse():
    str_0 = '        This is the first line of a docstring.\n        This is the second line of a docstring.\n\n        Parameters\n        ----------\n\n        :param a_b_c: This is the first line of\n            This is the second line of\n            This is the third line of\n            This is the fourth line of\n        :param d:\n        :param e:\n        :type e: this is e\n        :param f: f\n        :type f: this is f\n        :param g: g\n        :type g: this is g,\n            this is the second line of g\n\n        Other\n        -----\n\n        This is other section.\n        This is the second line of other section.\n        '

# Generated at 2022-06-25 16:40:03.625469
# Unit test for function parse
def test_parse():
    # Test with 0 args
    str_0 = '        This is the first line of a docstring.\n        This is the second line of a docstring.\n\n        Parameters\n        ----------\n\n        :param a_b_c: This is the first line of\n            This is the second line of\n            This is the third line of\n            This is the fourth line of\n        :param d:\n        :param e:\n        :type e: this is e\n        :param f: f\n        :type f: this is f\n        :param g: g\n        :type g: this is g,\n            this is the second line of g\n\n        Other\n        -----\n\n        This is other section.\n        This is the second line of other section.\n        '

# Generated at 2022-06-25 16:40:14.894365
# Unit test for function parse
def test_parse():
    docstring_0 = parse('        This is the first line of a docstring.\n        This is the second line of a docstring.\n\n        Parameters\n        ----------\n\n        :param a_b_c: This is the first line of\n            This is the second line of\n            This is the third line of\n            This is the fourth line of\n        :param d:\n        :param e:\n        :type e: this is e\n        :param f: f\n        :type f: this is f\n        :param g: g\n        :type g: this is g,\n            this is the second line of g\n\n        Other\n        -----\n\n        This is other section.\n        This is the second line of other section.\n        ')
    assert doc

# Generated at 2022-06-25 16:40:24.951217
# Unit test for function parse
def test_parse():
    str1 = ""
    test_parse_str1(str1)

    str2 = "This is a short description."
    test_parse_str2(str2)

    str3 = "This is a short description.\n"
    test_parse_str3(str3)

    str4 = "\nThis is a short description.\n"
    test_parse_str4(str4)

    str5 = "\nThis is a short description.\n\n"
    test_parse_str5(str5)

    str6 = "This is a short description.\n\nThis is a long description."
    test_parse_str6(str6)

    str7 = "This is a short description.\n\nThis is a long description.\n"
    test_parse_str7(str7)

   

# Generated at 2022-06-25 16:40:31.646497
# Unit test for function parse
def test_parse():
    import pytest
    import rstdoc.parser.rest as _m_rest
    import rstdoc.errors as _m_errors
    import rstdoc.parser.common as _m_common

    # Test that parse returns an instance of Docstring

# Generated at 2022-06-25 16:40:44.139513
# Unit test for function parse
def test_parse():
    str_0 = '        This is the first line of a docstring.\n        This is the second line of a docstring.\n\n        Parameters\n        ----------\n\n        :param a_b_c: This is the first line of\n            This is the second line of\n            This is the third line of\n            This is the fourth line of\n        :param d:\n        :param e:\n        :type e: this is e\n        :param f: f\n        :type f: this is f\n        :param g: g\n        :type g: this is g,\n            this is the second line of g\n\n        Other\n        -----\n\n        This is other section.\n        This is the second line of other section.\n        '

# Generated at 2022-06-25 16:40:49.101737
# Unit test for function parse
def test_parse():
    docstring = parse("")
    assert docstring.short_description == None
    assert docstring.long_description == None

    docstring = parse("Single line docstring.")
    assert docstring.short_description == "Single line docstring."
    assert docstring.long_description == None

    docstring = parse("\nSingle line docstring.")
    assert docstring.short_description == None
    assert docstring.long_description == "Single line docstring."

    docstring = parse("""\
        This is the first line of a docstring.
        This is the second line of a docstring.
    """)
    assert docstring.short_description == "This is the first line of a docstring."
    assert (
        docstring.long_description
        == "This is the second line of a docstring."
    )

# Generated at 2022-06-25 16:40:56.238736
# Unit test for function parse
def test_parse():
    # Test docstring parsing for parameters
    assert len(parse("This is a description.").params) == 0
    assert parse("This is a description.\n\n:param a: b").params[0].arg_name == "a"
    assert len(parse("This is a description.\n\n:param a b: c").params) == 0
    assert parse("This is a description.\n\n:param a: b").params[0].description == "b"
    assert len(parse("This is a description.\n\n:param a: b\n\n:param c: d").params) == 2
    assert parse("This is a description.\n\n:param a: b\n\n:param c: d").params[1].arg_name == "c"

# Generated at 2022-06-25 16:41:09.166583
# Unit test for function parse
def test_parse():
    # Case 0
    str_0 = '        This is the first line of a docstring.\n        This is the second line of a docstring.\n\n        Parameters\n        ----------\n\n        :param a_b_c: This is the first line of\n            This is the second line of\n            This is the third line of\n            This is the fourth line of\n        :param d:\n        :param e:\n        :type e: this is e\n        :param f: f\n        :type f: this is f\n        :param g: g\n        :type g: this is g,\n            this is the second line of g\n\n        Other\n        -----\n\n        This is other section.\n        This is the second line of other section.\n        '
   

# Generated at 2022-06-25 16:41:19.797392
# Unit test for function parse

# Generated at 2022-06-25 16:41:28.685239
# Unit test for function parse
def test_parse():
    str_1 = 'Sample docstring.\n\n    This is other section.\n    This is the second line of other section.\n\n    Parameters\n    ----------\n\n    :type a: This is a\n    :param b: This is b\n    :param c: This is c\n    :type d: this is d\n    :param e: e\n    :type e: this is e\n    :param f: f\n    :type f: this is f\n    :param g: g\n    :type g: this is g\n\n    Other\n    -----\n\n    This is other section.\n    This is the second line of other section.\n    '
    docstring_0 = parse(str_1)

# Generated at 2022-06-25 16:41:30.689418
# Unit test for function parse
def test_parse():
    test_case_0()
    print('unit test passed')

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:41:40.972744
# Unit test for function parse
def test_parse():
    assert parse("no docstring") == Docstring(short_description=None, meta=[])
    assert parse("") == Docstring(short_description=None, meta=[])
    assert parse("\n") == Docstring(short_description=None, meta=[])
    assert parse("First line") == Docstring(
        short_description="First line",
        meta=[],
        blank_after_short_description=True,
        long_description=None,
    )
    assert parse("First line.\nSecond line.") == Docstring(
        short_description="First line.",
        meta=[],
        blank_after_short_description=False,
        long_description="Second line.",
        blank_after_long_description=True,
    )

# Generated at 2022-06-25 16:41:41.864826
# Unit test for function parse
def test_parse():
    test_case_0()
    return

# Generated at 2022-06-25 16:41:51.198420
# Unit test for function parse

# Generated at 2022-06-25 16:41:57.397958
# Unit test for function parse
def test_parse():
    # test a
    str_a = '        This is the first line of a docstring.\n        This is the second line of a docstring.\n\n        Parameters\n        ----------\n\n        :param a_b_c: This is the first line of\n            This is the second line of\n            This is the third line of\n            This is the fourth line of\n        :param d:\n        :param e:\n        :type e: this is e\n        :param f: f\n        :type f: this is f\n        :param g: g\n        :type g: this is g,\n            this is the second line of g\n\n        Other\n        -----\n\n        This is other section.\n        This is the second line of other section.\n        '
   

# Generated at 2022-06-25 16:42:01.658012
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:42:14.035487
# Unit test for function parse
def test_parse():
    str_0 = '        This is the first line of a docstring.\n        This is the second line of a docstring.\n\n        Parameters\n        ----------\n\n        :param a_b_c: This is the first line of\n            This is the second line of\n            This is the third line of\n            This is the fourth line of\n        :param d:\n        :param e:\n        :type e: this is e\n        :param f: f\n        :type f: this is f\n        :param g: g\n        :type g: this is g,\n            this is the second line of g\n\n        Other\n        -----\n\n        This is other section.\n        This is the second line of other section.\n        '

# Generated at 2022-06-25 16:42:28.116127
# Unit test for function parse
def test_parse():
  str_ref = '        This is the first line of a docstring.\n        This is the second line of a docstring.\n\n        Parameters\n        ----------\n\n        :param a_b_c: This is the first line of\n            This is the second line of\n            This is the third line of\n            This is the fourth line of\n        :param d:\n        :param e:\n        :type e: this is e\n        :param f: f\n        :type f: this is f\n        :param g: g\n        :type g: this is g,\n            this is the second line of g\n\n        Other\n        -----\n\n        This is other section.\n        This is the second line of other section.\n        '

# Generated at 2022-06-25 16:42:38.296910
# Unit test for function parse
def test_parse():
    # No arguments
    docstring = parse("This is a docstring.")
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description is None

    # Multi-line docstring
    docstring = parse(
        """
        This is the first line of a docstring.
        This is the second line of a docstring.
        """
    )
    assert docstring.short_description == ""
    assert (
        docstring.long_description
        == "This is the first line of a docstring.\nThis is the second line of a docstring."
    )

    # Multiline docstring and meta information

# Generated at 2022-06-25 16:42:46.234259
# Unit test for function parse
def test_parse():
    # Verify some test cases, e.g. from function test_case_0
    assert parse('') == Docstring()
    assert parse('This is the first line of a docstring.\nThis is the second line of a docstring.\n') == Docstring(
        'This is the first line of a docstring.', 'This is the second line of a docstring.', False, True)

# Generated at 2022-06-25 16:42:49.254604
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:42:53.482762
# Unit test for function parse
def test_parse():
    # Python 3
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:42:55.514044
# Unit test for function parse
def test_parse():
    assert 0 == test_case_0()

# Generated at 2022-06-25 16:42:56.040732
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-25 16:43:06.380376
# Unit test for function parse

# Generated at 2022-06-25 16:43:11.793351
# Unit test for function parse
def test_parse():
    # Test with empty docstring
    assert parse("") == Docstring()

    # Test with a very simple docstring
    assert parse("This is a very simple docstring.") == Docstring(
        short_description="This is a very simple docstring."
    )

    # Test with a docstring that has a short description and long description
    docstring = parse(
        """
        This is the short description.

        This is the long description.
        """
    )
    assert docstring == Docstring(
        short_description="This is the short description.",
        blank_after_short_description=True,
        long_description="This is the long description.",
        blank_after_long_description=True,
    )

    # Test with a docstring that has a short description and long description
    # and their order is reversed
    docstring = parse

# Generated at 2022-06-25 16:43:23.491305
# Unit test for function parse
def test_parse():
    str_0 = '        This is the first line of a docstring.\n        This is the second line of a docstring.\n\n        Parameters\n        ----------\n\n        :param a_b_c: This is the first line of\n            This is the second line of\n            This is the third line of\n            This is the fourth line of\n        :param d:\n        :param e:\n        :type e: this is e\n        :param f: f\n        :type f: this is f\n        :param g: g\n        :type g: this is g,\n            this is the second line of g\n\n        Other\n        -----\n\n        This is other section.\n        This is the second line of other section.\n        '