

# Generated at 2022-06-25 16:34:04.853026
# Unit test for function parse
def test_parse():
    str_0 = "Calculate the log-likelihood of the data.\n\n:param ndarray x: the matrix of data samples\n:param ndarray mu: mean vector\n:param ndarray sigma: covariance matrix\n:returns: log-likelihood of the data (float)\n:raises ValueError: when the input matrix is not square\n:raises LinAlgError: if cov matrix is not positive definite"
    docstring_0 = parse(str_0)


if __name__ == "__main__":
    test_case_0()
    test_parse()

    print(parse.__annotations__)

# Generated at 2022-06-25 16:34:15.382284
# Unit test for function parse
def test_parse():
    # Test 1
    docstring_1 = parse('')
    assert docstring_1.short_description == None
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_long_description == False
    assert len(docstring_1.meta) == 0

    # Test 2
    docstring_2 = parse('short description')
    assert docstring_2.short_description == 'short description'
    assert docstring_2.blank_after_short_description == False
    assert docstring_2.long_description == None
    assert docstring_2.blank_after_long_description == False
    assert len(docstring_2.meta) == 0

    # Test 3

# Generated at 2022-06-25 16:34:23.624724
# Unit test for function parse
def test_parse():
    # Simple test case
    assert parse("some description") == Docstring(
        short_description="some description",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    # Simple test case with long description
    assert parse(
        "some description\n\nblah blah blah"
    ) == Docstring(
        short_description="some description",
        long_description="blah blah blah",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    # Long description is separated by a single blank line

# Generated at 2022-06-25 16:34:26.533112
# Unit test for function parse
def test_parse():
    assert parse(str_0) == parse(str_0)


# Generated at 2022-06-25 16:34:27.398023
# Unit test for function parse
def test_parse():
    assert callable(parse)



# Generated at 2022-06-25 16:34:38.912787
# Unit test for function parse
def test_parse():
    str_0 = "This is a docstring. It has two sentences.\n\nThis is the "
    str_1 = "second sentence."
    docstring_0 = parse(str_0 + str_1)
    assert docstring_0.short_description == str_0[:-1]
    assert docstring_0.long_description == str_1[1:]
    assert docstring_0.blank_after_short_description
    assert not docstring_0.blank_after_long_description
    assert not docstring_0.meta
    str_2 = "This is a docstring. It has two sentences.\n\n:param test_0: "
    str_3 = "description_0\n    which spans multiple lines\n:return: "

# Generated at 2022-06-25 16:34:50.056593
# Unit test for function parse
def test_parse():
    example_0 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    example_1 = "\n\n\n\n    For example,\n        >>> foo ()\n        'foo'\n        >>>\n        >>> bar ()\n        'bar'\n        >>>\n        >>>\n\n    '''\n    Eats the passed in argument, then returns it.\n    '''\n"

# Generated at 2022-06-25 16:34:52.650185
# Unit test for function parse
def test_parse():
    test_case_0()


# Generated at 2022-06-25 16:35:01.987906
# Unit test for function parse
def test_parse():
    assert parse("aaa\n") is not None
    assert parse("aaa\n") == Docstring(
        short_description="aaa",
        blank_after_short_description=True,
        long_description=None,
        meta=[],
    )

    assert parse("aaa\nbbb\n") is not None
    assert parse("aaa\nbbb\n") == Docstring(
        short_description="aaa",
        blank_after_short_description=False,
        long_description="bbb",
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("aaa\n\nbbb\n") is not None

# Generated at 2022-06-25 16:35:11.303905
# Unit test for function parse
def test_parse():
    # A simple non-empty docstring
    str_0 = "This is a docstring.\n\nIt has a short description then a blank line.\n\n"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "This is a docstring."
    assert docstring_0.long_description == "It has a short description then a blank line."
    assert not docstring_0.meta

    # A simple empty docstring
    docstring_1 = parse("")
    assert docstring_1.short_description is None
    assert docstring_1.long_description is None
    assert not docstring_1.meta

    # A docstring with no long description
    str_2 = "This is a docstring.\n"
    docstring_2 = parse(str_2)

# Generated at 2022-06-25 16:35:23.616161
# Unit test for function parse
def test_parse():
    try:
        test_case_0()
    except ParseError:
        pass
    except:
        raise
    return


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:35:32.607615
# Unit test for function parse

# Generated at 2022-06-25 16:35:35.397098
# Unit test for function parse
def test_parse():
    assert True, "Missing test for function parse"


# Generated at 2022-06-25 16:35:44.058570
# Unit test for function parse

# Generated at 2022-06-25 16:35:52.808047
# Unit test for function parse
def test_parse():
    str_0 = "Define a function foo."
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Define a function foo."
    str_1 = "Define a function foo.\n"
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "Define a function foo."
    str_2 = "\nDefine a function foo.\n"
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == "Define a function foo."
    str_3 = "\n\nDefine a function foo.\n"
    docstring_3 = parse(str_3)
    assert docstring_3.short_description == "Define a function foo."

# Generated at 2022-06-25 16:36:03.852005
# Unit test for function parse
def test_parse():
    str_0 = ""
    docstring_0 = parse(str_0)
    str_1 = "*Z{wCJ8}"
    docstring_1 = parse(str_1)
    str_2 = "tTJT?T77,F"
    docstring_2 = parse(str_2)
    str_3 = "9$K~+R"
    docstring_3 = parse(str_3)
    str_4 = ")t#QS;fJ_"
    docstring_4 = parse(str_4)
    str_5 = "\\zW+X9;\\'"
    docstring_5 = parse(str_5)
    str_6 = "y|R6]xU6="
    docstring_6 = parse(str_6)

# Generated at 2022-06-25 16:36:15.985714
# Unit test for function parse
def test_parse():
    docstring_0 = parse("\n    Single line description.\n    ")
    assert docstring_0.short_description == 'Single line description.'
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is None
    assert docstring_0.meta == []

    docstring_1 = parse("Single line description.")
    assert docstring_1.short_description == 'Single line description.'
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is False
    assert docstring_1.blank_after_long_description is None
    assert docstring_1.meta == []


# Generated at 2022-06-25 16:36:26.947540
# Unit test for function parse
def test_parse():
    # Test case 0
    str_0 = "]Qi\\u'{"
    docstring_0 = parse(str_0)

    # Test case 1
    str_1 = "    Returns a dictionary mapping (section_name, option_name) keys to\n    :class:`Option <Option>` instances.\n\n    The section_names are returned in the order they were first seen in the\n    configuration file, and section_name and option_name are both case\n    sensitive.\n\n    If a section_name is passed, only the options from the section are\n    returned. Otherwise all options are returned."
    docstring_1 = parse(str_1)

    # Test case 2

# Generated at 2022-06-25 16:36:32.396955
# Unit test for function parse
def test_parse():
    str_0 = "]Qi\\u'{"
    docstring_0 = parse(str_0)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:36:40.182158
# Unit test for function parse
def test_parse():
    str_0 = ""
    docstring_0 = parse(str_0)
    str_1 = "Creates a new go qua.\n\n:param name: The qua name.\n:returns: The qua object."
    docstring_1 = parse(str_1)
    str_2 = "Creates a new go qua."
    docstring_2 = parse(str_2)
    str_3 = "Creates a new go qua.\n\n:param name: The qua name.\n:type name: str\n\n:returns: The qua object.\n:rtype: qualia.data.Data"
    docstring_3 = parse(str_3)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:36:50.494597
# Unit test for function parse
def test_parse():
    test_case_0()


# Generated at 2022-06-25 16:37:01.139919
# Unit test for function parse
def test_parse():
    print("Testing parse...", end="")
    str_0 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Takes two numbers and divide the first by the second."
    assert docstring_0.long_description == "Takes two numbers and divide the first by the second."
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == True

# Generated at 2022-06-25 16:37:02.165891
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:37:03.019063
# Unit test for function parse
def test_parse():
    test_case_0()

test_parse()

# Generated at 2022-06-25 16:37:04.932440
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:37:14.600721
# Unit test for function parse
def test_parse():
    str_0 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    docstring_0 = parse(str_0)
    # print("\n")
    # print("Testing parse")
    # print("Input:")
    # print("str_0 =", str_0)
    # print("Output:")
    print("docstring_0 =", docstring_0)
    # print("Expected:")
    # print("docstring_0 =", docstring_0)
    # print("\n")

# Generated at 2022-06-25 16:37:15.103969
# Unit test for function parse
def test_parse():
    assert True

# Generated at 2022-06-25 16:37:28.494140
# Unit test for function parse
def test_parse():
    str_0 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Takes two numbers and divide the first by"
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == True
    assert docstring_0.long_description == "the second."
    assert len(docstring_0.meta) == 5

# Generated at 2022-06-25 16:37:36.939431
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("""\
A short description.

    With
    leading
    whitespace.

A long description.
""") == Docstring(
        short_description="A short description.",
        long_description="""\
A long description.
""",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-25 16:37:45.340727
# Unit test for function parse
def test_parse():
    str1 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    docstring1 = parse(str1)
    assert docstring1.short_description == "Takes two numbers and divide the first by"
    assert docstring1.long_description == "the second.\n"
    assert docstring1.blank_after_short_description == False
    assert docstring1.blank_after_long_description == True
    assert docstring1.meta[0].args == ['param', 'x', 'first number']
    assert docstring1.meta[0].description

# Generated at 2022-06-25 16:38:18.871348
# Unit test for function parse
def test_parse():
    str_0 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    docstring_0 = parse(str_0)
    assert str(docstring_0.short_description) == "Takes two numbers and divide the first by the second."
    assert docstring_0.blank_after_short_description
    assert not docstring_0.blank_after_long_description
    assert str(docstring_0.long_description) == "Takes two numbers and divide the first by the second."

# Generated at 2022-06-25 16:38:24.820354
# Unit test for function parse
def test_parse():
    str_0 = "'Human readable docstring'\n"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Human readable docstring"
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 0

    str_1 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"

# Generated at 2022-06-25 16:38:36.901405
# Unit test for function parse
def test_parse():
  str_0 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
  docstring_0 = parse(str_0)
  assert docstring_0.short_description == 'Takes two numbers and divide the first by the second.'
  assert docstring_0.long_description == 'param x: first number param y: second number returns: quotient rtype: float raises ZeroDivisionError: if the second number is zero'
  assert docstring_0.blank_after_short_description == True
  assert docstring_0.blank_after_long_description == False


# Generated at 2022-06-25 16:38:39.511931
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:38:51.477589
# Unit test for function parse
def test_parse():
    str_0 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Takes two numbers and divide the first by'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True
    assert docstring_0.long_description == 'the second.'
    assert docstring_0.meta[0].args == ['param', 'x']

# Generated at 2022-06-25 16:38:55.768478
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()

# Run test for function parse
test_parse()

# Generated at 2022-06-25 16:39:06.273819
# Unit test for function parse
def test_parse():
    str_0 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Takes two numbers and divide the first by the second."
    assert docstring_0.blank_after_short_description
    assert docstring_0.long_description == "None"
    assert docstring_0.blank_after_long_description
    assert docstring_0.meta[0].args == ['param', 'x', 'first number']

# Generated at 2022-06-25 16:39:08.004769
# Unit test for function parse
def test_parse():
    '''Assert the docstring of parse is correct'''
    function = parse
    source = inspect.getsource(function)
    doc = parse.__doc__
    assert doc == source


# Test for function parse

# Generated at 2022-06-25 16:39:12.509421
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:39:22.251958
# Unit test for function parse
def test_parse():
    str_0 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Takes two numbers and divide the first by\nthe second."
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == True
    assert docstring_0.long_description == None
    assert docstring_0.meta[0].args == ['returns', 'float']
    assert docstring_0.meta[0].description == "quotient"
    assert docstring_

# Generated at 2022-06-25 16:39:40.189810
# Unit test for function parse
def test_parse():
    test_case_0()

test_parse()

# Generated at 2022-06-25 16:39:49.892413
# Unit test for function parse
def test_parse():
    str_0 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Takes two numbers and divide the first by\nthe second."
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.long_description == None
    assert len(docstring_0.meta) == 3

# Generated at 2022-06-25 16:39:58.136048
# Unit test for function parse
def test_parse():
    str_0 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    docstring_0 = parse(str_0)
    assert len(docstring_0.meta) == 5
    assert str(docstring_0) == "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"




# Generated at 2022-06-25 16:40:06.981099
# Unit test for function parse
def test_parse():
    s = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    docstring_ = parse(s)
    assert docstring_.short_description == "Takes two numbers and divide the first by"
    assert docstring_.long_description == "the second.\n"
    assert docstring_.blank_after_long_description == False
    assert docstring_.blank_after_short_description == True
    assert len(docstring_.meta) == 3
    assert isinstance(docstring_.meta[0], DocstringParam)

# Generated at 2022-06-25 16:40:18.351071
# Unit test for function parse
def test_parse():
    docstring_0 = parse("'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n")
    assert docstring_0.short_description == "Takes two numbers and divide the first by"
    assert docstring_0.long_description == "the second."

# Generated at 2022-06-25 16:40:28.993353
# Unit test for function parse
def test_parse():
    str_0 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    docstring_0 = parse(str_0)
    # Check short_description of the parsed docstring
    assert docstring_0.short_description == 'Takes two numbers and divide the first by'
    # Check long_description of the parsed docstring
    assert docstring_0.long_description == 'the second.\n'
    # Check blank_after_short_description of the parsed docstring
    assert docstring_0.blank_after_short_description == True
    # Check blank

# Generated at 2022-06-25 16:40:29.726377
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 16:40:41.986630
# Unit test for function parse
def test_parse():
    str_0 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Takes two numbers and divide the first by'
    assert docstring_0.long_description == 'the second.'
    assert docstring_0.blank_after_short_description is True
    assert docstring_0.blank_after_long_description is True
    assert isinstance(docstring_0.meta[0], DocstringParam)

# Generated at 2022-06-25 16:40:52.568384
# Unit test for function parse
def test_parse():
  print("Test parse")
  str_0 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
  docstring_0 = parse(str_0)
  assert docstring_0.short_description == 'Takes two numbers and divide the first by'
  assert docstring_0.long_description == 'the second.\n'
  assert docstring_0.blank_after_short_description == True
  assert docstring_0.blank_after_long_description == True
  meta_0 = docstring_0.meta[0]
  assert meta_0

# Generated at 2022-06-25 16:41:04.143532
# Unit test for function parse
def test_parse():
    # Test whether parse funtion is correct
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("   \n") == Docstring()
    assert parse("\t\n") == Docstring()
    assert parse("   \n\t\n") == Docstring()

    str_0 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Takes two numbers and divide the first by\nthe second."


# Generated at 2022-06-25 16:41:29.503655
# Unit test for function parse
def test_parse():
    func = test_case_0
    func_name = func.__name__
    str_0 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    result = parse(str_0)
    assert result.short_description == 'Takes two numbers and divide the first by'
    assert result.blank_after_short_description
    assert result.long_description == 'the second.'
    assert result.blank_after_long_description
    assert result.meta[0].arg_name == 'x'

# Generated at 2022-06-25 16:41:39.095145
# Unit test for function parse
def test_parse():
    assert_equal(parse('"I am a docstring. There are many like me, but '
                       'this one is mine."'),
                 parse('"I am a docstring. There are many like me, but '
                       'this one is mine."'))
    assert_equal(parse('"I am a docstring. There are many like me, but '
                       'this one is mine."'),
                 parse('"I am a docstring. There are many like me, but '
                       'this one is mine."'))
    assert_equal(parse('"I am a docstring. There are many like me, but '
                       'this one is mine."'),
                 parse('"I am a docstring. There are many like me, but '
                       'this one is mine."'))

# Generated at 2022-06-25 16:41:40.053385
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:41:49.913644
# Unit test for function parse
def test_parse():
    # Docstring without description
    # Neither description, nor meta
    str_0 = ""
    expected_0 = Docstring()
    docstring_0 = parse(str_0)
    assert docstring_0 == expected_0

    # Short description only
    str_1 = "Short description"
    expected_1 = Docstring(
        short_description="Short description",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    docstring_1 = parse(str_1)
    assert docstring_1 == expected_1

    # Long description only
    str_2 = """\
    Long description

    More words"""

# Generated at 2022-06-25 16:41:57.112657
# Unit test for function parse
def test_parse():
    # Function signature: parse(text)
    docstring_0 = parse("'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n")
    assert docstring_0.short_description == "Takes two numbers and divide the first by"
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.long_description == "the second."
    assert docstring_0.blank_after_long_description == True
    assert docstring_0.meta[0].description == "first number"

# Generated at 2022-06-25 16:42:07.411552
# Unit test for function parse
def test_parse():
    str_0 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    docstring_0 = parse(str_0)
    str_1 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    docstring_1 = parse(str_1)

# Generated at 2022-06-25 16:42:08.525292
# Unit test for function parse
def test_parse():
    pass
    # TODO



# Generated at 2022-06-25 16:42:09.697541
# Unit test for function parse
def test_parse():
    # Test no arg
    test_case_0()

# Generated at 2022-06-25 16:42:20.651830
# Unit test for function parse
def test_parse():
    from pyee import EventEmitter
    import pytest
    import weakref
    import sys
    import time

    def add_callback_once(ee, fn, timeout=5):
        callbacks = []
        def cb(x):
            callbacks.append(True)
            fn(x)
        ee.once(cb)
        start = time.time()
        while not callbacks:
            if time.time() - start >= timeout:
                raise Exception("callback not called in %s seconds" % timeout)
            time.sleep(1)

    def test_add_listener():
        def on_foo(x):
            pass

        ee = EventEmitter()
        ee.on('foo', on_foo)
        assert len(ee._events['foo']) == 1

        ee = EventEmitter()

# Generated at 2022-06-25 16:42:29.898085
# Unit test for function parse
def test_parse():
  text = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
  docstring_0 = parse(text)


# Generated at 2022-06-25 16:43:13.096951
# Unit test for function parse
def test_parse():
    str_0 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    docstring_0 = parse(str_0)
    str_1 = "'''\n\n:returns: quotient\n:rtype: float\n'''\n"
    docstring_1 = parse(str_1)
    assert docstring_0.short_description.startswith("Takes two numbers and divide")
    assert docstring_1.short_description is None
    assert docstring_1.meta[0].description.startswith("quotient")

# Generated at 2022-06-25 16:43:24.042496
# Unit test for function parse
def test_parse():
    str_0 = """
"""
    docstring_0 = parse(str_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.meta == []

    str_1 = """
Takes two numbers and divide the first by
the second.

:param x: first number
:param y: second number
:returns: quotient
:rtype: float
:raises ZeroDivisionError: if the second
number is zero
"""
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "Takes two numbers and divide the first by"
    assert doc

# Generated at 2022-06-25 16:43:28.981140
# Unit test for function parse
def test_parse():
    str_0 = "'''\nTakes two numbers and divide the first by\nthe second.\n\n:param x: first number\n:param y: second number\n:returns: quotient\n:rtype: float\n:raises ZeroDivisionError: if the second\nnumber is zero\n'''\n"
    docstring_0 = parse(str_0)
