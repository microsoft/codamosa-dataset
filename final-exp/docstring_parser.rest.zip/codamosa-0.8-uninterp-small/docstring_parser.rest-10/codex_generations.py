

# Generated at 2022-06-25 16:33:47.712034
# Unit test for function parse
def test_parse():
    docstring = parse('jzK')
    assert docstring.short_description == 'jzK'
    assert docstring.long_description == None
    assert docstring.blank_after_long_description == None
    assert docstring.blank_after_short_description == None
    assert docstring.meta == []
    print('Passed test {}'.format(test_parse.__name__))


# Generated at 2022-06-25 16:33:58.023273
# Unit test for function parse
def test_parse():
    assert(parse("") == Docstring())
    assert(parse("""
    Short desc.

    Long desc.
    """) == Docstring(
        short_description="Short desc.",
        blank_after_short_description=True,
        long_description="Long desc.",
        blank_after_long_description=False,
        meta=[]
    ))

# Generated at 2022-06-25 16:34:06.366431
# Unit test for function parse
def test_parse():
    assert parse(":param int foo: Bar.\n\n: blah blah blah.")
    assert parse(":param str foo: Bar.\n\n: blah blah blah.")
    assert parse(
        ":param str foo:\n    Bar.\n    ..\n\n: blah blah blah."
    )
    assert parse(":param str foo: Bar.\n")
    assert parse(":param str foo: Bar.")
    assert parse(":param str foo:")
    assert parse(":param foo:")
    assert parse(":param list? foo: Bar.")
    assert parse(":param dict? foo: Bar.")
    assert parse(":param dict? foo: Bar.\n\n")
    assert parse(":param dict?: Bar.")
    assert parse(":param dict? Bar.\n\n")


# Generated at 2022-06-25 16:34:16.045954
# Unit test for function parse
def test_parse():
    assert str(parse("")) == """Docstring(short_description=None, blank_after_short_description=False, long_description=None, blank_after_long_description=False, meta=[])"""

    assert str(parse("x")) == """Docstring(short_description='x', blank_after_short_description=True, long_description=None, blank_after_long_description=False, meta=[])"""

    assert str(
        parse("x\n\ny")
    ) == """Docstring(short_description='x', blank_after_short_description=True, long_description='y', blank_after_long_description=True, meta=[])"""


# Generated at 2022-06-25 16:34:27.460903
# Unit test for function parse
def test_parse():
    str_0 = ''
    docstring_0 = parse(str_0)
    str_1 = 'dqF'
    docstring_1 = parse(str_1)
    str_2 = 'k\n'
    docstring_2 = parse(str_2)
    str_3 = 'AO\n\n\n\n'
    docstring_3 = parse(str_3)
    str_4 = '\n'
    docstring_4 = parse(str_4)
    str_5 = 'C\n\n\n'
    docstring_5 = parse(str_5)
    str_6 = '^'
    docstring_6 = parse(str_6)
    str_7 = '\n\n'
    docstring_7 = parse(str_7)
    str_

# Generated at 2022-06-25 16:34:38.991042
# Unit test for function parse
def test_parse():
    docstring_0 = parse('')
    docstring_1 = parse('example\n    ')
    docstring_2 = parse('example\n    \n    ')
    docstring_3 = parse('example\n\n')
    docstring_4 = parse('example\n    \n\n')
    docstring_5 = parse('example\n    \n    \n')
    docstring_6 = parse('example\n    \n    \n\n')
    docstring_7 = parse('\n    \n    \n\n')
    docstring_8 = parse('\n\n')
    docstring_9 = parse('example\n    example\n    ')
    docstring_10 = parse('example\n    \nexample\n    ')

# Generated at 2022-06-25 16:34:44.554747
# Unit test for function parse
def test_parse():
    str_1 = 'Method for testing.'
    docstring_1 = parse(str_1)
    str_2 = ':param filename: The name of the file to read.\n    :type filename:  str'
    docstring_2 = parse(str_2)

    # Function test for the first line of docstring
    assert docstring_1.short_description == 'Method for testing.'

    # Function test for the second line of docstring
    assert docstring_1.blank_after_short_description == True

    # Function test for the third line of docstring
    assert docstring_1.blank_after_long_description == True

    # Function test for the last line of docstring
    assert docstring_1.long_description == None

    # Function test for the number of meta objects in docstring

# Generated at 2022-06-25 16:34:54.397897
# Unit test for function parse
def test_parse():
    str_0 = ''
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 0

    str_1 = 'a\nb'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'a'
    assert docstring_1.long_description == 'b'
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank_after_long_description == False
    assert len(docstring_1.meta) == 0

    str_

# Generated at 2022-06-25 16:34:58.248866
# Unit test for function parse
def test_parse():
    str = 'jzK'
    docstring = parse(str)
    assert docstring == Docstring()
    str = 'jzK\n\n'
    docstring = parse(str)
    assert docstring == Docstring()
    str = """\
jzK

"""
    docstring = parse(str)
    assert docstring == Docstring()
    str = """\
jzK

jGg

"""
    docstring = parse(str)
    assert docstring == Docstring()


# Generated at 2022-06-25 16:35:09.005499
# Unit test for function parse
def test_parse():
    str_0 = 'jzK'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.meta == []
    str_1 = ''
    docstring_1 = parse(str_1)
    assert docstring_1.short_description is None
    assert docstring_1.blank_after_short_description is False
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_long_description is False
    assert docstring_1.meta == []

# Generated at 2022-06-25 16:35:29.405849
# Unit test for function parse
def test_parse():
    str_0 = 'jzK'
    docstring_0 = parse(str_0)

    str_1 = 'jzK'
    docstring_1 = parse(str_1)

    str_2 = 'jzK'
    docstring_2 = parse(str_2)

    str_3 = 'jzK'
    docstring_3 = parse(str_3)

    str_4 = 'jzK'
    docstring_4 = parse(str_4)

    str_5 = 'jzK'
    docstring_5 = parse(str_5)

    str_6 = 'jzK'
    docstring_6 = parse(str_6)

    str_7 = 'jzK'
    docstring_7 = parse(str_7)


# Generated at 2022-06-25 16:35:40.021720
# Unit test for function parse
def test_parse():
    print('test_parse')
    str_0 = 'jzK'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'jzK'
    str_0 = 'long enough;\nnot blank.'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'long enough;'
    assert docstring_0.long_description == 'not blank.'
    assert not docstring_0.blank_after_short_description
    assert docstring_0.blank_after_long_description
    str_0 = '::\n\n\n\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None

# Generated at 2022-06-25 16:35:47.353372
# Unit test for function parse
def test_parse():
    ds = '''
    """
    Parse the ReST-style docstring into its components.

    :returns: parsed docstring
    """
    '''
    docstring = parse(ds)
    assert docstring.short_description == "Parse the ReST-style docstring into its components."
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == True
    assert docstring.long_description == None
    assert docstring.meta == [DocstringMeta(args=['returns'], description='parsed docstring')]

    ds = '''
    """
    Short description.

    Long description.

    :param arg_name: arg description
    :returns: return description
    """
    '''
    docstring = parse(ds)
   

# Generated at 2022-06-25 16:35:58.755358
# Unit test for function parse
def test_parse():
    str_test = """\
        The first line here is always interpreted as the short description.
        The rest of the first paragraph is interpreted as the long description.
        The long description may contain ReST-style markup.
    
        :Parameters:
            Arg1 : type
                Parameter description.
        """
    str_test_meta = """\
    :Parameters:
        Arg1 : type
            Parameter description.
    """
    str_test_desc = """\
The first line here is always interpreted as the short description.
The rest of the first paragraph is interpreted as the long description.
The long description may contain ReST-style markup.

"""
    docstring_test = parse(str_test)
    assert docstring_test.short_description == "The first line here is always interpreted as the short description."

# Generated at 2022-06-25 16:36:05.789141
# Unit test for function parse
def test_parse():
    str_0 = ''
    docstring_0 = parse(str_0)
    str_1 = 'jzK'
    docstring_1 = parse(str_1)
    str_2 = 'jzK\njzK\njzK\n'
    docstring_2 = parse(str_2)
    str_3 = 'jzK:jzK:jzK\n'
    docstring_3 = parse(str_3)
    str_4 = 'jzK\njzK:jzK:jzK\n'
    docstring_4 = parse(str_4)
    str_5 = 'jzK\njzK\njzK\njzK:jzK:jzK\n'

# Generated at 2022-06-25 16:36:07.811911
# Unit test for function parse
def test_parse():
    test_case_0()

# Unit test main

# Generated at 2022-06-25 16:36:16.846145
# Unit test for function parse
def test_parse():
    # test case 0
    str_0 = ''
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 0

    # test case 1
    str_1 = 'jzK'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'jzK'
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.blank_after_long_description == False

# Generated at 2022-06-25 16:36:27.780298
# Unit test for function parse
def test_parse():
    """
    >>> docstring = parse("""
    ...

# Generated at 2022-06-25 16:36:38.965558
# Unit test for function parse
def test_parse():
    str_0 = 'Test jzK'
    docstring_0 = parse(str_0)
    str_1 = ':param int val: Just a value.'
    docstring_1 = parse(str_1)
    str_2 = ':return: Just a value.'
    docstring_2 = parse(str_2)
    str_3 = """Return type of the value.

    :rtype: int
    """
    docstring_3 = parse(str_3)
    str_4 = """Return some value.

    :returns: Return type of the value.

    :rtype: int
    """
    docstring_4 = parse(str_4)

# Generated at 2022-06-25 16:36:42.768307
# Unit test for function parse
def test_parse():
    output_0 = parse(str_0)
    assert isinstance(output_0, Docstring)
    assert output_0.__dict__ == docstring_0.__dict__

# Generated at 2022-06-25 16:37:01.569754
# Unit test for function parse

# Generated at 2022-06-25 16:37:08.970400
# Unit test for function parse

# Generated at 2022-06-25 16:37:17.610670
# Unit test for function parse
def test_parse():
    str_0 = '\n    >>> docstring = parse('
    str_1 = '\n    This function does something.'
    str_2 = '\n    '
    str_3 = '\n    '
    str_4 = '\n    This is a longer description.'
    str_5 = '\n    '
    str_6 = '\n    '
    str_7 = '\n    :param arg1: description'
    str_8 = '\n    :type arg1: int'
    str_9 = '\n    :param arg2: description'
    str_10 = '\n    :type arg2: str'
    str_11 = '\n    :returns: the calculated result'
    str_12 = '\n    :type: int'

# Generated at 2022-06-25 16:37:30.094144
# Unit test for function parse
def test_parse():
    docstring = parse('parses docstrings\n               which can be very long.\n\n               :param str arg1: a first argument\n               :param str|None arg2: a second argument')
    assert docstring.short_description == 'parses docstrings'
    assert len(docstring.meta) == 2
    f = docstring.meta[0]
    assert f.args == ['param', 'str', 'arg1']
    assert f.description == 'a first argument'
    f = docstring.meta[1]
    assert f.args == ['param', 'str|None', 'arg2']
    assert f.description == 'a second argument'


# Generated at 2022-06-25 16:37:37.833689
# Unit test for function parse
def test_parse():

    # Initialize test case
    docstring_0 = parse(test_case_0())

    # Test case has docstring with no args
    assert docstring_0.args == None, "Test failed for docstring_0"
    
    # Test case has docstring with no kwargs
    assert docstring_0.kwargs == None, "Test failed for docstring_0"

    # Test case has no short description
    assert docstring_0.short_description == None, "Test failed for docstring_0"

    # Test case has no blank after short description
    assert docstring_0.blank_after_short_description == None, "Test failed for docstring_0"

    # Test case has no long description
    assert docstring_0.long_description == None, "Test failed for docstring_0"

    # Test case has no

# Generated at 2022-06-25 16:37:48.213189
# Unit test for function parse
def test_parse():
    str_1 = r'\"\"\"This is a short description.\n\n:param int x: This is a param.\n:returns: This is the return.\n\"\"\"'
    ret_1 = parse(str_1)
    print(ret_1)
    assert ret_1.short_description == 'This is a short description.'
    assert ret_1.long_description == None
    assert ret_1.blank_after_short_description == True
    assert ret_1.blank_after_long_description == False
    assert ret_1.meta[0].args[0] == 'param'
    assert ret_1.meta[0].args[1] == 'int'
    assert ret_1.meta[0].args[2] == 'x'

# Generated at 2022-06-25 16:37:56.260332
# Unit test for function parse
def test_parse():
    str_0 = '\n    >>> docstring = parse('
    str_1 = '\n    >>> docstring = parse(\'\')'
    str_2 = '\n    >>> docstring = parse(\'\\n\')'
    str_3 = '\n    >>> docstring = parse(\'\\n\\n\')'
    str_4 = '\n    >>> docstring = parse(\'short desc\\n\')'
    str_5 = '\n    >>> docstring = parse(\'short desc\\n\\n\')'
    str_6 = '\n    >>> docstring = parse(\'short desc\\n\\nlong desc.\')'
    str_7 = '\n    >>> docstring = parse(\'short desc\\n\\nlong desc\\n\\n\')'

# Generated at 2022-06-25 16:38:09.240741
# Unit test for function parse
def test_parse():
    print("Testing function parse...")
    # Test case 1
    print("Test case 1")
    str_1 = '\n'
    ret_1 = parse(str_1)
    assert ret_1.short_description is None
    assert ret_1.blank_after_short_description is False
    assert ret_1.blank_after_long_description is True
    assert ret_1.long_description is None
    assert len(ret_1.meta) == 0
    # Test case 2
    print("Test case 2")
    str_2 = '  '
    ret_2 = parse(str_2)
    assert ret_2.short_description is None
    assert ret_2.blank_after_short_description is False
    assert ret_2.blank_after_long_description is True

# Generated at 2022-06-25 16:38:18.871954
# Unit test for function parse
def test_parse():
    str_0 = '\n    >>> docstring = parse('
    str_1 = '"Overview.\n\n    Some details."'
    str_2 = ')\n    >>> print(docstring.short_description)\n    Overview.\n    >>> print(docstring.long_description)\n    Some details.\n'
    str_3 = '"Overview.\n\n    Some details.\n\n    More details."'
    str_4 = ')\n    >>> print(docstring.short_description)\n    Overview.\n    >>> print(docstring.long_description)\n    Some details.\n\n    More details.\n'
    str_5 = '"Overview.\n\n    Some details.\n\n\n    More details."'

# Generated at 2022-06-25 16:38:29.271299
# Unit test for function parse

# Generated at 2022-06-25 16:39:06.742282
# Unit test for function parse
def test_parse():
    # Description in single line
    case_0 = parse('This is a single line description.')
    assert case_0.short_description == 'This is a single line description.'
    assert case_0.long_description == None

    # Description in two lines
    case_1 = parse('This is a first line\nThis is a second line.')
    assert case_1.short_description == 'This is a first line'
    assert case_1.long_description == 'This is a second line.'
    assert case_1.blank_after_short_description == True
    assert case_1.blank_after_long_description == False

    # Description in three lines
    case_2 = parse('This is a first line\n\nThis is a second line.')
    assert case_2.short_description == 'This is a first line'

# Generated at 2022-06-25 16:39:19.360092
# Unit test for function parse

# Generated at 2022-06-25 16:39:29.563698
# Unit test for function parse
def test_parse():

    sample_docstring = """This is a function.

    This is the first paragraph of the long description.

    This is the second paragraph of the long description.

    :param arg_a: this is a positional argument
    :param arg_b: this is a keyword argument
    :returns: None

    This paragraph occurs after the meta-data block.
    """

    # TestReturnValue
    docstring = parse(sample_docstring)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == 'This is the first paragraph of the long description.\n\nThis is the second paragraph of the long description.'
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.meta[0].name == 'param'
    assert docstring

# Generated at 2022-06-25 16:39:37.271572
# Unit test for function parse
def test_parse():
    from parse import parse
    from docstring_parser import demo

# Generated at 2022-06-25 16:39:40.111693
# Unit test for function parse
def test_parse():
    if test_case_0() == "Testcase 0 failed":
        print("Testcase 0 failed")
    else:
        print("Testcase 0 passed")

# Generated at 2022-06-25 16:39:44.538619
# Unit test for function parse
def test_parse():

    # String Declaration
    str_0 = (
        'Parse the ReST-style docstring into its components.\n\n    :returns: '
        'parsed docstring\n'
    )

    # Assert Parsed Docstring is Equal to str_0
    assert parse(str_0) == str_0, 'Parsed docstring is not equal to str_0'



# Generated at 2022-06-25 16:39:49.339824
# Unit test for function parse
def test_parse():
    d = parse('''\
        A multiple
        line example for
        your viewing pleasure.
        
        :param foo: a parameter
        :type foo: int
        :param bar: a parameter
        :type bar: int
        
        :returns: nothing
        :rtype: NoneType
        :raises Exception: if anything bad happens
        
        Extra text.
        
        ''')
    assert d.short_description == "A multiple line example for your viewing pleasure."
    assert d.long_description == "Extra text."
    assert d.blank_after_short_description
    assert d.blank_after_long_description
    assert len(d.meta) == 3

    meta = d.meta[0]
    assert meta.args == ["param", "foo"]
    assert meta.description == "a parameter"


# Generated at 2022-06-25 16:39:53.805057
# Unit test for function parse
def test_parse():
    docstring = parse(
'''Convert an angle measured in degrees to an approximately
equivalent angle measured in radians.

The conversion from degrees to radians is generally inexact.

:param float degrees:
    angle in degrees

:returns:
    Return the measurement of the angle 'degrees' in radians.
'''
    )
    print(docstring)


# Generated at 2022-06-25 16:40:03.859069
# Unit test for function parse
def test_parse():
    docstring = parse('')
    res = docstring.short_description
    assert  res == None
    res = docstring.blank_after_short_description
    assert  res == False
    res = docstring.long_description
    assert  res == None
    res = docstring.blank_after_long_description
    assert  res == False
    res = docstring.meta
    assert  res == []
    docstring = parse('foo\nbar')
    res = docstring.short_description
    assert  res == "foo"
    res = docstring.blank_after_short_description
    assert  res == False
    res = docstring.long_description
    assert  res == "bar"
    res = docstring.blank_after_long_description
    assert  res == False
    res = docstring.meta

# Generated at 2022-06-25 16:40:15.667932
# Unit test for function parse
def test_parse():
    import inspect

    # Test
    docstring = parse("")
    assert not docstring.short_description
    assert not docstring.long_description
    assert not docstring.meta

    # Test
    docstring = parse("Short description.")
    assert docstring.short_description == "Short description."
    assert not docstring.long_description
    assert not docstring.meta

    # Test
    docstring = parse("Short description.\n")
    assert docstring.short_description == "Short description."
    assert not docstring.long_description
    assert not docstring.meta

    # Test
    docstring = parse("Short description.\n\n")
    assert docstring.short_description == "Short description."
    assert not docstring.long_description
    assert not docstring.meta

    # Test
    docstring = parse

# Generated at 2022-06-25 16:40:44.142887
# Unit test for function parse
def test_parse():
    assert str(parse("")) == 'Docstring(short_description=None, blank_after_short_description=False, long_description=None, blank_after_long_description=False, meta=[])'
    assert str(parse("\n")) == 'Docstring(short_description=None, blank_after_short_description=False, long_description=None, blank_after_long_description=False, meta=[])'
    assert str(parse("\n\n")) == 'Docstring(short_description=None, blank_after_short_description=False, long_description=None, blank_after_long_description=False, meta=[])'


# Generated at 2022-06-25 16:40:50.102606
# Unit test for function parse
def test_parse():
    # Arrange
    str_0 = ':param filename: The name of the file to read.\n    :type filename:  str'
    expected = Docstring([DocstringParam(['param', 'filename', 'The name of the file to read.', 'str'])], [])
    # Act
    result = parse(str_0)
    # Assert
    for item in expected.meta:
        assert type(item) is type(result.meta[0])
        assert item in result.meta

# Generated at 2022-06-25 16:40:51.300222
# Unit test for function parse
def test_parse():
    """ test for function parse"""
    test_case_0()

# Generated at 2022-06-25 16:41:04.106993
# Unit test for function parse
def test_parse():
    docstring_0 = parse("")
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert len(docstring_0.meta) == 0

    docstring_1 = parse("short")
    assert docstring_1.short_description == "short"
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is False
    assert docstring_1.blank_after_long_description is False
    assert len(docstring_1.meta) == 0

    docstring_2 = parse("")
    assert docstring_2.short_description is None
    assert docstring_

# Generated at 2022-06-25 16:41:08.295158
# Unit test for function parse
def test_parse():
    print('Testing function: parse')
    test_case_0()

# Program that tests the module

# Generated at 2022-06-25 16:41:14.739463
# Unit test for function parse
def test_parse():
    str1 = """
    Simple function.

    :param filename: The name of the file to read.
    :type filename:  str
    """
    ds = parse(str1)
    assert ds.short_description == "Simple function."
    assert ds.blank_after_short_description
    assert not ds.blank_after_long_description
    assert ds.long_description == ""
    assert ds.meta == [
        DocstringParam(
            description="The name of the file to read.",
            arg_name="filename",
            type_name="str",
            is_optional=False,
            default=None,
        )
    ]



# Generated at 2022-06-25 16:41:22.932004
# Unit test for function parse
def test_parse():
    str_0 = 'This is the short description.\n\nThis is the long\ndescription.\n\nAnd a final paragraph.'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "This is the short description."
    assert docstring_0.long_description == 'This is the long\ndescription.\n\nAnd a final paragraph.'
    assert docstring_0.blank_after_short_description
    assert docstring_0.blank_after_long_description
    assert docstring_0.meta ==[]


# Generated at 2022-06-25 16:41:30.576025
# Unit test for function parse
def test_parse():
	
	# Test 0
	str_0 = ':param filename: The name of the file to read.\n    :type filename:  str'
	docstring_0 = parse(str_0)

	# Test 1
	str_1 = ':param filename: The name of the file to read.\n    :type filename:  str\n    :returns: The contents of the file\n    :rtype: bytes'
	docstring_1 = parse(str_1)

	# Test 2
	str_2 = ':param filename: The name of the file to read.\n    :type filename:  str\n    :returns: The contents of the file\n    :rtype: bytes\n\nThe contents of the file.'
	docstring_2 = parse(str_2)

	# Test 3
	str

# Generated at 2022-06-25 16:41:40.853635
# Unit test for function parse
def test_parse():
    print("Testing parse...", end="")
    # Test 1
    str1 = ':param filename: The name of the file to read.\n    :type filename:  str'
    docstring1 = parse(str1)
    assert docstring1.meta[0].arg_name == 'filename'
    assert docstring1.meta[0].type_name == 'str'
    assert docstring1.meta[0].description == 'The name of the file to read.'
    assert docstring1.meta[0].is_optional is False
    assert docstring1.meta[0].default is None

    # Test 2
    str2 = ':return: The image object in memory.\n    :rtype: Image'
    docstring2 = parse(str2)

# Generated at 2022-06-25 16:41:50.501574
# Unit test for function parse
def test_parse():
    str_0 = ':param filename: The name of the file to read.\n    :type filename:  str'
    assert type(parse(str_0)) is Docstring
    assert type(parse(str_0).__dict__) is dict
    assert parse(str_0).__dict__.keys() == ['short_description', 'long_description', 'blank_after_short_description', 'blank_after_long_description', 'meta']
    assert type(parse(str_0).short_description) is str
    assert parse(str_0).short_description == 'None'
    assert type(parse(str_0).long_description) is str
    assert parse(str_0).long_description == 'None'
    assert type(parse(str_0).blank_after_short_description) is bool

# Generated at 2022-06-25 16:42:57.638486
# Unit test for function parse
def test_parse():
    meta_str_0 = ':param filename: The name of the file to read.\n    :type filename:  str'
    meta_str_1 = ':param stuff: The thing to do.\n\n    :type stuff: int'
    string_0 = 'My name is Bond.\n\n' + meta_str_0 + '\n\n' + meta_str_1
    doc_string = parse(string_0)
    assert doc_string.short_description == 'My name is Bond.'
    assert len(doc_string.meta) == 2
    assert doc_string.meta[0].description == 'The name of the file to read.'
    assert doc_string.meta[0].type_name == 'str'
    assert doc_string.meta[1].description == 'The thing to do.'

# Generated at 2022-06-25 16:43:00.933287
# Unit test for function parse
def test_parse(): 
    test_case_0()

    print("All unit tests for parse passed!")

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:43:08.905112
# Unit test for function parse
def test_parse():

    # Test with no docstring
    assert parse("") == Docstring(short_description=None, long_description=None)

    # Test with empty docstring
    assert parse("\n") == Docstring(
        short_description=None, long_description=None
    )

    # Test with no long description
    assert parse("Hey") == Docstring(short_description="Hey", long_description=None)

    # Test with long description
    assert parse("Hey\nThere") == Docstring(
        short_description="Hey",
        long_description="There",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )

    # Test with long description with trailing blank lines

# Generated at 2022-06-25 16:43:10.151342
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Integration tests for function parse

# Generated at 2022-06-25 16:43:11.249835
# Unit test for function parse
def test_parse():
    assert 0 == 1, 'Test not implemented'



# Generated at 2022-06-25 16:43:12.536206
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:43:23.776958
# Unit test for function parse
def test_parse():
    assert isinstance(parse(''), Docstring)
    assert parse('').short_description == None
    assert parse('').long_description == None
    assert parse('').blank_after_short_description == False
    assert parse('').blank_after_long_description == False
    assert isinstance(parse('').meta, list)
    assert isinstance(parse('').meta[0], DocstringMeta)
    assert parse('').meta[0].args == []
    assert parse('').meta[0].description == None

    assert parse('a\n\nb').short_description == 'a'
    assert parse('a\n\nb').long_description == 'b'

    str_0 = ':param filename: The name of the file to read.\n    :type filename:  str'
    docstring_0

# Generated at 2022-06-25 16:43:31.572298
# Unit test for function parse
def test_parse():
    str_0 = ':param filename: The name of the file to read.\n    :type filename:  str'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 2

    str_1 = '''
    This is a docstring

    :param filename: The name of the file to read.
    :type filename:  str
    '''
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "This is a docstring"
    assert docstring_1.blank_after