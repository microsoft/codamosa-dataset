

# Generated at 2022-06-25 16:33:53.609969
# Unit test for function parse
def test_parse():

    str_0 = ""

    docstring_0 = parse(str_0)
    assert docstring_0.blank_after_long_description == None
    assert docstring_0.blank_after_short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.meta == []
    assert docstring_0.short_description == ""

    str_1 = "A function."

    docstring_1 = parse(str_1)
    assert docstring_1.blank_after_long_description == None
    assert docstring_1.blank_after_short_description == None
    assert docstring_1.long_description == None
    assert len(docstring_1.meta) == 0
    assert docstring_1.short_description == "A function."


# Generated at 2022-06-25 16:34:05.373790
# Unit test for function parse
def test_parse():
    # Test Case 0
    str_0 = 'T\\V1&'
    docstring_0 = parse(str_0)

    assert docstring_0.short_description == 'T\\V1&'
    assert docstring_0.meta == []
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False

    # Test Case 1
    str_1 = 'T\\V1&\n:param a: T\\V1&'
    docstring_1 = parse(str_1)

    assert docstring_1.short_description == 'T\\V1&'

# Generated at 2022-06-25 16:34:15.984387
# Unit test for function parse
def test_parse():
    str_0 = '''
    Function to add two numbers.

    :type arg_a: float
    :param arg_a: First number.
    :type arg_b: float
    :param arg_b: Second number.
    :returns: The sum of two numbers.
    '''
    str_1 = '''Function to add two numbers.'''
    str_2 = '''
    Function to add two numbers.

    :returns: The sum of two numbers.
    '''
    str_3 = '''
    Function to add two numbers.
    '''
    str_4 = '''
    Function to add two numbers.

    :type arg_a: float
    :param arg_a: First number.
    :type arg_b: float
    :param arg_b: Second number.
    '''


# Generated at 2022-06-25 16:34:27.386538
# Unit test for function parse
def test_parse():
    # Test 0:
    str_0 = ''
    docstring_0 = parse(str_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.meta == []

    # Test 1:
    str_1 = '''
        This is a short description.

        This is a
        long description.
    '''
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'This is a short description.'
    assert docstring_1.long_description == 'This is a\nlong description.'
    assert docstring_1.blank_after_short_description
    assert docstring_1.meta == []

    # Test 2:

# Generated at 2022-06-25 16:34:38.872892
# Unit test for function parse
def test_parse():

    docstring = parse("""

foo bar baz
""")
    assert docstring.short_description == "foo bar baz"
    assert docstring.long_description is None
    assert len(docstring.meta) == 0

    docstring = parse("""

foo bar baz

Long description.
""")
    assert docstring.short_description == "foo bar baz"
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 0

    docstring = parse("""
:type x: int
:raises ValueError: Don't do that.

foo bar baz

Long description.
""")

# Generated at 2022-06-25 16:34:50.057035
# Unit test for function parse
def test_parse():
    # Test docstring with short and long description
    str_1 = 'Short desc.\n\nLong desc.'
    docstring_1 = parse(str_1)
    assert hasattr(docstring_1, 'short_description')
    assert hasattr(docstring_1, 'long_description')
    assert hasattr(docstring_1, 'meta')
    assert docstring_1.short_description == 'Short desc.'
    assert docstring_1.long_description == 'Long desc.'
    assert docstring_1.meta == []
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank_after_long_description == False

    # Test docstring with only short description
    str_2 = 'Short desc.'
    docstring_2 = parse(str_2)

# Generated at 2022-06-25 16:35:01.357650
# Unit test for function parse
def test_parse():
    args_0 = 'param name'
    args_1 = 'type_hint arg'
    args_2 = 'type_hint arg'
    ret_0 = 'Return'
    ret_1 = ''
    yields = 'Yield'
    raises = 'Raise'
    raises_0 = 'type_hint'
    desc = 'description'
    docstring = parse(
        '####\n{0}:\n{1}:\n{2}:\n{3}:\n{4}:\n{5}:\n{6}:\n{7}'.format(
            args_0, args_1, args_2, ret_0, ret_1, raises, yields, raises_0
        )
        + '\n'
        + desc
    )
    assert len(docstring.meta) == 8

# Generated at 2022-06-25 16:35:10.744408
# Unit test for function parse
def test_parse():
    assert parse('T\\V1&') == Docstring()

    assert parse('short desc\n\nlong desc') == Docstring(
        short_description='short desc',
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description='long desc',
    )

    assert parse('first line\nsecond line') == Docstring(
        short_description='first line\nsecond line',
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
    )


# Generated at 2022-06-25 16:35:18.138878
# Unit test for function parse
def test_parse():
    assert(parse('T\\V1&') == Docstring(short_description='T\\V1&', meta=[]))
    assert(parse('T\\V1&\n\nYES') == Docstring(short_description='T\\V1&', long_description='YES', meta=[], blank_after_short_description=True, blank_after_long_description=False))
    assert(parse('T\\V1&\n\nYES\n\n') == Docstring(short_description='T\\V1&', long_description='YES', meta=[], blank_after_short_description=True, blank_after_long_description=True))

# Generated at 2022-06-25 16:35:29.370025
# Unit test for function parse

# Generated at 2022-06-25 16:35:49.363154
# Unit test for function parse
def test_parse():
    # Test with valid input
    # Test 1
    # Test description: Test for a valid docstring
    # Expected output: Docstring(short_description='T\V1&', long_description=None, blank_after_short_description=False, blank_after_long_description=False, meta=[])
    # Actual output: Docstring(short_description='T\V1&', long_description=None, blank_after_short_description=False, blank_after_long_description=False, meta=[])
    assert parse('T\\V1&') == Docstring(short_description='T\V1&', long_description=None, blank_after_short_description=False, blank_after_long_description=False, meta=[])
    # Test 2
    # Test description: Test for a valid docstring
    # Expected output: Doc

# Generated at 2022-06-25 16:35:59.366763
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('hello world') == Docstring(
        short_description='hello world',
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[])
    assert parse('hello world\n') == Docstring(
        short_description='hello world',
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[])

# Generated at 2022-06-25 16:36:06.053931
# Unit test for function parse
def test_parse():
    # Example from the documentation.
    str_0 = '''
        Calculate something.

        :param x: The x value.
        :param y: The y value.
        :returns: The value of :math:`x` raised to the power of :math:`y`.
        :raises: :exc:`ZeroDivisionError` if y <= 0.
        '''
    docstring_0 = parse(str_0)

    assert docstring_0.short_description == "Calculate something."
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is True
    assert docstring_0.blank_after_long_description is False
    assert len(docstring_0.meta) == 4

# Generated at 2022-06-25 16:36:16.171426
# Unit test for function parse
def test_parse():
    func = parse

    # Test 0
    str_0 = 'T\\V1&'
    result = func(str_0)
    assert not result.is_method_or_property
    assert not result.is_constructor
    assert not result.is_method
    assert not result.is_property
    assert not result.is_static
    assert not result.is_class_method
    assert result.short_description == 'T\\V1&'
    assert not result.blank_after_short_description
    assert not result.blank_after_long_description
    assert not result.long_description
    assert len(result.meta) == 0

    # Test 1
    str_0 = 'R_\\D2\\N/'
    result = func(str_0)
    assert not result.is_method_or_property

# Generated at 2022-06-25 16:36:18.688633
# Unit test for function parse
def test_parse():
    test_case_0()

# unit test for class DocstringMeta

# Generated at 2022-06-25 16:36:25.689250
# Unit test for function parse
def test_parse():
    str_1 = 'T\\V1&'
    assert str_1 == docstring_0
    str_2 = 'T\\V1&'
    assert str_2 == docstring_0
    str_3 = 'T\\V1&'
    assert str_3 == docstring_0
    str_4 = ''
    assert str_4 == docstring_0
    str_5 = 'T\\V1&'
    assert str_5 == docstring_0

if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:36:35.268359
# Unit test for function parse
def test_parse():
    str_2 = """TestCase.__call__(self, *args, **kwds)
    Implement case.run().

    This method is called by the test runner.  It returns a
    result object that captures the outcome of the test run.

    :param args: Argument list to pass to subTest()
    :param kwds: Keyword dict to pass to subTest()
    """
    docstring_1 = parse(str_2)


# Generated at 2022-06-25 16:36:47.045886
# Unit test for function parse
def test_parse():
    # Test case 0
    str_0 = 'This is a short description.\n\nThis is a long description.\n'
    expected_0 = [
        'This is a short description.',
        '',
        'This is a long description.',
        '',
        '',
        ''
    ]
    actual_0 = parse(str_0)
    assert expected_0 == actual_0
    # Test case 1
    str_1 = 'This is a short description.\nThis is a long description.\n\n'
    expected_1 = [
        'This is a short description.',
        '',
        'This is a long description.',
        '',
        '',
        ''
    ]
    actual_1 = parse(str_1)
    assert expected_1 == actual_1
   

# Generated at 2022-06-25 16:36:48.924582
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:36:52.427621
# Unit test for function parse
def test_parse():
    str_0 = 'T\\V1&' # Should raise an exception
    docstring_0 = parse(str_0)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:36:59.612385
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:37:08.510694
# Unit test for function parse
def test_parse():
    tmp = "  Test this out.\n  \n  :Parameters:\n    :param can: what a can can.\n    :type can: int\n    :param not: something you can't.\n    :type not: str\n  :returns something: something else\n  :rtype: int\n  :param must: something you must.\n    :type must: str\n    \n    :raises ValueError: if the input is wrong.\n  "
    dr = parse(tmp)
    assert dr.short_description == 'Test this out.'
    assert dr.long_description == 'what a can can.\nsomething you can\'t.\nsomething you must.\n\n'
    assert dr.blank_after_long_description
    assert dr.blank_after_short_description

# Generated at 2022-06-25 16:37:17.590337
# Unit test for function parse
def test_parse():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    # test_case_19()
    # test_case_20()
    # test_case_21()
    # test_case_22()
    # test_case_23()
    #

# Generated at 2022-06-25 16:37:28.898697
# Unit test for function parse
def test_parse():
    assert docstring_0.short_description == 'T\V1&'
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta[0].args == []
    assert docstring_0.meta[0].description == None
    assert docstring_0.meta[1].args == []
    assert docstring_0.meta[1].description == None


# Generated at 2022-06-25 16:37:29.840141
# Unit test for function parse
def test_parse():
    test_case_0()


# Generated at 2022-06-25 16:37:33.583140
# Unit test for function parse
def test_parse():
    str_0 = 'T\\V1&'
    docstring_0 = parse(str_0)


# Parameterize test case
testcase_parse = [(str_0)]
# @pytest.mark.parametrize("str", testcase_parse)

# Generated at 2022-06-25 16:37:38.892063
# Unit test for function parse
def test_parse():
    # Test case #0
    str_0 = 'T\nV1&'
    docstring_0 = parse(str_0)
    assert(docstring_0.short_description == 'T')


# Generated at 2022-06-25 16:37:49.799212
# Unit test for function parse
def test_parse():
    str_0 = 'T\\arrV1:A&'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'T\\arrV1:A'
    assert len(docstring_0.meta) == 0
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    str_1 = 'T\\arrV1:A& :param int a: a'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'T\\arrV1:A'
    assert len(docstring_1.meta) == 1
    assert docstring_1.meta[0].arg_name == 'a'

# Generated at 2022-06-25 16:37:55.239191
# Unit test for function parse
def test_parse():
    str_0 = 'T\\V1&'
    docstring_0 = parse(str_0)

    assert docstring_0.short_description == 'T\\V1&'
    assert not docstring_0.blank_after_short_description
    assert not docstring_0.blank_after_long_description
    assert docstring_0.long_description is None



# Generated at 2022-06-25 16:38:08.083747
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[]
    )
    assert parse('Docstring') == Docstring(
        short_description='Docstring',
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[]
    )
    assert parse('Docstring\n    with long description.') == Docstring(
        short_description='Docstring',
        long_description='with long description.',
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[]
    )

# Generated at 2022-06-25 16:38:19.101227
# Unit test for function parse
def test_parse():
    str_0 = 'This is a single line description of the function.\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == str_0.strip()
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []
    assert docstring_0.__repr__() == 'Docstring(short_description="This is a single line description of the function.")'
    str_1 = 'This is a single line description of the function.\n\nThis is a longer description of the function.\n'
    docstring_1 = parse(str_1)

# Generated at 2022-06-25 16:38:26.129291
# Unit test for function parse
def test_parse():
    str_0 = '''T\\V1&
    :param a: T\\V1&'''
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'T\\V1&'
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 1
    assert docstring_0.meta[0].args[0] == 'param'
    assert docstring_0.meta[0].args[1] == 'a'
    assert docstring_0.meta[0].description == 'T\\V1&'
    assert docstring_0.meta[0].arg_name == None

# Generated at 2022-06-25 16:38:35.349077
# Unit test for function parse

# Generated at 2022-06-25 16:38:42.313574
# Unit test for function parse
def test_parse():
    # /tests/test_parse.py:17: error: Unexpected exception raised:
    # Traceback (most recent call last):
    #   File "/usr/local/lib/python3.8/site-packages/mypy/mypyc/common.py", line 31, in module_object_to_str
    #     return chr(obj.kind) + obj.name
    # ValueError: chr() arg not in range(256)

    str_0 = "T\\V1&\n:param a: T\\V1&"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "T\\V1&"
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.long_description == None
    assert docstring_0

# Generated at 2022-06-25 16:38:44.882348
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:38:55.186303
# Unit test for function parse
def test_parse():
    str_0 = ':param a: T\\V1&\n\nFirst line.\n\nSecond line.'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.long_description == 'First line.\n\nSecond line.'
    assert docstring_0.blank_after_long_description == True
    assert docstring_0.meta[0].args == ['param', 'a']
    assert docstring_0.meta[0].description == 'T\\V1&'
    assert docstring_0.meta[0].arg_name == 'a'
    assert docstring_0.meta[0].type_name == None

# Generated at 2022-06-25 16:39:06.025951
# Unit test for function parse
def test_parse():
    str0 = str(':param a: T\\V1&')
    docstring0 = parse(str0)
    assert docstring0.short_description == None
    assert docstring0.long_description == None
    assert docstring0.blank_after_short_description == False
    assert docstring0.blank_after_long_description == False
    assert docstring0.meta[0].brief_description == None
    assert docstring0.meta[0].name == 'a'
    assert docstring0.meta[0].type_name == 'T\\V1'
    assert docstring0.meta[0].description == 'T\\V1&'
    assert len(docstring0.meta) == 1

    str1 = str(':param a: T\\V1&\n:param b: T\\V1&')


# Generated at 2022-06-25 16:39:13.856061
# Unit test for function parse
def test_parse():
    str_0 = ''
    docstring_0 = parse(str_0)
    assert docstring_0.long_description == None
    assert docstring_0.short_description == None
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.blank_after_short_description == False
    assert len(docstring_0.meta) == 0
    str_1 = 'A test\n    '
    docstring_1 = parse(str_1)
    assert docstring_1.long_description == None
    assert docstring_1.short_description == 'A test'
    assert docstring_1.blank_after_long_description == False
    assert docstring_1.blank_after_short_description == False
    assert len(docstring_1.meta) == 0
    str

# Generated at 2022-06-25 16:39:24.752102
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('A small description') == Docstring(
        short_description='A small description',
        blank_after_short_description=True,
        blank_after_long_description=False
    )
    assert parse('A small description.\n') == Docstring(
        short_description='A small description',
        blank_after_short_description=True,
        blank_after_long_description=False
    )
    assert parse('A small description.\n\n') == Docstring(
        short_description='A small description',
        blank_after_short_description=True,
        blank_after_long_description=True
    )

# Generated at 2022-06-25 16:39:32.962382
# Unit test for function parse
def test_parse():
    str_0 = ''
    ret_0 = Docstring(short_description=None, blank_after_short_description=False, long_description=None, blank_after_long_description=False, meta=[])
    res_0 = parse(str_0)
    assert res_0 == ret_0

    str_1 = 'T\\V1&'
    ret_1 = Docstring(short_description='T\\V1&', blank_after_short_description=False, long_description=None, blank_after_long_description=False, meta=[])
    res_1 = parse(str_1)
    assert res_1 == ret_1

    str_2 = 'T\\V1&\n:param a: T\\V1&'

# Generated at 2022-06-25 16:39:41.928608
# Unit test for function parse
def test_parse():
    str_0 = 'T\\V1&\n:param a: T\\V1&'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'T\\V1&'
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 1

    str_1 = '\n\nbb\n:param a: aa\n:return: bb'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == ''
    assert docstring_1.long_description == 'bb'
    assert docstring_1.blank_after_short_

# Generated at 2022-06-25 16:39:51.685107
# Unit test for function parse
def test_parse():
    str_0 = 'hello world\n\n:param x: integer\n:returns: None\n\n'
    doc_0 = parse(str_0)
    assert doc_0.short_description == "hello world"
    assert doc_0.blank_after_short_description == True
    assert doc_0.long_description == None
    assert doc_0.blank_after_long_description == False
    assert len(doc_0.meta) == 2
    assert doc_0.meta[0].args == ["param", "x"]
    assert doc_0.meta[0].description == "integer"
    assert doc_0.meta[1].args == ["returns"]
    assert doc_0.meta[1].description == "None"



# Generated at 2022-06-25 16:39:58.041477
# Unit test for function parse
def test_parse():
    # Test that function parse works correctly when given a string with no new lines
    assert parse("Test function") == Docstring(short_description="Test function", long_description=None)
    assert parse("") == Docstring(short_description=None, long_description=None)

    # Test that function parse works correctly when given a string with multiple new lines
    assert parse("Test function\n\n") == Docstring(short_description="Test function", long_description=None, blank_after_short_description=True, blank_after_long_description=True)
    # Test a basic case.
    assert parse("short description.") == Docstring(
        short_description="short description.", long_description=None,
    )
    # Test a case with no description, only meta.

# Generated at 2022-06-25 16:39:59.013113
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:40:07.435777
# Unit test for function parse
def test_parse():
    str_0 = 'T\\V1&\n:param a: T\\V1&'
    docstring_0 = parse(str_0)
    assert len(docstring_0.meta) == 1
    meta_0 = docstring_0.meta[0]
    assert isinstance(meta_0, DocstringParam)
    assert meta_0.arg_name == 'a'
    assert meta_0.type_name == 'T\\V1&'

    str_1 = 'T\\V1&\n:param a: T\\V1&\n:return: T\\V1&'
    docstring_1 = parse(str_1)
    assert len(docstring_1.meta) == 2
    meta_1_0 = docstring_1.meta[0]

# Generated at 2022-06-25 16:40:18.698462
# Unit test for function parse
def test_parse():
    str_0 = ''
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == None
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True
    assert docstring_0.long_description == None
    assert docstring_0.meta == []

    str_1 = 'T\\V1&\n:param a: T\\V1&'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'T&V1'
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.blank_after_long_description == True
    assert docstring_1.long_description == None
    assert docstring_1

# Generated at 2022-06-25 16:40:28.994125
# Unit test for function parse
def test_parse():
    # We use a docstring from the PyQT documentation
    str_1 = """
        QUrlInfo

        The QUrlInfo class stores information about URLs.

        This class is used in conjunction with the QUrlOperator to provide
        meta-data about the objects that make up the structure of the
        world wide web (or your intranet). It also provides a set of
        functions that enables you to determine the type of an object and
        the permissions that your application has to access it.

        See QUrl and QUrlOperator for more information.
        """

    docstring_1 = parse(str_1)

    assert docstring_1.short_description == "QUrlInfo"

# Generated at 2022-06-25 16:40:33.911979
# Unit test for function parse
def test_parse():
    docstring_0 = parse(':returns: int\n:returns: str')
    assert docstring_0.short_description is None, 'short_description should be None'
    assert docstring_0.long_description is None, 'long_description should be None'
    assert not docstring_0.blank_after_short_description, 'blank_after_short_description should be False'
    assert docstring_0.blank_after_long_description, 'blank_after_long_description should be True'
    assert len(docstring_0.meta) == 2, 'len(docstring_0.meta) should be 2'
    assert docstring_0.meta[0].description == 'int', 'description of docstring_0.meta[0] should be \'int\''
    assert docstring_0.meta[0].type

# Generated at 2022-06-25 16:40:44.502484
# Unit test for function parse
def test_parse():
    assert parse("") == parse("")
    assert parse("\n") == parse("\n")
    assert parse("\n\n") == parse("\n\n")
    assert parse("\n\n\n") == parse("\n\n\n")
    assert parse("\n\n\n\n") == parse("\n\n\n\n")
    assert parse("\n\n\n\n\n") == parse("\n\n\n\n\n")

    assert parse(" ") == parse(" ")
    assert parse("  ") == parse("  ")
    assert parse("   ") == parse("   ")
    assert parse("    ") == parse("    ")
    assert parse("     ") == parse("     ")


# Generated at 2022-06-25 16:40:45.514938
# Unit test for function parse
def test_parse():
    assert False, "TODO: Implement"

# Generated at 2022-06-25 16:40:51.989198
# Unit test for function parse
def test_parse():
    def f():
        """
        Short description.

        Args:
            arg1 (bool):
            arg2 ():

        Returns:
        """

    print(parse(f.__doc__))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:41:04.107062
# Unit test for function parse
def test_parse():
    docstring = parse(
        """Parses a docstring into its components.

The docstring is parsed as a reStructuredText docstring (http://www.
sphinx-doc.org/en/stable/domains.html#info-field-lists). The title, param
lines, returns line, and raises lines are extracted, while all other meta
lines are simply stored in the ``meta`` attribute.

:param text: docstring to be parsed
:raises ParseError: if the docstring can't be parsed properly
:returns: parsed docstring
"""
    )
    assert docstring.short_description == "Parses a docstring into its components."
    assert docstring.blank_after_short_description is True

# Generated at 2022-06-25 16:41:14.627460
# Unit test for function parse
def test_parse():
    assert parse("""
    short

    long
    """) == Docstring(
        short_description="short",
        blank_after_short_description=False,
        long_description="long",
        blank_after_long_description=True,
        meta=[],
    )
    assert parse("""
    short

    long
    :type a: int
    """) == Docstring(
        short_description="short",
        blank_after_short_description=False,
        long_description="long",
        blank_after_long_description=True,
        meta=[
            DocstringMeta(
                args=["type", "a", "int"], description=""
            )
        ],
    )

# Generated at 2022-06-25 16:41:22.850282
# Unit test for function parse
def test_parse():
    assert parse('N\\V1&\n:param x: N\\V1&') == Docstring(
        short_description='N\\V1&',
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[DocstringParam(
            args=['param', 'x'],
            description='N\\V1&',
            arg_name='x',
            type_name=None,
            is_optional=None,
            default=None)])


# Testing the definitions in the module

# Generated at 2022-06-25 16:41:30.482798
# Unit test for function parse
def test_parse():
    str_0 = 'T\\V1&\n:param a: T\\V1&'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'T\\V1&'
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.meta[0].args == ['param', 'a']
    assert docstring_0.meta[0].description == 'T\\V1&'
    assert docstring_0.meta[0].arg_name is None
    assert docstring_0.meta[0].type_name is None
    assert docstring_0.meta[0].is_generator is False
    assert doc

# Generated at 2022-06-25 16:41:40.773667
# Unit test for function parse
def test_parse():
    str_1 = '''
    """
    This is a test.
    """
    '''
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "This is a test."
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank_after_long_description == False
    assert docstring_1.meta == []

    str_2 = '''
    """
    This is a test.

    More description.

    """
    '''
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == "This is a test."
    assert docstring_2.long_description == "More description."
    assert docstring_2.blank

# Generated at 2022-06-25 16:41:50.440724
# Unit test for function parse
def test_parse():
    # Test for function with 0 parameters
    assert(parse("") == Docstring())

    # Test for function with only short description
    assert(parse("Short description") ==
           Docstring(short_description="Short description"))

    # Test for function with only long description
    assert(parse("\nLong description\n") ==
           Docstring(short_description=None,
                     long_description="Long description",
                     blank_after_short_description=True,
                     blank_after_long_description=True))

    # Test for function with both short and long descriptions
    assert(parse("Short description\n\nLong description\n") ==
           Docstring(short_description="Short description",
                     long_description="Long description",
                     blank_after_short_description=True,
                     blank_after_long_description=True))

    # Test for

# Generated at 2022-06-25 16:41:57.189761
# Unit test for function parse
def test_parse():
    d = parse('test')
    assert d.short_description == 'test'
    assert d.long_description is None

    d = parse('test\n\nhello world\nthis is a test')
    assert d.short_description == 'test'
    assert d.long_description == 'hello world\nthis is a test'
    assert d.blank_after_short_description
    assert d.blank_after_long_description

    d = parse('test\nhello world\nthis is a test')
    assert d.short_description == 'test'
    assert d.long_description == 'hello world\nthis is a test'
    assert not d.blank_after_short_description
    assert not d.blank_after_long_description


# Generated at 2022-06-25 16:42:07.484594
# Unit test for function parse
def test_parse():

    str_0 = '''
        docs

        '''

    docstring_0 = parse(str_0)
    assert(docstring_0.short_description == 'docs')
    assert(docstring_0.long_description == None)


    str_1 = '''
        docs

        docs
        '''

    docstring_1 = parse(str_1)
    assert(docstring_1.short_description == 'docs')
    assert(docstring_1.long_description == 'docs')


    str_2 = '''
        docs

        docs

        '''

    docstring_2 = parse(str_2)
    assert(docstring_2.short_description == 'docs')
    assert(docstring_2.long_description == 'docs')



# Generated at 2022-06-25 16:42:14.556723
# Unit test for function parse
def test_parse():
    print('Testing function "parse"(src/parsers/restructuredtext.py)')
    str_0 = 'T\\V1&\n:param a: T\\V1&'
    str_1 = 'T\\V1&\n:param a: T\\V1&\n:raises: T\\V1&\n:returns: T\\V1&'
    str_2 = 'T\\V1&\n:param a: T\\V1&\n:raises: T\\V1&\n:returns: T\\V1&\n'

    docstring_0 = parse(str_0)
    docstring_1 = parse(str_1)
    docstring_2 = parse(str_2)

    assert docstring_0.short_description == 'T\\V1&'


# Generated at 2022-06-25 16:42:27.219800
# Unit test for function parse
def test_parse():
    func_docstring = '"""\n\
            \n\
            Returns the additive inverse of the input.\n\
            \n\
            :param a: the value to invert\n\
            :type a: C\\V1&\n\
            :returns: -a\n\
            \n\
            """\n'
    docstring = parse(func_docstring)
    assert docstring.short_description == 'Returns the additive inverse of the input.'
    assert docstring.long_description == '\n:param a: the value to invert\n:type a: C\\V1&\n:returns: -a'
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is True

# Generated at 2022-06-25 16:42:30.585733
# Unit test for function parse
def test_parse():
    # docstring with short description, long description and meta information
    docstring_0 = parse('T\\V1&\n\nT\\V1\n:param a: T\\V1&')
    print(docstring_0)



# Generated at 2022-06-25 16:42:40.055957
# Unit test for function parse
def test_parse():
    # Test case 1
    str_1 = "Test context manager.\n\n:param a: T\\V1&"
    assert parse(str_1) == Docstring(
        short_description="Test context manager.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description=None,
        meta=[
            DocstringParam(
                args=["param", "a"],
                description="T\\V1&",
                arg_name="a",
                type_name="a",
                is_optional=None,
                default=None,
            )
        ],
    )

    # Test case 2

# Generated at 2022-06-25 16:42:47.436923
# Unit test for function parse
def test_parse():
    str_0 = 'T\\V1&\n:param a: T\\V1&'
    docstring_0 = parse(str_0)
    print("docstring_0.short_description: ", docstring_0.short_description)
    print("docstring_0.meta[0]: ", docstring_0.meta[0])
    print("docstring_0.meta[0].__dict__: ", docstring_0.meta[0].__dict__)
    assert docstring_0 == parse(str_0)
    assert docstring_0.short_description == "T\\V1&"
    assert docstring_0.meta[0] == DocstringParam(['param', 'a'], "T\\V1&", 'a', 'a')

# Generated at 2022-06-25 16:42:53.564220
# Unit test for function parse
def test_parse():
    # input_0.txt and output_0.txt is taken from the ReST-style docstring example.
    input_file = open("../test/input_0.txt", "r")
    input_string = input_file.read()
    exp_output_file = open("../test/expected_output_0.txt", "r")
    exp_output_string = exp_output_file.read()

    output_string = parse(input_string)
    output_text = str(output_string)

    assert output_string == exp_output_string

# Generated at 2022-06-25 16:43:00.454998
# Unit test for function parse
def test_parse():
    assert parse('first line\nsecond line') == Docstring(
        short_description='first line',
        long_description='second line',
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    assert parse('first line\n\nsecond line') == Docstring(
        short_description='first line',
        long_description='second line',
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-25 16:43:02.756353
# Unit test for function parse
def test_parse():
    str_0 = 'T\\V1&\n:param a: T\\V1&'
    docstring_0 = parse(str_0)
    assert len(docstring_0.meta) == 1

# Generated at 2022-06-25 16:43:12.932672
# Unit test for function parse
def test_parse():
    str_0 = '''
    testing inspect
    :param a : \V1&
    '''
    docstring_0 = parse(str_0)
    assert docstring_0.long_description == 'testing inspect'
    assert docstring_0.short_description == 'testing inspect'
    assert docstring_0.meta[0].arg_name == 'a'
    assert docstring_0.meta[0].type_name == '\V1&'

    str_1 = 'this is a test\n    :param a \V1&\n    :returns \V1\n    '
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'this is a test'
    assert docstring_1.long_description == ''

# Generated at 2022-06-25 16:43:24.002104
# Unit test for function parse
def test_parse():
    flag = 1
    str_1 = """
    :param a: T\\V1"""
    docstring_1 = parse(str_1)
    #print(docstring_1.meta)
    if not len(docstring_1.meta) == 1:
        print("Fail to test case 1, length fail")
        flag = 0
    if not docstring_1.meta[0].type_name == 'T\\\\V1':
        print("Fail to test case 1, type name fail")
        flag = 0
    if not docstring_1.meta[0].arg_name == 'a':
        print("Fail to test case 1, arg name fail")
        flag = 0
    if not docstring_1.meta[0].description == 'T\\\\V1':
        print("Fail to test case 1, description fail")
        flag

# Generated at 2022-06-25 16:43:31.687240
# Unit test for function parse
def test_parse():
    str_0 = 'is_empty(x) -> bool\n\nReturn whether a container is empty.\n\n:param x: A container.\n:returns: Whether x is empty.'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'is_empty(x) -> bool'
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.long_description == 'Return whether a container is empty.'
    assert docstring_0.blank_after_long_description == True

    str_1 = 'is_empty(x) -> bool\n\nReturn whether a container is empty.\n:param x: A container.\n:returns: Whether x is empty.'
    docstring_1 = parse(str_1)
    assert doc