

# Generated at 2022-06-24 23:42:19.872331
# Unit test for function is_chroot
def test_is_chroot():
    try:
        assert True == is_chroot()
    except Exception as err:
        if str(err) != "AssertionError":
            raise
    assert True == is_chroot()

# Generated at 2022-06-24 23:42:23.907175
# Unit test for function is_chroot
def test_is_chroot():
    var_1 = is_chroot()
    var_2 = False
    assert var_1 == var_2


# Generated at 2022-06-24 23:42:26.481633
# Unit test for function is_chroot
def test_is_chroot():

    assert (is_chroot() == False)

# Unit test case for 'ansible.module_utils.facts.system.chroot.is_chroot'

# Generated at 2022-06-24 23:42:29.105270
# Unit test for function is_chroot
def test_is_chroot():
    # Check that an exception is raised
    with pytest.raises(Exception):
        # The exception is raised
        is_chroot()
    assert is_chroot() == True

# Generated at 2022-06-24 23:42:30.397183
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot(add(1,1)) == 2, 'fail'

# Generated at 2022-06-24 23:42:31.431162
# Unit test for function is_chroot
def test_is_chroot():
    assert isinstance(is_chroot(), bool)

# Generated at 2022-06-24 23:42:32.370883
# Unit test for function is_chroot
def test_is_chroot():
    print('Not implemented')


# Generated at 2022-06-24 23:42:33.322278
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot()

# Generated at 2022-06-24 23:42:35.925991
# Unit test for function is_chroot
def test_is_chroot():
    assert False


# Generated at 2022-06-24 23:42:38.251028
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is None, 'is_chroot evaluation Test Failed'

# Generated at 2022-06-24 23:42:52.916228
# Unit test for function is_chroot

# Generated at 2022-06-24 23:42:55.769335
# Unit test for function is_chroot
def test_is_chroot():
    os.environ['debian_chroot'] = 'abc'
    assert is_chroot() == True
    os.environ['debian_chroot'] = 'False'
    assert is_chroot() == True
    os.environ['debian_chroot'] = ''
    assert is_chroot() == False
    os.environ.pop('debian_chroot')
    assert is_chroot() == False

# Generated at 2022-06-24 23:42:56.404765
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == None, 'Function: is_chroot failed'

# Generated at 2022-06-24 23:42:58.342895
# Unit test for function is_chroot
def test_is_chroot():
    var_1 = is_chroot()
    assert var_1 is False, "Failed asserting that: <var_1> is False"


# Generated at 2022-06-24 23:43:01.447359
# Unit test for function is_chroot
def test_is_chroot():
    pass


if __name__ == '__main__':
    import pytest
    pytest.main(["test_is_chroot.py"])

# Generated at 2022-06-24 23:43:02.424155
# Unit test for function is_chroot
def test_is_chroot():
    assert True == is_chroot()

# Generated at 2022-06-24 23:43:17.249988
# Unit test for function is_chroot
def test_is_chroot():
    var_1 = 'os.stat'
    with patch(var_1) as mock_os_stat:
        var_1 = {'st_ino': 256, 'st_dev': 256}
        mock_os_stat.return_value = var_1
        var_1 = 'os.environ.get'
        with patch(var_1) as mock_os_environ_get:
            mock_os_environ_get.return_value = False
            var_1 = 'os.stat'
            with patch(var_1) as mock_os_stat_1:
                var_2 = 256
                var_1 = {'st_ino': var_2, 'st_dev': 256}
                mock_os_stat_1.side_effect = [var_1]
                var_1 = is_chroot

# Generated at 2022-06-24 23:43:18.325713
# Unit test for function is_chroot
def test_is_chroot():
    var_0 = is_chroot()
    assert var_0 == False

# Generated at 2022-06-24 23:43:19.003353
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == None

# Generated at 2022-06-24 23:43:20.996118
# Unit test for function is_chroot
def test_is_chroot():
    var_0 = None
    var_0 = is_chroot()
    assert var_0 == False


# Generated at 2022-06-24 23:43:29.612855
# Unit test for function is_chroot
def test_is_chroot():
    var_0 = is_chroot()
    if var_0:
        assert var_0
    assert var_0

# Generated at 2022-06-24 23:43:36.971632
# Unit test for function is_chroot
def test_is_chroot():
    assert (is_chroot() == True), 'test_case_0: Expected True, got %s' % is_chroot()

# Output of set -o xtrace from inside of the is_chroot() function.
# + my_root=/
# + os.stat::stat('/')
# + my_root=<os.stat_result: (4096L, 1L, 0L)>
# + os.stat::stat('/proc/1/root/.')
# + proc_root=<os.stat_result: (4096L, 1L, 0L)>
# + is_chroot=True
# + return True
# __call__ {
# 	my_root=/
# 	os.stat::stat('/') => None
# 	my_root=<os.stat_result:

# Generated at 2022-06-24 23:43:38.830976
# Unit test for function is_chroot
def test_is_chroot():
    var_0 = is_chroot()
    # assert var_0 == False


# Generated at 2022-06-24 23:43:39.836983
# Unit test for function is_chroot
def test_is_chroot():
    assert( is_chroot() == True)

# Generated at 2022-06-24 23:43:41.456294
# Unit test for function is_chroot
def test_is_chroot():
    var_0 = 'foo'
    assert is_chroot(module=var_0)


# Generated at 2022-06-24 23:43:42.676092
# Unit test for function is_chroot
def test_is_chroot():
    out = is_chroot()
    assert out is not None

# Generated at 2022-06-24 23:43:43.568679
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot()

# Generated at 2022-06-24 23:43:44.113797
# Unit test for function is_chroot
def test_is_chroot():
    assert True

# Generated at 2022-06-24 23:43:51.621458
# Unit test for function is_chroot
def test_is_chroot():
    # mock out os
    real_os = os
    os = mock.MagicMock()

    # mock out os.environ
    real_os_environ = os.environ
    os.environ = {'debian_chroot': False}

    # mock out os.stat
    os.stat = mock.MagicMock()
    os.stat.return_value = mock.MagicMock(st_ino=1, st_dev=1)

    # mock os.path.isdir
    real_os_path_isdir = os.path.isdir
    os.path.isdir = mock.MagicMock()
    os.path.isdir.return_value = True

    # mock os.stat
    real_os_stat = os.stat
    os.stat = mock.MagicMock()
    os.stat

# Generated at 2022-06-24 23:43:55.183168
# Unit test for function is_chroot
def test_is_chroot():
    pass

# Generated at 2022-06-24 23:44:10.532915
# Unit test for function is_chroot
def test_is_chroot():
    assert True == is_chroot()

# Generated at 2022-06-24 23:44:13.145035
# Unit test for function is_chroot
def test_is_chroot():

    assert is_chroot() is not None
    assert True is not None

# Generated at 2022-06-24 23:44:14.229976
# Unit test for function is_chroot
def test_is_chroot():
    var_0 = is_chroot()
    assert type(var_0) == bool


# Generated at 2022-06-24 23:44:15.969807
# Unit test for function is_chroot
def test_is_chroot():
    var_0 = is_chroot()
    var_1 = is_chroot()
    assert var_0 == var_1
    # assert var_1 is False


# Generated at 2022-06-24 23:44:17.139892
# Unit test for function is_chroot
def test_is_chroot():
    # Module ansible.module_utils.facts.system.chroot.is_chroot has been removed
    pass

# Generated at 2022-06-24 23:44:20.159894
# Unit test for function is_chroot

# Generated at 2022-06-24 23:44:21.480272
# Unit test for function is_chroot
def test_is_chroot():
    assert isinstance(is_chroot(module=None), bool)

# Generated at 2022-06-24 23:44:22.676855
# Unit test for function is_chroot
def test_is_chroot():
    var_0 = is_chroot()
    assert var_0 is None

# Generated at 2022-06-24 23:44:23.512225
# Unit test for function is_chroot
def test_is_chroot():
    pass


# Generated at 2022-06-24 23:44:24.354123
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-24 23:45:03.403456
# Unit test for function is_chroot
def test_is_chroot():

    # this is the true case
    var_0 = is_chroot()
    assert var_0 is True

    # this is the false case
    var_1 = is_chroot()
    assert var_1 is False

# Generated at 2022-06-24 23:45:06.787552
# Unit test for function is_chroot
def test_is_chroot():

    # Test if function returns True
    var_0 = is_chroot()
    return True


# Generated at 2022-06-24 23:45:07.824979
# Unit test for function is_chroot
def test_is_chroot():
    assert False == is_chroot()

# Generated at 2022-06-24 23:45:09.365839
# Unit test for function is_chroot
def test_is_chroot():
    assert True

# Generated at 2022-06-24 23:45:10.706417
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == None

# Generated at 2022-06-24 23:45:20.424076
# Unit test for function is_chroot
def test_is_chroot():
    var_1 = os.stat('/')
    try:
        # check if my file system is the root one
        proc_root = os.stat('/proc/1/root/.')
        var_0 = (var_1.st_ino != proc_root.st_ino) or (var_1.st_dev != proc_root.st_dev)
    except Exception:
        # I'm not root or no proc, fallback to checking it is inode #2
        fs_root_ino = 2

        var_2 = 'stat'
        var_1 = os.stat('/')
        var_0 = (var_1.st_ino != fs_root_ino)
    
    return var_0

if __name__ == '__main__':
    print('Test 1:')

# Generated at 2022-06-24 23:45:25.997320
# Unit test for function is_chroot
def test_is_chroot():
    var_0 = is_chroot()

# Source: src/lib/ansible/module_utils/facts/collector/chroot.py
# Called from: src/lib/ansible/module_utils/facts/collector/chroot.py
# Supplementary return: 
#   (bool) -> Whether or not the current environment is chrooted

# Generated at 2022-06-24 23:45:26.880590
# Unit test for function is_chroot
def test_is_chroot():
    assert True == is_chroot()

# Generated at 2022-06-24 23:45:31.425015
# Unit test for function is_chroot
def test_is_chroot():
    var_0 = is_chroot()
    assert not var_0

# Generated at 2022-06-24 23:45:33.557117
# Unit test for function is_chroot
def test_is_chroot():
    var_0 = is_chroot()
    assert isinstance(var_0, (bool, type(None)))

# Module test for function is_chroot

# Generated at 2022-06-24 23:46:53.670075
# Unit test for function is_chroot
def test_is_chroot():
    if not is_chroot():
        assert 0
    else:
        assert 1

# Generated at 2022-06-24 23:47:01.041567
# Unit test for function is_chroot
def test_is_chroot():
    
    assert(is_chroot())
    assert(is_chroot())
    assert(is_chroot())
    assert(is_chroot())
    assert(is_chroot())
    assert(is_chroot())
    assert(is_chroot())
    assert(is_chroot())
    assert(is_chroot())
    assert(is_chroot())
    assert(is_chroot())
    assert(is_chroot())
    assert(is_chroot())
    assert(is_chroot())
    assert(is_chroot())
    assert(is_chroot())
    assert(is_chroot())
    assert(is_chroot())
    assert(is_chroot())
    assert(is_chroot())
    assert(is_chroot())


# Generated at 2022-06-24 23:47:01.434591
# Unit test for function is_chroot
def test_is_chroot():
    pass

# Generated at 2022-06-24 23:47:11.702470
# Unit test for function is_chroot
def test_is_chroot():
    import os


# Generated at 2022-06-24 23:47:18.702493
# Unit test for function is_chroot

# Generated at 2022-06-24 23:47:19.921581
# Unit test for function is_chroot
def test_is_chroot():
    var_0 = is_chroot()
    assert var_0 is None


# Generated at 2022-06-24 23:47:21.195787
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == None, "Function is_chroot returned a wrong result."



# Generated at 2022-06-24 23:47:24.910194
# Unit test for function is_chroot
def test_is_chroot():
    test_cases = [
        # BEGIN CHECK
        (
            '0',
        ),
        # END CHECK
    ]
    for i, test_case in enumerate(test_cases):
        test_case_0()
        test_case_0()
    test_case_0()



# Generated at 2022-06-24 23:47:26.517337
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is None, 'returned value does not match'


# Generated at 2022-06-24 23:47:29.237668
# Unit test for function is_chroot
def test_is_chroot():
    assert callable(is_chroot)

    var_0 = is_chroot()
    assert var_0 is None

    var_1 = is_chroot()
    assert var_1 is None



# Generated at 2022-06-24 23:50:33.420899
# Unit test for function is_chroot
def test_is_chroot():
    assert callable(is_chroot)


# Generated at 2022-06-24 23:50:34.361182
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot()



# Generated at 2022-06-24 23:50:35.211894
# Unit test for function is_chroot
def test_is_chroot():
    assert test_is_chroot() == True

# Generated at 2022-06-24 23:50:36.043730
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False


# Generated at 2022-06-24 23:50:37.474340
# Unit test for function is_chroot
def test_is_chroot():
    # Check that we are not in chroot
    assert is_chroot() == False


test_case_0()
test_is_chroot()

# Generated at 2022-06-24 23:50:38.333500
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False


# Generated at 2022-06-24 23:50:39.681644
# Unit test for function is_chroot
def test_is_chroot():
    result_0 = is_chroot()
    assert result_0 == None


# Generated at 2022-06-24 23:50:40.512318
# Unit test for function is_chroot
def test_is_chroot():
    var_0 = is_chroot()
    assert not var_0

# Generated at 2022-06-24 23:50:41.979733
# Unit test for function is_chroot
def test_is_chroot():
    """
    Check that is_chroot returns the correct fact.
    """
    # Tests for chroot mode
    assert(is_chroot() is True)

# Generated at 2022-06-24 23:50:46.961171
# Unit test for function is_chroot
def test_is_chroot():
    assert not hasattr(os, 'environ') or 'debian_chroot' not in os.environ
    assert not hasattr(os, 'stat') or '/' in os.stat
    assert not hasattr(os, 'stat') or '/proc/1/root/.' in os.stat
    assert not hasattr(os, 'stat') or '/' in os.stat
    assert not hasattr(os, 'stat') or '/proc/1/root/.' in os.stat
    assert not hasattr(os, 'stat') or '/' in os.stat