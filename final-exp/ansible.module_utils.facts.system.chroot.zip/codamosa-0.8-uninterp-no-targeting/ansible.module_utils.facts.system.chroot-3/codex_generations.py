

# Generated at 2022-06-20 19:01:30.521976
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fact_collector = ChrootFactCollector
    assert chroot_fact_collector.name == 'chroot'
    assert chroot_fact_collector._fact_ids == {'is_chroot'}


# Generated at 2022-06-20 19:01:33.988225
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot_fact = ChrootFactCollector()
    test_module = FakeAnsibleModule()
    assert chroot_fact.collect(test_module) == {'is_chroot': False}, 'chroot_fact.collect should return is_chroot = False'


# Generated at 2022-06-20 19:01:37.103159
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector.name == 'chroot'
    assert ChrootFactCollector._fact_ids == set(['is_chroot'])

# Generated at 2022-06-20 19:01:43.978388
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    """Assert collect() returns a dictionary containing 'is_chroot' in the keys
    Parameter module is not relevant to the test and has a default value set to None
    Parameter collected_facts is not relevant to the test and has a default value set to None
    """
    from ansible.module_utils.facts.collector import ChrootFactCollector
    chrootFactCollector = ChrootFactCollector()
    assert 'is_chroot' in chrootFactCollector.collect().keys()

# Generated at 2022-06-20 19:01:47.387806
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector.name == 'chroot'
    assert len(ChrootFactCollector._fact_ids) == 1

# Generated at 2022-06-20 19:01:49.357183
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    bfc = ChrootFactCollector()
    fact_data = bfc.collect()

    assert fact_data['is_chroot'] == False

# Generated at 2022-06-20 19:01:52.959702
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    from ansible.module_utils.facts import collector

    proto = collector.BaseFactCollector()

    assert hasattr(proto, 'collect') and callable(proto.collect)

# Generated at 2022-06-20 19:01:54.766075
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    assert ChrootFactCollector().collect().get('is_chroot') is None

# Generated at 2022-06-20 19:01:55.553830
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-20 19:02:01.913598
# Unit test for function is_chroot
def test_is_chroot():
    global os
    import os
    ctx = {'changed': 0, 'ansible_facts': {}}

    # Not in a chroot
    os.environ['debian_chroot'] = False
    os.stat = lambda x: os.lstat('/')

    os.stat = lambda x: os.lstat('/')
    os.lstat = lambda x: os.stat('/')
    assert not is_chroot()

    # In a chroot
    os.environ['debian_chroot'] = True
    assert is_chroot()

    # Not in a chroot
    os.environ['debian_chroot'] = False

    os.stat = lambda x: os.lstat('/')
    os.lstat = lambda x: os.stat('/usr')
    assert not is_chroot()



# Generated at 2022-06-20 19:02:09.778186
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    cf = ChrootFactCollector()
    assert(cf.name == 'chroot')
    assert(cf._fact_ids == set(['is_chroot']))


# Generated at 2022-06-20 19:02:13.628221
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fact = ChrootFactCollector()
    assert 'chroot' == chroot_fact.name
    assert 'is_chroot' in chroot_fact._fact_ids
    assert 'is_chroot' in chroot_fact.collect()

# Generated at 2022-06-20 19:02:23.483206
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():

    # Setup mock module object
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule
    setattr(module, 'get_bin_path', lambda x: '/usr/bin/stat')
    setattr(module, 'run_command', lambda x: (0, '', ''))

    # Test collector init
    cfc = ChrootFactCollector()

    # Test missing 'module' param
    assert is_chroot() is None

    # Test with mock module object
    assert is_chroot(module) is False
    # Test collect method
    facts = cfc.collect(module=module)[0]
    assert facts['is_chroot'] is False

# Generated at 2022-06-20 19:02:29.130632
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chrootFactCollector = ChrootFactCollector()
    assert chrootFactCollector.name == 'chroot'
    assert len(chrootFactCollector._fact_ids) == 1
    assert 'is_chroot' in chrootFactCollector._fact_ids

# Generated at 2022-06-20 19:02:31.769013
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    sys_module = AnsibleModuleMock()
    chroot_collector = ChrootFactCollector()
    assert chroot_collector.collect(sys_module) == {'is_chroot': False}


# Generated at 2022-06-20 19:02:41.651891
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.chroot import ChrootFactCollector
    from ansible.module_utils.facts.collectors import get_collector_instance

    collector = Collector()
    collector.collectors.append(
        get_collector_instance(ChrootFactCollector)
    )

    assert collector.collect()['is_chroot'] == is_chroot()

# Generated at 2022-06-20 19:02:43.647574
# Unit test for function is_chroot
def test_is_chroot():

    assert is_chroot(module=None) == False

# Generated at 2022-06-20 19:02:51.241824
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    class MockModule:
        def get_bin_path(self, string):
            return False
        def run_command(self, cmd):
            return (None, None, None)
    module = MockModule()
    fact_collector = ChrootFactCollector()
    res = fact_collector.collect(module=module)
    assert res == {'is_chroot': None}

# Generated at 2022-06-20 19:02:52.747309
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-20 19:02:57.459771
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot = ChrootFactCollector()
    assert chroot.name == 'chroot'
    assert chroot._fact_ids == { 'is_chroot' }

# Generated at 2022-06-20 19:03:16.557823
# Unit test for function is_chroot
def test_is_chroot():
    # We don't have a module mock for the test
    module = None

    if os.environ.get('debian_chroot', False):
        # We are in a Debian chroot, so we are in a chroot
        assert(is_chroot(module) == True)
    else:
        # We are not in a Debian chroot, we can test more cases
        if os.path.isdir('/proc'):
            # We have procfs, we can test the code path:
            my_root = os.stat('/')
            proc_root = os.stat('/proc/1/root/.')
            assert(is_chroot(module) == (my_root.st_ino != proc_root.st_ino or my_root.st_dev != proc_root.st_dev))

# Generated at 2022-06-20 19:03:21.865862
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chrootFactCollector = ChrootFactCollector()
    assert chrootFactCollector.name == 'chroot'
    assert len(chrootFactCollector._fact_ids) == 1
    assert 'is_chroot' in chrootFactCollector._fact_ids


# Generated at 2022-06-20 19:03:24.787848
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector.name == 'chroot'
    assert ChrootFactCollector._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:03:26.257601
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector.name == 'chroot'

# Generated at 2022-06-20 19:03:29.116951
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fact_collector = ChrootFactCollector()

    assert chroot_fact_collector.name == 'chroot'
    assert chroot_fact_collector._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:03:39.810844
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactManager
    from ansible.module_utils.facts import default_collectors
    
    # Setup FactManager to provide missing Facts used in the method
    mgr = FactManager(default_collectors)
    mgr.get_collection()
    
    # Test collect method with defined missing facts
    mgr.add_fact(ChrootFactCollector())
    test_collector = Collector.fetch_collector('chroot')
    test_collector.collect(mgr)
    assert(test_collector.fact_ids == {'is_chroot'})
    assert(test_collector.collectors == [])
    assert(test_collector.collect_once == {'is_chroot':True})
   

# Generated at 2022-06-20 19:03:49.131529
# Unit test for function is_chroot
def test_is_chroot():

    from ansible.module_utils.facts.collector import Facts
    from ansible.module_utils._text import to_text

    # simple '_ansible_test_facts' module with lots of privileges, can be used in
    # unit tests as drop-in replacement for 'setup' module.
    class _ansible_test_facts:
        def __init__(self, module_args):
            # detect if running in test environment
            if module_args.get('_ansible_test', False):
                self.run_command = _ansible_test_facts_run_command
            else:
                raise ValueError('Module can only be used in test environment')

        def get_bin_path(self, executable, required=False):
            if executable == 'stat':
                return '/bin/stat'
            else:
                return None



# Generated at 2022-06-20 19:03:52.359229
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chrootFactCollector = ChrootFactCollector()
    assert isinstance(chrootFactCollector, ChrootFactCollector)

# Generated at 2022-06-20 19:03:55.633298
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    my_chroot = ChrootFactCollector()
    assert my_chroot.name == 'chroot'
    assert my_chroot._fact_ids == set(['is_chroot'])



# Generated at 2022-06-20 19:04:00.137621
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    x = ChrootFactCollector()
    assert x.name == 'chroot'
    assert x._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:04:17.035812
# Unit test for function is_chroot
def test_is_chroot():
    """
    - name: Test timeout for is_chroot()
      assert:
        that:
          - is_chroot == expected_result
      vars:
        expected_result: False
    """

    from ansible.module_utils.facts import is_chroot as ansible_is_chroot

    try:
        # make the function available under its old name
        globals()['is_chroot'] = ansible_is_chroot
        assert is_chroot() == False
    except AssertionError as e:
        raise AssertionError(e)
    finally:
        del globals()['is_chroot']

# Generated at 2022-06-20 19:04:18.508199
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-20 19:04:21.220702
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    """ Test if collect method of ChrootFactCollector returns expected value.
    """
    collector = ChrootFactCollector()
    _facts = collector.collect()
    assert isinstance(_facts, dict)
    assert 'is_chroot' in _facts.keys()

# Generated at 2022-06-20 19:04:29.326834
# Unit test for function is_chroot
def test_is_chroot():

    class ModuleMock():
        def get_bin_path(self, bin):
            return '/usr/bin/' + bin

        def run_command(self, cmd):
            if cmd[1] == '-f':
                return 0, 'automatically mounted filesystem root type: btrfs', ''
            return 0, '2', ''

    import stat
    root_stat = os.stat('/')
    root_stat.st_ino = 2
    root_stat.st_dev = 0
    os.stat = lambda path: root_stat
    assert is_chroot(ModuleMock()) == False

    import shutil
    os.stat = shutil.copy(os.stat, globals())
    os.stat('/').st_ino = 256
    assert is_chroot(ModuleMock()) == False


# Generated at 2022-06-20 19:04:38.083831
# Unit test for function is_chroot
def test_is_chroot():

    class Module(object):
        def get_bin_path(self, path):
            return path

        def run_command(self, cmd):
            cmd_str = ' '.join(cmd)
            if cmd_str.endswith('/'):
                if cmd_str.endswith('/proc/1/root/.'):
                    return (0, '', '')
                elif cmd_str.endswith('/'):
                    return (0, 'btrfs', '')

    module = Module()
    assert is_chroot(module) == None

# Generated at 2022-06-20 19:04:39.446121
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    ChrootFactCollector()

# Generated at 2022-06-20 19:04:45.774487
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():

    class ModuleMock:

        def get_bin_path(self, executable):
            return '/usr/bin/%s' % executable

        def run_command(self, args):
            return None, 'ext4', ''

    fact_collector = ChrootFactCollector()
    collected_facts = {}

    fact_collector.collect(ModuleMock(), collected_facts)
    assert 'is_chroot' in collected_facts

# Generated at 2022-06-20 19:04:51.253999
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chrootFactCollector = ChrootFactCollector()
    assert (chrootFactCollector.name == 'chroot')
    assert (chrootFactCollector._fact_ids == {'is_chroot'})


# Generated at 2022-06-20 19:05:00.382760
# Unit test for function is_chroot
def test_is_chroot():
    from ansible.module_utils.facts._virtual import is_virtual
    from ansible.module_utils.facts.virtual import VirtualCollector

    _fake_module = lambda: None

    _fake_module.get_bin_path = lambda x: '/bin/' + x

    _fake_module.run_command = lambda x: (0, '', '')

    # Not in a chroot: should return false
    _fake_module.run_command = lambda x: (1, '/', '')
    assert not is_chroot(_fake_module)

    # In a chroot: should return true
    _fake_module.run_command = lambda x: (1, '/not-in-root', '')
    assert is_chroot(_fake_module)

# Generated at 2022-06-20 19:05:03.025635
# Unit test for function is_chroot
def test_is_chroot():
    import ansible.module_utils.facts.system.chroot
    assert ansible.module_utils.facts.system.chroot.is_chroot()


# Generated at 2022-06-20 19:05:23.648914
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    username_collector = ChrootFactCollector()
    assert username_collector.name == 'chroot'
    assert username_collector._fact_ids == set(['is_chroot'])

# Generated at 2022-06-20 19:05:24.596329
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False



# Generated at 2022-06-20 19:05:28.127543
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot = ChrootFactCollector()
    assert chroot.collect() == {'is_chroot': None}

# Generated at 2022-06-20 19:05:31.816907
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    collector = ChrootFactCollector()
    facts = collector.collect()
    assert 'is_chroot' in facts, "Expected facts['is_chroot'] to exist"

# Generated at 2022-06-20 19:05:33.143237
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-20 19:05:33.799059
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-20 19:05:36.294587
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    c = ChrootFactCollector()
    assert c.name == 'chroot'



# Generated at 2022-06-20 19:05:38.482319
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    assert is_chroot() == ChrootFactCollector().collect()['is_chroot']

# Generated at 2022-06-20 19:05:42.097224
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():

    cf = ChrootFactCollector()
    assert cf.name == 'chroot'
    assert cf._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:05:43.599782
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    collector = ChrootFactCollector()
    assert collector.name == 'chroot'
    assert collector._fact_ids == {'is_chroot'}

# Generated at 2022-06-20 19:06:18.160756
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    ChrootFactCollector()

# Generated at 2022-06-20 19:06:26.528914
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # Create an instance of the ChrootFactCollector
    cfc = ChrootFactCollector()

    # Create a fake module object to use in the collect method
    fm = FakeModule()

    # Call the collect method, of the ChrootFactCollector object.
    collected_facts = cfc.collect(fm)

    # Test the collected facts for a given set of values
    assert collected_facts == {'is_chroot': False}


# Generated at 2022-06-20 19:06:31.657245
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector().name == 'chroot'
    assert isinstance(ChrootFactCollector()._fact_ids, set)
    assert 'is_chroot' in ChrootFactCollector()._fact_ids


# Generated at 2022-06-20 19:06:34.674986
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    x = ChrootFactCollector()
    assert x.name == 'chroot'
    assert x._fact_ids == set(['is_chroot'])

# Generated at 2022-06-20 19:06:37.099237
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False
    os.environ['debian_chroot'] = "I'm in a chroot"
    assert is_chroot() is True

# Generated at 2022-06-20 19:06:43.204185
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fact_collector_object = ChrootFactCollector()
    assert chroot_fact_collector_object.name == 'chroot'
    assert chroot_fact_collector_object._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:06:50.443317
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    module = MagicMock()
    collected_facts = {'ansible_version': '2.9.1', 'ansible_facts': {'chroot': {'is_chroot': True}}}
    module.run_commad = MagicMock(return_value=(0, 'test', 'test'))
    module.get_bin_path = MagicMock(return_value='test')
    chroot = ChrootFactCollector().collect(module, collected_facts)
    module.assert_called()
    assert chroot == {'is_chroot': True}

# Generated at 2022-06-20 19:06:57.372488
# Unit test for function is_chroot
def test_is_chroot():

    fake_module = None

    # Check that fallback for no proc works
    root_fs = os.stat('/')
    if root_fs.st_ino == 2:
        is_chroot = is_chroot(fake_module)
        assert(is_chroot is False)
    else:
        is_chroot = is_chroot(fake_module)
        assert(is_chroot is True)

# Generated at 2022-06-20 19:06:58.662798
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-20 19:07:03.904779
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_obj = ChrootFactCollector()
    assert chroot_obj.name == 'chroot'
    assert chroot_obj._fact_ids == set(['is_chroot'])

# Generated at 2022-06-20 19:08:23.260450
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot_collector = ChrootFactCollector()
    assert {'is_chroot':False} == chroot_collector.collect()

# Generated at 2022-06-20 19:08:33.499704
# Unit test for function is_chroot
def test_is_chroot():
    import sys
    import os

    if os.stat('/').st_ino != 2:
        sys.exit('Test system does not have / inode 2, you should fix your test environment')

    # Let's create a fake chroot in tmp folder
    import tempfile
    import shutil

    dname = tempfile.mkdtemp()

    cmd = ['mount', '--bind', '/', dname]
    if os.getuid() != 0:
        cmd.insert(0, 'sudo')
    try:
        rc, out, err = module.run_command(cmd)
    except Exception:
        # If we are not root, try again with fakeroot
        # We assume fakeroot is in $PATH
        cmd.insert(0, 'fakeroot')
        rc, out, err = module.run_command(cmd)

# Generated at 2022-06-20 19:08:34.594895
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot(None) == False

# Generated at 2022-06-20 19:08:40.691777
# Unit test for function is_chroot
def test_is_chroot():
    # This is a bit complicated since we're trying to test that a function
    # works both inside and outside a chroot environment.  In this test,
    # I'm running the function in two different processes in two different
    # Python interpreters.  The method that is used to figure out if code
    # is running inside a chroot will work if we run the process as root with
    # a custom chroot directory.  If the process is not running as root, then
    # the chroot directory must be the default root directory '/'.

    import os

    def _is_chroot(custom_chroot):
        if os.geteuid() != 0:
            custom_chroot = '/'

        # This is a bit tricky.  When we monkey-patch os.stat to run
        # os.stat("/proc/1/root/.") followed by os.

# Generated at 2022-06-20 19:08:50.459927
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.chroot import ChrootFactCollector
    from ansible.module_utils.facts.collectors.chroot import is_chroot
    from ansible.module_utils.facts.utils import ansible_facts

    module = Collector()
    module.get_bin_path = lambda x: True
    module.run_command = lambda *x: (0, 'btrfs', '')
    chroot = ChrootFactCollector(module=module)
    assert chroot._fact_ids == set(['is_chroot'])
    assert 'is_chroot' in chroot.collect(module=module).keys()
    is_chroot(module=module)

# For testing in a chroot environment

# Generated at 2022-06-20 19:08:51.537062
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-20 19:08:54.748415
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fact_collector = ChrootFactCollector()
    assert chroot_fact_collector.name == "chroot"
    assert chroot_fact_collector._fact_ids == {"is_chroot"}



# Generated at 2022-06-20 19:08:56.189788
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# vim: set et ts=4 sw=4 sts=4

# Generated at 2022-06-20 19:08:58.376388
# Unit test for function is_chroot
def test_is_chroot():
    is_chroot = ChrootFactCollector().collect().get('is_chroot')
    assert is_chroot is not None

# Generated at 2022-06-20 19:09:01.010971
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False