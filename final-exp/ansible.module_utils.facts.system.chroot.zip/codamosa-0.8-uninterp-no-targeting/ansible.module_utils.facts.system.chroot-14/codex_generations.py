

# Generated at 2022-06-20 19:01:30.589368
# Unit test for function is_chroot
def test_is_chroot():
    module = None
    is_chroot = is_chroot(module)
    assert is_chroot is not None

# Generated at 2022-06-20 19:01:38.190149
# Unit test for function is_chroot
def test_is_chroot():

    import os

    class ModuleMock(object):

        def __init__(self):
            self.exit_args = {}
            self.exit_args['rc'] = 0
            self.exit_args['msg'] = None
            self.params = {}

        def fail_json(self, **kwargs):
            self.exit_args.update(kwargs)
            raise Exception('test')

        def get_bin_path(self, cmd, opts=None, required=False):
            return cmd

    # fake not chroot
    m = ModuleMock()
    try:
        is_chroot(m)
    except Exception:
        pass

    assert m.exit_args['rc'] == 0
    assert m.exit_args['msg'] is None

    # fake chroot
    m = ModuleMock()

# Generated at 2022-06-20 19:01:41.156524
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector.name == 'chroot'
    assert ChrootFactCollector._fact_ids == {'is_chroot'}

# Generated at 2022-06-20 19:01:50.367204
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    collector_obj = ChrootFactCollector(None, None)

    # Not running on a chroot
    with open('/proc/1/root/.', 'wb') as fs_root_file:
        fs_root_file.write(b'/')

    fact_result = collector_obj.collect(None)
    assert fact_result['is_chroot'] is False

    # Running inside a chroot
    with open('/proc/1/root/.', 'wb') as fs_root_file:
        fs_root_file.write(b'/some/chroot/path')

    fact_result = collector_obj.collect(None)
    assert fact_result['is_chroot'] is True

# Generated at 2022-06-20 19:01:59.062268
# Unit test for function is_chroot
def test_is_chroot():
    # unittest requires us to use the stdlib
    from unittest import mock

    # mocking run_command
    class RunCommandMock(object):
        def __init__(self, results):
            self.results = results
            self.count = 0

        def side_effect(self, *args, **_kwargs):
            rc = self.results[self.count]
            self.count += 1
            return rc

    # mocking get_bin_path
    class GetBinPathMock(object):
        def side_effect(self, *args, **kwargs):
            if args[0] == 'stat':
                return '/bin/stat'

    # mocking os.stat
    class OsStatMock(object):
        def __init__(self, ino, dev):
            self.st_ino = ino

# Generated at 2022-06-20 19:02:04.084142
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # Test that 'is_chroot' fact is in returned dictionary

    ansible_module = {}

    chroot_fact_module = ChrootFactCollector()
    facts = chroot_fact_module.collect(ansible_module)

    assert 'is_chroot' in facts

# Generated at 2022-06-20 19:02:07.120071
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    obj = ChrootFactCollector()
    assert obj.name == 'chroot'
    assert obj._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:02:10.983886
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    c = ChrootFactCollector()
    assert c.name == 'chroot'
    assert c._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:02:15.728676
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    cfc = ChrootFactCollector()
    facts = cfc.collect()
    assert isinstance(facts, dict)
    is_chroot = facts['is_chroot']
    assert isinstance(is_chroot, bool)



# Generated at 2022-06-20 19:02:20.160289
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chrootFactCollector = ChrootFactCollector()
    assert chrootFactCollector.name == 'chroot'
    assert chrootFactCollector._fact_ids == set(['is_chroot'])


# Unit tests for method collect of class ChrootFactCollector

# Generated at 2022-06-20 19:02:28.424182
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # Modify the environment to pretend to be running under a chroot
    os.environ['debian_chroot'] = 'test'
    assert ChrootFactCollector().collect() == {'is_chroot': True}

# Generated at 2022-06-20 19:02:31.805593
# Unit test for function is_chroot
def test_is_chroot():
    # What happens if we are not in a chroot?
    if os.getenv('__UNIT_TESTING_CHROOT') is not None:
        assert not is_chroot()
    else:
        assert is_chroot()

# Generated at 2022-06-20 19:02:36.365165
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    expected_result = {'is_chroot': False}
    c = ChrootFactCollector()
    result = c.collect()

    assert(result == expected_result)

# Generated at 2022-06-20 19:02:41.423938
# Unit test for function is_chroot
def test_is_chroot():
    if is_chroot():
        return {"changed": False, "ansible_facts": {"is_chroot": True}}
    else:
        return {"changed": False, "ansible_facts": {"is_chroot": False}}

# Generated at 2022-06-20 19:02:44.146529
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector.name == 'chroot'
    chroot_fact = ChrootFactCollector(None)
    assert chroot_fact._fact_ids == {'is_chroot'}


# Generated at 2022-06-20 19:02:48.624084
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fc = ChrootFactCollector()
    assert chroot_fc.name == 'chroot'
    assert set(chroot_fc._fact_ids) == set(['is_chroot'])

# Generated at 2022-06-20 19:02:50.598124
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    c = ChrootFactCollector()
    assert c.name == 'chroot'
    assert c._fact_ids == set(['is_chroot'])

# Generated at 2022-06-20 19:02:53.707367
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    fact = ChrootFactCollector()
    collected_facts = fact.collect()
    assert collected_facts.get('is_chroot') == is_chroot()

# Generated at 2022-06-20 19:02:56.488205
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    assert ChrootFactCollector().collect() == {'is_chroot': is_chroot()}

# Generated at 2022-06-20 19:03:00.556922
# Unit test for function is_chroot
def test_is_chroot():
    from ansible.module_utils.facts import ModuleFacts

    f = ModuleFacts(module_args={})
    f.populate()

    assert is_chroot(module=f.module) is not None

# Generated at 2022-06-20 19:03:12.459018
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # Create an instance of class ChrootFactCollector
    chroot_collector = ChrootFactCollector()

    # Check if method collect returns something
    assert chroot_collector.collect() is not None


# Generated at 2022-06-20 19:03:18.126870
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    is_chroot = True

    mocked_module = basic.AnsibleModule(argument_spec=dict())
    mocked_module.run_command = lambda cmd, check_rc=True: (0, None, None)
    mocked_module.get_bin_path = lambda cmd: None
    mocked_collector = ChrootFactCollector(mocked_module)

    is_chroot_ret = mocked_collector.collect(module=mocked_module, collected_facts=dict())
    assert is_chroot_ret['is_chroot'] == is_chroot

# Generated at 2022-06-20 19:03:18.856969
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-20 19:03:22.405888
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector.name == 'chroot'
    c = ChrootFactCollector()
    assert c._fact_ids == set(['is_chroot'])

### Unit tests for method collect()


# Generated at 2022-06-20 19:03:28.164698
# Unit test for function is_chroot
def test_is_chroot():

    is_chroot = is_chroot()

    # If you are not in a chroot environment and you are root, you should be in inode 2 or 256/128 depending of your fs
    # if you are not in root the check will fallback to the onde check
    # In case of error, the check will return None
    assert is_chroot in [True, False, None]

# Generated at 2022-06-20 19:03:35.540579
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

    # This is a bit tricky, because os.stat() uses a different method
    # to get the information in the chroot environment.  We can't
    # actually tell that we are in a chroot environment this way.
    # but we can tell that we are not in one.
    os.environ['debian_chroot'] = "foobar"
    assert is_chroot() is False

# Generated at 2022-06-20 19:03:37.583454
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-20 19:03:39.258798
# Unit test for function is_chroot
def test_is_chroot():
    assert not is_chroot()

# Generated at 2022-06-20 19:03:47.768208
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    from ansible.module_utils.facts.collector.chroot import ChrootFactCollector
    from ansible.module_utils.facts import ModuleFacts, BaseFactCollector
    from ansible.module_utils.facts.collector.chroot import is_chroot
    import mock

    # Create an instance of ModuleFacts class
    module_facts = ModuleFacts(module_path=None)
    module_facts_ids = module_facts._collector_classes.keys()
    # Set the `collected_facts` attribute of the instance
    module_facts.collected_facts = {'all': {}}

    # Create an instance of BaseFactCollector class

# Generated at 2022-06-20 19:03:49.124212
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    pass

# Generated at 2022-06-20 19:04:16.404928
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():

    class MockModule:
        class MockRunCommand:
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

            def __call__(self, cmd):
                return self.rc, self.out, self.err

        def __init__(self):
            self.run_command = self.MockRunCommand(0, 'btrfs', None)

        def get_bin_path(self, name):
            return '/usr/bin/' + name

    class MockStat:
        def __init__(self, st_ino=2, st_dev=0x0801):
            self.st_ino = st_ino
            self.st_dev = st_dev


# Generated at 2022-06-20 19:04:20.348417
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    x = ChrootFactCollector()
    assert(x.name == 'chroot')
    assert(x._fact_ids == {'is_chroot'})


# Generated at 2022-06-20 19:04:21.338544
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    obj = ChrootFactCollector()
    assert obj.name == 'chroot'

# Generated at 2022-06-20 19:04:25.154512
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_collector = ChrootFactCollector()
    assert chroot_collector.name == "chroot"
    assert 'is_chroot' in chroot_collector._fact_ids


# Generated at 2022-06-20 19:04:28.562368
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_inst = ChrootFactCollector()
    assert chroot_inst.name == 'chroot'
    assert set(chroot_inst._fact_ids) == set(['is_chroot'])

# Generated at 2022-06-20 19:04:34.366883
# Unit test for function is_chroot
def test_is_chroot():
    if is_chroot():
        assert 1 == 2, "is_chroot() should have returned False, but it returned True"
    else:
        assert 1 == 1, "is_chroot() returned False, which is expected"


# Generated at 2022-06-20 19:04:35.286538
# Unit test for function is_chroot
def test_is_chroot():
    assert isinstance(is_chroot(), bool)

# Generated at 2022-06-20 19:04:38.948352
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    cfc = ChrootFactCollector()
    assert cfc.name == "chroot"
    assert cfc._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:04:40.829590
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    collector = ChrootFactCollector()
    assert collector is not None

# Generated at 2022-06-20 19:04:43.271479
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    cfc = ChrootFactCollector()
    assert cfc.collect()['is_chroot'] is False

# Generated at 2022-06-20 19:05:16.603378
# Unit test for function is_chroot
def test_is_chroot():
    from ansible.module_utils.facts import collector

    # Known true
    assert is_chroot() == True
    collector.collectors['chroot'].collect() == True

    # Known false
    os.environ.pop('debian_chroot', None)
    assert is_chroot() == False
    collector.collectors['chroot'].collect() == False

# Generated at 2022-06-20 19:05:17.886346
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-20 19:05:23.214750
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    cfc = ChrootFactCollector()
    assert cfc.name == 'chroot'
    assert cfc._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:05:26.359285
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    from . import MockModule
    module = MockModule()
    fc = ChrootFactCollector()
    fc.collect(module, {})
    assert 'is_chroot' in module.exit_args
    assert isinstance(module.exit_args['is_chroot'], bool)

# Generated at 2022-06-20 19:05:28.416924
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-20 19:05:30.464565
# Unit test for function is_chroot
def test_is_chroot():
    # Fail with no parameter
    assert not is_chroot()

# Generated at 2022-06-20 19:05:31.816774
# Unit test for function is_chroot
def test_is_chroot():
    assert isinstance(is_chroot(), bool)

# Generated at 2022-06-20 19:05:33.827416
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fact_collector = ChrootFactCollector()
    assert chroot_fact_collector.name == 'chroot'
    assert chroot_fact_collector._fact_ids == set(['is_chroot'])

# Generated at 2022-06-20 19:05:45.917030
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    import unittest2 as unittest

    class MockAnsibleModule:
        class MockRunCommand:
            def __init__(self):
                self.completed_process = type('CompletedProcess', (object,), {'stdout':'ext4', 'returncode':0})

            def run_command(self, cmd, check_rc=True):
                return (self.completed_process.returncode, self.completed_process.stdout, None)

        class MockAnsibleModule(MockRunCommand):
            def __init__(self):
                MockRunCommand.__init__(self)
                self.params = {
                    'run_command': self.run_command
                }

        MockAnsibleModule = MockAnsibleModule()


    chroot_fact_collector = ChrootFactCollector()

# Generated at 2022-06-20 19:05:51.162421
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    from ansible.module_utils.facts import collector

    fc = ChrootFactCollector()
    facts = fc.collect()
    assert facts['ansible_facts']['is_chroot'] == is_chroot()

# Generated at 2022-06-20 19:06:53.078171
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-20 19:06:56.785941
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot_fact_collector = ChrootFactCollector()
    result = chroot_fact_collector.collect()
    assert type(result) is dict
    assert result['is_chroot'] == is_chroot()

# Generated at 2022-06-20 19:07:03.530019
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():

    class ModuleStub(object):
        def get_bin_path(self, arg):
            return '/bin/'+arg

        def run_command(self, args):
            pass

    module = ModuleStub()

    chroot_collector = ChrootFactCollector(module)
    chroot_collector.collect()

# Generated at 2022-06-20 19:07:06.352806
# Unit test for function is_chroot
def test_is_chroot():
    """
    This function is unit-tested using the classes in
    unit/module_utils/basic.py.
    """
    pass

# Generated at 2022-06-20 19:07:16.297003
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    test_collector = ChrootFactCollector()
    facts_dict = {'system_uuid': 'foo'}

    module = None
    collected_facts = facts_dict
    new_facts = test_collector.collect(module=module, collected_facts=collected_facts)
    assert new_facts.get('is_chroot') is False

    module = None
    collected_facts = facts_dict
    new_facts = test_collector.collect(module=module, collected_facts=collected_facts)
    assert new_facts.get('is_chroot') is False

# Generated at 2022-06-20 19:07:22.458039
# Unit test for function is_chroot
def test_is_chroot():
    try:
        os.unlink('/proc/1/root')
    except:
        pass
    assert is_chroot() is True
    os.symlink('/', '/proc/1/root')
    assert is_chroot() is False

# Generated at 2022-06-20 19:07:28.044875
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    """Test module for method collect of class ChrootFactCollector"""
    # Create an empty class
    class EmptyModule(object):
        pass

    module = EmptyModule()

    # Create a ChrootFactCollector object
    chroot_fact_collector = ChrootFactCollector()

    # Return facts
    assert chroot_fact_collector.collect(module) == {'is_chroot': False}

# Generated at 2022-06-20 19:07:39.933297
# Unit test for function is_chroot
def test_is_chroot():
    this_dir, this_filename = os.path.split(__file__)
    mock_ansible_module = AnsibleMockModule(**{
        'run_command.return_value': ['', '', 0],
        'get_bin_path.return_value': os.path.join(this_dir, '../../../bin/ansible')
    })

    # Make sure that is_chroot returns False if we are not in a chroot
    assert is_chroot(mock_ansible_module) is False

    # Make sure that is_chroot returns True if we are in a chroot
    with patch.dict(os.environ, {'debian_chroot': 'something'}):
        assert is_chroot(mock_ansible_module) is True



# Generated at 2022-06-20 19:07:49.916733
# Unit test for function is_chroot
def test_is_chroot():
    import ansible.module_utils.facts.collector

    ansible.module_utils.facts.collector.is_chroot = is_chroot
    # As a module
    import ansible.module_utils.basic
    facts = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    ).run()
    assert facts['ansible_facts']['is_chroot'] == is_chroot()
    # As a library
    collected_facts = ansible.module_utils.facts.collector.get_all_facts()
    assert collected_facts['is_chroot'] == is_chroot()

    del ansible.module_utils.facts.collector.is_chroot

# Generated at 2022-06-20 19:07:53.585391
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    test_module = {
        'run_command': lambda cmd: (0, 'btrfs', '')
    }
    facts = ChrootFactCollector().collect(test_module)
    assert isinstance(facts, dict)
    assert 'is_chroot' in facts
    assert 'changed' not in facts

# Generated at 2022-06-20 19:10:41.391979
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False
    # monkey patch os module functions to simulate chroot environment
    os.stat = lambda x: (0,0,0,0,0,'','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)
    assert is_chroot() is True

# Generated at 2022-06-20 19:10:45.783784
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    x = ChrootFactCollector()
    assert x.name == 'chroot'
    assert x._fact_ids == {'is_chroot'}

# Generated at 2022-06-20 19:10:54.693058
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    ChrootFactCollector.name = 'chroot'

    from ansible.module_utils.facts.collector import get_collector_instance

    ChrootFactCollector = get_collector_instance(ChrootFactCollector.name)()
    ChrootFactCollector._fact_ids = set(['is_chroot'])

    from ansible.module_utils._text import to_bytes

    class MockModule:
        def __init__(self):
            self.params = {}
            self.called = False

        def run_command(self, dir):
            self.called = True
            if dir[1] == '-f':
                return 0, to_bytes('btrfs'), None
            return 0, to_bytes('xfs'), None

        def get_bin_path(self, cmd):
            return 'stat'

# Generated at 2022-06-20 19:10:56.205510
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-20 19:11:05.889664
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    def run_command_mock(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False):
        stat_path, _, _, _ = args
        if stat_path == '/bin/stat':
            return 0, 'Filesystem Type: ext4', None
        elif stat_path == '/usr/bin/stat':
            return 0, 'Filesystem Type: btrfs', None

    def get_bin_path_mock(self, name, required=False, opt_dirs=[]):
        return '/bin/stat' if name == 'stat' else '/usr/bin/stat'


# Generated at 2022-06-20 19:11:07.587488
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-20 19:11:14.155486
# Unit test for function is_chroot
def test_is_chroot():
    if os.path.exists('/proc'):
        assert is_chroot() == (os.stat('/').st_ino != os.stat('/proc/1/root/.').st_ino \
                or os.stat('/').st_dev != os.stat('/proc/1/root/.').st_dev)
    else:
        assert is_chroot() == (os.stat('/').st_ino != 2)

# Generated at 2022-06-20 19:11:19.528606
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    ChrootFactCollector = ChrootFactCollector()
    module = None
    collected_facts = None
    is_chroot = ChrootFactCollector.collect(module, collected_facts)
    assert is_chroot != None

# Generated at 2022-06-20 19:11:25.913916
# Unit test for function is_chroot
def test_is_chroot():
    # We need to be able to import module_utils from the parent directory and
    # this is the easiest way to do that despite being poor form
    import sys
    sys.path.append('../')
    from ansible.module_utils.facts import collector

    chroot_fact_collector = collector.get_fact_collector('chroot', collected_facts=None)
    res = chroot_fact_collector.collect(collected_facts={})

    assert 'is_chroot' in res and res['is_chroot'] == False