

# Generated at 2022-06-20 19:01:29.650628
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # (collector, module, collected_facts)
    chroot_fact_collector = ChrootFactCollec

# Generated at 2022-06-20 19:01:32.654572
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    collector = ChrootFactCollector()
    assert collector.name == 'chroot'
    assert collector._fact_ids == set(['is_chroot'])

# Generated at 2022-06-20 19:01:33.457190
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    ChrootFactCollector()


# Generated at 2022-06-20 19:01:35.366362
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    cfc = ChrootFactCollector()
    assert cfc.name == 'chroot'
    assert cfc._fact_ids == set(['is_chroot'])

# Generated at 2022-06-20 19:01:37.273712
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    collector = ChrootFactCollector()
    assert collector.name == 'chroot'
    assert collector._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:01:40.898413
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # GIVEN
    # WHEN
    result = ChrootFactCollector().collect()
    # THEN
    assert result['is_chroot'] == is_chroot()

# Generated at 2022-06-20 19:01:43.341693
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    cf = ChrootFactCollector()
    assert cf.name == 'chroot'
    assert cf._fact_ids == set(['is_chroot'])

# Generated at 2022-06-20 19:01:45.046981
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-20 19:01:48.052850
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    f = ChrootFactCollector()
    assert isinstance(f, BaseFactCollector)
    assert f.name == 'chroot'


# Generated at 2022-06-20 19:01:55.020370
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    module = MockModule()

    # Test that when chroot is not running, the return value of collect
    # method is not None
    x = ChrootFactCollector().collect(module)
    assert x is not None

    # Test that when chroot is running, the return value of collect
    # method is not None
    os.environ['debian_chroot'] = 'test'
    assert ChrootFactCollector().collect(module) is not None

# Generated at 2022-06-20 19:02:08.558181
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # Create an instance of class ChrootFactCollector
    chroot_fact_collector_obj = ChrootFactCollector()
    # Call method collect
    result = chroot_fact_collector_obj.collect()
    assert result['is_chroot'] == is_chroot()

# Generated at 2022-06-20 19:02:11.763097
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    c = ChrootFactCollector()
    assert c.name == 'chroot'
    assert c._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:02:23.418720
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import collector_registry

    # Mock module
    class MockModule(object):
        def get_bin_path(self, _):
            return None

        def run_command(self, _):
            return (0, 'procfs', '')

    module = MockModule()

    # Mock os module
    class MockOS(object):
        class stat_result(object):
            def __init__(self, ino):
                self.st_ino = ino

        def stat(_):
            return MockOS.stat_result(2)

        def environ_get(_, default):
            return False

    import ansible.module_utils.facts.sources.chroot as chroot
    chroot.os = MockOS()

# Generated at 2022-06-20 19:02:27.359182
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    x = ChrootFactCollector()
    assert x.name == 'chroot'
    assert x._fact_ids == set(['is_chroot'])



# Generated at 2022-06-20 19:02:34.156306
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():

    class MockModule:

        class MockRunCommand:

            @staticmethod
            def run_command(cmd):
                return 0, 'btrfs', ''

        def get_bin_path(self, command):
            return True

        def run_command(self, cmd):
            return MockModule.MockRunCommand.run_command(cmd)

        @staticmethod
        def get_platform():
            return 'Linux'

        @staticmethod
        def get_distribution():
            return 'Ubuntu'

    assert ChrootFactCollector().collect(MockModule())['is_chroot'] == (os.stat('/').st_ino != 256)

# Generated at 2022-06-20 19:02:38.679250
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot = ChrootFactCollector()
    assert chroot is not None
    assert chroot.name == 'chroot'
    assert chroot._fact_ids == {'is_chroot'}

# Generated at 2022-06-20 19:02:42.321510
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    c = ChrootFactCollector()
    assert 'is_chroot' in c.collect()
    assert 'is_chroot' in c.collect(collected_facts={'is_chroot': True})

# Generated at 2022-06-20 19:02:44.466425
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    a = ChrootFactCollector()
    assert not a.is_caching

# Generated at 2022-06-20 19:02:50.226296
# Unit test for function is_chroot
def test_is_chroot():
    import ansible.module_utils.facts
    import os
    facts = ansible.module_utils.facts.collector.get_collection_context()
    is_chroot = facts['is_chroot']
    assert is_chroot == os.path.ismount('/ansible')

# Generated at 2022-06-20 19:02:52.151770
# Unit test for function is_chroot
def test_is_chroot():

    assert(isinstance(is_chroot(), bool))



# Generated at 2022-06-20 19:03:07.618952
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    ChrootFactCollector()


# Generated at 2022-06-20 19:03:09.012892
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    fact_collector = ChrootFactCollector()

# Generated at 2022-06-20 19:03:13.990725
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fact_collector = ChrootFactCollector()
    assert(chroot_fact_collector.name == 'chroot')
    assert(chroot_fact_collector._fact_ids == set(['is_chroot']))


# Generated at 2022-06-20 19:03:19.424255
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    os.environ['debian_chroot'] = 'test'
    assert ChrootFactCollector().collect(module=None, collected_facts=None) == {'is_chroot': True}
    del os.environ['debian_chroot']

# Generated at 2022-06-20 19:03:23.386649
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    """ChrootFactCollector - is_chroot"""
    test_class = ChrootFactCollector
    test_instance = test_class()

    assert test_instance.collect() == {'is_chroot': None}

# Generated at 2022-06-20 19:03:34.119940
# Unit test for function is_chroot
def test_is_chroot():
    # Test normal case
    is_chroot = is_chroot()
    assert is_chroot is True

    # Test with a valid module
    mock_module = MockModule()
    is_chroot = is_chroot(module=mock_module)
    assert is_chroot is True

    # Test with an invalid module
    mock_module = MockModule(returncode=1)
    is_chroot = is_chroot(module=mock_module)
    assert is_chroot is True

# Generated at 2022-06-20 19:03:46.907729
# Unit test for function is_chroot
def test_is_chroot():
    class MockModule(object):
        """Mock AnsibleModule object."""

        def __init__(self, bin_path, rc, out, err):
            self._bin_path = bin_path
            self._rc = rc
            self._out = out
            self._err = err

        def get_bin_path(self, bin):
            return self._bin_path

        def run_command(self, cmd):
            return self._rc, self._out, self._err

    class MockNoStat(object):
        def stat(self):
            raise Exception

    import contextlib

    @contextlib.contextmanager
    def mock_stat(path, statinfo):
        prev = os.stat
        try:
            os.stat = lambda x: statinfo
            yield
        finally:
            os.stat = prev

    #

# Generated at 2022-06-20 19:03:51.538724
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot = ChrootFactCollector()
    assert chroot.name == 'chroot'
    assert chroot._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:03:54.603478
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    cfc = ChrootFactCollector()
    result = cfc.collect()
    assert result['is_chroot'] is not None

# Generated at 2022-06-20 19:04:07.147567
# Unit test for function is_chroot
def test_is_chroot():
    import mock
    from ansible_collections.ansible.misc.tests.unit.module_utils.facts.collectors import chroot_collector

    # Instantiate our collector for tests - any module will do since we will
    # only call it's parameters
    collector = chroot_collector.ChrootFactCollector()

    class ModuleExitException(Exception):
        pass

    class TestModule:
        def __init__(self, params):
            self.params = params

        def exit_json(self, *args):
            raise ModuleExitException(args)

        def fail_json(self, *args, **kwargs):
            raise ModuleExitException(args, kwargs)

        def run_command(self, *args):
            return 0, '', ''

        def get_bin_path(self, *args):
            return

# Generated at 2022-06-20 19:04:26.505876
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    tChrootFactCollector = ChrootFactCollector()
    assert tChrootFactCollector
    assert tChrootFactCollector.name == 'chroot'
    assert tChrootFactCollector._fact_ids == set(['is_chroot'])


if __name__ == '__main__':
    test_ChrootFactCollector()

# Generated at 2022-06-20 19:04:39.125337
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactCollectorException

    class TestCollector(BaseFactCollector):

        _fact_ids = set(['id1', 'id2'])

        def collect(self, module=None, collected_facts=None):
            return {'id1': 'fact1',
                    'id2': 'fact2'}

    collector = TestCollector()
    assert Collector.collect_fact(collector, None) == {'id1': 'fact1', 'id2': 'fact2'}

# Generated at 2022-06-20 19:04:40.479849
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot()

# Generated at 2022-06-20 19:04:42.934985
# Unit test for function is_chroot
def test_is_chroot():
    module = MockModule()
    assert is_chroot(module) == module.is_chroot

# Generated at 2022-06-20 19:04:45.151014
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    fact_collector = ChrootFactCollector()
    facts = fact_collector.collect()
    assert facts['is_chroot'] == 'False'

# Generated at 2022-06-20 19:04:57.799190
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():

    import ansible.module_utils.facts.chroot
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.chroot import ChrootFactCollector
    from ansible.module_utils.facts import group_by

    # mock module
    class Module:
        def get_bin_path(self, command):
            if command == 'stat':
                return '/usr/bin/stat'

        def run_command(self, cmd):
            if cmd == ['/usr/bin/stat', '-f', '--format=%T', '/']:
                return (0, 'btrfs', '')

# Generated at 2022-06-20 19:05:01.784583
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot_fact_collector = ChrootFactCollector()
    facts = chroot_fact_collector.collect()
    assert facts == {'is_chroot': is_chroot()}

# Generated at 2022-06-20 19:05:04.248704
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    obj = ChrootFactCollector()
    assert obj.name == 'chroot'
    assert obj._fact_ids == set(['is_chroot'])
    assert obj.collect() == {'is_chroot': is_chroot()}

# Generated at 2022-06-20 19:05:05.454427
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    collector = ChrootFactCollector()
    facts = collector.collect()
    assert type(facts['is_chroot']) is bool

# Generated at 2022-06-20 19:05:07.754967
# Unit test for function is_chroot
def test_is_chroot():
    assert(is_chroot())

# Generated at 2022-06-20 19:05:37.600951
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is True

# Generated at 2022-06-20 19:05:39.508760
# Unit test for function is_chroot
def test_is_chroot():
    is_chroot = ChrootFactCollector()
    is_chroot.collect()

# Generated at 2022-06-20 19:05:43.829767
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fact_collector = ChrootFactCollector()
    assert chroot_fact_collector.name == 'chroot'
    assert 'is_chroot' in chroot_fact_collector._fact_ids



# Generated at 2022-06-20 19:05:54.008235
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # initialize
    root_fact_collector = ChrootFactCollector()

    # define the return value of is_chroot for testing
    def side_effect_is_chroot():
        return True

    # mock is_chroot
    root_fact_collector.is_chroot = side_effect_is_chroot

    # call method collect of ChrootFactCollector class
    is_chroot_actual = root_fact_collector.collect()

    assert is_chroot_actual == {"is_chroot": True}



# Generated at 2022-06-20 19:06:04.987920
# Unit test for function is_chroot
def test_is_chroot():
    test_os = {
        '/proc': {
            '1': {
                'root': {
                    '.': {}
                }
            }
        }
    }

    # Test that we detect that we are not in a chroot
    assert is_chroot(test_os) is False

    # Test that we detect that we are in a chroot (simply by mismatch on the inode)
    test_os['/']['st_ino'] = 3
    test_os['/proc/1/root/.']['st_ino'] = 2
    assert is_chroot(test_os) is True

# Generated at 2022-06-20 19:06:16.989982
# Unit test for function is_chroot
def test_is_chroot():
    root_stats = os.stat('/')
    fake_root_stats = os.stat('/etc')

    try:
        proc_stats = os.stat('/proc/1/root/.')
    except Exception:
        proc_stats = None

    # This is a chroot
    assert is_chroot()

    # Now emulate being outside a chroot
    os.stat = lambda path: root_stats if path == '/' else fake_root_stats
    assert not is_chroot()

    # Same but with /proc
    os.stat = lambda path: proc_stats if path == '/proc/1/root/.' else root_stats
    assert not is_chroot()

# Generated at 2022-06-20 19:06:21.454081
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    collector = ChrootFactCollector()
    assert collector.name == 'chroot'
    assert collector._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:06:22.755636
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    fact_module = ChrootFactCollector()
    assert fact_module.name == 'chroot'
    assert fact_module._fact_ids == set(['is_chroot'])

# Generated at 2022-06-20 19:06:26.458312
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    outcome = ChrootFactCollector()
    assert outcome
    assert outcome.name == "chroot"
    assert outcome._fact_ids == set(['is_chroot'])



# Generated at 2022-06-20 19:06:28.995740
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    assert is_chroot() in (True, False)

# Generated at 2022-06-20 19:07:39.289111
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    ChrootFactCollector()

# Generated at 2022-06-20 19:07:45.006634
# Unit test for function is_chroot
def test_is_chroot():
    from ansible.module_utils.facts.test_utils import FakeModule
    assert is_chroot() is True
    assert is_chroot(FakeModule({'connection': 'network_cli'})) is True
    assert is_chroot(FakeModule({'connection': 'local'})) is False

# Generated at 2022-06-20 19:07:47.301253
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector.name == 'chroot'
    assert ChrootFactCollector._fact_ids == {'is_chroot'}

# Generated at 2022-06-20 19:07:56.085682
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    c = ChrootFactCollector()
    class FakeModule():
        def __init__(self):
            self.run_command_result = None
        def get_bin_path(self, bin):
            return bin
        def run_command(self, cmd):
            return self.run_command_result
    xfs_stat_result = [0, 'linux', '']
    nfs_stat_result = [0, 'nfs', '']
    btrfs_stat_result = [0, 'btrfs', '']
    stat_err_result = [1, '', '']
    class FakeStatModule(FakeModule):
        def __init__(self):
            self.run_command_result = nfs_stat_result
    xfs_module = FakeStatModule()
    xfs_module.run_command

# Generated at 2022-06-20 19:07:56.938128
# Unit test for function is_chroot
def test_is_chroot():
    assert (is_chroot() == False)

# Generated at 2022-06-20 19:07:58.063637
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-20 19:08:08.003461
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():

    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import FactCache

    # Note: FactCache.get_facts also caches the new empty fact.
    # For now, that is fine for one time, as the test is done in isolation.
    collected_facts = FactCache().get_facts(gather_subset=[])

    assert not collected_facts['is_chroot']

    fc = get_collector_instance('chroot')
    assert fc.name == 'chroot'
    assert fc._fact_ids == set(['is_chroot'])

    collected_facts = fc.collect(collected_facts=collected_facts)
    assert collected_facts['is_chroot'] == is_chroot()

# Generated at 2022-06-20 19:08:10.343951
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fact = ChrootFactCollector()
    assert chroot_fact.name == 'chroot'
    assert chroot_fact._fact_ids == {'is_chroot'}


# Generated at 2022-06-20 19:08:11.975424
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    obj = ChrootFactCollector()
    assert obj.name == "chroot"
    assert obj._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:08:13.519170
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-20 19:11:04.121406
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    from ansible.module_utils.facts import is_chroot
    from ansible.module_utils.facts.facts import FactManager

    mock_module = None

    fm = FactManager()
    fm.collectors.append(ChrootFactCollector())
    # run the collect method to collect chroot facts
    fm.collect(module=mock_module)
    # get fact
    fact = fm.get_fact('is_chroot')
    # assert the fact and the method is_chroot returns the same value
    assert(fact == is_chroot(module=mock_module))

# Generated at 2022-06-20 19:11:10.094586
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # if module is None, ansible_local facts should be returned
    fc = ChrootFactCollector()
    facts = fc.collect()
    assert facts['ansible_local'] == fc.collect(module=None)
    assert facts['is_chroot']

# Generated at 2022-06-20 19:11:11.739184
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    ChrootFactCollector()


# Generated at 2022-06-20 19:11:15.949093
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import assemble_facts

    # test all subclasses of BaseFactCollector, at least
    # the one that may fail, chroot
    for factcollector_class in FactsCollector().fact_classes:
        f = factcollector_class()
        facts = f.collect()
        assemble_facts(facts, "test_ChrootFactCollector_collect", [])

    assert(facts['is_chroot'] is False)

# Generated at 2022-06-20 19:11:26.499417
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():

    import os
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import ChrootFactCollector

    class FakeModule():
        def get_bin_path(self, name, force=False):
            return "/bin/"+name

    def fake_run_command(self, commands, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        return (0, "", "")

    fake_module = FakeModule()
    fake_module.run_command = fake_run_command

    chroot = ChrootFactCollector()
    chroot.collect(module=fake_module)
