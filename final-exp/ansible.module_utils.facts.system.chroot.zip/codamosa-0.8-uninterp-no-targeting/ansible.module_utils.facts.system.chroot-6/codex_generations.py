

# Generated at 2022-06-20 19:01:35.508054
# Unit test for function is_chroot
def test_is_chroot():
    # Make easy to test, it will always use the function defined in this module
    import sys
    sys.modules['ansible.module_utils.facts'] = sys.modules[__name__]
    from ansible.module_utils.facts import chroot
    chroot.is_chroot = is_chroot
    from ansible.module_utils.facts.chroot import is_chroot

    assert is_chroot() is None
    os.environ["debian_chroot"]="(vagrant)"
    assert is_chroot() == True
    os.environ["debian_chroot"]=""
    assert is_chroot() == False
    os.environ.pop("debian_chroot")

# Generated at 2022-06-20 19:01:39.626048
# Unit test for function is_chroot
def test_is_chroot():
    assert os.environ.get('debian_chroot', None) is None
    assert is_chroot() is False
    os.environ['debian_chroot'] = 'foo'
    assert is_chroot() is True
    os.environ['debian_chroot'] = 'false'
    assert is_chroot() is True
    del os.environ['debian_chroot']
    assert os.environ.get('debian_chroot', None) is None

# Generated at 2022-06-20 19:01:40.944233
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot = ChrootFactCollector()

# Generated at 2022-06-20 19:01:44.118623
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    collector = ChrootFactCollector()
    assert collector is not None
    assert collector.name  == 'chroot'
    assert collector._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:01:55.412529
# Unit test for function is_chroot
def test_is_chroot():
    # No chroot - 0 tests
    assert is_chroot() == False

    # Chroot - 5 tests
    os.environ['debian_chroot'] = 'Chroot'
    assert is_chroot() == True
    del os.environ['debian_chroot']

    # No chroot - 0 tests (stat fails)
    os.stat('/2')
    assert is_chroot() == False

    # Chroot - 5 tests (same inode, different device)
    os.stat('/proc/1/root/3')
    assert is_chroot() == True

    # No chroot - 0 tests (different inode)
    os.stat('/')
    assert is_chroot() == False

# Generated at 2022-06-20 19:01:57.368876
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    c = ChrootFactCollector()
    assert c.name == 'chroot'
    assert c._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:01:58.041796
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-20 19:02:01.790079
# Unit test for function is_chroot
def test_is_chroot():
    is_chroot_var = is_chroot()
    assert type(is_chroot_var) is bool

# Generated at 2022-06-20 19:02:03.525323
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False, "This function should return False on normal environment"

# Generated at 2022-06-20 19:02:07.351107
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    collector = ChrootFactCollector()
    facts = collector.collect()
    assert facts['is_chroot'] == False


# Generated at 2022-06-20 19:02:16.378471
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_obj = ChrootFactCollector()
    assert chroot_obj.name == 'chroot'
    assert chroot_obj._fact_ids == set(['is_chroot'])

test_ChrootFactCollector()



# Generated at 2022-06-20 19:02:21.078329
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    mock_module = MockModule()
    mock_module.run_command = Mock(return_value=(0, 'btrfs', ''))
    is_chroot = ChrootFactCollector().collect(module=mock_module)
    assert is_chroot['is_chroot']


# Generated at 2022-06-20 19:02:22.994560
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector().name == 'chroot'

# Generated at 2022-06-20 19:02:25.196426
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    x = ChrootFactCollector()
    x.collect()

# Generated at 2022-06-20 19:02:25.909324
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-20 19:02:28.804779
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot = ChrootFactCollector()
    assert chroot.name == 'chroot'
    assert chroot._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:02:36.626989
# Unit test for function is_chroot
def test_is_chroot():
    class Module:
        def __init__(self, run_command_result):
            self.run_command_result = run_command_result

        def get_bin_path(self, bin, opts=None):
            return None

        def run_command(self, cmd, check_rc=True, close_fds=True):
            return self.run_command_result

    assert is_chroot(Module(run_command_result=(1, '', 'x'))) is None

    assert is_chroot(Module(run_command_result=(0, 'btrfs', ''))) is True
    assert is_chroot(Module(run_command_result=(0, 'ext4', ''))) is True
    assert is_chroot(Module(run_command_result=(0, 'ext3', ''))) is True

# Generated at 2022-06-20 19:02:38.095593
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot()

# Generated at 2022-06-20 19:02:41.728614
# Unit test for function is_chroot
def test_is_chroot():
    # If we are already running in a chroot, this test will not work
    # as expected, as we are already in a chroot environment.
    assert not is_chroot()

# Generated at 2022-06-20 19:02:47.333939
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    ChrootFactCollector = ChrootFactCollector()
    assert ChrootFactCollector.name == 'chroot'
    assert ChrootFactCollector._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:02:52.746380
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-20 19:02:57.459777
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    cfc = ChrootFactCollector()
    assert cfc.name == 'chroot'
    assert cfc._fact_ids == {'is_chroot'}

# Generated at 2022-06-20 19:03:01.683341
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    my_chroot = ChrootFactCollector()
    assert my_chroot.name == 'chroot'
    assert my_chroot.collect() == {'is_chroot': True}

# Generated at 2022-06-20 19:03:07.008567
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    """ Unit test for ChrootFactCollector collect."""

    os.environ['debian_chroot'] = 'foo'
    collector = ChrootFactCollector()
    result = collector.collect(module=None, collected_facts=None)
    assert result['is_chroot']

    os.environ.pop('debian_chroot')
    result = collector.collect(module=None, collected_facts=None)
    assert result['is_chroot']

# Generated at 2022-06-20 19:03:09.580257
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    cfc = ChrootFactCollector()
    assert cfc
    assert cfc.name == 'chroot'

# Generated at 2022-06-20 19:03:11.903602
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    fact_collector = ChrootFactCollector()
    assert fact_collector.name == 'chroot'
    assert fact_collector._fact_ids == {'is_chroot'}


# Generated at 2022-06-20 19:03:14.429059
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():

    # Test instantiation of class ChrootFactCollector
    chroot_collector_obj=ChrootFactCollector()
    assert chroot_collector_obj.name == 'chroot'

# Generated at 2022-06-20 19:03:16.085210
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    ChrootFactCollector()

# Generated at 2022-06-20 19:03:16.742842
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-20 19:03:26.019003
# Unit test for function is_chroot
def test_is_chroot():
    # Imports are here because we don't want to require mock unless
    # a unit test is actually running
    # pylint: disable=import-error
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector

    is_chroot = collector.chroot.is_chroot

    # Make sure function does not break when called with no argument
    assert is_chroot()

    # Make sure function does not break when called with a garbage argument
    assert is_chroot(None)
    assert is_chroot({'foo': 'bar'})
    assert is_chroot([1, 2, 3])
    assert is_chroot(BaseFactCollector())

    # Make sure function does not

# Generated at 2022-06-20 19:03:40.572189
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():

    import glob, os, uuid
    from ansible.module_utils import basic

    module_name = 'ansible_test_'+''.join(str(uuid.uuid4()).split('-'))
    module_path = os.path.join(glob.glob('/tmp/ansible_fact_collector_test_*')[0],module_name)
    os.mkdir(module_path)

# Generated at 2022-06-20 19:03:41.947592
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-20 19:03:43.248093
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-20 19:03:45.907321
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    # Create an object to test
    obj = ChrootFactCollector()

    # Check if it is an instance of the class
    assert isinstance(obj, ChrootFactCollector)


# Generated at 2022-06-20 19:03:51.114638
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert_equal(ChrootFactCollector().name, 'chroot')
    assert_equal(ChrootFactCollector()._fact_ids, set(['is_chroot']))


# Generated at 2022-06-20 19:03:52.494471
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot()

# Generated at 2022-06-20 19:03:54.421939
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    f = ChrootFactCollector()
    f.collect()

# Generated at 2022-06-20 19:03:57.312518
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # creating mock module object in order to use module.run_command
    import ansible.module_utils.basic
    M = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    assert ChrootFactCollector().collect(M) == {'is_chroot': None}


# Generated at 2022-06-20 19:04:02.194397
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_collector = ChrootFactCollector()
    assert chroot_collector.name == 'chroot'
    assert chroot_collector._fact_ids == {'is_chroot'}

# Generated at 2022-06-20 19:04:04.051393
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert (type(ChrootFactCollector()) is ChrootFactCollector)

# Generated at 2022-06-20 19:04:28.772518
# Unit test for function is_chroot
def test_is_chroot():
    import tempfile
    from ansible.module_utils.six import PY3
    from ansible.module_utils.facts import module_executor

    fact_collector = ChrootFactCollector()
    test_facts = {}
    fact_executor = module_executor.ModuleExecutor(module_name='setup', module_args={}, task_vars={})
    fact_executor.set_fact_collector(fact_collector)
    fact_executor.run(ansible_facts=test_facts)
    assert 'is_chroot' in test_facts

    if PY3:
        test_facts = {}

# Generated at 2022-06-20 19:04:30.407578
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    # creating instance of class ChrootFactCollector
    chroot_fact_collector_instance = ChrootFactCollector()
    # asserting name of instance
    assert chroot_fact_collector_instance.name == 'chroot'

# Generated at 2022-06-20 19:04:36.045743
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.chroot import ChrootFactCollector

    chroot = ChrootFactCollector()
    assert isinstance(chroot, ChrootFactCollector)
    assert isinstance(chroot, BaseFactCollector)

# Generated at 2022-06-20 19:04:39.582775
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    obj1 = ChrootFactCollector()
    assert obj1.name == 'chroot'
    assert obj1._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:04:46.315050
# Unit test for function is_chroot
def test_is_chroot():
    try:
        my_root = os.stat('/')
        proc_root = os.stat('/proc/1/root/.')
        is_chroot = my_root.st_ino != proc_root.st_ino or my_root.st_dev != proc_root.st_dev
    except Exception:
        is_chroot = False

    assert is_chroot == is_chroot(None)

# Generated at 2022-06-20 19:04:49.041392
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    f = ChrootFactCollector()
    assert(f.collect() == {'is_chroot': False})

# Generated at 2022-06-20 19:04:50.756799
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    x = ChrootFactCollector()
    assert x
    assert x.name == 'chroot'
    assert x._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:04:52.866690
# Unit test for function is_chroot
def test_is_chroot():

    is_ = is_chroot()

    assert(is_ in [True, False])

# Generated at 2022-06-20 19:04:54.182062
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-20 19:04:55.151446
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-20 19:05:28.053290
# Unit test for function is_chroot
def test_is_chroot():
    is_chroot = is_chroot()
    assert is_chroot is not None

# Generated at 2022-06-20 19:05:30.947762
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # Creating collector object
    x = ChrootFactCollector()
    # Getting collector facts
    res = x.collect()
    assert res['is_chroot'] is False

# Generated at 2022-06-20 19:05:31.751465
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    pass

# Generated at 2022-06-20 19:05:34.535172
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    facts = ChrootFactCollector()
    assert facts.name == 'chroot'
    assert facts._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:05:39.502174
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False
    # test if we have proc
    assert is_chroot(None) == True
    # test with module
    module = AnsibleModule(argument_spec={})
    assert is_chroot(module) == False

# Generated at 2022-06-20 19:05:46.872432
# Unit test for function is_chroot
def test_is_chroot():
    try:
        os.makedirs("/chroot/")
        with open("/chroot/.test", "w") as f:
            f.write("test")
        os.chroot("/chroot")
        os.chdir("/")
        assert os.stat("/chroot/.test")
        assert is_chroot() is True
    finally:
        os.chroot("/")
        os.chdir("/")
        os.unlink("/chroot/.test")
        os.rmdir("/chroot")


# Generated at 2022-06-20 19:05:50.033962
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    is_chroot = ChrootFactCollector().collect()
    assert type(is_chroot) is dict
    is_chroot_value = is_chroot['is_chroot']
    assert type(is_chroot_value) is bool

# Generated at 2022-06-20 19:05:53.469457
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    cfc = ChrootFactCollector()
    assert cfc.name == 'chroot'
    assert cfc._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:05:56.089489
# Unit test for function is_chroot
def test_is_chroot():
    class FakeModule:
        def get_bin_path(self, module):
            return module

        def run_command(self, cmd):
            return (0, 'btrfs', '')

    module = FakeModule()

    assert is_chroot(module) == False

# Generated at 2022-06-20 19:06:06.646475
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    """
    Test is_chroot fact
    :return:
    """
    class MyModule(object):
        def __init__(self, bin_path_mock):
            self.bin_path_mock = bin_path_mock

        def get_bin_path(self, cmd):
            return self.bin_path_mock

        def run_command(self, cmd):
            if cmd == ['/usr/bin/stat', '-f', '--format=%T', '/']:
                return (0, 'ext4', None)
            elif cmd == ['/bin/true', '-x', '/foo']:
                # this is a workaround to avoid fact_collector_chroot() being skipped because of the -x option in the command
                return (0, None, None)

    # test without stat command (

# Generated at 2022-06-20 19:06:40.582996
# Unit test for function is_chroot
def test_is_chroot():
    import ansible.module_utils.facts.system.chroot
    assert is_chroot() is True

# Generated at 2022-06-20 19:06:44.340892
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    obj = ChrootFactCollector()
    assert isinstance(obj, ChrootFactCollector)
    assert isinstance(obj, BaseFactCollector)


# Generated at 2022-06-20 19:06:51.963937
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    collector = ChrootFactCollector()
    my_root = os.stat('/')

    if os.environ.get('debian_chroot', False):
        assert collector.collect() == {'is_chroot': True}

    else:
        my_root = os.stat('/')
        try:
            # check if my file system is the root one
            proc_root = os.stat('/proc/1/root/.')
            assert collector.collect() == {'is_chroot': my_root.st_ino != proc_root.st_ino or my_root.st_dev != proc_root.st_dev}
        except Exception:
            # I'm not root or no proc, fallback to checking it is inode #2
            fs_root_ino = 2
            stat_path = '/bin/stat'

# Generated at 2022-06-20 19:06:55.639264
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    c = ChrootFactCollector()
    assert(c.name == 'chroot')
    assert(c._fact_ids == set(['is_chroot']))


# Generated at 2022-06-20 19:06:56.705684
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-20 19:06:59.270852
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    info = ChrootFactCollector()
    assert 'chroot' == info.name


# Generated at 2022-06-20 19:07:01.950792
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    module = None
    fact = ChrootFactCollector()
    fact.collect(module)

# Generated at 2022-06-20 19:07:05.550579
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector.name == 'chroot'
    assert ChrootFactCollector._fact_ids == set(['is_chroot'])


# Generated at 2022-06-20 19:07:08.451430
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fact_collector = ChrootFactCollector()
    assert chroot_fact_collector.name == 'chroot'

# Generated at 2022-06-20 19:07:09.785132
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot()

# Generated at 2022-06-20 19:08:30.160297
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    m = isChrootMock()
    fc = ChrootFactCollector()
    r= fc.collect(m)
    assert r['is_chroot'] == 'mock'

# Mock class to test method collect of class ChrootFactCollector

# Generated at 2022-06-20 19:08:33.300845
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    assert is_chroot() is None, "Chroot is not detected"

    # Override class variable _fact_ids to test collecting only chroot fact
    ChrootFactCollector._fact_ids = set(['is_chroot'])
    cf = ChrootFactCollector()
    assert cf.collect() == {'is_chroot': is_chroot()}, "Wrong chroot fact"

# Generated at 2022-06-20 19:08:40.053929
# Unit test for function is_chroot
def test_is_chroot():
    import ansible.module_utils.facts.chroot
    import tempfile
    import subprocess
    import shutil
    import os.path

    def _create_chroot():
        root_dir = tempfile.mkdtemp(prefix="chroot_")
        chroot_dir = os.path.join(root_dir, 'chroot_dir')
        os.makedirs(chroot_dir)
        open(os.path.join(chroot_dir, 'chroot_file'), "w").close()
        return root_dir, chroot_dir

    def _remove_chroot(root_dir):
        shutil.rmtree(root_dir, ignore_errors=True)

    def _chroot(chroot_dir):
        subprocess.check_call(['chroot', chroot_dir])

   

# Generated at 2022-06-20 19:08:43.026957
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False
    os.environ['debian_chroot'] = 'foo'
    assert is_chroot() is True
    del os.environ['debian_chroot']

# Generated at 2022-06-20 19:08:44.245237
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    c = ChrootFactCollector()
    assert c.name == 'chroot'
    assert c._fact_ids == set(['is_chroot'])

# Generated at 2022-06-20 19:08:45.652446
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    c = ChrootFactCollector()
    assert c.name == 'chroot'
    assert c._fact_ids == set(['is_chroot'])



# Generated at 2022-06-20 19:08:46.888417
# Unit test for function is_chroot
def test_is_chroot():
    # Assume not in chroot for now
    assert is_chroot() is False

# Generated at 2022-06-20 19:08:56.248041
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    l_chroot = ChrootFactCollector()

    class DummyModule():
        def run_command(self, cmd):
            return (0, 'xfs', '')

        def get_bin_path(self, cmd):
            if cmd == 'stat':
                return '/bin/stat'
            else:
                return None

    # Check chroot
    os.environ['debian_chroot'] = 'foo'
    facts = l_chroot.collect(DummyModule())
    assert facts['is_chroot']

    # Check no chroot
    del os.environ['debian_chroot']
    facts = l_chroot.collect(DummyModule())
    assert not facts['is_chroot']

    # Check no chroot with /proc unavailbale
    facts = l_chroot.collect()


# Generated at 2022-06-20 19:09:00.427839
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    collector = ChrootFactCollector()
    is_chroot = collector.collect()["is_chroot"]
    assert is_chroot in (True, False)

# Generated at 2022-06-20 19:09:09.087908
# Unit test for method collect of class ChrootFactCollector