

# Generated at 2022-06-11 04:17:50.542310
# Unit test for function is_chroot
def test_is_chroot():
    assert not os.environ.get('debian_chroot', False)
    assert is_chroot() == False
    os.environ['debian_chroot'] = 'test-chroot'
    assert is_chroot() == True
    del os.environ['debian_chroot']

# Generated at 2022-06-11 04:17:53.855173
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False
    os.environ['debian_chroot'] = "something"
    assert is_chroot() is True
    os.environ['debian_chroot'] = False
    assert is_chroot() is False

# Generated at 2022-06-11 04:17:56.995899
# Unit test for function is_chroot
def test_is_chroot():

    def run_command(cmd, module):
        return 0, 'btrfs', ''

    module = type('module', (object,), {'run_command': run_command})

    assert is_chroot(module) is True

# Generated at 2022-06-11 04:17:59.775488
# Unit test for function is_chroot
def test_is_chroot():
    # Check None value
    assert(is_chroot() is None)

    # Check chroot 'debian_chroot' env
    assert(is_chroot({'get_bin_path': lambda x: x}) is True)

# Generated at 2022-06-11 04:18:00.705222
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-11 04:18:01.606387
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is True

# Generated at 2022-06-11 04:18:07.138980
# Unit test for function is_chroot
def test_is_chroot():

    # We can not test this function when not in a chroot or when we are.
    # Mock the function os.stat
    import os
    import mock

    with mock.patch.object(os, 'stat', return_value=(None)):
        # When no /proc is available
        assert is_chroot() is False
        # When /proc is available
        with mock.patch.object(os, 'stat', return_value=(1,2)):
            assert is_chroot() is False

# Generated at 2022-06-11 04:18:08.157895
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-11 04:18:18.102425
# Unit test for function is_chroot
def test_is_chroot():

    module = None

    my_root = os.stat('/')
    proc_root = os.stat('/proc/1/root/.')

    # Test 1. I'm not root
    is_chroot = (my_root.st_ino != 2)
    assert is_chroot == is_chroot(module)

    # Test 2. I'm root and not chroot
    is_chroot = (my_root.st_ino != proc_root.st_ino or my_root.st_dev != proc_root.st_dev)
    assert is_chroot == is_chroot(module)

    # Test 3. I'm root and chroot
    os.environ['debian_chroot'] = 'test'
    is_chroot = True
    assert is_chroot == is_chroot(module)

   

# Generated at 2022-06-11 04:18:19.104481
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-11 04:18:32.614510
# Unit test for function is_chroot
def test_is_chroot():

    # required for module.run_command, thus it has to be part of a class
    class MyModule:
        def get_bin_path(self, module):
            pass

        def run_command(self, args):
            return (0, "", "")

    # chroot simulator
    os.environ['debian_chroot'] = '1'
    is_chroot = ChrootFactCollector().collect(collected_facts=None, module=MyModule())
    assert is_chroot['is_chroot'] is True

    # reset
    os.environ.pop('debian_chroot', None)
    is_chroot = ChrootFactCollector().collect(collected_facts=None, module=MyModule())
    assert is_chroot['is_chroot'] is False

    # chroot simulator 2

# Generated at 2022-06-11 04:18:33.571518
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot(None) is not None

# Generated at 2022-06-11 04:18:34.458548
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-11 04:18:35.397072
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-11 04:18:36.306796
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() in [True, False]

# Generated at 2022-06-11 04:18:46.699125
# Unit test for function is_chroot
def test_is_chroot():
    # We need to mock "module" argument with a function run_command
    from ansible.module_utils.basic import AnsibleModule
    mock_module = AnsibleModule(
        argument_spec = dict()
    )
    # Mocking run_command to always return 0 (rc), /dev/xvda1 (out) and empty string (err)
    mock_module.run_command = lambda x: (0, '/dev/xvda1', '')

    # Test when there is debian_chroot environment variable:
    os.environ["debian_chroot"] = "1"
    assert(is_chroot(module=mock_module) == True)
    del os.environ["debian_chroot"]

    # Test when there is no debian_chroot environment variable:

# Generated at 2022-06-11 04:18:52.361592
# Unit test for function is_chroot
def test_is_chroot():
    chroot = '/test/chroot'
    with open('/etc/debian_chroot', 'w') as chroot_file:
        chroot_file.write(chroot)
    assert is_chroot() is True
    os.unlink('/etc/debian_chroot')
    assert is_chroot() is False
    os.mkdir(chroot)
    os.chroot(chroot)
    assert is_chroot() is True

# Generated at 2022-06-11 04:18:53.375722
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-11 04:18:55.292601
# Unit test for function is_chroot
def test_is_chroot():
    my_root = os.stat('/')
    assert my_root.st_ino != 2
    assert is_chroot()

# Generated at 2022-06-11 04:19:03.458293
# Unit test for function is_chroot
def test_is_chroot():
    from ansible.module_utils import basic
    import ansible_collections.ansible.os_core.plugins.module_utils.facts as module_facts

    def run_func(module, func_name, args=None):
        if args is None:
            args = []

        actual = module_facts.get_module_api(module)[func_name](*args)
        return actual

    def test_func(module, func_name, args=None, expected=None):
        actual = run_func(module, func_name, args=args)
        if isinstance(expected, Exception):
            assert isinstance(actual, type(expected)), "Exception type mismatch"
            assert actual.args == expected.args, "Exception message does not match"
        else:
            assert actual == expected, "Return value does not match"


# Generated at 2022-06-11 04:19:08.580336
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is None

# Generated at 2022-06-11 04:19:09.446530
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-11 04:19:11.410610
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False
    os.environ['debian_chroot'] = 'foo'
    assert is_chroot() is True

# Generated at 2022-06-11 04:19:12.259555
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-11 04:19:21.610686
# Unit test for function is_chroot
def test_is_chroot():
    # os.stat('/') used to get statistics about the root directory.
    # os.stat('/proc/1/root/.') used to get statistics about container root directory.
    # os.stat('/.') or os.stat('/..') or os.stat('/') used to get statistics about host root directory.
    # All these are file system calls to get the inode attributes. Hence the mockup.
    class MockOsStat(object):
        def __init__(self, st_ino, st_dev):
            self.st_ino = st_ino
            self.st_dev = st_dev

    # Not chroot
    assert is_chroot() is False
    # Chroot
    assert is_chroot(MockOsStat(1, 2), MockOsStat(1, 2), MockOsStat(1, 2))

# Generated at 2022-06-11 04:19:25.243941
# Unit test for function is_chroot
def test_is_chroot():

    assert 'is_chroot' in is_chroot.__code__.co_varnames

    try:
        assert os.environ['debian_chroot'] is not False
        assert is_chroot() is True
    except KeyError:
        assert is_chroot() is not True

# Generated at 2022-06-11 04:19:35.247554
# Unit test for function is_chroot
def test_is_chroot():
    mock_module = type('module', (object,), {'get_bin_path': lambda: '/bin/stat'})
    mock_module_btrfs = type('module', (object,), {'get_bin_path': lambda: '/bin/stat', 'run_command': lambda: (0, 'File system is btrfs', '')})
    mock_module_xfs = type('module', (object,), {'get_bin_path': lambda: '/bin/stat', 'run_command': lambda: (0, 'File system is xfs', '')})
    mock_module_no_stat = type('module', (object,), {'get_bin_path': lambda: None})

    assert is_chroot() is True
    assert is_chroot(mock_module) is False

# Generated at 2022-06-11 04:19:44.428613
# Unit test for function is_chroot
def test_is_chroot():
    import mock
    import stat
    import fcntl

    # chroot
    def mock_open(path):
        if path == '/':
            return mock.Mock(spec=file, fd=0, name=path)
        if path == '/proc/1/stat':
            return mock.Mock(spec=file, fd=1, name=path)
        if path == '/proc/1/root/.':
            return mock.Mock(spec=file, fd=2, name=path)

    def mock_st_ino(fd):
        if fd == 0:
            return 123
        if fd == 1:
            return 456
        if fd == 2:
            return 789

    def mock_st_dev(fd):
        if fd == 0:
            return 456
       

# Generated at 2022-06-11 04:19:45.478960
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-11 04:19:49.884587
# Unit test for function is_chroot
def test_is_chroot():
    import sys
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collectors.chroot import ChrootFactCollector

    chroot_collector = ChrootFactCollector()
    assert chroot_collector.collect()['is_chroot'] is not None



# Generated at 2022-06-11 04:19:56.001594
# Unit test for function is_chroot
def test_is_chroot():
    # checksum unit test
    is_chroot_res = is_chroot()
    assert is_chroot_res == False

# Generated at 2022-06-11 04:20:01.510633
# Unit test for function is_chroot
def test_is_chroot():
    import mock

    # If the root directory is not inode 2, is_chroot should return True.
    with mock.patch.object(os, 'stat', return_value=MockStat(2)):
        assert is_chroot() == False

    # If the root directory is inode 2, is_chroot should return False.
    with mock.patch.object(os, 'stat', return_value=MockStat(1)):
        assert is_chroot() == True



# Generated at 2022-06-11 04:20:04.256809
# Unit test for function is_chroot
def test_is_chroot():
    # Check if function is_chroot works correctly when a chroot is detected
    assert is_chroot()
    # Check if function is_chroot works correctly when a chroot is not detected
    assert not is_chroot()

# Generated at 2022-06-11 04:20:12.278317
# Unit test for function is_chroot
def test_is_chroot():
    import pwd

    # Test some True cases.
    for root_dir in ['/tmp', '/']:
        os.environ['debian_chroot'] = 'test_chroot'
        assert is_chroot() is True
        del os.environ['debian_chroot']

        os.chroot(root_dir)
        assert is_chroot() is True
        os.chroot(pwd.getpwuid(os.getuid()).pw_dir)

    # Test some False cases.
    assert is_chroot() is False

# Generated at 2022-06-11 04:20:13.408834
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot()

# Generated at 2022-06-11 04:20:14.448108
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is True

# Generated at 2022-06-11 04:20:15.445378
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-11 04:20:17.180621
# Unit test for function is_chroot
def test_is_chroot():
    # test success
    assert is_chroot() == False

    # test execption
    assert is_chroot() == False

# Generated at 2022-06-11 04:20:25.587288
# Unit test for function is_chroot
def test_is_chroot():

    class TestModule(object):
        """ A TestModule class - Minimal module object to use in unit tests """
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, filename):
            return self.bin_path

        def run_command(self, cmd):
            return (0, 'xfstype', '')

    # Unit test with module - successfully
    tm = TestModule('/bin')
    assert is_chroot(tm) is False

    # Unit test with module - successfully but no stat and return false
    tm = TestModule(None)
    assert is_chroot(tm) is False

    # Unit test without module - successfully
    assert is_chroot() is False

# Generated at 2022-06-11 04:20:26.529029
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-11 04:20:44.488067
# Unit test for function is_chroot
def test_is_chroot():
    import json

    # simulate the module behavior
    class module_wrapper(object):
        def __init__(self, result):
            self.result = result
        def run_command(self, cmd):
            return (0, json.dumps({'stat': self.result}), None)

    def chk(result, expected):
        m = module_wrapper(result)
        assert is_chroot(m) is expected

    chk({'ino': 1}, True)
    chk({'ino': 2, 'dev': 2}, True)
    chk({'ino': 2, 'dev': 1}, False)
    chk({'ino': 2, 'dev': 1, 'format': 'btrfs'}, True)
    chk({'ino': 256, 'dev': 1, 'format': 'btrfs'}, False)

# Generated at 2022-06-11 04:20:45.504809
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-11 04:20:46.372232
# Unit test for function is_chroot
def test_is_chroot():
    assert not is_chroot()

# Generated at 2022-06-11 04:20:48.064926
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == os.path.exists('/.chroot_is_ok')

# Generated at 2022-06-11 04:20:54.209913
# Unit test for function is_chroot
def test_is_chroot():

    # Normal case: we are not in a chroot
    assert is_chroot() == False

    # Chroot case: we are in a chroot
    m = mock.mock_module.AnsibleModule()
    m.run_command = mock.mock_module.run_command
    m.get_bin_path = mock.mock_module.get_bin_path
    m.run_command = mock.Mock(return_value=(0, 'linux', ''))
    assert is_chroot(m) == True

# Generated at 2022-06-11 04:20:57.723141
# Unit test for function is_chroot
def test_is_chroot():
    import tempfile
    import stat
    import shutil
    import os

    root = tempfile.mkdtemp()
    try:
        os.chroot(root)
        assert is_chroot()
    finally:
        os.chroot('/')
        shutil.rmtree(root)

# Generated at 2022-06-11 04:20:59.252333
# Unit test for function is_chroot
def test_is_chroot():
    chroot = is_chroot()
    assert chroot is None or isinstance(chroot, bool)

# Generated at 2022-06-11 04:21:00.066432
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-11 04:21:01.118667
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot()

# Generated at 2022-06-11 04:21:02.344192
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is True
    assert is_chroot(None) is True

# Generated at 2022-06-11 04:21:19.707457
# Unit test for function is_chroot
def test_is_chroot():

    assert is_chroot() is False

# Generated at 2022-06-11 04:21:20.874933
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

test_is_chroot()

# Generated at 2022-06-11 04:21:30.298800
# Unit test for function is_chroot
def test_is_chroot():
    import os
    import sys

    # Test when chroot
    os.environ['debian_chroot'] = '1'
    sys.modules['ansible.module_utils.facts.collector.chroot.os'] = os
    sys.modules['ansible.module_utils.facts.collector.chroot.os.stat'] = os
    sys.modules['ansible.module_utils.facts.collector.chroot.os.environ'] = os.environ
    collector = ChrootFactCollector()
    assert collector.collect()['is_chroot']

    # Test when not chroot
    del os.environ['debian_chroot']
    assert not collector.collect()['is_chroot']

# Generated at 2022-06-11 04:21:30.952495
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-11 04:21:32.580517
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False
    os.environ['debian_chroot'] = 'TEST'
    assert is_chroot() == True

# Generated at 2022-06-11 04:21:41.780703
# Unit test for function is_chroot
def test_is_chroot():
    # FIXME: This test is broken, should use a mocker
    # and not actually write to /tmp
    tmpdir_path = '/tmp/ansible_test_is_chroot'
    tmpdir_inode = 2

    class MockModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''

        def get_bin_path(self, dirname):
            if 'stat' == dirname:
                return '/bin/stat'
            return None

        def run_command(self, cmd, check_rc=True):
            rc = self.run_command_rc
            out = self.run_command_out
            err = self.run_command_err


# Generated at 2022-06-11 04:21:42.625824
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == None

# Generated at 2022-06-11 04:21:43.557489
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is True

# Generated at 2022-06-11 04:21:52.014084
# Unit test for function is_chroot
def test_is_chroot():
    modules_mock = {'run_command': lambda self, cmd: (0, '/btrfs', '')
                    if 'stat' in cmd else (0, '', '')}
    assert is_chroot(modules_mock)
    modules_mock = {'run_command': lambda self, cmd: (0, '/xfs', '')
                    if 'stat' in cmd else (0, '', '')}
    assert is_chroot(modules_mock)
    modules_mock = {'run_command': lambda self, cmd: (0, '/ext4', '')
                    if 'stat' in cmd else (0, '', '')}
    assert is_chroot(modules_mock)
    modules_mock = {'run_command': lambda self, cmd: (0, '', '')}
    assert is_ch

# Generated at 2022-06-11 04:21:54.351603
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False
    chroot_env = {'debian_chroot':'anything'}
    assert is_chroot(module=MockModule(environ=chroot_env)) is True


# Generated at 2022-06-11 04:22:32.619454
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-11 04:22:40.518283
# Unit test for function is_chroot
def test_is_chroot():

    # Unit test for function is_chroot
    try:
        # os.stat('/').st_dev throws an exception on Windows
        os.stat('/').st_dev
    except AttributeError:
        import pytest
        pytest.skip('Not available on Windows')

    from ansible.module_utils.facts.collector.chroot import is_chroot

    class FakeModule:
        def __init__(self):
            self.run_command_result = (0, '', '')
            self.run_command_calls = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_result

        def get_bin_path(self, path):
            paths = {'stat': '/usr/bin/stat'}
           

# Generated at 2022-06-11 04:22:41.851553
# Unit test for function is_chroot
def test_is_chroot():
    # Returns 'True' if run in chroot environment
    assert is_chroot()

# Generated at 2022-06-11 04:22:42.645871
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-11 04:22:44.426297
# Unit test for function is_chroot
def test_is_chroot():
    # Function cannot be tested in test_facts.py as it needs to be run in a chroot env
    assert is_chroot() is True

# Generated at 2022-06-11 04:22:52.211430
# Unit test for function is_chroot
def test_is_chroot():

    # Check for previous run
    if os.path.exists('/root/test_is_chroot'):
        os.remove('/root/test_is_chroot')
    assert is_chroot() is False

    assert os.system('chroot / /bin/touch /root/test_is_chroot') == 0
    assert is_chroot() is True

    # Check that it works in a chroot
    os.mkdir('/chroot')
    os.mkdir('/chroot/chroot')
    os.system('mount --bind / /chroot/chroot')
    assert os.system('chroot /chroot/chroot /bin/touch /root/test_is_chroot') == 0
    assert is_chroot() is True


# Generated at 2022-06-11 04:22:52.993798
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-11 04:22:59.979999
# Unit test for function is_chroot
def test_is_chroot():
    # Simulate chroot
    os.environ['debian_chroot'] = "foo"
    assert is_chroot() is True

    # Check with a real chroot
    del(os.environ['debian_chroot'])
    orig_root = os.stat('/')
    assert is_chroot() is False

    # Simulate chroot without proc
    os.chroot('/')
    assert is_chroot() is True
    os.chdir('/')

    # Check we are in the correct directory
    new_root = os.stat('/')
    assert orig_root.st_ino != new_root.st_ino
    assert orig_root.st_dev != new_root.st_dev

# Generated at 2022-06-11 04:23:07.315465
# Unit test for function is_chroot
def test_is_chroot():
    # Create a fake root
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible.module_utils.basic import AnsibleModule

    tmpdir = mkdtemp()
    os.makedirs(os.path.join(tmpdir, 'etc', 'ansible'))
    import ansible.constants
    ansible.constants.DEFAULT_LOCAL_TMP = tmpdir

    module = AnsibleModule({},
        chroot=tmpdir
    )

    # This is a function test, so we need to check the return of is_chroot
    assert is_chroot(module)

    # Remove the fake root
    rmtree(tmpdir)

# Generated at 2022-06-11 04:23:08.244061
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-11 04:24:43.391948
# Unit test for function is_chroot
def test_is_chroot():
    class Module(object):
        def __init__(self, chroot):
            self.env = {'debian_chroot': chroot}
            self.params = {'ansible_module_mock_stat': True}
            self.run_command_calls = []

        def run_command(self, cmd, use_unsafe_shell=False, check_rc=True, close_fds=True):
            self.run_command_calls.append(cmd)
            return 0, '', ''

        def get_bin_path(self, name):
            return '/bin/%s' % name

    module = Module(False)
    assert is_chroot(module) is True

    module = Module(True)
    assert is_chroot(module) is True

# Generated at 2022-06-11 04:24:44.282267
# Unit test for function is_chroot
def test_is_chroot():
    assert isinstance(is_chroot(), bool)

# Generated at 2022-06-11 04:24:50.616601
# Unit test for function is_chroot
def test_is_chroot():
    import ansible.module_utils.facts.system.chroot
    class FakeModule():
        def __init__(self):
            self.params = {}
        def get_bin_path(self, arg):
            return None
        def run_command(self, cmd, check_rc=False, close_fds=True, executable=None, data=None):
            if cmd == ['stat', '-f', '--format=%T', '/']:
                return(0, 'btrfs', '')
            else:
                return(0, 'xfs', '')

    assert ansible.module_utils.facts.system.chroot.is_chroot(FakeModule())

# Generated at 2022-06-11 04:24:54.379273
# Unit test for function is_chroot
def test_is_chroot():
    try:
        from ansible.module_utils.facts.collector import AnsibleModule
        os.makedirs('/rootfs/proc/1')
        m = AnsibleModule(argument_spec={})
        assert is_chroot(m) is True
    except ImportError:
        pass
    finally:
        os.removedirs('/rootfs/proc/1')

# Generated at 2022-06-11 04:24:55.094435
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot(module=None) is True

# Generated at 2022-06-11 04:24:57.245180
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False
    os.environ['debian_chroot'] = 'foo'
    assert is_chroot() == True
    os.environ.pop('debian_chroot')

# Generated at 2022-06-11 04:24:58.051032
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-11 04:24:59.504737
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False, "is_chroot should be False outside of chroot"

# Generated at 2022-06-11 04:25:02.287741
# Unit test for function is_chroot
def test_is_chroot():
    import tempfile

    tmpdir = tempfile.mkdtemp()
    assert is_chroot()
    os.chroot(tmpdir)
    try:
        assert is_chroot()
    finally:
        os.chroot('/')
        os.rmdir(tmpdir)

# Generated at 2022-06-11 04:25:03.150996
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False