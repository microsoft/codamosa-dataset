

# Generated at 2022-06-23 00:47:51.249204
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    fc = ChrootFactCollector()
    assert fc is not None


# Generated at 2022-06-23 00:47:54.566250
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    """Test case : Constructor of class ChrootFactCollector"""
    print("Test case : Constructor of class ChrootFactCollector")
    obj = ChrootFactCollector()
    assert obj.name == 'chroot'

# Generated at 2022-06-23 00:48:05.587036
# Unit test for function is_chroot
def test_is_chroot():
    import os
    import tempfile

    def touch(path):
        with open(path, 'a'):
            os.utime(path, None)

    with tempfile.TemporaryDirectory() as tempdir:
        module = None
        assert is_chroot(module) == False
        os.chdir(tempdir)
        touch('normal')
        os.mkdir('dir')
        os.chdir('dir')
        touch('child')
        os.chdir('..')
        os.chroot(tempdir)
        assert is_chroot(module) == True
        os.chdir('dir')
        touch('chrooted')
        os.chdir('..')
        os.chroot('.')
        assert is_chroot(module) == True

# Generated at 2022-06-23 00:48:08.878912
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert isinstance(ChrootFactCollector, object)
    assert ChrootFactCollector.name == 'chroot'
    assert ChrootFactCollector._fact_ids == {'is_chroot'}

# Generated at 2022-06-23 00:48:19.222593
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.chroot import ChrootFactCollector
    from ansible.module_utils.facts.collector.chroot import is_chroot
    from ansible.module_utils._text import to_bytes

    def _is_chroot():
        return True

    is_chroot_saved = is_chroot
    is_chroot = _is_chroot

# Generated at 2022-06-23 00:48:20.458706
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-23 00:48:24.098013
# Unit test for function is_chroot
def test_is_chroot():

    from ansible.module_utils.facts.collector import AnsibleModule
    module = AnsibleModule()

    if not is_chroot(module):
        module.fail_json(msg="Ooops, that's not good")


# Generated at 2022-06-23 00:48:26.419177
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    my_chroot = ChrootFactCollector()
    assert my_chroot.name == 'chroot'
    assert 'is_chroot' in my_chroot._fact_ids

# Generated at 2022-06-23 00:48:29.082467
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    x = ChrootFactCollector()
    assert x.name == "chroot"


# Generated at 2022-06-23 00:48:30.494156
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot(None) is False

# Generated at 2022-06-23 00:48:32.845457
# Unit test for function is_chroot
def test_is_chroot():
    # This doesn't work outside a chroot.
    # I think it may be because the run_command function is unavailable?
    pass

# Generated at 2022-06-23 00:48:35.522273
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot = ChrootFactCollector()
    assert chroot.name == 'chroot'
    assert chroot._fact_ids == set(['is_chroot'])

# Generated at 2022-06-23 00:48:38.848645
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    instance = ChrootFactCollector()

    expected_name = 'chroot'
    expected_fact_ids = set(['is_chroot'])

    assert instance.name == expected_name
    assert instance._fact_ids == expected_fact_ids

# Generated at 2022-06-23 00:48:43.599536
# Unit test for function is_chroot
def test_is_chroot():
    # 1) Test is_chroot() in a chroot environement
    os.environ['debian_chroot'] = "test"
    assert is_chroot()
    # 2) Test is_chroot() outside of a chroot environement
    os.environ.pop('debian_chroot')
    assert not is_chroot()


# Generated at 2022-06-23 00:48:53.024112
# Unit test for function is_chroot
def test_is_chroot():
    def stub_module_run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        if cmd[-1] == 'df':
            return (0, "Filesystem     1K-blocks      Used Available Use% Mounted on\n/dev/sda1      803709900 144359232 647580472  19% /", "")
        elif cmd[-1] == 'df':
            return (0, "Filesystem     1K-blocks      Used Available Use% Mounted on\n/dev/sda1      803709900 144359232 647580472  19% /", "")
        elif cmd[-1] == 'stat':
            return (0, "ext4", "")

    import ansible.module_

# Generated at 2022-06-23 00:48:59.089043
# Unit test for function is_chroot
def test_is_chroot():

    from ansible.module_utils.basic import AnsibleModule

    def assertEqual(a, b):
        if a != b:
            raise Exception("%s != %s" % (a, b))

    # without procfs/rootfs
    module = AnsibleModule(argument_spec={})
    assertEqual(is_chroot(module), False)

    # with procfs, but no rootfs
    module = AnsibleModule(argument_spec={})
    assertEqual(is_chroot(module), False)

    # with procfs, but no rootfs
    module = AnsibleModule(argument_spec={})
    assertEqual(is_chroot(module), False)

# Generated at 2022-06-23 00:49:01.001976
# Unit test for function is_chroot
def test_is_chroot():
    os.environ['debian_chroot'] = 'foo'
    assert is_chroot()

# Generated at 2022-06-23 00:49:13.251912
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    def fake_run_command(cmd, check_rc=None, environ=None):
        if 'xfs' in cmd:
            return 0, 'XFS', ''
        elif 'btrfs' in cmd:
            return 0, 'BtrFS', ''
        else:
            return 0, 'ext4', ''

    class FakeModule:
        def run_command(self, cmd, **kwargs):
            ret = fake_run_command(cmd, **kwargs)
            out = ret[1]
            err = ret[2]
            return ret[0], out, err

        def get_bin_path(self, command, opt_dirs=[]):
            return '/bin/' + command
    module = FakeModule()

    # assert is fs root
    assert ChrootFactCollector().collect(module=module)

# Generated at 2022-06-23 00:49:18.559165
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    fact_collector_class = ChrootFactCollector()

    # Testing collect method
    # success case: is_chroot = False
    expected_facts = dict(is_chroot=False)
    actual_facts = fact_collector_class.collect()
    assert actual_facts == expected_facts

    # Success case: is_chroot = True
    expected_facts = dict(is_chroot=True)
    actual_facts = fact_collector_class.collect()
    assert actual_facts == expected_facts

# Generated at 2022-06-23 00:49:22.841170
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    with patch('ansible.module_utils.facts.collector.BaseFactCollector') as BaseFactCollector_mock:
        ChrootFactCollector()
        BaseFactCollector_mock.assert_called_once_with(
            'chroot', {'is_chroot'})


# Generated at 2022-06-23 00:49:25.094854
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    obj = ChrootFactCollector()
    assert obj.name == 'chroot'
    assert obj._fact_ids == set(['is_chroot'])

# Generated at 2022-06-23 00:49:26.105608
# Unit test for function is_chroot
def test_is_chroot():
    assert(is_chroot() == False)

# Generated at 2022-06-23 00:49:31.864256
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # Initialise the class
    chroot_collector = ChrootFactCollector()
    # Check if the method collect returns a dictionary with the key is_chroot
    # Check if the method collect return False if Ansible is not in a chroot environment
    assert 'is_chroot' in chroot_collector.collect()
    assert chroot_collector.collect()['is_chroot'] == False

# Generated at 2022-06-23 00:49:32.690621
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    assert not is_chroot()

# Generated at 2022-06-23 00:49:37.265207
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():

    # Arrange
    is_chroot_expected = False
    module = MockModule()
    collected_facts = None

    test_subject = ChrootFactCollector()

    # Act
    actual = test_subject.collect(module, collected_facts)

    # Assert
    assert actual['is_chroot'] == is_chroot_expected


# Generated at 2022-06-23 00:49:39.564709
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fact_collector = ChrootFactCollector()
    assert chroot_fact_collector
    assert chroot_fact_collector.name == 'chroot'

# Generated at 2022-06-23 00:49:42.469430
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    c = ChrootFactCollector()
    assert c.name == 'chroot'
    assert 'is_chroot' in c._fact_ids

# Generated at 2022-06-23 00:49:46.385835
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    print('Testing constructor of class ChrootFactCollector')
    chrootFactCollector = ChrootFactCollector()
    assert chrootFactCollector.name == 'chroot'
    assert chrootFactCollector._fact_ids == set(['is_chroot'])


# Generated at 2022-06-23 00:49:57.604206
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    import sys
    import os
    import types

    class FakeModule:

        def __init__(self):
            self._base_path = '/bin:/usr/bin'

        def get_bin_path(self, arg):
            if arg == 'stat':
                return '/usr/bin/stat'

        def run_command(self, arg):
            path = arg[1]
            # emulate stat -s --format=%T /
            if os.path.exists(path):
                return (0, 'btrfs', '')
            else:
                raise OSError("Cannot stat '%s'" % path)

    class FakeModule2:

        def __init__(self):
            self._base_path = '/bin:/usr/bin'


# Generated at 2022-06-23 00:50:01.322486
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    return_values = {
        'is_chroot': True,
    }
    with mock.patch.object(ChrootFactCollector, 'collect') as mock_collect:
        mock_collect.return_value = return_values
        assert return_values == ChrootFactCollector.collect()

# Generated at 2022-06-23 00:50:03.128681
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    result = ChrootFactCollector().collect()
    assert isinstance(result['is_chroot'], bool)

# Generated at 2022-06-23 00:50:13.252981
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    """
    Test that method collect
    - returns properly formatted facts dictionary.
    """

    # Mock module
    mock_module = type('AnsibleModule')()
    mock_module.get_bin_path = lambda x: '/usr/bin/' + x

    # Mock stat command
    mock_command = type('Command')()
    mock_command.stdout = 'ext4'

    mock_module.run_command = lambda x: mock_command

    # Create fact collector
    fact_collector = ChrootFactCollector()

    facts = fact_collector.collect(mock_module)
    assert isinstance(facts, dict)
    assert facts.get('is_chroot') == False

# Generated at 2022-06-23 00:50:15.161275
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot_fact_collector = ChrootFactCollector()
    # TODO
    return chroot_fact_collector.collect()

# Generated at 2022-06-23 00:50:18.695753
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    class MockChrootFactCollector(ChrootFactCollector):
        def is_chroot(self, module=None):
            return False

    assert MockChrootFactCollector().collect() == {'is_chroot': False}

# Generated at 2022-06-23 00:50:21.204503
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    obj = ChrootFactCollector()
    assert obj.name == 'chroot'
    assert obj._fact_ids == {'is_chroot'}



# Generated at 2022-06-23 00:50:24.742905
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    #Given
    chroot_fact_collector = ChrootFactCollector()
    #When
    result = chroot_fact_collector.collect()
    #Then
    #is_chroot should be false
    assert result['is_chroot'] == False

# Generated at 2022-06-23 00:50:25.414675
# Unit test for function is_chroot
def test_is_chroot():
    assert not is_chroot()

# Generated at 2022-06-23 00:50:26.165232
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    assert is_chroot() == False

# Generated at 2022-06-23 00:50:30.368945
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False
    os.environ['debian_chroot'] = 'cow'
    assert is_chroot() == True
    os.environ['debian_chroot'] = ''
    assert is_chroot() == False

# Generated at 2022-06-23 00:50:31.992783
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    ChrootFactCollector()

# Generated at 2022-06-23 00:50:35.374997
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot_fact_collector = ChrootFactCollector()
    collected_facts = chroot_fact_collector.collect()
    assert collected_facts['is_chroot'] == is_chroot()

# Generated at 2022-06-23 00:50:38.311396
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot = ChrootFactCollector()
    assert chroot.name == 'chroot'
    assert chroot._fact_ids == set(['is_chroot'])

# Generated at 2022-06-23 00:50:40.959441
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    fc = ChrootFactCollector()
    facts = dict()
    assert fc.collect(collected_facts=facts) == {'is_chroot': False}

# Generated at 2022-06-23 00:50:51.316214
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    import sys
    import unittest
    import ansible.module_utils

    if sys.version_info[:2] == (2, 6):
        import mock
        mock_module = mock.Mock()
        mock_module.run_command.return_value = 0, "", ""
    else:
        from unittest.mock import MagicMock
        mock_module = MagicMock()

    collector = ChrootFactCollector()

    def test_is_chroot(self):

        # mock module's get_bin_path method
        if sys.version_info[:2] == (2, 6):
            mock_module.get_bin_path.return_value = '/usr/bin/stat'

# Generated at 2022-06-23 00:50:56.322956
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # arrange
    os.environ['debian_chroot'] = 'test'
    obj = ChrootFactCollector()
    expected_result = {'is_chroot': True}
    # act
    result = obj.collect()
    # assert
    assert result == expected_result

# Generated at 2022-06-23 00:50:59.136164
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot_fact_collector = ChrootFactCollector()
    assert chroot_fact_collector.collect() == {'is_chroot': False}

# Unit test method is_chroot

# Generated at 2022-06-23 00:51:02.833779
# Unit test for function is_chroot
def test_is_chroot():
    # in a chroot
    os.environ['debian_chroot'] = 'test'
    assert is_chroot() is True

    # in a non-chroot
    del os.environ['debian_chroot']
    assert is_chroot() is False

# Generated at 2022-06-23 00:51:11.336429
# Unit test for function is_chroot
def test_is_chroot():
    if not os.geteuid() == 0:
        import sys
        sys.stderr.write('Unit test is_chroot requires root privilleges')
        return None

    import tempfile
    import shutil
    from contextlib import contextmanager
    from os.path import ismount
    from ansible.module_utils.basic import AnsibleModule  # for get_bin_path

    @contextmanager
    def bind_mount_chroot():
        bind_mount_chroot.tempdir = tempfile.mkdtemp()
        try:
            os.chroot(bind_mount_chroot.tempdir)
            os.chdir('/')
            yield
        finally:
            os.chroot('/')
            shutil.rmtree(bind_mount_chroot.tempdir)


# Generated at 2022-06-23 00:51:12.355230
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot()

# Generated at 2022-06-23 00:51:19.583798
# Unit test for function is_chroot
def test_is_chroot():
    # test that false positive on busybox doesn't occur
    # issue: github.com/ansible/ansible/issues/16104
    # command: hostname
    # expected: (True, False, False)
    print ("is_chroot: %s" % ([is_chroot(module) for module in [None, False, True]]))

    # test that running under docker returns False
    # issue: github.com/ansible/ansible/issues/24516
    # command: (from fedora:latest) hostname
    # expected: False
    print ("is_chroot on Docker: %s" % is_chroot(module=False))


# Generated at 2022-06-23 00:51:21.638445
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    cf = ChrootFactCollector()
    assert type(cf.collect()) == dict



# Generated at 2022-06-23 00:51:27.569556
# Unit test for function is_chroot
def test_is_chroot():

    # in a chroot
    os.environ['debian_chroot'] = 'jail'
    result = is_chroot()
    assert result

    # check when no proc or stat
    del os.environ['debian_chroot']

    result = is_chroot()
    assert result

    os.environ['debian_chroot'] = 'jail'
    result = is_chroot()
    assert result

# Generated at 2022-06-23 00:51:29.854526
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    fc = ChrootFactCollector()
    assert fc.name == 'chroot'
    assert fc._fact_ids == set(['is_chroot'])


# Generated at 2022-06-23 00:51:39.830883
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    module = AnsibleModuleMock()
    facts_collector = ChrootFactCollector()

    # Mock that / is procfs
    module.run_command.return_value = 0, 'proc', ''
    facts_collector.is_procfs = True

    facts = facts_collector.collect()
    assert facts.get('is_chroot') is True
    assert module.run_command.call_count == 1

    # Mock that / is not procfs
    module.run_command.return_value = 0, 'not proc', ''
    facts_collector.is_procfs = False

    facts = facts_collector.collect()
    assert facts.get('is_chroot') is False
    assert module.run_command.call_count == 2


# Generated at 2022-06-23 00:51:44.950134
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot_fact_collector = ChrootFactCollector()
    chroot_facts = chroot_fact_collector.collect()
    assert len(chroot_facts) == 1
    assert 'is_chroot' in chroot_facts
    assert chroot_facts['is_chroot'] is None or isinstance(chroot_facts['is_chroot'], bool)

# Generated at 2022-06-23 00:51:55.750021
# Unit test for function is_chroot
def test_is_chroot():
    # we are testing for a 'chroot' environment

    # to test, we write a chroot file and use it
    # we used a tmp directory because /run/ is a tmpfs and our test
    # might not work that way.
    run_dir = '/run/ansible_test'
    if not os.path.isdir(run_dir):
        os.makedirs(run_dir)

    orig_chroot_file_path = '/etc/debian_chroot'
    chroot_test_file_path = os.path.join(run_dir, 'chroot_test_file')
    os.environ['debian_chroot'] = 'test'

    assert is_chroot() is True
    os.environ.pop('debian_chroot')
    assert is_chroot() is False


# Generated at 2022-06-23 00:51:56.556044
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-23 00:51:59.647560
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert isinstance(ChrootFactCollector.name, str)
    assert isinstance(ChrootFactCollector._fact_ids, set)
    assert isinstance(ChrootFactCollector.collect(), dict)



# Generated at 2022-06-23 00:52:05.459111
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chrootFactCollector = ChrootFactCollector()
    assert 'is_chroot' in chrootFactCollector._fact_ids
    assert chrootFactCollector._fact_ids == {'is_chroot'}
    assert chrootFactCollector.name == 'chroot'


# Generated at 2022-06-23 00:52:09.484566
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    collector = ChrootFactCollector()

    # check that the proper module is used
    facts = collector.collect(module=MagicMock())
    assert isinstance(facts, dict)



# Generated at 2022-06-23 00:52:14.157254
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    my_chroot = ChrootFactCollector()
    assert my_chroot.name == 'chroot'
    assert isinstance(my_chroot.name, str)
    assert isinstance(my_chroot._fact_ids, set)
    assert my_chroot._fact_ids == set('is_chroot')


# Generated at 2022-06-23 00:52:17.263761
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot_fact_collector = ChrootFactCollector()

    collected_facts = chroot_fact_collector.collect()

    assert collected_facts['is_chroot'] == is_chroot()

# Generated at 2022-06-23 00:52:23.224374
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.chroot import ChrootFactCollector

    ChrootFactCollector = ChrootFactCollector()
    assert isinstance(ChrootFactCollector, BaseFactCollector)
    assert ChrootFactCollector.name == 'chroot'
    assert ChrootFactCollector._fact_ids == {'is_chroot'}

# Generated at 2022-06-23 00:52:25.523564
# Unit test for function is_chroot
def test_is_chroot():
    try:
        os.chroot('/')
    except OSError:
        pass

    assert is_chroot() == False

# Generated at 2022-06-23 00:52:27.828749
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chrootFactCollector = ChrootFactCollector()
    assert chrootFactCollector.name == 'chroot'
    assert chrootFactCollector._fact_ids == {'is_chroot'}

# Generated at 2022-06-23 00:52:28.637368
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    pass

# Generated at 2022-06-23 00:52:30.102772
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-23 00:52:33.413317
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():

    chroot_collector = ChrootFactCollector()
    assert 'chroot' == chroot_collector.name

    assert 'is_chroot' in chroot_collector._fact_ids

# Generated at 2022-06-23 00:52:34.871276
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    r = ChrootFactCollector()
    assert r.name == 'chroot'



# Generated at 2022-06-23 00:52:37.704891
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot_fact_collector = ChrootFactCollector()
    facts = chroot_fact_collector.collect()

    assert facts['is_chroot'] in [True, False]

# Generated at 2022-06-23 00:52:48.996380
# Unit test for function is_chroot
def test_is_chroot():
    from ansible.module_utils.facts.collector import FactsCollector
    import os

    # This is the easy case that it is not a chroot
    facts = FactsCollector()
    facts.collect()
    is_chroot = facts.get_fact('is_chroot')
    assert is_chroot is False

    # Now to make a chroot
    # test_is_chroot
    test_env_var = '/tmp/chroot_ansible_test'
    try:
        os.mkdir(test_env_var)
        os.environ['debian_chroot'] = test_env_var
        facts = FactsCollector()
        facts.collect()
        is_chroot = facts.get_fact('is_chroot')
        assert is_chroot

    finally:
        del os.environ

# Generated at 2022-06-23 00:52:52.945531
# Unit test for function is_chroot
def test_is_chroot():
    is_chroot_test = is_chroot()
    assert isinstance(is_chroot_test, bool)

# Generated at 2022-06-23 00:52:54.122517
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot()

# Generated at 2022-06-23 00:52:58.536037
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    test_name = 'chroot'
    obj = ChrootFactCollector()
    assert obj.name == test_name, 'Test Failed: Constructor of ChrootFactCollector failed'



# Generated at 2022-06-23 00:53:07.563230
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # Make sure that we are getting the right collector name
    chroot_collector = ChrootFactCollector()
    assert chroot_collector.name == 'chroot'

    # Make sure that we are getting the right set of fact ids
    assert chroot_collector._fact_ids == set(['is_chroot'])

    # Make sure that the collect method returns proper facts using the module (chroot.py)
    from ansible.module_utils.facts.chroot import is_chroot
    import ansible.module_utils.facts.chroot as chroot_module
    from ansible.module_utils.facts.chroot import ChrootFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule:
        def __init__(self):
            self._bin_path

# Generated at 2022-06-23 00:53:10.728837
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    import sys
    module = sys.modules[__name__]
    collector = ChrootFactCollector()
    result = collector.collect(module)

    assert result['is_chroot'] == is_chroot(module)

# Generated at 2022-06-23 00:53:12.451897
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector.name == 'chroot'
    assert ChrootFactCollector._fact_ids == set(['is_chroot'])


# Generated at 2022-06-23 00:53:13.885974
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot = ChrootFactCollector()
    assert 'is_chroot' in chroot._fact_ids

# Generated at 2022-06-23 00:53:25.651743
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # Required as this will be called from other processes
    os.environ.pop('debian_chroot', None)

    collector = ChrootFactCollector()
    collected_facts = {}

    # Test on a system where inode #2 is not a root filesystem
    def mock_os_stat(path):
        if path == '/':
            return os.stat_result((16877, 5, 1, 0, 0, 0, 4096, 1509145554, 1509146272, 1509146272))
        else:
            return os.stat_result((16877, 5, 1, 0, 0, 0, 4096, 1509145554, 1509146272, 1509146272))
    old_os_stat = os.stat
    os.stat = mock_os_stat

    collector.collect(collected_facts)

# Generated at 2022-06-23 00:53:35.127192
# Unit test for function is_chroot
def test_is_chroot():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule as amod

    is_chroot_expected = is_chroot()
    (fd, fp) = tempfile.mkstemp(dir='/tmp')
    os.close(fd)

    m = amod(
        argument_spec={},
        supports_check_mode=False,
    )

    # testing with a normal path
    m.run_command = lambda x: (0, '', '')
    assert is_chroot_expected == is_chroot(m)

    # testing with a path that does not exist
    m.run_command = lambda x: (1, '', '')
    assert is_chroot_expected == is_chroot(m)

    # testing with device node
    m.run_command

# Generated at 2022-06-23 00:53:37.307365
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    """ Make sure ChrootFactCollector instance can be created """
    ChrootFactCollector()

# Generated at 2022-06-23 00:53:43.010266
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    collector = ChrootFactCollector()
    result = collector.collect()
    assert result == {'is_chroot': is_chroot()}

# Generated at 2022-06-23 00:53:47.322548
# Unit test for function is_chroot
def test_is_chroot():
    os.environ['debian_chroot'] = ''
    os.environ['debian_chroot'] = 'wheezy'
    assert is_chroot(None) == True
    os.environ['debian_chroot'] = 'False'
    assert is_chroot(None) == False

# Generated at 2022-06-23 00:53:48.729466
# Unit test for function is_chroot
def test_is_chroot():
    assert not is_chroot()
    assert is_chroot(m)

# Generated at 2022-06-23 00:53:50.142593
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    t = ChrootFactCollector(None)
    assert t.name == 'chroot'

# Generated at 2022-06-23 00:53:52.493770
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    c = ChrootFactCollector()
    assert c.name == 'chroot'
    assert c._fact_ids == set(['is_chroot'])

# Generated at 2022-06-23 00:53:53.428447
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    ChrootFactCollector()


# Generated at 2022-06-23 00:53:57.500418
# Unit test for function is_chroot
def test_is_chroot():
    # This is a little tricky to test without invoking a chroot itself.
    # Therefore, we'll just mock the current environment
    os.environ['debian_chroot'] = 'jail'
    assert is_chroot() == True

    os.environ['debian_chroot'] = ''
    assert is_chroot() == False

# Generated at 2022-06-23 00:54:02.237126
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    fact_collector = ChrootFactCollector()
    assert fact_collector.name == 'chroot'
    assert fact_collector._fact_ids == {'is_chroot'}


# Generated at 2022-06-23 00:54:05.769462
# Unit test for function is_chroot
def test_is_chroot():
    try:
        my_root = os.stat('/')
        proc_root = os.stat('/proc/1/root/.')
        assert my_root.st_ino != proc_root.st_ino or my_root.st_dev != proc_root.st_dev
    except Exception:
        assert True

# Generated at 2022-06-23 00:54:06.979004
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    ChrootFactCollector()

# Generated at 2022-06-23 00:54:14.000307
# Unit test for function is_chroot
def test_is_chroot():

    module = Mock(
        get_bin_path=Mock(return_value=None)
    )

    assert is_chroot() == True
    assert is_chroot(module) == True

    module.run_command.return_value = (0, 'xfs', '')
    assert is_chroot(module) == False

    module.run_command.return_value = (0, 'btrfs', '')
    assert is_chroot(module) == False

# Generated at 2022-06-23 00:54:24.211257
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    class MockModule(object):
        def __init__(self):
            self.run_command_return_value = (0, '', '')
            self.run_command_count = 0
        def run_command(self, cmd):
            self.run_command_count += 1
            return self.run_command_return_value

    mock_module = MockModule()
    fact_collector = ChrootFactCollector()

    expected_result = {'is_chroot': False}
    assert expected_result == fact_collector.collect(module=mock_module)
    assert mock_module.run_command_count == 0

    # In chroot
    os.environ['debian_chroot'] = "test"
    expected_result = {'is_chroot': True}
    assert expected_result == fact_collect

# Generated at 2022-06-23 00:54:28.460381
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot_fact = ChrootFactCollector()
    result = chroot_fact.collect()
    assert result != None
    assert result['is_chroot'] != None
    assert isinstance(result['is_chroot'], bool)

# Generated at 2022-06-23 00:54:37.040299
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.chroot import ChrootFactCollector
    from ansible.module_utils.facts.system import SystemFactCollector
    from ansible.module_utils.facts.virtual import VirtualFactCollector
    from ansible.module_utils.facts.network import NetworkFactCollector
    from ansible.module_utils.facts.distribution import DistributionFactCollector

    # Facts

    facts = Facts({})
    facts.add_collector(SystemFactCollector())
    facts.add_collector(VirtualFactCollector())
    facts.add_collector(NetworkFactCollector())
    facts.add_collector(ChrootFactCollector())
    facts.add_collector

# Generated at 2022-06-23 00:54:38.534633
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot = ChrootFactCollector()
    assert chroot.name == 'chroot'

# Generated at 2022-06-23 00:54:42.085684
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    f = ChrootFactCollector()

    def _is_chroot():
        return True

    f._is_chroot = _is_chroot
    assert f.collect() == {'is_chroot': True}


# Generated at 2022-06-23 00:54:42.934204
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    ChrootFactCollector()

# Generated at 2022-06-23 00:54:43.960957
# Unit test for function is_chroot
def test_is_chroot():

    assert(is_chroot() == False)

# Generated at 2022-06-23 00:54:46.598949
# Unit test for function is_chroot
def test_is_chroot():
    # Expected behaviour is that this test runs in a chrooted environment if
    # we are in the integration testing environment. This behaviour may be
    # wrong for testing environments that do not use chroot.
    assert is_chroot() == (os.environ.get('TEST_SIDECAR_CHROOT', False))

# Generated at 2022-06-23 00:54:47.953419
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert not is_chroot()
    assert 'is_chroot' in ChrootFactCollector().collect()

# Generated at 2022-06-23 00:54:49.793908
# Unit test for function is_chroot
def test_is_chroot():

    # we assume that when running the unit test, we are not in a chroot
    assert is_chroot() == False

# Generated at 2022-06-23 00:54:53.420595
# Unit test for function is_chroot
def test_is_chroot():

    # TODO: Create a better testing method.
    assert is_chroot() is False or is_chroot() is True

# Generated at 2022-06-23 00:54:54.546169
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-23 00:54:55.874020
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot()

# Generated at 2022-06-23 00:55:00.123759
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    """
    Test that the collect method retrieves the correct facts.
    """
    chroot_fact_collector = ChrootFactCollector()
    assert chroot_fact_collector.collect() == {'is_chroot': True}

# Generated at 2022-06-23 00:55:04.700350
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    collected_facts = dict()
    chrootFactCollector = ChrootFactCollector()
    chrootFactCollector.collect(collected_facts=collected_facts)
    assert 'is_chroot' in collected_facts
    assert collected_facts['is_chroot'] == is_chroot()
    assert chrootFactCollector.name in collected_facts

# Generated at 2022-06-23 00:55:09.928760
# Unit test for function is_chroot
def test_is_chroot():
    import ansible.module_utils.facts.collector
    ansible.module_utils.facts.collector.is_chroot = is_chroot

    import ansible.module_utils.facts.system.chroot
    assert ansible.module_utils.facts.system.chroot.ChrootFactCollector().collect(module=None, collected_facts=None) == {'is_chroot': False}

    del ansible.module_utils.facts.collector.is_chroot

# Generated at 2022-06-23 00:55:13.921176
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fact_collector = ChrootFactCollector()
    assert chroot_fact_collector.name == 'chroot'
    assert chroot_fact_collector._fact_ids == ('is_chroot',)



# Generated at 2022-06-23 00:55:21.510324
# Unit test for function is_chroot
def test_is_chroot():
    def mocked_os_stat(path):
        if path == '/proc/1/root/.':
            raise IOError('Not a directory')
        else:
            return os.stat(path)

    saved_os_stat = os.stat

    # test os.stat error
    os.stat = mocked_os_stat
    assert is_chroot() is True
    os.stat = saved_os_stat

    # test inode is not 2
    assert is_chroot() is True

    # test inode is 2
    def mocked_os_stat_2(path):
        if path == '/':
            return os.stat_result((0, 2, 0, 0, 0, 0, 0, 0, 0, 0))
        else:
            return os.stat(path)

    os.stat = mocked_os_stat_

# Generated at 2022-06-23 00:55:24.540714
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    """
    Unit test for constructor of class ChrootFactCollector
    """
    assert ChrootFactCollector().name == 'chroot'
    assert ChrootFactCollector()._fact_ids == set(['is_chroot'])



# Generated at 2022-06-23 00:55:25.572661
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == True

# Generated at 2022-06-23 00:55:35.448895
# Unit test for function is_chroot
def test_is_chroot():
    import sys, os
    # This hack is needed to import module in a test function
    # DO NOT USE IN REAL CODE
    sys.modules['ansible'] = type('DummyAnsibleModule', (object,), {'get_bin_path': lambda self, path: None})

    assert(is_chroot() == False)

    class DummyAnsibleModule(object):
        def __init__(self, *args, **kwargs):
            self._ansible_module = object()

        def get_bin_path(self, path):
            return None

        def run_command(self, cmd):
           # btrfs
           if cmd[3] == '/':
               return (0, 'Filesystem features: subvolid, extref, skinny-metadata', '')
           # xfs

# Generated at 2022-06-23 00:55:38.232757
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_collector = ChrootFactCollector()
    assert chroot_collector.name == 'chroot'
    assert chroot_collector._fact_ids == set(['is_chroot'])

# Generated at 2022-06-23 00:55:39.942581
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot = ChrootFactCollector()
    assert chroot.name == 'chroot'

# Generated at 2022-06-23 00:55:41.170281
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is None

# Generated at 2022-06-23 00:55:53.470136
# Unit test for function is_chroot
def test_is_chroot():
    import os
    import subprocess
    import tempfile

    # get current working directory
    cwd = os.getcwd()
    fd, tmpdir = tempfile.mkstemp()
    in_chroot = None

# Generated at 2022-06-23 00:55:56.120043
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    collector = ChrootFactCollector()
    assert collector.name == 'chroot'
    assert collector._fact_ids == set(['is_chroot'])


# Generated at 2022-06-23 00:55:58.432365
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    x = ChrootFactCollector()
    assert x.name == 'chroot'
    assert x._fact_ids == {'is_chroot'}



# Generated at 2022-06-23 00:56:06.198225
# Unit test for function is_chroot
def test_is_chroot():
    try:
        import ansible.modules.system.chroot
        import ansible.module_utils.facts.chroot
        import ansible.module_utils.facts.collector
        import ansible.module_utils.facts as facts_mod
    except Exception:
        return False
    ansible.module_utils.facts.collector.register(ChrootFactCollector)
    ansible.module_utils.facts.collectors = [ChrootFactCollector]
    my_facts = facts_mod.get_facts(dict())
    return my_facts['is_chroot']

# Generated at 2022-06-23 00:56:16.768456
# Unit test for function is_chroot
def test_is_chroot():
    import tempfile
    import filecmp
    import subprocess
    import Image
    import shutil
    import stat

    # Test setup:
    # Create a temporary directory and add a file_1 and a dir_1
    # Create a second temporary directory and add a file_2 and a dir_2
    # Create a third temporary directory and add a file_3 and a dir_3
    # Populate a 4th temporary directory with a chroot environment
    #
    # Test teardown:
    # Remove the 4 temporary directories
    tmpdir_1 = tempfile.mkdtemp()
    tmpdir_2 = tempfile.mkdtemp()
    tmpdir_3 = tempfile.mkdtemp()
    tmpdir_chroot = tempfile.mkdtemp()
    assert os.path.isdir(tmpdir_1)
    assert os

# Generated at 2022-06-23 00:56:20.844286
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    ChrootFactCollector = ChrootFactCollector()
    facts = ChrootFactCollector.collect()
    assert facts["is_chroot"]

# Generated at 2022-06-23 00:56:26.577771
# Unit test for function is_chroot
def test_is_chroot():
    import sys
    import tempfile

    # Import katipo.py from ../utils/katipo.py
    sys.path.insert(1, os.path.join(os.path.dirname(__file__), '..'))

    import katipo
    import chroot_fact_collector

    with tempfile.TemporaryDirectory() as td:
        os.mkdir(os.path.join(td, 'proc'))
        os.mkdir(os.path.join(td, 'dummy'))
        os.mkdir(os.path.join(td, 'dummy/proc'))
        os.mkdir(os.path.join(td, 'dummy/proc/1'))

# Generated at 2022-06-23 00:56:37.535246
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    collected_facts = {}
    class MockModule(object):
        def __init__(self):
            self.bin_paths = {}
            self.run_command_results = []
            self.run_command_exceptions = []
            self.run_command_exceptions.append(Exception)

        def get_bin_path(self, name):
            return self.bin_paths.get(name, None)

        def run_command(self, args):
            if self.run_command_exceptions:
                e = self.run_command_exceptions.pop()
                if e is not None:
                    raise e
            return self.run_command_results.pop()

    c = ChrootFactCollector()

    # test where the is_chroot function throws a exception on an os.stat call

# Generated at 2022-06-23 00:56:39.979633
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
   assert ChrootFactCollector.name is 'chroot'
   assert ChrootFactCollector._fact_ids == {'is_chroot'}
   return True

# Generated at 2022-06-23 00:56:43.713742
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    obj = ChrootFactCollector()
    assert obj.name == 'chroot'
    assert obj._fact_ids == set(['is_chroot'])


# Generated at 2022-06-23 00:56:44.844932
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    obj = ChrootFactCollector()
    assert(obj.name == 'chroot')

# Generated at 2022-06-23 00:56:47.955533
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    collector = ChrootFactCollector()
    collected_facts = {}

    collected_facts['is_chroot'] = is_chroot()

    assert collector.collect(collected_facts=collected_facts) == collected_facts

# Generated at 2022-06-23 00:56:48.968945
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() != True

# Generated at 2022-06-23 00:56:51.839457
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    test_collector = ChrootFactCollector()
    test_dict = test_collector.collect()
    assert 'is_chroot' in test_dict
    assert test_dict['is_chroot'] is not None

# Generated at 2022-06-23 00:56:53.923233
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-23 00:57:04.311734
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():

    # Test whether is_chroot is correct on a not chrooted system
    _ChrootFactCollector = ChrootFactCollector()
    # Test that is_chroot is correct on a not chrooted system
    assert _ChrootFactCollector.collect()['is_chroot'] == False
    del _ChrootFactCollector

# Test whether is_chroot is correct on a chrooted system
# class TestChrootFactCollectorCollection(object):

#     def test_ChrootFactCollector_is_chroot(self, monkeypatch):
#         monkeypatch.setattr(os, 'stat', Mock(return_value=Mock(st_ino=1)))
#         assert ChrootFactCollector().collect()['is_chroot'] == True

# Generated at 2022-06-23 00:57:10.144172
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # We can't load the real collector, because the module is likely
    # to be running in a chroot.

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = True

        def get_bin_path(self, path):
            return path

    fake_facts = ChrootFactCollector.collect_from(FakeModule())
    assert fake_facts['is_chroot'] is not None

# Generated at 2022-06-23 00:57:11.793238
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    result = ChrootFactCollector()
    assert isinstance(result, ChrootFactCollector)
    assert result.name == 'chroot'

# Test is_chroot()

# Generated at 2022-06-23 00:57:14.532390
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    h = ChrootFactCollector()
    assert(h.collect().get('is_chroot') is None)

# Generated at 2022-06-23 00:57:16.880395
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    obj = ChrootFactCollector()
    assert obj.name == 'chroot'
    assert obj._fact_ids == {'is_chroot'}

# Generated at 2022-06-23 00:57:20.811315
# Unit test for function is_chroot
def test_is_chroot():

    class MockModule(object):
        def get_bin_path(self, _):
            return False
        def run_command(self, _):
            return 0, '', ''

    is_chroot(MockModule())

# Generated at 2022-06-23 00:57:27.796083
# Unit test for function is_chroot
def test_is_chroot():
    def mock_stat(path):
        if path == '/':
            return {'st_ino': 1, 'st_dev': 4}
        if path == '/proc/1/root/.':
            return {'st_ino': 1, 'st_dev': 2}
        raise Exception("Unexpected path")

    mock_module = Mock()
    mock_module.get_bin_path = Mock(return_value="stat")

    mock_run_command = Mock(return_value=(0, "xfs", ""))
    mock_module.run_command = mock_run_command

    os.stat = mock_stat

    assert is_chroot(mock_module) is True

    mock_stat.return_value = {'st_ino': 2, 'st_dev': 4}
    mock_run_command.return_value

# Generated at 2022-06-23 00:57:28.915701
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    ChrootFactCollector()

# Generated at 2022-06-23 00:57:36.576664
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    '''
    Unit test for collect
    '''
    from ansible.module_utils.facts.collector import ansible_collector

    _fact_list = ansible_collector.get_facts()

    for key in ("is_chroot",):
        assert key in _fact_list, "Failed to find expected key %s" % key

    # is_chroot should be a bool
    _is_chroot = _fact_list['is_chroot']
    assert isinstance(_is_chroot, type(True)), \
        'Failed to assert that is_chroot fact is a boolean'

# Generated at 2022-06-23 00:57:38.914735
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    x = ChrootFactCollector()
    assert x.name == 'chroot'
    assert x._fact_ids == set(['is_chroot'])

# Generated at 2022-06-23 00:57:40.580090
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    assert ChrootFactCollector().collect() == {'is_chroot': False}

# Generated at 2022-06-23 00:57:41.773958
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-23 00:57:42.894638
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-23 00:57:44.619928
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fact_collector = ChrootFactCollector()
    assert chroot_fact_collector

# Generated at 2022-06-23 00:57:47.689059
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot = ChrootFactCollector()
    assert chroot.name == "chroot"
    assert chroot._fact_ids == {"is_chroot"}


# Generated at 2022-06-23 00:57:49.152585
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is True

# Generated at 2022-06-23 00:57:49.841269
# Unit test for function is_chroot
def test_is_chroot():
    is_chroot()