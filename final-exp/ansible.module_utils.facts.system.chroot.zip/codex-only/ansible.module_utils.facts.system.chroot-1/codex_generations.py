

# Generated at 2022-06-23 00:47:49.732566
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    ChrootFactCollector().collect(None, None)

# Generated at 2022-06-23 00:47:52.968629
# Unit test for function is_chroot
def test_is_chroot():

    try:
        assert is_chroot()
    except AssertionError:
        pass
    else:
        raise AssertionError('is_chroot test failed')


# Generated at 2022-06-23 00:48:04.581743
# Unit test for function is_chroot
def test_is_chroot():
    import ansible.module_utils.facts.system.chroot

    # Here we check function return 'None' when module is None
    assert ansible.module_utils.facts.system.chroot.is_chroot() is None

    # Here we check function return 'True' when debian_chroot variable is set
    os.environ['debian_chroot'] = 'string'
    assert ansible.module_utils.facts.system.chroot.is_chroot() is True
    del os.environ['debian_chroot']

    # Here we check function return 'True' when '/' and '/proc/1/root/.' are on
    # different devices
    os.stat = lambda path: os.stat('/')
    os.stat.return_value.st_dev = 1

# Generated at 2022-06-23 00:48:12.098664
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    my_module = MockModule()
    my_module.run_command = Mock(return_value=(0, '', ''))

    with open('/etc/debian_chroot', 'w') as f:
        f.write('foo')
    cf = ChrootFactCollector()
    is_chroot = cf.collect(my_module)['is_chroot']
    assert is_chroot is True

    os.remove('/etc/debian_chroot')
    cf = ChrootFactCollector()
    is_chroot = cf.collect(my_module)['is_chroot']
    assert is_chroot is False



# Generated at 2022-06-23 00:48:15.419634
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    collector = ChrootFactCollector()
    facts = collector.collect()
    assert 'is_chroot' in facts


# Generated at 2022-06-23 00:48:24.628892
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    mock_module = MagicMock()
    mock_module.params = {}
    # Test with a '/proc/pid/root no'
    mock_module.run_command.side_effect = [
        (0, '', ''),
        (0, 'btrfs\n', ''),
        (0, 'xfs\n', ''),
        (0, 'ext4\n', ''),
    ]
    mock_module.get_bin_path.side_effect = [
        'stat'
    ]
    mock_stat = MagicMock()
    mock_stat.st_ino = 1
    mock_stat.st_dev = 2
    os.stat = MagicMock(return_value=mock_stat)
    os.environ = {'debian_chroot': False}
    chroot_fact = Ch

# Generated at 2022-06-23 00:48:26.253796
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_collector = ChrootFactCollector()
    assert chroot_collector.name == 'chroot'

# Generated at 2022-06-23 00:48:29.599544
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    fact = ChrootFactCollector()
    assert fact.name == 'chroot'
    assert fact._fact_ids == set(['is_chroot'])

# Generated at 2022-06-23 00:48:34.099123
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # is_chroot should be False since python unit test will be running on the host/container itself
    # is_chroot would be true if the unit test ran inside docker with docker python client enabled
    # Need to run with command "nose --exe" to run python script as executable
    assert is_chroot() is False

# Generated at 2022-06-23 00:48:35.574571
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    inst = ChrootFactCollector()
    assert inst.name == 'chroot'

# Generated at 2022-06-23 00:48:43.912940
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    class MockModule(object):
        def __init__(self):
            self.run_command = self._run_command

        def _run_command(self, params=None):
            # command called by method collect of ChrootFactCollector
            stat_path = self.get_bin_path('stat')
            cmd = [stat_path, '-f', '--format=%T', '/']
            if params == cmd:
                return 0, 'btrfs', ''
            # command called by method is_chroot of module_utils/facts/system/distribution.py
            stat_path = self.get_bin_path('stat')
            cmd = [stat_path, '-f', '--format=%T', '/']
            if params == cmd:
                return 0, 'btrfs', ''
            return 124, None

# Generated at 2022-06-23 00:48:45.828940
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():

    # If no module passed, make sure that is_chroot will still return a value
    assert is_chroot() == is_chroot(None)

# Generated at 2022-06-23 00:48:47.629106
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    cf = ChrootFactCollector()
    assert cf is not None
    assert cf.name == 'chroot'

# Generated at 2022-06-23 00:48:55.447776
# Unit test for function is_chroot
def test_is_chroot():

    import ansible.module_utils.facts.system.chroot as chroot

    def test_procmounts(read):
        def real_read(fname):
            return read(fname)
        chroot.read_file = real_read
        file = open('/proc/mounts', 'rb')
        read.txt = file.read()
        file.close()
        chroot.is_chroot()

    # The following tests use MNT namespace to test chroot detection.  To
    # run the tests, you need to have the necessary privileges to create a
    # MNT namespace. In case you don't have the privileges, the tests will
    # simply pass.

    import tempfile
    import os
    import ansible.module_utils.basic
    import ansible.module_utils.facts.system.linux


# Generated at 2022-06-23 00:48:56.201870
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-23 00:49:03.148008
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # TODO: Do we need an instance of BaseFactCollector to test a method of ChrootFactCollector class?
    instance_of_basefactcollector_class = BaseFactCollector()
    instance_of_chrootfactcollector_class = ChrootFactCollector()
    collected_facts = instance_of_basefactcollector_class.collect(None)
    collected_facts = instance_of_chrootfactcollector_class.collect(None, collected_facts)
    assert collected_facts['is_chroot'] == is_chroot()

# Generated at 2022-06-23 00:49:11.503166
# Unit test for function is_chroot
def test_is_chroot():
    module = None
    if os.environ.get('debian_chroot', False):
        assert is_chroot(module)
        return

    class MockModule:
        def get_bin_path(self, command):
            if command == 'stat':
                return True

        def run_command(self, cmd):
            assert cmd == [True, '-f', '--format=%T', '/']
            return True, "", ""

    # btrfs root
    module = MockModule()
    rc, out, err = module.run_command([True, '-f', '--format=%T', '/'])
    out = 'btrfs'
    assert is_chroot(module)

    # xfs root
    module = MockModule()

# Generated at 2022-06-23 00:49:14.709743
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    test_class = ChrootFactCollector()
    result = test_class.collect()
    assert result['is_chroot'] == is_chroot()

# Generated at 2022-06-23 00:49:18.638200
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    fc = ChrootFactCollector()
    is_chroot = fc.collect(collected_facts=None)
    assert(is_chroot['is_chroot'] == is_chroot())


# Generated at 2022-06-23 00:49:19.692585
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
  assert ChrootFactCollector.name == 'chroot'

# Generated at 2022-06-23 00:49:23.502679
# Unit test for function is_chroot
def test_is_chroot():
    class TestModule:
        def get_bin_path(self, path):
            return None

        def run_command(self, cmd):
            return 0, None, None

    test_module = TestModule()

    assert is_chroot(test_module) == False

# Generated at 2022-06-23 00:49:26.166096
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    fact_collector = ChrootFactCollector()
    # Test if is_chroot fact is defined
    assert 'is_chroot' in fact_collector._fact_ids

# Generated at 2022-06-23 00:49:27.168816
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector.name == 'chroot'

# Generated at 2022-06-23 00:49:28.893204
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    x = ChrootFactCollector()
    assert x.name == 'chroot'


# Generated at 2022-06-23 00:49:29.837819
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-23 00:49:30.839910
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot()

# Generated at 2022-06-23 00:49:34.350597
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fact_collector = ChrootFactCollector()
    assert 'chroot' == chroot_fact_collector.name
    assert 'is_chroot' in chroot_fact_collector._fact_ids

if __name__ == "__main__":
    test_ChrootFactCollector()

# Generated at 2022-06-23 00:49:37.104839
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    module = None
    collector = ChrootFactCollector()
    new_facts = collector.collect(module=module)

    assert new_facts['is_chroot'] == is_chroot(module)

# Generated at 2022-06-23 00:49:46.482805
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import collector

    class CollectedFacts(dict):
        pass

    collector_obj = ChrootFactCollector()
    collected_facts = CollectedFacts()

    # Test case 1: is_chroot == True
    environ_dict = {'debian_chroot': True}
    with patch.dict(os.environ, environ_dict):
        expected_result = {'is_chroot': True}
        test_result = collector_obj.collect(collected_facts=collected_facts)
        assert(expected_result == test_result)

    # Test case 2: is_chroot == False

# Generated at 2022-06-23 00:49:57.700650
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    """This tests whether is_chroot fact is true if system is chrooted"""
    if os.path.exists('/etc/community-facts.d/facts.d/is_chroot.yml') and os.path.isfile('/etc/community-facts.d/facts.d/is_chroot.yml'):
        os.remove('/etc/community-facts.d/facts.d/is_chroot.yml')

    #creating a test module
    class TestModule:
        def __init__(self):
            self.params = {}
            self.exit_json = False
            self.run_command_result = 0
            self.run_command_rc = ""
            self.run_command_stdout = ""
            self.run_command_stderr = ""

# Generated at 2022-06-23 00:50:00.200440
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector().name == 'chroot'
    assert ChrootFactCollector()._fact_ids == {'is_chroot'}


# Generated at 2022-06-23 00:50:02.119726
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    instance = ChrootFactCollector()
    assert instance.name == 'chroot'
    assert instance._fact_ids == set(['is_chroot'])

# Generated at 2022-06-23 00:50:05.669095
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    instance = ChrootFactCollector()
    assert instance.name == 'chroot'

# Generated at 2022-06-23 00:50:07.282818
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    #This test is to test the collect method of class ChrootFactCollector
    pass

# Generated at 2022-06-23 00:50:08.732496
# Unit test for function is_chroot
def test_is_chroot():
    # This does not work in a chroot environment
    assert is_chroot() == False

# Generated at 2022-06-23 00:50:09.690016
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is None

# Generated at 2022-06-23 00:50:11.408648
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot = ChrootFactCollector()
    assert chroot.collect()['is_chroot'] == False

# Generated at 2022-06-23 00:50:14.440762
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector.name == 'chroot'
    assert ChrootFactCollector._fact_ids == {'is_chroot'}

# Generated at 2022-06-23 00:50:21.440307
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    """
    Test ChrootFactCollector.collect() when the system is not
    inside a chroot environment.
    """

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import timeout

    try:
        Collector._collectors = [
            ChrootFactCollector
        ]

        timeout.timeout = 0
        facts_module = Collector()

        facts = facts_module.collect(None, None)

        assert facts['is_chroot'] == False

    finally:
        timeout.timeout = 30

# Generated at 2022-06-23 00:50:22.263248
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot()

# Generated at 2022-06-23 00:50:24.697240
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    t = ChrootFactCollector()
    assert t.name == 'chroot'
    assert t._fact_ids == set(['is_chroot'])



# Generated at 2022-06-23 00:50:27.309692
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    col = ChrootFactCollector()
    assert col.name == 'chroot'
    assert col._fact_ids == set(['is_chroot'])

# Unit tests for collect method of class ChrootFactCollector

# Generated at 2022-06-23 00:50:29.542088
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    my_dict = {}
    ChrootFactCollector().collect(None, my_dict)
    assert my_dict == {'is_chroot': None}

# Generated at 2022-06-23 00:50:40.510546
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():

    # create a temporary module to use for testing
    # module mock taken from: https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/common.py
    class AnsibleModule:

        def __init__(self, argument_spec, bypass_checks=False, check_invalid_arguments=True, mutually_exclusive=None,
                     required_together=None, required_one_of=None, add_file_common_args=False):
            pass

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            if arg == 'stat':
                return '/usr/bin/stat'

        def run_command(self, arg):
            return None, None, None

    test_module = AnsibleModule(argument_spec={})

# Generated at 2022-06-23 00:50:43.857065
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fact_collector = ChrootFactCollector()
    assert chroot_fact_collector.name == 'chroot'
    assert chroot_fact_collector._fact_ids == {'is_chroot'}



# Generated at 2022-06-23 00:50:44.992639
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-23 00:50:45.972137
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    ChrootFactCollector()



# Generated at 2022-06-23 00:50:48.701625
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    test_obj = ChrootFactCollector()
    test_result = test_obj.collect()
    assert 'is_chroot' in test_result
    assert isinstance(test_result['is_chroot'], bool)

# Generated at 2022-06-23 00:50:49.567684
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-23 00:50:51.946024
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot = ChrootFactCollector()
    facts = chroot.collect()
    assert 'is_chroot' in facts
    assert facts['is_chroot'] == is_chroot()

# Generated at 2022-06-23 00:50:56.031635
# Unit test for function is_chroot
def test_is_chroot():
    # test if not chrooted
    os.environ['debian_chroot'] = ''
    assert not is_chroot()
    del os.environ['debian_chroot']
    assert not is_chroot()

# Generated at 2022-06-23 00:50:58.487108
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    fc = ChrootFactCollector()
    assert fc.name == 'chroot'
    assert fc._fact_ids == set(['is_chroot'])

# Generated at 2022-06-23 00:51:04.725537
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    '''
    [Unit: ChrootFactCollector] - test collect()
    '''
    from ansible.utils.display import Display

    display = Display()
    chroot_collector = ChrootFactCollector(display)
    #
    # check how to collect facts when is not chroot
    #
    chroot_collector.collect()
    assert chroot_collector.get_fact_ids() == chroot_collector._fact_ids

# Generated at 2022-06-23 00:51:06.094399
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False, 'is_chroot() does not return False in Docker container'

# Generated at 2022-06-23 00:51:09.562756
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    fact_collector = ChrootFactCollector()
    ret = fact_collector.collect()
    assert 'is_chroot' in ret

# Generated at 2022-06-23 00:51:11.370331
# Unit test for function is_chroot
def test_is_chroot():
    from ansible.module_utils.basic import AnsibleModule
    assert not is_chroot(AnsibleModule({}))

# Generated at 2022-06-23 00:51:18.940572
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # is_chroot returns None if not in chroot. If a module is present, it is used to figure out if the root fs is chroot.
    # Otherwise it is assumed that there is no module and False is returned.
    assert ChrootFactCollector().collect() == {'is_chroot': False}
    assert ChrootFactCollector().collect(module=None) == {'is_chroot': False}
    assert ChrootFactCollector().collect(collected_facts=None) == {'is_chroot': False}
    assert ChrootFactCollector().collect(module=None, collected_facts=None) == {'is_chroot': False}

# Generated at 2022-06-23 00:51:30.696920
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    """ Unit test for method of class ChrootFactCollector """
    from ansible.module_utils.facts.collector.chroot import ChrootFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.chroot import is_chroot
    from ansible.module_utils.facts import ansible_collections

    # Create fake module
    fake_module = ansible_collections.AnsibleCollection('fake_module')._module

    # Create collector
    fake_chroot_collector = ChrootFactCollector()

    # Check that instance is of class BaseFactCollector
    assert isinstance(fake_chroot_collector, BaseFactCollector)

    # Check that is_chroot() is called with fake_module as parameter

# Generated at 2022-06-23 00:51:39.368185
# Unit test for function is_chroot
def test_is_chroot():
    # make sure it returns the correct value with a callable module
    def test_module(name, *args, **kwargs):
        class TestModule(object):
            def __init__(self):
                self.params = dict()
            def get_bin_path(self, *args, **kwargs):
                return os.path.realpath(os.path.expanduser(args[0]))
            def run_command(self, *args, **kwargs):
                class AnsibleModuleResult(object):
                    def __init__(self):
                        self.rc = 0
                        self.stdout = ''
                        self.stderr = ''
                cmd = args[0]
                if cmd[0] == '/usr/bin/stat':
                    m = TestModule()

# Generated at 2022-06-23 00:51:50.097439
# Unit test for function is_chroot
def test_is_chroot():

    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector import MockFileStats
    from ansible.module_utils.facts.collector import MockOSFileStats

    # Test if inode of '/' is not fs_root_ino (2)
    my_root = MockFileStats()
    my_root.st_ino = 3
    my_root.st_dev = 4
    proc_root = MockFileStats()
    proc_root.st_ino = 3
    proc_root.st_dev = 4
    assert is_chroot() == True

    # Test if inode of '/' is not fs_root_ino (2)
    my_root = MockFileStats()
    my_root.st_ino = 3
    my_root.st_dev = 4

# Generated at 2022-06-23 00:51:55.484781
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # test for fact is_chroot
    # set module to None
    test_ChrootFactCollector = ChrootFactCollector()
    # call method collect of ChrootFactCollector
    facts_dict = test_ChrootFactCollector.collect()
    # check facts_dict
    assert facts_dict == {'is_chroot': is_chroot(None)}

# Generated at 2022-06-23 00:51:57.773346
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    collector = ChrootFactCollector()
    assert(collector is not None)
    assert(collector.name == 'chroot')



# Generated at 2022-06-23 00:51:59.886763
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    cf = ChrootFactCollector()
    assert cf.name == 'chroot'

# Generated at 2022-06-23 00:52:04.977773
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fact_collector = ChrootFactCollector()
    assert chroot_fact_collector.name == 'chroot'
    assert not chroot_fact_collector._fact_ids.isdisjoint({'is_chroot'})

# Generated at 2022-06-23 00:52:08.451563
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    obj = ChrootFactCollector()
    chroot_facts = obj.collect()
    assert chroot_facts == {'is_chroot': is_chroot()}

# Generated at 2022-06-23 00:52:12.530727
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    import ansible.module_utils.facts.collector
    collected_facts = ansible.module_utils.facts.collector.CollectedFacts()

    collector = ChrootFactCollector()
    assert collector.collect(collected_facts) == {'is_chroot': False}

# Generated at 2022-06-23 00:52:15.021538
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    result = ChrootFactCollector()
    assert result.name == 'chroot'
    assert result._fact_ids == {'is_chroot'}

# Generated at 2022-06-23 00:52:16.750298
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot = ChrootFactCollector()
    assert chroot.collect() == {"is_chroot": False}

# Generated at 2022-06-23 00:52:17.716808
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-23 00:52:20.962439
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    assert ChrootFactCollector.collect() == {'is_chroot': is_chroot()}

# Generated at 2022-06-23 00:52:24.210888
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    my_class = ChrootFactCollector()
    result = my_class.collect()
    assert result == {'is_chroot': False}


# Generated at 2022-06-23 00:52:29.161352
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # test with a chroot environment
    collector_test = ChrootFactCollector()
    data = collector_test.collect(module=None, collected_facts=None)

    assert data['is_chroot'] is True

    # test with a non chroot environment
    collector_test = ChrootFactCollector()
    data = collector_test.collect(module=None, collected_facts=None)

    assert data['is_chroot'] is False

# Generated at 2022-06-23 00:52:29.965584
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-23 00:52:34.310460
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    """
    Test the method collect of class ChrootFactCollector
    """
    mock_module = Mock()
    mock_module.run_command = MagicMock(return_value=(0, 'btrfs', ''))
    chroot = ChrootFactCollector()
    facts = chroot.collect(mock_module)
    assert facts
    assert facts['is_chroot']

# Generated at 2022-06-23 00:52:42.606536
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():

    class ModuleMock:
        def get_bin_path(self, arg):
            return None

        def run_command(self, args):
            return None, None, None

    my_root = os.stat('/')

    # I'm not root or no proc, fallback to checking it is inode #2
    fs_root_ino = 2
    is_chroot_result = True if my_root.st_ino != fs_root_ino else False

    collector = ChrootFactCollector()
    result = collector.collect(module=ModuleMock())

    assert result == {'is_chroot': is_chroot_result}

# Generated at 2022-06-23 00:52:47.249344
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    from ansible.module_utils.facts import Facts

    # Create test environment
    c_facts = Facts()

    # Invoke target method
    method = ChrootFactCollector()
    result = method.collect(collected_facts=c_facts)

    # Check result is as expected
    assert result['is_chroot'] == is_chroot()


# Generated at 2022-06-23 00:52:54.598174
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    import ansible.module_utils.facts.collector

    def mock_chroot():
        return True

    ansible.module_utils.facts.collector.is_chroot = mock_chroot
    c = ChrootFactCollector()
    collected_facts = {}
    facts = c.collect(None, collected_facts)
    assert facts['is_chroot']

# Generated at 2022-06-23 00:52:58.353085
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fact_collector = ChrootFactCollector()
    assert chroot_fact_collector.name == 'chroot'
    assert 'is_chroot' in chroot_fact_collector._fact_ids

# Generated at 2022-06-23 00:52:59.423578
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    f = ChrootFactCollector()
    assert True

# Generated at 2022-06-23 00:53:08.719833
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    from ansible.module_utils.facts.collector.chroot import ChrootFactCollector
    class DummyModule():
        def __init__(self):
            self.run_command_called = False
            self.get_bin_path_return_value = None
            self.run_command_return_value = (0, 'xfs', '')

        def get_bin_path(self, arg):
            return self.get_bin_path_return_value

        def run_command(self, cmd):
            self.run_command_called = True
            return self.run_command_return_value

    def is_chroot(module):
        return False

    module = DummyModule()
    chroot_fact_collector = ChrootFactCollector()

    # Test chroot fact collector collect with run_command returning x

# Generated at 2022-06-23 00:53:09.660459
# Unit test for function is_chroot
def test_is_chroot():
    # we are not in chroot
    assert is_chroot(module=None) is False

# Generated at 2022-06-23 00:53:16.506048
# Unit test for function is_chroot
def test_is_chroot():

    from ansible.module_utils.facts.tests.test_module_arguments import AnsibleModuleArgsMocked

    # We are root and no chroot
    with AnsibleModuleArgsMocked(name='/bin/true'):
        assert not is_chroot(module=AnsibleModuleArgsMocked)

    # We are root and in a chroot
    with AnsibleModuleArgsMocked(name='/bin/true'):
        # Fake chroot
        os.environ["debian_chroot"] = 'user@host:~$'
        assert is_chroot(module=AnsibleModuleArgsMocked)
        del os.environ["debian_chroot"]

    # We are root and in chroot with a different root file system

# Generated at 2022-06-23 00:53:19.947832
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fact_collector = ChrootFactCollector()
    assert 'is_chroot' in chroot_fact_collector._fact_ids


# Generated at 2022-06-23 00:53:21.041723
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-23 00:53:27.222985
# Unit test for function is_chroot
def test_is_chroot():
    def mock_os_stat(path):
        class statinfo:
            def __init__(self, ino, dev):
                self.st_ino = ino
                self.st_dev = dev
        return statinfo(2, 1)

    orig_stat = os.stat

    try:
        os.stat = mock_os_stat
        assert is_chroot() is False
    finally:
        os.stat = orig_stat

# Generated at 2022-06-23 00:53:29.369154
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot_test = ChrootFactCollector()
    assert chroot_test.collect() == {'is_chroot': False}

# Generated at 2022-06-23 00:53:36.680655
# Unit test for function is_chroot
def test_is_chroot():
    # This is a positive case.
    # When os.stat returns st_ino and st_dev different than os.stat('/proc/1/root/.')
    os_stat__return_value = {"st_ino": 555, "st_dev": 66}
    os_stat__proc_return_value = {"st_ino": 4, "st_dev": 3}

    import os
    import mock

    with mock.patch.object(os.path.__class__, 'stat', autospec=True) as mock_stat:
        mock_stat.side_effect = [os_stat__return_value, os_stat__proc_return_value]
        is_chroot_result = is_chroot()
        assert is_chroot_result is True

    # This is also a positive case.
    # When os.stat returns st

# Generated at 2022-06-23 00:53:37.754091
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    tl = ChrootFactCollector()
    assert tl.name == 'chroot'

# Generated at 2022-06-23 00:53:43.579939
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    fact_collector = ChrootFactCollector()
    assert fact_collector.collect() == {'is_chroot': False}

# Generated at 2022-06-23 00:53:44.632448
# Unit test for function is_chroot
def test_is_chroot():
    import pytest
    assert is_chroot() is False

# Generated at 2022-06-23 00:53:45.828413
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-23 00:53:55.284063
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    import ansible.module_utils.facts as facts
    import ansible.module_utils.facts.collectors as c
    import ansible.module_utils.facts.system.chroot as chroot
    class MockModule(object):
        def __init__(self):
            self.run_command = lambda _, __: (0, '', '')
            self.get_bin_path = lambda _: 'stat'

    class MyChrootFactCollector(chroot.ChrootFactCollector):
        def is_chroot(self, module):
            return True

    c.register(MyChrootFactCollector())
    collected_facts = facts.collector.collect(MockModule())
    assert collected_facts['is_chroot']

# Generated at 2022-06-23 00:54:00.397459
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():

    collector = ChrootFactCollector()
    assert collector.name == 'chroot'
    assert collector._fact_ids == set(['is_chroot'])


# Generated at 2022-06-23 00:54:08.099380
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():

    class ModuleMock:
        def __init__(self):
            self.run_command_result = (0, '', '')
            self.run_command_side_effect = None

        def run_command(self, args):
            if self.run_command_side_effect:
                self.run_command_side_effect(self, args)
            return self.run_command_result

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name == 'stat':
                return '/usr/bin/stat'
            else:
                return None

    def test_chroot(module):
        module.run_command_result = (0, 'ext4', '')

    mod = ModuleMock()

    mod.run_command_side_effect = test_chroot



# Generated at 2022-06-23 00:54:19.204568
# Unit test for function is_chroot

# Generated at 2022-06-23 00:54:20.882394
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    coll = ChrootFactCollector()
    assert 'chroot' == coll.name
    assert coll._fact_ids

# Generated at 2022-06-23 00:54:31.049072
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    # Instantiate an object to collect facts
    cfc = ChrootFactCollector()
    # Define a fake module object
    class module:
        def get_bin_path(self, binary):
            return None
        def run_command(self, cmd):
            return (0, 'xfs', None)
    # Call collect
    facts = cfc.collect(module())
    # Assert that facts is a dict and 'is_chroot' key is present
    assert isinstance(facts, dict)
    assert set(['is_chroot']) == set(facts.keys())
    # Assert that 'is_chroot' value is a bool
    assert isinstance(facts['is_chroot'], bool)

# Generated at 2022-06-23 00:54:42.278868
# Unit test for function is_chroot
def test_is_chroot():

    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.hardware import HardwareCollector
    from ansible.module_utils.facts.system import SystemCollector

    module = VirtualCollector()
    module.get_bin_path = lambda x: None
    module.run_command = lambda x: (0, None, None)
    module.collect_file_facts = lambda x: {}
    module.run_command = lambda x: (0, None, None)
    module.get_file_content = lambda x: None
    module.gather_subset = lambda x: []
    module.get_platform_subclass = lambda: None
    hardware_collector = HardwareCollector(module=module)
    hardware_collector._get_platform = lambda: None
    system_collect

# Generated at 2022-06-23 00:54:44.408439
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    fact_collector = ChrootFactCollector()
    assert fact_collector.collect() == {'is_chroot': False}

# Generated at 2022-06-23 00:54:45.594378
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    c = ChrootFactCollector()
    assert c.name == 'chroot'


# Generated at 2022-06-23 00:54:48.205320
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot(None) == False

# Generated at 2022-06-23 00:54:49.553519
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    assert is_chroot() == ChrootFactCollector().collect()['is_chroot']

# Generated at 2022-06-23 00:54:55.497457
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    m = None
    cfc = ChrootFactCollector()
    res = cfc.collect(module=m)
    assert res is not None
    assert 'is_chroot' in res
    assert res['is_chroot'] is not None
    assert isinstance(res['is_chroot'], bool)


# Generated at 2022-06-23 00:54:58.652790
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector.name == 'chroot'
    assert ChrootFactCollector._fact_ids == set(['is_chroot'])

# Generated at 2022-06-23 00:55:00.717805
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    c = ChrootFactCollector()
    res = c.collect()
    assert res['is_chroot'] is False

# Generated at 2022-06-23 00:55:06.802908
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_fact_collector = ChrootFactCollector()
    assert chroot_fact_collector.name == 'chroot'
    chroot_fact_ids = chroot_fact_collector._fact_ids
    assert 'is_chroot' in chroot_fact_ids



# Generated at 2022-06-23 00:55:11.151477
# Unit test for function is_chroot
def test_is_chroot():
    # mock the module class
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    assert is_chroot(module) == False

# Generated at 2022-06-23 00:55:14.213230
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector.name == 'chroot'
    assert ChrootFactCollector._fact_ids == {'is_chroot'}


# Generated at 2022-06-23 00:55:15.180679
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    ChrootFactCollector()

# Generated at 2022-06-23 00:55:19.638633
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    c = ChrootFactCollector()
    assert c.name == 'chroot'
    assert c._fact_ids == set(['is_chroot'])


# Generated at 2022-06-23 00:55:22.971237
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector().name == 'chroot'
    assert ChrootFactCollector()._fact_ids == { 'is_chroot' }

# Generated at 2022-06-23 00:55:33.237646
# Unit test for method collect of class ChrootFactCollector

# Generated at 2022-06-23 00:55:34.028648
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-23 00:55:41.350205
# Unit test for function is_chroot
def test_is_chroot():
    # package not installed
    module = None
    is_chroot = is_chroot(module)
    assert not is_chroot
    # package installed
    module = MockAnsibleModule()
    module.run_command = Mock(return_value=(0, 'ext4', ''))
    is_chroot = is_chroot(module)
    assert not is_chroot
    # package installed
    module.run_command = Mock(return_value=(0, 'btrfs', ''))
    is_chroot = is_chroot(module)
    assert not is_chroot
    # package installed
    module.run_command = Mock(return_value=(0, 'xfs', ''))
    is_chroot = is_chroot(module)
    assert not is_chroot
    # package installed

# Generated at 2022-06-23 00:55:43.080165
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector.name == 'chroot'


# Generated at 2022-06-23 00:55:44.025370
# Unit test for function is_chroot
def test_is_chroot():
    assert not is_chroot()

# Generated at 2022-06-23 00:55:47.670157
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    my_collector = ChrootFactCollector()
    assert my_collector.name == 'chroot'
    assert my_collector._fact_ids == set(['is_chroot'])


# Generated at 2022-06-23 00:55:59.344331
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    class FakeModule():
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_stdout = 0
            self.run_command_stderr = 0
            self.file_tools_stats = {
                'st_ino': 2,
            }

        def get_bin_path(self, *args, **kwargs):
            return '/bin/stat'

        def run_command(self, *args, **kwargs):
            return [self.run_command_rc, self.run_command_stdout, self.run_command_stderr]

        def file_exists(self, *args, **kwargs):
            return False

    test_module = FakeModule()
    test_collector = ChrootFactCollector()

    # Not in chroot
    result

# Generated at 2022-06-23 00:56:01.361559
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    cfg = ChrootFactCollector()
    assert cfg.name == 'chroot'
    assert cfg._fact_ids == set(['is_chroot'])

# Generated at 2022-06-23 00:56:02.375730
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-23 00:56:08.380100
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    c = ChrootFactCollector()
    assert c.name == 'chroot'
    assert c._fact_ids == {'is_chroot'}

# Generated at 2022-06-23 00:56:12.594637
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    cfc = ChrootFactCollector()
    # Set is_chroot back to default state
    cfc.collect(collected_facts={'is_chroot': False})

    # TODO: create mocks for is_chroot()
    # https://docs.pytest.org/en/latest/monkeypatch.html

# Generated at 2022-06-23 00:56:14.422941
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot = ChrootFactCollector()
    assert chroot.collect().get('is_chroot') is None

# Generated at 2022-06-23 00:56:16.627347
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    collector = ChrootFactCollector()
    result = collector.collect()
    assert result.get('is_chroot') is False

# Generated at 2022-06-23 00:56:17.960918
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot = ChrootFactCollector()
    assert chroot is not None

# Generated at 2022-06-23 00:56:20.843297
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    test_chroot = ChrootFactCollector()
    assert test_chroot.name == 'chroot'
    assert test_chroot._fact_ids == set(['is_chroot'])


# Generated at 2022-06-23 00:56:22.907589
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chroot_object = ChrootFactCollector()

    assert chroot_object.name == 'chroot'
    assert chroot_object._fact_ids == {'is_chroot'}


# Generated at 2022-06-23 00:56:24.645346
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    cfc = ChrootFactCollector()
    assert cfc.name == 'chroot'
    assert cfc._fact_ids == {'is_chroot'}



# Generated at 2022-06-23 00:56:29.506708
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chr = ChrootFactCollector()
    assert chr.name == 'chroot'
    assert chr._fact_ids == set(['is_chroot'])


# Generated at 2022-06-23 00:56:34.120406
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot_fact_collector = ChrootFactCollector()
    collected_facts = {}
    chroot_facts = chroot_fact_collector.collect(collected_facts=collected_facts)
    assert chroot_facts == {'is_chroot': False}

# Generated at 2022-06-23 00:56:36.221837
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():

    # testing module directly
    assert ChrootFactCollector.collect() == {'is_chroot': is_chroot()}


# Generated at 2022-06-23 00:56:40.713163
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-23 00:56:44.392908
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    collector = ChrootFactCollector()
    # Class ChrootFactCollector does not depend on ansible_module
    assert collector.collect() == {'is_chroot': False}

# Generated at 2022-06-23 00:56:45.715516
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() == False

# Generated at 2022-06-23 00:56:54.796147
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    # Create a mock module that has a module_utils.facts.collector.Collector instance
    # with a mock _collect_from_collector method.
    module = MockModule()
    collector = Collector()
    collector._collect_from_collector = Mock(return_value={'is_chroot': True})

    # Call the collect method
    collector.collect(module=module)

    # Assert that the Collector instance had the _collect_from_collector method
    # called with the ChrootFactCollector class.
    collector._collect_from_collector.assert_called_with(ChrootFactCollector)

    # Assert that the

# Generated at 2022-06-23 00:57:06.445055
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    FACT_SUBSET = dict(
        ansible_facts=dict(
            ansible_local=dict(
                ansible_chroot=dict(
                    is_chroot=True
                )
            )
        )
    )

    # TODO: add test for different filesystems

    # Test default chroot
    chroot_collector = ChrootFactCollector()
    complete_facts = dict()
    chroot_collector.collect(collected_facts=complete_facts)
    assert FACT_SUBSET == complete_facts
    # Test in chroot
    chroot_collector = ChrootFactCollector()
    complete_facts = dict(ansible_facts=dict(ansible_local=dict(ansible_chroot=dict())))

# Generated at 2022-06-23 00:57:07.070965
# Unit test for function is_chroot
def test_is_chroot():
    assert not is_chroot()

# Generated at 2022-06-23 00:57:09.524755
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector().name == "chroot"
    assert ChrootFactCollector()._fact_ids == set(['is_chroot'])



# Generated at 2022-06-23 00:57:10.514389
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-23 00:57:13.061448
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    cf = ChrootFactCollector()
    assert isinstance(cf.collect(), dict)
    assert isinstance(cf.collect()['is_chroot'], bool)

# Generated at 2022-06-23 00:57:14.996671
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    assert isinstance(ChrootFactCollector().collect(), dict)


# Generated at 2022-06-23 00:57:17.842715
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    assert ChrootFactCollector.name == 'chroot'
    assert ChrootFactCollector._fact_ids == set(['is_chroot'])



# Generated at 2022-06-23 00:57:20.912461
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot_collector = ChrootFactCollector()
    result = chroot_collector.collect()
    assert result['is_chroot'] == None

# Generated at 2022-06-23 00:57:24.326072
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    """This function performs unit test for constructor of class ChrootFactCollector. """
    chroot_fact_constructor = ChrootFactCollector()
    assert chroot_fact_constructor.name == 'chroot', "Constructor of class ChrootFactCollector has failed"

# Generated at 2022-06-23 00:57:27.025857
# Unit test for method collect of class ChrootFactCollector
def test_ChrootFactCollector_collect():
    chroot = ChrootFactCollector()
    assert chroot.collect() == {'is_chroot': is_chroot()}

# Generated at 2022-06-23 00:57:29.681755
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    x = ChrootFactCollector()
    assert x.name == 'chroot'
    x._fact_ids == {'is_chroot'}

# Generated at 2022-06-23 00:57:31.901464
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    x = ChrootFactCollector()
    assert x.name == 'chroot'
    assert x._fact_ids == set(['is_chroot'])

# Generated at 2022-06-23 00:57:34.263446
# Unit test for function is_chroot
def test_is_chroot():
    try:
        assert is_chroot(None) == False
    except AssertionError as e:
        print("is_chroot failed: %s" % (e))

# Generated at 2022-06-23 00:57:35.432093
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    chf = ChrootFactCollector()
    assert chf.name == 'chroot'

# Generated at 2022-06-23 00:57:39.623017
# Unit test for constructor of class ChrootFactCollector
def test_ChrootFactCollector():
    from ansible.module_utils.facts import get_collector_instance
    c = get_collector_instance(ChrootFactCollector)
    assert c.name == 'chroot'
    c._collect_from_module = lambda a, b: {'the_facts': True}
    assert c.get_facts()['the_facts'] == True



# Generated at 2022-06-23 00:57:40.966357
# Unit test for function is_chroot
def test_is_chroot():
    assert is_chroot() is False

# Generated at 2022-06-23 00:57:43.327781
# Unit test for function is_chroot
def test_is_chroot():
    is_chroot_test = is_chroot()
    assert(type(is_chroot_test) == bool)

# Generated at 2022-06-23 00:57:54.004517
# Unit test for function is_chroot
def test_is_chroot():
    from ansible.module_utils._text import to_native

    assert is_chroot() == False
    assert is_chroot(None) == False

    # Mock up module.run_command for the exception handling path
    class Module(object):
        def __init__(self):
            self.run_command_args = []

        def run_command(self, args):
            self.run_command_args.append(args)
            raise Exception("I can't stat /proc/1/root/. (permission denied)")

        def get_bin_path(self, binary):
            self.get_bin_path_calls = binary
            return '/bin/%s' % binary

    module = Module()

    # Inode number 2 is the root inode filesystems other than btrfs or xfs.
    assert is_chroot