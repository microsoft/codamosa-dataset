

# Generated at 2022-06-22 04:07:09.807081
# Unit test for method __getattr__ of class _Mockable
def test__Mockable___getattr__():
	test = _Mockable(OptionParser())
	test.__dict__["_options"] = OptionParser()
	test.__dict__["_options"]._options = {"test_name":"test"}
	test.__dict__["_options"]._options["test_name"] = "test"
	assert test.test_name == "test"


# Generated at 2022-06-22 04:07:21.113628
# Unit test for method parse of class _Option
def test__Option_parse():
    op = _Option('a', default=None, type=str, help='', metavar='', multiple=True, file_name=None, group_name=None, callback=None)
    assert op.parse('a,b,c') == ['a', 'b', 'c']
    with pytest.raises(Exception):
        op.parse('a,b,c,d')
    op = _Option('a', default=None, type=str, help='', metavar='', multiple=False, file_name=None, group_name=None, callback=None)
    assert op.parse('a,b,c') == 'a,b,c'

# Generated at 2022-06-22 04:07:26.446120
# Unit test for method set of class _Option
def test__Option_set():
    opt = _Option(name='num', default=None, type=int, help=None, metavar=None, multiple=False, file_name=None,
                  group_name=None, callback=None)
    # Test with correct option
    opt.set(1)
    assert opt.value() == 1
    assert opt.type(opt.value()) == 'int'



# Generated at 2022-06-22 04:07:27.766633
# Unit test for function parse_command_line
def test_parse_command_line():
    assert parse_command_line() == 'abcd'


# Generated at 2022-06-22 04:07:33.648092
# Unit test for method __contains__ of class OptionParser
def test_OptionParser___contains__():
    print('test_OptionParser___contains__')
    options = OptionParser()
    options.define('a')
    assert options.__contains__('a')
    assert options.__contains__('A')
    assert not options.__contains__('b')
    assert not options.__contains__('B')
    assert 'a' in options
    assert 'A' in options
    assert 'b' not in options
    assert 'b' not in options


# Generated at 2022-06-22 04:07:36.653528
# Unit test for method add_parse_callback of class OptionParser
def test_OptionParser_add_parse_callback():
    option_parser= OptionParser()
    option_parser.add_parse_callback(lambda: 5)
    assert option_parser._parse_callbacks!=[]

# Generated at 2022-06-22 04:07:40.860235
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    from mock import call, MagicMock
    from tornado.options import _Options
    from tornado.options import OptionParser
    from tornado.options import options as options

    option_parser = OptionParser()
    _options = _Options()

# Generated at 2022-06-22 04:07:42.891456
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    option_parser = OptionParser()
    option_parser.define("name", default="foo")


# Generated at 2022-06-22 04:07:51.678931
# Unit test for method parse of class _Option
def test__Option_parse():
    # test of function _parse_bool
    c1 = _Option("test_bool", default=False, type=bool, help="a bool type")
    assert c1.parse("True") == True
    assert c1.parse("1") == True
    assert c1.parse("false") == False
    assert c1.parse("0") == False
    assert c1.parse("F") == False
    assert c1.parse("T") == True
    with pytest.raises(Error):
        _ = c1.parse("TOOOO")
    assert c1.parse("true") == True
    assert c1.parse("False") == False
    assert c1.parse("Abc") == True
    assert c1.parse("true") == True

# Generated at 2022-06-22 04:07:53.784211
# Unit test for function parse_command_line
def test_parse_command_line():
    try:
        parse_command_line()
    except Exception:
        raise AssertionError

# Generated at 2022-06-22 04:08:16.057133
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    import tempfile
    import shutil
    import os
    import six
    import unittest
    import tornado.options

    class FuncTest(unittest.TestCase):

        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.func_name = 'test_function'
            #create option
            tornado.options.define(self.func_name, type=str, default='default', multiple=False)

        def test_define_parse_config_file(self):
            #create a config file
            config_path = os.path.join(self.test_dir, 'test.conf')

# Generated at 2022-06-22 04:08:25.578833
# Unit test for method group_dict of class OptionParser
def test_OptionParser_group_dict():
    from tornado.options import define, parse_command_line, options
    define('template_path', group='application')
    define('static_path', group='application')
    parse_command_line()
    assert(options.group_dict('application')=={'static_path':options.static_path,'template_path':options.template_path})

test_OptionParser_group_dict()


# Options are stored here by default.
options = OptionParser()

# The global default value for options that don't have one explicitly set
DEFAULT = object()



# Generated at 2022-06-22 04:08:27.147895
# Unit test for method print_help of class OptionParser
def test_OptionParser_print_help():
	parser = OptionParser()
	parser.print_help()


# Generated at 2022-06-22 04:08:38.505654
# Unit test for method value of class _Option
def test__Option_value():
    assert _Option('name',default=None,type="type",help="help",metavar="metavar",multiple=False,file_name="file_name",group_name="group_name",callback="callback").value() == None
    assert _Option('name',default=None,type="type",help="help",metavar="metavar",multiple=True,file_name="file_name",group_name="group_name",callback="callback").value() == []
    assert _Option('name',default="default",type="type",help="help",metavar="metavar",multiple=False,file_name="file_name",group_name="group_name",callback="callback").value() == "default"

# Generated at 2022-06-22 04:08:47.279711
# Unit test for constructor of class _Option
def test__Option():
    _Option("a", default=3)
    _Option("a", default=3, type=int)
    _Option("a", default=3, type=int, help="sdfsdfs")
    _Option("a", default=3, type=int, help="sdfsdfs", metavar="234")
    _Option("a", default=3, type=int, help="sdfsdfs", metavar="234", multiple=True)
    _Option("a", default=3, type=int, help="sdfsdfs", metavar="234", multiple=True, file_name="sdf")
    _Option("a", default=3, type=int, help="sdfsdfs", metavar="234", multiple=True, file_name="sdf", group_name="sdf")
   

# Generated at 2022-06-22 04:08:52.660598
# Unit test for method mockable of class OptionParser
def test_OptionParser_mockable():
    from tornado import options
    import unittest.mock
    # mock.patch.object(options.mockable(), 'name', value)
    options.define('name', default='wocao', type=str)
    with unittest.mock.patch.object(options.mockable(), 'name', 'woca') as m:
        assert options.name == m()


# Generated at 2022-06-22 04:09:05.307357
# Unit test for method parse of class _Option
def test__Option_parse():
    _Option.UNSET = object()
    name = 'opt'
    default = None
    type = str
    help = 'option description'
    metavar = None
    multiple = False
    file_name = None
    group_name = None
    callback = None
    option = _Option(name, default, type, help, metavar, multiple, file_name, group_name, callback)
    value = '1'
    # parse value using the method _parse
    _parse = {
        int: option._parse_int,
        str: option._parse_str,
        bool: option._parse_bool,
    }.get(option.type)
    assert _parse == option._parse_str
    result = _parse(value)
    assert result == value
    option._value = _Option.UNSET
    #

# Generated at 2022-06-22 04:09:09.014463
# Unit test for method value of class _Option
def test__Option_value():
    option = _Option(name="port", default=None, type=int, help="help", metavar="metavar", multiple=False, file_name=None, group_name=None, callback=None)
    assert option.value() is None
    option._value = 8080
    assert option.value() == 8080


# Generated at 2022-06-22 04:09:19.027633
# Unit test for function parse_config_file
def test_parse_config_file():
    class TestOptionParser(OptionParser):
        def parse_config_file(self, path: str, final: bool = True) -> None:
            print(path)
    # test the parse_config_file when the config file and the yapf file are in the same directory
    test_op = TestOptionParser()
    # test the parse_config_file when the config file is in the upper level of the yapf file
    test_root_level_op = TestOptionParser()
    try:
        test_op.parse_config_file('../../config.ini')
        test_root_level_op.parse_config_file('../config.ini')
    except:
        print('Error')
        return False
    return True


# Generated at 2022-06-22 04:09:25.155492
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    parser = OptionParser()
    parser.define("debug", type=bool, help="debug mode")
    parser.define("port", type=int, help="port", default=8888)
    try:
        parser.parse_config_file("tests/test_options.txt")
    except:
        raise AssertionError("OptionParser_parse_config_file() failed")



# Generated at 2022-06-22 04:10:02.323925
# Unit test for method print_help of class OptionParser
def test_OptionParser_print_help():
    import io
    import sys
    import unittest
    import tornado.options
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    class OptionIterator(object):
        def __init__(self, iterable):
            self._iterable = iterable
        def __iter__(self):
            return iter(self._iterable)
    class OptionParserTestCase(unittest.TestCase):
        def test_print_help(self):
            options.define('foo', default=1)
            options.define('bar', default=2)
            options.define('baz', default=3)

# Generated at 2022-06-22 04:10:04.956801
# Unit test for method add_parse_callback of class OptionParser
def test_OptionParser_add_parse_callback():
    assert callable(OptionParser().add_parse_callback)
    assert isinstance(OptionParser().add_parse_callback, MethodType)


# Generated at 2022-06-22 04:10:12.333660
# Unit test for method as_dict of class OptionParser
def test_OptionParser_as_dict():
    # It was not easy to come up with an easy test, as it involves 
    # a command line parsing, which is not something directly 
    # accessible in a unit test (without any serious mocking)
    parser = OptionParser()
    parser.define("name", default="default_name")
    parser.define("value", default="default_value")
    parser.define("day", default="default_day")
    parser.define("month", default="default_month")
    parser.parse_command_line()
    print(parser.as_dict())

    with pytest.raises(tornado.options.Error) as excinfo:
        parser.parse_config_file("non_existing_file.cfg")

    assert 'Error: cannot open config file non_existing_file.cfg' in str(excinfo.value)


# Generated at 2022-06-22 04:10:15.483777
# Unit test for function define
def test_define():
    define("bar", default='baz', type=int, help='help', metavar='metavar', multiple=True, group='group', callback=None)
    assert options.bar == 'baz'
    assert type(options.bar) == int
    assert options.help['bar'] == 'help'
    assert options.metavar['bar'] == 'metavar'
    assert options.multiple['bar'] == True
    assert options.group['bar'] == 'group'



# Generated at 2022-06-22 04:10:23.647917
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
   dict = {"username":"Tom","password":"123456","age":"22"}
   conf_file = open("/tmp/options.conf",'w')
   conf_file.write("#!/usr/bin/python \n")
   conf_file.write("username = '"+dict["username"]+"' \n")
   conf_file.write("password = '"+dict["password"]+"' \n")
   conf_file.write("age = "+dict["age"]+" \n")
   conf_file.close()
   options = OptionParser()
   options.define("username", help="username", type=str)
   options.define("password", help="password", type=str)
   options.define("age", help="age", type=int)
   options.parse_config_file("/tmp/options.conf")
  

# Generated at 2022-06-22 04:10:25.414255
# Unit test for method run_parse_callbacks of class OptionParser
def test_OptionParser_run_parse_callbacks():
    parser = OptionParser()
    parser._parse_callbacks = [1, 2, 3]
    parser.run_parse_callbacks()
    assert parser._parse_callbacks == []

# Generated at 2022-06-22 04:10:27.506339
# Unit test for method __setitem__ of class OptionParser
def test_OptionParser___setitem__():
    command_line = ['Tornado.py', 'myfile']
    p = OptionParser()
    p.define("some_option")
    p.define("--some_other_option")
    p.parse_command_line(command_line)
 

# Generated at 2022-06-22 04:10:37.600845
# Unit test for constructor of class _Option
def test__Option():
    _Option("no_default")
    _Option("default_with_type", 0, int)
    _Option("default_with_type_and_callback", 0, int,
            callback=lambda val: bool(val))
    _Option("default_with_type_and_multiple", 0, int, multiple=True)
    _Option("default_with_type_and_group", 0, int, group_name='group1')
    _Option("default_with_type_and_file", 0, int, file_name='group1')
    _Option("default_with_type_and_metavar", 0, int, metavar='val')
    _Option("default_with_type_and_help", 0, int, help='help')

# Generated at 2022-06-22 04:10:41.175248
# Unit test for method __getitem__ of class OptionParser
def test_OptionParser___getitem__():
    # Declare objects and variables
    parser = OptionParser()
    name = 'name'
    value = 'value'

    # Configure parser
    parser.define(name, value)

    # Assertions
    assert parser[name] == value


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-22 04:10:51.596448
# Unit test for method parse of class _Option
def test__Option_parse():
    assert _Option('name', type=int, multiple=True).parse('1,2,3,4') == [1, 2, 3, 4]
    assert _Option('name', type=int, multiple=True).parse('1:3') == [1, 2, 3]
    assert _Option('name', type=int, multiple=True).parse('1') == [1]
    assert _Option('name', type=int, multiple=False).parse('1') == 1

    assert _Option('name', type=float).parse('1.1') == 1.1

    assert _Option('name', type=str).parse('123') == '123'

    assert _Option('name', type=datetime.datetime).parse('2011-10-11 00:00:00') == datetime.datetime(2011, 10, 11, 0, 0)

# Generated at 2022-06-22 04:11:21.811937
# Unit test for method group_dict of class OptionParser
def test_OptionParser_group_dict():
    # Test group_dict of class OptionParser
    parser = OptionParser()
    parser.define("name", type=str, help="name of the server", group='app')
    parser.define("x", type=int, default=10, group='app')
    parser.parse_command_line(['__main__.py', '--name=able', '--x=20'])
    result = parser.group_dict('app')
    assert(result['x'] == 20)
    assert(result['name'] == 'able')
    assert(parser.x == 20)
    assert(parser.name == 'able')


# Generated at 2022-06-22 04:11:26.385844
# Unit test for method __getitem__ of class OptionParser
def test_OptionParser___getitem__():
    # constructor test
    option_parser_obj = OptionParser()
    assert option_parser_obj.options == dict()
    # __getitem__ test
    option_parser_obj['key'] = None
    assert option_parser_obj['key'] is None
    assert option_parser_obj.options == dict(key=None)


# Generated at 2022-06-22 04:11:27.507586
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    pass



# Generated at 2022-06-22 04:11:35.236530
# Unit test for function parse_command_line
def test_parse_command_line():
    define("name", default='lala', type=str, help="name of command")
    define("name2", default='lele', type=str, help="name of command2")
    parse_command_line(args=['--name', 'lala1', '--name2', 'lele2', 'lala3'])
    assert options.name=='lala1'
    assert options.name2=='lele2'


# Generated at 2022-06-22 04:11:37.364103
# Unit test for function parse_config_file
def test_parse_config_file():
    config = "key1 = 'value1'\nkey2 = 'value2'"
    options.define("key1", type=str, help="")
    options.define("key2", type=str, help="")
    options.parse_config_file(config)
    assert options.key1 == "value1"
    assert options.key2 == "value2"


# Generated at 2022-06-22 04:11:42.249846
# Unit test for method run_parse_callbacks of class OptionParser
def test_OptionParser_run_parse_callbacks():
    # Example of test_run_parse_callbacks
    """
    tests = {
        'test_run_parse_callbacks': [
            {
                'input': '()',
                'expect': '()->None',
            },
        ],
    }
    """
    pass


# Generated at 2022-06-22 04:11:48.600474
# Unit test for method add_parse_callback of class OptionParser
def test_OptionParser_add_parse_callback():
    parser = OptionParser()
    parser.add_parse_callback(lambda: print("c"))
    parser.run_parse_callbacks()
    parser.add_parse_callback(lambda: print("a"))
    parser.add_parse_callback(lambda: print("b"))
    parser.run_parse_callbacks()


# Generated at 2022-06-22 04:11:57.066251
# Unit test for constructor of class _Mockable
def test__Mockable():
    options = OptionParser()
    options.define("foo", "bar")
    options.define("test", "testing")
    mock = _Mockable(options)
    mock.foo = "foo"
    mock.test = "test"
    assert options.foo == "foo"
    assert options.test == "test"
    del mock.foo
    del mock.test
    assert options.foo == "bar"
    assert options.test == "testing"


# A simple command line interface for running tests.  This is intended
# to be run interactively by developers and not called by automated
# systems, so the output is not machine-readable and a bit fancier
# than a typical test runner.

# Generated at 2022-06-22 04:12:00.758398
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    options.parse_command_line(['--test=test_parse_command_line'])
    assert options.test == 'test_parse_command_line'



# Generated at 2022-06-22 04:12:06.600406
# Unit test for constructor of class _Mockable
def test__Mockable():
    # Note: _Mockable is not typically used directly; this test is intended
    # only to exercise the constructor and destruction.
    options = OptionParser()
    options.define("name", default="Bob")
    mockable = _Mockable(options)
    mockable.name = "Alice"
    del mockable.name
    assert options.name == "Bob"


# Global instance of `OptionParser`.  Applications should use this
# instead of creating their own.
options = OptionParser()
options.define(
    "help", type=bool, help=None, callback=options._help_callback,
)



# Generated at 2022-06-22 04:12:22.436741
# Unit test for method parse of class _Option
def test__Option_parse():
    option = _Option("port", type=int, help="help test", metavar="name", multiple=False, file_name="file_name", group_name="group_name", callback=False)
    error = False
    try:
        value = option.parse("1")
    except Exception:
        error = True
    assert error == False

# Generated at 2022-06-22 04:12:27.982475
# Unit test for constructor of class OptionParser
def test_OptionParser():
    parser = OptionParser()
    assert parser._options == dict()
    assert len(parser._options) == 0
    assert parser._parse_callbacks == list()
    assert len(parser._parse_callbacks) == 0


# Generated at 2022-06-22 04:12:32.296713
# Unit test for method set of class _Option
def test__Option_set():
    from io import StringIO, BytesIO
    import builtins
    import sys

    options = OptionParser()
    # options.define('name', default='', type=str, help='',
    # metavar='', multiple=False, callback=None)
    option = _Option(
        'name',
        default='',
        type=str,
        help='',
        metavar='',
        multiple=False,
        file_name=None,
        group_name=None,
        callback=None,
    )
    option.set('a')
    assert option.value() == 'a'
    # options.define('name', default='', type=str, help='',
    # metavar='', multiple=True, callback=None)

# Generated at 2022-06-22 04:12:38.920647
# Unit test for method groups of class OptionParser
def test_OptionParser_groups():
    tornado_options._options = {}
    tornado_options.define('name', default='null', help='name help', type=str, multiple=False)
    tornado_options.define('name1', default='null', help='name1 help', type=str, multiple=False)
    tornado_options.define('name2', default='null', help='name2 help', type=str, multiple=False)
    tornado_options.define('age', default='null', help='age help', type=str, multiple=False)
    assert tornado_options.groups() == {'name','name1','name2','age'}



# Generated at 2022-06-22 04:12:42.730333
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    #define('mysql_host',  default='localhost:3306', help='Main host of MySQL')
    try:
        options.define('mysql_host',default='localhost:3306',help='main host of Mysql')
        return True
    except:
        return False


# Generated at 2022-06-22 04:12:45.516169
# Unit test for method value of class _Option
def test__Option_value():
    option = _Option('name', default=None, type=None, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    assert option.value()==None
    assert option._value == _Option.UNSET
    

# Generated at 2022-06-22 04:12:48.164676
# Unit test for method run_parse_callbacks of class OptionParser
def test_OptionParser_run_parse_callbacks():
    def callback():
        return
    pr = OptionParser()
    pr.add_parse_callback(callback)
    try:
        pr.run_parse_callbacks()
    except:
        raise AssertionError("run parse callbacks failed")
    finally:
        pass

# Generated at 2022-06-22 04:12:58.638004
# Unit test for method parse of class _Option
def test__Option_parse():
    _Option.UNSET = object()
    default = None
    is_multiple = False
    name = 'test'
    value = None
    #_Option.__init__(self,name,default=None,type=None,help=None,metavar=None,multiple=False,file_name=None,group_name=None,callback=None)
    option = _Option(name,default,type(default),None,None,is_multiple,None,None,None)
    if option.parse(str(value)) == option.default:
        print('coverage for parse of class _Option method: success!')
    else:
        print('coverage for parse of class _Option method: fail!')
test__Option_parse()

test__Option_parse()

# Generated at 2022-06-22 04:13:05.452622
# Unit test for method __contains__ of class OptionParser
def test_OptionParser___contains__():
    class MockOption:
        def __init__(self, name):
            self._name = name
        def name(self):
            return self._name

    op = OptionParser()
    op._options = {
        'test1' : MockOption('test1'),
        'test3' : MockOption('test3'),
        'test2' : MockOption('test2')
    }
    assert 'test1' in op
    assert not 'test4' in op



# Generated at 2022-06-22 04:13:09.294944
# Unit test for method add_parse_callback of class OptionParser
def test_OptionParser_add_parse_callback():
    options = OptionParser()
    def callback():
        print("hello")
    options.add_parse_callback(callback)
    #Expect: True
    assert callback in options._parse_callbacks

# Generated at 2022-06-22 04:13:51.179558
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    global_option = 0

    # Test 1: set attr for object of OptionParser
    class OptionParserTest1(OptionParser):
        def __init__(self):
            print("Test 1: set attr for object of OptionParser")
            #print(self._options)
            pass

            #print(self._options)
            return

    option_parser = OptionParser()
    option_parser.define("global_option", global_option, type=int, help="help")
    option_parser.parse_command_line(["--global_option=5"])


    class OptionParserTest2(OptionParser):
        def __init__(self):
            global global_option
            print("Test 2: set attr for object of OptionParser")
            option_parser = OptionParser()

# Generated at 2022-06-22 04:14:01.749017
# Unit test for method __getitem__ of class OptionParser
def test_OptionParser___getitem__():
    """Test for method __getitem__ of class OptionParser"""

    # OptionParser.__getitem__:
    # Read-only access to options by name.
    define("arg-default", default=4242, group="testing")
    # Make sure foo isn't already defined and doesn't collide with anything
    # defined in the main module under test.
    assert "foo" not in options
    define("foo", default=42, group="testing")
    assert options["foo"] == 42
    with raises(Error):
        options["bar"] = 42
    assert options["arg-default"] == 4242



# Generated at 2022-06-22 04:14:08.004683
# Unit test for method __setitem__ of class OptionParser
def test_OptionParser___setitem__():
    # OptionParser.__setitem__: raises NotImplementedError
    try:
        with pytest.raises(NotImplementedError):
            options = OptionParser()
            options[0] = 0
    except Exception as e:
        pytest.fail(f"Exception raised when testing OptionParser.__setitem__: {e}")
    else:
        pass # __setitem__ is not implemented so this will always pass



# Generated at 2022-06-22 04:14:19.253350
# Unit test for method groups of class OptionParser
def test_OptionParser_groups():
    # Create the OptionParser instance
    options = OptionParser()
    options.define('test', type=bool, default=True)
    options.define('test1', type=bool, default=False, group='testgroup')
    options.define('test1', type=bool, default=True, group='testgroup1')

    # Validate the groups() return value
    assert options.groups() == {'testgroup', 'testgroup1'}

    # Validate the group_dict() return value
    assert options.group_dict(None) == {'test': True, 'test1': True}
    assert options.group_dict('testgroup1') == {'test1': True}


# Generated at 2022-06-22 04:14:33.437216
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    """Test the method parse_command_line of class OptionParser"""
    test_obj = OptionParser()
    test_args = sys.argv
    # test_result = test_obj.parse_command_line(test_args)
    # assert test_result is None
    test_args = sys.argv[:-1]
    with pytest.raises(Error) as excinfo:
        test_obj.parse_command_line(test_args)
    assert "Error" in str(excinfo.value)
    test_obj = OptionParser()
    test_args = ["test_name"]
    test_result = test_obj.parse_command_line(test_args)
    assert test_result == []
    test_obj = OptionParser()

# Generated at 2022-06-22 04:14:37.410234
# Unit test for method as_dict of class OptionParser
def test_OptionParser_as_dict():
    # set up
    op = OptionParser()
    op.define("name","Zhang","str")
    # test func
    assert op.as_dict() == {'name': 'Zhang'}

# Generated at 2022-06-22 04:14:50.360272
# Unit test for constructor of class OptionParser
def test_OptionParser():
    def _test():
        parser = OptionParser()
        parser.define("dict_opt", default={}, type=dict)
        parser.define("list_opt", default=[], type=list)
        parser.define("int_opt", default=99, type=int, multiple=True)
        parser.define("float_opt", default=100.0, type=float, multiple=True)
        parser.define("str_opt", default=None, type=str, multiple=True)
        parser.define("bool_opt", default=False, type=bool)
        parser.define("auto_opt", default=False)
        parser.define("auto_bool_opt", default=False)
        parser.define("datetime_opt", type=datetime.datetime)

# Generated at 2022-06-22 04:14:58.462346
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    """
    Test that OptionParser.__iter__ return an iterator over options
    """
    class OptionParserTest(OptionParser):
        def __init__(self):
            super(OptionParserTest, self).__init__()
            self.define("opttest1", type=int, default=1)
            self.define("opttest2", type=int, default=2)
            self.define("opttest3", type=int, default=3)
    options = OptionParserTest()
    assert len(options) == 3

# Generated at 2022-06-22 04:15:04.447685
# Unit test for method group_dict of class OptionParser
def test_OptionParser_group_dict():
    o = OptionParser()
    o.define('template_path', group='application')
    o.define('static_path', group='application')
    str1 = o.group_dict('application')
    assert str1 == {'template_path': None, 'static_path': None}

# Generated at 2022-06-22 04:15:09.366898
# Unit test for method groups of class OptionParser
def test_OptionParser_groups():
    # options = OptionParser()
    # options.define("value", type=str, group='application')
    options.value = "aaa"
    options.define("value", type=str, group='application')
    options.value = "bbb"
    Options = options.group_dict("application")
    assert Options["value"] == "bbb"


# Generated at 2022-06-22 04:16:09.415117
# Unit test for constructor of class OptionParser
def test_OptionParser():
    assert OptionParser()._options == {}



# Generated at 2022-06-22 04:16:17.856545
# Unit test for method parse of class _Option
def test__Option_parse():
    option = _Option("a","1",int,None)
    print(option.parse("10"))
    print(option.parse("10:20"))
    print("------")
    option2 = _Option("b",datetime.datetime.now(),datetime.datetime,None)
    print(option2.parse("%Y-%m-%d %H:%M"))
    print("------")
    option3 = _Option("c",None,bool,None)
    print(option3.parse("False"))
    option4 = _Option("d",None,bool,None)
    print(option4.parse("1"))
    option5 = _Option("e",None,str,None)
    print(option5.parse("1"))