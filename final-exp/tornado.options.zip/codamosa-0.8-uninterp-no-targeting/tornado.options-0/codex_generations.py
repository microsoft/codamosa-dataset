

# Generated at 2022-06-22 04:07:10.312391
# Unit test for method __getattr__ of class _Mockable
def test__Mockable___getattr__():
    options = OptionParser()

    # Test if __getattr__ raises the exception if the attribute is not found
    try:
        foo = _Mockable(options)
        foo.bar
    except:
        raise Exception("Expected exception not raised")

    # Test if __getattr__ returns the expected value of the attribute
    mock = _Mockable(options)
    mock.name = "foo"
    assert mock.name == "foo"



# Generated at 2022-06-22 04:07:15.439581
# Unit test for method run_parse_callbacks of class OptionParser
def test_OptionParser_run_parse_callbacks():
    import sys
    from response import Response

    global res
    res = Response()
    def _test():
        """send response"""
        res.send([])
    
    OptionParser.add_parse_callback = lambda self, _test: self.add_parse_callback(_test)
    OptionParser.run_parse_callbacks = lambda self: self.run_parse_callbacks()

    # tests that the function runs without error
    try:
        OptionParser.run_parse_callbacks()
        res.send(["Ok"])
    except Exception as e:
        res.send([False, str(sys.exc_info()[0])])

if __name__ == "__main__":
    test_OptionParser_run_parse_callbacks()

# Generated at 2022-06-22 04:07:28.422875
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    # Build option_parser, a new OptionParser object
    option_parser = OptionParser()
    # OptionParser.define(name, default, type, help, metavar, multiple, group, callback)
    option_parser.define("a", "", type=str, help="", multiple=True)
    option_parser.define("b", "", type=str, help="")
    # Save the options
    options = option_parser.options()
    assert options.a == ""
    assert options.b == ""
    # OptionParser.parse_command_line(args, final)
    option_parser.parse_command_line(["--a", "1", "2", "--b", "3"])
    assert options.a == ["1", "2"]
    assert options.b == "3"
    # OptionParser.parse_config

# Generated at 2022-06-22 04:07:34.875580
# Unit test for method as_dict of class OptionParser
def test_OptionParser_as_dict():
    # Add a specific test here

    op = OptionParser()
    op.define('debug', type=bool, default=False)
    op.define('port', type=int, default=80)
    op.parse_command_line(['--port', '9000'])
    global dic
    dic = op.as_dict()
    assert dic['debug'] == False
    assert dic['port'] == 9000
#####################################################################



# Generated at 2022-06-22 04:07:38.676384
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    mock = _Mockable(object())
    assert hasattr(mock, "_originals") == False
    mock.__setattr__("_originals", {})
    assert hasattr(mock, "_originals") == True


# Generated at 2022-06-22 04:07:45.338709
# Unit test for constructor of class _Mockable
def test__Mockable():
    obj = _Mockable(object())
    obj.__dict__["_options"] = object()
    assert obj.__dict__ == {"_options": object(), "_originals": {}}


options = OptionParser()  # type: Final
options.define(
    "help", default=False, callback=options._help_callback, help="show this help information"
)

# Generated at 2022-06-22 04:07:49.625763
# Unit test for function add_parse_callback
def test_add_parse_callback():
    """
    Unit test.
    """
    global options
    options.add_parse_callback(test_add_parse_callback)



# Generated at 2022-06-22 04:08:00.870560
# Unit test for method add_parse_callback of class OptionParser
def test_OptionParser_add_parse_callback():
    # case1:
    # We want to check the method add_parser_callback is invoked correctly.
    # We set a callback function and call the method.
    # The callback function is invoked correctly, then we get the correct result.
    parser = OptionParser()
    parser.define('name', default='kong')

    def callback1():
        parser.set('name', 'xudong')
    
    def callback2():
        print('The callback2 is invoked')
    
    parser.add_parse_callback(callback1)
    parser.add_parse_callback(callback2)
    parser.parse_command_line()
    # The callback function is invoked correctly
    assert parser.name == 'xudong'
    # assert parser.parse_command_line() == []
    # The method will return a list containing all arguments that are not parsed

# Generated at 2022-06-22 04:08:14.397812
# Unit test for method __getattr__ of class OptionParser
def test_OptionParser___getattr__():
    # Check normal case (1)
    def test_1():
        import sys
        import builtins

        old_dir = sys.modules["tornado.options"].__dict__["dir"]
        sys.modules["tornado.options"].__dict__["dir"] = lambda *_, **__: ["foo"]
        old_magic = builtins.__dict__["___"]
        builtins.__dict__["___"] = lambda _: 1
        old_getattr = sys.modules["tornado.options"].__dict__["getattr"]
        sys.modules["tornado.options"].__dict__["getattr"] = lambda _, __: 2

        options = Options()
        result = options.foo
        assert result == 2

        sys.modules["tornado.options"].__dict__["dir"] = old_dir
       

# Generated at 2022-06-22 04:08:16.160696
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    from tornado.options import define, parse_command_line, options

    define('name', default='abc')
    parse_command_line()

    __setattr__('tornado', options, 'name', 'def')
    assert options.name == 'def'
    
    

# Generated at 2022-06-22 04:08:40.356293
# Unit test for method add_parse_callback of class OptionParser
def test_OptionParser_add_parse_callback():
    with pytest.raises(TypeError):
        OptionParser_1 = OptionParser()
        OptionParser_1.add_parse_callback("")


test_OptionParser_add_parse_callback()


# Generated at 2022-06-22 04:08:48.447396
# Unit test for method __contains__ of class OptionParser
def test_OptionParser___contains__():
    from datetime import datetime
    from datetime import timedelta
    from tornado.httputil import parse_timedelta

    class Mock:
        def __init__(self):
            self.name = "a"
            self.value = 1
            self.type = int
            self.multiple = False
            self.group_name = "test"
            self.metavar = "a"
            self.help = "test"
            self.callback = None
    mock = Mock()
    opt = _Option("name", file_name="", default="", type=Mock, help="", metavar="", multiple=False, group_name="", callback=None)
    options1 = Options()

# Generated at 2022-06-22 04:08:54.081116
# Unit test for method group_dict of class OptionParser
def test_OptionParser_group_dict():
    optionparser = OptionParser()
    optionparser.define('port', default=8888, group='application')
    optionparser.define('log_file_prefix', group='logging')
    assert optionparser.group_dict('logging') == { 'log_file_prefix': None}
    assert optionparser.group_dict('application') == {'port': 8888}
    assert optionparser.group_dict() == {}

# Generated at 2022-06-22 04:09:02.778024
# Unit test for method __setitem__ of class OptionParser
def test_OptionParser___setitem__():

    # Variable to store exception information, if any
    exception_thrown = False
    try:
        # The following call to method __setitem__ of OptionParser
        # raises an exception
        option_parser = OptionParser()
        option_parser['first_parameter'] = 1
    except:
        # An exception was raised
        exception_thrown = True

    # Evaluating the boolean expression (exception_thrown)
    if (exception_thrown):
        print('Exception was thrown')
    else:
        print('Exception was not thrown')


# Generated at 2022-06-22 04:09:05.710004
# Unit test for method as_dict of class OptionParser
def test_OptionParser_as_dict():
    from tornado.options import options, define
    define("port", default=8888, help="run on the given port", type=int)
    assert options.as_dict()["port"] == 8888



# Generated at 2022-06-22 04:09:09.832101
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    option_parser = OptionParser()
    option_parser.define("config", type=str, help="path to config file",
                   callback=lambda path: option_parser.parse_config_file(path, final=False))
    option_parser.parse_command_line("--config=config_test.py".split())
    assert option_parser.as_dict()["port"] == 80
    
    

# Generated at 2022-06-22 04:09:13.200008
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    _foo = OptionParser()
    _bar = iter(_foo)
    _foo_0 = next(_bar)
    assert isinstance(_foo_0, tuple)
    _foo_1 = next(_bar)
    assert isinstance(_foo_1, tuple)



# Generated at 2022-06-22 04:09:14.794359
# Unit test for method items of class OptionParser
def test_OptionParser_items():
    options = OptionParser()._items
    assert isinstance(options, dict)


# Generated at 2022-06-22 04:09:23.043565
# Unit test for method run_parse_callbacks of class OptionParser
def test_OptionParser_run_parse_callbacks():
    __tracebackhide__ = True
    opts = OptionParser()
    opts.define('port', default=80, callback=lambda x: print(x))
    opts.add_parse_callback(lambda: print(options.port))
    opts.run_parse_callbacks()
    tester = unittest.FunctionTestCase(test_OptionParser_run_parse_callbacks)
    unittest.TextTestRunner(verbosity=2).run(tester)

# Generated at 2022-06-22 04:09:25.256808
# Unit test for method items of class OptionParser
def test_OptionParser_items():
    op_1 = OptionParser()
    assert op_1.items() == {}


# Generated at 2022-06-22 04:09:38.431215
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    class Mock(object):
        def define(*args, **kwargs):
            pass

    m = Mock()
    options = tornado.options.OptionParser()
    options.define = m.define
    options.name = 1
    m.define.assert_called_with('name', 1, None, None, None, False, None, None)


# Generated at 2022-06-22 04:09:39.737046
# Unit test for function print_help
def test_print_help():
    options.add_parse_callback(lambda : None)
    print_help()



# Generated at 2022-06-22 04:09:52.692844
# Unit test for method __delattr__ of class _Mockable
def test__Mockable___delattr__():
    # Test _Mockable.__delattr__
    parser = OptionParser()
    parser.define('foo', default='bar')
    # Test that delattr in _Mockable deletes original value
    with mock.patch.object(parser.mockable(), 'foo', 42):
        pass
    assert parser.foo == 'bar', "delattr in _Mockable deletes original value"
    # Test that delattr in _Mockable reverts value to previous patch value
    mockable = parser.mockable()
    with mock.patch.object(mockable, 'foo', 42):
        with mock.patch.object(mockable, 'foo', 43):
            pass
    assert parser.foo == 43, "delattr in _Mockable reverts value to previous patch value"
    # Test that once a mockable object is used

# Generated at 2022-06-22 04:09:54.990749
# Unit test for constructor of class OptionParser
def test_OptionParser():
    parser = OptionParser()
    assert isinstance(parser, OptionParser)
    assert parser.options == {}
    assert parser.groups() == set()


# Generated at 2022-06-22 04:09:58.968363
# Unit test for method groups of class OptionParser
def test_OptionParser_groups():
    test_options = OptionParser()
    result = test_options.groups()
    assert isinstance(result,set), "Expected set got: " + str(type(result))


# Generated at 2022-06-22 04:10:09.911344
# Unit test for method __setitem__ of class OptionParser
def test_OptionParser___setitem__():
    t_OptionParser_v_testparser = None

    #from tornado.options import OptionParser 
    t_OptionParser_v_testparser = OptionParser()
    
    t_OptionParser_v_testparser.define("number", default=0, type=int) 
    
    # set the value of option in the following way #
    # testparser["number"] = 1 
    
    t_OptionParser_v_testparser.define("string", default="", type=str) 
    
    # set the value of option in the following way #
    # testparser["string"] = "something" 
    
    t_OptionParser_v_testparser.run_parse_callbacks()

    assert t_OptionParser_v_testparser["number"] == 1

# Generated at 2022-06-22 04:10:11.708593
# Unit test for method __getitem__ of class OptionParser
def test_OptionParser___getitem__():
    op = OptionParser()
    op.define("name", "Gene", type=str, help="Name of someone")
    assert op['name'] == "Gene"



# Generated at 2022-06-22 04:10:15.345197
# Unit test for constructor of class Error
def test_Error():
    try:
        raise Error
    except Error:
        pass

ERROR = (Error, re.error,)


# Generated at 2022-06-22 04:10:18.853803
# Unit test for constructor of class OptionParser
def test_OptionParser():
    opts = OptionParser()
    assert opts._options.keys() == set()
    assert opts._parse_callbacks == []


options = OptionParser()

define = options.define
parse_command_line = options.parse_command_line
parse_config_file = options.parse_config_file

# Generated at 2022-06-22 04:10:24.375799
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    import os
    import sys
    import time
    import platform
    from _tornado_options import (
        OptionParser,
        Error,
        _Option,
        _Mockable,
        _native_str,
    )
    from _tornado_util import import_object
    from typing import Any

    def parse_config_file(path, final=True):
        print('path:', path)
        print('final:', final)

    def print_help(
        self,
        file=None
    ):
        print('file:', file)

    callbacks = []

    # Initialize a OptionParser object, added a print_help method
    options = OptionParser()
    options.__class__.print_help = print_help
    
    # Define a common option and another option

# Generated at 2022-06-22 04:10:39.119496
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    verifyObject(IOptionParser, OptionParser())
    options = OptionParser()
    options.define("num", type=int, default=3)
    options.define("str", type=str, default="abc")
    options.define("bool", type=bool, default=True)
    args = options.parse_command_line(["--num", "2", "--str", "hello", "--no-bool"])
    assert options.num == 2
    assert options.str == "hello"
    assert not options.bool
    assert not args


# Generated at 2022-06-22 04:10:45.246546
# Unit test for function print_help
def test_print_help():
    options.add_option('-a', False, "", "", "", "")
    options.add_option('-b', True, "", "", "", "")
    options.add_option('-c', True, 'help this option print', "", "", "")
    options.print_help(None)


# Generated at 2022-06-22 04:10:47.197029
# Unit test for function define
def test_define():
    define("xxx", type=int, default=123)
    print(options.xxx)


# Generated at 2022-06-22 04:10:50.387381
# Unit test for function print_help
def test_print_help():
    from io import StringIO
    from contextlib import redirect_stdout
    f = StringIO()
    with redirect_stdout(f):
        print_help()
    return "Options:" in f.getvalue()

 

# Generated at 2022-06-22 04:10:56.776070
# Unit test for method set of class _Option
def test__Option_set():
    for i in range(10):
        o = _Option(
        name=_unicode('test_name'),
        default=[],
        type=list,
        help='',
        metavar=None,
        multiple=True,
        file_name=None,
        group_name=None,
        callback=None
        )
        logger.warning(o.multiple)


# Generated at 2022-06-22 04:11:04.620301
# Unit test for method parse of class _Option
def test__Option_parse():
    # name, default=None, type=None, help=None, metavar=None, multiple=False, file_name=None, group_name=None
    option = _Option("name")
    option.type = datetime.datetime
    for format in _Option._DATETIME_FORMATS:
        try:
            value = datetime.datetime.strptime(format, format)
            option.parse(format)
            assert value == option.value()
        except:
            assert False


# Generated at 2022-06-22 04:11:10.207197
# Unit test for method value of class _Option
def test__Option_value():
    # Declare a variable for _Option instance obj
    obj = _Option("name", None, None, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    # Set the value for obj._value
    obj._value = _Option.UNSET
    # Call the method value of obj
    _Option_value_ret = obj.value()
    # Assert _Option_value_ret is equal to obj.default
    assert _Option_value_ret == obj.default
    # Set the value for obj._value
    obj._value = None
    # Call the method value of obj
    _Option_value_ret = obj.value()
    # Assert _Option_value_ret is equal to obj._value
    assert _Option_value_ret == obj._value

#

# Generated at 2022-06-22 04:11:10.910114
# Unit test for method as_dict of class OptionParser
def test_OptionParser_as_dict():
    pass

# Generated at 2022-06-22 04:11:13.137559
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__(): 
    obj = OptionParser()
    # test the method __iter__ of class OptionParser
    obj.__iter__()


# Generated at 2022-06-22 04:11:21.103507
# Unit test for function parse_command_line
def test_parse_command_line():
    define('name', default=None, multiple=True, type=str, help='name')
    argv = ["mypy", "--name", "Mike", "test1", "test2"]
    left = parse_command_line(argv)
    assert left == ["test1", "test2"]
    assert options.name is not None
    assert options.name == ["Mike"]



# Generated at 2022-06-22 04:11:39.060166
# Unit test for constructor of class OptionParser
def test_OptionParser():

    parser = OptionParser()

    assert parser is not None


# Generated at 2022-06-22 04:11:42.516116
# Unit test for method __contains__ of class OptionParser
def test_OptionParser___contains__():
    import tornado.options

    options = tornado.options.OptionParser()
    expected = False
    result = ('port' in options)
    assert result == expected
    expected = True
    result = ('define' in options)
    assert result == expected

# Generated at 2022-06-22 04:11:55.240387
# Unit test for method mockable of class OptionParser
def test_OptionParser_mockable():
  import unittest
  class TestMockable(unittest.TestCase):
    def setUp(self):
      pass
    def tearDown(self):
      pass
    def test_options_mockable(self, mockable):
        with mock.patch.object(mockable, 'name', value):
            assert options.name == value
    def test_options_mockable(self):
        with mock.patch.object(mockable, 'name', value):
            assert options.name == value
    def test_options_mockable(self):
        with mock.patch.object(mockable, 'name', value):
            assert options.name == value
    def test_options_mockable(self):
        with mock.patch.object(mockable, 'name', value):
            assert options.name

# Generated at 2022-06-22 04:11:58.047686
# Unit test for method __getitem__ of class OptionParser
def test_OptionParser___getitem__():
    op = OptionParser()
    op._options = {
        'a' : '1',
        'b' : '2'
    }
    assert op['a'] == '1'
    assert op['b'] == '2'

# Generated at 2022-06-22 04:12:09.233243
# Unit test for method items of class OptionParser
def test_OptionParser_items():
    parser = OptionParser()
    parser.define("foo", default=10, type=int)
    parser.define("foo2", default=20, type=int)
    assert list(parser.items()) == [("foo", 10), ("foo2", 20)]
    parser = OptionParser(namespace=Options())
    parser.define("foo", default=10, type=int)
    parser.define("foo2", default=20, type=int)
    assert list(parser.items()) == [("foo", 10), ("foo2", 20)]
    ns = Options()
    ns.foo = 42
    parser = OptionParser(namespace=ns)
    parser.define("foo", default=10, type=int)
    parser.define("foo2", default=20, type=int)

# Generated at 2022-06-22 04:12:16.997692
# Unit test for method __getitem__ of class OptionParser
def test_OptionParser___getitem__():
    opt = options
    opt.define("a", type=int, default=1, help="A")
    opt.define("b", type=int, default=2, help="B")
    opt.define("c", type=int, default=3, help="C")
    assert opt["a"] == 1
    opt.a = 5
    assert opt["a"] == 5
    assert opt["b"] == 2
    assert opt["c"] == 3
    assert opt.a == 5
    assert opt.b == 2
    assert opt.c == 3
    opt.parse_command_line([])
    assert opt["a"] == 1
    assert opt["b"] == 2
    assert opt["c"] == 3
    assert opt.a == 1
    assert opt.b == 2
    assert opt.c == 3
    opt.parse_

# Generated at 2022-06-22 04:12:29.387068
# Unit test for method group_dict of class OptionParser
def test_OptionParser_group_dict():
    global _Value
    global _Function
    _Value = 0
    _Function = None
    def _function_def_a():
        global _Value
        global _Function
        _Value = 1
        _Function = 'a'
    def _function_def_b():
        global _Value
        global _Function
        _Value = 10
        _Function = 'b'


# Generated at 2022-06-22 04:12:31.644708
# Unit test for method groups of class OptionParser
def test_OptionParser_groups():
    with pytest.raises(NotImplementedError):
        options = OptionParser()
        options.groups()


# Generated at 2022-06-22 04:12:35.870495
# Unit test for function parse_config_file
def test_parse_config_file():
    '''
    Test for parse_config_file()
    '''

# Generated at 2022-06-22 04:12:41.746631
# Unit test for method print_help of class OptionParser
def test_OptionParser_print_help():
    import tornado.options

    parser = OptionParser()
    parser.define("foo", type=str, help="hello foo")
    parser.define("bar", type=str, help="hello bar")
    output = str(parser.print_help())
    assert "Options:" in output
    assert "--foo=METAVAR" in output
    assert "--bar=METAVAR" in output

# Generated at 2022-06-22 04:13:28.735135
# Unit test for method __contains__ of class OptionParser
def test_OptionParser___contains__():
  options = OptionParser()
  options['name'] = 'value'
  assert 'name' in options
  assert 'notname' not in options


# Generated at 2022-06-22 04:13:30.174441
# Unit test for function parse_command_line
def test_parse_command_line():
    global options
    options.define("port", default=8080, type=int, help="Port to run on")
    options.parse_command_line(["--port=9000"])
    assert options.port == 9000

# Generated at 2022-06-22 04:13:42.794646
# Unit test for method groups of class OptionParser
def test_OptionParser_groups():
    # First define some options
    define("option_a", default=None, type=str, help="str option")
    define("option_b", default=1, type=int, help="int option")
    define("option_c", default=2.0, type=float, help="float option")
    define("option_d", default=True, help="bool option")
    define("option_e", default=datetime.time(), help="datetime.time option")
    define("option_f", default=timedelta(seconds=10), help="timedelta option")

    # Now use groups
    define("option_1", default=None, type=str, help="str option", group="a")
    define("option_2", default=1, type=int, help="int option", group="b")

# Generated at 2022-06-22 04:13:43.892162
# Unit test for constructor of class OptionParser
def test_OptionParser():
    options = OptionParser()


# Generated at 2022-06-22 04:13:50.647550
# Unit test for method __delattr__ of class _Mockable
def test__Mockable___delattr__():
    self._options.someattr = self._options.someattr+1
    _originals = {"someattr": self._options.someattr+1}
    self.assertEqual(self._options.someattr, _originals["someattr"]+1)
    with mock.patch.object(self._options, 'someattr', _originals["someattr"]):
       self.assertEqual(self._options.someattr, _originals["someattr"])



# Generated at 2022-06-22 04:13:53.936690
# Unit test for function parse_command_line
def test_parse_command_line():
    """
    Args:
        args (Optional(List[str])): list of args
        final (bool): bool type

    ::

        >>> def test_parse_command_line():
        ... options.define("--option1")
        ... options.define("--option2")
        ... parse_command_line(args=['--option1', '1', '--option2', '2', 'a', 'b', 'c'])
        ... assert options.option1 == 1
        ... assert options.option2 == 2
        ... assert options.arguments == ['a', 'b', 'c']
    """
    pass

# Generated at 2022-06-22 04:14:06.044588
# Unit test for constructor of class _Option
def test__Option():
    with pytest.raises(ValueError) as e:
        _Option("name", None)
    assert "type must not be None" in str(e.value)

    with pytest.raises(ValueError) as e:
        _Option("name", None, type=int)
    assert "default must not be None" in str(e.value)

    with pytest.raises(ValueError) as e:
        _Option("name", None, type=int, multiple=True)
    assert "default must not be None" in str(e.value)

    with pytest.raises(ValueError) as e:
        _Option("name", None, type=str, multiple=True)
    assert "default must not be None" in str(e.value)


# Generated at 2022-06-22 04:14:19.449457
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    try:
        from pathlib import Path
    except ImportError:
        Path = None
    if Path is None:
        return

    options = _OptionParser()
    options.define("foo", type=str, help="foo help")
    options.define("bar", type=int, help="bar help")
    txt = r"""
__file__ = '{}'
foo = "foo value"
bar = 100
"""
    with temporary_file(encoding="utf-8") as f:
        with open(f, "w") as fp:
            fp.write(txt.format(f))
        options.parse_config_file(f)
    assert options.foo == "foo value"
    assert options.bar == 100


# Generated at 2022-06-22 04:14:21.709025
# Unit test for function parse_command_line
def test_parse_command_line():
    from pytype.pytd import config

    def set_foo(option):
      config.foo = option

    define("foo", type=int, callback=set_foo, help="set foo")
    parse_command_line(args=["--foo=10"])
    assert config.foo == 10
  # /home/travis/build/google/pytype/pytype/pytype/pyi/config.py:251

# Generated at 2022-06-22 04:14:25.232674
# Unit test for method run_parse_callbacks of class OptionParser
def test_OptionParser_run_parse_callbacks():
    opts = _OptionParser()
    opts.add_parse_callback(lambda: None)
    opts.run_parse_callbacks()
