

# Generated at 2022-06-22 04:07:00.972333
# Unit test for method value of class _Option
def test__Option_value():
    option1_1 = _Option("a", default='1')
    assert option1_1.value() == '1'
    option1_2 = _Option("a", default='1')
    assert option1_2.value() == '1'
    option2 = _Option("b", default='2')
    assert option2.value() == '2'
    assert option1_1.value() == option1_2.value()


# Generated at 2022-06-22 04:07:05.227936
# Unit test for method __contains__ of class OptionParser
def test_OptionParser___contains__():
    obj = OptionParser()
    assert "str" in obj == False
    assert "str" not in obj == True

# Generated at 2022-06-22 04:07:09.785485
# Unit test for method group_dict of class OptionParser
def test_OptionParser_group_dict():
    o = OptionParser()
    o.define("a", type=str, default='abc', group='test1')
    o.define("b", type=str, default='abc', group='test2')
    # This test is only for options with group, use assertEqual
    assert o.group_dict('test1') == {'a': 'abc'}
    assert o.group_dict('test2') == {'b': 'abc'}


# Generated at 2022-06-22 04:07:14.261715
# Unit test for method __getitem__ of class OptionParser
def test_OptionParser___getitem__():
    parser = OptionParser()
    parser.define('name')
    assert parser['name'] == parser.name




# Generated at 2022-06-22 04:07:28.379526
# Unit test for function add_parse_callback
def test_add_parse_callback():
    with mock.patch.object(options, "run_parse_callbacks") as run_parse_callbacks:
        options.add_parse_callback(run_parse_callbacks)
    options.run_parse_callbacks()
    assert run_parse_callbacks.call_count == 1



# Generated at 2022-06-22 04:07:29.501316
# Unit test for function parse_config_file
def test_parse_config_file():
    a =  parse_config_file('test_parse_config_file.cfg', final = True)


# Generated at 2022-06-22 04:07:36.750770
# Unit test for method __contains__ of class OptionParser
def test_OptionParser___contains__():
    # Create an instance of class OptionParser
    test_class = OptionParser(
        env_prefix="TEST"
    )

    # get args
    args = map_OptionParser_contains()

    # Call the method __contains__ with its present input parameters
    answer = test_class.__contains__(**args)

    # Check the expected and the returned result
    assert 3 == answer[0]


# Generated at 2022-06-22 04:07:42.232004
# Unit test for method add_parse_callback of class OptionParser
def test_OptionParser_add_parse_callback():
    print(sys._getframe().f_code.co_name)

    def _test_callback():
        print("callback called")

    opts = OptionParser()
    opts.add_parse_callback(_test_callback)
    opts.run_parse_callbacks()



# Generated at 2022-06-22 04:07:46.089458
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    opt = OptionParser()
    opt.define("foo", type=int)
    mockable = _Mockable(opt)
    mockable.__setattr__("foo", 123)
    assert opt.foo == 123


# Generated at 2022-06-22 04:07:52.157813
# Unit test for method print_help of class OptionParser
def test_OptionParser_print_help():
    option_parser = OptionParser()
    option_parser.define('name',default='zhanglian',type=str,help='option name',metavar=None,multiple=False,group=None,callback=None)
    option_parser.print_help()


# Generated at 2022-06-22 04:08:16.351843
# Unit test for constructor of class OptionParser
def test_OptionParser():
    #pylint: disable=no-member
    parser = OptionParser()
    parser.define('name', 'default value')
    parser.define('bool_option', default=True)
    parser.define('int_option', default=1)
    parser.define('float_option', default=2.0)
    parser.define('string_option', default='default value')
    parser.define('list_option', type=list)
    parser.define('dict_option', type=dict)
    parser.define('datetime_option', type=datetime.datetime)
    parser.define('timedelta_option', type=datetime.timedelta)

    assert parser.name == 'default value'
    assert parser.bool_option is True
    assert parser.int_option == 1
    assert parser.float_option == 2.

# Generated at 2022-06-22 04:08:20.953913
# Unit test for method set of class _Option
def test__Option_set():
    o = _Option('test', type=int, multiple=True)
    o.set(4)
    o.set(5)
    assert o.value()==5
    assert o.multiple==True
    assert o.type==int


# Generated at 2022-06-22 04:08:27.575196
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    print('>>>>>')
    print('test__Mockable___setattr__')
    m = _Mockable(None)
    m.a = 1
    assert m.a == 1
    m.a = 2
    assert m.a == 2
    del m.a
    assert not hasattr(m, 'a')
    print('<<<<<')


# Generated at 2022-06-22 04:08:30.855347
# Unit test for method __getattr__ of class _Mockable
def test__Mockable___getattr__():
    check_equal(1, test_class__Mockable1._Mockable___getattr__())

# Generated at 2022-06-22 04:08:36.201691
# Unit test for function print_help
def test_print_help():
    expected = '''
Usage: test_options.py [OPTIONS]

Options:

  --with-boolean=          (default True)
  --with-callback=         (default None)
  --with-default=          (default foo)
  --with-flag              (default None)
  --with-help=             (default None)
  --with-metavar=ARG=      (default None)
  --with-multiple=         (default None)
  --with-negatable         (default None)
  --with-not-configurable  (default None)
  --with-positional=       (default None)
'''
    # Since we can't capture stdout, we'll just check for the expected output anywhere
    # in the output call.
    stdout = sys.stdout

# Generated at 2022-06-22 04:08:39.980534
# Unit test for constructor of class OptionParser
def test_OptionParser():
    with OptionParser() as parser:
        parser.parse_command_line(['server.py', '--logging=debug'])
    assert logging.getLevelName(logging.getLogger().getEffectiveLevel()) == "DEBUG"



# Generated at 2022-06-22 04:08:45.307215
# Unit test for method __getitem__ of class OptionParser
def test_OptionParser___getitem__():
    options = OptionParser()
    assert isinstance(options, OptionParser)

    options.define(
        "a",
        default="b",
        type=str,
        help="help",
        group="g",
        callback=None
    )

    assert options["a"] == "b"
    try:
        options["d"]
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-22 04:08:56.432606
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    import doctest
    import tornado.options
    import mock
    import unittest
    import unittest.mock

    mock_type = unittest.mock.MagicMock()

    mock_value = unittest.mock.MagicMock()

    mock_type.assert_called_with(mock_value)

    mock_get_value = unittest.mock.MagicMock(return_value=mock_value)

    mock_name = unittest.mock.MagicMock(name='name')

    mock_name_obj = unittest.mock.MagicMock(name=mock_name)

    mock_name_obj.configure_mock(**{'get_value.return_value': mock_get_value})


# Generated at 2022-06-22 04:09:06.693115
# Unit test for method __setitem__ of class OptionParser
def test_OptionParser___setitem__():
    import sys
    import tornado.options
    import unittest

    class __():
        """
        A dummy class to mock 'tornado.options.Error' because
        'unittest.mock.patch' can't mock classes directly.
        """
        def __init__(self) -> None:
            def __():
                raise tornado.options.Error()
            self.__ = __
        '''
        Raise Tornado option error.

        :raises tornado.options.Error: Option parsing error.
        '''
    class _():
        """
        A dummy class to mock 'sys._getframe' because 'unittest.mock.patch'
        can't mock modules directly.
        """

# Generated at 2022-06-22 04:09:10.158378
# Unit test for method __contains__ of class OptionParser
def test_OptionParser___contains__():
    options = None
    try:
        options = OptionParser()
        options.define(
            'name',
            default='',
            help='name'
        )
        assert options.__contains__('name') == True
    finally:
        options.free()


# Generated at 2022-06-22 04:13:21.164332
# Unit test for method add_parse_callback of class OptionParser
def test_OptionParser_add_parse_callback():
    """
    Unit test for method add_parse_callback of class OptionParser
    """
    options = OptionParser()
    options.define("a", default=4)
    def fun():
        assert(options.a == 3)
    options.add_parse_callback(fun)
    options.parse_command_line(['--a=3'])



# Generated at 2022-06-22 04:13:32.899220
# Unit test for method __delattr__ of class _Mockable
def test__Mockable___delattr__():
    with OptionParser() as parser:
        parser.define("name1", type=str)
        parser.define("name2", type=str)
        mockable = _Mockable(parser)
        setattr(mockable, "name1", "value1")
        setattr(mockable, "name2", "value2")
        delattr(mockable, "name1")
        assert not hasattr(parser, "name1")
        assert parser.name2 == "value2"


# This deprecation strategy is incompatible with the `deprecated`
# decorator in `__init__` but is more robust when the function being
# deprecated is called by many functions that are not themselves
# deprecated.  It also allows us to give a more specific deprecation
# message.

# Generated at 2022-06-22 04:13:35.900136
# Unit test for method __contains__ of class OptionParser
def test_OptionParser___contains__():
    options = OptionParser()
    options.define("name", default=None, type=str)
    assert 'name' in options


# Generated at 2022-06-22 04:13:48.469618
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    from tornado.options import define, parse_command_line, options
    define('test_options_parser_name', default=None, type=str, help='test_options_parser_name')
    define('test_options_parser_int', default=1, type=int, help='test_options_parser_int')
    define('test_options_parser_float', default=1.1, type=float, help='test_options_parser_float')
    define('test_options_parser_bool', default=True, type=bool, help='test_options_parser_bool')
    define('test_options_parser_timedelta', default=None, type=Timedelta, help='test_options_parser_timedelta')

# Generated at 2022-06-22 04:13:52.104405
# Unit test for method group_dict of class OptionParser
def test_OptionParser_group_dict():
    # OptionParser.group_dict()
    _OptionParser.group_dict()
    # OptionParser.group_dict(group)
    _OptionParser.group_dict(group='application')
test_OptionParser_group_dict()


# Generated at 2022-06-22 04:14:04.058770
# Unit test for method __delattr__ of class _Mockable
def test__Mockable___delattr__():
    def test_name_value(name: str, value: Any):
        options = OptionParser()
        name = 'port'
        options.define('port', 80)
        assert options.port == 80
        mockable = _Mockable(options)
        setattr(mockable, name, value)
        assert options.port != 80
        delattr(mockable, name)
        assert options.port == 80
    def test_name(name: str):
        def test_value(value: Any):
            test_name_value(name, value)
        value = 8080
        test_value(value)
    name = 'port'
    test_name(name)

# Generated at 2022-06-22 04:14:10.845941
# Unit test for method items of class OptionParser
def test_OptionParser_items():
    opts = OptionParser()
    opts.define("opt1")
    opts.define("opt2")
    opts.define("opt3")
    actual = list(opts.items())
    expected = [
        ("opt1", opts._options['opt1']),
        ("opt2", opts._options['opt2']),
        ("opt3", opts._options['opt3'])
    ]
    assert actual == expected

# Generated at 2022-06-22 04:14:19.908846
# Unit test for method items of class OptionParser
def test_OptionParser_items():
    mock_args = ["test.py", "--test_arg", "test_value"]
    mock_parser = OptionParser()
    mock_parser.define("test_arg", default=None, type=str)
    mock_parser.parse_command_line(args=mock_args)
    mock_result = {}
    for name, value in mock_parser.items():
        mock_result[name] = value
    assert mock_result == {'test_arg': 'test_value'}


# Generated at 2022-06-22 04:14:27.796820
# Unit test for method groups of class OptionParser
def test_OptionParser_groups():
    """Test for OptionParser.groups"""
    op = OptionParser()
    # NOTE(pcsforeducation) - Need to use other methods of this class
    # to iniatiate it before method groups can be used.
    op.define('name1')
    op.define('name2')
    op.define('name3')
    print('op.groups()', op.groups())



# Generated at 2022-06-22 04:14:39.997495
# Unit test for function print_help
def test_print_help():
    import io
    import sys
    import tempfile
    import unittest
    import types

    class TestPrintHelp(unittest.TestCase):
        def setUp(self):
            # Set up read-only attributes on options, so that the
            # help text is the same regardless of version.
            def forward(self, name):
                return getattr(options, name)

            options.__class__.__getattr__ = types.MethodType(forward, options)

            # The options._options[name] attributes are also read-only,
            # and we don't want to break that for other tests, so we
            # have to make a copy here.
            self.options = options.__class__()
            self.options._options = dict(options._options)

            self.temp_file = tempfile.TemporaryFile()
           