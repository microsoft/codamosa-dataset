

# Generated at 2022-06-22 04:07:23.406279
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    class _FakeOptionParser(object):
        def __getattr__(self, name):
            return getattr(self, name)
        def __setattr__(self, name, value):
            return setattr(self, name, value)
    _FakeOptionParsers = _FakeOptionParser()
    _Mockable._options = _FakeOptionParsers
    _Mockable._originals = {}
    _Mockable.__setattr__(name = 'name', value = 'value')
    assert _Mockable.__getattr__(name = 'name') == 'value'
    assert _Mockable._originals['name'] == getattr(_FakeOptionParsers, 'name')
    assert _Mockable.__delattr__(name = 'name') == None


# Generated at 2022-06-22 04:07:31.382933
# Unit test for method as_dict of class OptionParser
def test_OptionParser_as_dict():
    # Test for as_dict method in OptionParser class
    import unittest
    from tornado.options import define, options, OptionParser

    define("test", default=100)
    define("test2", default=100)

    # Test for as_dict method defined in OptionParser class
    class TestOptionParser(unittest.TestCase):
        def test_as_dict(self):
            self.assertEqual(options.as_dict(), {"test": 100, "test2": 100})
    # Run unittest
    unittest.main()
    

# Generated at 2022-06-22 04:07:44.994882
# Unit test for method as_dict of class OptionParser
def test_OptionParser_as_dict():
    from tornado.options import options, define
    define("port", default=60000, type=int, help="port to listen on")
    define("address", default="localhost", help="Ip at which the server listens")
    define("app", default="", help="app")
    define("static_path", default=os.path.join(os.path.dirname(__file__), "static"), help="Path to static files")
    define("template_path", default=os.path.join(os.path.dirname(__file__), "templates"), help="Path to templates")
    define("database", default="test", help="Database name")
    define("dbuser", default="test", help="Database user")
    define("debug", default=False, help="Run in debug mode")


# Generated at 2022-06-22 04:07:52.552364
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    parser = OptionParser()
    parser.define("name1")
    parser.define("name2")
    parser.define("name3")
    parser.define("name4")
    parser.define("name5")
    args = parser.parse_command_line(
        ['prog_name', '--name1=val1', '--name2=val2', '--name5=val5']
    )
    test_assert_equal(args, [])
    test_assert_equal(parser.name1, 'val1')
    test_assert_equal(parser.name2, 'val2')
    test_assert_equal(parser.name3, None)
    test_assert_equal(parser.name4, None)
    test_assert_equal(parser.name5, 'val5')



# Generated at 2022-06-22 04:07:57.628602
# Unit test for constructor of class _Mockable
def test__Mockable():
    mockable = _Mockable(None)
    mockable.one = 1
    assert mockable.one == 1
    mockable.two = 2
    assert mockable.two == 2
    del mockable.one
    assert hasattr(mockable, "one") == False
    del mockable.two
    assert hasattr(mockable, "two") == False


# Generated at 2022-06-22 04:08:04.523958
# Unit test for constructor of class Error
def test_Error():
    e = Error()


# Data structures
# ===============
#
# Options are stored in a dictionary named ``_options``, indexed by
# name.  An entry in the dictionary is itself a dictionary containing
# several pieces of information about the option:
#
#   - default: default value for the option, or None if no default
#   - type: option type, for argument parsing and type-checking
#   - metavar: name for the argument in usage messages
#   - callback: function to call when the option is set
#   - help: help string, for usage messages
#   - nargs: number of arguments the option takes
#   - multiple: can option be specified multiple times?
#
# The special argument "--help" is handled specially.  It is added
# automatically and only if no option with the same name has been defined
# explicitly. 

# Generated at 2022-06-22 04:08:05.632476
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    pass # No functional test



# Generated at 2022-06-22 04:08:17.274437
# Unit test for function add_parse_callback
def test_add_parse_callback():
    global options
    options = OptionParser()
    options.define("foo", default=None)
    options.define("bar", default=None)
    options.define("baz", default=None)

    def callback1() -> None:
        print("callback1")
        foo = options.foo
        bar = options.bar
        if foo is None and bar is None:
            raise Exception("callback1")

    def callback2() -> None:
        print("callback2")
        baz = options.baz
        if baz is None:
            raise Exception("callback2")

    options.add_parse_callback(callback1)
    options.add_parse_callback(callback2)
    options.parse_argv(sys.argv[:1])


# Generated at 2022-06-22 04:08:21.191673
# Unit test for function define
def test_define():
    options.define("test_define", type=int, default=1, help="help")
    # print(options)
    assert options.test_define == 1



# Generated at 2022-06-22 04:08:33.540405
# Unit test for method add_parse_callback of class OptionParser
def test_OptionParser_add_parse_callback():
    from tornado.escape import utf8
    from tornado.options import define, options
    define("package", type=str, help="package to use")
    define("verbose", type=bool, help="turn on verbose logging")


    def set_logging_level():
        # print(options.verbose)
        level = logging.DEBUG if options.verbose else logging.INFO
        logger = logging.getLogger("peewee")
        logger.setLevel(level)
        logger.debug("set logging level to %d", level)

    options.add_parse_callback(set_logging_level)


    # print(set_logging_level())
    options.parse_command_line()
    # print(options.verbose)
    # print(options.package)


# Generated at 2022-06-22 04:08:48.812280
# Unit test for function define
def test_define():
    define("name", str,'futeng')
    print(options.name)
    import inspect
    print(inspect.getmembers(options))

if __name__ == "__main__":
    test_define()

# Generated at 2022-06-22 04:08:55.681178
# Unit test for method mockable of class OptionParser
def test_OptionParser_mockable():
    # Unit test of:
    #   Tornado options.OptionParser.mockable()
    # Function mockable should return an object that can be used with
    # mock.patch.object.  This is a regression test for
    # https://github.com/tornadoweb/tornado/issues/2432.
    parser = OptionParser()
    parser.define('settable', type=bool, default=False)
    with pytest.raises(SystemExit):
        with mock.patch.object(parser.mockable(), 'settable', True):
            parser.parse_command_line([sys.argv[0]])



# Generated at 2022-06-22 04:09:04.712736
# Unit test for method mockable of class OptionParser
def test_OptionParser_mockable():
    import unittest.mock as mock
    import tornado.ioloop
    options.parse_command_line()
    with mock.patch.object(options.mockable(), 'foo', 42):
        assert options.foo == 42
    # don't want to leave stale option values lying around
    options.reset(ioloop=tornado.ioloop.IOLoop.current())


# class OptionParser
test()

# The exported instance of OptionParser
options = OptionParser()

# Variable __all__ :
__all__ = [
    "Error",
    "options",
    "defines",
    "parse_command_line",
    "define",
    "help"
]

# Generated at 2022-06-22 04:09:06.111765
# Unit test for function define
def test_define():
    define("define_test",default=5,type=int,help="define test",metavar="test",multiple=False,group="test",callback=test_callback)
    assert options.define_test == None


# Generated at 2022-06-22 04:09:06.878800
# Unit test for function define
def test_define():
    define("name", str, "", "xxx")


# Generated at 2022-06-22 04:09:09.955754
# Unit test for method set of class _Option
def test__Option_set():
    options = _Option('name', None, bool, 'help', 'metavar', False, None, None, None)
    value = True
    options.set(value)
    assert getattr(options, '_value') == value


# Generated at 2022-06-22 04:09:15.243700
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    parser = OptionParser()
    parser.define("name", type=str, help="Your name", callback=None, group=None)
    parser.define("foo", type=str, help="Your foo", callback=None, group=None)
    parser.__setattr__("name", "Jiaqi")
    parser.__setattr__("foo", "bar")
    assert(parser.name == "Jiaqi")
    assert(parser.foo == "bar")

# Generated at 2022-06-22 04:09:21.263151
# Unit test for method __getattr__ of class _Mockable
def test__Mockable___getattr__():
    class _MockableSubclass(_Mockable):
        def __init__(self, options: OptionParser) -> None:
            super().__init__(options)

    mock = _MockableSubclass(OptionParser())
    assert mock.__getattr__("async_mode") == DEFAULT_ASYNC_MODE



# Generated at 2022-06-22 04:09:34.271719
# Unit test for method items of class OptionParser
def test_OptionParser_items():
    import os
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, gen_test, bind_unused_port

    AsyncIOMainLoop().install()

    _Loader().load(["python"])  # make sys.argv copy

    class FooTestCase(AsyncTestCase):
        def setUp(self):
            super(FooTestCase, self).setUp()
            define("name", default=None, type=str, help="Name of this app", metavar="NAME")
            define("port", default=None, type=int, help="Port to listen on", metavar="PORT")
            define("debug", default=None, type=bool, help="Turn on autoreload")

# Generated at 2022-06-22 04:09:40.438091
# Unit test for method __delattr__ of class _Mockable
def test__Mockable___delattr__():
    options = OptionParser()
    mock = _Mockable(options)
    setattr(mock, "test_del_attr", 123)
    assert hasattr(options, "test_del_attr")
    delattr(mock, "test_del_attr")
    assert not hasattr(options, "test_del_attr")

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-22 04:10:35.806124
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    parser = OptionParser()
    x = parser.define('x')
    assert x.name == 'x'
    parser.x = 1
    assert parser.x == 1



# Generated at 2022-06-22 04:10:44.676030
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    # Note that define is a class method of OptionParser.
    # So, we should initialize an object of OptionParser before defining an option.
    # TO-DO:
    # 1. Update the code (add more lines) to avoid the error 'unbound method m() must be called with A instance as first argument (got nothing instead)'.
    # 2. Write more unit tests to test the method.
    pass

# Generated at 2022-06-22 04:10:56.901358
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    options.define("name", default="world", help="name to say hello to")
    assert options.name == "world"
    options.parse_command_line([
        "--name=foo",
        "--version",
        ], final=False)
    assert "name" in options
    assert "name" in options._options
    assert options._options["name"].value() == "foo"
    assert options.name == "foo"
    assert options._options["name"].name == "name"
    assert options._options["name"].type is str
    assert options._options["name"].help == "name to say hello to"
    assert options._options["name"].metavar == None
    assert options._options["name"].multiple == False
    assert options._options["name"].group_name == ""
    assert options._

# Generated at 2022-06-22 04:11:09.578464
# Unit test for method set of class _Option
def test__Option_set():
    import logging
    import unittest
    from tornado import options
    from tornado import testing
    from tornado.testing import unittest

    class OptionTests(unittest.TestCase):
        def test_set_valid(self):
            option = options._Option('name', type=int, default=42)
            option.set(99)
            self.assertEqual(option.value(), 99)
            self.assertTrue(isinstance(option.value(), int))

        def test_set_invalid(self):
            option = options._Option('name', type=int, default=42)
            with self.assertRaises(options.Error):
                option.set('x')

        def test_set_callback(self):
            flag = []

            def set_flag():
                flag.append(True)

            option = options

# Generated at 2022-06-22 04:11:11.498153
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
	iter_options = iter(options)
	assert iter_options == options._options
	

# Generated at 2022-06-22 04:11:24.976789
# Unit test for constructor of class _Mockable
def test__Mockable():
    options = OptionParser()
    options.define("foo", type=str)
    m = _Mockable(options)
    m.foo = "bar"
    assert options.foo == "bar"
    del m.foo
    assert options.foo == ""
    m.foo = "baz"
    assert options.foo == "baz"
    del m
    # Verify that the original value is still set.
    assert options.foo == ""
    # Make sure that a second del won't restore the old value
    m = _Mockable(options)
    m.foo = "baz"
    del m
    del m
    assert options.foo == "baz"
    # Make sure that a second setattr doesn't clobber the old value
    m = _Mockable(options)

# Generated at 2022-06-22 04:11:38.462009
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    # Basic functionality test
    d = {
        "hello" : 1,
        "world" : 2,
    }
    assert Options.define("name") == None
    assert Options.define("name", default=0) == None
    assert Options.define("name", default=0, type=int) == None
    assert Options.define("name", default=0, type=int, help="arg") == None
    assert Options.define("name", default=0, type=int, help="arg", metavar="m") == None
    assert Options.define("name", default=0, type=int, help="arg", metavar="m", multiple=True) == None
    assert Options.define("name", default=0, type=int, help="arg", metavar="m", multiple=True, group="g") == None

# Generated at 2022-06-22 04:11:47.346071
# Unit test for function parse_command_line
def test_parse_command_line():
    import tempfile
    import unittest
    import unittest.mock

    def create_file(filename, contents):
        with open(filename, "w") as f:
            f.write(contents)

    def create_config_file():
        # Create a temporary directory and a temp file inside it
        temp_config_dir = tempfile.TemporaryDirectory(prefix="mypy")
        temp_config_file = tempfile.NamedTemporaryFile(
            prefix="mypy-config", suffix=".cfg", dir=temp_config_dir.name, delete=False
        )
        return temp_config_file


# Generated at 2022-06-22 04:11:59.684228
# Unit test for function parse_config_file
def test_parse_config_file():
    use_plugins = [0]
    def use_plugin():
        use_plugins[0] += 1
    options.define("foo", default=42, type=int)
    options.define("bar", default="spam", type=str)
    options.define("baz", default=False, type=bool)
    options.define("wibble", default=None, type=float)
    options.define("waldo", type=str, multiple=True, callback=use_plugin)
    options.define("fred", type=int, multiple=True)
    options.define(
        "xxx",
        default=datetime.timedelta(seconds=42), type=datetime.timedelta
    )
    options.define("yyy", default=datetime.datetime.utcnow(), type=datetime.datetime)
   

# Generated at 2022-06-22 04:12:01.020510
# Unit test for constructor of class OptionParser
def test_OptionParser():
    options = OptionParser()
    assert options



# Generated at 2022-06-22 04:12:45.384666
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    option_parser = OptionParser()
    option_parser.define("foo", type=str, help="", metavar="")
    option_parser.parse_config_file("tests/fixtures/option_parser.conf")
    assert option_parser.foo == "foo"


# Generated at 2022-06-22 04:12:46.582984
# Unit test for constructor of class Error
def test_Error():
    try:
        raise Error("test")
    except Error:
        pass



# Generated at 2022-06-22 04:12:47.552656
# Unit test for function print_help
def test_print_help():
    print_help(sys.stdout)
    print_help(sys.stderr)

test_print_help()


# Generated at 2022-06-22 04:12:50.169034
# Unit test for function add_parse_callback
def test_add_parse_callback():
    global callback
    callback = True
    def test_add_parse_callback_callback():
        global callback
        callback = False
    add_parse_callback(test_add_parse_callback_callback)
    run_parse_callbacks()
    assert callback == False

# Generated at 2022-06-22 04:12:50.878700
# Unit test for method __getattr__ of class _Mockable
def test__Mockable___getattr__():
    pass



# Generated at 2022-06-22 04:12:59.867046
# Unit test for method __getitem__ of class OptionParser
def test_OptionParser___getitem__():
    import unittest.mock
    op = _OptionParser()
    with unittest.mock.patch('tornado.options._OptionParser.define'):
        op.define(name = 'port', type = int)
    assert type(op['port']) == int
    try:
        op['port2']
        assert False
    except KeyError:
        pass
    assert op.port == 0
    op['port'] = 1
    assert op.port == 1


# Generated at 2022-06-22 04:13:04.530423
# Unit test for method __getattr__ of class OptionParser
def test_OptionParser___getattr__():
    print("Test OptionParser.__getattr__...")
    options = OptionParser()
    options.define("name", type=str, default="default_name", help="This is test")
    options.parse_command_line(['--name=new_name'], final=True)
    assert options.name == 'new_name'


# Generated at 2022-06-22 04:13:10.701478
# Unit test for function define
def test_define():
    from tornado.options import options
    from tornado.options import define

    define('foo', default='hello world', help='test', type=str)
    define('bar', default='goodbye world', help='test', type=str)
    options.parse_config_file('test.conf')
    assert options.foo == 'hello world'
    assert options.bar == 'goodbye world'


# Generated at 2022-06-22 04:13:12.384661
# Unit test for method __setitem__ of class OptionParser
def test_OptionParser___setitem__():
    assert 1 == 1
    assert 1 == 1


# Generated at 2022-06-22 04:13:22.740202
# Unit test for method parse of class _Option
def test__Option_parse():
    from datetime import datetime, timedelta
    from unittest import mock
    def test_parse(option, value, expected):
        parser = mock.Mock(spec=OptionParser)
        option = _Option(name="test", default=None, type=type(expected))
        result = option.parse(value)
        if isinstance(expected, datetime):
            assert result == expected
        elif isinstance(expected, timedelta):
            assert result == expected
        else:
            assert result == expected
    
    test_parse(
        option=_Option(name="test", default=None, type=datetime),
        value="Tue May 01 20:11:31 2018",
        expected=datetime(2018, 5, 1, 20, 11, 31),
    )
    

# Generated at 2022-06-22 04:13:51.431439
# Unit test for function add_parse_callback
def test_add_parse_callback():
    def callback():
        assert options.store_true_value == "store_true"
        assert options.mock_option == "mock"
    options.define("store_true_value", default="undefined", type=str)
    options.define("mock_option", default="", type=str)
    add_parse_callback(callback)
    options.parse_command_line(["--store_true_value=store_true", "--mock_option=mock"])


# Generated at 2022-06-22 04:13:56.707826
# Unit test for method __contains__ of class OptionParser
def test_OptionParser___contains__():
    parser = OptionParser()

    parser.define('name', default=None)
    assert 'name' in parser
    assert 'name1' not in parser

    parser.define('name1', default=None)
    assert 'name' in parser
    assert 'name1' in parser


# Generated at 2022-06-22 04:14:00.696094
# Unit test for function parse_command_line
def test_parse_command_line():
    define("test1", default="1.1.1.1", group="test")
    define("test2", default="", group="test")
    create_mock_options = mock.patch.object(options, "mockable")
    with create_mock_options as mock_options:
        mock_options["test1"] = "1.1.1.2"
        mock_options["test2"] = "1.1.1.3"
    assert options.test1 == "1.1.1.2"
    assert options.test2 == "1.1.1.3"

# Generated at 2022-06-22 04:14:03.122587
# Unit test for method __contains__ of class OptionParser
def test_OptionParser___contains__():
    option_parser = OptionParser()
    with pytest.raises(Error):
        option_parser.__contains__('a')

# Generated at 2022-06-22 04:14:15.783726
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # setup
    path = "./test.conf"
    # load data from test.conf
    f = open(path, "w")
    f.write("autoreload = True\n")
    f.write("debug = True\n")
    f.write("compress_response = True\n")
    f.write("default_handler_class = None\n")
    f.write("default_handler_args = None\n")
    f.write("static_hash_cache = True\n")
    f.write("static_path = None\n")
    f.write("static_url_prefix = None\n")
    f.write("template_path = None\n")
    f.write("compiled_template_cache = False\n")
    f.write("gzip = False")
    f.close

# Generated at 2022-06-22 04:14:20.044845
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    input_str = "interface help_string"
    args = input_str.split()
    option_parser=OptionParser()
    option_parser.define(*args)
    

if __name__ == "__main__":
    test_OptionParser_define()

# Generated at 2022-06-22 04:14:23.644725
# Unit test for function define
def test_define():
    define("name1", default=None, type=None, help=None, metavar=None, multiple=False, group=None, callback=None)


# Generated at 2022-06-22 04:14:37.061770
# Unit test for method __delattr__ of class _Mockable
def test__Mockable___delattr__():
    import json
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import tornado.options
    import tornado.autoreload
    import tornado.web
    import tornado.escape
    import time
    import tornado.locks
    import tornado.process
    import tornado.template
    import datetime
    from tornado.log import gen_log
    import decimal
    import json
    import docker
    import grpc
    import base64
    import copy
    import tornado.platform.asyncio

    class Test__Mockable___delattr__Handler(RequestHandler):
        @tornado.web.asynchronous
        def get(self):
            self.write('Test__Mockable___delattr__Handler')
            self.finish()

# Generated at 2022-06-22 04:14:42.527603
# Unit test for method value of class _Option
def test__Option_value():
    import unittest
    import inspect
    import io
    import datetime

    class CodeTest(unittest.TestCase):
        def test_value(self):
            # Arrange
            name = 'name'
            default = None
            type = None
            help = 'help'
            metavar = None
            multiple = False
            file_name = None
            group_name = None
            callback = None
            option = _Option(name, default, type, help, metavar, multiple, file_name, group_name, callback)

            # Act
            result = option.value()

            # Assert
            self.assertEqual(result, None)

        def test_value_with_string(self):
            # Arrange
            name = 'name'
            default = 'default'
            type = None
           

# Generated at 2022-06-22 04:14:54.945274
# Unit test for function parse_config_file
def test_parse_config_file():
    def test_config_file(path):
        options.parse_config_file(path)
    import tempfile
    temp = tempfile.NamedTemporaryFile(mode="w+", suffix = ".yaml", delete = False)