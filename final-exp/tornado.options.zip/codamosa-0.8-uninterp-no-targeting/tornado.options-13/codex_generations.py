

# Generated at 2022-06-22 04:07:01.797956
# Unit test for method __contains__ of class OptionParser
def test_OptionParser___contains__():
    # Ensure that __contains__ is working
    assert "debug" in options
    assert "debug" in options



# Generated at 2022-06-22 04:07:05.577084
# Unit test for function parse_command_line
def test_parse_command_line():
    temp=['--help', '--usage']
    temp2=[]
    options.parse_command_line(['--help','--usage'])
    assert temp==temp2


# Generated at 2022-06-22 04:07:10.422941
# Unit test for method value of class _Option
def test__Option_value():
    from tornado.options import _Option
    a = _Option(1,2,3,4,5)
    a.__setattr__(1,2)
    a.__setattr__(2,5)
    assert a._value is 2
    assert a.value() is 2
    #assert a._value is not 2
if __name__ == "__main__":
    import doctest
    from tornado.options import _Option
    doctest.testmod(optionflags=doctest.ELLIPSIS)
    #test__Option_value()

# Generated at 2022-06-22 04:07:13.062634
# Unit test for method set of class _Option
def test__Option_set():
    assert True

# Generated at 2022-06-22 04:07:19.960775
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    print("Unit testing __setattr__")
    _originals = {}
    _options = OptionParser()
    parsed = True
    name = "log_file_prefix"
    value = "mysite"

    _originals[name] = getattr(_options, name)
    setattr(_options, name, value)
    if name not in _originals:
        parsed = False

    if not parsed:
        raise Exception("Unit test for class _Mockable, method __setattr__ failed")


# Generated at 2022-06-22 04:07:23.685749
# Unit test for method value of class _Option
def test__Option_value():
    a = _Option("name", default = None, type = int, help = None, metavar = None, multiple = False, file_name = None, group_name = None, callback = None)
    a.parse("11")
    assert a.value() == 11


# Generated at 2022-06-22 04:07:33.717191
# Unit test for method parse of class _Option
def test__Option_parse():
    # test parse of _Option with type datetime.datetime
    option = _Option("value", type=datetime.datetime)
    # the format of value is "%a %b %d %H:%M:%S %Y"
    value = str(datetime.datetime.now().strftime("%a %b %d %H:%M:%S %Y"))
    assert option.parse(value) == datetime.datetime.now()
    # the format of value is "%Y-%m-%d %H:%M:%S"
    value = str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    assert option.parse(value) == datetime.datetime.now()
    # the format of value is "%Y-%m-

# Generated at 2022-06-22 04:07:35.443392
# Unit test for function parse_config_file
def test_parse_config_file():
    options.define('test',int,multiple=True,default=1)
    path = os.path.join(os.path.dirname(__file__),"tmux-config")
    options.parse_config_file(path)
    assert options.test == [1,2]

# Generated at 2022-06-22 04:07:37.946010
# Unit test for method __getitem__ of class OptionParser
def test_OptionParser___getitem__():
    # Argument 1
    parser = OptionParser()
    assert parser['name'] == parser.__getitem__('name')



# Generated at 2022-06-22 04:07:40.749228
# Unit test for function add_parse_callback
def test_add_parse_callback():
    def func():
        print("Hello, this is a test function")

    options.add_parse_callback(func)
    options.run_parse_callbacks()

    

# Generated at 2022-06-22 04:08:10.638940
# Unit test for method print_help of class OptionParser
def test_OptionParser_print_help():
    from utils import capture_stdout
    from _options import options
    def test_OptionParser_print_help_0():
        with capture_stdout() as stdout:
            options.print_help()
        if stdout.getvalue().strip() != """Usage: OptionParser.py [OPTIONS]

Options:

  --help                                  print this help message and exit
  --log_file_prefix=""                    Path prefix for log files.  Note that if
                                          you are running multiple tornado processes,
                                          log_file_prefix must be different for each
                                          of them (e.g. include the port number)


""":
            raise Exception
    def test_OptionParser_print_help_1():
        with capture_stdout() as stdout:
            options.print_help(file=None)
       

# Generated at 2022-06-22 04:08:19.822341
# Unit test for method group_dict of class OptionParser
def test_OptionParser_group_dict():
    parser = OptionParser()
    parser.define("name", default="yun", group='application')
    parser.define("age", default=21, group='application')
    parser.define("sex", default="male", group='application')
    parser.define("height", default=172, group='system')
    assert parser.group_dict('application') == {'name': 'yun', 'age': 21, 'sex': 'male'}
    assert parser.group_dict('system') == {'height': 172}
    assert parser.group_dict('') == {'name': 'yun', 'age': 21, 'sex': 'male', 'height':172}


# Generated at 2022-06-22 04:08:29.091498
# Unit test for method value of class _Option
def test__Option_value():
    try:
        a = _Option('a', 1, type=int)
    except ValueError:
        assert 1 == 1
    try:
        a = _Option('a', 1, type=int, multiple=True)
    except ValueError:
        assert 1 == 1
    a = _Option('a', 1, type=int)
    assert a.value() == 1
    a = _Option('a', 1, type=int)
    a.set(2)
    assert a.value() == 2
    a = _Option('a', [0, 1], type=int, multiple=True)
    assert a.value() == [0, 1]
    a.set([2])
    assert a.value() == [2]
    a = _Option('a', 1, type=int)
    a.parse('2')


# Generated at 2022-06-22 04:08:37.313800
# Unit test for method __contains__ of class OptionParser
def test_OptionParser___contains__():
    # options = OptionParser()
    # options.define("name", type=str, help="opt name")
    # nameopt = options["name"]

    assert nameopt == options.name

    assert nameopt.name == "name"
    assert nameopt.type == str
    assert nameopt.help == "opt name"
    assert nameopt.default is None
    assert nameopt.group_name == ""
    assert nameopt.callback is None
    assert nameopt.metavar is None
    assert nameopt.multiple is False



# Generated at 2022-06-22 04:08:40.876765
# Unit test for method value of class _Option
def test__Option_value():
    _Option_test = _Option('_Option_test')
    assert _Option_test.value() == _Option_test.default
    _Option_test.set(3)
    assert _Option_test.value() == 3



# Generated at 2022-06-22 04:08:51.806544
# Unit test for method group_dict of class OptionParser
def test_OptionParser_group_dict():
    # Default options
    opt = OptionParser()
    # Define options
    opt.define('name', default='Bob', type=str)
    opt.define('age', default=18, type=int)
    opt.define('city', default='Taipei', type=str)
    opt.define('country', default='Taiwan', type=str)
    opt.define('job', default='student', type=str)
    opt.define('food', default='cake', type=str)
    opt.define('sport', default='swimming', type=str)
    opt.define('hobby', default='reading', type=str)
    opt.define('color', default='black', type=str)
    opt.define('car', default='BMW', type=str)
    # Check options
    print(opt.as_dict())


# Generated at 2022-06-22 04:08:58.648391
# Unit test for method run_parse_callbacks of class OptionParser
def test_OptionParser_run_parse_callbacks():
    print(test_OptionParser_run_parse_callbacks.__doc__)
    parser = OptionParser()
    parser.define('a', callback=lambda x: print(x))
    parser.define('b', callback=lambda x: print(x))
    parser.run_parse_callbacks()

    parser.define('c', callback=lambda x: print(x))
    parser.parse_config_file('test_callback.conf')
    parser.run_parse_callbacks()

    parser.define('d', callback=lambda x: print(x))
    parser.parse_config_file('test_callback2.conf')
    parser.parse_command_line(['--d=100'])
    parser.run_parse_callbacks()

    parser.define('e', callback=lambda x: print(x))
    parser.parse

# Generated at 2022-06-22 04:08:59.224123
# Unit test for method print_help of class OptionParser
def test_OptionParser_print_help():
    pass


# Generated at 2022-06-22 04:09:07.177242
# Unit test for method groups of class OptionParser
def test_OptionParser_groups():
    parser = OptionParser()
    parser.define('port', default=80, help='Port to run this server on')
    parser.define('db_file', help='Path to database file')
    parser.define('log_file', help='Path to log file')
    print(parser.groups())
    parser.define('log_file', help='Path to log file', group="log")
    parser.define('log_level', help='Log level', group="log", multiple=True)
    print(parser.groups())
    print(parser.group_dict('log'))
    print(parser.as_dict())

test_OptionParser_groups()


# Generated at 2022-06-22 04:09:12.272561
# Unit test for constructor of class OptionParser
def test_OptionParser():
    parser = OptionParser()
    assert parser._parse_callbacks == []
    assert parser._options == {}
    assert parser._config_files == []
    assert parser.logging == True
    assert parser.print_help_func == None
    assert parser.allow_interspersed_args == True
    assert parser.usage == None
    assert parser.description == None
    assert parser.version == None
    assert parser.epilog == None



# Generated at 2022-06-22 04:09:35.000504
# Unit test for method print_help of class OptionParser
def test_OptionParser_print_help():
    define("a", type=str, help="A option")
    define("b", default="hello", help="B option")

    opt = Options()
    opt.print_help()


# Generated at 2022-06-22 04:09:36.719905
# Unit test for function define
def test_define():
    define('name',default='value',type=str,help='help',metavar='metavar',
           multiple=False,group='group',callback=None)
# parse_command_line

# Generated at 2022-06-22 04:09:44.660837
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    from typing import List

    # Tests for __setattr__()
    class OptionParser(object):
        # Test for __setattr__(self, name, value)
        def test___setattr__(self):
            # Implementation detail to __setattr__
            pass

    expected_error = ''

    # Call the __setattr__, passing the required parameters
    @attr.s
    class TestOptionParser(OptionParser):
        def __setattr__(self, name, value):
            # Test that the __setattr__ call raises the expected TypeError
            with self.assertRaises(TypeError) as error:
                object.__setattr__(self, name, value)
            assert str(error.exception) == expected_error

# Generated at 2022-06-22 04:09:49.986773
# Unit test for function print_help

# Generated at 2022-06-22 04:10:02.081824
# Unit test for function define
def test_define():
    with pytest.raises(ValueError):
        define('a', default = "Some String", type = None)
    with pytest.raises(AttributeError):
        define('a', default = None, type = str)
    define('b', default = 1.0, type = float)
    define('c', default = None, type = datetime.timedelta)
    define('d', default = None, type = datetime.date)
    define('e', default = None, type = datetime.datetime)
    define('f', default = None, type = bool)
    define('g', default = None, type = str)
    define('h', default = None, type = int)
    define('i', default = None, type = bytes)
    define('j', default = None, type = [str])



# Generated at 2022-06-22 04:10:05.535030
# Unit test for method parse of class _Option
def test__Option_parse():
    value = "--help true"
    opt = _Option(value)
    opt.parse(value)
    print(opt.value())



# Generated at 2022-06-22 04:10:07.016697
# Unit test for method __getitem__ of class OptionParser
def test_OptionParser___getitem__():
    # Testing OptionParser's  __getitem__(['name']) method, with default value
    with pytest.raises(KeyError):
        OptionParser.__getitem__(key=None)

# Generated at 2022-06-22 04:10:11.620419
# Unit test for method __setitem__ of class OptionParser
def test_OptionParser___setitem__():
    """
    Set and get OptionParser attribute values
    """
    options = OptionParser()
    options['port'] = 8080
    options['config'] = 'app.conf'
    assert options['port'] == 8080
    assert options['config'] == 'app.conf'


# Generated at 2022-06-22 04:10:22.461765
# Unit test for method __getattr__ of class OptionParser
def test_OptionParser___getattr__():
    # Test input parameters: global context is modified, however these modifications
    # are discarded at the end of the test.
    sys.argv.append('--port=8989')
    sys.argv.append('--db_host=localhost')
    sys.argv.append('--db_name=test')
    sys.argv.append('--config=/tmp/myapp.conf')

    parser = OptionParser()
    parser.define("port", default=8888, help="run on the given port", type=int)
    parser.define("db_host", default="127.0.0.1:3306", help="database host")
    parser.define("db_name", default="test", help="database name")
    parser.define("config", default="/etc/myapp.conf", help="path to config file")

# Generated at 2022-06-22 04:10:26.490543
# Unit test for method as_dict of class OptionParser
def test_OptionParser_as_dict():
    op = OptionParser()
    op.define('foo', default='bar', help='foo option')
    op.parse_config_file('/tmp/lala.py')
    assert op.as_dict()['foo'] == 'bar'

# Generated at 2022-06-22 04:10:57.938464
# Unit test for method items of class OptionParser
def test_OptionParser_items():
    print(type(options))
    print(type(options.items()))

    # -----
    from tornado.options import define, options, parse_config_file

    define("name", default=None, type=str, help="First name of the person")

    f = open('/tmp/foo.conf', 'w')
    f.write('name=foo')
    f.close()

    parse_config_file('/tmp/foo.conf')
    print(type(options.items()))
    print(options.items())  # odict_items([('name', 'foo')])
    print(list(options.items()))  # [('name', 'foo')]

# Generated at 2022-06-22 04:11:10.756828
# Unit test for method value of class _Option
def test__Option_value():
    # test for _Option.value()
    with pytest.raises(Error) as ex:
        option = _Option("name", type=str)
        option.set("aaa")
    assert(str(ex.value) == "Option 'name' is required to be a list of str")
    # test for _Option.parse()
    with pytest.raises(Error) as ex:
        option = _Option("name", type=str)
        option.parse("aaa")
    assert(str(ex.value) == "Unrecognized date/time format: 'aaa'")
    with pytest.raises(Error) as ex:
        option = _Option("name", type=datetime.timedelta)
        option.parse("aaa")

# Generated at 2022-06-22 04:11:11.796005
# Unit test for method items of class OptionParser
def test_OptionParser_items():
    pass



# Generated at 2022-06-22 04:11:25.263770
# Unit test for method set of class _Option
def test__Option_set():
    from datetime import datetime
    from datetime import date

    global __test_set__
    __test_set__ = True
    option = _Option("name", default = "default", type = basestring_type, help = "help", metavar = "metavar", multiple = True, file_name = "file_name", group_name = "group_name")
    option.set("test")
    assert option.value() == "test"

    option = _Option("name", default = "default", type = bool, help = "help", metavar = "metavar", multiple = True, file_name = "file_name", group_name = "group_name")
    option.set("false")
    print(option.value())
    assert option.value() == False


# Generated at 2022-06-22 04:11:27.814432
# Unit test for function parse_command_line
def test_parse_command_line():
    global options
    options = OptionParser()
    options.define('name',default='caojian'
                   , type=str, help='your name',
                   metavar='NAME', multiple=False, group='caojian', callback=None)
    args = parse_command_line()
    assert args == ['--name', 'caojian']
test_parse_command_line()

# Generated at 2022-06-22 04:11:31.831701
# Unit test for method __getattr__ of class OptionParser
def test_OptionParser___getattr__():
    # option_parser.py:264
    options = OptionParser()
    options.define("name", default="fred", help="name")
    assert options.name == "fred"
    assert options.name == "fred"

# Generated at 2022-06-22 04:11:44.656398
# Unit test for method group_dict of class OptionParser
def test_OptionParser_group_dict():
    # two groups with difference name.
    # group1: group_name is default group_name, which is file name
    # group2: group_name is explicit group_name
    group1 = 'default group'
    group2 = 'explicit group'

    # define a option with non-default group
    options.define(name='template_path', group=group2)
    # define a option with default group
    options.define(name='static_path')

    # assert that there is only two groups
    groups = options.groups()
    assert len(groups) == 2

    # assert that group_dict('group1') return correct dict
    template_path_dict = options.group_dict(group=group2)
    static_path_dict = options.group_dict(group=group1)

# Generated at 2022-06-22 04:11:55.568574
# Unit test for method add_parse_callback of class OptionParser
def test_OptionParser_add_parse_callback():
    import unittest

    class TestOptions(unittest.TestCase):

        def test_add_parse_callback(self):
            from tornado.options import options, OptionParser
            from tornado.testing import AsyncTestCase, gen_test

            options.add_parse_callback(self.callback)
            # The following line will call add_parse_callback
            options.define("test", callback=self.callback)
            options.test = "Testing"
            self.assertEqual(options.test, "Testing")
            self.assertEqual(options.test, "Testing")

        def callback(self):
            options.test = "Testing"

    unittest.main()


# Generated at 2022-06-22 04:11:58.238534
# Unit test for function parse_config_file
def test_parse_config_file():
    from myppy.tests.base import TEST_BASE

    parse_config_file(os.path.join(TEST_BASE, "test_data", "config.ini"))



# Generated at 2022-06-22 04:12:09.271585
# Unit test for method __getitem__ of class OptionParser
def test_OptionParser___getitem__():
    print("*************test_OptionParser___getitem__*************")
    # Make a custom options page
    class MyOptionParser(OptionParser):
        def __init__(self):
            super(MyOptionParser, self).__init__()
            # -----------------------------------------------------------------------
            # Define a bunch of options
            # -----------------------------------------------------------------------
            self.define("port", default=80, type=int, help="run on the given port", group="application")
            self.define("address", default="127.0.0.1", type=str, help="run on the given address", group="application")
            self.define("cookie_secret", type=str, help="secure cookie secret", group="application")
            self.define("xsrf_cookies", type=bool, default=False, help="turn on xsrf cookies", group="application")
            self

# Generated at 2022-06-22 04:13:09.879252
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    # Setup
    # Define option
    define('name', type=str)
    define('name', multiple=True, type=str)
    define('name', default=None, type=dict)
    define('name', default='', type=str)
    define('name', default=0, type=int, multiple=True)
    define('name', default=0.0, type=float, multiple=True)
    define('name', default=True, type=bool, multiple=True)
    define('name', default=datetime.timedelta(), type=datetime.timedelta, multiple=True)
    define('name', default=datetime.datetime.utcnow().replace(), type=datetime.datetime, multiple=True)
    define('name')
    define('name', default=None)

# Generated at 2022-06-22 04:13:11.312810
# Unit test for method __getattr__ of class _Mockable
def test__Mockable___getattr__():
    x = _Mockable()
    x.__getattr__(1)

# Generated at 2022-06-22 04:13:13.979330
# Unit test for constructor of class Error
def test_Error():
    def assert_Error(error: Error) -> None:
        assert isinstance(error, Error)
    assert_Error(Error("test_Error"))



# Generated at 2022-06-22 04:13:14.962400
# Unit test for method __setitem__ of class OptionParser
def test_OptionParser___setitem__():
    assert True

# Generated at 2022-06-22 04:13:24.173261
# Unit test for method groups of class OptionParser
def test_OptionParser_groups():
    global options
    options.define("myplugin_option20", default=-1, help="blah", type=int)
    options.define("myplugin_option21", default=None, help="blah")
    options.define("myplugin_option22", default=None, help="blah")
    options.define("myplugin_option23", default=None, help="blah")
    options.define("myplugin_option24", default=None, help="blah")
    options.parse_command_line([])
    assert options.groups() == {'', 'myplugin'}, "groups() is broken"
    expected = {"myplugin_option20": -1, "myplugin_option21": None, "myplugin_option22": None, "myplugin_option23": None, "myplugin_option24": None}
    assert options

# Generated at 2022-06-22 04:13:30.920875
# Unit test for constructor of class _Mockable
def test__Mockable():
    o = OptionParser()
    o.define("option1", default=True, help="option 1")
    m = _Mockable(o)
    with mock.patch.object(m, "option1", False):
        assert o.option1 == False
    assert o.option1 == True


# Global instance of OptionParser
options = OptionParser()



# Generated at 2022-06-22 04:13:33.482283
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    # Verify that define() returns None
    assert_equal(None, define('port', default=0, type=int, help='The port to bind'))


# Generated at 2022-06-22 04:13:46.127040
# Unit test for method items of class OptionParser
def test_OptionParser_items():
    import tornado
    import os

    TEST_VAR = 'TEST_VAR_1'
    TEST_VAR = 'TEST_VAR_2'
    TEST_VAR = 'TEST_VAR_3'
    TEST_VAR = 'TEST_VAR_4'
    TEST_VAR = 'TEST_VAR_5'

    def test_run(self_):
        self_.items()

        test_is_in.assert_called()

    def test_is_in(self_):
        assert TEST_VAR in os.environ

    tornado.options.OptionParser.items = test_run
    os.environ.__contains__ = test_is_in
    parse_command_line()



# Generated at 2022-06-22 04:13:57.011470
# Unit test for method group_dict of class OptionParser
def test_OptionParser_group_dict():
    from tornado.options import OptionParser
    parser = OptionParser()
    parser.define("config", type=str, help="path to config file")
    parser.define("port", type=int, default=8000, help="run on the given port")
    parser.define("debug", type=bool, default=False, help="run in debug mode")
    parser.define("logging", default="info", help="logging level")
    parser.define("template_path", group="application")
    parser.define("static_path", group="application")
    parser.parse_command_line()

    assert parser.group_dict("application") == {'template_path': None, 'static_path': None}

test_OptionParser_group_dict()

 


# Generated at 2022-06-22 04:14:06.869413
# Unit test for method run_parse_callbacks of class OptionParser
def test_OptionParser_run_parse_callbacks():

    def _run_one(self):
        self.run_parse_callbacks()

    def callback(opt_str, value, parser):
        self.setattr('name', 'value')

    def test_run_parse_callbacks(self):
        self.add_option('--name', '-n', callback=callback)
        self.define('define_name', 'define_value', callback=callback)
        _run_one(self)
        assert self.name == 'value'
        assert self.define_name == 'value'

if __name__ == '__main__':
    test_OptionParser_run_parse_callbacks()

# Generated at 2022-06-22 04:15:46.911541
# Unit test for method parse of class _Option
def test__Option_parse():
    _Option._parse_string("abc")

# Generated at 2022-06-22 04:15:52.785991
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    print("Testing OptionParser.define(self, name, default=None, type=None, help=None, metavar=None, multiple=False, group=None, callback=None)")

    op = OptionParser()
    op.define("option1", default=None, type=None, help=None, metavar=None, multiple=False, group=None, callback=None)
    if ("option1" in op._options):
        print("Success")
    else:
        print("Failure")
    return

# Generated at 2022-06-22 04:15:56.095703
# Unit test for method __delattr__ of class _Mockable
def test__Mockable___delattr__():
    options = OptionParser()
    options.define('test_del_attr', default='old_val')
    assert options.test_del_attr == 'old_val'
    m = _Mockable(options)
    m.test_del_attr = 'new_val'
    assert options.test_del_attr == 'new_val'
    delattr(m, 'test_del_attr')
    assert options.test_del_attr == 'old_val'


# Generated at 2022-06-22 04:15:58.980754
# Unit test for method __delattr__ of class _Mockable
def test__Mockable___delattr__():
    options=OptionParser()
    options.parse_config_file("testcase/test_options.cfg")
    mockable=_Mockable(options)
    delattr(mockable, "address")
    assert not any(option.name=="address" for option in options._options.values())
    assert not any(name=="address" for name in mockable._originals)


define = OptionParser().define



# Generated at 2022-06-22 04:16:01.310393
# Unit test for function parse_command_line
def test_parse_command_line():
    define("name", default="Bob", help="Who to greet.")
    define("verbose", default=False, help="Increase output verbosity.")
    args = parse_command_line( ["--verbose", "--name=Jane"])
    print(args)
    #assert args == ['--verbose', '--name=Jane']

test_parse_command_line()


# Generated at 2022-06-22 04:16:03.391949
# Unit test for method __getattr__ of class _Mockable
def test__Mockable___getattr__():
    options = None
    mockable = _Mockable(options)
    assert isinstance(mockable, _Mockable) is True


# Generated at 2022-06-22 04:16:13.499967
# Unit test for constructor of class _Mockable
def test__Mockable():
    import pytest
    from unittest.mock import patch
    options = OptionParser()
    options.define("v", default=1, type=int)
    options.define("v2", default=2, type=int)
    options.define("v2", default=2, type=int)
    m = _Mockable(options)
    assert m.v == 1
    with pytest.raises(Error):
        m.v2 = 3
    with pytest.raises(Error):
        del m.v2
    with patch.object(m, "v", 4):
        assert m.v == 4
    assert m.v == 1
    options.v = 5
    assert m.v == 5
    del options.v
    with pytest.raises(AttributeError):
        m.v



# Generated at 2022-06-22 04:16:17.239034
# Unit test for method __contains__ of class OptionParser
def test_OptionParser___contains__():
    options = OptionParser()
    options.define('name', type=str, help='this is name')
    assert 'name' in options
    assert 'not_exists' not in options


# Generated at 2022-06-22 04:16:23.125426
# Unit test for method run_parse_callbacks of class OptionParser
def test_OptionParser_run_parse_callbacks():
    opt = OptionParser()
    opt.define('test', callback=lambda value: None)
    opt.parse_command_line(['--test=1'])
    opt.define('test1', callback=lambda value: None)
    opt.parse_command_line(['--test1=1'])
    try:
        opt.run_parse_callbacks()
        assert True
    except RuntimeError:
        assert False