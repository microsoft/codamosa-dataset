

# Generated at 2022-06-12 14:01:50.528278
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    parser = OptionParser(allow_interspersed_args=False)
    parser.add_option("-i", "--input", default="in.txt",action="store", type="string", dest="infile")
    parser.add_option("-o", "--output", default="out.txt",action="store", type="string", dest="outfile")
    parser.add_option("-v", "--verbose",action="store_true", dest="verbose", default=False)
    parser.add_option("-q", "--quiet",action="store_false", dest="quiet", default=True)
    parser.add_option("-a", action="store_true", dest="a")
    parser.add_option("-b", action="store_false", dest="b")

# Generated at 2022-06-12 14:01:58.640900
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    import datetime
    import os
    import tempfile
    import tornado
    import tornado.escape
    import tornado.options
    import unittest
    from tornado.options import define
    def test_define():
        define("1", default=1)
        define("2", default=2)
        define("3", default=3)

# Generated at 2022-06-12 14:02:04.088736
# Unit test for method parse of class _Option
def test__Option_parse():
    option = _Option('name', default=None, type=str, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    assert option.parse('a') == 'a'
    assert option.parse('a') == 'a'


# Generated at 2022-06-12 14:02:13.451718
# Unit test for method set of class _Option
def test__Option_set():
    parser = OptionParser()
    parser.define('port', default=80)
    parser.parse_command_line(['--port=81'])
    assert parser.port == 81

    parser.define('mysql_host', default='mydb.example.com:3306')
    parser.parse_command_line(['--mysql_host=mydb.example.com:3306'])
    assert parser.mysql_host == 'mydb.example.com:3306'

    parser.define('memcache_hosts', default=['cache1.example.com:11011',
                                             'cache2.example.com:11011'], multiple=True)
    parser.parse_command_line(['--memcache_hosts=cache1.example.com:11011,cache2.example.com:11011'])

# Generated at 2022-06-12 14:02:17.597768
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    try:
        _Mockable({}).__setattr__()
    except TypeError:
        pass
    opt = _Mockable({})
    opt.__setattr__('name', 'value')
    assert getattr(opt, 'name') == 'value'


# Generated at 2022-06-12 14:02:22.854815
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # function: parse_config_file
    # parameters: path = os.path.abspath("Test_Cases_for_Unit_Tests/OptionParser_Test_Cases.txt")
    path = os.path.abspath("Test_Cases_for_Unit_Tests/OptionParser_Test_Cases.txt")
    # function call
    global options
    options.parse_config_file(path)
    # unit test
    assert options.test_bool_type == True
    assert options.test_int_type == 8
    assert options.test_float_type == 4.5
    assert options.test_datetime_type == datetime.datetime(2019, 12, 4, 15, 38, 59)
    assert options.test_timedelta_type == datetime.timedelta(seconds=2)


# Generated at 2022-06-12 14:02:30.638976
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    s = '''port = 80
    mysql_host = 'mydb.example.com:3306'
    # Both lists and comma-separated strings are allowed for
    # multiple=True.
    memcache_hosts = ['cache1.example.com:11011',
                      'cache2.example.com:11011']
    memcache_hosts = 'cache1.example.com:11011,cache2.example.com:11011'
    '''
    f = open('/tmp/parse_config_file.config','w')
    f.write(s)
    f.close()

    #Unit test parse_config_file()
    options = OptionParser()
    options.define('port')
    options.define('mysql_host')
    options.define('memcache_hosts',multiple=True)
   

# Generated at 2022-06-12 14:02:40.080853
# Unit test for constructor of class _Option
def test__Option():
    o = _Option("abc", default=123, type=int, help="help me", metavar="def", multiple=True, file_name="file.txt", group_name="group", callback=None)
    assert o.name == "abc"
    assert o.default == 123
    assert o.type == int
    assert o.help == "help me"
    assert o.metavar == "def"
    assert o.multiple == True
    assert o.file_name == "file.txt"
    assert o.group_name == "group"
    assert o.callback == None
    assert o._value == _Option.UNSET


# Generated at 2022-06-12 14:02:47.393832
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    from tornado.options import options, define, Error, parse_command_line, OptionError

    define("debug", default=False, help="run in debug mode")
    define("port", default=8000, help="run on the given port", type=int)
    define("parse_command_line", default=False, multiple=True)
    define("parse_config_file", default=False, multiple=True)
    define("expose_tracebacks", default=False, help="expose tracebacks in responses")
    define("help", default=False, help="show this help information", callback=options._help_callback)
    define("log_file_prefix", type=str, default=None, metavar="PATH",
           help="path prefix for log files")

# Generated at 2022-06-12 14:02:55.247718
# Unit test for method set of class _Option
def test__Option_set():
    test__Option_set_instance = _Option(
        'name',
        default=None,
        type=None,
        help=None,
        metavar=None,
        multiple=False,
        file_name=None,
        group_name=None,
        callback=None,
    )
    value = '''
    [hello]
    host = www.example.com
    '''
    try:
        result = test__Option_set_instance.set(value)
    except Exception as e:
        print(e)
    else:
        print(result)



# Generated at 2022-06-12 14:03:09.950843
# Unit test for method parse of class _Option
def test__Option_parse():
    import doctest
    _Option = _Option
    doctest.run_docstring_examples(_Option.parse, globals())

# Generated at 2022-06-12 14:03:17.194394
# Unit test for method parse of class _Option
def test__Option_parse():
    try:
        aop=_Option('', datetime.datetime, '', True)
        aop.parse('2017-12-29 08:30:21')
    except Error:
        pass
    # In test_options.py, we could use the following statements
    # to test parse.
    # options.define('test_option_parse', type=int,
    #                metavar='<int>',
    #                help='test parse',
    #                callback=_test_option_parse)
    # options.parse_command_line(args=['--test-option-parse=12'])
    # assert options.test_option_parse == 12
    # options.parse_command_line(args=['--test-option-parse=hello'])
    # AssertionError: assert 12 == 'hello'



# Generated at 2022-06-12 14:03:21.424742
# Unit test for method parse of class _Option
def test__Option_parse():
    _Option(name="name", default=None, type=None,
            help=None, metavar=None, multiple=False,
            file_name=None, group_name=None, callback=None)


if __name__ == "__main__":
    test__Option_parse()

# Generated at 2022-06-12 14:03:22.586603
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    pass


# Generated at 2022-06-12 14:03:32.879530
# Unit test for method set of class _Option
def test__Option_set():
    import tornado.options
    import datetime
    from time import time
    from time import sleep
    from time import time
    import time
    import unittest
    import mock
    import logging
    import copy
    import tempfile
    import fcntl
    import contextlib
    import functools
    import os
    import io
    import os.path
    import platform
    import signal
    import struct
    import warnings
    import subprocess
    import sys
    import sys
    import threading
    import types
    import types
    import unittest
    import unittest
    import unittest
    import unittest.mock
    import unittest.mock
    import traceback
    import logging
    import asynctest
    import asynctest
    import asynctest
    import py

# Generated at 2022-06-12 14:03:33.516926
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    pass

# Generated at 2022-06-12 14:03:40.444115
# Unit test for method parse of class _Option
def test__Option_parse():
    def test_case1():
        option = _Option("name", default=None, type=str, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
        value = "value"
        assert option._parse_string(value) == value
    def test_case2():
        option = _Option("name", default=None, type=bool, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
        value = "true"
        assert option._parse_bool(value) == True

# Generated at 2022-06-12 14:03:47.105906
# Unit test for method set of class _Option
def test__Option_set():
    option = _Option(name="name", default=None)
    option.set(None)
    option = _Option(name="name", default=None, multiple=True)
    option.set(None)
    option = _Option(name="name", default=None, multiple=True, type=str)
    option.set(None)
    option = _Option(name="name", default=None, multiple=True, type=str)
    option.set(list())
    option = _Option(name="name", default=None, multiple=True, type=str)
    option.set(["123"])
    option = _Option(name="name", default=None, multiple=True, type=int)
    option.set(["123"])

# Generated at 2022-06-12 14:03:50.583738
# Unit test for method set of class _Option
def test__Option_set():
	multiple: bool
	value: Any
	multiple = True
	value = [1,2,3]
	_options = _Option(name,default,type,help,metavar,multiple,file_name,group_name,callback)
	assert _options.set(value)



# Generated at 2022-06-12 14:03:51.560233
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    assert True



# Generated at 2022-06-12 14:04:16.866454
# Unit test for method group_dict of class OptionParser
def test_OptionParser_group_dict():
    def test1_OptionParser_group_dict():
        """
        当不包含group时
        """
        define("port", default=8888, type=int, help="run on the given port", group="application")
        define("template_path", default=None, help="path to template file", group="application")
        define("debug", default=False, help="do not verify my identity", group=None)
        parse_command_line()
        options.group_dict("application")
    def test2_OptionParser_group_dict():
        """
        当包含group时
        """
        define("port", default=8888, type=int, help="run on the given port", group="application")

# Generated at 2022-06-12 14:04:21.860294
# Unit test for method set of class _Option
def test__Option_set():
    option = _Option("option")
    option_value = 10
    with pytest.raises(Error):
        option.set(option_value)

    option.multiple = True
    option.set([])

    option_value = 10
    with pytest.raises(Error):
        option.set([option_value])

# Generated at 2022-06-12 14:04:26.198231
# Unit test for method set of class _Option
def test__Option_set():
	if default is None and multiple:
			temp=[]
			if not isinstance(value, list):
				Exception()
			for item in value:
				if not isinstance(item, self.type) :
					Exception()
				


# Generated at 2022-06-12 14:04:32.013426
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    # Test convert None to int
    a = OptionParser()
    a.define('int', type = int, default = 0.05)
    a.parse_command_line(['--int=%s'%None])
    assert a.int == 0
    # Test convert '' to int
    a = OptionParser()
    a.define('int', type = int, default = 0.05)
    a.parse_command_line(['--int=%s'%''])
    assert a.int == 0
    # Test convert 'None' to int
    a = OptionParser()
    a.define('int', type = int, default = 0.05)
    a.parse_command_line(['--int=%s'%'None'])
    assert a.int == 0
    # Test convert None to float
    a = Option

# Generated at 2022-06-12 14:04:38.333659
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    import os
    import sys
    import tempfile
    import unittest
    from tornado.options import OptionParser, parse_config_file, define
    from tornado.options import Error
    
    OptionParser.define=define
    OptionParser.parse_config_file=parse_config_file
    def test_all():
        for name, value in opts.items():
            assert opts[name] == value
    def test_get():
        for name, value in opts.items():
            assert opts.get(name) == value
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-12 14:04:49.137028
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # Zero Divison Error 
    path = '~/tornado/tornado/options.py'
    try:
        options.parse_config_file(path)
    except Exception as e:
        print(e)

if __name__ == "__main__":
    test_OptionParser_parse_config_file()

 

_op = options = OptionParser()  # type: OptionParser
if not _op._options:
    _op.define("help", type=bool, help=("show this help information"))
    _op.add_parse_callback(_op._help_callback)
    _op._add_parse_callback = _op.add_parse_callback
    _op.add_parse_callback(_op.run_parse_callbacks)

# We want the actual "options" variable to be an instance of the


# Generated at 2022-06-12 14:05:00.473615
# Unit test for constructor of class _Option
def test__Option():
    name = "a"
    default = 1
    type = int
    help = "help"
    metavar = "metavar"
    multiple = False
    file_name = "file_name"
    group_name = "group_name"
    callback = lambda x: None
    option = _Option(
        name=name,
        default=default,
        type=type,
        help=help,
        metavar=metavar,
        multiple=multiple,
        file_name=file_name,
        group_name=group_name,
        callback=callback,
    )
    assert option.name == name
    assert option.default == default
    assert option.type == type
    assert option.help == help
    assert option.metavar == metavar
    assert option.multiple == multiple
   

# Generated at 2022-06-12 14:05:03.163980
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # with open(console.log, "w") as f:
    #     print(globals(), file=f)
    assert False, "No Test"


# Generated at 2022-06-12 14:05:10.992401
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    import os
    import re
    # The following lines were added by mk_readme.py
    import tornado.ioloop
    import tornado.web
    import tornado.web.RequestHandler
    import urllib.parse
    import re
    import asyncio
    import threading
    import socket
    import os
    import signal
    import logging
    import types
    import sys
    import urllib.parse
    import socket
    import threading
    import os
    import time
    import re
    import os
    import logging
    import time
    import re
    import time
    import time
    import re
    import os
    import asyncio
    import asyncio.streams
    import os
    import types
    import socket
    import re
    import os
    import socket
    import socket
    import re

# Generated at 2022-06-12 14:05:14.964571
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    # Test without input parameters
    result = OptionParser.__iter__(self)
    assert isinstance(result, Iterator)
    # Test with input parameters
    result = OptionParser.__iter__(self, )
    assert isinstance(result, Iterator)

# Generated at 2022-06-12 14:07:22.099565
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    parser = OptionParser()
    parser.define("test_key", type=str, help="this is a test", default=None)
    parser.define("test_key2", type=str, help="this is a test2", default=None)
    file = open("test_file.cfg", "w+")
    file.write("test_key = 'test_value'\n")
    file.write("test_key2 = 'test_value2'\n")
    file.close()
    parser.parse_config_file(file.name)
    return options.test_key == "test_value" and options.test_key2 == "test_value2"


# Generated at 2022-06-12 14:07:25.649101
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
  # test _Mockable.__setattr__()
  from tornado.options import OptionParser
  options = OptionParser()
  options.mockable()._request_timeout = value = 1
  assert options._request_timeout == value
  del options.mockable()._request_timeout
  assert options._request_timeout != value

test__Mockable___setattr__()

# Generated at 2022-06-12 14:07:28.463271
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    optionparser = options.OptionParser()
    assert isinstance(optionparser.__iter__(), types.GeneratorType)

# Generated at 2022-06-12 14:07:39.646231
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    args = ["--foo=42"]
    parser = OptionParser()
    parser.define(name="foo", default=41, help="The meaning of life")
    parser.add_parse_callback(lambda: None)  # suppress warnings
    parser.define(name="config", type=str, help="path to config file",
                  callback=lambda path: parser.parse_config_file(path, final=False))
    parser.parse_command_line(args)
    # print(parser._options['foo'].__dict__)

# Generated at 2022-06-12 14:07:49.856550
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    options_instance = OptionParser()
    default_options = {
        "log_file_prefix": "tornado.log",
        "log_file_max_size": 100000000,
        "log_file_num_backups": 10,
        "log_to_stderr": False,
        "logging": "info",
        "autoreload": False
    }
    # Test with logging_config_dict = "info"
    config_file_path = os.path.join(os.path.dirname(__file__), "test_config_file.py")
    options_instance.parse_config_file(config_file_path, final=True)
    assert type(options_instance.log_file_prefix) is str
    assert type(options_instance.log_file_max_size) is int
   

# Generated at 2022-06-12 14:08:00.419776
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # Arrange
    import os
    import tempfile
    import tornado.options as options
    options.define('name', str)
    options.define('age', int)
    options.define('married', bool)
    options.define('x', float)
    options.define('y', float)
    options.define('z', float)
    # Act
    with tempfile.NamedTemporaryFile('w', delete=False) as f:
        f.write(
            '''
import os

name = "Tom"
age = 20
married = False
x, y, z = os.path.split(__file__)
'''
        )
    options.parse_config_file(f.name)
    # Assert

# Generated at 2022-06-12 14:08:10.550754
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    from tornado.options import OptionParser, DEFINE
    parser = OptionParser()
    parser.define("port", type=int, default=8888, help=(
        "TCP port for the server (default: %default)"))
    parser.define("cookie_secret", type=str, default=None, help=(
        "Cookie secret for the server (default: %default)"))
    parser.define("logging", type=str, default="info", help=(
        "Logging verbosity, set to 'none' to disable logging"))
    parser.define("debug", type=str, default=None, multiple=True, help=(
        "[DEPRECATED in favor of logging] Set to_json error_level"))
    parser.define("autoreload", type=bool, default=False, help=(
        "Reload the application on any detected change"))


# Generated at 2022-06-12 14:08:19.174495
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    op = OptionParser()
    op.define("a", default="1")
    op.define("b", default=5)
    op.define("c", default=5.5)
    op.define("d", default=True)
    op.define("e", default=["hello", "world"])

    op.parse_config_file("test_options_config.py")

    # Test that parsing a config file with no option values,
    # doesn't change any defaults.
    assert op.options.a == "1"
    assert op.options.b == 5
    assert op.options.c == 5.5
    assert op.options.d == True
    assert op.options.e == ["hello", "world"]

    # Test that parsing a config file with some option values,
    # will change only that option values
    op

# Generated at 2022-06-12 14:08:22.936438
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    a = _Mockable(OptionParser())
    a.__setattr__('a', 20)
    assert a.a == a._options.a
    assert a._originals == {'a' : None}


# Generated at 2022-06-12 14:08:29.708821
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    options = OptionParser()
    options.define('name')
    options.define('age', default=25, type=int)
    options.define('page', type=int)
    options.define('cookie', type='str')
    options.define('sugar', type=str)
    options.define('name', type=str)
    options.define('name', type=str, multiple=True)
    options.define('name', type=str, multiple=True, group='g1')
    options.define('name', type=str, multiple=True, help='test', metavar='test')

test_OptionParser_define()
out = ""

# Generated at 2022-06-12 14:09:39.418710
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    import tornado.testing
    import tempfile
    import io
    import os

    class OptionsTest(tornado.testing.AsyncTestCase):  # type: ignore
        def test_config_file(self):
            # type: () -> None
            path = tempfile.mktemp()

# Generated at 2022-06-12 14:09:45.053309
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    os.system('cp test_options_1.conf.bak test_options_1.conf')
    op = OptionParser()
    op.define('port', type=int, help='Port to listen on.')
    op.define('port', type=int, default=8999, help='Port to listen on.')
    op.define('port', type=int, default=8999, help='Port to listen on.', callback=None)
    op.define('port', type=int, default=8999, help='Port to listen on.', callback=lambda x: x)
    op.parse_config_file('test_options_1.conf')
    assert op.as_dict() == {'port': 8888}

# Generated at 2022-06-12 14:09:50.793898
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    from tornado import options
    import unittest
    import unittest.mock
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.curl_httpclient import CurlAsyncHTTPClient
    from tornado.escape import native_str
    import pycurl
    import typing
    import os.path
    import binascii
    import contextlib
    import tornado.testing
    class _Mockable:
        def __init__(self, opt_parser) -> None:
            self._opt_parser = opt_parser


# Generated at 2022-06-12 14:09:52.574510
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    test_subject = OptionParser()
    assert isinstance(test_subject.__iter__(), Iterator) == True
    return


# Generated at 2022-06-12 14:09:55.033292
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    input_arg = OptionParser()
    return_value = input_arg.__iter__()
    assert return_value == input_arg._options.values()



# Generated at 2022-06-12 14:10:01.535303
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    #set up
    args = [
        '-c', 'config.json',
        '-p', '8080',
        '--app_name', 'app',
        '--secret_key', 'password',
        '-v',
        '-c', 'testing.json',
        '--log_to_stderr',
        '--logging=warning',
        '--template_path=template',
        '--static_path=static'
    ]

    #test parse_command_line
    opt = OptionParser()
    opt.define('config', default='config.json')
    opt.define('port', default='8080')
    opt.define('app_name', default='app')
    opt.define('secret_key', default='password')
    opt.define('verbose', default=False)
   

# Generated at 2022-06-12 14:10:06.753004
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    # Imports
    import unittest

    class _MockableTests(unittest.TestCase):
        def test__setattr__(self):
            # Test __setattr__()
            mockable = _Mockable('OptionParser')

            self.assertEqual(mockable.__dict__['_originals'], {})
            self.assertEqual(mockable.__dict__['_options'], 'OptionParser')

            mockable.__setattr__('foo', 'bar')

            self.assertEqual(mockable.__dict__['_originals'], {'foo': None})
            self.assertEqual(mockable.__dict__['_options'], 'OptionParser')

    unittest.main()

if __name__ == '__main__':
    test__Mock

# Generated at 2022-06-12 14:10:14.024143
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # options.py
    # Unit test for method parse_config_file of class OptionParser
    import os
    import unittest
    import tempfile
    from tornado.options import options, parse_config_file, Error
    import sys

    class TestParseConfigFile(unittest.TestCase):
        def test_parse_config_file(self):
            options.define("a", type=int, default=1)
            options.define("b", type=float, default=1.1)
            options.define("c", default="spammy")
            options.define("d", type=str)
            options.define("e", multiple=True, default=["a"])
            options.define("f", type=str, multiple=True, default=["a"])
            file = tempfile.NamedTemporaryFile()
           

# Generated at 2022-06-12 14:10:18.645013
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    options = OptionParser()
    options.define('test', type=int, default=1)
    mockable = _Mockable(options)
    mockable.__setattr__('test', 2)
    print(getattr(options, 'test'))
    
test__Mockable___setattr__()


# Generated at 2022-06-12 14:10:25.483301
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    import tornado.testing
    import logging
    import unittest
    try:
        import mock
    except ImportError:
        raise unittest.SkipTest("mock package not available")

    class OptionsMockTest(tornado.testing.AsyncTestCase):
        def test_mock(self):
            options.define("name", type=str, default="Jones", help="some help")
            self.assertEqual(options.name, "Jones")
            mock_options = options.mockable()
            with mock.patch.object(mock_options, "name", "Smith"):
                self.assertEqual(options.name, "Smith")
            self.assertEqual(options.name, "Jones")

    tornado.testing.main()


#-----------------------------------------------------------------------------
# Dev API
#-----------------------------------------------------------------------------

#-----------------------------------------------------------------------------
#