

# Generated at 2022-06-12 14:01:29.839007
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    options = Options()
    options.define("port", type=int, help="port number")
    options.define("address", type=str, help="host address")
    options.define("subdomain", type=str, help="subdomain of address")
    options.define("subdomains", multiple=True, type=str, help="subdomains of address")
    options.define("query", type=str, help="query of address")
    options.define("queries", multiple=True, type=str, help="queries of address")
    args = options.parse_command_line(["","--port=80","--address=www.example.com","--subdomain=www","--subdomains=www,blog","--query=http","--queries=http,https"])
    assert(options.port == 80)

# Generated at 2022-06-12 14:01:40.874580
# Unit test for method value of class _Option
def test__Option_value():
    option = _Option("test", default=None, type=None, help=None,
        metavar=None, multiple=False, file_name=None, group_name=None,
        callback=None)
    assert option.value() == None
    option = _Option("test", default=None, type=str, help=None,
        metavar=None, multiple=False, file_name=None, group_name=None,
        callback=None)
    assert option.value() == None
    option = _Option("test", default='', type=str, help=None,
        metavar=None, multiple=False, file_name=None, group_name=None,
        callback=None)
    assert option.value() == ''

# Generated at 2022-06-12 14:01:49.663226
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    print("="*40)
    print("test__Mockable___setattr__")
    print("="*40)

    import unittest.mock as mock
    a = OptionParser()
    a.define("a", type=int, default=1, multiple=True)
    b = _Mockable(a)
    # mock.patch not working (maybe because of accessor methods __getattr__ and __setattr__)
    # with mock.patch.object(a, "a", [2, 3, 4]):
    #     print(a.a)
    #     assert a.a == [2, 3, 4]

    # mock.patch.object not working, since it does not patch the option.
    # with mock.patch.object(b, "a", [2, 3, 4]):
    #     print

# Generated at 2022-06-12 14:01:52.031607
# Unit test for method parse of class _Option
def test__Option_parse():
    o = _Option('name','default','type','',None,False,None,None,None)
    o.parse('value')
    assert o.callback == None
    assert o._value == 'value'
    assert o.default == 'default'



# Generated at 2022-06-12 14:01:58.513061
# Unit test for method parse of class _Option
def test__Option_parse():
    # Initialize the object
    testObj = _Option('testObj', '123', str, 'help', 'metavar', False, 'file_name', 'group_name', None)
    testValue = 'test'
    testResult = testObj.parse(testValue)
    assert isinstance(testResult, str) == True
    assert isinstance(testResult, int) == False
    assert isinstance(testResult, float) == False
    assert testResult == 'test'
    return True

# Generated at 2022-06-12 14:01:59.211927
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    pass


# Generated at 2022-06-12 14:02:05.228034
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    options = OptionParser()
    options.define('foo', type=int)
    options.define('bar', type=bool)
    options.foo = '123'
    options.bar = 'False'
    assert options.foo == 123
    assert options.bar is False
test_OptionParser___setattr__()


# Generated at 2022-06-12 14:02:13.915379
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():

    import unittest
    
    
    
    
    
    
    
    
    
    
    
    
    class Test_OptionParser___iter__(unittest.TestCase):
        """Unit tests for method __iter__ of class OptionParser"""
        
        
    
        
    

        
    
        
    

        
    
        def test_1(self):
            """Test #1"""
        
            import tornado.options
            import types
            import unittest.mock
            import functools
            import types

            import tornado.options
            
            import unittest
            import tornado.testing
            import tornado.gen
            
            def setUpModule():
                tornado.options.define("myoption1", default=1, type=int)

# Generated at 2022-06-12 14:02:16.897243
# Unit test for method parse of class _Option
def test__Option_parse():
    _Option.UNSET = object()
    option = _Option("name",default=None, type=None,help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    try:
        option.parse(value='key=value')
    except Exception:
        assert True
    else:
        assert False



# Generated at 2022-06-12 14:02:20.615456
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    o = OptionParser()
    o.define("debug", default=False, type=bool)
    #  if sys.platform == 'win32':
    #      o.define('profile', default=False, type=bool)
    assert list(o.keys()) == ['debug']

# Generated at 2022-06-12 14:02:41.475465
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    opt = OptionParser()
    opt.define('--foo', help="Foo", type=str)
    opt.foo = 'bar'
    assert opt.foo == 'bar'


# Generated at 2022-06-12 14:02:42.641651
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
  r = OptionParser()
  expected = []
  actual = []
  for i in r:
    actual.append(i)
  assert expected == actual

# Generated at 2022-06-12 14:02:48.581522
# Unit test for method value of class _Option
def test__Option_value():
    a = OptionParser()
    b = _Option('name', default=None, type=None, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    try:
        b.value()
        print('test__Option_value success')
    except Exception as e:
        b.value()
        print('test__Option_value failed')



# Generated at 2022-06-12 14:02:57.642877
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    options = OptionParser()
    options.define("x", type=float, default=1.0)
    options.define("y", type=int, default=2)
    options.define("z", default="hello")
    options.parse_command_line(["--x=1.2", "--y=3", "--z=word"])
    assert options.x == 1.2
    assert options.y == 3
    assert options.z == "word"

    options.parse_command_line(["--no_z=true", "--no_y", "--no_x"])
    assert options.x is False
    assert options.y is False
    assert options.z is False

    options.reset()

# Generated at 2022-06-12 14:03:06.731883
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    import unittest

    def myfunc():
        import itertools

        s = [1, 2, 3]
        _s = [1, 2, 3]

        c = itertools.cycle(s)
        _c = itertools.cycle(_s)
        assert list(c) == list(_c)
        assert list(c) == list(_c)

        c = itertools.cycle(s)
        _c = itertools.cycle(_s)
        assert next(c) == next(_c)
        assert next(c) == next(_c)

    myfunc()

# Generated at 2022-06-12 14:03:15.521743
# Unit test for method set of class _Option

# Generated at 2022-06-12 14:03:26.667115
# Unit test for method parse of class _Option
def test__Option_parse():
    sample_values = ["", "   ", " 3 ", " ", "a,b", "a", "a:", "1:3"]
    for value in sample_values:
        # parse for type datetime.datetime
        a1 = _Option("name", default=None, type=datetime.datetime, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
        a2 = _Option("name", default=None, type=datetime.datetime, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
        try:
            a1.parse(value)
            a2.parse(value)
        except Error:
            a1.parse(value)

# Generated at 2022-06-12 14:03:31.759983
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    obj_mockable = _Mockable(options)
    obj_mockable.__setattr__(name, value)
    assert name not in self._originals, "don't reuse mockable objects"
    self._originals[name] = getattr(self._options, name)
    setattr(self._options, name, value)
test__Mockable___setattr__()

# Generated at 2022-06-12 14:03:40.940903
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    global options
    options = OptionParser()
    options.define("name", type=str, default="", multiple=True)
    options.define("value", type=str, default="")
    options.parse_config_file("/opt/work/tornado/tornado/test/options_test.conf")
    assert "name" in options._options
    assert "value" in options._options

test_OptionParser_parse_config_file()
if hasattr(sys, "frozen"):  # py2exe, PyInstaller, etc.
    # When we are frozen, default to "production" settings
    DEFAULT_LOGGING = "none"
else:
    # When we are unfrozen, default to "debug" settings
    DEFAULT_LOGGING = "debug"


# Generated at 2022-06-12 14:03:47.575057
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    class Options(object):
        def __setattr__(self, name, value):
            if name == '_originals':
                object.__setattr__(self, name, value)
            elif name != '_options':
                assert '_options' in self.__dict__
                setattr(self._options, name, value)
    class OptionParser(object):
        def __getattr__(self, name):
            return getattr(self._options, name)
        def __setattr__(self, name, value):
            assert name != '_options'
            object.__setattr__(self, name, value)
    class TestCase(unittest.TestCase):
        def setUp(self):
            self.options = Options()
            self.options._options = OptionParser()
            self.options._options._

# Generated at 2022-06-12 14:04:08.019960
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    class MockOptionParser:
        counter = 0
        def __init__(self, *args, **kwargs):
            pass
        def define(self, *args, **kwargs):
            MockOptionParser.counter += 1
    # Testing normal cases
    # Case:
    #   _options = {}
    #   _parse_callbacks = []
    #   _additional = {}
    options = Options(option_class=MockOptionParser)
    options.a = 1
    eq_(MockOptionParser.counter, 1)
    eq_(options.a, 1)
    # Case:
    #   _options = {}
    #   _parse_callbacks = []
    #   _additional = {'a': 1}
    # Case:
    #   _options = {}
    #   _parse_callbacks = []

# Generated at 2022-06-12 14:04:13.035054
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    # Testing function OptionParser.__setattr__
    # Tests class OptionParser.__setattr__
    from io import StringIO
    from tornado.options import define, options
    define("hello", default=1, help="helpful message")
    define("world", default=2, help="helpful message")
    with pytest.raises(AttributeError):
        options.nothing  # type: ignore
    options.hello = 3  # type: ignore
    print_option_help(StringIO())
    options.hello = None

# Generated at 2022-06-12 14:04:20.702317
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    """
        Test method parse_config_file of class OptionParser.
    """
    def read_file(file_path):
        """
            Read a file, in order to check if the content is what we want.
        """
        file_object = open(file_path, 'rb')
        try:
            content = file_object.read()
        finally:
            file_object.close()

        return content
    def exec_in_file(file_path):
        """
            Execute a file and check the content inside.
        """
        file_object = open(file_path, 'rb')
        try:
            exec_in(native_str(file_object.read()), globals(), globals())
        finally:
            file_object.close()

    #print("test_OptionParser_parse_config_file

# Generated at 2022-06-12 14:04:23.801306
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    options = OptionParser()
    options.define('name', type=str, default='', help='')
    options.__setattr__('name', 'value')
    assert options.name == 'value'

# Generated at 2022-06-12 14:04:34.170951
# Unit test for method parse of class _Option

# Generated at 2022-06-12 14:04:37.519858
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    op = OptionParser()
    op.define('define_1',default=1)
    op.define('define_2',default=2)
    op.define('define_3',default=3)
    assert op.define_1 == 1
    assert op.define_2 == 2
    assert op.define_3 == 3
    op.define_3 = 33
    assert op.define_3 == 33


# Generated at 2022-06-12 14:04:46.169491
# Unit test for method parse of class _Option
def test__Option_parse():
    class TestOptionParser(OptionParser):
        pass

    option = _Option(
        name="fake_option",
        type=str,
        help="fake_option:help",
        metavar="fake_option: metavar",
        multiple=False,
        file_name="fake_option:file_name",
        group_name="fake_option:group_name",
        callback=None,
    )
    option.parse("fake_options:value")
    assert option.value() == "fake_options:value"
option_parse = test__Option_parse()


# Generated at 2022-06-12 14:04:56.708647
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    import os.path
    import sys
    from tornado.testing import gen_test, AsyncTestCase
    from tornado.web import Application, RequestHandler
    from tornado.ioloop import IOLoop
    from tornado.options import define, parse_config_file, options, OptionParser

    import tornado.testing as testing
    from tornado.options import LogFormatter, OptionParser
    from tornado.log import app_log, gen_log
    app_log.propagate = False
    app_log.handlers = []
    app_log.addHandler(testing.LogTrapTestCase.logTrap)
    app_log.setLevel(testing.LogTrapTestCase.logTrap.level)
    gen_log.propagate = False
    gen_log.handlers = []

# Generated at 2022-06-12 14:05:06.926640
# Unit test for method value of class _Option
def test__Option_value():
    import pathlib
    from typing import List
    from datetime import datetime
    from pytest import mark
    from . import options
    from .options import _parse_config_file
    def test_value_default():
        import datetime
        from typing import Union
        from pytest import mark
        from .options import _Option
        # Test when `_Option`'s `_value` is UNSET
        o = _Option('test_value', type=Union[int, str, bool], default=1)
        assert o.value() == 1
        o = _Option('test_value', type=Union[int, str, bool], default='foo')
        assert o.value() == 'foo'
        o = _Option('test_value', type=Union[int, str, bool], default=True)

# Generated at 2022-06-12 14:05:09.907707
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    from py3test.mock import Mock

    def gettest():
        return

    options = Mock()
    options.__dict__["name"] = "name"
    __mockable = _Mockable(options=options)
    __mockable.__setattr__(name="name", value="value")
    del __mockable  # Ensures test coverage of __delattr__



# Generated at 2022-06-12 14:06:44.333759
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    dirname = os.path.dirname(os.path.realpath(__file__))
    config_file = os.path.join(
        dirname,
        'resources/tornado/options_test_config.txt')
    parser = OptionParser()
    parser.define("one", type=int, default=1, help="one")
    parser.define("two", type=int, default=2, help="two")
    parser.define("three", type=int, default=3, help="three")
    parser.define("four", type=int, default=4, help="four")
    parser.parse_config_file(config_file)
    assert parser.one == 111
    assert parser.two == 2
    assert parser.three == 333
    assert parser.four == 4

# Generated at 2022-06-12 14:06:54.887246
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    cls = OptionParser
    obj = cls()
    try:
        obj.define("default", default=True)
        obj.define("int", type=int)
        obj.define("float", type=float)
        obj.define("str", type=str)
        obj.define("datetime", type=datetime.datetime)
        obj.define("timedelta", type=datetime.timedelta)
        obj.define("multiple")
        obj.define("group", group="group")
        obj.run_parse_callbacks()
        print(obj.as_dict())
        assert 0
    except Exception:
        pass



###############################################################################
# Copyright 2018 The Tornado Authors.
# Copyright 2016 The Kubernetes Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License

# Generated at 2022-06-12 14:07:01.439043
# Unit test for method parse of class _Option
def test__Option_parse():
    import time
    from tornado.options import options
    from tornado.options import define
    define("name_1", default=1.0, type=float)
    define("name_2", default="a", type=str)
    define("name_3", default=[], type=float, multiple=True)
    define("name_4", default=False, type=bool)
    define("name_5", default=None, type=datetime.datetime)
    define("name_6", default=None, type=datetime.timedelta)
    define("name_7", default="c", type=str, multiple=True)
    # Test parse float value
    assert _Option("name_1", default=1.0, type=float, multiple=False).parse("1.1") == 1.1

# Generated at 2022-06-12 14:07:13.201120
# Unit test for method parse of class _Option
def test__Option_parse():
    from tornado.testing import AsyncHTTPTestCase
    from tornado.web import RequestHandler, Application
    from tornado.ioloop import IOLoop
    import requests
    import unittest
    import time
    import os
    import re
    import json
    import time
    import random
    import logging
    import sys
    
    class Test_Handler(RequestHandler):
        def initialize(self, conf):
            self.conf = conf

        def get(self):
            self.conf.add_parse_callback(self.conf.run_parse_callbacks)
            self.conf.add_parse_callback(self.conf.print_help)
            self.write("The option value of the option 'help' is: " + str(self.conf.help))


# Generated at 2022-06-12 14:07:20.439892
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    # Check whether method iter(op) of class OptionParser
    # calls the method keys of class OptionParser,
    # and returns the result of this call.
    _keys = mock.Mock()
    op = options._OptionParser()
    op._keys = _keys
    result = iter(op)
    assert result is _keys.return_value.__iter__.return_value
    assert len(_keys.mock_calls) == 1
    assert _keys.mock_calls[0] == mock.call()


# Generated at 2022-06-12 14:07:27.489636
# Unit test for method parse of class _Option
def test__Option_parse():
    o = _Option(name="name", type=datetime.datetime, multiple=False)
    dt = o.parse("Sat May 28 23:07:53 2016")
    print(o.value())
    print(dt)
    dt = o.parse("2016-05-28 23:07:53")
    print(o.value())
    print(dt)
    dt = o.parse("2016-05-28 23:07")
    print(o.value())
    print(dt)
    dt = o.parse("20160528 23:07:53")
    print(o.value())
    print(dt)
    dt = o.parse("20160528 23:07")
    print(o.value())
    print(dt)
    dt = o.parse("2016-05-28")


# Generated at 2022-06-12 14:07:38.422926
# Unit test for method parse of class _Option
def test__Option_parse():
    option_parser = OptionParser()

    option = _Option(
        name='name',
        default=None,
        type=datetime.datetime,
        help=None,
        metavar=None,
        multiple=False,
        file_name=None,
        group_name=None,
        callback=None)

    # _parse_datetime, datetime型はNoneが帰る
    assert option.parse('2019-12-02 17:50:00') is None
    assert option.parse('2019-12-02 17:50') is None
    assert option.parse('2019-12-02T17:50') is None
    assert option.parse('20191202 17:50:00') is None
    assert option.parse('20191202 17:50') is None

# Generated at 2022-06-12 14:07:45.757048
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    parser = OptionParser()
    parser.define('name1', None, type=str)
    parser.define('name2', None, type=str)
    parser.name1 = 'val1'
    parser.name2 = 'val2'
    option_names = ['name1', 'name2']
    option_name_set = set(option_names)
    i = 0
    for option_name in parser:
        assert option_name in option_name_set
        i += 1

    assert i == 2


# Generated at 2022-06-12 14:07:50.736368
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    parser = OptionParser()
    parser.define("name1", type = str)
    parser.define("name2", type = str)
    parser.define("name3", type = str)
    iter_result = []
    for option in parser:
        iter_result.append(option)
    assert iter_result == ['name1', 'name2', 'name3']



# Generated at 2022-06-12 14:08:01.299380
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    option = OptionParser()
    option.define("port", type=int, default=80)
    option.define("mysql_host", type=str, default='localhost')
    option.define("memcache_hosts", type=str, default='localhost', multiple=True)

    config_file_content = """
    port = 80
    mysql_host = 'mydb.example.com:3306'
    # Both lists and comma-separated strings are allowed for
    # multiple=True.
    memcache_hosts = ['cache1.example.com:11011',
                      'cache2.example.com:11011']
    memcache_hosts = 'cache1.example.com:11011,cache2.example.com:11011'
    """

# Generated at 2022-06-12 14:08:49.303310
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    try:
        # Parsing of the config file, which is located in the current directory
        Options.parse_config_file(path="test_config_file.py")
        # Check if the real value is correct
        assert Options.virtual1 == "TRUE"
        assert Options.virtual2 == "9999"
        assert Options.virtual3 == "10"
        assert Options.virtual4 == "20"
    except:
        assert False

# Generated at 2022-06-12 14:08:53.234910
# Unit test for method set of class _Option
def test__Option_set():
    with pytest.raises(Error) as err:
        o = _Option(None, type=int, multiple=False)
        o.set(1.1)
    assert err.value.args[0] == "Option None is required to be a int (float given)"



# Generated at 2022-06-12 14:09:03.214721
# Unit test for method parse of class _Option
def test__Option_parse():
    from unittest.mock import patch
    import datetime
    from unittest import TestCase
    from dateutil.parser import parse

    class MockedOption(object):
        def __init__(self, file_name: Optional[str] = None, group_name: Optional[str] = None):
            self.file_name = file_name
            self.group_name = group_name

    class MockedOptionTest(TestCase):
        @patch.object(_Option, '__init__', return_value=None)
        def test_datetime(self, mocked_init) -> None:
            mocked_option = MockedOption()

            # datetime.datetime.strptime() is mocked by patch.object

# Generated at 2022-06-12 14:09:07.602102
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # 1. test normal case
    options = OptionParser()
    options.define(name="test1", default="default1")
    options.define(name="test2", default="default2")
    options.parse_config_file("./test_config_file.py")


# Generated at 2022-06-12 14:09:15.483257
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    def t():
        op = OptionParser()
        op.define("foo", default=1)
        op.define("bar", default=2)
        return op
    op = t()
    if op.foo != 1 or op.bar != 2:
        print("Err")

    op.parse_command_line([])
    if op.foo != 1 or op.bar != 2:
        print("Err")

    op.parse_command_line(["--foo=2", "--bar=3"])
    if op.foo != 2 or op.bar != 3:
        print("Err")

    print(list(op))



# Generated at 2022-06-12 14:09:20.978528
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    _options = OptionParser()
    _options.define('name', default='test')
    _options.define('--option', default='test')
    _options.define('--option2', default='test')
    res = [] 
    for name in _options:
        res.append(name)
    assert(res == ['name', 'option', 'option2'])


# Generated at 2022-06-12 14:09:31.063824
# Unit test for method parse of class _Option
def test__Option_parse():
    _Option('name', "default", datetime.datetime, help="help", metavar='metavar', multiple=True, file_name='file_name', group_name='group_name', callback=lambda x: x + 1)

# Generated at 2022-06-12 14:09:39.641999
# Unit test for method parse of class _Option
def test__Option_parse():
    import time
    import datetime
    option = options.define('test_option', type=datetime.datetime)
    opt = _Option('test', "10 Jun 2018 03:00", type=datetime.datetime)
    # test parse
    assert opt.parse(option.value()) == datetime.datetime(2018, 6, 10, 3, 0)
    opt = _Option('test', "10 Jun 2018 03:00:00", type=datetime.datetime)
    assert opt.parse(option.value()) == datetime.datetime(2018, 6, 10, 3, 0)
    opt = _Option('test', "10 Jun 2018 03:00:00", type=datetime.datetime)
    assert opt.parse(option.value()) == datetime.datetime(2018, 6, 10, 3, 0)
    opt

# Generated at 2022-06-12 14:09:46.576769
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    opts = OptionParser()
    opts.parse_command_line(['-h'])
    opts.help = 'root'
    assert opts.help == 'root'
    try:
        opts.parse_command_line([])
    except:
        assert True
    else:
        assert False
    try:
        opts.parse_command_line(['--help'])
    except:
        assert True
    else:
        assert False
    opts.define('name', default='root')
    opts.parse_command_line(['--name=root'])
    assert opts.name == 'root'
    try:
        opts.parse_command_line([])
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-12 14:09:54.019302
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    options.define('a', type=int, default=1)
    options.define('b', type=int, default=2)
    options.define('c', type=int, default=3)
    options.define('d', type=int, default=4)
    options.define('e', type=int, default=5)
    options.define('f', type=int, default=6)
    options.define('g', type=int, default=7)
    options.define('h', type=int, default=8)
    result = []
    for option in options:
        result.append(option)
    assert ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']==result
