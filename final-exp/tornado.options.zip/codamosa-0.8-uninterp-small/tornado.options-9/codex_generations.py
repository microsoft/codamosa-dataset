

# Generated at 2022-06-26 08:28:44.080109
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    """Unit test for method __iter__ of class OptionParser"""
    print()
    print('UNIT TESTING FOR METHOD def __iter__(self)')

    # Create an instance of the OptionParser
    op = OptionParser()

    # Set a few options for testing
    op.define('port', default=80, type=int, help='Port number.')
    op.define('host', default='localhost', type=str, help='Host address.')
    op.define('time', default=None, type=str, help='Time of the request.')

    # Test each option
    print('option: port, type: int, value: 80')
    print('option: host, type: str, value: localhost')
    print('option: time, type: str, value: None')

    # Test the OptionParser if all the option is recorded

# Generated at 2022-06-26 08:28:46.665681
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    parser = OptionParser()

    parser.parse_command_line()


# Generated at 2022-06-26 08:28:54.887839
# Unit test for method set of class _Option
def test__Option_set():
    option = _Option(
        name="mockable",
        default=None,
        type=str,
        help=None,
        metavar=None,
        multiple=False,
        file_name=None,
        group_name=None,
        callback=None,
    )
    option.set("Mockable")
    print(option._value)

if __name__ == "__main__":
    test_case_0()
    # test__Option_set()

# Generated at 2022-06-26 08:29:06.513208
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():

    path = get_tornado_test_dir() + "/tornado_test/options/config_file"
    # Read content of the config file using class OptionParser
    config_file_content = ""
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            config_file_content += line
    print("config_file_content:", config_file_content)
    # Create an instance of class OptionParser
    parser = OptionParser()
    # Define option options.keystore
    parser.define("keystore", default=None, help="Path to keystore file.", type=str)
    # Define option options.cookie_secret
    parser.define("cookie_secret", default=None, help="Cookie secret.", type=str)
    # Parse the config file to set values of the

# Generated at 2022-06-26 08:29:10.155871
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    op = OptionParser()
    op.define('name', default='value', type=str, help='name of configuration file', metavar='FILE')
    op.parse_config_file('test_file.cfg')


# Generated at 2022-06-26 08:29:19.056135
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # Test 1:
    # Test comment
    text = """
    # Test comment
    # Test comment
    # Test comment
    """
    config = {}
    exec_in(text, config, config)
    assert config.get('__file__') == '__config__'
    # Test 2: test for single line comment
    text = """
    # Test comment
    port = 80
    """
    config = {}
    exec_in(text, config, config)
    assert config.get('port') == 80
    # Test 3: test for single line comment
    text = """
    # Test comment
    host1 = 'example.com'
    """
    config = {}
    exec_in(text, config, config)
    assert config.get('host1') == 'example.com'

# Test 2: test for

# Generated at 2022-06-26 08:29:27.502663
# Unit test for method set of class _Option
def test__Option_set():
    name = "name"
    type = bool
    option = _Option(name, type = type)

    # case 1: value is a bool
    value = False
    option.set(value)
    assert option.value() == value

    # case 2: value is not a bool
    value = "2"
    try:
        option.set(value)
    except Error as e:
        assert True
    else:
        assert False

# Generated at 2022-06-26 08:29:39.976673
# Unit test for method parse of class _Option
def test__Option_parse():
    import unittest
    import os
    import sys
    import tempfile

    class Test_Option(unittest.TestCase):
        def setUp(self):
            self.options = OptionParser()

        def test_integer(self):
            self.options.define('test_integer', default=0)
            self.options.define('test_integer_prefix', default=[], multiple=True)
            self.options.define('test_integer_larger', default=0)

            self.options.parse_command_line(['--test_integer', '10'])
            self.assertEqual(self.options.test_integer, 10)

            # multiple
            self.options.parse_command_line(['--test_integer_prefix', '1', '2', '4'])

# Generated at 2022-06-26 08:29:44.238839
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    # test 1
    # unit test for parse_command_line with no args
    options.parse_command_line()
    assert options.logging == "debug"
    assert options.testing == False
    assert options.port == 8000
    assert options.server == "localhost"

    # test 2
    # unit test for parse_command_line with args: ["--port=90", "--logging=info"]
    options.reset()
    options.parse_command_line(["--port=90", "--logging=info"])
    assert options.port == 90
    assert options.logging == "info"

    # test 3
    # unit test for parse_command_line with args: ["--testing"]
    options.reset()
    options.parse_command_line(["--testing"])
    assert options.testing == True



# Generated at 2022-06-26 08:29:52.873539
# Unit test for method parse of class _Option
def test__Option_parse():
    print("Test case 0: Test the parse of _Option()")
    #test_case_0()
    print("Test case 1: test the parse of _Option()")
    default = None
    type = int
    multiple = False
    option = _Option("port", default, type, None, None, multiple)
    value_0 = "80"
    option.parse(value_0)
    print(option.__dict__)
    assert (option.value(), 80)
    value_1 = "8080"
    option.parse(value_1)
    assert(option.value(), 8080)
    print_help()
    print("=" * 60)



# Generated at 2022-06-26 08:30:47.362964
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    op = OptionParser()
    assert op.parse_command_line() == []
    assert op.parse_command_line([]) == []
    assert op.parse_command_line(["a"]) == ["a"]
    assert op.parse_command_line(["a", "b"]) == ["a", "b"]
    assert op.parse_command_line(["--logging=info"]) == []
    assert op.parse_command_line(["--logging", "info"]) == []
    assert op.parse_command_line(["--logging", "info", "a"]) == ["a"]
    assert op.parse_command_line(["--log", "info"]) == []
    assert op.parse_command_line(["--logging=info", "--log", "debug"]) == []

# Generated at 2022-06-26 08:30:55.943072
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    op = OptionParser()
    test = OptionParser()
    test.define("port", type=int, default=80, metavar="N", help="set the port")
    test.define("memcache", default="127.0.0.1:11211", multiple=True,
                help="memcache servers")
    test.define("log_file_prefix", type=str, default=None, metavar="PATH",
                help="Path prefix for log files")
    test.define("log_to_stderr", type=bool, default=False,
                help="If true, log will go to stderr")
    test.define("logging", default="info",
                help="Set the Python log level. If 'none', tornado won't touch "
                     "the logging configuration."
                     "bose - info - debug")
   

# Generated at 2022-06-26 08:31:07.129681
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    option_parser = OptionParser()
    option_parser.define('port', default=8888, type=int,
                         help="the port of listen")
    # case 0, no file or not exist
    try:
        option_parser.parse_config_file('')
    except Exception as e:
        assert type(e) == Error
    # case 1, normal case
    option_parser.parse_config_file('dns.conf')
    assert option_parser.port == 9999
    # case 2, not a file
    try:
        option_parser.parse_config_file('dns')
    except Exception as e:
        assert type(e) == Error


# Generated at 2022-06-26 08:31:19.893801
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    print("test_OptionParser___iter__")
    options = OptionParser()
    options.define(flag='f', int_1='i', int_2='i', int_3='i', int_4='i', int_5='i')
    options.define('int_1', default=0, type=int, metavar='N')
    options.define('int_2', default=[], type=int, multiple=True)
    options.define('int_3', default=None, type=int)
    options.define('int_4', default=[], type=int, multiple=True)
    options.define('int_5', default=None, type=int)

# Generated at 2022-06-26 08:31:26.712715
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    options.define("port", type=int, help="port to listen on")
    options.define("debug", type=bool, help="open debug")
    options.parse_config_file("test_options.conf")
    # print(options)
    print(options.port)
    print(options.debug)



# Generated at 2022-06-26 08:31:33.173171
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    _options = {}
    _parse_callbacks = []

    # Arrange
    name = "test_name"
    default = "test_default"
    type = str
    help = "test help"
    metavar = "abc"
    multiple = "True"
    group = "test group"
    option = _Option(
        name,
        file_name="",
        default=default,
        type=type,
        help=help,
        metavar=metavar,
        multiple=multiple,
        group_name=group
    )

    # Act
    _options[name] = option
    parser = OptionParser()

# Generated at 2022-06-26 08:31:44.153202
# Unit test for method set of class _Option
def test__Option_set():
    default = 'abc'
    type = str
    help = 'help'
    metavar = None
    multiple = False
    file_name = None
    group_name = None
    callback = None

    o = _Option(
        name,
        default,
        type,
        help,
        metavar,
        multiple,
        file_name,
        group_name,
        callback,
    )

    # test case 1
    value = 'test'
    o.set(value)
    assert o._value == value

    # test case 2
    value = None
    o.set(value)
    assert o._value == value

    # test case 3
    value = 0
    try:
        o.set(value)
    except Error:
        pass
    else:
        assert False

    #

# Generated at 2022-06-26 08:31:57.030813
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    # Test OptionParser object.
    option_parser = OptionParser()
    # Test OptionParser.__iter__().
    for name, _ in option_parser:
        print(name, option_parser.get(name))


if __name__ == "__main__":
    args = sys.argv
    # option_parser = OptionParser()
    # for name, _ in option_parser:
    #     print(name, option_parser.get(name))
    if len(sys.argv) >= 2:
        if sys.argv[1] == "0":
            test_case_0()
        else:
            print("Unknown option: {}".format(sys.argv[1]))
    else:
        print("1. Test method __iter__ of class OptionParser")

# Generated at 2022-06-26 08:32:07.787708
# Unit test for method parse of class _Option
def test__Option_parse():
    # The first part is to define a variable self.type,
    # and other variable is optional.
    option = _Option(name='_Option', type=str, help='help of _Option', file_name='filename', group_name='groupname')
    print('type of option is: %s' % option.type)
    # The second part is to test if the parse function works well.
    print('parse 123: %s' % (option.parse('123'),))
    print('parse abc: %s' % (option.parse('ABC'),))
    print('parse datetime: %s' % (option.parse('2018-04-22 11:13:17'),))
    # The third part is to test if the callback works well.
    option.callback = test_callback
    option.parse('abc')
    # The last part is

# Generated at 2022-06-26 08:32:10.791072
# Unit test for method set of class _Option
def test__Option_set():
    test = _Option("test", default="", type = str, help = "", metavar = "", multiple = False, file_name = "", group_name = "", callback = None)
    test.set("test")


# Generated at 2022-06-26 08:32:42.386586
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    args = ["./test.py", "--name=John", "--lastname=Doe", "foo", "bar"]
    sys.argv = args
    options = OptionParser()
    options.define("name", type=str, help="name", group="test")
    options.define("lastname", type=str, help="last name", group="test")
    options.parse_config_file("config.conf")
    print("Current value of name is", options.name)
    print("Current value of lastname is", options.lastname)


if __name__ == "__main__":
    # test_OptionParser_parse_command_line()
    # test_OptionParser_parse_config_file()
    test_case_0()

# Generated at 2022-06-26 08:32:48.653654
# Unit test for method parse of class _Option
def test__Option_parse():
    theOption = _Option("name", default=None, type=str, help="", metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    res = theOption.parse(value="")
    print(res)


# Generated at 2022-06-26 08:33:03.201157
# Unit test for method parse of class _Option
def test__Option_parse():
    import unittest
    import string
    from .helpers import TestCase
    from .helpers import AsyncTestCase

    # Test parse of _Option.parse
    class _Option_parse(TestCase):
        def test_case_0(self):
            # Test parse of _Option.parse
            option = _Option(name='testname', type=string.ascii_letters)
            # Test 0:
            # Test 1:
            # Test 2:
            # Test 3:
            # Test 4:
            # Test 5:
            # Test 6:
            # Test 7:
            # Test 8:
            # Test 9:
            # Test 10:
    unittest.main()

if __name__ == "__main__":
    test_case_0()
    test__Option_parse()

# Generated at 2022-06-26 08:33:06.222903
# Unit test for method parse of class _Option
def test__Option_parse():
    op = _Option('demo', type=str, multiple=True, default=None)
    print(op.parse('1,2,3'))
    print(op.parse('[1,2,3]'))


# Generated at 2022-06-26 08:33:15.215058
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    # step 1. define options
    define("port", default=8080, type=int, help="run on the given port", metavar="PORT")
    define("address", default="localhost", type=str, help="run on the given address", metavar="ADDRESS")
    define("debug", default=None, help="run in debug mode", callback=print_help)
    define("flag", default=False, help="Run in flag mode", callback=print_help)
    # step 2. parse options
    parse_command_line()
    # step 3. show options
    print(options.port)
    print(options.address)


# Generated at 2022-06-26 08:33:20.167055
# Unit test for method group_dict of class OptionParser
def test_OptionParser_group_dict():
    group_name = 'Application'
    key = 'template_path'
    value = 'templatePath'
    test_case_1(key, value, group_name)


# Generated at 2022-06-26 08:33:23.918840
# Unit test for method set of class _Option
def test__Option_set():
    test_Option_1 = _Option('name1', default=None)
    test_Option_1.set(value=1)
    assert test_Option_1.value() == 1


# Generated at 2022-06-26 08:33:29.010393
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    op = OptionParser()
    it = iter(op)
    op.define('name', default=None)
    # This test will cause the program terminate with error message:
    #     "RuntimeError: dictionary changed size during iteration".
    # It means that the dictionary _options in class OptionsParser has been changed
    # when the code is executing the corresponding __iter__ method.
    # print(next(it))
    print(next(it))


# Generated at 2022-06-26 08:33:38.663765
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    define("Test_option_parser", type=int)

    # case 1: read from configuration file.
    test_config_file = 'test_config_file.cfg'
    with open(test_config_file, 'w') as f:
        f.write('Test_option_parser = 1')
    parse_config_file(test_config_file)
    assert options.Test_option_parser == 1
    os.remove(test_config_file)

    # case 2: read from configuration file and command line argument.
    test_config_file = 'test_config_file.cfg'
    with open(test_config_file, 'w') as f:
        f.write('Test_option_parser = 1')
    parse_config_file(test_config_file)


# Generated at 2022-06-26 08:33:48.463632
# Unit test for method parse of class _Option
def test__Option_parse():
    try:
        option = _Option("name", type = datetime.datetime, help = "my datetime")
    except ValueError as e:
        option = None
        return
    except Exception as e:
        print(e)
        exit()

    if option is None:
        option = _Option("name", type=datetime.datetime, help="my datetime")
    try:
        value = "Sat Dec 22 14:52:52 2012"
        option.parse(value)
    except ValueError as e:
        print(e)
        option.parse(value)
    except Exception as e:
        print(e)
        exit()

    try:
        value = "2012 Dec 22 14:52:52"
        option.parse(value)
    except ValueError as e:
        print(e)
        option

# Generated at 2022-06-26 08:34:16.609588
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    test_oParser = OptionParser()
    test_oParser.define('test_define',default='test_default')
    test_oParser.parse_config_file('/tmp/test_config')
    assert test_oParser.test_define == 'test_default'


# Generated at 2022-06-26 08:34:30.748728
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # Get the sets of options in advance
    op = OptionParser()
    opt_set_before = set(op._options.keys())
    op.define("opt1", default=0)
    op.define("opt2", default=0)
    opt_set_include_config_file = set(op._options.keys())
    opt_set_additional = set(("opt3", "opt4"))
    opt_set_all = opt_set_include_config_file | opt_set_additional  # Union
    opt_set_config_file = opt_set_all - opt_set_before  # Diff
    opt_set_config_file_override = opt_set_config_file - opt_set_additional

    # Parse the config file
    op.parse_config_file("test_config.py")

# Generated at 2022-06-26 08:34:34.826060
# Unit test for method parse of class _Option
def test__Option_parse():
    opt = _Option("test_Option", default="", type=str, help="", metavar="string")
    print("opt @ {0}".format(opt))
    value = opt.parse("foo")
    print("value @ {0}".format(value))

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 08:34:43.762954
# Unit test for method parse of class _Option
def test__Option_parse():
    _parse_timedelta("2s")

    _parse_bool("true")
    _parse_bool("false")
    _parse_bool("True")
    _parse_bool("False")
    _parse_bool("1")
    _parse_bool("0")
    _parse_bool("t")
    _parse_bool("f")

    _parse_timedelta("1 days 1 min")
    _parse_timedelta("1 days 1 min")
    _parse_timedelta("2d1min")
    _parse_timedelta("1 d 1 mi n") # space in between
    _parse_timedelta("02d")       # leading 0
    try:
        _parse_timedelta("1days1mind")
        assert False
    except Exception:
        pass


# Generated at 2022-06-26 08:34:53.276653
# Unit test for method set of class _Option
def test__Option_set():
    print('Unit test for method set of class _Option')
    # Test 1
    _opt = _Option(name='_name', type=int)
    _opt.set(1)
    assert _opt.value() == 1
    print('Test 1 passing')
    # Test 2
    _opt = _Option(name='_name', type=int)
    _opt.set([10,20,30])
    assert _opt.value() == [10,20,30]
    print('Test 2 passing')
    # Test 3
    _opt = _Option(name='_name', type=str, multiple=True)
    _opt.set('a,b,c')
    assert _opt.value() == ['a', 'b', 'c']
    print('Test 3 passing')


# Generated at 2022-06-26 08:35:01.424991
# Unit test for method set of class _Option
def test__Option_set():
    _Option(name="age", default=1, type=int, multiple=False).set(101)
    # print(value)
    _Option(name="age", default=1, type=int, multiple=False).set(None)
    # print(value)
    _Option(name="age", default=1, type=int, multiple=False).set(101.0)
    # print(value)


# Generated at 2022-06-26 08:35:03.828313
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    # This unit test can't be implemented
    pass


# Generated at 2022-06-26 08:35:16.810314
# Unit test for method parse of class _Option

# Generated at 2022-06-26 08:35:27.245773
# Unit test for method parse of class _Option
def test__Option_parse():
    from datetime import datetime, timedelta

    def callback(value):
        print('Warning: value changed to %s' % value)

    # Test for datetime
    dt = _Option(
        name='datetime',
        type=datetime,
        help='datetime help',
        metavar='datetime',
        multiple=False,
        group_name='group1',
        callback=callback,
    )
    print('Test for datetime:')
    # datetime, string of datetime
    dt.parse('2019-01-17 13:00:00')
    print(dt.value())
    dt.parse('2019-01-17T13:00')
    print(dt.value())
    dt.parse('2019-01-17')
    print(dt.value())

# Generated at 2022-06-26 08:35:33.289600
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    # OPTIONS contains the definition for all command line options
    # used by the Tornado framework.
    # In addition to the options below, each Application subclass may define
    # additional options.
    define("logging", default="info", type=str, metavar="info|warning|error")
    define("log_to_stderr", default=False, type=bool)
    define("log_file_prefix", default=None, type=str)
    define("log_file_max_size", default=100 * 1000 * 1000, type=int)
    define("log_file_num_backups", default=10, type=int)
    define("log_rotate_when", default="midnight", type=str,
           metavar="s|m|h|d|w0-6|midnight")

# Generated at 2022-06-26 08:35:59.625435
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    parser = OptionParser()
    # 1. test for return type
    assert type(parser.parse_command_line()) == list 


# Generated at 2022-06-26 08:36:03.262880
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    print_help()
    option_parser = OptionParser()
    for o in option_parser:
        print(o)


# Generated at 2022-06-26 08:36:11.161302
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():

    # Get the current working directory
    path = os.path.split(os.path.realpath(__file__))[0]

    # Get to the directory for this file
    os.chdir(path)

    # Define an option
    define("test_option_0", default='test_option_0')

    # Call parse_config_file
    parse_config_file('test_config_file.conf')

    # Check the value of the option
    assert options.test_option_0 == 'test_option_0_1'


# Generated at 2022-06-26 08:36:15.996901
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    options = OptionParser()
    # options.parse_config_file('./test_options.conf')
    options.parse_config_file('./test_options.py')

# Generated at 2022-06-26 08:36:21.602340
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    # get default attributes of class OptionParser
    obj = OptionParser()
    default_args = sys.argv
    default_final = True
    # method parse_command_line to be tested
    try:
        result = obj.parse_command_line(default_args, default_final)
    except:
        pass
    assert result != None



# Generated at 2022-06-26 08:36:32.879038
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    op = OptionParser()
    op.define("port", default=8888, type=int, help="help string")
    op.define("mysql_host", default="mydb.example.com:3306")
    op.define("memcache_hosts", default=[], multiple=True)
    op.parse_config_file("D:\\pyarch\\tornado-master\\tornado\\test\\options_test1.conf")

    assert op.port == 80
    assert op.mysql_host == 'mydb.example.com:3306'
    assert op.memcache_hosts == ['cache1.example.com:11011', 'cache2.example.com:11011']



# Generated at 2022-06-26 08:36:44.827947
# Unit test for method set of class _Option
def test__Option_set():
    option = _Option("test", help="test")
    # case 0: set None to integer option
    option.set(None)
    assert option.value() is None
    # case 1: set None to multiple option
    option.multiple = True
    with pytest.raises(Error) as excinfo:
        option.set(None)
    assert 'is required to be a list of' in str(excinfo.value)
    # case 2: set list of integer to multiple option
    option.set([1, 2])
    assert option.value() == [1, 2]
    # case 3: set list of string to multiple integer option
    with pytest.raises(Error) as excinfo:
        option.set(['1', '2'])
    assert 'is required to be a list of' in str(excinfo.value)

# Generated at 2022-06-26 08:36:54.906610
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    print("\n\n==== [ test_OptionParser___iter__ ] ====")
    # Define, parse and print option values
    my_options = OptionParser()
    my_options.define("foo", default=False)
    my_options.define("bar", default=["a", "b", "c"], multiple=True)

    # print("my_options: {0}".format(my_options))
    print("my_options length: {0}".format(len(my_options)))

    for item in my_options:
        print("item: {0}".format(item))


# Generated at 2022-06-26 08:37:00.114409
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    parser = OptionParser()
    try:
        parser.parse_command_line()
    except:
        pass
    parser.print_help()


# Generated at 2022-06-26 08:37:09.407082
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    import sys
    opt = OptionParser()
    opt.define("name", default="test", type=str)
    opt.define("foo", default=None, type=str)
    opt.define("foo2", default=None, type=str)
    opt.define("foo3", default=None, type=str)
    opt.define("foo4", default=None, type=str)
    opt.define("foo5", default=None, type=str)
    opt.define("foo6", default=None, type=str)
    opt.define("foo7", default=None, type=str)
    opt.define("foo8", default=None, type=str)

    print("sys.argv:", sys.argv)
    opt.parse_command_line(sys.argv)