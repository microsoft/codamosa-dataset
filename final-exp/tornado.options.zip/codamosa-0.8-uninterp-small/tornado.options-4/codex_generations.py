

# Generated at 2022-06-26 08:28:31.011224
# Unit test for method set of class _Option
def test__Option_set():
    option = _Option(name="a", default=1, type=int, help="1")
    option.set(2)


# Generated at 2022-06-26 08:28:33.179542
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    p = OptionParser()
    p.define("env", default="test", help="test")
    p.parse_config_file("/tornado_test/config/test_conf1")
    # print(p.env)
    assert p.env == "test"


# Generated at 2022-06-26 08:28:42.317945
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    parser = OptionParser()
    # test parser.define(name, default, type, help, metavar, multiple, group, callback)
    name = '--name'
    default = 'default-value'
    type = 3
    help = 'help-info'
    metavar = 'metavar-name'
    multiple = False
    group = 'group-name'
    callback = 'callback-name'
    parser.define(name, default, type, help, metavar, multiple, group, callback)


# Generated at 2022-06-26 08:28:53.172098
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    """
    test_OptionParser_parse_command_line
    """
    args = ["/usr/bin/python2.7", "-g", "--", "aa", "bb", "cc"]
    list_0 = options.parse_command_line(args)
    assert list_0 == ["aa", "bb", "cc"]
    assert options.global_setting == True
    assert options.define_1 == 4
    assert options.define_2 == 2


# Generated at 2022-06-26 08:29:06.372435
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    name = None
    value = None
    options = None
    # begin case 0
    # source code:
    # if name in self._options:
    #     self._options[name].set(value)
    #     return
    # end case 0
    name = 'port'
    value = '80'
    options = OptionParser()
    options.define(name, default=None, type=None, help=None, metavar=None, multiple=False, group=None, callback=None)
    OptionParser___setattr__(options, name, value)
    if __check_equal_with_print__('options.port', options.port, value):
        pass
    else:
        return False
    # begin case 1
    # source code:
    # self.__dict__[name] = value
    # end case

# Generated at 2022-06-26 08:29:07.732438
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    list_0 = parse_command_line()



# Generated at 2022-06-26 08:29:17.711292
# Unit test for method set of class _Option
def test__Option_set():
    name_0 = ""; default_0 = None; type_0 = None; help_0 = None; metavar_0 = None; multiple_0 = False; file_name_0 = None; group_name_0 = None; callback_0 = None
    _option_0 = _Option(name = name_0, default = default_0, type = type_0, help = help_0, metavar = metavar_0, multiple = multiple_0, file_name = file_name_0, group_name = group_name_0, callback = callback_0)
    with pytest.raises(ValueError):
        _option_0.set(value = None)


# Generated at 2022-06-26 08:29:21.216302
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    list_0 = parse_command_line()


# Generated at 2022-06-26 08:29:29.336641
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    for i in range(1):
        list_0 = parse_command_line()
        if 1:
            tmp = list_0
    for i in range(1):
        list_0 = parse_command_line(args=None)
        if 1:
            tmp = list_0
    for i in range(0):
        list_0 = parse_command_line(final=True)
        if 1:
            tmp = list_0
    for i in range(0):
        list_0 = parse_command_line(args=None, final=True)
        if 1:
            tmp = list_0


# Generated at 2022-06-26 08:29:31.126159
# Unit test for method set of class _Option
def test__Option_set():
    option = _Option("name")
    try:
        option.set(True)
        raise AssertionError("Expected ValueError")
    except ValueError:
        pass


# Generated at 2022-06-26 08:29:59.451213
# Unit test for method set of class _Option
def test__Option_set(): 
    option = _Option("a", default=None, type=type(1), help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    option.set(1)
    

# Generated at 2022-06-26 08:30:02.444668
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    parser = OptionParser()
    list_0 = parser.__iter__()


# Generated at 2022-06-26 08:30:14.137652
# Unit test for method set of class _Option
def test__Option_set():
    import random
    import string
    import sys
    import types
    import unittest

    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    import tornado.options
    import tornado.testing

    @tornado.options.define("some_option", type=str)
    class MyOptionParser(tornado.options.OptionParser):
        """An OptionParser with a few extra options for testing."""

        def parse_command_line(self, args=None):
            """Saves a copy of the command-line arguments for use by unit tests."""
            result = super(MyOptionParser, self).parse_command_line(args)
            self.parsed_command_line = sys.argv[:]
            return result


# Generated at 2022-06-26 08:30:15.681678
# Unit test for method parse of class _Option
def test__Option_parse():
    pass


# Generated at 2022-06-26 08:30:24.281037
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    options = OptionParser()
    options.define('f', multiple=True)
    options.define('f2', multiple=True)
    options.define('d', type=float)
    options.define('b', type=bool)
    options.define('b2', type=bool)
    options.define('l', type=list)
    options.define('t', type=list)
    options.define('t2', type=list)
    options.define('s', type=str)
    args = options.parse_command_line('--d=0.125 --f a --f b --b --b2=false --s foo --l 1 --l 2'.split())
    assert options.f == ['a', 'b']
    assert options.f2 == []
    assert options.d == 0.125

# Generated at 2022-06-26 08:30:30.099087
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    try:
        parse_config_file("/media/sf_Refactor/Refactor/Tornado/test_options.conf", True)
    except Exception as e:
        print("Exception in parse_config_file():", e)


# Generated at 2022-06-26 08:30:41.445996
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    options = Options()
    options.define("port", default=8000, help="run on the given port", type=int)
    options.define("log_file_prefix", default='', help="log file", type=str)
    options.define("fake_log_file_prefix", default='', help="log file", type=str)
    
    def test_case_0():
        options.parse_config_file("/home/louis/py_test/tornado_test/test.conf")
        assert options.log_file_prefix=="log_file.log"
    
    def test_case_1():
        try:
            options.parse_config_file("/home/louis/py_test/tornado_test/test2.conf")
        except:
            print("Passed. ")
    

# Generated at 2022-06-26 08:30:47.564604
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # Initialize inputs and expected outputs
    options = OptionParser()
    path = "./test/config.cfg"

    # Call function with arguments and observe output
    options.parse_config_file(path)

    # Verify and Observe output
    assert options.listen == 3306
    assert options.port == 80
    assert options.debug == True
    assert options.d is None
    assert options.db == None
    assert options.db_config == {'user': 'user', 'pwd': 'pwd'}
    assert options.db_url == "mysql://user:pwd@localhost:3306"
    assert options.log_format == '%(msecs)d %(levelname)s %(message)s'
    assert options.log_file_prefix == "./test/log/test.log"
   

# Generated at 2022-06-26 08:30:56.245226
# Unit test for method set of class _Option
def test__Option_set():
    set_0 = _Option(None, None, None, False, False)
    set_0.set(None)

if __name__ == '__main__':
    test_case_0()
    test__Option_set()

# Generated at 2022-06-26 08:31:03.845419
# Unit test for method set of class _Option
def test__Option_set():   
    test_Option = _Option(name='listen_port', default=8080,
        type=int, help='Port to listen on', metavar='PORT', multiple=False,
        file_name=None, group_name='server:main',
        callback=None)
    test_Option.set(80)
    print('1. Expected value: 80', 'Actual value: ', test_Option.value())
    test_Option.set(1.23)
    print('2. Expected value: 80', 'Actual value: ', test_Option.value())
    test_Option.set(True)
    print('3. Expected value: 80', 'Actual value: ', test_Option.value())
    test_Option.set('80')

# Generated at 2022-06-26 08:31:18.305500
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    list_0 = [1, 2, 3]
    obj_0 = OptionParser()
    __iterator_0 = iter(obj_0)
    del obj_0
    assert __iterator_0 != __iterator_0
    # obj_0 is an instance of OptionParser
    # obj_0 is an instance of object



# Generated at 2022-06-26 08:31:25.423053
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    my = OptionParser()
    my.define("check",type=float, help="help")
    config = {"check": 0.2}
    my.parse_config_file(config)
    assert my.check == 0.2

#  Unit test for method parse_config_file of class OptionParser

# Generated at 2022-06-26 08:31:26.931669
# Unit test for method parse of class _Option
def test__Option_parse():
    pass


# Generated at 2022-06-26 08:31:30.631728
# Unit test for method set of class _Option
def test__Option_set():
    list_0 = [None]
    option_instance = _Option(list_0, None, None, None, None)
    try:
        list_1 = option_instance._Option__set(list_0, None)
    except Exception:
        list_1 = list_0
    assert list_1 == list_0


# Generated at 2022-06-26 08:31:35.897583
# Unit test for method set of class _Option
def test__Option_set():
    instance = _Option('some_name')
    try:
        instance.set('some_value')
    except Exception as err:
        print('Test failed with:', err)
    else:
        print('Test passed')


# Generated at 2022-06-26 08:31:41.961694
# Unit test for method parse of class _Option
def test__Option_parse():
    _Option_0 = _Option(None, None, None, None, None, None)
    _Option_0.default = 0.5
    if True:
        _Option_0.multiple = True
        if True:
            _Option_0.type = int
    _Option_0.parse("2")
    _Option_0.parse("3:5")

# Generated at 2022-06-26 08:31:44.767140
# Unit test for method parse of class _Option
def test__Option_parse():
    list_0 = parse_command_line()


# Generated at 2022-06-26 08:31:50.282276
# Unit test for method set of class _Option
def test__Option_set():
    value_0 = None
    opt_0 = _Option(value_0, False, 'www.google.com')
    assert opt_0._value == 'www.google.com'


# Generated at 2022-06-26 08:31:53.537864
# Unit test for method set of class _Option
def test__Option_set():
    # Instance _Option
    _Option_ = _Option("_Option_")
    # Call method set of class _Option_ with parameter value = 1
    _Option_._Option__set("1")



# Generated at 2022-06-26 08:31:57.405353
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    o = OptionParser()
    # This method is not implemented yet.
    pass


# Generated at 2022-06-26 08:32:39.296585
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    print("******* Unit Test of method parse_command_line in class OptionParser *******")
    test_OptionParser_parse_command_line_0()
    test_OptionParser_parse_command_line_1()
    test_OptionParser_parse_command_line_2()
    test_OptionParser_parse_command_line_3()
    test_OptionParser_parse_command_line_4()
    test_OptionParser_parse_command_line_5()
    test_OptionParser_parse_command_line_6()
    test_OptionParser_parse_command_line_7()
    test_OptionParser_parse_command_line_8()
    test_OptionParser_parse_command_line_9()
    test_OptionParser_parse_command_line_10()
    test_OptionParser_parse_command_line_

# Generated at 2022-06-26 08:32:48.022532
# Unit test for method parse of class _Option
def test__Option_parse():
    o = _Option("name", default = "True", type = bool, help = "None", metavar = "None", multiple = True, file_name = "None", group_name = "None", callback = "None", )
    assert o.parse("False") == False
    assert o.parse("False") == False


# Generated at 2022-06-26 08:32:55.097729
# Unit test for method parse of class _Option
def test__Option_parse():
    list_0 = ["-m", "5", "-m", "1", "-m", "2"]

    #if len(list_0) != 3:
    #    raise Exception()

    if len(list_0) == 0:
        raise Exception()

    expect = ""

    if list_0[0] == "-m":
        expect = "5"
    else:
        raise Exception()

    if list_0[1] == "-m":
        expect = "1"
    else:
        raise Exception()

    if list_0[2] == "-m":
        expect = "2"
    else:
        raise Exception()



# Generated at 2022-06-26 08:33:00.446120
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    # This is the stub for a unit test in the tornado.options module
    # pass
    list_0 = []
    for i in options:
        list_0.append(i.name)
    print(list_0)


# Generated at 2022-06-26 08:33:14.172981
# Unit test for method set of class _Option
def test__Option_set():
    class Test_Option(unittest.TestCase):
        def setUp(self):
            self.option = _Option('test_name', None, str, 'help', 'metavar', False, 'file_name', 'group_name', None)

        def test_set_1(self):
            self.option.set('test')
            self.assertEqual(self.option._value, 'test')
        def test_set_2(self):
            self.option.set(1)
            self.assertRaises(Error)
        def test_set_3(self):
            self.option.set(True)
            self.assertRaises(Error)
        def test_set_4(self):
            self.option.set(None)
            self.assertRaises(Error)

# Generated at 2022-06-26 08:33:22.184917
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    tornado.options.define("template_path",group="application")
    tornado.options.define("static_path",group="application")
    tornado.options.parse_config_file("application.yaml")
    print(options.group_dict("application"))
    print(options.as_dict())

# test_case_1 tests

# Generated at 2022-06-26 08:33:34.519957
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    print("\nTesting: test_OptionParser_parse_command_line()")
    options.define("port", default=8000, help="Server port", type=int)
    options.define("debug", default=False, help="Run in debug mode")
    options.define("addresses", multiple=True, help="Address to listen on")

    argv = [
        "progname",
        "--port",
        "9000",
        "--addresses",
        "localhost",
        "--addresses",
        "localhost,127.0.0.1",
        "--addresses",
        "0:100",
        "--debug",
        "--addresses",
        "::1,compute1",
    ]

    remaining = options.parse_command_line(argv)
    print(options)
   

# Generated at 2022-06-26 08:33:48.240455
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    # Options for the test.
    define("name", default="world", help="print name")
    define("age", type=int, help="print age")
    define("h", default=False, help="show help", callback=test_case_3)
    define("o", group="g1", help="show help", callback=test_case_3)
    define("p", type=str, group="g1", help="show help", callback=test_case_3)
    define("t", group="g2", help="show help", callback=test_case_3)
    define("y", group="g2", help="show help", callback=test_case_3)
    parser = OptionParser()
    test_iter = iter(parser)
    name_0 = str(type(test_iter))
    print(name_0)

# Generated at 2022-06-26 08:34:00.264871
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    """test: method parse_config_file of class OptionParser"""
    """test: method parse_config_file of class OptionParser"""
    """test: method parse_config_file of class OptionParser"""
    """test: method parse_config_file of class OptionParser"""
    """test: method parse_config_file of class OptionParser"""
    """test: method parse_config_file of class OptionParser"""
    """test: method parse_config_file of class OptionParser"""
    """test: method parse_config_file of class OptionParser"""
    """test: method parse_config_file of class OptionParser"""
    """test: method parse_config_file of class OptionParser"""
    """test: method parse_config_file of class OptionParser"""
    """test: method parse_config_file of class OptionParser"""

# Generated at 2022-06-26 08:34:08.728928
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    print("Unit test for optionparser.parse_config_file")
    print("----------------------------------------------------------------------")
    parser = OptionParser()
    parser.define("port", default=8888, help="run on the given port", type=int)
    parser.define("debug", default=False, help="run in debug mode", type=bool)
    parser.define("host", default="", help="host to listen on")
    parser.define("times", default=[], help="list of integers", multiple=True)
    parser.define(
        "config", type=str, help="path to config file", callback=lambda path: parser.parse_config_file(path, final=False))
    parser.parse_config_file('D:/Research/Tracing/data/options_example.conf')
    print(parser.port)
    print(parser.debug)


# Generated at 2022-06-26 08:35:05.298196
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    # Testing default.
    option_parser_0 = OptionParser()
    print(list(option_parser_0))
    # Testing with arg option_parser.
    option_parser_1 = OptionParser()
    print(list(option_parser_1))
    print(list(option_parser_1))
    print(list(option_parser_1))
    print(list(option_parser_1))
    print(list(option_parser_1))
    print(list(option_parser_1))
    print(list(option_parser_1))
    print(list(option_parser_1))
    print(list(option_parser_1))
    # Testing exception Error.
    option_parser_2 = OptionParser()
    options_0 = list(option_parser_2)
    # Testing with arg option_parser.

# Generated at 2022-06-26 08:35:10.031246
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    config_1 = OptionParser()
    config_0 = config_1.__iter__()
    assert isinstance(config_0, Iterator)


# Generated at 2022-06-26 08:35:17.867712
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    options = OptionParser()
    options.define("port", default=8888, help="run on the given port")
    options.define("logging", default="level=INFO", help="Logging configuration")

    import tempfile

    with tempfile.NamedTemporaryFile("wt") as f:
        f.write("port = 8080\nlogging = level=DEBUG\n")
        f.flush()
        options.parse_config_file(f.name)
    assert options.port == 8080
    assert options.logging == "level=DEBUG"

if __name__ == "__main__":
    test_case_0()
    test_OptionParser_parse_config_file()

# Generated at 2022-06-26 08:35:30.297017
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    from io import StringIO
    import sys
    from os.path import basename

    # OptionParser.__iter__() with simple args
    def test_case_1():
        list_0 = ['', 'a', 'b', 'c']
        sys.argv = list_0
        list_1 = parse_command_line()
        list_2 = []
        for local_opt in options:
            list_2.append(local_opt.name)
        list_3 = options.keys()

        assert list_1 == list_0[1:]
        assert list_2 == list_3
        sys.argv = list_0

    # OptionParser.__iter__() with simple args
    def test_case_2():
        list_0 = ['', 'a', 'b', 'c']

# Generated at 2022-06-26 08:35:35.638800
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    define("template_path", default="", type=str, help="", metavar="")
    define("static_path", default="", type=str, help="", metavar="")
    parse_config_file('mock_application.py')


# Generated at 2022-06-26 08:35:48.658119
# Unit test for method set of class _Option
def test__Option_set():
    list_0 = parse_command_line()
    var_0 = list_0.type
    var_0 = list_0.value
    var_0 = list_0._parse_string
    var_0 = list_0.callback
    var_0 = list_0.file_name
    var_0 = list_0._value
    var_0 = list_0._parse_timedelta
    var_0 = list_0.name
    var_0 = list_0.default
    var_0 = list_0._parse_bool
    var_0 = list_0.group_name
    var_0 = list_0.multiple
    var_0 = list_0.help
    var_0 = list_0._parse_datetime
    var_0 = list_0.metavar

# Generated at 2022-06-26 08:35:57.927391
# Unit test for method parse of class _Option
def test__Option_parse():
    option_0 = _Option("", bool, None, None, None, False, None, None, None)
    option_0.parse("false")
    if not True:
        raise AssertionError("expected True but got False")
    option_0.parse("true")
    if not True:
        raise AssertionError("expected True but got False")



# Generated at 2022-06-26 08:36:02.601403
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    OP = OptionParser()
    try:
        OP.define(
                name="name",
                default=None,
                type=None,
                help=None,
                metavar=None,
                multiple=False,
                group=None,
                callback=None
            )
        assert False
    except:
        assert True


# Generated at 2022-06-26 08:36:13.041032
# Unit test for method set of class _Option
def test__Option_set():
    list_0 = [ ]
    def func_0( list_0 ):
        list_1 = [ ]
        # Test case that raises a TypeError
        try:
            list_1.append( list_0[None] )
        except TypeError as exception_0:
            list_1.append( str( exception_0 ) )
        # Test case that raises a ValueError
        try:
            list_1.append( list_0[None] )
        except ValueError as exception_0:
            list_1.append( str( exception_0 ) )
        # Test case that raises no exceptions
        list_1.append( "no exceptions" )
        return list_1
    list_0.append( func_0 )
    func_0( list_0 )

if __name__ == '__main__':
    test

# Generated at 2022-06-26 08:36:15.603493
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    config = 'config.py'

    with open(config, 'w') as f:
        f.write('option_test = "test"')

    # parse
    OptionParser().parse_config_file(config)
    global option_test
    # assert
    assert option_test == "test"


# Generated at 2022-06-26 08:36:43.027471
# Unit test for method parse of class _Option
def test__Option_parse():
    option = _Option(type=str, group_name='test_parse')
    # test for multiple = false
    option.multiple = False
    option.parse('default')
    assert option.value() == 'default'
    # test for multiple = true
    option.multiple = True
    option.parse('default')
    assert option.value() == ['default']

if __name__ == '__main__':
    test_case_0()
    test__Option_parse()

# Generated at 2022-06-26 08:36:53.864560
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    parser = OptionParser()
    parser.define("port", default=80)
    parser.define("mysql_host", default="mydb.example.com:3306")

    parser.define("memcache_hosts", default=['cache1.example.com:11011', 'cache2.example.com:11011'], multiple=True)
    parser.parse_config_file("example/options/example.conf")
    print(parser.options.port)
    print(parser.options.mysql_host)
    print(parser.options.memcache_hosts)


# Generated at 2022-06-26 08:37:07.603885
# Unit test for method set of class _Option
def test__Option_set():
    l_0 = _Option("foo", default=None, help=None, type=bool)
    l_1 = _Option("foo", default=None, help=None, type=datetime.datetime)
    l_2 = _Option("foo", default=None, help=None, type=datetime.timedelta)
    l_3 = _Option("foo", default=None, help=None, type=basestring_type)
    l_4 = _Option("foo", default=None, help=None, type=str)
    l_5 = _Option("foo", default=None, help=None, type=int)
    l_6 = _Option("foo", default=None, help=None, type=float)

    assert l_0.__dict__["name"] == "foo"
    assert l_1.__dict

# Generated at 2022-06-26 08:37:19.534373
# Unit test for method parse of class _Option
def test__Option_parse():
    option = _Option('port', default=80, type=int, metavar='port', multiple=False, file_name=None, group_name=None, callback=None)
    # print('try to parse int')
    option.parse('8080')
    option.parse('8200')
    # print('try to parse timedelta')
    option = _Option('port', default=80, type=datetime.timedelta, metavar='port', multiple=False, file_name=None, group_name=None, callback=None)
    option.parse('1d')
    # print('try to parse datetime')
    option = _Option('port', default='80', type=datetime.datetime, metavar='port', multiple=False, file_name=None, group_name=None, callback=None)
    option

# Generated at 2022-06-26 08:37:27.514071
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    # Test for when value of parameter args is None
    # Instantiation of OptionParser
    parser = OptionParser()
    # Call of method parse_command_line of class OptionParser
    list_0 = parser.parse_command_line()
    # Test for when value of parameter args is not None
    list_0 = parser.parse_command_line(args=['arg1', 'arg2'])


# Generated at 2022-06-26 08:37:39.159347
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # Make sure file 1.txt exists
    f = open("1.txt", "w")
    f.write("port = 80 \n")
    f.write("memcache_hosts = 'cache1.example.com:11011,cache2.example.com:11011'")
    f.close()
    parse_config_file("1.txt")
    assert options.port == 80
    assert options.memcache_hosts[0] == "cache1.example.com:11011"
    assert options.memcache_hosts[1] == "cache2.example.com:11011"


# Generated at 2022-06-26 08:37:41.214750
# Unit test for method parse of class _Option
def test__Option_parse():
    option = _Option("name")
    option.parse("")
