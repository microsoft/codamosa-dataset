

# Generated at 2022-06-26 08:28:43.070426
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    import sys
    import unittest
    from tornado.options import options, parse_command_line, define
    from tornado.testing import AsyncTestCase, gen_test, main

    define("name", default="", multiple=True)

    class OptionParserTest(AsyncTestCase):
        @gen_test
        def test_iterable(self):
            sys.argv = ["progname", "--name=a", "--name", "b"]
            parse_command_line()
            self.assertEqual(["a", "b"], [x for x in options])

    if __name__ == "__main__":
        unittest.main()



# Generated at 2022-06-26 08:28:48.352976
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    options = Options()
    options.define("name", type=str, help="name of the test file.")
    options.parse_command_line()
    print(options.name)


# Generated at 2022-06-26 08:28:58.157718
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    """
    This unit test is for testing method __iter__ of class OptionParser
    :return:
    """
    def mock_read(filename):
        textfile = open(filename, 'rb')
        content = textfile.read()
        textfile.close()
        return content
    def mock_open(filename,content):
        textfile = open(filename, 'wb')
        textfile.write(content)
        textfile.close()
    def mock_subprocess_call(command):
        #return subprocess.run(command, stdout=subprocess.PIPE)
        #print(subprocess.Popen(command, stdout=subprocess.PIPE).communicate()[0].decode('utf-8'))
        return subprocess.Popen(command, stdout=subprocess.PIPE).communicate

# Generated at 2022-06-26 08:29:07.325574
# Unit test for method set of class _Option
def test__Option_set():
    print("************************************")
    print("TESTING _Option.set")
    print("************************************\n")
    default = _Option.UNSET
    value = _Option.UNSET
    type = str
    multiple = False
    callback = None
    option = _Option("name", default, type, "help", "metavar", multiple, "file_name", "group_name", callback)

    # Value is not instance of type
    print("Test 1: input value is not instance of option type")
    value = 1
    try:
        option.set(value)
    except Error as e:
        print("An Error is raised, as expected")
        print(e)
    else:
        print("AssertionError is NOT raised, incorrect.")
    print()

    # Value is instance of type

# Generated at 2022-06-26 08:29:18.429980
# Unit test for method set of class _Option
def test__Option_set():
    import os
    import unittest
    import uuid
    from tornado.options import define
    from tornado.options import options
    from tornado.options import _Option
    from tornado.options import Error
    from tornado.options import print_help

    def callback_case_1(value):
        print('value was: ', value)

    class _OptionTests(unittest.TestCase):
        def setUp(self):
            self.option = _Option(
                name="name",
                default=None,
                type=str,
                help=None,
                metavar="whatever",
                multiple=True,
                file_name=None,
                group_name=None,
                callback=callback_case_1
            )

        # Positive test for method set of class _Option

# Generated at 2022-06-26 08:29:28.663989
# Unit test for method parse of class _Option
def test__Option_parse():
    string_option = _Option(
        name = "string",
        default = "-1",
        type = str,
        help = "string",
        metavar = None,
        multiple = False,
        file_name = None,
        group_name = None,
        callback = None,
    )

    bool_option = _Option(
        name = 'bool',
        default = True,
        type = bool,
        help = "bool",
        metavar = None,
        multiple = False,
        file_name = None,
        group_name = None,
        callback = None,
    )

    try:
        assert string_option.parse("123") == "123"
        assert bool_option.parse("False") == False
    except Exception:
        pass


# Generated at 2022-06-26 08:29:33.763063
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    # Set up test data
    s = OptionParser()
    s.define("s", default=1, help="s")
    s.define("p", default=1, help="p")

    # Set up mock objects
    class MockOptionParser(OptionParser):
        def __init__(self):
            self.p_mark = 0
        def p(self, val):
            self.p_mark += 1

    # Run unit test
    m = MockOptionParser()
    m.p = 1
    m.__setattr__("p", 2)
    assert m.p == 2
    assert m.p_mark == 1



# Generated at 2022-06-26 08:29:46.928287
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    options = _Options()
    options.define("port", type=int, default=8888, help="run on the given port", group="application")
    options.define("logging", default="info", help="set the Python log level", group="application")
    options.define("debug", type=bool, group="application")
    options.define("mysql_host", default="localhost:3306", group="database")
    options.define("mysql_database", default="test", group="database")
    options.define("mysql_user", default="root", group="database")
    options.define("mysql_password", default="secret", group="database")
    args = options.parse_command_line(["--mysql_host", "otherhost", "--mysql_host", "thirdhost,fourthhost"])
    print(args)

# Generated at 2022-06-26 08:29:51.373210
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    # GIVEN
    parser = OptionParser()
    # WHEN
    parser.define("define_with_no_default", type=bool)
    parser.define("define_with_default", type=int, default=12)
    # THEN
    assert parser.__iter__() == ['define_with_no_default', 'define_with_default']


# Generated at 2022-06-26 08:30:03.181109
# Unit test for method parse of class _Option
def test__Option_parse():
    _options = [
        _Option(name="name", default=None, type=datetime.datetime, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None),
        _Option(name=None, default=None, type=datetime.datetime, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None),
    ]
    for _option in _options:
        _value = None
        if _option.multiple:
            if issubclass(_option.type, numbers.Integral):
                pass
            else:
                _option._value.append(_value)
        else:
            _option._value = _value

# Generated at 2022-06-26 08:30:24.099187
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    opt_1 = OptionParser()
    opt_1.define("key_1", default = 3, help = "help_1")
    opt_1.define("key_2", default = 4, help = "help_2")

    moc_1 = opt_1.mockable()
    print(opt_1.key_1) # expect to print 3
    setattr(moc_1, "key_1", 10)
    print(opt_1.key_1) # expect to print 10
    delattr(moc_1, "key_1")
    print(opt_1.key_1) # expect to print 3

# Generated at 2022-06-26 08:30:35.811920
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    options = OptionParser()
    options.define('name',default='abc_0',type=str,help='help_0',metavar='metavar_0',
                   multiple=False,group='group_0',callback=None)

    # Normal case #1
    list_0 = parse_command_line()
    setattr(options,'parse_callbacks',[])
    print('\n')
    print('Normal case #1')
    print(options.as_dict())
    print('\n')

    # Normal case #2
    # [sys.flags.optimize = sys.flags.optimize - 1, sys.flags.optimize = sys.flags.optimize - 1]
    list_0 = parse_command_line()
    setattr(options,'parse_callbacks',[])
    print('\n')


# Generated at 2022-06-26 08:30:39.925900
# Unit test for method group_dict of class OptionParser
def test_OptionParser_group_dict():
    print('test_OptionParser_group_dict: begin')
    print('test_OptionParser_group_dict: end')


# Generated at 2022-06-26 08:30:47.060995
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    # args is None
    options = OptionParser()
    options.define("a")
    options.define("b")
    options.parse_command_line(args=None)

    # multiple=True, no equals, not boolean
    options = OptionParser()
    options.define("a", multiple=True)
    with pytest.raises(Error) as excinfo:
        options.parse_command_line(["--a"])
    
    # multiple=True, equals, not boolean
    options = OptionParser()
    options.define("a", multiple=True)
    options.parse_command_line(["--a=1"])

    # boolean
    options = OptionParser()
    options.define("a", type=bool)
    options.parse_command_line(["--a"])
    options.parse_command_line

# Generated at 2022-06-26 08:30:54.257497
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    test_case_0()
    # list_1 = options.OptionParser().__iter__()


# Generated at 2022-06-26 08:30:55.521533
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    pass


# Generated at 2022-06-26 08:31:07.824570
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    def setUp(self):
        self.option_parser = OptionParser()
        self.option_parser.define('test_0', default='test_value')
        self.option_parser.define('test_1', default='test_value')

    def test___iter__(self):
        self.assertIsInstance(self.option_parser.__iter__(), types.GeneratorType)
        keys = []
        for key in self.option_parser:
            keys.append(key)
        self.assertEqual(keys, ['test_0', 'test_1'])

    def test___iter__with_group(self):
        self.option_parser.define('test_2', default='test_value', group='test_group')
        keys = []

# Generated at 2022-06-26 08:31:14.527415
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    # Create an instance of OptionParser
    option_parser = OptionParser()

    # Iterate through the instance
    iterator = iter(option_parser)
    while True:
        try:
            item = next(iterator)
        except StopIteration:
            break

# Generated at 2022-06-26 08:31:16.396880
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    options = OptionParser()
    _mockable = _Mockable(options)
    name = 'fake_name'
    value = 'fake_value'

    try:
        _mockable.__setattr__(name, value)
    except AssertionError:
        pass



# Generated at 2022-06-26 08:31:20.461706
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    print("\n###  Unit test for method __setattr__ of class OptionParser")
    #test_case_0()


if __name__ == '__main__':
    test_OptionParser___setattr__()

# Generated at 2022-06-26 08:31:38.842605
# Unit test for method parse of class _Option
def test__Option_parse():
    value = "2019-02-14 15:56:27"
    option = _Option('name',default=None,type=datetime.datetime,help=None,metavar=None,multiple=False,file_name=None,group_name=None,callback=None)
    result = option._parse_datetime(value)
    print(result)


# Generated at 2022-06-26 08:31:40.520294
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    options.Options.instance().parse_command_line()


# Generated at 2022-06-26 08:31:43.667052
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    parser = OptionParser()
    parser.define("name", default=None, help="name of this app")
    parser.parse_command_line(["--name=foo"])
    assert "name" in parser._options
    assert parser._options["name"].value() == "foo"



# Generated at 2022-06-26 08:31:51.706768
# Unit test for method set of class _Option
def test__Option_set():
    option = _Option(name='name',
                     default=None,
                     type=str,
                     help=None,
                     metavar=None,
                     multiple=False,
                     file_name=None,
                     group_name=None,
                     callback=None
    )
    option.set('Test_value')


# Generated at 2022-06-26 08:32:02.124940
# Unit test for method set of class _Option
def test__Option_set():
    name = "port"
    default = None
    type = int
    help = "The port to listen on."
    metavar = "PORT"
    multiple = False
    file_name = "tornado.options"
    group_name = "Server"
    callback = None
    option = _Option(name, default, type, help, metavar, multiple, file_name, group_name, callback)
    option.set(80)
    assert option.value() == 80



# Generated at 2022-06-26 08:32:10.505767
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    file_name = "/tmp/tornado_test"
    with open(file_name, "a+") as fd:
        fd.write("test=test_ok")

    _options = {}
    option = _Option(
            "test",
            file_name=file_name,
            default="",
            type=str,
            help="help message",
            metavar="test help",
            multiple=False,
            group_name=file_name,
            callback=None,
        )
    _options["test"] = option

    assert option.value() == ""

    option_parser = OptionParser()
    option_parser._options = _options

    option_parser.parse_config_file(file_name)
    assert option.value() == "test_ok"


# Generated at 2022-06-26 08:32:20.758715
# Unit test for method define of class OptionParser

# Generated at 2022-06-26 08:32:23.697709
# Unit test for method parse of class _Option
def test__Option_parse():
    option = _Option('option')
    option.parse('2')
    assert option.value() == 2


# Generated at 2022-06-26 08:32:33.866307
# Unit test for method set of class _Option
def test__Option_set():
    name = "a"
    type = str
    def callback(value: str) -> bool:
        if value == "b":
            return True
        else:
            return False

    default = "c"
    option = _Option(name, default, type, None, None, False, None, None, callback)
    # Check if option.value() == default
    assert option.value() == default

    option.set("b")
    # Check if option.value() == "b"
    assert option.value() == "b"


# Generated at 2022-06-26 08:32:37.727325
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    test_parser = OptionParser()
    test_parser.define('long_name', default=False, type=bool, help='some long name')



# Generated at 2022-06-26 08:33:08.098788
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    a = OptionParser()
    a.define('test_test', type=bool)
    a.parse_command_line([])
    b = iter(a)
    assert type(b) == list_iterator
    # TODO: implement parsing command line!



# Generated at 2022-06-26 08:33:16.928050
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    """Test method: OptionParser.parse_command_line()"""
    if len(sys.argv) < 2:
        print("You are testing method 'OptionParser.parse_command_line()' ")
        print("of class 'OptionParser'.")
        print("You should input at least two arguments. The first argument is ")
        print("the method you want to test. The last argument is the ")
        print("test case file.")
        print("For example:")
        print("python3 tornado_options_test.py OptionParser.parse_command_line ")
        print("test_case_0.txt")
        exit(0)
    testcase_file = open(sys.argv[-1])

# Generated at 2022-06-26 08:33:25.719911
# Unit test for method parse of class _Option
def test__Option_parse():
    # Create an instance of class _Option
    option = _Option("test_option", type=datetime.datetime)
    date_value = option.parse("2014-01-01 00:00:00")
    print("date_value = {}".format(date_value))

    # Create an instance of class _Option
    option = _Option("test_option", type=datetime.datetime)
    date_value = option.parse("2014-01")
    print("date_value = {}".format(date_value))



# Generated at 2022-06-26 08:33:31.756233
# Unit test for method print_help of class OptionParser
def test_OptionParser_print_help():
    parser = OptionParser()
    parser.print_help()
    print()
    parser.define('log_file_prefix')
    parser.print_help()



# Generated at 2022-06-26 08:33:37.556569
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    """
    Method parse_command_line in class OptionParser
    """
    print("[Test case 0] parse_command_line()\n", end="")
    # Initialize the object options
    options = OptionParser()
    # Run the method parse_command_line
    list_0 = options.parse_command_line()

    # Unit test for method print_help of class OptionParser

# Generated at 2022-06-26 08:33:42.619531
# Unit test for method value of class _Option
def test__Option_value():
    opt = _Option('name', default=None, type=int, help='Option name', metavar='', multiple=False, file_name='', group_name='')
    assert opt.value() is None


# Generated at 2022-06-26 08:33:54.499058
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    list_0 = [None, None]
    list_1 = []

    args = [None] * 2
    args[0] = list_0

    def test_0_callback(value: bool) -> None:
        list_0[0] = value

    option = options.define("option", type=bool, callback=test_0_callback)
    list_1.append(option)
    option = options.define("option", default=False, type=bool, callback=test_0_callback)
    list_1.append(option)

    list_0[1] = list_1



# Generated at 2022-06-26 08:33:55.473422
# Unit test for method parse of class _Option
def test__Option_parse():
    pass


# Generated at 2022-06-26 08:34:03.371200
# Unit test for method set of class _Option
def test__Option_set():
    settings = option_list.parse_command_line()

if __name__ == '__main__':
    settings = option_list.parse_command_line()
    # test_options()
    list_1 = test_case_0()
    test_case_1()
    test_case_2()
    test__Option_set()

# Generated at 2022-06-26 08:34:09.340626
# Unit test for method value of class _Option
def test__Option_value():
    # Define input for the test
    # Generate the instance for the test
    option = _Option(name="test", default="test", type=str, help="test", metavar="test", multiple=True, file_name="test", group_name="test", callback="test")
    option.set("test")
    # Generate expected result
    expected = "test"
    # Execute the test
    result = option.value()
    # Verify the result
    assert result == expected


# Generated at 2022-06-26 08:34:37.760690
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    list_0 = parse_command_line()
    assert list_0==[], "parse_command_line() failed"


# Generated at 2022-06-26 08:34:41.825875
# Unit test for method parse of class _Option
def test__Option_parse():
    option_0 = _Option("test_name_0", datetime.timedelta, help="test_help_0")
    option_1 = _Option("test_name_1", int, help="test_help_1")
    option_0.parse("test_value_0")
    option_1.parse("test_value_1")


# Generated at 2022-06-26 08:34:49.475601
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    options = _OptionParser()
    options.define('name', default='', type=str, help='option help')
    options.add_parse_callback(test_case_0)

    sys.argv = ['osa_agent.py', '--name', 'value']
    options.parse_command_line()
    print(options.name)


# Generated at 2022-06-26 08:34:54.739204
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # Test the branch that no exceptions are raised
    # Build an instance of OptionParser
    options = parse_command_line()
    assert isinstance(options, dict)
    pass


# Generated at 2022-06-26 08:34:57.745788
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    options = OptionParser()
    options.mockable = _Mockable(options)
    options.mockable.port = 3306
    assert options.mockable.__dict__['_originals'] == {'port': None}, "Test case 0 failed"


# Generated at 2022-06-26 08:35:06.631088
# Unit test for method parse of class _Option
def test__Option_parse():
    # Create a _Option object
    option_obj = _Option("name", "default", str, "help", "metavar", True, "file_name", "group_name", None)

    # Call the method parse of _Option
    argument_value = "value"
    option_obj.parse(argument_value)

    # Check the value of attributes after the method parse is called
    assert option_obj.name == "name", "The field '_Option.name' doesn't have the expected value after calling '_Option.parse' method"
    assert option_obj.type == str, "The field '_Option.type' doesn't have the expected value after calling '_Option.parse' method"

# Generated at 2022-06-26 08:35:13.219379
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    options = OptionParser()
    options.define("name", help="the name")
    options.define("age", type=int, help="the age")
    for name in options:
        print(name)

if __name__ == "__main__":
    test_OptionParser___iter__()

# Generated at 2022-06-26 08:35:25.969689
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    global options
    options = OptionParser()
    options.define("port", default=80, help="Run on this port", type=int)
    options.define("memcache", default="127.0.0.1:11011", multiple=True,
                        help="List of memcache servers")
    options.define("name", default='test', help="The name of this server")
    options.define("test_opt_0", default='test_val_0', help="test value 0")
    options.parse_command_line()

    if options.port != 80:
        raise Exception("Invalid value of option port")
    if options.memcache != ["127.0.0.1:11011"]:
        raise Exception("Invalid value of option memcache")
    if options.name != 'test':
        raise Exception("Invalid value of option name")

# Generated at 2022-06-26 08:35:30.605499
# Unit test for method set of class _Option
def test__Option_set():
    # Set up mock parameters and context
    # _Option instance to be tested
    _Option_instance = _Option('my_name', None, None, None, None, False,
       'my_file_name', None, None)
    # argument 1: name: str
    name = 'my_name'
    # argument 2: value: Any
    value = True


    # Invoke method
    _Option_instance.set(name=name,value=value)



# Generated at 2022-06-26 08:35:37.092169
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    option_parser = OptionParser()
    option_parser.define("list_0", default=list(), type=list, callback=list_0, multiple=True)
    option_parser.parse_config_file(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test.cfg'))
    assert list_0 == [1, 2, 3, 4]


# Generated at 2022-06-26 08:35:55.930041
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    from tornado.options import options
    from tornado.options import parse_command_line

    parse_command_line()
    assert options["address"] == "localhost"
    assert len(options) == 1


# Generated at 2022-06-26 08:36:03.962339
# Unit test for method parse of class _Option

# Generated at 2022-06-26 08:36:08.844782
# Unit test for method parse of class _Option
def test__Option_parse():
    list_0 = parse_command_line()
    value = ""
    rv = list_0[0].parse(value)
    assert rv == None
    assert list_0[0].value() == None


# Generated at 2022-06-26 08:36:22.548599
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    _OptionParser_instance_0 = _OptionParser()
    _OptionParser_instance_0.define('string', default='0')
    _OptionParser_instance_0.parse_command_line()
    _OptionParser_instance_0.define('integer', default=1)
    _OptionParser_instance_0.parse_command_line()
    _OptionParser_instance_0.define('float', default=2.0)
    _OptionParser_instance_0.parse_command_line()
    _OptionParser_instance_0.define('boolean', default=True)
    _OptionParser_instance_0.parse_command_line()
    _OptionParser_instance_0.define('datetime', default=datetime(2019, 12, 31, 23, 59, 59))
    _OptionParser_instance_0.parse_command_line

# Generated at 2022-06-26 08:36:28.079570
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    parser = OptionParser()
    parser.parse_config_file('/Users/xczx/Desktop/python_study/tornado_study/test_config.txt')
    print(options.group_dict('test'))


# Generated at 2022-06-26 08:36:30.391678
# Unit test for method set of class _Option
def test__Option_set():
    method = _Option.set
    method(None, 0)


# Generated at 2022-06-26 08:36:36.116325
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    #global options:
    global options
    options = OptionParser()

    # options for test case 0
    # options for test case 1
    # options for test case 2
    # options for test case 3
    # options for test case 4
    # options for test case 5
    # options for test case 6
    # options for test case 7
    # options for test case 8
    # options for test case 9
    # options for test case 10
    # options for test case 11
    # options for test case 12
    # options for test case 13
    # options for test case 14
    # options for test case 15
    # options for test case 16
    # options for test case 17
    # options for test case 18
    # options for test case 19
    # options for test case 20
    # options for test case 21
    # options for test case

# Generated at 2022-06-26 08:36:42.066374
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    option_parser = OptionParser()
    option_parser.parse_config_file("./options_test_file1.cfg")
    if option_parser.options.port == 80:
        print ("Pass test case 0")


# Generated at 2022-06-26 08:36:47.687044
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    opts = OptionParser()
    for opt in opts:
        assert opt.__class__.__name__ == "_Option"
    for opt in opts:
        assert opt.__class__.__name__ == "_Option"


# Generated at 2022-06-26 08:36:54.607409
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    parser = OptionParser()
    parser.define("name", default="Bob", help="name of the guy")
    parser.define("-s", "--salary", default=1000, help="salary of the guy",type=int)
    parser.parse_command_line("--name=Jane --salary=2000".split(" "))
    print("name:%s,salary:%d" % (parser.name,parser.salary))



# Generated at 2022-06-26 08:37:27.930805
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    list_0 = parse_command_line(['test_case.py', '--testcase="test_case_0"'])
    for i in range(len(list_0)):
        print(list_0[i])


# Generated at 2022-06-26 08:37:30.565978
# Unit test for method parse of class _Option
def test__Option_parse():
    print(simple_option._Option.parse())


# Generated at 2022-06-26 08:37:41.456532
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    print('Running UnitTest for test_OptionParser_parse_config_file')
    ap = ArgumentParser()
    ap.add_argument("-i", "--image", required=True,
                    help="path to the input image")
    ap.add_argument("-c", "--conf", required=True,
                    help="path to the input confidence map")
    ap.add_argument("-o", "--out", required=True,
                    help="path to the output image")
    ap.add_argument("-v", "--visualize", type=bool, default=False,
                    help="whether or not we are going to visualize each instance after processing")
    ap.add_argument("-l", "--min-confidence", type=float, default=0.5,
                    help="minimum probability to filter weak detections")
    #args = v