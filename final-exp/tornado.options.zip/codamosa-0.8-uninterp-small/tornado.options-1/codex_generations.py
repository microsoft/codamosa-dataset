

# Generated at 2022-06-26 08:28:22.408699
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    from tornado.options import define
    define("config", type=str, help="path to config file")
    # ...
    option_parser_0 = OptionParser()
    path_0: str = sys.argv[1]
    option_parser_0.parse_config_file(path_0, final=True)
    # ...


# Generated at 2022-06-26 08:28:28.609486
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    option_parser_0 = OptionParser()
    option_parser_0.define('port', type=int, help="port", callback=lambda: None, multiple=False, metavar="METAVAR", default=0)
    option_parser_0.define('host', type=str, help="host", callback=lambda: None, multiple=False, metavar="METAVAR", default=0)
    option_parser_0.parse_config_file('/home/hasee/log/sentiment_analysis.log')


# Generated at 2022-06-26 08:28:31.082157
# Unit test for constructor of class _Option
def test__Option():
    option_parser_0 = OptionParser()
    name = "--help"
    default = None
    type = None
    help = "show this help information"
    metavar = None
    multiple = False
    file_name = None
    group_name = None
    callback = None
    option_0 = _Option(name, default, type, help, metavar, multiple, file_name, group_name, callback)


# Generated at 2022-06-26 08:28:39.925829
# Unit test for method parse of class _Option
def test__Option_parse():
    option_parser_0 = OptionParser()
    _Option_option_parser_0 = _Option(option_parser_0.name, option_parser_0.default, option_parser_0.type, option_parser_0.help, option_parser_0.metavar, option_parser_0.multiple, option_parser_0.file_name, option_parser_0.group_name, option_parser_0.callback)
    _Option_option_parser_parse_0 = _Option_option_parser_0.parse(_Option_value_0)


# Generated at 2022-06-26 08:28:47.011733
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    option_parser_0 = OptionParser()
    _mockable_0 = _Mockable(option_parser_0)
    try:
        _mockable_0._originals = defaultdict(None, {('a'): None})
        _mockable_0.a = "a"
        print("Value of _mockable_0.a: ", _mockable_0.a, sep="")
        _mockable_0._originals = defaultdict(None, {('b'): None})
        _mockable_0.b = "b"
        print("Value of _mockable_0.b: ", _mockable_0.b, sep="")
    except Exception as e:
        print("Exception: ", e, sep="")


# Generated at 2022-06-26 08:28:49.874587
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    option_parser_0 = OptionParser()
    option_parser_0.parse_command_line()


# Generated at 2022-06-26 08:28:50.416342
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    pass


# Generated at 2022-06-26 08:28:54.156812
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    option_parser_0 = OptionParser()
    output_0 = option_parser_0.__iter__()
    assert not output_0, f"Expected False, but got: {output_0}"


# Generated at 2022-06-26 08:28:57.374850
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    options = OptionParser()
    options.a = 'b'



# Generated at 2022-06-26 08:29:05.073124
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    option_parser_0 = OptionParser()
    option_parser_0.define('port', type=int, default=80, help='port')
    option_parser_0.define('mysql_host', type=str, default="'mydb.example.com:3306'", help='host and port')
    option_parser_0.parse_config_file('/home/marat/tornado_programs/effect/tornado-server/config.py')


# Generated at 2022-06-26 08:29:25.519919
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    parser = OptionParser()
    parser.define("port", default=8888, type=int)


# Generated at 2022-06-26 08:29:28.972746
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    option = options.define("port", default=80, help="run on the given port", type=int)
    options.parse_config_file("test.cfg")
    assert options.port == 80
    # TODO: Add more cases.


# Generated at 2022-06-26 08:29:35.038364
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    list_0 = _Mockable(OptionParser())
    test_case_0()
    list_0.__setattr__('Opt', 'Opt')



if __name__ == '__main__':
    # Create an instance of class OptionParser for testing
    parser = OptionParser()
    parser.add_option(
        '-m',
        '--my-option',
        dest='my_option',
        default=None,
        type=str,
        help='my option',
        metavar='MY_OPTION'
    )
    parser.add_option(
        '-b',
        '--bootstrap',
        dest='bootstrap',
        default=False,
        type=bool,
        help='bootstrap',
        metavar='BOOTSTRAP'
    )
    parser.add_

# Generated at 2022-06-26 08:29:36.875233
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    list_0 = list(iter(OptionParser()))


# Generated at 2022-06-26 08:29:50.455059
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    op = OptionParser()
    op.define('foo', default=False, help='foo', callback=test_case_0)
    op.define('bar', default=True, help='bar')
    op.define('baz', default=42, help='baz', type=int)
    op.define('blargs', default=[], multiple=True, help='blargs')
    op.define('server_version', default='', help='version')
    op.define('time', default=datetime.timedelta(1, 15))
    op.define('path', default=os.path)
    op.define('db', default=None, help='database instance', type=None)
    op.define('log_file_prefix', default=None, group='logging',
              help='log_file_prefix')

# Generated at 2022-06-26 08:29:52.510122
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    pass



# Generated at 2022-06-26 08:29:54.325658
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    list_0 = parse_command_line()
    object_0 = OptionParser()
    for str_0 in object_0:
        print(str_0)


# Generated at 2022-06-26 08:29:55.788592
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    list_0 = parse_command_line()

# Generated at 2022-06-26 08:30:05.396515
# Unit test for method parse of class _Option
def test__Option_parse():
    list_0 = ['unit_test','-help']
    sys.argv = list_0
    list_0 = parse_command_line()
    # assert list_0[0] == True
    # assert list_0[1] == [5]
    # assert list_0[2] == 5
    # assert list_0[3] == "hello"
    # assert list_0[4] == "hello"
    # assert list_0[5] == "hello"
    # assert list_0[7] == datetime.datetime(2016, 6, 1, 0, 0)
    # assert list_0[8] == datetime.timedelta(0, 600)
    # assert list_0[9] == datetime.timedelta(0, 600)
    # assert list_0[6] == [1

# Generated at 2022-06-26 08:30:11.486627
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    options = OptionParser()

    options._options = OptionParser()
    options._originals = {}

    name = "name"
    value = 2
    expected = 2
    actual = options.__setattr__(name, value)
    if expected != actual:
        raise Error("__setattr__ fails")
    print("__setattr__ passes")


# Generated at 2022-06-26 08:30:47.928721
# Unit test for method parse of class _Option

# Generated at 2022-06-26 08:30:49.496677
# Unit test for method set of class _Option
def test__Option_set():
    o = _Option()
    o.set(value)


# Generated at 2022-06-26 08:30:56.756647
# Unit test for method parse of class _Option
def test__Option_parse():
    strip_0 = _Option("strip_0", multiple=True, type=int)
    # not None
    strip_0.parse("1")
    # not None
    strip_0.parse("1:3")
    # not None
    strip_1 = _Option("strip_1", default="[None]", multiple=True, type=str)
    # not None
    strip_1.parse("[None]")
    # not None
    strip_1 = _Option("strip_1", default="[None]", multiple=False, type=str)
    # not None
    strip_1.parse("[None]")


# Generated at 2022-06-26 08:31:00.559870
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():

    def test_case_0():
        list_0 = parse_command_line()

    def test_case_1():
        list_0 = parse_command_line(["--name=haha", "--verbose", "-v", "--help"])


# Generated at 2022-06-26 08:31:02.860820
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    pass


options = _OptionParser()

# Generated at 2022-06-26 08:31:11.219038
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # Constructor for test fixture
    opts = OptionParser()

    opts.define('port', default=80, type=int)
    opts.define('mysql_host', default='localhost:3306')

    # Test 1
    opts.parse_config_file('test_file.cfg')
    assert opts.port == 8080
    assert opts.mysql_host == 'mydb.example.com:3306'



# Generated at 2022-06-26 08:31:16.420126
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    parser = OptionParser()
    parser.define('test_1', default='test_1')
    temp_file = tempfile.NamedTemporaryFile(prefix='test_', mode='w+t', dir=None, delete=True)
    temp_file_name = temp_file.name
    parser.parse_config_file(temp_file_name)



# Generated at 2022-06-26 08:31:27.610627
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    """This test case is used to test method 'define' of class OptionParser """
    # Step 0: create new OptionParser instance
    options = OptionParser()
    # Step 1: Define an option
    options.define("path", type=str, multiple=False, help="The file path")
    # Step 2: Set the option value
    options.path = "path_1"
    # Step 3: Return the option value
    value = options.path
    print("The option returned value is: " + value)
    # Step 4: Check the returned value
    assert value == "path_1"


# Generated at 2022-06-26 08:31:30.032583
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    path = 'options.cfg'
    parse_config_file(path)
    path = 'options.cfg'
    path = 'options.cfg'
    parse_config_file(path)



# Generated at 2022-06-26 08:31:30.738225
# Unit test for method parse of class _Option
def test__Option_parse():
    _Option()


# Generated at 2022-06-26 08:31:52.893398
# Unit test for method parse of class _Option
def test__Option_parse():
    name_0 = 'name_0'
    value_0 = 'value_0'
    option_0 = _Option(name_0)
    option_0.parse(value_0)



# Generated at 2022-06-26 08:32:06.554733
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    global options
    options = OptionParser()

    options.define("port", type=int, default=8888, help="run on the given port", group="application")
    options.define("debug", type=bool, default=False, group="application")
    options.define("udp_port", type=int, default=9999, help="bind udp on the given port", group="application")
    options.define("config", type=str, help="path to config file", group="application")

    options.define("logging", type=str, default="info", help="logging level", group="logging")
    options.define("logfile", type=str, help="Path to a log file.", group="logging")
    options.define("syslog", default=False, help="Log to syslog.", group="logging")

    options.define

# Generated at 2022-06-26 08:32:18.372126
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    file_path = "config_file.txt"
    with open(file_path, "w") as f:
        f.write("port = 80\n")
        f.write("mysql_host = 'mydb.example.com:3306'\n")
        f.write("memcache_hosts = ['cache1.example.com:11011','cache2.example.com:11011']\n")
        f.write("memcache_hosts = 'cache1.example.com:11011,cache2.example.com:11011'\n")
        f.write("__file__ = file_path\n")
    options.parse_config_file(file_path)
    os.remove(file_path)



# Generated at 2022-06-26 08:32:29.517282
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # Create a temporary file for config options
    test_path = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), "test.conf"
    )
    temp_file = open(test_path, "w")
    temp_file.write("db_Path = 'Test_db'")
    temp_file.close()

    # Create a dummy class to test
    class A:
        pass

    # Create a function to test
    def test_function():
        return "Tested"

    # Create a OptionParser instance
    options = OptionParser()

    # Define options
    options.define("db_Path", type=str, callback=test_function)
    options.define("int_var", type=int)
    options.define("float_var", type=float)


# Generated at 2022-06-26 08:32:40.793902
# Unit test for method parse of class _Option
def test__Option_parse():
    # test case 1
    name = 'X'
    default = 0
    type = int
    help = 'this is help of X'
    metavar = 'X'
    multiple = False
    file_name = 'hello.py'
    group_name = 'group_0'
    callback = None
    option = _Option(
            name, default, type, help, metavar, multiple, file_name,
            group_name, callback
        )
    value = '123'
    assert option.parse(value) == 123
    # test case 2
    option.multiple = True
    option.type = float
    assert option.parse(value) == [123.0]


# Generated at 2022-06-26 08:32:53.236808
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    parser = OptionParser()
    parser.define("opt_1")
    parser.define("opt_2")
    parser.define("opt_3")
    parser.define("opt_4")
    parser.define("opt_5")
    parser.define("opt_6")
    parser.define("opt_7")
    parser.define("opt_8")
    parser.define("opt_9")
    parser.define("opt_10")
    parser.define("opt_11")
    parser.define("opt_12")
    parser.define("opt_13")
    parser.define("opt_14")
    parser.define("opt_15")
    parser.define("opt_16")
    parser.define("opt_17")
    parser.define("opt_18")
    parser.define("opt_19")
    parser

# Generated at 2022-06-26 08:33:05.658216
# Unit test for method set of class _Option
def test__Option_set():
    list_0 = parse_command_line()

# Generated at 2022-06-26 08:33:16.082511
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    with open('conf.py', 'w') as f:
        f.write('port = 80\n')
        f.write('mysql_host = \'mydb.example.com:3306\'\n')
        f.write('memcache_hosts = \'cache1.example.com:11011,cache2.example.com:11011\'\n')
        f.write('memcache_hosts = [\'cache1.example.com:11011\', \'cache2.example.com:11011\']\n')
    assert(len(options._options) == 4)
    options.parse_config_file('./conf.py')
    assert(options.port == 80)
    assert(options.mysql_host == 'mydb.example.com:3306')

# Generated at 2022-06-26 08:33:23.177523
# Unit test for method parse of class _Option
def test__Option_parse():
    opt = _Option("foo", default=None, type=int, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    res = opt.parse("1")
    assert res == 1 and opt.value() == 1



# Generated at 2022-06-26 08:33:35.245173
# Unit test for method parse of class _Option
def test__Option_parse():
    import sys
    _test_case_0_type_str = 'str'
    _test_case_0_type_datetime = 'datetime'
    _test_case_0_type_timedelta = 'timedelta'
    _test_case_0_type_bool = 'bool'
    _test_case_0_multiple_False = False
    _test_case_0_multiple_True = True
    _test_case_0_callback_None = None

    _test_case_0_value_0_str = 'test'
    _test_case_0_value_0_datetime = '2018-08-01 10:10:10'
    _test_case_0_value_0_timedelta = '15sec'

# Generated at 2022-06-26 08:34:08.827819
# Unit test for method set of class _Option
def test__Option_set():
    global _Option
    # test empty input
    _Option = _Option("name", "default", "type", "help", "metavar", "multiple", "file_name", "group_name", "callback")
    try:
        _Option.set("")
    except Error as error:
        pass
    # test function attribute
    _Option = _Option("name", "default", "type", "help", "metavar", "multiple", "file_name", "group_name", None)
    try:
        _Option.set("_Option")
    except Error as error:
        pass
    # test List[T] attribue
    _Option = _Option("name", [1, 2, 3], "type", "help", "metavar", "multiple", "file_name", "group_name", "callback")

# Generated at 2022-06-26 08:34:17.102421
# Unit test for method set of class _Option
def test__Option_set():
    list_0 = []
    def function_0(value):
        list_0.append(value)
    option = _Option('option_name', 'option_default', str, 'option_help', 'option_metavar', False, 'option_file_name', 'option_group_name', function_0)
    option.set('option_value')
    assert list_0 == ['option_value']


# Generated at 2022-06-26 08:34:25.037394
# Unit test for method set of class _Option
def test__Option_set():
    a_0 = _Option('a', default = None, type = None, help = None, metavar = None, multiple = False, file_name = None, group_name = None, callback = None)
    value = None
    assert a_0.set(value) is None


# Generated at 2022-06-26 08:34:32.532315
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():

    # Testing
    try:
        options.parse_config_file( "config_file_not_exist" )
    except:
        print( "Expected exception happened!" )



# Generated at 2022-06-26 08:34:43.114964
# Unit test for method set of class _Option
def test__Option_set():
    _Option_instance = _Option(name = 'opt_0', type = str, default = None, 
                               help = "This is an option", 
                               metavar = 'STR', multiple = False, 
                               file_name = "~/src/tornado-4.5.3/tornado/options.py", group_name = 'test_0', 
                               callback = None)
    value = 'opt_0'
    _Option_instance.set(value)
    assert _Option_instance.value() == value
    value = [1, 2, 3, 4]
    type_error_raised = False
    try:
        _Option_instance.set(value)
    except Exception:
        type_error_raised = True
    assert type_error_raised

# Generated at 2022-06-26 08:34:47.867636
# Unit test for method set of class _Option
def test__Option_set():
    try:
        r = _Option('name', type=int, multiple=True, default=None)
        option_0 = r.set(['12', '13'])
        r.multiple = 'FALSE'
        r.default = []
        option_1 = r.set(['12'])
        print(option_0)
        print(option_1)
    except Exception:
        traceback.print_exc()
        return -1
    return 0


# Generated at 2022-06-26 08:34:52.941605
# Unit test for method parse of class _Option
def test__Option_parse():
    name = 'name'
    default = 'default'
    type = 'type'
    help = 'help'
    metavar = 'metavar'
    multiple = True
    file_name = 'file_name'
    group_name = 'group_name'
    callback = 'callback'
    value = 'value'
    _Option_obj = _Option(name, default, type, help, metavar, multiple, file_name, group_name, callback)
    _Option_obj.parse(value)
    print(_Option_obj.value())


# Generated at 2022-06-26 08:35:01.582547
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    parser = OptionParser()
    parser.define("name", default="default_value", type=int, help="help_text", metavar="metavar")
    parser.define("name_2", default="default_value", type=str, help="help_text", metavar="metavar")
    parser.define("name_2", default="default_value", type=str, help="help_text", metavar="metavar")

# Generated at 2022-06-26 08:35:15.878290
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    class TestConfig(object):
        def __init__(self):
            self.file_name = ""
            self.default = 0
            self.type = int
            self.help = ""
            self.metavar = ""
            self.multiple = False
            self.group_name = ""
            self.callback = None
    _options1 = {}
    _options1[str("test")] = TestConfig()

    class TestClass(object):
        pass
    test_object = TestClass()
    test_object._options = _options1

    def parse_config_file(self, path: str, final: bool = True) -> None:
        config = {"__file__": os.path.abspath(path)}

# Generated at 2022-06-26 08:35:23.121610
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    # Prepare
    list_0 = []

    # Exercise
    try:
        list_0 = parse_command_line()
    except:
        assert False

    # Verify
    assert (
        list_0 == []
    ), '''The returned value should be equal to ["0", "-i", "1", "2", "3"].'''


# Generated at 2022-06-26 08:36:00.111057
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # In this test, the config file will declare the value for the option 'logging' to be 'info', in line with the defult value as declared in main_0 function
    config_file = 'config_file_0.cfg'

# Generated at 2022-06-26 08:36:08.524642
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # Inizialize the parser
    parser = OptionParser()
    # Define the options that can be parsed from the file
    parser.define("name", default='test_name')
    parser.define("port", default='11011')
    # Parse the options of the file
    parser.parse_config_file(r"C:\Users\luca\Desktop\test.conf")
    
    
    

# Generated at 2022-06-26 08:36:11.018393
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    list_0 = parse_command_line()
    assert list_0 == []


# Generated at 2022-06-26 08:36:19.788390
# Unit test for method parse of class _Option
def test__Option_parse():
    # Setup variables
    self = _Option("name", type=int, help="help", metavar="metavar")
    value = "123"

    # Test with typical value
    r = self.parse(value)
    assert r == 123

    # Test with multiple value
    self.multiple = True
    r = self.parse(value)
    assert r == [123]


# Generated at 2022-06-26 08:36:28.583683
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # options = None
    # path = "./parse_command_line.py"
    # final = False
    # parse_config_file(path, final)
    print("test")

# def main():
#     # test_case_0()
#     test_OptionParser_parse_config_file()
#
# if __name__ == "__main__":
#     main()

# Generated at 2022-06-26 08:36:35.735004
# Unit test for method parse of class _Option
def test__Option_parse():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future
    import time
    import random

    @gen.coroutine
    def _test_parse_case0():
        s = '--logging=warning'
        option_0 = _Option('logging', 'warning', type=str, help=None,
                           metavar=None, multiple=False, file_name=None,
                           group_name=None, callback=None)
        result = option_0.parse(s)
        print('parse_command_line: ', result)


# Generated at 2022-06-26 08:36:45.562008
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    global _parse_callbacks
    cur_callbacks = _parse_callbacks.copy()
    _OptionParser_obj = OptionParser()
    _OptionParser_obj.define("port",default=8888,help="The port on which to listen",type=int,)
    _OptionParser_obj.define("template_path",group="application",help="The path to the template file",)
    _OptionParser_obj.define("static_path",group="application",help="The path to the static files",)
    _OptionParser_obj.define("test_var",default="test_var",type=str)
    _OptionParser_obj.define("test_list",default=list(),multiple=True)
    _OptionParser_obj.define("test_dict",default=dict(),type=dict)

# Generated at 2022-06-26 08:36:56.506001
# Unit test for method parse of class _Option
def test__Option_parse():
    test__Option_parse_set_0 = _Option("name", default=None, type=None, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    assert test__Option_parse_set_0._parse_string('foo') == 'foo'
    assert test__Option_parse_set_0._parse_bool('true') == True
    assert test__Option_parse_set_0._parse_bool('false') == False
    assert test__Option_parse_set_0._parse_timedelta('1 year') == datetime.timedelta(31536000)
    assert test__Option_parse_set_0._parse_timedelta('1d') == datetime.timedelta(1)
    assert test__Option_parse_set_0.parse

# Generated at 2022-06-26 08:36:58.097131
# Unit test for method parse of class _Option
def test__Option_parse():
    list_0 = []
    string_0 = _Option._Option.parse(list_0, "")
    string_1 = _Option._Option.parse(list_0, "")
    return string_0, string_1


# Generated at 2022-06-26 08:37:08.759454
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # -b for bool
    # -i for int
    # -f for float
    # -s for string
    # -l for list
    # -d for dict
    # -t for datetime
    # -dt for timedelta
    # -c for callback
    # -o for object
    # -p for path
    # -e for existing path
    # -r for existing path or empty string
    # -m for method
    # -g for group
    # --g1= for group
    # --g2= for group
    # --g3= for group
    # -h for help
    options = OptionParser()
    options.define('b', default=True)
    options.define('i', default=100, type=int)
    options.define('f', default=0.1, type=float)
