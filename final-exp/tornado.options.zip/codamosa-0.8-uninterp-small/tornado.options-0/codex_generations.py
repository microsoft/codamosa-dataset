

# Generated at 2022-06-26 08:28:34.973690
# Unit test for method value of class _Option
def test__Option_value():
    option_parser_1 = OptionParser()
    option_i_0 = _Option('name', '"value"')
    option_i_0.parse('"value"')
    assert option_i_0.value() == '"value"'
    option_i_1 = _Option('name', '"value"')
    option_i_1.set('"value"')
    assert option_i_1.value() == '"value"'
    option_i_2 = _Option('name', '"value"')
    option_i_2.value()
    assert option_i_2.value() == '"value"'


# Generated at 2022-06-26 08:28:39.479153
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    option_parser_0 = OptionParser()
    name_0 = Dummy()
    value_0 = Dummy()
    option_parser_0.__setattr__(name_0, value_0)



# Generated at 2022-06-26 08:28:42.642210
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    from tornado.options import OptionParser
    option_parser_1 = OptionParser()
    with pytest.raises(Exception) as __einfo:
        option_parser_1.parse_config_file(path='config')



# Generated at 2022-06-26 08:28:53.382659
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    config_0 = {"__file__": os.path.abspath("")}
    open("", "rb")
    with open("", "rb") as f_0:
        exec_in("", config_0, config_0)
    for name_0 in config_0:
        normalized = OptionParser()._normalize_name(name_0)
        if normalized in OptionParser()._options:
            OptionParser().run_parse_callbacks()


# Generated at 2022-06-26 08:28:58.301886
# Unit test for method value of class _Option
def test__Option_value():
    option_0 = _Option("name",type=None)
    assert option_0.value() == None


# Generated at 2022-06-26 08:29:04.761970
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    option_parser_1 = OptionParser()
    with open("test0.py", "w") as file:
        file.write(
            'print("OMG")\n'
            "key = value\n"
            "key2 = value2\n"
        )

    option_parser_1.parse_config_file("test0.py", final=False)


# Generated at 2022-06-26 08:29:15.147528
# Unit test for method set of class _Option
def test__Option_set():
    option_parser_0 = OptionParser()
    option_parser_0.add_option('--logging', dest='logging', default='info', type='string', help='Set the Python log level. If not set, no logging will occur.', metavar='LEVEL')
    option_parser_0._options['logging'].set('info')
    option_parser_0._options['logging'].set('info')


# Generated at 2022-06-26 08:29:17.435405
# Unit test for method parse of class _Option
def test__Option_parse():
    option_parser_0 = OptionParser()
    list_0 = []
    for str_0 in list_0:
        _Option.parse(str_0)



# Generated at 2022-06-26 08:29:20.656963
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    test_case_0()


# Generated at 2022-06-26 08:29:27.391441
# Unit test for method group_dict of class OptionParser
def test_OptionParser_group_dict():
    print('Testing OptionParser.group_dict')
    option_parser_0 = OptionParser()
    option_parser_0.define('name', type=str, multiple=False, group='group_name_0')
    option_parser_0.define('name', type=bool, multiple=True, group='group_name_1')
    option_parser_0.define('name', default=None, group='group_name_2')
    group_dict_0 = option_parser_0.group_dict('group_name_2')



# Generated at 2022-06-26 08:29:55.588484
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    option_parser_0 = _Mockable()
    option_parser_0.__setattr__('name', 'value')
    option_parser_0._originals['name'] = 'value'


# Generated at 2022-06-26 08:29:59.507230
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    option_parser_0 = OptionParser()
    # Unit test for method __iter__ of class OptionParser
    # AssertionError: <tornado.options._Option object at 0x10e0d2518> != <_Option object at 0x10e0d2518>
    assert option_parser_0.__iter__() != object()


# Generated at 2022-06-26 08:30:12.979385
# Unit test for method parse of class _Option
def test__Option_parse():
    def __init__(self, name: str, default: Any = None, type: Optional[type] = None, help: Optional[str] = None, metavar: Optional[str] = None, multiple: bool = False, file_name: Optional[str] = None, group_name: Optional[str] = None, callback: Optional[Callable[[Any], None]] = None) -> None:
        if default is None and multiple:
            default = []
        self.name = name
        if type is None:
            raise ValueError("type must not be None")
        self.type = type
        self.help = help
        self.metavar = metavar
        self.multiple = multiple
        self.file_name = file_name
        self.group_name = group_name
        self.callback = callback

# Generated at 2022-06-26 08:30:24.697650
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # test_path = os.path.dirname(os.path.abspath(__file__))
    # template_dir = os.path.join(test_path, "data/templates")
    # static_dir = os.path.join(test_path, "data/static")
    option_parser_0 = OptionParser()
    option_parser_0.define("mysql_host", default="127.0.0.1:3306", type=str)
    option_parser_0.define("memcache_hosts", default="127.0.0.1:11011", type=str, multiple=True)
    option_parser_0.define("mysql_database", default="tornado_test")

# Generated at 2022-06-26 08:30:31.344561
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    options = Options()
    options.define("name", default="default-name", type=str, help="name")
    options.define("age", default=13, type=int, help="age")
    options.define("skill", default="default-skill", type=str, help="skill")


# Generated at 2022-06-26 08:30:34.122948
# Unit test for method set of class _Option
def test__Option_set():
    option_0 = _Option("/tmp/dummy", multiple=False, type=text_type, default="dummy default")
    option_0.set("dummy value")


# Generated at 2022-06-26 08:30:41.581897
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    # Initialization of OptionParser #
    option_parser_1 = OptionParser()
    # Test code for __iter__ #
    for x in option_parser_1:
        pass
    # Attribute '_options' of OptionParser #
    assert isinstance(option_parser_1._options, dict)


# Generated at 2022-06-26 08:30:42.998309
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    option_parser_0 = OptionParser()
    iterator_0 = iter(option_parser_0)


# Generated at 2022-06-26 08:30:50.730870
# Unit test for method parse of class _Option
def test__Option_parse():
    option_parser_0 = OptionParser()
    _o = _Option("name", "default", None, None, None, None, None, None, None)
    _o.parse("value")
    # Unit test for method value of class _Option
    _o.value()

# Generated at 2022-06-26 08:31:02.155632
# Unit test for method set of class _Option
def test__Option_set():
    option_parser_0 = OptionParser()
    option_1 = _Option("option_1", default=None, type=None, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    option_1.set(value)
    option_2 = _Option("option_2", default=None, type=None, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    option_2.set(value)
    option_3 = _Option("option_3", default=None, type=None, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    option_3.set(value)


# Generated at 2022-06-26 08:31:22.342165
# Unit test for method parse of class _Option

# Generated at 2022-06-26 08:31:25.809390
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # args and kwargs for the called function
    parser = OptionParser()
    parser.parse_config_file(path='./test.conf')
    print(options.env)

# unit test for method parse_command_line of class OptionParser

# Generated at 2022-06-26 08:31:31.069394
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    instance = OptionParser()
    try:
        assert isinstance(iter(instance), collections.abc.Iterator)
    except Exception as e:
        print('Error:', e)
        print('Error:', list(zip(
            ("An exception of type " + str(type(e).__name__) +
             " was raised when calling the " +
            inspect.stack()[0][3] + " function with the following arguments:"),
            list(''))))
        raise


# Generated at 2022-06-26 08:31:38.332574
# Unit test for method set of class _Option
def test__Option_set():
    # Create an instance of class _Option
    name = "My test"
    type = str
    option = _Option(name, type)
    # Set the value of an option
    value = "My value"
    option.set(value)
    assert option._value == value


# Generated at 2022-06-26 08:31:39.572730
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    test_case_0()


# Generated at 2022-06-26 08:31:41.449317
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    mockable = _Mockable()
    __setattr__(mockable, "name", value)


# Generated at 2022-06-26 08:31:51.230649
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    option_parser = OptionParser()
    option_parser.define("name", default='apple')
    mockable_obj = _Mockable(option_parser)
    mockable_obj.__setattr__('name', 'pear')
    assert getattr(option_parser, 'name') == 'pear', 'Assertion Error: ' + str(getattr(option_parser, 'name'))


# Generated at 2022-06-26 08:31:52.785336
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    obj = _Mockable()
    obj.__setattr__('', '', '')


# Generated at 2022-06-26 08:31:54.991739
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    test_case_0()


# Generated at 2022-06-26 08:32:07.109200
# Unit test for method parse of class _Option
def test__Option_parse():
    # Test cases
    test_cases = [
        # Test case 1
        # Input
        {
            'name': 'name_0',
            'default': None,
            'type': datetime.datetime,
            'help': None,
            'metavar': None,
            'multiple': True,
            'file_name': None,
            'group_name': None,
            'callback': None,
            'value': 'string_0'
        },
        # Output
    ]
    for test_case in test_cases:
        name, default, type, help, metavar, multiple, file_name, group_name, callback, value = \
            test_case['name'], test_case['default'], test_case['type'], test_case['help'], test_case['metavar'],

# Generated at 2022-06-26 08:32:28.521297
# Unit test for method parse of class _Option
def test__Option_parse():
    try:
        settable = _Option('t', default=datetime.datetime(2010, 1, 1), type=datetime.datetime, multiple=False)
        settable.parse('2010-2-2')
        assert(settable.value().year == 2010)
        assert(settable.value().month == 2)
        assert(settable.value().day == 2)
    except Exception as e:
        print('parse failed with:', e)
        sys.exit(1)

# Test case for command line parsing

# Generated at 2022-06-26 08:32:41.233233
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    import os
    import sys
    from shutil import copyfile

    from tornado.options import define, options, parse_config_file, print, parse_command_line
    from tornado.options import Error

    original = os.path.abspath(__file__)

# Generated at 2022-06-26 08:32:47.213675
# Unit test for method set of class _Option
def test__Option_set():
    o: _Option = _Option("test_option")
    o.set([1, 2])
    assert o.value() == [1, 2]
    o.set(3)
    assert o.value() == 3


# Generated at 2022-06-26 08:32:55.040950
# Unit test for method parse of class _Option
def test__Option_parse():
    print("Unit test for method parse of class _Option")
    # input
    option_0 = _Option(
        "name",
        default=None,
        type=int,
        help=None,
        metavar=None,
        multiple=False,
        file_name=None,
        group_name=None,
        callback=None
    )
    parse_0 = option_0.parse("1")
    parse_1 = option_0.parse("0")
    parse_2 = option_0.parse("-1")
    # check
    assert parse_0 == 1
    assert parse_1 == 0
    assert parse_2 == -1


# Generated at 2022-06-26 08:32:57.750620
# Unit test for method print_help of class OptionParser
def test_OptionParser_print_help():
    try:
        print_help()
    except:
        raise Error("Unexpected Error raised in print_help")


# Generated at 2022-06-26 08:33:02.530267
# Unit test for method set of class _Option
def test__Option_set():
    option = _Option("help",
                     default=None,
                     type=type(None),
                     help=None,
                     metavar=None,
                     multiple=False,
                     file_name=None,
                     group_name=None,
                     callback=None)
    option.set(None)



# Generated at 2022-06-26 08:33:08.878722
# Unit test for method parse of class _Option
def test__Option_parse():
    list_0 = _Option("name", "default")
    list_1 = list_0.parse("value")
    assert list_1 == list_0.value()
    assert isinstance(list_1, str)
    assert list_0._value == "value"


# Generated at 2022-06-26 08:33:13.129346
# Unit test for method set of class _Option
def test__Option_set():
    test_arg_0 = ('n',)
    test_arg_1 = ('n',)

    test__Option_set_arg_0 = _Option(test_arg_0,test_arg_1)
    print(test__Option_set_arg_0)


# Generated at 2022-06-26 08:33:15.778033
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    inst = OptionParser()
    inst.print_help()


# Generated at 2022-06-26 08:33:25.500238
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    options = Options()
    options.define("opt_str", type=str, default=None)
    options.define("opt_bool", type=bool, default=None)
    options.parse_config_file('test/test_option_parser.cfg', final=False)
    assert options.opt_str == "test"
    assert options.opt_bool == True
    try:
        options.parse_config_file('test/not_exist.cfg', final=False)
    except FileNotFoundError:
        print("File not exist. Pass")


# Generated at 2022-06-26 08:34:03.888784
# Unit test for method set of class _Option
def test__Option_set():
    option = _Option("name")
    option.set("value")


# Generated at 2022-06-26 08:34:11.499207
# Unit test for method set of class _Option
def test__Option_set():
    log_list = []
    print_list = []
    mock_print = MagicMock()
    mock_print.side_effect = print_list.append
    mock_open = MagicMock()
    mock_open.return_value = []
    # We mock __name__ because it isn't available under python3.x in
    # the global namespace.
    with patch('builtins.open') as mock_open, patch('builtins.print') as mock_print:
        mock_open.return_value = []
        with patch('os.path.basename') as mock_os_path_basename:
            with patch('sys.argv') as mock_sys_argv:
                mock_os_path_basename.return_value = "python3.7"

# Generated at 2022-06-26 08:34:21.276992
# Unit test for method parse of class _Option
def test__Option_parse():
    option = _Option('abc')
    # Test case0: multiple == False, type == datetime.timedelta, value = '0m0s'
    option.multiple = False
    assert option._parse_timedelta('0m0s') == datetime.timedelta(0, 0, 0)
    assert option._parse_timedelta('0s') == datetime.timedelta(0, 0, 0)
    assert option._parse_timedelta('0.0s') == datetime.timedelta(0, 0, 0)
    assert option._parse_timedelta('0m0.0s') == datetime.timedelta(0, 0, 0)
    assert option._parse_timedelta('0h') == datetime.timedelta(0, 3600, 0)
    assert option._parse_

# Generated at 2022-06-26 08:34:34.040454
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    options = OptionParser()
    
    options.define('a', multiple=True)
    options.define('b', type=int)
    options.define('c', type=str)
    options.define('d', type=float)
    options.define('e', type=bool)
    options.define('f', type=datetime.datetime)
    options.define('g', type=datetime.timedelta)


# Generated at 2022-06-26 08:34:40.546580
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    optparse = OptionParser()

    optparse.define("port", type=int, default=8888, help="run on the given port", metavar="PORT")
    optparse.define("debug", type=bool, default=False, help="run in debug mode")

    optparse.parse_config_file("./config/default.conf")

    print(optparse.options)


# Generated at 2022-06-26 08:34:46.328700
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    list_0 = []
    # Todo: move to unit test
    #assert not list_0, 'after unittest, a list of failed tests will be printed'
    return list_0


# Generated at 2022-06-26 08:34:48.949537
# Unit test for method set of class _Option
def test__Option_set():
    option = _Option('', '', str, '', '')
    option.set('', '')

# Generated at 2022-06-26 08:35:02.878943
# Unit test for method group_dict of class OptionParser
def test_OptionParser_group_dict():
    print(__name__)
    print(OptionParser.group_dict)
    print(OptionParser.group_dict.__doc__)

    option_parser_0 = OptionParser(module_name_prefix="test_module_prefix")
    option_parser_0.define("test_option_1", type=str, group="test_group_1")
    option_parser_0.define("test_option_2", type=int, group="test_group_2")
    # prints "{'test_option_1': None}"
    print(option_parser_0.group_dict("test_group_1"))
    # prints "{'test_option_2': None}"
    print(option_parser_0.group_dict("test_group_2"))
    # prints "{'test_option_1': None, 'test_option_

# Generated at 2022-06-26 08:35:08.354419
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    # Case 0: construct a new instance and call parse_command_line
    # Case 1: construct a new instance, set the options, call set the command line args, call parse_command_line
    pass




# Generated at 2022-06-26 08:35:12.603813
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    options.config_file = 'option_config_file'
    options.parse_config_file(options.config_file)
    assert options.test_val == 1


# Generated at 2022-06-26 08:36:03.413486
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    test_case_0()

if __name__ == "__main__":
    test__Mockable___setattr__()

# Generated at 2022-06-26 08:36:04.127345
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    test_case_0()


# Generated at 2022-06-26 08:36:11.222519
# Unit test for method parse of class _Option
def test__Option_parse():
    _option = _Option(bool)
    _option.parse("true")
    _option.parse("True")
    _option.parse("1")
    _option.parse("t")
    _option.parse("yes")
    _option.parse("y")
    _option.parse("false")
    _option.parse("False")
    _option.parse("0")
    _option.parse("f")
    _option.parse("no")
    _option.parse("n")


# Generated at 2022-06-26 08:36:22.888175
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    global _options
    global options
    global _optparse_instance
    _options = {}
    options = _OptionParser()
    options.define("template_path", group='application')
    options.define("static_path", group='application')
    options.define("config", type=str, callback=lambda path: options.parse_config_file(path, final=False))
    args = [sys.executable, '--config=test/test.conf']
    options.parse_command_line(args=args, final=True)
    test_case_0()
    dict_0 = options.group_dict('application')
    assert dict_0 == {'template_path': 'templates', 'static_path': 'static'}


# Generated at 2022-06-26 08:36:25.909535
# Unit test for method set of class _Option
def test__Option_set():
    _Option_inst = _Option
    _Option_inst.set(arg_0)
    assert True


# Generated at 2022-06-26 08:36:33.232544
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    dval = {
        "aaa": 1,
        "bbb": 2,
        "ccc": 3
    }
    # 模拟 command line input
    sys.argv = ['__main__.py', '--aaa=1', '--bbb=2', '--ccc=3']
    parsed_option = parse_command_line()
    for key, value in options.items():
        print(key,value)
        assert key in options
        assert value == dval[key]


# Generated at 2022-06-26 08:36:42.753773
# Unit test for method parse of class _Option
def test__Option_parse():
    option = _Option(
        "name",
        default="2030-12-31 00:00:00",
        type=datetime.datetime,
        help=None,
        metavar=None,
        multiple=False,
        file_name=None,
        group_name=None,
        callback=None,
    )

# Generated at 2022-06-26 08:36:55.557910
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    options = Options()
    options.define("opt1", default=0)
    options.define("opt2", default=0, type=int)
    options.define("opt3", default=0, type=bool)
    options.define("opt4", default=0, type=float)
    options.define("opt5", default=0, type=str)
    options.define("opt6", default=0, type=list)
    options.define("opt7", default=0, type=Options.as_str_list)
    options.define("opt8", default=0, type=lambda value: type(value))
    options.define("opt9", default=0, type=datetime.datetime)
    options.define("opt10", default=0, type=datetime.timedelta)

# Generated at 2022-06-26 08:36:58.773202
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    if options._options:
        test_case_0()


# Generated at 2022-06-26 08:37:04.503231
# Unit test for method parse of class _Option
def test__Option_parse():
    _value = datetime.datetime(2019, 12, 12, 15, 51, 27)
    obj = _Option("name", type=datetime.datetime, metavar="")
    obj.parse(_value)
    s = obj.value()
    print(s)
