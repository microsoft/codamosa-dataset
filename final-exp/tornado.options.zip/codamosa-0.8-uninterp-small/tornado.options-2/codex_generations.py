

# Generated at 2022-06-26 08:29:14.710582
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    options = OptionParser()
    options.define("x")
    options.define("y")
    _mockable = _Mockable(options)
    _mockable.__setattr__("x", True)
    _mockable.__setattr__("y", False)
    assert _mockable.x == _mockable.__getattr__("x")
    assert _mockable.y == _mockable.__getattr__("y")



# Generated at 2022-06-26 08:29:17.060931
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    options = OptionParser()
    options.define("name")
    options.name = 3
    assert options.name == 3


# Generated at 2022-06-26 08:29:29.744685
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    print('start test_OptionParser_parse_config_file')
    # Create a test config file
    configFile = open('config_file', 'w')
    configFile.write('port = 81\n')
    configFile.write('mysql_host = \'mydb.example.com:3306\'\n')
    configFile.write('memcache_hosts = [\'cache1.example.com:11011\']\n')
    configFile.close()

    # Define option in the test file
    define('port', type=int, group='application')
    define('mysql_host', type=str, group='database')
    define('memcache_hosts', type=str, group='services', multiple=True)

    global options
    options = OptionParser()

# Generated at 2022-06-26 08:29:34.557911
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    tornado.options.define("port", default=80, type=int, multiple=False,
        help="run on the given port", metavar="PORT", group="application",
        callback=None)
    print("define test passed")


# Generated at 2022-06-26 08:29:48.141355
# Unit test for method set of class _Option
def test__Option_set():
    # Use the case in top-level docs of this module
    options = OptionParser()

    class MyHandler(tornado.web.RequestHandler):
        def initialize(self, db, memcache):
            pass

    options.define("port", default=8000, help="run on the given port", type=int)
    options.define("mysql_host", default="127.0.0.1:3306", help="main user db host")
    options.define("memcache_hosts", default="127.0.0.1:11011", multiple=True, help="memcache hosts")
    options.define("log_to_stderr", default=False)
    options.parse_command_line(args=["--log_to_stderr", "1"])
    options.print_help()
    # test with legal input


# Generated at 2022-06-26 08:29:56.376343
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    parser = OptionParser()
    parser.define("name", type=str, help="Your name")
    parser.define("age", type=int, help="Your age")
    parser.define("platform", type=str, help="Your platform")
    parser.define("favourite_number", type=int, help="Your favourite number")
    parser.define("favourite_color", type=str, help="Your favourite color")

    argv = ["", "--name=suvash", "--age=25", "--platform=Python", "--favourite_number=2", "--favourite_color=blue"]

    remaining = parser.parse_command_line(argv)
    assert remaining == []

    assert options.name == "suvash"
    assert options.age == 25
    assert options.platform == "Python"

# Generated at 2022-06-26 08:30:09.707219
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    OptionParser.define("port", type=int, default=8888, group="server", help="run on the given port", metavar="PORT")
    OptionParser.define("mysql_host", type=str, default="localhost:3306", group="database", help="mysql database host")
    OptionParser.define("redis_host", type=str, default="localhost:6379", group="database", help="redis database host")
    OptionParser.define("memcache_hosts", multiple=True, type=str, default=["localhost:11011", "localhost:11012"],
                        group="cache", help="memcache hosts")

# Generated at 2022-06-26 08:30:16.850076
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    print('Testing method __iter__')

# Generated at 2022-06-26 08:30:26.124248
# Unit test for method value of class _Option
def test__Option_value():
    options = OptionParser()
    options.define("foo", 1, int, multiple=False)
    options.define("bar", [1, 2], int, multiple=True)

    # Normal case
    options.parse_command_line(["--foo", "2"])
    assert options.foo == 2

    options.parse_command_line(["--bar", "1,2:4"])
    assert options.bar == [1, 2, 3, 4]

    options.parse_command_line(["--bar", "1,2:4"])
    assert options.bar == [1, 2, 3, 4]

    # Parse from config file
    options.parse_config_file("./options.cfg")
    assert options.foo == 10

# Generated at 2022-06-26 08:30:36.542557
# Unit test for method set of class _Option
def test__Option_set():
    print("Running test test_set")
    opt = _Option("", default="", type=str, multiple=False)
    # Test 1
    try:
        # test_set
        value = "1"
        opt.set(value)
        assert opt.value() == "1", opt.value()
    except Error:
        raise Error("test_set failed")


# Generated at 2022-06-26 08:30:56.752924
# Unit test for method parse of class _Option
def test__Option_parse():
    option = _Option("name", None, str, None, None, False, None, None, None)
    option.parse("Wrong time format")

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 08:31:08.084138
# Unit test for method parse of class _Option
def test__Option_parse():
    # test_01
    options = OptionParser()
    option = _Option(
        name="date",
        default=None,
        type=datetime.datetime,
        help=None,
        metavar=None,
        multiple=False,
        file_name=None,
        group_name=None,
        callback=None,
    )
    value = "Fri Oct 12 16:55:55 2012"
    option.parse(value)
    result = option.value()
    # 格式化时间输出
    result = result.strftime("%Y-%m-%d %H:%M:%S")
    print_result(result, "2012-10-12 16:55:55")

    # test_02
    options = OptionParser()

# Generated at 2022-06-26 08:31:13.701441
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    op = OptionParser()

    def foo(opt_name):
        op.define(opt_name, type=str, help="foo")

    foo("bar")
    foo("baz")
    # print(list(op))


# Generated at 2022-06-26 08:31:24.479512
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    op_test = OptionParser()
    op_test.define('host', default='www.mydomain.com', type=str, group='mydomain')
    op_test.define('port', default=80, type=int, group='mydomain')
    op_test.define('log_file_prefix', default='/tmp/tornado.log', type=str)
    op_test.define('log_to_stderr', default=False, type=bool)
    op_test.parse_config_file('../config_file.py')
    group_dict = op_test.group_dict('mydomain')
    print(group_dict)


# Generated at 2022-06-26 08:31:30.146418
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    import io
    from contextlib import redirect_stdout
    parser = OptionParser()
    parser.define("name", default="Bob", help="who to greet")
    parser.define("greeting", default="Hello", help="how to greet")
    parser.parse_command_line(["--name=Jane"])
    assert list(parser.options) == ["name", "greeting"]


# Generated at 2022-06-26 08:31:34.884550
# Unit test for method parse of class _Option
def test__Option_parse():
    # define options
    def on_parse_complete():
        print("parse complete")
    
    def on_parse_int(value):
        print("on_parse_int: " + str(value))
    
    def on_parse_float(value):
        print("on_parse_float: " + str(value))
        
    def on_parse_string(value):
        print("on_parse_string: " + str(value))

    # set options
    options.define("int", 0, int, group="test", callback=on_parse_int)
    options.define("float", 0.0, float, group="test", callback=on_parse_float)
    options.define("string", "", str, group="test", callback=on_parse_string)

    # add parse callback
    options.add_parse

# Generated at 2022-06-26 08:31:37.901292
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    define("port", type=int, default=80, help="Run server on a specific port")


# Generated at 2022-06-26 08:31:39.020975
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    print_help()


# Generated at 2022-06-26 08:31:42.160083
# Unit test for method set of class _Option
def test__Option_set():
    test_class = _Option(name="testname")
    test_value = [1, 2, 3]
    test_class.set(test_value)
    print(test_class.value())


# Generated at 2022-06-26 08:31:56.417459
# Unit test for method set of class _Option
def test__Option_set():
    _option = _Option(
        name="name",
        default=None,
        type=str,
        help=None,
        metavar=None,
        multiple=False,
        file_name=None,
        group_name=None,
        callback=None
    )
    value_1 = "value 1"
    _option.set(value_1)
    value_2 = [1, 2, 3]
    try:
        _option.set(value_2)
    except Error as e:
        print(e)
    value_3 = None
    try:
        _option.set(value_3)
    except Error as e:
        print(e)
    _option.multiple = True
    _option.set(value_2)

# Generated at 2022-06-26 08:32:10.930806
# Unit test for method set of class _Option
def test__Option_set():
    option = _Option('name', default='default_value', type=str,
            help='help', metavar='metavar', multiple=False,
            file_name='file_name', group_name='group_name',
            callback=None)
    option.set('value')
    assert option.value() == 'value'


# Generated at 2022-06-26 08:32:20.916806
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    options = OptionParser()
    options.define("port", default="8080", help="run on the given PORT)",
                   type=int)
    options.define("debug", default="true", help="run in debug mode")
    options.define("log_file_prefix", default=os.path.join(".", "logs", "server.log"),
                   help="Path prefix for log files", type=str)
    options.define("logging", default="debug",
                   help="the logging level", type=str)
    options.define("db_uri", default="mysql+pymysql://root:root@127.0.0.1:3306/supermarket?charset=utf8", help="the database uri")

# Generated at 2022-06-26 08:32:30.036649
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    # Test cases:
    # 1. Test when argument args of parse_command_line is None
    # 2. Test when argument args of parse_command_line is not None
    # 3. Test when argument final of parse_command_line is not None
    # 4. Test when option is defined but its value is not given

    # Test case 1
    # args[0] is ignored since it is the program name in sys.argv
    args_input = ["program_name", "--help"]
    # If args is None, args is set to sys.argv
    assert options.parse_command_line(args_input) == []
    print("Test case 1, parse_command_line(args=None) success\n")

    # Test case 2
    args = ["program_name", "--port=8080"]
    # If args is not

# Generated at 2022-06-26 08:32:41.675015
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    import os
    from pathlib import Path

    option_parser = OptionParser()
    option_name = 'option_name'
    option_type = str
    default_value = 'default_value'
    option_help = 'option_help'
    option_metavar = 'option_metavar'
    option_callback = None

    # Defines a new command line option
    option_parser.define(
        option_name,
        default=default_value,
        type=option_type,
        help=option_help,
        metavar=option_metavar,
        callback=option_callback
    )

    # Setup the test config file
    cwd = Path.cwd()
    test_config_filename = "test_option_parser.config"

# Generated at 2022-06-26 08:32:49.626477
# Unit test for method set of class _Option
def test__Option_set():
    opt = _Option('name',default=None,type=int,help='',
                  metavar=None,multiple=False,file_name=None,
                  group_name=None,callback=None)
    opt._parse = lambda x: int(x)
    opt.set('1')
    assert opt._value == 1
    opt.set(2)
    assert opt._value == 2


# Generated at 2022-06-26 08:33:03.564918
# Unit test for method set of class _Option

# Generated at 2022-06-26 08:33:15.333306
# Unit test for method set of class _Option
def test__Option_set():
    # Test case 1
    testcase = {"name":"test1", "type":123, "multiple":True, "callback":None}
    option = _Option(**testcase)
    testcase.pop("name")
    testcase.pop("multiple")
    testcase.pop("callback")
    testcase["value"] = 123
    try:
        option.set(**testcase)
        print("Pass testcase 1")
    except Exception:
        print("Fail testcase 1")

    # Test case 2
    testcase = {"name":"test1", "type":123, "multiple":True, "callback":None}
    option = _Option(**testcase)
    testcase.pop("name")
    testcase.pop("multiple")
    testcase.pop("callback")
    testcase["value"] = "a"

# Generated at 2022-06-26 08:33:20.865482
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    # Initialize the OptionParser class
    option_parser = OptionParser()

    assert option_parser

    #Test cases
    assert option_parser._parse_command_line(["-h"]) == []

# Generated at 2022-06-26 08:33:25.167752
# Unit test for method set of class _Option
def test__Option_set():
    op = _Option("name", default="Hellow", type=str, help="blahblah", metavar="blah", multiple=False, file_name="file.py", group_name=None, callback=None)
    op.set("Hello")
    assert (op.value() == "Hello")


# Generated at 2022-06-26 08:33:27.915280
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    op = OptionParser()
    op.define("mysql_host",default='mydb.example.com:3306')

    op.parse_config_file('config.py')
    print(op.mysql_host)


# Generated at 2022-06-26 08:33:35.334209
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    assert True == _OptionParser().parse_config_file("./parse_config_file.cfg", True)


# Generated at 2022-06-26 08:33:47.296205
# Unit test for method set of class _Option
def test__Option_set():
    myargs_dict = {"dst_path": "dst_path"}
    options = OptionParser()
    options.define("dst_path", type=str, help=None, multiple=False, metavar=None)
    options._parse_command_line(myargs_dict)
    option = _Option("dst_path", default=None, type=str, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    assert option.set(myargs_dict["dst_path"]) == None
    assert option._value == "dst_path"
    assert option.value() == "dst_path"


# Generated at 2022-06-26 08:33:55.885778
# Unit test for method parse of class _Option
def test__Option_parse():
    # Test cases
    _option_dict = {
        "default": None,
        "type": datetime.date,
        "help": None,
        "name": "date",
        "metavar": None,
        "multiple": False,
        "file_name": None,
        "group_name": None,
        "callback": None
    }

# Generated at 2022-06-26 08:34:07.726713
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    import argparse
    argparam = OptionParser()
    argparam.define('multi_opt', default=False, type=bool)
    argparam.define('speed', default=False, type=bool, group='testing')
    argparam.define('profile', default=False, type=bool, group='testing')
    argparam.define('logging_level', default=False, type=bool)
    argparam.define('logging_file', default='/var/log/test.log', type=str)
    argparam.define('port', default=False, type=int)
    argparam.define('template_path', default=False, type=str)
    argparam.define('error_handler', default=False, type=bool)
    argparam.define('logfile', default=False, type=str)

    argv_list

# Generated at 2022-06-26 08:34:20.108426
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # test_OptionParser_parse_config_file
    parser = OptionParser()
    parser.define("name", 'liujian', type=str, help="name")
    parser.define("age", 15, type=int, help="age")
    parser.define("balance", 1000.00, type=float, help="balance")
    parser.define("is_student", False, type=bool, help="is a student")
    parser.define("courses", ['math', 'physics', 'chemistry'], multiple=True, help="courses")
    config_file = os.path.abspath(os.path.join(os.path.curdir, "test.config"))
    parser.parse_config_file(config_file)
    assert parser.name == 'liujian'
    assert parser.age == 15
   

# Generated at 2022-06-26 08:34:24.020367
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    define("template_path", group='application')
    define("static_path", group='application')
    print(options.group_dict('application')) # {'template_path': None, 'static_path': None}
    path = 'tornado_config_file.txt'
    parse_config_file(path, final=False)
    print(options.group_dict('application')) # {'template_path': 'template', 'static_path': 'static'}


# Generated at 2022-06-26 08:34:33.242417
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    test_dict = {}
    # test_dict["db_host"] = "localhost"
    # test_dict["db_database"] = "mydatabase"
    # test_dict["db_user"] = "root"
    # test_dict["db_password"] = "password"
    # test_dict["logging_level"] = "warning"
    test_dict["application_name"] = "pqdict"
    test_dict["application_version"] = "0.0.2"
    test_dict["path_log"] = "./log/pqdict.log"
    test_dict["path_db"] = "./pqdict.db"
    test_dict["path_config"] = "./config.ini"

    for key, value in test_dict.items():
        define(key, default=None)
   

# Generated at 2022-06-26 08:34:43.405772
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    # create options for unit test
    define("name")
    define("abc")
    define("xyz")

    # create an instance of OptionParser
    parser = OptionParser()

    # return the iterator by calling __iter__
    instance_iter = parser.__iter__()

    # create a list of expected iterator
    expected_iter = [
        ("name", ""),
        ("abc", ""),
        ("xyz", "")
    ]
    
    # check if the next value of both iterators are the same
    for instance_iter_value, expected_iter_value in zip(instance_iter, expected_iter):
        assert instance_iter_value.name == expected_iter_value[0]
        assert instance_iter_value.default == expected_iter_value[1]


# Generated at 2022-06-26 08:34:51.022696
# Unit test for method parse of class _Option
def test__Option_parse():
    o = _Option('t', type=bool)
    print(o.parse('true'))
    o = _Option('t', type=bool)
    print(o.parse('false'))
    o = _Option('t', type=bool)
    print(o.parse('0'))
    o = _Option('t', type=bool)
    print(o.parse('1'))
    o = _Option('t', type=bool)
    print(o.parse('f'))


# Generated at 2022-06-26 08:34:57.891041
# Unit test for method parse of class _Option
def test__Option_parse():
    option = _Option("name", type=str)
    option.parse("abc")
    assert option._value == "abc"

    option = _Option("name", type=int)
    option.parse("123")
    assert option._value == 123


# Generated at 2022-06-26 08:35:27.261589
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # To be corrected
    test_sickids = [
        'sick_S001',
        'sick_S002',
        'sick_S003',
    ]

    # Expected result
    expected_result = dict()
    expected_result['sickids'] = test_sickids

    # To be tested
    tested_result = dict()

    OptionParser.parse_config_file('test_config.py', final = True)



# Generated at 2022-06-26 08:35:29.409661
# Unit test for method set of class _Option
def test__Option_set():
    OP = _Option()
    OP.set(None)



# Generated at 2022-06-26 08:35:39.943863
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    file_name = r"c:\Program Files\Tornado\test_config.conf"
    fp = open(file_name, "w")
    fp.write("port = 80\n")
    fp.write("mysql_host = 'mydb.example.com:3306'\n")
    fp.write("memcache_hosts = ['cache1.example.com:11011',\
              'cache2.example.com:11011']\n")
    fp.write("memcache_hosts = 'cache1.example.com:11011,\
              cache2.example.com:11011'\n")
    fp.close()

    option_parser = OptionParser()
    option_parser.define('port', type=int)

# Generated at 2022-06-26 08:35:49.869040
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # TODO: refactor this
    global options
    options = _Options()

    options.define("port", default=8000, help="run on the given port", type=int)
    options.define("debug", default=False, help="run in debug mode")
    options.define("log_file_prefix", type=str, default="log/tornado.log", help="log file prefix")
    options.define("log_file_max_size", type=int, default=100 * 1000 * 1000, help="max log file size")
    options.define("log_file_num_backups", type=int, default=10, help="how many log files to keep")
    options.define("sql_host", type=str, default="localhost", help="the host of redis")

# Generated at 2022-06-26 08:35:58.778506
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    options.define("address", default="localhost", type=str, help="bind address", group="application")
    options.define("port", default="8080", type=int, help="port to listen on", group="application")
    # options.parse_config_file("./config2.py")
    options.parse_config_file("config.py")


# Generated at 2022-06-26 08:36:11.372056
# Unit test for method parse of class _Option
def test__Option_parse():
    """
    This method was converted from the main method of tornado.options
    to run the following tests for datetime and timedelta type options.
    """
    def _test_datetime(timestamp: str, datetime_obj: datetime.datetime) -> None:
        """
        Tests the datetime case with the timestamp string and a timezone-aware
        datetime object.
        """
        option = _Option(
            name="test_datetime",
            type=datetime.datetime,
            help="testing datetime format parsing",
        )
        assert option.parse(timestamp) == datetime_obj

    def _test_timedelta(timestamp: str, timedelta_obj: datetime.timedelta) -> None:
        """
        Tests the timedelta case with the timestamp string and a timedelta object.
        """

# Generated at 2022-06-26 08:36:23.378828
# Unit test for method parse of class _Option
def test__Option_parse():

    _option = _Option(
        name = "alpha",
        default='b',
        type=str,
        help="help information for alpha",
        metavar="alpha",
        multiple=False,
        file_name='test.py',
        group_name="a",
        callback=None
    )
    _option.parse('abc')
    assert _option.value() == 'abc'
    try:
        _option.parse(1234)
    except Error as e:
        print(e)

    _option = _Option(
        name = "beta",
        default='b',
        type=int,
        help="help information for beta",
        metavar="beta",
        multiple=False,
        file_name='test.py',
        group_name="a",
        callback=None
    )

# Generated at 2022-06-26 08:36:34.121972
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    re = RegExp(r"^\d+\.\d+\.\d+$")
    parser = OptionParser()
    parser.define("version", default=None, type=str, help="set version number")
    parser.define("interval", default=1, type=int, help="set interval")
    parser.define("log_level", default=None, type=str, help="set log level")
    parser.define("logger", default=None, type=str, help="set logger")

    parser.parse_config_file("./test_config.conf")
    print("version: " + str(parser.version))
    print("interval: " + str(parser.interval))
    print("log_level: " + str(parser.log_level))

# Generated at 2022-06-26 08:36:44.524435
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    _opt0 = OptionParser()
    _up = Options()
    _opt1 = _up.define("foo", type=int, help="FOO option")
    _opt2 = _up.define("bar", type=str, help="BAR option")
    _up.parse_command_line(["--foo=1"])
    for _opt in _up:
        if _opt == _opt1:
            assert _opt.value() == 1
        elif _opt == _opt2:
            assert _opt.value() == None
        else:
            raise AssertionError("Unrecognized option %r" % _opt.name)
    else:
        pass
    

# Generated at 2022-06-26 08:36:56.201016
# Unit test for method parse of class _Option
def test__Option_parse():
    from tornado.options import BoolOption
    from tornado.options import StringOption

    _name = "test_bool_name"
    _default = True
    _type = bool
    _help = "test_bool_help"
    bool_option = BoolOption(_name, _default, _help)

    # test bool parse
    bool_parse = bool_option._parse_bool("True")
    assert bool_parse == True
    bool_parse = bool_option._parse_bool("t")
    assert bool_parse == True
    bool_parse = bool_option._parse_bool("1")
    assert bool_parse == True
    bool_parse = bool_option._parse_bool("False")
    assert bool_parse == False
    bool_parse = bool_option._parse_bool("f")
    assert bool_parse == False


# Generated at 2022-06-26 08:37:19.348061
# Unit test for method parse of class _Option
def test__Option_parse():
    wo = _Option('test_name', default = False, type = bool, help = 'test_help', metavar = 'test', multiple = True, file_name = 'test.log', group_name = 'test_group_name', callback = None)

    # test for multiple = False
    assert wo.parse('True') == True
    assert wo.parse('False') == False
    assert wo.parse('1') == True
    assert wo.parse('0') == False
    assert wo.parse('t') == True
    assert wo.parse('f') == False
    assert wo._value == False

    # test for multiple = True
    wo.multiple = True
    wo._value = []
    assert wo.parse('True,False,0') == [True, False, False]

# Generated at 2022-06-26 08:37:21.415583
# Unit test for method set of class _Option
def test__Option_set():
    test_case_0()


# Generated at 2022-06-26 08:37:30.024355
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    module_path = os.path.dirname(os.path.abspath(__file__))
    options.parse_config_file(module_path + "/test_option.cfg")
    assert options.port == 80
    assert options.mysql_host == "mydb.example.com:3306"
    assert options.memcache_hosts == ["cache1.example.com:11011", "cache2.example.com:11011"]
    print("test_OptionParser_parse_config_file passed")

if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.DEBUG)
    test_case_0()
    test_OptionParser_parse_config_file()

# Generated at 2022-06-26 08:37:41.299032
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    def my_callback(value):
        print("callback invoked with value %r" % value)
    # 调用变量定义函数
    options.define("port", type=int, help="run on the given port", callback=my_callback)
    options.define("debug", type=bool, help="run in debug mode")
    # 解析配置文件
    options.parse_config_file("/Users/zheng/Desktop/github/tornado/tests/server_test/options.py")
    print("port = " + str(options.port))
    print("debug = " + str(options.debug))
    print("other = " + str(options.other))
    print("____ = " + str(options.____))
    #