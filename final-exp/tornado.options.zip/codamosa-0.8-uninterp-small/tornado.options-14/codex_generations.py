

# Generated at 2022-06-26 08:28:23.251765
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    option_parser_0 = OptionParser()
    for _opt in option_parser_0:
        assert False


# Generated at 2022-06-26 08:28:30.872688
# Unit test for method set of class _Option
def test__Option_set():
    option_0 = _Option('http_port', type=int, default=80, help='HTTP port',
                      group_name='HTTP Server')
    option_0.set(1)
    #assert option_0.value() == 1
    option_0.set(80)
    #assert option_0.value() == 80


# Generated at 2022-06-26 08:28:41.944987
# Unit test for method group_dict of class OptionParser
def test_OptionParser_group_dict():
    # Use the structure defined in image_for_group_dict_0.png
    option_parser_0 = OptionParser()
    option_parser_0.define(
        "id", default=2, help="An option that takes an integer value.", group="group1"
    )

    option_parser_0.define(
        "human_id",
        default="a",
        help="Human id",
        group="group2",
    )

    # Should print {'id': 2}
    print(option_parser_0.group_dict('group1'))


# Generated at 2022-06-26 08:28:50.869937
# Unit test for method group_dict of class OptionParser
def test_OptionParser_group_dict():
    option_parser_0 = OptionParser()
    group = ""
    group_dict_0: Dict[str, Any] = option_parser_0.group_dict(group)
    print(group_dict_0)
    group_dict_1: Dict[str, Any] = option_parser_0.group_dict(group)
    print(group_dict_1)


# Generated at 2022-06-26 08:28:57.295172
# Unit test for method parse of class _Option
def test__Option_parse():
    with pytest.raises(TypeError):
        _Option.parse(datetime.datetime.utcnow(), "datetime.datetime")
    with pytest.raises(TypeError):
        _Option.parse(datetime.timedelta(0), "datetime.timedelta")
    with pytest.raises(TypeError):
        _Option.parse(True, "bool")
    with pytest.raises(TypeError):
        _Option.parse("string", "builtins.str")


# Generated at 2022-06-26 08:29:02.530189
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    option_parser_0 = OptionParser()
    if option_parser_0.__iter__():
        print('Success')
    else:
        print('Failure')


# Generated at 2022-06-26 08:29:06.655103
# Unit test for method parse of class _Option
def test__Option_parse():
    option_parser_1 = OptionParser()
    option_1 = _Option("name_0", "", "", "", "", "", "", "", "")
    option_1.parse("")


# Generated at 2022-06-26 08:29:13.710132
# Unit test for method parse of class _Option
def test__Option_parse():
    option_parser_1 = OptionParser()
    option_0 = _Option("", None)
    option_parser_1.parse("")
    option_parser_1.parse("")
    option_parser_1.parse("")
    option_parser_1.parse("")
    option_parser_1.parse("")
    option_parser_1.parse("")
    option_parser_1.parse("")
    option_parser_1.parse("")
    option_parser_1.parse("")
    option_parser_1.parse("")
    option_parser_1.parse("")


# Generated at 2022-06-26 08:29:20.318467
# Unit test for method set of class _Option
def test__Option_set():
    option_object_0 = _Option(
        "string_0", False, bool, "string_1", "string_2", True, "string_3"
    )
    # Type error
    #option_object_0.set(None)
    # Type error
    #option_object_0.set(None)
    # Type error
    #option_object_0.set(False)
    option_object_0.set(None)
    

# Generated at 2022-06-26 08:29:30.306670
# Unit test for method parse of class _Option
def test__Option_parse():
    name = os.path.basename(sys.argv[0])

    # Default argument for parse function
    option_parser_0 = OptionParser()
    option_parser_0.define("port", type=int, help="...", group="Application Options", default=8080)
    option_parser_0.define("logging", type=int, help="...", group="Application Options", default=None)
    option_parser_0.define("debug", type=bool, help="...", group="Application Options", default=False)
    option_parser_0.define("url", type=str, help="...", group="Application Options", default=None)

    option_parser_0.parse_command_line()
    option_parser_0.print_help()

# Generated at 2022-06-26 08:29:43.244790
# Unit test for method parse of class _Option
def test__Option_parse():
    option_parser_0 = OptionParser()
    option_0 = _Option('is_master', None, bool, 'enable_admin_state', 'is_master', False, None, None, None)
    option_0.parse('enable_admin_state')


# Generated at 2022-06-26 08:29:53.259408
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    with open('config1.txt', 'w') as config_file:
        print("port = 80", file=config_file)
        print("mysql_host = 'mydb.example.com:3306'", file=config_file)
        print("memcache_hosts = ['cache1.example.com:11011', 'cache2.example.com:11011']", file=config_file)
        print("memcache_hosts = 'cache1.example.com:11011,cache2.example.com:11011'", file=config_file)
    option_parser_0 = OptionParser()
    try:
        option_parser_0.parse_config_file('config1.txt')
    except:
        print("an exception occurred while parsing config file")


# Generated at 2022-06-26 08:29:56.972941
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    option_parser_0 = OptionParser()
    option_parser_0.define("name_0", default="1")
    option_parser_0.__iter__()


# Generated at 2022-06-26 08:29:58.356709
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    options = OptionParser()


# Generated at 2022-06-26 08:30:06.435161
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    # OptionParser_0 instantiation: option_parser_0
    option_parser_0 = OptionParser()
    # _Mockable_0 instantiation: mockable_0
    mockable_0 = _Mockable(option_parser_0)
    # Call to _Mockable._Mockable__setattr__(mockable_0, 'name', 'value')
    mockable_0._Mockable__setattr__('name', 'value')


# Generated at 2022-06-26 08:30:14.443186
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    option_parser_0 = OptionParser()
    mockable_instance_0 = option_parser_0.mockable()
    try:
        mockable_instance_0.__setattr__('attribute_0', 'value_1')
        if mockable_instance_0.attribute_0 == 'value_1':
            print(True)
        else:
            print(False)
    except Exception as e:
        print(False)
    try:
        mockable_instance_0.__setattr__('attribute_0', 'value_0')
        print('ExpectedException')
    except Exception as e:
        print(True)


# Generated at 2022-06-26 08:30:23.312357
# Unit test for method parse of class _Option
def test__Option_parse():
    # setup
    option_parser_1 = OptionParser()
    value_1 = "value_1"

    # stub
    # Note: the stub implementation below is of a function that returns a
    #       choice of two values with probability 1:2 
    def _parse_1(value):
        assert value == value_1
        return value_1
    option_parser_1._Option__parse = _parse_1

    # exercise
    assert option_parser_1._Option__parse(value_1) == value_1


# Generated at 2022-06-26 08:30:25.644665
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    pass


# Generated at 2022-06-26 08:30:39.405581
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    option_parser_0 = OptionParser()
    # The assignment is needed to make sure the object is initialized
    option_parser_0.option_parser_0 = option_parser_0.mockable()
    # mock.patch.object is used to modify the attribute of option_parser_0
    # The name of the attribute to be modified is 'option_parser_0'
    name_0 = 'option_parser_0'
    value_0 = 1
    with mock.patch.object(option_parser_0.option_parser_0, name_0, value_0):
        # Assert the value of the modified attribute.
        assert option_parser_0.option_parser_0 == option_parser_0.mockable()
        assert option_parser_0.option_parser_0.option_parser_0 == 1

# Unit

# Generated at 2022-06-26 08:30:44.587363
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    option_parser_0 = OptionParser()
    _Mockable_0 = _Mockable(option_parser_0)
    _Mockable_0.__setattr__('', ())

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 08:30:56.778106
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    global options
    options = OptionParser()
    print('options is a dictionary: ', isinstance(options,dict))
    print('options is a set: ', isinstance(options,set))
    print('options is a list: ', isinstance(options,list))


# Generated at 2022-06-26 08:31:04.141923
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # TODO: following code may has syntax errors, should be fixed!
    #     delete after finished the unit test code
    #

    # create a tmp file for test
    tmp_path = '/tmp/test_options.py'
    fp = open(tmp_path, 'w')
    fp.write('''
    port = 80
    mysql_host = "mydb.example.com:3306"
    memcache_hosts = ['cache1.example.com:11011', 'cache2.example.com:11011']
    ''')
    fp.close()

    # test parse_config_file function
    options.parse_config_file(tmp_path)
    assert options.port is 80
    assert options.mysql_host is "mydb.example.com:3306"

# Generated at 2022-06-26 08:31:16.545184
# Unit test for method parse of class _Option
def test__Option_parse():
    my_option1 = _Option('my_option1', type=str, multiple=True)
    my_option2 = _Option('my_option2', type=str, multiple=False)
    my_option3 = _Option('my_option3', type=bool, multiple=False)
    my_option4 = _Option('my_option4', type=int, multiple=True)
    my_option5 = _Option('my_option5', type=int, multiple=False)
    my_option6 = _Option('my_option6', type=datetime.datetime, multiple=True)
    my_option7 = _Option('my_option7', type=datetime.datetime, multiple=False)
    my_option8 = _Option('my_option8', type=datetime.timedelta, multiple=True)
    my

# Generated at 2022-06-26 08:31:19.441531
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    import random
    # create mock
    mock = _Mockable(None)
    # create a random value for name
    name = random.random()
    # create a random value for value
    value = random.random()
    mock._originals['name'] = value
    # call method
    mock._Mockable__setattr__(name, value)


# Generated at 2022-06-26 08:31:30.932039
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # Test a defined config file
    option_parser = OptionParser()
    option_parser.define('config_file_path', type=str, group='application')
    option_parser.define('user', type=str, group='application')
    option_parser.define('pass', type=str, group='application')
    option_parser.parse_config_file('test_config.conf')
    assert option_parser.group_dict('application') == {'config_file_path': './test_config.conf', 'user': 'mydb', 'pass': 'mydb'}

    # Test with a path that is not defined in the config file
    with pytest.raises(Exception) as excinfo:
        option_parser.parse_config_file('test_config_with_invalid_path.conf')

# Generated at 2022-06-26 08:31:42.284598
# Unit test for method set of class _Option
def test__Option_set():
    option = _Option(name="some_option", default=None, type={}, help="", metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    # With a valid value
    value = {'foo': 'bar'}
    option.set(value)
    assert option.value() == value
    # With an invalid value
    value = 123
    try:
        option.set(value)
        assert False, "Should have thrown an exception"
    except Error as e:
        assert str(e) == "Option 'some_option' is required to be a dict ({} given)".format(type(value))


# Generated at 2022-06-26 08:31:56.494780
# Unit test for method set of class _Option
def test__Option_set():
    class Test_Option(object):
        def __init__(self, name: str,
                     default: Any = None,
                     type: Optional[type] = None,
                     help: Optional[str] = None,
                     metavar: Optional[str] = None,
                     multiple: bool = False,
                     file_name: Optional[str] = None,
                     group_name: Optional[str] = None,
                     callback: Optional[Callable[[Any], None]] = None
                     ) -> None:
            pass

    o_obj = Test_Option('name', default=None, type=int, help='help', metavar='1', multiple=True,
             file_name=None, group_name='group_name', callback=None)

    value_list = [1, 0]

# Generated at 2022-06-26 08:32:03.794373
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    options = OptionParser()
    # Test case 0
    print("Test case 0: Test default function")
    options.define("port", default=8000, help="run on the given port", type=int)
    options.define("debug", default=False, help="run in debug mode")

    try:
        options.parse_command_line(["--port=9000", "--debug"])
    except Error:
        print("Test case 0 fail")
        return False
    print("Test case 0 pass")

    # Test case 1
    print("Test case 1: Test type attribute is not valid")
    options = OptionParser()
    options.define("port", default=8000, help="run on the given port", type=str)

# Generated at 2022-06-26 08:32:17.157379
# Unit test for method set of class _Option
def test__Option_set():
    option = _Option(
        name="name",
        default=None,
        type=str,
        help="",
        metavar="",
        multiple=False,
        file_name="filename",
        group_name="group name"
        ,callback=str
    )
    if option.multiple:
        if not isinstance(value, list):
            raise Error
                # "Option %r is required to be a list of %s"
                # % (self.name, self.type.__name__)
    else:
        if value is not None and not isinstance(value, self.type):
            raise Error
    if option.callback is not None:
        option.callback(option.value())
        return option.value()


# Generated at 2022-06-26 08:32:29.079491
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    o = OptionParser()
    o.define("name", help="this is for testing", type=str, default="dummy")
    o.parse_command_line(["--name=value"])
    assert(o.name == "value")

    #Test for single dash option
    o.parse_command_line(["-n", "value"])
    assert(o.name == "value")

    #Test for empty value
    o.parse_command_line(["--name"])
    assert(o.name == "true")

    #Test for missing leading dash
    try:
        o.parse_command_line(["name=value"])
    except:
        pass
    else:
        assert False, "parse_command_line should always fail"

    #Test for missing equals sign

# Generated at 2022-06-26 08:33:07.136271
# Unit test for method parse of class _Option
def test__Option_parse():
    option = _Option("name", default=None, type=int, help="sample", metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    assert option.parse("123") == 123

    option = _Option("name", default=None, type=int, help="sample", metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    assert option.parse("-123") == -123

    option = _Option("name", default=None, type=str, help="sample", metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    assert option.parse("hello world") == "hello world"


# Generated at 2022-06-26 08:33:14.858860
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    print("Testing method OptionParser.__iter__(self):")
    print()
    # Create and initialize an OptionParser
    OP = OptionParser()
    OP.define("a", 10)
    OP.define("b", 20)
    OP.define("c", 30)
    OP.define("d", 40)
    OP.define("e", 50)
    OP.define("f", 60)
    for option in OP:
        print('option = ' + str(option))
    print()
    print()


# Generated at 2022-06-26 08:33:22.337363
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # OptionParser.parse_config_file()
    # parser = OptionParser()
    keys = parse_config_file("./config.py")
    print(keys)

    # parser.parse_config_file()
    # assert len(parser.options_dict) > 0


# Generated at 2022-06-26 08:33:34.585752
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # OptionParser instance for testing
    parser = OptionParser()

    # Case 0: File not exists
    parser.parse_config_file('NotExists')

    # Case 1
    with file_test_config_01 as f:
        parser.parse_config_file(f.name)
    assert parser.ssl_options.certfile == "tornado/test/test.crt"
    assert parser.ssl_options.keyfile == "tornado/test/test.key"
    assert parser.log_file_max_size == 10485760
    assert parser.log_rotate_mode == "time"
    assert parser.log_file_prefix == "tornado/log/tornado.log"
    assert parser.log_rotate_interval == 1
    assert parser.log_rotate_when == "W6"


# Generated at 2022-06-26 08:33:41.483809
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    options = _Mockable(OptionParser())
    # Set the attribute name to a new value
    name = 'name'
    value = 'value'
    options.__setattr__(name, value)
    assert getattr(options, name) == value
    # Set the attribute name to a new value
    name = 'name1'
    value = 'value1'
    options.__setattr__(name, value)
    assert getattr(options, name) == value
    # Set the attribute name to a new value
    name = 'name2'
    value = 'value2'
    options.__setattr__(name, value)
    assert getattr(options, name) == value
    # Test case: reuse mockable objects
    name = 'name'
    with pytest.raises(AssertionError):
        options

# Generated at 2022-06-26 08:33:50.497409
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    # OptionParser instance
    options = OptionParser()
    # Define a option with name 'test_flag' and type bool
    options.define('test_bool', type=bool)
    # Define a option with name 'test_int' and type int
    options.define('test_int', type=int)
    # Define a option with name 'test_string' and type str
    options.define('test_string', type=str)
    # Define a option with name 'test_list' and type list
    options.define('test_list', type=list)
    # Define a option with name 'test_json' and type json
    options.define('test_json', type=json)
    # Parse a list of String into options

# Generated at 2022-06-26 08:33:57.142749
# Unit test for method parse of class _Option
def test__Option_parse():
    print("test_options")
    print("test__Option_parse")
    
    option = _Option("a", default=1, type=int, help="a", metavar="A")
    
    #testcase 1
    value = "1"
    try:
        option.parse(value)
        print("testcase 1: pass")
    except:
        print("testcase 1: fail")
    #testcase 2
    value = "1.1"
    try:
        option.parse(value)
        print("testcase 2: pass")
    except:
        print("testcase 2: fail")
    #testcase 3
    value = "a"
    try:
        option.parse(value)
        print("testcase 3: pass")
    except:
        print("testcase 3: fail")
   

# Generated at 2022-06-26 08:34:07.905477
# Unit test for method parse of class _Option
def test__Option_parse():
    # Check for datetime.timedelta
    assert _Option(name='', type=datetime.timedelta,
                   help=None, metavar=None, multiple=False,
                   file_name=None, group_name=None,
                   callback=None, default=None).parse('1h') == datetime.timedelta(hours=1)
    assert _Option(name='', type=datetime.timedelta,
                   help=None, metavar=None, multiple=False,
                   file_name=None, group_name=None,
                   callback=None, default=None).parse('1h1m1s') == datetime.timedelta(
        hours=1, minutes=1, seconds=1)

# Generated at 2022-06-26 08:34:16.902724
# Unit test for method print_help of class OptionParser
def test_OptionParser_print_help():
    parser = OptionParser()

    # Create test file - test.txt
    with open('test.txt', 'w') as test_file:
        parser.print_help(test_file)
    
    # Checking
    test_file = open('test.txt', 'r')
    result = ''
    for line in test_file:
        result += line
    test_file.close()

    assert result == expect_help


# Generated at 2022-06-26 08:34:30.605243
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    config = "../example/example1.cfg"
    oparser = OptionParser()
    oparser.define("username", default="", help="Username of the user", type=str)
    oparser.define("password", default="", help="Password of the user", type=str)
    oparser.define("port", default=80, help="Port of the server", type=int)
    oparser.define("debug", default=False, help="Whether or not the server is in debug mode")
    oparser.parse_config_file(config)
    print(oparser.options.username)
    print(oparser.options.password)
    print(oparser.options.port)
    print(oparser.options.debug)
    #oparser.options.username
    
    

# Generated at 2022-06-26 08:35:03.817958
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    t = tornado.options.OptionParser()
    t.define("var_int", type=int, default=1)
    t.define("var_float", type=float, default=1.1)
    t.define("var_str", type=str, default="hello")
    t.define("var_timedelta", type=timedelta, default=timedelta(seconds=1))
    t.define("var_datetime", type=datetime, default=datetime.utcnow())
    t.define("var_bool", type=bool, default=False)
    t.define("multiple_str", type=str, default=["hello", "world"], multiple=True)
    t.define("multiple_int", type=int, default=[1], multiple=True)

# Generated at 2022-06-26 08:35:12.937114
# Unit test for method parse of class _Option
def test__Option_parse():
    _opt_obj: _Option = _Option("option-name", type=datetime.datetime)
    _opt_obj.parse("2020-08-28:2020-09-02")

# Main entrypoint
if __name__ == "__main__":
    print("Start in main: %s" % __file__)
    test_case_0()
    print("End in main: %s" % __file__)

# Generated at 2022-06-26 08:35:15.426257
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    parser = OptionParser()
    assert parser.__iter__() is not None


# Generated at 2022-06-26 08:35:26.778396
# Unit test for method parse of class _Option
def test__Option_parse():
    import datetime
    o = _Option(name="test", type=datetime.datetime, multiple=False)
    o.parse('2019-02-11 17:15:17')
    o.parse('2019-02-11T17:15')
    o.parse('2019-02-11 17:15')
    o.parse('2019-02-11')
    o.parse('20190211')
    o.parse('09:15:17')
    o.parse('09:15')
    o.parse('9:15')
    o.parse('9:5')
    o.parse('5')

    o = _Option(name="test", type=datetime.timedelta, multiple=False)
    o.parse('1')
    o.parse('1e3')

# Generated at 2022-06-26 08:35:38.728995
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    parser = OptionParser()
    parser.define("demo1", type=int, multiple=True, help="demo1 help")
    parser.define("demo2", type=int, default=10)
    parser.define("demo3", type=int, default=10, help="demo3 help")

    assert parser._normalize_name("demo1") == "demo-1"
    assert parser._normalize_name("demo2") == "demo-2"
    assert parser._normalize_name("demo3") == "demo-3"

    assert parser.options() == ["demo1", "demo2", "demo3"]
    assert parser.groups() == set()
    assert parser.group_dict('') == {}

    assert parser.demo1 == [0]
    assert parser

# Generated at 2022-06-26 08:35:49.512124
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    class Options():

        def __init__(self):
            self.flag = None
            self.flag2 = None
            self.foo = None
            self.bar = None

    options = Options()
    parser = OptionParser()
    parser.define("flag", type=bool, callback=lambda x: setattr(options, 'flag', x))
    parser.define("flag2", type=bool, callback=lambda x: setattr(options, 'flag2', x))
    parser.define("foo", callback=lambda x: setattr(options, 'foo', x))
    parser.define("bar", callback=lambda x: setattr(options, 'bar', x))

# Generated at 2022-06-26 08:35:58.932133
# Unit test for method parse of class _Option
def test__Option_parse():
    option = _Option(
        name="test_name", default=None, type=str, help="test_help", metavar="test_metavar", multiple=False, file_name=None, group_name=None, callback=None)
    option.parse("test_value")
    assert option.value() == "test_value"
    assert option._value == "test_value"


# Generated at 2022-06-26 08:36:09.936924
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    opts = options.Options()
    opts.define("a", default=0, type=int)
    with TemporaryFile("wb+") as tf:
        # Because Windows can't keep a file open for reading while it's
        # also open for writing, we have to write to the temporary file
        # in binary mode and then seek back to the beginning.
        tf.write("a = 1".encode("utf-8"))
        tf.flush()
        tf.seek(0)
        opts.parse_config_file(tf.name)
    assert opts.a == 1


# Generated at 2022-06-26 08:36:19.535206
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # Case-0: when there are no options defined.
    #         In this case, the method just returns without doing anything.
    options = default_options()
    path = "./data/test_OptionParser_parse_config_file/config0.cfg"
    options.parse_config_file(path)
    test_case_0()
    print("test_OptionParser_parse_config_file: case-0")
    print("done")


# Generated at 2022-06-26 08:36:33.089113
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():    
    parser = OptionParser()
    parser.define("port", default=8080, type=int)
    parser.define("ssl_port", type=int)
    parser.define("mysql_host", default="127.0.0.1:3306")
    parser.define(
        "memcache_hosts", default="127.0.0.1:11011", multiple=True
    )
    parser.define("debug", default=False, type=bool)

    print("before parse")
    # Note that the specified config file 'test_config.py' is not present in the package
    # 'test_config.py' is generated with the below code and placed outside the package
    # python -c "from tornado.options import options; print 'from tornado.options import options; options.port = {0}'.format(options.port)

# Generated at 2022-06-26 08:37:15.302639
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    o = _Mockable(OptionParser())
    o.__setattr__("ryanshao", "666")
    assert o._originals == {"ryanshao": "666"}
    assert o._options._options == {"ryanshao": "666"}


# Generated at 2022-06-26 08:37:26.770390
# Unit test for method parse of class _Option
def test__Option_parse():
    _option = _Option('name', default='dsfsd',
                 type=str,
                 help='dsfs',
                 metavar='sfsfs',
                 multiple=False,
                 file_name='sdfsdfs',
                 group_name='sdfsdfsdfs',
                 callback=None)
    assert _option.parse('sdfs') == 'sdfs'

if __name__ == '__main__':
    test_case_0()
    test__Option_parse()

# Generated at 2022-06-26 08:37:40.242434
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    module_path = os.path.dirname(__file__)
    config_path = os.path.join(module_path, 'test_config.py')
    OptionParser = options.OptionParser()
    OptionParser.define('config_int_value', type=int, help='int value in config file')
    OptionParser.define('config_string_value', type=str, help='string value in config file')
    OptionParser.define('config_bool_value', type=bool, help='bool value in config file')
    OptionParser.define('config_list_value', type=list, help='list value in config file')
    OptionParser.define('config_list_int_value', type=list, help='list int value in config file')
    OptionParser.parse_config_file(config_path)