

# Generated at 2022-06-18 10:36:49.147310
# Unit test for method set of class _Option
def test__Option_set():
    option = _Option("name", type=str)
    option.set("value")
    assert option.value() == "value"
    option.set(None)
    assert option.value() == None
    option.set(1)
    assert option.value() == 1
    option.set(1.0)
    assert option.value() == 1.0
    option.set(True)
    assert option.value() == True
    option.set(False)
    assert option.value() == False
    option.set(datetime.datetime.now())
    assert option.value() == datetime.datetime.now()
    option.set(datetime.timedelta(seconds=1))
    assert option.value() == datetime.timedelta(seconds=1)

# Generated at 2022-06-18 10:36:58.320193
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    # Test case 1
    # Input
    #   - args = ['--port=8080']
    #   - final = True
    # Expected output
    #   - remaining = []
    #   - options.port = 8080
    args = ['--port=8080']
    final = True
    options = OptionParser()
    options.define('port', type=int, default=8888)
    remaining = options.parse_command_line(args, final)
    assert remaining == []
    assert options.port == 8080

    # Test case 2
    # Input
    #   - args = ['--port=8080']
    #   - final = False
    # Expected output
    #   - remaining = []
    #   - options.port = 8888
    args = ['--port=8080']

# Generated at 2022-06-18 10:37:10.620112
# Unit test for method set of class _Option
def test__Option_set():
    option = _Option(name='name', default=None, type=None, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    option.set(value=None)
    assert option._value == None
    option.set(value='')
    assert option._value == ''
    option.set(value=0)
    assert option._value == 0
    option.set(value=1)
    assert option._value == 1
    option.set(value=True)
    assert option._value == True
    option.set(value=False)
    assert option._value == False
    option.set(value=[])
    assert option._value == []
    option.set(value=[None])
    assert option._value == [None]

# Generated at 2022-06-18 10:37:19.009980
# Unit test for method value of class _Option
def test__Option_value():
    option = _Option('name', default=None, type=int, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    assert option.value() == None
    option = _Option('name', default=None, type=int, help=None, metavar=None, multiple=True, file_name=None, group_name=None, callback=None)
    assert option.value() == []
    option = _Option('name', default=None, type=int, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    option.parse('1')
    assert option.value() == 1

# Generated at 2022-06-18 10:37:22.091426
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    from tornado.options import OptionParser
    import unittest.mock
    options = OptionParser()
    options.define("name", default="foo")
    mockable = _Mockable(options)
    with unittest.mock.patch.object(mockable, "name", "bar"):
        assert options.name == "bar"
    assert options.name == "foo"

# Generated at 2022-06-18 10:37:26.598530
# Unit test for method set of class _Option
def test__Option_set():
    option = _Option("name", default=None, type=str, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    option.set("value")
    assert option._value == "value"


# Generated at 2022-06-18 10:37:34.211248
# Unit test for method parse_command_line of class OptionParser

# Generated at 2022-06-18 10:37:43.887917
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    parser = OptionParser()
    parser.define('name', default='', help='name of the user')
    parser.define('age', default=0, help='age of the user')
    parser.define('gender', default='', help='gender of the user')
    parser.define('height', default=0, help='height of the user')
    parser.define('weight', default=0, help='weight of the user')
    parser.define('eye_color', default='', help='eye color of the user')
    parser.define('hair_color', default='', help='hair color of the user')
    parser.define('hair_length', default='', help='hair length of the user')
    parser.define('hair_style', default='', help='hair style of the user')

# Generated at 2022-06-18 10:37:54.049706
# Unit test for method __iter__ of class OptionParser

# Generated at 2022-06-18 10:38:02.275083
# Unit test for method parse of class _Option

# Generated at 2022-06-18 10:38:26.850623
# Unit test for method set of class _Option
def test__Option_set():
    import unittest
    import mock
    from tornado.options import _Option
    from tornado.options import Error
    from tornado.options import OptionParser
    from tornado.options import options
    from tornado.options import parse_command_line
    from tornado.options import parse_config_file
    from tornado.options import print_help
    from tornado.options import run_parse_callbacks
    from tornado.options import add_parse_callback
    from tornado.options import mockable
    from tornado.options import _Mockable
    from tornado.options import UNSET
    from tornado.options import _parse_datetime
    from tornado.options import _parse_timedelta
    from tornado.options import _parse_bool
    from tornado.options import _parse_string
    from tornado.options import _DATETIME_FORMATS

# Generated at 2022-06-18 10:38:35.382945
# Unit test for method __setattr__ of class OptionParser

# Generated at 2022-06-18 10:38:48.470980
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    # Test that the __iter__ method of the OptionParser class returns an iterator
    # over the options in the parser.
    # Create an OptionParser object
    parser = OptionParser()
    # Define a couple of options
    parser.define("name", type=str, help="name of the user")
    parser.define("age", type=int, help="age of the user")
    # Create a list of the options in the parser
    options = list(parser)
    # Check that the list contains the two options
    assert len(options) == 2
    assert options[0].name == "name"
    assert options[0].type == str
    assert options[0].help == "name of the user"
    assert options[1].name == "age"
    assert options[1].type == int

# Generated at 2022-06-18 10:38:59.373794
# Unit test for method parse of class _Option

# Generated at 2022-06-18 10:39:10.443466
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    from tornado.options import OptionParser
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import unittest
    import mock
    import sys
    import os
    import time
    import logging
    import functools
    import inspect
    import types
    import typing
    import re
    import datetime
    import io
    import random
    import string
    import warnings
    import contextlib
    import threading
    import concurrent.futures
    import subprocess
    import collections
    import copy
    import json
    import decimal
    import base64
    import binascii
    import zlib
    import hashlib
    import hmac
    import socket
    import s

# Generated at 2022-06-18 10:39:19.178266
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    # Test that __setattr__ works
    options = OptionParser()
    options.define("name", default="foo")
    mockable = _Mockable(options)
    assert options.name == "foo"
    mockable.name = "bar"
    assert options.name == "bar"
    del mockable.name
    assert options.name == "foo"
    # Test that __setattr__ fails when called twice
    mockable.name = "bar"
    with pytest.raises(AssertionError):
        mockable.name = "baz"


# Generated at 2022-06-18 10:39:31.168997
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    from tornado.options import OptionParser
    from tornado.options import _Option
    from tornado.options import Error
    from tornado.options import _normalize_name
    from tornado.options import _Mockable
    import sys
    import os
    import textwrap
    import unittest.mock
    import unittest.mock as mock
    import unittest
    import unittest as ut
    import unittest.mock as mock
    import unittest.mock as mock
    import unittest.mock as mock
    import unittest.mock as mock
    import unittest.mock as mock
    import unittest.mock as mock
    import unittest.mock as mock
    import unittest.mock as mock
    import unittest.mock as mock
    import unitt

# Generated at 2022-06-18 10:39:43.935679
# Unit test for method set of class _Option
def test__Option_set():
    import datetime
    from tornado.options import _Option
    option = _Option(name="name", type=datetime.datetime, default=None, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    option.set(datetime.datetime(2019, 1, 1, 0, 0))
    assert option.value() == datetime.datetime(2019, 1, 1, 0, 0)
    option.set(None)
    assert option.value() == None
    option.set(datetime.datetime(2019, 1, 1, 0, 0))
    assert option.value() == datetime.datetime(2019, 1, 1, 0, 0)
    option.set(None)
    assert option.value() == None

# Generated at 2022-06-18 10:39:55.476010
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    import unittest
    import mock
    from tornado.options import OptionParser, _Mockable
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import sys
    import os
    import time
    import datetime
    import functools
    import inspect
    import logging
    import re
    import signal
    import socket
    import subprocess
    import threading
    import traceback
    import types
    import warnings
    import weakref
    import zlib
    import _thread
    import _dummy_thread
    import _markupbase
    import _threading_local
    import _weakrefset
    import abc
    import aifc
    import antigravity
    import anydbm
    import argparse

# Generated at 2022-06-18 10:40:06.304428
# Unit test for method parse of class _Option
def test__Option_parse():
    # Test for method parse(self, value)
    # of class _Option
    # test for _parse_datetime
    option = _Option("name", type=datetime.datetime)
    option.parse("Tue Feb  3 15:26:13 2015")
    option.parse("2015-02-03 15:26:13")
    option.parse("2015-02-03 15:26")
    option.parse("2015-02-03T15:26")
    option.parse("20150203 15:26:13")
    option.parse("20150203 15:26")
    option.parse("2015-02-03")
    option.parse("20150203")
    option.parse("15:26:13")
    option.parse("15:26")
    # test for _parse_timedelta
    option = _Option

# Generated at 2022-06-18 10:40:24.757125
# Unit test for method value of class _Option
def test__Option_value():
    option = _Option("name", default=None, type=str, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    assert option.value() == None
    option = _Option("name", default=None, type=str, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    option.parse("value")
    assert option.value() == "value"
    option = _Option("name", default=None, type=str, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    option.set("value")
    assert option.value() == "value"

# Generated at 2022-06-18 10:40:34.177040
# Unit test for method set of class _Option
def test__Option_set():
    import unittest
    from tornado.options import _Option
    from tornado.options import Error
    import datetime
    import numbers
    import sys
    import os
    import textwrap
    import sys
    import os
    import unittest
    import textwrap
    import sys
    import os
    import unittest
    import textwrap
    import sys
    import os
    import unittest
    import textwrap
    import sys
    import os
    import unittest
    import textwrap
    import sys
    import os
    import unittest
    import textwrap
    import sys
    import os
    import unittest
    import textwrap
    import sys
    import os
    import unittest
    import textwrap
    import sys
    import os
    import unittest
    import textwrap

# Generated at 2022-06-18 10:40:42.194204
# Unit test for method parse of class _Option
def test__Option_parse():
    from tornado.options import _Option
    option = _Option("name", type=str)
    assert option.parse("value") == "value"
    option = _Option("name", type=int)
    assert option.parse("1") == 1
    option = _Option("name", type=float)
    assert option.parse("1.1") == 1.1
    option = _Option("name", type=bool)
    assert option.parse("true") == True
    assert option.parse("false") == False
    option = _Option("name", type=datetime.datetime)
    assert option.parse("2019-01-01 00:00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0)
    option = _Option("name", type=datetime.timedelta)
    assert option.parse

# Generated at 2022-06-18 10:40:52.642634
# Unit test for method __setattr__ of class OptionParser

# Generated at 2022-06-18 10:41:00.467290
# Unit test for method __setattr__ of class OptionParser

# Generated at 2022-06-18 10:41:12.507851
# Unit test for method value of class _Option
def test__Option_value():
    option = _Option("name", default=None, type=str, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    assert option.value() == None
    option = _Option("name", default=None, type=str, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    option.parse("")
    assert option.value() == ""
    option = _Option("name", default=None, type=str, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    option.parse("1")
    assert option.value() == "1"

# Generated at 2022-06-18 10:41:23.254790
# Unit test for method parse of class _Option
def test__Option_parse():
    # Test for method parse(self, value)
    # of class _Option
    # test for _parse_datetime
    option = _Option("name", type=datetime.datetime)
    option.parse("Thu Jan 01 00:00:00 1970")
    option.parse("1970-01-01 00:00:00")
    option.parse("1970-01-01 00:00")
    option.parse("1970-01-01T00:00")
    option.parse("19700101 00:00:00")
    option.parse("19700101 00:00")
    option.parse("1970-01-01")
    option.parse("19700101")
    option.parse("00:00:00")
    option.parse("00:00")
    # test for _parse_timedelta

# Generated at 2022-06-18 10:41:35.110687
# Unit test for method __setattr__ of class OptionParser

# Generated at 2022-06-18 10:41:47.369234
# Unit test for method value of class _Option
def test__Option_value():
    option = _Option('name', default=None, type=str, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    assert option.value() == None
    option = _Option('name', default=None, type=str, help=None, metavar=None, multiple=True, file_name=None, group_name=None, callback=None)
    assert option.value() == []
    option = _Option('name', default=1, type=int, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    assert option.value() == 1

# Generated at 2022-06-18 10:41:53.004570
# Unit test for method __setattr__ of class _Mockable

# Generated at 2022-06-18 10:42:09.361909
# Unit test for method __setattr__ of class OptionParser

# Generated at 2022-06-18 10:42:19.195382
# Unit test for method parse of class _Option

# Generated at 2022-06-18 10:42:28.064214
# Unit test for method parse_config_file of class OptionParser

# Generated at 2022-06-18 10:42:38.325806
# Unit test for method parse of class _Option
def test__Option_parse():
    option = _Option(name="name", default=None, type=datetime.datetime, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    option.parse("2019-12-31 12:59:59")
    assert option.value() == datetime.datetime(2019, 12, 31, 12, 59, 59)
    option.parse("2019-12-31 12:59")
    assert option.value() == datetime.datetime(2019, 12, 31, 12, 59)
    option.parse("2019-12-31T12:59")
    assert option.value() == datetime.datetime(2019, 12, 31, 12, 59)
    option.parse("20191231 12:59:59")
    assert option.value() == datetime

# Generated at 2022-06-18 10:42:48.156947
# Unit test for method parse_config_file of class OptionParser

# Generated at 2022-06-18 10:42:53.253011
# Unit test for method value of class _Option
def test__Option_value():
    option = _Option('name', default=None, type=str, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    option._value = 'value'
    assert option.value() == 'value'
    option._value = _Option.UNSET
    assert option.value() == None


# Generated at 2022-06-18 10:43:02.503211
# Unit test for method __setattr__ of class OptionParser

# Generated at 2022-06-18 10:43:13.182227
# Unit test for method parse of class _Option
def test__Option_parse():
    import unittest
    import datetime
    from tornado.options import _Option
    from tornado.options import Error
    from tornado.options import _unicode
    from tornado.options import _parse_command_line
    from tornado.options import _parse_config_file
    from tornado.options import _parse_command_line_and_config_file
    from tornado.options import _parse_command_line_and_config_file
    from tornado.options import _parse_command_line_and_config_file
    from tornado.options import _parse_command_line_and_config_file
    from tornado.options import _parse_command_line_and_config_file
    from tornado.options import _parse_command_line_and_config_file
    from tornado.options import _parse_command_line_and_config_file

# Generated at 2022-06-18 10:43:22.167690
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    options = OptionParser()
    options.define("name", default="foo")
    mockable = _Mockable(options)
    assert options.name == "foo"
    mockable.name = "bar"
    assert options.name == "bar"
    del mockable.name
    assert options.name == "foo"
    # Test that we can't reuse the mockable object
    mockable.name = "bar"
    assert options.name == "bar"
    with pytest.raises(AssertionError):
        mockable.name = "baz"
    assert options.name == "bar"



# Generated at 2022-06-18 10:43:34.388983
# Unit test for method parse of class _Option
def test__Option_parse():
    # test for _parse_datetime
    option = _Option("name", default=None, type=datetime.datetime, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    assert option._parse_datetime("Sat May  9 23:46:26 2015") == datetime.datetime(2015, 5, 9, 23, 46, 26)
    assert option._parse_datetime("2015-05-09 23:46:26") == datetime.datetime(2015, 5, 9, 23, 46, 26)
    assert option._parse_datetime("2015-05-09 23:46") == datetime.datetime(2015, 5, 9, 23, 46)
    assert option._parse_datetime("2015-05-09T23:46") == datetime

# Generated at 2022-06-18 10:43:50.348142
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    import os
    import tempfile
    import unittest
    from tornado.options import define, options, Error
    define("name", type=str, default="")
    define("value", type=int, default=0)
    define("multiple", type=int, multiple=True)
    define("float", type=float, default=0.0)
    define("datetime", type=datetime.datetime, default=datetime.datetime(2000, 1, 1))
    define("timedelta", type=datetime.timedelta, default=datetime.timedelta(0))
    define("bool", type=bool, default=False)
    define("list", type=str, multiple=True)
    define("dict", type=str, multiple=True)

# Generated at 2022-06-18 10:43:55.588960
# Unit test for method value of class _Option
def test__Option_value():
    option = _Option(name='name', default=None, type=int, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    option._value = 1
    assert option.value() == 1
    option._value = _Option.UNSET
    assert option.value() == None


# Generated at 2022-06-18 10:44:05.544708
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    # Create a new OptionParser object
    parser = OptionParser()
    # Define a new option
    parser.define("name", default="", type=str, help="name of the user", metavar="NAME")
    # Define a new option
    parser.define("age", default=0, type=int, help="age of the user", metavar="AGE")
    # Define a new option
    parser.define("gender", default="", type=str, help="gender of the user", metavar="GENDER")
    # Define a new option
    parser.define("height", default=0, type=float, help="height of the user", metavar="HEIGHT")
    # Define a new option

# Generated at 2022-06-18 10:44:16.679447
# Unit test for method parse of class _Option
def test__Option_parse():
    # Test for _parse_datetime
    option = _Option("name", type=datetime.datetime)
    assert option.parse("Mon Sep 28 22:23:24 2015") == datetime.datetime(2015, 9, 28, 22, 23, 24)
    assert option.parse("2015-09-28 22:23:24") == datetime.datetime(2015, 9, 28, 22, 23, 24)
    assert option.parse("2015-09-28 22:23") == datetime.datetime(2015, 9, 28, 22, 23)
    assert option.parse("2015-09-28T22:23") == datetime.datetime(2015, 9, 28, 22, 23)

# Generated at 2022-06-18 10:44:25.132709
# Unit test for method parse_command_line of class OptionParser

# Generated at 2022-06-18 10:44:35.536620
# Unit test for method set of class _Option
def test__Option_set():
    # Test that _Option.set raises an error if the value is not of the correct type
    option = _Option("name", type=str)
    option.set("value")
    with pytest.raises(Error):
        option.set(1)
    option = _Option("name", type=int)
    option.set(1)
    with pytest.raises(Error):
        option.set("value")
    option = _Option("name", type=bool)
    option.set(True)
    with pytest.raises(Error):
        option.set(1)
    option = _Option("name", type=datetime.datetime)
    option.set(datetime.datetime.now())
    with pytest.raises(Error):
        option.set(1)

# Generated at 2022-06-18 10:44:39.578575
# Unit test for method set of class _Option
def test__Option_set():
    option = _Option('name', default=None, type=None, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    option.set(value=None)
    assert option.value() == None


# Generated at 2022-06-18 10:44:42.492089
# Unit test for method __setattr__ of class OptionParser
def test_OptionParser___setattr__():
    from tornado.options import options
    options.define("name", default="", type=str)
    options.name = "test"
    assert options.name == "test"


# Generated at 2022-06-18 10:44:50.825373
# Unit test for method set of class _Option
def test__Option_set():
    import random
    import string
    import datetime
    import time
    import unittest
    import unittest.mock
    import tornado.options
    import tornado.testing
    import tornado.test.util
    import tornado.util
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.locks
    import tornado.queues
    import tornado.stack_context
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.gen
    import tornado.httpclient
    import tornado.httputil
    import tornado.httptest
    import tornado.escape
    import tornado.locale
    import tornado.log
    import tornado.autoreload

# Generated at 2022-06-18 10:44:59.777542
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    import unittest
    from tornado.options import OptionParser, _Mockable
    from unittest.mock import patch

    class Test_Mockable(unittest.TestCase):
        def test_setattr(self):
            options = OptionParser()
            options.define("name", default="Bob", help="name help")
            options.define("age", default=20, help="age help")
            mockable = _Mockable(options)
            with patch.object(mockable, "name", "Alice"):
                self.assertEqual(options.name, "Alice")
            self.assertEqual(options.name, "Bob")
            with patch.object(mockable, "age", 30):
                self.assertEqual(options.age, 30)

# Generated at 2022-06-18 10:46:02.566542
# Unit test for method parse of class _Option
def test__Option_parse():
    # Test for method parse(self, value)
    # of class _Option
    # test for _parse_datetime
    option = _Option("name", type=datetime.datetime)
    option.parse("Thu Jan 01 00:00:00 1970")
    option.parse("1970-01-01 00:00:00")
    option.parse("1970-01-01 00:00")
    option.parse("1970-01-01T00:00")
    option.parse("19700101 00:00:00")
    option.parse("19700101 00:00")
    option.parse("1970-01-01")
    option.parse("19700101")
    option.parse("00:00:00")
    option.parse("00:00")
    # test for _parse_timedelta

# Generated at 2022-06-18 10:46:11.125525
# Unit test for method parse_config_file of class OptionParser