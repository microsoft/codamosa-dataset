

# Generated at 2022-06-18 10:39:13.354449
# Unit test for method __iter__ of class OptionParser

# Generated at 2022-06-18 10:39:26.267188
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    from tornado.options import OptionParser
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.web import Application, RequestHandler
    import asyncio
    import unittest

    class TestHandler(RequestHandler):
        def get(self):
            self.write("Hello, world")

    class TestCase(AsyncTestCase):
        def setUp(self):
            super(TestCase, self).setUp()
            self.options = OptionParser()
            self.options.define("port", default=8888, type=int)
            self.options.define("debug", default=False, type=bool)
            self.options.define("db_host", default="localhost:3306", type=str)

# Generated at 2022-06-18 10:39:37.978561
# Unit test for method parse of class _Option
def test__Option_parse():
    # Test case 1
    option = _Option(name='name', default=None, type=None, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    value = 'value'
    try:
        option.parse(value)
    except Exception as e:
        assert type(e) == ValueError
        assert str(e) == 'type must not be None'
    else:
        assert False, 'ExpectedException not raised'
    # Test case 2
    option = _Option(name='name', default=None, type=str, help=None, metavar=None, multiple=False, file_name=None, group_name=None, callback=None)
    value = 'value'
    assert option.parse(value) == 'value'
    #

# Generated at 2022-06-18 10:39:50.632670
# Unit test for method set of class _Option

# Generated at 2022-06-18 10:40:01.584954
# Unit test for method parse of class _Option

# Generated at 2022-06-18 10:40:12.321859
# Unit test for method set of class _Option
def test__Option_set():
    option = _Option('name', type=int)
    option.set(1)
    assert option.value() == 1
    option.set([1, 2, 3])
    assert option.value() == [1, 2, 3]
    option.set([1, 2, 3, 'a'])
    assert option.value() == [1, 2, 3, 'a']
    option.set([1, 2, 3, 'a', None])
    assert option.value() == [1, 2, 3, 'a', None]
    option.set(None)
    assert option.value() == None
    option.set(['a', 'b', 'c'])
    assert option.value() == ['a', 'b', 'c']
    option.set(['a', 'b', 'c', None])

# Generated at 2022-06-18 10:40:22.937491
# Unit test for method parse_config_file of class OptionParser

# Generated at 2022-06-18 10:40:32.367845
# Unit test for method parse_command_line of class OptionParser
def test_OptionParser_parse_command_line():
    import sys
    from tornado.options import define, options, OptionParser
    define("port", default=8888, help="run on the given port", type=int)
    define("debug", default=False, help="run in debug mode")
    define("log_file_prefix", default="", help="path prefix for log files")
    define("log_to_stderr", default=False, help="log to stderr")
    define("logging", default="info", help="logging level")
    define("config", default="", help="path to config file", type=str)
    define("config_dict", default={}, help="dict to config file", type=dict)
    define("config_list", default=[], help="list to config file", type=list)

# Generated at 2022-06-18 10:40:39.757934
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    # Test for method __iter__ (returns an iterator over the options)
    # of class OptionParser
    #
    # Create an OptionParser instance
    parser = OptionParser()
    # Define some options
    parser.define("option1", default=1, help="option1 help")
    parser.define("option2", default=2, help="option2 help")
    parser.define("option3", default=3, help="option3 help")
    # Iterate over the options
    for option in parser:
        assert option.name in ("option1", "option2", "option3")
        assert option.default in (1, 2, 3)
        assert option.help in ("option1 help", "option2 help", "option3 help")

# Generated at 2022-06-18 10:40:49.392042
# Unit test for method parse of class _Option
def test__Option_parse():
    import unittest
    import datetime
    import time
    from tornado.options import _Option
    from tornado.options import Error
    from tornado.options import _parse_config_file
    from tornado.options import _unicode
    from tornado.options import _normalize_name
    from tornado.options import _parse_command_line
    from tornado.options import _parse_command_line_and_config_file
    from tornado.options import _parse_command_line_and_config_file_impl
    from tornado.options import _parse_command_line_impl
    from tornado.options import _parse_config_file_impl
    from tornado.options import _parse_env_file
    from tornado.options import _parse_env_file_impl
    from tornado.options import _parse_env_var
    from tornado.options import _parse

# Generated at 2022-06-18 10:41:49.763874
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    options = OptionParser()
    options.define("name", type=str, help="name help")
    options.define("value", type=int, help="value help")
    options.name = "foo"
    options.value = 42
    mockable = _Mockable(options)
    assert mockable.name == "foo"
    assert mockable.value == 42
    mockable.name = "bar"
    mockable.value = 43
    assert mockable.name == "bar"
    assert mockable.value == 43
    del mockable.name
    del mockable.value
    assert mockable.name == "foo"
    assert mockable.value == 42



# Generated at 2022-06-18 10:41:58.612428
# Unit test for method __setattr__ of class _Mockable
def test__Mockable___setattr__():
    options = OptionParser()
    options.define("name", default="Bob", help="name help")
    options.define("age", default=20, help="age help")
    mockable = _Mockable(options)
    assert mockable.name == "Bob"
    assert mockable.age == 20
    mockable.name = "Alice"
    mockable.age = 30
    assert mockable.name == "Alice"
    assert mockable.age == 30
    assert options.name == "Alice"
    assert options.age == 30
    mockable.name = "Bob"
    mockable.age = 20
    assert mockable.name == "Bob"
    assert mockable.age == 20
    assert options.name == "Bob"
    assert options.age == 20
    mockable.name = "Alice"

# Generated at 2022-06-18 10:42:08.430475
# Unit test for method set of class _Option
def test__Option_set():
    option = _Option("name", type=str, multiple=False)
    option.set("value")
    assert option.value() == "value"
    option.set("value2")
    assert option.value() == "value2"
    option.set(None)
    assert option.value() == None
    option.set("value3")
    assert option.value() == "value3"
    option.set(None)
    assert option.value() == None
    option.set("value4")
    assert option.value() == "value4"
    option.set(None)
    assert option.value() == None
    option.set("value5")
    assert option.value() == "value5"
    option.set(None)
    assert option.value() == None
    option.set("value6")

# Generated at 2022-06-18 10:42:18.288922
# Unit test for method __iter__ of class OptionParser
def test_OptionParser___iter__():
    import tornado.options
    import sys
    import os
    import textwrap
    import unittest

    from tornado.options import define, options, Error, _Option, _Mockable

    class OptionParserTest(unittest.TestCase):
        def test_iter(self):
            define("name", default="Bob", help="help for name")
            define("age", default=25, help="help for age")
            define("height", default=175.5, help="help for height")
            define("admin", default=False, help="help for admin")
            define("uuid", default=None, help="help for uuid")
            define("aliases", default=[], help="help for aliases", multiple=True)
            define("scores", default=[], help="help for scores", multiple=True)

# Generated at 2022-06-18 10:42:24.536169
# Unit test for method set of class _Option
def test__Option_set():
    import unittest
    from tornado.options import _Option
    from tornado.options import Error
    from tornado.options import OptionParser
    from tornado.options import parse_command_line
    from tornado.options import print_help
    from tornado.options import run_parse_callbacks
    from tornado.options import add_parse_callback
    from tornado.options import _Mockable
    from tornado.options import define
    from tornado.options import options
    from tornado.options import parse_config_file
    from tornado.options import parse_command_line
    from tornado.options import parse_command_line
    from tornado.options import parse_command_line
    from tornado.options import parse_command_line
    from tornado.options import parse_command_line
    from tornado.options import parse_command_line
    from tornado.options import parse_command

# Generated at 2022-06-18 10:42:34.104794
# Unit test for method parse of class _Option
def test__Option_parse():
    option = _Option("name", type=int, multiple=False)
    assert option.parse("1") == 1
    assert option.parse("1") == 1
    assert option.parse("1") == 1
    assert option.parse("1") == 1
    assert option.parse("1") == 1
    assert option.parse("1") == 1
    assert option.parse("1") == 1
    assert option.parse("1") == 1
    assert option.parse("1") == 1
    assert option.parse("1") == 1
    assert option.parse("1") == 1
    assert option.parse("1") == 1
    assert option.parse("1") == 1
    assert option.parse("1") == 1
    assert option.parse("1") == 1
    assert option.parse("1") == 1

# Generated at 2022-06-18 10:42:37.951691
# Unit test for method set of class _Option
def test__Option_set():
    # Set up
    option = _Option("name", type=int, multiple=True)
    # Exercise
    option.set([1, 2, 3])
    # Verify
    assert option.value() == [1, 2, 3]
    # Clean up - none necessary



# Generated at 2022-06-18 10:42:46.931273
# Unit test for method parse_config_file of class OptionParser
def test_OptionParser_parse_config_file():
    import os
    import tempfile
    import unittest

    from tornado.options import define, options, OptionParser

    define("foo", type=int)
    define("bar", type=str)
    define("baz", type=bool)
    define("qux", type=list)
    define("quux", type=list)
    define("corge", type=list)
    define("grault", type=list)
    define("garply", type=list)
    define("waldo", type=list)
    define("fred", type=list)
    define("plugh", type=list)
    define("xyzzy", type=list)
    define("thud", type=list)

    class OptionParserTest(unittest.TestCase):
        def test_parse_config_file(self):
            config_file

# Generated at 2022-06-18 10:42:57.360092
# Unit test for method set of class _Option
def test__Option_set():
    import unittest
    import tornado.options
    import tornado.testing
    import tornado.test.util
    import tornado.util
    import datetime
    import sys
    import time
    import types
    import unittest
    import tornado.options
    import tornado.testing
    import tornado.test.util
    import tornado.util
    import datetime
    import sys
    import time
    import types
    import unittest
    import tornado.options
    import tornado.testing
    import tornado.test.util
    import tornado.util
    import datetime
    import sys
    import time
    import types
    import unittest
    import tornado.options
    import tornado.testing
    import tornado.test.util
    import tornado.util
    import datetime
    import sys
    import time
    import types
    import un

# Generated at 2022-06-18 10:43:05.977130
# Unit test for method define of class OptionParser
def test_OptionParser_define():
    # Test for method define(self, name, default, type, help, metavar, multiple, group, callback)
    # Tests for multiple=True
    options = OptionParser()
    options.define("name", multiple=True)
    options.define("name", multiple=True, type=int)
    options.define("name", multiple=True, type=float)
    options.define("name", multiple=True, type=str)
    options.define("name", multiple=True, type=bool)
    options.define("name", multiple=True, type=datetime.datetime)
    options.define("name", multiple=True, type=datetime.timedelta)
    options.define("name", multiple=True, type=None)
    options.define("name", multiple=True, type=None, default=None)