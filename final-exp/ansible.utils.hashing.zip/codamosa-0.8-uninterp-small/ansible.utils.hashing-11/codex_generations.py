

# Generated at 2022-06-25 13:00:50.681906
# Unit test for function checksum
def test_checksum():
    # Test with a file that exists
    filename = os.path.join(os.path.dirname(__file__), 'hashlib_test.py')
    checksum_value = checksum(filename)
    assert checksum_value == 'efd5a1c8b75f9b2a7d1fbb07ac665439db443f0f'

    # Test with a file that does not exist
    fake_filename = os.path.join(os.path.dirname(__file__), 'fake_hashlib_test.py')
    checksum_value = checksum(fake_filename)
    assert checksum_value is None

    # Test with a directory
    checksum_value = checksum(os.path.dirname(__file__))
    assert checksum_value is None


# Generated at 2022-06-25 13:00:52.790707
# Unit test for function md5s
def test_md5s():
    assert md5s(b"test_string") == "f9320baf0249169e73850cd6156ded01"


# Generated at 2022-06-25 13:00:56.043697
# Unit test for function md5s
def test_md5s():
    assert md5s(b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d') == 'b96a9a2a26f9da1b2893e064a8f84626'


# Generated at 2022-06-25 13:01:01.563587
# Unit test for function md5s
def test_md5s():
    data_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    var_1 = md5s(data_0)
    assert var_1 == '3a3af87a9c55f8d7f4c4a1a7d5b5eb49'



# Generated at 2022-06-25 13:01:04.814765
# Unit test for function md5s
def test_md5s():
    bytes_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    var_0 = md5s(bytes_0)
    var_1 = secure_hash_s(bytes_0, _md5)
    print(var_0)
    print(var_1)
    assert var_0 == var_1



# Generated at 2022-06-25 13:01:13.328667
# Unit test for function checksum
def test_checksum():
    # Test the secure_hash and secure_hash_s functions

    # Test for data
    bytes_1 = b'\x0c\x88@\xcd\x99\xa6\xec\xc2\x8e\x94\xa6\x1ce\xae\xbf\xa6\x85\xc5\xee\xe8\x9f\x0b'
    hexdigest_1 = '3376254d42b78fba5ce3b8555a3ddc7d5d5f5c7f'
    var_1 = checksum_s(bytes_1)
    assert hexdigest_1 == var_1
    # Test for file
    var_2 = checksum('test.txt')

# Generated at 2022-06-25 13:01:21.301800
# Unit test for function md5
def test_md5():
    test_bytes = b'The quick brown fox jumps over the lazy dog.'
    expected_bytes = b'9e107d9d372bb6826bd81d3542a419d6'
    test_bytes_unicode = 'The quick brown fox jumps over the lazy dog.'
    expected_bytes_unicode = '9e107d9d372bb6826bd81d3542a419d6'
    assert md5s(test_bytes) == expected_bytes
    assert md5s(test_bytes_unicode) == expected_bytes_unicode
    assert md5s(test_bytes_unicode, hash_func=_md5) == expected_bytes_unicode


# Generated at 2022-06-25 13:01:24.929204
# Unit test for function md5s
def test_md5s():
    bytes_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    var_0 = md5s(bytes_0)
    assert var_0 == '10c853b36e543d38492c5995c8b1cd43'


# Generated at 2022-06-25 13:01:33.486210
# Unit test for function checksum
def test_checksum():
    bytes_0 = b'\x13\x87\xc6\x83\xb8p\xe9\xac\xe7\xce\x04\x8d\x95\x02\xdc\x00\x8c'
    bytes_1 = b'{\xfb\xbf\x05\xcdx\x12\x8e\x9c\xd4\x18\x1d\xb8\x15\xae\x87\x8e\xaf\x9bH\x87\x8d\xae\x18\xea'

# Generated at 2022-06-25 13:01:34.485841
# Unit test for function md5
def test_md5():
    assert callable(md5)
    try:
        md5("Test")
    except ValueError as e:
        assert e


# Generated at 2022-06-25 13:01:42.214992
# Unit test for function md5s
def test_md5s():
    bytes_0 = to_bytes('5f4dcc3b5aa765d61d8327deb882cf99', errors='surrogate_or_strict')
    assert md5s(to_bytes('password', errors='surrogate_or_strict')) == bytes_0



# Generated at 2022-06-25 13:01:43.208427
# Unit test for function md5
def test_md5():
    print(md5(__file__))



# Generated at 2022-06-25 13:01:44.578712
# Unit test for function checksum
def test_checksum():
    filename = 'path/to/file'
    hash_func = 'sha1'

    result = checksum(filename, hash_func)
    assert isinstance(result, str)
    assert result == 'sha1'


# Generated at 2022-06-25 13:01:48.579070
# Unit test for function md5s
def test_md5s():
    bytes_0 = ''
    var_0 = md5s(bytes_0)
    assert var_0 == 'd41d8cd98f00b204e9800998ecf8427e'

    bytes_0 = 'abc'
    var_0 = md5s(bytes_0)
    assert var_0 == '900150983cd24fb0d6963f7d28e17f72'

    bytes_0 = '1234'
    var_0 = md5s(bytes_0)
    assert var_0 == '81dc9bdb52d04dc20036dbd8313ed055'

    bytes_0 = '12345'
    var_0 = md5s(bytes_0)

# Generated at 2022-06-25 13:01:55.086775
# Unit test for function md5
def test_md5():
    answer = 'dd5049a05b34d69b75eee82c061762bb'
    result = md5('../test/test_module.py')
    assert result == answer

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-25 13:01:57.837502
# Unit test for function checksum
def test_checksum():
    assert checksum(__file__) == secure_hash(__file__)
    assert checksum_s('123') == secure_hash_s('123')


# Generated at 2022-06-25 13:02:01.053374
# Unit test for function checksum
def test_checksum():
    bytes_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    var_0 = checksum_s(bytes_0)

# Generated at 2022-06-25 13:02:05.830642
# Unit test for function checksum
def test_checksum():
    bytes_0 = b'V\xb2\xacu\xaa\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    checksum_s(bytes_0)


# Generated at 2022-06-25 13:02:13.609475
# Unit test for function md5
def test_md5():
    bytes_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    var_0 = md5s(bytes_0)
    assert var_0 == 'ceef967c7957d4a20c461287488718d7'

    str_0 = 'ceef967c7957d4a20c461287488718d7'
    var_1 = md5s(str_0)
    assert var_1 == '52d0f0ac3e6bbb7aae2a814b7e95ddf6'


# Generated at 2022-06-25 13:02:16.698316
# Unit test for function checksum
def test_checksum():
    filename = "test/test.txt"
    checksum_str = "098f6bcd4621d373cade4e832627b4f6"
    assert checksum(filename) == checksum_str


# Generated at 2022-06-25 13:02:21.143039
# Unit test for function md5
def test_md5():
    print('Function md5 not tested')


# Generated at 2022-06-25 13:02:23.672150
# Unit test for function checksum
def test_checksum():
    pass

    # Return a secure hash hex digest of data.
    #assert checksum_s('data') == 'secure_hash_hex_digest'


# Generated at 2022-06-25 13:02:28.412448
# Unit test for function checksum
def test_checksum():
    data = "Hello World"
    result = checksum_s(data)
    assert result == 'b10a8db164e0754105b7a99be72e3fe5'
    result = checksum("./test/file/name")



# Generated at 2022-06-25 13:02:30.375770
# Unit test for function md5
def test_md5():
    try:
        md5(filename)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 13:02:36.137081
# Unit test for function checksum
def test_checksum():
    data = os.urandom(10)
    hash = checksum_s(data)
    assert hash == sha1(data).hexdigest()

    filename = os.path.join(os.path.abspath(os.path.dirname(__file__)), '__init__.py')
    with open(filename, 'rb') as f:
        data = f.read()
    hash = checksum(filename)
    assert hash == sha1(data).hexdigest()

# Generated at 2022-06-25 13:02:43.536814
# Unit test for function md5s
def test_md5s():
    # Dummy bytes for test data
    bytes_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'

    # Expected value
    exp_value = 'd53523a2b94f9045d766a8a8b97a3ec3'
    value = md5s(bytes_0)
    assert value == exp_value


# Generated at 2022-06-25 13:02:52.212128
# Unit test for function checksum
def test_checksum():
    assert( checksum('/bin/ls') == "41b8334f39d9f2b445205483a148f835d33f329d" )
    assert( type(checksum('/bin/ls')) == str )
    assert( checksum('/bin/ls') == checksum_s(b'/bin/ls') )
    assert( type(checksum_s(b'/bin/ls')) == str )
    assert( checksum('/bin/ls') != checksum('/etc/passwd') )
    assert( checksum('/bin/ls') != secure_hash('/bin/ls', sha1) )
    assert( not checksum('/bin/ls/') )
    assert( not checksum('/bin/ls_') )

# Generated at 2022-06-25 13:02:54.859689
# Unit test for function md5
def test_md5():
    result = md5s('test_text')
    assert result == '1ebea2e2a8f8e0745a33d766f3ee3b91'


# Generated at 2022-06-25 13:02:58.136720
# Unit test for function md5
def test_md5():
    assert md5('filename') == 'd0dacf05e5a2d5289f9b9d8bc15af10c', 'md5 did not return d0dacf05e5a2d5289f9b9d8bc15af10c'


# Generated at 2022-06-25 13:03:01.502297
# Unit test for function checksum
def test_checksum():
    filename = 'hiera.yaml'
    # function checksum return the sha1 value of given file.
    assert checksum(filename) == 'c0059c1ce2e7e4d5760f939c9ebd8efad90d3747'


# Generated at 2022-06-25 13:03:10.357617
# Unit test for function md5s
def test_md5s():
    bytes_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    var_0 = md5s(bytes_0)
    assert var_0 == 'd6a8a6e77334ac039c3a3a10f777af4a'


# Generated at 2022-06-25 13:03:13.447417
# Unit test for function md5
def test_md5():
    assert md5('DUMMY_FILENAME') is None
    assert md5('/etc/passwd') is not None
    assert md5('/no/such/file') is None
    assert md5('/bin') is None


# Generated at 2022-06-25 13:03:15.662614
# Unit test for function md5
def test_md5():
    assert 'e67512cdff11b6d47f634cd056a2f566' == md5('/bin/sh')


# Generated at 2022-06-25 13:03:22.905944
# Unit test for function md5s
def test_md5s():
    r = md5s(b'This is test string.')
    assert r == 'a25d7d0b705c843f19e11b68e6c1d6f9', r
    r = md5s('This is test string.')
    assert r == 'a25d7d0b705c843f19e11b68e6c1d6f9', r
    r = md5s('This is test string.'.encode('utf-8'))
    assert r == 'a25d7d0b705c843f19e11b68e6c1d6f9', r


# Generated at 2022-06-25 13:03:26.949608
# Unit test for function checksum
def test_checksum():
    test_str = 'hello world'
    expected_str = '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    output_str = checksum_s(test_str)
    assert(expected_str == output_str)


# Generated at 2022-06-25 13:03:30.496834
# Unit test for function md5
def test_md5():
    # See if the function fails when no arguments are specified
    try:
        md5()
        assert False
    except TypeError:
        assert True
    except:
        assert False

    # Run the unit test routine
    test_case_0()


# Generated at 2022-06-25 13:03:39.616855
# Unit test for function md5
def test_md5():
    bytes_0 = b'\xef\xe0\x1d\xac\x89\xd5\xdd'
    var_0 = md5s(bytes_0)
    assert var_0 == b'8df7a57083fb068f0c8f50a61e7bba6f'
    bytes_0 = b'\xd3\xdd\xfe\xbb\x00\x1e\x10\x07\xf8\xd9\xbe\x1c\xaa\x81\x98\x93\x11\xb3\xac\x89\xe9\x91'
    var_1 = md5s(bytes_0)

# Generated at 2022-06-25 13:03:46.476736
# Unit test for function checksum
def test_checksum():
    path = os.getcwd() + os.path.sep + 'test' + os.path.sep + 'files' + os.path.sep + 'test_file.txt'
    # check file, ensure that there is no trailing slash at the end
    assert checksum(path) == checksum(path.rstrip(os.path.sep))
    assert checksum(path) != checksum(path + '.bak')
    # check string
    assert checksum_s('hello') != checksum_s('world')
    assert checksum_s(bytes('hello', 'utf-8')) == checksum_s('hello')



# Generated at 2022-06-25 13:03:49.713129
# Unit test for function md5s
def test_md5s():
    try:
        test_case_0()
    except ValueError as e:
        # If the function is not available, md5() will never be used
        pass



# Generated at 2022-06-25 13:03:54.626614
# Unit test for function md5s
def test_md5s():
    import os
    import hashlib
    for filename in os.listdir('.'):
        if os.path.isfile(filename):
            file = open(filename, 'rb')
            content = file.read()
            localmd5 = md5s(content)
            md5 = hashlib.md5(content).hexdigest()
            file.close()
            assert localmd5 == md5


# Generated at 2022-06-25 13:03:59.435720
# Unit test for function md5
def test_md5():
    assert True
    test_case_0()


# Generated at 2022-06-25 13:04:01.185674
# Unit test for function md5s
def test_md5s():
    result = md5s(b'123')
    assert result == '202cb962ac59075b964b07152d234b70'


# Generated at 2022-06-25 13:04:02.335533
# Unit test for function md5s
def test_md5s():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 13:04:04.877271
# Unit test for function md5s
def test_md5s():
    data = "hello"
    digest = md5s(data)
    assert type(digest) == str
    assert len(digest) == 32


# Generated at 2022-06-25 13:04:09.101152
# Unit test for function md5s
def test_md5s():
    bytes_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    var_0 = md5s(bytes_0)
    assert var_0 == 'e831946f1df0b3b3dfc3d256f4b4d4c4'



# Generated at 2022-06-25 13:04:15.004883
# Unit test for function md5s
def test_md5s():
    assert os.path.exists('test/test_md5s/test_case_0')
    bytes_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    var_0 = md5s(bytes_0)
    assert var_0 == '0ef5b5f5c5a51b2ec0d4c2776aa4c39a'


# Generated at 2022-06-25 13:04:19.571525
# Unit test for function md5
def test_md5():
    var_1 = md5('./data/ansible_modlib.zip')
    var_2 = md5('./data/ansible_modlib.zip')
    assert (var_1 == var_2)
    var_3 = md5('./data/ansible_modlib.zipp')
    assert (var_3 != var_2)


# Generated at 2022-06-25 13:04:24.262499
# Unit test for function checksum
def test_checksum():
    assert os.path.isfile('/etc/passwd') == True
    assert checksum('/etc/passwd') == '6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b'
    assert checksum_s('The rain in Spain') == 'c77b662e9dd43f3f113b8e841c2a7dbf473866c3'


# Generated at 2022-06-25 13:04:28.813139
# Unit test for function md5
def test_md5():
    assert md5('/home/user/file') == 'f0a477b9d9b3020b6fddb6d7f6c8e336'
    assert md5('/home/user/file') == checksum('/home/user/file')

# Generated at 2022-06-25 13:04:34.096470
# Unit test for function md5s
def test_md5s():
    result = md5s(b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d')
    assert result == 'e1438eeb2e7d4ddd9c9b4e20e46a4d05'

if __name__ == "__main__":
    test_case_0()
    test_md5s()

# Generated at 2022-06-25 13:04:42.780338
# Unit test for function md5
def test_md5():
    test_in_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    test_out_0 = md5s(test_in_0)
    assert (test_out_0 == "ee6fc2b4fe87a27f1a4f4f4d2a67cda4"), "Expected result does not match actual result"


# Generated at 2022-06-25 13:04:49.686314
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/dev/null') == 'd41d8cd98f00b204e9800998ecf8427e'
    a = md5('./test/unit/utils/ansible/modules/core/files/test_file.py')
    assert a == 'cc0d622b9c9abcd46d1ec0a37c91a8ed', a

# Generated at 2022-06-25 13:04:56.368422
# Unit test for function md5
def test_md5():
    assert md5('') is None
    assert md5('bad_file_name') is None
    assert md5('test/ansible_test/_data/test_file.txt') == '2855827cadf0d3e2bffaa2e26551a9c1'
    assert md5('test/ansible_test/_data/test_file_2.txt') == 'cc9e9b46172344d0afdeaafb6d0511d5'


# Generated at 2022-06-25 13:04:58.500246
# Unit test for function md5
def test_md5():
    assert len(md5("/bin/ls")) == 32


# Generated at 2022-06-25 13:05:05.331284
# Unit test for function md5s
def test_md5s():
    stdin_0 = '"this-is-not-a-number"'
    stdin_1 = 'this-is-not-a-number'
    stdin_2 = '"this-is-not-a-number'
    var_0 = md5s(stdin_0) # ""
    var_1 = md5s(stdin_1) # "9816d2b7c8b6afc1d810ece96985f53c"
    var_2 = md5s(stdin_2) # ""

# Generated at 2022-06-25 13:05:05.869374
# Unit test for function md5s
def test_md5s():
    pass # TODO: add tests here


# Generated at 2022-06-25 13:05:06.742203
# Unit test for function checksum
def test_checksum():
    test_checksum = checksum('/hello')
    print (test_checksum)


# Generated at 2022-06-25 13:05:12.848253
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "6b8f30ef074e4d4e894029c9e7a22b63c5f5cc8f"
    assert checksum("/bin/ls", None) == "6b8f30ef074e4d4e894029c9e7a22b63c5f5cc8f"
    assert checksum("/bin/ls", "sha1") == "6b8f30ef074e4d4e894029c9e7a22b63c5f5cc8f"


# Generated at 2022-06-25 13:05:16.867481
# Unit test for function checksum
def test_checksum():
    arg1 = 'hello world'
    arg2 = sha1
    out = checksum(arg1, arg2)
    assert out == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed', \
           'Failed to verify SHA1 checksum'


# Generated at 2022-06-25 13:05:20.441425
# Unit test for function md5s
def test_md5s():
    arg1 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    assert md5s(arg1) == '67ab6b9f1d132add1b88f6b95d6c26fc'


# Generated at 2022-06-25 13:05:26.757188
# Unit test for function md5
def test_md5():
    assert isinstance(md5, object)
    assert md5(to_bytes('playbooks/acme_app.yml', errors='surrogate_or_strict')) == 'a7098df2e2a760acb5016bd8d6fd21a9'
    assert isinstance(md5s, object)

# Generated at 2022-06-25 13:05:28.240314
# Unit test for function md5
def test_md5():
    assert checksum('/etc/passwd') == md5('/etc/passwd')


# Generated at 2022-06-25 13:05:32.517037
# Unit test for function md5s
def test_md5s():
    # Test case 0: Very simple test
    result = md5s(b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d')
    assert result == "d7e0c96f9eca9ee1c8d6b0f61144acf5"
    # Test case 1: Pass an object which has no __str__ method
    result = md5s(b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d')
    assert result == "d7e0c96f9eca9ee1c8d6b0f61144acf5"


# Generated at 2022-06-25 13:05:40.913370
# Unit test for function md5
def test_md5():
    filename = ""
    assert md5(filename) == (""), "md5('{filename}') returned '{actual}' expected '{expected}'".format(filename=filename, actual=md5(filename), expected=(""))
    filename = ""
    assert md5(filename) == (""), "md5('{filename}') returned '{actual}' expected '{expected}'".format(filename=filename, actual=md5(filename), expected=(""))
    filename = "data"

# Generated at 2022-06-25 13:05:48.806990
# Unit test for function checksum
def test_checksum():
    # Test for correct md5 hash for a string
    value = '''#cloud-config
print: Hello World
'''
    assert checksum_s(value) == '1c47abf1366fdf4908b1d754ef8682ee5a6d0c79'

    # Test for correct md5 hash for a file
    location = '~/.ansible/tmp/test_checksum.txt'
    with open(location, 'w') as f:
        f.write(value)
    assert checksum(location) == '1c47abf1366fdf4908b1d754ef8682ee5a6d0c79'
    os.remove(location)



# Generated at 2022-06-25 13:05:54.508116
# Unit test for function md5
def test_md5():

    filename = './test_md5'
    try:
        f = open(filename, 'w')
        try:
            f.write('test123')
        finally:
            f.close()

        sum = md5(filename)
        assert sum == 'b64e947b3931e8f2d98d2b0f3b3514a3'
    finally:
        if os.path.isfile(filename):
            os.unlink(filename)



# Generated at 2022-06-25 13:05:57.342802
# Unit test for function md5s
def test_md5s():
    var_0 = b'foo'
    var_3 = md5s(var_0)
    assert (var_3 == 'acbd18db4cc2f85cedef654fccc4a4d8')


# Generated at 2022-06-25 13:06:09.426626
# Unit test for function md5s
def test_md5s():
    assert md5s(bytes('', 'utf-8')) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(bytes('a', 'utf-8')) == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s(bytes('abc', 'utf-8')) == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s(bytes('message digest', 'utf-8')) == 'f96b697d7cb7938d525a2f31aaf161d0'

# Generated at 2022-06-25 13:06:13.213522
# Unit test for function md5s
def test_md5s():
    # TestCase 0
    result = md5s(b"N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d")
    print(result)
    assert(result == "d38a9c9e1a8b57a632cd5b208c425bdc")


# Generated at 2022-06-25 13:06:17.272497
# Unit test for function md5
def test_md5():
    assert md5s('ansible') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert md5('/etc/ansible/hosts') == '2c758186972a072c50d5f878c67e4074'


# Generated at 2022-06-25 13:06:21.668162
# Unit test for function md5s
def test_md5s():
    test_case_0()


# Generated at 2022-06-25 13:06:31.667986
# Unit test for function md5s
def test_md5s():
    assert md5s('N.#............U9.oz)...d') == 'ccc4bd2838b505da3113ebaae7d96c3e'
    assert md5s('N.#............U9.oz)...d') ==  'ccc4bd2838b505da3113ebaae7d96c3e'
    assert md5s(128*'\0') == '1b99b9698f891465dbb9d6f42e6c1e6e'
    assert md5s(255*'\0') == 'c8e9f87ccb320d4f7fe4c4b285565d69'

# Generated at 2022-06-25 13:06:34.898210
# Unit test for function md5
def test_md5():
    filename = 'C:\\Users\\asethi\\workspace\\junos-ansible\\test\\test_md5.txt'
    hash = 'fe7e48de4c8bcb08c4fa4ba97fa4c9ad'
    assert md5(filename) == hash

# Generated at 2022-06-25 13:06:37.482054
# Unit test for function md5
def test_md5():
    bytes_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    var_0 = md5s(bytes_0)
    print("MD5: %s" % var_0)


# Generated at 2022-06-25 13:06:44.097280
# Unit test for function md5
def test_md5():
    bytes_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    var_0 = md5s(bytes_0)
    assert var_0 ==  '644b9a9d47d5bb7c8bcd20e7722f5b05'
    var_1 = md5(bytes_0)
    assert var_1 ==  '644b9a9d47d5bb7c8bcd20e7722f5b05'
    bytes_1 = b'\r\r\r\r\r\r\r'
    var_2 = md5s(bytes_1)
    assert var_2 ==  '6d425e6a7e8794fde638d9527d06d62e'

# Generated at 2022-06-25 13:06:50.468387
# Unit test for function md5
def test_md5():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    filename = basic.get_platform_subclass().get_tmp_path('ansible_test_file_for_md5')

    # If a file doesn't exist, md5() should return None
    basic.remove_tree(filename)
    assert md5(filename) is None

    # If a file is empty, md5() should return the same hash as md5s('')
    open(filename, 'a').close()
    assert md5(filename) == md5s('')

    # If a file has some content, md5() should return the same hash as md5s(file_content)
    file_content = 'content ' * 1000

# Generated at 2022-06-25 13:07:00.394761
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    bytes_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    var_0 = md5s(bytes_0)
    assert var_0 == 'fe98b8a8b0dacf9b0a9c9078a0e5dd5e'


if __name__ == "__main__":
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-25 13:07:04.581803
# Unit test for function checksum
def test_checksum():
    assert checksum('tests/unit/utils/test_utils_hashing.py') == checksum('../../utils/test_utils_hashing.py')
    assert checksum_s(b"Hello World") == '0a4d55a8d778e5022fab701977c5d840bbc486d0'



# Generated at 2022-06-25 13:07:12.078508
# Unit test for function md5
def test_md5():
    retrieved_value = md5s(b"Hello World")
    assert retrieved_value == "ed076287532e86365e841e92bfc50d8c"

# Generated at 2022-06-25 13:07:14.732928
# Unit test for function checksum
def test_checksum():
    assert to_bytes(checksum('nonexistent_file.txt')) == to_bytes('')
    assert to_bytes(checksum('test_file.txt')) == to_bytes('4c4b2b4d4ff627f8f0e3ebd2b3e6f374')

# Generated at 2022-06-25 13:07:19.910923
# Unit test for function md5
def test_md5():
    print('Testing md5')
    for file in ('/etc/hosts', '/etc/resolv.conf'):
        assert md5(file)


# Generated at 2022-06-25 13:07:21.878398
# Unit test for function checksum
def test_checksum():
    assert checksum("test_utils/file/test.txt")       == "e4edcf4c4f5a7b5406bd844eca5e5e5c0a2b3f3b"
    assert checksum("test_utils/file/test_dir/test.txt") == None


# Generated at 2022-06-25 13:07:24.862749
# Unit test for function md5s
def test_md5s():
    # Testing for var_0
    bytes_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    var_0 = md5s(bytes_0)


# Generated at 2022-06-25 13:07:29.149041
# Unit test for function md5
def test_md5():
    txt_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    var_0 = md5(txt_0)
    ref_0 = b'de5a5d4f6a2a4a87c6daf0d870f0c473'

    assert isinstance(var_0, bytes)
    assert var_0 == ref_0

# Generated at 2022-06-25 13:07:34.180347
# Unit test for function md5s
def test_md5s():
    import random
    import string
    random_string = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(100))

    expected = '5a8a5184f1bd0d9e9e9d8c857e2638dc'
    result = md5s(random_string)
    assert expected == result


# Generated at 2022-06-25 13:07:36.392134
# Unit test for function md5
def test_md5():
    for i in range(0,1,1):
        try:
            test_case_0()
        except ValueError as e:
            print("Error raised: ", e)

# Generated at 2022-06-25 13:07:38.500843
# Unit test for function md5
def test_md5():
    assert md5(u'/etc/hosts') == u'8c7d7b34460e44a730b7e8f11cb4ba4a'


# Generated at 2022-06-25 13:07:47.113803
# Unit test for function md5
def test_md5():
    data1 = b'hello'
    data2 = b'goodbye'
    data3 = b''
    data4 = b'z'

    # print("Testing md5(" + data1 + ")")
    assert md5s(data1) == '5d41402abc4b2a76b9719d911017c592'
    # print("Testing md5(" + data2 + ")")
    assert md5s(data2) == '45b23deebc4fb9c8223b5d90925f1d34'
    # print("Testing md5(" + data3 + ")")
    assert md5s(data3) == 'd41d8cd98f00b204e9800998ecf8427e'
    # print("Testing md5(" + data4 + ")")
    assert md

# Generated at 2022-06-25 13:07:51.601132
# Unit test for function md5s
def test_md5s():
    # Zero argument case
    try:
        md5s()
    except TypeError as e:
        assert True, '0 argument case: TypeError raised as expected'

    # Single argument case
    var_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    var_1 = md5s(var_0)
    assert var_1=='e939c0f8d8dfd45a5f63bb03a631c333', 'Single argument case: md5s returned wrong value'



# Generated at 2022-06-25 13:07:53.371734
# Unit test for function md5
def test_md5():
    bytes_0 = b'This is a test string'
    var_0 = md5s(bytes_0)
    assert var_0 == '851577e1b50e6eb19c02d06bfb0bf316'


# Generated at 2022-06-25 13:07:59.385436
# Unit test for function checksum
def test_checksum():
    test_string = b'hello world'
    expected = '5eb63bbbe01eeed093cb22bb8f5acdc3'
    actual = checksum_s(test_string)
    assert actual == expected



# Generated at 2022-06-25 13:08:00.205169
# Unit test for function md5
def test_md5():
    test_case_0()


# Generated at 2022-06-25 13:08:09.457244
# Unit test for function md5s
def test_md5s():
    from tests.unit.playbook.remote_management import CLICommon

    # patch __salt__ dunder
    setattr(CLICommon, '__salt__', {})

    assert md5s(b'Test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s(b'Test Test Test Test') == '2f5b8c62b1d5abd921e2e5d5f5a5aea5'

# Generated at 2022-06-25 13:08:12.116532
# Unit test for function md5s
def test_md5s():
    var_0 = md5s('test123')
    assert var_0 == '05cb9cb9985e519868d5a5b11a7fa049'



# Generated at 2022-06-25 13:08:19.780917
# Unit test for function md5
def test_md5():
    from unittest import TestLoader, TextTestRunner, TestSuite
    import sys
    import os
    import tempfile
    from ansible.module_utils._text import to_bytes
    try:
        from hashlib import md5 as _md5
    except ImportError:
        try:
            from md5 import md5 as _md5
        except ImportError:
            # Assume we're running in FIPS-140 mode here
            _md5 = None
        else:
            md5_compat = True

    class TestMd5(unittest.TestCase):
        ''' Validate md5 function returns correct result '''
        def test_positive_md5(self):
            random_bytes = os.urandom(64)
            md5_check = _md5(random_bytes).hexdigest()
            f

# Generated at 2022-06-25 13:08:28.373770
# Unit test for function checksum
def test_checksum():
    print("Test for checksum")

    assert checksum('ansible/utils/__init__.py') == 'f9a10097eb2f2c457f7b1e235e47fe722f6babf6'
    assert checksum('/bin/bash') == '97cee14e0959f84e0f2d2e8add8bf1e02cfdbd99'
    assert checksum('does_not_exist') is None
    assert checksum('/bin') is None


# Generated at 2022-06-25 13:08:36.065217
# Unit test for function md5s
def test_md5s():
    fname = 'tests/unit/module_utils/test_string_utils_data/md5s'
    if os.path.exists(fname):
        with open(fname, 'r') as f:
            buf = f.read()
    else:
        buf = 'The quick brown fox jumps over the lazy dog.'

    m = md5s(buf)
    # TODO: fix this test data
    # print ('MD5S TEST DATA', buf, m)
    assert m == '9e107d9d372bb6826bd81d3542a419d6'



# Generated at 2022-06-25 13:08:42.762679
# Unit test for function md5
def test_md5():
    # Test case 1
    result_1 = md5(b'c:\\windows\\system32\\utilman.exe')

    # Test case 2
    result_2 = md5(b'c:\\windows\\system32\\sethc.exe')

    # Test case 3
    result_3 = md5(b'c:\\windows\\sysnative\\utilman.exe')

    # Test case 4
    result_4 = md5(b'c:\\windows\\sysnative\\sethc.exe')

    # Test case 5
    result_5 = md5(b'C:\\Windows\\System32\\utilman.EXE')

    # Test case 6
    result_6 = md5(b'c:\\windows\\system32\\utilman.exe')

    # Test case 7

# Generated at 2022-06-25 13:08:43.860627
# Unit test for function md5
def test_md5():
    assert isinstance(md5(b'/etc/passwd'), str)


# Generated at 2022-06-25 13:08:48.207734
# Unit test for function md5s
def test_md5s():

    s = 'hello'
    md5 = md5s(s)
    assert len(md5) == 32
    assert md5 == '5d41402abc4b2a76b9719d911017c592'

if __name__ == "__main__":
    test_case_0()
    test_md5s()

# Generated at 2022-06-25 13:08:53.121958
# Unit test for function md5s
def test_md5s():
    test_case_0()

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-25 13:08:55.723540
# Unit test for function md5
def test_md5():
    var_1 = md5(__file__)
    return var_1

if __name__ == '__main__':
    result = test_md5()
    print(result)

# Generated at 2022-06-25 13:09:03.222684
# Unit test for function checksum
def test_checksum():
    from nose.plugins.skip import SkipTest
    try:
        from nose.tools import assert_equals
    except ImportError:
        raise SkipTest("can't run tests without nose")


# Generated at 2022-06-25 13:09:07.910997
# Unit test for function md5s
def test_md5s():
    assert hash(md5s(b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d')
               ) == hash(b'5e5e5d5d645d5d5d5d5d5d5d5d5d5d5d')

# Generated at 2022-06-25 13:09:09.704038
# Unit test for function checksum
def test_checksum():
    bytes_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    var_0 = md5s(bytes_0)

# Generated at 2022-06-25 13:09:11.024004
# Unit test for function checksum
def test_checksum():
    checksum('test_hash.py')


# Generated at 2022-06-25 13:09:12.194980
# Unit test for function md5s
def test_md5s():
    test_case_0()


# Generated at 2022-06-25 13:09:21.798168
# Unit test for function md5
def test_md5():
    # Test using a string
    bytes_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    assert md5s(bytes_0) == 'a9a9d2474d3bd6fdbb738c33d84a2a14'
    assert md5s(bytes_0) == 'a9a9d2474d3bd6fdbb738c33d84a2a14'

    # Test using unicode
    assert md5s(u'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d') == 'a9a9d2474d3bd6fdbb738c33d84a2a14'

    # Test using a

# Generated at 2022-06-25 13:09:27.349802
# Unit test for function checksum
def test_checksum():
    assert checksum("tests/test_hashlib.py") == "1d86f889e50a0c903e55e7b49f1d3d7e54a81112" or checksum("tests/test_hashlib.py") == "e3588ddbd2b36eea1e83910cae726d43"
    assert checksum("non-existent-file") is None


# Generated at 2022-06-25 13:09:34.923155
# Unit test for function checksum
def test_checksum():
    # This test requires the "file" module, and thus needs to be
    # included in test/lib/ansible_test/_data/modules/file/ansible_collections/community/general/
    infile = os.path.join(os.path.dirname(__file__), "..", "..", "..", "_data", "modules", "file", "ansible_collections", "community", "general", "copy", "test_src")
    sha1_digest = secure_hash(infile)
    assert sha1_digest == "4ae81574a9f9e0ae9165d8ffd2f2fc5b5f5a35ae"

if __name__ == '__main__':
    test_case_0()
    test_checksum()

# Generated at 2022-06-25 13:09:41.587216
# Unit test for function checksum
def test_checksum():
    filename = 'dummy_file'
    hash_checksum = checksum(filename)
    test_checksum = secure_hash(filename)
    assert hash_checksum == test_checksum, "Checksum function failed"


# Generated at 2022-06-25 13:09:48.777844
# Unit test for function md5s
def test_md5s():
    assert md5s(b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d') == 'a8a37ab9f9f0af5b3d2370e8cda5b0d5'
    try:
        assert md5s(to_bytes('N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d', errors='surrogate_or_strict')) == 'a8a37ab9f9f0af5b3d2370e8cda5b0d5'
    except ValueError:
        pass


# Generated at 2022-06-25 13:09:51.174850
# Unit test for function md5
def test_md5():
    bytes_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    var_0 = md5s(bytes_0)

    return

test_md5()

# Generated at 2022-06-25 13:09:59.724529
# Unit test for function md5s
def test_md5s():
    assert md5s(b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d') == b'4f70dca7e9e9b8c7d95ebcf16f05cbb5'
    assert md5s(b'BA\x05<\x9d\x90\xf6t\x10\xf4\xe5\x8aq\xfb\x87\x9e\x8cV\x1b\x80h7\xf4\x0e\x15\xca\x9e\x9d') == b'6f3dfa525b169f0b8a094599cfd37ee6'

# Generated at 2022-06-25 13:10:02.860975
# Unit test for function checksum
def test_checksum():
    assert "23f821c86028a7a2f451c52d93b8a845" == checksum("/tmp/test_file")


# Generated at 2022-06-25 13:10:06.793484
# Unit test for function md5
def test_md5():
    bytes_0 = b'N.#\x98/\x18\x00\xaa\x14U9\x0eoz)\xe0d'
    var_0 = md5s(bytes_0)
    assert var_0 == 'c56f60b79c834f6d1f6ddfb7e52fdb2c'


# Generated at 2022-06-25 13:10:09.119988
# Unit test for function md5s
def test_md5s():
    try:
        test_case_0()
    except Exception as e:
        print(str(e))
        return False
    else:
        return True



# Generated at 2022-06-25 13:10:14.557261
# Unit test for function md5
def test_md5():
    """
    Test md5
    """
    test_file = "test_file.txt"

    with open(to_bytes(test_file, errors='surrogate_or_strict'), "wt") as f:
        f.write("Hallo")
    md5_hash = md5(test_file)
    os.remove(to_bytes(test_file, errors='surrogate_or_strict'))
    assert(md5_hash == "1eef3a05f7b173d1c125837a8fbf34f7")


# Generated at 2022-06-25 13:10:16.187224
# Unit test for function md5
def test_md5():
    data = b"abc123xyz"
    assert md5s(data) == 'cafebabecafebabecafebabecafebabe'


# Generated at 2022-06-25 13:10:16.784940
# Unit test for function md5
def test_md5():
    test_case_0()


# Generated at 2022-06-25 13:10:30.948339
# Unit test for function md5

# Generated at 2022-06-25 13:10:34.156901
# Unit test for function md5s
def test_md5s():
    md5s_test = md5s(b'123456789')
    assert md5s_test == '25f9e794323b453885f5181f1b624d0b'
