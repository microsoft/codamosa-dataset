

# Generated at 2022-06-25 13:00:47.639422
# Unit test for function checksum
def test_checksum():
    var_1 = secure_hash("./test/units/module_utils/a.py")
    assert(var_1 == "a4f8dc3c4d4cf4a70f7c4e8a9e9a937d59e24ab1")


# Generated at 2022-06-25 13:00:49.329788
# Unit test for function checksum
def test_checksum():
    str_0 = 'ansible'
    var_0 = checksum_s(str_0)


# Generated at 2022-06-25 13:00:52.697883
# Unit test for function md5s
def test_md5s():
    assert md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == '2bb1b33e8d91a22ccd791c30f4d4c796'


# Generated at 2022-06-25 13:00:55.332982
# Unit test for function checksum
def test_checksum():
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_0 = checksum_s(str_0)


# Generated at 2022-06-25 13:00:57.775524
# Unit test for function md5s
def test_md5s():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:01:04.134161
# Unit test for function checksum
def test_checksum():
    assert secure_hash(os.path.dirname(__file__) + "/test_checksum.py", hash_func=sha1) == "ee1e63466b6e2d6d9e6c1e63ec7c6c2dbe7dbb56"
    assert secure_hash_s('Hello World', hash_func=sha1) == "b10a8db164e0754105b7a99be72e3fe5"


# Generated at 2022-06-25 13:01:04.814783
# Unit test for function md5s
def test_md5s():
    assert True == True


# Generated at 2022-06-25 13:01:08.686650
# Unit test for function md5s
def test_md5s():
    var_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    res_0 = 'fccefa89b770f42b9cd0b05c34d53f54'
    res_1 = md5s(var_0)
    return res_0 == res_1


# Generated at 2022-06-25 13:01:13.507470
# Unit test for function md5
def test_md5():
    str = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    res = md5s(str)
    if res != '2e8b6e0a6d7f6ca0ab6c9b6d1f6c1b10':
        raise ValueError('Returned incorrect md5 value')
    return True


# Generated at 2022-06-25 13:01:22.736013
# Unit test for function checksum
def test_checksum():
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_0 = checksum_s(str_0)



# Generated at 2022-06-25 13:01:31.617644
# Unit test for function checksum
def test_checksum():
    test_file = 'test_checksum.txt'
    file_target = open(test_file, 'w')
    file_target.write('test file content')
    file_target.close()
    checksum_result = checksum(test_file)
    print("The SHA1 checksum of file %s is: %s" % (test_file, checksum_result))
    os.remove(test_file)


# Generated at 2022-06-25 13:01:36.426676
# Unit test for function md5
def test_md5():
    assert md5('/etc/hostname') == '3c9ca53110bbb065d34bf46b6c8e2e85'


# Generated at 2022-06-25 13:01:44.761017
# Unit test for function md5s
def test_md5s():
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_0 = md5s(str_0)
    if var_0 != 'b2789a8de55798ac7dbf39edf71afb58':
        raise AssertionError("md5s returned: %s, expected: %s" % (var_0, 'b2789a8de55798ac7dbf39edf71afb58'))
if __name__ == '__main__':
    import sys
    sys.exit(main())

# Generated at 2022-06-25 13:01:51.022195
# Unit test for function checksum
def test_checksum():
    # Input parameters
    filename = '/etc/passwd'

    # Output parameters
    var_1 = None
    var_2 = None
#   var_3 = None

    # Invoke checksum method to create a checksum for the file
    var_1 = checksum(filename)
    var_2 = checksum_s(filename)
#   var_3 = checksum(checksum_s(filename))

    print("Test Case #1 - " + "pass") if (var_1 != None) else print("Test Case #1 - fail")
    print("Test Case #2 - " + "pass") if (var_2 != None) else print("Test Case #2 - fail")
#   print("Test Case #3 - " + "pass") if (var_3 != None) else print("Test Case #3 - fail")

# Unit

# Generated at 2022-06-25 13:01:53.630730
# Unit test for function md5s
def test_md5s():
    assert callable(md5s), \
        'Function md5s not callable'
    test_case_0()


# Generated at 2022-06-25 13:02:03.333402
# Unit test for function checksum
def test_checksum():

    # Assume we're running in FIPS mode which requires sha1
    assert checksum('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'

    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'

    # Non-FIPS mode should support md5
    if _md5:
        assert checksum('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

        assert checksum_s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-25 13:02:09.299444
# Unit test for function checksum
def test_checksum():
    assert not checksum('./test/data/test.yml')
    assert not checksum('./test/data')
    assert checksum('./test/data/test.yml') == checksum_s(to_bytes(open('./test/data/test.yml', 'r').read()))
    assert checksum('./test/data/test.yml') == checksum('./test/data/test.yml')


# Generated at 2022-06-25 13:02:11.687948
# Unit test for function checksum
def test_checksum():
    assert checksum('pi-bootstrap/bootstrap.sh') == 'd19f3b3ca43c7edc0e688c77779b9fa9d0315b18'

# Generated at 2022-06-25 13:02:14.559922
# Unit test for function md5
def test_md5():
    assert md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == 'af107b97961b1dc2cab2538a082f91a5', 'Test md5 failed'


# Generated at 2022-06-25 13:02:17.309941
# Unit test for function md5
def test_md5():
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_0 = md5s(str_0)



# Generated at 2022-06-25 13:02:20.786448
# Unit test for function md5s
def test_md5s():
    assert md5s(str_0) == var_0

# Generated at 2022-06-25 13:02:29.147558
# Unit test for function checksum
def test_checksum():
    filename = '/tmp/test_checksum_file'
    test_str = 'test_checksum_string'
    with open(filename, 'w') as f:
        f.write(test_str)
    assert checksum(filename) == checksum(filename, hash_func=sha1)
    assert checksum_s(test_str) == checksum_s(test_str, hash_func=sha1)
    os.unlink(filename)


if __name__ == '__main__':
    test_checksum()
    test_case_0()

# Generated at 2022-06-25 13:02:32.035106
# Unit test for function checksum
def test_checksum():
    assert (checksum('test/test_utils.py', None) == 'f35ad9582801f8aa96e7dee43acfe6af')


# Generated at 2022-06-25 13:02:35.125381
# Unit test for function md5s
def test_md5s():
    assert md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == 'd6bb3d6a9f617746cb76a2f8aa07f575'


# Generated at 2022-06-25 13:02:37.509424
# Unit test for function md5s
def test_md5s():
    print('Calling functions.')
    test_case_0()

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-25 13:02:42.333009
# Unit test for function md5s
def test_md5s():
    assert md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == '08e7a2e5350bcc7addb35d6e4ce4ed95'


# Generated at 2022-06-25 13:02:45.487764
# Unit test for function md5
def test_md5():
    file_name = 'file_exists'
    assert md5(file_name) == 'c0a8a388da6c89a45dfb38c2f5cc5de5'

# Unit Test for function md5s

# Generated at 2022-06-25 13:02:48.631911
# Unit test for function md5
def test_md5():
    assert(md5('/tmp/aaa') == 'd41d8cd98f00b204e9800998ecf8427e')
    return True



# Generated at 2022-06-25 13:02:51.366436
# Unit test for function checksum
def test_checksum():
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_0 = checksum_s(str_0)


# Generated at 2022-06-25 13:02:54.727760
# Unit test for function checksum
def test_checksum():
    assert md5('test.ini') == '172e6cc28f9b438d1634f0bce0735b00'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-25 13:02:59.753905
# Unit test for function checksum
def test_checksum():
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_0 = checksum_s(str_0)


# Generated at 2022-06-25 13:03:03.098804
# Unit test for function md5
def test_md5():
    md5_s = md5s('Hello World')
    if md5_s == 'b10a8db164e0754105b7a99be72e3fe5':
        return True
    else:
        raise Exception('Failed')


# Generated at 2022-06-25 13:03:12.435882
# Unit test for function checksum
def test_checksum():
    ansible_1_9_linux_sftp_path = u"/etc/ansible/modules/core/files/sftp.py"
    ansible_1_9_linux_stat_path = u"/etc/ansible/modules/core/files/stat.py"
    ansible_1_9_linux_synchronize_path = u"/etc/ansible/modules/core/files/synchronize.py"
    ansible_1_9_linux_patch_path = u"/etc/ansible/modules/core/packaging/os/patch.py"
    ansible_1_9_linux_pip_path = u"/etc/ansible/modules/extras/packaging/os/pip.py"

# Generated at 2022-06-25 13:03:14.884655
# Unit test for function md5
def test_md5():
    assert md5('/usr/bin/python2') == 'e3f0c922a75e863cad5c5b3615c4cfa4'


# Generated at 2022-06-25 13:03:21.571886
# Unit test for function checksum
def test_checksum():
    assert(checksum("/dev/null") == "d41d8cd98f00b204e9800998ecf8427e")  # Check against file which has 0 length
    assert(checksum("/bin/true") == "b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9")
    assert(checksum("/bin/false") == "8cc72b5c99b4041be000c3e088429155")
    assert(checksum("/nonexistent") is None)


# Generated at 2022-06-25 13:03:24.077060
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'c63f94d8ed8eec3c395b7d19f6a8b95d'


# Generated at 2022-06-25 13:03:26.664760
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'd3ca71c1fef5f5b26bf85f00d3a3abf6'


# Generated at 2022-06-25 13:03:32.750735
# Unit test for function md5
def test_md5():
    try:
        str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
        var_0 = md5s(str_0)
        pass
    except ValueError as e:
        print('This machine does not support the MD5 algorithm, possibly running in FIPS-140-2 mode')
        assert(e.args[0] == 'MD5 not available.  Possibly running in FIPS mode')
        pass
    pass



# Generated at 2022-06-25 13:03:36.546266
# Unit test for function md5s
def test_md5s():
    assert md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == '78d8c41f9cc9f2c62a4a4b03e4a3d4c4'


# Generated at 2022-06-25 13:03:39.040474
# Unit test for function checksum
def test_checksum():
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_0 = checksum_s(str_0)
    assert var_0 == '10dc6069a96e78435abd7a0a6fd8fdc2b2dca2a0'

# Generated at 2022-06-25 13:03:46.445111
# Unit test for function md5s
def test_md5s():
    try:
        assert(md5s('Test') == '098f6bcd4621d373cade4e832627b4f6')
    except AssertionError:
        raise AssertionError('MD5 sum expected: 098f6bcd4621d373cade4e832627b4f6\nMD5 sum received: ' +md5s('Test'))

# Generated at 2022-06-25 13:03:56.304939
# Unit test for function checksum
def test_checksum():
    str_0 = '-f'
    str_1 = 'version'
    str_2 = '-'
    str_3 = 'i'
    str_4 = 'path'
    str_5 = '-'
    str_6 = 'b'
    str_7 = 'mark_host_failed'
    str_8 = '-'
    str_9 = 'a'
    str_10 = 'private_data_dir'
    str_11 = '-'
    str_12 = 'v'
    str_13 = '-'
    str_14 = 'C'
    str_15 = '-'
    str_16 = 'P'
    str_17 = 'passwords'
    str_18 = '-'
    str_19 = 'k'
    str_20 = 'ask_pass'

# Generated at 2022-06-25 13:03:57.103729
# Unit test for function md5s
def test_md5s():
    test_case_0()


# Generated at 2022-06-25 13:03:58.633032
# Unit test for function md5s
def test_md5s():
    assert type(md5s('', _md5)) == str


# Generated at 2022-06-25 13:04:02.124492
# Unit test for function md5s
def test_md5s():
    print('Test for function md5s')
    assert md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == '7c206d049deba8c4e9923d031f3c4e84'


# Generated at 2022-06-25 13:04:05.379032
# Unit test for function checksum
def test_checksum():
    try:
        assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    except:
        var_1 = 'md5 mismatch'
        raise var_1


# Generated at 2022-06-25 13:04:07.653723
# Unit test for function md5s
def test_md5s():
    assert (md5s(str_0) == 'c625d0d7de868a087bb05f1e0f51f885')


# Generated at 2022-06-25 13:04:08.821891
# Unit test for function md5s
def test_md5s():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 13:04:11.410866
# Unit test for function md5s
def test_md5s():
    result = md5s('')
    assert result == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-25 13:04:16.358144
# Unit test for function md5s
def test_md5s():
    assert md5s(to_bytes('Conflicting options used, only one of --host, --graph or --list can be used at the same time.')) == b'89eb7d4f1098f2a05e34c77bd4a6438e'


if __name__ == '__main__':
    from unit.ansible_module_utils import *

    test_case_0()

# Generated at 2022-06-25 13:04:24.330839
# Unit test for function md5
def test_md5():
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    assert md5s(str_0) == 'e70c6d1383a85cc2f7ddba3d2cc58f9d'

    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    assert secure_hash_s(str_0) == 'b10a8db164e0754105b7a99be72e3fe5'

# Generated at 2022-06-25 13:04:29.168532
# Unit test for function md5s
def test_md5s():
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_0 = md5s(str_0)
    assert var_0 == '6e63983a58fd0a2e2e23d7a46717cb4c'

# Generated at 2022-06-25 13:04:31.967102
# Unit test for function md5
def test_md5():
    assert md5('some_file') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('some_file') == md5s('some_file')

# Generated at 2022-06-25 13:04:38.745970
# Unit test for function md5s
def test_md5s():
    ENABLE_MD5 = False
    if ENABLE_MD5:
        # This test will only pass if the module is being run on a system
        # which does not support FIPS-140-2.
        md5('')
    else:
        # This test will only pass if the module is being run on a system
        # which supports FIPS-140-2.
        try:
            md5('')
        except ValueError as e:
            assert e.message == 'MD5 not available.  Possibly running in FIPS mode'

# Generated at 2022-06-25 13:04:46.130292
# Unit test for function md5s
def test_md5s():
    # Clear the current working directory
    tmp_dir = os.path.dirname(__file__) + "/../../tmp"
    try:
        os.chdir(tmp_dir)
    except:
        os.mkdir(tmp_dir)
        os.chdir(tmp_dir)
    # Create a new directory under the current working directory
    tmp_test_dir = tmp_dir + "/" + "test_md5s"
    try:
        os.chdir(tmp_test_dir)
    except:
        os.mkdir(tmp_test_dir)
        os.chdir(tmp_test_dir)
    test_case_0()


# Generated at 2022-06-25 13:04:50.858992
# Unit test for function md5
def test_md5():
    assert md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == 'a9b6ccfc357558c8411a0fbd1d071743'
    assert md5('/etc/ansible/ansible.cfg') == '0e0cf5d5e10b0bc3a3bc3a1683d77b13'
    assert md5('/etc/ansible') == None
    assert md5('/etc/ansible/') == None


# Generated at 2022-06-25 13:04:55.854220
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/motd') == 'b70d0536f89e899c53e224546f2ff105'
    assert checksum('/etc/motd', _md5) == '9561a3a0a829cec1f9a1e0b1377b647c'


# Generated at 2022-06-25 13:04:59.018919
# Unit test for function md5
def test_md5():
    assert(md5('filename') == None)
    assert(md5('filename') == md5('filename'))

# Generated at 2022-06-25 13:05:08.705554
# Unit test for function checksum
def test_checksum():
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_0 = checksum_s(str_0)
    str_1 = '--list'
    var_1 = checksum_s(str_1)
    str_2 = '--graph'
    var_2 = checksum_s(str_2)
    str_3 = '--host'
    var_3 = checksum_s(str_3)
    str_4 = 'ANSI_X3.4-1968'
    var_4 = checksum_s(str_4)
    str_5 = 'ANSI_X3.4-1986'
    var_5 = checksum_s(str_5)
    str_6 = 'ASCII'
    var_

# Generated at 2022-06-25 13:05:13.838595
# Unit test for function md5s
def test_md5s():
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_0 = md5s(str_0)
    checksum_s(str_0)


# Generated at 2022-06-25 13:05:18.880677
# Unit test for function md5
def test_md5():
    assert 'e05de1fd14fa6d8f8b3f3cf75ebf7b82' == md5('test')


# Generated at 2022-06-25 13:05:21.840570
# Unit test for function md5s
def test_md5s():
    assert md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == 'b6d35b6a4d2b52c0da5c0e5cc5f37993'



# Generated at 2022-06-25 13:05:24.324307
# Unit test for function md5s
def test_md5s():
    print('Testing md5s()')

    # From python docs
    expected = "900150983cd24fb0d6963f7d28e17f72"
    actual = md5s("abc")
    assert actual == expected, "md5s() failed"


# Generated at 2022-06-25 13:05:27.161846
# Unit test for function md5
def test_md5():
    assert to_bytes(md5('test/ansible-playbook/test_playbook/playbook.yml')) == 'dbba7f10c95f4e7e65dd29e4200b4a4b'



# Generated at 2022-06-25 13:05:35.854208
# Unit test for function checksum
def test_checksum():
    input_filename = "~/python/ansible/lib/ansible/modules/core/system/ping.py"
    num_includes = 20
    num_lines = 153
    num_statements = 20
    num_complexity = 9
    function_complexity_distribution = { "1": 0, "2": 0, "3": 0,
                                         "4": 0, "5": 0, "6": 0, "7": 9,
                                         "8": 0, "9": 0, "10": 0, "11": 0,
                                         "12": 0, "13": 0, "14": 0, "15": 0,
                                         "16": 0, "17": 0, "18": 0, "19": 0,
                                         "20": 0 }

# Generated at 2022-06-25 13:05:39.173759
# Unit test for function md5
def test_md5():
    test_str = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    assert(md5s(test_str) == 'a78a38d7fc5c5bcccf742e3d1f0b84bd')


# Generated at 2022-06-25 13:05:47.463003
# Unit test for function md5
def test_md5():
    '''
    Bootstrap the unit test
    '''
    import os
    import tempfile
    import shutil

    # Create a directory
    tempdir = tempfile.mkdtemp()

    # Create a temporary file
    filename = os.path.join(tempdir, 'test_md5')
    f = open(filename, 'w')
    f.write('testdata')
    f.close()

    try:
        # Verify that the file's md5 checksum is equal to the known md5
        assert md5(filename) == '098f6bcd4621d373cade4e832627b4f6'
    finally:
        # Remove the directory after the test
        shutil.rmtree(tempdir)


# Generated at 2022-06-25 13:05:49.283366
# Unit test for function md5s
def test_md5s():
    assert test_case_0() == '1633d1cd86e16e6da2d2faae0a358d8c'



# Generated at 2022-06-25 13:05:52.823819
# Unit test for function md5s
def test_md5s():
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_0 = md5s(str_0)
    return var_0 == '68a26f8fa90e4b47e581a2f34b4c4a4d'

# Generated at 2022-06-25 13:05:55.689315
# Unit test for function md5
def test_md5():
    assert md5s('Hello World') == 'b10a8db164e0754105b7a99be72e3fe5'


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-25 13:06:09.922283
# Unit test for function md5
def test_md5():
    str_1 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    str_2 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_2 = md5s(str_2)
    assert var_2 == '3e2c3cc8b73e8e7c8875d9d6f82ec1f5', 'Expected "3e2c3cc8b73e8e7c8875d9d6f82ec1f5", got "%s"' % var_2
    str_3 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_3 = md5s(str_3)
   

# Generated at 2022-06-25 13:06:12.855516
# Unit test for function checksum
def test_checksum():  
    filename = 'test_file'
    with open(filename, 'wb') as f:
        f.write(b'Hello world!')
    test_checksum = checksum(filename)
    os.remove(filename)
    return test_checksum


# Generated at 2022-06-25 13:06:14.887370
# Unit test for function checksum
def test_checksum():
    assert checksum('foo') == 'd3b07384d113edec49eaa6238ad5ff00'


# Generated at 2022-06-25 13:06:17.400168
# Unit test for function md5
def test_md5():
    """Md5 Unit tests"""
    assert md5('/etc/passwd') == '7d93096535aedb06e4d8aeaf15c373b5'


# Generated at 2022-06-25 13:06:21.549727
# Unit test for function md5s
def test_md5s():
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_0 = md5s(str_0)

    assert(var_0 == '4a4604f7a9f977e597a4ab43fba35d03')


# Generated at 2022-06-25 13:06:31.550124
# Unit test for function checksum
def test_checksum():
    assert type(checksum(filename=None)) == type(None)
    assert type(checksum(filename='bc57a6c2d6335484de6c1a8f1b6da5a7e5a5f5cc8')) == type('')
    assert type(checksum(filename='f4d3b4918b30e53a8c2a6eb5d6c2f6f0fc79c148')) == type('')

    assert checksum(filename='bc57a6c2d6335484de6c1a8f1b6da5a7e5a5f5cc8') == 'bc57a6c2d6335484de6c1a8f1b6da5a7e5a5f5cc8'

# Generated at 2022-06-25 13:06:35.875877
# Unit test for function md5
def test_md5():
    assert callable(md5)

    if _md5:
        assert md5('/etc/passwd') == md5('/etc/passwd')
        assert md5('/etc/passwd') != md5('/etc/shadow')
    else:
        try:
            md5('/etc/passwd')
        except ValueError:
            return
        raise Exception('No ValueError exception thrown when MD5 is unavailable')


# Generated at 2022-06-25 13:06:36.528611
# Unit test for function md5s
def test_md5s():
    test_case_0()

# Generated at 2022-06-25 13:06:43.585478
# Unit test for function md5s
def test_md5s():
    assert(md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == 'a7c099c5832cd3fcf9d0776a1c3be18b')
    assert(md5s('ERROR: undefined variable') == 'c5b3f3b5997b588d1f8c1b2797e56614')
    assert(md5s('Request Error') == 'ba4011e9a2a8348c4ffa0bbfafdbc0ae')
    assert(md5s('TASK: [Gathering Facts] *********************************************************') == 'f16ae1dd46aa2d8edc7ab2e2b08d7395')

# Generated at 2022-06-25 13:06:50.199052
# Unit test for function md5s
def test_md5s():
    str_0 = 'i'
    var_0 = md5s(str_0)
    str_1 = 'd'
    var_1 = md5s(str_1)
    str_2 = 'u'
    var_2 = md5s(str_2)
    str_3 = 'l'
    var_3 = md5s(str_3)
    str_4 = 'e'
    var_4 = md5s(str_4)
    str_5 = 's'
    var_5 = md5s(str_5)
    str_6 = '.'
    var_6 = md5s(str_6)
    str_7 = '/'
    var_7 = md5s(str_7)
    str_8 = ' '

# Generated at 2022-06-25 13:06:56.141609
# Unit test for function checksum
def test_checksum():
    assert checksum('a') == '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8'


# Generated at 2022-06-25 13:06:59.782055
# Unit test for function md5
def test_md5():
    assert md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == '895bcaa96bfc18fd02d92f1b8d68cbd5'


# Generated at 2022-06-25 13:07:05.594978
# Unit test for function md5
def test_md5():
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    if not md5s(str_0) == '17a1657b1f3c963ee3e17d443a72beb6':
        raise AssertionError
    if not md5s(str_0) == '17a1657b1f3c963ee3e17d443a72beb6':
        raise AssertionError

# Generated at 2022-06-25 13:07:08.007821
# Unit test for function md5s
def test_md5s():
  str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
  var_1 = md5s(str_0)


# Generated at 2022-06-25 13:07:11.002711
# Unit test for function checksum
def test_checksum():
    filename = 'test_checksum_filename'
    checksum = 'test_checksum_checksum'
    var_1 = checksum(filename, checksum)
    var_2 = checksum(filename, var_1)

    # Test with content
    # Test with content



# Generated at 2022-06-25 13:07:11.724904
# Unit test for function md5
def test_md5():
    test_case_0()

# Generated at 2022-06-25 13:07:13.377739
# Unit test for function md5
def test_md5():
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_0 = md5s(str_0)

# Generated at 2022-06-25 13:07:14.137091
# Unit test for function md5s
def test_md5s():
    assert True


# Generated at 2022-06-25 13:07:21.505492
# Unit test for function md5s
def test_md5s():
    # Test with good input
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_0 = md5s(str_0)
    assert var_0 == 'ddb1f9b65e61d1dfc6e344a7e79c93f0'
    # Test with bad input
    str_0 = 's0W8TvGJHmgAKpfJgwEHFk8Dvqk3NG9Y'
    var_0 = md5s(str_0)
    assert var_0 == 'f72968c04cb9a9ddb9c26f5e5c706599'

# Generated at 2022-06-25 13:07:22.361012
# Unit test for function md5
def test_md5():
    assert (md5(filename="filename") is None)


# Generated at 2022-06-25 13:07:26.848442
# Unit test for function md5
def test_md5():
    assert (md5('string') is not None)


# Generated at 2022-06-25 13:07:29.403375
# Unit test for function md5s
def test_md5s():
    with pytest.raises(ValueError):
        assert test_case_0() == "b9f9cf0fea42f7547432c9843b3bf0ce"
    print('Test md5s passed')


# Generated at 2022-06-25 13:07:31.379841
# Unit test for function md5
def test_md5():
    assert 'c3eef8e5e5f6418b0a9d9ae4b79a4cd0' == md5('/etc/ansible')


# Generated at 2022-06-25 13:07:34.352145
# Unit test for function checksum
def test_checksum():
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'


# Generated at 2022-06-25 13:07:37.506495
# Unit test for function md5
def test_md5():
    assert md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == '8c0de23ab3d3c67cd61f858a6e7b6b80'



# Generated at 2022-06-25 13:07:40.288624
# Unit test for function md5s
def test_md5s():
    assert md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == 'f6adcfb498e2efc2da2d35791eb3a26c'

# Generated at 2022-06-25 13:07:43.462315
# Unit test for function md5s
def test_md5s():
    assert md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == '7f8a2bcda81b7f1b97bbf216d9e3a394'


# Generated at 2022-06-25 13:07:44.310750
# Unit test for function md5
def test_md5():
    test_case_0()


# Generated at 2022-06-25 13:07:46.714202
# Unit test for function checksum
def test_checksum():
    assert checksum(filename='test_file') == 'cf23df2207d99a74fbe169e3eba035e633b65d94'


# Generated at 2022-06-25 13:07:49.678629
# Unit test for function md5s
def test_md5s():
    data = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    assert md5s(data) == 'c9b7e8d6681c2bfb329ddd14edb734d8'


# Generated at 2022-06-25 13:07:54.808638
# Unit test for function md5
def test_md5():
    var = md5s('sample')
    assert var == '89e92b1c8b70f2930e5d28e22e84d4c1', 'Expected different value for md5 than what was returned'


# Generated at 2022-06-25 13:07:57.659163
# Unit test for function md5s
def test_md5s():
    var_0 = md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.')
    assert var_0 == '50b2a2fd7e17c9e9f558a52d18fc1fcf'


# Generated at 2022-06-25 13:08:06.464183
# Unit test for function checksum
def test_checksum():
    if checksum('/tmp/foo') is None:
        return
    assert checksum(u'/tmp/foo') is not None
    assert checksum(u'/tmp/foo') == checksum('/tmp/foo')
    assert checksum_s(u'foo') is not None
    assert checksum_s(b'foo') is not None
    assert checksum_s(u'foo') == md5s('foo')
    assert checksum_s(b'foo') == md5s('foo')
    assert checksum_s(u'foo') == checksum_s('foo')
    assert checksum(u'/tmp/foo') == md5('/tmp/foo')
    assert checksum(b'/tmp/foo') == md5('/tmp/foo')

# Generated at 2022-06-25 13:08:15.392849
# Unit test for function checksum
def test_checksum():
    try:
        assert checksum('/var/folders/s7/vvd22b7515n7hf1gjkgrfwbr0000gn/T/tmpE3q_bD.py') == 'f0d002cc7a0d3e57c7b2a0f8ee0493605b5bb6eb'
    except AssertionError:
        raise AssertionError('checksum did not return "f0d002cc7a0d3e57c7b2a0f8ee0493605b5bb6eb" for file "/var/folders/s7/vvd22b7515n7hf1gjkgrfwbr0000gn/T/tmpE3q_bD.py"')


# Generated at 2022-06-25 13:08:18.133102
# Unit test for function checksum
def test_checksum():
    assert checksum("") == "da39a3ee5e6b4b0d3255bfef95601890afd80709"
    assert checksum("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"


# Generated at 2022-06-25 13:08:21.439892
# Unit test for function md5s
def test_md5s():
    assert md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == 'd544aeea21a67b4751874aa1c2e3ebec'


# Generated at 2022-06-25 13:08:22.784942
# Unit test for function checksum
def test_checksum():
    var_0 = checksum('/etc/passwd', 'md5')


# Generated at 2022-06-25 13:08:26.039087
# Unit test for function md5s
def test_md5s():
    assert(md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.')) == '8e39b71c7eacc3ad04b78170be8a24a9'


# Generated at 2022-06-25 13:08:29.688390
# Unit test for function md5
def test_md5():
    try:
        md5_ret_0 = md5('/tmp/ansible_filetoupload_tXJ4C8')
    except Exception:
        md5_ret_0 = None
    assert md5_ret_0 == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-25 13:08:31.922276
# Unit test for function md5
def test_md5():
    # Test with argument = ['', '']
    # Test with argument = ['', '']

    result = md5('', '')
    # Validate type of result

    # Validate value of result



# Generated at 2022-06-25 13:08:42.511471
# Unit test for function md5
def test_md5():
    # Check that exception is raised for directory
    try:
        md5('/tmp')
    except Exception as e:
        assert e.args[0] == "file (/tmp) does not exist"

    # Check that exception is raised for missing file

# Generated at 2022-06-25 13:08:44.783590
# Unit test for function md5
def test_md5():
    assert md5(str) == '21232f297a57a5a743894a0e4a801fc3'


# Generated at 2022-06-25 13:08:48.167722
# Unit test for function checksum
def test_checksum():
    assert not checksum('/dev/null')
    assert not checksum(None)
    assert checksum(__file__) == '6e65211c718a40745d7f6c1d13716a8e2df39c25'


# Generated at 2022-06-25 13:08:50.875363
# Unit test for function md5s
def test_md5s():
    assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"


# Generated at 2022-06-25 13:08:57.548841
# Unit test for function md5
def test_md5():
    assert md5('./test/unit/utils/test_module_utils_basic.py') == '5b3c5d5f543b4c4b7a4e4a475a7b4f5c'
    assert md5('/bin/ls') == '0f83a8b094a1cf8030d1b9b21f8e1e36'
    assert md5('/bin/ls2') == None
    assert md5('/bin') == None
    assert md5('/usr/share/') == None



# Generated at 2022-06-25 13:09:03.253009
# Unit test for function md5s
def test_md5s():
    assert md5s( b'Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == 'e23e7f3d3c3a3d791907c2c9825fd081'


# Generated at 2022-06-25 13:09:04.182875
# Unit test for function md5
def test_md5():
    assert md5('filename') is None


# Generated at 2022-06-25 13:09:06.022904
# Unit test for function md5
def test_md5():
    var_0 = "test_md5"
    var_0 = md5s(var_0)

    assert var_0 == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-25 13:09:09.890177
# Unit test for function md5
def test_md5():
    # Tests for funcation md5
    str_1 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_1 = md5(str_1)
    assert var_1 == 'e6fba9e1a5ef5b5b5f5ab5a2c5d5a5a5'


# Generated at 2022-06-25 13:09:11.260695
# Unit test for function md5s
def test_md5s():
    md5s(','.join(['foo', 'bar']))


# Generated at 2022-06-25 13:09:18.961263
# Unit test for function md5
def test_md5():
    args = {}
    if not isinstance(md5('filename'), str):
        fail('Return value expected to be of type `str`')
    if not isinstance(md5('filename', 'hash_func'), str):
        fail('Return value expected to be of type `str`')


# Generated at 2022-06-25 13:09:22.538917
# Unit test for function checksum
def test_checksum():
    data = "123456789\n"
    assert checksum_s(data) == "e807f1fcf82d132f9bb018ca6738a19f"

if __name__ == '__main__':
    test_case_0()
    test_checksum()

# Generated at 2022-06-25 13:09:26.891103
# Unit test for function md5
def test_md5():
    try:
        assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    except ValueError:
        # Assume we're running in FIPS mode here
        assert False

if __name__ == '__main__':
    test_case_0()
    test_md5()

# Generated at 2022-06-25 13:09:30.158248
# Unit test for function md5s
def test_md5s():
    assert md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == '73f0a7634f2d7c4b4fe4c7f8e1c9e73b'


# Generated at 2022-06-25 13:09:32.518204
# Unit test for function md5s
def test_md5s():
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_0 = md5s(str_0)



# Generated at 2022-06-25 13:09:35.865409
# Unit test for function md5
def test_md5():
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    assert md5s(str_0) == '68e60d1c50f95d9dbc7045bc3ef23ce2'


# Generated at 2022-06-25 13:09:37.940012
# Unit test for function md5
def test_md5():
    assert md5('test.txt') == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-25 13:09:43.879158
# Unit test for function checksum
def test_checksum():
    temp_path = os.path.dirname(os.path.abspath(__file__))
    filename = temp_path + '/secure_hash_test.txt'
    fp = open(filename, 'wb')
    fp.write("""#!/usr/bin/python
print("hello world")
""".encode('utf-8'))
    fp.close()
    assert secure_hash(filename) == checksum(filename)


# Generated at 2022-06-25 13:09:46.576899
# Unit test for function md5s
def test_md5s():
    try:
        str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
        var_0 = md5s(str_0)
        assert var_0 == '8c61e9e2c60849b1db6b058dcb527c87'
    except AssertionError:
        raise


# Generated at 2022-06-25 13:09:49.373820
# Unit test for function checksum
def test_checksum():
    test_file = 'test_fixtures/ansible_test_file'
    test_sum = 'f96df6fef48c5b59d0f02c78d934e923'
    assert checksum(test_file) == test_sum



# Generated at 2022-06-25 13:09:55.364717
# Unit test for function md5
def test_md5():
    assert md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == 'dc4cf4a4a741e8b27f44d05508d6da9b'

if __name__ == '__main__':
    test_case_0()
    test_md5()

# Generated at 2022-06-25 13:10:04.737422
# Unit test for function md5
def test_md5():
    str_0 = 'an arbitrary string of text'
    var_0 = md5s(str_0)
    str_1 = 'an arbitrary string of text'
    var_1 = md5s(str_1)
    assert(var_0 == var_1)

    str_2 = 'Another string of text'
    var_2 = md5s(str_2)
    assert(var_0 != var_2)

    str_3 = 'This string is longer than the other...'
    var_3 = md5s(str_3)
    assert(var_3 != var_2)
    assert(var_3 != var_0)

    tmp = 'This is a TMPDIR file'
    fd = os.tmpfile()
    fd.write(tmp)
    fd.flush()
    f

# Generated at 2022-06-25 13:10:08.305606
# Unit test for function md5s
def test_md5s():
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_0 = checksum_s(str_0)
    assert 'd4d4e0ae0b4f8ba4a16e9abd6b47c1f8' == var_0


# Generated at 2022-06-25 13:10:11.004180
# Unit test for function md5
def test_md5():
    assert(md5('/etc/hosts') == '92f0115d5cc2e9db13b9119b88a6b7d1')


# Generated at 2022-06-25 13:10:15.810708
# Unit test for function md5
def test_md5():
    assert md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == '4e4f4c4e434947204f7074696f6e73207573' + \
    '6564,206f6e6c79206f66202d2d686f73742c202d2d6772617068206f72202d2d6c6973742063616e206275656420' + \
    '6163207468652073616d652074696d652e'



# Generated at 2022-06-25 13:10:19.692906
# Unit test for function md5s
def test_md5s():
    assert(md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == '275c469a5bd3d0d3b865b08a9bc9dceb')
    assert(md5s('ansible-playbook 2.1.1.0') == '69de2dfbb725e0fcb7961044c8b61052')

# Generated at 2022-06-25 13:10:22.681533
# Unit test for function md5s
def test_md5s():
    str_0 = 'Conflicting options used, only one of --host, --graph or --list can be used at the same time.'
    var_0 = md5s(str_0)
    assert var_0 == '0a709c1d0deccdf8baf28e85e9c61bd6'


# Generated at 2022-06-25 13:10:33.758145
# Unit test for function md5s
def test_md5s():
    assert md5s(str_0) == '0c0cec2b1a0e90f34ce1e897b6c64bcd'
    assert md5s(str_1) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(str_2) == '9e107d9d372bb6826bd81d3542a419d6'
    assert md5s(str_3) == '4a8a08f09d37b73795649038408b5f33'
    assert md5s(str_4) == 'e4d909c290d0fb1ca068ffaddf22cbd0'

# Generated at 2022-06-25 13:10:36.701279
# Unit test for function md5
def test_md5():
    assert md5s('Conflicting options used, only one of --host, --graph or --list can be used at the same time.') == 'fa6e9a8d0d6f38ae0fbaa6aabbe8b0d2'


# Generated at 2022-06-25 13:10:40.089535
# Unit test for function checksum
def test_checksum():
    #assert _md5 is not None, 'MD5 not available.  Possibly running in FIPS mode'
    assert _md5 is None, 'MD5 available.  Not running in FIPS mode'


if __name__ == '__main__':

    for i in range(0, 1000000):
        test_case_0()
    #    test_checksum()