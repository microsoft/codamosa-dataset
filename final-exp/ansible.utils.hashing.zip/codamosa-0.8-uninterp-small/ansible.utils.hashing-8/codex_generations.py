

# Generated at 2022-06-25 13:00:43.452449
# Unit test for function checksum
def test_checksum():
    filename = None
    assert checksum(filename) is None


# Generated at 2022-06-25 13:00:48.782252
# Unit test for function checksum
def test_checksum():
    str_1 = 'A'
    assert checksum(str_1) == '1fc74aafb75b7aafb31d8b03f94b00493577f8d2'

    str_2 = 'A'
    assert checksum_s(str_2) == '1fc74aafb75b7aafb31d8b03f94b00493577f8d2'



# Generated at 2022-06-25 13:00:57.607289
# Unit test for function checksum

# Generated at 2022-06-25 13:01:00.595830
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/passwd') == '9d331f9a35d223dbc5d6f8c7691b43e3'


# Generated at 2022-06-25 13:01:07.410764
# Unit test for function checksum
def test_checksum():
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'

    # Unit test for function md5
    assert md5('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

    # Unit test for function md5s
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

if __name__ == '__main__':
    test_case_0()
    test_checksum()

# Generated at 2022-06-25 13:01:09.878979
# Unit test for function checksum
def test_checksum():
    assert checksum('ansible/utils/unsafe_proxy.py') == 'd4df4ab8f1451b6f72d6c2a6a15c9f9ba6aadb89'


# Generated at 2022-06-25 13:01:10.831261
# Unit test for function md5s
def test_md5s():
    test_case_0()


# Generated at 2022-06-25 13:01:13.959959
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/bash') == '8ce1e3c3d3f0574c5a8454e72ff9c2f2'
    assert checksum('/bin/foobar') is None


# Generated at 2022-06-25 13:01:18.886659
# Unit test for function checksum
def test_checksum():
    assert md5s('-tdaq\\qt\\z G"K') == '8a7ad2d9943c1e6d2c6c1f34f05b6dbe'
    assert checksum_s('-tdaq\\qt\\z G"K') == '8a7ad2d9943c1e6d2c6c1f34f05b6dbe'


# Generated at 2022-06-25 13:01:21.861434
# Unit test for function checksum
def test_checksum():
    assert (checksum("C:\\temp\\ansible_test\\test_file.txt") == "19e1b8ed1f0e5b926eebd3cfb3c849a5")



# Generated at 2022-06-25 13:01:26.509145
# Unit test for function md5s
def test_md5s():
    str_0 = '-tdaq\\qt\\z G"K'
    assert(md5s(str_0) == 'b87a87aad09d556dafb6473c67b3a3ee')


# Generated at 2022-06-25 13:01:34.407462
# Unit test for function md5

# Generated at 2022-06-25 13:01:38.798452
# Unit test for function md5s
def test_md5s():
    assert "2d2a68bf8e8e0980b9d6c9ac6d8f0c37" == md5s("hello world")
    assert "2d2a68bf8e8e0980b9d6c9ac6d8f0c37" == md5s("hello world")
    assert "d41d8cd98f00b204e9800998ecf8427e" == md5s("")
    assert "80e88c6acfcf6c86970f0cbf71927c10" == md5s("foo bar")


# Generated at 2022-06-25 13:01:48.495541
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    data_0 = '-tdaq\\qt\\z G"K'
    data_1 = '-tdaq\qt\z G"K'
    data_2 = '"a'
    data_3 = '$|Fm>qJ:t'
    data_4 = 'j'
    data_5 = '63oI]bM|"e"Y>d=:1'
    data_6 = 'nj'
    data_7 = 'y'
    data_8 = 'Tj<H'
    data_9 = '2^N.|'
    data_10 = 'a/D'
    data_11 = '-M\n'

# Generated at 2022-06-25 13:01:54.709653
# Unit test for function md5
def test_md5():
    filename = 'test/ansible-test-inventory'
    var_0 = md5(filename)

    assert var_0 == 'a0bdbfaca1446d8d9e9b7e82e149eba2'



# Generated at 2022-06-25 13:02:00.552014
# Unit test for function md5s
def test_md5s():
    str_0 = '-tdaq\\qt\\z G"K'
    var_0 = str_0
    var_1 = '5cbf97e42e624c54d0d4987e812815c9'
    if var_0 is None:
        var_0 = md5s(str_0)
    assert var_0 == var_1,"Failed to calculate the same MD5"


# Generated at 2022-06-25 13:02:08.009169
# Unit test for function md5
def test_md5():
    # Test without argument
    try:
        md5()
    except (TypeError, ValueError) as e:
        assert "takes exactly 1 argument" in str(e)

    # Test with argument
    target_dir = os.path.dirname(os.path.realpath(__file__))
    filename = os.path.join(target_dir, "test_file_1.txt")
    md5_digest = md5(filename)
    assert md5_digest == "fc9a6d8b6a1e6e5c6b34659c8f99f358"


# Generated at 2022-06-25 13:02:11.559040
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('world') != md5s('hello')
    assert md5s('world') != 'abc'


# Generated at 2022-06-25 13:02:14.461294
# Unit test for function md5
def test_md5():
    print('Test case 0 ...')
    try:
        test_case_0()
        print("Success")
    except Exception as e:
        print("Failure: " + str(e))

# Unit test
if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-25 13:02:23.939671
# Unit test for function md5
def test_md5():
    str_1 = 'z7*4X/ JQ%c_:+#3qh'
    var_1 = checksum_s(str_1)
    str_2 = '-tdaq\\qt\\z G"K'
    var_2 = md5s(str_2)
    str_3 = 'mv-8T|#+|rC>Q2,_'
    var_3 = checksum_s(str_3)
    str_4 = '-tdaq\\qt\\z G"K'
    var_4 = md5s(str_4)
    str_5 = 'Ce&w%q3Hp5Bx1 [7]'
    var_5 = checksum_s(str_5)
    str_6 = '-tdaq\\qt\\z G"K'


# Generated at 2022-06-25 13:02:32.126063
# Unit test for function md5s
def test_md5s():
    str_0 = '-tdaq\\qt\\z G"K'
    var_0 = md5s(str_0)
    var_1 = checksum_s(str_0)
    assert var_0 == var_1

if __name__ == '__main__':
    import logging
    logging.basicConfig(level=logging.INFO)
    logging.getLogger().setLevel(logging.INFO)

# Generated at 2022-06-25 13:02:34.541499
# Unit test for function md5
def test_md5():
    str_1 = '-tdaq\\qt\\z G"K'
    var_1 = md5s(str_1)
    print(var_1)


# Generated at 2022-06-25 13:02:36.593476
# Unit test for function md5s
def test_md5s():
    assert 'c9dedec8131b5a855be7b752c0fbf5a5' == md5s('-tdaq\\qt\\z G"K')


# Generated at 2022-06-25 13:02:41.122258
# Unit test for function checksum
def test_checksum():
    assert checksum("/etc/hosts") == "0d7f07e6ef1cd6c9cc8f3d6bd1df2bca05e34c6f"


# Generated at 2022-06-25 13:02:43.863554
# Unit test for function checksum
def test_checksum():
    var_1 = 'I'
    var_2 = checksum_s(var_1)
    assert (len(var_2) == 40)


# Generated at 2022-06-25 13:02:52.483421
# Unit test for function md5
def test_md5():
    assert md5('t_file_0') == '7dac72a0a06633e88d3f9a145a0beb06'

# Generated at 2022-06-25 13:02:54.411451
# Unit test for function checksum
def test_checksum():
    str_0 = '-tdaq\\qt\\z G"K'
    var_0 = checksum_s(str_0)


# Generated at 2022-06-25 13:02:58.667131
# Unit test for function md5
def test_md5():
    '''Unit test for md5'''
    str_0 = 'tdaq\\qt\\z G"K'
    var_0 = _md5(to_bytes(str_0, errors='surrogate_or_strict'))
    var_1 = md5s(str_0)
    assert(var_0.hexdigest() == var_1)


# Generated at 2022-06-25 13:03:01.387518
# Unit test for function md5
def test_md5():
    assert(md5('/etc/passwd') == '4e4a8a0c06d6d7b50cae5d1e9d5b5c5d')


# Generated at 2022-06-25 13:03:04.796991
# Unit test for function md5s
def test_md5s():
    str_0 = '-tdaq\\qt\\z G"K'
    var_0 = md5s(str_0)
    assert '5d5e5db5f360a5c8e5b9c9bcfaeb7c77' == var_0


# Generated at 2022-06-25 13:03:10.780823
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test2') == 'e8dc4081b13434b45189a720b77b6818'


# Generated at 2022-06-25 13:03:12.305788
# Unit test for function md5s
def test_md5s():
    print('Unit test for md5s')
    test_case_0()


# Generated at 2022-06-25 13:03:15.418354
# Unit test for function checksum
def test_checksum():
    assert checksum('test/files/test.txt', hash_func=sha1) == '396db2e2d3506a9a9ca0abaa49d3eba3c08a09dc'


# Generated at 2022-06-25 13:03:18.968709
# Unit test for function md5
def test_md5():
    test_string = 'foo'
    test_sum = 'acbd18db4cc2f85cedef654fccc4a4d8'
    test_sum_func = md5s(test_string)
    assert(test_sum_func == test_sum)


# Generated at 2022-06-25 13:03:21.659811
# Unit test for function md5
def test_md5():
    data = 'foo bar'
    expected = '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s(data) == expected


# Generated at 2022-06-25 13:03:23.410421
# Unit test for function md5s
def test_md5s():
    with pytest.raises(ValueError):
        md5s('foo')


# Generated at 2022-06-25 13:03:29.730068
# Unit test for function md5
def test_md5():
    test_s = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    test_expected = '827ccb0eea8a706c4c34a16891f84e7b'
    test_actual = md5s(test_s)
    assert test_actual == test_expected, 'Expected "%s", got "%s"' % (test_expected, test_actual)



# Generated at 2022-06-25 13:03:38.994736
# Unit test for function md5s
def test_md5s():
    assert(md5s('') == 'd41d8cd98f00b204e9800998ecf8427e')
    assert(md5s('The quick brown fox jumps over the lazy dog') == '9e107d9d372bb6826bd81d3542a419d6')
    assert(md5s('The quick brown fox jumps over the lazy dog.') == 'e4d909c290d0fb1ca068ffaddf22cbd0')
    assert(md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592')
    assert(md5s(b'hello\xa2') == 'a4a4aefb4d52e7a923c1bfbbd67dac46')

# Generated at 2022-06-25 13:03:40.615859
# Unit test for function md5
def test_md5():
    assert '912ec803b2ce49e4a541068d495ab570' == md5('test/data/file1')


# Generated at 2022-06-25 13:03:46.400454
# Unit test for function md5
def test_md5():
    try:
        assert str(md5('t.txt')) == 'd41d8cd98f00b204e9800998ecf8427e'
    except AssertionError:
        raise AssertionError("Expected md5('t.txt') to be d41d8cd98f00b204e9800998ecf8427e")
    except ValueError as e:
        if str(e) != 'MD5 not available.  Possibly running in FIPS mode':
            raise e


# Generated at 2022-06-25 13:03:51.184249
# Unit test for function md5
def test_md5():
    assert md5('test/files/test.txt') == '8a9c06e5bf1a5e5cf5ea5e305f2a28d5'


# Generated at 2022-06-25 13:03:55.032184
# Unit test for function md5
def test_md5():
    assert(md5s(test_case_0) == '912ec803b2ce49e4a541068d495ab570')
    assert(md5(test_case_0) == '912ec803b2ce49e4a541068d495ab570')



# Generated at 2022-06-25 13:03:57.834092
# Unit test for function checksum
def test_checksum():
    str_0 = 'test/files/test.txt'
    md_0 = 'dc96e9bf9b1c1548d6fdf1cbec342bff'
    assert checksum(str_0) == md_0


# Generated at 2022-06-25 13:04:00.589492
# Unit test for function md5s
def test_md5s():
    path = 'test/files/test.txt'
    assert '58b9d60b2ea37b8e839d6f085aac4526' == md5s(path)


# Generated at 2022-06-25 13:04:04.061319
# Unit test for function md5
def test_md5():
    print("Test that %s produces correct checksum" % test_case_0.__name__)
    assert md5(str_0) == '3c5f5d5b821f16d724c5f08bdfd8be8b'


# Generated at 2022-06-25 13:04:06.575232
# Unit test for function md5s
def test_md5s():
    # str -> str
    assert md5s('test/files/test.txt') == '78ef0caea1b6aadf6f54b6a1c6a249e6'


# Generated at 2022-06-25 13:04:09.143252
# Unit test for function md5s
def test_md5s():
    assert md5s('test/files/test.txt') == 'bf24f3ac3a6a79a6a0f71e3cc3e7e3c8'


# Generated at 2022-06-25 13:04:11.410776
# Unit test for function md5
def test_md5():
    assert md5(str_0) == 'd8e8fca2dc0f896fd7cb4cb0031ba249'


# Generated at 2022-06-25 13:04:14.410769
# Unit test for function md5
def test_md5():
    assert callable(md5)
    assert md5('test/files/test.txt') == 'a3f59c7d8a67ec1a7bef93a914d7e8f8'


# Generated at 2022-06-25 13:04:17.439985
# Unit test for function md5
def test_md5():
    filename = test_case_0()

    assert md5(filename) == 'e255221457f8efb7d0d1a82c7a3bcb5f'


# Generated at 2022-06-25 13:04:23.382274
# Unit test for function checksum
def test_checksum():
    ''' Assert that the checksum of the specified file is correct '''
    str_1 = 'test/files/test.txt'
    str_2 = '5fbd56848a466a5c5a5f5d36cb9fbe2f'
    assert checksum(str_1) == str_2

# Generated at 2022-06-25 13:04:27.344532
# Unit test for function checksum
def test_checksum():
    file_0 = '/etc/passwd'
    print(checksum(file_0))
    print(checksum_s(file_0))
    #test_case_0()

test_checksum()

# Generated at 2022-06-25 13:04:33.309856
# Unit test for function md5s
def test_md5s():
    assert '6a20f3ef1f442e9e8a2ccebfb3c87e80' == md5s('test/files/test.txt')
    assert 'd41d8cd98f00b204e9800998ecf8427e' == md5s('')
    assert '74c51fa9a04a03deec665a996d049a8a' == md5s('This is a very short file.\n')


# Generated at 2022-06-25 13:04:36.538264
# Unit test for function md5s
def test_md5s():
    string_0 = 'test'
    # Should return the md5 of 'test'
    assert md5s(string_0) == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-25 13:04:38.995601
# Unit test for function md5
def test_md5():
   assert md5(test_case_0()) == 'd41d8cd98f00b204e9800998ecf8427e'

 # Unit test for function md5s

# Generated at 2022-06-25 13:04:47.537441
# Unit test for function checksum
def test_checksum():
    test_case_0()
    assert os.path.isfile(str_0) == True
    output_0 = checksum(str_0)
    assert output_0 == '967f355f08e9b0a8ab0f210b7ffd69de'
    assert output_0 == '967f355f08e9b0a8ab0f210b7ffd69de'
    assert output_0 == '967f355f08e9b0a8ab0f210b7ffd69de'
    assert output_0 == '967f355f08e9b0a8ab0f210b7ffd69de'
    assert output_0 == '967f355f08e9b0a8ab0f210b7ffd69de'

# Generated at 2022-06-25 13:04:50.764685
# Unit test for function checksum
def test_checksum():
    actual = checksum('./test/files/test.txt')
    expected = 'f9b48e9e9c2b2fc8d817f3ff3b6e3d2a7b8f5250'
    assert actual == expected, 'Test failed: expected "{0}", got "{1}"'.format(expected, actual)


# Generated at 2022-06-25 13:04:53.350832
# Unit test for function md5
def test_md5():
    assert md5('/etc/hosts') == '611b2416e4d4b11dd1f7cc17f3d33fac'


# Generated at 2022-06-25 13:04:56.871287
# Unit test for function md5s
def test_md5s():
    assert md5s('test/files/test.txt') == 'ae7a44664c9a2cf43e8c8d2d08a0c11a'


# Generated at 2022-06-25 13:04:59.172710
# Unit test for function md5
def test_md5():
    assert md5('test/files/test.txt') == md5('test/files/test.txt')



# Generated at 2022-06-25 13:05:04.337573
# Unit test for function md5s
def test_md5s():
    assert md5s('test/files/test.txt') == 'f6aebeed6e5d6ab2c0f22f8d1b30ba7b'


# Generated at 2022-06-25 13:05:07.800859
# Unit test for function checksum
def test_checksum():
    str_0 = 'test/files/test.txt'
    assert checksum(str_0) == 'e7cfb8edbef0c1a1da19a0cfe7840b86e9e25a88'


# Generated at 2022-06-25 13:05:08.634491
# Unit test for function md5s
def test_md5s():
    assert type(md5s) == type(test_case_0)


# Generated at 2022-06-25 13:05:19.458852
# Unit test for function md5s
def test_md5s():
    str_0 = 'test/files/test.txt'
    str_1 = 'test/files/test_dir/'
    # str_2 = 'test/files/test_link'
    str_3 = 'test/files/test_broken_link'
    # str_4 = 'test/files/test_hosts'
    str_5 = 'test/files/test_hosts/hosts'
    str_6 = 'test/files/test_hosts/hosts/'
    str_7 = 'test/files/test_hosts/hosts/file'
    str_8 = 'test/files/test_hosts/hosts/file/'
    str_9 = 'test/files/test_hosts/hosts/file/file.txt'

# Generated at 2022-06-25 13:05:21.512288
# Unit test for function md5
def test_md5():
    assert md5('test/files/test.txt') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-25 13:05:28.793803
# Unit test for function md5s
def test_md5s():
    str_0 = 'test/files/test.txt'
    int_0 = 884
    int_1 = 884
    int_2 = 884
    int_3 = 884
    str_1 = 'test/files/test.txt'
    str_2 = 'test/files/test.txt'
    str_3 = 'test/files/test.txt'
    str_4 = 'test/files/test.txt'
    str_5 = 'test/files/test.txt'
    str_6 = 'test/files/test.txt'
    str_7 = 'test/files/test.txt'
    str_8 = 'test/files/test.txt'
    str_9 = 'test/files/test.txt'
    str_10 = 'test/files/test.txt'
    str

# Generated at 2022-06-25 13:05:32.287404
# Unit test for function md5
def test_md5():
    try:
        res = secure_hash('test/files/test.txt', _md5)
        print ( "res: {}".format(res))
        
    except Exception as e:
        print ( "e: {}".format(e))



# Generated at 2022-06-25 13:05:37.015915
# Unit test for function md5
def test_md5():
    assert md5('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5('test/files/test.txt') == '7e240de74fb1ed08fa08d38063f6a6a9'
    assert md5('/usr') == 'b3a8e026d7b901dfc1fefa5a5f8de051'


# Generated at 2022-06-25 13:05:38.416449
# Unit test for function md5s
def test_md5s():
    str_0 = 'test/files/test.txt'
    md5s(str_0)


# Generated at 2022-06-25 13:05:40.481117
# Unit test for function checksum
def test_checksum():
    assert checksum(str_0) == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-25 13:05:46.157644
# Unit test for function md5s
def test_md5s():
    str_0 = 'test/files/test.txt'
    assert md5s(str_0) == 'd88f2a856d42b1c6f9e7d1fd6db2fd7f'


# Generated at 2022-06-25 13:05:50.345567
# Unit test for function md5s
def test_md5s():
    str_0 = 'test/files/test.txt'
    hash_value_md5 = 'a971158c1bfb108ca5f5fc5a5ae1d5af'
    result_md5s = md5s(str_0)
    assert result_md5s == hash_value_md5


# Generated at 2022-06-25 13:05:52.401535
# Unit test for function md5
def test_md5():
    assert md5(str_0) == 'c4fa4aaae8b1de9d2e68c717ef09a8d6'


# Generated at 2022-06-25 13:06:00.717803
# Unit test for function md5s
def test_md5s():
    file_1 = 'test/files/test.txt'
    file_2 = 'test/files/test_missing_in_path.txt'

    str_1 = 'test/files/test.txt'
    str_2 = 'test/files/test_missing_in_path.txt'
    md5s(file_1)
    md5s(file_2)
    md5s(str_1)
    md5s(str_2)
    #md5s(None)
    return 'no_fail'


# Generated at 2022-06-25 13:06:05.250813
# Unit test for function md5
def test_md5():
    assert os.path.exists(str_0)
    assert os.path.isfile(str_0)
    assert (md5(str_0) == '3f74f100c141d5e5b5c5f5fb11c5d5b5')


# Generated at 2022-06-25 13:06:07.988735
# Unit test for function md5s
def test_md5s():
    data = 'test string'
    result = md5s(data)

    assert result == 'ae2b1fca515949e5d54fb22b8ed95575'


# Generated at 2022-06-25 13:06:10.214772
# Unit test for function md5
def test_md5():
    file = to_bytes('test/files/test.txt', errors='surrogate_or_strict')
    assert(md5(file))


# Generated at 2022-06-25 13:06:13.067346
# Unit test for function md5s
def test_md5s():
    str_0 = 'test/files/test.txt'
    str_ret_0 = '4c03bb1f444de58589a8a8a77a21d972'
    assert md5s( str_0 ) == str_ret_0



# Generated at 2022-06-25 13:06:15.433128
# Unit test for function md5s
def test_md5s():
    assert md5s('test/files/test.txt') == '0b26f00cb0f42d10784b82d8f973d2e2'


# Generated at 2022-06-25 13:06:17.638187
# Unit test for function md5
def test_md5():
    assert secure_hash('test/files/test.txt', hash_func=_md5) == md5('test/files/test.txt')



# Generated at 2022-06-25 13:06:22.179936
# Unit test for function checksum
def test_checksum():
    str_0 = 'test/files/test.txt'
    assert (checksum(str_0) == md5(str_0))


# Generated at 2022-06-25 13:06:26.261863
# Unit test for function checksum
def test_checksum():
    str_0 = 'test/files/test.txt'
    assert checksum(str_0) == 'd14cb716cdc921d56b1a0b281a60f982c8b3319f'


# Generated at 2022-06-25 13:06:34.745928
# Unit test for function md5
def test_md5():
    md5_hash_output = md5('test/files/test.txt')
    # Test for the path exists.
    assert os.path.exists('test/files/test.txt')
    # Test if the file is not a directory
    assert not os.path.isdir('test/files/test.txt')
    # Test the md5 checksum function should return a MD5 hash.
    assert isinstance(md5_hash_output, str)
    # Test if the length of the checksum is 32.
    assert len(md5_hash_output) == 32
    # Test for the return value of the MD5 checksum value is correct.
    assert md5_hash_output == '5712e30a33c1c8fe44fc0b77cb53b04a'



# Generated at 2022-06-25 13:06:40.575229
# Unit test for function md5
def test_md5():
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    with tempfile.NamedTemporaryFile() as testfile:
        testfile.write(b'hello world')
        testfile.flush()
        testfile.seek(0)

        with tempfile.NamedTemporaryFile() as otherfile:
            # I don't know a better way to set these variables
            module = AnsibleModule(
                argument_spec=dict(),
                supports_check_mode=False,
                bypass_checks=False
            )
            module.params['path'] = testfile.name

            module.run_command = lambda *args, **kwargs: (0, "", "")
            module.run_command_environ_update = {}

            md5_val = md5(module.params['path'])

# Generated at 2022-06-25 13:06:43.735749
# Unit test for function md5
def test_md5():
    if _md5:
        assert md5('test/files/test.txt') == '098f6bcd4621d373cade4e832627b4f6', 'Wrong md5 hash value returned'


# Generated at 2022-06-25 13:06:46.068057
# Unit test for function md5
def test_md5():
    assert '2e1a5c1e73e83b50c0a74b03bdc6f17a' == md5(test_case_0())


# Generated at 2022-06-25 13:06:48.063352
# Unit test for function checksum
def test_checksum():
    # Test for simple case
    assert checksum(test_case_0()) == 'b95adc6ee12a2c8d6f4b4a4a9a98d6c8'

# Generated at 2022-06-25 13:06:50.873939
# Unit test for function md5
def test_md5():
    #print('Testing md5()')
    assert md5(str_0)=='827ccb0eea8a706c4c34a16891f84e7b', 'md5() failed'


# Generated at 2022-06-25 13:06:54.387596
# Unit test for function md5
def test_md5():
    print(md5('test/files/test.txt')) # md5 is not FIPS compliant



# Generated at 2022-06-25 13:06:56.832564
# Unit test for function md5s
def test_md5s():

    test_cases = ['test_case_0']
    for test_case in test_cases:
        test_case_0()
        assert 1 == 1



# Generated at 2022-06-25 13:07:06.882910
# Unit test for function checksum
def test_checksum():
    try:
        temp_0 = checksum('test/files/test.txt')
        assert(temp_0 == 'b1fd8edf2708cb62f3da81f0905f34ba1b77a2f0')
    except AssertionError:
        raise AssertionError('assertion failed')
    except Exception:
        raise AssertionError('exception raised')


# Generated at 2022-06-25 13:07:08.959029
# Unit test for function md5s
def test_md5s():
    input = 'asdfasdf'
    out = md5s(input)
    assert len(out) == 32
    assert out == '4f4b6f1d1795d0db81cbc9bc9f16d1d8'



# Generated at 2022-06-25 13:07:10.615594
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-25 13:07:13.799297
# Unit test for function md5
def test_md5():
    str_0 = 'test_files/test.txt'
    fd_0 = open(str_0, 'r')
    assert md5(fd_0) == '5f5f5d359c5a047e0a9c9ef99f0b2f1a'
    fd_0.close()


# Generated at 2022-06-25 13:07:18.137085
# Unit test for function md5s
def test_md5s():
    str_0 = 'test/files/test.txt'
    hash_0 = 'f4e5f87c92e6020a9f0eb11c6a12d2e2'

    assert md5(str_0) == hash_0, \
        'md5 of %s should return %s, instead returned %s' % \
        (str_0, hash_0, md5(str_0))


# Generated at 2022-06-25 13:07:20.846517
# Unit test for function md5
def test_md5():
    from os import getcwd

    str_0 = 'test/files/test.txt'
    md5_0 = os.path.join(getcwd(), str_0)
    str_1 = '49c6bbb4874f2c6e7e1c8ca6708306f6'
    str_2 = md5(md5_0)
    assert str_1 == str_2


# Generated at 2022-06-25 13:07:23.204289
# Unit test for function md5s
def test_md5s():
    # Verify that `data` is not changed by md5s
    data = 'test/files/test.txt'
    assert(md5s(data) == md5s(data))
    # Verify that `filename` is not changed by md5
    filename = 'test/files/test.txt'
    assert(md5(filename) == md5(filename))

test_case_0()
test_md5s()

# Generated at 2022-06-25 13:07:25.703296
# Unit test for function md5s
def test_md5s():
    data = 'test/files/test.txt'
    assert md5s(data) == 'e9a967b51a37a0a83f21fa8a8a1e23ef', 'Test md5s Failed!'


# Generated at 2022-06-25 13:07:27.666377
# Unit test for function md5
def test_md5():
    assert md5('test/files/test.txt') == 'c11b7572dbb374d55eeeec2aeb44c0ba'


# Generated at 2022-06-25 13:07:29.043146
# Unit test for function md5
def test_md5():
    ret_1 = md5(str_0)
    print(ret_1)


# Generated at 2022-06-25 13:07:40.366521
# Unit test for function checksum
def test_checksum():
    # Test normal operation
    digest = secure_hash('test/files/test.txt')
    assert digest == 'f6e49a6a66b6a3f6e3b91a1b6d916f6caf6e3f5d'

    # Test failure cases (file not found, directory path, etc.)
    assert secure_hash('') is None
    assert secure_hash('fakefile') is None
    assert secure_hash('/bin', _md5) is None
    assert secure_hash('/bin', _md5) is None


# Generated at 2022-06-25 13:07:43.229366
# Unit test for function md5s
def test_md5s():
    print('Testing md5s')

    assert(md5s('test/files/test.txt') == '27d43b7e4d9c4e7ec201b73c1b59f57b')


# Generated at 2022-06-25 13:07:45.409394
# Unit test for function md5
def test_md5():
    assert md5('test/files/test.txt') == '6ab3b9e1b4c8b4eb6130520c3f87ceb7'


# Generated at 2022-06-25 13:07:47.780991
# Unit test for function md5s
def test_md5s():
    assert md5s(test_case_0) == 'cce903b56a7b2c42b8e7ab4a4f4d1b73'


# Generated at 2022-06-25 13:07:50.470216
# Unit test for function checksum
def test_checksum():
    str_0 = 'test/files/test.txt'
    str_1 = '1c8b8a21f0ff4d2e4f39afe4c841f663bcd7c1f0'
    assert(checksum(str_0, sha1) == str_1)


# Generated at 2022-06-25 13:07:52.367750
# Unit test for function md5s
def test_md5s():
    str_0 = 'test/files/test.txt'
    assert md5s(str_0) == secure_hash_s(str_0, _md5)


# Generated at 2022-06-25 13:07:54.259998
# Unit test for function md5s
def test_md5s():
    str_0 = 'test/files/test.txt'
    assert(md5s(str_0) == md5s(str_0))


# Generated at 2022-06-25 13:07:55.001638
# Unit test for function md5
def test_md5():
    pass


# Generated at 2022-06-25 13:08:00.598794
# Unit test for function checksum
def test_checksum():
    ''' Tests the "checksum" function '''
    str_0 = 'test/files/test.txt'
    str_1 = 'sha1'
    str_2 = '3d9f02813c032031bbde29a7b3a3d3f7b8a9baf0'
    if secure_hash(str_0) != str_2:
        print( secure_hash(str_0))
        print( str_2)
        raise Exception( "FAILED: secure_hash()")
    if secure_hash(str_0, hash_func=sha1()) != str_2:
        print( secure_hash(str_0, hash_func=sha1()))
        print( str_2)
        raise Exception( "FAILED: secure_hash()")

# Generated at 2022-06-25 13:08:02.926521
# Unit test for function md5
def test_md5():
    assert md5('test/files/test.txt') == 'e2a85e80c9f964e8fdb50dcf7a4c4e4f'


# Generated at 2022-06-25 13:08:11.268484
# Unit test for function md5s
def test_md5s():
    assert md5s('-tdaq\\qt\\z G"K') == 'b9a864d5ddbbb6497c8b8f612fd7c635'



# Generated at 2022-06-25 13:08:14.608584
# Unit test for function checksum
def test_checksum():
    str_0 = '-tdaq\\qt\\z G"K'
    var_0 = checksum(str_0)
    assert var_0 == '9b9c79a8d65246367c3f3ba3a3e55a2405d847c7'


# Generated at 2022-06-25 13:08:15.581157
# Unit test for function md5
def test_md5():
    test_case_0()


# Generated at 2022-06-25 13:08:16.849908
# Unit test for function md5
def test_md5():
    assert md5("/etc/passwd") == "12a6abb9c6f44d8acddab6e3bada38ae"


# Generated at 2022-06-25 13:08:18.087335
# Unit test for function checksum
def test_checksum():
    assert(checksum_s(None) == 'da39a3ee5e6b4b0d3255bfef95601890afd80709')
    assert(checksum(None) == None)


# Generated at 2022-06-25 13:08:22.001279
# Unit test for function md5s
def test_md5s():
    str_0 = '-tdaq\\qt\\z G"K'
    var_0 = md5s(str_0)
    assert var_0 == "c1b0dc7a39a1d35a8f2c0a53a0f946dd"


# Generated at 2022-06-25 13:08:24.334560
# Unit test for function md5
def test_md5():
    print('test_md5')
    filename = 'test'
    print(md5(filename))

# Unit test function

# Generated at 2022-06-25 13:08:26.475801
# Unit test for function checksum
def test_checksum():
    assert checksum('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert checksum_s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert checksum('foo') == checksum_s('foo')
    assert len(checksum('foo')) == 32



# Generated at 2022-06-25 13:08:36.258183
# Unit test for function md5
def test_md5():
    assert md5('test_utils__test_basic.py') == '69d070d00f723a22c8bb64d7a0fcfc40', 'test_utils__test_basic.py'
    assert md5('test_utils__test_command.py') == '6e9b6e27e6ea32d39ba14be0d0b6fbed', 'test_utils__test_command.py'
    assert md5('test_utils__test_crypto.py') == '8a227a1f5d2a5a9a5e8c94fce7ca6e76', 'test_utils__test_crypto.py'

# Generated at 2022-06-25 13:08:39.148772
# Unit test for function md5s
def test_md5s():
    r = md5s('The quick brown fox jumps over the lazy dog.')
    assert r == '9e107d9d372bb6826bd81d3542a419d6'


# Generated at 2022-06-25 13:08:48.167675
# Unit test for function checksum
def test_checksum():
    assert checksum('/Users/michael/Documents/ansible/lib/ansible/modules/core/command.py') == '34b057633e7dcc6f19e24bcc8f1c9369c5a6ddc0'


# Generated at 2022-06-25 13:08:53.635433
# Unit test for function checksum
def test_checksum():
    str_0 = 'dummy.txt'
    var_0 = checksum(str_0)
    assert var_0 == '87f80e2ddf0088e90b2564fbeb32b3e3', "Expected %s. Got %s instead." % ('87f80e2ddf0088e90b2564fbeb32b3e3', var_0)


# Generated at 2022-06-25 13:09:01.982937
# Unit test for function md5
def test_md5():
    # This test is to make sure the md5 function is stable and consistent across all platforms.
    # This was added in response to ticket #25513
    # Generate test input data
    str_1 = '-tdaq\\qt\\z G"K'
    str_2 = '2\\{ZR\\x1e\\x0b\\x15\\t\\x15\\x1e\\x02\\x18\\'
    str_3 = '\\x0c\\x1b\\x1bR\\x02\\x1c\\x1fd\\xf0*\\xa0'
    str_4 = '\\x80\'\\xa9\\xe9\\xce\\xc2\\x98+\\x15o\\x00'

# Generated at 2022-06-25 13:09:09.413596
# Unit test for function md5s
def test_md5s():
    str_0 = '?\\D25$:&<~Kr-0}#,c.ysBm_{tb=dt|O1&R'
    var_0 = md5s(str_0)
    # Expected Value: '8c7fef9cc6f2c1d3a3c8fa6b28a1a40d'
    assert var_0 == '8c7fef9cc6f2c1d3a3c8fa6b28a1a40d'
    test_case_0()


# Generated at 2022-06-25 13:09:13.418447
# Unit test for function md5s
def test_md5s():
    try:
        assert md5s(str_0) == '00b749e51d835f3d3c9a0613f7c74f9a'
    except AssertionError as e:
        print("Test md5s failed, got error: ", e)


# Generated at 2022-06-25 13:09:15.456366
# Unit test for function checksum
def test_checksum():
    str_0 = '-tdaq\\qt\\z G"K'
    var_0 = checksum_s(str_0)


# Generated at 2022-06-25 13:09:18.054909
# Unit test for function md5
def test_md5():
    data = "abcd"
    assert md5s(data) == "e2fc714c4727ee9395f324cd2e7f331f"


# Generated at 2022-06-25 13:09:19.710791
# Unit test for function md5s
def test_md5s():
    """ Testing a unit. """
    test_case_0()

# Generated at 2022-06-25 13:09:20.972801
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/passwd') != None


# Generated at 2022-06-25 13:09:24.393264
# Unit test for function md5s
def test_md5s():
    data = '-tdaq\\qt\\z G"K'
    expected = 'd74b1c6a8fcbf70b98fd000b9fdfd8c8'
    assert md5s(data) == expected


# Generated at 2022-06-25 13:09:30.971349
# Unit test for function md5
def test_md5():
    assert md5s('str') == '9e107d9d372bb6826bd81d3542a419d6'



# Generated at 2022-06-25 13:09:34.482055
# Unit test for function md5s
def test_md5s():
    str_0 = '-tdaq\\qt\\z G"K'
    var_0 = md5s(str_0)
    assert var_0 == '6e423f6a58bd0d90339905c44e720111'


# Generated at 2022-06-25 13:09:36.858765
# Unit test for function md5s
def test_md5s():
    assert md5s('-tdaq\\qt\\z G"K') == 'aa7f6d8325d0dce6b916bb36c359d734'

test_case_0()

# Generated at 2022-06-25 13:09:42.548676
# Unit test for function md5s
def test_md5s():
    assert md5s('-tdaq\\qt\\z G"K') == 'a3b9a8f1fc9d80a96ca2e48129f0086c'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-25 13:09:43.877919
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/passwd') is not None


# Generated at 2022-06-25 13:09:44.707196
# Unit test for function md5
def test_md5():
    test_case_0()


# Generated at 2022-06-25 13:09:55.468294
# Unit test for function md5s
def test_md5s():
    assert md5s("") == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s("a") == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s("abc") == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s("message digest") == 'f96b697d7cb7938d525a2f31aaf161d0'
    assert md5s("abcdefghijklmnopqrstuvwxyz") == 'c3fcd3d76192e4007dfb496cca67e13b'

# Generated at 2022-06-25 13:09:59.181399
# Unit test for function md5s
def test_md5s():
    str_0 = '-tdaq\\qt\\z G"K'
    var_0 = secure_hash_s(str_0, _md5)
    assert var_0 == 'aecef6aee3b698d64ea3c839da24d746'


# Generated at 2022-06-25 13:10:02.131072
# Unit test for function md5
def test_md5():
    test_string = 'The quick brown fox jumps over the lazy dog'
    result = secure_hash_s(test_string, _md5)
    assert result == md5s(test_string)


# Generated at 2022-06-25 13:10:04.204912
# Unit test for function checksum
def test_checksum():
    str_0 = '-tdaq\\qt\\z G"K'
    var_0 = md5s(str_0)


# Generated at 2022-06-25 13:10:11.383776
# Unit test for function checksum
def test_checksum():

    print(secure_hash('/etc/hosts'))
    print(secure_hash_s('abc'))
    print(md5s('abc'))



# Generated at 2022-06-25 13:10:13.134757
# Unit test for function md5
def test_md5():
    assert md5("/etc/hosts") == "9fe9a6aa68f7a5a6bde06c7ac79abd32"


# Generated at 2022-06-25 13:10:16.021251
# Unit test for function md5s
def test_md5s():
    # Verify that md5s returns the expected value for the following inputs
    str_0 = '-tdaq\\qt\\z G"K'
    var_0 = md5s(str_0)

    assert var_0 == 'b4a4f4cc4e50c8d99a0dc14a56e3ba3b'

# Generated at 2022-06-25 13:10:19.164751
# Unit test for function md5s
def test_md5s():
    str_0 = '-tdaq\\qt\\z G"K'
    var_0 = md5s(str_0)

    assert var_0  == '5852c6508f50686e3c0ce3e71d9b9ed9', 'Expected different hash value'



# Generated at 2022-06-25 13:10:20.771245
# Unit test for function md5s
def test_md5s():
    assert 'f20e532a2d82e6412822cc0f84a794b3' == md5s('-tdaq\\qt\\z G"K')

# Generated at 2022-06-25 13:10:23.686982
# Unit test for function md5
def test_md5():
    assert(md5('file1') == 'f1cc9170c2c91929ab078e7cfc1f4653')
    assert(md5('file2') == 'cf48f6c75b5a3b1d5c8d69bb5a547acf')


# Generated at 2022-06-25 13:10:34.747236
# Unit test for function md5s
def test_md5s():
    assert md5s('-tdaq\\qt\\z G"K') == 'ccc7d0e65e9b734e11a8c097d4f4c1d0'

    #val:str = '-tdaq\\qt\\z G"K'
    #assert md5s(val) == 'ccc7d0e65e9b734e11a8c097d4f4c1d0'
    #assert md5s('dokem-yvn1') == '1b4d4d4c58c010dc81847c5e9d269462'
    #assert md5s('cyfrif-bedw') == 'ffcc0f8a6c298a9357c708980b678a81'
    #assert md5s('wryw-br

# Generated at 2022-06-25 13:10:41.667106
# Unit test for function md5
def test_md5():
    # Test case #0, with
    # str_0 = '-tdaq\\qt\\z G"K'
    str_0 = '-tdaq\\qt\\z G"K'
    var_0 = md5(str_0)
    assert var_0 == "aa2b6c0e6b0d7d8411a3e3a3b8e07aa6"
    # Test case #1, with
    # str_0 = '^sG<j'
    str_0 = '^sG<j'
    var_0 = md5(str_0)
    assert var_0 == "a4a1ea4d4a6f9a9f05b849b5f5d5e5cb"
    # Test case #2, with
    # str_0 = 'J\\