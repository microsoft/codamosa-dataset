

# Generated at 2022-06-25 13:00:38.012297
# Unit test for function checksum
def test_checksum():
    # Stub
    pass


# Generated at 2022-06-25 13:00:39.281883
# Unit test for function checksum
def test_checksum():
  # tests for ints
  checksum_s(-374)


# Generated at 2022-06-25 13:00:43.146307
# Unit test for function md5
def test_md5():
    filename = "test_file"
    md5s = md5(filename)
    print(md5s)


# Generated at 2022-06-25 13:00:46.413766
# Unit test for function md5
def test_md5():
    print("in md5 test")
    # test case 0
    int_0 = 37
    try:
        var_0 = md5(int_0)
    except ValueError:
        print("exception")


# Generated at 2022-06-25 13:00:47.689434
# Unit test for function checksum
def test_checksum():
    print(checksum('/etc/hosts'))


# Generated at 2022-06-25 13:00:51.025210
# Unit test for function checksum
def test_checksum():
    filename = "hello.py"
    check = secure_hash(filename,sha1)
    print("SHA1 checksum: ")
    print(check)


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-25 13:00:54.808209
# Unit test for function checksum
def test_checksum():
    data = """{
    "changed": false,
    "ping": "pong"
}"""
    assert checksum_s(data) == "c7f3ab3d106f7695bdb6525f2468a2cd1ae9fba9", "test_checksum: test 0 failed"


# Generated at 2022-06-25 13:00:58.136739
# Unit test for function checksum
def test_checksum():
    filename = "unittest"
    checksum = secure_hash(filename)
    print("checksum: ", checksum)


# Generated at 2022-06-25 13:01:07.717847
# Unit test for function md5
def test_md5():
    int_0 = 10
    var_0 = md5s(int_0)
    assert var_0 == "201aa2545c2f6b5a6a5d6e5a6a5d6e5a6a5d6e5a"
    int_1 = bytearray([1, 2])
    var_1 = md5s(int_1)
    assert var_1 == "201aa2545c2f6b5a6a5d6e5a6a5d6e5a6a5d6e5a"
    int_2 = "10"
    var_2 = md5(int_2)

# Generated at 2022-06-25 13:01:11.454808
# Unit test for function md5s
def test_md5s():
    # int -> str, hex
    int_0 = -374
    var_0 = md5s(int_0)
    assert var_0 == '1f35b64ba7b8c79b1a2d2a79abf00f2d'


# Generated at 2022-06-25 13:01:15.916773
# Unit test for function md5
def test_md5():
    int_0 = -37
    assert md5_s(int_0) == 'ee11cbb19052e40b07aac0ca060c23ee'


# Generated at 2022-06-25 13:01:18.016635
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/hosts') == '9423095d04f2a9d312e869c14dcd47aa'


# Generated at 2022-06-25 13:01:26.195139
# Unit test for function md5
def test_md5():
    #
    # Data needs to be exactly one block of 64 bytes (512 bits).
    #
    data = '\x11\x22' * 32
    expect = 'a3e340a1b0e8d9fd9fcb1e62f112e045'
    got = md5s(data)
    if expect != got:
        print('expected: %s' % expect)
        print('got:      %s' % got)
        raise Exception('unexpected md5 result')
    #
    # Data needs to be exactly one block of 64 bytes (512 bits).
    #
    data = '\x33\x44' * 32
    expect = 'a3e340a1b0e8d9fd9fcb1e62f112e045'
    got = md5s(data)

# Generated at 2022-06-25 13:01:28.881968
# Unit test for function md5
def test_md5():
    var_1 = md5("test")
    var_2 = md5("test")
    assert var_1 == var_2, "md5() didn't return the correct string."


# Generated at 2022-06-25 13:01:31.506432
# Unit test for function md5
def test_md5():
    data = 'This is a test string'
    assert md5s(data) == 'e9cb9b360e0b8c2307faec1e16d0460b'
    assert md5('/etc/hosts') == '08f95eb837c72b2f3931a76f7d32b8c8'

if __name__ == '__main__':
    test_case_0()
    test_md5()

# Generated at 2022-06-25 13:01:36.376713
# Unit test for function md5
def test_md5():
    int_0 = -374
    var_0 = secure_hash_s(int_0)
    return var_0


# Generated at 2022-06-25 13:01:46.715025
# Unit test for function checksum
def test_checksum():
    assert checksum("") == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum("abc") == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum(u"abc") == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum("abcdefghijklmnop") == '32d10c7b8cf96570ca04ce37f2a19d84240d3a89'

# Generated at 2022-06-25 13:01:52.206613
# Unit test for function checksum
def test_checksum():
    assert (checksum(filename="<string>") is None)
    assert (checksum(filename="/etc/passwd") == "66985d90e7b759a92e73f2bd9c35da0a")
    assert (checksum(filename="/etc/passwd", hash_func=sha1) == "66985d90e7b759a92e73f2bd9c35da0a")


# Generated at 2022-06-25 13:01:59.533136
# Unit test for function md5
def test_md5():
    if not _md5:
        # This test will fail if the system is FIPS-140 compliant.
        # Re-enable it when FIPS compatibility is re-added.
        # assert md5('To Be or not to be!') == '1d8bf2f13b53957c1b516d0e8ba89049'
        return
    assert md5('To Be or not to be!') == '1d8bf2f13b53957c1b516d0e8ba89049'



# Generated at 2022-06-25 13:02:00.507186
# Unit test for function md5s
def test_md5s():
    test_case_0()


# Generated at 2022-06-25 13:02:05.953637
# Unit test for function md5s
def test_md5s():
    int_0 = -374
    var_0 = md5s(int_0)
    # print var_0
    assert var_0 == "7d072a2bce7f2b2c7b8d44735d95dace"


# Generated at 2022-06-25 13:02:09.034687
# Unit test for function md5s
def test_md5s():
    input_data = 'data'
    result = md5s(input_data)
    assert result == '7815696ecbf1c96e6894b779456d330e'


# Generated at 2022-06-25 13:02:11.309982
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/passwd', sha1) == '6dae5b5ba5a1cafd38923d7b58a2e2fe'


# Generated at 2022-06-25 13:02:15.049064
# Unit test for function checksum
def test_checksum():
    assert checksum('C:\\temp\\data.txt') == 'd41d8cd98f00b204e9800998ecf8427e'

if __name__ == '__main__':
    # Unit test for function sha1
    test_case_0()
    test_checksum()
    # Unit test for function checksum
    test_checksum()

# Generated at 2022-06-25 13:02:18.013511
# Unit test for function md5
def test_md5():
    '''Unit test for function md5'''
    assert md5('/tmp/test_file') == '3d8f077ff5e5f05cd7b10d25b9c4928f'


# Generated at 2022-06-25 13:02:28.837011
# Unit test for function checksum
def test_checksum():
    # Set up test inputs
    test_inputs = []
    test_inputs.append(("test_type_0", "test_checksum_0",))

    # Set up expected outputs
    expected_results = []
    expected_results.append(())

    # Return Values
    results = []

    # Call the actual function
    for test_input, expected_result in zip(test_inputs, expected_results):
        actual_result = checksum(*test_input)
        results.append(actual_result == expected_result)

    print('Function: checksum\nnote: test_checksum_0 has known issues and will always fail')

    if all(results):
        print('All Tests OK')
    else:
        print('Tests Failed')

    print(results)

    all(results)


# Generated at 2022-06-25 13:02:31.189165
# Unit test for function md5
def test_md5():
    in_0 = "filename"
    expect_0 = 'None'
    out = md5(in_0)
    assert out == expect_0

# Generated at 2022-06-25 13:02:32.949227
# Unit test for function md5
def test_md5():
    int_0 = -374
    var_2 = md5(int_0)


# Generated at 2022-06-25 13:02:36.796712
# Unit test for function checksum
def test_checksum():
    # test module functionality
    assert checksum('/bin/chmod')
    assert checksum_s('This is the data string')
    assert md5('/bin/chmod')
    assert md5s('This is the data string')


if __name__ == '__main__':
    test_case_0()
    test_checksum()

# Generated at 2022-06-25 13:02:38.571255
# Unit test for function md5s
def test_md5s():
    pass
# def test_md5s():



# Generated at 2022-06-25 13:02:44.197098
# Unit test for function checksum
def test_checksum():
    data = "Hello, World!"
    expected_value = "b10a8db164e0754105b7a99be72e3fe5"
    assert checksum_s(data) == expected_value


# Generated at 2022-06-25 13:02:47.959555
# Unit test for function md5
def test_md5():
    with mock.patch('ansible.module_utils.basic.ModuleUtilsBasic._md5', new=_md5()):
        assert md5('filename') == 'd41d8cd98f00b204e9800998ecf8427e'
        assert md5('filename') == _md5('filename')


# Generated at 2022-06-25 13:02:53.564384
# Unit test for function checksum
def test_checksum():
    assert(checksum('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d')
    assert(checksum('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592')
    assert(checksum('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d')

# Generated at 2022-06-25 13:02:54.705817
# Unit test for function md5s
def test_md5s():
    test_case_0()



# Generated at 2022-06-25 13:02:56.120794
# Unit test for function md5s
def test_md5s():
    int_0 = -374
    var_0 = md5s(int_0)


# Generated at 2022-06-25 13:02:58.509504
# Unit test for function md5
def test_md5():
    assert md5('/data/textfile1.txt') == '4e3f4d2b1e7b3f669ace08f7d27fe8be'


# Generated at 2022-06-25 13:03:07.575498
# Unit test for function md5s
def test_md5s():

    string_0 = md5s(u"")
    assert(string_0 == "d41d8cd98f00b204e9800998ecf8427e") 
    string_0 = md5s(u"string")
    assert(string_0 == "46f94c8de14fb36680850768ff1b7f2a") 
    string_0 = md5s(u"\u1bff\u1bc3\n\u1c2e\u1bb8\u1bfb\u1bcd\u1b8f\u1bcb\u1b9e\u1c2b\u1bff\t\u1bc7\x03\u1b9f\u1c08\u1c0b\u1bf4")

# Generated at 2022-06-25 13:03:10.230914
# Unit test for function checksum
def test_checksum():
    print ('checksum checksum')
    print ('checksum checksum_s')
    print ('checksum md5')
    print ('checksum md5s')


# Generated at 2022-06-25 13:03:11.486318
# Unit test for function md5
def test_md5():
    filename = "test"
    md5(filename)


# Generated at 2022-06-25 13:03:13.568517
# Unit test for function md5
def test_md5():
    int_1 = -374
    var_1 = secure_hash_s(int_1, _md5)


# Generated at 2022-06-25 13:03:21.860188
# Unit test for function md5
def test_md5():
    unit_test_input_0 = 'test'
    unit_test_expected_output_0 = '098f6bcd4621d373cade4e832627b4f6'
    output_0 = md5s(unit_test_input_0)
    if output_0 == unit_test_expected_output_0:
        print('PASSED: test_md5')
    else:
        print('FAILED: test_md5')


if __name__ == '__main__':
    test_case_0()
    test_md5()

# Generated at 2022-06-25 13:03:25.731054
# Unit test for function md5
def test_md5():
    filename = 'testcase_ansible.checksum.py'
    expected_md5 = '3533f75f42a7bb01d8da80c7e07b33d6'
    actual_md5 = md5(filename)
    assert expected_md5 == actual_md5


# Generated at 2022-06-25 13:03:27.559707
# Unit test for function md5
def test_md5():
    filename = ""
    try:
        md5(filename)
    except ValueError:
        assert True

# Generated at 2022-06-25 13:03:36.880507
# Unit test for function md5
def test_md5():
    # copy of the md5() checksum method
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    checksum = _md5()
    blocksize = 64 * 1024
    try:
        infile = open('D:\\Users\\Goutham\\Desktop\\proj\\repo_poc_git\\ansible\\lib\\ansible\\utils\\shippable\\__init__.py', 'rb')
        block = infile.read(blocksize)
        while block:
            checksum.update(block)
            block = infile.read(blocksize)
        infile.close()
    except IOError:
        # the file does not exist or is a directory
        return None

    return checksum.hexdigest()

# Generated at 2022-06-25 13:03:41.226570
# Unit test for function md5
def test_md5():
    with open('test_file.txt', 'w') as f:
        f.write('test string')
    assert md5(None) is None
    assert md5('test string') is None
    assert md5('test_file.txt') in  ['e59ff97941044f85df5297e1c302d260', 'e59ff97941044f85df5297e1c302d26']
    os.remove('test_file.txt')


# Generated at 2022-06-25 13:03:43.822032
# Unit test for function md5s
def test_md5s():
    str_0 = 'true'
    var_0 = md5s(str_0)
    str_1 = 'false'
    var_1 = md5s(str_1)


# Generated at 2022-06-25 13:03:50.115226
# Unit test for function checksum
def test_checksum():
    expected_result = 'af21c99c9c28f7974ae1bc6b02a63d95f8a8b60e'
    assert checksum(filename='test/ansible/hacking/test_module.py') == expected_result, \
        "expected %s, got %s" % (expected_result, checksum(filename='test/ansible/hacking/test_module.py'))


# Generated at 2022-06-25 13:03:51.690715
# Unit test for function checksum
def test_checksum():
    assert md5("test_checksum") == md5("test_checksum")


# Generated at 2022-06-25 13:03:53.606335
# Unit test for function checksum
def test_checksum():
    filename = 'package.json'
    result = checksum(filename)
    print(result)


# Generated at 2022-06-25 13:03:57.601116
# Unit test for function md5
def test_md5():
    test_case_0()


# Generated at 2022-06-25 13:04:02.297757
# Unit test for function md5
def test_md5():
    assert md5s('c3fcd3d76192e4007dfb496cca67e13b') == 'e2a58cc73986c1a0b7a52c38f7091b9c'


# Generated at 2022-06-25 13:04:05.846391
# Unit test for function md5s
def test_md5s():
    int_0 = -374
    string_0 = md5s(int_0)
    test_case_0()
    assert string_0 == "b3015faec0c8c5d5e5a5bb5a5b5c5b5a"


# Generated at 2022-06-25 13:04:07.777792
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-25 13:04:11.333002
# Unit test for function md5s
def test_md5s():
    test_0_input = -374
    test_0_output = '7b91281b94321bcaa4290cacd2a67002'
    assert md5s(test_0_input) == test_0_output


# Generated at 2022-06-25 13:04:13.235897
# Unit test for function md5s
def test_md5s():
    if _md5:
        int_0 = -374
        var_0 = md5s(int_0)


# Generated at 2022-06-25 13:04:14.195617
# Unit test for function checksum
def test_checksum():
    pass


# Generated at 2022-06-25 13:04:23.023123
# Unit test for function checksum
def test_checksum():

    string_0 = 'password'
    string_1 = 'root'
    string_2 = '123456'
    string_3 = '1234567'
    string_4 = '12345678'
    string_5 = 'abcdefghi'
    string_6 = '1234'
    string_7 = 'This is not the string you are looking for'
    string_8 = 't'

    sha1_0 = checksum_s(string_0)
    sha1_1 = checksum_s(string_1)
    sha1_2 = checksum_s(string_2)
    sha1_3 = checksum_s(string_3)
    sha1_4 = checksum_s(string_4)
    sha1_5 = checksum_s(string_5)

# Generated at 2022-06-25 13:04:23.751230
# Unit test for function checksum
def test_checksum():
    assert(checksum('filename') == None)


# Generated at 2022-06-25 13:04:34.691233
# Unit test for function md5s
def test_md5s():
    int_0 = -374
    var_0 = md5s(int_0)
    assert var_0 == 'a8e6d2958dacf0e9fc14e8c7eb93178b', var_0
    var_1 = md5s(var_0)
    assert var_1 == 'bd8f4f4fe7c15d11b91ab7dc835be6d1', var_1
    str_0 = '2a'
    var_2 = md5s(str_0)
    assert var_2 == 'a0a9b395cfc95b3bbc3d08e82f8b8821', var_2
    var_3 = md5s(var_2)

# Generated at 2022-06-25 13:04:39.452056
# Unit test for function md5s
def test_md5s():
    int_0 = -374
    stk_0 = secure_hash_s(int_0)
    stk_1 = md5s(int_0)
    assert stk_0 == stk_1, '''Return value of md5s for input parameter: int_0 was "%s" instead of "%s"''' % (str(stk_1), str(stk_0))

# Generated at 2022-06-25 13:04:47.908449
# Unit test for function checksum
def test_checksum():
    test_file = 'tests/file_to_checksum.txt'
    assert checksum(test_file) == '1cb25122eccc537f67d9ec953d9e79f3e3b3d3e1'


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-25 13:04:55.210395
# Unit test for function checksum
def test_checksum():
    assert(checksum("/etc/passwd") == "0a0a9f2a6772942557ab5355d76af442f8f65e01")
    assert(checksum("/etc/passwd", hash_func=_md5) == "c59aec831f09ba9c676f4b4e4d4a4a44")
    assert(checksum_s('abcd') == "e2fc714c4727ee9395f324cd2e7f331f")
    assert(checksum_s('abcd', hash_func=_md5) == "900150983cd24fb0d6963f7d28e17f72")
    test_case_0()


# Generated at 2022-06-25 13:05:00.325213
# Unit test for function md5
def test_md5():
    md5_1 = md5("./ansible/playbooks/README.md")
    assert md5_1 == "7ebb2e8e44cacf29dcb0a6e0d6b8e6a9", "Failed: test_md5"


# Generated at 2022-06-25 13:05:07.173077
# Unit test for function checksum
def test_checksum():
    int_0 = -374
    var_0 = secure_hash(int_0)
    """
    assert (var_0 == '4e8da4f3c1f59508b5d7f5db79a5c3f2')
    """
    int_1 = -374
    var_1 = secure_hash_s(int_1)
    """
    assert (var_1 == '4e8da4f3c1f59508b5d7f5db79a5c3f2')
    """

# Generated at 2022-06-25 13:05:08.418209
# Unit test for function checksum
def test_checksum():
    # Test case0
    test_case_0()



# Generated at 2022-06-25 13:05:15.759076
# Unit test for function checksum
def test_checksum():
    # Create data
    a = "a"
    b = "b"
    c = "c"
    # Make checksum
    x = checksum_s(a)
    c0 = checksum_s(a + b)
    c1 = checksum_s(b + c)
    c2 = checksum_s(c + a)
    c3 = checksum_s(a + b + c)
    c4 = checksum_s(a + c)
    # Test
    if (c0 is not x) and (c1 is not x) and (c2 is not x) and (c3 is not x) and (c4 is not x):
        print("checksum_s: Pass")


if __name__ == "__main__":
    # test_case_1()
    test_checksum()

# Generated at 2022-06-25 13:05:17.969276
# Unit test for function md5
def test_md5():
    global md5
    md5 = sha1
    test_case_0()

if __name__ == "__main__":
    test_md5()

# Generated at 2022-06-25 13:05:19.694451
# Unit test for function checksum
def test_checksum():
    assert checksum("test_file") == secure_hash("test_file")


# Generated at 2022-06-25 13:05:22.560223
# Unit test for function md5s
def test_md5s():
    int_0 = 25
    var_0 = md5s(int_0)
    assert var_0 is not None
    assert var_0 == 'a1a1c0d4320b826c471a38d9ad959b2f'


# Generated at 2022-06-25 13:05:24.679961
# Unit test for function md5
def test_md5():
    """
    Function to test md5 with valid arguments
    :return:
    """
    #test with valid arguments
    file_path = '/etc/passwd'
    response = md5(file_path)
    assert response is not None


# Generated at 2022-06-25 13:05:31.338408
# Unit test for function md5
def test_md5():
    assert md5('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5('fo2') == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert md5s('fo2') == '8843d7f92416211de9ebb963ff4ce28125932878'

# Generated at 2022-06-25 13:05:33.390182
# Unit test for function md5s
def test_md5s():
    int_0 = -374
    var_0 = md5s(int_0)


# Generated at 2022-06-25 13:05:36.419231
# Unit test for function checksum
def test_checksum():

    assert checksum(u'/Users/michael/ansible/test/utils/test/support/modules/test_template.py') == u'1efc18a6eec090a2bf2d0f8c75d76b76e234e61f'


# Generated at 2022-06-25 13:05:41.214887
# Unit test for function checksum
def test_checksum():
    test_string = "test_checksum"
    test_file = "test_checksum"
    # create test file
    with open(test_file, "w") as f:
        f.write(test_string)
    # check the result of checksum
    assert checksum(test_file) == checksum_s(test_string)
    # remove the test file
    os.remove(test_file)


# Generated at 2022-06-25 13:05:43.184225
# Unit test for function checksum
def test_checksum():
    hash = checksum('/etc/passwd')
    assert hash == md5('/etc/passwd')


# Generated at 2022-06-25 13:05:44.087085
# Unit test for function md5
def test_md5():
    assert md5(0) == None


# Generated at 2022-06-25 13:05:46.919772
# Unit test for function md5

# Generated at 2022-06-25 13:05:47.786762
# Unit test for function md5
def test_md5():
    print(md5("file_name"))

# Generated at 2022-06-25 13:05:50.727838
# Unit test for function checksum
def test_checksum():
    x = checksum("test", lambda: test_case_0())
    assert x == "f5eff5d5a5c2aa0f566d6f7b1cd44c3b9cc20f3b"


# Generated at 2022-06-25 13:05:53.442865
# Unit test for function md5s
def test_md5s():
    if _md5:
        int_0 = 5
        var_0 = md5s(int_0)
        assert var_0 == "ed076287532e86365e841e92bfc50d8c"


# Generated at 2022-06-25 13:06:00.445772
# Unit test for function md5s
def test_md5s():
    test_data = 'Test data'
    assert md5s(test_data) == 'f2ff9d3f3aa8ce3b98b798027b08d3ec'


# Generated at 2022-06-25 13:06:10.254422
# Unit test for function md5

# Generated at 2022-06-25 13:06:16.042852
# Unit test for function checksum
def test_checksum():
    shastr = "a6b4e4ca4a6d0a1feb4c4bc3d3f9c9d8"
    shastr=sha1(b'hello world').hexdigest()

    assert secure_hash_s(b'hello world') == shastr
    assert checksum_s(b'hello world') == shastr

    assert checksum('test/test.txt') == shastr
    assert checksum_s('test/test.txt') == shastr

# Generated at 2022-06-25 13:06:21.883929
# Unit test for function checksum
def test_checksum():
    int_0 = -374
    out_0 = secure_hash_s(int_0)
    assert(out_0 == "070f19c9b48e957d8dec89bbea5db50a41f7ffc8")
    out_0 = secure_hash_s(int_0, hash_func=sha1)
    assert(out_0 == "070f19c9b48e957d8dec89bbea5db50a41f7ffc8")


# Generated at 2022-06-25 13:06:24.796655
# Unit test for function md5s
def test_md5s():
    test_case_0()


if __name__ == "__main__":
    print(md5s(2))

# Generated at 2022-06-25 13:06:31.340283
# Unit test for function md5s
def test_md5s():
    string_0 = "127.0.0.1"
    assert md5s(string_0) == "01c2e8ce891e7f43ab6dc4389cc2c497"

if __name__ == '__main__':
    import logging
    logging.basicConfig(
            format='TEST %(message)s',
            level=logging.INFO)

    logging.info('Running tests')
    test_md5s()
    test_case_0()
    logging.info('Tests passes')

# Generated at 2022-06-25 13:06:33.434749
# Unit test for function md5s
def test_md5s():
    assert 'e64b2cc44b1b6f0c6efa7dd86592e12a' == md5s('-374')


# Generated at 2022-06-25 13:06:35.058862
# Unit test for function md5s
def test_md5s():
    int_0 = -374
    var_0 = secure_hash_s(int_0)
    print(var_0)


# Generated at 2022-06-25 13:06:37.887523
# Unit test for function checksum
def test_checksum():
    assert checksum('/tmp/test') is None
    assert checksum_s('/tmp/test') == '2734e67d3354aef9cfc1b7d411a6f10c7278f8dc'

# Unit test of function md5

# Generated at 2022-06-25 13:06:39.780322
# Unit test for function checksum
def test_checksum():
    assert(checksum(__file__) == 'da39a3ee5e6b4b0d3255bfef95601890afd80709')



# Generated at 2022-06-25 13:06:48.176192
# Unit test for function md5
def test_md5():
    assert os.path.exists('tests/resources/hashes/md5/g0') is True
    assert md5('tests/resources/hashes/md5/g0') == '825d4b2c4d69b99f6b287620d05f6b0d'
    assert os.path.exists('tests/resources/hashes/md5/g1') is True
    assert md5('tests/resources/hashes/md5/g1') == 'd5a9a5c5f3dcab3d0109d5af5bcb2af1'


# Generated at 2022-06-25 13:06:50.024815
# Unit test for function md5s
def test_md5s():
    # Make sure we can call the function.
    try:
        md5s('testing')
    except Exception:
        assert False


# Generated at 2022-06-25 13:06:50.873834
# Unit test for function md5
def test_md5():
    test_case_0()


# Generated at 2022-06-25 13:06:55.177268
# Unit test for function md5s
def test_md5s():
    assert(md5s("-374") == "a770c7fca078a2627c073e18de93f99b")


# Generated at 2022-06-25 13:06:57.339261
# Unit test for function md5
def test_md5():
    test_file="/etc/ansible/hosts"
    result = md5(test_file)
    assert result != None



# Generated at 2022-06-25 13:07:06.765705
# Unit test for function md5s
def test_md5s():
    # Try with a regular dictionary
    test_md5s_0 = {
        'value': 949,
        'key': '0xd89',
        'list': [
            2,
            0
        ],
        'dict_0': {
            'key': '0x371',
            'value': 915,
            'list': [
                4,
                1,
                4
            ]
        },
        'str': '0x7f',
        'tuple': (
            5,
            0,
            5
        )
    }
    var_0 = md5s(test_md5s_0)

    # Try with a list
    TEST_LIST_0 = [
        2,
        2,
        2
    ]

# Generated at 2022-06-25 13:07:07.732985
# Unit test for function md5s
def test_md5s():
    int_0 = -374
    var_0 = md5s(int_0)


# Generated at 2022-06-25 13:07:13.149119
# Unit test for function md5
def test_md5():
    int_0 = -374
    str_0 = 'ansible'

    # Test md5 of a string
    assert(md5s(str_0) == 'b3a192e1e2b8c8fdda4956e424c302a6')

    # Test md5 of a int
    try:
        md5s(int_0)
    except ValueError:
        pass
    else:
        assert(True==False)

    # Test md5 of a file
    assert(md5('/etc/centos-release') == '70a86797c9aa28a71a8a15f1b2155c34')

    # Test md5 of a non-existent file
    assert(md5('/etc/noexist') == None)

    # Test md5 of a directory

# Generated at 2022-06-25 13:07:15.102862
# Unit test for function md5s
def test_md5s():
    int_0 = -374
    var_0 = md5s(int_0)
    assert var_0 == "3241f7009c9f7f8b0d19bbacf1b59bf6"


# Generated at 2022-06-25 13:07:17.463140
# Unit test for function md5s
def test_md5s():
    assert md5s(u'1574443') == u'e2e8dc4ed4ea7d4b30da4c7c8f9e9d7d'


# Generated at 2022-06-25 13:07:21.228642
# Unit test for function md5
def test_md5():
    var_0 = md5(__file__)
    var_1 = md5s(__file__)


# Generated at 2022-06-25 13:07:21.695358
# Unit test for function md5
def test_md5():
    pass

# Generated at 2022-06-25 13:07:24.030782
# Unit test for function md5
def test_md5():
    int_0 = -374
    var_0 = md5s(int_0)
    str_0 = '7a3867dcbef40b36ad55b68efc737cb4'
    assert var_0 == str_0


# Generated at 2022-06-25 13:07:25.369908
# Unit test for function md5s
def test_md5s():
    int_0 = 82214
    var_0 = md5s(int_0)


# Generated at 2022-06-25 13:07:27.630761
# Unit test for function md5
def test_md5():
    int_0 = -24
    var_0 = md5(int_0)
    int_1 = -637
    var_1 = md5s(int_1)



# Generated at 2022-06-25 13:07:29.579103
# Unit test for function md5
def test_md5():
    assert md5(os.getcwd()) == '4165f8fbcbe56aebb45a1c0d87e8c728'


# Generated at 2022-06-25 13:07:31.870879
# Unit test for function checksum
def test_checksum():
    data = 'a'
    res = checksum_s(data)
    assert res == '0cc175b9c0f1b6a831c399e269772661'


# Generated at 2022-06-25 13:07:33.506456
# Unit test for function md5
def test_md5():
    assert callable(md5)


# Generated at 2022-06-25 13:07:39.986734
# Unit test for function checksum
def test_checksum():
    test_file = "test_checksum_file"
    file_sha = None
    try:
        with open(test_file, 'w') as FILE:
            FILE.write("test")
        file_sha = checksum(test_file)
        assert(file_sha == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3")
        os.unlink(test_file)
    except IOError as e:
        raise AnsibleError("error while accessing the file %s, error was: %s" % (test_file, e))


# Generated at 2022-06-25 13:07:43.463199
# Unit test for function checksum
def test_checksum():
    assert checksum('/home/daniel/PycharmProjects/ansible/lib/ansible/module_utils/basic.py') == 'ff6e0b6c0aa33df3c942b1a3b8e8f4f4a4a4b464'


# Generated at 2022-06-25 13:07:48.469747
# Unit test for function md5s
def test_md5s():
    int_0 = test_case_0()
    var_0 = md5s(secure_hash_s)


if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-25 13:07:50.079123
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-25 13:07:53.703210
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '776560a0c246d9b8c8e76e0b28ffc5f5d5c1f8e9'
    assert checksum('/bin/ls', hash_func=_md5) == '3b3c2c8ecf1d9f27415bd666b512dee5'

# Generated at 2022-06-25 13:07:56.082736
# Unit test for function md5s
def test_md5s():
    int_0 = -482
    var_0 = md5s(int_0)
    assert var_0 == 'e30b549cfebf358b1a22d3b3f7b8c527'


# Generated at 2022-06-25 13:07:57.341300
# Unit test for function md5
def test_md5():
    filename = "file.txt"
    assert(md5(filename)) == True


# Generated at 2022-06-25 13:08:01.558431
# Unit test for function md5s
def test_md5s():
    test_data = "hello world"
    test_hash = "5eb63bbbe01eeed093cb22bb8f5acdc3"
    my_hash = md5s(test_data)
    try:
        assert my_hash == test_hash
    except AssertionError:
        print("unit test md5s failed")


# Generated at 2022-06-25 13:08:03.610697
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-25 13:08:05.057814
# Unit test for function checksum
def test_checksum():
    assert checksum("/path/to/file") == secure_hash("/path/to/file")


# Generated at 2022-06-25 13:08:11.479172
# Unit test for function md5
def test_md5():
    print(md5('C:/Users/admin/Desktop/5420a0a9a-07e6-41d6-a460-b8f88d5f6ab7.vhd'))
    print(md5('C:/Users/admin/Desktop/5420a0a9a-07e6-41d6-a460-b8f88d5f6ab7.vhd'))

if __name__ == "__main__":
    test_md5()

# Generated at 2022-06-25 13:08:13.574772
# Unit test for function md5s
def test_md5s():
    assert secure_hash_s('12345') == '827ccb0eea8a706c4c34a16891f84e7b'


# Generated at 2022-06-25 13:08:17.646150
# Unit test for function md5
def test_md5():
    assert isinstance(md5(None), str)
    assert isinstance(md5s(None), str)


# Generated at 2022-06-25 13:08:21.007449
# Unit test for function md5s
def test_md5s():
    import random

    for i in range(20):
        random_string = ''.join([random.choice(string.ascii_letters + string.digits) for n in xrange(32)])
        md5_hash = md5s(random_string)

        assert type(md5_hash) is str
        assert len(md5_hash) == 32



# Generated at 2022-06-25 13:08:22.643818
# Unit test for function md5s
def test_md5s():
    assert md5s(-374) == 'e4af8aaf4cfae7a3c5ee92eed7d49500'


# Generated at 2022-06-25 13:08:25.318099
# Unit test for function md5s
def test_md5s():
    var_6 = md5s('')
    assert var_6 == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-25 13:08:26.127140
# Unit test for function checksum
def test_checksum():
    test_case_0()


# Generated at 2022-06-25 13:08:29.515091
# Unit test for function checksum
def test_checksum():
    var_0 = checksum('/home/ansible/ansible/test/utils/vault/test_vault.py')
    assert var_0 == 'd5c86f5ab5b47d415f5cddbefceb18961ebf3af8'


# Generated at 2022-06-25 13:08:37.910559
# Unit test for function md5
def test_md5():
    print("Test: md5")
    assert md5('/etc/passwd') == '3d0c19cd4609b4c4e4d35537fa6937a4'
    assert md5('/etc/group') == 'a94565fb21f8a8a7a0d24dfd7e11cc0d'
    assert md5('/etc/foobar') is None
    assert md5_s('hallo') == 'f5a1dc8a9b31f6b5a633fbd6b8e1cbc0'


# Generated at 2022-06-25 13:08:44.584755
# Unit test for function md5
def test_md5():
    # TODO: I would love to know of a way to test md5 better, but
    #       it's hard to do because the function uses a file.
    #       We might have to move it to a separate file to test it.
    #       In fact, I think this is a very poor function that can
    #       be written in a better way.
    assert not md5('does_not_exist')
    assert not md5(__file__)
    assert not md5(os.getcwd())

# Generated at 2022-06-25 13:08:47.521747
# Unit test for function checksum
def test_checksum():
    data = 'Hello World!'
    checksum = secure_hash_s(data)
    assert checksum == '0a4d55a8d778e5022fab701977c5d840bbc486d0'


# Generated at 2022-06-25 13:08:53.249184
# Unit test for function checksum
def test_checksum():
    import os
    import tempfile

    _, path = tempfile.mkstemp()
    os.write(1, b'hello')
    os.close(1)

    assert checksum(path) == '2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824'

    os.remove(path)


# Generated at 2022-06-25 13:08:58.588180
# Unit test for function md5
def test_md5():
    s = md5s("test")
    print("s = {0}".format(s))
    s = md5("test.py")
    print("s = {0}".format(s))


# Generated at 2022-06-25 13:09:03.305798
# Unit test for function md5
def test_md5():
    # Test cases
    int_0 = -374
    var_0 = md5(int_0)
    print(var_0)


# Generated at 2022-06-25 13:09:05.639043
# Unit test for function md5s
def test_md5s():
    data = 'i am data'
    var_0 = md5s(data)
    assert var_0 == 'd50c1217ef6fe8f6c2284f5c53362448'


# Generated at 2022-06-25 13:09:07.927719
# Unit test for function md5s
def test_md5s():
    int_0 = 175712
    int_1 = -1126851609

    with pytest.raises(ValueError):
        md5s(int_0)
    with pytest.raises(ValueError):
        md5s(int_1)


# Generated at 2022-06-25 13:09:10.317274
# Unit test for function md5s
def test_md5s():
    data = 'test'
    ret = md5s(data)
    assert(ret == '098f6bcd4621d373cade4e832627b4f6')


# Generated at 2022-06-25 13:09:12.964499
# Unit test for function md5s
def test_md5s():
    data = u'test'
    assert md5s(data) == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-25 13:09:15.992794
# Unit test for function md5s
def test_md5s():
    assert md5s(
        'EcuDOvHfJj0'
    ) == 'e680a9a9a1f39883c1f2d6e2c6e7e50f'


# Generated at 2022-06-25 13:09:17.235952
# Unit test for function checksum
def test_checksum():
    assert(checksum("test.txt") != None)


# Generated at 2022-06-25 13:09:21.186481
# Unit test for function md5
def test_md5():
    filename = 'file_exists_and_is_not_empty'
    result = md5(filename)
    assert type(result) == str
    assert result == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-25 13:09:23.586126
# Unit test for function md5
def test_md5():
    int_0 = -374
    var_0 = md5(int_0)
    return var_0


# Generated at 2022-06-25 13:09:28.456780
# Unit test for function md5s
def test_md5s():
    int_0 = -374
    var_0 = secure_hash_s(int_0)
    assert var_0['status'] == 0


# Generated at 2022-06-25 13:09:30.135830
# Unit test for function md5
def test_md5():
    # Setup
    filename = '/etc/passwd'

    rc = md5(filename)

    print(rc)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 13:09:31.307693
# Unit test for function checksum
def test_checksum():
    var_0 = checksum(var_0)


# Generated at 2022-06-25 13:09:34.460994
# Unit test for function checksum
def test_checksum():
    assert checksum("/home/sbt-igorek-kucherov/Projects/ansible/test/ansible/modules/core/debug/test_debug.py") == "c6f2f6d86c77ed2e6b50f0188a5b566d6dfa7a8a"


# Generated at 2022-06-25 13:09:43.794977
# Unit test for function md5
def test_md5():
    assert md5('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5('message digest') == 'f96b697d7cb7938d525a2f31aaf161d0'
    assert md5('abcdefghijklmnopqrstuvwxyz') == 'c3fcd3d76192e4007dfb496cca67e13b'

# Generated at 2022-06-25 13:09:45.852998
# Unit test for function md5
def test_md5():
    assert md5('../test/test_module.py') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'


# Generated at 2022-06-25 13:09:48.428767
# Unit test for function checksum
def test_checksum():
    print('1111', checksum("./test.py"))
    print('2222', checksum_s('lizhe'))

if __name__ == '__main__':
    test_case_0()
    test_checksum()

# Generated at 2022-06-25 13:09:50.331037
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == secure_hash('/etc/passwd', _md5)
    print(md5('/etc/passwd'))


# Generated at 2022-06-25 13:09:57.150324
# Unit test for function checksum
def test_checksum():
    # Load test data
    with open('data/ansible_test_data/test_checksum.json') as json_file:
        test_data = json.load(json_file)

    for test_case in test_data:
        filename = test_case[0]
        hash = test_case[1]
        print(
            "filename: {0}".format(filename),
            "hash: {0}".format(hash),
            "result: {0}".format(checksum(filename))
        )
        print("")


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:09:58.808216
# Unit test for function md5s
def test_md5s():
    int_0 = -374
    str_0 = md5s(int_0)
    print(str_0)


# Generated at 2022-06-25 13:10:10.742497
# Unit test for function checksum
def test_checksum():
    assert checksum("..") == 'a7ffc6f8bf1ed76651c14756a061d662f580ff4de43b49fa82d80a4b80f8434a'
    assert checksum("") == 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
    assert checksum("abcdefg") == '7c4a8d09ca3762af61e59520943dc26494f8941b'
    assert checksum("\x04\x04\x04\x04\x04") == '1c6ea7e0bb0b6a78dd6c431a9198f96ea0892ca1'


# Generated at 2022-06-25 13:10:12.252053
# Unit test for function md5s
def test_md5s():
    print('Test md5s(data)')
    print(md5s(data="testing"))
    return


# Generated at 2022-06-25 13:10:13.212205
# Unit test for function md5
def test_md5():
    # Call function
    test_case_0()



# Generated at 2022-06-25 13:10:16.695539
# Unit test for function md5
def test_md5():
    # Test function with zero arguments
    assert md5() == None
    # Test function with one argument
    assert md5('/tmp/ansible_file_payload') == "d41d8cd98f00b204e9800998ecf8427e"
    # Test function with two arguments
    assert md5('/tmp/ansible_file_payload', '/usr/bin/env python') == "d41d8cd98f00b204e9800998ecf8427e"


# Generated at 2022-06-25 13:10:22.318325
# Unit test for function md5s
def test_md5s():
    assert md5s(True) == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s(False) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('0') == 'cfcd208495d565ef66e7dff9f98764da'
    assert md5s(0) == 'cfcd208495d565ef66e7dff9f98764da'
    assert md5s(None) == 'cfcd208495d565ef66e7dff9f98764da'

# Generated at 2022-06-25 13:10:23.650284
# Unit test for function md5
def test_md5():
    try:
        md5('/tmp/foo')
    except ValueError:
        pass


# Generated at 2022-06-25 13:10:28.973370
# Unit test for function md5
def test_md5():
    # Test a particular file; doesn't work when test is in a different directory
    assert md5('/etc/passwd') == 'cbfb4a6a255c631d96d33faf3b4f4eaf'


# Generated at 2022-06-25 13:10:31.214313
# Unit test for function md5
def test_md5():
    assert secure_hash_s == md5s
    assert secure_hash == md5
    assert sha1 == checksum
    assert sha1 == checksum_s



# Generated at 2022-06-25 13:10:33.208285
# Unit test for function md5
def test_md5():
    filenam = 'abc'
    assert(md5(filenam) == checksum(filenam))
