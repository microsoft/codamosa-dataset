

# Generated at 2022-06-25 13:00:44.308841
# Unit test for function checksum
def test_checksum():
    assert str(type(secure_hash('password'))) == "<type 'str'>"
    assert str(type(secure_hash_s('password'))) == "<type 'str'>"

# Generated at 2022-06-25 13:00:46.817151
# Unit test for function md5s
def test_md5s():
    print("\n\n\nResults of md5s:")
    test_case_0()

if __name__=="__main__":
    test_md5s()

# Generated at 2022-06-25 13:00:49.932598
# Unit test for function checksum
def test_checksum():
    assert checksum("test.txt") is not None
    assert checksum("test.txt") == "d9c1ab9e86978a0f58ece3bfe3e2a1b8"


# Generated at 2022-06-25 13:00:52.518478
# Unit test for function checksum
def test_checksum():
    assert checksum("test") == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"



# Generated at 2022-06-25 13:00:54.532975
# Unit test for function md5s
def test_md5s():
    bool_0 = False
    assert md5s(bool_0) == '6cd3556deb0da54bca060b4c39479839'


# Generated at 2022-06-25 13:00:59.798627
# Unit test for function md5s
def test_md5s():
    data = 'some string'
    test_data = 'a2e2fa7e93f8dcaa89c05928b06f46e8'
    assert md5s(data) == test_data
    data = b'some string 2'
    test_data = '867da4a2a7c50d3a3e88a1ae0e2bcc51'
    assert md5s(data) == test_data
    try:
        data = u'some unicode string'
        test_data = 'dfcc04fbebdf9162b739a1297326ec85'
        assert md5s(data) == test_data
    except ValueError as e:
        # running in FIPS mode
        pass
    data = None

# Generated at 2022-06-25 13:01:01.265033
# Unit test for function checksum
def test_checksum():
    assert checksum(__file__) is not None


# Generated at 2022-06-25 13:01:04.005951
# Unit test for function md5s
def test_md5s():
    # set function parameters
    data = "Test string"
    assert md5s(data) == "3e3fb76e5842315c18d8efc6bceea6da"


# Generated at 2022-06-25 13:01:04.568595
# Unit test for function md5
def test_md5():

    assert True

# Generated at 2022-06-25 13:01:07.063319
# Unit test for function checksum
def test_checksum():
    filename = "/etc/passwd"
    result = checksum(filename)
    assert(result == "e52d65a8dc5c5f56421ba93a3a4a4a8f")


# Generated at 2022-06-25 13:01:13.435817
# Unit test for function md5
def test_md5():
    '''
    Unit test for function md5
    '''
    data = to_bytes(b'Hello World')
    hashed_data = md5s(data)
    assert hashed_data == 'b10a8db164e0754105b7a99be72e3fe5'



# Generated at 2022-06-25 13:01:15.268587
# Unit test for function checksum
def test_checksum():
    filename = "filename"
    assert secure_hash(filename) == checksum(filename)



# Generated at 2022-06-25 13:01:16.116323
# Unit test for function md5s
def test_md5s():
    assert True
#

# Generated at 2022-06-25 13:01:24.783198
# Unit test for function md5
def test_md5():
    assert md5s(1) == "c4ca4238a0b923820dcc509a6f75849b"
    assert md5s("1") == "c4ca4238a0b923820dcc509a6f75849b"
    assert md5s(0) == "cacf7c6ae90a994acad08e0d7a86a4fe"
    assert md5s(False) == "cacf7c6ae90a994acad08e0d7a86a4fe"
    assert md5s(True) == "c4ca4238a0b923820dcc509a6f75849b"
    assert md5s(None) == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5

# Generated at 2022-06-25 13:01:32.006251
# Unit test for function md5s
def test_md5s():
    tests = [
        (True, "0cc175b9c0f1b6a831c399e269772661"),
        ("foo", "acbd18db4cc2f85cedef654fccc4a4d8"),
        ("ansible", "4d107792ef50f4b7380ccb8d735bda61"),
        ("test", "098f6bcd4621d373cade4e832627b4f6")
    ]

    for test in tests:
        assert test[1] == md5s(test[0]), \
            "md5s() failed to reasonably hashes a string"


# Generated at 2022-06-25 13:01:36.426390
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/hosts') == '3a2d396bcd04c6a16598d3144d092d98'


# Generated at 2022-06-25 13:01:41.835885
# Unit test for function checksum
def test_checksum():
    f = open('/tmp/ansible_secure_hash.txt', 'w')
    f.write('hello world')
    f.close()
    result = checksum('/tmp/ansible_secure_hash.txt', hash_func=sha1)
    assert result == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'


# Generated at 2022-06-25 13:01:49.963029
# Unit test for function md5
def test_md5():
    class File:
        def __init__(self, name, content):
            self.name = name
            self.content = content

        def read(self):
            return self.content

    def tempfile(content):
        return File('tempfile', content)

    # Test 1:
    file_1 = tempfile('')
    file_1.seek = lambda n: None
    file_1.read = lambda n: None
    if md5(file_1) is None:
        print('Test 1 OK')
    else:
        print('Test 1 FAIL')
    # Test 2:
    file_2 = tempfile('')
    if md5(file_2) == 'd41d8cd98f00b204e9800998ecf8427e':
        print('Test 2 OK')

# Generated at 2022-06-25 13:01:55.562521
# Unit test for function md5
def test_md5():
    expected = '78:ac:c0:1d:e7:85:86:9f:7e:e5:f7:e0:3b:1e:71:0e'
    actual = md5('ansible/module_utils/basic.py')
    assert expected == actual



# Generated at 2022-06-25 13:02:05.488098
# Unit test for function checksum
def test_checksum():
    # Make a tempfile of zeros.
    import tempfile
    tmp_fd, tmp_path = tempfile.mkstemp(text=False)
    os.write(tmp_fd, b'\0' * 1048576)
    os.close(tmp_fd)

    # Try SHA1, SHA224, SHA256, SHA384 and SHA512.
    for algo in ['sha1', 'sha224', 'sha256', 'sha384', 'sha512']:
        csum_func = getattr(sha1, '__constructor__')
        csum = checksum(tmp_path, csum_func)
        assert csum == getattr(sha1, 'hexdigest')()

    # Clean up tempfile.
    os.remove(tmp_path)

    # Make a tempfile of zeros.
    tmp_

# Generated at 2022-06-25 13:02:11.941614
# Unit test for function md5
def test_md5():
    assert md5(os.getcwd()+'/tests/core/test_data/foobar') == '22c3901f50f2d54077add0d039e7b9ad'
    assert md5(os.getcwd()+'/tests/core/test_data/foobar_dir') == None

# Generated at 2022-06-25 13:02:14.273396
# Unit test for function md5s
def test_md5s():
    case_0 = ["False"]
    if not False:
        test_case_0()


# Generated at 2022-06-25 13:02:16.688677
# Unit test for function checksum
def test_checksum():
    assert checksum("test_file") == "d2b7ff1b639fce7eafd38dd999415ebf28c9ea9a"


# Generated at 2022-06-25 13:02:17.933323
# Unit test for function md5
def test_md5():
    assert secure_hash(filename, hash_func=sha1) == None


# Generated at 2022-06-25 13:02:20.321428
# Unit test for function md5
def test_md5():
    filename = '/etc/hosts'
    assert md5(filename) == '035942ab0f6a18a8a459c01016e9a710'


# Generated at 2022-06-25 13:02:23.531221
# Unit test for function checksum
def test_checksum():
    assert "eb3d513adffdc58e069f4b7c2d2d0844" == checksum("/tmp/foo")


# for testing only
if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-25 13:02:28.836636
# Unit test for function checksum
def test_checksum():
    local_filename = "./test/units/file/test_file"
    remote_checksum = secure_hash(local_filename)
    assert remote_checksum == "a81b8f2a2d2c2f49ca52b349c8cb1d78a9f9d2e2"


# Generated at 2022-06-25 13:02:32.125588
# Unit test for function md5
def test_md5():
    filename = "test01"
    ret = md5(filename)
    print(ret)
    #assert ret == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-25 13:02:34.047104
# Unit test for function checksum
def test_checksum():
    arg_0 = str
    if (checksum(arg_0) != secure_hash(arg_0)):
        raise ValueError


# Generated at 2022-06-25 13:02:35.084399
# Unit test for function md5s
def test_md5s():
    test_case_0()



# Generated at 2022-06-25 13:02:43.308782
# Unit test for function md5
def test_md5():
    # Should return a secure hash hex digest of data
    assert md5('example.txt') == 'bf8a5708e8a90a9d1413d4ce8e4f4c22'
    # Should return None if file is not present or a directory
    assert md5('doesnotexist.txt') is None
    assert md5('.') is None

# Generated at 2022-06-25 13:02:44.286501
# Unit test for function md5
def test_md5():
    test_case_0()


# Generated at 2022-06-25 13:02:45.903050
# Unit test for function md5s
def test_md5s():
    case_0 = test_case_0()

###########################################


# Generated at 2022-06-25 13:02:55.016403
# Unit test for function md5
def test_md5():
    assert(md5s("") == "d41d8cd98f00b204e9800998ecf8427e")
    assert(md5s("a") == "0cc175b9c0f1b6a831c399e269772661")
    assert(md5s("abc") == "900150983cd24fb0d6963f7d28e17f72")
    assert(md5s("message digest") == "f96b697d7cb7938d525a2f31aaf161d0")
    assert(md5s("abcdefghijklmnopqrstuvwxyz") == "c3fcd3d76192e4007dfb496cca67e13b")

# Generated at 2022-06-25 13:02:57.257199
# Unit test for function md5s
def test_md5s():
    assert "7e94c3020d1e9f0a3547b7cecbf19e40" == md5s("foo.txt")


# Generated at 2022-06-25 13:03:06.053143
# Unit test for function md5s
def test_md5s():
    bool_0 = False
    assert md5s(bool_0) == "4e1243bd22c66e76c2ba9eddc1f91394e57f9f83"
    str_0 = "abcd"
    assert md5s(str_0) == "e2fc714c4727ee9395f324cd2e7f331f"
    str_0 = "abcde"
    assert md5s(str_0) == "ab56b4d92b40713acc5af89985d4b786"
    str_1 = "0123456789"
    assert md5s(str_1) == "781e5e245d69b566979b86e28d23f2c7"

# Generated at 2022-06-25 13:03:07.573826
# Unit test for function md5
def test_md5():
    assert md5("./test.txt") == md5("./test.txt") 


# Generated at 2022-06-25 13:03:09.900365
# Unit test for function md5
def test_md5():
    assert '912ec803b2ce49e4a541068d495ab570' == md5("sha1.py")


# Generated at 2022-06-25 13:03:12.107462
# Unit test for function md5s
def test_md5s():
    var_1 = md5s("test")
    assert var_1 == "098f6bcd4621d373cade4e832627b4f6"



# Generated at 2022-06-25 13:03:16.971524
# Unit test for function md5
def test_md5():
    bool_0 = False
    param_0 = 'data'
    param_1 = 'filename'
    var_0 = md5(filename=param_0)
    var_1 = md5(filename=param_1)
    var_2 = md5s(data=param_0)

if __name__ == '__main__':
    test_md5()
    test_case_0()

# Generated at 2022-06-25 13:03:20.710884
# Unit test for function md5s
def test_md5s():
    assert(False) == test_case_0()

# Generated at 2022-06-25 13:03:24.196874
# Unit test for function md5s
def test_md5s():
    var_0 = False
    try:
        var_1 = md5s(var_0)
    except ValueError as exc:
        pass
    else:
        raise AssertionError("MD5 not available.  Possibly running in FIPS mode")


# Generated at 2022-06-25 13:03:27.171660
# Unit test for function md5
def test_md5():
    assert checksum("adfadf") == "5f5ad5c5d6e2e6a674b38a1f6e08b9c9b89d1f6c"


# Generated at 2022-06-25 13:03:28.719690
# Unit test for function md5
def test_md5():
    print("running test_md5:")
    test_case_0()


# Generated at 2022-06-25 13:03:30.233468
# Unit test for function md5s
def test_md5s():
    assert not md5s(b'False')


# Generated at 2022-06-25 13:03:36.929528
# Unit test for function checksum
def test_checksum():
    test_data_dir = os.path.join(os.path.dirname(__file__), 'test_data')
    test_file = os.path.join(test_data_dir, 'test_file')
    # We can't know what the output of this function is, but we can make
    # sure it doesn't throw an exception, and is the right length.
    checksum(test_file)
    assert len(checksum(test_file)) == 40
    assert len(checksum_s(test_file)) == 40


# Generated at 2022-06-25 13:03:39.067485
# Unit test for function md5s
def test_md5s():
    x = md5s('foo')
    assert x == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-25 13:03:41.158600
# Unit test for function md5s
def test_md5s():
    bool_0 = True
    var_3 = md5s(bool_0)
    assert var_3 == '78e731027d8fd50ed642340b7c9a63b3'


# Generated at 2022-06-25 13:03:43.746028
# Unit test for function checksum
def test_checksum():
    assert checksum("tests/units/modules/utility/test_files/test_file_0") == "2f78d2c9ee9109ab92e8c34d130a73a7"


# Generated at 2022-06-25 13:03:52.022694
# Unit test for function md5
def test_md5():
    val1 = b'one'
    val2 = b'two'
    # Check for correct hash
    val1_hash = md5s(val1)
    if val1_hash != 'ed076287532e86365e841e92bfc50d8c':
        raise ValueError("md5s( 'one' ) -> " + val1_hash)
    # Check for unique hash
    val2_hash = md5s(val2)
    if val1_hash == val2_hash:
        raise ValueError('md5s( \'one\' ) == md5s( \'two\' ) -> ' + val1_hash)


# Generated at 2022-06-25 13:03:57.907669
# Unit test for function md5
def test_md5():
    with pytest.raises(ValueError):
        variable = "1"
        # This should raise an exception because we are assuming that we are running on a FIPS-140-2 compliant
        # system and _md5 should be None.
        result = md5(variable)


# Generated at 2022-06-25 13:04:00.047238
# Unit test for function md5s
def test_md5s():
    bool_0: bool = True
    str_0: str = "str"
    str_1: str = md5s(str_0)

# Generated at 2022-06-25 13:04:08.821883
# Unit test for function md5s
def test_md5s():
    bool_0 = True
    var_0 = md5s(bool_0)
    int_0 = 1345
    var_1 = md5s(int_0)
    str_0 = '1345'
    var_2 = md5s(str_0)
    str_1 = 'this is a string'
    var_3 = md5s(str_1)
    bool_1 = False
    var_4 = md5s(bool_1)
    int_1 = -1345
    var_5 = md5s(int_1)
    bool_2 = True
    var_6 = md5s(bool_2)
    str_2 = '1345'
    var_7 = md5s(str_2)
    str_3 = 'THIS IS A STRING'
    var_8

# Generated at 2022-06-25 13:04:18.376864
# Unit test for function md5
def test_md5():
    # Remove the directories used by the tests
    """
    TODO
    """
    # Verify the MD5 checksum of the file
    data = 'Hello world'
    var_0 = secure_hash_s(data) # Ansible should be able to calculate the SHA1
    assert var_0 == secure_hash_s(data)
    
    file = './test.txt'
    with open(file, 'w') as f:
        f.write(data)
    var_1 = secure_hash(file)
    assert var_1 == secure_hash(file)

    # Execute the function with all but the last two parameters
    try:
        md5(file, 'Expected 2 parameters, got 3')
    except TypeError as e:
        assert e == TypeError('Expected 2 parameters, got 3')

# Generated at 2022-06-25 13:04:21.252594
# Unit test for function md5
def test_md5():
    md5_s = md5s('abcd')
    assert md5_s == 'e2fc714c4727ee9395f324cd2e7f331f'


test_case_0()
test_md5()

# Generated at 2022-06-25 13:04:26.108852
# Unit test for function md5
def test_md5():
    # Assert True
    assert md5("/home/mike/test_file") == "0cc175b9c0f1b6a831c399e269772661"
    # Assert False
    assert md5("/home/mike/test_file") == "0cc175b9c0f1b6a831c399e269772660"



# Generated at 2022-06-25 13:04:34.052662
# Unit test for function md5
def test_md5():
    test_file = 'test/test_md5'
    with open(test_file, 'w') as ff:
        ff.write('test file')

    expected_md5 = '098f6bcd4621d373cade4e832627b4f6'
    md5sum_value = md5(test_file)
    assert expected_md5 == md5sum_value
    assert md5sum_value == secure_hash(test_file, _md5)
    assert md5sum_value == secure_hash_s(md5sum_value)
    assert md5sum_value == checksum(test_file)


# Generated at 2022-06-25 13:04:37.625247
# Unit test for function md5s
def test_md5s():
    print("testing md5s")
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    test_case_0()

    print("success")


if __name__ == "__main__":
    test_md5s()

# Generated at 2022-06-25 13:04:46.485331
# Unit test for function checksum
def test_checksum():
    assert checksum('ansible') == 'f2ca1bb6c7e907d06dafe4687e579fce76b37e4e93b7605022da52e6ccc26fd2'
    assert checksum('ansible', 'sha1') == 'f2ca1bb6c7e907d06dafe4687e579fce76b37e4e93b7605022da52e6ccc26fd2'

# Generated at 2022-06-25 13:04:54.544130
# Unit test for function checksum
def test_checksum():
    # Test with a valid file
    filename = "test-fixtures/testfile.txt"
    assert checksum(filename) == "943936e0c2a11a330d847fd7167afaf0c5d06575"
    assert checksum(filename, hash_func=sha1) == "943936e0c2a11a330d847fd7167afaf0c5d06575"

    # Test with an invalid file
    assert checksum("/invalid/path/to/file") == None
    assert checksum("/invalid/path/to/file", hash_func=sha1) == None

    # Test with a directory
    assert checksum("/etc") == None
    assert checksum("/etc", hash_func=sha1) == None

    # Test with a non-supported

# Generated at 2022-06-25 13:04:58.743481
# Unit test for function md5
def test_md5():
    pass



# Generated at 2022-06-25 13:05:04.661344
# Unit test for function md5s
def test_md5s():
    assert md5s("abc") == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s("abc" * 10) == '77befb79cbe8b36e9c7a038adc67aa7f'
    assert md5s("1" * 1000) == '6a2123c9edb6a5dfe08b03e8c48ab1db'


# Generated at 2022-06-25 13:05:09.587530
# Unit test for function md5
def test_md5():
    filename = 'test_file.txt'
    test_string = 'Test string'
    with open(filename, 'w') as test_file:
        test_file.write(test_string)
    md5_string = md5(filename)
    os.remove(filename)
    assert md5_string == '6f8db599de986fab7a21625b7916589c'


# Generated at 2022-06-25 13:05:13.439543
# Unit test for function checksum
def test_checksum():
    assert checksum('filename') == secure_hash('filename')


# Generated at 2022-06-25 13:05:14.871916
# Unit test for function md5s
def test_md5s():
    bool_0 = False
    assert md5s(bool_0) == None


# Generated at 2022-06-25 13:05:16.121433
# Unit test for function md5
def test_md5():
    assert md5(filename="file") == None



# Generated at 2022-06-25 13:05:17.161503
# Unit test for function checksum
def test_checksum():
    assert secure_hash(filename)


# Generated at 2022-06-25 13:05:21.910357
# Unit test for function md5
def test_md5():
    data_file_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'lib', 'basic.yml'))
    test_md5 = md5(data_file_path)
    assert test_md5 == "8a0c8bead7b050959b8e8d228cf56e0d"


# Generated at 2022-06-25 13:05:23.225165
# Unit test for function checksum
def test_checksum():
    path = os.path.realpath(__file__)
    result = checksum(path)
    print(result)


# Generated at 2022-06-25 13:05:25.365520
# Unit test for function md5
def test_md5():
    assert md5('tests/data/templates/hosts') == 'c5e9ce878f00a7dca86f05c365701d0a'


# Generated at 2022-06-25 13:05:30.187960
# Unit test for function md5
def test_md5():
    assert md5('../../fixtures/test.txt') == '784bba7266eee8b2a2b7f70b01a0b7d9', "md5: The output does not match the expected output"


# Generated at 2022-06-25 13:05:32.913656
# Unit test for function checksum
def test_checksum():
    bool_0 = True
    var_0 = checksum(bool_0)
    bool_1 = False
    var_1 = checksum(bool_1)

#

# Generated at 2022-06-25 13:05:35.738058
# Unit test for function md5s
def test_md5s():
    var_1 = 'test'
    if md5s(var_1) == '098f6bcd4621d373cade4e832627b4f6':
        assert True
    else:
        assert False
    

# Generated at 2022-06-25 13:05:37.436214
# Unit test for function md5s
def test_md5s():
    assert test_case_0()

test_case_0_test_md5s = test_case_0()


# Generated at 2022-06-25 13:05:39.247267
# Unit test for function md5s
def test_md5s():
    assert md5s(True) == "78e731027d8fd50ed642340b7c9a63b3"


# Generated at 2022-06-25 13:05:40.130687
# Unit test for function md5s
def test_md5s():
    print(md5s("test"))


# Generated at 2022-06-25 13:05:42.392986
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/passwd') == 'c63c9e50b86ae57bf5f80b1aa6b79359'


# Generated at 2022-06-25 13:05:48.195773
# Unit test for function checksum
def test_checksum():
    print("Unit test for function checksum")

    path = "dummyfile"

    # Test function with no input
    checksum_no_input = checksum()

    # Test function with valid input
    checksum_valid_input = checksum(path)

    # Test function with invalid input
    checksum_invalid_input = checksum(1234)

    assert checksum_no_input is None
    assert checksum_valid_input is not None
    assert checksum_invalid_input is None


# Generated at 2022-06-25 13:05:51.749716
# Unit test for function md5s
def test_md5s():
    var_0 = "hello"
    var_1 = md5s(var_0)
    assert(var_1 == "5d41402abc4b2a76b9719d911017c592")

if __name__ == '__main__':
    test_case_0()
    test_md5s()

# Generated at 2022-06-25 13:06:03.665335
# Unit test for function md5
def test_md5():
    # 'False'
    assert md5s(False) == '5feceb66ffc86f38d952786c6d696c79'
    # 'True'
    assert md5s(True) == '5feceb66ffc86f38d952786c6d696c79'
    # 1
    assert md5s(1) == 'c4ca4238a0b923820dcc509a6f75849b'
    # 2
    assert md5s(2) == 'c81e728d9d4c2f636f067f89cc14862c'
    # 3
    assert md5s(3) == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'
    # 'xyz'
    assert md

# Generated at 2022-06-25 13:06:08.666086
# Unit test for function md5
def test_md5():
    assert md5("test case") == "9dd4e461268c8034f5c8564e155c67a6", "md5 function failed"


# Generated at 2022-06-25 13:06:15.321753
# Unit test for function md5s
def test_md5s():
    assert (md5s(False) == '78ee5ca11e19c102c458fda7ed8d42ac')
    assert (md5s(True) == '2e99758548972a8e8822ad47fa1017ff')
    assert (md5s('a') == '0cc175b9c0f1b6a831c399e269772661')
    assert (md5s('ab') == '187ef4436122d1cc2f40dc2b92f0eba0')
    assert (md5s('abc') == '900150983cd24fb0d6963f7d28e17f72')
    assert (md5s('abcd') == 'e2fc714c4727ee9395f324cd2e7f331f')

# Generated at 2022-06-25 13:06:18.162125
# Unit test for function md5
def test_md5():
    bool_1 = True
    ansible_0 = secure_hash_s(bool_1)
    assert ansible_0 == '900150983cd24fb0d6963f7d28e17f72'


# Generated at 2022-06-25 13:06:23.394245
# Unit test for function md5s
def test_md5s():
    bool_0 = False
    string_0 = "ansible"
    string_1 = "ansible"
    string_2 = "5f5d7ea045ca1a9f0f5de10f0c617de6"
    #Test case 0
    assert string_2 == md5s(bool_0)
    #Test case 1
    assert str(string_1) == md5s(string_0)


# Generated at 2022-06-25 13:06:33.251474
# Unit test for function checksum
def test_checksum():
    assert checksum('var/test/test_copy_module/test_src', sha1) == 'd4f7312a88b5eeeab73ad5f5a5d5c5b1af5baf7e'
    assert checksum('var/test/test_copy_module/test_dst_abc', sha1) == '675f81562b5a0d4ee0b5f5b5f5f5c5d5d5b5a5b5'
    assert checksum('var/test/test_copy_module/test_dst_dir', sha1) == '675f81562b5a0d4ee0b5f5b5f5f5c5d5d5b5a5b5'

# Generated at 2022-06-25 13:06:34.557450
# Unit test for function md5
def test_md5():
    # Tests fixed behaviour
    assert md5('filename')
    assert md5(2) == None


# Generated at 2022-06-25 13:06:37.615663
# Unit test for function md5s
def test_md5s():
    print('Test 0')
    test_case_0()
    print('Test 1')
    var_1 = b'ansible'
    md5s(var_1)
    print('Test 2')
    var_2 = 'ansible'
    md5s(var_2)



# Generated at 2022-06-25 13:06:40.340298
# Unit test for function checksum
def test_checksum():
    src = 'test/test_data/testfile.txt'
    assert os.path.exists(src)
    assert checksum(src) == '5fc955d9cd8e8e744a6a27a6dcd56fd8'


# Generated at 2022-06-25 13:06:43.444419
# Unit test for function md5
def test_md5():
    assert(char_0 == md5(unicode_0)), "Check md5 on non-existent file"
    assert(ansible_0 == md5(unicode_1)), "Check md5 on ansible playbook"
    char_1 = md5(unicode_2)
    assert(char_1 is None), "Check md5 on a directory"



# Generated at 2022-06-25 13:06:44.600627
# Unit test for function md5s
def test_md5s():
    assert True


# Generated at 2022-06-25 13:06:51.546900
# Unit test for function md5s
def test_md5s():
    assert checksum_s('hello') == md5s('hello'), "md5s does not match ansible's checksum_s"
    assert checksum_s('hello') == md5s(False), "md5s does not match ansible's checksum_s"


# Generated at 2022-06-25 13:06:55.305112
# Unit test for function md5s
def test_md5s():
    assert "d41d8cd98f00b204e9800998ecf8427e" == md5s(None)


# Generated at 2022-06-25 13:06:59.128802
# Unit test for function md5s
def test_md5s():
    bool_0 = bool('False')
    var_0 = md5s(bool_0)
    assert var_0 == '5feceb66ffc86f38d952786c6d696c79', var_0


# Generated at 2022-06-25 13:07:04.297756
# Unit test for function md5s
def test_md5s():
    assert md5s("dGVzdA==") == "ab07acbb1e496801937adfa772424bf7"
    assert md5s("dGVzdA==") == "ab07acbb1e496801937adfa772424bf7"
    assert md5s("dGVzdA==") == "ab07acbb1e496801937adfa772424bf7"


# Generated at 2022-06-25 13:07:08.300698
# Unit test for function checksum
def test_checksum():
    # Run tests for function with different values
    value = checksum("/etc/hosts")
    print(value)
    assert value == 'cc5f2a5c553a5d48b5f6a7af6cfc3b97'

if __name__ == '__main__':
    test_case_0()
    test_checksum()

# Generated at 2022-06-25 13:07:12.386086
# Unit test for function md5s
def test_md5s():
    # This test assumes the code is being tested is in the same directory
    # as the test.  This is NOT a good assumption for all cases.
    fixture_path = os.path.join(os.path.dirname(__file__), 'test_fixtures')
    test_path = os.path.join(fixture_path, "test_md5_s")

    with open(test_path, 'rb') as f:
        test_data = f.read()

    test_checksum = md5s(test_data)

    assert test_checksum is not None

# Generated at 2022-06-25 13:07:14.118166
# Unit test for function checksum
def test_checksum():

    try:
        checksum('/file/path')
    except TypeError:
        print('TypeError caught')
    except IOError:
        print('IOError caught')


# Generated at 2022-06-25 13:07:17.269253
# Unit test for function checksum
def test_checksum():
    assert checksum("/Users/lucasjones/Documents/Work/Python/ansible/lib/ansible/modules/packaging/os/yum.py") == 'b8a66d2bd2c30321f6cb5cb7ee8ecf69a52b907e'

# Generated at 2022-06-25 13:07:24.029024
# Unit test for function md5
def test_md5():
    # This test should fail
    try:
        assert to_bytes(md5('/home/sh/D303')) == 'a859ae35e9f037ffb3e6486f8e28f44c'
    except ComparisonFailure:
        pass
    # This test should fail
    try:
        assert to_bytes(md5('/home/sh/工具/Python/安装包/sublime_text_3_build_3083_x64.tar.bz2')) == 'be8a29d938e5e06f091f6acd2965d3aa'
    except ComparisonFailure:
        pass
    # This test should fail

# Generated at 2022-06-25 13:07:25.995277
# Unit test for function checksum
def test_checksum():
    h1 = checksum("/etc/passwd")
    h2 = checksum("/etc/shadow")
    assert h1 != h2


# Generated at 2022-06-25 13:07:34.352936
# Unit test for function md5
def test_md5():
    print("Test md5")

    print("Test case 0 - Empty input array")
    test_case_0()
    print("Test case 1 - md5 of 12345678")
    print("SHA512: %s" % md5("12345678"))
    print("Test case 2 - md5 of abcde")
    print("SHA512: %s" % md5("abcde"))


# Generated at 2022-06-25 13:07:39.787733
# Unit test for function md5s
def test_md5s():
    try:
        print('\n=================== test_md5s ===================\n')
        test_case_0()
    except Exception:
        print('\n=================== debug_start ===================\n')
        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback.print_exception(exc_type, exc_value, exc_traceback, limit=5, file=sys.stdout)
        print('\n=================== debug_end ===================\n')



# Generated at 2022-06-25 13:07:41.062673
# Unit test for function md5
def test_md5():
    # true expected result
    assert md5('test_file') == None

# Generated at 2022-06-25 13:07:42.839064
# Unit test for function md5s
def test_md5s():
    md5s = secure_hash_s(hash_func=md5)
    assert md5s != None


# Generated at 2022-06-25 13:07:45.293258
# Unit test for function md5
def test_md5():
    assert(md5(b'/tmp/ansible_file') ==  '722d5d473330c2409e03bde0b3c3d3a5')


# Generated at 2022-06-25 13:07:46.394484
# Unit test for function md5s
def test_md5s():
    test_case_0()


# Generated at 2022-06-25 13:07:47.230692
# Unit test for function md5
def test_md5():
    assert True == True


# Generated at 2022-06-25 13:07:49.261914
# Unit test for function checksum
def test_checksum():
    var_0 = 't0sT'
    var_0_var_0 = md5s(var_0)
    return var_0_var_0


# Generated at 2022-06-25 13:07:50.619857
# Unit test for function md5s
def test_md5s():
    bool_0 = False
    var_0 = md5s(bool_0)


# Generated at 2022-06-25 13:07:51.381096
# Unit test for function checksum
def test_checksum():
    assert callable(checksum)


# Generated at 2022-06-25 13:07:58.085838
# Unit test for function md5
def test_md5():
    test_0_data = os.path.join(os.path.dirname(__file__), '../../../test/integration/targets/module_utils/')
    test_0_output = md5(test_0_data)
    assert test_0_output == 'eb33cd042a5b0d77ee7a45a747a1fde8'


# Generated at 2022-06-25 13:08:05.696238
# Unit test for function md5
def test_md5():
    # Assign values to variables
    bool_0 = False
    str_0 = "8q3WEP7vS"

    str_1 = md5s(str_0)
    # Test for no value
    bool_1 = bool_0 is None
    bool_2 = bool_0 is not None
    bool_3 = bool_0 not in (None)

    # Test for str value
    bool_4 = "q3WEP7vS" in str_0
    bool_5 = bool_0 not in str_0
    # Test for bool value
    bool_6 = bool_0 is bool_0
    bool_7 = bool_1 is bool_0


# Generated at 2022-06-25 13:08:06.463131
# Unit test for function md5s
def test_md5s():
    assert md5s == md5s


# Generated at 2022-06-25 13:08:15.696241
# Unit test for function md5s
def test_md5s():
    bool_0 = True
    var_0 = md5s(bool_0)
    int_0 = 835
    var_1 = md5s(int_0)
    str_0 = 'Hello World'
    var_2 = md5s(str_0)
    int_1 = -558
    var_3 = md5s(int_1)
    int_2 = -667
    var_4 = md5s(int_2)
    int_3 = -291
    var_5 = md5s(int_3)
    str_1 = 'Hello World'
    var_6 = md5s(str_1)
    str_2 = 'Hello World'
    var_7 = md5s(str_2)
    str_3 = 'Hello World'
    var_8 = md5s

# Generated at 2022-06-25 13:08:16.966409
# Unit test for function md5s
def test_md5s():
    assert secure_hash_s('foo', _md5) == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-25 13:08:18.067771
# Unit test for function md5s
def test_md5s():
    bool_0 = False
    assert md5s(bool_0) == '9e107d9d372bb6826bd81d3542a419d6'


# Generated at 2022-06-25 13:08:27.268202
# Unit test for function checksum
def test_checksum():
    assert md5s(False) == '78e731027d8fd50ed642340b7c9a63b3'
    assert md5s(123) == '202cb962ac59075b964b07152d234b70'
    assert md5s('123') == '202cb962ac59075b964b07152d234b70'
    assert md5s('string') == '94a2be8b22f8323caf9eec851ccb0347'
    assert md5s('string') == '94a2be8b22f8323caf9eec851ccb0347'
    assert md5s('string') == '94a2be8b22f8323caf9eec851ccb0347'

# Generated at 2022-06-25 13:08:36.907789
# Unit test for function md5s
def test_md5s():
    print("Unit testing function md5s")
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert secure_hash_s(False, _md5) == md5s(False)
    assert secure_hash_s(True, _md5) == md5s(True)
    assert secure_hash_s(0, _md5) == md5s(0)
    assert secure_hash_s(1234567, _md5) == md5s(1234567)
    assert secure_hash_s("hello world", _md5) == md5s("hello world")
    assert secure_hash_s("", _md5) == md5s("")
    assert secure_hash_s(None, _md5) == md5s(None)
    assert secure

# Generated at 2022-06-25 13:08:43.126943
# Unit test for function md5
def test_md5():
    test_data_0 = "test"
    test_data_0 = to_bytes(test_data_0, errors='surrogate_or_strict')
    print(md5s(test_data_0))
    test_data_1 = "test"
    test_data_1 = to_bytes(test_data_1, errors='surrogate_or_strict')
    print(secure_hash_s(test_data_1))
    test_data_2 = "test"
    test_data_2 = to_bytes(test_data_2, errors='surrogate_or_strict')
    print(checksum_s(test_data_2))
    test_data_3 = "test"

# Generated at 2022-06-25 13:08:44.956775
# Unit test for function md5
def test_md5():
    assert secure_hash("files/test.py", _md5) == md5("files/test.py")

# Generated at 2022-06-25 13:08:51.736150
# Unit test for function checksum
def test_checksum():
    var_0 = secure_hash_s('1234567890')
    assert var_0 == '25f9e794323b453885f5181f1b624d0b'


# Generated at 2022-06-25 13:08:52.952922
# Unit test for function md5
def test_md5():
    assert md5('/tmp/') is None


# Generated at 2022-06-25 13:08:55.225278
# Unit test for function md5s
def test_md5s():
    assert md5s(False) == '78e731027d8fd50ed642340b7c9a63b3'


# Generated at 2022-06-25 13:08:57.549295
# Unit test for function md5s
def test_md5s():
    bool_0 = False
    assert md5s(bool_0) == '78e731027d8fd50ed642340b7c9a63b3'


# Generated at 2022-06-25 13:08:58.232628
# Unit test for function checksum
def test_checksum():
    pass # TODO: implement your test here


# Generated at 2022-06-25 13:09:03.840719
# Unit test for function md5
def test_md5():
    # Should be able to pass in a bool
    test_var = False
    assert md5s(test_var) == '78e731027d8fd50ed642340b7c9a63b3'



# Generated at 2022-06-25 13:09:04.997420
# Unit test for function checksum
def test_checksum():
    bool_0 = False
    var_0 = checksum(bool_0)


# Generated at 2022-06-25 13:09:10.842881
# Unit test for function md5s
def test_md5s():
    assert md5s(True) == '78e731027d8fd50ed642340b7c9a63b3'
    assert md5s(5) == '56461b96b5b915d1e3d36f87800838d4'
    assert md5s(1.5) == 'ea6e7a54d335a2f1b9eafd6ff61b6d1d'
    assert md5s('cisco') == '12d18b345ec8b57c2b2f46b08d495baa'
    assert md5s('bgp') == '1c2e9f8c32d3cde81b624e3b8fd523fa'

# Generated at 2022-06-25 13:09:13.045864
# Unit test for function md5s
def test_md5s():
    assert md5s("test") == "098f6bcd4621d373cade4e832627b4f6"



# Generated at 2022-06-25 13:09:22.882520
# Unit test for function md5
def test_md5():

    # Sourced from:
    # http://www.miniwebtool.com/md5-generator/

    # Source data for test_case_0
    test_case_0_source_data = False

    # Expected result derived from test_case_0_source_data
    test_case_0_expected_result = "cbe0f64eed5c7d5cf5c78f7a5338ec74"

    # Source data for test_case_1
    test_case_1_source_data = False

    # Expected result derived from test_case_1_source_data
    test_case_1_expected_result = "cbe0f64eed5c7d5cf5c78f7a5338ec74"

    # Source data for test_case_2
    test_case_2_source

# Generated at 2022-06-25 13:09:34.230897
# Unit test for function md5s
def test_md5s():
    assert md5s(False) == md5s(False)
    assert md5s(True) == md5s(True)
    assert md5s(0) == md5s(0)
    assert md5s(1) == md5s(1)
    assert md5s(10) == md5s(10)
    assert md5s(11) == md5s(11)
    assert md5s(19) == md5s(19)
    assert md5s(21) == md5s(21)
    assert md5s(29) == md5s(29)
    assert md5s(31) == md5s(31)
    assert md5s(39) == md5s(39)
    assert md5s(41) == md5s(41)

# Generated at 2022-06-25 13:09:43.552536
# Unit test for function md5s
def test_md5s():
    # Test case 1
    bool_0 = False
    var_0 = md5s(bool_0)

    # Test case 2
    bool_0 = True
    var_0 = md5s(bool_0)

    # Test case 3
    int_0 = 0
    var_0 = md5s(int_0)

    # Test case 4
    int_0 = 1
    var_0 = md5s(int_0)

    # Test case 5
    str_0 = "A"
    var_0 = md5s(str_0)

    # Test case 6
    str_0 = "AB"
    var_0 = md5s(str_0)

    # Test case 7
    str_0 = "ABC"
    var_0 = md5s(str_0)

    # Test case

# Generated at 2022-06-25 13:09:51.114085
# Unit test for function md5
def test_md5():
    bool_0 = False
    var_0 = md5(bool_0)
    bool_1 = True
    var_1 = md5(bool_1)
    float_0 = 4.5
    var_2 = md5(float_0)
    float_1 = 8.0
    var_3 = md5(float_1)
    float_2 = 0.5
    var_4 = md5(float_2)
    float_3 = -0.5
    var_5 = md5(float_3)
    int_0 = 0
    var_6 = md5(int_0)
    int_1 = -1
    var_7 = md5(int_1)
    int_2 = 1
    var_8 = md5(int_2)
    int_3 = -214748

# Generated at 2022-06-25 13:09:53.352291
# Unit test for function checksum
def test_checksum():
    filename = "/etc/resolv.conf"
    func_call_0 = checksum(filename)
    assert func_call_0 == "ecce1c85083e6e2a6d8a6c2f6b5f6a5a"

# Generated at 2022-06-25 13:09:53.946761
# Unit test for function md5s
def test_md5s():
    assert True

# Generated at 2022-06-25 13:10:03.783253
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'

# Generated at 2022-06-25 13:10:05.484250
# Unit test for function md5
def test_md5():
    assert md5('bar') == '37b51d194a7513e45b56f6524f2d51f2'



# Generated at 2022-06-25 13:10:07.569661
# Unit test for function md5
def test_md5():
    test_file = "files/test_md5.txt"
    result = md5(test_file)
    assert 10 < result.__len__() < 30


# Generated at 2022-06-25 13:10:10.250871
# Unit test for function md5s
def test_md5s():
    md5s_0 = md5s('')
    assert md5s_0 == 'd41d8cd98f00b204e9800998ecf8427e'



# Generated at 2022-06-25 13:10:12.469814
# Unit test for function md5
def test_md5():
    bool_0 = False
    var_0 = md5s(bool_0)


if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-25 13:10:21.819175
# Unit test for function md5
def test_md5():
    # Need to test these inputs:
    # Filename: "test.file"
    # Input: "test"
    # Input: "test12345"
    # Input: "test______"

    try:
        md5("test.file")
    except ValueError:
        return False

    if md5s("test") == "098f6bcd4621d373cade4e832627b4f6":
        return True
    else:
        return False

    if md5s("test12345") == "25f9e794323b453885f5181f1b624d0b":
        return True
    else:
        return False

    if md5s("test______") == "e52cd87dea31a353a7d0489d9a2077b0":
        return True

# Generated at 2022-06-25 13:10:23.095550
# Unit test for function md5s
def test_md5s():
    assert sha1(to_bytes("False")).hexdigest() == md5s("False")


# Generated at 2022-06-25 13:10:34.208204
# Unit test for function checksum
def test_checksum():
    # Test with valid values
        # Test with valid values
        string_0 = "abc"
        string_1 = "def"
        # This test will fail with FIPS mode enabled
        #assert checksum_s(string_0 + string_1) == md5s(string_0 + string_1)
        #assert checksum_s(string_0) == md5s(string_0)
        #assert checksum_s(string_1) == md5s(string_1)
        #assert checksum_s('string') == md5s('string')
        #assert checksum_s('') == md5s('')
        #assert checksum_s(string_0, sha1) == secure_hash_s(string_0, sha1)
        #assert checksum_s(string_1, sh

# Generated at 2022-06-25 13:10:36.609394
# Unit test for function md5
def test_md5():
    m = md5s('Hello')
    assert m == '8b1a9953c4611296a827abf8c47804d7'

if __name__ == "__main__":
    pass

# Generated at 2022-06-25 13:10:38.453385
# Unit test for function md5
def test_md5():
    assert "8350d8e7dfe70d092f7aa86e58b8d7d3" == md5s(True)
