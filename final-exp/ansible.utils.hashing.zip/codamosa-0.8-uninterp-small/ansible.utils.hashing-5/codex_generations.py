

# Generated at 2022-06-25 13:00:42.593825
# Unit test for function md5s
def test_md5s():
    assert sha1('a').hexdigest() == '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8'


# Generated at 2022-06-25 13:00:45.827371
# Unit test for function checksum
def test_checksum():
    print("checksum")
    assert checksum("49_add_a.py") == "b25d6f77f32c41652a0b0a6b927107b1a6d0fa85"


# Generated at 2022-06-25 13:00:48.868801
# Unit test for function md5s
def test_md5s():
    for i in range(0, 10):
        data = "Unit test for function md5s " + str(i)
        assert data == md5s(data), "Failed assert unit test for function md5s"


# Generated at 2022-06-25 13:00:56.312622
# Unit test for function checksum
def test_checksum():
    temp_file = "temp_file"
    string_0 = "foo"
    checksum_new = checksum(temp_file)
    checksum_s_new = checksum_s(string_0)
    md5_new = md5(temp_file)
    md5s_new = md5s(string_0)
    secure_hash_new = secure_hash(temp_file)
    secure_hash_s_new = secure_hash_s(string_0)


if __name__ == "__main__":

    # Run the unit tests
    test_checksum()
    test_case_0()

# Generated at 2022-06-25 13:01:01.613312
# Unit test for function checksum
def test_checksum():
    assert checksum(0) == 'cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e'

# Generated at 2022-06-25 13:01:02.290243
# Unit test for function md5
def test_md5():
    test_case_0()



# Generated at 2022-06-25 13:01:05.266220
# Unit test for function checksum
def test_checksum():
    '''
    Test the module checksum
    '''
    assert checksum("foo.txt") == "4f7a0c48b9a7b9f64c3f8e363c93d04f0c1a2b2a"

# Generated at 2022-06-25 13:01:06.448512
# Unit test for function md5s
def test_md5s():
    print("Testing md5s")
    test_case_0()


# Generated at 2022-06-25 13:01:08.522072
# Unit test for function checksum
def test_checksum():
    data = "abcdefghijklmnopqrstuvwxyz"
    checksum = secure_hash_s(data)
    print(checksum)


# Generated at 2022-06-25 13:01:16.779382
# Unit test for function md5
def test_md5():
    float_0 = -727.167
    list_0 = [float_0]
    list_1 = [float_0]
    float_1 = float_0
    # Verifies that the md5 function is working
    assert md5(float_0) is not None, "md5 Failed"
    # Verifies that the md5 function is working
    assert md5(list_0) is not None, "md5 Failed"
    # Verifies that the md5 function is working
    assert md5(list_1) is not None, "md5 Failed"
    # Verifies that the md5 function is working
    assert md5(float_1) is not None, "md5 Failed"



# Generated at 2022-06-25 13:01:22.523755
# Unit test for function md5s
def test_md5s():
    print ('Test md5s()')
    assert (md5s(test_case_0()) == 'c3fcd3d76192e4007dfb496cca67e13b'), 'md5s() is incorrect'


# Generated at 2022-06-25 13:01:25.295966
# Unit test for function md5
def test_md5():
    str_0 = 'abcdefghijklmnopqrstuvwxyz'
    result = md5(str_0)
    assert result == '0cc175b9c0f1b6a831c399e269772661'


# Generated at 2022-06-25 13:01:32.152752
# Unit test for function checksum
def test_checksum():
    str_0 = 'abcdefghijklmnopqrstuvwxyz'
    assert (checksum(str_0) == '22a52a90cba38ab8b00bfb0febd2dbc0cc6bff9c'), 'Failed checksum test'
    str_0 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert (checksum(str_0) == 'f4656c11b6fe71b6cbc42c56af8a94b53ec88b22'), 'Failed checksum test'


# Generated at 2022-06-25 13:01:37.900732
# Unit test for function checksum
def test_checksum():
    assert checksum(os.path.basename(__file__)) == 'd44b5f8b7c5e5db5f7c5ae5e9b67a62b657874d7'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    test_case_0()


# Generated at 2022-06-25 13:01:45.694639
# Unit test for function md5
def test_md5():
    # string
    assert md5s(str_0) == 'c3fcd3d76192e4007dfb496cca67e13b'
    # file
    assert md5(str_0) == 'c3fcd3d76192e4007dfb496cca67e13b'

if __name__ == '__main__':
    try:
        import nose2
        nose2.main()
    except ImportError:
        # don't have nose2 installed
        import nose
        nose.runmodule()

# vim: set et tabstop=4:

# Generated at 2022-06-25 13:01:49.397506
# Unit test for function checksum
def test_checksum():

    # . . . . . . . . . . . . . . . . . . . .
    # Expected Output:
    # . . . . . . . . . . . . . . . . . . . .

    # "str_0"
    assert checksum(str_0) == 'c3fcd3d76192e4007dfb496cca67e13b'


# Generated at 2022-06-25 13:01:54.352101
# Unit test for function md5
def test_md5():
    # No arguments provided
    # test function call
    try:
        md5()
    except TypeError as e:
        assert str(e) == "md5() takes exactly 1 argument (0 given)"


# Generated at 2022-06-25 13:02:04.423870
# Unit test for function checksum
def test_checksum():
    assert checksum('abcdefghijklmnopqrstuvwxyz', _md5) == 'c3fcd3d76192e4007dfb496cca67e13b'
    assert checksum('abcdefghijklmnopqrstuvwxyz', sha1) == '32d10c7b8cf96570ca04ce37f2a19d84240d3a89'
    assert checksum('abcdefghijklmnopqrstuvwxyz') == '32d10c7b8cf96570ca04ce37f2a19d84240d3a89'

# Generated at 2022-06-25 13:02:06.660958
# Unit test for function checksum
def test_checksum():
    assert (checksum(str_0)=="7991c4f9eaaafc4f7f201b5a0b8a479987c284ad")


# Generated at 2022-06-25 13:02:15.278858
# Unit test for function checksum
def test_checksum():
    str_1 = 'abcdefghijklmnopqrstuvwxyz'
    assert checksum_s(str_1) == 'yz'
    # FIXME: What should the code do here?
    # assert checksum_s(str_1, md5) == None, " checksum_s(str_1, md5) returned: %s" % (checksum_s(str_1, md5))
    # FIXME: What should the code do here?
    # assert checksum_s(str_1, md5) == None, " checksum_s(str_1, md5) returned: %s" % (checksum_s(str_1, md5))
    # FIXME: What should the code do here?
    # assert checksum_s(str_1, md5) == None, " checks

# Generated at 2022-06-25 13:02:21.354005
# Unit test for function checksum
def test_checksum():
    str_0 = 'abcdefghijklmnopqrstuvwxyz'
    assert checksum(str_0) == '7c4a8d09ca3762af61e59520943dc26494f8941b'



# Generated at 2022-06-25 13:02:29.943926
# Unit test for function md5s
def test_md5s():
    str_0 = 'abcdefghijklmnopqrstuvwxyz'
    str_1 = md5s(str_0)
    str_2 = 'c3fcd3d76192e4007dfb496cca67e13b'
    ansible_module_0 = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )
    if str_1 != str_2:
        ansible_module_0.fail_json(msg='Expected different output when calling md5s')


# Generated at 2022-06-25 13:02:30.980265
# Unit test for function checksum

# Generated at 2022-06-25 13:02:34.665121
# Unit test for function md5
def test_md5():
    str_0 = 'abcdefghijklmnopqrstuvwxyz'
    str_1 = 'abcdefghijklmnopqrstuvwxyz'
    assert md5s(str_0) == md5s(str_1)


# Generated at 2022-06-25 13:02:38.313950
# Unit test for function checksum
def test_checksum():
    test_case_0()
    assert '0cbc6611f5540bd0809a388dc95a615b' == checksum_s(str_0)
    assert '26d35d9c4f4a8c18b195e0d4f4e289a0' == md5s(str_0)

if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-25 13:02:42.970940
# Unit test for function checksum
def test_checksum():
    filename = str_0
    result = checksum(filename)
    assert result == 'e3de7ff2a9a77c4439e0b9d16fa79a5f2648563b'


# Generated at 2022-06-25 13:02:45.444947
# Unit test for function checksum
def test_checksum():
    assert checksum(test_case_0.str_0)=='c3fcd3d76192e4007dfb496cca67e13b'


# Generated at 2022-06-25 13:02:48.849988
# Unit test for function md5
def test_md5():
    str_0 = 'abcdefghijklmnopqrstuvwxyz'
    str_1 = md5s(str_0)
    print(str_1)
    pass


# Generated at 2022-06-25 13:02:51.392855
# Unit test for function checksum
def test_checksum():
    file_0 = 'test_file_0'

    # Call function with args
    try:
        result = checksum(file_0)
    except NameError:
        pass

    # Call function with args
    try:
        result = checksum(file_0, 2)
    except NameError:
        pass



# Generated at 2022-06-25 13:02:53.268550
# Unit test for function md5s
def test_md5s():
    assert(md5s(str_0) == 'c3fcd3d76192e4007dfb496cca67e13b')


# Generated at 2022-06-25 13:02:59.260312
# Unit test for function checksum
def test_checksum():
    assert checksum('test/test.txt') == 'a9d1a1b8c0bb639ba051f51d6b32fec839049e4d'


# Generated at 2022-06-25 13:03:02.071822
# Unit test for function md5
def test_md5():
    assert md5('test/resources/test_copy.txt') == '9dbc6a9a6f74ebd95b7b17cbb6f6514d'


# Generated at 2022-06-25 13:03:04.124547
# Unit test for function checksum
def test_checksum():

    assert checksum('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d', "Test for checksum"


# Generated at 2022-06-25 13:03:07.451721
# Unit test for function md5s
def test_md5s():
    str_0 = 'abcdefghijklmnopqrstuvwxyz'
    assert md5s(str_0) == 'c3fcd3d76192e4007dfb496cca67e13b'


# Generated at 2022-06-25 13:03:15.988887
# Unit test for function md5s
def test_md5s():
    assert md5s('qwertyuiop') == 'adbcdf72f32ce8996c0a67f025d72566'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('abcdefghijklmnopqrstuvwxyz') == 'c3fcd3d76192e4007dfb496cca67e13b'
    assert md5s('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789') == 'd174ab98d277d9f5a5611c2c9f419d9f'


# Generated at 2022-06-25 13:03:18.891223
# Unit test for function checksum
def test_checksum():
  print(checksum(test_case_0))
  print(checksum_s(test_case_0))
  print(md5(test_case_0))
  print(checksum_s(test_case_0))


# Generated at 2022-06-25 13:03:21.582964
# Unit test for function checksum
def test_checksum():
    assert checksum('test_hash_utils.py') == '7b9c9cfdd5e5e5d5b0fc11b8c8dea98f975b0e61'


# Generated at 2022-06-25 13:03:24.419255
# Unit test for function checksum
def test_checksum():
    #assert checksum.__doc__
    assert checksum(test_case_0, sha1) == 'c3fcd3d76192e4007dfb496cca67e13b';



# Generated at 2022-06-25 13:03:26.665019
# Unit test for function checksum
def test_checksum():
    assert checksum('/usr/bin/ansible') == checksum_s('/usr/bin/ansible')


# Generated at 2022-06-25 13:03:32.414704
# Unit test for function checksum
def test_checksum():
    ansible_0 = 'abcdefghijklmnopqrstuvwxyz'
    assert checksum(ansible_0) == 'c3fcd3d76192e4007dfb496cca67e13b'
    ansible_0 = 'abcdefghijklmnopqrstuvwxyz'
    assert checksum_s(ansible_0) == 'c3fcd3d76192e4007dfb496cca67e13b'


# Generated at 2022-06-25 13:03:36.546568
# Unit test for function checksum
def test_checksum():
    pass


# Generated at 2022-06-25 13:03:42.018765
# Unit test for function checksum
def test_checksum():
    # Create a list of inputs
    inputs = [('string', None)]
    inputs += [('file', '.README.md')]
    outputs = [('74681a8b13043f9ecd331f3c1d822a8b', 'string'),
               ('e4d7f1b4cbfbf65d9fafb4d4e4fd1412', 'file')]

    for i, inp in enumerate(inputs):
        rc = checksum(*inp)
        assert rc == outputs[i][0], 'Expected %s, got %s' % (outputs[i][0], rc)


# Generated at 2022-06-25 13:03:45.730436
# Unit test for function checksum
def test_checksum():
    print(checksum(str_0))
    print(checksum_s(str_0))
    print(md5(str_0))
    print(md5s(str_0))

if __name__ == '__main__':
    test_case_0()
    test_checksum()

# Generated at 2022-06-25 13:03:53.084743
# Unit test for function checksum
def test_checksum():
    # Test case 0
    print('Testing case 0')
    print('file contents: ' + str_0)
    test_0_checksum = 'c3fcd3d76192e4007dfb496cca67e13b'
    test_0_result = checksum(str_0)
    print('expected checksum: ' + test_0_checksum)
    print('returned checksum: ' + test_0_result)
    assert test_0_result == test_0_checksum
    print('PASS for case 0')


# Generated at 2022-06-25 13:03:56.041455
# Unit test for function md5
def test_md5():
    str_1 = 'abcdefghijklmnopqrstuvwxyz'
    assert md5s(str_1) == 'c3fcd3d76192e4007dfb496cca67e13b'


# Generated at 2022-06-25 13:04:01.652804
# Unit test for function checksum
def test_checksum():
    #
    # Test with a valid argument type
    #
    filename = '/etc/passwd'
    result = checksum(filename)
    assert isinstance(result, str)

    #
    # Test with an invalid argument type
    #
    try:
        checksum(str_0)
    except ValueError:
        pass
    else:
        raise Exception('ExpectedValueError')


# Generated at 2022-06-25 13:04:07.299414
# Unit test for function md5
def test_md5():
    str_0 = 'abcdefghijklmnopqrstuvwxyz'
    str_1 = 'abcdefghijklmnopqrstuvwxyz'
    assert md5s(str_0) == 'c3fcd3d76192e4007dfb496cca67e13b'
    assert md5(str_1) == 'c3fcd3d76192e4007dfb496cca67e13b'


# Generated at 2022-06-25 13:04:11.834787
# Unit test for function checksum
def test_checksum():
  str_0 = 'abcdefghijklmnopqrstuvwxyz'
  res = checksum_s(str_0)
  exp = 'c3fcd3d76192e4007dfb496cca67e13b'
  assert res == exp, 'Expected "%s", but got "%s"' % (exp, res)


# Generated at 2022-06-25 13:04:13.074161
# Unit test for function md5s
def test_md5s():
    print(md5s(test_case_0))


# Generated at 2022-06-25 13:04:16.316669
# Unit test for function md5
def test_md5():
    str_0 = 'abcdefghijklmnopqrstuvwxyz'
    if not _md5:
        md5_0 = None
    else:
        md5_0 = md5(str_0)



# Generated at 2022-06-25 13:04:22.544887
# Unit test for function checksum
def test_checksum():
    assert checksum('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum('test', hash_func=sha1) == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'


# Generated at 2022-06-25 13:04:23.867363
# Unit test for function md5s
def test_md5s():
    int_0 = 161
    var_0 = md5s(int_0)


# Generated at 2022-06-25 13:04:27.241921
# Unit test for function md5s
def test_md5s():
    assert md5s(161) == "a14dd1e81f9190e1c6e3b6ebdedb88da"



# Generated at 2022-06-25 13:04:30.360788
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5("/bin/ls") == '6f8db599de986fab7a21625b7916589c'


# Generated at 2022-06-25 13:04:33.082022
# Unit test for function md5
def test_md5():
    assert md5("/bin/cat") == 'cba84c54b4d0d8c0b2e2cafea98f1154'


# Generated at 2022-06-25 13:04:39.298390
# Unit test for function md5
def test_md5():
    dash = '-'
    b = 'b'
    data = '90125b4c0b301f0d0c0bb0b4c4b4c0b4b4c4b4c0f0b4c4b4b4c4c0b'
    expected_result = '8ae8c7d54fb78e0ffa1b8a6a0d6f9a2a'
    result = md5s(data)
    assert result == expected_result

# Generated at 2022-06-25 13:04:49.272835
# Unit test for function md5
def test_md5():
    # Test case 0
    int_0 = 161
    var_0 = md5s(int_0)
    assert var_0 == 'b6cbf65e300814ed8cf7eeab2c16e32e'
    try:
        md5(int_0)
        assert False, "Calling md5 with an int input didn't throw an exception"
    except TypeError:
        assert True, "Calling md5 with an int input threw an exception"
    # Test case 1
    int_1 = 224
    var_1 = md5s(int_1)
    assert var_1 == '4c9b7a4b1384fc8d634870bb6f0a6241'

# Generated at 2022-06-25 13:04:51.450800
# Unit test for function md5
def test_md5():
    assert md5("test_data/test_file_1") == "d41d8cd98f00b204e9800998ecf8427e"


# Generated at 2022-06-25 13:04:55.895472
# Unit test for function checksum
def test_checksum():
    assert checksum_s(161) == '44b8f1b6ed9ee16d9d62be5f6e5a6c5a6d5f6e5a6c5a6d5f6e5a6c5a6d5f6e5a'



# Generated at 2022-06-25 13:04:59.082550
# Unit test for function checksum
def test_checksum():
    assert checksum(None) == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'


# Generated at 2022-06-25 13:05:03.193266
# Unit test for function md5
def test_md5():
    int_0 = 161
    var_0 = md5s(int_0)
    assert( var_0 == 'ca9a03f2a8f7bae8c13f2fea5a5a5c5b')

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-25 13:05:05.750864
# Unit test for function md5s
def test_md5s():
    assert('ea03e6a9a3f74d4879d6ab78a6b0fd28' == md5s(161))


# Generated at 2022-06-25 13:05:07.676208
# Unit test for function checksum
def test_checksum():
    c = checksum
    assert c('tiny.txt') == '14a081067279b36775abb50e699ecaf4'


# Generated at 2022-06-25 13:05:15.210160
# Unit test for function md5
def test_md5():
    assert md5('file1.txt') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('file2.txt') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('file3.txt') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('file4.txt') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5('file5.txt') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5('file6.txt') == 'b4ba93170358df216e8648734ac2d539'


# Generated at 2022-06-25 13:05:16.979048
# Unit test for function md5
def test_md5():
    with pytest.raises(ValueError) as e:
        md5('')


# Generated at 2022-06-25 13:05:19.305400
# Unit test for function md5
def test_md5():
    assert(md5s(161)=='f6e43b7d78d92382aa7bd1af40cdfd93')


# Generated at 2022-06-25 13:05:21.369485
# Unit test for function md5s
def test_md5s():
    # Check if content is the same
    assert md5s('161') == '68b329da9893e34099c7d8ad5cb9c940'



# Generated at 2022-06-25 13:05:22.390666
# Unit test for function md5
def test_md5():
    # Test cases for function md5
    test_case_0()



# Generated at 2022-06-25 13:05:24.103794
# Unit test for function md5
def test_md5():
    assert md5('sums.py') == '6a98705c24f8a02f56c37e4a4a4f4c9f'


# Generated at 2022-06-25 13:05:25.730821
# Unit test for function md5
def test_md5():
	test_case_0()

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-25 13:05:29.981067
# Unit test for function md5
def test_md5():
    assert md5(filename) == secure_hash(filename, _md5)


# Generated at 2022-06-25 13:05:34.733188
# Unit test for function checksum
def test_checksum():
    test_string = "This is the string to be checksum'd"
    test_case_0()
    assert checksum(__file__) != None
    assert checksum_s(test_string) == 'b33ff63d8c1a9be959c3f5f5d8c5489a17e7e85c'


# Generated at 2022-06-25 13:05:43.146087
# Unit test for function md5s
def test_md5s():
    int_0 = 161
    var_0 = md5s(int_0)

    if var_0 != 'baacd8b5f5bb5f5c5a5d5a5b5d5e5a5b5e5d5f5e5d5a5b5f5b5f5c5c5d5f5e5e5c5e5b5f5b5f5f5b5c5a5d5d5b5d5e5e5b5e5d5d5e5b5e5f5c5f5d5d5b5f5b5c5b5b5e5d5a5f5b':
        raise ValueError('md5s Unit Test #0 failed')

# Generated at 2022-06-25 13:05:47.666191
# Unit test for function md5s
def test_md5s():
    # Simulate the var_0 variable being passed into md5s and assert the result
    int_0 = 161
    int_0 = str(int_0)
    var_0 = md5s(int_0)
    assert var_0 == '9fef9abdce70166124f02e7baa4546ad'
test_case_0()

# Generated at 2022-06-25 13:05:53.442296
# Unit test for function md5
def test_md5():
    data = 'The quick brown fox jumps over the lazy dog'
    true_hash = '9e107d9d372bb6826bd81d3542a419d6'

# Generated at 2022-06-25 13:06:05.505657
# Unit test for function checksum
def test_checksum():

    assert checksum(os.path.join(os.path.dirname(__file__), '../../CHANGELOG')) == 'e5e1f5d5f8b88695c3e5070b9c94d1e8f5c73f42'
    assert checksum(os.path.join(os.path.dirname(__file__), '../../README.md')) == '0e1399b8a83fba823a2e9e9514b0dae911a78cfe'
    assert checksum(os.path.join(os.path.dirname(__file__), '../../CONTRIBUTING.md')) == '5b534cdb5f5b9a5b3f3edfc7dfd2a895b7fda6ad'

# Generated at 2022-06-25 13:06:07.222432
# Unit test for function md5s
def test_md5s():
    int_0 = 161
    var_0 = md5s(int_0)


# Generated at 2022-06-25 13:06:10.130323
# Unit test for function md5s
def test_md5s():
    int_0 = 161
    var_0 = md5s(int_0)
    assert var_0 == "a66abfcd7d0f52c9dcd2e6f3a3a31be6", var_0


# Generated at 2022-06-25 13:06:12.182977
# Unit test for function md5s
def test_md5s():
    print("\n=== function md5s ===")
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 13:06:14.289731
# Unit test for function md5s
def test_md5s():
    print('# Testing md5s function')
    print(md5s(161))



# Generated at 2022-06-25 13:06:18.279737
# Unit test for function md5
def test_md5():
    int_0 = 161
    var_0 = md5s(int_0)


# Generated at 2022-06-25 13:06:19.943855
# Unit test for function md5
def test_md5():
    print('Test 0')
    test_case_0()

# Run tests
test_md5()

# Generated at 2022-06-25 13:06:29.821909
# Unit test for function md5

# Generated at 2022-06-25 13:06:32.538913
# Unit test for function md5
def test_md5():
    assert md5(448) == '1bf31c7f85c51cb57d7d30b0cae5bcee'

if __name__ == "__main__":
    test_md5()

# Generated at 2022-06-25 13:06:33.050710
# Unit test for function md5
def test_md5():
    pass


# Generated at 2022-06-25 13:06:37.069773
# Unit test for function md5
def test_md5():
    answer = md5("testdata/ansible_test/testdata0")
    assert answer == "bb24d4e4fd47d55c9f7bb9bdbc0d7d86"

    answer = md5("testdata/ansible_test/testdata1")
    assert answer == "c43d8d26a20b5c5b5cf1e5d8f5e1b44c"


# Generated at 2022-06-25 13:06:44.067042
# Unit test for function md5s
def test_md5s():
    int_0 = 161
    var_0 = md5s(int_0)
    print("md5s(" + str(int_0) + ") returns: " + str(var_0))

# Generated at 2022-06-25 13:06:45.661441
# Unit test for function md5s
def test_md5s():
    assert 'dc0c73d1ceb9a97f7313778bcdc769d8' == md5s(161)

test_case_0()
test_md5s()

# Generated at 2022-06-25 13:06:47.345057
# Unit test for function md5s
def test_md5s():
    actual_output = md5s("161")
    expected_output = "2a3b3d440e3c8e15a84d14a1b1e94b21"
    assert actual_output == expected_output


# Generated at 2022-06-25 13:06:48.749125
# Unit test for function md5
def test_md5():
    print("Test for function: md5")
    test_case_0()


# Generated at 2022-06-25 13:06:56.687445
# Unit test for function md5
def test_md5():
    int_0 = 161
    var_0 = md5s(int_0)
    assert var_0 == 'b9f9b6edee5da5b5d7decc3ddc3fbc71'



# Generated at 2022-06-25 13:07:06.160218
# Unit test for function checksum
def test_checksum():
    """Ansible module to calculate SHA256 checksum of a file."""
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            hash_algorithm=dict(default='sha256', choices=['sha1', 'sha256', 'sha512']),
        ),
        supports_check_mode=True
    )

    filename = module.params['path']
    hash_algorithm = module.params['hash_algorithm']

    if hash_algorithm == 'sha256':
        hash_func = sha256
    elif hash_algorithm == 'sha1':
        hash_func = sha1
    elif hash_algorithm == 'sha512':
        hash_func = sha512
    else:
        hash_func = sha256


# Generated at 2022-06-25 13:07:08.795176
# Unit test for function checksum
def test_checksum():
    expected = 'a8a8f51d8e227fbc7cac7701d923ecef'
    assert checksum('/home/conz/ansible-test/test/files/echo.py') == expected


# Generated at 2022-06-25 13:07:12.486485
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    int_0 = 161
    var_0 = md5s(int_0)
    if not var_0:
        print('Test Fail')
    else:
        print('Test Pass')


if __name__ == '__main__':
    test_md5s()
    test_case_0()

# Generated at 2022-06-25 13:07:13.942975
# Unit test for function md5
def test_md5():
    file_1 = 'file_1'
    result_1 = md5(file_1)
    assert file_1 == result_1


# Generated at 2022-06-25 13:07:15.843102
# Unit test for function md5s
def test_md5s():
    assert md5s(161) == '95e0bcd5a5f543b4ad7ff4f4f2b867d0'


# Generated at 2022-06-25 13:07:17.879751
# Unit test for function md5
def test_md5():
    md5_0 = md5(int_0)
    test_case_0()

if __name__ == "__main__":
    test_md5()

# Generated at 2022-06-25 13:07:18.943561
# Unit test for function md5
def test_md5():
    # Case 0:
    test_case_0()


# Generated at 2022-06-25 13:07:20.539134
# Unit test for function md5
def test_md5():
    print("running test case: %s" % (test_case_0.__name__))
    test_case_0()

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-25 13:07:21.465238
# Unit test for function md5s
def test_md5s():
    # Testing
    # Setup input parameters
    # Call function
    test_case_0()


# Generated at 2022-06-25 13:07:26.176560
# Unit test for function md5s
def test_md5s():
    assert '81dc9bdb52d04dc20036dbd8313ed055' == md5s('test')


# Generated at 2022-06-25 13:07:27.849549
# Unit test for function md5
def test_md5():
    assert md5("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"


# Generated at 2022-06-25 13:07:29.216421
# Unit test for function md5
def test_md5():
    '''
    Placeholder for md5 unit tests.
    '''

    pass


# Generated at 2022-06-25 13:07:29.986623
# Unit test for function md5s
def test_md5s():
    test_case_0()


# Generated at 2022-06-25 13:07:30.745613
# Unit test for function md5s
def test_md5s():
    test_case_0()


# Generated at 2022-06-25 13:07:33.602718
# Unit test for function md5
def test_md5():
    assert md5("test_md5") == "c8eec15b9fcec22a19eee42e8b0fe442"


# Generated at 2022-06-25 13:07:36.198135
# Unit test for function md5
def test_md5():
    filename = 'test_data/file.txt'
    expected = 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5(filename) == expected



# Generated at 2022-06-25 13:07:38.990370
# Unit test for function checksum
def test_checksum():
    test_checksum_s = checksum_s('test_checksum_s')
    test_checksum_0 = checksum('/etc/hosts')

    assert test_checksum_s
    assert test_checksum_0


# Generated at 2022-06-25 13:07:40.764870
# Unit test for function md5
def test_md5():
    filename = os.path.join(sys._getframe().f_code.co_filename)
    assert check_md5(filename)


# Generated at 2022-06-25 13:07:43.190116
# Unit test for function md5s

# Generated at 2022-06-25 13:07:46.974061
# Unit test for function md5
def test_md5():
    int_0 = 0
    var_0 = md5(int_0)


# Generated at 2022-06-25 13:07:47.856815
# Unit test for function md5
def test_md5():
    print("unit test for md5")
    assert md5("file") == None


# Generated at 2022-06-25 13:07:48.863594
# Unit test for function md5
def test_md5():
    assert md5(filename="test_md5") == secure_hash(filename="test_md5")


# Generated at 2022-06-25 13:07:52.967601
# Unit test for function md5s
def test_md5s():
    buffer_0 = b"abc"
    buffer_1 = b"a"
    test_case_0()

    md5s_buffer = md5s(buffer_0)
    assert md5s_buffer == '900150983cd24fb0d6963f7d28e17f72'
    md5s_buffer = md5s(buffer_1)
    assert md5s_buffer == '0cc175b9c0f1b6a831c399e269772661'



# Generated at 2022-06-25 13:07:55.102025
# Unit test for function checksum
def test_checksum():
    assert(checksum('tests/test_checksum.py') == '3a3a0d35f226c2e350a3b3e1ed6c9d6a')


# Generated at 2022-06-25 13:07:57.252017
# Unit test for function checksum
def test_checksum():
    print("Running test_checksum()...")
    output = checksum_s("test")
    assert output == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"


# Generated at 2022-06-25 13:07:59.180983
# Unit test for function md5
def test_md5():
    str_0 = 'MD5 is not encrypted'
    str_1 = md5s(str_0)
    assert str_1 == '9a9de917557d0845f0d13ffa3e827b87'


# Generated at 2022-06-25 13:08:01.276866
# Unit test for function md5
def test_md5():
    for i in range(100):
        int_0 = i
        var_0 = md5s(int_0)
        print(var_0)


# Generated at 2022-06-25 13:08:05.955117
# Unit test for function md5s

# Generated at 2022-06-25 13:08:08.508844
# Unit test for function checksum
def test_checksum():
    assert checksum(1500) == 'f59b1f0ae03e7b08433f1d1fbc9bc18e'


# Generated at 2022-06-25 13:08:13.458896
# Unit test for function checksum
def test_checksum():
    path = os.path.realpath(__file__)
    assert(checksum(path) is not None)


# Generated at 2022-06-25 13:08:20.833306
# Unit test for function md5s
def test_md5s():
    # '161'
    assert md5s(161) == '936c9b8f08ba294c1beda7a0c185bde8'
    # '1'
    assert md5s(1) == 'c4ca4238a0b923820dcc509a6f75849b'
    # '0'
    assert md5s(0) == 'd41d8cd98f00b204e9800998ecf8427e'
    # '15'
    assert md5s(15) == 'f06d69cd89c2b6eb8f8edb76b89f54e9'
    # '16'
    assert md5s(16) == '4889b8e280e39fa1e9805bce14f1b8fb'
    # '7

# Generated at 2022-06-25 13:08:21.932282
# Unit test for function md5s
def test_md5s():
    assert type(md5s(161)) == str


# Generated at 2022-06-25 13:08:25.172659
# Unit test for function md5
def test_md5():
    var_4 = md5('test.txt')
    if (var_4 == '68b329da9893e34099c7d8ad5cb9c940'):
        return True
    else:
        return False


# Generated at 2022-06-25 13:08:27.059599
# Unit test for function md5
def test_md5():
   assert md5("test_file_0") == "d41d8cd98f00b204e9800998ecf8427e"


# Generated at 2022-06-25 13:08:30.198272
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    int_0 = 161
    str_0 = 'a1'
    ret_0 = md5s(int_0)
    assert ret_0 == str_0


# Generated at 2022-06-25 13:08:30.997344
# Unit test for function md5
def test_md5():
    pass


# Generated at 2022-06-25 13:08:35.254490
# Unit test for function md5s
def test_md5s():
    int_0 = 161
    var_0 = md5s(int_0)

    assert var_0 == "3f4d4d2735dcc944b7a8a18d6a7b01d1"


# Generated at 2022-06-25 13:08:36.257861
# Unit test for function md5s
def test_md5s():
    test_case_0()


# Generated at 2022-06-25 13:08:37.911233
# Unit test for function md5
def test_md5():
    assert md5('/tmp/test_file') == '0123456789abcdef'

# Generated at 2022-06-25 13:08:43.192592
# Unit test for function md5
def test_md5():
    s = 'Hello World!'
    m = 'ed076287532e86365e841e92bfc50d8c'
    assert md5s(s) == m

print(test_md5())

# Generated at 2022-06-25 13:08:46.470554
# Unit test for function md5s
def test_md5s():
    assert int_0 == 161
    assert var_0 == '9b0f0e8d71d45e65ad67c0a57a5979e8'
    assert checksum_s(int_0) == var_0



# Generated at 2022-06-25 13:08:48.412595
# Unit test for function checksum
def test_checksum():
    #checksum(filename)

    # Call function and test return
    #assert checksum(filename) == 'test'
    return


# Generated at 2022-06-25 13:08:51.448951
# Unit test for function md5s
def test_md5s():
    assert md5s(161) == 'b4d09e17e8b92edde9bacbdc9d0ada7c'



# Generated at 2022-06-25 13:08:54.631909
# Unit test for function md5s
def test_md5s():
    test_in = 'Hello world'
    test_out = '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(test_in) == test_out



# Generated at 2022-06-25 13:08:58.508371
# Unit test for function md5
def test_md5():
    '''
    Test md5 function
    '''
    return_value = md5('/attic/var/tmp/test_md5_file')
    assert return_value == '8dc47a2c1a14e23b2f1e8a5a3c146a3d'



# Generated at 2022-06-25 13:09:03.753438
# Unit test for function md5
def test_md5():
    assert (md5('test/test_utils.py') == '49f2e2e81a2d80a6910141d1f7b1a9b9')


# Generated at 2022-06-25 13:09:06.374772
# Unit test for function md5s
def test_md5s():
    s = md5s(161)
    assert s == 'c5a5a5ff8f57d5a9c9b5f5e2ff8a3a3a'



# Generated at 2022-06-25 13:09:07.694963
# Unit test for function md5s
def test_md5s():
    test_case_0()


# Generated at 2022-06-25 13:09:11.436110
# Unit test for function md5s
def test_md5s():
    with pytest.raises(TypeError) as e_0:
        md5s()
    with pytest.raises(TypeError) as e_1:
        md5s(None)
    with pytest.raises(TypeError) as e_2:
        md5s(None, None)


# Generated at 2022-06-25 13:09:18.181731
# Unit test for function md5s
def test_md5s():
    i = md5s('hello world')
    assert i == '5eb63bbbe01eeed093cb22bb8f5acdc3', 'md5s did not return the correct value'
    print('test [test_md5s] ok')


# Generated at 2022-06-25 13:09:19.492233
# Unit test for function md5s
def test_md5s():
    test_case_0()


# Generated at 2022-06-25 13:09:28.953587
# Unit test for function md5s
def test_md5s():
    var_0 = 161
    var_1 = 1707491531
    var_2 = -2134237582
    var_3 = -336519707
    var_4 = 880395694
    var_5 = -723291566
    var_6 = var_0
    var_7 = var_6
    var_8 = var_6
    var_9 = var_6
    var_10 = var_6
    var_11 = var_6
    var_12 = var_6
    var_13 = var_6
    var_14 = var_6
    var_15 = var_6
    var_16 = var_6
    var_17 = var_6
    var_18 = var_6
    var_19 = var_6
    var_20 = var_6
   

# Generated at 2022-06-25 13:09:30.091457
# Unit test for function md5s
def test_md5s():
    assert(md5s('161') == '5b21007c1f098b5a5f6a5f6d109c73e1')


# Generated at 2022-06-25 13:09:30.913322
# Unit test for function checksum
def test_checksum():
    pass



# Generated at 2022-06-25 13:09:33.674389
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    int_0 = 161
    var_0 = md5s(int_0)

    assert(var_0 == md5s(int_0))


# Generated at 2022-06-25 13:09:34.482162
# Unit test for function md5s
def test_md5s():
    test_case_0()



# Generated at 2022-06-25 13:09:36.450102
# Unit test for function md5
def test_md5():
    assert md5('/etc/hosts') == '9c977faa7d0d8c4bc7bc1e4b13d7ff1f'


# Generated at 2022-06-25 13:09:40.004919
# Unit test for function md5s
def test_md5s():
    try:
        assert md5s('AA') == 'a4f4b7d4835c4cc4e77b95894f7a1565'
    except AssertionError as e:
        print(e)


# Generated at 2022-06-25 13:09:42.804402
# Unit test for function md5
def test_md5():
    int_0 = 161
    var_0 = md5s(int_0)
    f_a = "aa2"
    f_b = "abb"
    assert f_a == f_b


# Generated at 2022-06-25 13:09:49.415921
# Unit test for function md5
def test_md5():
    print('Running test for function md5')
    print('Test case 0:')
    test_case_0()


# Generated at 2022-06-25 13:09:51.012903
# Unit test for function md5
def test_md5():
    assert(md5s('161') == 'd638394e0c9f9e7dcf22b778e6c30b11')

# Generated at 2022-06-25 13:09:52.617782
# Unit test for function md5s
def test_md5s():
    assert md5s(161) == 'a2c9d9fcf915c1a8b3d3a43ba7dcef09'


# Generated at 2022-06-25 13:09:56.810241
# Unit test for function checksum
def test_checksum():
    int_0 = 454
    var_0 = secure_hash_s(int_0)
    assert var_0 == '9b42eb2e3f3d10c0a0b2c27c7094d7f6a98a31b7'


# Generated at 2022-06-25 13:09:58.188675
# Unit test for function md5s
def test_md5s():
    int_0 = 161
    var_0 = md5s(int_0)


# Generated at 2022-06-25 13:10:00.141735
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == '0fe33f37d6bea8fe5e15fcfa3f3a7bac'


# Generated at 2022-06-25 13:10:03.857978
# Unit test for function md5
def test_md5():
    # Input parameters
    filename = 'test.txt'

    # Expected output
    expected_result = None

    # Call function and check output
    result = md5(filename)
    assert result == expected_result


# Generated at 2022-06-25 13:10:06.266918
# Unit test for function md5s
def test_md5s():
    int_0 = 161
    test_case_0()
    assert var_0 == '08f36d859f6c1270b09dae6ac1f6a8a9'

# Generated at 2022-06-25 13:10:11.626201
# Unit test for function checksum
def test_checksum():
    h = 'd41d8cd98f00b204e9800998ecf8427e'
    assert checksum(to_bytes('')) == h
    assert checksum(to_bytes('foo')) == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert checksum(to_bytes('foo\n')) == '0a4d55a8d778e5022fab701977c5d840'


# Generated at 2022-06-25 13:10:13.179821
# Unit test for function checksum
def test_checksum():
    assert checksum("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"


# Generated at 2022-06-25 13:10:19.725274
# Unit test for function md5
def test_md5():
    assert md5("/usr/bin/true") == "552b7bb8a9ad25b75f0a1d85a624b831"


# Generated at 2022-06-25 13:10:21.087404
# Unit test for function md5s
def test_md5s():
    assert(md5s(b'abc') == '900150983cd24fb0d6963f7d28e17f72')

# Generated at 2022-06-25 13:10:25.353576
# Unit test for function md5s
def test_md5s():
    orig_0 = 161
    want_0 = 'a1ebe00441f27b8bafc5b0d3255bfef'
    got_0 = md5s(orig_0)
    if (want_0 != got_0):
        raise AssertionError(
            'md5s(int) test failed: want %s, got %s' %
            (want_0, got_0))

# Generated at 2022-06-25 13:10:30.492185
# Unit test for function md5s
def test_md5s():
    int_0 = 7
    var_0 = md5s(int_0)
    assert var_0 == "e8d0c02b15fea3335a13d496a0e64c2e"


# Generated at 2022-06-25 13:10:33.207830
# Unit test for function md5
def test_md5():
    assert(md5("ansible") == '9dd4e461268c8034f5c8564e155c67a6'), "md5: Wrong checksum for ansible"
