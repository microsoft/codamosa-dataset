

# Generated at 2022-06-25 13:00:45.061532
# Unit test for function md5s
def test_md5s():
    data = "Hello"
    try:
        secure_hash_s(data, _md5)
    except:
        pass


# Generated at 2022-06-25 13:00:48.560869
# Unit test for function md5s
def test_md5s():
    # Test using a known md5 value
    test_md5s_0 = '7e30f8cc3767522fe94f10d1d7ea7064'
    var_0 = md5s('Hello World')
    assert test_md5s_0 == var_0

# Generated at 2022-06-25 13:00:55.787092
# Unit test for function md5s
def test_md5s():
    float_0 = -686.0
    var_0 = md5s(float_0)
    # AssertionError: AssertionError: 'md5=c6dd895aa829e9c5dc6e5b5f8d5ee569' != 'sha1=a62e46a0d67e96624a9f29fe21f8f89dee78098e'
    # assert(var_0 == "md5=c6dd895aa829e9c5dc6e5b5f8d5ee569")


# Generated at 2022-06-25 13:00:58.834146
# Unit test for function md5s
def test_md5s():
    v1 = md5s("test")
    assert v1 == "098f6bcd4621d373cade4e832627b4f6"


# Generated at 2022-06-25 13:01:08.065910
# Unit test for function checksum
def test_checksum():
    float_0 = float(0)
    float_1 = float(1)
    float_2 = float(2)
    float_3 = float(3)
    float_4 = float(4)
    float_5 = float(5)
    float_6 = float(6)
    float_7 = float(7)
    float_8 = float(8)
    float_9 = float(9)
    float_10 = float(10)
    float_11 = float(11)
    float_12 = float(12)
    float_13 = float(13)
    float_14 = float(14)
    float_15 = float(15)
    float_16 = float(16)
    float_17 = float(17)
    float_18 = float(18)
    float_19 = float(19)

# Generated at 2022-06-25 13:01:11.966576
# Unit test for function checksum
def test_checksum():
    var_0 = secure_hash('/tmp/file2', sha1)
    if var_0 == '339e4380d3c3cd59f7f6e246701f7d9f5534a097':
        return
    else:
        raise ValueError('checksum failed')


# Generated at 2022-06-25 13:01:13.996984
# Unit test for function md5s
def test_md5s():
    assert(md5s(10.0) == "3b4d4e4a4c4f4f4f")


# Generated at 2022-06-25 13:01:18.568269
# Unit test for function checksum
def test_checksum():
    expected = '9c3d0b4f4d4e8dcd7c4b3a30d10bc11f'
    result = checksum("sha1.py")
    if result != expected:
        print("Expected {0} but got {1}".format(expected, result))
        raise AssertionError("Unit test for function checksum() failed.")


# Generated at 2022-06-25 13:01:19.857072
# Unit test for function md5
def test_md5():
    assert md5(float_0) == checksum(float_0)


# Generated at 2022-06-25 13:01:27.323596
# Unit test for function md5s
def test_md5s():
    from ansible.utils._md5 import md5s
    from ansible.module_utils._text import to_bytes
    from hashlib import md5

    # these are from the docs
    assert md5s("abc") == md5("abc".encode("utf-8")).hexdigest()
    assert md5s("".encode("utf-8")) == md5("".encode("utf-8")).hexdigest()
    assert md5s("abc".encode("utf-8")) == md5("abc".encode("utf-8")).hexdigest()

    # unit tests from md5sum
    assert md5s("hello world\n") == "5eb63bbbe01eeed093cb22bb8f5acdc3"

    # Unit test for function secure_hash_s (Above)
    assert secure

# Generated at 2022-06-25 13:01:36.213648
# Unit test for function checksum
def test_checksum():
    from ansible.utils import checksum
    assert checksum('test_0.c') == 'd295f7a8ed4a4e3e4dd4b471eebcb40d'


# Generated at 2022-06-25 13:01:38.801714
# Unit test for function md5
def test_md5():
    print('Test case 1 - md5')
    str_0 = b'Hello'
    ret = md5(str_0)
    print('md5: '+ret)


# Generated at 2022-06-25 13:01:42.693483
# Unit test for function md5s
def test_md5s():
    try:
        assert md5s(str_0) == '8b1a9953c4611296a827abf8c47804d7'
    except:
        print('AssertionError')


# Generated at 2022-06-25 13:01:43.481653
# Unit test for function md5
def test_md5():
    pass


# Generated at 2022-06-25 13:01:45.909605
# Unit test for function md5s
def test_md5s():
    r = md5s(str_0)
    assert r == '8b1a9953c4611296a827abf8c47804d7'


# Generated at 2022-06-25 13:01:47.918389
# Unit test for function md5
def test_md5():
    assert '8b1a9953c4611296a827abf8c47804d7' ==  md5s('Hello')
    print('Pass')


# Generated at 2022-06-25 13:01:51.536561
# Unit test for function checksum
def test_checksum():
    str_0 = 'Hello'
    assert checksum_s(str_0) == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'


# Generated at 2022-06-25 13:01:56.401336
# Unit test for function checksum
def test_checksum():
    #print('Test: Checksum of ' + str_0 + ' is ' + checksum_s(str_0))
    str_0 = 'Hello'
    return checksum_s(str_0) == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'


# Generated at 2022-06-25 13:01:58.360967
# Unit test for function md5s
def test_md5s():
    assert str2int(md5s(str_0)) == 17833110006966382058


# Generated at 2022-06-25 13:02:03.678744
# Unit test for function checksum
def test_checksum():
    test_string = 'Hello'
    test_file = 'test.txt'
    f = open(test_file, 'w')
    f.write(test_string)
    f.close()
    real_hash = checksum(test_file)
    expected_hash = checksum_s(test_string)
    assert(real_hash == expected_hash)
    os.remove(test_file)

# Generated at 2022-06-25 13:02:09.170904
# Unit test for function md5s
def test_md5s():
    float_0 = float
    var_0 = md5s(float_0)


# Generated at 2022-06-25 13:02:16.105684
# Unit test for function checksum
def test_checksum():
    assert checksum('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum('bar') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert checksum_s('baz') == '1475c7f9f9e613025c0bf07ad8c635c70afe8e94'
    assert checksum_s('qux') == 'db573fda88c4b2a4a4a4becae4e0301f44ae67e4'


if __name__ == '__main__':
    test_case_0()
    test_checksum()

# Generated at 2022-06-25 13:02:26.221148
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s('\n') == '68b329da9893e34099c7d8ad5cb9c940'
    assert md5s('\r\n') == '92eb5ffee6ae2fec3ad71c777531578f'
    assert md5s('a\r\n') == '2b1d0f07fbc274cfccbc46c89be91a7c'

# Generated at 2022-06-25 13:02:36.245442
# Unit test for function md5
def test_md5():
    filename = './test_files/test_0'
    assert md5(filename) == '8051af7701a2cfe9a9d98d7b1f10f8ed'
    filename = './test_files/test_1'
    assert md5(filename) == '1b9faa9f9494c57b4f8c7fa421cf3b62'
    filename = './test_files/test_2'
    assert md5(filename) == '9948f5dcfa71e567946f8a5c3b3dce23'
    filename = './test_files/test_3'
    assert md5(filename) == '7b13e1b352c9c89dbf379b1ffa5053d7'

# Generated at 2022-06-25 13:02:40.709384
# Unit test for function md5
def test_md5():
   filename = 'test_file'
   # Test for expected functionality
   assert md5(filename) == "380b0a065bea1d5f21a8a0f403cad6dd"


# Generated at 2022-06-25 13:02:43.863799
# Unit test for function md5
def test_md5():
    try:
        filename = 'this_should_fail.txt'
        test_md5 = md5(filename)
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-25 13:02:48.850476
# Unit test for function md5s
def test_md5s():
    print("TESTING md5s()")
    assert md5s('asdf') == '912ec803b2ce49e4a541068d495ab570'
    print("md5s() PASSED")


# Generated at 2022-06-25 13:02:53.068843
# Unit test for function md5
def test_md5():
  # Use example from https://wiki.python.org/moin/UsingAssertionsEffectively
  try:
    assert md5("test.txt") == "327396a245425f1f7f62593b274ee430"
  except AssertionError:
    print("File test.txt has no correct md5 checksum.")
    raise


# Generated at 2022-06-25 13:02:55.188962
# Unit test for function md5
def test_md5():
    s = "test"
    result = md5(s)
    assert result == "098f6bcd4621d373cade4e832627b4f6", "Failed md5 test"


# Generated at 2022-06-25 13:02:56.704021
# Unit test for function checksum
def test_checksum():
    assert checksum(float_0) == '63386b6363c7e9e9cc009527589280ae'


# Generated at 2022-06-25 13:03:01.913422
# Unit test for function md5
def test_md5():
    assert md5("testfile") == 'aa1d41e31ea22176a8ec08d3c6abff3c'


# Generated at 2022-06-25 13:03:10.873444
# Unit test for function md5s
def test_md5s():
    file_fixture_path = os.path.dirname(__file__) + "/fixtures/test_file"
    assert(md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3")
    assert(md5s("hola mundo") == "c1470e7b8a3f4d6efb2c0e737a8a6e47")
    assert(md5s("whoops I mean hello world") == "a9c9a84f00d854e060934dab5097c2f7")
    assert(md5(file_fixture_path) == "5c2d53bdf36e62d99b35c311c868db44")

# Generated at 2022-06-25 13:03:13.056844
# Unit test for function md5
def test_md5():
    assert md5("/etc/fstab") == "d0ddcdc0685a24962eff28d8c3b3a9e0"


# Generated at 2022-06-25 13:03:15.464702
# Unit test for function md5
def test_md5():
    assert md5('test/resource/openssl.cnf') == 'd144b5e862f12bbb0d0090e665e312d7'


# Generated at 2022-06-25 13:03:23.762365
# Unit test for function md5
def test_md5():
    float_0 = -686.0
    float_1 = -686.0
    float_2 = -686.0
    string_0 = "5J5N5)1{Qj:M:F82/^(<8f7P+l&~ljf1GQmXJ3qm(+23k;17^cY@F8hV7^"
    string_1 = "0z+j9`sT-Tc:f;]I l2G3A3j6J2U6Svm=6EjABf9l9#0J4A4_4k4w4#4+4B6U"
    string_2 = "4B6U"


# Generated at 2022-06-25 13:03:27.435697
# Unit test for function checksum
def test_checksum():

    filename = "/etc/passwd"
    float_0 = -686.0
    var_0 = checksum(filename)
    var_1 = checksum_s(float_0)

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-25 13:03:29.942270
# Unit test for function md5
def test_md5():
    var_1 = md5("")
    assert var_1 == "d41d8cd98f00b204e9800998ecf8427e"



# Generated at 2022-06-25 13:03:30.831431
# Unit test for function md5
def test_md5():
    assert md5('filename') is None


# Generated at 2022-06-25 13:03:39.897760
# Unit test for function md5
def test_md5():
    # Test function secure_hash with typical data
    data = 'eW91ciBzdG9wIGFwcGx5IHN0aWxsIHByb2JhYmx5IG1hbnkgdGhhdCBsaWtlIEkgc2FmZWx5IG9uIG9u'
    filename = 'yut5geV7wN'
    filename_1 = 'MZD'
    filename_2 = '[O3q'
    # expected_return = 'c67dfab010cba8fce6c1dea71e9e48de'
    expected_return_1 = 'c67dfab010cba8fce6c1dea71e9e48de'

# Generated at 2022-06-25 13:03:41.195381
# Unit test for function md5s
def test_md5s():
    try:
        md5s(0)
    except ValueError:
        pass


# Generated at 2022-06-25 13:03:47.170189
# Unit test for function md5
def test_md5():
    result = md5('./tests/support/file1')
    assert result == 'fa8e4dcf3d83a4a6a27cb65c8d3624b1'

# Generated at 2022-06-25 13:03:50.062988
# Unit test for function md5s
def test_md5s():
    assert(md5s("asdf") == "912ec803b2ce49e4a541068d495ab570")



# Generated at 2022-06-25 13:03:53.127033
# Unit test for function md5
def test_md5():
    filename = 'C:\\Users\\admini\\Documents\\0030.jpg'
    assert md5(filename) == 'd94150cf89adaf0b5db6c8e1d836d16e'


# Generated at 2022-06-25 13:03:55.385014
# Unit test for function md5
def test_md5():
    assert md5("ansible_test/checksum/sample.txt") == "7a8b89a80d7cd0236c097283868a00b0"


# Generated at 2022-06-25 13:03:58.717620
# Unit test for function md5s
def test_md5s():
    float_0 = -686.0
    var_0 = md5s(float_0)
    float_1 = 686.0
    var_1 = md5s(float_1)
    float_2 = -686.0
    var_2 = md5s(float_2)

# Generated at 2022-06-25 13:04:00.045625
# Unit test for function md5
def test_md5():
    print(md5('test-file.txt'))


# Generated at 2022-06-25 13:04:00.850580
# Unit test for function md5s
def test_md5s():
    return


# Generated at 2022-06-25 13:04:02.334299
# Unit test for function md5s
def test_md5s():
    with pytest.raises(ValueError):
        md5s(float_0)


# Generated at 2022-06-25 13:04:06.972592
# Unit test for function md5s
def test_md5s():
    var_0 = md5s( 'abc')
    assert var_0 == '900150983cd24fb0d6963f7d28e17f72'
    var_0 = md5s( 'ABC')
    assert var_0 == '902fbdd2b1df0c4f70b4a5d23525e932'


# Generated at 2022-06-25 13:04:08.197092
# Unit test for function md5
def test_md5():
    var_0 = md5(filename = "")


# Generated at 2022-06-25 13:04:12.776832
# Unit test for function md5s
def test_md5s():
    string_0 = md5s(float_0)


# Generated at 2022-06-25 13:04:16.693315
# Unit test for function checksum
def test_checksum():
    assert checksum('/tmp/ansible_file') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert checksum('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'


# Generated at 2022-06-25 13:04:24.434639
# Unit test for function md5
def test_md5():
    assert md5('examples/files/foo.txt') == '6f5902ac237024bdd0c176cb93063dc4'
    assert md5('examples/files/bar.txt') == '6f5902ac237024bdd0c176cb93063dc4'
    assert md5('examples/files/baz.txt') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5('examples/files/ascii.txt') == 'b1946ac92492d2347c6235b4d2611184'
    assert md5('examples/files/subdir/ascii.txt') == 'b1946ac92492d2347c6235b4d2611184'

# Generated at 2022-06-25 13:04:34.229952
# Unit test for function checksum
def test_checksum():
    test_fname = '/tmp/test_module_utils_module_packaging_py.txt'
    try:
        test_file = open(test_fname, 'w')
        test_file.write('there is some test data')
        test_file.close()
        test_file = open(test_fname, 'r')
        test_data = test_file.read()
        test_file.close()
    finally:
        if os.path.exists(test_fname):
            os.remove(test_fname)
    if checksum(test_fname) == None:
        return
    assert checksum_s(test_data) == checksum(test_fname)


# Generated at 2022-06-25 13:04:37.077508
# Unit test for function md5s
def test_md5s():
    assert md5s('-686.0') == '3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f'


# Generated at 2022-06-25 13:04:40.013300
# Unit test for function md5
def test_md5():
    float_1 = -570.0
    float_2 = -652.0
    var_1 = md5s(float_1)
    var_2 = md5(float_2)


# Generated at 2022-06-25 13:04:43.243683
# Unit test for function md5s
def test_md5s():
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('123') == '202cb962ac59075b964b07152d234b70'


# Generated at 2022-06-25 13:04:44.332979
# Unit test for function md5s
def test_md5s():
    try:
        assert 1 == 1
    except:
        raise


# Generated at 2022-06-25 13:04:46.221134
# Unit test for function md5
def test_md5():
    float_0 = -30.9
    var_0 = md5(float_0)


# Generated at 2022-06-25 13:04:48.512756
# Unit test for function md5s
def test_md5s():
    # Assert if the expected result fails
    assert md5s('test_data') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-25 13:04:55.813238
# Unit test for function md5s
def test_md5s():
    assert md5s(1) == 'c4ca4238a0b923820dcc509a6f75849b'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-25 13:05:04.292350
# Unit test for function md5s
def test_md5s():

    # Sanity check.  Return value should be the same as checksum_s
    assert md5s(25) == checksum_s(25)

    # The return value should be the same when checksum_s is called
    # with a string as an argument
    assert md5s('25') == checksum_s('25')

    # Test that a non-FIPS-140-2 compliant system will return the same
    # result for both checksum_s and md5s
    if _md5:
        assert md5s('25') == checksum_s('25', _md5)



# Generated at 2022-06-25 13:05:07.089214
# Unit test for function checksum
def test_checksum():
    try:
        filename = sys.argv[1]
        print(checksum(filename))
    except Exception as e:
        print(e)


# Generated at 2022-06-25 13:05:09.321211
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == '28cac32409fca1e2a8fcff708d3f3b95'


# Generated at 2022-06-25 13:05:11.623804
# Unit test for function md5
def test_md5():
    assert md5(__file__) == 'a9fbfb1e7d1c0eb49d7bb0cdda669f17'

# Test for function md5s

# Generated at 2022-06-25 13:05:14.882301
# Unit test for function md5
def test_md5():
    try:
        assert md5('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    except ValueError as ve:
        if str(ve) == 'MD5 not available.  Possibly running in FIPS mode':
            raise nose.SkipTest()
        else:
            raise ve



# Generated at 2022-06-25 13:05:18.159127
# Unit test for function md5
def test_md5():
    file_1 = './test/test1'
    var_1 = md5(file_1)
    assert var_1 == 'd5f82b1cacb5113f2b7f001a818bd4d4'


# Generated at 2022-06-25 13:05:20.521169
# Unit test for function md5
def test_md5():
    assert md5('/etc/fstab') == '1dd6abf5a32eacd9ee8e1b7a93b4db4d'


# Generated at 2022-06-25 13:05:22.458420
# Unit test for function md5
def test_md5():
    #assert md5("sample-file") == "56f06691e94e62a3b397d0a1a3bf29a9"
    assert True


# Generated at 2022-06-25 13:05:23.696763
# Unit test for function md5s
def test_md5s():
    #  Test will fail until md5 is implemented
    #  assert True is False
    return


# Generated at 2022-06-25 13:05:31.049225
# Unit test for function checksum
def test_checksum():
    filename_0 = "test/test_utils_hash.py"
    checksum_0 = checksum(filename_0, sha1)
    assert checksum_0 == "ec6cbf0df3d8f727a2a2f0c020b9d0dc9c9a301a"


# Generated at 2022-06-25 13:05:34.761151
# Unit test for function md5
def test_md5():
    float_0 = -686.0
    # Calling secure_hash_s(float_0, _md5)
    # Call to md5s(data)
    try:
        md5s(float_0)
    except ValueError as e:
        raise RuntimeError(e)

# Generated at 2022-06-25 13:05:37.094456
# Unit test for function md5
def test_md5():
    assert md5('test_files/test_md5.txt') == 'c11fe5e5d5a5a5a5c5e5e5d5226c5d5e'


# Generated at 2022-06-25 13:05:41.290365
# Unit test for function md5
def test_md5():
    filename = "test_file.tmp"
    test_file = open(filename, 'w')
    test_file.write("This is a test_file")
    test_file.close()
    hsh = md5(filename)
    os.remove(filename)
    if hsh:
        return True
    else:
        return False


# Generated at 2022-06-25 13:05:44.999638
# Unit test for function md5s
def test_md5s():
    '''
    Unit test for function md5s
    '''

    float_0 = -686.0
    var_0 = md5s(float_0)
    assert var_0 == 'd6b4257aa4e4c3a9e5834c05d33ded6b'


# Generated at 2022-06-25 13:05:49.362791
# Unit test for function md5
def test_md5():
    fpath = os.path.join(os.environ['HOME'], 'get-pip.py')
    try:
        assert md5(fpath) == 'dc924a7854f3f330df318c271a0c7c8e'
    except AssertionError:
        raise AssertionError('Test md5 has failed')


# Generated at 2022-06-25 13:05:51.006883
# Unit test for function md5s
def test_md5s():
    float_0 = -686.0
    var_0 = md5s(float_0)


# Generated at 2022-06-25 13:05:55.689386
# Unit test for function checksum
def test_checksum():
    assert checksum('/usr/lib/python2.7/dist-packages/ansible/parsing/dataloader.py') == '97c10e5928f0fcb9aaded7b40414e6ef'
    assert checksum('/etc/ansible/hosts') is None
    assert checksum('/usr/share/ansible/') is None


# Generated at 2022-06-25 13:06:05.457699
# Unit test for function md5s
def test_md5s():
    try:
        assert(md5s('test') == '098f6bcd4621d373cade4e832627b4f6')
    except AssertionError as e:
        print("Test Failed:")
        print("Failed test: {}".format("md5s('test')"))
        print("Expected md5s('test') to be '098f6bcd4621d373cade4e832627b4f6' but it returned {}".format(md5s('test')))
        print("StackTrace:")
        print("{}".format(e))



# Generated at 2022-06-25 13:06:06.852504
# Unit test for function md5
def test_md5():
    for i in range(10):
        test_case_0()

# Generated at 2022-06-25 13:06:12.293726
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == '2c740d603712d6944c56a2a5b2c1e05a'


# Generated at 2022-06-25 13:06:16.579268
# Unit test for function md5
def test_md5():
    test_file = 'test/files/md5/ansible.cfg'
    result = secure_hash(test_file, _md5)
    if not result == '46023cf1f2c08f076fd0c6d0f9a9b3a1':
        raise ValueError('md5 test failed')


# Generated at 2022-06-25 13:06:21.135179
# Unit test for function checksum
def test_checksum():
    test_string = 'This is the test string'
    answer = checksum(test_string)
    # The solution is the sha1 of the string.  Using the
    # module_utils version of checksum to generate it.
    from ansible.module_utils.basic import AnsibleModule
    solution = AnsibleModule()._checksum(test_string)
    assert solution == answer


# Generated at 2022-06-25 13:06:25.544442
# Unit test for function md5s
def test_md5s():
    ansible_md5 = 'c36a14bfd8c82468a5a64ebb05d0b43c'
    my_md5 = md5s('test')
    assert(ansible_md5 == my_md5)



# Generated at 2022-06-25 13:06:31.005352
# Unit test for function md5
def test_md5():
    print('Test #1')
    data = '5d41402abc4b2a76b9719d911017c592'
    assert data == md5s('hello')
    print('Test #2')
    data2 = 'b9434d84e7b5cac6dd8bdfd292657f98.ansible_facts.yaml'
    assert data2 == md5('./ansible_facts.yaml')


# Generated at 2022-06-25 13:06:32.500537
# Unit test for function md5
def test_md5():
    float_0 = -686.0
    var_0 = md5(float_0)


# Generated at 2022-06-25 13:06:34.498612
# Unit test for function md5
def test_md5():
    var_1 = secure_hash_s("test-" + "test")
    print("test_md5 - 0:", var_1)

test_md5()

# Generated at 2022-06-25 13:06:35.272018
# Unit test for function checksum
def test_checksum():
    assert callable(checksum)


# Generated at 2022-06-25 13:06:36.494744
# Unit test for function md5s
def test_md5s():
    """Test if function md5s works"""
    assert md5s("This is a string")


test_case_0()

# Generated at 2022-06-25 13:06:38.293627
# Unit test for function md5
def test_md5():
    float_0 = -686.0
    var_0 = secure_hash(float_0)
    print(var_0)


# Generated at 2022-06-25 13:06:44.622630
# Unit test for function md5s
def test_md5s():
    assert md5s(float_0) == "50fcb9e91475ad5f43d5c5cc5a5c5d03"


# Generated at 2022-06-25 13:06:50.558208
# Unit test for function checksum
def test_checksum():
    var_0 = 'test_str'
    var_1 = ('test_str', 'test_str', ['test_str', 'test_str'],
             ('test_str', 'test_str', ['test_str', 'test_str']))
    var_2 = ('test_str',)
    var_3 = ('test_str', 32, ['test_str', 'test_str'],
             ('test_str', 'test_str', 'test_str', ['test_str', 'test_str']))
    var_4 = ('test_str', 32, 64, ['test_str', 'test_str'],
             ('test_str', 'test_str', 64, ['test_str', 'test_str']))
    str_0 = checksum(var_0)

# Generated at 2022-06-25 13:06:51.667763
# Unit test for function md5s
def test_md5s():
    print(md5s(0))

# Generated at 2022-06-25 13:06:55.844753
# Unit test for function md5s
def test_md5s():
    str1 = "123,456"
    str2 = "abc,def"
    assert md5s(str1) != md5s(str2)



# Generated at 2022-06-25 13:07:05.474497
# Unit test for function md5s
def test_md5s():
    # Test 1 - Typical usage
    assert md5s('Hi') == '49f68a5c8493ec2c0bf489821c21fc3b', 'Test #1'
    # Test 2 - Typical usage
    assert md5s(58.0) == '17d3c74d6c4622ad527e1867ef3a30a4', 'Test #2'
    # Test 3 - Typical usage
    assert md5s(27) == '0a4569ded816ebe66d6fae50c29117b6', 'Test #3'
    # Test 4 - Typical usage
    assert md5s('35') == '95a7a8b039f9ec09dbd0c1a2f8ba06c2', 'Test #4'
    # Test 5 - Typical usage
   

# Generated at 2022-06-25 13:07:07.900112
# Unit test for function md5s
def test_md5s():
    var_1 = md5s(385.5)
    assert var_1 == '6abd118d0059d98b9a03b0fe6d9c2a8a'


# Generated at 2022-06-25 13:07:10.632290
# Unit test for function md5
def test_md5():
    try:
        md5("test_data/test.txt")
    except Exception as e:
        print("Exception caught, message: " + str(e))


if __name__ == "__main__":
    test_case_0()
    test_md5()

# Generated at 2022-06-25 13:07:12.543459
# Unit test for function md5s
def test_md5s():
    assert md5s(8820) == '6f7255a2a3de1d0cbf2f26066349d6c3'


# Generated at 2022-06-25 13:07:14.467816
# Unit test for function checksum
def test_checksum():
    assert secure_hash_s('test_checksum') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'


# Generated at 2022-06-25 13:07:17.694398
# Unit test for function md5
def test_md5():
    test_file = os.path.join(os.path.dirname(__file__), 'data', 'checksum.txt')
    ret = md5(test_file)
    assert ret == '8a36a5511bc0e3ea0de573e7b8d1f0c3'


# Generated at 2022-06-25 13:07:24.245023
# Unit test for function md5s
def test_md5s():
    assert secure_hash_s(str) == 'ce0111b0d5a5e5fdd476fb022f7c8e4d'


# Generated at 2022-06-25 13:07:25.631832
# Unit test for function md5s
def test_md5s():
    s_0 = 'qwer1234'
    var_1 = md5s(s_0)

# Generated at 2022-06-25 13:07:27.586050
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '7c3510a2a74b8f236e12f7dee260bf87'


# Generated at 2022-06-25 13:07:30.417797
# Unit test for function md5s
def test_md5s():
    float_0 = -686.0
    var_0 = secure_hash_s(float_0)
    assert var_0 == "bd8d98e81a2dda417b9a3237d8c5b5e5"


# Generated at 2022-06-25 13:07:31.822908
# Unit test for function md5
def test_md5():
    string_0 = 'test_file.txt'
    var_0 = md5(string_0)


# Generated at 2022-06-25 13:07:39.167955
# Unit test for function checksum
def test_checksum():

    assert checksum('filename') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert checksum_s('string') == 'd41d8cd98f00b204e9800998ecf8427e'

    if _md5:
        assert md5('filename') == 'd41d8cd98f00b204e9800998ecf8427e'
        assert md5s('string') == 'd41d8cd98f00b204e9800998ecf8427e'

if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-25 13:07:40.621267
# Unit test for function md5s
def test_md5s():
    float_0 = -686.0
    var_0 = md5s(float_0)


# Generated at 2022-06-25 13:07:42.523753
# Unit test for function md5
def test_md5():
    assert md5('foo.txt') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-25 13:07:44.313240
# Unit test for function md5s
def test_md5s():
    assert md5s('value') == '2063c1608d6e0baf80249c42e2be5804'


# Generated at 2022-06-25 13:07:45.222766
# Unit test for function md5
def test_md5():
    pass



# Generated at 2022-06-25 13:07:50.892675
# Unit test for function md5s
def test_md5s():
    assert md5s(3) == '3e25960a79dbc69b674cd4ec67a72c62'


# Generated at 2022-06-25 13:07:53.063895
# Unit test for function checksum
def test_checksum():
    assert md5('tests/test_utils/test_checksum/dummy_file') == 'b6a23145c5e0e3dee05a77b1a0e907ff'


# Generated at 2022-06-25 13:07:55.706642
# Unit test for function checksum
def test_checksum():
    expected = 'eaa52bfa5e2a1f7aea99c9b9d7a46c6e65514725'
    filename = './test/support/files/hello.txt'
    result = checksum(filename)
    assert result == expected

# Generated at 2022-06-25 13:08:03.993771
# Unit test for function md5
def test_md5():
    to_bytes()

# Generated at 2022-06-25 13:08:11.060635
# Unit test for function checksum
def test_checksum():
    # Test with a file that exists
    test_checksum = '77a8a58e3157aa3bd53e9972b70d091f'
    f = open('test_checksum.txt', 'w')
    f.write('This is a test string')
    f.close()
    assert checksum('test_checksum.txt') == test_checksum
    # Test with a file that does not exist
    assert checksum('bogus.txt') == None
    # Test with a directory
    assert checksum('./') == None


# Generated at 2022-06-25 13:08:12.862135
# Unit test for function md5s
def test_md5s():
    assert md5s(b'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-25 13:08:20.378870
# Unit test for function md5s
def test_md5s():
    float_0 = -686.0
    var_0 = md5s(float_0)
    float_1 = -639.0
    var_1 = md5s(float_1)
    if var_0 != var_1:
        print("1: %s" % var_0)
        print("2: %s" % var_1)
        return False
    float_2 = -597.0
    var_2 = md5s(float_2)
    float_3 = -777.0
    var_3 = md5s(float_3)
    if var_2 != var_3:
        print("3: %s" % var_2)
        print("4: %s" % var_3)
        return False
    float_4 = -540.0
    var_4 = md

# Generated at 2022-06-25 13:08:23.210139
# Unit test for function md5
def test_md5():
    param_0 = "/?read"
    var_0 = md5(param_0)
    with open(param_0, "w"):
        pass
    var_1 = md5(param_0)
    assert (var_0 != var_1)


# Generated at 2022-06-25 13:08:31.624709
# Unit test for function md5s
def test_md5s():
    r_0 = md5s(1)
    assert r_0 == '37c937a2f4c8d7a4ab4c60aa1f4d8f06'
    r_1 = md5s('ansible')
    assert r_1 == '5e5e5ccc40ce8e543f91934df825b656'
    r_2 = md5s([1, 2, 3])
    assert r_2 == '912ec803b2ce49e4a541068d495ab570'
    r_3 = md5s('ansible')
    assert r_3 == '5e5e5ccc40ce8e543f91934df825b656'
    r_4 = md5s(1)

# Generated at 2022-06-25 13:08:41.103901
# Unit test for function md5s
def test_md5s():
    # The test values are taken from example in https://en.wikipedia.org/wiki/MD5
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('message digest') == 'f96b697d7cb7938d525a2f31aaf161d0'
    assert md5s('abcdefghijklmnopqrstuvwxyz') == 'c3fcd3d76192e4007dfb496cca67e13b'
    assert md

# Generated at 2022-06-25 13:08:47.769742
# Unit test for function md5
def test_md5():
    var_0 = secure_hash_s(56.0,sha1)
    assert var_0 is not None, 'var_0 is None'


# Generated at 2022-06-25 13:08:50.128864
# Unit test for function md5s
def test_md5s():
    float_0 = -686.0
    var_0 = md5s(float_0)


# Generated at 2022-06-25 13:08:51.995284
# Unit test for function md5s
def test_md5s():
    float_0 = -686.0
    var_0 = md5s(float_0.__str__())


# Generated at 2022-06-25 13:08:54.492575
# Unit test for function md5
def test_md5():
    data = "123abc"
    assert md5s(data) == '202cb962ac59075b964b07152d234b70'



# Generated at 2022-06-25 13:08:57.212294
# Unit test for function md5s
def test_md5s():
    print("Test: md5s()")
    assert md5s(float_0) == "e6d723d8d0232c63f5840e3ce0d80f76"


# Generated at 2022-06-25 13:08:59.825536
# Unit test for function md5s
def test_md5s():
    _in = 'test'
    _out = md5s(_in)
    assert (_out == '098f6bcd4621d373cade4e832627b4f6')


# Generated at 2022-06-25 13:09:10.745922
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s(12345) == '827ccb0eea8a706c4c34a16891f84e7b'
    assert md5s(False) == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('test in python2') == 'c80e9f6a89a99c18e6afbfd6a8c87e54'
    assert md5s('test in python3') == 'f897393f16ae6d0a6c0ed6efb7c3d56d'

# Generated at 2022-06-25 13:09:12.284539
# Unit test for function md5
def test_md5():
    assert(md5("/tmp/no_file") is None)




# Generated at 2022-06-25 13:09:20.158253
# Unit test for function md5
def test_md5():
    import os
    import tempfile
    assert not md5('/does/not/exist')
    assert not md5(None)
    assert md5(__file__) == md5(__file__)

    fd, fname = tempfile.mkstemp()
    os.close(fd)
    try:
        assert not md5(fname)
        with open(fname, 'w') as f:
            f.write('test')
        assert md5(fname) == '098f6bcd4621d373cade4e832627b4f6'
    finally:
        os.unlink(fname)

# Generated at 2022-06-25 13:09:23.970545
# Unit test for function md5s
def test_md5s():
    # Test 1
    float_0 = -686.0
    var_0 = secure_hash_s(float_0)
    assert var_0 == "0a7c6fe40d0f0c35a63b2d4b70942ba4"


# Generated at 2022-06-25 13:09:34.288686
# Unit test for function checksum
def test_checksum():
    assert checksum('test/test_utils/test_checksum.py') == checksum_s('')
    assert checksum('test/test_utils/test_checksum.py') != checksum_s('test/test_utils/test_checksum.py')
    assert checksum('test/test_utils/test_checksum.py') != checksum_s('tests/test_utils/test_checksum.py')
    try:
        checksum('test/test_utils/test_checksum_file_not_exist.py')
    except AnsibleError:
        pass
    else:
        assert False, 'should not pass here.'



# Generated at 2022-06-25 13:09:36.269105
# Unit test for function md5s
def test_md5s():
    assert md5s('makethisover1') == 'd1829a2e2cfbbaae799e8a4011b50470'


# Generated at 2022-06-25 13:09:37.246874
# Unit test for function md5s
def test_md5s():
    test_case_0()

# Generated at 2022-06-25 13:09:41.588919
# Unit test for function checksum
def test_checksum():
    data = 'Some random string'
    hashed = checksum_s(data)

    assert len(hashed) == 40
    assert hashed == 'c2b4d0a69e6e878f5d5f5ed5d4be4c4d4e4b2c4b'


# Generated at 2022-06-25 13:09:49.621273
# Unit test for function checksum
def test_checksum():
    # We're just testing the encodings here
    assert checksum_s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert checksum_s('é') == '9fdbc2e78bbaa6a0e6d7b23ea396b60a'
    assert checksum_s('é', hash_func=_md5) == '0f4d86785cc2bb4e6663a3c2e9b00e24'
    assert checksum_s(u'é') == '9fdbc2e78bbaa6a0e6d7b23ea396b60a'

# Generated at 2022-06-25 13:09:55.386635
# Unit test for function md5s
def test_md5s():
    # Test case 0
    float_0 = -686.0
    var_0 = md5s(float_0)
    assert var_0 == '767a614c20137f6b83780b00f6b365d6'

    # Test case 1
    float_0 = -706.0
    var_0 = md5s(float_0)
    assert var_0 == '814f48b7c75a28e1a8fcee9d903d6b93'

    # Test case 2
    float_0 = -106.0
    var_0 = md5s(float_0)
    assert var_0 == 'de9735b55cacf5ed5ab0c60230cce9f9'

    # Test case 3
    float_0 = -1.0


# Generated at 2022-06-25 13:09:57.972066
# Unit test for function md5
def test_md5():
    assert(md5('file.txt')=='49e95c2a80a8a9c9beaea7f1e2afb2f8')


# Generated at 2022-06-25 13:10:00.249348
# Unit test for function md5s
def test_md5s():
    output = md5s(123.5)
    assert output == "5d9dbda9df7e2cdde6d74470f4b40e7b"


# Generated at 2022-06-25 13:10:09.631004
# Unit test for function md5
def test_md5():
    # Make sure we can successfully calculate for a file.
    assert checksum("test/support/test_md5.py") == "76227711b4c4f4db4af37a6d08d6fcfa"
    # calc_md5 should give the same output.
    assert calc_md5("test/support/test_md5.py") == checksum("test/support/test_md5.py")
    # Make sure we can successfully calculate for a string
    assert checksum_s("test string") == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"
    # calc_md5 should give the same output.
    assert calc_md5_s("test string") == checksum_s("test string")


# Generated at 2022-06-25 13:10:16.530854
# Unit test for function checksum
def test_checksum():
    print("*** test_checksum ***")

    float_0 = -686.0
    var_0 = secure_hash_s(float_0)

    int_0 = -675
    var_1 = secure_hash_s(int_0)

    float_1 = -43.0
    var_2 = secure_hash_s(float_1)

    str_0 = 'test_checksum'
    var_3 = secure_hash_s(str_0)

    str_1 = 'test_checksum'
    var_4 = secure_hash_s(str_1)

    str_2 = 'test_checksum'
    var_5 = checksum_s(str_2)

    str_3 = 'test_checksum'
    var_6 = secure_hash_s(str_3)

   

# Generated at 2022-06-25 13:10:22.418078
# Unit test for function md5s
def test_md5s():
    float_0 = -458.0
    var_0 = md5s(float_0)


# Generated at 2022-06-25 13:10:25.355221
# Unit test for function checksum
def test_checksum():
    filename = 'ansible.cfg'
    var_1 = checksum(filename)
    assert(var_1 == 'a5c2fe1dabfcadda38ae9c0b11a3b64e88a0bfe7')


# Generated at 2022-06-25 13:10:29.383526
# Unit test for function md5
def test_md5():
    assert md5('foo.txt') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-25 13:10:37.736347
# Unit test for function md5s
def test_md5s():
    # Check that md5s calculates a valid md5 hash of the given string
    assert md5s("") == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s("a") == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s("abc") == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s("message digest") == 'f96b697d7cb7938d525a2f31aaf161d0'
    assert md5s("abcdefghijklmnopqrstuvwxyz") == 'c3fcd3d76192e4007dfb496cca67e13b'