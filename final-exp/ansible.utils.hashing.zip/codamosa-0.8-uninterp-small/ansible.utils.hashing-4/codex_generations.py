

# Generated at 2022-06-25 13:00:46.981521
# Unit test for function md5
def test_md5():
    result = md5("abcdefghijklmnopqrstuvwxyz")
    assert result == "c3fcd3d76192e4007dfb496cca67e13b", "md5(abcdefghijklmnopqrstuvwxyz) does not return c3fcd3d76192e4007dfb496cca67e13b but it returns %s" %result

test_md5()
test_case_0()

# Generated at 2022-06-25 13:00:48.665353
# Unit test for function checksum
def test_checksum():
    file = open(__file__, 'r')
    checksum_value = checksum(file)
    print(checksum_value)


# Generated at 2022-06-25 13:00:52.475204
# Unit test for function checksum
def test_checksum():
    with open(__file__) as f:
        checksum_0 = checksum(f)

    with open(__file__) as f:
        checksum_1 = checksum(f)

    assert checksum_0 == checksum_1


# Generated at 2022-06-25 13:00:53.416005
# Unit test for function checksum
def test_checksum():
    assert checksum(filen)


# Generated at 2022-06-25 13:01:00.279455
# Unit test for function checksum
def test_checksum():
    import os
    from ansible.utils.hashing import checksum
    from ansible.utils.hashing import checksum_s
    # Use the test file which has md5=e9c0c9e89b3c3d1a3cdfadcbaad4860c

# Generated at 2022-06-25 13:01:09.017173
# Unit test for function md5s

# Generated at 2022-06-25 13:01:11.610249
# Unit test for function md5
def test_md5():
    assert md5('data/test_md5') == '80e9c9a32033db6e5d6b569f2acee6a3'


# Generated at 2022-06-25 13:01:13.447983
# Unit test for function checksum
def test_checksum():
    print(checksum('time_module.py'))
    print(checksum_s('-500'))


# Generated at 2022-06-25 13:01:15.267908
# Unit test for function md5s
def test_md5s():
#    print("Test case 0")
    test_case_0()

test_md5s()

# Generated at 2022-06-25 13:01:21.259145
# Unit test for function checksum
def test_checksum():
    assert(checksum('a.txt') == 'acbd18db4cc2f85cedef654fccc4a4d8')
    # assert(checksum('b.txt') == 'acbd18db4cc2f85cedef654fccc4a4d8')  # b.txt doesn't exist
    assert(checksum('c.txt') == 'c9f6e89b6d47394a28b819c4e6d7bdde')


# Generated at 2022-06-25 13:01:24.929931
# Unit test for function md5
def test_md5():
    assert md5('/etc/hosts') != None


# Generated at 2022-06-25 13:01:27.489936
# Unit test for function checksum
def test_checksum():
    assert checksum('file1') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert checksum('file2') == 'd41d8cd98f00b204e9800998ecf8427e'


if __name__ == '__main__':
#    test_checksum()
    test_case_0()

# Generated at 2022-06-25 13:01:29.559095
# Unit test for function checksum
def test_checksum():
    assert(checksum('/etc/passwd') == '2f3a3e1d2ae6e8137141c98a3f014c7d')


# Generated at 2022-06-25 13:01:35.003764
# Unit test for function md5s
def test_md5s():
    int_0 = -5092
    var_0 = md5s(int_0)

# Generated at 2022-06-25 13:01:38.885948
# Unit test for function checksum
def test_checksum():
    input = 'data: test_string'
    expected_output = '8aa60a1c48cc30f9a7beb935e99b5613f0b46e0c'
    output = checksum_s(input)
    assert output == expected_output


# Generated at 2022-06-25 13:01:44.002268
# Unit test for function md5s
def test_md5s():
    #
    # This test case was generated from the following code fragment
    #

    int_0 = -5092

    var_0 = md5s(int_0)
    f = open(r'md5s.txt', 'w')
    f.write(var_0)
    f.close()


# Generated at 2022-06-25 13:01:47.601549
# Unit test for function md5
def test_md5():
    data = to_bytes("hello world", errors='surrogate_or_strict')
    assert checksum_s(data) == md5s(data)
    #assert checksum_s(None) == md5s(None)
    #assert checksum_s("") == md5s("")


# Generated at 2022-06-25 13:01:51.300678
# Unit test for function md5s
def test_md5s():
    assert secure_hash_s(-5092,_md5) == '6be024c2b095c8a7e34c056dab2d9b62'


# Generated at 2022-06-25 13:01:52.476605
# Unit test for function md5s
def test_md5s():
    test_case_0()


# Generated at 2022-06-25 13:01:57.838095
# Unit test for function checksum
def test_checksum():
    int_0 = -4961716
    var_0 = checksum_s(int_0)
    assert var_0 == '2b1f7a0a851b8c715c9a9e0be668fca95af8b4c1'

# Run the tests
if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-25 13:02:04.647014
# Unit test for function md5
def test_md5():
    assert(md5('./../../library/get_url.py') == 'de0d9a95a55b83973b2315edb30f3573')
    assert(md5('./../../module_utils/urls.py') == '6f027d6e3e60a9aa8b0d621cc61dee0f')


# Generated at 2022-06-25 13:02:06.550761
# Unit test for function md5
def test_md5():
    md5 = md5s('123')
    assert(md5 == '202cb962ac59075b964b07152d234b70')

# Generated at 2022-06-25 13:02:12.113254
# Unit test for function md5s
def test_md5s():
    int_0 = -5092
    var_0 = md5s(int_0)
    if var_0 != 'a9a051faa83d2bb067fc595ecb5da532':
        print('[-] md5s: Expected %s; got %s' % ('a9a051faa83d2bb067fc595ecb5da532', var_0))


# Generated at 2022-06-25 13:02:18.132865
# Unit test for function md5
def test_md5():
    md5 = md5s
    md5 = md5
    test = {
        "test_case_0": {
            "input_args": [
                -5092,
            ],
            "output": "f7fa57f8a61a7ffb1d3b21476f58c878",
        },
    }
    result = test[test_case_0.__name__]["output"]
    assert result == test_case_0()

# Generated at 2022-06-25 13:02:20.534318
# Unit test for function md5s
def test_md5s():
    assert 'ed65a9a9fc7fdfa3d3ffc863f8f8a7c1' == test_case_0()


# Generated at 2022-06-25 13:02:21.490725
# Unit test for function md5
def test_md5():
    assert md5(0) == ''



# Generated at 2022-06-25 13:02:27.160932
# Unit test for function checksum
def test_checksum():
    o_file = open(r"test_cases/test_case_0.log")
    o_file_content = o_file.read()
    o_file.close()
    test_case = o_file_content

    str_0 = checksum(test_case, sha1)
    print(str_0)



# Generated at 2022-06-25 13:02:28.508277
# Unit test for function md5
def test_md5():
    assert md5(filename) == checksum(filename)


# Generated at 2022-06-25 13:02:30.513367
# Unit test for function checksum
def test_checksum():
    int_0 = 6862
    var_0 = checksum(int_0)


# Generated at 2022-06-25 13:02:35.574206
# Unit test for function md5s
def test_md5s():
    assert md5s(0) == 'cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e'


# Generated at 2022-06-25 13:02:44.856570
# Unit test for function checksum
def test_checksum():
    assert checksum('test.txt') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert checksum('test.txt', hash_func=sha1) == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('test.txt') == '6f8db599de986fab7a21625b7916589c'


# Generated at 2022-06-25 13:02:50.269134
# Unit test for function md5
def test_md5():
    print("== test_md5 ==")
    int_0 = -5092
    var_0 = md5(int_0)
    if var_0 == 'd41d8cd98f00b204e9800998ecf8427e':
        print("Passed!")
    else:
        print("Failed!")


# Generated at 2022-06-25 13:02:55.363107
# Unit test for function checksum
def test_checksum():
    sample_data = 'test'
    expected_result = 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    checksum_value = checksum_s(sample_data)
    print ("checksum(",sample_data,") =",checksum_value, ", expected:", expected_result)
    assert checksum_value == expected_result

# Test Case with variable assignment in all branches

# Generated at 2022-06-25 13:02:59.632547
# Unit test for function md5
def test_md5():
    test_file = '/etc/hosts'
    var_0 = md5(test_file)
    assert var_0 == '65e29ddcdf3e0f744e10bbd9ce3da3f5', "expected var_0 to be 65e29ddcdf3e0f744e10bbd9ce3da3f5"


# Generated at 2022-06-25 13:03:02.435017
# Unit test for function checksum
def test_checksum():
    int_0 = -5092
    assert checksum(int_0) == md5(int_0)
    assert checksum_s(int_0) == md5s(int_0)


# Generated at 2022-06-25 13:03:11.786394
# Unit test for function md5s
def test_md5s():
    int_0 = -1685
    var_0 = md5s(int_0)
    if (var_0.__ne__('3b01c47eafd9100f9e07a70f8e8fae92')):
        print('FAILED: md5s failed for int')
    int_0 = 1467
    var_0 = md5s(int_0)
    if (var_0.__ne__('a612537e5e2ef8a5dd532d60f7e42cfc')):
        print('FAILED: md5s failed for int')
    int_0 = -6817
    var_0 = md5s(int_0)

# Generated at 2022-06-25 13:03:16.985575
# Unit test for function md5
def test_md5():
    # Create a test file
    with open('testfile.txt', 'w') as f:
        f.write('This is a test file.\n')
    # Search for the test file in the directory and generate an md5sum for it
    for file in os.listdir('./'):
        if file == 'testfile.txt':
            md5sum = md5(file)
            return md5sum



# Generated at 2022-06-25 13:03:19.691054
# Unit test for function md5s
def test_md5s():
    int_0 = -5092
    var_0 = md5s(int_0)
    assert var_0 == "a3d3a504bffd3b0f40ab0aa2b2c5633b"


# Generated at 2022-06-25 13:03:24.783935
# Unit test for function checksum
def test_checksum():
    # Assert if secure_hash_s(data, hash_func=sha1) == '749362756e35b8a6690e65dbee7d56ea7523f9c9':
    assert secure_hash_s(data, hash_func=sha1) == '749362756e35b8a6690e65dbee7d56ea7523f9c9'

# Generated at 2022-06-25 13:03:27.046397
# Unit test for function md5s
def test_md5s():
    ret_1 = md5s(-5092)
    if ret_1 is not None:
        assert False


# Generated at 2022-06-25 13:03:38.458201
# Unit test for function checksum
def test_checksum():
    # Get the full path of the test file
    import sys, os.path, inspect
    path_of_current_file = os.path.abspath(\
            os.path.split(inspect.getfile( inspect.currentframe() ))[0])
    test_file = os.path.join(path_of_current_file, "test_file")
    # Create a file with the test string
    f = open(test_file, "w")
    test_str = "The quick brown fox jumps over the lazy dog"
    f.write(test_str)
    f.close()
    # Create another file with the same test string
    f = open(test_file+".aux", "w")
    f.write(test_str)
    f.close()
    # Get the checksum using the string version of the function

# Generated at 2022-06-25 13:03:40.548398
# Unit test for function md5
def test_md5():
    # test with a file that doesn't exist
    var_1 = md5("/var/log")
    # test with a file that exists
    var_2 = md5("/etc/passwd")


# Generated at 2022-06-25 13:03:50.365341
# Unit test for function md5s
def test_md5s():
    print("in md5s")
    assert md5s(5) == '6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b'
    assert md5s(0) == 'cfcd208495d565ef66e7dff9f98764da'
    assert md5s(-1) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(False) == 'cfcd208495d565ef66e7dff9f98764da'
    assert md5s(True) == '3e25960a79dbc69b674cd4ec67a72c62'

# Generated at 2022-06-25 13:03:53.083351
# Unit test for function checksum
def test_checksum():
    hello = "Hello, World!"
    print (checksum_s(hello))
    print (checksum(hello))
    print (checksum_s("hello"))
    print (checksum("hello"))


# Generated at 2022-06-25 13:03:54.745682
# Unit test for function md5
def test_md5():
    assert callable(md5)
    assert isinstance(md5('input'), str)


# Generated at 2022-06-25 13:03:58.438700
# Unit test for function md5
def test_md5():
    assert md5('test') == '098f6bcd4621d373cade4e832627b4f6', 'md5 failed'
    assert md5(80) == 'f27b9f1d42d2feffc682233b1fa8e86d', 'md5 failed'


# Generated at 2022-06-25 13:04:04.995532
# Unit test for function md5
def test_md5():
    import tempfile
    (fd, fn) = tempfile.mkstemp(prefix='ansible_test')
    with os.fdopen(fd, 'w') as f:
        f.write('abc')
    m = md5(fn)
    os.remove(fn)
    assert m == '900150983cd24fb0d6963f7d28e17f72', 'Expected the checksum of "900150983cd24fb0d6963f7d28e17f72" but got "%s"' % m


# Generated at 2022-06-25 13:04:06.534834
# Unit test for function checksum
def test_checksum():
    sum = checksum(filename='/etc/resolv.conf')
    print(sum)


# Generated at 2022-06-25 13:04:15.895919
# Unit test for function md5
def test_md5():
    assert md5("a") == '0cc175b9c0f1b6a831c399e269772661'
    assert md5("abcd") == 'e2fc714c4727ee9395f324cd2e7f331f'
    assert md5("abcdefghijklmnopqrstuwxyz") == 'c3fcd3d76192e4007dfb496cca67e13b'
    assert md5("ABCDEFGHIJKLMNOPQRSTUWXYZabcdefghijklmnopqrstuwxyz0123456789") == 'd174ab98d277d9f5a5611c2c9f419d9f'

# Generated at 2022-06-25 13:04:16.774679
# Unit test for function md5
def test_md5():
    test_case_0()


# Generated at 2022-06-25 13:04:21.495849
# Unit test for function md5
def test_md5():
    test_str = "test"
    expected_output = "098f6bcd4621d373cade4e832627b4f6"
    assert md5s(test_str) == expected_output

# Generated at 2022-06-25 13:04:31.096784
# Unit test for function md5s
def test_md5s():
    int_0 = -5092
    var_0 = md5s(int_0)
    assert 'fb37aefa7b78e3a3fe7f0619b64d5f59' == var_0
    str_0 = 'SI.6<xm&wM'
    var_1 = md5s(str_0)
    assert '44fc67e5a298042fde6f8e4f4bf6d77a' == var_1
    list_0 = []
    var_2 = md5s(list_0)
    assert 'd41d8cd98f00b204e9800998ecf8427e' == var_2
    list_1 = []
    list_2 = []
    list_1.append(list_2)
    var_3 = md

# Generated at 2022-06-25 13:04:40.983124
# Unit test for function checksum
def test_checksum():
    s = 'The quick brown fox jumps over the lazy dog'
    assert(checksum_s(s) == '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12')
    assert(checksum_s(s, 'sha1') == '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12')
    assert(checksum_s(s, 'sha256') == 'd7a8fbb307d7809469ca9abcb0082e4f8d5651e46d3cdb762d02d0bf37c9e592')

# Generated at 2022-06-25 13:04:42.857774
# Unit test for function md5s
def test_md5s():
    int_0 = -5092
    var_0 = md5s(int_0)
    print(var_0)
test_md5s()

# Generated at 2022-06-25 13:04:44.263732
# Unit test for function md5
def test_md5():
    data = 'Hello World'
    assert md5s(data) == md5s(data)


# Generated at 2022-06-25 13:04:52.903219
# Unit test for function md5s
def test_md5s():
    var_2 = "0x6bcfdc6c9a6a7665e0c86f0cb1c39490"
    var_3 = "0x00000bea"
    var_4 = "Failed to get md5 of string '0x00000bea'"
    var_5 = "-5092"
    var_6 = 0x6bcfdc6c9a6a7665e0c86f0cb1c39490
    var_7 = 0x00000bea
    var_8 = "Failed to get md5 of string '0x00000bea'"
    var_9 = -5092
    var_10 = "0xbf7e8a13d98e7c0b9f9711062d4c3111"
    var_11 = "0x000018b1"


# Generated at 2022-06-25 13:05:01.181440
# Unit test for function md5
def test_md5():
    assert md5("") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5("/etc/passwd") == "76cc92e80495d9fd2d2d0c51acb5aa7b"
    assert md5("/etc/shadow") == "7b89839327e686c08d02b3de3b3f07eb"

if __name__ == "__main__":
    test_case_0()
    test_md5()

# Generated at 2022-06-25 13:05:04.384202
# Unit test for function md5
def test_md5():
    # NOTE: currently this unit test is a bit limited and the only real
    # purpose is to ensure the unit test for md5 is executed and not
    # optimized out during test coverage analysis.

    # skip in FIPS mode
    if not _md5:
        return

    data = "abc"
    r = md5(data)
    assert r == '900150983cd24fb0d6963f7d28e17f72'



# Generated at 2022-06-25 13:05:09.785228
# Unit test for function checksum
def test_checksum():
    assert checksum(filename='test.txt') == 'd41d8cd98f00b204e9800998ecf8427e'

    os.system('echo -n "test string" > test.txt')

    assert checksum(filename='test.txt') == '58f6a3d3c8c6b1e6edd5d6f1b6ae5c6b'

    os.system('rm test.txt')


# Generated at 2022-06-25 13:05:20.892271
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    int_0 = -5092
    var_0 = md5s(int_0)
    if var_0 != '89a6dbd955ebac78b3c3b0fd14d32e2c':
        print('FAILED: md5s(int_0) = ' + var_0)
        return False

    filename = 'test'
    var_1 = md5(filename)
    if var_1 != 'b10a8db164e0754105b7a99be72e3fe5':
        print('FAILED: md5(filename) = ' + var_1)
        return False

    print('PASSED: md5')
    return True


# Generated at 2022-06-25 13:05:30.362751
# Unit test for function md5s
def test_md5s():
    import random
    import hashlib
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    # unit test for md5s()
    # generate a random integer
    int_0 = random.randint(-5000,5000)
    int_1 = random.randint(-5000,5000)
    # create a variable named var_0
    var_0 = md5s(int_0)
    # create a variable named var_1
    var_1 = hashlib.md5(str(int_0).encode('utf-8')).hexdigest()
    # check if var_0 and var_1 are equal
    assert var_0 == var_1


# Generated at 2022-06-25 13:05:32.727219
# Unit test for function md5
def test_md5():
    assert md5("test.txt") == "0a4d55a8d778e5022fab701977c5d840bbc486d0"

# Generated at 2022-06-25 13:05:33.682983
# Unit test for function md5s
def test_md5s():
    print(md5s(-5092))

# Generated at 2022-06-25 13:05:36.382583
# Unit test for function md5s
def test_md5s():
    in_var = 5092
    out_var = md5s(in_var)
    return out_var == "19ac96a9a9ab2790b1d568899c997e08" and in_var == 5092



# Generated at 2022-06-25 13:05:39.098329
# Unit test for function md5s
def test_md5s():
    var_0 = '-5092'
    var_0 = md5s(var_0)
    assert var_0 == 'c1bdb92f35d8e53c7c589e190d9a8327'

# Generated at 2022-06-25 13:05:41.764297
# Unit test for function md5s
def test_md5s():
    var = md5s(8.439722731921325)
    assert(var == "86d70ff3fd4c4b61ff7b95c25b3e3eac")
    

# Generated at 2022-06-25 13:05:43.606258
# Unit test for function md5
def test_md5():
        assert md5(test_case_0()) == '7f3d3e850175f71e18d31c7e2255f9c9'

# Generated at 2022-06-25 13:05:46.239361
# Unit test for function checksum
def test_checksum():
    assert checksum('./tests/unit_tests/hash_test_file') == 'f087fcd80e8b393c01b69f6d4caab4d9'


# Generated at 2022-06-25 13:05:48.965217
# Unit test for function md5s
def test_md5s():
    int_0 = -5092
    var_0 = md5s(int_0)
    print(var_0)

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-25 13:05:57.602852
# Unit test for function md5
def test_md5():
    import os

    os.environ['test_env'] = 'test_value'
    assert md5('/bin/sh') == "f99a9e6857bc2e2e97d734b8c57b7fa4"
    assert md5('/usr/bin/env') == "bace1d59867a33efc6f2326cb79d081b"
    assert md5('/usr/bin/env test_env=ansible') == "2b3a1d2c2f918a12a0afb82ac7c5921a"
    assert md5('/usr/bin/python -c "import os; print(os.environ[\"test_env\"])"') == "b51c8aacf462d791d9b9f08cc9099489"


# Generated at 2022-06-25 13:06:01.544369
# Unit test for function md5s
def test_md5s():
    for test_case_0 in range(1):
        res = md5s(test_case_0)
        if __name__ == "__main__":
            print(res)
        assert res == "bcb49ea65f54abd0cf28b773a25961e7"


# Generated at 2022-06-25 13:06:10.807924
# Unit test for function md5s
def test_md5s():
    assert md5s(1) == 'c4ca4238a0b923820dcc509a6f75849b'
    assert md5s('abc' * 1024) == '3b6435e0e86a8a3d4d2e75f6a079b8e1'
    assert md5s(1.1) == '8e640ee6565c7b43e9b72034f05bf6f0'
    assert md5s(2.2) == '589dacd7361b1da29b9a0d0a18c637e5'

    assert md5(1) is None
    assert md5(1.1) == '3e3c5c5e89bce567b66f267869f07d93'

# Generated at 2022-06-25 13:06:12.219135
# Unit test for function md5
def test_md5():
	str_0 = 'This is a test string'
	str_1 = md5(str_0)

# Generated at 2022-06-25 13:06:21.509615
# Unit test for function md5s

# Generated at 2022-06-25 13:06:25.081557
# Unit test for function md5s
def test_md5s():
    out_0 = md5s(-5092)
    assert out_0 == "f80dcc22f31a9a9c2a8e469f7f747b25"


# Generated at 2022-06-25 13:06:32.399602
# Unit test for function md5s
def test_md5s():
    ins_0 = 9223372036854775807
    assert(md5s(ins_0) == '0c8a8f65c0f0eeb6c5e6a8b638a67a88')

    ins_1 = b'\x00\x01\x00\x00'
    assert(md5s(ins_1) == 'bba4bb8f16ada72c93d77e4e4dbf3b28')

    ins_2 = 'd16e58613e3c1c03e6267b069d9aac27'
    assert(md5s(ins_2) == 'c5606c12bff6c5a9dd5d6a5a2c8af69d')


# Generated at 2022-06-25 13:06:39.850802
# Unit test for function md5s
def test_md5s():
    t_0 = md5s(10)
    assert t_0 == 'b9f06d9f115948a2599b3d0e2ecb3158'
    t_1 = md5s(20)
    assert t_1 == '71bf832949d46e0b0ecc73d6b8e50c51'
    t_2 = md5s(30)
    assert t_2 == '42bdc2e5a5f5d5d5a1c5a5f85b1d5f5a'
    t_3 = md5s(40)
    assert t_3 == 'c1a5a5c5a5f5d5d5a5a5a5f5c5a5a5a5'

# Generated at 2022-06-25 13:06:43.051947
# Unit test for function md5
def test_md5():
    assert md5s('test_md5') == '5e543256c480ac577d30f76f9120eb74'
    assert md5('test_md5.py') == '7ee2e376486b7e8bfd20e2a2c96a36d9'
    assert md5('test_md5.out') == None


# Generated at 2022-06-25 13:06:49.895920
# Unit test for function checksum
def test_checksum():
    '''Return a secure hash hex digest of local file'''
    # Source file
    source = 'test_checksum.txt'
    with open(source, 'w') as f:
        f.write('test_checksum')

    # Destination file
    dest = 'test_checksum.txt'
    with open(dest, 'w') as f:
        f.write('test_checksum_changed')

    # test file
    changed_file = "test_checksum_changed.txt"
    with open(changed_file, 'w') as f:
        f.write('test_checksum_changed')

    # Directory
    path = 'test_checksum_path'
    if not os.path.exists(path):
        os.makedirs(path)

    # No file

# Generated at 2022-06-25 13:06:53.912380
# Unit test for function md5s
def test_md5s():
    assert md5s(var_0) == "e848c40db9dc2baebc3e4dfe8a81aad4"



# Generated at 2022-06-25 13:07:03.432342
# Unit test for function md5s
def test_md5s():
    int_0 = -5092
    var_0 = md5s(int_0)
    print("%s: %s" % ("Expected output", "c7945f959800cfb3a3b81d229bae8e07"))
    print("%s: %s" % ("Received output", var_0))
    if (var_0 != "c7945f959800cfb3a3b81d229bae8e07"):
        var_1 = 1
    else:
        var_1 = 0
    assert var_1 == 0

# Generated at 2022-06-25 13:07:04.621987
# Unit test for function md5s
def test_md5s():
    print('Executing test case 0')
    test_case_0()


# Generated at 2022-06-25 13:07:06.201151
# Unit test for function md5
def test_md5():
    correct_md5 = "b7f30e6dd8ff7f89d2c657a3a6834f1b"
    data = "Just some test data for md5"
    md5_hash = md5s(data)
    assert md5_hash == correct_md5

# Generated at 2022-06-25 13:07:07.781630
# Unit test for function md5
def test_md5():
    try:
        md5()
    except (TypeError,ValueError) as e:
        assert False, "md5 function raised " + type(e).__name__ + ": " + str(e)



# Generated at 2022-06-25 13:07:08.417983
# Unit test for function md5s
def test_md5s():
    test_case_0()



# Generated at 2022-06-25 13:07:09.712005
# Unit test for function md5s
def test_md5s():
    try:
        tmp = md5s('s')
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 13:07:11.266211
# Unit test for function md5s
def test_md5s():
    assert md5s(0) == '8ad8757baa8564dc136c1e07507f4a98'


# Generated at 2022-06-25 13:07:15.711378
# Unit test for function md5
def test_md5():
    assert 'b01a7b78a9a1092b818f05e325bcbfb1' == md5('/tmp/goto.sh')
    assert '912ec803b2ce49e4a541068d495ab570' == md5('/tmp/music.mp3')
    assert 'd41d8cd98f00b204e9800998ecf8427e' == md5('/tmp/empty.txt')
    assert None == md5('/tmp/nonexistant')


# Generated at 2022-06-25 13:07:19.739558
# Unit test for function md5s
def test_md5s():
    assert md5s(5) == '5ccf7c91d59b8529e3a8d31f183bc800'
    assert md5s(-5092) == '877ee0c4803749a5f45b8afb18c7abef'
    assert md5s('Hello World') == 'ed076287532e86365e841e92bfc50d8c'


# Generated at 2022-06-25 13:07:21.317083
# Unit test for function md5s
def test_md5s():
    test_case_0()


if __name__ == '__main__':
    import sys
    sys.exit(test_md5s())

# Generated at 2022-06-25 13:07:25.603776
# Unit test for function md5
def test_md5():
    string = "abc"
    assert md5s(string) == md5("test/test_utils.py")

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-25 13:07:27.885072
# Unit test for function md5
def test_md5():
    assert md5(None) is None
    assert md5(1) is None
    assert md5([]) is None
    assert md5( [1,2,3] ) is None



# Generated at 2022-06-25 13:07:29.855485
# Unit test for function md5s
def test_md5s():
    data = 'test_string'
    assert(md5s(data) == '5e543256c480ac577d30f76f9120eb74')


# Generated at 2022-06-25 13:07:31.233821
# Unit test for function md5
def test_md5():
    res = md5("string")
    assert(res == type(res))


# Generated at 2022-06-25 13:07:34.883994
# Unit test for function md5s
def test_md5s():
    int_0 = -5092

    # Call function
    var_0 = md5s(int_0)

    assert_equal(var_0, '09dc08a99d70acf8df2e6af08de9ee9b')

# Generated at 2022-06-25 13:07:36.393161
# Unit test for function md5
def test_md5():
    np_file_path = ''
    assert md5(np_file_path) is None


# Generated at 2022-06-25 13:07:38.871151
# Unit test for function checksum
def test_checksum():
    assert(checksum('UnitTest/fakefilez.txt') == '23b9feae17656f8c68a2d2c0b14892b2a29d50dc')


# Generated at 2022-06-25 13:07:41.091887
# Unit test for function md5
def test_md5():
    print('************* Running md5 tests *************')
    test_case_0()

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-25 13:07:42.561671
# Unit test for function md5
def test_md5():
    with pytest.raises(ValueError):
        md5('/tmp/test')


# Generated at 2022-06-25 13:07:45.331831
# Unit test for function checksum
def test_checksum():
    assert(checksum("/home/jdoe/ansible/test/ansible-test") == "56bd43f0b9d9dfb8f54a38a3b7d3b3aac3e8bfff")


# Generated at 2022-06-25 13:07:48.180653
# Unit test for function md5
def test_md5():
    test_case_0()


# Generated at 2022-06-25 13:07:48.798650
# Unit test for function md5
def test_md5():
    test_case_0()


# Generated at 2022-06-25 13:07:51.727631
# Unit test for function md5s
def test_md5s():
    int_0 = -5092
    var_0 = md5s(int_0)

    assert var_0 == b'c56fb3b30ccc3a2c2d8d791ade3e34e9'
    print('TEST: md5s ' + var_0.decode())


# Generated at 2022-06-25 13:07:54.747586
# Unit test for function md5
def test_md5():
    tests = []
    tests.append(123)
    #tests.append(test_case_0)
    print(test_case_0())

    for i in tests:
        print(md5s(i))

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-25 13:07:55.773018
# Unit test for function md5
def test_md5():
    ret = md5('file.txt')
    print(ret)


# Generated at 2022-06-25 13:07:58.127635
# Unit test for function checksum
def test_checksum():
  try:
    assert checksum("test.txt") == "d41d8cd98f00b204e9800998ecf8427e"
  except AssertionError as e:
    print("Test checksum failed")



# Generated at 2022-06-25 13:07:59.629174
# Unit test for function md5
def test_md5():
    assert md5(3) == md5(3)


# Generated at 2022-06-25 13:08:03.525983
# Unit test for function md5
def test_md5():
    filename = "ansible"
    answer = "e3e3ea09a7414e56b7cdd71fa1f04fa7"
    result = md5(filename)
    print("Testcase 0: expected: %s, actual: %s" % (answer, result))
    assert result == answer


# Generated at 2022-06-25 13:08:05.804541
# Unit test for function md5
def test_md5():
    data = -5092

# Generated at 2022-06-25 13:08:06.620439
# Unit test for function md5s
def test_md5s():
    test_case_0()


# Generated at 2022-06-25 13:08:13.574355
# Unit test for function md5s
def test_md5s():
    test_int = 578
    test_result = md5s(test_int)
    assert isinstance(test_result, str)
    assert len(test_result) == 32

# Generated at 2022-06-25 13:08:20.921402
# Unit test for function md5s
def test_md5s():
    # Return type test
    #assert isinstance(md5s(int), str)

    # Assertion test
    assert(md5s("abcdefghijklmnopqrstuvwxyz") == "c3fcd3d76192e4007dfb496cca67e13b")

    # Assertion test
    assert(md5s("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789") == "d174ab98d277d9f5a5611c2c9f419d9f")

    # Assertion test

# Generated at 2022-06-25 13:08:24.419850
# Unit test for function md5
def test_md5():
    int_0 = -5092
    var_0 = md5s(int_0)
    assert var_0 == 'd0c7f8b928f9c46592b5d0d5a5f0e5e5'


# Generated at 2022-06-25 13:08:32.144557
# Unit test for function md5
def test_md5():
    var_0 = md5('/etc/passwd')
    if var_0 is not None:
        print('md5 - passwd: ' + var_0)
    else:
        print('md5 - passwd: None')
    var_1 = md5('/etc/group')
    if var_1 is not None:
        print('md5 - group: ' + var_1)
    else:
        print('md5 - group: None')
    var_2 = md5('/bin/sh')
    if var_2 is not None:
        print('md5 - sh: ' + var_2)
    else:
        print('md5 - sh: None')
    var_3 = md5('/etc/passwd1')

# Generated at 2022-06-25 13:08:38.560339
# Unit test for function checksum
def test_checksum():
    print("Running test_checksum ...")

    filename = "test"
    var_0 = checksum(filename)
    assert var_0 == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"

    print("test_checksum completed")

if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-25 13:08:42.383131
# Unit test for function md5s
def test_md5s():
    assert md5s(-5092) == 'c2895e04a39307f56d34fdafb7afc5c5'


# Generated at 2022-06-25 13:08:45.146192
# Unit test for function md5
def test_md5():
    int_0 = -5092
    var_0 = secure_hash_s(int_0, sha1)
    # print(var_0)


# Generated at 2022-06-25 13:08:52.655373
# Unit test for function md5
def test_md5():
    with open("output.txt", "wb") as f:
        f.write(md5("../../files/hash/secure_hash.py"))
        f.write("\n")
        f.write(md5("../../files/hash/secure_hash.pyc"))
        f.write("\n")
        f.write(md5("../../files/hash/test_md5_file"))
        f.write("\n")
        f.write(md5("../../files/hash/test_md5_file_fail"))
        f.write("\n")


# Generated at 2022-06-25 13:08:59.131945
# Unit test for function md5
def test_md5():
    test_file = "unit_test_file_do_not_delete"
    f = open(test_file, "wb")
    f.write("hello")
    f.close()
    with open(test_file, "rb") as f:
        assert(md5(test_file) == '5d41402abc4b2a76b9719d911017c592')
    os.remove(test_file)

if __name__ == '__main__':
    test_case_0()
    test_md5()

# Generated at 2022-06-25 13:09:03.518736
# Unit test for function md5s
def test_md5s():
    assert md5s("-5092") == 'fae7f090de69f1a8e45dbd2caa7ab1a8'


# Generated at 2022-06-25 13:09:11.023077
# Unit test for function md5
def test_md5():
    data = "Hello World"
    assert secure_hash_s(data, _md5) == md5s(data)

if __name__ == "__main__":
    test_md5()

# Generated at 2022-06-25 13:09:20.886696
# Unit test for function md5
def test_md5():
    assert md5s('15') == 'f7ddac1efdabb6b4cbf86e735d0c979c'
    assert md5s('7') == '6dc08f6e58a6b4798b3a9f4d4e8f8c1e'
    assert md5s('-856') == '519c39b21f9b27993a8b8a07b94e7d29'
    assert md5s('-74') == '50e943d95bbd6fef06a8e16a71ef79cf'
    assert md5s('-34') == '2d73516e45ead08c7cee4c13e077b1d6'

# Generated at 2022-06-25 13:09:21.799891
# Unit test for function md5s
def test_md5s():
    test_case_0()


# Generated at 2022-06-25 13:09:22.892461
# Unit test for function md5s
def test_md5s():
    print("md5s is ok.")


# Generated at 2022-06-25 13:09:31.845700
# Unit test for function md5s
def test_md5s():
    # Input parameters
    int_0 = -1201086419
    var_0 = md5s(int_0)
    if var_0 != 'a5320b02f6c1e6b5fc6b5d03f5af5d5e':
        raise Exception('Returned value was incorrect, expected \'a5320b02f6c1e6b5fc6b5d03f5af5d5e\', but got \'' + var_0 + '\'.')

    int_0 = -1032
    var_0 = md5s(int_0)

# Generated at 2022-06-25 13:09:38.674923
# Unit test for function checksum
def test_checksum():
    int_0 = 12332449765 * 12332449765 * 12332449765 * 12332449765 * 12332449765 * 12332449765 * 12332449765 * 12332449765 * 12332449765 * 12332449765 * 12332449765 * 12332449765 * 12332449765 * 12332449765 * 12332449765 * 12332449765 * 12332449765 * 12332449765 * 12332449765 * 12332449765 * 12332449765
    var_1 = checksum_s(int_0)


# Generated at 2022-06-25 13:09:40.099908
# Unit test for function md5
def test_md5():
    var_0 = True
    if var_0:
        test_case_0()

# Generated at 2022-06-25 13:09:41.160583
# Unit test for function md5s
def test_md5s():
    print(md5s(range(10)))



# Generated at 2022-06-25 13:09:49.268143
# Unit test for function md5s
def test_md5s():
    print(md5s(0))
    print(md5s(1))
    print(md5s(2))
    print(md5s(3))
    print(md5s(4))
    print(md5s(5))
    print(md5s(6))
    print(md5s(7))
    print(md5s(8))
    print(md5s(9))
    print(md5s(10))
    print(md5s(11))
    print(md5s(12))
    print(md5s(13))
    print(md5s(14))
    print(md5s(15))
    print(md5s(16))
    print(md5s(17))
    print(md5s(18))
    print(md5s(19))

# Generated at 2022-06-25 13:09:53.645128
# Unit test for function checksum
def test_checksum():
    #
    # Input parameters:
    #   filename: Filename to get the checksum for.
    #   hash_func: Type of hash function to use.
    #
    # Expected results:
    #   It is expected that sha1 hash is returned for file on disk.
    #
    filename = 'nonexistent_file'
    hash_func = sha1
    expected_result = None
    actual_result = checksum(filename, hash_func)
    assert actual_result == expected_result


# Generated at 2022-06-25 13:10:07.161211
# Unit test for function md5s
def test_md5s():
    var_0 = md5s(1)
    assert(var_0 == "c4ca4238a0b923820dcc509a6f75849b")
    var_1 = md5s(0)
    assert(var_1 == "d41d8cd98f00b204e9800998ecf8427e")
    var_2 = md5s(-5092)
    assert(var_2 == "1e07a02acf8e066a7a7d1a9e6c9a6fb3")
    var_3 = md5s(-100)
    assert(var_3 == "9cef7bab865b0812c9898e6a606d7c37")


# Generated at 2022-06-25 13:10:11.902511
# Unit test for function md5
def test_md5():
    # set these variables to test your function
    input_string = 'test'
    expected_sum = '098f6bcd4621d373cade4e832627b4f6'
    computed_sum = md5s(input_string)
    assert computed_sum == expected_sum, 'Expected %s but got %s' % (expected_sum, computed_sum)


# Generated at 2022-06-25 13:10:13.328923
# Unit test for function checksum
def test_checksum():
    # TODO: replace with real test case
    checksum('C:\\ansible\\tests\\unit\\modules\\file', sha1)
    assert True


# Generated at 2022-06-25 13:10:14.579521
# Unit test for function checksum
def test_checksum():
    filename = u"/home/z/data/tmp/ansible_code/temp/a"
    checksum(filename)


# Generated at 2022-06-25 13:10:19.532107
# Unit test for function md5s
def test_md5s():
    assert '8ebcb2672b02d830e38efbaca82122d5' == md5s(-5092)
    assert '5eb63bbbe01eeed093cb22bb8f5acdc3' == md5s(-6721)
    assert 'ace1b5a9b3ed1e5ee7c229a35b70a7b0' == md5s(-2175)
    assert '9bf9a4594cc6b2c6d8b6f28c611a41f7' == md5s(6374)
    assert '77e7e0c0d4697b3da4b81fd891f71cf8' == md5s(9171)

# Generated at 2022-06-25 13:10:21.017024
# Unit test for function md5s
def test_md5s():
    assert md5s(-5092) == "65c4f4d4b4d0566d6d8bf98c15ddb191"


# Generated at 2022-06-25 13:10:31.617360
# Unit test for function md5s
def test_md5s():
    int_2 = 'green'
    int_2_1 = str(int_2)
    str_1 = 'four'
    str_1_1 = str(str_1)
    dict_1 = {'one':1,'two':2,'three':3}
    dict_1_1 = str(dict_1)

    list_1 = [1,2,3]
    list_1_1 = str(list_1)
    assert md5s(str_0) == '0a279a2a6c7b0f14d9b9f1b4996afc50'
    assert md5s(int_2) == '7c6e14de2d107b76a3bc464a17c8edf5'

# Generated at 2022-06-25 13:10:35.569579
# Unit test for function md5s
def test_md5s():
    global int_0, var_0
    # Setup
    int_0 = -5092
    # Run function
    var_0 = md5s(int_0)
    # Verify results
    assert(var_0 == "260a3b8e5aacd7b1051dc36e8d63234d")
