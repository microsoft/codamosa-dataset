

# Generated at 2022-06-25 13:00:46.618254
# Unit test for function checksum
def test_checksum():
    '''
    Unit test for function checksum
    '''
    time_now = time.time()
    data_test = time_now
    
    assert checksum_s(data_test) == 'e1e6a61c01dba7e5d5e599856ceb69fe943d0f56'

if __name__ == '__main__':
    test_case_0()
    test_checksum()

# Generated at 2022-06-25 13:00:50.676697
# Unit test for function md5s
def test_md5s():
    int_0 = 733
    var_0 = md5s(int_0)
    assert var_0 == "f2d2d5b42fafb7c1b6cb0df7c2f6e959"
    print('Test case 0: md5s(int_0) = f2d2d5b42fafb7c1b6cb0df7c2f6e959')


# Generated at 2022-06-25 13:00:52.011866
# Unit test for function checksum
def test_checksum():
    print("Checking function checksum...")
    test_case_0()


# Generated at 2022-06-25 13:00:54.797271
# Unit test for function checksum
def test_checksum():
    test_val = "test"
    result = checksum(test_val)
    assert result == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'


# Generated at 2022-06-25 13:00:58.135876
# Unit test for function md5
def test_md5():
    assert md5(733) == '8b88d54ed0628ea820354cdf40ca6d8c'



# Generated at 2022-06-25 13:00:59.358615
# Unit test for function md5
def test_md5():
    # Test Case
    test_case_0()

# Generated at 2022-06-25 13:01:08.446599
# Unit test for function md5
def test_md5():
    data = b'This is the data to hash'
    assert md5s(data) == md5(data)
    assert md5s(data) == '7e9c9dc0dd8e0f86c2f7b6442d1ea3a6'
    assert md5s(data) == '7e9c9dc0dd8e0f86c2f7b6442d1ea3a6'
    assert md5s(data) == secure_hash_s(data, _md5)
    assert md5s(data) == secure_hash_s(data, hash_func=_md5)
    assert md5(data) == secure_hash(data, _md5)
    assert md5(data) == secure_hash(data, hash_func=_md5)


# Generated at 2022-06-25 13:01:10.230630
# Unit test for function md5s
def test_md5s():
    # Test that md5s return value is a string
    assert_type(test_case_0)



# Generated at 2022-06-25 13:01:12.609889
# Unit test for function md5s
def test_md5s():
    assert md5s(733) == 'b9d1c8e7f235e0bbc5a5e5c5d8e3f3a2'


# Generated at 2022-06-25 13:01:14.355850
# Unit test for function checksum
def test_checksum():
    assert secure_hash_s('737') == checksum_s('737')


# Generated at 2022-06-25 13:01:24.954211
# Unit test for function checksum
def test_checksum():
    data = b'foo'
    assert checksum_s(data) == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert md5s(data) == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert secure_hash_s(data) == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert secure_hash_s(data, hash_func=_md5) == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-25 13:01:26.299917
# Unit test for function md5
def test_md5():
    md5_0 = md5(test_case_0.__code__)



# Generated at 2022-06-25 13:01:30.008412
# Unit test for function checksum
def test_checksum():

    data_0 = 'Cannot open file: ansible'
    data_1 = 'Cannot open file: ansible'
    # AssertionError: 'Cannot open file: ansible' != 'Cannot open file: ansible'
    assert(checksum(data_0) == checksum(data_1))


# Generated at 2022-06-25 13:01:43.081569
# Unit test for function md5
def test_md5():
    output = md5('./ansible/utils/__init__.py')
    assert output == 'f0d844d03a2a6f7b617dbecc8fab7a6c'
    output = md5('./ansible/utils/__init__.py')
    assert output == 'f0d844d03a2a6f7b617dbecc8fab7a6c'
    output = md5('./ansible/utils/__init__.py')
    assert output == 'f0d844d03a2a6f7b617dbecc8fab7a6c'
    output = md5('./ansible/utils/__init__.py')

# Generated at 2022-06-25 13:01:50.435305
# Unit test for function checksum
def test_checksum():
    str_0 = 'abcd'
    str_1 = str_0
    str_2 = 'abcde'
    str_3 = 'abcdef'
    str_4 = 'abcdefg'
    str_5 = 'abcdefgh'
    str_6 = '\n    Unit test for function checksum\n    '
    str_7 = 'Unit test for function checksum'
    str_8 = 'Unit test for function md5'
    str_9 = '\n    Unit test for function md5\n    '
    str_10 = 'Unit test for function md5s'
    str_11 = '\n    Unit test for function md5s\n    '
    str_12 = 'Unit test for function secure_hash'

# Generated at 2022-06-25 13:01:53.149679
# Unit test for function md5
def test_md5():
    str_0 = '\n    Unit test for function md5\n    '


# Generated at 2022-06-25 13:01:54.647618
# Unit test for function md5s
def test_md5s():
    assert isinstance(md5s(str_0), str)


# Generated at 2022-06-25 13:01:58.499905
# Unit test for function md5s
def test_md5s():
    assert md5s('-\x82U\x0eo\x90a)\x1c\x9a\x8d\xa0\xc1') == '09d255e2f259ddaacd7ba5c5f5d5a5a5'


# Generated at 2022-06-25 13:02:03.210722
# Unit test for function checksum
def test_checksum():
    res_0 = checksum(str_0)
    assert res_0 == 'e2dac04bcb0f1e7e8c66ee2c7d7079a0e9e4ba4a'
    res_1 = checksum(None)
    assert res_1 == None
    res_2 = checksum(1)
    assert res_2 == None


# Generated at 2022-06-25 13:02:05.067351
# Unit test for function md5s
def test_md5s():
    try:
        results = md5s(str_0)
    except ValueError:
        pass


# Generated at 2022-06-25 13:02:16.077158
# Unit test for function checksum
def test_checksum():
    # md5 checksum
    file_0 = 'test/ansible_test/test_data/checksum_input'
    correct_digest_0 = 'fa0f65fa60c4b97cf4d4e90ce85b1857'
    assert md5(file_0) == correct_digest_0
    # sha1 checksum
    correct_digest_1 = 'a3dc0e8962afcddafdfa3888f3d3e3d5c68e5f97'
    assert checksum(file_0) == correct_digest_1
    str_1 = 'input test string'
    # sha1 checksum

# Generated at 2022-06-25 13:02:18.807060
# Unit test for function checksum
def test_checksum():
    (str_1, str_2) = ('name', 'ansible')
    assert checksum(str_1, str_2) == secure_hash(str_1, str_2)



# Generated at 2022-06-25 13:02:23.336583
# Unit test for function checksum
def test_checksum():
    try:
        correct_result = checksum('test_case_0.py')

    except Exception as err:
        assert False, "Test case test_checksum failed: " + str(err)
    else:
        assert True


if __name__ == '__main__':
    import sys
    import pytest

    pytest.main(sys.argv)

# Generated at 2022-06-25 13:02:25.503129
# Unit test for function md5
def test_md5():
    str_0 = '\n    Unit test for function md5\n    '


# Generated at 2022-06-25 13:02:31.909855
# Unit test for function checksum
def test_checksum():
    str_0 = '\n    Unit test for function checksum\n    '
    filename_0 = './test/test_utils.py'
    str_1 = checksum(filename_0)
    assert str_1 == '1d96d1922d08f0c843a24a14bbd7e04cc0edf3b3', 'Checksum error'


# Generated at 2022-06-25 13:02:33.835216
# Unit test for function md5s
def test_md5s():
    assert md5s(str_0) == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-25 13:02:41.528389
# Unit test for function checksum
def test_checksum():
    tests = 0
    fails = 0
    # test 0
    global str_0
    try:
        raise KeyError()
    except KeyError:
        str_0 = '\n    Unit test for function checksum\n    '
    if True: # built-in exception
        print(str_0)
        print('    Test 0: Expected exception')
        try:
            checksum()
        except TypeError:
            print('    Test 0: PASSED')
            tests += 1
        else:
            print('    Test 0: FAILED')
            fails += 1
    # Test 1: Test checksum of non-existent file
    print('    Test 1: Test checksum of non-existent file')

# Generated at 2022-06-25 13:02:47.588365
# Unit test for function checksum
def test_checksum():
    assert _md5('test string').hexdigest() == '4f4e4d4a24091879a3983af21d2f8792'
    assert _md5('test string' ).hexdigest() == '4f4e4d4a24091879a3983af21d2f8792'
    assert checksum('test string') == '3366cab7c1b6d8b8cbfe3bd3cf9c0a0a52b47244'


# Generated at 2022-06-25 13:02:49.219090
# Unit test for function md5s
def test_md5s():
    str_0 = '\n    Unit test for function md5s\n    '


# Generated at 2022-06-25 13:02:49.853511
# Unit test for function checksum
def test_checksum():
    test_case_0()


# Generated at 2022-06-25 13:02:57.642576
# Unit test for function checksum
def test_checksum():
    # Run function checksum with arguments
    key = 'sha1'
    file = os.path.join(os.path.dirname(__file__), 'test.py')
    result = checksum(file, algo=key)

    # Check that the result is correct
    assert result == 'b85d1b40a77b61366a75ee2e67ea721d95c0f902'


# Generated at 2022-06-25 13:03:01.062340
# Unit test for function checksum
def test_checksum():
    filename = '/tmp/test_file_0'
    result = None
    result = secure_hash(filename)
    assert result == 'd41d8cd98f00b204e9800998ecf8427e'
    assert result is not None


# Generated at 2022-06-25 13:03:03.250498
# Unit test for function md5
def test_md5():
    value = md5(str(''))
    assert value == 'd41d8cd98f00b204e9800998ecf8427e'



# Generated at 2022-06-25 13:03:12.607574
# Unit test for function md5
def test_md5():
    # print("Unit test for function md5")

    # test_case_0()
    str_0 = 'cheese'
    str_1 = secure_hash_s(str_0)
    assert str_1 == '66c3e531c1d2983d9f149dd2ab7e27342905a71e', "Checksum of string %s is incorrect" % str_0
    str_0 = '\x00'
    str_1 = secure_hash_s(str_0)
    assert str_1 == '34aa973cd4c4daa4f61eeb2bdbad27316534016f', "Checksum of string %s is incorrect" % str_0
    str_0 = '\x00\x00'

# Generated at 2022-06-25 13:03:14.720791
# Unit test for function md5s
def test_md5s():
    assert md5s('string') == '05bdc3d1c2ce2d9eb923e35a0beb89f5'


# Generated at 2022-06-25 13:03:19.277351
# Unit test for function md5s
def test_md5s():
    # Try to call the function, but catch any exception thrown and return False
    # instead.  We do this so we can run this function in the importer and be
    # able to turn it off later, if we don't have the function.
    try:
        md5s(str_0)
    except (NameError, NotImplementedError):
        return False
    return True



# Generated at 2022-06-25 13:03:22.865574
# Unit test for function md5
def test_md5():
    str_3 = './test/files/test_module.py'
    assert md5(str_3) == '2dd4af4f4c7d5e5c5cf5f5c5cf5f5c5c', 'md5 returned incorrect value'


# Generated at 2022-06-25 13:03:25.195868
# Unit test for function checksum
def test_checksum():
    assert secure_hash('/etc/passwd') == 'e53df9071d40bba5e5d5ad5c2b0f2730'


# Generated at 2022-06-25 13:03:28.139992
# Unit test for function md5s
def test_md5s():
    out_0 = 'a1a2b35f9a9d8ee0e10c3f3a3a65cfeb'
    assert md5s('root') == out_0


# Generated at 2022-06-25 13:03:30.324886
# Unit test for function md5s
def test_md5s():
    str_0 = 'hello world'
    str_1 = md5s(str_0)
    print(str_1)


# Generated at 2022-06-25 13:03:36.432475
# Unit test for function md5s
def test_md5s():
    str_0 = 'test'
    val_1 = md5s(str_0)
    assert val_1 == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-25 13:03:40.712902
# Unit test for function checksum
def test_checksum():
    assert checksum('test_data/test.py') == 'e8e5b5bac6e7e6d158b6d891025c0638d2ebc7f3'
    assert checksum('test_data/test.py', sha1) == 'e8e5b5bac6e7e6d158b6d891025c0638d2ebc7f3'


# Generated at 2022-06-25 13:03:50.587124
# Unit test for function checksum
def test_checksum():
    try:
        assert (secure_hash('/etc/passwd') in ('d3b07384d113edec49eaa6238ad5ff00', '8b8456c2edab7325a97a7c44ea902d1e'))
        assert (secure_hash('/etc/shadow') is None)
        assert (secure_hash('/etc/fake') is None)
        assert (secure_hash_s('hello') == '5d41402abc4b2a76b9719d911017c592')
        assert (secure_hash_s('world') == '7d793037a0760186574b0282f2f435e7')
    except AssertionError:
        raise AssertionError


if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-25 13:03:51.478478
# Unit test for function md5
def test_md5():
    pass


# Generated at 2022-06-25 13:03:57.616172
# Unit test for function checksum
def test_checksum():
    str_0 = 'test'
    str_1 = 'fdaa99b93ccaeff23bc965e14b3baa1b'
    ret_1 = checksum_s(str_0)
    assert ret_1 == str_1
    str_2 = '/etc/passwd'
    str_3 = '3b8ef8b16f83e367744665b9cfd5416d'
    ret_2 = checksum(str_2)
    assert ret_2 == str_3


# Generated at 2022-06-25 13:04:01.034566
# Unit test for function md5
def test_md5():
    str_0 = '\n    Unit test for function hash_v\n    '
    # Test case for function md5
    assert checksum(test_case_0.__name__) == md5(test_case_0.__name__)


# Generated at 2022-06-25 13:04:07.618497
# Unit test for function checksum
def test_checksum():
    data = 'This is a string'
    out = checksum_s(data)
    print(out)
    assert out == '737c0e47a0a84d1c914bc7eab9a63a4d1396f06c'

    data = 'This is a stringThis is a string'
    out = checksum_s(data)
    print(out)
    assert out == 'c7cc752f1c6d90b289cb19a6f83d6e51e6a8a6a5'


# Generated at 2022-06-25 13:04:16.895401
# Unit test for function md5s
def test_md5s():
    str_0 = '\n    Unit test for function md5s\n    '
    str_1 = 'b1946ac92492d2347c6235b4d2611184'
    var_1 = secure_hash_s(str_0, _md5)
    assert var_1 == str_1, 'AssertionError assert str(md5s(str_0)) == str_1'

    str_2 = 'foobar'
    str_3 = '3858f62230ac3c915f300c664312c63f'
    var_2 = secure_hash_s(str_2, _md5)
    assert var_2 == str_3, 'AssertionError assert str(md5s(str_2)) == str_3'


# Generated at 2022-06-25 13:04:21.915181
# Unit test for function checksum
def test_checksum():

    # Create a new context for function 'checksum'
    # This may be used to cache information about the checksum function
    # Determine if the function can be successfully called
    try:
        checksum(filename='file')
    # The exception information is not required
    except:
        # Unable to call the function
        str_0 = str('''Cannot call function "checksum"''')
        raise Exception(str_0)


# Generated at 2022-06-25 13:04:22.821176
# Unit test for function checksum
def test_checksum():
    assert not False, "Error running function 'test_checksum'"


# Generated at 2022-06-25 13:04:28.679335
# Unit test for function md5s
def test_md5s():
    int_0 = 733
    var_0 = md5s(int_0)
    assert var_0 == '600ec41a04e0e1b9fc214c8a45a9a6d9'



# Generated at 2022-06-25 13:04:31.097515
# Unit test for function md5
def test_md5():
    '''
    Test if md5 can hash strings
    '''
    assert(len(md5('this is a string')) != 0)


# Generated at 2022-06-25 13:04:35.746169
# Unit test for function md5
def test_md5():
    int_0 = 733
    hash_0 = md5s(int_0)
    assert hash_0 == "cec9a7caf96e0eaf7a04a2d4345b2b79"

if __name__ == "__main__":
    test_case_0()
    test_md5()

# Generated at 2022-06-25 13:04:37.765729
# Unit test for function md5
def test_md5():
    int_0 = 733
    var_0 = md5(int_0)
    print('%s' % var_0)


# Generated at 2022-06-25 13:04:45.969902
# Unit test for function md5s
def test_md5s():
    try:
        assert md5s('amazing') == 'b5f5e6a47b6f5b6d910f8a5d68a0b913'
        assert md5s('amazing') != 'amazing'
    except AssertionError:
        print("Test_md5s FAILED.  Expected %s, but got %s" % ('b5f5e6a47b6f5b6d910f8a5d68a0b913', 'amazing'))
    except Exception:
        print("Test_md5s FAILED.  Unknown exception.")
    else:
        print("Test_md5s PASSED.  All values are as expected.")


# Generated at 2022-06-25 13:04:54.146289
# Unit test for function md5s
def test_md5s():
    int_0 = 733
    var_0 = md5s(int_0)
    assert var_0 == 'ac9f7d8df1a59da7e75e0f604fa7f82d'
    int_1 = 131
    var_0 = md5s(int_1)
    assert var_0 == '8f38d93fe22723c6b1bd6d9e8f98ebb0'
    int_2 = -439
    var_0 = md5s(int_2)
    assert var_0 == '90cd42c0b6edb28d8f042f58f3a3a9a9'
    int_3 = -711
    var_0 = md5s(int_3)

# Generated at 2022-06-25 13:05:02.262736
# Unit test for function checksum
def test_checksum():
    print("Test 0 **************** ")
    test_case_0()

if __name__ == '__main__':
    # test_checksum()
    with open("src/20160429160226052457.jpg", "rb") as f:
        # image_data = f.read()
        print("file %s" % (checksum("src/20160429160226052457.jpg")))
        print("file %s" % (md5("src/20160429160226052457.jpg")))
        print("file %s" % (md5("src")))

# Generated at 2022-06-25 13:05:06.577033
# Unit test for function md5s
def test_md5s():
    inp = md5s('input')
    assert(inp == 'f6d389addc3880e0109c9d9e7f9e2baf')


if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-25 13:05:10.971438
# Unit test for function md5
def test_md5():
    assert md5('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    #assert md5('foo') == '96b09c03d68fb03c8c3ebc3ad8e6b15d'
    assert md5('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-25 13:05:14.157867
# Unit test for function checksum
def test_checksum():
    result = checksum('/etc/hosts')
    assert type(result) == str



# Generated at 2022-06-25 13:05:23.064624
# Unit test for function md5
def test_md5():
    print('\nTest md5')
    import inspect
    # get the script dir
    t = inspect.getfile(inspect.currentframe())
    script_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    file_path = os.path.join(script_dir,'../../')
    file_name = file_path + 'hacking/env-setup'
    print(md5(file_name))

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-25 13:05:28.398557
# Unit test for function md5
def test_md5():
    assert md5('thorium/shared.yml') == 'd2c8d97b58e51f03edf7a25abfe8a9f9'
    assert md5('thorium/meta/main.yml') == '6c3f62236d76bfe0c14e72d95c674141'
    assert md5('thorium/handlers/main.yml') == '19c6c0b7c4d8e029f2b08f4b4ae7b59f'
    assert md5('thorium/tasks/bootstraps.yml') == '9b9a40e09f71bdb5d338ec5cb2385be2'

# Generated at 2022-06-25 13:05:30.064653
# Unit test for function md5s
def test_md5s():
    int_0 = 733
    string_0 = md5s(int_0)
    assert string_0 == 'd564d0b3cde3fd3ec6e74bf222706c0e'


# Generated at 2022-06-25 13:05:32.792940
# Unit test for function md5s
def test_md5s():
    print("Test: MD5S")
    assert md5s('733') == 'bd08a746d5f80b5ce4e997b074a7a2a2', 'MD5S test 1 failed'
    assert md5s('733') == 'bd08a746d5f80b5ce4e997b074a7a2a2', 'MD5S test 2 failed'
    print("MD5S - TEST COMPLETED")


# Generated at 2022-06-25 13:05:35.625052
# Unit test for function md5s
def test_md5s():
    var_0 = '733'
    var_1 = md5s(var_0)
    assert var_1 == '14bde3a3b82e0b9a9b7f57983c330715'



# Generated at 2022-06-25 13:05:38.528019
# Unit test for function md5s
def test_md5s():
    print("HINT: If you get an error related to non-available MD5, you are probably running in FIPS mode")
    # Place your code here
    raise Exception("Cannot test function md5s because '_md5' is not in globals")


# Generated at 2022-06-25 13:05:41.215037
# Unit test for function checksum
def test_checksum():
  var_0 = md5s('/var/tmp/test1')
  assert var_0 == '4d16a214a12ab7e68dd1b3d7a09ca9ac'


# Generated at 2022-06-25 13:05:43.459312
# Unit test for function md5
def test_md5():
    assert 'ae4e25f0762d52c3eafe6c2d6f1d6367' == md5_s('password')


# Generated at 2022-06-25 13:05:49.283748
# Unit test for function checksum
def test_checksum():
    str_0 = 'w_S[uK@6:q3q0$'
    var_2 = checksum_s(str_0)
    # str_1 = files/test_file.txt
    var_4 = checksum(str_1)
    # str_2 = files/None.txt
    var_6 = checksum(str_2)
    # str_3 = dirs/test_dir
    var_8 = checksum(str_3)


# Generated at 2022-06-25 13:05:51.865989
# Unit test for function md5
def test_md5():
    assert secure_hash_s(733) == '1f2a57b7a3e3e26c357a10d9fc207f7d12f217a1'

## Unit test for function md5s

# Generated at 2022-06-25 13:06:04.155963
# Unit test for function md5
def test_md5():
    assert md5s(733) == '7f190413816e6e46d6ca02cb4a4e1c8b'

if __name__ == "__main__":
    import sys
    import pytest

    errno = pytest.main(args=[__file__, '-vvs', '-x', '--pdb', '--cov-report=term-missing', '--cov-report=html', '--cov-fail-under=75', '--cov=lib/ansible/utils/crypto'])
    sys.exit(errno)

# Generated at 2022-06-25 13:06:08.923151
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '4cf75e8b02a7f27ccde0dde83cfb8702be06d741'  # NOQA
    assert checksum('test/test_utils/test_checksum/testfile') == 'ea8a1a6a684199b4883e6b5f6bebfee6'  # NOQA



# Generated at 2022-06-25 13:06:12.855130
# Unit test for function md5
def test_md5():
    encrypted_val_0 = md5('/tmp/local_file')
    expected_val_0 = 'd41d8cd98f00b204e9800998ecf8427e'
    assert encrypted_val_0 == expected_val_0, str(encrypted_val_0) + ' does not equal expected value of ' + str(expected_val_0)


# Generated at 2022-06-25 13:06:18.960846
# Unit test for function md5s
def test_md5s():
    assert md5s(733) == 'f6fe4d6c0cfb4ab44502a336550f8ad3'

    # Since md5s returns a string, we can not compare
    # actual values at this time.
    # assert md5s('something') == '6f9b9af3cd6e8b8a73c2cdced37fe9e1'
    # assert md5s('something else') == '34ac86160c25b0e7def60c083d065ea8'


# Generated at 2022-06-25 13:06:21.668803
# Unit test for function checksum
def test_checksum():
    assert checksum('tests/files/checksum/test_file.txt') == '16a0e63eafe96a34d88cc84f3bd2c4fc'


# Generated at 2022-06-25 13:06:26.443454
# Unit test for function md5s
def test_md5s():
    int_0 = 1
    int_1 = 2
    str_0 = 'abc'
    str_1 = 'def'
    assert md5s(int_0) == md5s(int_1)
    assert md5s(str_0) == md5s(str_1)

# Generated at 2022-06-25 13:06:28.988285
# Unit test for function md5s
def test_md5s():
    # Test with no parameters
    var_0 = md5s()
    # Test with a single parameter
    int_0 = 733
    var_0 = md5s(int_0)


# Generated at 2022-06-25 13:06:32.072350
# Unit test for function md5s
def test_md5s():
    var_0 = md5s("abc")
    var_1 = md5s("abc")
    if var_0 != var_1:
        raise AssertionError("MD5 should hash constant strings to the same value")



# Generated at 2022-06-25 13:06:35.774903
# Unit test for function md5s
def test_md5s():
    data = 733
    expected = 'f2c7bf0edb9f14d7d50a71888a2030dc'
    result = md5s(data)
    assert result == expected, \
            'md5s({0!r}) returned {1!r}, expected {2!r}'.format(data, expected, result)


# Generated at 2022-06-25 13:06:42.791156
# Unit test for function md5s
def test_md5s():
    assert "d1bb3d3f053a0a5c5f8ca5c83a0348e0" == md5s(733)
    assert "b6d842219c2874aeb8eafbb4f4d4db80" == md5s(568)
    assert "d1bb3d3f053a0a5c5f8ca5c83a0348e0" == md5s(733)
    assert "b6d842219c2874aeb8eafbb4f4d4db80" == md5s(568)
    assert "8eb3cc756777d3ceb0f9b50e8c2a1873" == md5s(155)

# Generated at 2022-06-25 13:06:46.688998
# Unit test for function md5
def test_md5():
    print('Test 0')
    test_case_0()


# Generated at 2022-06-25 13:06:54.256846
# Unit test for function md5
def test_md5():
    '''
    unit test of md5
    '''
    assert '9e107d9d372bb6826bd81d3542a419d6' == md5('/etc/passwd')
    assert '0cc175b9c0f1b6a831c399e269772661' == md5('/etc/hosts')
    assert 'ee1c7c14e8dcb0a38b77c8c8a838755f' == md5('/etc/not_exist')



# Generated at 2022-06-25 13:06:56.053760
# Unit test for function md5s
def test_md5s():
    assert len(md5s(733)) == 32, "unit test: md5s failed"


# Generated at 2022-06-25 13:06:59.085589
# Unit test for function md5s
def test_md5s():
    print('Test md5s')
    test_case_0()
    test_case_1()
    test_case_2()

# unit test for function md5

# Generated at 2022-06-25 13:07:01.490267
# Unit test for function md5s
def test_md5s():
    hash = md5s('hello')
    assert hash == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-25 13:07:04.134730
# Unit test for function md5s
def test_md5s():
    expected = "37c8b28d45063c67e0b7f1b62cfb4eaf"
    actual = md5s(str(733))
    assert actual == expected


# Generated at 2022-06-25 13:07:07.235803
# Unit test for function checksum
def test_checksum():
    assert checksum('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert checksum_s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-25 13:07:09.743489
# Unit test for function md5
def test_md5():
    test_file = 'test_files/test.file'
    digest = md5(test_file)
    assert digest == 'e70cfb20d44dd64a4b9a9e88ab04bf40'


# Generated at 2022-06-25 13:07:11.587050
# Unit test for function checksum
def test_checksum():
    assert checksum("test_file") == "b1a7872a10d139f570d9d9ce0c438bb252e14eb2"


# Generated at 2022-06-25 13:07:13.387550
# Unit test for function md5s
def test_md5s():
    d = md5s('hello world')
    assert d == '5eb63bbbe01eeed093cb22bb8f5acdc3', d


# Generated at 2022-06-25 13:07:18.715127
# Unit test for function md5s
def test_md5s():
    assert md5s(733) == 'e0fd2726f7c464e1b85962baea71eb92'
    assert md5s(24) == 'f78a2ad26e743f2c4d4e42d6e53e6b44'



# Generated at 2022-06-25 13:07:21.104611
# Unit test for function checksum
def test_checksum():
    assert checksum('/home/ansible/ansible/test/utils/test-module-2') == '78f49fcd69abf648e962ebcce0c7b1ed4e041d8d'


# Generated at 2022-06-25 13:07:22.168753
# Unit test for function md5
def test_md5():
    print("Testing function md5...")
    test_case_0()
    print("Passed")


# Generated at 2022-06-25 13:07:24.706876
# Unit test for function checksum
def test_checksum():
    assert checksum('ansible/test/utils/test_module_utils_basic.py') == 'd8e097ff6a08f6a73d6cb11cbda4f4c9ebcf73e4'
    assert checksum('/tmp/does_not_exist') is None



# Generated at 2022-06-25 13:07:25.974530
# Unit test for function md5
def test_md5():
    assert secure_hash('test_md5_hashlib.py', _md5) == md5('test_md5_hashlib.py')

# Generated at 2022-06-25 13:07:27.958081
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/hosts') == '86d89ff80f8a75b0e90c61154d2a9e83'


# Generated at 2022-06-25 13:07:29.906530
# Unit test for function md5s
def test_md5s():
    var_1 = 'Hello'
    var_2 = md5s(var_1)
    print("MD5S HASH: " + var_2)


# Generated at 2022-06-25 13:07:31.561690
# Unit test for function md5s
def test_md5s():
    assert ("b1e107d36305b2cbc04a9db9da90c714" in md5s(733))


# Generated at 2022-06-25 13:07:33.871479
# Unit test for function md5s
def test_md5s():
    int_0 = 733
    var_0 = md5s(int_0)



# Generated at 2022-06-25 13:07:35.473256
# Unit test for function md5
def test_md5():
    assert md5('/tmp/filename') == secure_hash('/tmp/filename', _md5)


# Generated at 2022-06-25 13:07:47.036347
# Unit test for function checksum

# Generated at 2022-06-25 13:07:48.691366
# Unit test for function md5
def test_md5():
    assert(md5("/home/user/test_file") == "5eb63bbbe01eeed093cb22bb8f5acdc3")
    assert(md5("/home/user/test_file__") == None)



# Generated at 2022-06-25 13:07:54.868450
# Unit test for function md5s

# Generated at 2022-06-25 13:07:56.543121
# Unit test for function md5s
def test_md5s():
    correct_result = 'ed7a9f64aa1f7c2d61a0f749e1f15099'
    test_case_0()
    

# Generated at 2022-06-25 13:07:57.869324
# Unit test for function md5
def test_md5():
    assert(checksum_s(733, _md5) == md5s(733))


# Generated at 2022-06-25 13:08:00.938417
# Unit test for function md5s
def test_md5s():
    # Test 1
    int_1 = 733
    var_1 = md5s(int_1)
    assert var_1 == "d4fc7f974f8bfd7dd0f70723dce1cc63"


# Generated at 2022-06-25 13:08:03.618764
# Unit test for function md5
def test_md5():
    assert(md5(__file__) == "fb7c8b89d528bea32de3e3ebb7f835a2")
    assert(os.path.isdir(__file__) is False)

# Generated at 2022-06-25 13:08:11.922309
# Unit test for function checksum
def test_checksum():
    print('Test checksum()')
    assert checksum('test/test_utils.py') == '15a8d16691217e5f5c5e7d5f5b5d5c5b5d5c5d5b5c5d5c5d5c5d5c5d5c5d5c5b5d5c5b5d5c5c5d5b5d5c5c5b5d5b5d5c5c5d5d5c5c5b5d5c5c5d5c5c5b5d5c5b5d5c5c5d5b5d5c'


# Generated at 2022-06-25 13:08:14.005989
# Unit test for function md5
def test_md5():
    filename = "test.txt"
    assert md5(filename) == "3f3d5bdde8ee727ebb05a7f2d2824796"



# Generated at 2022-06-25 13:08:17.611709
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/passwd') == '1fc7401c56f0e75c8e0b8399d7a575e5e5c7e9df'
    assert checksum('/etc/hosts') == '99dcccef7fefdaeb417ccb152aac9f67'


# Generated at 2022-06-25 13:08:23.029612
# Unit test for function checksum
def test_checksum():
    filename = "test/test_secure_hash.py"
    hash_func = sha1
    assert(checksum(filename,hash_func) == secure_hash(filename,hash_func))


# Generated at 2022-06-25 13:08:26.263413
# Unit test for function md5
def test_md5():
    int_0 = 733
    var_0 = md5s(int_0)
    assert var_0 == 'b8416ceaf95554bc4bc3f3d80bd014e4'


# Generated at 2022-06-25 13:08:28.547308
# Unit test for function checksum
def test_checksum():
    assert '9e107d9d372bb6826bd81d3542a419d6' == checksum_s("The quick brown fox jumps over the lazy dog")


# Generated at 2022-06-25 13:08:36.615566
# Unit test for function md5
def test_md5():
    # Input parameters
    filename = '/home/guestd/Downloads/ansible-2.9.2/lib/ansible/module_utils/urls.py'

    # Output parameters
    expected_md5 = 'fa53c8fa4863d1a1e59d33b9e9b8a8f2'

    # Call function to test
    actual_md5 = md5(filename)

    print('Actual output: ', actual_md5)
    print('Expected output: ', expected_md5)

    assert actual_md5 == expected_md5


if __name__ == "__main__":
    test_md5()

# Generated at 2022-06-25 13:08:39.147122
# Unit test for function md5
def test_md5():
    assert(md5("/etc/passwd") == "9b4e1c8a1b7e258e2d7db1023c28e186")


# Generated at 2022-06-25 13:08:41.493120
# Unit test for function checksum
def test_checksum():
    pass



# Generated at 2022-06-25 13:08:43.409985
# Unit test for function md5s
def test_md5s():
    int_0 = 733
    assert md5s(int_0) == "dc4fc4bf5056d4f4a4d7963b929a2a8a"


# Generated at 2022-06-25 13:08:48.087077
# Unit test for function md5s
def test_md5s():
    var_0 = md5s('test')
    print(str(var_0) + " == 9128f66cce5f2faaa8c9f23d87b999a0")
    assert var_0 == "9128f66cce5f2faaa8c9f23d87b999a0"
test_md5s()


# Generated at 2022-06-25 13:08:52.454994
# Unit test for function md5s
def test_md5s():
    int_0 = "test"
    var_0 = md5s(int_0)
    assert (var_0 == '098f6bcd4621d373cade4e832627b4f6')

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-25 13:08:57.128003
# Unit test for function md5
def test_md5():
    assert md5s('testing') == 'ae2b1fca515949e5d54fb22b8ed95575'
    assert md5('/etc/hosts') == '4b7a4b4b0138f3e3ab43d72c9018aa9a'
    #print(md5s(None))



# Generated at 2022-06-25 13:09:06.343144
# Unit test for function md5s
def test_md5s():
    int_0 = 733
    str_0 = md5s(int_0)
    assert str_0 == 'd0e42ceef97c63a1b2f7e157fcf5bd18'


# Generated at 2022-06-25 13:09:08.115097
# Unit test for function md5s
def test_md5s():
    with pytest.raises(ValueError):
        md5s(733)


# Generated at 2022-06-25 13:09:10.780536
# Unit test for function md5s
def test_md5s():
    var_0 = 733
    int_0 = md5s(var_0)
    assert int_0 == 'b0c78b858978ebe6c21a9a666b7d8f47'


# Generated at 2022-06-25 13:09:13.295684
# Unit test for function md5s
def test_md5s():
    assert(md5s("733") == "2e1d619acf6b7af634e41c99af88e81b")


# Generated at 2022-06-25 13:09:17.027183
# Unit test for function md5s
def test_md5s():
    import random

    int_0 = random.randint(0, 100000)
    assert sha1(int_0).hexdigest() == md5s(int_0)

if __name__ == '__main__':
    for i in xrange(10):
        test_case_0()

# Generated at 2022-06-25 13:09:20.768991
# Unit test for function checksum
def test_checksum():
    int_0 = 733
    var_0 = checksum_s(int_0)
    assert var_0 == '146a7731e13d8f99c0d6b2295fde0beeb0877d30'


# Generated at 2022-06-25 13:09:24.515925
# Unit test for function md5s
def test_md5s():
    hash_0 = md5s("hello")
    hash_1 = md5("hello")
    assert hash_0 == "5d41402abc4b2a76b9719d911017c592"
    assert hash_1 == hash_0


# Generated at 2022-06-25 13:09:25.939088
# Unit test for function checksum
def test_checksum():
    filename = 'test_filename'
    value = checksum(filename)


# Generated at 2022-06-25 13:09:27.911396
# Unit test for function md5
def test_md5():
    print(secure_hash_s('input.txt'))
    # print(md5('input.txt'))


# Generated at 2022-06-25 13:09:29.441147
# Unit test for function md5
def test_md5():
    assert md5("arg") == "b1946ac92492d2347c6235b4d2611184"

# Generated at 2022-06-25 13:09:37.558186
# Unit test for function checksum
def test_checksum():
    # Test with a large input filename
    # (e.g., when a long path name is given to Ansible
    # by other applications)
    filename = "/" + ("a" * 32) + "/" + ("b" * 32)
    assert sha1(b"test").hexdigest() == checksum(filename="test")
    assert checksum(filename=filename) is None
    filename = "test"
    assert sha1(b"test").hexdigest() == checksum(filename=filename)


# Generated at 2022-06-25 13:09:46.694254
# Unit test for function md5
def test_md5():
    # Unit test for function md5
    int_0 = 733
    var_0 = md5s(int_0)
    assert(var_0 == "53d15f90324e5a5bf5b5badb22e634a5")
    int_0 = 743
    var_0 = md5s(int_0)
    assert(var_0 == "5a0a445b02be20fda6c9076e3b4db4b2")
    int_0 = 743
    var_0 = md5s(int_0)
    assert(var_0 == "5a0a445b02be20fda6c9076e3b4db4b2")


if __name__ == "__main__":
    test_md5()

# Generated at 2022-06-25 13:09:48.638195
# Unit test for function md5
def test_md5():
    assert(secure_hash('demo.txt', _md5) == '7f81883b63bce3066ef481877522e7e8')


# Generated at 2022-06-25 13:09:50.815407
# Unit test for function md5
def test_md5():
    assert md5("/home/ansible/playbooks/test.txt") == "143619f6a9f6a1c6bedaf30b7d3f04e3"


# Generated at 2022-06-25 13:09:52.048991
# Unit test for function md5
def test_md5():
    assert md5("/etc/passwd") == "d41d8cd98f00b204e9800998ecf8427e"


# Generated at 2022-06-25 13:09:55.235308
# Unit test for function md5s
def test_md5s():
    # Case 1
    int_0 = 733
    var_0 = md5s(int_0)
    
    # Case 2
    int_0 = 0
    var_0 = md5s(int_0)


# Generated at 2022-06-25 13:09:59.541944
# Unit test for function checksum
def test_checksum():
    assert checksum('test_cases/unit-tests/checksum.py') == 'd66f972723b9773f2606d5a6cc1e3c1a'
    assert checksum_s(733) == '5e9f0c6e5ccb1f1c3ea3b2fdf6fc0c89'


# Generated at 2022-06-25 13:10:07.012924
# Unit test for function md5
def test_md5():

    # param 0 is given.
    filename = "C:/Users/jeffc/Workspaces/aloe/tests/resources/ubuntu-14.04-amd64.iso"
    value = md5(filename)
    assert value == '75c8db9ce595b6da02abba44968ddf8e'

    # param 0 is given.
    filename = "C:/Users/jeffc/Workspaces/aloe/tests/resources/ubuntu-14.04-amd64.iso"
    value = md5(filename)
    assert value == '75c8db9ce595b6da02abba44968ddf8e'


# Generated at 2022-06-25 13:10:11.483489
# Unit test for function checksum
def test_checksum():
    num = 259285
    exp = 'ec3d3a3bcef73ea11aa7b9c972e2d7dc50c1c71d'
    assert checksum_s(num) == exp
    assert checksum_s(str(num)) == exp
    assert isinstance(checksum_s(num), str)


# Generated at 2022-06-25 13:10:17.066728
# Unit test for function md5
def test_md5():
    assert md5s('0') == 'cfcd208495d565ef66e7dff9f98764da'
    assert md5s('1') == 'c4ca4238a0b923820dcc509a6f75849b'
    assert md5s('2') == 'c81e728d9d4c2f636f067f89cc14862c'
    assert md5s('3') == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'
    assert md5s('4') == 'a87ff679a2f3e71d9181a67b7542122c'
    assert md5s('5') == 'e4da3b7fbbce2345d7772b0674a318d5'
    assert md5

# Generated at 2022-06-25 13:10:29.197719
# Unit test for function md5s
def test_md5s():
    var_1 = md5s("abc")
    assert var_1 == "900150983cd24fb0d6963f7d28e17f72"
    var_2 = md5s("abcd")
    assert var_2 == "e2fc714c4727ee9395f324cd2e7f331f"
    var_3 = md5s("abcde")
    assert var_3 == "ab56b4d92b40713acc5af89985d4b786"
    var_4 = md5s("abcdef")
    assert var_4 == "e80b5017098950fc58aad83c8c14978e"

# Generated at 2022-06-25 13:10:37.545548
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    tests = ["", "a", "abc", "message digest", "abcdefghijklmnopqrstuvwxyz",
             "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
             "12345678901234567890123456789012345678901234567890123456789012345678901234567890",
             "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz"]