

# Generated at 2022-06-25 13:00:45.883115
# Unit test for function md5s
def test_md5s():
    set_0 = set()
    var_0 = md5s(set_0)


# Generated at 2022-06-25 13:00:48.010757
# Unit test for function md5
def test_md5():
    try:
        md5()
    except Exception as e:
        print('Exception raised: ')
        print(e)
        assert False
    else:
        pass


# Generated at 2022-06-25 13:00:57.057768
# Unit test for function md5s
def test_md5s():

    # Applying default arguments 
    md5s_0 = md5s('test')
    assert md5s_0 == '098f6bcd4621d373cade4e832627b4f6'

    # Applying default arguments 
    md5s_1 = md5s('test')
    assert md5s_1 == '098f6bcd4621d373cade4e832627b4f6'

    # Applying default arguments 
    md5s_2 = md5s('test')
    assert md5s_2 == '098f6bcd4621d373cade4e832627b4f6'

    # Applying default arguments 
    md5s_3 = md5s('test')

# Generated at 2022-06-25 13:01:02.031864
# Unit test for function checksum
def test_checksum():
    answer = secure_hash("foo")
    assert answer == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33", "Expected 0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33, got " + answer

# Generated at 2022-06-25 13:01:05.056759
# Unit test for function checksum
def test_checksum():
    assert callable(checksum)
    assert checksum('/etc/passwd') == '90b5d6dc8f6ef5358fb58b6418c5e6d1'
    assert checksum('/etc') is None


# Generated at 2022-06-25 13:01:07.212569
# Unit test for function checksum
def test_checksum():
    assert secure_hash('test_checksum') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'


# Generated at 2022-06-25 13:01:09.455069
# Unit test for function checksum
def test_checksum():
    assert checksum('/tmp/ansible_test_file/test_file_0') == 'e3a08d06f7746920c26e9a8d4a57ecb4'


# Generated at 2022-06-25 13:01:11.496552
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-25 13:01:12.649039
# Unit test for function md5s
def test_md5s():
    set_0 = set()
    var_0 = md5s(set_0)

# Generated at 2022-06-25 13:01:13.180301
# Unit test for function md5
def test_md5():
    pass

# Generated at 2022-06-25 13:01:18.451946
# Unit test for function md5
def test_md5():
    assert md5("test") == "098f6bcd4621d373cade4e832627b4f6"


# Generated at 2022-06-25 13:01:20.439371
# Unit test for function md5s
def test_md5s():
    print('Testing md5s')
    test_case_0()
    print('Test case 0: OK')


# Generated at 2022-06-25 13:01:23.869256
# Unit test for function md5s
def test_md5s():
    assert md5s(512.0) == '197c9f2d24b03fa8c8e07aa4465c0b1e'
    assert md5s('42.0') == '24dceecf829c77a36dc1f80027d3a3c3'


# Generated at 2022-06-25 13:01:32.396310
# Unit test for function md5s
def test_md5s():
    assert md5s(512.0) == 'b05e872a55d1abb6fae2d77f65c868ae'
    assert md5s('123') == '202cb962ac59075b964b07152d234b70'
    assert md5s('0') == 'cfcd208495d565ef66e7dff9f98764da'
    assert md5s(0) == 'cfcd208495d565ef66e7dff9f98764da'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(None) == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-25 13:01:36.001758
# Unit test for function md5s
def test_md5s():
    assert callable(md5s) or md5s is None, "md5s is not callable"


# Generated at 2022-06-25 13:01:38.304212
# Unit test for function md5
def test_md5():
    assert md5('testfile') == 'c3fcd3d76192e4007dfb496cca67e13b'


# Generated at 2022-06-25 13:01:47.528531
# Unit test for function md5
def test_md5():
    test_values = [
        {
            'input_value': None,
            'output_value': None
        },
        {
            'input_value': '',
            'output_value': 'd41d8cd98f00b204e9800998ecf8427e'
        },
        {
            'input_value': 'Hello World',
            'output_value': '65a8e27d8879283831b664bd8b7f0ad4'
        }
    ]

    for value in test_values:
        assert value['output_value'] == md5s(value['input_value'])


if __name__ == "__main__":
    test_case_0()
    # test_md5()

# Generated at 2022-06-25 13:01:53.978930
# Unit test for function checksum
def test_checksum():
    print("Testing checksum")
    print("Testing assert_raises::input_file_does_not_exists")
    input_file = './input.txt'
    try:
        checksum(input_file)
    except SystemExit as e:
        assert("error while accessing the file ./input.txt, error was: [Errno 2] No such file or directory:" in str(e.code))
    print("Testing assert_raises::input_file_is_directory")
    try:
        checksum('./')
    except SystemExit as e:
        assert("error while accessing the file ./, error was: [Errno 21] Is a directory:" in str(e.code))
    print("Testing checksum::input_valid")
    input_file = './tests/files/test_file.txt'
    expected

# Generated at 2022-06-25 13:01:56.675672
# Unit test for function md5s
def test_md5s():
    assert md5s(512.0) == '5795c9f9aa06c3ceac3d1e27c6176aa5'



# Generated at 2022-06-25 13:02:00.132039
# Unit test for function md5
def test_md5():
    sentence_1 = 'The quick brown fox jumps over the lazy dog'
    sentence_2 = 'The quick brown fox jumps over the lazy dog.'

    assert md5(sentence_1) == md5(sentence_2)



# Generated at 2022-06-25 13:02:12.677018
# Unit test for function md5
def test_md5():

    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test.txt') == 'f8d5a14d7a9fcd9c6b8dde21a1e69aef'
    assert md5s('/tmp/test.txt') == 'bb35b72ccefbf71abe051a7d95b1302b'
    assert md5s('/tmp/tes') == '5a722308bcd2e440c0d3e0f8b6eba5d5'
    assert md5s('this is a test of the emergency broadcast system') == 'df19f4e8265cfebb2c4d4ceb55dd2fe8'

    assert md5s('')

# Generated at 2022-06-25 13:02:14.681020
# Unit test for function md5
def test_md5():
    assert(md5("foobar.txt") == "3858f62230ac3c915f300c664312c63f")


# Generated at 2022-06-25 13:02:18.930589
# Unit test for function md5s
def test_md5s():
    ret = md5s("test")
    assert ret == "098f6bcd4621d373cade4e832627b4f6"
    try:
        md5s("test")
        raise AssertionError("Expected md5s function to throw an error")
    except ValueError:
        pass


# Generated at 2022-06-25 13:02:29.893964
# Unit test for function checksum
def test_checksum():
    # Tuple of strings to pass as argument
    if os.path.exists('/tmp/foo.tmp'):
        os.remove('/tmp/foo.tmp')
    fd = open('/tmp/foo.tmp', 'w')
    fd.write('hello world!\n')
    fd.close()

    # Tuple of strings to pass as argument
    if os.path.exists('/tmp/foo2.tmp'):
        os.remove('/tmp/foo2.tmp')
    fd = open('/tmp/foo2.tmp', 'w')
    fd.write('hello world!\n')
    fd.close()

    # Test with valid tuple of strings as argument
    assert checksum('/tmp/foo.tmp') == checksum('/tmp/foo2.tmp')

    #

# Generated at 2022-06-25 13:02:33.232173
# Unit test for function md5
def test_md5():
    test_hash = "82e53abbf98a6dbd1b8e679937f1e9ab"
    assert md5("tests/unit/hashlib/test_file.txt") == test_hash



# Generated at 2022-06-25 13:02:40.271773
# Unit test for function checksum
def test_checksum():
    assert checksum('/tmp/test.txt') == 'd41d8cd98f00b204e9800998ecf8427e', \
        '''./hacking/test-module:1 (checksum)'''
    assert checksum('/') == 'd41d8cd98f00b204e9800998ecf8427e', \
        '''./hacking/test-module:2 (checksum)'''
    assert checksum_s('123') == '202cb962ac59075b964b07152d234b70', \
        '''./hacking/test-module:3 (checksum)'''


# Generated at 2022-06-25 13:02:49.273759
# Unit test for function md5
def test_md5():
    assert md5('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('\0') == '93b885adfe0da089cdf634904fd59f71'
    assert md5('The quick brown fox jumps over the lazy dog') == '9e107d9d372bb6826bd81d3542a419d6'
    assert md5('The quick brown fox jumps over the lazy dog.') == 'e4d909c290d0fb1ca068ffaddf22cbd0'
    assert md5('The quick brown fox jumps over the lazy dog ') == '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12'


# Generated at 2022-06-25 13:02:52.140960
# Unit test for function md5s
def test_md5s():
    var_1 = md5s(10)
    assert var_1 == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'


# Generated at 2022-06-25 13:03:01.011934
# Unit test for function checksum
def test_checksum():
    assert ('a94a8fe5ccb19ba61c4c0873d391e987982fbbd3' == checksum_s('foo'))
    assert ('a94a8fe5ccb19ba61c4c0873d391e987982fbbd3' == checksum_s('foo'))
    assert ('cf23df2207d99a74fbe169e3eba035e633b65d94' == checksum_s('bar'))
    assert ('8c4f08595e1bdc58f5b5d5b8d6c5f6f5' == checksum_s('baz'))
    assert ('be1bf07f4bd8a738b4a58b4f01b894d8' == checksum_s('qux'))



# Generated at 2022-06-25 13:03:01.967029
# Unit test for function md5
def test_md5():
	test_case_0()


# Generated at 2022-06-25 13:03:08.049460
# Unit test for function md5s
def test_md5s():
    assert md5s(512.0) == '34b9d0f3aff3b39e8e57456c9915cce1'


# Generated at 2022-06-25 13:03:17.217533
# Unit test for function md5s
def test_md5s():
    float_0 = float(0)
    float_1 = float(0)
    float_2 = float(0)
    float_3 = float(0)
    float_4 = float(0)
    float_5 = float(0)
    float_6 = float(0)
    float_7 = float(0)
    float_8 = float(0)
    float_9 = float(0)
    float_10 = float(0)
    float_11 = float(0)
    float_12 = float(0)
    float_13 = float(0)
    float_14 = float(0)
    float_15 = float(0)
    float_16 = float(0)
    float_17 = float(0)
    float_18 = float(0)
    float_19 = float(0)

# Generated at 2022-06-25 13:03:18.190949
# Unit test for function md5
def test_md5():
    assert 'f85e45a7a7b25d0bdfaade03c10f64d9' == md5('/tmp/foo')


# Generated at 2022-06-25 13:03:20.650853
# Unit test for function md5
def test_md5():
    assert md5s('test_string') == '3787f09d37c7fa98ea134072c7fa7d61'
    assert md5('unit_test/md5_data') == 'd94f3f016ae679c3008de268209132f2'



# Generated at 2022-06-25 13:03:22.388088
# Unit test for function md5s
def test_md5s():
    assert md5s('test_string'), 'md5s did not work as expected.'


# Generated at 2022-06-25 13:03:28.140998
# Unit test for function md5s
def test_md5s():
    # if test_case_0() != 'f2d0ccb5c5f5fe716e45a2f816f5af43':
    #     raise AssertionError("MD5 '%s' != '%s'" % (test_case_0(), 'f2d0ccb5c5f5fe716e45a2f816f5af43'))
    return


if __name__ == "__main__":
    test_md5s()

# Generated at 2022-06-25 13:03:30.993112
# Unit test for function md5
def test_md5():
    filename = "test"
    var_0 = md5(filename)
    assert(var_0 == 'd41d8cd98f00b204e9800998ecf8427e')


# Generated at 2022-06-25 13:03:36.677549
# Unit test for function md5s
def test_md5s():
    # Test with float argument
    float_0 = 512.0
    assert md5s(float_0) == '0f1c67b4d4e4cc4f9218791056f2b1ea'
    # Test with str argument
    str_0 = 'file'
    assert md5s(str_0) == '78e731027d8fd50ed642340b7c9a63b3'


# Generated at 2022-06-25 13:03:39.104567
# Unit test for function md5s
def test_md5s():
    float_0 = 512.0
    var_0 = md5s(float_0)
    var_1 = checksum_s(float_0)

    assert var_0 == var_1


# Generated at 2022-06-25 13:03:42.703320
# Unit test for function md5
def test_md5():
    assert(md5s("1.0") == "c4ca4238a0b923820dcc509a6f75849b")
    assert(md5("test/support/files/md5sum/sample1.txt") == "7b1816c9a9d81bcfcad4ba7b4e4ab1d7")


# Generated at 2022-06-25 13:03:51.310421
# Unit test for function md5
def test_md5():
    data = "this is a test"
    test_result = md5s(data)

    print("md5s(" + data + ") = [" + test_result + "]")
    assert test_result == "8b92ba63b2ee6e97c6e1f8d964f30c6e", "Return value: " + test_result


# Generated at 2022-06-25 13:03:52.644581
# Unit test for function md5
def test_md5():
    print ('Testing function md5')
    test_case_0()


# Generated at 2022-06-25 13:03:58.944974
# Unit test for function md5
def test_md5():
    # Return value is correct
    assert(md5("/etc/shadow") == '0fe271344f8a2c57ece91f1d1f973a8b')

    # Return value is correct
    assert(md5("/etc/shadow") == '0fe271344f8a2c57ece91f1d1f973a8b')

    # Return value is correct
    assert(md5("/etc/shadow") == '0fe271344f8a2c57ece91f1d1f973a8b')



# Generated at 2022-06-25 13:04:01.459845
# Unit test for function md5
def test_md5():
    ''' md5 unit test for function md5
        This test is used for checking the function md5
        in module "hashlib".
    '''
    assert test_case_0()


# Generated at 2022-06-25 13:04:06.652314
# Unit test for function md5s
def test_md5s():
    # Check if md5s function returns the right answer
    # Input:
    #   data: 512.0
    # Expected Output:
    #   str: '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    # TODO: Create function tests for md5s
    assert False


# Generated at 2022-06-25 13:04:07.299540
# Unit test for function md5
def test_md5():
    pass

# Generated at 2022-06-25 13:04:08.145468
# Unit test for function md5s
def test_md5s():
    test_case_0()


# Generated at 2022-06-25 13:04:17.641399
# Unit test for function md5s
def test_md5s():
    float_0 = 512.0
    var_0 = md5s(float_0)
    var_1 = b'912ec803b2ce49e4a541068d495ab570'
    assert var_0 == var_1
    float_1 = 64.0
    var_2 = md5s(float_1)
    var_3 = b'ffd8b6c97112bb67acae2e7cc8cdae6e'
    assert var_2 == var_3
    float_2 = 192.0
    var_4 = md5s(float_2)
    var_5 = b'b8fbb54b6f67cd6f2ac374b1d31e1c6b'
    assert var_4 == var_5
    float_3 = 768.0


# Generated at 2022-06-25 13:04:19.871954
# Unit test for function md5
def test_md5():
    assert md5('input_data/var_0.txt') == 'ac6acfad6ef13b6fddb6c685067ed487'


# Generated at 2022-06-25 13:04:23.618636
# Unit test for function checksum
def test_checksum():
    assert checksum("tests/hashtest.txt") == "8f3c1266b3a3e9c9f63e8b630f7d5a5a"
    assert checksum("tests/hashtest.txt", hash_func=_md5) == "c76f8769db148f2ab03c85b2c85ff50d"


# Generated at 2022-06-25 13:04:28.284168
# Unit test for function md5
def test_md5():
    print(md5('/etc/hosts'))


# Generated at 2022-06-25 13:04:37.990090
# Unit test for function md5
def test_md5():
    # Testing string
    assert md5(__file__) == '3e50a73a9a9c8f1e6a8751b0732f6acd', 'Test failed'
    # Testing empty string
    assert md5('') == 'd41d8cd98f00b204e9800998ecf8427e', 'Test failed'
    # Testing byte input
    assert md5(bytearray([104, 101, 108, 108, 111])) == '5d41402abc4b2a76b9719d911017c592', 'Test failed'
    # Testing zero input

# Generated at 2022-06-25 13:04:40.576271
# Unit test for function md5s
def test_md5s():
    s = md5s("test")
    assert s == "098f6bcd4621d373cade4e832627b4f6"


# Generated at 2022-06-25 13:04:41.492700
# Unit test for function md5s
def test_md5s():
    global float_0


# Generated at 2022-06-25 13:04:43.630161
# Unit test for function md5
def test_md5():
    var_1 = 123
    var_2 = md5(var_1)

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 13:04:45.852937
# Unit test for function md5
def test_md5():
    print("md5 on Float")
    test_case_0()

# Generated at 2022-06-25 13:04:47.281459
# Unit test for function checksum
def test_checksum():

    # Test case
    try:
        test_case_0()
    except ValueError:
        pass


# Generated at 2022-06-25 13:04:50.594209
# Unit test for function checksum
def test_checksum():
    assert checksum('./tests/test_utils.py') == '42a9e3ef76f8b4e4d4e084f4a0a847c3'
    assert checksum('./tests/test_utils.py') == checksum('./tests/test_utils.py')
    assert checksum('nofile.txt') == None


# Generated at 2022-06-25 13:04:53.173718
# Unit test for function md5
def test_md5():
    val = md5('testfile.txt')
    assert val == '54ec5b3a5a8a5bbb3c4f74d69b960343'


# Generated at 2022-06-25 13:05:04.423716
# Unit test for function checksum
def test_checksum():
    # test empty data
    assert checksum_s(data='') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s(data=b'') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum(filename='tests/test_secure_hash/empty_file') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    # test some data and file with one byte
    assert checksum_s(data='1') == '356a192b7913b04c54574d18c28d46e6395428ab'

# Generated at 2022-06-25 13:05:09.113404
# Unit test for function checksum
def test_checksum():
    path = 'path'
    assert(checksum(path) == secure_hash(path))


# Generated at 2022-06-25 13:05:11.453389
# Unit test for function checksum
def test_checksum():
    assert checksum('filename', 'algorithm') == None


# Generated at 2022-06-25 13:05:15.000170
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == '6f8db599de986fab7a21625b7916589c'
    assert md5('./my/file.txt') == None


# Generated at 2022-06-25 13:05:21.076696
# Unit test for function checksum
def test_checksum():
    with open('/tmp/test_checksum','w') as f:
        f.write('This is a test file')
    assert checksum('/tmp/test_checksum') == '5e5d5d98e5c5f5e5c5b5d5d98e5f5e5c5b5f5e5d5b5b5d5b5e5d5b5b5d5c5b5b5d5b'
    os.remove('/tmp/test_checksum')



# Generated at 2022-06-25 13:05:22.695087
# Unit test for function md5s
def test_md5s():
    assert md5s('test_data') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-25 13:05:23.374365
# Unit test for function md5s
def test_md5s():
    var_1 = md5s()



# Generated at 2022-06-25 13:05:27.364536
# Unit test for function md5
def test_md5():

    # Test if the hash of file is '9c7ffb3f3d3c81336cc7b96a39cf3a3f'
    assert md5('../test_files/test_shell_module.txt') == '9c7ffb3f3d3c81336cc7b96a39cf3a3f'


# Generated at 2022-06-25 13:05:31.339383
# Unit test for function checksum
def test_checksum():
    string_0 = "7b8a6a1a7d6486d0baf7f1bd6f7db7b0"
    string_1 = "0674c49ad7b1d16e1c6b3216ada4c4d4"

    result = checksum(string_0)
    assert result == string_1


# Generated at 2022-06-25 13:05:34.682128
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    else:
        raises(ValueError, md5s, 'hello')


# Generated at 2022-06-25 13:05:41.716698
# Unit test for function checksum
def test_checksum():
    hasher = lambda x: 'checksum' + str(x)
    filename = 'my/filename'
    assert 'checksum' + filename == checksum(filename, hasher)
    assert None == checksum(filename, hasher, follow=True)
    assert None == checksum(filename, hasher, follow=False)

    follow = True
    assert 'checksum' + filename == checksum(filename, hasher, follow)
    assert 'checksum' + filename == checksum(filename, hasher, follow=follow)
    follow = False
    assert None == checksum(filename, hasher, follow)
    assert None == checksum(filename, hasher, follow=follow)

# Generated at 2022-06-25 13:05:51.006345
# Unit test for function md5
def test_md5():
    assert(md5("test_data/test_file_0") == md5("test_data/test_file_1"))
    assert(md5("test_data/test_file_0") == "b1e82a8cc8f2ef062cfd34a9a9408b11")
    assert(md5("test_data/test_file_2") == "ae24d631c9ae9cc8f84c2fceb7d57e12")



# Generated at 2022-06-25 13:05:54.646297
# Unit test for function checksum
def test_checksum():
    test_path = 'test_path'
    expected_results = 'd41d8cd98f00b204e9800998ecf8427e'
    results = checksum(test_path)

    assert(results == expected_results)
    assert(type(results) is str)


# Generated at 2022-06-25 13:05:57.455136
# Unit test for function md5s
def test_md5s():
    float_0 = 512.0
    var_0 = md5s(float_0)
    # Assertions
    assert var_0 == '000ffff0e3b0f8d3ce0841e628e806c1'


# Generated at 2022-06-25 13:06:02.014925
# Unit test for function md5s
def test_md5s():
    assert md5s(512.0) == 34359738368.0


# Generated at 2022-06-25 13:06:08.704846
# Unit test for function md5s
def test_md5s():
    print("Md5s test")
    assert md5s("ansible") == "d0be2dc421be4fcd0172e5afceea3970e2f3d940"
    assert md5s("ansible2") == "05af55b7e54ef8d3ac3ec3b50e00e724ad418a97"
    assert md5s("ansible3") == "9d09e9b320b3394da1c7e1f2c61d3dd0e3b26f63"


# Generated at 2022-06-25 13:06:10.882639
# Unit test for function md5s
def test_md5s():
    func = md5s
    assert func(3) == '37f10fb91b07a525a8d12a0e899c02f1'


# Generated at 2022-06-25 13:06:11.951163
# Unit test for function md5s
def test_md5s():
    assert md5s(1)

test_md5s()


# Generated at 2022-06-25 13:06:15.200206
# Unit test for function md5
def test_md5():
   float_0 = 512.0
   var_0 = md5(float_0)

if __name__ == "__main__":
    test_case_0()
    test_md5()

# Generated at 2022-06-25 13:06:19.823864
# Unit test for function md5s
def test_md5s():
    # Define the arguments of the function
    float_0 = 512.0
    # Get the actual result
    result = md5s(float_0)
    # Get the expected result
    expected = "8f9bfe906f0b5e98401d3b3ce0f723c1"
    # Compare the actual result with the expected one
    assert result == expected



# Generated at 2022-06-25 13:06:26.107409
# Unit test for function md5
def test_md5():
    assert md5s('Hello World') == '0a4d55a8d778e5022fab701977c5d840bbc486d0'
    assert md5s('Hello World!') == '7d793037a0760186574b0282f2f435e7'
    assert md5('/bin/ls') == '4d186321c1a7f0f354b297e8914ab240'


# Generated at 2022-06-25 13:06:30.790191
# Unit test for function md5s
def test_md5s():
    print('Testing md5s')
    test_case_0()


# Generated at 2022-06-25 13:06:33.240978
# Unit test for function checksum
def test_checksum():
    assert "193c2d5920d5d317b5228dd078f5f5c0" == checksum("test/test-utils/test_utils.py")


# Generated at 2022-06-25 13:06:37.210510
# Unit test for function md5
def test_md5():
    var_1 = md5('/etc/passwd')
    assert var_1 == 'c31abdf5c5ef5b5d7571c633ce9f907b', 'Expected md5() to return "c31abdf5c5ef5b5d7571c633ce9f907b", got "%s"' % var_1

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-25 13:06:39.352522
# Unit test for function md5s
def test_md5s():
    assert md5s(512.0) == 'e9071c9e43f74a90b8a3a3f3c3f0b3a1'



# Generated at 2022-06-25 13:06:41.921531
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'c63d635d9a30862a0dde102502dff0f4'
    assert md5('nosuchfile') is None
    assert md5('/etc') is None


# Generated at 2022-06-25 13:06:42.585173
# Unit test for function md5s
def test_md5s():
    test_case_0()



# Generated at 2022-06-25 13:06:44.761402
# Unit test for function md5s
def test_md5s():
    print('Test 0:')
    test_case_0()
    print('Mem used: ' + str(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss))


if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-25 13:06:48.639298
# Unit test for function md5
def test_md5():
    # Create the basic variables used in the unit test.
    float_0 = 512.0
    var_0 = md5s(float_0)
    assert var_0 == 'd41d8cd98f00b204e9800998ecf8427e'
    var_1 = md5(float_0)
    assert var_1 == 'd41d8cd98f00b204e9800998ecf8427e'



# Generated at 2022-06-25 13:06:50.473370
# Unit test for function md5s
def test_md5s():
    assert md5s(' ') == '7215ee9c7d9dc229d2921a40e899ec5f'


# Generated at 2022-06-25 13:06:56.286259
# Unit test for function md5s
def test_md5s():
    assert md5s(512) == "69c7aabf78a9b8af09ae83d4e0e07d50"
    assert md5s('512.0') == "f4cc4f67ca2b7eb17547a2c429d0ef58"


# Generated at 2022-06-25 13:07:03.897691
# Unit test for function md5
def test_md5():
    # Test case 0
    float_0 = 512.0
    var_0 = md5s(float_0)
    assert var_0 == '17428896c3f195aa4313d0a8a5a0fcd2'
    assert True

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-25 13:07:06.681325
# Unit test for function md5s
def test_md5s():
    from subprocess import call
    import sys
    import os
    cmd = os.getcwd() + '/test_md5s.py'
    cmd_output = call(cmd, shell=True, executable='/bin/bash')


# Generated at 2022-06-25 13:07:09.258366
# Unit test for function md5s
def test_md5s():
    val = md5s(512.0)
    assert val == '7d865e959b2466918c9863afca942d0fb89d7c9ac0c99bafc3749504ded97730'

# Generated at 2022-06-25 13:07:16.154359
# Unit test for function md5
def test_md5():
    test_case_0()

# Generated at 2022-06-25 13:07:18.465490
# Unit test for function md5
def test_md5():
    assert md5("./test/unit/utils/test_utils/test_utils.py") == "1108e28aa3c46e2f2d75951f84f8e038"


# Generated at 2022-06-25 13:07:20.083193
# Unit test for function md5s
def test_md5s():
    assert md5s('ansible') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-25 13:07:21.373938
# Unit test for function md5
def test_md5():
    float_0 = 344.0
    var_0 = md5('test.txt')


# Generated at 2022-06-25 13:07:23.654133
# Unit test for function md5s
def test_md5s():
    float_0 = 512.0
    #assert var_0 == '340cdd9c9ffa81cb75acdacb7c50f693'
    return True



# Generated at 2022-06-25 13:07:25.593967
# Unit test for function md5s
def test_md5s():
    assert md5s(b'foo') == b'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-25 13:07:34.180891
# Unit test for function checksum
def test_checksum():
    if not os.path.exists("/bin/ls"):
        print("[FAIL]: Did not find /bin/ls")
        return False

    match = checksum("/bin/ls")

    if match:
        print("[FAIL]: Expected checksum to fail on a directory")
        return False

    match = checksum("/bogus/file")

    if match:
        print("[FAIL]: Expected checksum to fail on a missing file")
        return False

    match = checksum("/bin/ls")

    if match == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed":
        return True
    else:
        print("[FAIL]: Expected sha1 sum to match")
        return False



# Generated at 2022-06-25 13:07:39.157730
# Unit test for function md5
def test_md5():
    print("UNIT TESTING: md5")
    # Test case 0
    test_case_0()

# Unit test runner
test_md5()

# Generated at 2022-06-25 13:07:40.611335
# Unit test for function md5s
def test_md5s():
    print("Unit test for function md5s")
    test_case_0()


# Generated at 2022-06-25 13:07:42.220632
# Unit test for function md5s
def test_md5s():
    assert md5s(512.0) == md5s(512.0)


# Generated at 2022-06-25 13:07:43.074233
# Unit test for function md5s
def test_md5s():
    pass


# Generated at 2022-06-25 13:07:43.908743
# Unit test for function md5s
def test_md5s():
    assert False



# Generated at 2022-06-25 13:07:45.727675
# Unit test for function md5
def test_md5():
    int_0 = 48
    var_0 = md5(int_0)


#Unit test for function secure_hash_s

# Generated at 2022-06-25 13:07:50.167694
# Unit test for function md5
def test_md5():
    """Unit test for function md5"""
    testfile = open("/tmp/test.txt", "w")
    testfile.write("test file for md5")
    testfile.flush()
    testfile.close()
    assert md5("/tmp/test.txt") == "22d9b42a0b46b90fe7ca8ac2838e1d15"


# Generated at 2022-06-25 13:07:52.159744
# Unit test for function md5s
def test_md5s():
    assert md5s(512.0) == '34e361f9c3eac6c9dceb86e6b0d6c87c'



# Generated at 2022-06-25 13:07:54.050428
# Unit test for function checksum
def test_checksum():
    assert checksum('file.txt') == secure_hash('file.txt')
    assert checksum_s('test') == secure_hash_s('test')


# Generated at 2022-06-25 13:07:54.806240
# Unit test for function md5
def test_md5():
    assert md5('/tmp/foo')

# Generated at 2022-06-25 13:07:59.328602
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == '6d15e430a217c59e9d86b41e3d2c2f55'


# Generated at 2022-06-25 13:08:05.949434
# Unit test for function md5s
def test_md5s():
    assert('884f547eda6c1a7d92e05f46e7f22aeb' == md5s(8))
    assert('5e543256c480ac577d30f76f9120eb74' == md5s(512))
    assert('40bd001563085fc35165329ea1ff5c5ecbdbbeef' == md5s('abracadabra'))
    assert('e612d9967c6da8ed25e74e6a1d90eee6' == md5s(512.0))


# Generated at 2022-06-25 13:08:08.815860
# Unit test for function md5
def test_md5():
    assert md5("/etc/passwd") == "08d30d2e2c22e4812b538f9bd3879085"


# Generated at 2022-06-25 13:08:12.793435
# Unit test for function md5s
def test_md5s():
    assert(md5s(data=512.0) == 'f308948b5d460dbb1cf8b1d2b2ebe5c5')
    assert(md5s(data=256.0) == '1b8dde1709d06b056f90b6f9b2627248')



# Generated at 2022-06-25 13:08:14.878309
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == '51d5f6ab5c0ba8f0f06b6d5eb5b5f6b0'


# Generated at 2022-06-25 13:08:15.876888
# Unit test for function md5s
def test_md5s():
    test_case_0()


# Generated at 2022-06-25 13:08:18.029714
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    float_0 = 512.0
    var_0 = md5s(float_0)



# Generated at 2022-06-25 13:08:19.057460
# Unit test for function md5
def test_md5():
    print(md5("test_md5.py"))


# Generated at 2022-06-25 13:08:20.859138
# Unit test for function md5s
def test_md5s():
    print("Testing md5s")
    test_case_0()


if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-25 13:08:23.066153
# Unit test for function md5
def test_md5():
    string = 'test'
    h = md5s(string)
    assert h == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-25 13:08:28.513975
# Unit test for function md5
def test_md5():
    assert md5('password') == '5f4dcc3b5aa765d61d8327deb882cf99'


# Generated at 2022-06-25 13:08:30.410341
# Unit test for function md5s
def test_md5s():
    assert(md5s('512.0') == '6ffe44e09dd3c30eceb8e22c6f923e92')


# Generated at 2022-06-25 13:08:35.708105
# Unit test for function md5
def test_md5():
    checksum_file_path = 'file_to_checksum.txt'
    hash_file_path = 'checksum_sha_file.txt'
    sha_hash = open(hash_file_path, "r").read()

    assert checksum(checksum_file_path) == sha_hash


# Generated at 2022-06-25 13:08:38.485418
# Unit test for function checksum
def test_checksum():
    assert checksum('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'


# Generated at 2022-06-25 13:08:43.089298
# Unit test for function md5s
def test_md5s():
    float_0 = 512.0
    var_0 = md5s(float_0)
    assert var_0 == "5965ff7fc44cadabeda3ac2acb1e5d5d"



# Generated at 2022-06-25 13:08:45.633772
# Unit test for function md5
def test_md5():
    try:
        md5('/tmp/ansible_jE5gYl')
    except ValueError as excep:
        print(excep)



# Generated at 2022-06-25 13:08:55.499384
# Unit test for function checksum
def test_checksum():
    _0 = 0.0
    _1 = 1.0
    _2 = 2.0
    _3 = 3.0
    _4 = 4.0
    _5 = 5.0
    _6 = 6.0
    _7 = 7.0
    _8 = 8.0
    _9 = 9.0
    _10 = 10.0
    _11 = 11.0
    _12 = 12.0
    _13 = 13.0
    _14 = 14.0
    _15 = 15.0
    _16 = 16.0
    _17 = 17.0
    _18 = 18.0
    _19 = 19.0
    _20 = 20.0
    _21 = 21.0
    _22 = 22.0
    _23 = 23.0
    _24 = 24.0

# Generated at 2022-06-25 13:08:57.464862
# Unit test for function md5s
def test_md5s():
    assert(md5s('a') == '0cc175b9c0f1b6a831c399e269772661')



# Generated at 2022-06-25 13:09:00.267785
# Unit test for function md5s
def test_md5s():
    float_0 = 512.0
    var_0 = md5s(float_0)

    assert var_0 == 'a3ac1d9f6b59e6c37f6e0722f735178f'


# Generated at 2022-06-25 13:09:05.837948
# Unit test for function md5s
def test_md5s():
    var_0 = md5s('Hello World')
    assert var_0 == 'b10a8db164e0754105b7a99be72e3fe5'


# Generated at 2022-06-25 13:09:14.235040
# Unit test for function checksum
def test_checksum():
    # Create a map of arguments to pass to the function
    # You may add more arguments if needed.
    args = {}
    args['filename'] = 'test_file'

    # Get the result
    result = checksum(**args)

    # Compare to expected result
    assert result == '7b79b468926f8eefab67297f76d4f0e1'


# Generated at 2022-06-25 13:09:19.049408
# Unit test for function md5s
def test_md5s():
    assert md5s(512.0) == '6b0c6b5e6d04ae26d783f0e59c8d93a1', "md5s(512.0) == '6b0c6b5e6d04ae26d783f0e59c8d93a1'"


# Generated at 2022-06-25 13:09:22.280684
# Unit test for function md5s
def test_md5s():
    with pytest.raises(TypeError) as excinfo:
        assert test_case_0() == 'f5c5b8ca3dec547e3c4f4ad0827a8d2b'


# Generated at 2022-06-25 13:09:25.418241
# Unit test for function md5s
def test_md5s():
    float_0 = 512.0
    var_0 = md5s(float_0)
    assert var_0 == '3481df8e077c9946ea4857e43e86d1eb', var_0



# Generated at 2022-06-25 13:09:27.514142
# Unit test for function md5
def test_md5():
    try:
        md5(oldstyle_0)
    except ValueError as e:
        assert "MD5 not available" in e


# Generated at 2022-06-25 13:09:33.572010
# Unit test for function md5
def test_md5():
    var_6 = "thx1138"
    var_7 = md5s(var_6)
    # Ansible-specific, since md5 is not supported in FIPS-mode
    if not _md5:
        assert var_7 == False
        return
    assert var_7 == "4d4caadc811e7b1e68647c26d7f079fd"
    var_8 = md5("./hack_solution.py")
    assert var_8 == "7e409c9b939201bdc24eb0aab749314b"


# Generated at 2022-06-25 13:09:42.717728
# Unit test for function checksum
def test_checksum():
    assert '' == checksum('')
    assert 'da39a3ee5e6b4b0d3255bfef95601890afd80709' == checksum(None)
    assert 'ad0234829205b9033196ba818f7a872b' == checksum('hello')
    assert 'd41d8cd98f00b204e9800998ecf8427e' == checksum('world')
    assert '3858f62230ac3c915f300c664312c63f' == checksum('!!!')
    assert 'd0a6a4fb6a837e96eb7d4c3e3bd7aa8b' == checksum('python')

# Generated at 2022-06-25 13:09:50.543022
# Unit test for function md5
def test_md5():
    var_0 = md5('test_data/test_0')
    assert var_0 == 'd41d8cd98f00b204e9800998ecf8427e'
    var_1 = md5('test_data/test_1')
    assert var_1 == '4d186321c1a7f0f354b297e8914ab240'
    var_2 = md5('test_data/test_2')
    assert var_2 == 'd4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35'
    var_3 = md5('test_data/test_3')

# Generated at 2022-06-25 13:09:52.595238
# Unit test for function md5
def test_md5():
    devnull = open('/dev/null', 'w')
    ret = secure_hash(devnull.name, md5)
    assert ret == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-25 13:09:53.225623
# Unit test for function md5
def test_md5():
    pass


# Generated at 2022-06-25 13:10:03.096216
# Unit test for function checksum
def test_checksum():
    assert checksum(u'filename') is not None
    assert checksum_s(u'string') is not None


# Generated at 2022-06-25 13:10:03.897919
# Unit test for function md5s
def test_md5s():
    test_case_0()


# Generated at 2022-06-25 13:10:11.190837
# Unit test for function md5
def test_md5():
    assert(md5(512.0) == '2e8d7a9e6f0c7ad20b6eb8c7f1d2c39e')
    assert(md5(1024.0) == 'cf7ccef65e8f77e24a2d1c723e73f93b')
    assert(md5(1536.0) == 'b8681059aa6f2a53c1f2f12b6d9a6bc2')
    assert(md5(2048.0) == 'b3d3b3f3c60ba32e9d9b961c4e4cfc4d')

# Generated at 2022-06-25 13:10:12.950573
# Unit test for function md5s
def test_md5s():
    float_0 = 512.0
    assert md5s(float_0) == '5c3d921d40197a947f71b1cae6119f93'

# Generated at 2022-06-25 13:10:18.768502
# Unit test for function md5
def test_md5():
    assert "d41d8cd98f00b204e9800998ecf8427e" == md5("")
    assert len(md5("")) == 32
    assert "e2fc714c4727ee9395f324cd2e7f331f" == md5("a")
    assert len(md5("a")) == 32
    assert "900150983cd24fb0d6963f7d28e17f72" == md5("abc")
    assert len(md5("abc")) == 32
    assert "f96b697d7cb7938d525a2f31aaf161d0" == md5("message digest")
    assert len(md5("message digest")) == 32

# Generated at 2022-06-25 13:10:23.877793
# Unit test for function md5s
def test_md5s():
    float_0 = 2.0
    assert md5s(float_0) == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'

    str_0 = 'hello world'
    assert md5s(str_0) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

    int_0 = 256
    assert md5s(int_0) == '5c5fc5aefbf5bfb60c8170f0c9a7a69d'

    # Test for floats in the range of [0.0, 1.0)
    float_0 = 0.125

# Generated at 2022-06-25 13:10:31.211763
# Unit test for function md5
def test_md5():
    assert(md5s('test') == '098f6bcd4621d373cade4e832627b4f6')
    assert(md5('/dev/null') == 'd41d8cd98f00b204e9800998ecf8427e')
    assert(md5('/bin/ls') != 'd41d8cd98f00b204e9800998ecf8427e')


# Generated at 2022-06-25 13:10:39.217134
# Unit test for function md5s
def test_md5s():
    float_0 = 512.0
    var_0 = md5s(float_0)
    assert var_0 == '3050d5b5ff5e564374f5e5b8780f5c23'
    var_1 = md5s("a")
    assert var_1 == '0cc175b9c0f1b6a831c399e269772661'
    var_2 = md5s("md5")
    assert var_2 == '1bc29b36f623ba82aaf6724fd3b16718'
    var_3 = md5s("")
    assert var_3 == 'd41d8cd98f00b204e9800998ecf8427e'
    var_4 = md5s("md5sum")