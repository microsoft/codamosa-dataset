

# Generated at 2022-06-17 15:04:04.476719
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:04:06.611621
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:04:13.483019
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module. '''

    import os
    import tempfile
    import shutil
    import stat

    from ansible.module_utils.basic import AnsibleModule

    def _create_file(path, data):
        f = open(path, 'w')
        f.write(data)
        f.close()

    def _create_dir(path):
        os.mkdir(path)

    def _create_link(src, dst):
        os.symlink(src, dst)

    def _create_fifo(path):
        os.mkfifo(path)

    def _create_sock(path):
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.bind(path)
       

# Generated at 2022-06-17 15:04:23.552326
# Unit test for function md5
def test_md5():
    '''
    ansible.utils.md5 unit test
    '''

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestMd5(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        @patch('ansible.utils.md5.secure_hash')
        def test_md5(self, secure_hash_mock):
            secure_hash_mock.return_value = 'fake_md5'
            self.assertEqual(md5('fake_file'), 'fake_md5')
            secure_hash_mock.assert_called_with('fake_file', _md5)


# Generated at 2022-06-17 15:04:29.933500
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    test_file = os.path.join(tmpdir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test')
    assert md5(test_file) == '098f6bcd4621d373cade4e832627b4f6'
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:04:41.070584
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\n') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\r\n') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\r') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\r\r') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:04:49.241569
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == 'f71c27109c692c1b56bbdceb5b9d2865b3708dbc'

# Generated at 2022-06-17 15:04:59.713969
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for utils.checksum '''

    import os
    import tempfile

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, mock_open, MagicMock

    from ansible.module_utils import basic

    class TestChecksum(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.testfile = os.path.join(self.tmpdir, 'testfile')
            self.testfile2 = os.path.join(self.tmpdir, 'testfile2')
            self.testfile3 = os.path.join(self.tmpdir, 'testfile3')

# Generated at 2022-06-17 15:05:12.117266
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5s('hello') != md5s('hello ')
    assert md5s('hello') != md5s('hello\n')
    assert md5s('hello') != md5s('hello\r')
    assert md5s('hello') != md5s('hello\r\n')
    assert md5s('hello') != md5s('hello\r\n\r\n')
    assert md5s('hello') != md5s('hello\r\n\r\n ')

# Generated at 2022-06-17 15:05:16.839186
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'e19d5cd5af0378da05f63f891c7467af'
    assert md5s('hello\n\n') == 'e19d5cd5af0378da05f63f891c7467af'
    assert md5s('hello\n\n\n') == 'e19d5cd5af0378da05f63f891c7467af'
    assert md5s('hello\n\n\n\n') == 'e19d5cd5af0378da05f63f891c7467af'

# Generated at 2022-06-17 15:05:27.429489
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\n') == 'e59ff97941044f85df5297e1c302d260'
    assert md5s('hello\nworld') == '9d9e9c4cd21fe4be24a5cf0c6bd96cb7'
    assert md5s('hello\nworld\n') == '8b9128347a6f816c6fe86e08714e7b90'

# Generated at 2022-06-17 15:05:29.809323
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:05:32.583735
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "4a0c5b8c1d5d5f5a0f5b7b102ac5d6d9"


# Generated at 2022-06-17 15:05:38.265255
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:05:41.154724
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b6a8a0d7d7b9c12f32728ba185ad1b0b'


# Generated at 2022-06-17 15:05:50.190969
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file
    (handle, filename) = tempfile.mkstemp()
    os.close(handle)

    # Write some data to the temporary file
    handle = open(filename, 'w')
    handle.write('test')
    handle.close()

    # Create a temporary directory
    dirname = tempfile.mkdtemp()

    # Create a temporary file in the temporary directory
    (handle, filename2) = tempfile.mkstemp(dir=dirname)
    os.close(handle)

    # Write some data to the temporary file
    handle = open(filename2, 'w')
    handle.write('test')


# Generated at 2022-06-17 15:05:52.088177
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:06:04.099089
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\nworld') == 'fc5e038d38a57032085441e7fe7010b0'
    assert md5s('hello\nworld\n') == 'ed076287532e86365e841e92bfc50d8c'
    assert md5s('hello\nworld\n\n') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:06:13.963309
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5s('hello') != md5s('helloo')
    assert md5s('hello') != md5s('hell')
    assert md5s('hello') != md5s('he')
    assert md5s('hello') != md5s('h')
    assert md5s('hello') != md5s('helloo')
    assert md5s('hello') != md5s('hellooo')
    assert md5s('hello') != md5s('helloooo')
    assert md5s('hello') != md5s('hellooooo')

# Generated at 2022-06-17 15:06:22.667388
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='path'),
            hash_algorithm=dict(required=False, default='sha1', choices=['sha1', 'md5']),
        ),
        supports_check_mode=True
    )

    path = module.params['path']
    hash_algorithm = module.params['hash_algorithm']

    if hash_algorithm == 'sha1':
        result = checksum(path)
    else:
        result = md5(path)

    if result is None:
        module.fail_json(msg="%s is not a valid file" % path)

   

# Generated at 2022-06-17 15:06:26.786140
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:06:28.516364
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:06:38.622653
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf9480de5d7a0cdcb34f0ff3ea'
    assert checksum('/bin/ls', 'sha1') == '6b8e3eaf9480de5d7a0cdcb34f0ff3ea'
    assert checksum('/bin/ls', 'sha256') == 'c4d4a5c4f4a8d8c2a3e2d4a5c4d4a5c4f4a8d8c2a3e2d4a5c4d4a5c4f4a8d8c2a'

# Generated at 2022-06-17 15:06:41.375430
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2cac7a5b24af5f148fda7a5b3c'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-17 15:06:43.685854
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:06:53.562806
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf0f8d09af95e065f9d11c52e2'
    assert checksum('/bin/ls', sha1) == '6b8e3eaf0f8d09af95e065f9d11c52e2'
    assert checksum('/bin/ls', _md5) == '6b8e3eaf0f8d09af95e065f9d11c52e2'
    assert checksum('/bin/ls', 'sha1') == '6b8e3eaf0f8d09af95e065f9d11c52e2'

# Generated at 2022-06-17 15:06:57.816232
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'


# Generated at 2022-06-17 15:07:08.825558
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'e9e5d3d0c7a0b9a2cfa1c6e5d6c7a0b9'
    assert md5('/bin/cat') == 'd0763edaa9d9bd2a9516280e9044d885'
    assert md5('/bin/sleep') == 'f1b70c2e24f9a235802458f0e660e9a9'
    assert md5('/bin/uname') == '8e9e5d3d0c7a0b9a2cfa1c6e5d6c7a0b'
    assert md5('/bin/sh') == 'd0763edaa9d9bd2a9516280e9044d885'

# Generated at 2022-06-17 15:07:19.956978
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world!') == 'b48b4b7a9b4cda8bbb8005831f939e1c'
    assert md5s('hello world!!') == 'f8c7e99a9b9a26b7c7a5aefd6e2d17e1'
    assert md5s('hello world!!!') == '3d4f2bf07dc1be38b20cd6e46949a1071'

# Generated at 2022-06-17 15:07:22.390275
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:07:36.343745
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s(u'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s(b'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo' * 100000) == 'e8dc4081b13434b45189a720b77b6818'
    assert md5s(u'foo' * 100000) == 'e8dc4081b13434b45189a720b77b6818'

# Generated at 2022-06-17 15:07:43.231634
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('Hello World')
    f.close()

    # Create a temporary directory
    dname = tempfile.mkdtemp()

    # Create a temporary file in the directory
    fname2 = os.path.join(dname, 'foo')
    f = open(fname2, 'w')
    f.write('Hello World')
    f.close()

    # Create a temporary file in the directory
    fname3 = os.path.join(dname, 'bar')

# Generated at 2022-06-17 15:07:53.267343
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test_checksum"), "wb")
    f.write(b"foo")
    f.close()

    # Test the checksum
    assert checksum(os.path.join(tmpdir, "test_checksum")) == "acbd18db4cc2f85cedef654fccc4a4d8"

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:07:59.561892
# Unit test for function md5
def test_md5():
    ''' test md5 function '''
    # Create a temporary file
    import tempfile
    (fd, fname) = tempfile.mkstemp()
    os.close(fd)
    # Write some data to it
    fd = open(fname, 'w')
    fd.write('abcdefg')
    fd.close()
    # Check the md5
    assert md5(fname) == '7ac66c0f148de9519b8bd264312c4d64'
    # Remove the temporary file
    os.unlink(fname)

# Generated at 2022-06-17 15:08:04.295738
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'd7e9a3e3fbf5f105d0da8c8f8c8c8e0e'


# Generated at 2022-06-17 15:08:13.714505
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9b3afdbeab212d55a488d6'
    assert checksum('/bin/ls', sha1) == '6b8e3eaf1f9b3afdbeab212d55a488d6'
    assert checksum('/bin/ls', _md5) == '6b8e3eaf1f9b3afdbeab212d55a488d6'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls', sha1)


# Generated at 2022-06-17 15:08:22.803603
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "a8c88e5d1d8c3b5e5f0fdb37e8d3f3e5"
    assert md5("/bin/cat") == "c2d177e8c5f9f5d43d1af4f3b1ea39c2"
    assert md5("/bin/cat") != "c2d177e8c5f9f5d43d1af4f3b1ea39c3"
    assert md5("/bin/cat") != "c2d177e8c5f9f5d43d1af4f3b1ea39c1"

# Generated at 2022-06-17 15:08:24.961083
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-17 15:08:33.975428
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/passwd') == '9a3d5f9c2a6d60d8a8e6d5a9a5d5f9c2'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', _md5) == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/etc/passwd') == '9a3d5f9c2a6d60d8a8e6d5a9a5d5f9c2'

# Generated at 2022-06-17 15:08:45.998345
# Unit test for function checksum
def test_checksum():
    '''
    ansible.utils.checksum - Test checksum function
    '''

    # Create a temporary file
    import tempfile
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the temporary file
    with open(temp_path, 'w') as f:
        f.write('test')

    # Check the checksum
    assert checksum(temp_path) == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

    # Remove the temporary file
    os.remove(temp_path)

# Generated at 2022-06-17 15:08:56.546675
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create a file
    f = open('foo', 'w')
    f.write('foobar')
    f.close()

    # Check the md5
    assert md5('foo') == '3858f62230ac3c915f300c664312c63f'

    # Clean up
    os.chdir(curdir)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:09:08.542795
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'a8c88e5d3e0c6c8d6b5a2a6e7ed5a1ee'
    assert checksum('/bin/ls', hash_func=_md5) == 'f1c20f07b46b7e71c8e0b383581766b6'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert checksum_s('hello world', hash_func=_md5) == md5s('hello world')
    assert checksum

# Generated at 2022-06-17 15:09:12.208327
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:09:14.299516
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:09:18.267714
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:09:24.465837
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0e5fe84ad3518c83ce8c0b8845'
    assert checksum('/bin/ls', hash_func=_md5) == '6b8e3e0e5fe84ad3518c83ce8c0b8845'
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:09:33.925734
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\n\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'

# Generated at 2022-06-17 15:09:37.831607
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:09:49.570290
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, fname = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write data to the file
    f = open(fname, 'wb')
    f.write(b"foo")
    f.close()

    # Get the checksum
    csum = checksum(fname)

    # Make sure the checksum is 40 characters long
    assert len(csum) == 40, "Invalid checksum %s" % csum

    # Make the file read only
    os.chmod(fname, stat.S_IREAD)

    # Get the checksum
    csum = checks

# Generated at 2022-06-17 15:09:57.075669
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile
    import shutil
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write data to the temporary file
    with open(temp_path, 'w') as f:
        f.write('Hello World')

    # Create a temporary module
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
        ),
        supports_check_mode=True
    )

    # Run the checksum module
    module.exit_

# Generated at 2022-06-17 15:10:05.415533
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf0f8d09e0c4a963e4da4d1b8f'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-17 15:10:11.008726
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'

# Generated at 2022-06-17 15:10:18.648035
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Create a temporary directory
    dname = tempfile.mkdtemp()

    # Create a temporary file in the temporary directory
    fname2 = os.path.join(dname, 'bar')
    f = open(fname2, 'w')
    f.write('bar')
    f.close()

    # Create a temporary file in the temporary directory

# Generated at 2022-06-17 15:10:24.423460
# Unit test for function md5
def test_md5():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile

    module = AnsibleModule(argument_spec={})

    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('hello')
    f.close()

    module.exit_json(changed=False, md5=md5(fname))


# Generated at 2022-06-17 15:10:33.720261
# Unit test for function checksum
def test_checksum():
    ''' test_checksum() - test the checksum function '''
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Check the checksum
    assert checksum(temp_path) == 'acbd18db4cc2f85cedef654fccc4a4d8'

    # Remove the temporary file
    os.remove(temp_path)

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:10:46.218875
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_checksum'), 'w')
    f.write('test_checksum')
    f.close()

    # Test if the checksum of the file matches
    assert checksum(os.path.join(tmpdir, 'test_checksum')) == '6a3f3f8b6c0a8a0d9a9c1d7b6c5c9f7d0f3f3e8b'

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:10:56.310486
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'c8d11180c9c2f055f4a3d8b944a5fefc'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-17 15:11:03.523569
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e979e0afc0c4214a2f5a1f57d2c2b9f5f2d35'
    assert checksum('/bin/ls', hash_func=_md5) == 'f0ffa2e9d8f1c28d9a5a8d36b0b0d2c2'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:11:08.341070
# Unit test for function md5
def test_md5():
    ''' md5 unit test '''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(required=True, type='str'),
        ),
        supports_check_mode=True
    )

    data = module.params['data']
    result = md5s(data)
    module.exit_json(changed=False, md5=result)


# Generated at 2022-06-17 15:11:11.826404
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:11:18.101547
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:11:27.250890
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'e2c569be17396eca2a2e3c11578123ed'
    assert md5s('hello\r\n') == '1f8ac10f23c5b5bc1167bda84b833e5c'
    assert md5s('hello\r') == '7815696ecbf1c96e6894b779456d330e'
    assert md5s('hello\n\r') == 'e2c569be17396eca2a2e3c11578123ed'

# Generated at 2022-06-17 15:11:32.104282
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:11:45.322482
# Unit test for function md5
def test_md5():
    ''' test_md5.py: Unit test for function md5 '''

    import tempfile
    import shutil
    import os

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temp directory
    fd, fname = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('Hello World')
    f.close()

    # Calculate the md5 checksum
    checksum = md5(fname)

    # Remove the temp directory
    shutil.rmtree(tmpdir)

    # Assert that the checksum is correct
    assert checksum == 'fc3ff98e8c6a0d3087d515c0473f8677'

# Generated at 2022-06-17 15:11:53.652816
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/passwd') == '9d7df2a8f0d7b8c9f9f9a8f0d7d7df2a'
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert md5('/etc/passwd') == '9d7df2a8f0d7b8c9f9f9a8f0d7d7df2a'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:11:56.119552
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:11:59.535426
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d8f5e7d76f5fad9e0'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:08.462679
# Unit test for function md5
def test_md5():
    ''' md5.py: Test md5 function '''
    from ansible.compat.tests import unittest
    import os

    class TestMd5(unittest.TestCase):

        def test_md5(self):
            ''' md5.py: Test md5 function '''
            testfile = os.path.join(os.path.dirname(__file__), 'testfile')
            self.assertEqual(md5(testfile), 'd41d8cd98f00b204e9800998ecf8427e')

    unittest.main(verbosity=2)

if __name__ == "__main__":
    test_md5()

# Generated at 2022-06-17 15:12:17.426532
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for ansible.utils.checksum '''

    import os
    import tempfile

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    from ansible.utils.checksum import (
        checksum,
        checksum_s,
        md5,
        md5s,
    )

    class TestChecksum(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.tmpfile = tempfile.NamedTemporaryFile(dir=self.tmpdir)
            self.tmpfile.write(b'foo')
            self.tmpfile.flush()


# Generated at 2022-06-17 15:12:30.010690
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == 'c7ef86a6d87aae6d2e2b13ee6bbb0e56'
    assert md5s('hello\n\n\n') == 'c7ef86a6d87aae6d2e2b13ee6bbb0e56'
    assert md5s('hello\n\n\n\n') == 'c7ef86a6d87aae6d2e2b13ee6bbb0e56'

# Generated at 2022-06-17 15:12:45.956288
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'


# Generated at 2022-06-17 15:12:52.830441
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:12:56.786847
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == secure_hash_s('hello', _md5)


# Generated at 2022-06-17 15:13:00.443315
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == md5('test')
    assert md5s('test') == md5s('test')


# Generated at 2022-06-17 15:13:11.968581
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == '9e9e0b5c7d0d1a5f8d7f3fad7f3c8f3b'
    assert md5s('hello\n\n\n') == 'c8e7b8f5f0f6c2c1c4b461ae1ae1ae1a'
    assert md5s('hello\n\n\n\n') == 'e9d71f5ee7c92d6dc9e92ffdad17b8bd'


# Generated at 2022-06-17 15:13:20.199099
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:13:22.201082
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'a8b64babd99c5e3dde3f7a3913e2a8d6'


# Generated at 2022-06-17 15:13:27.117915
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf0f8d16b8c49b46b7f8e9a0c1'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:29.878633
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:13:33.359310
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-17 15:13:47.388280
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n\r\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:13:57.103826
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile
    import shutil

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Create a temporary directory
    dirname = tempfile.mkdtemp(dir=tmpdir)

    # Create a temporary file
    (fd, fname2) = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('bar')