

# Generated at 2022-06-17 15:04:01.753779
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == md5('test')

# Generated at 2022-06-17 15:04:12.105578
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf9480de5d7a0c2d3966a0f87f'
    assert checksum('/bin/ls', hash_func=_md5) == 'f8dff6e0e1f913d40168b64f1b1535bf'
    assert checksum('/bin/ls', hash_func=sha1) == '6b8e3eaf9480de5d7a0c2d3966a0f87f'
    assert checksum('/bin/ls', hash_func=sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls', hash_func=_md5) == checksum('/bin/ls', hash_func=_md5)

# Generated at 2022-06-17 15:04:17.873041
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls') == '4f9a3b07c1e3d4f49b2e622a3514533b'


# Generated at 2022-06-17 15:04:25.832090
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:04:32.902127
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'testfile'), 'w')
    f.write('test')
    f.close()

    # Test the md5 function
    assert md5(os.path.join(tmpdir, 'testfile')) == '098f6bcd4621d373cade4e832627b4f6'

    # Remove the temporary directory after the test
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:04:46.505095
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-17 15:04:48.131767
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:04:52.502042
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:05:00.987678
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0c7bfbfdb2c13054d45e8d2c49'
    assert checksum('/bin/ls', sha1) == '6b8e3e0c7bfbfdb2c13054d45e8d2c49'
    assert checksum('/bin/ls', _md5) == '6b8e3e0c7bfbfdb2c13054d45e8d2c49'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls')

# Generated at 2022-06-17 15:05:12.810125
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2f30d8e0ffb46c8e50f3'
    assert checksum('/bin/ls', hash_func=_md5) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5('/bin/ls') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5

# Generated at 2022-06-17 15:05:20.384274
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls') == 'b6a7c8d8c6b8d6a7c8d8c6b8d6a7c8d8'

# Generated at 2022-06-17 15:05:26.160595
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:05:30.786056
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'


# Generated at 2022-06-17 15:05:40.159691
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile
    import shutil

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, "w")
    f.write("Hello World")
    f.close()

    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)

    # Create a temporary file
    (fd, fname2) = tempfile.mkstemp(dir=tmpdir2)
    f = os.fdopen(fd, "w")
    f.write

# Generated at 2022-06-17 15:05:49.573601
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\r\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\r') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\r\r') == '8b1a9953c4611296a827abf8c47804d7'

# Generated at 2022-06-17 15:05:56.836723
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'


# Generated at 2022-06-17 15:06:06.618303
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

# Generated at 2022-06-17 15:06:09.592743
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')

# Generated at 2022-06-17 15:06:20.568193
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test')
    f.close()

    # Test checksum
    assert checksum(os.path.join(tmpdir, 'test')) == '098f6bcd4621d373cade4e832627b4f6'

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:06:29.756519
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '4b7dbb062e5a9a9a8d309865d8e7dfe5e8d8a8b5'
    assert checksum('/bin/ls', sha1) == '4b7dbb062e5a9a9a8d309865d8e7dfe5e8d8a8b5'
    assert checksum('/bin/ls', _md5) == 'c2d8e7dfe5e8d8a8b5'
    assert checksum('/bin/ls', _md5) == 'c2d8e7dfe5e8d8a8b5'

# Generated at 2022-06-17 15:06:42.805691
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0a9f8ca29e0b93bef7a1c2c3'
    assert checksum('/bin/ls', sha1) == '6b8e3e2e0a9f8ca29e0b93bef7a1c2c3'
    assert checksum('/bin/ls', _md5) == '6b8e3e2e0a9f8ca29e0b93bef7a1c2c3'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls')

# Generated at 2022-06-17 15:06:47.215756
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == md5s('test')
    assert md5s('test') != md5s('test2')
    assert md5s('test') != md5s('Test')


# Generated at 2022-06-17 15:06:56.598190
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf0f8d16b8a0e1b20e1727e49d'
    assert checksum('/bin/ls', sha1) == '6b8e3eaf0f8d16b8a0e1b20e1727e49d'
    assert checksum('/bin/ls', _md5) == '6b8e3eaf0f8d16b8a0e1b20e1727e49d'
    assert checksum('/bin/ls', 'sha1') == '6b8e3eaf0f8d16b8a0e1b20e1727e49d'

# Generated at 2022-06-17 15:07:07.939819
# Unit test for function checksum
def test_checksum():
    import tempfile
    from ansible.compat.tests import unittest

    class TestChecksum(unittest.TestCase):
        def setUp(self):
            (fd, self.path) = tempfile.mkstemp()
            f = os.fdopen(fd, 'w')
            f.write('test')
            f.close()

        def tearDown(self):
            os.unlink(self.path)

        def test_checksum(self):
            self.assertEqual(checksum(self.path), 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3')


# Generated at 2022-06-17 15:07:10.600910
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d8d86865246f24e36e3'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:07:14.970275
# Unit test for function md5
def test_md5():
    ''' md5 unit test '''

    # Create a temporary file
    import tempfile
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('test')
    f.close()

    # Calculate the md5 checksum
    md5sum = md5(fname)

    # Remove the temporary file
    os.remove(fname)

    # Assert that the md5 checksum is correct
    assert md5sum == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-17 15:07:17.087002
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:07:27.973513
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test"), 'w')
    f.write("foo")
    f.close()

    # Checksum the file we've just created
    cksum = checksum(os.path.join(tmpdir, "test"))

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

    # Make sure the checksum is what we expect it to be
    assert cksum == "acbd18db4cc2f85cedef654fccc4a4d8"

# Generated at 2022-06-17 15:07:29.709639
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:07:38.102885
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:07:48.497140
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for ansible.utils.checksum '''

    import os
    import tempfile

    from ansible.utils import checksum

    # Create a temporary file and write some data to it
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('test file')
    f.close()

    # Calculate the checksum
    csum = checksum(fname)

    # Remove the temporary file
    os.unlink(fname)

    # Assert that the checksum is correct
    assert csum == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

# Generated at 2022-06-17 15:07:50.783138
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:07:57.712297
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for ansible.utils.checksum '''

    import os
    import tempfile
    from ansible.utils.checksum import checksum

    (fd, fname) = tempfile.mkstemp()
    os.write(fd, b"foobar")
    os.close(fd)
    assert checksum(fname) == 'acbd18db4cc2f85cedef654fccc4a4d8'
    os.unlink(fname)

# Generated at 2022-06-17 15:08:09.872748
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9b9aeb8b85d0c4b30b0e'
    assert md5('/bin/cat') == 'd3b07384d113edec49eaa6238ad5ff00'
    assert md5('/bin/grep') == 'c3b3ad8e0f1a8c7d8b05b46d3a0feaf6'
    assert md5('/bin/pwd') == 'e59ff97941044f85df5297e1c302d260'
    assert md5('/bin/sleep') == 'f1c20f14e6e00b8a7d0e2a5b6e8d1366'

# Generated at 2022-06-17 15:08:13.351085
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "6b1634cbea7c7f12e0b6f2735e3d14f1"


# Generated at 2022-06-17 15:08:16.212879
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d5ae2129ece6e0b30'


# Generated at 2022-06-17 15:08:23.531769
# Unit test for function md5
def test_md5():
    ''' md5.py: Test md5 function '''

    from ansible.compat.tests import unittest
    import tempfile

    class TestMd5(unittest.TestCase):

        def setUp(self):
            (fd, self.path) = tempfile.mkstemp()

        def tearDown(self):
            os.unlink(self.path)

        def test_md5(self):
            ''' md5: test md5 function '''
            with open(self.path, 'w') as f:
                f.write('test string')
            self.assertEqual(md5(self.path), 'e2a3c265c4d118d0e124c0533f5b007f')

    unittest.main()


# Generated at 2022-06-17 15:08:29.428536
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum functions '''

    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write data to the temporary file
    with open(temp_path, 'w') as f:
        f.write('Hello World')

    # Create a temporary subdirectory
    temp_subdir = os.path.join(tmpdir, 'subdir')
    os.mkdir(temp_subdir)

    # Create a temporary file in the subdirectory
    fd, temp_subdir_path = tempfile.mkstemp(dir=temp_subdir)

# Generated at 2022-06-17 15:08:36.558874
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "6b8e979e0af8f0e4d8e7d8afd18b8c74e0f3f7d1"
    assert checksum_s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert checksum_s("hello", hash_func=_md5) == "5d41402abc4b2a76b9719d911017c592"
    assert checksum_s("hello", hash_func=_md5) == md5s("hello")
    assert checksum("/bin/ls", hash_func=_md5) == "6b8e979e0af8f0e4d8e7d8afd18b8c74"

# Generated at 2022-06-17 15:08:39.915636
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:08:50.335066
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0a8d8bc3a7ba3a5d81c8acb5e4e1c1a5'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', _md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', _md5) == md5s('hello')
    assert checksum('/bin/ls', _md5) == '6b8e3e2e0a8d8bc3a7ba3a5d81c8acb5e4e1c1a5'

# Generated at 2022-06-17 15:08:59.052080
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile
    import shutil

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True),
            hash_algorithm = dict(default='sha1', choices=['sha1', 'md5']),
        ),
        supports_check_mode=True
    )

    path = module.params['path']
    hash_algorithm = module.params['hash_algorithm']

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, tmpfile) = tempfile.mk

# Generated at 2022-06-17 15:09:01.713207
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:09:04.186727
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:09:14.263044
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\nworld') == 'ed076287532e86365e841e92bfc50d8c'
    assert md5s('hello\nworld\n') == 'dffd6021bb2bd5b0af676290809ec3a53191dd81'
    assert md5s('hello\nworld\n\n') == 'f1d2d2f924e986ac86fdf7b36c94bcdf32beec15'

# Generated at 2022-06-17 15:09:25.505305
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Create a temporary directory
    dname = tempfile.mkdtemp()

    # Create a temporary file in the directory
    fname2 = os.path.join(dname, 'foo')
    f = open(fname2, 'w')
    f.write('foo')
    f.close()

    # Create a temporary file in the directory
    fname3 = os.path.join(dname, 'bar')
   

# Generated at 2022-06-17 15:09:30.580165
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5('/bin/ls') == 'b9a8e8f9c9e9b7d0f7b8c7d8f7a0a3d0'


# Generated at 2022-06-17 15:09:36.423822
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test"), "wb")
    f.write(b"foo")
    f.close()

    # Test checksum
    assert checksum(os.path.join(tmpdir, "test")) == checksum_s("foo")

    # Test checksum with non-existent file
    assert checksum(os.path.join(tmpdir, "test2")) is None

    # Test checksum with directory
    assert checksum(tmpdir) is None

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:09:45.273956
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test')
    assert md5(test_file) == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:09:52.236405
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    (fd, fname) = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Test checksum
    assert checksum(fname) == checksum_s('foo')

    # Remove the temporary file
    os.unlink(fname)
    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:10:04.990705
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')

    # Create a test file
    with open(test_file, 'w') as f:
        f.write('test')

    # Test md5
    assert md5(test_file) == '098f6bcd4621d373cade4e832627b4f6'

    # Test md5s
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

    # Cleanup
    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:10:07.198993
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:10:10.872210
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    else:
        try:
            md5s('hello')
            assert False
        except ValueError:
            pass

# Generated at 2022-06-17 15:10:20.112796
# Unit test for function md5
def test_md5():
    ''' md5 unit test '''

    # Create a temporary file and write some data to it
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Calculate the md5 checksum of the file
    checksum = md5(fname)

    # Remove the temporary file
    os.remove(fname)

    # Assert that the checksum is correct
    assert checksum == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-17 15:10:29.262066
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile
    import shutil
    import sys

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
            # checksum_algorithm = dict(required=False, default='sha1', choices=['sha1', 'md5']),
        ),
        supports_check_mode=True
    )

    path = module.params['path']

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, tmppath) = tempfile.mkstemp(dir=tmpdir)

    # Write data to the temporary file
   

# Generated at 2022-06-17 15:10:38.749190
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '4b7dbb03115e9bd3d0e3a7d4f8b397c7'
    assert checksum('/bin/ls', sha1) == '4b7dbb03115e9bd3d0e3a7d4f8b397c7'
    assert checksum('/bin/ls', _md5) == '4b7dbb03115e9bd3d0e3a7d4f8b397c7'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-17 15:10:41.978789
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:10:48.313133
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s("hello world\n") == "e59ff97941044f85df5297e1c302d260"
    assert md5s("hello world\r\n") == "1f8ac10f23c5b5bc1167bda84b833e5c"
    assert md5s("hello world\r\n\r\n") == "b858cb282617fb0956d960215c8e84d1"


# Generated at 2022-06-17 15:10:58.620830
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "c3f5c3d76192e4007dfb496cca67e13b"
    assert md5("/bin/cat") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5("/bin/cat1") == None
    assert md5("/bin/cat1") == None
    assert md5("/bin/cat1") == None
    assert md5("/bin/cat1") == None
    assert md5("/bin/cat1") == None
    assert md5("/bin/cat1") == None
    assert md5("/bin/cat1") == None
    assert md5("/bin/cat1") == None
    assert md5("/bin/cat1") == None

# Generated at 2022-06-17 15:11:01.417499
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:11:08.575251
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test')
    assert md5(test_file) == '098f6bcd4621d373cade4e832627b4f6'
    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:11:13.428480
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'


# Generated at 2022-06-17 15:11:16.521438
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:11:25.888724
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d8ce0c13f0f6a8e9aecf744de2a'
    assert checksum('/bin/ls', sha1) == '6b8e3eaf1f9f2d8ce0c13f0f6a8e9aecf744de2a'
    assert checksum('/bin/ls', _md5) == 'b9cbf875c0e3a7f8e0e43e4b97de9a37'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum('/bin/ls')

# Generated at 2022-06-17 15:11:32.006333
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s("") == "d41d8cd98f00b204e9800998ecf8427e"

# Generated at 2022-06-17 15:11:45.553788
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b9fcece5c8e3b8bfdbf58f8b0c5e8c39'
    assert md5('/bin/cat') == 'd3b07384d113edec49eaa6238ad5ff00'
    assert md5('/bin/grep') == '0b8c87f7d53b5ffb967f740d31c0e826'
    assert md5('/bin/pwd') == 'f1b70c2dcbdbd459aa295e8c0c6a8f17'
    assert md5('/bin/sleep') == 'c7d7d7d8a71f5d1e7a0f1f2f924f9f0f'

# Generated at 2022-06-17 15:11:54.867807
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test"), "wb")
    f.write(b"foo")
    f.close()

    # Test checksum
    assert checksum(os.path.join(tmpdir, "test")) == "acbd18db4cc2f85cedef654fccc4a4d8"

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:12:03.479827
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "6b1634cbea5ce2bba8c29ae4d316497b"
    assert md5("/bin/cat") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5("/bin/cat1") == None
    assert md5("/bin/cat2") == None
    assert md5("/bin/cat3") == None
    assert md5("/bin/cat4") == None
    assert md5("/bin/cat5") == None
    assert md5("/bin/cat6") == None
    assert md5("/bin/cat7") == None
    assert md5("/bin/cat8") == None
    assert md5("/bin/cat9") == None

# Generated at 2022-06-17 15:12:13.495536
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == '81fe8bfe87576c3ecb22426f8e57847382917acf'

# Generated at 2022-06-17 15:12:22.846613
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Create a temporary directory
    dname = tempfile.mkdtemp()

    # Create a temporary file in the directory
    (fd, fname2) = tempfile.mkstemp(dir=dname)
    f = os.fdopen(fd, 'w')
    f.write('bar')
    f.close()

    # Create a temporary file in the directory
    (fd, fname3) = tempfile.mkstem

# Generated at 2022-06-17 15:12:33.864886
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0c6a7cee0d7d2d65c266f5d78a'
    assert checksum('/bin/ls', hash_func=_md5) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5('/bin/ls') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5

# Generated at 2022-06-17 15:12:39.780473
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'd3b07384d113edec49eaa6238ad5ff00'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:48.605433
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\n\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'

# Generated at 2022-06-17 15:12:59.410076
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum('/bin/ls') == 'b8f8c9a8b7e9b2e8d7d8a9b9a9b9a8b8'
    assert checksum('/bin/ls', hash_func=_md5) == 'b8f8c9a8b7e9b2e8d7d8a9b9a9b9a8b8'
    assert checksum('/bin/ls', hash_func=sha1) == 'b8f8c9a8b7e9b2e8d7d8a9b9a9b9a8b8'

# Generated at 2022-06-17 15:13:11.249367
# Unit test for function checksum
def test_checksum():
    # test for checksum
    assert checksum("/bin/ls") == "6b8e3eaf1f9b6ebd8b8c2d66f5dd9d65"
    assert checksum("/bin/ls", hash_func=_md5) == "5a105e8b9d40e1329780d62ea2265d8a"
    assert checksum("/bin/ls", hash_func=sha1) == "6b8e3eaf1f9b6ebd8b8c2d66f5dd9d65"
    assert checksum("/bin/ls", hash_func=sha1) == checksum("/bin/ls")

# Generated at 2022-06-17 15:13:21.024346
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1d69a6a471e3917c8e2ff8e4'
    assert checksum('/bin/ls', hash_func=_md5) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert checksum('/bin/ls', hash_func=sha1) == '6b8e3eaf1d69a6a471e3917c8e2ff8e4'
    assert checksum('/bin/ls', hash_func=sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls', hash_func=_md5) == checksum('/bin/ls', hash_func=_md5)

# Generated at 2022-06-17 15:13:28.584694
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum('/etc/passwd') == '9e73d9a9d4f4a3d8e4a0d3b7b33855c4'

# Generated at 2022-06-17 15:13:37.479806
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True),
            follow = dict(required=False, default=False, type='bool'),
        ),
        supports_check_mode=True
    )

    path = module.params['path']
    follow = module.params['follow']

    if not os.path.exists(path):
        module.fail_json(msg="Source %s not found" % (path))

    if os.path.isdir(path):
        module.fail_json(msg="Source %s is a directory" % (path))


# Generated at 2022-06-17 15:13:39.133262
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:42.728867
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:56.014899
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b6f0a8e7a9a0e8b7d1e4a6f0f1e4a6f0'
    assert md5('/bin/ls') == 'b6f0a8e7a9a0e8b7d1e4a6f0f1e4a6f0'
    assert md5('/bin/ls') == 'b6f0a8e7a9a0e8b7d1e4a6f0f1e4a6f0'
    assert md5('/bin/ls') == 'b6f0a8e7a9a0e8b7d1e4a6f0f1e4a6f0'