

# Generated at 2022-06-17 15:04:04.650052
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '9dcf7d5d5f1a7b8e5b0e3a36b6a201d7'


# Generated at 2022-06-17 15:04:16.048897
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '914f244f443d518c85e7d63927a69a87'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello\n') == '914f244f443d518c85e7d63927a69a87'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello\n') == '914f244f443d518c85e7d63927a69a87'

# Generated at 2022-06-17 15:04:18.174784
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:04:26.067843
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum functions '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True),
            mode = dict(default='sha1', choices=['sha1', 'md5']),
        ),
        supports_check_mode=True
    )

    path = module.params['path']
    mode = module.params['mode']

    if not os.path.exists(path):
        module.fail_json(msg="file not found: %s" % path)

    if mode == 'sha1':
        checksum = secure_hash(path)

# Generated at 2022-06-17 15:04:31.659752
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile
    import shutil
    import stat

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
            follow = dict(required=False, default=False, type='bool'),
        ),
        supports_check_mode=True
    )

    path = module.params['path']
    follow = module.params['follow']

    if not os.path.exists(path):
        module.fail_json(msg="Source %s not found" % (path))


# Generated at 2022-06-17 15:04:36.124358
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "6b8e9c2cd7f9b7e0f1e676306e0b7c49"


# Generated at 2022-06-17 15:04:47.496973
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create a file
    f = open("test_file", "w")
    f.write("This is a test file")
    f.close()

    # Calculate the md5 checksum
    checksum = md5("test_file")

    # Remove the temporary directory
    os.chdir(curdir)
    shutil.rmtree(tmpdir)

    # Assert that the checksum is correct
    assert checksum == "c8d11180cddc8a8bdbf62bdd9b5e9b2d"

# Generated at 2022-06-17 15:04:51.062659
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:04:54.488087
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    else:
        try:
            md5s('foo')
            assert False
        except ValueError:
            pass

# Generated at 2022-06-17 15:04:58.488089
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '4b7dbb03115e9bd3d0e3d9d4f1f2f0f9'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-17 15:05:06.008828
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:05:09.863017
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:05:19.990925
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'
    assert md5s('hello\n\n') == '6f5902ac237024bdd0c176cb93063dc4'
    assert md5s('hello\n\n\n') == '6f5902ac237024bdd0c176cb93063dc4'
    assert md5s('hello\n\n\n\n') == '6f5902ac237024bdd0c176cb93063dc4'

# Generated at 2022-06-17 15:05:28.554978
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f5f2e7d9c0c114d62fdf8b8c9a8a0e4'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-17 15:05:30.551063
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:05:39.959312
# Unit test for function md5
def test_md5():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(u'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(b'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(bytearray(b'hello world')) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5('/bin/ls') == 'c4d0f3e3d4a8a9a5a858a6d28d4c3d25'

# Generated at 2022-06-17 15:05:49.435917
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d5b0c9a5c9f8d3761'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-17 15:05:53.229599
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    try:
        tmpdir = tempfile.mkdtemp()
        test_file = os.path.join(tmpdir, 'test_md5')
        with open(test_file, 'w') as f:
            f.write('test')
        assert md5(test_file) == '098f6bcd4621d373cade4e832627b4f6'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:05:56.737594
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:05:59.114217
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:06:06.212338
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:06:13.745882
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create a file
    f = open("testfile", "w")
    f.write("This is a test file")
    f.close()

    # Calculate the md5 checksum
    checksum = md5("testfile")

    # Remove the temporary directory
    os.chdir(curdir)
    shutil.rmtree(tmpdir)

    # Verify the checksum
    assert checksum == "c8fdb181845a4ca6b8fec737b35143eb"

# Generated at 2022-06-17 15:06:22.558872
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum functions '''

    import os
    import tempfile
    import shutil
    import sys

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a temp file
    (fd, fname) = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Test checksum
    assert checksum(fname) == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert checksum(fname) == checksum_s('foo')

    # Test md5

# Generated at 2022-06-17 15:06:29.691977
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    f = open('foo', 'w')
    f.write('foobar')
    f.close()

    assert md5('foo') == '3858f62230ac3c915f300c664312c63f'
    assert md5s('foobar') == '3858f62230ac3c915f300c664312c63f'

    os.chdir(curdir)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:06:32.265106
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'e2a3f8e9c8b0a58f86b1409b68e8c55b'


# Generated at 2022-06-17 15:06:41.963235
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0a9f8e7a2a9d9a7a8f6e8d1c'
    assert checksum('/bin/ls', hash_func=_md5) == 'a8f05d3d76be0f2f35b29b0d2e8d7d92'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-17 15:06:45.829119
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls') == 'd8e8fca2dc0f896fd7cb4cb0031ba249'


# Generated at 2022-06-17 15:06:56.024956
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_checksum')

    try:
        with open(test_file, 'w') as f:
            f.write('test_checksum')

        assert checksum(test_file) == '2d711642b726b04401627ca9fbac32f5c8530fb1903cc4db02258717921a4881'
        assert checksum_s('test_checksum') == '2d711642b726b04401627ca9fbac32f5c8530fb1903cc4db02258717921a4881'
    finally:
        shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:07:03.592319
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_checksum')
    test_data = 'test_checksum'

    with open(test_file, 'w') as f:
        f.write(test_data)

    assert checksum(test_file) == checksum_s(test_data)

    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:07:11.613436
# Unit test for function md5
def test_md5():
    import tempfile
    import os
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, fname = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write data to the file
    f = open(fname, 'w')
    f.write('This is a test')
    f.close()

    # Make the file read-only
    os.chmod(fname, stat.S_IREAD)

    # Calculate the md5 checksum
    checksum = md5(fname)

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

    # Make sure the checksum is correct

# Generated at 2022-06-17 15:07:23.573282
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:07:30.233916
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create a file
    f = open('foo', 'w')
    f.write('foo')
    f.close()

    # Check the md5
    assert md5('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

    # Remove the temporary directory
    os.chdir(curdir)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:07:33.773453
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:07:37.195016
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-17 15:07:47.809271
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == md5s('test')
    assert md5s('test') != md5s('test2')
    assert md5('/bin/ls') == 'e7dafb5a7f8a8f9b3ec7c5d9d3d8c9e6'
    assert md5('/bin/ls') == md5('/bin/ls')
    assert md5('/bin/ls') != md5('/bin/ls2')
    assert md5('/bin/ls') != md5s('/bin/ls')
    assert md5('/bin/ls') != md5s('/bin/ls2')

# Generated at 2022-06-17 15:07:58.337883
# Unit test for function md5
def test_md5():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == md5s('hello world')
    assert md5s('hello world') != md5s('hello')
    assert md5s('hello world') != md5s('hello worle')
    assert md5s('hello world') != md5s('hello world ')
    assert md5s('hello world') != md5s('hello world!')
    assert md5s('hello world') != md5s('hello world!!')
    assert md5s('hello world') != md5s('hello world!!!')
    assert md5s('hello world') != md5s('hello world!!!!')
    assert md5s('hello world') != md5s('hello world!!!!!')

# Generated at 2022-06-17 15:08:10.617575
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:08:12.427399
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:08:20.395138
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf0f8d2e3a8a6c8f7724b1c399'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls') == '6b8e3eaf0f8d2e3a8a6c8f7724b1c399'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:08:26.551554
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3a8d4ee3c8c63f58f2'


# Generated at 2022-06-17 15:08:36.393559
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\n\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'

# Generated at 2022-06-17 15:08:39.680613
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:08:45.257015
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '4b7dbb03b9c6e4d4a5c491f0f20726f0'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:08:56.472793
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0e2d251d4c0a141a85a6f4c9e1e4c4e9a4'
    assert checksum('/bin/ls', hash_func=_md5) == 'f0b1a3df9e47a2d4f49a1d0d790f5b0c'
    assert checksum('/bin/ls', hash_func=sha1) == '6b8e3e0e2d251d4c0a141a85a6f4c9e1e4c4e9a4'
    assert checksum('/bin/ls', hash_func=sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls', hash_func=_md5)

# Generated at 2022-06-17 15:09:00.251834
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c5f9f9dac420d8c88'


# Generated at 2022-06-17 15:09:04.862090
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5('/etc/passwd') == 'c21f969b5f03d33d43e04f8f136e7682'


# Generated at 2022-06-17 15:09:14.153081
# Unit test for function md5
def test_md5():
    ''' md5 unit test '''

    from ansible.compat.tests import unittest

    class TestMd5(unittest.TestCase):

        def test_md5(self):
            ''' md5 unit test '''
            self.assertEqual(md5('/bin/ls'), '6b8e3eaf66e170e8e7e1c8b7ee0a9f31')
            self.assertEqual(md5('/bin/cat'), 'd41d8cd98f00b204e9800998ecf8427e')
            self.assertEqual(md5('/bin/foo'), None)

    unittest.main(verbosity=2)


# Generated at 2022-06-17 15:09:25.516463
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d8eeafb7b05d8c7d2e0c6c7a2f0'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', _md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', _md5) == md5s('hello')
    assert checksum('/bin/ls', _md5) == 'c0d0f7e8f8a7aecb2c3e0e3a8f5f3d7e'

# Generated at 2022-06-17 15:09:28.915108
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3ac3f0ea7d7b8f4e87'


# Generated at 2022-06-17 15:09:34.224679
# Unit test for function md5
def test_md5():
    '''
    Test md5 function
    '''
    import tempfile
    import shutil
    import os

    try:
        tmpdir = tempfile.mkdtemp()
        testfile = os.path.join(tmpdir, 'testfile')
        with open(testfile, 'w') as f:
            f.write('test')
        assert md5(testfile) == '098f6bcd4621d373cade4e832627b4f6'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:09:49.152774
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True),
            hash_algo = dict(default='sha1', choices=['sha1', 'md5']),
        ),
        supports_check_mode=True
    )

    path = module.params['path']
    hash_algo = module.params['hash_algo']

    if hash_algo == 'sha1':
        checksum_func = checksum
    else:
        checksum_func = md5

    if not os.path.exists(path):
        module.fail_json(msg="file not found: %s" % path)


# Generated at 2022-06-17 15:09:51.053837
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"


# Generated at 2022-06-17 15:09:56.408576
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0dacab96f7935b0cdc08e8e7f24e941b'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', _md5) == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:10:04.715783
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    # Create a temporary file for testing
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Test that the checksum of the temporary file is correct
    assert checksum(fname) == 'acbd18db4cc2f85cedef654fccc4a4d8'

    # Remove the temporary file
    os.unlink(fname)

# Generated at 2022-06-17 15:10:06.922743
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:10:09.147542
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:10:20.626457
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s(u'hello')
    assert md5s('hello') == md5s(b'hello')
    assert md5s(u'hello') == md5s(b'hello')
    assert md5s(b'hello') == md5s(u'hello')
    assert md5s(u'\u1234') == md5s(b'\xe1\x88\xb4')
    assert md5s(b'\xe1\x88\xb4') == md5s(u'\u1234')
    assert md5s(b'\xe1\x88\xb4') == md5s('\u1234')

# Generated at 2022-06-17 15:10:24.078767
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '7e8c0a1e1d7d3ebc8d5a3e36b2a1a5db'


# Generated at 2022-06-17 15:10:27.078098
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'd7e5b5a5f5f8f5e2a5a6f5d7d7e5b5a5'


# Generated at 2022-06-17 15:10:29.169488
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:10:33.756760
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:10:46.800497
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for utils.checksum '''

    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foobar')
    f.close()

    # Create a temporary directory
    dname = os.path.join(tmpdir, 'foo')
    os.mkdir(dname)

    # Create a temporary symlink
    lname = os.path.join(tmpdir, 'bar')
    os.symlink(fname, lname)

    # Test checksum

# Generated at 2022-06-17 15:10:56.719454
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:11:05.749427
# Unit test for function md5
def test_md5():
    ''' md5.py: Test md5 function '''

    from ansible.compat.tests import unittest
    import os

    class TestMd5(unittest.TestCase):

        def setUp(self):
            self.testfile = 'testfile'
            with open(self.testfile, 'w') as f:
                f.write('test')

        def tearDown(self):
            os.unlink(self.testfile)

        def test_md5(self):
            ''' md5: Test md5 function '''
            self.assertEqual(md5(self.testfile), '098f6bcd4621d373cade4e832627b4f6')

    unittest.main()


# Generated at 2022-06-17 15:11:17.792775
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5s('hello') != md5s('helloo')
    assert md5s('hello') != md5s('hell')
    assert md5s('hello') != md5s('hello ')
    assert md5s('hello') != md5s('hello\n')
    assert md5s('hello') != md5s('hello\r\n')
    assert md5s('hello') != md5s('hello\r')
    assert md5s('hello') != md5s('hello\n\r')
    assert md5s('hello') != md

# Generated at 2022-06-17 15:11:23.708743
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '98c6e5f3d8f9a32a844e0d7de5d0e6bb'


# Generated at 2022-06-17 15:11:30.024762
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:11:40.204508
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create a file
    f = open("testfile", "w")
    f.write("Hello World")
    f.close()

    # Get the md5 checksum
    md5sum = md5("testfile")

    # Remove the temporary directory
    os.chdir(curdir)
    shutil.rmtree(tmpdir)

    # Assert that the md5 checksum is correct
    assert md5sum == "ed076287532e86365e841e92bfc50d8c"

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-17 15:11:48.766592
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test"), "wb")
    f.write(b"foo")
    f.close()

    # Check if the checksum is correct
    assert checksum(os.path.join(tmpdir, "test")) == "acbd18db4cc2f85cedef654fccc4a4d8"

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:11:51.274585
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:12:02.261952
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:12:12.661359
# Unit test for function md5
def test_md5():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s("") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5s("hello\nworld") == "b10a8db164e0754105b7a99be72e3fe5"
    assert md5s("hello\rworld") == "1f2d1e2dc9f9466d7b0f487ee1243e4f"

# Generated at 2022-06-17 15:12:18.337218
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create a file
    f = open('foo', 'w')
    f.write('foobar')
    f.close()

    # Check the md5
    assert md5('foo') == '3858f62230ac3c915f300c664312c63f'

    # Clean up
    os.chdir(curdir)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:12:22.739772
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9a9c8f0e3e96147ac858'


# Generated at 2022-06-17 15:12:32.416256
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf9480b8de7e1c9e5d7d0f2eb1'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-17 15:12:46.355613
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-17 15:12:52.021465
# Unit test for function checksum
def test_checksum():
    ''' unit test for checksum '''

    # Create a temporary file
    import tempfile
    tmp_file = tempfile.NamedTemporaryFile()

    # Write some data to the file
    tmp_file.write(b"Hello World")
    tmp_file.flush()

    # Get the checksum of the file
    file_checksum = checksum(tmp_file.name)

    # Get the checksum of the data
    data_checksum = checksum_s("Hello World")

    # Assert that the checksums are the same
    assert file_checksum == data_checksum

    # Close the temporary file
    tmp_file.close()

# Generated at 2022-06-17 15:12:54.931008
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:59.845729
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:03.179390
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:09.396873
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:13.928555
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'c6f1a9f5d5c2e0b6c8e8d3a5c6d0a3d4'


# Generated at 2022-06-17 15:13:16.603423
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:18.760272
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:20.582168
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:23.838089
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls') == 'e2a3c01489af4f933d8ab0d2611d53e7'


# Generated at 2022-06-17 15:13:33.658365
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create a file
    f = open('foo', 'w')
    f.write('foobar')
    f.close()

    # Check the md5
    assert md5('foo') == '3858f62230ac3c915f300c664312c63f'

    # Remove the temporary directory
    os.chdir(curdir)
    shutil.rmtree(tmpdir)


# Generated at 2022-06-17 15:13:44.696468
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test.txt"), "w")
    f.write("Hello World")
    f.close()

    # Test md5
    assert md5(os.path.join(tmpdir, "test.txt")) == "ed076287532e86365e841e92bfc50d8c"

    # Remove the directory after the test
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:13:55.709506
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '914f244f079e620f3ebd1794d3c949a5'
    assert md5s('hello\n\n') == 'c7ad44cbad762a5da0a452f9e854fdc1'
    assert md5s('hello\n\n\n') == 'e59ff97941044f85df5297e1c302d260'
    assert md5s('hello\n\n\n\n') == '944cd2847fb54558d4775db0485a5000'