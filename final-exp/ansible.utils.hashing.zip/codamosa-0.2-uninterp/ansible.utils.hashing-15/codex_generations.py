

# Generated at 2022-06-17 15:04:10.460566
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '4b7dbb03115cbbd2a0efb9a4b30aee50'
    assert checksum('/bin/ls', hash_func=_md5) == 'f9d7ee9a9f5a0f4d8d77b0c8b315b8d7'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-17 15:04:19.507591
# Unit test for function checksum
def test_checksum():
    '''
    ansible core: checksum module
    '''
    import os
    import tempfile

    (fd, fname) = tempfile.mkstemp()
    os.write(fd, b"hello")
    os.close(fd)

    assert checksum(fname) == checksum_s("hello")
    assert checksum_s("hello") == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s("hello") == md5s("hello")
    assert checksum(fname) == md5(fname)
    os.unlink(fname)

# Generated at 2022-06-17 15:04:27.189361
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n\r\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:04:34.414471
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Test checksum function '''

    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test"), "wb")
    f.write(b"foo")
    f.close()

    # Check if the checksum of the file matches
    assert checksum(os.path.join(tmpdir, "test")) == "acbd18db4cc2f85cedef654fccc4a4d8"

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:04:47.063985
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0e966c7a73c8d090dccb8815'
    assert checksum('/bin/ls', hash_func=_md5) == 'b9a1f9e8d13b40913e9969b0e0ea6a8b'
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:04:56.796610
# Unit test for function md5
def test_md5():
    test_string = "This is a test string"
    test_file = "test_file"
    f = open(test_file, "w")
    f.write(test_string)
    f.close()
    assert md5(test_file) == "e2c569be17396eca2a2e3c11578123ed"
    assert md5s(test_string) == "e2c569be17396eca2a2e3c11578123ed"
    os.remove(test_file)

# Generated at 2022-06-17 15:05:04.258920
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile
    import shutil
    from ansible.module_utils.basic import AnsibleModule

    def cleanup(tmpdir):
        shutil.rmtree(tmpdir)

    def run_module(module_args):
        module_args.update(dict(
            path=tmpdir + '/testfile',
        ))
        module = AnsibleModule(
            argument_spec=dict(
                path=dict(required=True),
            ),
            supports_check_mode=True,
        )
        module.exit_json(**module.run_command('checksum', module_args))


# Generated at 2022-06-17 15:05:13.543286
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9e3eb94cdb7c9a0e64d379'
    assert checksum('/bin/ls', hash_func=_md5) == 'f1c20f07b280f9e0e00d52202c0f250b'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5

# Generated at 2022-06-17 15:05:16.590827
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:05:21.185370
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5('/etc/passwd') == 'd7b0c7f0e7b0c7f0e7b0c7f0e7b0c7f0'

# Generated at 2022-06-17 15:05:34.232110
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '4b7dbb062e6d902c5a7e8967b8b4a94e'
    assert checksum('/bin/ls', hash_func=_md5) == 'f8dff7f7d1a8e7dcdc6a5a79d98507d3'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:05:45.918826
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path=dict(required=True, type='path'),
            checksum=dict(required=True, type='str'),
        ),
        supports_check_mode=True
    )

    path = module.params['path']
    checksum = module.params['checksum']

    # Create a temp file
    (fd, fname) = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the file
    fd = open(fname, 'w')
    fd.write('Hello World\n')
    fd.close()



# Generated at 2022-06-17 15:05:58.192679
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\nworld') == 'fcea920f7412b5da7be0cf42b8c93759'
    assert md5s('hello\nworld\n') == 'fcea920f7412b5da7be0cf42b8c93759'
    assert md5s('hello\nworld\n\n') == 'fcea920f7412b5da7be0cf42b8c93759'

# Generated at 2022-06-17 15:06:06.085360
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'


# Generated at 2022-06-17 15:06:09.093005
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == md5s('test')
    assert md5s('test') != md5s('test2')


# Generated at 2022-06-17 15:06:12.563913
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:06:22.392256
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == md5('test')
    assert md5s('test') == md5s('test')
    assert md5('test') == md5('test')
    assert md5s('test') != md5s('test2')
    assert md5('test') != md5('test2')
    assert md5s('test') != md5('test2')
    assert md5('test') != md5s('test2')
    assert md5s('test') != 'test'
    assert md5('test') != 'test'
    assert md5s('test') != 'test2'
    assert md5('test') != 'test2'

# Generated at 2022-06-17 15:06:31.382807
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:06:35.074004
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'


# Generated at 2022-06-17 15:06:45.658583
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5s('hello') != md5s('hello ')
    assert md5s('hello') != md5s('hello\n')
    assert md5s('hello') != md5s('hello\r')
    assert md5s('hello') != md5s('hello\r\n')
    assert md5s('hello') != md5s('hello\n\r')
    assert md5s('hello') != md5s('hello\r\n\r\n')

# Generated at 2022-06-17 15:06:51.464929
# Unit test for function md5
def test_md5():
    '''
    Test md5 function
    '''
    assert md5('/etc/passwd') == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-17 15:06:54.672798
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')


# Generated at 2022-06-17 15:06:56.559933
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:06:58.590881
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c8f5cddcd651a3d31'


# Generated at 2022-06-17 15:07:02.202543
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf1f9b012e608de2cdad8c2f86'


# Generated at 2022-06-17 15:07:04.823007
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c5f497dbbfa0fe192'


# Generated at 2022-06-17 15:07:11.014918
# Unit test for function checksum
def test_checksum():
    # Create a temporary file
    import tempfile
    import shutil
    import os
    tmpdir = tempfile.mkdtemp()
    testfile = os.path.join(tmpdir, "testfile")
    with open(testfile, 'w') as f:
        f.write("Hello world")
    # Check that the checksum is correct
    assert checksum(testfile) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    # Cleanup
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:07:21.354348
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
   

# Generated at 2022-06-17 15:07:24.655741
# Unit test for function md5
def test_md5():
    ''' md5 unit test '''
    assert md5('/bin/ls') == 'c8d11180c937c2e9ff8e790123f8e5af'


# Generated at 2022-06-17 15:07:26.696407
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f8d09af95e7f0c11d8e38b1'


# Generated at 2022-06-17 15:07:32.475116
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:07:44.337371
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for ansible.utils.checksum '''

    import tempfile

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('test')
    f.close()

    # Check that the checksum of the file matches the expected value
    assert checksum(temp_path) == '098f6bcd4621d373cade4e832627b4f6'

    # Remove the temporary file
    os.remove(temp_path)

# Generated at 2022-06-17 15:07:52.327059
# Unit test for function checksum
def test_checksum():
    '''
    ansible.utils.checksum test
    This is not a complete test, but it will at least run the function
    '''
    assert checksum('/bin/ls') == '6b8e3eaf9480de5d7a0cdad8e0d29a9d'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:08:00.504350
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf9dfbaa0c0354bb5f9a3ecbe6'
    assert checksum('/bin/ls', sha1) == '6b8e3eaf9dfbaa0c0354bb5f9a3ecbe6'
    assert checksum('/bin/ls', _md5) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls')

# Generated at 2022-06-17 15:08:12.013892
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eafb22cee0e9b04a7d7b0aa9e3f'
    assert checksum('/bin/ls', hash_func=_md5) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:08:22.379811
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the temporary file
    with open(temp_path, 'w') as f:
        f.write('Hello World')

    # Create a module
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='str'),
            algorithm=dict(required=False, type='str', default='sha1', choices=['sha1', 'md5']),
        ),
        supports_check_mode=True
    )

    # Run the checksum module


# Generated at 2022-06-17 15:08:33.436143
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "4a0a3d63c9fad3a8d3fca295bcbcc6c5"
    assert md5("/bin/cat") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5("/bin/cat") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5("/bin/cat") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5("/bin/cat") == "d41d8cd98f00b204e9800998ecf8427e"

# Generated at 2022-06-17 15:08:46.427546
# Unit test for function md5
def test_md5():
    ''' md5 should return the same value as md5sum command line tool '''
    import tempfile
    import subprocess

    test_file = tempfile.NamedTemporaryFile()
    test_file.write(b"Hello World")
    test_file.flush()

    p = subprocess.Popen(['md5sum', test_file.name], stdout=subprocess.PIPE)
    out, err = p.communicate()
    md5sum_value = out.split()[0]

    test_file.seek(0)
    md5_value = md5(test_file.name)

    assert md5_value == md5sum_value
    test_file.close()

# Generated at 2022-06-17 15:08:52.385634
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5('test/unit/utils/test_md5.py')

# Generated at 2022-06-17 15:08:54.341004
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:09:07.721954
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '4b7dbb03115cbbd2d3aeba2dcdad9a5c'
    assert checksum('/bin/ls', hash_func=_md5) == '9f9a3f5e3c8d2c3f7b894e9b31f1e9d6'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:09:18.955107
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\n') == '6f5902ac237024bdd0c176cb93063dc4'
    assert md5s(b'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(b'hello world\n') == '6f5902ac237024bdd0c176cb93063dc4'
    assert md5s(u'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:09:27.245593
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')


# Generated at 2022-06-17 15:09:37.112555
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s(u'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s(b'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s(bytearray(b'foo')) == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s(u'\u2713') == 'e0d42c6e9a6a8a6a8c6e42e0d4c6e9a6'

# Generated at 2022-06-17 15:09:40.956462
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f8d23206f47e0e83e3d3020'


# Generated at 2022-06-17 15:09:50.908433
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\n\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'

# Generated at 2022-06-17 15:09:52.596593
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-17 15:09:54.240587
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:09:55.826367
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:10:05.872763
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "testfile"), "w")
    f.write("test")
    f.close()
    # Calculate the md5 checksum
    md5sum = md5(os.path.join(tmpdir, "testfile"))
    # Remove the temporary directory
    shutil.rmtree(tmpdir)
    # Assert that the md5 checksum is correct
    assert md5sum == "098f6bcd4621d373cade4e832627b4f6"

# Generated at 2022-06-17 15:10:11.718974
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0e5fe84ad3518c9c496e8f8f9b'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:10:17.886727
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_checksum')

    with open(test_file, 'w') as f:
        f.write('test')

    assert checksum(test_file) == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:10:20.160675
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:10:29.316560
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == 'f71c27109c692c1b56bbdceb5b9d2865b3708dbc'

# Generated at 2022-06-17 15:10:33.714822
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:10:41.392798
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5('/bin/ls') == 'b8d8f8c6a7f9e9d9b7c7d7b7f8f7e8e8'


# Generated at 2022-06-17 15:10:44.524711
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'f6d7e1e8e1e68d8c61a7ea0c63d3fea0'


# Generated at 2022-06-17 15:10:51.922974
# Unit test for function md5
def test_md5():
    test_file = 'test_md5'
    test_data = 'test_data'
    with open(test_file, 'w') as f:
        f.write(test_data)
    assert md5(test_file) == 'e2c569be17396eca2a2e3c11578123ed'
    assert md5s(test_data) == 'e2c569be17396eca2a2e3c11578123ed'
    os.remove(test_file)

# Generated at 2022-06-17 15:11:00.503421
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0dac6b8e3e2e0dac6b8e3e2e0dac6b8e'
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert md5('/bin/ls') == '6b8e3e2e0dac6b8e3e2e0dac6b8e3e2e0dac6b8e'
    assert md5s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

# Generated at 2022-06-17 15:11:03.811374
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:11:12.211855
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '4f7f0d8a8b7a0b36e0d1c9a0d5f27a9e'


# Generated at 2022-06-17 15:11:23.381231
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0e2d251d9a8f2a47f9736e1957'
    assert checksum('/bin/ls', sha1) == '6b8e3e0e2d251d9a8f2a47f9736e1957'
    assert checksum('/bin/ls', _md5) == '6b8e3e0e2d251d9a8f2a47f9736e1957'
    assert checksum('/bin/ls', 'sha1') == '6b8e3e0e2d251d9a8f2a47f9736e1957'

# Generated at 2022-06-17 15:11:31.205129
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e1ffdac8c47a8e0c38f6a1d7e4a'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:11:40.612854
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s(u'test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s(b'test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s(b'\xc3\xbc') == 'fcbef7a0e0f0f7bdd5f9f6f8c6d6a0c7'
    assert md5s(u'\xfc') == 'fcbef7a0e0f0f7bdd5f9f6f8c6d6a0c7'

# Generated at 2022-06-17 15:11:48.692944
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b7b338a0f0a4039ac1a1a6b7f0caebeb'
    assert md5('/bin/cat') == 'e5b2a1c8f05e2e530a3f1d16e8b0eee3'
    assert md5('/bin/grep') == '7a7dee472f0c626e3a9564f1f38d6a8a'
    assert md5('/bin/pwd') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/sleep') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-17 15:11:52.811159
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:12:01.638066
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5s('hello') != md5s('helloo')
    assert md5s('hello') != md5s('hell')
    assert md5s('hello') != md5s('he')
    assert md5s('hello') != md5s('h')
    assert md5s('hello') != md5s('he')
    assert md5s('hello') != md5s('hell')
    assert md5s('hello') != md5s('helloo')
    assert md5s('hello') != md5s('hello2')
    assert md5s

# Generated at 2022-06-17 15:12:04.323349
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:06.465468
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:12:09.047595
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b7a875fc1ea228b9061041b7cec4bd3c'


# Generated at 2022-06-17 15:12:14.262321
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:12:16.372369
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b5a3a7f8f9e5dbaa1a9f0f7b26aa5249'


# Generated at 2022-06-17 15:12:23.543662
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:29.973157
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test')
    assert md5(test_file) == '098f6bcd4621d373cade4e832627b4f6'
    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:12:37.466985
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create a file
    f = open('foo', 'w')
    f.write('foo')
    f.close()

    # Check the md5 checksum
    assert md5('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

    # Remove the temporary directory
    os.chdir(curdir)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:12:39.123987
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:42.505529
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:49.333608
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '914f244f079a634e7c7cde4c95b63ca1'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('\n') == '68b329da9893e34099c7d8ad5cb9c940'
    assert md5s('\r\n') == '68b329da9893e34099c7d8ad5cb9c940'

# Generated at 2022-06-17 15:12:59.622114
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\nworld') == 'fc5e038d38a57032085441e7fe7010b0'
    assert md5s('hello\nworld\n') == 'fc5e038d38a57032085441e7fe7010b0'

# Generated at 2022-06-17 15:13:11.413009
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5s('hello') != md5s('helloo')
    assert md5s('hello') != md5s('hell')
    assert md5s('hello') != md5s('he')
    assert md5s('hello') != md5s('h')
    assert md5s('hello') != md5s('h')
    assert md5s('hello') != md5s('h')
    assert md5s('hello') != md5s('h')
    assert md5s('hello') != md5s('h')

# Generated at 2022-06-17 15:13:16.900900
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:24.736154
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d5ae7d13d7f8ff9ca'
    assert md5('/bin/cat') == 'd3b07384d113edec49eaa6238ad5ff00'
    assert md5('/bin/grep') == '1f74ad18f9a8f05c6e0c1459d3e3c60b'
    assert md5('/bin/pwd') == '9c8e7dacd4f4c7f6d7c1c7b6dd3c97b5'
    assert md5('/bin/sleep') == 'f7f0f0e3d9b3c2ab6a5d43e4c902fcf4'


# Generated at 2022-06-17 15:13:28.376416
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:36.160643
# Unit test for function md5
def test_md5():
    '''
    ansible.utils.md5 unit test
    '''
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_file_contents = 'test'

    try:
        with open(test_file, 'w') as f:
            f.write(test_file_contents)

        assert md5(test_file) == '098f6bcd4621d373cade4e832627b4f6'
    finally:
        shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:13:46.846035
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'f2a7c9117e4d0c1cf75d4b35f35147d6b949ccd8'
    assert checksum('/bin/ls', hash_func=_md5) == 'f2a7c9117e4d0c1cf75d4b35f35147d6b949ccd8'
    assert checksum('/bin/ls', hash_func=sha1) == 'f2a7c9117e4d0c1cf75d4b35f35147d6b949ccd8'
    assert checksum('/bin/ls', hash_func=sha1) == checksum('/bin/ls')

# Generated at 2022-06-17 15:13:56.709595
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '31d6cfe0d16ae931b73c59d7e0c089c0'
    assert md5s('quux') == 'ab56b4d92b40713acc5af89985d4b786'