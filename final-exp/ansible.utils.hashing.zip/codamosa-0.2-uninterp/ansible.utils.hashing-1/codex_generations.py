

# Generated at 2022-06-17 15:04:04.224160
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:04:09.306860
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n\r\n\r\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:04:10.853003
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:04:21.365563
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n\r\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:04:24.973532
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == md5s('test')
    assert md5s('test') != md5s('test2')


# Generated at 2022-06-17 15:04:34.163356
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf0afb3e95b9d17bbc8ce3b8bf'
    assert checksum('/bin/ls', hash_func=_md5) == 'f8dff4a3d5d3daffef4a1d52b5a6719e'
    assert checksum('/bin/ls', hash_func=sha1) == '6b8e3eaf0afb3e95b9d17bbc8ce3b8bf'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-17 15:04:37.521451
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:04:48.209744
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\r') == 'b1946ac92492d2347c6235b4d2611184'
    assert md5s('hello\r\n') == '68b329da9893e34099c7d8ad5cb9c940'
    assert md5s('hello\r\n\r\n') == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'

# Generated at 2022-06-17 15:04:59.565538
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0a8d7dc1deeb7c9fbbf45b4d'
    assert checksum('/bin/ls', hash_func=_md5) == '4f7dbc1b33f9b9f9d61e4d4ff5a8e0d7'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:05:04.509269
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "6b890caf0f1e3b6b7a5f959d1cda6c0a"


# Generated at 2022-06-17 15:05:10.878451
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "6b8be1b7bca15c085de5f2b735f0aa63"


# Generated at 2022-06-17 15:05:20.970899
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf88ec2e36e1ad8a0c5efb4cad'
    assert checksum('/bin/ls', sha1) == '6b8e3eaf88ec2e36e1ad8a0c5efb4cad'
    assert checksum('/bin/ls', sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls', sha1)
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls', sha1)

# Generated at 2022-06-17 15:05:26.214859
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:05:30.098010
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0c7bfbfdb7f17e3e95b0fdf7bd6a0a3a38'


# Generated at 2022-06-17 15:05:33.533048
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\n') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-17 15:05:45.632516
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '914c8e9a1d5fadc6a33a8e112a4a67c2'
    assert md5s('hello\nworld') == 'f9ff92f2630eab6fd602e94d58c38b7c'
    assert md5s('hello\nworld\n') == 'f9ff92f2630eab6fd602e94d58c38b7c'
    assert md5s('hello\nworld\n\n') == 'f9ff92f2630eab6fd602e94d58c38b7c'

# Generated at 2022-06-17 15:05:58.192227
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile
    import shutil
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp(dir=tmpdir)

    # Create a temporary file in the temporary directory
    fd, temp_path2 = tempfile.mkstemp(dir=temp_dir)
    f = os.fdopen(fd, 'w')
   

# Generated at 2022-06-17 15:05:59.961859
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:06:08.231104
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_file_contents = 'This is a test file'
    test_file_checksum = '7b79b431f5c58e3acf2c3885b3f0a8d8'

    # Create a test file
    with open(test_file, 'w') as f:
        f.write(test_file_contents)

    # Test checksum
    assert checksum(test_file) == test_file_checksum

    # Cleanup
    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:06:15.344546
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert checksum('/bin/ls') == 'a7d9f9e3a8f8d9a8e7c3a3e3c8b8a9c9'
    assert checksum('/bin/ls', hash_func=_md5) == 'e2a3f8f8d3d1c2a1e3d3e8c8a9c9a7d9'

# Generated at 2022-06-17 15:06:23.071870
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '6cd3556deb0da54bca060b4c39479839'
    assert md5s('hello\n\n') == '6cd3556deb0da54bca060b4c39479839'
    assert md5s('hello\n\n\n') == '6cd3556deb0da54bca060b4c39479839'
    assert md5s('hello\n\n\n\n') == '6cd3556deb0da54bca060b4c39479839'

# Generated at 2022-06-17 15:06:25.326654
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:06:32.668794
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_file_contents = 'This is a test file'

    with open(test_file, 'w') as f:
        f.write(test_file_contents)

    assert checksum(test_file) == 'b026324c6904b2a9cb4b88d6d61c81d1'
    assert checksum_s(test_file_contents) == 'b026324c6904b2a9cb4b88d6d61c81d1'

    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:06:43.097245
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == 'f8dff79e4b58dbb0d926c3e8d7f1b0d7'
    assert md5s('hello\n\n\n') == 'f8dff79e4b58dbb0d926c3e8d7f1b0d7'
    assert md5s('hello\n\n\n\n') == 'f8dff79e4b58dbb0d926c3e8d7f1b0d7'

# Generated at 2022-06-17 15:06:53.187967
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c5a0dea6a65f4a37c'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat2') is None
    assert md5('/bin/cat2') is None
    assert md5('/bin/cat2') is None
    assert md5('/bin/cat2') is None
    assert md5('/bin/cat2') is None
    assert md5('/bin/cat2') is None
    assert md5('/bin/cat2') is None
    assert md5('/bin/cat2') is None

# Generated at 2022-06-17 15:06:58.122302
# Unit test for function md5
def test_md5():
    '''
    Test md5 function
    '''
    import tempfile
    import shutil
    import os

    try:
        tmpdir = tempfile.mkdtemp()
        test_file = os.path.join(tmpdir, 'test_file')
        with open(test_file, 'w') as f:
            f.write('test')
        assert md5(test_file) == '098f6bcd4621d373cade4e832627b4f6'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:07:06.509919
# Unit test for function md5
def test_md5():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    result = module.from_json(module.run_command('python -c "import hashlib; print hashlib.md5(\'foo\').hexdigest()"'))
    assert result['stdout'] == md5s('foo')
    assert result['stdout'] == md5('lib/ansible/modules/core/system/ping.py')
    assert result['stdout'] != md5('lib/ansible/modules/core/system/copy.py')


# Generated at 2022-06-17 15:07:10.359178
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c5dea6665d29ae3d7'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:07:21.051389
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf0f8a7d44a7385e0d7f0f8021'
    assert checksum('/bin/ls', 'sha1') == '6b8e3eaf0f8a7d44a7385e0d7f0f8021'
    assert checksum('/bin/ls', 'sha256') == 'd5b0a3d5a5d5d5d5d5d5d5d5d5d5d5d5d5d5d5d5d5d5d5d5d5d5d5d5d5d5d5d5'

# Generated at 2022-06-17 15:07:29.800763
# Unit test for function checksum
def test_checksum():
    '''
    ansible.utils.checksum tests
    This module tests the checksum function against known sha1 and md5 hashes
    '''
    import os
    import tempfile

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('Hello World')
    f.close()

    # Calculate the checksum
    sha1_hash = checksum(fname)
    md5_hash = md5(fname)

    # Remove the temporary file
    os.unlink(fname)

    # Assert the checksum
    assert sha1_hash == '0a0a9f2a6772942557ab5355d76af442f8f65e01'
    assert md5_hash

# Generated at 2022-06-17 15:07:46.128344
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'e2c569be17396eca2a2e3c11578123ed'
    assert md5s('hello\n\n') == 'c7ef86a6d961c6b0c3cea723f8e26f17'
    assert md5s('hello\n\n\n') == 'e64f922d149c8f33e64f922d149c8f33'
    assert md5s('hello\n\n\n\n') == 'e64f922d149c8f33e64f922d149c8f33'

# Generated at 2022-06-17 15:07:57.626976
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n\r\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:08:09.826456
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf66e170b5c5f43208d9c0a194'
    assert checksum('/bin/ls', hash_func=_md5) == 'c4d8dce5f7b5aaffaa9c7d43b5d564a6'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:08:20.712709
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile
    import shutil
    import sys

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write data to the temporary file
    with open(temp_path, 'wb') as f:
        f.write(b"Hello World")

    # Create a temporary directory
    temp_dir_path = os.path.join(tmpdir, "temp_dir")
    os.mkdir(temp_dir_path)

    # Create a temporary file in the temporary directory
    f

# Generated at 2022-06-17 15:08:27.812446
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls') == 'c8d11180c8a8cad1f6210c92d48860d2'

# Generated at 2022-06-17 15:08:35.315220
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum('test/utils/checksum.py') == 'c9f9a9e8b7e8d9f5c7f5e5b3b7e5e5f9'
    assert checksum('test/utils/checksum.py', hash_func=_md5) == 'c9f9a9e8b7e8d9f5c7f5e5b3b7e5e5f9'

# Generated at 2022-06-17 15:08:45.246397
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'


# Generated at 2022-06-17 15:08:54.624420
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test"), "wb")
    f.write(b"foo")
    f.close()

    # Test md5
    assert md5(os.path.join(tmpdir, "test")) == "acbd18db4cc2f85cedef654fccc4a4d8"

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:09:00.544488
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d6a1e5d3d7a0f4e3c'


# Generated at 2022-06-17 15:09:08.588303
# Unit test for function checksum
def test_checksum():
    ''' test checksum '''

    import tempfile

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the file
    f = open(fname, 'wb')
    f.write(b'hello')
    f.close()

    # Check the checksum
    assert checksum(fname) == '5d41402abc4b2a76b9719d911017c592'

    # Remove the temporary file
    os.unlink(fname)

# Generated at 2022-06-17 15:09:13.603152
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:09:22.701288
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test')
    try:
        assert md5(test_file) == '098f6bcd4621d373cade4e832627b4f6'
    finally:
        shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:09:26.609552
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(bytearray(b'hello')) == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:09:31.170838
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '4b7dbb03115cbbd5a5c7f0a7d4a8b0c1e3f0cc4a'
    assert checksum('/bin/ls', sha1) == '4b7dbb03115cbbd5a5c7f0a7d4a8b0c1e3f0cc4a'
    assert checksum('/bin/ls', _md5) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert checksum('/bin/ls', 'sha1') == '4b7dbb03115cbbd5a5c7f0a7d4a8b0c1e3f0cc4a'

# Generated at 2022-06-17 15:09:35.652183
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "6b89032e8f299c010bcaa0c1a5fda31b"


# Generated at 2022-06-17 15:09:48.610230
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

# Generated at 2022-06-17 15:09:53.337866
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "b8d8c3f3a9a8a9d9b8d8c3f3a9a8a9d9"
    assert md5("/bin/cat") == "b8d8c3f3a9a8a9d9b8d8c3f3a9a8a9d9"
    assert md5("/bin/cat") == "b8d8c3f3a9a8a9d9b8d8c3f3a9a8a9d9"
    assert md5("/bin/cat") == "b8d8c3f3a9a8a9d9b8d8c3f3a9a8a9d9"

# Generated at 2022-06-17 15:09:59.734880
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\nworld\n') == 'f9d5f7a0d5ef8d7d8e7d8a4c4c7f3fba'
    assert md5s('hello\nworld\nfoo\nbar\n') == 'f9d5f7a0d5ef8d7d8e7d8a4c4c7f3fba'

# Generated at 2022-06-17 15:10:01.810226
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:10:05.746229
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:10:10.295485
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:10:12.351562
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:10:14.512514
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf9480b98875de5c9b0c3829d4'


# Generated at 2022-06-17 15:10:20.871561
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile
    import shutil
    import stat

    from ansible.module_utils.basic import AnsibleModule

    def test_checksum_file(filename, checksum):
        ''' test_checksum_file:  Checks the checksum of a file '''

        module = AnsibleModule(
            argument_spec = dict(
                path = dict(required=True),
                checksum = dict(required=True),
            ),
            supports_check_mode=True
        )

        module.exit_json(changed=False, checksum=checksum, path=filename)

    def test_checksum_string(string, checksum):
        ''' test_checksum_string:  Checks the checksum of a string '''

# Generated at 2022-06-17 15:10:23.473860
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "4d186321c1a7f0f354b297e8914ab240"


# Generated at 2022-06-17 15:10:25.836903
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "f3a9a7c8e0d3d5f5a5b3a2d8d5f5a5b3"


# Generated at 2022-06-17 15:10:28.158993
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:10:37.030590
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for ansible.utils.checksum '''

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class TestChecksum(unittest.TestCase):

        @patch('ansible.utils.checksum.secure_hash')
        def test_checksum_calls_secure_hash(self, mock_secure_hash):
            mock_secure_hash.return_value = 'foo'
            filename = 'bar'
            checksum(filename)
            mock_secure_hash.assert_called_with(filename)


# Generated at 2022-06-17 15:10:47.850971
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(delete=False)
    tmpfile.write(b"Hello World")
    tmpfile.close()

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file in the temporary directory
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpfile2.write(b"Hello World")
    tmpfile2.close()

    # Create a temporary file in the temporary directory
    tmpfile3 = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)


# Generated at 2022-06-17 15:10:58.223719
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '4a8f213e2c18b11500222f2131f5d0f5cab5cd4b'
    assert checksum('/bin/ls', sha1) == '4a8f213e2c18b11500222f2131f5d0f5cab5cd4b'
    assert checksum('/bin/ls', _md5) == 'c8d11180c9c2f105f49c2cfb8a3fda96'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls') == md5('/bin/ls')
    assert checksum('/bin/ls') == checksum('/bin/ls', sha1)

# Generated at 2022-06-17 15:11:04.481722
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c5f497db3f6c8b0e4'


# Generated at 2022-06-17 15:11:11.561679
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf9480de5d7a06e2b749b25c50'
    assert checksum('/bin/ls', hash_func=_md5) == 'a3f4c9bfb9cdea0c1e7d4f9e9e8cd8b1'
    assert checksum('/bin/ls', hash_func=sha1) == '6b8e3eaf9480de5d7a06e2b749b25c50'
    assert checksum('/bin/ls', hash_func=sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls', hash_func=_md5) == checksum('/bin/ls', hash_func=_md5)

# Generated at 2022-06-17 15:11:20.885454
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n\r\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:11:28.530679
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file for testing
    (handle, fname) = tempfile.mkstemp()
    f = os.fdopen(handle, 'w')
    f.write('hello')
    f.close()

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
        ),
        supports_check_mode=True
    )

    # Get the checksum
    result = module.run_command(['sha1sum', fname])

# Generated at 2022-06-17 15:11:39.719150
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\n') == 'e59ff97941044f85df5297e1c302d260'
    assert md5s('hello\nworld') == '7f83b1657ff1fc53b92dc18148a1d65d'
    assert md5s('hello\nworld\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'

# Generated at 2022-06-17 15:11:41.784176
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:11:43.644663
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:11:54.386974
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b'


# Generated at 2022-06-17 15:11:58.004353
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f0bf94b229379540f23f820'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:08.267566
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5s('hello') != md5s('helloo')
    assert md5s('hello') != md5s('hell')
    assert md5s('hello') != md5s('hello ')
    assert md5s('hello') != md5s('hello\n')
    assert md5s('hello') != md5s('hello\r')
    assert md5s('hello') != md5s('hello\r\n')
    assert md5s('hello') != md5s('hello\t')
    assert md5s('hello') != md5s

# Generated at 2022-06-17 15:12:18.763277
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum functions '''

    import os
    import tempfile
    import shutil

    from ansible.module_utils.basic import AnsibleModule

    def _create_test_file(path, content):
        ''' Create a test file with the given content '''
        f = open(path, 'w')
        f.write(content)
        f.close()

    def _remove_test_file(path):
        ''' Remove the test file '''
        os.remove(path)

    def _create_test_dir(path):
        ''' Create a test directory '''
        os.mkdir(path)

    def _remove_test_dir(path):
        ''' Remove the test directory '''
        shutil.rmtree(path)


# Generated at 2022-06-17 15:12:22.508236
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:12:25.118166
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c5dea6665e3d824b6'


# Generated at 2022-06-17 15:12:29.345026
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == md5s('test')
    assert md5s('test') != md5s('test2')


# Generated at 2022-06-17 15:12:35.819958
# Unit test for function md5
def test_md5():
    # Create a temporary file
    import tempfile
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write("hello")
    f.close()

    # Calculate the md5 checksum
    m = md5(fname)

    # Remove the temporary file
    os.remove(fname)

    # Verify the checksum
    assert m == "5d41402abc4b2a76b9719d911017c592"

# Generated at 2022-06-17 15:12:42.959135
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''
    import tempfile
    import os
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Write some data to the temporary file
    tmpfile.write(b"This is some data")
    tmpfile.flush()
    # Get the checksum of the file
    checksum_value = checksum(tmpfile.name)
    # Remove the temporary directory
    shutil.rmtree(tmpdir)
    # Check if the checksum is correct

# Generated at 2022-06-17 15:12:52.481619
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\n\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'

# Generated at 2022-06-17 15:13:00.219903
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_file_contents = 'test'
    with open(test_file, 'w') as f:
        f.write(test_file_contents)

    test_file_checksum = checksum(test_file)
    test_file_checksum_s = checksum_s(test_file_contents)

    assert test_file_checksum == test_file_checksum_s

    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:13:06.518087
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9b9aeb8b85d0a1f18978'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat2') is None
    assert md5('/bin/') is None


# Generated at 2022-06-17 15:13:09.175364
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c5fecb6d8dc8f8f2c'


# Generated at 2022-06-17 15:13:16.809777
# Unit test for function md5
def test_md5():
    '''
    Test md5 function
    '''
    assert md5('/etc/passwd') == 'c21f969b5f03d33d43e04f8f136e7682'
    assert md5('/etc/shadow') == '1f2d1e2e68fc302ea7ea8e397c0c5c5c'
    assert md5('/etc/group') == 'a8d3e3a2aeee7a9c7e5a0e5f1d0e5f3c'
    assert md5('/etc/hosts') == '3d7a8c8c9d9c8d8a9a9d8c4a8c9d8c8d'

# Generated at 2022-06-17 15:13:24.791301
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == '81fe8bfe87576c3ecb22426f8e57847382917acf'

# Generated at 2022-06-17 15:13:36.085922
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == '81fe8bfe87576c3ecb22426f8e57847382917acf'

# Generated at 2022-06-17 15:13:39.354736
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:43.448897
# Unit test for function md5s
def test_md5s():
    ''' md5s() returns a string of length 32 '''
    s = md5s('foo')
    assert len(s) == 32


# Generated at 2022-06-17 15:13:49.306884
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/etc/passwd') == 'a9d8a9f8e5b6a7f6d8f8e7a9f8e5b6a7'

# Generated at 2022-06-17 15:13:56.218236
# Unit test for function checksum
def test_checksum():
    test_file = 'test_checksum.txt'
    test_string = 'This is a test string'
    test_string_hash = 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'

    # Create a file with a test string
    with open(test_file, 'w') as f:
        f.write(test_string)

    # Test checksum of a string
    assert checksum_s(test_string) == test_string_hash

    # Test checksum of a file
    assert checksum(test_file) == test_string_hash

    # Clean up
    os.remove(test_file)