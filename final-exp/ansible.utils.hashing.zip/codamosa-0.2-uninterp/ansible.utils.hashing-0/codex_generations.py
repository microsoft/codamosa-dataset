

# Generated at 2022-06-17 15:04:05.962360
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9b3d8cda87bf9b5f2ffc'


# Generated at 2022-06-17 15:04:13.325901
# Unit test for function md5
def test_md5():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\n') == 'e59ff97941044f85df5297e1c302d260'
    assert md5s('hello world\r\n') == 'a1dc9fb8e35b9e5a6d7b0f5a5b5a5b5a'
    assert md5s('hello world\r\n\r\n') == 'a1dc9fb8e35b9e5a6d7b0f5a5b5a5b5a'

# Generated at 2022-06-17 15:04:24.531753
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '4b7dbb45b8f06904cdb88e65f9e0d388'
    assert checksum('/bin/ls', 'sha1') == '4b7dbb45b8f06904cdb88e65f9e0d388'
    assert checksum('/bin/ls', 'sha256') == '9a9e9d9c5f5b5c5d5e5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f'

# Generated at 2022-06-17 15:04:28.833085
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == md5s('test')
    assert md5s('test') != md5s('test2')


# Generated at 2022-06-17 15:04:39.331292
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0e0d88e26fadb5d74783e9305f'
    assert checksum('/bin/ls', hash_func=_md5) == 'c8d11180c9c2f105f49c2d55b48c5faf'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-17 15:04:48.775052
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Create a temporary directory
    dname = tempfile.mkdtemp()

    # Create a temporary file in the directory
    fname2 = os.path.join(dname, 'bar')
    f = open(fname2, 'w')
    f.write('bar')
    f.close()

    # Create a temporary file in the directory
    fname3 = os.path.join(dname, 'baz')

# Generated at 2022-06-17 15:04:52.549434
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:05:01.013417
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:05:11.662418
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0a8d8bc3a7ba3e9fa8e9b9a0e89a7a5f'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5('/bin/ls') == '6b8e3e2e0a8d8bc3a7ba3e9fa8e9b9a0'

# Generated at 2022-06-17 15:05:14.029460
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:05:26.319019
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'e2c569be17396eca2a2e3c11578123ed'
    assert md5s('hello\n\n') == 'f5ffc7e0fbc8dacd9b7e0dd6a5d7e1f4'
    assert md5s('hello\n\n\n') == 'f5ffc7e0fbc8dacd9b7e0dd6a5d7e1f4'

# Generated at 2022-06-17 15:05:29.468428
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"


# Generated at 2022-06-17 15:05:31.948555
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f8d16c37e1b1bd2d485c813'


# Generated at 2022-06-17 15:05:39.548890
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "foo"), "wb")
    f.write(b"foobar")
    f.close()

    # Check if the checksum is correct
    assert checksum(os.path.join(tmpdir, "foo")) == "8843d7f92416211de9ebb963ff4ce28125932878"

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:05:49.240039
# Unit test for function md5
def test_md5():
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abc\n') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abc\n\n') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abc\n\n\n') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abc\n\n\n\n') == '900150983cd24fb0d6963f7d28e17f72'

# Generated at 2022-06-17 15:05:54.946097
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile
    import shutil
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Create a temporary non-regular file
    os.mkfifo(os.path.join(tmpdir, 'fifo'))

    # Create a temporary directory
    os.mkdir(os.path.join(tmpdir, 'dir'))

    # Create a temporary symlink
    os.symlink

# Generated at 2022-06-17 15:06:01.184634
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf0f8d16b8a0e2b7b13b6a0254'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert md5('/bin/ls') == '6b8e3eaf0f8d16b8a0e2b7b13b6a0254'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:06:11.195584
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Test the checksum function
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='path'),
        ),
        supports_check_mode=False,
    )
    module.exit_json(changed=False, checksum=checksum(fname))

    # Remove the temporary file
    os.unlink(fname)



# Generated at 2022-06-17 15:06:22.133575
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0dac6b8e3e2e0dac6b8e3e2e0dac6b8e'
    assert checksum('/bin/ls', hash_func=_md5) == '6b8e3e2e0dac6b8e3e2e0dac6b8e3e2e0dac6b8e'
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:06:25.019134
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3e2e0e906d26f8e76e1d75c8d240'


# Generated at 2022-06-17 15:06:30.483971
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9b7d1b37939796f068f2'


# Generated at 2022-06-17 15:06:41.183982
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\r') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\r\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:06:50.907881
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2c72e3c8e3d8a92af0e6'
    assert checksum('/bin/ls', sha1) == '6b8e3eaf1f9f2c72e3c8e3d8a92af0e6'
    assert checksum('/bin/ls', _md5) == 'c8d11180c20e9b5a9d5d4a8ce725dd47'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum('/bin/ls')

# Generated at 2022-06-17 15:06:53.798987
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9a5dbb1a28ad8345b9a0'


# Generated at 2022-06-17 15:07:01.573107
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
            algorithm = dict(default='sha1', choices=['sha1', 'md5']),
        ),
        supports_check_mode = True
    )

    path = module.params['path']
    algorithm = module.params['algorithm']

    if algorithm == 'md5':
        if _md5:
            checksum_func = md5
        else:
            module.fail_json(msg='MD5 not available.  Possibly running in FIPS mode')
    else:
        checksum_func = checksum

   

# Generated at 2022-06-17 15:07:12.372740
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'e2c569be17396eca2a2e3c11578123ed'
    assert md5s('hello\n\n') == 'f0d4e3c3a8e8d3c2f863db39f8a3aacb'
    assert md5s('hello\n\n\n') == 'a9b3773d9bfc7e0f1cdea3fd44e0c7e0'
    assert md5s('hello\n\n\n\n') == '2f1d0cbd1b5dcfeaefef0f8f7f79e092'
    assert md

# Generated at 2022-06-17 15:07:14.767979
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:07:23.721370
# Unit test for function md5
def test_md5():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5('/bin/ls') == 'f8d9d9a7a2b9f3c7a8d8c8b7b8a8c9d9'
    assert md5('/bin/ls') == 'f8d9d9a7a2b9f3c7a8d8c8b7b8a8c9d9'
    assert md5('/bin/ls') == 'f8d9d9a7a2b9f3c7a8d8c8b7b8a8c9d9'

# Generated at 2022-06-17 15:07:33.705205
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\n') == 'e59ff97941044f85df5297e1c302d260'
    assert md5s('hello world\n\n') == 'a948904f2f0f479b8f8197694b30184b'
    assert md5s('hello world\n\n\n') == 'b7bc5fb91080c7de6b582ea281f8a396'
    assert md5s('hello world\n\n\n\n') == 'f06d69cdc7da0f1f39b672c2951e95fd'

# Generated at 2022-06-17 15:07:46.600210
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == 'f0e4c2f76c58916ec258f246851bea09'
    assert md5s('hello\n\n\n') == 'f0e4c2f76c58916ec258f246851bea09'
    assert md5s('hello\n\n\n\n') == 'f0e4c2f76c58916ec258f246851bea09'

# Generated at 2022-06-17 15:07:58.383032
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "testfile"), "w")
    f.write("This is a test file")
    f.close()

    # Calculate the md5 checksum
    checksum = md5(os.path.join(tmpdir, "testfile"))

    # Remove the directory after the test
    shutil.rmtree(tmpdir)

    assert checksum == "c8fdb181845a4ca6b8fec737b35143eb"

# Generated at 2022-06-17 15:08:01.833913
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'a8b64babd9971442e3e81d26e0cbe931'


# Generated at 2022-06-17 15:08:11.879089
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    test_file = os.path.join(tmpdir, "test_file")
    with open(test_file, "w") as f:
        f.write("Hello World")

    # Calculate the checksum
    checksum_value = checksum(test_file)

    # Remove the directory
    shutil.rmtree(tmpdir)

    # Assert the checksum
    assert checksum_value == "0a4d55a8d778e5022fab701977c5d840bbc486d0"

# Generated at 2022-06-17 15:08:22.345285
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'f6d0e1e50c92eef8b7c5b47b360efcf9'
    assert checksum('/bin/ls', hash_func=_md5) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert checksum('/bin/ls', hash_func=sha1) == 'f6d0e1e50c92eef8b7c5b47b360efcf9'
    assert checksum('/bin/ls', hash_func=_md5) == md5('/bin/ls')
    assert checksum('/bin/ls', hash_func=sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls', hash_func=_md5) == md

# Generated at 2022-06-17 15:08:26.252602
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:08:34.921759
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum functions '''

    import os
    import tempfile
    import shutil
    from ansible.module_utils.basic import AnsibleModule

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a temp file
    (fd, fname) = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Create a temp directory
    dirname = os.path.join(tmpdir, 'foo')
    os.mkdir(dirname)

    # Create a temp symlink
    symlink = os.path.join(tmpdir, 'bar')

# Generated at 2022-06-17 15:08:38.907975
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d8f5e7d76f5fad02e'


# Generated at 2022-06-17 15:08:49.480512
# Unit test for function checksum
def test_checksum():
    import os
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, fname = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('hello')
    f.close()

    # Check that the checksum of the file is correct
    assert checksum(fname) == '5d41402abc4b2a76b9719d911017c592'

    # Check that the checksum of a file that does not exist is None
    assert checksum(fname + '.bad') is None

    # Check that the checksum of a directory is None
    assert checksum(tmpdir) is None

    # Remove the file


# Generated at 2022-06-17 15:08:58.747487
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c8cece768d5f5e2e0'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat2') == None
    assert md5('/bin/cat3') == None
    assert md5('/bin/cat4') == None
    assert md5('/bin/cat5') == None
    assert md5('/bin/cat6') == None
    assert md5('/bin/cat7') == None
    assert md5('/bin/cat8') == None
    assert md5('/bin/cat9') == None
    assert md5('/bin/cat10') == None

# Generated at 2022-06-17 15:09:03.101661
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9b9aebf3b03827bb7c3d'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:09:08.599352
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '4b8e0c5f78dcd95ef1b56f2a471e38a4'


# Generated at 2022-06-17 15:09:17.890669
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '31d6cfe0d16ae931b73c59d7e0c089c0'

# Generated at 2022-06-17 15:09:20.173122
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d6a1e5d3d7a0f4e3c'


# Generated at 2022-06-17 15:09:32.712689
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '4b7dbb03115cbbd2a7f9b0d3eeb0b9c0'
    assert checksum('/bin/ls', sha1) == '4b7dbb03115cbbd2a7f9b0d3eeb0b9c0'
    assert checksum('/bin/ls', _md5) == '4b7dbb03115cbbd2a7f9b0d3eeb0b9c0'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum('/bin/ls')

# Generated at 2022-06-17 15:09:46.347889
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:09:50.527749
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1c1392c38e561c6e0c6c9c'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:09:52.853353
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b8a8f9f3d3d5ef0d3a8f8c9a2a8f5f1f'


# Generated at 2022-06-17 15:09:59.392028
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1d7e2e74b9aaf7b05d6b8fe8'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', _md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', _md5) == md5s('hello')
    assert checksum('/bin/ls', _md5) == '6b8e3eaf1d7e2e74b9aaf7b05d6b8fe8'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')

# Generated at 2022-06-17 15:10:07.549923
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file
    (handle, filename) = tempfile.mkstemp()

    # Write some data to the temporary file
    os.write(handle, b"Hello World")
    os.close(handle)

    # Create a temporary file
    (handle, filename2) = tempfile.mkstemp()

    # Write some data to the temporary file
    os.write(handle, b"Hello World")
    os.close(handle)

    # Create a temporary file
    (handle, filename3) = tempfile.mkstemp()

    # Write some data to the temporary file
    os.write(handle, b"Hello World2")


# Generated at 2022-06-17 15:10:10.119046
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "9a8c8c230a87899fc57c08a07d8e3c3c"


# Generated at 2022-06-17 15:10:20.004557
# Unit test for function checksum
def test_checksum():
    '''
    ansible.utils.checksum - Test checksum function
    '''
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Create a temporary directory
    dname = os.path.join(tmpdir, 'foo')
    os.mkdir(dname)

    # Test checksum function
    assert checksum(fname) == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert checksum(dname) is None

# Generated at 2022-06-17 15:10:22.667613
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:10:30.267443
# Unit test for function md5
def test_md5():
    '''
    ansible.utils.md5 unit test
    '''
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Write some data to the temporary file
    tmpfile.write(b"Hello World")
    # Close the temporary file
    tmpfile.close()

    # Get the md5 checksum of the temporary file
    md5sum = md5(tmpfile.name)

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

    # Assert that the md5 checksum is correct

# Generated at 2022-06-17 15:10:37.930880
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:10:48.169679
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d8ce0c13f0eeadd6e1c'
    assert checksum('/bin/ls', hash_func=_md5) == 'f1d2d2f924e986ac86fdf7b36c94bcdf'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:10:51.076963
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9a3cdad8b21b13e4b060'


# Generated at 2022-06-17 15:10:56.846261
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:11:04.647862
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d5ae3d8f5b0fb0e69'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:11:10.191221
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum functions '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
            content = dict(required=False, type='str'),
        ),
        supports_check_mode=True
    )

    path = module.params['path']
    content = module.params['content']

    if content is not None:
        (fd, path) = tempfile.mkstemp()
        os.write(fd, content)
        os.close(fd)

    if not os.path.exists(path):
        module.fail_json(msg="file not found: %s" % path)

   

# Generated at 2022-06-17 15:11:19.805104
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert checksum('/etc/passwd') == '9f9e9c8c7e0d7bbe1e1a9b7a8b6c9f9d9b9c9e9f'
    assert checksum('/etc/passwd', hash_func=_md5) == '9f9e9c8c7e0d7bbe1e1a9b7a8b6c9f9d'

# Generated at 2022-06-17 15:11:24.672820
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:11:30.675079
# Unit test for function md5
def test_md5():
    ''' md5.py: Test md5 function '''
    from ansible.compat.tests import unittest
    import os

    class TestMd5(unittest.TestCase):

        def setUp(self):
            self.filename = os.path.join(os.path.dirname(__file__), 'test_md5.txt')
            with open(self.filename, 'w') as f:
                f.write('test file for md5\n')

        def tearDown(self):
            os.unlink(self.filename)

        def test_md5_file(self):
            ''' md5: Test md5 function with file '''

# Generated at 2022-06-17 15:11:40.275062
# Unit test for function md5s
def test_md5s():
    '''
    Test md5s function
    '''
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world!') == 'b48b7b8f8e9f0f5b7b0c2b40e17f7f22'
    assert md5s('hello world!!') == '9f9e9d9c9b9a99989796959493929190'
    assert md5s('hello world!!!') == '8f8e8d8c8b8a89888786858483828180'
    assert md5s('hello world!!!!')

# Generated at 2022-06-17 15:11:43.391290
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:11:45.062279
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:11:56.514198
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n\r\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:12:00.607935
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "6b1634cbea5ce2ea9c8f88d99aa08d36"


# Generated at 2022-06-17 15:12:05.261219
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls') == 'b4b5ec18077e7a1f3e737a2d14cbf974'


# Generated at 2022-06-17 15:12:07.371549
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:12:14.847545
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "testfile"), "w")
    f.write("Hello World!")
    f.close()

    # Test md5 function
    assert md5(os.path.join(tmpdir, "testfile")) == "ed076287532e86365e841e92bfc50d8c"

    # Remove the directory after the test
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:12:25.766481
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9b9aeb8b85bbe3f0c2e0'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/doesnotexist') is None
    assert md5('/bin') is None


# Generated at 2022-06-17 15:12:28.549505
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:31.561330
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d8ce0c13f0f22f131eb'


# Generated at 2022-06-17 15:12:39.952518
# Unit test for function md5
def test_md5():
    ''' md5 unit test '''

    from ansible.compat.tests import unittest

    class TestMd5(unittest.TestCase):

        def test_md5(self):
            ''' md5 unit test '''
            self.assertEqual(md5('/bin/ls'), '6b8e3eaf66e170e8e1c2e7d8f4a34d16')
            self.assertEqual(md5('/bin/cat'), 'd41d8cd98f00b204e9800998ecf8427e')
            self.assertEqual(md5('/bin/fake'), None)

        def test_md5s(self):
            ''' md5s unit test '''

# Generated at 2022-06-17 15:12:48.673508
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n\r\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:12:51.596914
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:52.977757
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:57.198449
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('world') == '7d793037a0760186574b0282f2f435e7'


# Generated at 2022-06-17 15:13:06.736031
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0a9f8eef9479a8a5d14efb13a6e0de3b'
    assert checksum('/bin/ls', hash_func=_md5) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:13:13.358527
# Unit test for function md5
def test_md5():
    '''
    Test md5 function
    '''
    test_file = 'test_file'
    test_file_content = 'test_file_content'
    test_file_md5 = 'e2c569be17396eca2a2e3c11578123ed'

    with open(test_file, 'w') as f:
        f.write(test_file_content)

    assert md5(test_file) == test_file_md5

    os.remove(test_file)

# Generated at 2022-06-17 15:13:23.273729
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d8c49f0e03748a4a8c6'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls') == '6b8e3eaf1f9f2d8c49f0e03748a4a8c6'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:13:29.864499
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == '81fe8bfe87576c3ecb22426f8e57847382917acf'

# Generated at 2022-06-17 15:13:38.205427
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:13:47.466273
# Unit test for function md5
def test_md5():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == md5s('hello world')
    assert md5s('hello world') != md5s('hello worle')
    assert md5s('hello world') != md5s('hello worl')
    assert md5s('hello world') != md5s('hello wor')
    assert md5s('hello world') != md5s('hello wo')
    assert md5s('hello world') != md5s('hello w')
    assert md5s('hello world') != md5s('hello ')
    assert md5s('hello world') != md5s('hello')
    assert md5s('hello world') != md5s('hell')
    assert md5s

# Generated at 2022-06-17 15:13:57.168051
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'c3fcd3d76192e4007dfb496cca67e13b'
    assert md5s('hello\nworld') == '65a8e27d8879283831b664bd8b7f0ad4'
    assert md5s('hello\nworld\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\nworld\n\n') == '9e107d9d372bb6826bd81d3542a419d6'