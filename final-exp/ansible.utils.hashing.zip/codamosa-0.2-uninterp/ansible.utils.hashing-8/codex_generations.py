

# Generated at 2022-06-17 15:04:03.232324
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:04:12.583674
# Unit test for function md5
def test_md5():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestMd5(unittest.TestCase):
        def setUp(self):
            self.mock_md5 = patch('ansible.module_utils.basic.md5')
            self.mock_md5.start()

        def tearDown(self):
            self.mock_md5.stop()

        def test_md5_exists(self):
            self.assertTrue(hasattr(basic, 'md5'))

        def test_md5_raises_exception(self):
            self.assertRaises(ValueError, basic.md5, 'filename')

    unittest.main()

# Generated at 2022-06-17 15:04:18.277149
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0c4e6040d5c1d3f4e24f0f94'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:04:21.365534
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == md5s('test')
    assert md5s('test') != md5s('test2')


# Generated at 2022-06-17 15:04:23.576730
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:04:26.365124
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:04:34.600443
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5s('hello') != md5s('helloo')
    assert md5s('hello') != md5s('hell')
    assert md5s('hello') != md5s('h')
    assert md5s('hello') != md5s('he')
    assert md5s('hello') != md5s('hel')
    assert md5s('hello') != md5s('helloo')
    assert md5s('hello') != md5s('hellooo')
    assert md5s('hello') != md5s('helloooo')
    assert md5

# Generated at 2022-06-17 15:04:37.901428
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:04:48.361617
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', _md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum('/bin/ls') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum('/bin/ls', _md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum('/bin/ls', sha1)

# Generated at 2022-06-17 15:04:52.502079
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-17 15:04:56.568707
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:05:04.058387
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\r\r') == '5d41402abc4b2a76b9719d911017c592'
   

# Generated at 2022-06-17 15:05:07.287107
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "6b890caf8a7a2c0b5b99fc8901df8264"


# Generated at 2022-06-17 15:05:10.004835
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:05:13.107337
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:05:19.051347
# Unit test for function md5
def test_md5():
    ''' md5.py: Test md5 function '''

    import tempfile

    # Create a temporary file
    fd, fname = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('test')
    f.close()

    # Check md5
    assert md5(fname) == '098f6bcd4621d373cade4e832627b4f6'

    # Remove temporary file
    os.remove(fname)

# Generated at 2022-06-17 15:05:23.501380
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls') == 'b7a1b8a8a8d6e9c6f9d6b8c7d8f8e8a1'


# Generated at 2022-06-17 15:05:26.360626
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:05:37.258039
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0f1c9e24fdd5c5f6f0d72b5d26'
    assert checksum('/bin/ls', sha1) == '6b8e3e0f1c9e24fdd5c5f6f0d72b5d26'
    assert checksum('/bin/ls', _md5) == '6b8e3e0f1c9e24fdd5c5f6f0d72b5d26'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls')

# Generated at 2022-06-17 15:05:46.780402
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum('/etc/passwd') == 'a3f5b3b2cbf3cb297978b9e7e3f4d174'
    assert checksum('/etc/passwd', hash_func=_md5) == 'a3f5b3b2cbf3cb297978b9e7e3f4d174'

# Generated at 2022-06-17 15:05:55.372812
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5('/bin/ls') == 'b9c7c8f9f9b8a9d6f0b6f8b6c8e8e8d6'

# Generated at 2022-06-17 15:06:05.789642
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == '81fe8bfe87576c3ecb22426f8e57847382917acf'

# Generated at 2022-06-17 15:06:07.959783
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:06:17.700704
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf66e170b8a77ab49b52480c0d'
    assert checksum('/bin/ls', 'sha1') == '6b8e3eaf66e170b8a77ab49b52480c0d'
    assert checksum('/bin/ls', 'sha256') == 'c8d1f1a3c3c0b27f9a4cff26d944b5b8f9faa6be9b6a195c55d4925b0f504100'

# Generated at 2022-06-17 15:06:19.564267
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:06:29.135552
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '4b7dbb03115cbbd5a4d0f251f51e06c4'
    assert checksum('/bin/ls', sha1) == '4b7dbb03115cbbd5a4d0f251f51e06c4'
    assert checksum('/bin/ls', _md5) == '4b7dbb03115cbbd5a4d0f251f51e06c4'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls') == md5('/bin/ls')
    assert checksum('/bin/ls') == checks

# Generated at 2022-06-17 15:06:39.425405
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile
    import shutil

    from ansible.module_utils.basic import AnsibleModule

    def cleanup(tmpdir):
        ''' Cleanup function to remove the temporary directory '''
        shutil.rmtree(tmpdir)

    def run_module(args):
        ''' Utility function to run the module'''

        # Create a temporary directory
        tmpdir = tempfile.mkdtemp()

        # Create a temporary ansible.cfg file
        fd, tmppath = tempfile.mkstemp(dir=tmpdir)
        f = os.fdopen(fd, 'w')
        f.write('[defaults]\nroles_path=%s' % tmpdir)
        f.close

# Generated at 2022-06-17 15:06:49.239602
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'f8d7bf0d3b3a3c9a9f8f8e3d7d2f2b0e'
    assert md5('/bin/cat') == '9d9e8ee8a1a5d4c4d4c7a8e8e9f9f0e0'
    assert md5('/bin/sleep') == 'd4d4d4d4d4d4d4d4d4d4d4d4d4d4d4d4'
    assert md5('/bin/false') == 'c4d4c4d4c4d4c4d4c4d4c4d4c4d4c4d4'

# Generated at 2022-06-17 15:06:58.329464
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, "test_file")
    test_file_contents = "test file contents"

    # Test file does not exist
    assert checksum(test_file) is None

    # Test directory
    assert checksum(test_dir) is None

    # Test file exists
    with open(test_file, "w") as f:
        f.write(test_file_contents)
    assert checksum(test_file) == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"

    # Cleanup
    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:07:01.677263
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:07:17.041218
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b9f2a0e1d3d3b1c5a0f5a7c5d5d5b5d5'
    assert md5('/bin/cat') == 'c8a8a8a8a8a8a8a8a8a8a8a8a8a8a8a8'
    assert md5('/bin/cat') != 'c8a8a8a8a8a8a8a8a8a8a8a8a8a8a8a9'
    assert md5('/bin/cat') != 'c8a8a8a8a8a8a8a8a8a8a8a8a8a8a8'

# Generated at 2022-06-17 15:07:22.246525
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f8d16c37e1d22908e6f8e36'


# Generated at 2022-06-17 15:07:27.543823
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d5ae8c5f5b39f9ebe'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/does-not-exist') is None
    assert md5('/bin') is None


# Generated at 2022-06-17 15:07:34.176793
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == '81fe8bfe87576c3ecb22426f8e57847382917acf'

# Generated at 2022-06-17 15:07:37.635604
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:07:40.904359
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:07:45.901277
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9b9aebf3b0e2c9dec8e3'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat2') is None
    assert md5('/bin/cat3') is None
    assert md5('/bin/cat4') is None
    assert md5('/bin/cat5') is None
    assert md5('/bin/cat6') is None
    assert md5('/bin/cat7') is None
    assert md5('/bin/cat8') is None
    assert md5('/bin/cat9') is None

# Generated at 2022-06-17 15:07:49.013467
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:07:57.300375
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test"), "wb")
    f.write(b"foo")
    f.close()

    # Check if the checksum is correct
    assert checksum(os.path.join(tmpdir, "test")) == "acbd18db4cc2f85cedef654fccc4a4d8"

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:08:05.123371
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'


# Generated at 2022-06-17 15:08:11.581505
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:08:15.495415
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-17 15:08:26.994082
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\r') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\r\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\r\n\r\n') == '8b1a9953c4611296a827abf8c47804d7'

# Generated at 2022-06-17 15:08:35.370329
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == '81fe8bfe87576c3ecb22426f8e57847382917acf'

# Generated at 2022-06-17 15:08:38.136969
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"

# Generated at 2022-06-17 15:08:48.456513
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\n') == 'e59ff97941044f85df5297e1c302d260'
    assert md5s('hello\nworld') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\nworld\n') == '943a702d06f34599aee1f8da8ef9f729'


# Generated at 2022-06-17 15:08:55.145403
# Unit test for function checksum
def test_checksum():
    '''
    ansible.utils.checksum - Test checksum function
    '''

    # Create a temporary file
    import tempfile
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the file
    fd = open(temp_path, 'w')
    fd.write('hello world')
    fd.close()

    # Check the checksum
    assert checksum(temp_path) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    # Remove the temporary file
    os.remove(temp_path)

# Generated at 2022-06-17 15:09:08.458471
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == 'ab07acbb1e496801937adfa772424bf35'

# Generated at 2022-06-17 15:09:12.053658
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-17 15:09:15.960774
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n\r\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:09:22.946600
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "6b1634cbea7d6657f3a8d6559d7edb23"


# Generated at 2022-06-17 15:09:26.609637
# Unit test for function md5
def test_md5():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestMd5(unittest.TestCase):

        @patch('ansible.module_utils.basic.AnsibleModule.fail_json')
        def test_md5_fail(self, fail_json):
            md5('/tmp/test')
            fail_json.assert_called_with(msg='MD5 not available.  Possibly running in FIPS mode')

    unittest.main()

# Generated at 2022-06-17 15:09:34.920255
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0c9fa0afc1fb2b037f8fa5c2e2'
    assert checksum('/bin/ls', sha1) == '6b8e3e0c9fa0afc1fb2b037f8fa5c2e2'
    assert checksum('/bin/ls', _md5) == '6b8e3e0c9fa0afc1fb2b037f8fa5c2e2'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls')
    assert checksum('/bin/ls', _md5) == checksum_

# Generated at 2022-06-17 15:09:47.314364
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:09:54.573582
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0a8a8cadf86e8137e3e3e66c'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == md5s('hello')

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-17 15:10:02.584761
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    try:
        tmpdir = tempfile.mkdtemp()
        testfile = os.path.join(tmpdir, 'testfile')
        with open(testfile, 'w') as f:
            f.write('test')
        assert md5(testfile) == '098f6bcd4621d373cade4e832627b4f6'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:10:10.917692
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile
    import shutil

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp(dir=tmpdir)

    # Create a temporary file in the temporary directory
    fd, temp_path2 = tempfile.mkstemp(dir=temp_dir)
    f = os.fdopen(fd, 'w')
   

# Generated at 2022-06-17 15:10:18.564347
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == '6f5902ac237024bdd0c176cb93063dc4'
    assert md5s('hello\n\n\n') == '6f5902ac237024bdd0c176cb93063dc4'
    assert md5s('hello\n\n\n\n') == '6f5902ac237024bdd0c176cb93063dc4'

# Generated at 2022-06-17 15:10:28.210276
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d8c1a0c8f2d9ca187d9'
    assert checksum('/bin/ls', hash_func=_md5) == '8b3f0e1c7d9a76fcfc8bdd86f75d5ae6'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:10:33.497505
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:10:55.457989
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile
    import shutil

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Create a temporary directory
    dirname = os.path.join(tmpdir, 'foo')
    os.mkdir(dirname)

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp(dir=dirname)

# Generated at 2022-06-17 15:11:03.615469
# Unit test for function md5
def test_md5():
    # Create a file
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('test')
    f.close()

    # Check the md5
    assert md5(fname) == '098f6bcd4621d373cade4e832627b4f6'

    # Remove the file
    os.remove(fname)

# Generated at 2022-06-17 15:11:10.852214
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '6cd3556deb0da54bca060b4c39479839'
    assert md5s('hello\n\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n\n') == '187ef4436122d1cc2f40dc2b92f0eba0'
    assert md5s('hello\n\n\n\n') == 'c20ad4d76fe97759aa27a0c99bff6710'

# Generated at 2022-06-17 15:11:20.197550
# Unit test for function md5
def test_md5():
    ''' md5 unit test '''
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestMd5(unittest.TestCase):
        ''' Test md5 function '''

        def setUp(self):
            pass

        def tearDown(self):
            pass

        @patch('ansible.module_utils.basic.md5')
        def test_md5_exception(self, mock_md5):
            ''' Test md5 exception '''
            mock_md5.side_effect = ValueError('MD5 not available.  Possibly running in FIPS mode')
            self.assertRaises(ValueError, md5, 'filename')


# Generated at 2022-06-17 15:11:22.464409
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "4f7f1e2d8d0e1fbd2a9d14c114096f9e"


# Generated at 2022-06-17 15:11:24.985622
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b8d8b8e9a9a9f9f8e8d8d8e8e9e9e9e8'


# Generated at 2022-06-17 15:11:33.783693
# Unit test for function md5
def test_md5():
    ''' md5 should return the same value as md5sum command '''
    import tempfile
    import subprocess

    (fd, fname) = tempfile.mkstemp()
    os.write(fd, b"hello world")
    os.close(fd)

    try:
        md5_value = md5(fname)
        md5sum_value = subprocess.check_output(["md5sum", fname]).split()[0]
        assert md5_value == md5sum_value
    finally:
        os.unlink(fname)

# Generated at 2022-06-17 15:11:37.732757
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:11:43.174917
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    else:
        try:
            md5s('test')
            assert False
        except ValueError:
            pass

# Generated at 2022-06-17 15:11:49.424474
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create a file
    f = open('foo', 'w')
    f.write('foo')
    f.close()

    # Check the md5
    assert md5('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

    # Remove the temporary directory
    os.chdir(curdir)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:12:02.289491
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:12:05.614133
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '4f3e5c8d7e0d7c8a94c385b5d3d7c3d7'


# Generated at 2022-06-17 15:12:09.859330
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls') == '8e8e7b9e9b9e9e8e8e8e8e8e8e8e8e8e'

# Generated at 2022-06-17 15:12:18.226329
# Unit test for function md5s
def test_md5s():
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abc\n') == 'e2fc714c4727ee9395f324cd2e7f331f'
    assert md5s('abc\n\n') == 'a9c9e4f4a7d0c4a8b9f8efb0e3b3f5e9'
    assert md5s('abc\n\n\n') == 'b7c9e4f4a7d0c4a8b9f8efb0e3b3f5e9'

# Generated at 2022-06-17 15:12:22.222741
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:31.825228
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'e2c569be17396eca2a2e3c11578123ed'
    assert md5s('hello\n\n') == 'f9ffa1b085d4e00a73b17c6d1bb8f8b4'
    assert md5s('hello\n\n\n') == 'f9ffa1b085d4e00a73b17c6d1bb8f8b4'
    assert md5s('hello\n\n\n\n') == 'f9ffa1b085d4e00a73b17c6d1bb8f8b4'
    assert md5

# Generated at 2022-06-17 15:12:36.268466
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5s('hello') != md5s('helloo')
    assert md5s('hello') != md5s('hell')


# Generated at 2022-06-17 15:12:38.437346
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c5f497db3f98faaf4'


# Generated at 2022-06-17 15:12:41.778894
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:12:49.158985
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile
    import shutil

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Create a temporary file
    fd, temp_path2 = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('bar')
    f.close()

    # Create a temporary file
    fd, temp_path3 = temp

# Generated at 2022-06-17 15:13:03.869737
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:12.245027
# Unit test for function md5
def test_md5():
    ''' md5.py: Test md5 function '''

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestMd5(unittest.TestCase):

        @patch('ansible.module_utils.basic.AnsibleModule.fail_json')
        def test_md5_fail(self, fail_json):
            md5('/etc/passwd')
            fail_json.assert_called_with(msg='MD5 not available.  Possibly running in FIPS mode')

    unittest.main()

# Generated at 2022-06-17 15:13:19.078603
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf9d0e9b8cfb0b9d187c8e22f2'
    assert checksum('/bin/ls', sha1) == '6b8e3eaf9d0e9b8cfb0b9d187c8e22f2'
    assert checksum('/bin/ls', _md5) == '6b8e3eaf9d0e9b8cfb0b9d187c8e22f2'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')


# Generated at 2022-06-17 15:13:25.052815
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "testfile"), "w")
    f.write("test")
    f.close()

    # Test md5
    assert md5(os.path.join(tmpdir, "testfile")) == "098f6bcd4621d373cade4e832627b4f6"

    # Remove the directory after the test
    shutil.rmtree(tmpdir)


# Generated at 2022-06-17 15:13:36.123816
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:13:39.430690
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:47.750088
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'e2c569be17396eca2a2e3c11578123ed'
    assert md5s('hello\r\n') == '1f8ac10f23c5b5bc1167bda84b833e5c'
    assert md5s('hello\r') == '6f5902ac237024bdd0c176cb93063dc4'
    assert md5s('hello\r\r\n') == '6f5902ac237024bdd0c176cb93063dc4'

# Generated at 2022-06-17 15:13:49.513427
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"


# Generated at 2022-06-17 15:13:53.321272
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5s(u'hello') == md5s('hello')


# Generated at 2022-06-17 15:13:55.190104
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
