

# Generated at 2022-06-17 15:04:04.464367
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:04:15.811444
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == 'b1946ac92492d2347c6235b4d2611184'
    assert md5s('hello\n\n\n') == '931f9f68b4c3e4dcd0e8b2a2a9f5f1d7'
    assert md5s('hello\n\n\n\n') == 'e9d71f5ee7c92d6dc9e92ffdad17b8bd'

# Generated at 2022-06-17 15:04:26.118730
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create a file
    f = open("testfile", "w")
    f.write("This is a test file")
    f.close()

    # Calculate the md5 checksum
    md5sum = md5("testfile")

    # Remove the temporary directory
    os.chdir(curdir)
    shutil.rmtree(tmpdir)

    # Check the md5 checksum
    assert md5sum == "b9f8d8a4b6a7a6b5d6d3e8e8b6a7a6b5"


# Generated at 2022-06-17 15:04:34.439772
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9dfa7ea9b08b0c90f48b7d'
    assert checksum('/bin/ls', hash_func=_md5) == 'c8d11180c9c2c2e9e0a7097f6e9a7585'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-17 15:04:37.101459
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:04:47.409244
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
        ),
        supports_check_mode=True,
    )

    path = module.params['path']
    checksum = secure_hash(path)

    if checksum:
        module.exit_json(changed=False, checksum=checksum)
    else:
        module.fail_json(msg="%s does not exist" % path)

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-17 15:04:52.456570
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:05:00.961735
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0c9e530350d7c9d9b1cff9b4'
    assert checksum('/bin/ls', hash_func=_md5) == '4a8a6d1ffa1c8c49fdfa5b5f8023147c'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:05:12.810886
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d8eeafb9b3d7a615920'
    assert checksum('/bin/ls', hash_func=_md5) == 'f9d0c9b7a9e8e8b7a8e8a9c7f9f9d0c9'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:05:19.685976
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_file_contents = 'test_file_contents'

    with open(test_file, 'w') as f:
        f.write(test_file_contents)

    assert md5(test_file) == 'f1b70c7d4f4c3b4b25c2a4d4f7d7e4e1'

    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:05:25.859441
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:05:35.085731
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9dfcee8e0f442c9b6e4043'
    assert checksum('/bin/ls', sha1) == '6b8e3eaf1f9dfcee8e0f442c9b6e4043'
    assert checksum('/bin/ls', _md5) == 'e8d9b8f4a4d4c7e4c8f9c2a4b6a4d80c'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls')
    assert checksum('/bin/ls', _md5) == checksum_

# Generated at 2022-06-17 15:05:43.374059
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os
    import filecmp

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create a file
    f = open("testfile", "w")
    f.write("Hello World")
    f.close()

    # Test md5
    assert md5("testfile") == "ed076287532e86365e841e92bfc50d8c"

    # Test md5s
    assert md5s("Hello World") == "ed076287532e86365e841e92bfc50d8c"

    # Clean up
    os.chdir(curdir)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:05:55.177104
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum functions '''

    import os
    import tempfile
    import shutil
    import stat

    from ansible.module_utils.basic import AnsibleModule

    def _create_file(path, data):
        ''' Create a file with the given data '''
        f = open(path, 'w')
        f.write(data)
        f.close()

    def _create_dir(path):
        ''' Create a directory '''
        os.mkdir(path)

    def _create_symlink(path, target):
        ''' Create a symlink '''
        os.symlink(target, path)

    def _create_fifo(path):
        ''' Create a fifo '''
        os.mkfifo(path)

# Generated at 2022-06-17 15:06:05.712677
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == 'f0e4c2f76c58916ec258f246851bea09'
    assert md5s('hello\n\n\n') == 'f0e4c2f76c58916ec258f246851bea09'
    assert md5s('hello\n\n\n\n') == 'f0e4c2f76c58916ec258f246851bea09'

# Generated at 2022-06-17 15:06:07.957449
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:06:15.640427
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile
    import shutil
    import unittest

    class TestChecksum(unittest.TestCase):

        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test_checksum')
            open(self.test_file, 'w').close()

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def test_checksum_file(self):
            ''' test checksum of a file '''

# Generated at 2022-06-17 15:06:18.816720
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "6b1634cbea7d36a0f3c9d5a7a36b1362"


# Generated at 2022-06-17 15:06:21.208953
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d6a1e5d3d7a0e4e3f'


# Generated at 2022-06-17 15:06:29.369249
# Unit test for function checksum
def test_checksum():
    ''' unit test for checksum '''
    from ansible.compat.tests import unittest

    class TestChecksum(unittest.TestCase):

        def test_checksum(self):
            ''' test checksum '''
            self.assertEqual(checksum('/bin/ls'), '6b8e3eaf0f8d16b8a6d4829122577a0a')
            self.assertEqual(checksum_s('hello'), '5d41402abc4b2a76b9719d911017c592')

    unittest.main(verbosity=2)

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-17 15:06:42.308030
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b2d7b0e6b9cadb1f9d9c7f0f3e6f0e4b'
    assert md5('/bin/cat') == 'a3b3a5b3d9c0c7f9a9b9a9b9e0e0e0e0'
    assert md5('/bin/cat') != 'a3b3a5b3d9c0c7f9a9b9a9b9e0e0e0e1'
    assert md5('/bin/cat') != 'a3b3a5b3d9c0c7f9a9b9a9b9e0e0e0e2'

# Generated at 2022-06-17 15:06:51.597458
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_checksum')

    # Create a file with some data
    with open(test_file, 'w') as f:
        f.write('test_checksum')

    # Check the checksum
    assert checksum(test_file) == 'f5c5d9d6c8f8c5e6b5b5c5d9d9f8f5c5'

    # Remove the file
    os.remove(test_file)

    # Check the checksum
    assert checksum(test_file) is None

    # Remove the directory
    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:07:00.293800
# Unit test for function md5
def test_md5():
    ''' test_md5.py:  Test md5 function '''
    import tempfile
    import shutil
    import os

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temp directory
    f = open(os.path.join(tmpdir, "testfile"), "w")
    f.write("This is a test")
    f.close()

    # Calculate the md5 checksum
    md5sum = md5(os.path.join(tmpdir, "testfile"))

    # Remove the temp directory
    shutil.rmtree(tmpdir)

    # Assert that the md5 checksum is correct
    assert md5sum == "9e107d9d372bb6826bd81d3542a419d6"

# Generated at 2022-06-17 15:07:02.850819
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:07:06.556657
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')


# Generated at 2022-06-17 15:07:17.454437
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\r\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\r') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\r') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'

# Generated at 2022-06-17 15:07:28.815952
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'e9a3b8c8e7d8a1c7d7f0f1c7b8a8c7b8'
    assert checksum('/bin/ls', hash_func=_md5) == 'c8e7d8a1c7d7f0f1c7b8a8c7b8e9a3b8'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:07:37.222635
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == 'b1946ac92492d2347c6235b4d2611184'
    assert md5s('hello\n\n\n') == 'b1946ac92492d2347c6235b4d2611184'
    assert md5s('hello\n\n\n\n') == 'b1946ac92492d2347c6235b4d2611184'

# Generated at 2022-06-17 15:07:42.688854
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    # Test for non-existent file
    assert checksum('/etc/asdfasdfasdfasdf') is None

    # Test for directory
    assert checksum('/etc') is None

    # Test for file
    assert checksum('/etc/hosts') == 'b1b3773a05c0ed0176787a4f1574ff0075f7521e'

    # Test for string
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:07:49.185972
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
            hash_algorithm = dict(default='sha1', choices=['sha1', 'md5'])
        ),
        supports_check_mode = True
    )

    path = module.params['path']
    hash_algorithm = module.params['hash_algorithm']

    if hash_algorithm == 'sha1':
        checksum_func = checksum
    elif hash_algorithm == 'md5':
        checksum_func = md5

    result = checksum_func(path)

    if result is None:
        module.fail_json

# Generated at 2022-06-17 15:08:00.241896
# Unit test for function md5
def test_md5():
    ''' md5 unit test '''
    from ansible.compat.tests import unittest
    import tempfile
    import shutil

    class TestMd5(unittest.TestCase):

        def setUp(self):
            self.test_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def test_md5_s(self):
            self.assertEqual(md5s('test'), '098f6bcd4621d373cade4e832627b4f6')

        def test_md5(self):
            test_file = os.path.join(self.test_dir, 'test')
            with open(test_file, 'w') as f:
                f.write('test')
            self

# Generated at 2022-06-17 15:08:12.002312
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'e2c569be17396eca2a2e3c11578123ed'
    assert md5s('hello\r') == 'f6c4db0c1b465e79e0a8e0f1304c2cad'
    assert md5s('hello\r\n') == '1f8708d5b30e3c5f37f8ffb27b6f9e1e'
    assert md5s('hello\r\n\r\n') == 'b9f9e1f7e8c5fadc5f5a7d3a0d3f5a3d'
    assert md5

# Generated at 2022-06-17 15:08:17.100963
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'


# Generated at 2022-06-17 15:08:19.667816
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9b9aebf5e4a8d6a24b4b'


# Generated at 2022-06-17 15:08:27.886422
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b7b338bcb33e1c1b5dc9a8d7d0e7f0f6'
    assert md5('/bin/cat') == 'd3b07384d113edec49eaa6238ad5ff00'
    assert md5('/bin/sleep') == 'f9a8a9d8f5c3a3a8d7c4f1a869a8a9d8'
    assert md5('/bin/echo') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5('/bin/sh') == 'd00696a07f895f06a3fdf4adae62bdc5'

# Generated at 2022-06-17 15:08:33.610873
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:08:37.299909
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-17 15:08:40.644875
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:08:46.079954
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d5c2ce8d5a43f8e12'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-17 15:08:57.540364
# Unit test for function checksum
def test_checksum():
    test_file = 'test/files/changelogs/changelog_sample.txt'

# Generated at 2022-06-17 15:09:10.492655
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:09:13.556396
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:09:25.471845
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True),
        ),
        supports_check_mode=True
    )

    # Create a temp file
    (fd, fname) = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the temp file
    fd = open(fname, 'w')
    fd.write('test data')
    fd.close()

    # Get the checksum
    module.params['path'] = fname
    result = checksum(module.params['path'])

    # Remove the temp file

# Generated at 2022-06-17 15:09:31.175929
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:09:35.654881
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9b9aebf3b0e2c9dec8e0'


# Generated at 2022-06-17 15:09:45.668959
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create a file
    f = open('foo', 'w')
    f.write('Hello')
    f.close()

    # Calculate the md5 checksum
    md5sum = md5('foo')

    # Remove the temporary directory
    os.chdir(curdir)
    shutil.rmtree(tmpdir)

    # Assert that the md5 checksum is correct
    assert md5sum == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:09:53.873272
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0f1a7f0f163e0c3c8d3f4a9d30'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', _md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', _md5) == md5s('hello')
    assert checksum('/bin/ls', _md5) == '6b8e3e0f1a7f0f163e0c3c8d3f4a9d30'

# Generated at 2022-06-17 15:09:56.520973
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b6d4a8c8f0e8d0a2f9a7f9b7b02b0c6a'


# Generated at 2022-06-17 15:10:06.838317
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '98c6e5f3d8f9a32a844e0d7de1d3f0e4'
    assert md5s('qux') == '31d6cfe0d16ae931b73c59d7e0c089c0'
    assert md5s('quux') == 'ed076287532e86365e841e92bfc50d8c'

# Generated at 2022-06-17 15:10:18.339981
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
            checksum=dict(required=True),
        ),
    )

    path = module.params['path']
    checksum = module.params['checksum']

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the temporary file
    fd = open(fname, 'w')
    fd.write('Hello World\n')
    fd.close()

    # Calculate the checksum
    calculated_checksum = checksum

# Generated at 2022-06-17 15:10:23.846052
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf88ec2c8dfdd2385a2e66f3e8'


# Generated at 2022-06-17 15:10:25.734807
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:10:28.935859
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d5b4c2b836e3eaf0f'


# Generated at 2022-06-17 15:10:37.466324
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'\u00e9') == '0cbc6611f5540bd0809a388dc95a615b'
    assert md5s(b'\xc3\xa9') == '0cbc6611f5540bd0809a388dc95a615b'

# Generated at 2022-06-17 15:10:40.725038
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:10:46.585577
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'

# Generated at 2022-06-17 15:10:48.543059
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-17 15:10:58.907391
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '98c6e5f3d8f9a32a844e0d7de5d7bfe9'
    assert md5s('qux') == '31d6cfe0d16ae931b73c59d7e0c089c0'
    assert md5s('quux') == 'ed076287532e86365e841e92bfc50d8c'

# Generated at 2022-06-17 15:11:01.959165
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf66c0a44d7d08a52f7d7e0c4e'


# Generated at 2022-06-17 15:11:04.927140
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:11:12.037908
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "6b890c92926e89e872e4d7ff8c5f967f"


# Generated at 2022-06-17 15:11:15.143348
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c5f497dbc2b3c6160'


# Generated at 2022-06-17 15:11:24.791499
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "6b1629f97905daa5e5d8e79a178c9b84"
    assert md5("/bin/ls") == "6b1629f97905daa5e5d8e79a178c9b84"
    assert md5("/bin/ls") == "6b1629f97905daa5e5d8e79a178c9b84"
    assert md5("/bin/ls") == "6b1629f97905daa5e5d8e79a178c9b84"
    assert md5("/bin/ls") == "6b1629f97905daa5e5d8e79a178c9b84"

# Generated at 2022-06-17 15:11:27.341071
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:11:32.140655
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:11:43.675244
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "6b8e0c86f8e8d8c3c3a6e3d8ca9b8a4e"
    assert checksum("/bin/ls", hash_func=_md5) == "c9f0f895fb98ab9159f51fd0297e236d"
    assert checksum("/bin/ls", hash_func=sha1) == "6b8e0c86f8e8d8c3c3a6e3d8ca9b8a4e"


# Generated at 2022-06-17 15:11:47.085263
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f8d09af95e7e0c13fe9caa8'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:11:50.676504
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:12:00.308180
# Unit test for function md5
def test_md5():
    '''
    ansible.utils.md5 unit test
    '''
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, mock_open

    class TestMd5(unittest.TestCase):

        @patch('ansible.utils.md5.open', mock_open(read_data='testdata'), create=True)
        def test_md5_file(self):
            self.assertEqual(md5('testfile'), '098f6bcd4621d373cade4e832627b4f6')

        def test_md5_s(self):
            self.assertEqual(md5s('testdata'), '098f6bcd4621d373cade4e832627b4f6')


# Generated at 2022-06-17 15:12:08.857082
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os.path
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "foo"), "w")
    f.write("foo")
    f.close()
    # Check that the md5 of the file is correct
    assert md5(os.path.join(tmpdir, "foo")) == "acbd18db4cc2f85cedef654fccc4a4d8"
    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:12:14.973073
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'


# Generated at 2022-06-17 15:12:23.729166
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-17 15:12:27.901953
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, fname = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('hello')
    f.close()

    # Check that the checksum is correct
    assert checksum(fname) == '5d41402abc4b2a76b9719d911017c592'

    # Change the file mode
    os.chmod(fname, stat.S_IRUSR)

    # Check that the checksum is still correct

# Generated at 2022-06-17 15:12:35.470057
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test file content')
    f.close()

    # Check the md5 of the file we just created
    assert md5(os.path.join(tmpdir, 'test')) == '098f6bcd4621d373cade4e832627b4f6'

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:12:37.656145
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "6b16a3ec2a22f0e939b5b5c13d9b22b6"


# Generated at 2022-06-17 15:12:41.942556
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c5f497db3f6c2da24'
    assert md5('/bin/cat') == '8c1f30d9f5f2e3c5f497db3f6c2da24'
    assert md5('/bin/notfound') is None
    assert md5('/bin') is None


# Generated at 2022-06-17 15:12:49.214803
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0c9fa0afc1fb2b037f3aa6a3db'
    assert checksum('/bin/ls', sha1) == '6b8e3e0c9fa0afc1fb2b037f3aa6a3db'
    assert checksum('/bin/ls', _md5) == '6b8e3e0c9fa0afc1fb2b037f3aa6a3db'
    assert checksum('/bin/ls', None) == '6b8e3e0c9fa0afc1fb2b037f3aa6a3db'

# Generated at 2022-06-17 15:12:54.349966
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b9d8eee7b0f0e7f8a7d8ee7f8eee7d8e'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:05.485779
# Unit test for function md5
def test_md5():
    ''' md5 should return the same value as md5sum command '''
    import tempfile
    import subprocess
    import os

    (fd, fname) = tempfile.mkstemp()
    os.write(fd, b"abcdefghijklmnopqrstuvwxyz")
    os.close(fd)
    try:
        md5sum = subprocess.check_output(["md5sum", fname]).split()[0]
        assert(md5sum == md5(fname))
    finally:
        os.remove(fname)


# Generated at 2022-06-17 15:13:16.699705
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('\n') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('\n\n\n') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('\n\n\n\n') == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-17 15:13:24.921646
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == md5s('test')
    assert md5s('test') != md5s('test2')


# Generated at 2022-06-17 15:13:29.123295
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f8d09af95e7f0f065e8c82a'


# Generated at 2022-06-17 15:13:37.773686
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\nworld') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\nworld\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\nworld\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'

# Generated at 2022-06-17 15:13:44.597744
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf66c0a8b36e2008e48f77702e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat2') == None


# Generated at 2022-06-17 15:13:47.994694
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'd3f07e86d8b21b0f8edc6898c99e0f3f'


# Generated at 2022-06-17 15:13:53.224847
# Unit test for function md5
def test_md5():
    '''
    ansible.utils.md5 unit test
    '''
    import tempfile

    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('hello')
    f.close()

    assert md5(fname) == '5d41402abc4b2a76b9719d911017c592'
    os.unlink(fname)


# Generated at 2022-06-17 15:13:59.704533
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "6b8e0c86c2231f1ed2e0ed9b9d3f0e7d"
    assert checksum("/bin/ls", sha1) == "6b8e0c86c2231f1ed2e0ed9b9d3f0e7d"
    assert checksum("/bin/ls", sha1) == checksum("/bin/ls")
    assert checksum("/bin/ls", sha1) == checksum_s("/bin/ls")
    assert checksum("/bin/ls", sha1) == checksum_s("/bin/ls", sha1)
    assert checksum("/bin/ls", sha1) == checksum_s("/bin/ls", sha1)
    assert checks