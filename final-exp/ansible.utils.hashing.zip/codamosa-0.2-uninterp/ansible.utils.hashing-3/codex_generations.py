

# Generated at 2022-06-17 15:03:58.119582
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:04:10.418364
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum functions '''

    import os
    import tempfile
    import shutil
    import stat

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write some data to the temporary file
    f = open(tmpfile, 'w')
    f.write('foo')
    f.close()

    # Make the temporary file read only
    os.chmod(tmpfile, stat.S_IRUSR)

    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)

    #

# Generated at 2022-06-17 15:04:21.067967
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0c9fa0afc1fb2b037f8fa5c843'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == md5s('hello')
    assert checksum('/bin/ls', hash_func=_md5) == '6b8e3e0c9fa0afc1fb2b037f8fa5c843'

# Generated at 2022-06-17 15:04:23.047364
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:04:29.583255
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile
    import shutil
    import sys

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Create a temporary non-existent file
    temp_path_nonexistent = os.path.join(tmpdir, 'nonexistent')

    # Create a temporary directory
    temp_path_dir = tempfile.mkdtemp(dir=tmpdir)

    # Create a temporary symlink


# Generated at 2022-06-17 15:04:32.776745
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "6b1634cbea9dcceb8c8c79d1a0fe39d2"


# Generated at 2022-06-17 15:04:46.468196
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == 'c7ef86a6d7c2cf8e6f0d6d827c8c3479'
    assert md5s('hello\n\n\n') == 'd8e8fca2dc0f896fd7cb4cb0031ba249'
    assert md5s('hello\n\n\n\n') == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'

# Generated at 2022-06-17 15:04:51.874199
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf66e170b5c5b0e3e3d8d5f3f3'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls') == '6b8e3eaf66e170b5c5b0e3e3d8d5f3f3'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:05:00.612807
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum('/etc/passwd') == 'c9b899b0f7c8b6fd24093862a9a230c3'
    assert checksum('/etc/passwd', hash_func=_md5) == 'c9b899b0f7c8b6fd24093862a9a230c3'

# Generated at 2022-06-17 15:05:12.538476
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d8c49f0e03748a4a8c6'
    assert checksum('/bin/ls', sha1) == '6b8e3eaf1f9f2d8c49f0e03748a4a8c6'
    assert checksum('/bin/ls', _md5) == '6b8e3eaf1f9f2d8c49f0e03748a4a8c6'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls')

# Generated at 2022-06-17 15:05:18.432292
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f8d09af95e7f0c11a8d8b9e'


# Generated at 2022-06-17 15:05:21.232808
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "6b890c92926e89e871f2afd633f06c14"


# Generated at 2022-06-17 15:05:26.266790
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:05:37.259909
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf0f8a7d44e038514fdbb7cabd'
    assert checksum('/bin/ls', 'sha1') == '6b8e3eaf0f8a7d44e038514fdbb7cabd'
    assert checksum('/bin/ls', 'sha256') == 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'

# Generated at 2022-06-17 15:05:40.759042
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d4a4d8c37e3d4faae'


# Generated at 2022-06-17 15:05:49.957862
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:05:59.062808
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, fname = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write data to the file
    f = open(fname, 'wb')
    f.write(b"foo")
    f.close()

    # Make sure the function works for existing files
    assert checksum(fname) == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-17 15:06:06.086042
# Unit test for function checksum
def test_checksum():
    ''' test_checksum() - test checksum function '''

    # Create a temporary file
    import tempfile
    fd, fname = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the file
    f = open(fname, 'w')
    f.write("Hello World")
    f.close()

    # Get the checksum
    csum = checksum(fname)

    # Remove the temporary file
    os.unlink(fname)

    # Return the checksum
    return csum


# Generated at 2022-06-17 15:06:14.206341
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

# Generated at 2022-06-17 15:06:16.446100
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '4b9cd8a08e8af0c2a14c8e729f4632e5'


# Generated at 2022-06-17 15:06:22.435934
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:06:30.781644
# Unit test for function checksum
def test_checksum():
    ''' test_checksum() - test checksum function '''

    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('test file')
    f.close()

    # Check the checksum
    assert checksum(fname) == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

    # Remove the temporary file
    os.remove(fname)

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:06:38.107359
# Unit test for function md5
def test_md5():
    '''
    ansible.utils.md5 unit test
    '''
    import tempfile

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('test')
    f.close()

    # Test md5
    assert md5(temp_path) == '098f6bcd4621d373cade4e832627b4f6'

    # Remove the temporary file
    os.remove(temp_path)

# Generated at 2022-06-17 15:06:48.115203
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1d69a6a471e39e0cda8e9c4e'
    assert checksum('/bin/ls', hash_func=_md5) == 'b9a1f9e3c8d36b5b5b1e2b18c7d8f8c8'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:06:57.727051
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == '81fe8bfe87576c3ecb22426f8e57847382917acf'

# Generated at 2022-06-17 15:07:08.734541
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf0f8d09af95e7f0c11a8d3b0f'
    assert checksum('/bin/ls', hash_func=_md5) == 'c8d11180c9d5f9f3a0a0c6f70f19c8eb'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:07:19.865313
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'e2c569be17396eca2a2e3c11578123ed'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(' ') == '7215ee9c7d9dc229d2921a40e899ec5f'
    assert md5s('\n') == '68b329da9893e34099c7d8ad5cb9c940'

# Generated at 2022-06-17 15:07:29.127536
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0e5fe84ad3518c83ce8c0be8bb'
    assert checksum('/bin/ls', sha1) == '6b8e3e0e5fe84ad3518c83ce8c0be8bb'
    assert checksum('/bin/ls', _md5) == '6b8e3e0e5fe84ad3518c83ce8c0be8bb'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls') == md5('/bin/ls')
    assert checksum('/bin/ls') == checksum_s('/bin/ls')
    assert checksum('/bin/ls', sha1)

# Generated at 2022-06-17 15:07:37.432507
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0a9f8ca29e6d6d25d8cb9aaf'
    assert checksum('/bin/ls', sha1) == '6b8e3e2e0a9f8ca29e6d6d25d8cb9aaf'
    assert checksum('/bin/ls', sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls')
    assert checksum_s('/bin/ls') == checksum_s('/bin/ls', sha1)
    assert checksum_s('/bin/ls') == checksum('/bin/ls')

# Generated at 2022-06-17 15:07:39.164691
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:07:50.002034
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create a file
    f = open("testfile", "w")
    f.write("This is a test file")
    f.close()

    # Check the md5
    assert md5("testfile") == "c8b5b0f8e7bfefd1c8eeb3a441d8f7f2"

    # Remove the temporary directory
    os.chdir(curdir)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:07:52.573406
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'd8e8fca2dc0f896fd7cb4cb0031ba249'


# Generated at 2022-06-17 15:07:55.239432
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '4b7dbb03d4caa904a1f64fa0d4de3d4f'


# Generated at 2022-06-17 15:07:56.211309
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:07:57.721748
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:08:04.831292
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5s('hello') != md5s('helloo')
    assert md5s('hello') != md5s('hell')

# Generated at 2022-06-17 15:08:07.183963
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:08:18.509614
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == '81fe8bfe87576c3ecb22426f8e57847382917acf'

# Generated at 2022-06-17 15:08:21.478267
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:08:33.400806
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5s('hello') != md5s('helloo')
    assert md5s('hello') != md5s('hell')
    assert md5s('hello') != md5s('hello ')
    assert md5s('hello') != md5s('hello\n')
    assert md5s('hello') != md5s('hello\r')
    assert md5s('hello') != md5s('hello\r\n')
    assert md5s('hello') != md5s('hello\r\n\r\n')

# Generated at 2022-06-17 15:08:48.457009
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'\xc3\xa9') == '0cbc6611f5540bd0809a388dc95a615b'
    assert md5s(u'\xe9') == '0cbc6611f5540bd0809a388dc95a615b'

# Generated at 2022-06-17 15:08:49.820292
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"


# Generated at 2022-06-17 15:08:58.866555
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='str'),
            follow=dict(required=False, type='bool', default=False),
        ),
        supports_check_mode=True
    )

    path = module.params['path']
    follow = module.params['follow']

    if not os.path.exists(path):
        module.fail_json(msg="Source %s not found" % (path))

    if os.path.isdir(path):
        module.fail_json(msg="Source %s is a directory" % (path))


# Generated at 2022-06-17 15:09:09.757190
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:09:20.240444
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2cac7a5b8e0d38b7b1e0aad67a'
    assert checksum('/bin/ls', 'sha1') == '6b8e3e2cac7a5b8e0d38b7b1e0aad67a'
    assert checksum('/bin/ls', 'md5') == '6b8e3e2cac7a5b8e0d38b7b1e0aad67a'

# Generated at 2022-06-17 15:09:25.616618
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '4f8e8e8a7b0a9e9b3f8c6a7d8c90beb2'


# Generated at 2022-06-17 15:09:34.600183
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n\r\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:09:47.093679
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5('/etc/passwd') == 'd3b07384d113edec49eaa6238ad5ff00'
    assert md5('/etc/passwd') == md5('/etc/passwd')
    assert md5('/etc/passwd') != md5('/etc/group')
    assert md5('/etc/passwd') != md5s('/etc/passwd')
    assert md5s('/etc/passwd') != md5('/etc/passwd')
    assert md5s('/etc/passwd') == md

# Generated at 2022-06-17 15:09:55.244518
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\nworld') == 'b10a8db164e0754105b7a99be72e3fe5'
    assert md5s('hello\nworld\n') == '7c222fb2927d828af22f592134e89324'
    assert md5s('hello\nworld\n\n') == 'f0e4c2f76c58916ec258f246851bea09'

# Generated at 2022-06-17 15:09:59.958656
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:10:11.238747
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5('/bin/ls') == 'e9a3f9e9c8c79f0a1e39ad00ec2a12a0'
    assert md5('/bin/ls') == md5('/bin/ls')
    assert md5('/bin/ls') != md5('/bin/ls2')


# Generated at 2022-06-17 15:10:18.756143
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:10:23.425982
# Unit test for function md5
def test_md5():
    ''' md5 should return the md5 checksum of a file '''
    assert md5('lib/ansible/module_utils/basic.py') == 'b9a8f2c8d0d9e2c7b8f8d8c8e9f9a9b9'


# Generated at 2022-06-17 15:10:33.092220
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('\n') == '68b329da9893e34099c7d8ad5cb9c940'
    assert md5s('\n\n') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9'
    assert md5s('\n\n\n') == 'e8dc4081b13434b45189a720b77b6818'

# Generated at 2022-06-17 15:10:46.440601
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == '81fe8bfe87576c3ecb22426f8e57847382917acf'

# Generated at 2022-06-17 15:10:48.952275
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d1fa4849c6e8659c9'


# Generated at 2022-06-17 15:10:58.183177
# Unit test for function md5
def test_md5():
    '''
    ansible.utils.md5 unit test
    '''
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_file'), 'w')
    f.write('test file contents')
    f.close()

    # Check the md5 checksum
    assert md5(os.path.join(tmpdir, 'test_file')) == 'e59ff97941044f85df5297e1c302d260'

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:11:05.610842
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\r\n') == '9e8dc93e85e36c25a3f683f3d8b0e923'
    assert md5s('hello\r') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\r') == 'e9feb0c7b0c8cb8a78ca1c24977d7e3d'
    assert md5s('hello\r\n\r\n')

# Generated at 2022-06-17 15:11:10.540287
# Unit test for function md5
def test_md5():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('HELLO WORLD') == '7b502c3a1f48c8609ae212cdfb639dee'
    assert md5s('hello world ') == '86fb269d190d2c85f6e0468ceca42a20'
    assert md5s('hello world\n') == '86fb269d190d2c85f6e0468ceca42a20'
    assert md5s('hello world\n\n') == '86fb269d190d2c85f6e0468ceca42a20'

# Generated at 2022-06-17 15:11:18.866231
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf0f8d16b8a0e1b20e1729ab1f'
    assert checksum('/bin/ls', hash_func=_md5) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:11:23.503687
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-17 15:11:28.028163
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for ansible.utils.checksum '''

    import tempfile

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('Hello World')
    f.close()

    # Check the checksum
    assert checksum(fname) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    # Remove the temporary file
    os.remove(fname)

# Generated at 2022-06-17 15:11:30.467570
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:11:34.936926
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_file_content = 'test_file_content'
    with open(test_file, 'w') as f:
        f.write(test_file_content)
    assert md5(test_file) == 'b9c4b9e249f0b1ce90745c881c409f5d'
    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:11:39.121693
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'

# Generated at 2022-06-17 15:11:43.388455
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c8e0c17f8f9a0c9bf'


# Generated at 2022-06-17 15:11:48.827150
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-17 15:11:57.347899
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "testfile"), "w")
    f.write("Hello World")
    f.close()

    # Test the md5 function
    assert md5(os.path.join(tmpdir, "testfile")) == "ed076287532e86365e841e92bfc50d8c"

    # Remove the directory after the test
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:12:00.351705
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:10.984254
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\n\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'

# Generated at 2022-06-17 15:12:22.919847
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == 'f0e4c2f76c58916ec258f246851bea09'
    assert md5s('hello\n\n\n') == 'f0e4c2f76c58916ec258f246851bea09'
    assert md5s('hello\n\n\n\n') == 'f0e4c2f76c58916ec258f246851bea09'

# Generated at 2022-06-17 15:12:27.109947
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/passwd') == '974b8af3a3c61296aad3b4317245b45aa4e0f3e3'
    assert checksum('/etc/shadow') == 'c597566c1e8ee5c9cab4c5e4d1f9f6a2'
    assert checksum('/etc/group') == '1b2cf1b7b4251d47251d4b5b4ee40d45'
    assert checksum('/etc/sudoers') == '95e43c7fe0d7f8c4d0e3166f32c9a0d4'

# Generated at 2022-06-17 15:12:30.637833
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9b6ebd8d5b7d7a2f28dbd7'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:35.237171
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls') == '9a7c5b8c8d5f5f6e0b6f8b6d3a8b3d75'


# Generated at 2022-06-17 15:12:45.612808
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "testfile"), "w")
    f.write("Hello World")
    f.close()

    # Test the md5 function
    assert md5(os.path.join(tmpdir, "testfile")) == "ed076287532e86365e841e92bfc50d8c"

    # Remove the temporary directory after the test
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:12:49.733846
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5('/bin/ls') == 'c8d11180c8a8cad1f6210f3eaadf1b12'

# Generated at 2022-06-17 15:12:59.914199
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == '9e9e135c2a5fefa9c7e0f5a67d7f3f5e'
    assert md5s('hello\n\n\n') == 'c2d0c90f94b8f20e9b9d5b8f0f2b8c8e'

# Generated at 2022-06-17 15:13:10.141492
# Unit test for function md5
def test_md5():
    '''
    Test md5 function
    '''
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test"), "wb")
    f.write(b"test")
    f.close()

    # Test md5 function
    assert md5(os.path.join(tmpdir, "test")) == '098f6bcd4621d373cade4e832627b4f6'

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:13:13.389667
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:15.806398
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:13:24.998773
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum functions '''

    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('Hello World')
    f.close()

    # Check that the checksum of the file matches the expected value
    module.exit_json(changed=False, ansible_facts={'checksum': checksum(fname)})

    # Remove the temporary file
    os.remove(fname)

# Generated at 2022-06-17 15:13:36.124437
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == '81fe8bfe87576c3ecb22426f8e57847382917acf'

# Generated at 2022-06-17 15:13:44.541486
# Unit test for function md5
def test_md5():
    '''
    ansible.utils.md5 unit test
    '''
    import tempfile

    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('test')
    f.close()

    assert md5(fname) == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

    os.unlink(fname)

# Generated at 2022-06-17 15:13:55.630103
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'
    assert md5s('hello\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'
    assert md5s('hello\n\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'