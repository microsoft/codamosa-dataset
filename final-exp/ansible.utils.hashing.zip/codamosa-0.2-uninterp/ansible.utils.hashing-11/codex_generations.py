

# Generated at 2022-06-17 15:04:01.987451
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:04:06.558426
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '4b7dbb47c8e8a0afd4c6fc3f0df0e8be'
    assert checksum('/bin/ls', hash_func=_md5) == '4b7dbb47c8e8a0afd4c6fc3f0df0e8be'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:04:12.705856
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', _md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'


# Generated at 2022-06-17 15:04:23.846201
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == 'f0e4c2f76c58916ec258f246851bea09'
    assert md5s('hello\n\n\n') == 'f0e4c2f76c58916ec258f246851bea09'
    assert md5s('hello\n\n\n\n') == 'f0e4c2f76c58916ec258f246851bea09'

# Generated at 2022-06-17 15:04:33.352468
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1d7e2bdea0e0d4d8a65c3fd0'
    assert checksum('/bin/ls', sha1) == '6b8e3eaf1d7e2bdea0e0d4d8a65c3fd0'
    assert checksum('/bin/ls', _md5) == '6b8e3eaf1d7e2bdea0e0d4d8a65c3fd0'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls')

# Generated at 2022-06-17 15:04:40.579368
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "4d186321c1a7f0f354b297e8914ab240"
    assert md5("/bin/cat") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5("/bin/cat1") == None


# Generated at 2022-06-17 15:04:45.877244
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True),
        ),
    )

    path = module.params['path']
    checksum = module.checksum(path)

    module.exit_json(path=path, checksum=checksum)


# Generated at 2022-06-17 15:04:47.556078
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == md5s('test')
    assert md5s('test') != md5s('test2')


# Generated at 2022-06-17 15:04:57.939163
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    testfile = os.path.join(tmpdir, 'testfile')
    testfile2 = os.path.join(tmpdir, 'testfile2')

    with open(testfile, 'w') as f:
        f.write('test')

    with open(testfile2, 'w') as f:
        f.write('test2')

    assert checksum(testfile) == checksum(testfile)
    assert checksum(testfile) != checksum(testfile2)

    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:05:05.729382
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d8c1a0f0fa3dd4f312e'
    assert checksum('/bin/ls', hash_func=_md5) == 'b9a1f9e8f8c61fbe9d3a1a8a8d8b0f84'
    assert checksum('/bin/ls', hash_func=sha1) == '6b8e3eaf1f9f2d8c1a0f0fa3dd4f312e'
    assert checksum('/bin/ls', hash_func=sha1) == checksum('/bin/ls')

# Generated at 2022-06-17 15:05:11.257729
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:05:13.369483
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b6d4c3a9e6a0e6f9a0caed4f2d7e0d4a'


# Generated at 2022-06-17 15:05:14.464979
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"


# Generated at 2022-06-17 15:05:25.173736
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo\n') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo\nbar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('foo\nbar\n') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('foo\nbar\nbaz\n') == 'b5bb9d8014a0f9b1d61e21e796d78dcc'

# Generated at 2022-06-17 15:05:27.267313
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:05:37.667664
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == '9e9e135c2a935c0fa1bd2e5c0e0ff9e1'
    assert md5s('hello\n\n\n') == 'd7a8fbb307d7809469ca9abcb0082e4f'
    assert md5s('hello\n\n\n\n') == 'd7a8fbb307d7809469ca9abcb0082e4f'

# Generated at 2022-06-17 15:05:44.707354
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for ansible.utils.checksum '''

    import tempfile
    import os
    import shutil
    from ansible.utils.checksum import checksum

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp(dir=tmpdir)

    # Write some data to the file
    os.write(fd, b"Hello World")
    os.close(fd)

    # Calculate the checksum
    result = checksum(temp_path)

    # Remove the temporary file and directory
    os.remove(temp_path)
    shutil.rmtree(tmpdir)

    # Assert the result

# Generated at 2022-06-17 15:05:56.991064
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'f8e9c9e4d5a7f0a2e0d4c4d4f4a7f0a2'
    assert md5('/bin/cat') == 'd0763edaa9d9bd2a9516280e9044d885'
    assert md5('/bin/sleep') == 'b1bbaafbefd1c59dc8a0c6f1c695c6a6'
    assert md5('/bin/sh') == 'd0b2c3a8d55d1c4de85a120ce7b4749a'
    assert md5('/bin/bash') == '3f1d13ac5f0a8bf12b8c1f8bf59b2a0c'
    assert md

# Generated at 2022-06-17 15:05:59.378365
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'd3b07384d113edec49eaa6238ad5ff00'


# Generated at 2022-06-17 15:06:02.192980
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f8d09af95e9e1f8f7a27b8a'


# Generated at 2022-06-17 15:06:08.552815
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b9a8e9bbd1a0c5b8d6a5a8d8c4a1c2c5'


# Generated at 2022-06-17 15:06:14.437121
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test"), "w")
    f.write("test")
    f.close()

    # Test if the checksum of the file matches
    assert checksum(os.path.join(tmpdir, "test")) == "098f6bcd4621d373cade4e832627b4f6"

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:06:17.316616
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'a8f0a2c8e7a7de9c0f0c3ab45a879b22'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:06:25.951170
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '4b6e8c9b5d3e4a9f9d0a00c6c8f36035'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat2') == None
    assert md5('/bin/cat3') == None


# Generated at 2022-06-17 15:06:33.631252
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:06:40.105300
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'


# Generated at 2022-06-17 15:06:49.841601
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "6b8e0c86f8e1a41a7b4c8c7d4a6528e2"
    assert checksum("/bin/ls", sha1) == "6b8e0c86f8e1a41a7b4c8c7d4a6528e2"
    assert checksum("/bin/ls", _md5) == "e2a8f8c8a47a7b417b1f8e0c86f6b8e2"
    assert checksum("/bin/ls", _md5) == md5("/bin/ls")
    assert checksum("/bin/ls", sha1) == checksum("/bin/ls")
    assert checksum("/bin/ls", sha1) == checksum

# Generated at 2022-06-17 15:06:59.067113
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-17 15:07:09.939275
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '4b7f6a97b7d8b8b8d9c3d3e4198ed35e'
    assert checksum('/bin/ls', hash_func=_md5) == '4b7f6a97b7d8b8b8d9c3d3e4198ed35e'
    assert checksum('/bin/ls', hash_func=sha1) == '4b7f6a97b7d8b8b8d9c3d3e4198ed35e'
    assert checksum('/bin/ls', hash_func=sha1) == checksum('/bin/ls')

# Generated at 2022-06-17 15:07:12.911842
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:07:22.582781
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '4f7f8e4e9a7c5fafd5c7b8a8f28f7f39'


# Generated at 2022-06-17 15:07:29.232707
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test"), "wb")
    f.write(b"foo")
    f.close()

    # Test checksum
    assert checksum(os.path.join(tmpdir, "test")) == "acbd18db4cc2f85cedef654fccc4a4d8"

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:07:35.001161
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'e2c569be17396eca2a2e3c11578123ed'
    assert md5s('hello\nworld') == '7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069'


# Generated at 2022-06-17 15:07:47.088232
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == '6f5902ac237024bdd0c176cb93063dc4'
    assert md5s('hello\n\n\n') == '6f5902ac237024bdd0c176cb93063dc4'
    assert md5s('hello\n\n\n\n') == '6f5902ac237024bdd0c176cb93063dc4'

# Generated at 2022-06-17 15:07:52.473600
# Unit test for function md5
def test_md5():
    ''' test md5 function '''
    assert md5('/bin/ls') == 'e3f0b9f5c8c9d5f5a7d7b04c8a9b9a2e'
    assert md5('/bin/bad_file') is None
    assert md5('/bin/') is None



# Generated at 2022-06-17 15:07:56.752465
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1d7f07b89e9e0f89c8d8b0c4'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:07:58.517123
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:08:10.803804
# Unit test for function md5
def test_md5():
    ''' md5 should return the same value as md5sum command '''
    import tempfile
    import subprocess
    import os

    test_data = 'test data'
    fd, fname = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write(test_data)
    f.close()

    p = subprocess.Popen(['md5sum', fname], stdout=subprocess.PIPE)
    out, err = p.communicate()
    os.unlink(fname)
    md5sum_value = out.split()[0]

    assert md5(fname) == md5sum_value
    assert md5s(test_data) == md5sum_value

if __name__ == '__main__':
    test_md

# Generated at 2022-06-17 15:08:12.864848
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "4a8a08f09d37b73795649038408b5f33"


# Generated at 2022-06-17 15:08:19.281648
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test')
    assert md5(test_file) == '098f6bcd4621d373cade4e832627b4f6'
    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:08:33.472463
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:08:37.831535
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9a3d8de3c0f0f7d79230'


# Generated at 2022-06-17 15:08:48.849765
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for ansible.utils.checksum '''

    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, fname = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write some data to the file
    f = open(fname, 'w')
    f.write('Hello World')
    f.close()

    # Check the checksum
    assert checksum(fname) == '0a4d55a8d778e5022fab701977c5d840bbc486d0'

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:08:55.048914
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create a file
    f = open("foo", "w")
    f.write("foobar")
    f.close()

    # Check md5
    assert md5("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"

    # Clean up
    os.chdir(curdir)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:09:08.459080
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n\r\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:09:12.008714
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:09:20.973134
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b7c9e862f5dba0d0a8c7d8c99baf5ed0'
    assert md5('/bin/cat') == 'f0ef7081e74e36b6fa9ad4767a49b816'
    assert md5('/bin/sleep') == '9a9666345e6d5c566a63f5a9ae9d5b5f'
    assert md5('/bin/sh') == 'a0d0eb67a2f8d09e5a4f36b0caa5b0f3'
    assert md5('/bin/bash') == '3d7c02e9c3c2f0e2c2bf0d59d7a07a9f'


# Generated at 2022-06-17 15:09:32.784518
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create a file
    f = open("test_file", "w")
    f.write("This is a test file")
    f.close()

    # Get the md5 checksum
    md5sum = md5("test_file")

    # Remove the temporary directory
    os.chdir(curdir)
    shutil.rmtree(tmpdir)

    # Assert that the md5 checksum is correct
    assert md5sum == "a8d8e5d5d1b5a5f0e9b9a1c9d8f8e0e0"

# Generated at 2022-06-17 15:09:46.414490
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'
    assert md5s('hello\r\n') == '1f8ac10f23c5b5bc1167bda84b833e5c057a77d2'
    assert md5s('hello\r') == '7815696ecbf1c96e6894b779456d330e'
    assert md5s('hello\n\r') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'

# Generated at 2022-06-17 15:09:55.250333
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-17 15:10:03.329491
# Unit test for function md5
def test_md5():
    import tempfile
    fd, fname = tempfile.mkstemp()
    os.write(fd, b"hello")
    os.close(fd)
    assert md5(fname) == "5d41402abc4b2a76b9719d911017c592"
    os.unlink(fname)

# Generated at 2022-06-17 15:10:05.560608
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:10:08.165619
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "6b890c92926e89e871f4a6776c6a7a43"


# Generated at 2022-06-17 15:10:10.202851
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:10:12.268433
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:10:15.072319
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5('/bin/ls') == '6f8db599de986fab7a21625b7916589c'

# Generated at 2022-06-17 15:10:26.405208
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'e2c569be17396eca2a2e3c11578123ed'
    assert md5s('hello\n\n') == 'b1946ac92492d2347c6235b4d2611184'
    assert md5s('hello\n\n\n') == '931f9f534e85bf45e5b4d6d1b8b67a8b'
    assert md5s('hello\n\n\n\n') == 'c9e4d1f5f0d6927c75bd4c9a9e0ffbcf'

# Generated at 2022-06-17 15:10:29.208405
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8be1e924f8a9b56a2a6d7e7c1e7a2d'


# Generated at 2022-06-17 15:10:31.605142
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:10:34.765726
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'


# Generated at 2022-06-17 15:10:48.196447
# Unit test for function md5s
def test_md5s():
    ''' test md5s function '''

    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello')

# Generated at 2022-06-17 15:10:58.503054
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'd3b07384d113edec49eaa6238ad5ff00'
    assert md5('/bin/cat') == 'c2911f22aacbf3a49eac72170a05be53'
    assert md5('/bin/sleep') == 'f1b70c2a42a7ba4a7d193a47b8e9f0e0'
    assert md5('/bin/echo') == 'c5b9d5b44b2b4b5deee5dd3e0ec3c6f1'
    assert md5('/bin/false') == 'c7567e8b7b0a38b50e5a6f8f0c4ca147'

# Generated at 2022-06-17 15:11:02.829157
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    try:
        tmpdir = tempfile.mkdtemp()
        testfile = os.path.join(tmpdir, 'testfile')
        with open(testfile, 'w') as f:
            f.write('test')
        assert md5(testfile) == '098f6bcd4621d373cade4e832627b4f6'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:11:10.713936
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('This is a test')
    f.close()

    # Create a temporary directory
    dname = tempfile.mkdtemp()

    # Create a temporary file in the directory
    fname2 = os.path.join(dname, 'test2')
    f = open(fname2, 'w')
    f.write('This is a test')
    f.close()

    # Create a temporary file in the directory

# Generated at 2022-06-17 15:11:20.100191
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == '81fe8bfe87576c3ecb22426f8e57847382917acf'

# Generated at 2022-06-17 15:11:22.509617
# Unit test for function md5s
def test_md5s():
    ''' test md5s function '''
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:11:24.439689
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:11:30.221958
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-17 15:11:33.381905
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1c13b8e9dbcaf6f0f0ee42'

# Generated at 2022-06-17 15:11:37.304252
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:11:51.065690
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0c00bceeb8bb8a49b9e8d8adc083aa0b'
    assert checksum('/bin/ls', 'sha1') == '6b8e3e2e0c00bceeb8bb8a49b9e8d8adc083aa0b'
    assert checksum('/bin/ls', 'sha256') == 'f4d7e1a3c701d29d7d4a5ef71a9c9f5f5f2f3a8d5f9a5a1c6a3b2896145b5e40'

# Generated at 2022-06-17 15:11:57.306075
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d8f5e7d76f5fad02f'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/doesnotexist') is None
    assert md5('/bin') is None


# Generated at 2022-06-17 15:12:00.844107
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'f8e9e8d9e1b9f9b8f8c8d8e8e8e8e8e8'


# Generated at 2022-06-17 15:12:03.464843
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:13.540014
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'\xc3\xbc') == 'f9e9a1c8f9f0e8a0f9e0e4c8f9f0e8a0'
    assert md5s(u'\xfc') == 'f9e9a1c8f9f0e8a0f9e0e4c8f9f0e8a0'

# Generated at 2022-06-17 15:12:17.066978
# Unit test for function checksum
def test_checksum():
    data = 'hello world'
    assert checksum_s(data) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(data, hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:12:29.623736
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == 'f0e4c2f76c58916ec258f246851bea09'
    assert md5s('hello\n\n\n') == 'f0e4c2f76c58916ec258f246851bea09'
    assert md5s('hello\n\n\n\n') == 'f0e4c2f76c58916ec258f246851bea09'

# Generated at 2022-06-17 15:12:34.065912
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0e5fe84ad3518c83ce8c0b88e8'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:44.126215
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    test_file = os.path.join(tmpdir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test')
    try:
        assert md5(test_file) == '098f6bcd4621d373cade4e832627b4f6'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:12:47.611321
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:07.838784
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '914f244f079a624ad8b04d78e4d8c8e5'
    assert md5s('hello\n\n') == 'c9fbb8b8fbb8a8fbb8b8fbb8a8fbb8b8'
    assert md5s('hello\n\n\n') == 'c9fbb8b8fbb8a8fbb8b8fbb8a8fbb8b8'

# Generated at 2022-06-17 15:13:11.733795
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:13:20.009859
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for utils.checksum '''

    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_file_contents = 'This is a test file'


# Generated at 2022-06-17 15:13:22.015859
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "6b16f98b6b8a7d0b6e5a5b3f4507ffa3"


# Generated at 2022-06-17 15:13:29.195679
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f8d085dea5c17f8d37b41c743a934'
    assert checksum('/bin/ls', sha1) == '6b8e3eaf1f9f8d085dea5c17f8d37b41c743a934'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', sha1) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-17 15:13:36.336301
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest

    class TestChecksum(unittest.TestCase):
        def test_checksum_s(self):
            self.assertEqual(checksum_s('hello'), 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d')

        def test_checksum(self):
            self.assertEqual(checksum(__file__), 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d')

    unittest.main()

# Generated at 2022-06-17 15:13:46.650741
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')

    # Create a test file
    with open(test_file, 'w') as f:
        f.write('hello world')

    # Test checksum
    assert checksum(test_file) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    # Test checksum_s
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    # Clean up
    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:13:48.749629
# Unit test for function md5
def test_md5():
    assert md5("/etc/passwd") == "d3b07384d113edec49eaa6238ad5ff00"


# Generated at 2022-06-17 15:13:56.446192
# Unit test for function md5
def test_md5():
    '''
    Test md5 function
    '''
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test file content')
    f.close()

    # Calculate the md5 checksum
    md5_checksum = md5(os.path.join(tmpdir, 'test'))

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

    # Assert the checksum
    assert md5_checksum == '098f6bcd4621d373cade4e832627b4f6'