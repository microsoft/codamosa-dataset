

# Generated at 2022-06-17 15:04:04.476419
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:04:15.859550
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf0f8d09e0b8c1d8c499f1c45e'
    assert checksum('/bin/ls', hash_func=_md5) == 'c8d7d5f5d79e0b6f64931d62b74e63b0'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:04:26.168149
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:04:29.657776
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'

# Generated at 2022-06-17 15:04:41.049361
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'e2c569be17396eca2a2e3c11578123ed'
    assert md5s('hello\nworld') == 'fcea920f7412b5da7be0cf42b8c93759'
    assert md5s('hello\nworld\n') == 'fcea920f7412b5da7be0cf42b8c93759'
    assert md5s('hello\nworld\n\n') == 'fcea920f7412b5da7be0cf42b8c93759'

# Generated at 2022-06-17 15:04:51.323938
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf88ec2e36e1e2fa5c5d8c98de5a1e07d7'
    assert checksum('/bin/ls', hash_func=_md5) == 'c8f1e2b9a1a0f3e4e70c2a8f4f4e0e68'
    assert checksum('/bin/ls', hash_func=sha1) == '6b8e3eaf88ec2e36e1e2fa5c5d8c98de5a1e07d7'
    assert checksum('/bin/ls', hash_func=sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls', hash_func=_md5) == checksum

# Generated at 2022-06-17 15:04:59.777013
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0c7bfbfdb6b8e3e0c7bfbfdb6b8e3e0c7'
    assert checksum('/bin/ls', hash_func=_md5) == '6b8e3e0c7bfbfdb6b8e3e0c7bfbfdb6b8e3e0c7'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:05:05.961427
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0a9f8eef9e876f23cb45c86b'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:05:13.623414
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0c7bfbfdb2f38d8aa0d0a9f8d7'
    assert checksum('/bin/ls', hash_func=_md5) == 'c4f08e9c9a1a9e8c8b8a7a7a6a5a4a3a'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:05:24.512173
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d8f5e7e39d7c8d7b7'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-17 15:05:31.025791
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:05:40.323528
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:05:49.703047
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile
    import shutil
    import sys

    from ansible.module_utils.basic import AnsibleModule

    # Make sure we can write to a temporary directory
    tmpdir = tempfile.mkdtemp()
    if not os.access(tmpdir, os.W_OK):
        print("ERROR: %s is not writable" % tmpdir)
        sys.exit(1)

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foobar')
    f.close()

    # Create a temporary directory

# Generated at 2022-06-17 15:06:01.274941
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'e2c569be17396eca2a2e3c11578123ed'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello\n') == 'e2c569be17396eca2a2e3c11578123ed'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello\n') == 'e2c569be17396eca2a2e3c11578123ed'

# Generated at 2022-06-17 15:06:11.290755
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d8eeafb9b3d7f0f6e32'
    assert checksum('/bin/ls', hash_func=_md5) == 'f0e8bce908e3c8e3c2ea7ea87a308b13'
    assert checksum('/bin/ls', hash_func=sha1) == '6b8e3eaf1f9f2d8eeafb9b3d7f0f6e32'
    assert checksum('/bin/ls', hash_func=sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls', hash_func=_md5) == checksum('/bin/ls', hash_func=_md5)

# Generated at 2022-06-17 15:06:22.363794
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\r\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\r') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\r\r\n') == '8b1a9953c4611296a827abf8c47804d7'

# Generated at 2022-06-17 15:06:31.077389
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  tests for utils.checksum '''

    import os
    import tempfile
    import shutil
    from ansible.utils import checksum

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Check that the checksum is correct
    assert checksum(fname) == 'acbd18db4cc2f85cedef654fccc4a4d8'

    # Remove the temporary file and directory
    os.remove(fname)
    os.rmdir(tmpdir)

# Generated at 2022-06-17 15:06:33.573287
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') != '098f6bcd4621d373cade4e832627b4f7'


# Generated at 2022-06-17 15:06:40.056194
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'


# Generated at 2022-06-17 15:06:51.295195
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "4d186321c1a7f0f354b297e8914ab240"
    assert md5("/bin/cat") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5("/bin/grep") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5("/bin/pwd") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5("/bin/sleep") == "d41d8cd98f00b204e9800998ecf8427e"

# Generated at 2022-06-17 15:06:58.001055
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    try:
        tmpdir = tempfile.mkdtemp()
        testfile = os.path.join(tmpdir, 'testfile')
        with open(testfile, 'w') as f:
            f.write('test')
        assert md5(testfile) == '098f6bcd4621d373cade4e832627b4f6'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:07:09.006337
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f5aacd2e8c3a8d4f453e4f4'
    assert checksum('/bin/ls', hash_func=_md5) == 'c8d0a48f88f8e8f6d5a7d8a7d7c5b375'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:07:20.177617
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:07:22.535044
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:07:32.963911
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c8e3f6e3c5d4c7f2c'
    assert md5('/bin/cat') == 'd3b07384d113edec49eaa6238ad5ff00'
    assert md5('/bin/grep') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/pwd') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/sleep') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-17 15:07:36.411119
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:07:45.582222
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(bytearray(b'hello')) == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:07:49.493343
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9a3d8ed2a5f9d0dcfb8f'


# Generated at 2022-06-17 15:07:52.077809
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-17 15:08:00.360686
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d8ce0c13f0a8f06a1f2'
    assert checksum('/bin/ls', hash_func=_md5) == 'f1d2d2f924e986ac86fdf7b36c94bcdf'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
   

# Generated at 2022-06-17 15:08:12.932047
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == '81fe8bfe87576c3ecb22426f8e57847382917acf'

# Generated at 2022-06-17 15:08:20.435040
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(bytearray(b'hello')) == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:08:32.738366
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible utils.checksum module '''

    import os
    import tempfile
    from ansible.utils.checksum import checksum

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the file
    fd = open(fname, 'w')
    fd.write('test data')
    fd.close()

    # Check the checksum
    assert checksum(fname) == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

    # Remove the temporary file
    os.unlink(fname)

# Generated at 2022-06-17 15:08:36.918778
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"


# Generated at 2022-06-17 15:08:48.721789
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == '81fe8bfe87576c3ecb22426f8e57847382917acf'

# Generated at 2022-06-17 15:08:50.702638
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9b9aebf3b13b8af0c474'


# Generated at 2022-06-17 15:08:58.226811
# Unit test for function md5
def test_md5():
    '''
    Test md5 function
    '''
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test"), "wb")
    f.write(b"test")
    f.close()

    # Test md5 function
    assert md5(os.path.join(tmpdir, "test")) == '098f6bcd4621d373cade4e832627b4f6'

    # Remove the temporary directory after the test
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:09:02.004795
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(bytearray(b'hello')) == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:09:11.810343
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0a8d8bc3e5bab45f9e1b4e68'
    assert checksum('/bin/ls', hash_func=_md5) == 'c8d4a9a0c8d4a9a0c8d4a9a0c8d4a9a0'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:09:13.979822
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:09:26.017999
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == 'f0e4c2f76c58916ec258f246851bea09'
    assert md5s('hello\n\n\n') == 'f0e4c2f76c58916ec258f246851bea09'
    assert md5s('hello\n\n\n\n') == 'f0e4c2f76c58916ec258f246851bea09'

# Generated at 2022-06-17 15:09:34.829751
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:09:39.828842
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9b9aeb9c83d1a8f0d0e0'


# Generated at 2022-06-17 15:09:44.112345
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d5ae3d8f5b0f2edc0'


# Generated at 2022-06-17 15:09:47.214268
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls') == '6b8be1e9b6a8149a7a5fd37705f5f60e'

# Generated at 2022-06-17 15:09:57.192950
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b7d5b6a7b8f5d2f5'
    assert md5('/bin/ls') == 'b7d5b6a7b8f5d2f5'
    assert md5('/bin/ls') == 'b7d5b6a7b8f5d2f5'
    assert md5('/bin/ls') == 'b7d5b6a7b8f5d2f5'
    assert md5('/bin/ls') == 'b7d5b6a7b8f5d2f5'
    assert md5('/bin/ls') == 'b7d5b6a7b8f5d2f5'

# Generated at 2022-06-17 15:10:07.176764
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\r\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\r') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\r\r\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'

# Generated at 2022-06-17 15:10:18.668298
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d3c4189a5e1e6d04ac3'
    assert checksum('/bin/ls', sha1) == '6b8e3eaf1f9f2d3c4189a5e1e6d04ac3'
    assert checksum('/bin/ls', sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls')
    assert checksum_s('/bin/ls') == checksum_s('/bin/ls', sha1)
    assert checksum_s('/bin/ls') == checksum('/bin/ls')

# Generated at 2022-06-17 15:10:26.765937
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_file_contents = 'test_file_contents'
    with open(test_file, 'w') as f:
        f.write(test_file_contents)

    assert md5(test_file) == 'c3fcd3d76192e4007dfb496cca67e13b'

    shutil.rmtree(test_dir)

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-17 15:10:28.858191
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:10:38.541354
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5('/etc/passwd') == '6b5c7a9b5b5ceb8d9a0a8cd3a79f0e8f'
    assert md5('/etc/shadow') == 'd6e4f1c8e9e5a3f8edf8e1f3f5dccc9b'
    assert md5('/etc/group') == 'b3aafbdbb8f7b0b50a3a82830d4a38c8'

# Generated at 2022-06-17 15:10:41.762929
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:10:44.446898
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:10:46.440954
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b8c9c1e1f9aac56103d1d76c8d7d30a2'


# Generated at 2022-06-17 15:10:56.628058
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\n') == 'e59ff97941044f85df5297e1c302d260'
    assert md5s('hello world\n\n') == '2ef7bde608ce5404e97d5f042f95f89f'
    assert md5s('hello world\n\n\n') == 'c743fbf7f1d1c5b0af8732b789caf8c9'
    assert md5s('hello world\n\n\n\n') == 'd2c7f6af1c8b9ab3cdcf2d3cf6635d2b'

# Generated at 2022-06-17 15:11:08.104365
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for ansible.utils.checksum '''

    import os
    import tempfile

    from ansible.utils.checksum import checksum

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the file
    with open(temp_path, 'wb') as f:
        f.write(b'hello world')

    # Check the checksum
    assert checksum(temp_path) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    # Remove the temporary file
    os.remove(temp_path)

# Generated at 2022-06-17 15:11:19.262445
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'e19d5cd5af0378da05f63f891c7467af'
    assert md5s('hello\nworld') == '7b502c3a1f48c8609ae212cdfb639dee'
    assert md5s('hello\nworld\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\nworld\n\n') == 'c3fcd3d76192e4007dfb496cca67e13b'

# Generated at 2022-06-17 15:11:27.454019
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file for testing
    (handle, filename) = tempfile.mkstemp()
    os.close(handle)

    # Create a temporary file for testing
    (handle, filename2) = tempfile.mkstemp()
    os.close(handle)

    # Write some data to the temporary file
    f = open(filename, 'w')
    f.write('Hello World')
    f.close()

    # Write some data to the temporary file
    f = open(filename2, 'w')
    f.write('Hello World')
    f.close()

    # Create a module for testing

# Generated at 2022-06-17 15:11:38.689999
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n\r\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:11:40.844893
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:11:54.240629
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile
    import shutil
    import stat

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write data to the temporary file
    with open(temp_path, 'wb') as f:
        f.write(b"Hello World")

    # Make the temporary file read-only
    os.chmod(temp_path, stat.S_IRUSR)

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp(dir=tmpdir)

   

# Generated at 2022-06-17 15:11:56.831015
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1c13b8e9dbc8c08f629e77'


# Generated at 2022-06-17 15:12:03.891125
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  tests for ansible.utils.checksum '''

    import tempfile
    import os

    (fd, fname) = tempfile.mkstemp()
    os.write(fd, b"foobar")
    os.close(fd)

    assert checksum(fname) == checksum_s("foobar")
    assert checksum_s("foobar") == "8843d7f92416211de9ebb963ff4ce28125932878"

    os.unlink(fname)

# Generated at 2022-06-17 15:12:06.088299
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:12:16.138223
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf0f8d09af95e7f0c11a8f52f3'
    assert checksum('/bin/ls', hash_func=_md5) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls')

# Generated at 2022-06-17 15:12:24.781119
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0dacb09e5a992d8d8b7552ce'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-17 15:12:27.655710
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:29.509881
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:12:33.748093
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')


# Generated at 2022-06-17 15:12:37.740979
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c5f497db0f0e86c67'


# Generated at 2022-06-17 15:12:48.780949
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == '81fe8bfe87576c3ecb22426f8e57847382917acf'

# Generated at 2022-06-17 15:12:59.481424
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile
    import shutil

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Create a temporary directory
    dirname = os.path.join(tmpdir, 'foo')
    os.mkdir(dirname)

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp(dir=dirname)

# Generated at 2022-06-17 15:13:11.331166
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d8a0c2178309731576c'
    assert checksum('/bin/ls', hash_func=_md5) == 'c4f0d8d8e7d3a1aec5e3d8f5d41c3d9a'
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
   

# Generated at 2022-06-17 15:13:12.947574
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:13:22.570247
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum functions '''

    import os
    import tempfile
    import shutil

    from ansible.module_utils.basic import AnsibleModule

    def test_checksum_s(data, expected):
        ''' test_checksum_s:  Test checksum_s function '''

        result = checksum_s(data)
        assert result == expected, "Expected %s, got %s" % (expected, result)

    def test_checksum(data, expected):
        ''' test_checksum:  Test checksum function '''

        (fd, fname) = tempfile.mkstemp()
        f = os.fdopen(fd, 'w')
        f.write(data)
        f.close()
        result = checksum(fname)

# Generated at 2022-06-17 15:13:25.745558
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5('/dev/null') == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-17 15:13:30.469510
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'


# Generated at 2022-06-17 15:13:40.661481
# Unit test for function md5
def test_md5():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:13:45.958906
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:55.190182
# Unit test for function md5
def test_md5():
    ''' md5.py: Test md5 function '''

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, mock_open

    class TestMd5(unittest.TestCase):

        @patch('ansible.utils.md5.open', mock_open(read_data='foo'))
        def test_md5(self):
            self.assertEqual(md5('/does/not/exist'), 'acbd18db4cc2f85cedef654fccc4a4d8')

    unittest.main()

if __name__ == '__main__':
    test_md5()