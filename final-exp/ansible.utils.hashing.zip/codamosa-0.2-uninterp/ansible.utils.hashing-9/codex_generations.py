

# Generated at 2022-06-17 15:04:05.902109
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d8eeafb9b3d7f0d2493'
    assert checksum('/bin/ls', sha1) == '6b8e3eaf1f9f2d8eeafb9b3d7f0d2493'
    assert checksum('/bin/ls', _md5) == '6b8e3eaf1f9f2d8eeafb9b3d7f0d2493'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum('/bin/ls')

# Generated at 2022-06-17 15:04:17.371126
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1d7e32e859e3a9d6a1ddb3ae'
    assert checksum('/bin/ls', hash_func=_md5) == '9a966a8e9a6a8e9a9a9a9a9a9a9a9a9a'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:04:19.511577
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c8f399d9f5fef40e9'


# Generated at 2022-06-17 15:04:27.188664
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == 'f0e4c2f76c58916ec258f246851bea09'
    assert md5s('hello\n\n\n') == 'f0e4c2f76c58916ec258f246851bea09'
    assert md5s('hello\n\n\n\n') == 'f0e4c2f76c58916ec258f246851bea09'

# Generated at 2022-06-17 15:04:35.159799
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf0f8d09af95e7e98c6e0b0c22'
    assert checksum('/bin/ls', sha1) == '6b8e3eaf0f8d09af95e7e98c6e0b0c22'
    assert checksum('/bin/ls', _md5) == '6b8e3eaf0f8d09af95e7e98c6e0b0c22'
    assert checksum('/bin/ls', 'sha1') == '6b8e3eaf0f8d09af95e7e98c6e0b0c22'

# Generated at 2022-06-17 15:04:47.140400
# Unit test for function checksum
def test_checksum():
    '''
    ansible core: checksum module
    '''
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test file content')
    f.close()

    # Check the checksum of the file
    assert checksum(os.path.join(tmpdir, 'test')) == '2d711642b726b04401627ca9fbac32f5c8530fb1903cc4db02258717921a4881'

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:04:53.950800
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test"), "wb")
    f.write(b"foo")
    f.close()

    # Test checksum
    assert checksum(os.path.join(tmpdir, "test")) == "acbd18db4cc2f85cedef654fccc4a4d8"

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:04:57.364285
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')


# Generated at 2022-06-17 15:05:01.073008
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "4b9cd8e5933c2a8dab30313bab43f4d4"
    assert md5("/bin/cat") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5("/bin/cat1") == None


# Generated at 2022-06-17 15:05:10.635825
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\n') == 'e59ff97941044f85df5297e1c302d260'
    assert md5s(u'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(u'hello world\n') == 'e59ff97941044f85df5297e1c302d260'


# Generated at 2022-06-17 15:05:17.389234
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d8eeafb9b3d7f0d2431'
    assert checksum('/bin/ls', hash_func=_md5) == '8c35b8d4d4f0b9e8c0e3aeba3f9c7c3d'
    assert checksum('/bin/ls', hash_func=sha1) == '6b8e3eaf1f9f2d8eeafb9b3d7f0d2431'
    assert checksum('/bin/ls', hash_func=sha1) == checksum('/bin/ls')

# Generated at 2022-06-17 15:05:26.480717
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:05:37.258215
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == '8c8e7c2a1feacadc5c3f4a9d3ee3ae9d'
    assert md5s('hello\n\n\n') == '5f8db3990b9e5461d7c2d48c7e690d2e'
    assert md5s('hello\n\n\n\n') == 'f3e8028e0bf86ce5846a81b7babf8c9c'

# Generated at 2022-06-17 15:05:40.355851
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:05:42.671702
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b1f9a9c8a1a8d8c7e0d7a8c8b1f9c8a1'


# Generated at 2022-06-17 15:05:48.613273
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test')
    assert checksum(test_file) == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:05:58.461138
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5s('hello') != md5s('helloo')
    assert md5s('hello') != md5s('hell')
    assert md5s('hello') != md5s('h')
    assert md5s('hello') != md5s('he')
    assert md5s('hello') != md5s('hel')
    assert md5s('hello') != md5s('helloo')
    assert md5s('hello') != md5s('hellooo')
    assert md5s('hello') != md5s('helloooo')
    assert md5

# Generated at 2022-06-17 15:06:00.770133
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:06:10.814005
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0e1ab6c38b8e49c1485d4d1596'
    assert checksum('/bin/ls', hash_func=_md5) == 'f1d2d2f924e986ac86fdf7b36c94bcdf'
    assert checksum('/bin/ls', hash_func=sha1) == '6b8e3e0e1ab6c38b8e49c1485d4d1596'
    assert checksum('/bin/ls', hash_func=sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls', hash_func=_md5) == checksum('/bin/ls', hash_func=_md5)

# Generated at 2022-06-17 15:06:22.113541
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n\r\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:06:31.800167
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5s('hello') != md5s('helloo')
    assert md5s('hello') != md5s('hell')
    assert md5s('hello') != md5s('hello ')
    assert md5s('hello') != md5s('hello\n')
    assert md5s('hello') != md5s('hello\r')
    assert md5s('hello') != md5s('hello\r\n')
    assert md5s('hello') != md5s('hello\t')
    assert md5s('hello') != md5s

# Generated at 2022-06-17 15:06:35.712644
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:06:46.166275
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d8ce0c13f0a8f06ec65'
    assert checksum('/bin/ls', hash_func=_md5) == 'b873e1e50f8d8de0c13f0a8f06ec65'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:06:55.860776
# Unit test for function md5s
def test_md5s():
    import random
    import string

    # Test md5s with a random string
    random_str = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
    assert md5s(random_str) == 'f7d6d5b8c9b9f1b7c7f9d9c8e7c2b4d4'

    # Test md5s with a random unicode string
    random_unicode_str = u'\u00f1'
    assert md5s(random_unicode_str) == 'e2b7b0d2f8b7d2e2'

    # Test md5s with a random byte string

# Generated at 2022-06-17 15:07:07.331069
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:07:09.443567
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:07:15.099013
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s(u'hello')


# Generated at 2022-06-17 15:07:18.848795
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum('/bin/ls') == '6b8e3e0e4af085e9a3f8e7efb24d02fe'

# Generated at 2022-06-17 15:07:24.320624
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'f5d5a5a5e5c7f5f5d5d5b5b5f5f5f5f5'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:07:29.879041
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'e2a3f8e9c8c7910e63fdb68a33fb43d4'


# Generated at 2022-06-17 15:07:33.958134
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:07:46.724633
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "6b8e3e2e0dac6e877dbf8d81baad41d6"
    assert checksum("/bin/ls", sha1) == "6b8e3e2e0dac6e877dbf8d81baad41d6"
    assert checksum("/bin/ls", sha1) == checksum("/bin/ls")
    assert checksum("/bin/ls", sha1) == checksum_s("/bin/ls")
    assert checksum("/bin/ls", sha1) == checksum_s("/bin/ls", sha1)
    assert checksum("/bin/ls", sha1) == checksum_s("/bin/ls", sha1)

# Generated at 2022-06-17 15:07:49.492590
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:07:59.237617
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(b'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(u'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(u'\u6d4b\u8bd5') == '7f9c9d0f0f9b7e0b9d0a7f38c3c5a3b1'

# Generated at 2022-06-17 15:08:11.454467
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\nworld') == '812c63e9a9b7e2c2a9dffb918c5e9288'
    assert md5s('hello\nworld\n') == 'fcea920f7412b5da7be0cf42b8c93759'
    assert md5s('hello\nworld\n\n') == 'fcea920f7412b5da7be0cf42b8c93759'
    assert md5s('hello\nworld\n\n\n')

# Generated at 2022-06-17 15:08:21.760660
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf9480de5d7a0cdcb34f0ff3e5'
    assert checksum('/bin/ls', hash_func=_md5) == 'f8dff7e6e0f6a0f8e9c310c900c7f0c1'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-17 15:08:26.201741
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:08:34.892582
# Unit test for function md5
def test_md5():
    assert md5('test/support/files/chown.sh') == 'b2d0e9c9d9e9b5c7d5f5f8f8f2d0e9c9'
    assert md5('test/support/files/chown.sh') != 'b2d0e9c9d9e9b5c7d5f5f8f8f2d0e9c8'
    assert md5('test/support/files/chown.sh') != 'b2d0e9c9d9e9b5c7d5f5f8f8f2d0e9c9d'

# Generated at 2022-06-17 15:08:38.907685
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9b9aebf5e3d7dc8d23f5'


# Generated at 2022-06-17 15:08:47.031870
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'f2a7c911744c2f8cfceb94591f7aa2a3'
    assert checksum('/bin/ls', hash_func=_md5) == 'e2a3c0129e2b964761d83e6f59d98bd4'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md

# Generated at 2022-06-17 15:08:52.386870
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:08:59.964416
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum('/etc/passwd') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

# Generated at 2022-06-17 15:09:10.372557
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c8e0c17d235dfa7e6'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-17 15:09:20.574362
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e0c863e4daa5f9d0240d7d5ccb278'
    assert checksum('/bin/ls', sha1) == '6b8e0c863e4daa5f9d0240d7d5ccb278'
    assert checksum('/bin/ls', _md5) == '6b8e0c863e4daa5f9d0240d7d5ccb278'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-17 15:09:32.792258
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5('/etc/passwd') == 'c9b899b7e0c5f5f5a63f3ac66c7f0f5f'
    assert md5('/etc/passwd') == md5('/etc/passwd')
    assert md5('/etc/passwd') != md5('/etc/group')
    assert md5('/etc/passwd') != md5s('/etc/passwd')
    assert md5s('/etc/passwd') != md5('/etc/passwd')

# Generated at 2022-06-17 15:09:46.414639
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_file_contents = 'This is a test file'
    with open(test_file, 'w') as f:
        f.write(test_file_contents)

    test_file_hash = checksum(test_file)
    assert test_file_hash == 'f1c96f7d0c4a8d37e8b2b6e2b45a9bde1d0a8f5e'

    test_file_hash = checksum_s(test_file_contents)

# Generated at 2022-06-17 15:09:49.075247
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')


# Generated at 2022-06-17 15:09:50.979757
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:09:55.549924
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test')
    assert md5(test_file) == '098f6bcd4621d373cade4e832627b4f6'
    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:10:04.592523
# Unit test for function md5
def test_md5():
    ''' md5.py: Test md5 function '''
    from ansible.compat.tests import unittest

    class TestMd5(unittest.TestCase):

        def test_md5(self):
            ''' md5: Test md5 function '''
            self.assertEqual(md5("/bin/ls"), "6b1634cbea9dc97f5f749b41d22c4ce1")

    unittest.main(verbosity=2)

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-17 15:10:18.761238
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == '81fe8bfe87576c3ecb22426f8e57847382917acf'

# Generated at 2022-06-17 15:10:20.026373
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:10:29.235030
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5s('hello') != md5s('helloo')
    assert md5s('hello') != md5s('hell')
    assert md5s('hello') != md5s('hello ')
    assert md5s('hello') != md5s('hello\n')
    assert md5s('hello') != md5s('hello\r')
    assert md5s('hello') != md5s('hello\r\n')
    assert md5s('hello') != md5s('hello\r\n\r\n')

# Generated at 2022-06-17 15:10:33.618053
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:10:46.730875
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\n') == 'e59ff97941044f85df5297e1c302d260'
    assert md5s('hello world\r\n') == '1f8ac10f23c5b5bc1167bda84b833e5c'
    assert md5s('hello world\r\n\r\n') == 'e9d71f5ee7c92d6dc9e92ffdad17b8bd'
    assert md5s('hello world\r\n\r\n\r\n') == 'e9d71f5ee7c92d6dc9e92ffdad17b8bd'

# Generated at 2022-06-17 15:10:48.585655
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:10:53.041425
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls') == 'f6d8e9c9a6a3e6f3a7ba0d7a8c6f9a49'

# Generated at 2022-06-17 15:11:01.843225
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum functions '''

    import os
    import tempfile
    import shutil

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
            mode = dict(required=False, type='str', choices=['md5', 'sha1']),
        ),
        supports_check_mode=True
    )

    path = module.params['path']
    mode = module.params['mode']

    if mode is None:
        mode = 'sha1'

    if mode == 'md5':
        checksum_func = md5
        checksum_func_s = md5s
    else:
        checksum_func = checksum
       

# Generated at 2022-06-17 15:11:05.174714
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '4a8a4f9b0c5b31c19f36f7d7b700e3b5'


# Generated at 2022-06-17 15:11:06.831911
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:11:19.461709
# Unit test for function checksum
def test_checksum():
    # Test with a file
    filename = 'test_checksum.py'
    assert checksum(filename) == 'c0d8e8f7c7a0a2b4c4b6d8a9c9f1f4e1'
    assert checksum(filename, _md5) == 'a8c0e8d7c7a0a2b4c4b6d8a9c9f1f4e1'

    # Test with a string
    data = 'Hello World'
    assert checksum_s(data) == '2ef7bde608ce5404e97d5f042f95f89f1c232871'

# Generated at 2022-06-17 15:11:21.465017
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:11:23.381394
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:11:29.976931
# Unit test for function checksum
def test_checksum():
    ''' test_checksum() - test the checksum function '''
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write data to the temporary file
    with open(temp_path, 'w') as f:
        f.write('Hello world!')

    # Calculate the checksum
    checksum_value = checksum(temp_path)

    # Remove the temporary file and directory
    os.remove(temp_path)
    shutil.rmtree(tmpdir)

    # Assert that the checksum is correct

# Generated at 2022-06-17 15:11:32.994292
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:11:38.098862
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'd3f07e8f4f7c5d36e3d3a8d64c0ef8a0'


# Generated at 2022-06-17 15:11:44.421606
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf0f8d16b8a6a49f54f6f36f24'
    assert checksum('/bin/ls', hash_func=_md5) == 'e2fc714c4727ee9395f324cd2e7f331f'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:11:55.592115
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file
    tmpfd, tmpfname = tempfile.mkstemp()
    os.close(tmpfd)

    # Write some data to the temporary file
    f = open(tmpfname, "w")
    f.write("Hello World")
    f.close()

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file in the temporary directory
    tmpfname2 = os.path.join(tmpdir, "tmpfile")
    f = open(tmpfname2, "w")
    f.write("Hello World")
    f.close()

    # Create a temporary

# Generated at 2022-06-17 15:11:57.964153
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d8f5e7e3923a3a010'


# Generated at 2022-06-17 15:12:05.724436
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'a8e9b8c1e0d7c2a6a2a6d1d6c7e0b8e9'
    assert md5('/etc/shadow') == 'c2e0b8e9a8e9b8c1e0d7c2a6a2a6d1d6'
    assert md5('/etc/group') == 'd1d6c7e0b8e9a8e9b8c1e0d7c2a6a2a6'
    assert md5('/etc/gshadow') == 'e0d7c2a6a2a6d1d6c7e0b8e9a8e9b8c1'

# Generated at 2022-06-17 15:12:15.929224
# Unit test for function md5
def test_md5():
    ''' test md5 function '''
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test"), 'w')
    f.write("test")
    f.close()

    # Test if md5 returns the correct value
    assert md5(os.path.join(tmpdir, "test")) == "098f6bcd4621d373cade4e832627b4f6"

    # Remove the directory after the test
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:12:20.763856
# Unit test for function md5
def test_md5():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(data=dict(required=True, type='str'),
                                              filename=dict(required=True, type='str')))
    data = module.params['data']
    filename = module.params['filename']
    md5_data = md5s(data)
    md5_file = md5(filename)
    module.exit_json(changed=False, md5_data=md5_data, md5_file=md5_file)

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-17 15:12:30.849514
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5('/bin/ls') == '4f1b8e8b7b9e9e9d7e0f8a8b7d8f3c0d'
    assert md5('/bin/ls') == md5('/bin/ls')
    assert md5('/bin/ls') != md5('/bin/ls2')
    assert md5('/bin/ls') != md5('/bin/ls2')
    assert md5('/bin/ls') != md5('/bin/ls2')

# Generated at 2022-06-17 15:12:33.706499
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf66e170e8c9a0d5b735c76d3e'


# Generated at 2022-06-17 15:12:46.575906
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s(u'hello')
    assert md5s(u'hello') == md5s(u'hello')
    assert md5s('hello') == md5s(b'hello')
    assert md5s(b'hello') == md5s(b'hello')
    assert md5s(b'hello') == md5s(u'hello')
    assert md5s(u'hello') == md5s(b'hello')
    assert md5s(u'\u1234') == md5s(b'\xe1\x88\xb4')
    assert md5s(b'\xe1\x88\xb4') == md5s

# Generated at 2022-06-17 15:12:53.397208
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '98c615784ccb5fe59bfdb058d26525ce'
    assert md5s('qux') == '0c7f2909a44c215b9a6e3e5e30f6f0f6'
    assert md5s('quux') == '8d777f385d3dfec8815d20f7496026dc'

# Generated at 2022-06-17 15:12:58.544010
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "4b8e0c5f78dcd95ef1f57f8e6f1e0a0c"


# Generated at 2022-06-17 15:13:08.091037
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'e2c569be17396eca2a2e3c11578123ed'
    assert md5s('hello\n\n') == 'c9b20b8bd0c92f3dde8a3fe8b7f22976'
    assert md5s('hello\n\n\n') == 'f9e4854f6e9e99c8e8cd30c3a3a5f214'
    assert md5s('hello\n\n\n\n') == 'e5e9fa1ba31ecd1ae84f75caaa474f3a'

# Generated at 2022-06-17 15:13:13.237063
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:16.095310
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "4a0a3e8c4ad7a2bea9d6a750d1d7ec51"


# Generated at 2022-06-17 15:13:25.430165
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test"), 'w')
    f.write("test")
    f.close()

    # Test if the checksum of the file matches
    assert checksum(os.path.join(tmpdir, "test")) == "098f6bcd4621d373cade4e832627b4f6"

    # Remove the directory after the test
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:13:33.845638
# Unit test for function checksum
def test_checksum():
    import tempfile
    import os

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('hello')
    f.close()

    # Test checksum
    assert checksum(temp_path) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

    # Clean up
    os.remove(temp_path)

# Generated at 2022-06-17 15:13:43.018088
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s(u'hello')
    assert md5s('hello') == md5s(b'hello')
    assert md5s(b'hello') == md5s(u'hello')
    assert md5s(u'hello') == md5s(b'hello')


# Generated at 2022-06-17 15:13:47.404507
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:13:57.104555
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf0f8c9b5aafd6b7d1d8a23036'
    assert checksum('/bin/ls', hash_func=_md5) == 'e2fc714c4727ee9395f324cd2e7f331f'
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'