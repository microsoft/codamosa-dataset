

# Generated at 2022-06-17 15:04:04.338096
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:04:15.333392
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  tests for ansible.utils.checksum '''

    import tempfile

    # Create a temporary file
    fd, fname = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('Hello World')
    f.close()

    # Test for checksum
    assert checksum(fname) == '0a4d55a8d778e5022fab701977c5d840bbc486d0'

    # Test for checksum_s
    assert checksum_s('Hello World') == '0a4d55a8d778e5022fab701977c5d840bbc486d0'

    # Remove the temporary file
    os.remove(fname)

# Generated at 2022-06-17 15:04:24.969075
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert checksum('/bin/ls') == 'f0d9c2e9f8a8d0c3c8b7b1c9f8a8d0c3'
    assert checksum('/bin/ls', hash_func=_md5) == 'f0d9c2e9f8a8d0c3c8b7b1c9f8a8d0c3'

# Generated at 2022-06-17 15:04:29.849947
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-17 15:04:41.068748
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum('/etc/passwd') == '8e9c8f6a5b06a1c6d22f8b28c42a4e2c'
    assert checksum('/etc/shadow') is None
    assert checksum('/etc') is None
    assert checksum('/this/file/does/not/exist') is None
    assert checksum('/etc/passwd', hash_func=_md5) == '8e9c8f6a5b06a1c6d22f8b28c42a4e2c'
    assert checksum('/etc/shadow', hash_func=_md5) is None

# Generated at 2022-06-17 15:04:51.355372
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile
    import unittest

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('test file')
    f.close()

    # Create a temporary directory
    dname = tempfile.mkdtemp()

    # Create a temporary file in the directory
    (fd, fname2) = tempfile.mkstemp(dir=dname)
    f = os.fdopen(fd, 'w')
    f.write('test file')
    f.close()

    # Create a temporary file in the directory

# Generated at 2022-06-17 15:05:00.339740
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == 'f5d2a0e8e4f3f0b5e77c170c8c9b3df1'
    assert md5s('hello\n\n\n') == 'c8e7f51d9b5e5e2b6a8d5a48374a5c81'
    assert md5s('hello\n\n\n\n') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9'
    assert md

# Generated at 2022-06-17 15:05:12.323419
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "6b8e3eaf1f9dfa7ea924d76ecfa6c5b4"
    assert checksum("/bin/ls", sha1) == "6b8e3eaf1f9dfa7ea924d76ecfa6c5b4"
    assert checksum("/bin/ls", sha1) == checksum("/bin/ls")
    assert checksum("/bin/ls", sha1) == checksum_s("/bin/ls")
    assert checksum("/bin/ls", sha1) == checksum_s("/bin/ls", sha1)
    assert checksum("/bin/ls", sha1) == checksum_s("/bin/ls", sha1)

# Generated at 2022-06-17 15:05:21.174960
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum('/etc/passwd') == 'c4b7f1c9a967e2a9d7f6f7d0a7aacb0e'
    assert checksum('/etc/passwd', hash_func=_md5) == 'c4b7f1c9a967e2a9d7f6f7d0a7aacb0e'


# Generated at 2022-06-17 15:05:33.880510
# Unit test for function md5
def test_md5():
    ''' test_md5.py:  unit test for md5 function '''
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_string = 'test string'

    # Create a test file
    with open(test_file, 'w') as f:
        f.write(test_string)

    # Calculate the md5 of the test file
    test_md5 = md5(test_file)

    # Calculate the md5 of the test string
    test_md5_s = md5s(test_string)

    # Clean up
    shutil.rmtree(test_dir)

    # Test the md5 of the test file
    assert test_md

# Generated at 2022-06-17 15:05:38.076701
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:05:47.486552
# Unit test for function md5
def test_md5():
    test_file = 'test_file'
    test_string = 'test_string'
    test_string_md5 = '098f6bcd4621d373cade4e832627b4f6'
    test_file_md5 = 'd41d8cd98f00b204e9800998ecf8427e'
    with open(test_file, 'w') as f:
        f.write(test_string)
    assert md5(test_file) == test_string_md5
    assert md5s(test_string) == test_string_md5
    assert md5(test_string) == test_file_md5
    os.remove(test_file)

# Generated at 2022-06-17 15:05:50.750679
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:06:00.021351
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '4b7dbb1c2c9145d0c45e7b4ddc4b0b4d'
    assert md5('/bin/cat') == '7f9c8d9a7e0e6c0a7dab5c5c5d8e5f6f'
    assert md5('/bin/sleep') == 'c6f3f3a8b0a7a6e9c6f3f3a8b0a7a6e9'
    assert md5('/bin/pwd') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-17 15:06:07.987563
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "testfile"), "wb")
    f.write(b"Hello World")
    f.close()
    # Compute the md5 checksum
    checksum = md5(os.path.join(tmpdir, "testfile"))
    # Remove the temporary directory
    shutil.rmtree(tmpdir)
    # Assert that the md5 checksum is computed properly
    assert checksum == 'ed076287532e86365e841e92bfc50d8c'

# Generated at 2022-06-17 15:06:15.666605
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum functions '''

    import os
    import tempfile

    from ansible.utils.hashing import checksum, checksum_s, md5, md5s

    # Create a temporary file
    (handle, filename) = tempfile.mkstemp()
    os.close(handle)

    # Write some data to the temporary file
    handle = open(filename, 'w')
    handle.write('Hello World!')
    handle.close()

    # Check the checksum of the temporary file
    assert checksum(filename) == '0a1c945d4f2a29beba87d67c755eaabd5ff12b9d'

# Generated at 2022-06-17 15:06:18.565841
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:06:28.481094
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create a file
    f = open("testfile", "w")
    f.write("Hello World")
    f.close()

    # Calculate the md5 checksum
    checksum = md5("testfile")

    # Remove the temporary directory
    os.chdir(curdir)
    shutil.rmtree(tmpdir)

    # Assert that the checksum is correct
    assert checksum == "ed076287532e86365e841e92bfc50d8c"

# Generated at 2022-06-17 15:06:38.616685
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf0f8d16c37bb8a00c386e8e1b'
    assert checksum('/bin/ls', sha1) == '6b8e3eaf0f8d16c37bb8a00c386e8e1b'
    assert checksum('/bin/ls', sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls')
    assert checksum_s('/bin/ls') == checksum_s('/bin/ls', sha1)

# Generated at 2022-06-17 15:06:41.376810
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf88ec2ebd9e8a1e1a6f5dce81'


# Generated at 2022-06-17 15:06:47.220318
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:06:50.169269
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo') == md5s('foo')
    assert md5s('foo') != md5s('bar')


# Generated at 2022-06-17 15:06:53.470506
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c5a0dea6a65e6a0c6'


# Generated at 2022-06-17 15:06:55.462654
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:07:06.767872
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '98c6e5f3d9e93c71418e2c0e9f541f3e'
    assert md5s('qux') == '31d6cfe0d16ae931b73c59d7e0c089c0'
    assert md5s('quux') == 'ed076287532e86365e841e92bfc50d8c'

# Generated at 2022-06-17 15:07:13.690030
# Unit test for function md5
def test_md5():
    ''' test_md5.py:  unit test for md5 '''
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test_md5.txt"), "wb")
    f.write("This is a test")
    f.close()

    # Calculate the md5 checksum
    md5sum = md5(os.path.join(tmpdir, "test_md5.txt"))

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

    # Make sure the md5 checksum is correct

# Generated at 2022-06-17 15:07:16.148502
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:07:22.118204
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '4a8f213e2c18c6e87a2c33f9e1d3f324'


# Generated at 2022-06-17 15:07:29.950608
# Unit test for function md5
def test_md5():
    '''
    Test md5 function
    '''
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test file content')
    f.close()

    # Calculate the md5 checksum
    checksum = md5(os.path.join(tmpdir, 'test'))

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

    # Assert the checksum
    assert checksum == 'e59ff97941044f85df5297e1c302d260'

# Generated at 2022-06-17 15:07:39.516775
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
            checksum_algorithm = dict(default='sha1', choices=['sha1', 'md5']),
        ),
        supports_check_mode=True
    )

    path = module.params['path']
    checksum_algorithm = module.params['checksum_algorithm']

    if checksum_algorithm == 'md5':
        if _md5:
            checksum_func = md5
        else:
            module.fail_json(msg='MD5 not available.  Possibly running in FIPS mode')

# Generated at 2022-06-17 15:07:42.798161
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:07:44.024726
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:07:56.411998
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'dffd6021bb2bd5b0af676290809ec3a53191dd81'
    assert md5s('hello\n\n') == 'f0e4c2f76c58916ec258f246851bea091d14d4247a2fc3e18694461b1816e13b'
    assert md5s('hello\n\n\n') == 'f0e4c2f76c58916ec258f246851bea091d14d4247a2fc3e18694461b1816e13b'

# Generated at 2022-06-17 15:08:08.149810
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for ansible.utils.checksum '''

    import os
    import tempfile

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    from ansible.utils import checksum

    class TestChecksum(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.tmpfile = tempfile.NamedTemporaryFile(dir=self.tmpdir)
            self.tmpfile.write(b"Hello World")
            self.tmpfile.flush()

        def tearDown(self):
            self.tmpfile.close()
            os.rmdir(self.tmpdir)


# Generated at 2022-06-17 15:08:11.022784
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b3f3e2d6f0f45fbd8b1d7a8afc6d0b0f'


# Generated at 2022-06-17 15:08:18.465299
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world!') == 'f8c7e0d5f7c7d8b8c8b8c7d8f7e0d5f8'


# Generated at 2022-06-17 15:08:21.740947
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c5f497db0f5e8f4ae'


# Generated at 2022-06-17 15:08:26.593533
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f8d16c37e1d22908e6c2b30'


# Generated at 2022-06-17 15:08:31.652621
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5('/etc/passwd') == '6e8eceb8c9e1f9fdbd8bf8d7d3f0d3b2'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:08:35.581029
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "f2c7ddd8a92d0d785f6eafc2831ba68a"
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"


# Generated at 2022-06-17 15:08:49.072783
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '914f244fdbf579fa6a69e5d9e5d9e618'
    assert md5s('hello\n\n') == 'c7ef86a7a1b7b8a92d9b75fb7e0cda9d'
    assert md5s('hello\n\n\n') == '6b9cdc24fc21e1cdea8e83a7f8ccd6b8'
    assert md5s('hello\n\n\n\n') == 'c9f15b6c2a61d3d6e2e43a7a3d964b0a'


# Generated at 2022-06-17 15:08:58.587254
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0e5fe84ad3518c83ce8c0bebab'
    assert checksum('/bin/ls', hash_func=_md5) == '8c2e7d5b0e3a7f17b7c27ab1c9eeb5a9'
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5

# Generated at 2022-06-17 15:09:09.548590
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0e1ab6c38b8f91209c2e9f8f5a7fcb6753'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:09:18.289736
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0e3e6a4ea44a3c133c6a0ab5b1d45b3ccb'
    assert checksum('/bin/ls', sha1) == '6b8e3e0e3e6a4ea44a3c133c6a0ab5b1d45b3ccb'
    assert checksum('/bin/ls', _md5) == 'c4f0d66b1feddc3e8dc085d4c3df2b08'


# Generated at 2022-06-17 15:09:24.244954
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum('/etc/passwd') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum('/etc/passwd', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
   

# Generated at 2022-06-17 15:09:27.244015
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:09:28.308020
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:09:29.523525
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d8f5e7e24f54a39bd'


# Generated at 2022-06-17 15:09:36.221575
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum functions '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the file
    fd = open(fname, 'w')
    fd.write('test data')
    fd.close()

    # Get the checksum of the file
    checksum = secure_hash(fname)

    # Remove the temporary file
    os.unlink(fname)

    # Create a module object

# Generated at 2022-06-17 15:09:46.942310
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == '81fe8bfe87576c3ecb22426f8e57847382917acf'

# Generated at 2022-06-17 15:09:52.264225
# Unit test for function md5
def test_md5():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.exit_json(changed=False, ansible_facts={'test_md5': md5('/etc/passwd')})


# Generated at 2022-06-17 15:09:53.909490
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:10:01.002110
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test_checksum"), "wb")
    f.write(b"foo")
    f.close()

    # Test checksum
    assert checksum(os.path.join(tmpdir, "test_checksum")) == "acbd18db4cc2f85cedef654fccc4a4d8"

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:10:02.959930
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-17 15:10:07.431535
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'


# Generated at 2022-06-17 15:10:18.949248
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-17 15:10:23.612094
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls') == 'b5a5f5f4b4a0f4e2f0e9c7a2c5d0d7f2'

# Generated at 2022-06-17 15:10:27.115144
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5('/etc/passwd')

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-17 15:10:36.166765
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello\nworld') == '7f9a0d5a8f0524d4a04b0d4c37c6cec9'
    assert md5s('hello\rworld') == '7f9a0d5a8f0524d4a04b0d4c37c6cec9'
    assert md5s('hello\r\nworld') == '7f9a0d5a8f0524d4a04b0d4c37c6cec9'

# Generated at 2022-06-17 15:10:47.467827
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'e19d5cd5af0378da05f63f891c7467af'
    assert md5s('hello\n\n') == 'c7ef86a6d8b8b78e957a9e47d9c212d8'
    assert md5s('hello\n\n\n') == 'd3b07384d113edec49eaa6238ad5ff00'
    assert md5s('hello\n\n\n\n') == 'e4d909c290d0fb1ca068ffaddf22cbd0'
    assert md5s('hello\n\n\n\n\n')

# Generated at 2022-06-17 15:10:53.468154
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == md5s('test')
    assert md5s('test') != md5s('test2')


# Generated at 2022-06-17 15:10:55.920117
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9a5dbf7b1b0d646b8faa'


# Generated at 2022-06-17 15:11:06.441014
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    try:
        tmpdir = tempfile.mkdtemp()
        testfile = os.path.join(tmpdir, 'testfile')
        f = open(testfile, 'w')
        f.write('test')
        f.close()
        assert md5(testfile) == '098f6bcd4621d373cade4e832627b4f6'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:11:10.918616
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d6fa148924b43c7dc'


# Generated at 2022-06-17 15:11:19.129081
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "testfile"), "wb")
    f.write(b"Hello World")
    f.close()
    # Compute the md5 checksum
    md5sum = md5(os.path.join(tmpdir, "testfile"))
    # Remove the temporary directory
    shutil.rmtree(tmpdir)
    assert md5sum == "ed076287532e86365e841e92bfc50d8c"

# Generated at 2022-06-17 15:11:21.209568
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:11:28.719744
# Unit test for function checksum
def test_checksum():
    '''
    ansible.utils.checksum - Test checksum function
    '''
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Create a temporary subdirectory
    subdir = os.path.join(tmpdir, 'subdir')
    os.mkdir(subdir)

    # Test checksum function
    assert checksum(fname) == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert checksum(subdir) is None

# Generated at 2022-06-17 15:11:39.271087
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert checksum('/bin/ls') == 'f3d7e0c8e8e8f9f1c2e7f8d7f3b9d8b2'
    assert checksum('/bin/ls', hash_func=_md5) == 'f3d7e0c8e8e8f9f1c2e7f8d7f3b9d8b2'

# Generated at 2022-06-17 15:11:50.865196
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile
    import shutil

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='path'),
            checksum_algorithm=dict(required=False, default='sha1', choices=['sha1', 'md5']),
        ),
        supports_check_mode=True
    )

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

# Generated at 2022-06-17 15:12:00.444559
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0dac6b8dda8c7dda6c9a0c99'
    assert checksum('/bin/ls', sha1) == '6b8e3e2e0dac6b8dda8c7dda6c9a0c99'
    assert checksum('/bin/ls', sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls', sha1)
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls', sha1)
   

# Generated at 2022-06-17 15:12:04.986269
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:11.510381
# Unit test for function md5
def test_md5():
    ''' test md5 function '''
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    testfile = os.path.join(tmpdir, 'testfile')
    with open(testfile, 'w') as f:
        f.write('test')
    assert md5(testfile) == '098f6bcd4621d373cade4e832627b4f6'
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:12:14.216855
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "6b16f98b6b8a7d0b6e5b3d7b6a5b4a6b"


# Generated at 2022-06-17 15:12:16.349863
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8be1e937ed6e0ff1d8b7b6e2b388a4'


# Generated at 2022-06-17 15:12:24.735739
# Unit test for function md5s
def test_md5s():
    '''
    Test md5s function
    '''
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s(u'test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s(b'test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:12:27.976816
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "4a8a6d1c2c7a1c1e7d7dc97f9dfb80f8"


# Generated at 2022-06-17 15:12:37.237237
# Unit test for function checksum
def test_checksum():
    ''' test checksum function '''
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_file_content = 'test_file_content'
    test_file_content_hash = 'f1c96f8e7a9b9c8b8c5c3c4c7c1c3c0c'
    test_file_content_hash_s = 'f1c96f8e7a9b9c8b8c5c3c4c7c1c3c0c'

# Generated at 2022-06-17 15:12:40.610137
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:12:42.809415
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf9d06e0c2e447d23e8ad398b2'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-17 15:12:45.955787
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    else:
        try:
            md5s('test')
            assert False
        except ValueError:
            pass


# Generated at 2022-06-17 15:12:59.229562
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'e2c569be17396eca2a2e3c11578123ed'
    assert md5s('hello\n\n') == 'f3b3b1e9b4af4f1fbf2c4f2b7a27fee5'
    assert md5s('hello\n\n\n') == 'f3b3b1e9b4af4f1fbf2c4f2b7a27fee5'
    assert md5s('hello\n\n\n\n') == 'f3b3b1e9b4af4f1fbf2c4f2b7a27fee5'
   

# Generated at 2022-06-17 15:13:11.123264
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:13:13.031376
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"


# Generated at 2022-06-17 15:13:20.460975
# Unit test for function md5
def test_md5():
    '''
    ansible.utils.md5 unit test
    '''
    import tempfile

    fd, fname = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('hello')
    f.close()

    assert md5(fname) == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

    os.unlink(fname)

# Generated at 2022-06-17 15:13:28.070525
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0c7bfbfdb2f38edffc6eb14f17'
    assert checksum('/bin/ls', sha1) == '6b8e3e0c7bfbfdb2f38edffc6eb14f17'
    assert checksum('/bin/ls', _md5) == '6b8e3e0c7bfbfdb2f38edffc6eb14f17'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls')
    assert checksum('/bin/ls', _md5) == checksum_s('/bin/ls', _md5)


# Generated at 2022-06-17 15:13:33.658246
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:13:37.068464
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:13:47.154604
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf0f8d16b8c49b46b7e0f60c51'
    assert checksum('/bin/ls', hash_func=_md5) == 'a9d6a9e9b0c2d8a7a9a9a9a9a9a9a9a9'
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:13:49.212985
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:13:56.865529
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\n') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\r\n') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\r') == '5eb63bbbe01eeed093cb22bb8f5acdc3'