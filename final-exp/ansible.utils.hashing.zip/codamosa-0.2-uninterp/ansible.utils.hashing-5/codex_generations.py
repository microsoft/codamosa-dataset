

# Generated at 2022-06-17 15:04:05.760369
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'a9d6bae85f7aebd5d5f838faa54f1d54'
    assert checksum('/bin/ls', sha1) == 'a9d6bae85f7aebd5d5f838faa54f1d54'
    assert checksum('/bin/ls', _md5) == 'a9d6bae85f7aebd5d5f838faa54f1d54'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls')


# Generated at 2022-06-17 15:04:12.564177
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e0c863f4e4a01c8c7a526922d5bf9'
    assert checksum('/bin/ls', hash_func=_md5) == 'f5d2bf8d7e0d5fcec8b7d8a9a31e0e0b'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:04:23.012714
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf0f8d09af95e9b3d8d3f0d7d3'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == md5s('hello')
    assert checksum('/bin/ls', hash_func=_md5) == '6b8e3eaf0f8d09af95e9b3d8d3f0d7d3'

# Generated at 2022-06-17 15:04:32.049540
# Unit test for function md5
def test_md5():
    '''
    ansible.utils.md5 unit test
    '''
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_file_contents = 'test_file_contents'
    test_file_md5 = 'd41d8cd98f00b204e9800998ecf8427e'

    try:
        with open(test_file, 'w') as f:
            f.write(test_file_contents)

        assert test_file_md5 == md5(test_file)
    finally:
        shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:04:46.205656
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file
    (tmpfd, tmpfname) = tempfile.mkstemp()
    os.close(tmpfd)

    # Write some data to it
    f = open(tmpfname, 'w')
    f.write('test data')
    f.close()

    # Make sure the checksum is correct
    assert checksum(tmpfname) == '9ac86d8d3b7f3d8a6a63f8e5d5c98e11d8c2b761'

    # Remove the temporary file
    os.remove(tmpfname)

    # Make sure the checksum is None for

# Generated at 2022-06-17 15:04:49.886118
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("hello") == md5s("hello")
    assert md5s("hello") != md5s("hello2")


# Generated at 2022-06-17 15:04:59.776684
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert checksum('/bin/ls') == 'b7c9b8d9f9b8d6b4c7f4b4f4d8d4f4c4'
    assert checksum('/bin/ls', hash_func=_md5) == 'e2fc714c4727ee9395f324cd2e7f331f'
    assert checksum('/bin/ls', hash_func=_md5) == md5('/bin/ls')
    assert checksum

# Generated at 2022-06-17 15:05:12.117690
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n\r\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:05:22.634025
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    def cleanup(filename):
        try:
            os.unlink(filename)
        except:
            pass

    def test_checksum(data, expected):
        (fd, filename) = tempfile.mkstemp()
        f = os.fdopen(fd, 'w')
        f.write(data)
        f.close()
        result = checksum(filename)
        cleanup(filename)
        if result != expected:
            raise AssertionError("Expected %s, got %s" % (expected, result))

    def test_checksum_s(data, expected):
        result = checksum_s(data)

# Generated at 2022-06-17 15:05:34.407236
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0dacab4e4b8c49b11e6c2b08'
    assert checksum('/bin/ls', hash_func=_md5) == 'b8c9d9e8e8d5f1f0c6a60a0ed3a8d8d3'
    assert checksum('/bin/ls', hash_func=sha1) == '6b8e3e2e0dacab4e4b8c49b11e6c2b08'
    assert checksum('/bin/ls', hash_func=sha1) == checksum('/bin/ls')

# Generated at 2022-06-17 15:05:42.396003
# Unit test for function md5
def test_md5():
    ''' test md5 function '''

    from ansible.compat.tests import unittest

    class TestMd5(unittest.TestCase):

        def test_md5(self):
            ''' test md5 function '''
            self.assertEqual(md5('/bin/ls'), '6b8be1e9cdad44b8a58f2d5c966a76ae')

    unittest.main(verbosity=2)

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-17 15:05:44.011550
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8be1e927b0ebd8d9a2a7146a2c6f91'


# Generated at 2022-06-17 15:05:49.012707
# Unit test for function checksum
def test_checksum():
    assert checksum('test/utils/checksum.py') == 'c8bdbf7d8c1f8f7d9b9a9d9c9a9b9c9d'
    assert checksum('test/utils/checksum.py', hash_func=sha1) == 'c8bdbf7d8c1f8f7d9b9a9d9c9a9b9c9d'
    assert checksum('test/utils/checksum.py', hash_func=_md5) == 'c8bdbf7d8c1f8f7d9b9a9d9c9a9b9c9d'
    assert checksum('test/utils/checksum.py', hash_func=_md5) == md5('test/utils/checksum.py')
   

# Generated at 2022-06-17 15:05:52.880868
# Unit test for function md5
def test_md5():
    ''' test md5 function '''
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')

    with open(test_file, 'w') as f:
        f.write('test')

    assert md5(test_file) == '098f6bcd4621d373cade4e832627b4f6'

    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:06:04.600326
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "6b8e3eaf1f5f2e3dbaadc8f173f0c112"
    assert checksum("/bin/ls", hash_func=_md5) == "0e9e643b28b9014c7d2a02824fdbb1d8"
    assert checksum("/bin/ls", hash_func=sha1) == "6b8e3eaf1f5f2e3dbaadc8f173f0c112"
    assert checksum("/bin/ls", hash_func=sha1) == checksum("/bin/ls")
    assert checksum("/bin/ls", hash_func=_md5) == checksum("/bin/ls", hash_func=_md5)

# Generated at 2022-06-17 15:06:10.769107
# Unit test for function md5
def test_md5():
    '''
    ansible.utils.md5 unit test
    '''
    import tempfile

    fd, fname = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('hello')
    f.close()
    assert md5(fname) == '5d41402abc4b2a76b9719d911017c592'
    os.unlink(fname)

# Generated at 2022-06-17 15:06:16.561135
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:06:28.831199
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'f0b8a8d9d8c8d6c8a1a8c8d8d8f0d0d0'
    assert md5('/bin/ls') == 'f0b8a8d9d8c8d6c8a1a8c8d8d8f0d0d0'
    assert md5('/bin/ls') == 'f0b8a8d9d8c8d6c8a1a8c8d8d8f0d0d0'
    assert md5('/bin/ls') == 'f0b8a8d9d8c8d6c8a1a8c8d8d8f0d0d0'

# Generated at 2022-06-17 15:06:38.920687
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:06:43.332429
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == md5('test')
    assert md5s('test') == md5s('test')
    assert md5s('test') == md5('test')
    assert md5s('test') == md5s('test')
    assert md5s('test') == md5('test')
    assert md5s('test') == md5s('test')
    assert md5s('test') == md5('test')
    assert md5s('test') == md5s('test')
    assert md5s('test') == md5('test')
    assert md5s('test') == md5s('test')

# Generated at 2022-06-17 15:06:48.410743
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b4b5f875e3a9fad4a9f9d4c4b7c1e0e0'


# Generated at 2022-06-17 15:06:50.552114
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:06:59.590143
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("hello" * 100) == "9d5ed678fe57bcca610140957afab571"
    assert md5s("") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5s("hello", _md5) == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("hello" * 100, _md5) == "9d5ed678fe57bcca610140957afab571"
    assert md5s("", _md5) == "d41d8cd98f00b204e9800998ecf8427e"


# Generated at 2022-06-17 15:07:02.759325
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b7c3e9d4f4f7d4a0b4c481b8549f88d5'


# Generated at 2022-06-17 15:07:13.422790
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum functions '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='str'),
            content = dict(required=False, type='str'),
        ),
        supports_check_mode=True
    )

    path = module.params['path']
    content = module.params['content']

    if content is not None:
        (fd, path) = tempfile.mkstemp()
        f = os.fdopen(fd, 'w')
        f.write(content)
        f.close()


# Generated at 2022-06-17 15:07:17.408354
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5('/etc/passwd') == 'c21f969b5f03d33d43e04f8f136e7682'

# Generated at 2022-06-17 15:07:28.594690
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f5cacb8d0f3b7a3f9b8d924'
    assert checksum('/bin/ls', hash_func=_md5) == '5a105e8b9d40e1329780d62ea2265d8a'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
   

# Generated at 2022-06-17 15:07:30.595249
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9b9aebf3b0e2c9dec9bf'


# Generated at 2022-06-17 15:07:39.115631
# Unit test for function md5
def test_md5():
    ''' test_md5.py: Unit test for function md5 '''

    import tempfile

    # Create a temporary file
    fd, temp_file = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the temporary file
    fd = open(temp_file, 'w')
    fd.write('Hello World')
    fd.close()

    # Calculate the md5 checksum
    md5sum = md5(temp_file)

    # Remove the temporary file
    os.remove(temp_file)

    # Assert that the md5 checksum is correct
    assert md5sum == 'ed076287532e86365e841e92bfc50d8c'


# Generated at 2022-06-17 15:07:48.441915
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\n') == '7b502c3a1f48c8609ae212cdfb639dee'
    assert md5s('hello\nworld') == 'e59ff97941044f85df5297e1c302d260'
    assert md5s('hello\nworld\n') == 'ed076287532e86365e841e92bfc50d8c'

# Generated at 2022-06-17 15:07:58.888939
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == '81dc9bdb52d04dc20036dbd8313ed055'

# Generated at 2022-06-17 15:08:11.161157
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0cbe0c50b6149c44d2b904c3a7fa910d'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', _md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', _md5) == md5s('hello')
    assert checksum('/bin/ls', _md5) == '6b8e3e2e0cbe0c50b6149c44d2b904c3a7fa910d'

# Generated at 2022-06-17 15:08:21.893125
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0a9f8ca29e0b93efcad9d0c4'
    assert checksum('/bin/ls', 'sha1') == '6b8e3e2e0a9f8ca29e0b93efcad9d0c4'
    assert checksum('/bin/ls', 'sha256') == '9a8c8c8e0f1c9f5e5a8e0f8f0c0a9c8c9e8f1c0e5e5f1c0c9c8e0f8f0c0a9c8c'

# Generated at 2022-06-17 15:08:33.399932
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3d8f5e7d76f5fad02e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-17 15:08:37.150562
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:08:41.751237
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b8f8d9a3c9e9b9c1f8f8c9a3b9d9e1d9'


# Generated at 2022-06-17 15:08:48.146827
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'


# Generated at 2022-06-17 15:08:52.207483
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '4a8f213e2c18b11a2f396ae1ad3c88e5'


# Generated at 2022-06-17 15:08:59.868237
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n\r\n\r\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:09:04.569445
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5('/bin/ls') == 'b7b8d8c7f0c0f8e8c7a8c8d0c0d0c8c8'

# Generated at 2022-06-17 15:09:18.479159
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0dac6b8c49fda0c8c70a27c3'
    assert checksum('/bin/ls', hash_func=_md5) == 'e2a3c8f5d5c3d0c4a8a5d62242739168'
    assert checksum('/bin/ls', hash_func=sha1) == '6b8e3e2e0dac6b8c49fda0c8c70a27c3'
    assert checksum('/bin/ls', hash_func=sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls', hash_func=_md5) == checksum('/bin/ls', hash_func=_md5)

# Generated at 2022-06-17 15:09:20.428004
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == md5('test')

# Generated at 2022-06-17 15:09:32.791756
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  tests for utils.checksum '''

    import os
    import tempfile
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_checksum')

    with open(test_file, 'w') as f:
        f.write('test')

    assert checksum(test_file) == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum(test_file) == checksum_s('test')
    assert checksum(test_file) == checksum_s(AnsibleUnsafeText('test'))

    os.remove(test_file)


# Generated at 2022-06-17 15:09:46.414449
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for ansible.utils.checksum '''

    import tempfile

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the temporary file
    f = open(temp_path, 'w')
    f.write('Hello World')
    f.close()

    # Verify that the checksum of the temporary file is correct
    assert checksum(temp_path) == '0a4d55a8d778e5022fab701977c5d840bbc486d0'

    # Remove the temporary file
    os.remove(temp_path)

    # Verify that the checksum of a non-existent file is None
    assert checksum(temp_path) is None

    # Verify that the

# Generated at 2022-06-17 15:09:55.249383
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum functions '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    def test_checksum_s(data, expected):
        ''' Test checksum_s() '''

        result = checksum_s(data)
        assert result == expected, "Expected %s, got %s" % (expected, result)

    def test_checksum(data, expected):
        ''' Test checksum() '''

        (fd, fname) = tempfile.mkstemp()
        f = os.fdopen(fd, 'w')
        f.write(data)
        f.close()
        result = checksum(fname)
        os.unlink(fname)

# Generated at 2022-06-17 15:10:00.004748
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:10:02.032413
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:10:05.794345
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:10:16.930953
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\r') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n\r\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:10:19.472445
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:10:27.441493
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    test_file = os.path.join(tmpdir, "test_file")
    with open(test_file, "w") as f:
        f.write("test")
    assert md5(test_file) == "098f6bcd4621d373cade4e832627b4f6"
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:10:36.392529
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf9480de5d7a0cdcb34f0ff3ea'
    assert checksum('/bin/ls', sha1) == '6b8e3eaf9480de5d7a0cdcb34f0ff3ea'
    assert checksum('/bin/ls', _md5) == '6b8e3eaf9480de5d7a0cdcb34f0ff3ea'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls') == checksum('/bin/ls')
    assert checksum('/bin/ls') == checks

# Generated at 2022-06-17 15:10:47.595067
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_file_contents = 'This is a test file'

    with open(test_file, 'w') as f:
        f.write(test_file_contents)

    assert checksum(test_file) == 'f1c96f8d7d3b5e3f3d0c92141f7e2b3a9d9a0e0f'
    assert checksum_s(test_file_contents) == 'f1c96f8d7d3b5e3f3d0c92141f7e2b3a9d9a0e0f'


# Generated at 2022-06-17 15:10:57.939132
# Unit test for function md5
def test_md5():
    ''' test md5 function '''
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert md5s('qux') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'
    assert md5s('quux') == '81fe8bfe87576c3ecb22426f8e57847382917acf'
    assert md5s

# Generated at 2022-06-17 15:11:04.690407
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls') == 'b5a3f5d1e6d8a0c1f5fadc7d7b8c61b2'

# Generated at 2022-06-17 15:11:10.192607
# Unit test for function md5
def test_md5():
    ''' md5.py: Test md5() function '''
    from ansible.compat.tests import unittest
    import os

    class TestMd5(unittest.TestCase):

        def setUp(self):
            self.filename = os.path.join(os.path.dirname(__file__), 'test_md5.txt')
            with open(self.filename, 'w') as f:
                f.write('test')

        def tearDown(self):
            os.unlink(self.filename)

        def test_md5(self):
            ''' md5: Test md5() function '''
            self.assertEqual(md5(self.filename), '098f6bcd4621d373cade4e832627b4f6')


# Generated at 2022-06-17 15:11:12.575891
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:11:23.629641
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "6b8e3eaf1f9e9a7d8a99f1d9c8ccb141"
    assert checksum("/bin/ls", hash_func=_md5) == "a9d5a7d5f6e8f7a8a3c4d4a4b4a8a5a5"
    assert checksum("/bin/ls", hash_func=sha1) == "6b8e3eaf1f9e9a7d8a99f1d9c8ccb141"
    assert checksum("/bin/ls", hash_func=sha1) == checksum("/bin/ls")

# Generated at 2022-06-17 15:11:25.663931
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c5e099c5e7c5f5f5a'


# Generated at 2022-06-17 15:11:35.980483
# Unit test for function md5
def test_md5():
    ''' md5.py: Test md5() function '''

    import tempfile

    # Create a temporary file
    fd, fname = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the file
    fd = open(fname, 'wb')
    fd.write(b'abc')
    fd.close()

    # Calculate the md5 checksum
    md5sum = md5(fname)

    # Remove the temporary file
    os.unlink(fname)

    # The md5 checksum should be 900150983cd24fb0d6963f7d28e17f72
    assert md5sum == '900150983cd24fb0d6963f7d28e17f72'


# Generated at 2022-06-17 15:11:50.269495
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf9dfba8fc0354bb5f9a325750f1f8f363'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', _md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert checksum_s('hello world', _md5) == md5s('hello world')
    assert checksum('/bin/ls', _md5) == '7f9a0d9a96498f8e6d61c4c74a08b943'

# Generated at 2022-06-17 15:12:00.031494
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == 'd6a9a4c9e9b9f9f9f9f9f9f9f9f9f9f9'
    assert md5s('hello\n\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\n\n\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'

# Generated at 2022-06-17 15:12:06.230048
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == md5('test')
    assert md5s('test') == md5s('test')
    assert md5('test') == md5('test')
    assert md5('test') != md5('test2')
    assert md5s('test') != md5s('test2')

# Generated at 2022-06-17 15:12:08.765277
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b026324c6904b2a9cb4b88d6d61c81d1'


# Generated at 2022-06-17 15:12:11.414136
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b9d9a59e13c5f747a08ddc3d5ee3c048'


# Generated at 2022-06-17 15:12:13.448994
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:20.271242
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b9cbf25a1c5b5bfab07f4c49d8e6b971'
    assert md5('/bin/cat') == '6b9cd5b0acb277c200c40e3e8f7e77e1'
    assert md5('/bin/grep') == 'c2f1b7f2e9cadb3f9d3b7f8b7c3f9a37'
    assert md5('/bin/pwd') == 'f0fa8dbc0afc2c3c2b836750d5f1c9c9'
    assert md5('/bin/sleep') == '8b0a15eefe63fd41f8dc9dee01c5cf9a'


# Generated at 2022-06-17 15:12:26.674352
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:27.688373
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:12:33.585036
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '983e5152eeb2b778eec6b2e7c72a9c4a'


# Generated at 2022-06-17 15:12:47.221799
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test"), "wb")
    f.write(b"foo")
    f.close()

    # Test checksum
    assert checksum(os.path.join(tmpdir, "test")) == "acbd18db4cc2f85cedef654fccc4a4d8"

    # Test checksum_s
    assert checksum_s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"

    # Remove the temporary directory after the test
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:12:53.782451
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os
    import stat

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temp directory
    (fd, fname) = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, "w")
    f.write("This is a test")
    f.close()

    # Make the file read only
    os.chmod(fname, stat.S_IREAD)

    # Get the md5 checksum of the file
    checksum = md5(fname)

    # Remove the temp directory
    shutil.rmtree(tmpdir)

    # The checksum should be "e2fc714c4727ee9395f324cd2e7f331f"
    assert checksum

# Generated at 2022-06-17 15:12:58.543236
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b4b5f875cffd4f9e8d3b5f2b4e8c9aad'


# Generated at 2022-06-17 15:13:06.617195
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e0c5b5f4631b3d0f2b05b485c5fad'
    assert checksum('/bin/ls', hash_func=_md5) == 'f0ef7081e74f0e92a13ea0f2b7fbbbce'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:13:14.512871
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0a9f8ca29e0b97f7b3f3e9c7'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls') == '6b8e3e2e0a9f8ca29e0b97f7b3f3e9c7'

# Generated at 2022-06-17 15:13:23.756893
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello ') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world ') == '7c222fb2927d828af22f592134e89324'
    assert md5s('hello world!') == 'fcea920f7412b5da7be0cf42b8c93759'

# Generated at 2022-06-17 15:13:27.118030
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:13:31.124697
# Unit test for function md5
def test_md5():
    ''' test md5 function '''
    assert md5('/bin/ls') == '4b7dbc5f5b5b5b5b5b5b5b5b5b5b5b5b'


# Generated at 2022-06-17 15:13:38.850140
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == 'f0e4c2f76c58916ec258f246851bea09'
    assert md5s('hello\n\n\n') == 'f0e4c2f76c58916ec258f246851bea09'
    assert md5s('hello\n\n\n\n') == 'f0e4c2f76c58916ec258f246851bea09'

# Generated at 2022-06-17 15:13:47.629882
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s("hello world\n") == "e59ff97941044f85df5297e1c302d260"
    assert md5s("hello world\n\n") == "a948904f2f0f479b8f8197694b30184b"
    assert md5s("hello world\n\n\n") == "f7ff9e8b7bb2e09b70935a5d785e0cc5"
    assert md5s("hello world\n\n\n\n") == "f7ff9e8b7bb2e09b70935a5d785e0cc5"

# Generated at 2022-06-17 15:13:52.352499
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:13:54.308347
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c5f497db3f6086e25'


# Generated at 2022-06-17 15:13:56.128741
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "6b890c92926e89e871f2afd633f2c862"


# Generated at 2022-06-17 15:13:59.757748
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0e3e6a4ea44a3f3e0d7d45b754a0c8e8d3'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', _md5) == '5d41402abc4b2a76b9719d911017c592'