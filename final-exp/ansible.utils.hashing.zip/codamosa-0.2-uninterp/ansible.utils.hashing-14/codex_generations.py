

# Generated at 2022-06-17 15:04:12.625449
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d8af8e79c8b52d8e4e2'
    assert checksum('/bin/ls', hash_func=_md5) == 'f8dff4a0f8c9ca2d83a0f60f4c3934c8'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:04:23.845963
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
            hash_algorithm = dict(default='sha1', choices=['sha1', 'sha256', 'sha512', 'md5'])
        ),
        supports_check_mode=True
    )

    path = module.params['path']
    hash_algorithm = module.params['hash_algorithm']

    if not os.path.exists(path):
        module.fail_json(msg="Source %s not found" % (path))


# Generated at 2022-06-17 15:04:33.351902
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:04:46.650740
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp()

    # Write some data to the file
    os.write(fd, b"Hello World")
    os.close(fd)

    # Create a module
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='str'),
        ),
        supports_check_mode=True
    )

    # Run the checksum module
    module.run_command_environ_update = dict(LANG='C', LC_ALL='C', LC_MESSAGES='C', LC_CTYPE='C')

# Generated at 2022-06-17 15:04:54.889604
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum functions '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp()

    # Write some data to the file
    os.write(fd, b"Hello World")
    os.close(fd)

    # Get the checksum of the file
    chksum = module.checksum(fname)

    # Remove the temporary file
    os.remove(fname)

    # Fail the test if the checksum is incorrect
    if chksum != "b10a8db164e0754105b7a99be72e3fe5":
        module.fail_json

# Generated at 2022-06-17 15:04:57.969923
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls') == '8b7dfd297c91c71a2307d3d74f0644cd'

# Generated at 2022-06-17 15:05:06.841911
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5s('hello') != md5s('helloo')
    assert md5s('hello') != md5s('hell')
    assert md5s('hello') != md5s('h')
    assert md5s('hello') != md5s('he')
    assert md5s('hello') != md5s('hel')
    assert md5s('hello') != md5s('hell')
    assert md5s('hello') != md5s('hell')
    assert md5s('hello') != md5s('hell')

# Generated at 2022-06-17 15:05:16.069976
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '4b8e0c85a29d63839d9581ba4e8d8c3f'
    assert md5('/bin/cat') == 'e5a0d5a91d4e8b25a2ca108d9bb9f8d8'
    assert md5('/bin/grep') == '8a8f60b0e5cda30c0aee1f8e8b64c8b4'
    assert md5('/bin/pwd') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/sleep') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-17 15:05:24.003781
# Unit test for function md5
def test_md5():
    ''' test_md5.py: Unit test for function md5 '''
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')

    # Create a test file
    with open(test_file, 'w') as f:
        f.write('Hello World')

    # Test md5
    assert md5(test_file) == 'ed076287532e86365e841e92bfc50d8c'

    # Cleanup
    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:05:28.524863
# Unit test for function md5s
def test_md5s():
    '''
    Test md5s function
    '''
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') != '098f6bcd4621d373cade4e832627b4f7'


# Generated at 2022-06-17 15:05:34.513604
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    else:
        try:
            md5s('foo')
            assert False
        except ValueError:
            pass

# Generated at 2022-06-17 15:05:43.148910
# Unit test for function md5

# Generated at 2022-06-17 15:05:44.534117
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:05:56.900854
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp(dir=tmpdir)

    # Write some data to the file
    os.write(fd, b"This is some test data")
    os.close(fd)

    # Get the checksum
    checksum = secure_hash(temp_path)

    # Make sure the checksum is correct
    assert checksum == 'b9c4b9e49bfef70b9a3a5e2ed2e0f174e6a0e41e', "Checksum failed"

    # Remove the temporary file
   

# Generated at 2022-06-17 15:06:06.653771
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '914f244f07fc645438a139d75c98d8e1'
    assert md5s('hello\r\n') == '914f244f07fc645438a139d75c98d8e1'
    assert md5s('hello\r') == '914f244f07fc645438a139d75c98d8e1'
    assert md5s('hello\r\n\r\n') == '914f244f07fc645438a139d75c98d8e1'

# Generated at 2022-06-17 15:06:08.652595
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:06:14.272264
# Unit test for function md5
def test_md5():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5("/bin/cat") == "e5d3d79f2b0df85efe0ff7fbb58f52f7"
    assert md5("/bin/cat2") is None


# Generated at 2022-06-17 15:06:16.178076
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:06:21.329708
# Unit test for function md5
def test_md5():
    ''' md5 unit test '''
    import tempfile

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    f = open(temp_path, 'w')
    f.write('test')
    f.close()

    # Test md5
    assert md5(temp_path) == '098f6bcd4621d373cade4e832627b4f6'

    # Remove the temporary file
    os.remove(temp_path)

# Generated at 2022-06-17 15:06:27.393713
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test')
    assert md5(test_file) == '098f6bcd4621d373cade4e832627b4f6'
    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:06:40.932260
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0a9f8eefb7251b0c124c8683'
    assert checksum('/bin/ls', hash_func=_md5) == 'c4d0f2c3d4f8f9c8e0c6e3d4f8d0c3c4'
    assert checksum('/bin/ls', hash_func=sha1) == '6b8e3e2e0a9f8eefb7251b0c124c8683'
    assert checksum('/bin/ls', hash_func=sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls', hash_func=_md5) == md5('/bin/ls')

# Generated at 2022-06-17 15:06:50.638196
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf9480b9d3618b1e1d5baba6c4d8e04a5f'
    assert checksum('/bin/ls', hash_func=_md5) == 'f0ffa4c9e5e3d28a3d3f5e64c0c5dde3'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:06:53.907814
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'f0c8e9e6c9f7f9a2a1a3a8c6c3c0c4c5'


# Generated at 2022-06-17 15:07:04.281684
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '4b7c5650008b2bf95d0e12d8a931aeb1'
    assert checksum('/bin/ls', hash_func=_md5) == '4b7c5650008b2bf95d0e12d8a931aeb1'
    assert checksum('/bin/ls', hash_func=sha1) == '4b7c5650008b2bf95d0e12d8a931aeb1'
    assert checksum('/bin/ls', hash_func=sha1) == checksum('/bin/ls')
    assert checksum('/bin/ls', hash_func=_md5) == checksum('/bin/ls', hash_func=_md5)

# Generated at 2022-06-17 15:07:06.948071
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf66e170e8a0c30d9a5c7b0d5f'


# Generated at 2022-06-17 15:07:17.826879
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum function '''

    import os
    import tempfile
    import shutil
    import stat

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True),
        ),
        supports_check_mode=True
    )

    path = module.params['path']

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a temp file
    (fd, fname) = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Create a temp symlink

# Generated at 2022-06-17 15:07:20.123534
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:07:29.267809
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum functions '''

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True),
            content = dict(required=False),
        ),
        supports_check_mode=True
    )

    path = module.params['path']
    content = module.params['content']

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp()
    os.close(fd)

    # Write content to the temporary file
    if content is not None:
        fd = open(fname, 'w')
        fd.write(content)
        fd.close()

    # Calculate the checks

# Generated at 2022-06-17 15:07:32.251162
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:07:46.049794
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d8ce0c13f0b839d2e0d7d832b0f'
    assert checksum('/bin/ls', sha1) == '6b8e3eaf1f9f2d8ce0c13f0b839d2e0d7d832b0f'
    assert checksum('/bin/ls', _md5) == 'f0e8bcef0c503d08e4c8837c5c2c0d7f'
    assert checksum('/bin/ls', _md5) == md5('/bin/ls')
    assert checksum('/bin/ls', sha1) == checksum_s('/bin/ls')
    assert checks

# Generated at 2022-06-17 15:07:51.707930
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:07:59.145503
# Unit test for function md5
def test_md5():
    ''' test md5 '''
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_file_contents = 'test'

    with open(test_file, 'w') as f:
        f.write(test_file_contents)

    test_file_md5 = md5(test_file)
    assert test_file_md5 == '098f6bcd4621d373cade4e832627b4f6'

    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:08:03.073177
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:08:05.420593
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:08:16.611876
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile
    import shutil

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True),
            checksum_algorithm = dict(required=False, default='sha1', choices=['sha1', 'md5']),
        ),
        supports_check_mode = True
    )

    path = module.params['path']
    checksum_algorithm = module.params['checksum_algorithm']

    if checksum_algorithm == 'md5':
        if not _md5:
            module.fail_json(msg='MD5 not available.  Possibly running in FIPS mode')

# Generated at 2022-06-17 15:08:24.237064
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'e19d5cd5af0378da05f63f891c7467af'
    assert md5s('hello\r\n') == '1f8ac10f23c5b5bc1167bda84b833e5c'
    assert md5s('hello\r') == '6f5902ac237024bdd0c176cb93063dc4'
    assert md5s('hello\n\r') == 'd8cbc7186ba13533a6a086d6f547b3d3'

# Generated at 2022-06-17 15:08:25.821483
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:08:34.666038
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0e1ab6c38b8e49248d8b4978f0c2b4ea2a'
    assert checksum('/bin/ls', 'sha1') == '6b8e3e0e1ab6c38b8e49248d8b4978f0c2b4ea2a'
    assert checksum('/bin/ls', 'sha256') == 'f0ef70289a6ddc339ebc3d28e0e7f19e9b6a4f8a7b70a777b5525f0e7de0a997'

# Generated at 2022-06-17 15:08:45.956962
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test"), "wb")
    f.write(b"foo")
    f.close()

    # Test checksum
    assert checksum(os.path.join(tmpdir, "test")) == "acbd18db4cc2f85cedef654fccc4a4d8"

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:08:57.186077
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'f3d3f1b7d8c5d8a7a9a5a8c8d5c3c5a5'
    assert checksum('/bin/ls', sha1) == 'f3d3f1b7d8c5d8a7a9a5a8c8d5c3c5a5'
    assert checksum('/bin/ls', _md5) == 'f3d3f1b7d8c5d8a7a9a5a8c8d5c3c5a5'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', sha1)

# Generated at 2022-06-17 15:09:02.776039
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:09:05.470892
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:09:09.429849
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5('/bin/ls') == 'c4a7a1f924fcd628dea195a22e6543b0'


# Generated at 2022-06-17 15:09:14.257415
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == md5s('test')
    assert md5s('test') != md5s('test2')


# Generated at 2022-06-17 15:09:25.506696
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s('hello')
    assert md5s('hello') != md5s('hello2')
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(None) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == md5s(u'hello')
    assert md5s(u'hello') != md5s(u'hello2')
   

# Generated at 2022-06-17 15:09:30.250327
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e9b9aeb8e88c95c38e81b'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:09:31.488669
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c8cece768d6f209f1'


# Generated at 2022-06-17 15:09:36.820090
# Unit test for function md5
def test_md5():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5('/bin/ls') == '7f9b47b06a2c0f1dda848c189b8fbaa8'

# Generated at 2022-06-17 15:09:47.645385
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum functions '''

    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
            content = dict(required=False, type='str'),
        ),
        supports_check_mode=True
    )

    path = module.params['path']
    content = module.params['content']

    if content is not None:
        (fd, path) = tempfile.mkstemp()
        os.write(fd, content)
        os.close(fd)

    if not os.path.exists(path):
        module.fail_json(msg="Source %s not found" % (path))

   

# Generated at 2022-06-17 15:09:52.483204
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create a file
    f = open("foo", "w")
    f.write("Hello Ansible")
    f.close()

    # Check the md5 checksum
    assert md5("foo") == "7f9b1af26c98b06d19b41ca7c70acbdd"

    # Remove the temporary directory
    os.chdir(curdir)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:10:06.670158
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf2d8f9ab3d0f3823a6f396b1b'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-17 15:10:08.958813
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:10:20.401625
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3eaf1f9f2d8c49f170f64d0b8e69d7a0e3b1'
    assert checksum('/bin/ls', hash_func=_md5) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-17 15:10:24.548151
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c8f5cddcd651a3d31'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:10:27.044266
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:10:36.070832
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'e7dafd5a9e5d5b5b5a5c5d5e5f5a5a5a'
    assert md5('/bin/cat') == 'e7dafd5a9e5d5b5b5a5c5d5e5f5a5a5a'
    assert md5('/bin/cat') == md5('/bin/ls')
    assert md5('/bin/cat') != md5('/bin/echo')
    assert md5('/bin/cat') != md5('/bin/sleep')
    assert md5('/bin/cat') != md5('/bin/false')
    assert md5('/bin/cat') != md5('/bin/true')

# Generated at 2022-06-17 15:10:44.523926
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')

    with open(test_file, 'w') as f:
        f.write('test')

    assert md5(test_file) == '098f6bcd4621d373cade4e832627b4f6'

    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:10:53.040388
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "testfile"), "w")
    f.write("Hello World!")
    f.close()

    # Test the md5 function
    assert md5(os.path.join(tmpdir, "testfile")) == "ed076287532e86365e841e92bfc50d8c"

    # Remove the directory after the test
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 15:11:00.773118
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_string = 'test string'

    with open(test_file, 'w') as f:
        f.write(test_string)

    assert md5(test_file) == 'e2c569be17396eca2a2e3c11578123ed'
    assert md5s(test_string) == 'e2c569be17396eca2a2e3c11578123ed'

    shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:11:03.992289
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:11:12.682851
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e2e0a9f8e7dc8a63f6d7a6c0b6a'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:11:17.688674
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == md5s(u'test')
    assert md5s('test') == md5s(b'test')


# Generated at 2022-06-17 15:11:22.548750
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e0e3e6a4ea44a3c133c6a0ab5b1f9a2220d'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-17 15:11:23.979741
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:11:30.221984
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:11:33.040394
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-17 15:11:45.984263
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "6b8e3eaf88ec2c8dfd759b2a3a88c6d1"
    assert checksum("/bin/ls", hash_func=_md5) == "c8f1e1a1f95a8da7689f8d4b4b4d4c1b"
    assert checksum_s("hello world") == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"
    assert checksum_s("hello world", hash_func=_md5) == "5eb63bbbe01eeed093cb22bb8f5acdc3"

# Generated at 2022-06-17 15:11:57.721976
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "f2d8f9c2b65a6f3f3d1e2d8a4d4f1a1c"
    assert md5("/bin/cat") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5("/bin/cat1") == None
    assert md5("/bin/cat2") == None
    assert md5("/bin/cat3") == None
    assert md5("/bin/cat4") == None
    assert md5("/bin/cat5") == None
    assert md5("/bin/cat6") == None
    assert md5("/bin/cat7") == None
    assert md5("/bin/cat8") == None

# Generated at 2022-06-17 15:12:06.845513
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_file_content = 'test_content'
    test_file_md5 = 'f2c7bbd9176c98de7a3a6f8e7e1b137f'

    try:
        with open(test_file, 'w') as f:
            f.write(test_file_content)

        assert md5(test_file) == test_file_md5
    finally:
        shutil.rmtree(test_dir)

# Generated at 2022-06-17 15:12:16.313493
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('hello\n\n') == 'f0e4c2f76c58916ec258f246851bea09'
    assert md5s('hello\n\n\n') == 'f0e4c2f76c58916ec258f246851bea09'
    assert md5s('hello\n\n\n\n') == 'f0e4c2f76c58916ec258f246851bea09'

# Generated at 2022-06-17 15:12:30.610627
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:12:33.260800
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-17 15:12:46.516940
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'
    assert md5s('hello\n\n') == 'd3b07384d113edec49eaa6238ad5ff00'
    assert md5s('hello\n\n\n') == 'c4ca4238a0b923820dcc509a6f75849b'
    assert md5s('hello\n\n\n\n') == 'c81e728d9d4c2f636f067f89cc14862c'

# Generated at 2022-06-17 15:12:53.346103
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n\n\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-17 15:13:04.916169
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf0f1e2e3c8cecee710f9edbf7'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/cat') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-17 15:13:13.270761
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible checksum module '''

    import os
    import tempfile
    import shutil

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    # Create a temporary symlink
    symlink_path = os.path.join(tmpdir, 'symlink')
    os.symlink(temp_path, symlink_path)

    # Create a temporary directory
    dir_path = os.path.join(tmpdir, 'dir')


# Generated at 2022-06-17 15:13:22.872498
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'e2c0f8d7d7f9a9a7a5f8a0d7e8c0c007'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello\n') == 'e2c0f8d7d7f9a9a7a5f8a0d7e8c0c007'

# Generated at 2022-06-17 15:13:26.491955
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '6b8e3eaf1f9f2d8ce0c13f0a8f06d3f4'


# Generated at 2022-06-17 15:13:36.537477
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'd7b835b0f7f24f1fbd30bea44a88c7a0'
    assert md5('/etc/shadow') == '1f2d1e2f0e0d0a0a1a0a0e0d0f2e1f2d'
    assert md5('/etc/group') == '8c6925e0f3f8e3a5a8f3e5c69258c69e'
    assert md5('/etc/gshadow') == '1f2d1e2f0e0d0a0a1a0a0e0d0f2e1f2d'

# Generated at 2022-06-17 15:13:46.871558
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == md5s(u'hello')
    assert md5s(u'hello') == md5s(u'hello')
    assert md5s(u'hello') == md5s(u'hello')
    assert md5s(u'hello') == md5s(u'hello')
    assert md5s(u'hello') == md5s(u'hello')
    assert md5s(u'hello') == md5s(u'hello')
    assert md5s(u'hello') == md5s(u'hello')
    assert md5s(u'hello') == md5s(u'hello')

# Generated at 2022-06-17 15:13:51.527311
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-17 15:13:53.605502
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'd7e959c9d8c9f9b8a6c9c9d9b8e9c9d9'


# Generated at 2022-06-17 15:13:55.848017
# Unit test for function md5
def test_md5():
    assert md5('lib/ansible/module_utils/basic.py') == 'a1d0c6e83f027327d8461063f4ac58a6'


# Generated at 2022-06-17 15:14:01.498409
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', _md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert checksum('/bin/ls') == 'b9a7c8d8d7c7b8a7d8c7c8d8d7c7b8a7d8c7c8d8'
    assert checksum('/bin/ls', _md5) == 'b9a7c8d8d7c7b8a7d8c7c8d8d7c7b8a7'