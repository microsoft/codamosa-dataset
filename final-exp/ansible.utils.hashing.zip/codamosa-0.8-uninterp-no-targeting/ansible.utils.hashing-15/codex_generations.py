

# Generated at 2022-06-21 08:22:07.027305
# Unit test for function md5s
def test_md5s():
    digest = md5s('hello world')
    assert digest == '5eb63bbbe01eeed093cb22bb8f5acdc3', 'md5s returned %s instead of 5eb63bbbe01eeed093cb22bb8f5acdc3' % digest

# Generated at 2022-06-21 08:22:09.226481
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'


# Generated at 2022-06-21 08:22:13.774671
# Unit test for function md5s
def test_md5s():
    md5s_val = md5s('hello')
    assert md5s_val == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-21 08:22:16.284726
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-21 08:22:18.582879
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

# Generated at 2022-06-21 08:22:24.908803
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    s = md5s('test')
    assert s == '098f6bcd4621d373cade4e832627b4f6'

    s = md5s('test' * 1000)
    assert s == 'd7b8db8b1b7b2a2f9cc7c9b9dcc9937b'



# Generated at 2022-06-21 08:22:30.557431
# Unit test for function md5s
def test_md5s():
    ''' md5s() return value must match value obtained with Python md5 module '''

    import md5
    test_data = 'test string'

    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    assert md5s(test_data) == md5.new(test_data).hexdigest(), 'md5s() value does not match md5.new() value.'



# Generated at 2022-06-21 08:22:34.759867
# Unit test for function checksum
def test_checksum():

    filename = 'test_checksum.txt'
    data = 'blah'
    with open(filename, 'w') as f:
        f.write(data)

    assert(checksum_s(data) == checksum(filename))

    os.remove(filename)

# Generated at 2022-06-21 08:22:47.009121
# Unit test for function checksum
def test_checksum():
    """Tests for existence of md5s and checksum functions, and some trivial
    checks that verify the functions give expected results"""

    from ansible.module_utils.basic import AnsibleModule

    def _use_hashlib():
        try:
            from hashlib import md5, sha1
            return md5, sha1
        except ImportError:
            try:
                from md5 import md5
                from sha import sha as sha1
            except ImportError:
                return None
    try:
        md5_ref, sha1_ref = _use_hashlib()
        if md5_ref:
            md5_ref = md5_ref().hexdigest()
            sha1_ref = sha1_ref().hexdigest()
    except ValueError:
        md5_ref = sha1

# Generated at 2022-06-21 08:22:50.180079
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello world") == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-21 08:23:04.102367
# Unit test for function checksum
def test_checksum():

    # Generate a unique filename
    import tempfile
    tmp_file = tempfile.NamedTemporaryFile()

    # Remove file and assert no error status
    os.unlink(tmp_file.name)
    assert not os.path.exists(tmp_file.name)
    assert secure_hash(tmp_file.name) is None

    # Create the file, write data, assert returns data hash
    tmp_file.write('abc123\n')
    tmp_file.flush()
    assert checksum(tmp_file.name) == 'e99a18c428cb38d5f260853678922e03'

    # Append data, assert returns new data hash
    tmp_file.write('def456\n')
    tmp_file.flush()

# Generated at 2022-06-21 08:23:06.068618
# Unit test for function checksum
def test_checksum():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
    )
    digest = checksum('lib/ansible/module_utils/basic.py')
    module.exit_json(changed=False, checksum=digest)

# Generated at 2022-06-21 08:23:08.103813
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

# Generated at 2022-06-21 08:23:14.500855
# Unit test for function checksum
def test_checksum():
    filename = 'tests/sha1sum.py'
    assert checksum(filename) == 'd126549f1d7eee4d1f7a4d77a9a27c9f4a4e4e18'
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_s(u'foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_s(b'foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'


if __name__ == '__main__':
    test_

# Generated at 2022-06-21 08:23:19.263300
# Unit test for function checksum
def test_checksum():
    filename = '/etc/ansible/hosts'
    print((filename, checksum(filename)))
    assert checksum(filename) == 'e8d98ef93b1bb6ab95f6af2d8c108737bb2d6a4e'



# Generated at 2022-06-21 08:23:20.366280
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("test_data") == '3a3d7c81678a2c1b0de6d77a75a8bd24fc2edf86'

# Generated at 2022-06-21 08:23:30.742051
# Unit test for function md5
def test_md5():
    """Check that the md5 function works correctly. If one of the tests fails
    then it will raise an AssertError exception.
    """
    # create a test file
    f = open("test.tmp", "w")
    f.write("this is a test file")
    f.close()

    # check that an md5 is returned for an existing file
    assert(md5("test.tmp") == "7f21b3c422b5d5dd5be5f7e2bfcc552a")

    # check that None is returned for a non-existent file
    assert(md5("test_does_not_exist.tmp") == None)

    # check that None is returned for a directory
    assert(md5(".") == None)

    # remove the temporary file
    os.remove("test.tmp")


# Unit test

# Generated at 2022-06-21 08:23:42.216201
# Unit test for function checksum
def test_checksum():
    text = "Hello World"

    checksum_sum = checksum_s(text)
    assert checksum_sum == 'f8c3b3f0ec40b8f0bab1a1db68fc56b97f16bdcb'.upper()

    # Test same sum with same text
    checksum_sum2 = checksum_s(text)
    assert checksum_sum2 == checksum_sum

    # Test some other hash
    checksum_sum3 = md5s(text)
    assert checksum_sum3 == '0a4d55a8d778e5022fab701977c5d840'.upper()

    ## Test some other hash
    checksum_sum4 = md5s(text)
    assert checksum_sum4 == checksum_sum3

    # Test same sum with same text
   

# Generated at 2022-06-21 08:23:53.332936
# Unit test for function md5
def test_md5():
    from tempfile import NamedTemporaryFile
    from shutil import rmtree
    from os import mkdir, sep
    import tempfile

    # create a temp directory and cd to it
    temp_dir = tempfile.mkdtemp('', '', tempfile.gettempdir())
    old_dir = os.getcwd()
    os.chdir(temp_dir)

    # create a temp file
    ntf = NamedTemporaryFile(delete=False)
    ntf.write(b"file_contents")
    ntf.flush()

    # test md5(filename)
    assert md5(ntf.name) == 'd41d8cd98f00b204e9800998ecf8427e'

    # create a subdirectory
    os.mkdir('foo')

    # test md5(filename) returns

# Generated at 2022-06-21 08:23:59.841718
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s(u'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s(b'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo' * 1000) == 'f3e97f8da9bf91205a250f08704a8eb1'
    assert md5s(b'foo' * 1000) == 'f3e97f8da9bf91205a250f08704a8eb1'

# Generated at 2022-06-21 08:24:06.691148
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"

# Generated at 2022-06-21 08:24:13.451758
# Unit test for function md5s
def test_md5s():
    import random
    import string
    from ansible.module_utils.six import b
    # Make sure we can create a hash of a bytestring
    # and that the length of the returned value is
    # reasonable
    if _md5:
        test_str = b(''.join(random.choice(string.ascii_letters) for x in range(1024)))
        hsh = md5s(test_str)
        assert isinstance(hsh, str)
        assert len(hsh) == 32

# Generated at 2022-06-21 08:24:22.072043
# Unit test for function checksum_s
def test_checksum_s():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    data = AnsibleUnsafeText('test')

    ret = checksum_s(data)
    assert ret == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

    ret = checksum_s(data, _md5)
    assert ret == '098f6bcd4621d373cade4e832627b4f6'

    data = 'test'
    ret = checksum_s(data)
    assert ret == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

    ret = checksum_s(data, _md5)

# Generated at 2022-06-21 08:24:30.880730
# Unit test for function checksum
def test_checksum():
    import os
    import tempfile

    fd, temp_path = tempfile.mkstemp(prefix='ansible_test_secure_hash')
    f = os.fdopen(fd, 'w')
    test_data = 'test data'
    f.write(test_data)
    f.close()

    #check a file
    assert checksum(temp_path) == secure_hash_s(test_data)
    #check a string
    assert checksum_s(test_data) == secure_hash_s(test_data)

    #cleanup
    os.remove(temp_path)

# Generated at 2022-06-21 08:24:37.490434
# Unit test for function md5s
def test_md5s():
    ''' test_md5s.py: Test the splitter generator. '''

    # This is the md5 checksum of the file data/splitter/test.in
    expected = 'ad0234829205b9033196ba818f7a872b'
    actual = md5s('ansible')
    assert actual == expected, 'md5s returned %s instead of %s' % (actual, expected)
    pass



# Generated at 2022-06-21 08:24:45.086722
# Unit test for function md5
def test_md5():
    import os
    import tempfile
    import shutil

    the_file = os.path.splitext(os.path.basename(__file__))[0] + ".py"
    this_file = os.path.abspath(__file__)

    directory = tempfile.mkdtemp()
    try:
        filename = os.path.join(directory, the_file)
        shutil.copyfile(this_file, filename)
        assert md5(filename) == md5(filename)
    finally:
        shutil.rmtree(directory)

# Generated at 2022-06-21 08:24:49.947714
# Unit test for function md5s
def test_md5s():
    # MD5 Digest of "foobar"
    input_data = '3858f62230ac3c915f300c664312c63f'
    data = "foobar"
    if md5s(data) != input_data:
        raise ValueError("md5s returned incorrect digest for simple input")


# Generated at 2022-06-21 08:24:57.199606
# Unit test for function checksum
def test_checksum():
    sum = checksum("/bin/ls")
    assert sum == "c9a2e6f859aecda7d041e841beec7a57b646d14c", sum
    sum_s = checksum_s("Hello World!")
    assert sum_s == "7b502c3a1f48c8609ae212cdfb639dee39673f5e", sum_s

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:25:06.292846
# Unit test for function checksum_s
def test_checksum_s():
    # Unit test for function checksum_s
    from ansible.utils.hashing import checksum_s
    from ansible.utils.unicode import to_bytes

    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    try:
        if _md5:
            assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    except NameError:
        pass

# Generated at 2022-06-21 08:25:13.892485
# Unit test for function md5s
def test_md5s():
    from ansible.compat.tests import unittest

    # test data from http://www.miraclesalad.com/webtools/md5.php

# Generated at 2022-06-21 08:25:20.358021
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-21 08:25:33.357457
# Unit test for function checksum_s
def test_checksum_s():
    from ansible.module_utils._text import to_bytes
    import types
    import os

    res = checksum_s("This is test string")
    assert res=="0ca35b7d153f2f6a04b8e29e1b161e5c1fa7425e"

    res = checksum_s("This is test string", hash_func=sha1())
    assert res=="0ca35b7d153f2f6a04b8e29e1b161e5c1fa7425e"

    res = checksum_s(to_bytes("This is test string"), hash_func=sha1())
    assert res=="0ca35b7d153f2f6a04b8e29e1b161e5c1fa7425e"



# Generated at 2022-06-21 08:25:35.709674
# Unit test for function md5s
def test_md5s():
    assert md5s('hi') == '49f68a5c8493ec2c0bf489821c21fc3b'

# Generated at 2022-06-21 08:25:43.246654
# Unit test for function md5
def test_md5():
    cur_dir = os.path.dirname(__file__)
    file_name = os.path.join(cur_dir, 'test_md5')
    file_name = os.path.join(file_name, 'test_md5.txt')
    if not os.path.isdir(os.path.dirname(file_name)):
        os.makedirs(os.path.dirname(file_name))
    with open(file_name, 'w') as f:
        f.write('test')
    with open(file_name, 'r') as f:
        if md5(file_name) != md5s(f.read()):
            return False
        else:
            return True


# Generated at 2022-06-21 08:25:48.743740
# Unit test for function md5
def test_md5():
    import tempfile
    fd, path = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('hello world')
    f.close()

    if md5(path) != '5eb63bbbe01eeed093cb22bb8f5acdc3':
        raise Exception('md5 of a file did not match expected value')
    os.remove(path)

# Generated at 2022-06-21 08:25:52.481190
# Unit test for function md5s
def test_md5s():
    from nose.plugins.attrib import attr
    plaintext = 'The quick brown fox jumps over the lazy dog'

    # RFC 1321 Test Vectors
    expected = '9e107d9d372bb6826bd81d3542a419d6'
    actual = md5s(plaintext)
    assert expected == actual


# Generated at 2022-06-21 08:25:53.964250
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-21 08:26:05.479171
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('foo' * 10) == '9dc3f3e3b742d0e84a8f04a15ae1b2a7'
    assert md5s('bar' * 10) == 'd5b6ee208b7fbe62e063c55ceacbfc68'

# Generated at 2022-06-21 08:26:08.913487
# Unit test for function checksum
def test_checksum():
    '''
    This is a simple test to ensure that the checksum matches
    what is expected.

    The checksum is against 'this is a string'.
    '''
    assert checksum_s('this is a string') == '8136a6d7b6f0e32f9c0e21243b84ab3e3d3b11bb'



# Generated at 2022-06-21 08:26:18.313821
# Unit test for function checksum
def test_checksum():

    def touch(FN):
        try:
            os.unlink(FN)
        except:
            pass
        open(FN,'wb').write('')

    def compare(FN1, FN2):
        if not os.path.exists(FN1) or not os.path.exists(FN2):
            print("Missing file")
            return False
        CHKSUM1 = checksum(FN1)
        CHKSUM2 = checksum(FN2)
        return CHKSUM1 == CHKSUM2

    FN1 = "/tmp/testfile.txt"
    FN2 = "/tmp/testfile2.txt"

    touch(FN1)
    touch(FN2)
    assert not compare(FN1, FN2)

    open(FN2,'wb').write('blah')

# Generated at 2022-06-21 08:26:27.356589
# Unit test for function checksum_s
def test_checksum_s():
    ''' test checksum_s() '''
    import random
    import string

    for characters in [string.ascii_letters, string.digits, string.punctuation, string.whitespace]:
        for i in range(1000):
            ret = checksum_s(''.join([random.choice(characters) for i in range(i)]))
            assert ret is not None
            assert isinstance(ret, str)
            assert len(ret) == 40

# Generated at 2022-06-21 08:26:37.130091
# Unit test for function checksum
def test_checksum():
    if checksum("lib/ansible/modules/files/synchronize.py") != "c9f9f0b81a1b1a5766e5e5b498d6fec7c9e53b8a":
        raise Exception("Hashing or filename is broken")
    if checksum_s("hello world") != "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed":
        raise Exception("Hashing or filename is broken")
    if checksum_s("hello world") != "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed":
        raise Exception("Hashing or filename is broken")

# Generated at 2022-06-21 08:26:48.873199
# Unit test for function md5
def test_md5():
    "Test md5 function."
    import shutil
    test_file = 'file-to-check-md5'
    test_file2 = 'file-to-check-md5-2'
    test_file_bom = 'file-to-check-md5-bom'
    test_link = 'link-to-check-md5'
    test_contents = 'some data'
    test_contents_bom = b'\xef\xbb\xbfsome data'

    open(test_file, 'w').write(test_contents)
    open(test_file_bom, 'wb').write(test_contents_bom)
    os.symlink(test_file, test_link)
    shutil.copy2(test_file, test_file2)

    assert md

# Generated at 2022-06-21 08:26:55.594709
# Unit test for function md5
def test_md5():
    print("test_md5: creating file test_secure_hash.tmp")
    with open('test_secure_hash.tmp', 'wb') as f:
        f.write(b'test_secure_hash')

    assert md5('test_secure_hash.tmp') == secure_hash('test_secure_hash.tmp')

    print("test_md5: deleting file test_secure_hash.tmp")

    os.remove('test_secure_hash.tmp')



# Generated at 2022-06-21 08:27:07.242254
# Unit test for function checksum_s
def test_checksum_s():
    if not secure_hash_s(b"test") == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3":
        raise AssertionError()
    if not secure_hash_s(u"test") == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3":
        raise AssertionError()
    if not secure_hash_s(u"test", hash_func=_md5) == "098f6bcd4621d373cade4e832627b4f6":
        raise AssertionError()

# Generated at 2022-06-21 08:27:19.554276
# Unit test for function checksum
def test_checksum():
    import os, tempfile
    from ansible.compat.tests import unittest
    from ansible.module_utils.basic import AnsibleModule

    fd, temp_path = tempfile.mkstemp()
    # create a file
    f = os.fdopen(fd, 'w')
    f.write('foo')
    f.close()

    class TestChecksumFunctions(unittest.TestCase):
        def test_checksum_s(self):
            self.assertEqual(checksum_s('foo'), '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33')
            self.assertEqual(md5s('foo'), 'acbd18db4cc2f85cedef654fccc4a4d8')


# Generated at 2022-06-21 08:27:26.633275
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "6b8e3e0b1a2a88f74dbe3a90760319c6"
    assert checksum("/bin/echo") == "f6edbdc89dae0f0be92f2514b40a39d6"
    assert checksum("/bin/cat") == "f1185dae7e0d2460c65b224a6d358aff"

# Generated at 2022-06-21 08:27:32.333564
# Unit test for function checksum_s
def test_checksum_s():
    ''' test checksum_s function '''
    assert checksum_s('hello world') == 'fc3ff98e8c6a0d3087d515c0473f8677'
    assert checksum_s(b'hello world') == 'fc3ff98e8c6a0d3087d515c0473f8677'


# Generated at 2022-06-21 08:27:40.368774
# Unit test for function md5
def test_md5():
    from ansible.utils.unsafe_proxy import wrap_var
    from collections import namedtuple

    Options = namedtuple('Options', ['remote_tmp', 'remote_checksum'])
    options = Options({}, 'md5')

    try:
        wrap_var(options)
        assert False, 'test should have failed'
    except ValueError as e:
        assert str(e) == 'MD5 not available.  Possibly running in FIPS mode'

    options = Options({}, 'checksum')
    wrap_var(options)

# Generated at 2022-06-21 08:27:49.266968
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('message digest') == 'f96b697d7cb7938d525a2f31aaf161d0'
    assert md5s('abcdefghijklmnopqrstuvwxyz') == 'c3fcd3d76192e4007dfb496cca67e13b'

# Generated at 2022-06-21 08:28:00.167185
# Unit test for function checksum_s
def test_checksum_s():
    # Test sha1
    assert secure_hash_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    # Test md5 (only if available)
    if _md5:
        assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-21 08:28:05.799308
# Unit test for function md5
def test_md5():
    """
    Verify that the md5 hash function is working correctly.

    :returns: True if tests pass, otherwise False.
    """
    assert md5('test/unit/hashing/files/checksum') == 'e7b6a710bd6dccc8f8fcbe3ceb639c4d'
    assert md5('test/unit/hashing/files/non_existent_file') == None

# Generated at 2022-06-21 08:28:13.682568
# Unit test for function md5s
def test_md5s():
    assert md5s(None) == secure_hash_s(None, _md5)
    assert md5s('') == secure_hash_s('', _md5)
    assert md5s('a') == secure_hash_s('a', _md5)
    assert md5s('abc') == secure_hash_s('abc', _md5)
    assert md5s('message digest') == secure_hash_s('message digest', _md5)
    assert md5s('abcdefghijklmnopqrstuvwxyz') == secure_hash_s('abcdefghijklmnopqrstuvwxyz', _md5)

# Generated at 2022-06-21 08:28:20.057634
# Unit test for function md5s
def test_md5s():
    test_data = b"hello"
    if not _md5:
        try:
            md5s(test_data)
            raise Exception('md5s should have failed')
        except ValueError:
            pass
    else:
        assert md5s(test_data) == '5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-21 08:28:23.238953
# Unit test for function checksum_s
def test_checksum_s():
    s1 = "asdf"
    s2 = "asdg"
    assert checksum_s(s1) == checksum_s(s1)
    assert checksum_s(s1) != checksum_s(s2)

# Generated at 2022-06-21 08:28:28.350271
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-21 08:28:33.855174
# Unit test for function checksum_s
def test_checksum_s():

    dict = {'message' : 'Hello World' }
    result = checksum_s(dict)
    assert(result == '9bf7f0825e539dc7d518ae3e19ec2e64cdaac64e')

    dict = {'message' : 'HelloWorld' }
    result = checksum_s(dict)
    assert(result == '2d3cf903b0ab0cd66a1a1a0f4c1558c2f478b6d4')

# Generated at 2022-06-21 08:28:41.613436
# Unit test for function checksum
def test_checksum():
    print("Checking secure_hash()")
    assert checksum("ansible/data/ansible_test.cfg") == "b5387c60f8ddd5a5f5c7b25f1ed9a7634cc05b45"
    print("Checking checksum_s()")
    assert checksum_s("hello world") == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:28:47.146170
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_s(b'123') == '202cb962ac59075b964b07152d234b70'
    assert checksum_s(123) == '202cb962ac59075b964b07152d234b70'

# Generated at 2022-06-21 08:28:58.517304
# Unit test for function checksum_s
def test_checksum_s():
    ''' unit testing for checksum_s function '''
    assert checksum_s('string1') == '6a8a1a38ea9d561995b2640e6e64d6f2d02c7a6b'
    assert checksum_s('string1', hash_func=_md5) == 'a64a50ebb8ec35cd63dd0d37660076a6'

    # FIPS mode
    try:
        md5s('string1')
    except ValueError as e:
        assert str(e) == 'MD5 not available.  Possibly running in FIPS mode'
    else:
        raise AssertionError('should raise error when md5 is not available')



# Generated at 2022-06-21 08:29:14.047713
# Unit test for function md5
def test_md5():
    data = "Mary had a little lamb"
    assert md5s(data) == "d6eee0a05a6ca1b6beb9e9f92654b2c2"
    assert md5(__file__) == "4f087ab213d0a4f99b6cd09a3e0f0e96"



# Generated at 2022-06-21 08:29:25.686912
# Unit test for function md5
def test_md5():
    assert(md5s(b"ONE") == "e8dc4081b13434b45189a720b77b6818")
    assert(md5s(b"TWO") == "7ac66c0f148de9519b8bd264312c4d64")
    os.system("echo -n ONE > ONE")
    assert(md5("ONE") == md5s(b"ONE"))
    assert(md5("") == None)
    assert(md5(None) == None)
    assert(md5("NEVERGONNAMAKEIT") == None)
    os.system("echo -n TWO > TWO")
    assert(md5("TWO") == md5s(b"TWO"))
    os.system("rm ONE TWO")



# Generated at 2022-06-21 08:29:30.556972
# Unit test for function checksum_s
def test_checksum_s():
    '''Test checksum_s'''

    assert checksum_s('test-content') == '4f4d8d4f4c647e8855ab70d6b0c60a534517b7e0'


# Generated at 2022-06-21 08:29:37.853346
# Unit test for function checksum_s
def test_checksum_s():
    # Test a typical string value
    param = "testing1 2 3 4"
    assert checksum_s(param) == "23de28d5cfb098889ca7a3cbe0fd6d0c96e5a6e5"

    # Test an empty string
    param = ""
    assert checksum_s(param) == "da39a3ee5e6b4b0d3255bfef95601890afd80709"

    # Test an empty buffer
    param = b""
    assert checksum_s(param) == "da39a3ee5e6b4b0d3255bfef95601890afd80709"

    # Test an invalid type
    param = 12345

# Generated at 2022-06-21 08:29:40.231744
# Unit test for function checksum_s
def test_checksum_s():
    assert secure_hash_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'


# Generated at 2022-06-21 08:29:50.671414
# Unit test for function md5
def test_md5():
    ''' md5 should return the md5 checksum of filename, None if file is not present or a directory. '''

    filename_test1 = 'test1.txt'
    with open(to_bytes(filename_test1, errors='surrogate_or_strict'), 'wb') as f:
        f.write(b'Hello')
    filename_test2 = 'test2.txt'
    with open(to_bytes(filename_test2, errors='surrogate_or_strict'), 'wb') as f:
        f.write(b'Hello')
    filename_test3 = 'test3.txt'
    with open(to_bytes(filename_test3, errors='surrogate_or_strict'), 'wb') as f:
        f.write(b'Hello There')
    filename_directory = 'directory'

# Generated at 2022-06-21 08:29:51.933053
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-21 08:29:57.919746
# Unit test for function checksum
def test_checksum():
    checksum1 = checksum("hashes.py")
    checksum2 = checksum("hashes.py")
    if checksum1 != checksum2:
        raise Error("hashes.py has the same checksum")
    else:
        print("All is good")
  
if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:30:02.917800
# Unit test for function md5
def test_md5():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            filename = dict(required=True, type='str'),
        ),
    )

    filename = module.params['filename']

    result = md5(filename)

    module.exit_json(changed=False, md5sum=result)


# Generated at 2022-06-21 08:30:04.258192
# Unit test for function md5
def test_md5():
    assert md5(__file__) == md5(__file__)


# Generated at 2022-06-21 08:30:16.874078
# Unit test for function checksum
def test_checksum():
    filename = "file_checksum.py"
    assert checksum(filename) == 'b67eef8dc44adb7d75fdf9a250734a77132030b5'

# Generated at 2022-06-21 08:30:19.813850
# Unit test for function md5s
def test_md5s():
    # Known hash of string "test"
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-21 08:30:30.489429
# Unit test for function checksum
def test_checksum():
    from tempfile import mkstemp
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory("/dev/null", "localhost, testhost", loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

    # test checksum function on some known values
    assert checksum_s(u'blue') == 'fe5dbbcea5bf0fda4cfa86cda5c5bbb8aeabc4ff'
    assert checksum_s(u'green') == '1b7a90a37a335d60f396c00e2b18a300e3a9fdc1'



# Generated at 2022-06-21 08:30:32.725637
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-21 08:30:40.946630
# Unit test for function md5s
def test_md5s():
    assert md5s("abcdef") == "ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f"
    assert md5s("abcdefg") == "e4d7f18c7f1e8b9c130c8a56068451b3"
    assert md5s("abcdefgh") == "c2fc2acb5fc8c42e9d9d042aaffadb7b"
    assert md5s("abcdefghi") == "04bba5a5b9e5e5cbadb5db2b5bee5ff5"

# Generated at 2022-06-21 08:30:52.107111
# Unit test for function md5
def test_md5():
    digest_a = md5('lib/ansible/modules/packaging/os/package.py')
    digest_b = md5('lib/ansible/modules/packaging/os/package.py')
    if digest_a is None and digest_b is None:
       print("No file 'lib/ansible/modules/packaging/os/package.py'")
    elif digest_a != digest_b:
       print("md5: digests do not match, %s != %s" % (digest_a, digest_b))
    else:
       print("md5: digests match as expected, %s == %s" % (digest_a, digest_b))



# Generated at 2022-06-21 08:31:00.208341
# Unit test for function md5
def test_md5():
    '''Return unit test results for md5 function'''

    from ansible.utils.hashing import md5s, md5

    # create a small file
    file_name = '/tmp/test_md5.tmp'
    f1 = open(file_name, 'w')
    f1.write('abcdefghijklmnopqrstuvwxyz')
    f1.close()

    # check results
    if md5s('0123456789') != '25f9e794323b453885f5181f1b624d0b':
        return "md5s failed"
    if md5(file_name) != 'c3fcd3d76192e4007dfb496cca67e13b':
        return "md5 failed"

    # cleanup

# Generated at 2022-06-21 08:31:08.499108
# Unit test for function md5s
def test_md5s():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    # FIXME: is it ok?
    if not _md5:
        module.fail_json(msg='MD5 not available.  Possibly running in FIPS mode')
    module.exit_json(changed=False, ansible_facts=dict(hash_md5s=md5s('hello world')))


if __name__ == '__main__':
    # Run tests if called directly
    test_md5s()

# Generated at 2022-06-21 08:31:17.461733
# Unit test for function md5s
def test_md5s():
    # "abcd" -> abcd
    assert md5s('abcd') == 'e2fc714c4727ee9395f324cd2e7f331f'
    # u"abcd" -> abcd
    assert md5s(u'abcd') == 'e2fc714c4727ee9395f324cd2e7f331f'
    # [97, 98, 99, 100] -> abcd
    assert md5s([97, 98, 99, 100]) == 'e2fc714c4727ee9395f324cd2e7f331f'
    # (97, 98, 99, 100) -> abcd
    assert md5s((97, 98, 99, 100)) == 'e2fc714c4727ee9395f324cd2e7f331f'
    # b"abcd" ->

# Generated at 2022-06-21 08:31:20.691751
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8', 'md5s returned wrong value'


# Generated at 2022-06-21 08:31:33.801342
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s("foobar") != "8843d7f92416211de9ebb963ff4ce28125932878":
        raise ValueError("Wrong checksum")

# Generated at 2022-06-21 08:31:42.762992
# Unit test for function checksum
def test_checksum():
    from ansible.module_utils.basic import AnsibleModule
    import io
    import sys


# Generated at 2022-06-21 08:31:50.026459
# Unit test for function checksum_s
def test_checksum_s():
    import os
    """
    >>> if not os.path.exists("/bin/sh"):
    ...     print("WARNING: /bin/sh does not exist.  Not running test_checksum_s")
    ... else:
    ...     print(checksum_s("/bin/sh"))
    ...
    a9c95ca1f07683b8dc8a2f7d80ca1bd0d7a05c34
    """



# Generated at 2022-06-21 08:31:53.539074
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-21 08:31:56.027385
# Unit test for function checksum_s
def test_checksum_s():
    data = 'Hello World!'
    assert checksum_s(data) == '2ef7bde608ce5404e97d5f042f95f89f1c232871'



# Generated at 2022-06-21 08:31:58.733984
# Unit test for function md5
def test_md5():
    x = md5s(b"abc")
    assert x == "900150983cd24fb0d6963f7d28e17f72"
