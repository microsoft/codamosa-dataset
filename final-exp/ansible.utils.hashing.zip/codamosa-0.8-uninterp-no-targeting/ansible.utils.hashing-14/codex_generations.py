

# Generated at 2022-06-21 08:22:15.988404
# Unit test for function md5s
def test_md5s():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    result = md5s(b"hello world")
    module.exit_json(changed=False, meta=result)

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-21 08:22:26.926038
# Unit test for function md5
def test_md5():
    ''' md5 unittest'''

    DATA = "Hello World"
    EXTRA = "\nThis is another line."
    FILENAME = "md5_test_file"

    try:
        dig1 = md5s(DATA)
        with open(FILENAME, 'wb') as f:
            f.write(DATA)
        dig2 = md5(FILENAME)
        assert dig1 == dig2

        with open(FILENAME, 'ab') as f:
            f.write(EXTRA)
        dig1 = secure_hash_s(DATA + EXTRA, _md5)
        dig2 = md5(FILENAME)
        assert dig1 == dig2

    except Exception as err:
        raise
    finally:
        if os.path.exists(FILENAME):
            os.remove

# Generated at 2022-06-21 08:22:37.573763
# Unit test for function md5s
def test_md5s():

    import random
    import string
    import unittest

    class TestMd5s(unittest.TestCase):

        def setUp(self):
            pass

        def test_simple_string(self):
            self.assertEqual(md5s("hello"), "5d41402abc4b2a76b9719d911017c592")

        def test_very_long_string(self):
            # Generate a string of length 10M, and compute md5 sum
            src = []
            src.append(''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(1000000)))
            result = md5s(''.join(src))

# Generated at 2022-06-21 08:22:50.377308
# Unit test for function checksum
def test_checksum():
    import tempfile
    from shutil import rmtree
    from tempfile import mkdtemp
    import os
    import ansible.module_utils.basic

    checksum_result=dict()
    checksum_result['all']=dict(sha1='ffecd6e07d6d2e93f9c27a0a0a35c4839dddcbea',md5='18ff38d0adad6f2f6c6856ae2f3996e5')
    checksum_result['sha1']='ffecd6e07d6d2e93f9c27a0a0a35c4839dddcbea'
    checksum_result['md5']='18ff38d0adad6f2f6c6856ae2f3996e5'

    tempdir = mkdtemp()

# Generated at 2022-06-21 08:22:59.087927
# Unit test for function md5s
def test_md5s():
    # Tests for functions in this file should use the same data
    # that the modules use
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('This is a longer message and should work as expected as well.') == 'db887d8c735e5b54882660d39b28e8fa'

del _md5

# Generated at 2022-06-21 08:23:07.780592
# Unit test for function md5
def test_md5():
    h = md5s('hello')
    assert h == '5d41402abc4b2a76b9719d911017c592'  # from python's md5.new('hello').hexdigest()

    testfile = os.path.join(os.path.dirname(__file__), 'testdata', 'changelogs','changelog.Debian.gz')
    h = md5(testfile)
    assert h == '5e0d689735e0006cf65f1a8265d1ebe5'  # from python's md5.new(open('testfile').read()).hexdigest()

# Generated at 2022-06-21 08:23:12.090448
# Unit test for function md5
def test_md5():
    "test md5 function"
    # Test file doesn't exist
    assert md5('does-not-exist') is None
    # Test directory
    assert md5('./lib') is None
    # Test some real file
    assert md5('./lib/ansible/module_utils/basic.py') == '8e20f9a6c1de7e9ebe68a1b42391a6a4'

# Generated at 2022-06-21 08:23:13.867901
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foo') == checksum_s('foo')


# Generated at 2022-06-21 08:23:26.284690
# Unit test for function md5
def test_md5():
    ''' md5.py: Test md5 function '''

    from ansible.compat.tests import unittest
    import tempfile
    import shutil
    import os

    test_str = 'test string'

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    fd, fpath = tempfile.mkstemp(dir=tmpdir)

    # Write test_str to file
    os.write(fd, to_bytes(test_str))
    os.close(fd)

    test_md5 = md5(fpath)

    # Remove temporary directory
    shutil.rmtree(tmpdir)


# Generated at 2022-06-21 08:23:30.993493
# Unit test for function checksum_s
def test_checksum_s():
    h1 = checksum_s('hello world')
    assert h1 == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    h2 = checksum_s('hello world', hash_func=sha1)
    assert h1 == h2
    assert h1 != 'no_such_hash'



# Generated at 2022-06-21 08:23:35.926483
# Unit test for function checksum_s
def test_checksum_s():
    s = checksum_s('hello world')
    print(s)


# Generated at 2022-06-21 08:23:48.037991
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import jinja2
    import sys

    md5_available = True
    try:
        import hashlib
        hashlib.md5
    except (AttributeError, ImportError):
        md5_available = False

    # we need to create a temporary directory with a file
    # and move the user to that temp directory
    temp_dir = tempfile.mkdtemp()
    saved_cwd = os.getcwd()
    os.chdir(temp_dir)
    temp_file_path = os.path.join(temp_dir, "test_md5.txt")

    # create a temp file
    temp_file = open(temp_file_path, "w")
    temp_file.write("Hello, this is a test")
    temp_file.close()

    #

# Generated at 2022-06-21 08:23:55.444432
# Unit test for function md5s
def test_md5s():
    md5s_test_data = u"foobarbaz"
    if _md5:
        if md5s(md5s_test_data) != u"3858f62230ac3c915f300c664312c63f":
            raise AssertionError("md5s test failed.")
    else:
        try:
            md5s(md5s_test_data)
        except ValueError:
            pass
        else:
            raise AssertionError("md5s test failed.")

# Generated at 2022-06-21 08:23:57.660041
# Unit test for function md5
def test_md5():
    _md5 = secure_hash_s('test', _md5)
    assert _md5 == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-21 08:24:01.447897
# Unit test for function md5
def test_md5():
    data = "Hello World"
    h = md5s(data)
    assert(h == "ed076287532e86365e841e92bfc50d8c")


# Tests for backwards compat md5 function

# Generated at 2022-06-21 08:24:10.526927
# Unit test for function checksum
def test_checksum():
    try:
        assert(checksum("tests/support/checksum_test") == checksum("tests/support/checksum_test.py"))
    except Exception as e:
        raise(e)

    try:
        assert(checksum("tests/support/checksum_test.py") == checksum("tests/support/checksum_test.py"))
    except Exception as e:
        raise(e)

    try:
        assert(checksum("tests/support/checksum_test.py") == checksum_s("tests/support/checksum_test.py"))
    except Exception as e:
        raise(e)

# Generated at 2022-06-21 08:24:20.003726
# Unit test for function checksum
def test_checksum():

    # create a dummy file for testing
    test_file = "/tmp/ansible_test_file_%s" % os.getpid()
    f = open(test_file, 'w')
    f.write("HELO WORLD")
    f.close()

    # get the checksum string using function secure_hash
    checksum_str = secure_hash(test_file)

    # assert the checksum string of a file
    assert checksum_str == "2768d1cd4509fec9e9d8c350f0d7676b"

    # assert the checksum string of a string
    checksum_str = secure_hash_s('hello world')
    assert checksum_str == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"

#

# Generated at 2022-06-21 08:24:22.867920
# Unit test for function md5s
def test_md5s():
    ''' test md5s function '''
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-21 08:24:33.059799
# Unit test for function md5
def test_md5():
    """ test md5 function """
    # md5 function uses md5.md5() to calculate md5,
    # which involves only one block of data.
    # try a data block with 1024 bytes and zero bytes
    data = '01234567' * 128
    md5_sum_data = md5s(data)
    md5_t = md5_sum_data.replace('0', '23456789')
    try:
        md5_sum_data = md5s(data)
        if md5_sum_data != md5_t:
            pass
        else:
            raise
    except Exception as e:
        raise AnsibleError('md5 function failed: %s' % e)

# Generated at 2022-06-21 08:24:35.935313
# Unit test for function md5s
def test_md5s():
    data = 'test-data'
    assert md5s(data) == '1234'
    assert md5s(data) == '1234'


# Generated at 2022-06-21 08:24:48.312967
# Unit test for function md5
def test_md5():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestMD5(unittest.TestCase):

        def setUp(self):
            self.f = open("/tmp/test.txt", "w")
            self.f.write("This is test file.")
            self.f.close()

        @patch('ansible.module_utils.basic.AnsibleModule.fail_json')
        @patch('ansible.module_utils.checksum.md5s')
        def test_md5(self, mock_md5, mock_fail):
            mock_md5.return_value = "abc"
            self.assertEquals(md5("/tmp/test.txt"), "abc")
            mock_fail.assert_not_called()

       

# Generated at 2022-06-21 08:24:50.403858
# Unit test for function md5s
def test_md5s():
    assert md5s('asdf') == '912ec803b2ce49e4a541068d495ab570'


# Generated at 2022-06-21 08:24:56.054575
# Unit test for function checksum
def test_checksum():
    fd, tfile = tempfile.mkstemp()
    os.write(fd, "data")
    os.close(fd)

    sha1 = checksum(tfile)
    md5 = checksum(tfile, _md5)
    print("sha1: %s" % sha1)
    print("md5: %s" % md5)


# Generated at 2022-06-21 08:25:02.568476
# Unit test for function md5s
def test_md5s():
    result = md5s('test')
    assert result == '098f6bcd4621d373cade4e832627b4f6', "md5s() returned '%s' instead of '098f6bcd4621d373cade4e832627b4f6'" % result

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 08:25:05.391744
# Unit test for function md5s
def test_md5s():
    s = 'string'
    h = md5s(s)
    assert h == '9a0364b9e99bb480dd25e1f0284c8555'

# Generated at 2022-06-21 08:25:13.516724
# Unit test for function checksum
def test_checksum():
    import os
    from ansible.module_utils.basic import AnsibleModule

    t_file = '/tmp/test/test.txt'
    t_file1 = '/tmp/test/test1.txt'
    t_file2 = '/tmp/test/test2.txt'
    t_file3 = '/tmp/test/test3.txt'
    dir_name = os.path.dirname(t_file)

    if not os.path.exists(dir_name):
        os.makedirs(dir_name)

    f_test = open(t_file, "w+")
    f_test1 = open(t_file1, "w+")
    f_test2 = open(t_file2, "w+")
    f_test3 = open(t_file3, "w+")



# Generated at 2022-06-21 08:25:24.532624
# Unit test for function checksum_s
def test_checksum_s():
    test_values = {
        "I am a string": "f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0",
        "I am a unicode string": "f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0"
    }

    for key in test_values:
        assert checksum_s(key) == test_values[key]

    with open("/dev/null", "r") as fh:
        assert checksum_s(fh) == "d41d8cd98f00b204e9800998ecf8427e"

# Generated at 2022-06-21 08:25:29.809876
# Unit test for function md5s
def test_md5s():
    import ansible.module_utils.basic
    hsh = md5s(ansible.module_utils.basic)
    assert hsh == '44b8da29eb4e4e3c3ccfa4dbc8b50b2c'


# Generated at 2022-06-21 08:25:36.337442
# Unit test for function md5s
def test_md5s():
    test_str = "hello\u00fc"
    expected_sha1 = "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d"
    expected_md5 = "5d41402abc4b2a76b9719d911017c592"
    if _md5:
        assert md5s(test_str) == expected_md5
    assert checksum_s(test_str) == expected_sha1

test_md5s()

# Generated at 2022-06-21 08:25:42.849290
# Unit test for function checksum
def test_checksum():
    checksum1 = '2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae'
    checksum2 = '5e86809bbb2afb2aa753e20f70f92c25d085a2ee'
    if secure_hash_s('abcde') != checksum1:
        print("checksum test failed")
        return 1
    if secure_hash_s('abcdefghijklmnopqrstuvwxyz') != checksum2:
        print("checksum test failed")
        return 1
    return 0

# unit test for function secure_hash_s

# Generated at 2022-06-21 08:25:50.088033
# Unit test for function checksum_s
def test_checksum_s():
    h = sha1.new()
    h.update(b"12345")
    assert checksum_s("12345") == h.hexdigest()
    assert md5s("12345") == "827ccb0eea8a706c4c34a16891f84e7b"



# Generated at 2022-06-21 08:25:50.940577
# Unit test for function md5

# Generated at 2022-06-21 08:25:53.949182
# Unit test for function md5s
def test_md5s():
    s = "asdfasdf"
    h = "3a3f0d7b0c385e42aa6763064e70d39f"
    assert md5s(s) == h


# Generated at 2022-06-21 08:26:00.570104
# Unit test for function md5s
def test_md5s():
    assert md5s(b'') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(b'a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s(b'abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s(b'message digest') == 'f96b697d7cb7938d525a2f31aaf161d0'
    assert md5s(b'abcdefghijklmnopqrstuvwxyz') == 'c3fcd3d76192e4007dfb496cca67e13b'

# Generated at 2022-06-21 08:26:04.655800
# Unit test for function md5s
def test_md5s():
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests import unittest

    # MD5 is not available in FIPS mode.
    with patch('hashlib.md5', None):
        with self.assertRaises(ValueError):
            md5s('dummy_data')

# Generated at 2022-06-21 08:26:11.088002
# Unit test for function checksum
def test_checksum():
    if secure_hash_s('hello', _md5) != md5s('hello'):
        raise AssertionError('md5 and secure_hash_s failed using md5')
    if secure_hash_s('hello') != sha1('hello').hexdigest():
        raise AssertionError('sha1 and secure_hash_s failed using sha1')
    if secure_hash_s('hello', _md5) != secure_hash('hello').hexdigest():
        raise AssertionError('md5 and secure_hash_s failed using md5')

# Generated at 2022-06-21 08:26:14.405220
# Unit test for function checksum_s
def test_checksum_s():
    if not md5s('foo'):
        raise AssertionError('md5s is not functioning')
    if not checksum_s('foo'):
        raise AssertionError('checksum_s is not functioning')

# Generated at 2022-06-21 08:26:18.940415
# Unit test for function md5
def test_md5():
    assert md5s(b"hello world\n") == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s(b"hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5s(b"abc") == "900150983cd24fb0d6963f7d28e17f72"


# Generated at 2022-06-21 08:26:22.475319
# Unit test for function checksum
def test_checksum():
    h = checksum('lib/ansible/utils/__init__.py')
    assert h == 'a07b5c5b5db5c4e55b0f5d64f4a4bf9033eba0de'



# Generated at 2022-06-21 08:26:25.846046
# Unit test for function md5s
def test_md5s():
    data = 'hello world'
    ret = '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(data) == ret


# Generated at 2022-06-21 08:26:32.201613
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('string') == '4d4e3a648ef38adb8f45a55642d4fbed0cbad8e8'

# Generated at 2022-06-21 08:26:36.421105
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s(u'Hello world') == sha1(b'Hello world').hexdigest()
    assert checksum_s(b'hello world') == sha1(b'hello world').hexdigest()
    assert checksum_s(b'hello world', _md5) == _md5(b'hello world').hexdigest()

# Generated at 2022-06-21 08:26:41.250577
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert secure_hash_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

# Generated at 2022-06-21 08:26:46.732300
# Unit test for function md5s
def test_md5s():
    import getpass
    print("Testing md5s function")
    result = md5s("password")
    if result == "5f4dcc3b5aa765d61d8327deb882cf99":
        print("md5s: PASS")
    else:
        print("md5s: FAIL")


# Generated at 2022-06-21 08:26:55.358558
# Unit test for function checksum
def test_checksum():
    assert checksum_s('herpderp') == 'c93b63f0829b0f1c04bb22d95d944a87b87f2b0d'
    assert checksum_s('flabbergasted') == 'bc7b2c9390ea0324b43f69cfa95d6c0b8f487a6d'
    assert checksum_s('supercalifragilisticexpialidocious') == 'c2b8e5fc01ef2a0a0a9cbbd8aff4aad4e1f4f4d4'

# Generated at 2022-06-21 08:26:58.197384
# Unit test for function checksum_s
def test_checksum_s():
    string = 'I love Ansible'
    h = checksum_s(string)
    assert h == '4dea4c8a7e9ccd45e2bd0b07e48dff10a6f40b72'


# Generated at 2022-06-21 08:27:01.913646
# Unit test for function md5
def test_md5():
    assert md5('data') == '1f3870be274f6c49b3e31a0c6728957f'


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 08:27:09.769974
# Unit test for function md5
def test_md5():
    ''' test md5 function '''

    fname1 = __file__
    data1 = open(fname1, 'rb').read()

    if not _md5:
        print('WARNING: MD5 probably not available.  Possibly running in FIPS mode')

    assert md5(__file__) == '947c9fea6c0ea6e0a055c7af78b829ce'
    assert md5s(data1) == '947c9fea6c0ea6e0a055c7af78b829ce'
    assert checksum_s(data1) == secure_hash_s(data1, sha1)

    print("SUCCESS: md5 unit test completed successfully")


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-21 08:27:14.637585
# Unit test for function md5s
def test_md5s():
    string = "Sample String"
    expected = "e2abde6eeb93527d0c2ce2f47c8af658"
    result = md5s(string)
    assert result == expected, "Invalid output: %s" % result


# Generated at 2022-06-21 08:27:23.602898
# Unit test for function md5
def test_md5():
    """
    since md5 is deprecated, the test is defined here in this file

    the test creates a temporary file
    it computes the md5 sum of the file
    it compares the value of the md5 sum to the expected value

    the test file content and the expected md5 sum were generated on linux:
    echo -n "ansible rocks" | md5sum

    it uses both the function md5s (md5sum of a string) and the function md5 (md5sum of a file)
    in order to test both calls.
    """

# Generated at 2022-06-21 08:27:29.416403
# Unit test for function checksum_s
def test_checksum_s():
    ''' Return a secure hash hex digest of data. '''

    assert checksum_s('hello world') == secure_hash_s('hello world')
    if _md5:
        assert md5s('hello world') == secure_hash_s('hello world', _md5)



# Generated at 2022-06-21 08:27:40.460554
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('Hello World') == 'b10a8db164e0754105b7a99be72e3fe5'
    assert md5s('Hello World ') == '66b27417d37e024c46526c2f6d358a75'
    assert md5s(' ') == '7215ee9c7d9dc229d2921a40e899ec5f'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-21 08:27:49.330733
# Unit test for function checksum
def test_checksum():
    # Should be hexadecimal
    assert len(checksum('/bin/ls')) == 40
    assert len(checksum_s('/bin/ls')) == 40

    # Default is sha1
    assert checksum('/bin/ls') == secure_hash('/bin/ls')
    assert checksum_s('/bin/ls') == secure_hash_s('/bin/ls')

    # Both of these files have the same content
    # Note, these files are not guaranteed to exist
    # on all platforms
    assert checksum('/bin/ls') == checksum('/usr/bin/ls')
    assert checksum_s('/bin/ls') == checksum_s('/usr/bin/ls')

    # This file does not exist, should get None
    assert checksum('/bin/noexist') is None

# Generated at 2022-06-21 08:28:00.168648
# Unit test for function md5
def test_md5():
    """This is the md5 unit test function

    This function is used to test the md5 function.
    """
    md5_data = 'a'
    md5_correct = '0cc175b9c0f1b6a831c399e269772661'
    md5_data_bytes = to_bytes(md5_data, errors='strict')
    md5_correct_bytes = to_bytes(md5_correct, errors='strict')

    if _md5:
        assert(md5s(md5_data_bytes) == md5_correct_bytes)
    else:
        try:
            md5s(md5_data_bytes)
        except ValueError:
            pass
        else:
            assert(False)

# Generated at 2022-06-21 08:28:06.299971
# Unit test for function checksum_s
def test_checksum_s():
    data = "hello world"
    h1 = checksum_s(data)  # hashlib.sha1
    assert h1 == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    h2 = checksum_s(data, hash_func=_md5)
    assert h2 == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-21 08:28:11.154799
# Unit test for function md5
def test_md5():
    ''' md5 should work for a string and for a file'''

    string = 'The quick brown fox jumped over the lazy dog.'
    assert md5s(string) == 'bb7bc29079e246f054b57a1286d50bdd'
    assert md5(__file__)  == '88a3c6947c45e14dd94402a2e0d76c2b'


# Generated at 2022-06-21 08:28:15.172109
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s(b'hello world') == b'2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'


# Generated at 2022-06-21 08:28:21.940312
# Unit test for function checksum
def test_checksum():
    try:
        import hashlib
        assert checksum('/etc/passwd','md5')
    except ImportError:
        try:
            import md5
            assert checksum('/etc/passwd','md5')
        except ImportError:
            # Assume we're running in FIPS mode here
            raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert checksum('/etc/passwd')
    assert not checksum('/etc/doesnotexist')

# Generated at 2022-06-21 08:28:29.769941
# Unit test for function md5
def test_md5():
    ''' ansible.utils.md5 unit test '''
    path = 'lib/ansible/modules/core/system/service.py'
    if not os.path.exists(path):
        # in an unpacked tarball or zip.
        path = os.path.join(os.path.dirname(__file__), '../../../', path)
        assert os.path.exists(path)

    assert secure_hash(path) == '33cbd5f5d5f5a9a5f77c5ca17a1e2a89'

# Generated at 2022-06-21 08:28:40.060275
# Unit test for function md5s
def test_md5s():

    # Testing the md5 of a string.
    original_md5 = "a7b97a23f9b921ebe2f0edbeba574fc6"
    md5_calculated = secure_hash_s("this is a test")
    assert md5_calculated == original_md5

    # Testing the md5 of a file
    original_md5 = "a7b97a23f9b921ebe2f0edbeba574fc6"
    current_dir = os.path.dirname(os.path.abspath(__file__))
    test_md5_file_name = os.path.join(current_dir, 'test_md5_file')

    md5_calculated = secure_hash(test_md5_file_name)
    assert md5_calculated == original

# Generated at 2022-06-21 08:28:55.938133
# Unit test for function checksum
def test_checksum():
    ''' checksum() basic tests '''
    import tempfile
    import os

    (tmpfd, tmpfile) = tempfile.mkstemp(prefix='ansible_test_checksum_')
    tmp = os.fdopen(tmpfd,'w')
    tmp.write('''
This is a test file for the checksum function in module_utils/hashutil.py
The checksum should be be b30bd0b84c9a3d66b8e788f64c0ae5e2d686bb8e
''')
    tmp.close()

    sum = checksum(tmpfile)
    assert sum == 'b30bd0b84c9a3d66b8e788f64c0ae5e2d686bb8e'
    os.remove(tmpfile)


# Generated at 2022-06-21 08:28:57.567626
# Unit test for function md5s
def test_md5s():
    hashsum = md5s('hello')
    assert hashsum == '5d41402abc4b2a76b9719d911017c592'

    try:
        md5s(u'hello')
    except UnicodeDecodeError:
        assert False, 'Unicode error during md5s'

# Generated at 2022-06-21 08:29:03.767925
# Unit test for function md5s
def test_md5s():
    input = 'test_md5s'
    output = 'c98bb8772b8891d1c61b7e20a0f9f7d2'
    assert output == md5s(input), 'md5s() returned an incorrect hash value'
    assert type(output) is str, "type of output is %s" % type(output)

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-21 08:29:06.109805
# Unit test for function md5s
def test_md5s():
    assert md5s('nonsense') == '8f3a75a6955c6d9ad6ce2621e1d7a1ef'


# Generated at 2022-06-21 08:29:12.283989
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"
    assert checksum_s("foo", hash_func=_md5) == "acbd18db4cc2f85cedef654fccc4a4d8"



# Generated at 2022-06-21 08:29:23.837067
# Unit test for function md5
def test_md5():
    ''' md5 unit tests '''

    filename = 'filename'

    def file_not_found(filename):
        raise OSError('No such file or directory')

    old_os_path_exists = os.path.exists
    old_open = open

    os.path.exists = file_not_found
    open = file_not_found

    if _md5:
        assert md5(filename) is None
    else:
        try:
            md5(filename)
        except ValueError as e:
            assert str(e) == 'MD5 not available.  Possibly running in FIPS mode'

    # restore os.path.exists and open to their original values
    os.path.exists = old_os_path_exists
    open = old_open


# Generated at 2022-06-21 08:29:35.546629
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("Hello World") == '6cd3556deb0da54bca060b4c39479839'
    assert checksum_s("test-file") == '3f8a3f4d07625fc0b9f937b37bb39eeb'
    assert checksum_s("test-file\n") == '72e4c7169b9e4ab40c0d4f329f3b3eb3'
    assert checksum_s("test-file\n1") == '8de00abd48bae7ecded31c112f02d8f4'
    assert checksum_s("test-file\n12") == '6930fbadc06153e12901cfc16fbb79b6'
    assert checksum_s("test-file\n123")

# Generated at 2022-06-21 08:29:44.844474
# Unit test for function md5
def test_md5():
    filename = __file__
    secure_filename = 'test/testdata/secure_hash_test.txt'
    if os.path.exists(filename):
        assert checksum(filename, _md5) == md5(filename)
    if os.path.exists(secure_filename):
        secure_hash_data = 'edu.ansible.test.secure_hash_test'
        secure_hash_md5 = 'c64e6f1484b1591bcb1acb6c3d3fa25e'
        assert md5s(secure_hash_data) == secure_hash_md5

# Generated at 2022-06-21 08:29:47.725146
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello world", sha1) == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"



# Generated at 2022-06-21 08:29:53.038507
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s(b"hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"


# Generated at 2022-06-21 08:29:58.434150
# Unit test for function checksum
def test_checksum():
    assert checksum_s(to_bytes('hello', errors='surrogate_or_strict')) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'


# Generated at 2022-06-21 08:30:03.090298
# Unit test for function checksum
def test_checksum():
    assert checksum("data.txt") == checksum("data.txt")
    assert checksum("data.txt") != checksum("data1.txt")
    assert checksum("data.txt") != checksum("data1.txt")
    assert checksum("data.txt") != checksum("data2.txt")


# Generated at 2022-06-21 08:30:09.366403
# Unit test for function md5
def test_md5():
    from tempfile import NamedTemporaryFile
    f = NamedTemporaryFile()
    f.write(b'test')
    f.seek(0)
    assert md5(f.name) == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    f.close()



# Generated at 2022-06-21 08:30:11.731412
# Unit test for function checksum_s
def test_checksum_s():

    assert checksum_s('hello') == "5d41402abc4b2a76b9719d911017c592"



# Generated at 2022-06-21 08:30:15.423763
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    else:
        try:
            md5s('foo')
        except ValueError as e:
            assert str(e) == 'MD5 not available.  Possibly running in FIPS mode'

# Generated at 2022-06-21 08:30:19.764143
# Unit test for function md5
def test_md5():
    assert md5s("foobar") == "3858f62230ac3c915f300c664312c63f"
    assert md5s("ansible") == "b3b35c41f68c783d8a83cc31f42700b2"

# Generated at 2022-06-21 08:30:30.448564
# Unit test for function checksum
def test_checksum():
    from ansible.module_utils.basic import AnsibleModule

    test_str = "foobarbaz"

    if checksum_s(test_str) != "8843d7f92416211de9ebb963ff4ce28125932878":
        module = AnsibleModule(argument_spec=dict())
        module.fail_json(msg='checksum_s() failed')

    test_file = ".testfile"

    if not os.path.exists(test_file):
        try:
            with open(test_file,"a+") as f:
                f.write(test_str)
        except IOError as e:
            module = AnsibleModule(argument_spec=dict())
            module.fail_json(msg="Couldn't create test file")


# Generated at 2022-06-21 08:30:39.023948
# Unit test for function checksum
def test_checksum():
    from tempfile import NamedTemporaryFile
    import time

    handle, path = NamedTemporaryFile(delete=False)
    handle.write(b'hello world')
    handle.close()

    if checksum(path, 'sha1'):
        print("sha1 checksum of 'hello world' = %s" % checksum(path, 'sha1'))
    else:
        print("No checksum generated")
    os.remove(path)

    if checksum(path, 'sha1'):
        print("sha1 checksum of 'hello world' = %s" % checksum(path, 'sha1'))
    else:
        print("No checksum generated")

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:30:40.637766
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("data") == "47bce5c74f589f4867dbd57e9ca9f808"



# Generated at 2022-06-21 08:30:43.821700
# Unit test for function md5
def test_md5():
    assert md5("test/support/logging.yaml") == "7e4d829f17b33bc6b16c9e9e31d9a6c2"

# Generated at 2022-06-21 08:30:57.094124
# Unit test for function checksum
def test_checksum():
    import sys, tempfile
    from ansible.module_utils.basic import AnsibleModule

    data = 'hello world'
    good = checksum_s(data)
    path = tempfile.gettempdir() + os.sep + 'ansible-test-checksum'
    fh = open(path, 'wb')
    fh.write(data.encode('utf-8'))
    fh.close()

    m = AnsibleModule(argument_spec={'path': dict(type='path'), 'checksum': dict()})
    m.params['path'] = path
    m.params['checksum'] = good
    m.run_command()
    os.remove(path)
    assert not m.fail_json.called

# end of module

# Generated at 2022-06-21 08:31:00.009853
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-21 08:31:06.145696
# Unit test for function checksum
def test_checksum():
    cur_dir = os.path.dirname(os.path.abspath(__file__))
    example_file = os.path.join(cur_dir, "..", "..", "changelogs", "example")
    assert(checksum(example_file) == '0dd5eef87c87d3d17bc9c1e2e2b27e0d313989e2')



# Generated at 2022-06-21 08:31:16.413426
# Unit test for function md5
def test_md5():
    from tempfile import mkstemp
    from shutil import copyfile
    import os

    _, src = mkstemp(prefix='src_')
    _, dst = mkstemp(prefix='dst_')


# Generated at 2022-06-21 08:31:27.976555
# Unit test for function md5
def test_md5():
    import tempfile
    from ansible.module_utils._text import to_bytes
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s("hello world\n") == "4d85437fb9ebb21bf53dbea760bf8e2b"

    (fd, name) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write("hello world")
    f.close()

    assert md5(name) == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    os.remove(to_bytes(name, errors='surrogate_or_strict'))

    (fd, name) = tempfile.mkstemp

# Generated at 2022-06-21 08:31:31.898991
# Unit test for function checksum
def test_checksum():
    return "FAILED" if checksum("cheese") != "4102c09c2582a929f3e3db54f085d1c5f5dc5c4e" else "PASSED"


# Generated at 2022-06-21 08:31:35.489665
# Unit test for function md5
def test_md5():
    if not _md5:
        return
    assert md5('/bin/ls') == '9c6e8e6a5b5c2b6a5a5a5c5d5e5c5b5a'



# Generated at 2022-06-21 08:31:38.069600
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'c1f6e29e1b0a54da2c2cb501a4a5b8f7'

# Generated at 2022-06-21 08:31:40.583832
# Unit test for function md5s
def test_md5s():
    text = 'some data'
    digest = '19d0cac70ac56b9c095d9b0e4be4b4b4'
    assert md5s(text) == digest

# Generated at 2022-06-21 08:31:44.090279
# Unit test for function md5
def test_md5():
    import tempfile, shutil

    dirname = tempfile.mkdtemp()
    testfile = os.path.join(dirname, 'test_file')
    with open(testfile, 'w') as f:
        f.write('Test data')

    # test md5
    assert md5(testfile) == 'e2b907c55cced776004a780074c1b1d2'

    # test secure_hash
    assert checksum(testfile) == '89b69c64b61186d8c3d6e3cd9971d972d8e8f09b'

    shutil.rmtree(dirname)


# Generated at 2022-06-21 08:31:50.367871
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "4f63bb4e9cd95c9e85ed6da0ce5fcf89"

# Generated at 2022-06-21 08:31:57.433817
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/etc/passwd') == '1d515b87590f40b47c62b3e5df5c5e9f'


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-21 08:32:01.457495
# Unit test for function md5
def test_md5():
    test_file = open("test.txt", "wb")
    test_file.write("test")
    test_file.close()

    assert md5(test_file.name) == "098f6bcd4621d373cade4e832627b4f6"

    os.remove(test_file.name)

# Generated at 2022-06-21 08:32:10.550946
# Unit test for function checksum
def test_checksum():
    '''Basic test of checksum'''
    assert checksum('/etc/hosts') == '3c36d29e1d6e0f7baa9c9e75cfb2eda6bb2aaaf2'
    assert checksum_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    if _md5:
        assert md5('/etc/hosts') == '3c36d29e1d6e0f7baa9c9e75cfb2eda6'
        assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'

if __name__ == '__main__':
    test_checksum()