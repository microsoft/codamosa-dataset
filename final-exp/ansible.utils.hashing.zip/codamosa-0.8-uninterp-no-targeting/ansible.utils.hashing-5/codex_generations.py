

# Generated at 2022-06-21 08:22:22.484173
# Unit test for function checksum
def test_checksum():
    assert checksum("test/files/changelogs/changelog_group1/changelog1") == "8054d4315d77a8e92c0f93f2259e5f5c9f9cdc36"
    assert checksum("test/files/changelogs/changelog_group1/changelog2") == "b1e15c1d5afa5c86f823a47085c0ed78e67b5c0e"
    assert checksum("test/files/changelogs/changelog_group2/changelog3") == "d38383a4ee3d4c4a7920d04d0c0c8ecf6fb25a7b"

# Generated at 2022-06-21 08:22:25.008095
# Unit test for function checksum
def test_checksum():
    try:
        assert(checksum("/bin/ls") == checksum("/bin/ls"))
    except:
        print("Checksum failed")
        raise



# Generated at 2022-06-21 08:22:28.403330
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == md5('lib/ansible/module_utils/basic.py')


# backwards compat
digest_s = secure_hash_s
digest    = secure_hash


# Generated at 2022-06-21 08:22:34.282590
# Unit test for function checksum_s
def test_checksum_s():
    assert secure_hash_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert secure_hash_s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert secure_hash_s('\xe4\xf6\xfc') == 'e98c70f7d0e24b1d8719a47c9e9adbc0'
    assert secure_hash_s(b'\xe4\xf6\xfc') == 'e98c70f7d0e24b1d8719a47c9e9adbc0'


# Generated at 2022-06-21 08:22:38.994546
# Unit test for function checksum_s
def test_checksum_s():
    test_string = "hello world"
    assert checksum_s(test_string) == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"

if __name__ == '__main__':

    test_checksum_s()

# Generated at 2022-06-21 08:22:45.449389
# Unit test for function checksum_s
def test_checksum_s():
    # SHA1
    expected = '0a4d55a8d778e5022fab701977c5d840bbc486d0'
    result = checksum_s('test')
    assert result == expected

    # MD5
    expected = '098f6bcd4621d373cade4e832627b4f6'
    result = md5s('test')
    assert result == expected

# Generated at 2022-06-21 08:22:50.953574
# Unit test for function checksum_s
def test_checksum_s():
    '''
    Test with no input, a string, and an int
    '''
    print("Test checksum_s with no input")
    print("Expect: d41d8cd98f00b204e9800998ecf8427e")
    print("Result: %s" % checksum_s(''))

    print("Test checksum_s with input")
    print("Expect: a948904f2f0f479b8f8197694b30184b0d2ed1c1cd2a1ec0fb85d299a192a447")
    print("Result: %s" % checksum_s('Hello World'))

    print("Test checksum_s with int input")

# Generated at 2022-06-21 08:22:56.732956
# Unit test for function md5
def test_md5():

    # test_file = "~/tmp/test"
    # test_file = os.path.expanduser(test_file)
    test_file = "/tmp/test"
    with open(test_file, "w") as f:
        f.write("testline")

    md5_s = md5s("testline")
    md5_f = md5(test_file)

    assert md5_s == md5_f

# Generated at 2022-06-21 08:23:03.294102
# Unit test for function checksum
def test_checksum():
    '''
    Unit tests for funciton checksum.
    '''

    # File or directory not found
    assert checksum('/not/exists') is None

    # Existing file
    assert checksum('/bin/ls') == '4cf4aafb3dbbfe8070ec4173a6d33a525b0c6137'

    # Existing directory
    assert checksum('/bin/.') is None

# Generated at 2022-06-21 08:23:08.182360
# Unit test for function md5
def test_md5():
    import tempfile
    with tempfile.TemporaryFile(mode='w+') as f:
        f.write('foo\n')
        f.flush()
        f.seek(0)
        assert md5(f.name) == secure_hash(f.name)
        assert md5s('foo') == secure_hash_s('foo')
    f.close()

# Generated at 2022-06-21 08:23:15.361981
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5('/bin/ls') == '739e96fdd2a7125bcc085bb8f91d547f'

# Generated at 2022-06-21 08:23:27.615269
# Unit test for function checksum_s
def test_checksum_s():
    # Test for string
    assert checksum_s("Hello") == "8b1a9953c4611296a827abf8c47804d7"

    # Test for unicode string
    assert checksum_s(u"H\xe9llo") == "8b1a9953c4611296a827abf8c47804d7"

    # Test for bytes
    assert checksum_s(b"Hello") == "8b1a9953c4611296a827abf8c47804d7"

    # Test for None
    assert checksum_s(None) == "cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce"


# Generated at 2022-06-21 08:23:31.553864
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'


# Generated at 2022-06-21 08:23:34.732218
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e7d076d0f637b02a8f0a769ae6afb'

# Unit test function checksum_s

# Generated at 2022-06-21 08:23:45.095397
# Unit test for function checksum_s
def test_checksum_s():

    good_data = 'hello world'
    good_sha1 = '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    bad_data = 'not the same string as above'
    bad_sha1 = 'ca9eadaa2d2c7f1a1c1d7f3a3bf3bb7ee15b9fe1'

    tmp = checksum_s(good_data)
    assert tmp == good_sha1, tmp
    tmp = checksum_s(bad_data)
    assert tmp == bad_sha1, tmp
    assert checksum_s(good_data) != checksum_s(bad_data)



# Generated at 2022-06-21 08:23:49.321237
# Unit test for function checksum
def test_checksum():
    assert checksum('changelogs/CHANGELOG-v1.8') == '1cff3b3a3eee078527f0c9b71d6745a6a80a7a35'
    assert checksum('changelogs/CHANGELOG-v1.8', 'sha256') == 'd7574e7b1a19f3cd3eee3c27e08ea9b398de6745f7ddd075ccfa1a7e82972d09'


# Generated at 2022-06-21 08:23:57.983331
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestChecksum(unittest.TestCase):

        def test_checksum_success(self):
            with patch("os.path.exists") as ope_mock:
                ope_mock.return_value = True
                with patch("os.path.isdir") as ope_isdir_mock:
                    ope_isdir_mock.return_value = False
                    with patch("ansible.utils.checksum.sha1") as sha1_mock:
                        h = sha1_mock.return_value
                        h.update.return_value = None

# Generated at 2022-06-21 08:24:02.874856
# Unit test for function md5
def test_md5():
    assert md5(__file__) == 'c9e00d63d69bfb6a09b702fdce8d895c'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'


# Generated at 2022-06-21 08:24:10.073551
# Unit test for function checksum
def test_checksum():
    ''' test_checksum() - basic checksum function test'''
    data = 'hello world'
    expected = '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    actual = checksum_s(data)
    if actual != expected:
        raise AssertionError('checksum_s() produced unexpected result. Actual:%s, Expected:%s' % (actual, expected))



# Generated at 2022-06-21 08:24:17.811818
# Unit test for function md5
def test_md5():
    # Testing with short and long data
    short = "abcde"
    short_md5 = md5s(short)
    assert short_md5 == '01d8e7ae97ec69d0d898e46f9a90a756'

    long_data = """This
is
a test
of
the
emergency
broadcast
system"""
    long_md5 = md5s(long_data)
    assert long_md5 == '6db9f7d3c3e44ab746c14e5e5b5c2df5'


# Generated at 2022-06-21 08:24:31.218009
# Unit test for function checksum
def test_checksum():
    ''' Test the checksum function.  This isn't a real test, this is more of an integration test.
    The integrity of sha1 is out of scope of this testing.
    '''
    import tempfile
    import shutil
    import filecmp

    (fd, fname) = tempfile.mkstemp(suffix='.txt')
    f = os.fdopen(fd, 'w')
    f.write("hello world\n")
    f.close()

    # Test that the file was created with the correct contents
    f = open(fname, 'r')
    r = f.read()
    f.close()
    os.remove(fname)
    assert(r == "hello world\n")

    # Test that comparing the checksums of two identical files comes out True

# Generated at 2022-06-21 08:24:36.072175
# Unit test for function checksum_s
def test_checksum_s():

    # Test string
    data = 'This is some data to hash'
    expected = 'f868ab5cb5b5d7b5e5a1c9692b2f403978e9e9c5'
    actual = checksum_s(data)

    assert actual == expected


# Generated at 2022-06-21 08:24:43.498462
# Unit test for function md5
def test_md5():
    # test files must be created before runing unit test
    # and should be deleted after testing
    import tempfile
    (dummy_fd, dummy_filename) = tempfile.mkstemp()
    assert(md5(dummy_filename) == '23d9cc3f1e3a3c48a89d0f3b68527fb9')
    assert(md5s('hello') == '5d41402abc4b2a76b9719d911017c592')
    os.remove(dummy_filename)



# Generated at 2022-06-21 08:24:47.663468
# Unit test for function md5
def test_md5():
    bytes_data = b'Hello World!'
    string_data = b'Hello World!'.decode()

    assert md5s(bytes_data) == 'b10a8db164e0754105b7a99be72e3fe5'
    assert md5s(string_data) == 'b10a8db164e0754105b7a99be72e3fe5'

# Generated at 2022-06-21 08:24:58.294993
# Unit test for function md5s
def test_md5s():
    from unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase
    # Test 1, with md5 support
    test1 = 'Nothing important, just test for md5s function'
    correct_result = '5536b7d9fa4a0a6586f4e2d8d7e79311'
    md5test1 = md5s(test1)
    assert md5test1 == correct_result
    # Test 2, without md5 support
    # Try with hashlib
    try:
        from hashlib import md5 as _md5
    except ImportError:
        # Add md5 to module search path and try again
        import sys
        sys.modules['hashlib'] = None

# Generated at 2022-06-21 08:25:06.504463
# Unit test for function md5
def test_md5():
    ## module_utils/hashing.py, function md5()

    # Test for md5() function
    # Test with a nonexistent file
    nonexistent_file = secure_hash("nonexistent_file")
    # Check if file is not found
    assert nonexistent_file == None
    # Test with a directory
    directory = secure_hash("module_utils")
    # Check if directory is found
    assert directory == None
    # Test for a real file
    real_file = secure_hash("module_utils/hashing.py")
    # Check if file is found and hash is valid
    assert real_file == "d9f8018eb98b8a1c0ea6d1cba837e6b8"


# Generated at 2022-06-21 08:25:16.856876
# Unit test for function md5s
def test_md5s():
    import unittest
    class TestSequenceFunctions(unittest.TestCase):
        def setUp(self):
            pass
        def test_md5s(self):
            self.assertEqual(md5s('test123'), '076d16f320e37406c98c8f7aba165a53')
            self.assertEqual(md5s(u'test123'), '076d16f320e37406c98c8f7aba165a53')
            self.assertEqual(md5s(u'test123'), '076d16f320e37406c98c8f7aba165a53')
            self.assertEqual(md5s(b'test123'), '076d16f320e37406c98c8f7aba165a53')

# Generated at 2022-06-21 08:25:24.919776
# Unit test for function checksum
def test_checksum():

    assert checksum("/bin/ls") == "6b163426188022dc5c5ea03a7d0d0455"
    assert checksum("/bin/ls") == checksum("/usr/bin/ls")

    # Ensure we get an exception when the file does not exist
    try:
        checksum("/bin/bar")
        raise Exception("Shouldn't get here")
    except AnsibleError:
        pass
    else:
        raise Exception("Shouldn't get here")

    assert checksum_s("hello world") == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"
    assert checksum_s("hello world") == checksum_s("HELLO WORLD")


if __name__ == '__main__':
    test_checksum

# Generated at 2022-06-21 08:25:32.296018
# Unit test for function md5s
def test_md5s():

    data = 'This is my input string'
    hashed_data = '566e3e3d1fc3db9a9a41e31caa58d0dd'
    test_md5 = md5s(data)
    assert (test_md5 == hashed_data), "Test failed! MD5 hash did not match."

    print('Test passed!')

if __name__ == "__main__":
    test_md5s()

# Generated at 2022-06-21 08:25:40.843637
# Unit test for function md5
def test_md5():
    from ansible.module_utils.six import PY3

    if PY3:
        return
    '''
    >>> from ansible.utils import md5
    '''
    current_dir = os.path.dirname(__file__)
    test_file = current_dir + os.sep + "test_md5.txt"

    test_file_open = open(test_file, "w")
    test_file_open.write("Hello World")
    test_file_open.close()
    # If we are on a FIPS enabled system, this will raise an exception
    md5sum = md5(test_file)
    assert md5sum == "ed076287532e86365e841e92bfc50d8c"
    os.unlink(test_file)


# Backwards compat

# Generated at 2022-06-21 08:25:50.987311
# Unit test for function md5
def test_md5():
    ''' test md5() and md5s() using file and string '''
    import os
    import tempfile

    # testing a file
    (fd, fname) = tempfile.mkstemp()
    os.write(fd, b"hello")

    m = md5(fname)
    assert m == "5d41402abc4b2a76b9719d911017c592"
    os.close(fd)
    os.unlink(fname)

    # testing a string
    m = md5s("hello")
    assert m == "5d41402abc4b2a76b9719d911017c592"

# Generated at 2022-06-21 08:25:56.196229
# Unit test for function md5
def test_md5():
    filename = os.path.join(os.path.dirname(__file__), "test.md5")
    with open(filename) as f:
        for line in f:
            if line.strip() == "":
                continue
            (md5sum, filename) = line.split()
            filename = os.path.join(os.path.dirname(__file__), filename)
            assert md5(filename) == md5sum


# Generated at 2022-06-21 08:26:00.653446
# Unit test for function md5s
def test_md5s():

    test_string = "Hello World"
    expected_result = "ed076287532e86365e841e92bfc50d8c"

    assert(md5s(test_string) == expected_result)

# Generated at 2022-06-21 08:26:04.023340
# Unit test for function checksum
def test_checksum():
    checksum_value = secure_hash('./test/units/module_utils/basic.py')
    print("Checksum: %s" % checksum_value)

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:26:05.688106
# Unit test for function md5s
def test_md5s():
    assert "d41d8cd98f00b204e9800998ecf8427e" == md5s("")

# Generated at 2022-06-21 08:26:07.851746
# Unit test for function md5
def test_md5():
    assert md5("test.txt") == "7afd70a31f2a2b87ee9b2add3da3a3d3"


# Generated at 2022-06-21 08:26:11.255279
# Unit test for function md5s
def test_md5s():
    if _md5:
        # Known message digest (from RFC 1321)
        assert md5s("The quick brown fox jumps over the lazy dog") == "9e107d9d372bb6826bd81d3542a419d6"


# Generated at 2022-06-21 08:26:15.266912
# Unit test for function md5s
def test_md5s():
    if not _md5:
        # Don't run the test; it will fail
        return
    if md5s('hello') != '5d41402abc4b2a76b9719d911017c592':
        raise Exception("md5s() test failed")



# Generated at 2022-06-21 08:26:25.559025
# Unit test for function checksum_s
def test_checksum_s():
    from tempfile import NamedTemporaryFile
    from shutil import rmtree
    from tempfile import mkdtemp

    empty_file = NamedTemporaryFile(delete=False)
    empty_file.close()
    empty_md5 = md5s("")
    empty_sha1 = checksum_s("")
    assert empty_md5 == "d41d8cd98f00b204e9800998ecf8427e"
    assert empty_sha1 == "da39a3ee5e6b4b0d3255bfef95601890afd80709"
    one_file = NamedTemporaryFile(delete=False)
    one_file.write("*")
    one_file.close()
    one_md5 = md5s("*")
    one_sha1 = checksum_s("*")


# Generated at 2022-06-21 08:26:28.942899
# Unit test for function md5s
def test_md5s():
    ''' md5s should return correct md5 hash '''

    assert md5s('data') == '1f3870be274f6c49b3e31a0c6728957f'



# Generated at 2022-06-21 08:26:39.471908
# Unit test for function checksum
def test_checksum():
    file_name = "test_checksum"
    test_string = "This is a test string!"
    with open(file_name, "w") as f:
        f.write(test_string)
    expected_checksum = "5f5a5a5b5d5588c2b4f17d4b151a352427c5b9a5"
    assert checksum(file_name) == expected_checksum
    os.remove(file_name)
    assert checksum(file_name) == None
    assert checksum_s(test_string) == expected_checksum
    try:
        md5s("test")
        assert False
    except ValueError:
        assert True
    try:
        md5("test")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-21 08:26:44.903592
# Unit test for function md5
def test_md5():
    filename = "sample.txt"
    f = open(filename, 'w')
    f.write('Hello')
    f.close()
    returned_value = md5(filename)
    os.remove(filename)
    assert returned_value == 'ed076287532e86365e841e92bfc50d8c'

# Generated at 2022-06-21 08:26:49.468726
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', _md5) == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-21 08:26:52.972490
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return
    rtn = md5s("hello")
    assert rtn == "5d41402abc4b2a76b9719d911017c592"

# Generated at 2022-06-21 08:26:57.281805
# Unit test for function md5
def test_md5():
    assert md5s("Hello World") == "ed076287532e86365e841e92bfc50d8c"
    assert md5("test/unit/utils/test_utils.py") == "08e1e6f4d6b5f6bdca15a3669b6cbf02"

# Generated at 2022-06-21 08:27:07.680002
# Unit test for function md5
def test_md5():
    from ansible.compat.tests.mock import patch

    with patch('ansible.module_utils.basic._md5') as mock_md5, \
            patch('os.path.exists') as mock_exists, \
            patch('os.path.isdir') as mock_isdir:
        mock_md5.return_value = 'md5'
        mock_exists.return_value = True
        mock_isdir.return_value = False
        assert md5('test') == 'md5'
        mock_md5.assert_called_with()
        mock_exists.assert_called_with('test')
        mock_isdir.assert_called_with('test')
        mock_exists.return_value = False
        assert md5('test') is None
        mock_md5.assert_

# Generated at 2022-06-21 08:27:10.552854
# Unit test for function checksum
def test_checksum():
    filename = '/etc/rc.conf'
    print('%s: %s' % (filename, checksum(filename)))

# Generated at 2022-06-21 08:27:19.281652
# Unit test for function checksum_s
def test_checksum_s():

    class FakeKey(object):
        def __init__(self, name):
            self.name = name

    assert checksum_s('hello', FakeKey('sha1')) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', FakeKey('md5')) == '5d41402abc4b2a76b9719d911017c592'

    if _md5:
        assert checksum_s('world') == '86fb269d190d2c85f6e0468ceca42a20'

# Generated at 2022-06-21 08:27:25.319285
# Unit test for function md5s
def test_md5s():
    test_md5s = ['a', 'tester', 'test']
    # Using the OpenSSL command line tool for known hashes
    for test_md5 in test_md5s:
        test_md5 = to_bytes(test_md5)
        assert md5s(test_md5) == "7f9c2ba4e88f827d616045507605853e"


# Generated at 2022-06-21 08:27:33.467769
# Unit test for function md5
def test_md5():
    import tempfile
    test_string = "This is a string"
    file_name = tempfile.NamedTemporaryFile().name
    f = open(file_name, 'w')
    f.write(test_string)
    f.close()

    assert md5s(test_string) == 'd62c43e372d0e9f7521c3073952f8e7d'
    assert md5(file_name) == 'd62c43e372d0e9f7521c3073952f8e7d'

# Generated at 2022-06-21 08:27:40.323162
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-21 08:27:48.685845
# Unit test for function md5
def test_md5():
    # Create a test file
    (fd, test_path) = tempfile.mkstemp()
    test_file = open(test_path, 'w')
    test_str = 'string to test md5'
    test_file.write(test_str)
    test_file.close()

    # Calculate the md5 of the test file
    actual_md5 = md5(test_path)

    # Calculate the md5 of the test string
    expected_md5 = secure_hash_s(test_str, _md5)

    assert actual_md5 == expected_md5, \
        "actual_md5: %s; expected_md5: %s" % (actual_md5, expected_md5)

# Generated at 2022-06-21 08:28:00.275729
# Unit test for function checksum_s
def test_checksum_s():
    data = 'test'
    checksum = secure_hash_s(data)
    correct = '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert checksum == correct

    # Test that function works with unicode data
    data = u'\u0430\u043d\u0441\u0438\u0431\u043b'
    checksum = secure_hash_s(data)
    # This is the correct hash for the utf-8 representation of 'data'
    correct = 'ca59e8e06281d2dd2a0de3912b92c8b5f95aa9fe'
    assert checksum == correct


# Generated at 2022-06-21 08:28:09.244284
# Unit test for function md5s
def test_md5s():
    ''' unit test for md5s()'''
    # Note, sha1 is the only hash algorithm compatible with python2.4 and with
    # FIPS-140 mode (as of 11-2014)
    import hashlib
    if hasattr(hashlib, 'md5'):
        # If we have a current hash module, use that to verify function
        assert(md5s('string_test') == '6f8db599de986fab7a21625b7916589c')
    else:
        # Otherwise, use the hexdigest of the old-fashioned md5 module
        import md5
        assert(md5s('string_test') == md5.new('string_test').hexdigest())

# Generated at 2022-06-21 08:28:15.494364
# Unit test for function md5
def test_md5():
    test_filename = "/tmp/test"
    with open(test_filename,"w") as f:
        f.write("test")
    assert md5(test_filename) == '098f6bcd4621d373cade4e832627b4f6'
    err = "MD5 not available.  Possibly running in FIPS mode"

# Generated at 2022-06-21 08:28:21.156198
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  tests for module_utils.checksum '''

    import tempfile
    import os
    fd, name = tempfile.mkstemp()
    os.write(fd, b"ansible")
    os.close(fd)
    assert checksum(name) == checksum_s("ansible")
    os.unlink(name)

# Generated at 2022-06-21 08:28:29.674462
# Unit test for function md5
def test_md5():
    # Result of md5sum tests/utils/test_md5_hashsum.txt is "2cbb1b809f60eb3457650b6a1c8e5a82"
    # Result of md5 "tests/utils/test_md5_hashsum.txt" is "2cbb1b809f60eb3457650b6a1c8e5a82"
    checksum_md5 = md5('tests/utils/test_md5_hashsum.txt')
    return checksum_md5 == "2cbb1b809f60eb3457650b6a1c8e5a82"


# Generated at 2022-06-21 08:28:38.498889
# Unit test for function checksum_s
def test_checksum_s():
    ''' Unit test for function checksum_s. '''
    # Test the function with plain text
    message = 'Welcome to Ansible'
    h = checksum_s(message)
    assert isinstance(h, str)
    assert len(h) == 40
    assert h == '5aa5259ca6b7ec1b2645e4973a1d9a6ac723e69c'

    # Test the function with unicode
    u_message = u'\u20ac'
    h = checksum_s(u_message)
    assert h == u'94946180627d0b9462d9a8c1a87e54bcd62710a1'


# Generated at 2022-06-21 08:28:48.998715
# Unit test for function md5s
def test_md5s():
    '''Test cases for Ansible md5s function'''
    from ansible.utils.unicode import to_bytes
    try:
        from hashlib import md5 as _md5
    except ImportError:
        try:
            from md5 import md5 as _md5
        except ImportError:
            return False

    assert md5s("test") == _md5(to_bytes("test", errors='surrogate_or_strict')).hexdigest()
    assert md5s(u"test") == _md5(to_bytes("test", errors='surrogate_or_strict')).hexdigest()
    assert md5s(b"test") == _md5(b"test").hexdigest()

# Generated at 2022-06-21 08:28:52.881278
# Unit test for function md5
def test_md5():
    f = open(os.path.dirname(__file__)+"/hashes", "w")
    f.write("001b7a0e55bda062bd9d9a5a5a5c5fb5 *test\n")
    f.close()
    assert (md5(os.path.dirname(__file__)+"/test") == "001b7a0e55bda062bd9d9a5a5a5c5fb5")
    os.remove(os.path.dirname(__file__)+"/hashes")

# Generated at 2022-06-21 08:29:00.461135
# Unit test for function checksum_s
def test_checksum_s():
    h = secure_hash_s("The quick brown fox jumps over the lazy dog")
    assert h == '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12'



# Generated at 2022-06-21 08:29:02.563543
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-21 08:29:05.976712
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world\n") == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s("ansible") == "9fdcd1019e0fd7f2e00a8efd7ae1ddf4"

# Generated at 2022-06-21 08:29:13.947714
# Unit test for function md5
def test_md5():
    if _md5:
        input = "this is my data to hash"
        expected_md5 = "a641a70a723c1f65619d9e01f4fa4f57"
        r = md5s(input)
        assert r == expected_md5, "%s != %s" % (r, expected_md5)
    else:
        # no md5 module, just assume it's working.
        pass


# Generated at 2022-06-21 08:29:22.321890
# Unit test for function md5
def test_md5():

    msg = b"hello"
    digest = b"5d41402abc4b2a76b9719d911017c592"

    assert md5s(msg) == digest, "wrong md5s"
    f = os.path.join(os.getcwd(), "test_utils_md5.txt")
    fw = open(f, "wb")
    fw.write(msg)
    fw.close()
    assert md5(f) == digest, "wrong md5"
    os.remove(f)

# Generated at 2022-06-21 08:29:29.224814
# Unit test for function checksum
def test_checksum():
    testfile='/tmp/checksum_test'
    testdata='0' * 100
    with open(testfile, 'w') as fh:
        fh.write(testdata)
    sha1_sum = checksum(testfile)
    assert sha1_sum is not None
    os.unlink(testfile)

# Generated at 2022-06-21 08:29:31.758485
# Unit test for function md5s
def test_md5s():
    assert md5s('abcdefgh') == '28d20c9933c828f7018b85f1f75e30e9'



# Generated at 2022-06-21 08:29:35.206326
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("foo") == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_s("bar") == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'

# Generated at 2022-06-21 08:29:46.905938
# Unit test for function md5
def test_md5():
    import filecmp
    import shutil
    import tempfile
    import random

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a temporary file in the directory
    tmpfile = tempfile.NamedTemporaryFile(prefix='ansible-tmp-md5-test-', dir=tmpdir, delete=False)
    data_line = '%032x\n' % random.getrandbits(128)
    for i in range(100):
        tmpfile.write(data_line.encode())
    tmpfile.close()

    # compute the md5 checksum for the file
    ansible_md5 = md5(tmpfile.name)

    # compare it with the output of the system 'md5sum' command
    cmd = 'md5sum'

# Generated at 2022-06-21 08:29:58.338065
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('test') == secure_hash_s('test')
    assert checksum_s('test') == secure_hash_s('test', hash_func=sha1)
    assert checksum_s('test', hash_func=_md5) == secure_hash_s('test', hash_func=_md5)
    assert checksum_s('test') != checksum_s('test2')
    assert checksum_s('test', hash_func=_md5) != checksum_s('test2', hash_func=_md5)
    assert checksum_s('test', hash_func=_md5) != secure_hash_s('test', hash_func=sha1)


# Generated at 2022-06-21 08:30:09.184319
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('baz') == 'a3b3ed3f7fdaa9a55d7f4a862c1f4605c4f18b5a'
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'



# Generated at 2022-06-21 08:30:11.602081
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

# Generated at 2022-06-21 08:30:18.037559
# Unit test for function checksum_s
def test_checksum_s():
    from os import remove
    from os.path import exists
    from tempfile import mkstemp
    from shutil import copyfileobj
    from ansible.utils.path import makedirs_safe

    (fd, src) = mkstemp()
    f = open(src, 'w')
    f.write('hello world')
    f.close()

    result = checksum_s('hello world')

    assert result == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    # Test that checksum_s matches md5s for backwards compat
    try:
        assert checksum_s('hello world') == md5s('hello world')
    except ValueError:
        # Being run on a FIPS-140-2 compliant system.  md5 not allowed
        return

   

# Generated at 2022-06-21 08:30:24.985678
# Unit test for function checksum_s
def test_checksum_s():
    """
    Ansible secure_hash_s unit test
    """
    print("checksum_s test")
    print("Asserting that 'foo' == %s" % checksum_s('foo'))
    assert secure_hash_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'

# Generated at 2022-06-21 08:30:30.107480
# Unit test for function md5
def test_md5():
    import random
    import string
    s = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(100))

    md5 = md5s(s)
    assert(md5 == "c76a269d8e9682862e55b4a996b88c4b")

test_md5()

# Generated at 2022-06-21 08:30:36.535786
# Unit test for function md5
def test_md5():
  data1 = "Mais où sont les neiges d'antan?"
  data2 = "Les neiges d'antan neigeaient-elles pas aussi?"
  assert md5s(data1) == "ebee7a9b54a6d087c2f8cb57c7bbe259"
  assert md5s(data2) == "bcc36fbd0d7eae8f8b79c2b1a119ef44"


# Generated at 2022-06-21 08:30:43.348803
# Unit test for function md5s
def test_md5s():
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s('ab') == '187ef4436122d1cc2f40dc2b92f0eba0'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abcd') == 'e2fc714c4727ee9395f324cd2e7f331f'
    assert md5s('abcde') == 'ab56b4d92b40713acc5af89985d4b786'
    assert md5s('abcdef') == 'e80b5017098950fc58aad83c8c14978e'

# Generated at 2022-06-21 08:30:46.839918
# Unit test for function md5
def test_md5():
    string = "test"
    assert md5s(string) == "098f6bcd4621d373cade4e832627b4f6"

# Generated at 2022-06-21 08:30:49.583671
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

# Generated at 2022-06-21 08:30:55.325992
# Unit test for function md5s
def test_md5s():
    if _md5:
        if md5s('test_data') != '6f8db599de986fab7a21625b7916589c':
            raise AnsibleError('md5s() failed sanity check.')
    else:
        try:
            md5s('test_data')
        except ValueError:
            pass
        else:
            raise AnsibleError('md5s() failed sanity check.')

# Generated at 2022-06-21 08:31:03.004539
# Unit test for function md5
def test_md5():

    try:
        md5('/dev/null')
    except ValueError:
        return

    raise ValueError('MD5 hash should fail in FIPS mode')

# Generated at 2022-06-21 08:31:09.095408
# Unit test for function md5s
def test_md5s():
    expected = 'f0e4c2f76c58916ec258f246851bea091d14d4247a2fc3e18694461b1816e13b'
    actual = md5s('Hello World')
    assert expected == actual


# vim: set et ts=4 sts=4 sw=4

# Generated at 2022-06-21 08:31:17.754029
# Unit test for function md5
def test_md5():
    assert md5s('Hello') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('Scooby') == 'bf1944f6b7c3f4bc4f7df13d91b40f82'
    assert md5s('Dooby') == '07c1f82cebde323b867eb0d9efb7e766'
    assert md5s('Doo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('Doo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-21 08:31:23.002754
# Unit test for function md5s
def test_md5s():
    '''
    >>> md5s("hello")
    '5d41402abc4b2a76b9719d911017c592'
    '''
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"



# Generated at 2022-06-21 08:31:26.866466
# Unit test for function checksum
def test_checksum():
    checksum_s('123')
    if os.path.exists('/bin/ls'):
        checksum('/bin/ls')
    else:
        checksum('/bin/false')

if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-21 08:31:29.277731
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-21 08:31:39.749931
# Unit test for function checksum
def test_checksum():

    from ansible.utils.unicode import to_bytes, to_unicode

    #
    # If a text string is passed to the checksum function the result should
    # be the same for each call, for the same string:
    #
    test_unicode_string = u"Hello World!"
    assert checksum_s(test_unicode_string) == 'ed076287532e86365e841e92bfc50d8c'
    assert checksum_s(test_unicode_string) == 'ed076287532e86365e841e92bfc50d8c'
    assert checksum_s(test_unicode_string) == 'ed076287532e86365e841e92bfc50d8c'

    #
    # If a binary string is passed to the checksum function the

# Generated at 2022-06-21 08:31:41.773212
# Unit test for function md5s
def test_md5s():
    test_data = "this is a test"
    assert md5s(test_data) == '6f8db599de986fab7a21625b7916589c'

# Generated at 2022-06-21 08:31:52.125619
# Unit test for function checksum
def test_checksum():
    filename = os.path.join(os.path.dirname(__file__), 'test_utils.py')
    chksum = checksum(filename)
    if chksum != "d9e9f0a19c7fe03e3b3c7d1d8f238bdc37b5abf1":
        raise AnsibleError("unexpected checksum: %s" % chksum )
    result = checksum_s('hello')
    if result != "5d41402abc4b2a76b9719d911017c592":
        raise AnsibleError("unexpected md5 checksum_s: %s" % result )

# Generated at 2022-06-21 08:31:54.769052
# Unit test for function checksum_s
def test_checksum_s():
    mystr = "foobar"
    hash = checksum_s(mystr)
    assert len(hash) == 40, "Error: Hash length not correct for checksum_s"