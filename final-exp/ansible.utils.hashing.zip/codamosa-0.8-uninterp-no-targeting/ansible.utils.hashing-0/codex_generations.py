

# Generated at 2022-06-21 08:22:16.435127
# Unit test for function checksum
def test_checksum():
    import tempfile

    for m in [sha1, md5]:
        # test string
        (fd, fn) = tempfile.mkstemp()
        d = 'This is a test'
        os.write(fd, d)
        os.close(fd)

        assert secure_hash_s(d) == secure_hash_s(d)
        assert secure_hash(fn) == secure_hash(fn)
        assert secure_hash_s(d) == secure_hash(fn)

        os.unlink(fn)

# Generated at 2022-06-21 08:22:27.256051
# Unit test for function md5
def test_md5():
    # md5 is available (no FIPS mode)
    old_md5 = _md5

    class FakeHash(object):
        def __init__(self):
            self.digest = [100, 200, 255]

        def update(self, data):
            pass

        def hexdigest(self):
            return ''.join([chr(x) for x in self.digest])

    _md5 = lambda: FakeHash()
    assert md5('foo') == '64c8f9f3c1b0b31e472382f814f6e82c'
    assert md5s('foo') == '64c8f9f3c1b0b31e472382f814f6e82c'

    # md5 is not available (FIPS mode)
    _md5 = None


# Generated at 2022-06-21 08:22:33.811428
# Unit test for function checksum
def test_checksum():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.become import Become
    from ansible.playbook.become_plugin import BecomePlugin
    from ansible.playbook.role.include import RoleInclude
    print(checksum('lib/ansible/playbook/__init__.py'))

# Generated at 2022-06-21 08:22:46.334844
# Unit test for function md5
def test_md5():
    # prepare test files
    import tempfile
    from ansible.module_utils._text import to_text

    f1 = tempfile.NamedTemporaryFile()
    f1.write(b'hello')
    f1.flush()
    f1.seek(0)

    f2 = tempfile.NamedTemporaryFile()
    f2.write(b'goodbye')
    f2.flush()
    f2.seek(0)

    # run tests

    # test md5s
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

    # test md5
    assert md5(to_text(f1.name)) == '5d41402abc4b2a76b9719d911017c592'

    # edge cases
   

# Generated at 2022-06-21 08:22:56.359001
# Unit test for function md5
def test_md5():
    """
    This is a non-regression test for the md5 function

    """
    import tempfile
    import os

    # Create a temporary file

    (fd, tfile) = tempfile.mkstemp()
    f = open(tfile, 'w')
    f.write("Hello world")
    f.close()

    # MD5 of a file
    assert md5(tfile) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

    # MD5 of a string
    assert md5s("Hello world") == '5eb63bbbe01eeed093cb22bb8f5acdc3'

    os.remove(tfile)

# Generated at 2022-06-21 08:23:07.199374
# Unit test for function md5s
def test_md5s():

    assert 'd41d8cd98f00b204e9800998ecf8427e' == md5s('')
    assert '0cc175b9c0f1b6a831c399e269772661' == md5s('a')
    assert '900150983cd24fb0d6963f7d28e17f72' == md5s('abc')
    assert 'f96b697d7cb7938d525a2f31aaf161d0' == md5s('message digest')
    assert 'c3fcd3d76192e4007dfb496cca67e13b' == md5s('abcdefghijklmnopqrstuvwxyz')
    assert 'd174ab98d277d9f5a5611c2c9f419d9f'

# Generated at 2022-06-21 08:23:14.113655
# Unit test for function checksum
def test_checksum():
    ''' unit test for checksum module '''
    from ansible.module_utils import basic
    import os
    import random
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file under tmpdir
    testfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Write random data to the temporary file
    data = os.urandom(random.randint(1, 10000))
    testfile.write(data)
    testfile.flush()

    # Calculate the md5 and sha1 checksum of the temporary file
    md5sum  = md5(testfile.name)
    sha1sum = checksum(testfile.name)

    # Create ansible module argument spec

# Generated at 2022-06-21 08:23:17.864465
# Unit test for function checksum
def test_checksum():
    filename = os.path.join(os.path.dirname(__file__), '../../tests/test_checksum.txt')
    assert checksum(filename) == 'fc5e038d38a57032085441e7fe7010b0'

# Generated at 2022-06-21 08:23:21.365862
# Unit test for function md5s
def test_md5s():
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'

# Generated at 2022-06-21 08:23:31.372049
# Unit test for function checksum_s
def test_checksum_s():

    assert checksum_s('Hello world', sha1) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed', checksum_s('Hello world')

# Generated at 2022-06-21 08:23:40.374478
# Unit test for function md5s
def test_md5s():
    a = md5s("alpha")
    assert a == "f944dcd135d6eef66e7385b6456e3fde"
    b = md5s("beta")
    assert b == "75e59eeaae7b84555c2acdbaa6fb02d6"


# Generated at 2022-06-21 08:23:46.906281
# Unit test for function md5s
def test_md5s():
    import random
    from base64 import b64encode

    for i in range(2048):
        randint = random.randint(0, 2 ** 1024)
        assert md5s(str(randint)) == md5s(str(randint))
        assert md5s(str(randint)) == md5s(str(randint + 1))
        assert b64encode(randint)[:10] != md5s(str(randint))

# Generated at 2022-06-21 08:23:52.856237
# Unit test for function checksum
def test_checksum():
    path_to_file = os.path.join(os.path.dirname(__file__), '../../lib/ansible/module_utils/basic.py')
    expected_checksum = '1e7ff83c0b1d599c37f0d9f9cc907600b2c2e43e'
    assert checksum(path_to_file) == expected_checksum

# Generated at 2022-06-21 08:23:56.825664
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    # check for valid md5
    test_hash = 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'
    assert test_hash == md5s("hello world")



# Generated at 2022-06-21 08:24:07.699729
# Unit test for function checksum
def test_checksum():

    # test checksum_s
    try:
        checksum_s('1')
        checksum_s('12345678901234567890123456789012345678901234567890123456789012345678901234567890')
    except Exception:
        assert False

    # test checksum
    if os.path.exists('/etc/passwd'):
        if os.path.isdir('/etc/passwd'):
            assert checksum('/etc/passwd') == None
        else:
            try:
                checksum('/etc/passwd')
            except Exception:
                assert False
    else:
        assert checksum('/etc/passwd') == None

# Generated at 2022-06-21 08:24:09.968156
# Unit test for function checksum_s
def test_checksum_s():
    data = b"foobar"
    ret  = secure_hash_s(data, hash_func=sha1)
    assert ret == "8843d7f92416211de9ebb963ff4ce28125932878"

# Generated at 2022-06-21 08:24:17.346295
# Unit test for function checksum
def test_checksum():
    import tempfile

    # Create a temporary file with a known string
    fd, tfn = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('abcdef')
    f.close()

    # Check sum
    res = checksum(tfn)
    if res != '97ecefdb0e35eca2588f042e792e0f0e83cdd1d1':
        raise Exception('Failed checksum() function test')

    # Remove temporary file
    os.unlink(tfn)

# Generated at 2022-06-21 08:24:20.873142
# Unit test for function checksum_s
def test_checksum_s():
    expected = "c4e2d2f0d2c816e869bddde17cbbf9e6ba2e1a3b"

    assert expected == checksum_s("foo")


# Generated at 2022-06-21 08:24:26.462493
# Unit test for function md5
def test_md5():
    assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"
    fname = os.path.join(os.path.dirname(__file__), 'test_md5.py')
    assert md5(fname) == "0aaf2edc4af0e0d3a4e4ac8f67a0c7a4"

# Generated at 2022-06-21 08:24:30.132686
# Unit test for function checksum
def test_checksum():
    content = 'hello world'
    retval = checksum_s(content)
    assert retval == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed', retval

# Generated at 2022-06-21 08:24:35.049505
# Unit test for function checksum_s
def test_checksum_s():
  try:
    assert(checksum_s("Hello World", sha1) == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed")
  except Exception as err:
    print("test_checksum_s: %s" % err)



# Generated at 2022-06-21 08:24:45.451938
# Unit test for function checksum
def test_checksum():
    # We assume that the function secure_hash_s works fine.
    # We just test the function checksum here
    # We create a file for testing
    file_content = "This is the content of the file"
    test_file = open("test_checksum", "w")
    test_file.write(file_content)
    test_file.close()

    # We calculate the sha1 digest of the file's content
    if os.path.exists("test_checksum") and not os.path.isdir("test_checksum"):
        digest = sha1()
        blocksize = 64 * 1024

# Generated at 2022-06-21 08:24:48.033317
# Unit test for function checksum_s
def test_checksum_s():
    data_1 = "Hello World"
    data_2 = "Hello World!"
    digest_1 = checksum_s(data_1)
    digest_2 = checksum_s(data_2)
    assert digest_1 != digest_2

# Generated at 2022-06-21 08:24:58.776974
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s(b'') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(b'a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s(b'a\n') == 'b9a1632c06fcf0fd1a8b4c49e17f8f48'
    assert md5s(b'\x00\x1f\xa4') == '16a8964f1075e2e2d9a873de543f1d7f'

# Generated at 2022-06-21 08:25:01.408932
# Unit test for function checksum
def test_checksum():
    ''' returns the checksum for a string '''
    assert checksum_s('data') == '4e1243bd22c66e76c2ba9eddc1f91394e57f9f83'

# Generated at 2022-06-21 08:25:09.267144
# Unit test for function checksum_s
def test_checksum_s():
    # We want to make sure that we get the right sha1 checksum
    # for a given piece of data. We do that by comparing the known
    # checksum for the data with the one computed by the function under test
    assert checksum_s(b"hello") == "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d"
    assert checksum_s(b"hello", sha1) == "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d"
    assert checksum_s(b"hello", None) == "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d"

# Generated at 2022-06-21 08:25:12.675749
# Unit test for function md5
def test_md5():
    import tempfile
    (fd, name) = tempfile.mkstemp()
    os.write(fd, b'foobar')
    os.close(fd)
    assert md5(name) == '3858f62230ac3c915f300c664312c63f'
    os.unlink(name)

# Generated at 2022-06-21 08:25:18.679154
# Unit test for function checksum
def test_checksum():
    sample = 'test'
    sample_hash = 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

    assert checksum_s(sample) == sample_hash
    assert checksum(__file__) != None
    assert checksum('/non/existent/file') == None

# Generated at 2022-06-21 08:25:24.532185
# Unit test for function md5
def test_md5():
    from ansible.module_utils._text import to_text

    result = md5(__file__)
    assert result is not None
    assert len(result) == 32
    assert result == '11ae6a79c8d59f9c7ba6da03ea2b46d8'

    result = md5s(to_text(__file__, errors='surrogate_or_strict'))
    assert result is not None
    assert len(result) == 32
    assert result == '72bc481901a53f26d70f3bb1d2b0e5e5'

# Generated at 2022-06-21 08:25:34.768573
# Unit test for function md5
def test_md5():
    from tempfile import NamedTemporaryFile

    line = b"This is a test of the emergency broadcast system."

    tempf = NamedTemporaryFile()
    tempf.write(line)
    tempf.flush()
    assert md5(tempf.name) == secure_hash(tempf.name, _md5)
    assert md5s(line) == secure_hash_s(line, _md5)

    if not _md5:
        # Make sure we can't use it if it is unavailable
        try:
            md5(b"")
            assert False
        except ValueError:
            pass

        try:
            md5s(b"")
            assert False
        except ValueError:
            pass

# Generated at 2022-06-21 08:25:43.506461
# Unit test for function md5
def test_md5():
    import os
    import tempfile

    fd, path = tempfile.mkstemp()

    try:
        os.write(fd, b"This is a test.")
        os.close(fd)
        assert md5(path) == "7fae1f8f2d5a5f579e5b5f5b5a5b4181"
    finally:
        os.unlink(path)

# Generated at 2022-06-21 08:25:52.745858
# Unit test for function checksum_s
def test_checksum_s():
    string_test = 'string to test'
    string_test2 = 'string to test2'

    # Test if the checksum_s works with different hash functions
    assert(checksum_s(string_test, sha1) == 'bda83fda8a3b2d3565f6c9eba9f8d1b287e4c2e0')
    if _md5:
        assert(checksum_s(string_test, _md5) == 'dd62f0b2fe2a8791960e4d049da4f4ff')
        assert(md5s(string_test) == 'dd62f0b2fe2a8791960e4d049da4f4ff')

# Generated at 2022-06-21 08:26:03.469983
# Unit test for function checksum_s

# Generated at 2022-06-21 08:26:13.385714
# Unit test for function checksum
def test_checksum():
    from ansible import constants as C

    tmp_file = C.DEFAULT_LOCAL_TMP + "/mytestfile.txt"

    # Create a temp file and get a checksum of it
    fd = open(tmp_file, "w")
    fd.write("Hello World\n")
    fd.close()
    orig_checksum = checksum(tmp_file)

    # Verify checksum does not change if the file does not change
    assert(orig_checksum == checksum(tmp_file))

    # Verify checksum changes if the file changes
    fd = open(tmp_file, "w")
    fd.write("Hello World\n")
    fd.close()
    assert(orig_checksum != checksum(tmp_file))

    # Cleanup
    os.remove(tmp_file)

# Generated at 2022-06-21 08:26:19.211803
# Unit test for function checksum
def test_checksum():
    with open('test_checksum.txt', 'w') as test_file:
        test_file.write('Hello\n')
    # The checksum algorithm must match with the algorithm in ShellModule.checksum() method
    assert (checksum('test_checksum.txt') == '68b329da9893e34099c7d8ad5cb9c940')
    assert (checksum_s('Hello') == '18fe9f1ccd9e21c8a1593e51c97ebe19')
    os.remove('test_checksum.txt')



# Generated at 2022-06-21 08:26:21.344311
# Unit test for function md5s
def test_md5s():
    data='hello'
    assert md5s(data) == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-21 08:26:32.345909
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
    assert checksum('/bin/lsx') == None
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s(None) == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

# Generated at 2022-06-21 08:26:34.893066
# Unit test for function checksum_s
def test_checksum_s():
    import sys
    if sys.version_info[0] == 3:
        return checksum_s(u'foo')
    else:
        return checksum_s('foo')

# Generated at 2022-06-21 08:26:38.983807
# Unit test for function checksum
def test_checksum():
    ''' returns True if the unit test passes, False otherwise '''
    import tempfile

    (fd, name) = tempfile.mkstemp()
    os.write(fd, b"test string")
    os.close(fd)
    try:
        assert checksum(name) == "c55b9af39e7c1cac39acba7e5d44183b"
    finally:
        os.unlink(name)
    return True

# Generated at 2022-06-21 08:26:50.816126
# Unit test for function md5s
def test_md5s():
    from ansible.compat.six import StringIO
    from ansible.compat.tests import unittest
    # use StringIO as it handles unicode natively in python 2 and 3
    class TestMd5(unittest.TestCase):
        _data = u'Iñtërnâtiônàlizætiøn'
        _md5_hexdigest = u'c3d12f645ac06dcc01f47aed8ceb9f15'
        _md5_b64digest = u'dAtnkrx6lhZ6I2U6zcUeSQ=='
        _sha1_hexdigest = u'155f4d4b4c9afb0afc9f04a7000d24f4059e7e1c'

# Generated at 2022-06-21 08:26:57.124112
# Unit test for function md5
def test_md5():
    print('MD5 = %s' % md5('/bin/ls'))
    print('MD5s = %s' % md5s('Test string'))

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-21 08:27:07.644765
# Unit test for function checksum
def test_checksum():

    # Test with empty string
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'

    # Test with a short string
    assert checksum_s('Hello world, my name is Joshua!') == '446e076b567f9005d5b95594f386fd6f7e6e5497'

    # Test with a long string

# Generated at 2022-06-21 08:27:19.776923
# Unit test for function md5s
def test_md5s():
    data='abc'
    assert(md5s(data) == '900150983cd24fb0d6963f7d28e17f72')

    data='abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq'
    assert(md5s(data) == '8215ef0796a20bcaaae116d3876c664a')

    data='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    assert(md5s(data) == 'd174ab98d277d9f5a5611c2c9f419d9f')


# Generated at 2022-06-21 08:27:22.880302
# Unit test for function md5s
def test_md5s():
    if md5s('hello') != '5d41402abc4b2a76b9719d911017c592':
        raise AssertionError('md5s test failed')



# Generated at 2022-06-21 08:27:33.805578
# Unit test for function checksum
def test_checksum():
    from subprocess import Popen, PIPE

    p = Popen(['python', '-c', 'import sys; print(sys.version_info[0])'], stdout=PIPE, stderr=PIPE)
    python_version = p.stdout.read()
    if python_version == b'2':
        assert(checksum("test/test_utils.py") == "1e76ce2e2f929b05d6fbe78cb95f1b35")
    else:
        assert(checksum("test/test_utils.py") == "b2e3d27c07843b1f30f5c0e3d5279c8a")


# Generated at 2022-06-21 08:27:36.615877
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-21 08:27:45.579769
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(u'hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(b'hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(None) == 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'

# Generated at 2022-06-21 08:27:48.881335
# Unit test for function md5
def test_md5():
    """ Tests md5 function """
    assert md5('/etc/resolv.conf') == '3be9e9c6882f5a8c5e2b93fb6b1483e1'

# Generated at 2022-06-21 08:27:51.225044
# Unit test for function md5
def test_md5():
    file = '/etc/ansible/hosts'
    print("md5 hash for file %s is %s" % (file, md5(file)))

# Generated at 2022-06-21 08:28:01.901316
# Unit test for function md5
def test_md5():
    ''' md5 unit test. '''

    filename = 'test_module_utils.py'

    # check that a file exists and is a file
    assert os.path.isfile(filename)

    # check that md5 hash of the file matches the md5 hash of the file
    assert md5(filename) == md5(filename)

    # check that md5 hash of the file matches the md5 hash of the file
    # with a specific block size
    assert md5(filename) == md5(filename)

    # Test a file which does not exist
    assert md5('/path/to/file/which/does/not/exist') is None

    # Test a directory, it should return None
    assert md5(os.path.dirname(filename)) is None

# Generated at 2022-06-21 08:28:08.294766
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "6b8e2644414f8a0e53d6e737b3183a74e3d9a496"
    assert checksum("/file/not/found") is None


# Generated at 2022-06-21 08:28:10.749808
# Unit test for function checksum
def test_checksum():
    s = "hello world"
    assert checksum_s(s) == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"


# Generated at 2022-06-21 08:28:17.559431
# Unit test for function md5
def test_md5():
    filename='test_file_for_md5'
    f = open(filename,'w')
    f.write('hello world')
    f.close()
    md5hash=md5(filename)
    assert md5hash == 'b10a8db164e0754105b7a99be72e3fe5'
    os.remove(filename)

# Generated at 2022-06-21 08:28:20.772453
# Unit test for function md5s
def test_md5s():
    msg = 'test message'
    res = md5s(msg)
    assert 'fb1c3cfcc3a89cdaaa9137ff39cb9b0c' == res


# Generated at 2022-06-21 08:28:25.329618
# Unit test for function md5
def test_md5():
    assert md5s('hello world') == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5('/bin/cat') == "8cbb5f5d5c5b1e43a5f9a1bbac3b7f3d"


# Generated at 2022-06-21 08:28:28.445558
# Unit test for function md5
def test_md5():
    assert md5("lib/ansible/modules/network/cloudengine/ce_config.py") == '5a5f9a9be2ef3801e0c1cc52e8bd71f6'

# Generated at 2022-06-21 08:28:35.579217
# Unit test for function md5s
def test_md5s():
    import os
    import shutil
    import tempfile

    # create a file and compute its hash
    tmp_dir = tempfile.mkdtemp()
    tmp_filename = os.path.join(tmp_dir, "tmp_test_file")
    with open(tmp_filename, "w") as output_file:
        output_file.write("test content")
    hashval = md5s("test content")

    # now try to compute it in other ways
    assert hashval == md5(tmp_filename)

    with open(tmp_filename, "r") as input_file:
        assert hashval == md5s(input_file.read())

    # clean temporary files
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-21 08:28:41.613990
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s('Hello World') == 'b10a8db164e0754105b7a99be72e3fe5'
    assert md5s(open(__file__).read()) != 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-21 08:28:48.997511
# Unit test for function md5
def test_md5():
    data = md5('/etc/passwd')
    assert data == 'b4a9f9e8f0e9d2b68a3a79af0c3b3d3b'
    assert md5s('/etc/passwd') == 'b4a9f9e8f0e9d2b68a3a79af0c3b3d3b'
    assert md5s('/etc/shadow') == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-21 08:28:52.881857
# Unit test for function md5
def test_md5():
    assert md5(None) is None
    assert md5('') is None
    assert md5('/doesnotexist') is None
    assert md5('/dev/null') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/etc/hosts') == '6c5da5d5a99b5279a670a8f8c78dba71'
    try:
        md5(__file__)
    except ValueError as e:
        assert "FIPS mode" in str(e)



# Generated at 2022-06-21 08:29:00.582404
# Unit test for function checksum
def test_checksum():

    # Test normal execution
    (rc, out, err) = module.run_command(module.get_bin_path('head', required=True) + " /etc/passwd")
    assert rc == 0
    assert out != err
    assert len(out) > 0
    assert len(err) == 0
    md5 = secure_hash_s(out)
    sha1 = secure_hash_s(out)
    assert md5 != None
    assert sha1 != None

    # Test if the command does not exist
    (rc, out, err) = module.run_command("false")
    assert rc == 1
    assert out == err
    assert len(out) == 0
    assert len(err) > 0

    # Test if the command is not executable

# Generated at 2022-06-21 08:29:09.921489
# Unit test for function checksum
def test_checksum():
    import tempfile

    fd, fp = tempfile.mkstemp()

# Generated at 2022-06-21 08:29:22.062488
# Unit test for function checksum
def test_checksum():
    import tempfile
    import os

    if os.path.exists('/bin/cp'):
        CP = '/bin/cp'
    elif os.path.exists('/usr/bin/cp'):
        CP = '/usr/bin/cp'
    else:
        raise OSError


# Generated at 2022-06-21 08:29:25.928656
# Unit test for function md5s
def test_md5s():
    '''
    >>> from ansible.utils import md5s
    >>> md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    True
    '''


# Generated at 2022-06-21 08:29:36.120824
# Unit test for function checksum
def test_checksum():
    import os
    import tempfile
    # Create temporary file
    (tmpfile, tmpfile_name) = tempfile.mkstemp()
    now = b'1\n'
    nill = b'\n'
    twice = b'2\n'
    # Note, check the checksum not the contents
    os.write(tmpfile, now)
    now_sha1 = secure_hash(tmpfile_name)
    os.write(tmpfile, nill)
    nil_sha1 = secure_hash(tmpfile_name)
    os.write(tmpfile, twice)
    twice_sha1 = secure_hash(tmpfile_name)
    # Ensure that the checksums are different
    assert now_sha1 != twice_sha1
    assert now_sha1 != nil_sha1

# Generated at 2022-06-21 08:29:39.949766
# Unit test for function md5s
def test_md5s():
    # test case
    string = 'hello world'
    digest = md5s(string)

    # print result
    print('the string is "%s".' % string)
    print('the md5 digest of string is "%s".' % digest)


# Generated at 2022-06-21 08:29:43.930823
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-21 08:29:46.342423
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-21 08:29:49.075354
# Unit test for function checksum_s
def test_checksum_s():
    data = 'ansible'
    hexdigest = 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert hexdigest == secure_hash_s(data)

# Generated at 2022-06-21 08:29:56.796296
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(' ') == '7215ee9c7d9dc229d2921a40e899ec5f'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-21 08:30:06.304818
# Unit test for function md5
def test_md5():
    ''' ansible.utils.md5 test '''

    utils_path = os.path.dirname(__file__)
    test_file = os.path.join(utils_path,
                             'test_file_md5')

    # test reading the file
    file_md5 = md5(test_file)
    assert file_md5 == 'fae0e6e3ed3e02728a545bfa6b869277'

    # add extra tests here as they are written


# Generated at 2022-06-21 08:30:11.602103
# Unit test for function checksum
def test_checksum():
    filename='./lib/ansible/module_utils/basic.py'
    filename=os.path.abspath(filename)
    print('filename=%s' % filename)
    print('checksum=%s' % checksum(filename))

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:30:16.558674
# Unit test for function checksum
def test_checksum():
    '''test_checksum
    This is a test to ensure that the checksum function passes
    '''
    checksum_file = checksum("test/utils/checksum_testfile")
    if not checksum_file == "55ca7d43afd9af936e0a633b7d9839041b86ebd0":
        raise Exception("Error calculating checksum")


# Generated at 2022-06-21 08:30:27.921885
# Unit test for function checksum_s
def test_checksum_s():
    # Happy path
    assert checksum_s('test_checksum_s') == 'd0301f3f3a12747f1d8f7c4d4ad4b4ec4b2d2e90'
    # Edge case
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    # Non-ascii string
    assert checksum_s(u'こんにちは') == '7eafb5d831e7c0f1f3fc7c48fae8a33551adec50'
    # Unicode string

# Generated at 2022-06-21 08:30:35.240742
# Unit test for function md5s
def test_md5s():
    from base64 import urlsafe_b64encode
    from random import randint
    from ansible.module_utils.six import text_type
    for _ in range(100):
        for length in range(1, randint(2, 100000)):
            text = urlsafe_b64encode(os.urandom(length))
            if text_type is str:
                text = text.decode('utf-8')
            assert md5s(text) == md5s(text)
            assert md5s(text) != md5s(text[1:])

# Generated at 2022-06-21 08:30:41.868049
# Unit test for function md5s
def test_md5s():
    test_string = 'this is a test'
    if _md5:
        # Test for md5s
        assert md5s('') == b'd41d8cd98f00b204e9800998ecf8427e'
        assert md5s('a') == b'0cc175b9c0f1b6a831c399e269772661'
        assert md5s('abc') == b'900150983cd24fb0d6963f7d28e17f72'
        assert md5s(test_string) == b'2f3db7d60dcf6e04eb6a80e2614e7ade'

test_md5s()

# Generated at 2022-06-21 08:30:48.031940
# Unit test for function md5s
def test_md5s():
    data = "foo"
    # The md5 checksum of "foo" is acbd18db4cc2f85cedef654fccc4a4d8
    assert md5s(data) == "acbd18db4cc2f85cedef654fccc4a4d8"


# Generated at 2022-06-21 08:30:57.799848
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "71b8e4929a5fbea5c7b8e18a9d20c3d3"
    assert md5("/bin/cat") == "866b13c46087a5d539d9c9fa1eba5e28"
    try:
        md5("/bin/notthere")
    except:
        pass

    import tempfile
    # Make a small temporary file
    fd, fname = tempfile.mkstemp()
    os.write(fd, b"0123456789")
    os.close(fd)
    assert md5(fname) == "78e731027d8fd50ed642340b7c9a63b3"
    os.remove(fname)


# Generated at 2022-06-21 08:31:09.937040
# Unit test for function checksum
def test_checksum():
    # create a temporary file
    import tempfile, shutil

    expected_md5_value  = 'd41d8cd98f00b204e9800998ecf8427e'
    expected_sha1_value = 'da39a3ee5e6b4b0d3255bfef95601890afd80709'

    dirname = tempfile.mkdtemp()
    fd, testfile = tempfile.mkstemp(dir=dirname)
    os.close(fd)


# Generated at 2022-06-21 08:31:19.205465
# Unit test for function checksum
def test_checksum():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            filename = dict(required=True),
            algorithm = dict(default='sha1')
        )
    )

    filename = module.params.get('filename')
    algorithm = module.params.get('algorithm')

    module.exit_json(**{
        'changed': False,
        'checksum': checksum(filename,hash_func=getattr(__import__('hashlib', fromlist=[algorithm]), algorithm)()),
        'checkum_s': checksum_s('foo',hash_func=getattr(__import__('hashlib', fromlist=[algorithm]), algorithm)()),
    })

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:31:30.093456
# Unit test for function md5s
def test_md5s():
    data = 'Hello world'
    expected = '5eb63bbbe01eeed093cb22bb8f5acdc3'
    actual = md5s(data)
    assert actual == expected, \
        "Expected %s, got %s" % (expected, actual)



# Generated at 2022-06-21 08:31:40.240025
# Unit test for function md5s
def test_md5s():
    from ansible.compat.tests import unittest
    from ansible.compat.tests import mock

    import binascii

    class md5sTestCase(unittest.TestCase):
        def test_md5s_b(self):
            self.assertEqual(md5s(b'foo'), 'acbd18db4cc2f85cedef654fccc4a4d8')

        def test_md5s_s(self):
            self.assertEqual(md5s('foo'), 'acbd18db4cc2f85cedef654fccc4a4d8')


# Generated at 2022-06-21 08:31:43.053874
# Unit test for function md5
def test_md5():
    h1 = md5("hashlib.py")
    assert h1 == "ac3a591647eb3ea7b1d0817d252b914c"
    h2 = md5s("hashlib.py")
    assert h2 == h1

# Generated at 2022-06-21 08:31:54.370523
# Unit test for function md5
def test_md5():
    md5_random = md5(os.path.join(os.path.dirname(__file__), 'hashes', 'random'))
    assert len(md5_random) == 32
    assert md5_random == 'f1c5f7d12e5d5b5f5d3243c3a9f927f5'
    md5_empty = md5(os.path.join(os.path.dirname(__file__), 'hashes', 'empty'))
    assert len(md5_empty) == 32
    assert md5_empty == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('not_exists') == None


# Generated at 2022-06-21 08:31:59.057547
# Unit test for function md5
def test_md5():
    if not _md5:
        print('MD5 not available.  Possibly running in FIPS mode')
        return

    import doctest
    failures, tests = doctest.testmod(md5)
    if failures:
        print('*** %d failures in %d tests' % (failures, tests))

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-21 08:32:01.187856
# Unit test for function md5s
def test_md5s():
    data = "\x00" * 10
    assert md5s(data) == "c4ca4238a0b923820dcc509a6f75849b"

# Generated at 2022-06-21 08:32:10.620834
# Unit test for function md5s
def test_md5s():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.urls import open_url

    try:
        import hashlib
        hashlib.md5()
    except ImportError:
        return

    module = AnsibleModule(argument_spec={
        'path': {'required': True, 'type': 'str'}
    })

    # if the md5sum is not installed, we should get an error
    if module.get_bin_path('md5sum') is None:
        module.fail_json(msg="Unable to locate md5sum, it is required")

    # if we have the md5sum tool, we should get the same checksum that we have
    # in our code