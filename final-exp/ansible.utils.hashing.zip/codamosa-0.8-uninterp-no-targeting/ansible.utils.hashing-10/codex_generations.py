

# Generated at 2022-06-21 08:22:18.043845
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('Hello World') == '0a4d55a8d778e5022fab701977c5d840bbc486d0'
    assert checksum_s(u'Hello World') == '0a4d55a8d778e5022fab701977c5d840bbc486d0'
    assert checksum_s(b'Hello World') == '0a4d55a8d778e5022fab701977c5d840bbc486d0'

# Generated at 2022-06-21 08:22:28.653640
# Unit test for function md5s
def test_md5s():
    assert md5s('dummy') == md5s(to_bytes('dummy', errors='surrogate_or_strict'))  # No error on lazy b_or_s
    assert md5s(b'dummy') == md5s('dummy')  # No error on data vs str
    assert md5s('dummy') == '3b3181d9e1c7f1ed61e0b02d13d8acd7'
    assert md5s('dummy', encoding='UTF-8') == '3b3181d9e1c7f1ed61e0b02d13d8acd7'

# Generated at 2022-06-21 08:22:33.128053
# Unit test for function md5
def test_md5():
    '''
    function: md5
    date: 2014-11-06
    objective: verify md5 function
    input: any
    output: MD5 hash
    '''

    #expected = 'c4d59fb04c9ed64bf826f0068e2c3d3e'
    expected = 'd41d8cd98f00b204e9800998ecf8427e'
    returned = md5s("")
    assert returned == expected



# Generated at 2022-06-21 08:22:38.697465
# Unit test for function md5
def test_md5():
    if not _md5:
        return True
    test_str = 'hashlib.md5().hexdigest() test'
    test_hash = md5(None)
    if test_hash:
        return False
    test_hash = md5s(test_str)
    if len(test_hash) != 32:
        return False
    return True

# Generated at 2022-06-21 08:22:46.766906
# Unit test for function md5s
def test_md5s():
    # input
    data="Hello,World!"
    data_wrong="Hello,World!_wrong"
    # expect
    hexdigest_expect="65a8e27d8879283831b664bd8b7f0ad4"
    # actual
    hexdigest_actual = md5s(data)
    # check
    assert(hexdigest_actual==hexdigest_expect)
    assert(hexdigest_actual!=md5s(data_wrong))


# Generated at 2022-06-21 08:22:57.984668
# Unit test for function checksum_s
def test_checksum_s():
    ''' ansible.utils.checksum_s unit test '''

    # Test the checksum_s function when it is called without parameters
    checksum_sha1 = checksum_s()
    assert checksum_sha1 == 'da39a3ee5e6b4b0d3255bfef95601890afd80709', \
           "ansible.utils.checksum_s expected 'da39a3ee5e6b4b0d3255bfef95601890afd80709' got %s" % checksum_sha1

    # Test the checksum_s function when it is called with parameters
    checksum_sha1 = checksum_s('This is a string')

# Generated at 2022-06-21 08:23:04.101926
# Unit test for function checksum
def test_checksum():
    filename = os.path.join(os.path.dirname(__file__), '../../docs/modules/ping.py')
    assert checksum(filename) == '954c0ceec770b7ca8e4a4fce0232f6fa'
    assert md5(filename) == '954c0ceec770b7ca8e4a4fce0232f6fa'



# Generated at 2022-06-21 08:23:11.094293
# Unit test for function md5
def test_md5():
    from os import remove,rename
    from tempfile import mkstemp
    (fd,fn) = mkstemp()
    os.write(fd,b'qwerty')
    os.close(fd)
    assert md5(fn) == '841cf4e53a28a7572e18353820b129a2'
    assert md5s('qwerty') == '841cf4e53a28a7572e18353820b129a2'
    rename(fn,fn+'.bak')
    assert md5(fn) == None
    remove(fn+'.bak')

# Generated at 2022-06-21 08:23:17.814312
# Unit test for function checksum_s
def test_checksum_s():
    data = 'this is a string'
    digest = secure_hash_s(data)
    assert(digest == '0d0b595031cdfcee5a78c85e51b9e9cac9c90b0e')

    md5digest = md5s(data)
    assert(md5digest == '49f68a5c8493ec2c0bf489821c21fc3b')

# Generated at 2022-06-21 08:23:29.710372
# Unit test for function checksum_s
def test_checksum_s():

    # Tests without data
    try:
        # Missing argument
        secure_hash_s()
    except TypeError:
        pass
    else:
        raise AssertionError("Missing argument should raise TypeError")

    try:
        # String is ok
        secure_hash_s("hello")
    except TypeError:
        raise AssertionError("String argument should not raise TypeError")

    # No algorithm not accepted
    try:
        secure_hash_s("hello", "sha1")
    except TypeError:
        pass
    else:
        raise AssertionError("No algorithm should raise TypeError")

    # Other types of data not accepted
    try:
        secure_hash_s(u"hello")
    except TypeError:
        pass

# Generated at 2022-06-21 08:23:37.465556
# Unit test for function md5s
def test_md5s():
    h1 = "7d865e959b2466918c9863afca942d0fb89d7c9ac0c99bafc3749504ded97730"
    h2 = md5s("foo")
    assert h1 == h2



# Generated at 2022-06-21 08:23:42.168360
# Unit test for function md5s
def test_md5s():
    b = 'this is a test'
    md5 = md5s(b)
    # noinspection PyUnresolvedReferences
    assert(md5 == 'f62895d062ef8b0c9bbe4495b9aa8e64')



# Generated at 2022-06-21 08:23:50.060657
# Unit test for function checksum
def test_checksum():
    '''
    test_checksum: Refactored from ansible.runner.checksum
    '''
    import tempfile
    test_file = tempfile.NamedTemporaryFile()
    test_file.write(b"foobar")
    test_file.flush()
    test_file_sha1sum = checksum(test_file.name)
    if not test_file_sha1sum:
        raise ValueError("test_checksum: checksum failed")
    test_file.close()
    return test_file_sha1sum

# Generated at 2022-06-21 08:23:58.403692
# Unit test for function md5
def test_md5():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.compat.tests import unittest
    import os

    class TestChecksum(unittest.TestCase):

        TEST_DATA_FILE = os.path.join(os.path.dirname(__file__), 'test_data', 'checksum_test.txt')

        def test_md5s(self):
            sample = 'hello world'
            self.assertEqual(md5s(sample), '5eb63bbbe01eeed093cb22bb8f5acdc3')
            self.assertEqual(md5s(AnsibleUnsafeText(sample)), '5eb63bbbe01eeed093cb22bb8f5acdc3')


# Generated at 2022-06-21 08:24:02.975839
# Unit test for function md5
def test_md5():
    assert md5('/etc/hosts') is not None


if __name__ == '__main__':
    print(checksum('setup.py'))
    print(checksum('/bin/ls'))
    print(checksum_s('booya'))

# Generated at 2022-06-21 08:24:08.161062
# Unit test for function checksum_s
def test_checksum_s():
    ''' test checksum_s function '''

    sample_str = 'hello'

    # default is sha1
    digest = 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s(sample_str) == digest



# Generated at 2022-06-21 08:24:10.280417
# Unit test for function md5s
def test_md5s():
    data = 'hello'
    assert md5s(data) == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-21 08:24:19.487758
# Unit test for function checksum_s
def test_checksum_s():
    # Should return identical checksums for identical strings
    assert checksum_s("foo") == checksum_s("foo"), "Failed to return identical checksums for identical strings"

    # Should return different checksums for different strings
    assert checksum_s("foo") != checksum_s("bar"), "Failed to return different checksums for different strings"

    # Should return identical checksums for equivalent unicode strings
    assert checksum_s("føø") == checksum_s("føø"), "Failed to return identical checksums for equivalent unicode strings"

    # Should return different checksums for different unicode strings
    assert checksum_s("føø") != checksum_s("bøø"), "Failed to return different checksums for different unicode strings"



# Generated at 2022-06-21 08:24:24.198659
# Unit test for function md5s
def test_md5s():
    # If md5s is available then the md5 object should be available too
    assert _md5 is not None, 'MD5 not available. Possibly running in FIPS mode'
    # The md5s of 'foo' should be the same as the md5 of 'foo'
    assert md5s('foo') == md5('foo')


# Generated at 2022-06-21 08:24:28.516078
# Unit test for function md5
def test_md5():
    file = os.path.join(os.path.dirname(__file__), 'vars', 'main.yml')
    assert md5(file) == 'b28a8c12d49fc1fce2ec037e9f8e3f3b'

# Generated at 2022-06-21 08:24:35.934737
# Unit test for function checksum_s
def test_checksum_s():
    data = 'hello world'
    assert checksum_s(data) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

if __name__ == '__main__':
    # Run unit tests
    test_checksum_s()

# Generated at 2022-06-21 08:24:42.317861
# Unit test for function checksum
def test_checksum():
    assert checksum_s('dummy') == '0a4d55a8d778e5022fab701977c5d840bbc486d0'
    assert checksum('/etc/ansible/ansible.cfg') == '1d51f91c8e6e0c6e7d70445d355741f838f3b6de'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:24:44.297971
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("foo") == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-21 08:24:46.844463
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'c215b6fadc6ef14e622d2b2c3df196f6e5913b7d'


# Generated at 2022-06-21 08:24:56.416170
# Unit test for function md5
def test_md5():
    # create test file
    tf = __file__ + '_' + str(os.getpid())
    tfh = open(tf, 'w')
    tfh.write("hello world\n")
    tfh.close()

    # calculate md5sum of file
    fh = open(tf)
    m = _md5()
    blocksize = 64 * 1024
    block = fh.read(blocksize)
    while block:
        m.update(block)
        block = fh.read(blocksize)
    fh.close()

    # remove test file
    os.unlink(tf)

    # return md5
    return m.hexdigest()

# Generated at 2022-06-21 08:25:06.504993
# Unit test for function md5
def test_md5():
    ''' md5 should match md5sum output '''
    # NOTE (peterjs): This should be generalized/moved to test/utils/module_utils/hash_utils/__init__.py
    original_md5 = None
    # Ensure we are not running in FIPS mode
    global _md5
    _md5 = None
    try:
        from hashlib import md5 as _md5
    except ImportError:
        pass

# Generated at 2022-06-21 08:25:16.516034
# Unit test for function md5
def test_md5():
    test_str = "Hello world"
    test_file_name = "test_file"

    assert(md5s(test_str) == "5eb63bbbe01eeed093cb22bb8f5acdc3")
    f = open(test_file_name, "w")
    f.write(test_str)
    f.close()
    assert(md5(test_file_name) == "5eb63bbbe01eeed093cb22bb8f5acdc3")
    os.remove(test_file_name)
    return True


if __name__ == "__main__":
    import sys
    import doctest
    if doctest.testmod(sys.modules[__name__])[0] == 0:
        test_md5()

# Generated at 2022-06-21 08:25:19.667443
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return
    assert md5s('blah') == '7f895d1efd7e064613f29fcf4c8f14b4'

# Generated at 2022-06-21 08:25:25.973644
# Unit test for function md5
def test_md5():
    # Ensure that md5 returns the same results for both python2 and python3
    # Test against the string "This is a test of the md5 function".
    # Test that md5 returns None for a file that does not exist
    # Test that md5 returns None for a directory
    # Test that md5 does not exist in FIPS mode

    from tempfile import NamedTemporaryFile
    from ansible.module_utils._text import to_bytes, to_native
    import os

    try:
        from hashlib import md5 as _md5
    except ImportError:
        try:
            from md5 import md5 as _md5
        except ImportError:
            # Assume we're running in FIPS mode here
            _md5_available = False
        else:
            _md5_available = True
    else:
        _md5_

# Generated at 2022-06-21 08:25:32.005923
# Unit test for function md5
def test_md5():
    from ansible.module_utils.basic import AnsibleModule
    test_str = 'asdfasdf'
    md5sum = md5s(test_str)
    module = AnsibleModule(argument_spec = dict())
    module.exit_json(changed = False, md5sum = md5sum)


# Generated at 2022-06-21 08:25:37.155494
# Unit test for function md5
def test_md5():
    return md5('library/crypto_utils.py') == 'e15068a57df53272ce0dc8ecd64f320d'


# Generated at 2022-06-21 08:25:48.179525
# Unit test for function md5
def test_md5():
    '''
    This function tests the md5 function, by providing a known md5 checksum,
    running md5 on a string, and verifying that they match.
    '''
    from ansible.compat.tests import unittest
    import tempfile

    class TestMd5(unittest.TestCase):
        @classmethod
        def setUpClass(self):
            self.test_string = 'This is a test string'
            self.test_string_md5 = 'f7ff9e8b7bb2e09b70935a5d785e0cc5'

        def test_typeerror(self):
            self.assertRaises(TypeError, md5, 123)

        def test_md5(self):
            temp_dir = tempfile.mkdtemp()
            temp_file = tempfile.mk

# Generated at 2022-06-21 08:25:54.448353
# Unit test for function checksum
def test_checksum():
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('testing\n') == '98f13708210194c475687be6106a3b84239d3e79'
    assert checksum('/etc/resolv.conf') == '6b5db5f5fc70d2c6425eb8b47e3de32d'

# Generated at 2022-06-21 08:25:58.771814
# Unit test for function md5
def test_md5():
    if _md5:
        # Just do a basic test
        assert md5('setup.py') == '54d8a3366f347dbb0a590a8a0a925d29'


# Generated at 2022-06-21 08:26:08.721948
# Unit test for function md5
def test_md5():
    if _md5:
        assert md5('/etc/passwd') == '3e241f4a8b1fa079b47e26dd9d7d8c00'
        assert md5('/etc/nosuchfile') is None
        assert md5('/dev/null') is None
        assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    else:
        assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
        try:
            md5('/etc/passwd')
            assert False
        except ValueError as e:
            assert str(e) == 'MD5 not available.  Possibly running in FIPS mode'

#
# Backwards compat functions.  Some modules

# Generated at 2022-06-21 08:26:13.607628
# Unit test for function md5s
def test_md5s():
    ''' md5s() should calculate md5 digest of a string '''
    expected = '1f3870be274f6c49b3e31a0c6728957f'
    observed = md5s('foo')
    assert observed == expected, 'Got %s instead of %s' % (observed, expected)


# Generated at 2022-06-21 08:26:20.645587
# Unit test for function md5s
def test_md5s():
    from io import StringIO
    from tempfile import NamedTemporaryFile
    from shutil import copyfileobj

    # Test md5s with given data
    data = b'hello world'
    hash_func = md5s(data)
    assert hash_func == '5eb63bbbe01eeed093cb22bb8f5acdc3'

    # Test md5s with file
    tmpfile = NamedTemporaryFile()
    # Ansible checksum is currently broken for empty StringIO
    copyfileobj(StringIO(data), tmpfile)
    tmpfile.flush()
    hash_func = md5(tmpfile.name)
    assert hash_func == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    tmpfile.close()

# Generated at 2022-06-21 08:26:24.494060
# Unit test for function checksum_s
def test_checksum_s():
    data = "this is a file"
    checksum = checksum_s(data)
    assert checksum == 'e69d1f741a6252aa33d7adb6eee41427d9f9aae4'

# Generated at 2022-06-21 08:26:27.705847
# Unit test for function checksum_s
def test_checksum_s():
    ''' test checksum_s '''

    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-21 08:26:37.368011
# Unit test for function md5
def test_md5():
    '''Unit test for function md5.

    if this function is named 'test', it may be called by nose.
    '''
    test_file = '/tmp/test_md5'
    test_string = 'THIS IS A UNIT TEST'

    # Test encryption/decryption of a string
    assert md5s(test_string) == '8d8cef19b99859e175f5f5d5cd5e5641'

    # Test encryption/decryption of a file
    with open(test_file, 'w') as f:
        f.write(test_string)
    assert md5(test_file) == '8d8cef19b99859e175f5f5d5cd5e5641'
    import os
    os.unlink(test_file)

# Generated at 2022-06-21 08:26:43.880209
# Unit test for function md5
def test_md5():
    """ Test function md5()
    """
    filename = 'sha1.py'
    assert md5(filename) == '67a6bffa6c2329b8e7f1ed43e3bd7c2d'


# Generated at 2022-06-21 08:26:52.627736
# Unit test for function checksum
def test_checksum():
    '''
    unit test function
    '''

    filename = 'changeme_file'
    content = 'this is some test content'
    f = open(filename, 'wt')
    f.write(content)
    f.close()
    expected = 'cbaa6ed0695a6a2c6f4041c38179be6a9d6e1e74'
    if checksum(filename) != expected:
        raise Exception('checksum(filename) returned a different value than expected: %s' % checksum(filename))
    os.remove(filename)

# Generated at 2022-06-21 08:27:02.780093
# Unit test for function checksum
def test_checksum():

    import sys
    import time

    filepath = os.path.join(os.path.dirname(__file__), '../../test/support/test-module.sh')
    test_cases = [
        'c1a15b3f3b3c45bc37e14eafbc8ae741e2bdf1f7',
        'c1a15b3f3b3c45bc37e14eafbc8ae741e2bdf1f7',
        'c1a15b3f3b3c45bc37e14eafbc8ae741e2bdf1f7',
        'c1a15b3f3b3c45bc37e14eafbc8ae741e2bdf1f7',
    ]


# Generated at 2022-06-21 08:27:08.264377
# Unit test for function checksum_s
def test_checksum_s():
    ''' test_checksum_s should return the same result for a given string '''
    test_string = 'test_checksum_s'

    sample_sha1 = 'b04aafba385a153ac7dd1ab0fcebdc5661823c2e'

    assert checksum_s(test_string) == sample_sha1
    assert md5s(test_string) == 'd94f3f016ae679c3008de268209132f2'

    return 'ok'

# Generated at 2022-06-21 08:27:20.032385
# Unit test for function md5
def test_md5():
    ''' test_md5 '''
    from ansible.module_utils._text import to_bytes
    from ansible.utils import md5s
    data = "ansible"
    hashed = md5s(data)
    assert hashed == "e8fd159fca6ebab3cbb9e4d8ec4a4a4e"
    data = "ansible ansible ansible"
    hashed = md5s(data)
    assert hashed == "6c4584a2d0df81714a53a40aecbf1e2a"
    data = ""
    hashed = md5s(data)
    assert hashed == "d41d8cd98f00b204e9800998ecf8427e"
    filename = "/etc/passwd"
    hashed = md

# Generated at 2022-06-21 08:27:25.387779
# Unit test for function md5
def test_md5():
    ''' unit test for md5 function '''

    assert(md5s('hello') == '5d41402abc4b2a76b9719d911017c592')

    assert(md5('/dev/null') == 'd41d8cd98f00b204e9800998ecf8427e')


# Unit test
if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-21 08:27:28.999152
# Unit test for function checksum
def test_checksum():
    assert checksum_s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert checksum_s('foo') == secure_hash_s('foo')

# Generated at 2022-06-21 08:27:37.992268
# Unit test for function checksum_s
def test_checksum_s():
    '''
    Test checksum_s function with inputs:
    'input_data': 'foobar', hash_algorithm: sha1
    '''
    # set input data
    input_data = 'foobar'
    # get checksum
    # use of globals() to take the reference of function
    checksum = globals()['checksum_s']
    (rc, stdout, stderr) = checksum(input_data)
    assert rc == '8843d7f92416211de9ebb963ff4ce28125932878', 'test failure'



# Generated at 2022-06-21 08:27:46.666385
# Unit test for function md5s
def test_md5s():
    test_data = [
        {'data': 'abc', 'expected': '900150983cd24fb0d6963f7d28e17f72'},
        {'data': '12345678901234567890123456789012345678901234567890123456789012345678901234567890',
         'expected': '57edf4a22be3c955ac49da2e2107b67a'},
    ]
    for data_test in test_data:
        if md5s(data_test['data']) != data_test['expected']:
            raise Exception("md5s() failed to generate correct result.")


# Generated at 2022-06-21 08:27:52.179544
# Unit test for function checksum
def test_checksum():
    """
    file to checksum
    """

    testfile = open(__file__)
    testfile.close()

    # test that the function runs and checksums the local file
    chksum = checksum(__file__)
    if not chksum:
        raise ValueError('Could not checksum local file with checksum function')

test_checksum()

# Generated at 2022-06-21 08:27:59.371639
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-21 08:28:03.176198
# Unit test for function md5
def test_md5():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-21 08:28:06.678248
# Unit test for function md5s
def test_md5s():
    test_value = b"1234567890"
    assert md5s(test_value) == 'e807f1fcf82d132f9bb018ca6738a19f'


# Generated at 2022-06-21 08:28:09.324348
# Unit test for function checksum_s
def test_checksum_s():
    correct = sha1()
    correct.update(b'hello')
    correct_result = correct.hexdigest()
    assert correct_result == checksum_s('hello'), 'Unexpected checksum result.'

# Generated at 2022-06-21 08:28:12.868651
# Unit test for function checksum_s
def test_checksum_s():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.modules.system import stat as stat_module

    # Create a mock class to avoid calling the original checksum_s function.
    class StatModule(stat_module.Stat):
        def checksum(self, filename):
            raise NotImplementedError()

    with patch.object(stat_module.Stat, 'checksum', side_effect=lambda f: f):
        stat = StatModule(load_args=stat_module.StatArgs({}))
        res = stat._checksum_s('hello')
    assert res == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed', 'sha1 hash failed'



# Generated at 2022-06-21 08:28:20.375187
# Unit test for function md5
def test_md5():
    final_result = "d41d8cd98f00b204e9800998ecf8427e"
    hex_digest = md5('')
    print('the final_result is: %s\n' % final_result)
    print('the hex_digest is: %s\n' % hex_digest)
    assert hex_digest == final_result

if __name__ == "__main__":
    test_md5()

# Generated at 2022-06-21 08:28:24.229530
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(b'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-21 08:28:26.568422
# Unit test for function md5s
def test_md5s():
    assert md5s("foobar") == '3858f62230ac3c915f300c664312c63f'


# Generated at 2022-06-21 08:28:31.073883
# Unit test for function checksum
def test_checksum():
    ''' test_checksum: test checksum function '''

    assert checksum("foo") is None
    assert checksum("/etc/hosts") == "6a2e6c78fe9f919bab824b091811c1b1b07d20ae"
    assert checksum("/dne") is None


# Generated at 2022-06-21 08:28:35.632570
# Unit test for function md5
def test_md5():
    test_file_name = "/tmp/ansible_test_md5"
    test_file = open(test_file_name, 'w')
    test_file.write("abcdefghijklmnopqrstuvwxyz\n")
    test_file.close()
    assert md5(test_file_name) == "c3fcd3d76192e4007dfb496cca67e13b"
    os.remove(test_file_name)



# Generated at 2022-06-21 08:28:47.051805
# Unit test for function md5s
def test_md5s():
    ''' md5s should return the same string for strings and unicode '''
    s = 'a string'
    u = u'a string'
    assert( md5s(s) == md5s(u) )


# Generated at 2022-06-21 08:28:52.048963
# Unit test for function md5
def test_md5():
    '''
    Run the function 'md5' and check that it returns the hash of a file
    '''

    return check_md5('test/files/test.cfg', 'ec68a6c1bcf97e34f7b373eae64c6b89')



# Generated at 2022-06-21 08:28:54.139422
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-21 08:28:57.336296
# Unit test for function checksum_s
def test_checksum_s():
    checksum = checksum_s("hello world")
    assert checksum == "5eb63bbbe01eeed093cb22bb8f5acdc3"


# Generated at 2022-06-21 08:29:04.250552
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/passwd') == checksum('/etc/passwd')
    assert checksum('/etc/passwd') != checksum('/etc/hosts')
    assert checksum('/etc/passwd') != checksum_s('/etc/passwd')
    assert checksum('/etc/passwd') != secure_hash('/etc/passwd', _md5)
    assert checksum('/etc/passwd') != md5('/etc/passwd')


# Generated at 2022-06-21 08:29:09.919808
# Unit test for function checksum
def test_checksum():
    chunk = 'abc'
    assert (checksum_s(chunk) == 'a9993e364706816aba3e25717850c26c9cd0d89d')
    assert (checksum_s(chunk, hash_func=_md5) == '900150983cd24fb0d6963f7d28e17f72')

# Generated at 2022-06-21 08:29:20.705173
# Unit test for function md5s
def test_md5s():
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789') == 'd174ab98d277d9f5a5611c2c9f419d9f'
    assert md5s('12345678901234567890123456789012345678901234567890123456789012345678901234567890') == '57edf4a22be3c955ac49da2e2107b67a'


# Generated at 2022-06-21 08:29:29.658148
# Unit test for function checksum
def test_checksum():
    test_file = "test/support/test.txt"
    test_file_sha1 = "f38e1f8c826e19208551059ae29ec9c5dc7a38b5"
    test_file_sha256 = "7e8f2d4b9f4b4d9044ccd1008e4a80a7fd84fdc5b7e5d5688e9f9a653a4558f7"

# Generated at 2022-06-21 08:29:32.154600
# Unit test for function md5s
def test_md5s():
    data = "Hello World!"
    result = md5s(data)
    assert result == "b10a8db164e0754105b7a99be72e3fe5"

# Generated at 2022-06-21 08:29:34.047352
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-21 08:29:46.863669
# Unit test for function checksum_s
def test_checksum_s():
    ''' test the function checksum_s'''
    from ansible.module_utils import basic

    print('Testing checksum_s function')
    data = 'test data'
    hash_val = '9a0364b9e99bb480dd25e1f0284c8555'
    if checksum_s(data) == hash_val:
        basic.exiter('checksum_s returned expected value')
    else:
        basic.exiter('checksum_s returned wrong hash value')

# Generated at 2022-06-21 08:29:50.022779
# Unit test for function checksum
def test_checksum():
    assert checksum_s("foo") == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    assert checksum("test/resources/checksum/file1") == "8d777f385d3dfec8815d20f7496026dc"

# Generated at 2022-06-21 08:29:59.528533
# Unit test for function checksum_s
def test_checksum_s():
    s = "kitten"
    assert (checksum_s(s) == '06df1d1cd755e01d7cec6ad884dffd9c93f21520'), "checksum_s() returned wrong hash"
    # FIPS: md5 not available
    try:
        assert (md5s(s) == 'd6b0e6c2e6cf1ca2eccd47ef0f9d5f5b'), "md5s() returned wrong hash"
    except ValueError:
        assert True, "md5s() failed as expected"

# Generated at 2022-06-21 08:30:07.451308
# Unit test for function checksum_s
def test_checksum_s():
    # check if the function returns the correct hash
    if secure_hash_s("hello") != "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d":
        # test failed
        print("Test 1: failure")
    else:
        # test passed
        print("Test 1: success")

    # check if the function can handle null strings
    if secure_hash_s("") is not None:
        # test failed
        print("Test 2: failure")
    else:
        # test passed
        print("Test 2: success")


# Generated at 2022-06-21 08:30:16.393175
# Unit test for function checksum
def test_checksum():

    file = '/tmp/checksum_test_file'
    # Create a test file with some data
    with open(file, 'w') as f:
        f.write('1.2.3.4')

    # Calculate checksum of the file
    checksum_ret = checksum(file)
    checksum_ret_md5 = md5(file)

    # Calculate checksum of the string '1.2.3.4'
    checksum_ret_string = checksum_s('1.2.3.4')

    assert checksum_ret_string == checksum_ret
    assert checksum_ret_md5 == '3d6b7c6a9086b7c6d8e2a24f6a0dc2b7'

    os.remove(file)



# Generated at 2022-06-21 08:30:27.782135
# Unit test for function md5s
def test_md5s():
    from ansible.module_utils import basic
    import sys
    import os

# Generated at 2022-06-21 08:30:33.239759
# Unit test for function md5s
def test_md5s():
    s = 'hello world'
    s_md5 = md5s(s)
    assert s_md5 == "5eb63bbbe01eeed093cb22bb8f5acdc3", "md5s('hello world') != 5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s(s) == md5s(s)


# Generated at 2022-06-21 08:30:41.320026
# Unit test for function checksum
def test_checksum():
    assert secure_hash_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert secure_hash('/dev/null') == 'cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce' # expect cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce
    assert secure_hash('/bin/sh') == '3fdfafd147d8c1e23b1c5e745908e38540ce4279' # expect 3fdfafd147d8c1e23b1c5e745908e38540ce4

# Generated at 2022-06-21 08:30:50.252635
# Unit test for function checksum
def test_checksum():
    content = b'Hello World'
    assert checksum_s(content) == '0a4d55a8d778e5022fab701977c5d840bbc486d0'
    assert checksum_s(b'') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s(content, hash_func=_md5) == 'ed076287532e86365e841e92bfc50d8c'

# Generated at 2022-06-21 08:30:57.488767
# Unit test for function checksum_s
def test_checksum_s():
    md5s = checksum_s('stuff', 'md5')
    sha1s = checksum_s('stuff', 'sha1')
    assert md5s == '6f8db599de986fab7a21625b7916589c'
    assert sha1s == '185f8db32271fe25f561a6fc938b2e264306ec304eda518007d1764826381969'

    # check backwards compat
    assert md5s == secure_hash_s('stuff', 'md5')
    assert sha1s == secure_hash_s('stuff', 'sha1')

# Generated at 2022-06-21 08:31:11.618533
# Unit test for function checksum
def test_checksum():
    filename = 'checksum.py'
    assert checksum(filename) == '74b87337454200d320ea65aa9e3e44b6fb922e3f'
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'


if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1:
        print(checksum(sys.argv[1]))
    else:
        test_checksum()

# Generated at 2022-06-21 08:31:15.040291
# Unit test for function md5s
def test_md5s():
    if _md5:
        test_str = "This is a test string"
        test_md5 = "d687a7d42c06b4607a4a4f4f4f4f4a4a"
        assert md5s(test_str) == test_md5

# Generated at 2022-06-21 08:31:19.103822
# Unit test for function checksum_s
def test_checksum_s():
    s = 'this is some text'
    hsh = sha1()
    hsh.update(to_bytes(s))
    hsh = hsh.hexdigest()
    assert secure_hash_s(s) == hsh

# Generated at 2022-06-21 08:31:30.547092
# Unit test for function checksum
def test_checksum():

    # Tests for secure_hash_s
    assert secure_hash_s("tests") == "cf80cd8aed482d5d1527d7dc72fceff84e6326592848447d2dc0b0e87dfc9a90"
    assert secure_hash_s("abcdefghijklmnopqrstuvwxyz") == "32d10c7b8cf96570ca04ce37f2a19d84240d3a89"
    assert secure_hash_s("") == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"

    # Tests for secure_hash

# Generated at 2022-06-21 08:31:40.551257
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock
    from ansible.module_utils.six.moves import StringIO

    class TestChecksum(unittest.TestCase):

        @patch('os.path.exists')
        def test_checksum_file_exists(self, os_path_exists_mock):
            os_path_exists_mock.return_value = True
            m = Mock()
            m.hexdigest.return_value = "1234567890"
            with patch('ansible.module_utils.basic._load_backend', Mock()) as _load_backend_mock:
                _load_backend_mock.sha1.return_value = m

# Generated at 2022-06-21 08:31:43.054035
# Unit test for function checksum_s
def test_checksum_s():
    data = 'Hello World!'

    test_sha1 = checksum_s(data)
    assert test_sha1 == '0a4d55a8d778e5022fab701977c5d840bbc486d0'

    return True

# Generated at 2022-06-21 08:31:50.070976
# Unit test for function md5
def test_md5():
    import tempfile
    try:
        fd, dummy = tempfile.mkstemp(text=True)
        _file = os.fdopen(fd, 'w')
        _file.write("#!/usr/bin/python\nprint 'hello'\n")
        _file.close()
        assert md5(dummy) == '3e25960a79dbc69b674cd4ec67a72c62'
    finally:
        os.remove(dummy)

# Generated at 2022-06-21 08:32:00.819096
# Unit test for function checksum_s
def test_checksum_s():

    result = checksum_s('hello world')
    if result != '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed':
        raise AssertionError()

    result = checksum_s(u'hello world')
    if result != '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed':
        raise AssertionError()

    result = checksum_s('hello world', sha1)
    if result != '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed':
        raise AssertionError()

    result = checksum_s(u'hello world', sha1)