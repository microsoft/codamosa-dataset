

# Generated at 2022-06-21 08:22:09.837736
# Unit test for function md5s
def test_md5s():
    test_data = 'This is the data to hash.'

    hashed_data = md5s(test_data)

    if hashed_data != '5d41d8cd98f00b204e9800998ecf8427e':
        raise ValueError('Error when hashing data: ' + test_data)
    else:
        print('test_md5s passed')



# Generated at 2022-06-21 08:22:22.154407
# Unit test for function checksum
def test_checksum():
    # Create a temporary file, write some data to it, then get a checksum
    with open("check_sum_test_file", "w") as f:
        f.write("Ansible test data")
    test_sha1 = checksum("check_sum_test_file")
    os.remove("check_sum_test_file")
    assert test_sha1 == "6f77a5d5cc7f1ceb9a9dd6e65b35a34d6fbd207b"

    # Test the string checksum with the same data
    test_sha1_s = checksum_s("Ansible test data")
    assert test_sha1_s == "6f77a5d5cc7f1ceb9a9dd6e65b35a34d6fbd207b"

# Generated at 2022-06-21 08:22:25.127845
# Unit test for function md5s
def test_md5s():
    ''' md5s should return correct md5sum of data '''
    assert(md5s("abcdefg") == "7ac66c0f148de9519b8bd264312c4d64")



# Generated at 2022-06-21 08:22:31.261804
# Unit test for function checksum
def test_checksum():
    def check(data, expected):
        digest = checksum_s(data)
        assert digest == expected

    check("Hello World", "7b502c3a1f48c8609ae212cdfb639dee39673f5e")

    # This is a value from RFC 2202
    check("what do ya want for nothing?", "750c783e6ab0b503eaa86e310a5db738")

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:22:43.017560
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s("foo") != "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33":
        raise AssertionError('sha1 hash of "foo" is not correct')
    if checksum_s(u"foo") != "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33":
        raise AssertionError('sha1 hash of "foo" is not correct')
    if checksum_s(b"foo") != "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33":
        raise AssertionError('sha1 hash of "foo" is not correct')

# Generated at 2022-06-21 08:22:52.062735
# Unit test for function md5
def test_md5():
    import tempfile

    (infile, infile_name) = tempfile.mkstemp()
    fd = os.fdopen(infile, "w")
    fd.write(b"hello world")
    fd.close()
    digest = md5(infile_name)
    os.unlink(infile_name)
    print(digest)
    assert digest == b'5eb63bbbe01eeed093cb22bb8f5acdc3'

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-21 08:22:55.427426
# Unit test for function md5
def test_md5():
    m = md5("test_utils.py")
    assert m == 'b75a9b2c2d8a03338433e24f1672607e'


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-21 08:23:06.376316
# Unit test for function checksum
def test_checksum():
    # test default checksum function
    assert checksum("/etc/passwd") == "31b8f19af948238c3e3b83bceec8afc5d5f5c5d4"
    assert checksum("/bogus/file/that/does/not/exist") is None
    assert checksum("/") is None

    # test checksum with sha1
    assert checksum("/etc/passwd", hash_func=sha1) == "31b8f19af948238c3e3b83bceec8afc5d5f5c5d4"

    # test checksum_s with sha1

# Generated at 2022-06-21 08:23:10.418595
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("Hello") == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'
    assert checksum_s("Hello",hash_func=md5) == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-21 08:23:13.241654
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('test.txt') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'

# Generated at 2022-06-21 08:23:23.321897
# Unit test for function md5
def test_md5():
    ''' md5 unit tests'''

    assert md5('lib/ansible/module_utils/basic.py') == 'ad60f7ebc04e5f7b5c8d5d5cf5c5a5a5'
    assert md5s('lib/ansible/module_utils/basic.py') == 'ad60f7ebc04e5f7b5c8d5d5cf5c5a5a5'



# Generated at 2022-06-21 08:23:27.512186
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', _md5) == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-21 08:23:31.512052
# Unit test for function checksum
def test_checksum():
    assert checksum("a") == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"

#

# Generated at 2022-06-21 08:23:41.647411
# Unit test for function md5
def test_md5():
    # Create a file with a known md5 checksum
    import tempfile
    from shutil import rmtree

    try:
        # Create a temporary directory
        tmpdir = tempfile.mkdtemp()
        # Create a file with a known md5 checksum
        testfile = os.path.join(tmpdir, "testfile")
        h = open(testfile, "wb")
        h.write("foobar")
        h.close()
        # Assert if the md5 check fails
        assert md5(testfile) == '3858f62230ac3c915f300c664312c63f'
    finally:
        # Cleanup the temporary directory
        rmtree(tmpdir)

# Generated at 2022-06-21 08:23:45.045093
# Unit test for function md5s
def test_md5s():
    test_data = 'A test string'
    val = md5s(test_data)
    assert val == 'd8e8fca2dc0f896fd7cb4cb0031ba249'


# Generated at 2022-06-21 08:23:48.718010
# Unit test for function checksum_s
def test_checksum_s():
    test_data = b"test.test"
    assert checksum_s(test_data) == "d7d2c93b98ff7f1bf9f3d24cdb3c80dcba4848bf"

# Generated at 2022-06-21 08:23:51.569314
# Unit test for function checksum_s
def test_checksum_s():
    """Test Checksum of string"""
    assert checksum_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'

# Generated at 2022-06-21 08:23:53.120056
# Unit test for function md5
def test_md5():
    assert md5('/etc/group') == '44f42e14f06eb129e3668d6cea72bf46'


# Generated at 2022-06-21 08:23:55.173390
# Unit test for function checksum_s
def test_checksum_s():
    testHash = "e4c6b2451e8a0c95a9a0ee15e9d766cd93d991ea"
    assert checksum_s("some string") == testHash

# Generated at 2022-06-21 08:23:57.952440
# Unit test for function md5
def test_md5():
    'Note, this function is not a unit test.  It is used to compare results in a file.'
    import sys

    if len(sys.argv) >= 2:
        hash = md5(sys.argv[1])
        print(hash)



# Generated at 2022-06-21 08:24:11.559223
# Unit test for function checksum
def test_checksum():
    # pylint: disable=unused-import
    from ansible.utils.vars import combine_vars
    from ansible.parsing.vault import VaultLib

    data = 'hello world'
    expected_checksum = '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    checksum_value = checksum_s(data)
    assert expected_checksum == checksum_value
    assert md5s(data) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

    # Test fast mode
    # Create a vault encrypted temp file
    vault_password = 'ansible'

# Generated at 2022-06-21 08:24:17.849680
# Unit test for function checksum
def test_checksum():
    from . import random
    data = random.random_bytes(1024 * 1024)
    fn1 = "/tmp/ansible_test_data"
    s1 = secure_hash_s(data)
    with open(fn1, "wb") as f:
        f.write(data)
    s2 = checksum(fn1)
    os.unlink(fn1)
    assert s1 == s2

if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-21 08:24:24.792279
# Unit test for function md5s
def test_md5s():
    # make sure we raise on FIPS systems
    if not _md5:
        try:
            md5s('abc')
        except ValueError:
            pass # excepted
        else:
            raise AssertionError("md5s() did not raise ValueError on FIPS systems")

    # make sure our results match python's
    import hashlib
    h = hashlib.md5()
    h.update('abc')
    assert md5s('abc') == h.hexdigest()


# Generated at 2022-06-21 08:24:36.442961
# Unit test for function checksum
def test_checksum():
    """
    This is used only by module test_utils

    test_utils needs to import this file instead of module utils in order
    to work with py.test.

    This function is used only for unit test.
    """

    import tempfile

    def _make_file(message):
        (fd, path) = tempfile.mkstemp()
        f = os.fdopen(fd, 'w')
        f.write(message)
        f.close()
        return path

    # sha1 tests
    assert checksum(filename=_make_file('hello')) == '8b0a15eefe63fd41f8dc9dee01c5cf9ae33efcfa'
    assert checksum(filename=None) is None

# Generated at 2022-06-21 08:24:46.659406
# Unit test for function checksum_s
def test_checksum_s():

  from ansible.module_utils.basic import AnsibleModule
  data = b'test_checksum_s'
  # Test sha1
  expected = 'bef57ec7f53a6d40beb640a780a639c83bc29ac8a9816f1fc6c5c6dcd93c4721'
  result = checksum_s(data)
  assert result == expected, 'expected: %s, but returned: %s' % (expected, result)
  # Test sha1 (text)
  expected = 'bef57ec7f53a6d40beb640a780a639c83bc29ac8a9816f1fc6c5c6dcd93c4721'
  result = checksum_s(data.decode("utf-8"))

# Generated at 2022-06-21 08:24:51.542744
# Unit test for function md5s
def test_md5s():
    if _md5:
        expected = "9dd8b32e5b5a5c5d103ae198dd5f5aac"
        result = md5s("I am a cow, hear me moo, I weigh twice as much as you")
        assert expected == result


# Generated at 2022-06-21 08:25:01.712059
# Unit test for function checksum
def test_checksum():
    test_string = "I am not dead yet."
    test_sha1 = "2191d38f20ccd7c6e0cc3bdf9428b0b67c9c6f85"
    test_md5 = "7b0ea38e852d54e25e4cad9f9c4d4e5d"
    assert checksum_s(test_string) == test_sha1
    test_file_contents = b"I was not dead then.\nAnd I'm not dead now."
    test_file_name = 'test_checksum.txt'
    f = open(test_file_name, 'w')
    f.write(test_file_contents)
    f.close
    assert checksum(test_file_name) == test_sha1
    assert md5

# Generated at 2022-06-21 08:25:07.088072
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s('hello') != '5d41402abc4b2a76b9719d911017c592':
        raise AssertionError()

    # Try unicode characters that aren't in the ascii range.
    if checksum_s(u'\u2424') != '9e74fa4760d0f0d5f37a542d76b12fba5c2e0b1f':
        raise AssertionError()

# Generated at 2022-06-21 08:25:09.672772
# Unit test for function md5
def test_md5():
    test_data = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890"
    assert md5s(test_data) == "e6b3aeeb3da6e33d6c18693a1a85c113"


# Generated at 2022-06-21 08:25:19.217963
# Unit test for function md5s
def test_md5s():
    samples = [
        ('aabb', '9f9c9cb7befce79e84926d2851f6a19b'),
        ('This is a string with no meaning at all', '6e9ef6b13a6b0ef6cdbbb1f3a3fce3b2')
    ]

    for s, h in samples:
        assert h == md5s(s), "%s: %s != %s" % (s, h, md5s(s))


# Generated at 2022-06-21 08:25:30.807997
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest

    class TestChecksum(unittest.TestCase):

        def test_basic(self):
            self.assertEqual(
                checksum_s("hello world"),
                checksum("lib/ansible/module_utils/basic.py")
            )
            self.assertNotEqual(
                checksum("lib/ansible/module_utils/basic.py"),
                checksum("lib/ansible/module_utils/argspec.py")
            )

# Generated at 2022-06-21 08:25:39.853465
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s("hello world\n") == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s("hello world\r") == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s("hello world\n\r") == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s("hello world\n\r\n") == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-21 08:25:47.716835
# Unit test for function checksum
def test_checksum():
    file_with_data = 'test_file'
    f = open(file_with_data, 'w')
    f.write('hello world')
    f.close()

    assert checksum(file_with_data) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    os.remove(file_with_data)

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 08:25:55.861291
# Unit test for function md5
def test_md5():
    from shutil import copyfile

    try:
        temp_dir = tempfile.mkdtemp()
        source_file = os.path.join(temp_dir, "source_file")
        target_file = os.path.join(temp_dir, "target_file")
        copyfile(__file__, source_file)
        copyfile(__file__, target_file)
        assert md5(source_file) == md5(target_file)
        assert md5s(open(source_file, 'rb').read()) == md5s(open(target_file, 'rb').read())
    finally:
        shutil.rmtree(temp_dir)


# Generated at 2022-06-21 08:25:59.717463
# Unit test for function md5
def test_md5():
    data = "foo"
    assert md5s(data) == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-21 08:26:02.590863
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed', checksum_s('hello world')

# Generated at 2022-06-21 08:26:08.626851
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/cat") == "04d6a1c6f2f8d5e6e82091a42aae5b9e"
    assert checksum_s(b"hello world\n") == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"
    assert _md5 is None or md5_s("hello world\n") == "5eb63bbbe01eeed093cb22bb8f5acdc3"

# Generated at 2022-06-21 08:26:15.944089
# Unit test for function checksum_s
def test_checksum_s():
    tests = [
        ('', 'da39a3ee5e6b4b0d3255bfef95601890afd80709'),
        ('Hello World', '2ef7bde608ce5404e97d5f042f95f89f1c232871'),
        ('Hello World ' * 1000, '7d793037a0760186574b0282f2f435e7ef1e9e4d'),
    ]
    for data, expected_checksum in tests:
        assert expected_checksum == checksum_s(data)

# Generated at 2022-06-21 08:26:19.595390
# Unit test for function md5
def test_md5():
    try_md5_check = md5("test/test-fixtures/ansible_test/test.cfg")
    assert try_md5_check == "8e1d2380c190776f0bcb055f8b98d441"


# Generated at 2022-06-21 08:26:25.374491
# Unit test for function md5
def test_md5():
    f_path = 'test_file'
    with open(f_path, 'w') as f:
        f.write('Hello world')

    h = 'ed076287532e86365e841e92bfc50d8c'
    if md5(f_path) != h:
        raise AnsibleError('Error with md5 function')
    os.remove(f_path)



# Generated at 2022-06-21 08:26:37.604076
# Unit test for function md5
def test_md5():
    print("md5 test")
    print("md5 test of ansible-doc: %s" % md5("/usr/bin/ansible-doc"))
    print("md5 test of ansible-playbook: %s" % md5("/usr/bin/ansible-playbook"))
    ansible_doc_md5 = md5("/usr/bin/ansible-doc")
    ansible_playbook_md5 = md5("/usr/bin/ansible-playbook")

    if ansible_doc_md5 == ansible_playbook_md5:
        print("Both files have same md5: %s" % ansible_doc_md5)
    else:
        print("Files have different md5: %s and %s" % (ansible_doc_md5, ansible_playbook_md5))

# Generated at 2022-06-21 08:26:41.446114
# Unit test for function checksum
def test_checksum():
    if checksum('/etc/passwd') is not None:
        print("checksum successful")
    else:
        raise Exception("Checksum error")

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:26:46.881147
# Unit test for function md5
def test_md5():
    test_file = os.path.join(os.path.dirname(__file__), 'files', 'test_file')
    test_md5 = md5(test_file)
    assert test_md5 == '76b0e96577dd9c78f4d13b02b00a4343'



# Generated at 2022-06-21 08:26:57.624810
# Unit test for function checksum
def test_checksum():
    import tempfile

    data = 'Zm9vYmFy'
    f = tempfile.NamedTemporaryFile()
    try:
        f.write(to_bytes(data, errors='surrogate_or_strict'))
        f.flush()
        f.seek(0)

        assert secure_hash_s(data) == 'e5e9fa1ba31ecd1ae84f75caaa474f3a663f05f4'
        assert secure_hash(f.name) == 'e5e9fa1ba31ecd1ae84f75caaa474f3a663f05f4'
    finally:
        f.close()


# Generated at 2022-06-21 08:27:07.715290
# Unit test for function md5
def test_md5():
    data = 'foobar'
    expected_hash = '3858f62230ac3c915f300c664312c63f'
    actual_hash = md5s(data)
    if expected_hash != actual_hash:
        print("md5s() returned an unexpected value")
        print("Expected: %s\nActual: %s" % (expected_hash, actual_hash))
        return False

    data = 'foobar'
    expected_hash = '3858f62230ac3c915f300c664312c63f'
    actual_hash = md5s(data)
    if expected_hash != actual_hash:
        print("md5s() returned an unexpected value")
        print("Expected: %s\nActual: %s" % (expected_hash, actual_hash))

# Generated at 2022-06-21 08:27:11.216859
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-21 08:27:15.899226
# Unit test for function checksum
def test_checksum():
    import tempfile
    test_file = tempfile.NamedTemporaryFile(delete=False)
    test_file.write(b"this is a test")

    assert checksum(test_file.name) == checksum_s(b"this is a test")
    os.unlink(test_file.name)

# Generated at 2022-06-21 08:27:23.362467
# Unit test for function md5s
def test_md5s():
    print("MD5    (abc) = 900150983cd24fb0d6963f7d28e17f72")
    print("MD5    (abc) = %s" % md5s("abc"))
    print("MD5    (abc) = 900150983cd24fb0d6963f7d28e17f72")
    print("MD5    (abc) = %s" % md5s("abc"))
    print("MD5    (abc) = 900150983cd24fb0d6963f7d28e17f72")
    print("MD5    (abc) = %s" % md5s("abc"))


# Generated at 2022-06-21 08:27:27.296777
# Unit test for function checksum
def test_checksum():
    assert checksum("hello", hash_func=sha1) == "5d41402abc4b2a76b9719d911017c592"
    assert checksum("hello", hash_func=_md5) == "5d41402abc4b2a76b9719d911017c592"


# Generated at 2022-06-21 08:27:39.350294
# Unit test for function md5s
def test_md5s():
    assert "d41d8cd98f00b204e9800998ecf8427e" == md5s("")
    assert "cf85f0c4a4a60a5b5f73ef0c9f6d2af6" == md5s("a")
    assert "585028aa0f794af812ee3be8804eb14a" == md5s("ab")
    assert "62c99ccf16a829f83ad8dcb6c2b6d2bc" == md5s("abc")
    assert "52d67a2295c8f0e290158c9b0d0e0ebb" == md5s("abcd")
    assert "cffa8a8c979cd3b3dfb3017c2c2e08d7"

# Generated at 2022-06-21 08:27:43.202558
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-21 08:27:49.227204
# Unit test for function checksum
def test_checksum():
    f1 = open('/tmp/test_checksum', 'wb')
    f1.write('hello world')
    f1.close()
    assert checksum('/tmp/test_checksum') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    os.remove('/tmp/test_checksum')

    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-21 08:27:58.726200
# Unit test for function md5s
def test_md5s():
    if _md5:
        h = md5s('abc')
        assert h == '900150983cd24fb0d6963f7d28e17f72'

        h = md5s('')
        assert h == 'd41d8cd98f00b204e9800998ecf8427e'

        h = md5s('foo')
        assert h == 'acbd18db4cc2f85cedef654fccc4a4d8'

        h = md5s('i am a string to convert')
        assert h == 'e740acf8b860dffda6db2bfd2f41d9d1'



# Generated at 2022-06-21 08:28:01.473565
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-21 08:28:04.310072
# Unit test for function md5
def test_md5():
    assert(md5s('asd') == '57f8ff8fb0c0c5e241f98e24e8c0f5e5')


# Generated at 2022-06-21 08:28:08.728145
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("test") == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s("test", hash_func=_md5) == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-21 08:28:15.235570
# Unit test for function md5s
def test_md5s():
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('qwerty') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('12345678901234567890123456789012345678901234567890123456789012345678901234567890') == '57edf4a22be3c955ac49da2e2107b67a'
    assert md5s(u'abc') == '900150983cd24fb0d6963f7d28e17f72'

# Generated at 2022-06-21 08:28:18.443490
# Unit test for function md5s
def test_md5s():
    assert md5s(b'The quick brown fox jumps over the lazy dog') == '9e107d9d372bb6826bd81d3542a419d6'



# Generated at 2022-06-21 08:28:25.858413
# Unit test for function md5
def test_md5():
    ''' test md5 function '''

    test_file = '/tmp/test_md5_file'

    content = "abc"
    md5 = md5s(content)
    assert md5 == '900150983cd24fb0d6963f7d28e17f72'

    open(test_file, 'w').write(content)
    assert md5(test_file) == '900150983cd24fb0d6963f7d28e17f72'

    os.remove(test_file)


# Generated at 2022-06-21 08:28:32.356383
# Unit test for function checksum_s
def test_checksum_s():
    from ansible.compat.tests import unittest

    class TestChecksum(unittest.TestCase):
        def test_checksum_s(self):
            ''' confirm that checksum_s works '''
            dig1 = checksum_s('hello')
            dig2 = checksum_s('world')
            self.assertNotEqual(dig1, dig2)
            dig3 = checksum_s('hello')
            self.assertEqual(dig1, dig3)

    unittest.main()


# Generated at 2022-06-21 08:28:46.035139
# Unit test for function checksum
def test_checksum():
    this_dir = os.path.join(os.path.dirname(__file__), 'test_checksum')
    files = [os.path.join(this_dir, path) for path in os.listdir(this_dir) if path.endswith('.txt')]
    test_pass = True

    for file_path in files:
        file_name = os.path.basename(file_path)
        file_sha1_hexdigest = file_name.split(".")[0]
        test_pass = test_pass and (checksum(file_path) == file_sha1_hexdigest)

    if test_pass:
        print("checksum() test passed")
    else:
        raise Exception("checksum() test failed")

    # Unit test for function checksum_s

# Generated at 2022-06-21 08:28:57.986389
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('message digest') == 'f96b697d7cb7938d525a2f31aaf161d0'
    assert md5s('abcdefghijklmnopqrstuvwxyz') == 'c3fcd3d76192e4007dfb496cca67e13b'

# Generated at 2022-06-21 08:29:00.981443
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert checksum_s("hello", sha1) == "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d"
    assert checksum_s("hello", _md5) == "5d41402abc4b2a76b9719d911017c592"

# Generated at 2022-06-21 08:29:07.071087
# Unit test for function md5
def test_md5():
    import tempfile
    temp_file = tempfile.NamedTemporaryFile()
    temp_file.write(b'foo')
    temp_file.flush()
    # The md5 checksum for the letter f is '03d123335e2a9db9d40f8f384683a173'
    result = md5(temp_file.name)
    assert result == '03d123335e2a9db9d40f8f384683a173', result
    temp_file.close()

# Generated at 2022-06-21 08:29:14.886203
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("hello\n") == "d7cda81a816e7e5b5af5b743f9042f2a"
    assert md5s(b"hello\n") == "d7cda81a816e7e5b5af5b743f9042f2a"

# Generated at 2022-06-21 08:29:17.062361
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-21 08:29:23.297925
# Unit test for function md5
def test_md5():
    test_filename = '../../test/sanity/' + 'inventory.ini'
    test_md5_hexdigest = 'd7e09301a0c22d23b8baae9e7a6e1e86'
    md5_hexdigest = md5(test_filename)
    assert(md5_hexdigest == test_md5_hexdigest)

# Generated at 2022-06-21 08:29:26.367603
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert type(md5("test/test.py")) == str

# Generated at 2022-06-21 08:29:30.257202
# Unit test for function md5
def test_md5():
    s = "foobar"
    s_md5 = md5s(s)
    assert s_md5 == '3858f62230ac3c915f300c664312c63f'



# Generated at 2022-06-21 08:29:36.554466
# Unit test for function md5
def test_md5():
    import os

    md5_test_s = md5s('test1')
    md5_test = md5('hacking/test/utils/test1')
    assert md5_test == md5_test_s

    try:
        import hashlib

        # Running in FIPS mode
        md5(5)
    except ValueError:
        # Expected exception
        pass
    except TypeError as e:
        # If a TypeError is raised we're not running in FIPS mode
        raise Exception(e)
    except ImportError:
        # md5 is not available on platforms running FIPS mode
        pass



# Generated at 2022-06-21 08:29:45.578049
# Unit test for function checksum_s
def test_checksum_s():
    h1 = checksum_s('Hello World')
    assert h1 == 'ed076287532e86365e841e92bfc50d8c'

    h2 = checksum_s(b'Hello World')
    assert h2 == 'ed076287532e86365e841e92bfc50d8c'

# Generated at 2022-06-21 08:29:50.829816
# Unit test for function md5
def test_md5():
    from ansible.module_utils import basic

    path = basic.__file__
    good_md5 = 'a3a879d57e50f2daabc27a67b8d8c561'
    if not os.path.exists(path) or os.path.isdir(path):
        raise ValueError("%s does not exist or is a directory" % path)
    if md5(path) != good_md5:
        raise ValueError("md5 of %s failed" % path)


# unit test for function md5s

# Generated at 2022-06-21 08:30:00.133210
# Unit test for function md5
def test_md5():
    test_file = 'test.txt'
    test_file_handle = open(test_file, 'w')
    test_file_handle.write('This is a test file')
    test_file_handle.close()

    test_data = 'test123'

    assert md5s(test_data) == 'd8e8fca2dc0f896fd7cb4cb0031ba249'
    assert md5(test_file) == 'f122009856ae4f17e15e43c69b976dae'

    os.remove(test_file)

# Generated at 2022-06-21 08:30:03.516748
# Unit test for function md5
def test_md5():
    H = '1abcb33beeb811dca15f0ac3e47b88d9'
    h = md5('lib/ansible/modules/core/files/file_attributes.py')
    assert h == H



# Generated at 2022-06-21 08:30:09.418652
# Unit test for function md5s
def test_md5s():
    test_string = "Hello, World!"
    test_md5_hexdigest = "8ddd8be8807d5f78fa855b0f9adec2e2"
    test_md5s = md5s(test_string)
    test_md5s_correct = (test_md5s == test_md5_hexdigest)
    assert test_md5s_correct


# Generated at 2022-06-21 08:30:12.470283
# Unit test for function md5s
def test_md5s():
    """This function tests the md5s method for initial values."""
    assert md5s(b'Hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'



# Generated at 2022-06-21 08:30:14.324502
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-21 08:30:18.515034
# Unit test for function md5s
def test_md5s():
    # Given
    old_val = '0cc175b9c0f1b6a831c399e269772661'
    new_val = md5s('a')
    # Then
    assert new_val == old_val



# Generated at 2022-06-21 08:30:22.430334
# Unit test for function md5s
def test_md5s():
    assert md5s(b'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-21 08:30:28.198682
# Unit test for function md5
def test_md5():
    """
    Check if md5() returns the same result as the one calculated with
    an online tool on a known file.
    """
    md5_hash = md5("/etc/passwd")
    assert md5_hash == "6ecc5a9f4c4a3a95a4b8f52bfe7f7c45"


# Generated at 2022-06-21 08:30:34.669349
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('world') == '7d793037a0760186574b0282f2f435e7'

# Generated at 2022-06-21 08:30:39.985879
# Unit test for function md5
def test_md5():
    import tempfile
    (fd, filename) = tempfile.mkstemp()
    fd = os.fdopen(fd, 'w')
    fd.write('hello')
    fd.close()
    r = md5(filename)
    # FIXME: this is a hardcoded value which might change one day
    if r != '5d41402abc4b2a76b9719d911017c592':
        raise Exception("md5 returned the wrong checksum")
    os.unlink(filename)



# Generated at 2022-06-21 08:30:42.667366
# Unit test for function checksum_s
def test_checksum_s():
    if not checksum_s("hello world"):
        raise AnsibleError("checksum_s: failed creating a checksum")



# Generated at 2022-06-21 08:30:44.185742
# Unit test for function checksum_s
def test_checksum_s():
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 08:30:51.249936
# Unit test for function checksum
def test_checksum():
    import tempfile

    try:
        fd, fn = tempfile.mkstemp()
        with open(fn, "w") as f:
            f.write("abcdefghijklmnopqrstuvwxyz")
        assert(checksum(fn) == "c3fcd3d76192e4007dfb496cca67e13b")
    finally:
        os.remove(fn)

# Generated at 2022-06-21 08:30:53.208497
# Unit test for function md5s
def test_md5s():
    assert md5s('Hello World') == '5eb63bbbe01eeed093cb22bb8f5acdc3'



# Generated at 2022-06-21 08:30:57.918719
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == secure_hash_s('hello world')
    assert checksum_s('hello world', hash_func=_md5) == md5s('hello world')
    assert checksum_s('hello world', hash_func=_md5) == secure_hash_s('hello world', hash_func=_md5)


# Generated at 2022-06-21 08:31:01.165700
# Unit test for function checksum_s
def test_checksum_s():
    data = "foo"
    csum = checksum_s(data)
    assert csum == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"

# Generated at 2022-06-21 08:31:04.773586
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s('foo') != '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33':
        raise ValueError('checksum_s failed')

# Generated at 2022-06-21 08:31:15.792332
# Unit test for function checksum
def test_checksum():
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('a') == '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8'
    assert checksum_s('foobar') == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert checksum_s('deadbeef') == 'de072f1dc449167c4756a0a8a3a2f4db6e20826b'

# Generated at 2022-06-21 08:31:29.692822
# Unit test for function md5s
def test_md5s():
    # Normal
    assert md5s("Hello") == "8b1a9953c4611296a827abf8c47804d7"
    assert md5s("Hello", _md5) == "8b1a9953c4611296a827abf8c47804d7"
    assert md5s("Hello", sha1) != "8b1a9953c4611296a827abf8c47804d7"

    # With unicode
    assert md5s(u"Hello") == "8b1a9953c4611296a827abf8c47804d7"
    assert md5s(u"Hello", _md5) == "8b1a9953c4611296a827abf8c47804d7"

# Generated at 2022-06-21 08:31:34.443347
# Unit test for function checksum_s
def test_checksum_s():
    from ansible.utils.crypto import secure_hash_s
    test_sha1_s = "b202c42f0e72b6d1acd7732870f2b2ffc38f3d3f"
    assert secure_hash_s("data") == test_sha1_s

# Generated at 2022-06-21 08:31:43.145650
# Unit test for function checksum
def test_checksum():

    my_filename = '/etc/passwd'
    my_data = 'Hello World!'

    assert checksum(my_filename, hash_func=_md5) == 'b59c67bf196a4758191e42f76670ceba'
    assert checksum(my_filename, hash_func=sha1) == '9c7f7309a5e5be91d4c492fc01dfa263e4e4f5a5'
    assert md5(my_filename) == 'b59c67bf196a4758191e42f76670ceba'
    assert checksum(my_filename) == '9c7f7309a5e5be91d4c492fc01dfa263e4e4f5a5'


# Generated at 2022-06-21 08:31:45.421597
# Unit test for function md5
def test_md5():
    if md5('/etc/hosts'):
        return True
    else:
        return False


# Generated at 2022-06-21 08:31:48.725680
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s('string') != 'd033e22ae348aeb5660fc2140aec35850c4da997':
        raise Exception("String checksum failed")


# Generated at 2022-06-21 08:31:56.741143
# Unit test for function checksum
def test_checksum():
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_s('data to hash') == '86e26a7cbb64c61b0a8e08a5e5b0405b7c2e2e2d'
    assert checksum('lib/ansible/module_utils/basic.py') == '0340c4b559a8d4a89f84ae1396e6c9d6'


# Generated at 2022-06-21 08:32:04.156348
# Unit test for function md5
def test_md5():
    fname = os.path.join(os.getcwd(), 'test_md5.txt')
    test_string = 'mandatoryargument'

    assert md5(fname) is None

    if os.path.exists(fname):
        os.remove(fname)

    # write test_string to test_md5.txt
    test_file = open(fname, 'w')
    test_file.write(test_string)
    test_file.close()

    assert md5(fname) == '7c6e67f5a7d8b976f2fb03b0d32b0ba3'