

# Generated at 2022-06-21 08:22:17.425962
# Unit test for function checksum
def test_checksum():
    data = b"abc123"
    digest = secure_hash_s(data)
    assert digest == "4f7f6d70d79011881e1dfcc2b5e71d30ad836fe0"

    f = open("/bin/cat", "rb")
    digest = secure_hash(f)
    assert digest == "48f2780f3b0f7ffd9f8e8d8bfddc7ee49f40b60d"

# Generated at 2022-06-21 08:22:20.002855
# Unit test for function checksum_s
def test_checksum_s():
    assert '84d89877f0d4041efb6bf91a16f0248f2fd573e6' == checksum_s('foo')


# Generated at 2022-06-21 08:22:23.918097
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-21 08:22:28.805852
# Unit test for function checksum
def test_checksum():
    checksum_value = checksum('/bin/ls')
    if checksum_value:
        print("Test: The sha1 checksum of /bin/ls is " + checksum_value)
    else:
        print("Test: The file /bin/ls does not exist")

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:22:32.002896
# Unit test for function checksum_s
def test_checksum_s():

    """
    Examples for checksum_s:
    https://docs.python.org/2/library/sha.html
    >>> test_checksum_s()
    0a4d55a8d778e5022fab701977c5d840bbc486d0
    """

    checksum_s("abc")

# Generated at 2022-06-21 08:22:44.635450
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import textwrap

    from ansible.module_utils.six import BytesIO

    # Test checksum of a string
    content = 'hinz'
    file = BytesIO(content)
    assert checksum_s(file.read()) == '7ffd333dfa1c7eec13d8fd01d015ca02fd9c1e74'
    file.close()

    # Test checksum of a file
    tmpdir = tempfile.mkdtemp()
    testfile = os.path.join(tmpdir, 'testfile')
    with open(testfile, 'w') as file:
        file.write(content)

# Generated at 2022-06-21 08:22:47.009540
# Unit test for function checksum_s
def test_checksum_s():
    assert(checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592')


# Generated at 2022-06-21 08:22:50.563619
# Unit test for function checksum_s
def test_checksum_s():
    test_data = '12345'
    assert checksum_s(test_data) == '8cb2237d0679ca88db6464eac60da96345513964'

# Generated at 2022-06-21 08:22:58.030812
# Unit test for function checksum
def test_checksum():
    ''' Unit test a trivial checksum case '''
        
    md5sum = md5("lib/ansible/module_utils/facts/network.py")
    assert md5sum == 'bb2615a216f39a868ddd3c3a947f6a02' , "MD5 sums didn't match!"
    
    md5sum_s = md5s("this should be exactly 32 bytes long")
    assert md5sum_s == '4e4180c4fce500db8d482112b9f23b66' , "MD5 sums didn't match!"

# Generated at 2022-06-21 08:23:00.909476
# Unit test for function md5s
def test_md5s():
    value = md5s('test')
    assert value == "098f6bcd4621d373cade4e832627b4f6"



# Generated at 2022-06-21 08:23:08.610179
# Unit test for function md5
def test_md5():
    """
    Test md5(), md5s()
    """
    assert md5('/etc/group') == 'f1c96e2a2dcec6efb7bd02b0cbdcee85'
    assert md5s('hi there') == '49f68a5c8493ec2c0bf489821c21fc3b'

# Generated at 2022-06-21 08:23:10.377116
# Unit test for function md5s
def test_md5s():
    import types
    s = md5s("a")
    assert isinstance(s, types.StringTypes)
    assert len(s) == 32

# Generated at 2022-06-21 08:23:23.001728
# Unit test for function checksum_s
def test_checksum_s():
    import sys

    try:
        from hashlib import sha1
    except ImportError:
        from sha import sha as sha1

    from ansible.module_utils.basic import AnsibleModule

    def run_module():

        # define the available arguments/parameters that a user can pass to
        # the module
        module_args = dict(
            data='JavaScript',
            func_name='sha1',
        )

        # seed the result dict in the object
        # we primarily care about changed and state
        # change is if this module effectively modified the target
        # state will include any data that you want your module to pass back
        # for consumption, for example, in a subsequent task
        result = dict(
            changed=False,
            original_message='',
            message='',
        )

        # the AnsibleModule

# Generated at 2022-06-21 08:23:32.293294
# Unit test for function md5
def test_md5():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    def test(data):
        # unit test function for the checksum function
        module = AnsibleModule(argument_spec=dict())
        sum = secure_hash_s(data, _md5)
        module.exit_json(changed=False, md5sum=sum, checksum=sum)

    # use a local file if checksum is a string
    if isinstance(to_bytes('foo'), basestring):
        if not os.path.exists('/tmp/ansible_test_md5.txt'):
            testfile = open('/tmp/ansible_test_md5.txt','w')
            testfile.write('foo')
            testfile.close()
        module_args = dict

# Generated at 2022-06-21 08:23:36.914480
# Unit test for function md5
def test_md5():
    md5_value = md5('test_value')
    assert md5_value == '1bc29b36f623ba82aaf6724fd3b16718', \
        "test_value md5 hash value should be 1bc29b36f623ba82aaf6724fd3b16718"

# Generated at 2022-06-21 08:23:48.909298
# Unit test for function md5s
def test_md5s():
    import yaml

    # FIPS mode, no md5 available, should show error
    del os.environ['OPENSSL_FIPS']
    del os.environ['OPENSSL_FORCE_FIPS']
    del os.environ['FIPS_MODE']
    del os.environ['FIPSMODE']

    try:
        md5s('ansible')
    except ValueError:
        pass
    else:
        assert False, "md5s() should not be available, but it is"

    # FIPS mode, no md5 available, should show error
    os.environ['OPENSSL_FIPS'] = '1'
    os.environ['OPENSSL_FORCE_FIPS'] = '1'
    os.environ['FIPS_MODE'] = '1'

# Generated at 2022-06-21 08:23:56.675740
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s(b'hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s(b'hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-21 08:24:02.641794
# Unit test for function checksum
def test_checksum():
    s = 'The quick brown fox jumped over the lazy dog'
    assert checksum_s(s) == "2fd4e1c67a2d28fced849ee1bb76e7391b93eb12"
    assert checksum_s(s, sha1) == "2fd4e1c67a2d28fced849ee1bb76e7391b93eb12"

# Generated at 2022-06-21 08:24:05.539618
# Unit test for function md5s
def test_md5s():
    assert(md5s("test") == '098f6bcd4621d373cade4e832627b4f6')


# Generated at 2022-06-21 08:24:11.094027
# Unit test for function md5
def test_md5():
    """ Runs a series of MD5 checksums on various strings
        and compares them to their known return values.
    """

    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5('/bin/echo') == '2e1c9c9e844a8de243084a4e4c7db779'

# Generated at 2022-06-21 08:24:16.395323
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('123') == '40bd001563085fc35165329ea1ff5c5ecbdbbeef'


# Generated at 2022-06-21 08:24:24.003660
# Unit test for function md5
def test_md5():
    """Test if md5 calculates correct md5sum for a file"""
    import tempfile
    import shutil
    import os

    tempdir = tempfile.mkdtemp()
    data_dir = os.path.join(tempdir, "data")
    os.makedirs(data_dir)

    test_file_path = os.path.join(data_dir, "test.data")
    test_file_data = "1234567890"
    test_file_hash = "e807f1fcf82d132f9bb018ca6738a19f"

    with open(test_file_path, "w") as test_file:
        test_file.write(test_file_data)


# Generated at 2022-06-21 08:24:26.411751
# Unit test for function checksum_s
def test_checksum_s():
    print(secure_hash_s('Ala ma kota'))
    print(md5s('Ala ma kota'))


# Generated at 2022-06-21 08:24:34.770143
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import mock

    m = mock.mock_open(read_data='data')
    with mock.patch('ansible.module_utils.basic.open', m, create=True):
        assert checksum('/test1') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
        assert checksum_s('data') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-21 08:24:45.250644
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return
    correct_hash = '78e731027d8fd50ed642340b7c9a63b3'
    file_name = 'test_file_md5'
    test_string = 'test string here'
    with open(file_name, 'w') as f:
        f.write(test_string)
    hash_from_file = md5(file_name)
    hash_from_string = md5s(test_string)
    if hash_from_file != correct_hash:
        raise AssertionError("MD5 of file is not calculated correctly")
    if hash_from_string != correct_hash:
        raise AssertionError("MD5 of string is not calculated correctly")
    os.remove(file_name)


# Generated at 2022-06-21 08:24:51.243804
# Unit test for function checksum
def test_checksum():
    ''' test_checksum()
        test to verify checksum functions work
    '''
    import os
    import tempfile

    tests = []
    testdir = tempfile.mkdtemp()

# Generated at 2022-06-21 08:24:57.996881
# Unit test for function checksum
def test_checksum():
    # Create a file and write to it
    import tempfile
    f = tempfile.NamedTemporaryFile()
    s = "Hello World"
    f.write(s)
    f.seek(0)

    md5 = md5s(s)
    sha1 = secure_hash_s(s)
    assert(sha1 == secure_hash(f.name))

    f.close()

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:25:01.451867
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello") == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s("world") == '7d793037a0760186574b0282f2f435e7'


# Generated at 2022-06-21 08:25:06.183088
# Unit test for function checksum
def test_checksum():
    assert checksum("asdas") == checksum("asdas")
    assert checksum("asdas", sha1) == checksum("asdas", sha1)
    assert checksum("asdas") != checksum("asdas", sha1)
    assert checksum("asdas", sha1) != checksum("asdas", _md5)


# Generated at 2022-06-21 08:25:12.298332
# Unit test for function checksum
def test_checksum():

    # Create a file and calculate the checksum
    with open("/tmp/test_checksum", "w") as f:
        f.write("Hello World")
    chksum = checksum("/tmp/test_checksum")
    os.unlink("/tmp/test_checksum")
    if chksum != "5eb63bbbe01eeed093cb22bb8f5acdc3":
        return False

    # Verify that supplying a directory is handled properly
    if checksum("/tmp") is not None:
        return False
    return True


# Generated at 2022-06-21 08:25:25.140114
# Unit test for function checksum
def test_checksum():

    TEST_FILES = {
        '/home/jdoe/testfile': 'd3268902a8c8f53a2aec57c5aa5d5b9c',
        '/tmp': None
    }

    for test_file in TEST_FILES:

        if not os.path.isfile(test_file):
            open(test_file, 'a').close()  # create file if it doesn't exist

        if not os.path.isdir(test_file):
            fcontent = open(test_file, 'r').read()
            os.remove(test_file)
        else:
            fcontent = ''

        assert checksum(test_file) == TEST_FILES[test_file]
        assert checksum_s(fcontent) == TEST_FILES[test_file]



# Generated at 2022-06-21 08:25:36.542361
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('different message') == 'f4e343e4c4b2efb2a33d142a9e35e51c'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(b'a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s(u'a') == '0cc175b9c0f1b6a831c399e269772661'

# Generated at 2022-06-21 08:25:39.186786
# Unit test for function md5
def test_md5():
    h = md5('/bin/anyfile')
    assert h and len(h) == 32, h
    h = md5s('hello')
    assert h and len(h) == 32, h


# Generated at 2022-06-21 08:25:41.085213
# Unit test for function md5
def test_md5():
    assert md5(__file__) == md5s(open(__file__).read())


# Generated at 2022-06-21 08:25:49.388593
# Unit test for function md5
def test_md5():
    ''' test md5 function '''

    def _md5_count_once(filename):
        count = 0
        for i in range(10):
            hashval = md5(filename)
            if hashval and count == 0:
                count = 1
        return count

    assert _md5_count_once(__file__) == 1
    try:
        md5(__file__ + 'some_bad_filename')
        assert False, 'Should have failed because of missing file'
    except ValueError as e:
        assert 'No such file or directory' in str(e)

# Generated at 2022-06-21 08:25:58.223917
# Unit test for function checksum
def test_checksum():
    ''' test_checksum:
        - generate the md5 checksum of a file
        - generate the sha1 checksum of a file
        - generate the md5 checksum of a string
        - generate the sha1 checksum of a string
    '''

    import filecmp

    # Create a testfile and make sure that its size is > 0
    testfile = "test-checksum"
    testdata = "hello world\n"
    f = open(testfile, 'w')
    f.write(testdata)
    f.close()
    assert os.path.getsize(testfile) > 0

    # Create a string with testdata
    teststr = "hello world\n"

    # Create a test directory
    testdir = "test-checksum-dir"
    os.mkdir(testdir)

   

# Generated at 2022-06-21 08:26:07.126663
# Unit test for function checksum_s
def test_checksum_s():
    # Test a simple string
    if checksum_s("hello world") != "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed":
        raise AssertionError("checksum_s() failed string test")

    # Test unicode string (contains non-ascii)
    if checksum_s("hello t\xe9st world") != "8e0a22f7b0cd30b2c3e0a99d29a7f61d0b2472bc":
        raise AssertionError("checksum_s() failed unicode test")


if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-21 08:26:12.265156
# Unit test for function checksum_s
def test_checksum_s():
    '''
    module_utils.crypto.checksum_s unit test

    This module tries to run checksum_s against some fixed
    input. Output is saved to a file and then used for comparison.
    '''
    file_path = os.path.join(os.path.dirname(__file__), 'checksum_s.output.txt')
    with open(file_path, 'w') as file:
        file.write(checksum_s('This is an unit test for module_utils.crypto.checksum_s'))

if __name__ == "__main__":
    test_checksum_s()

# Generated at 2022-06-21 08:26:15.810731
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('hi') == '49f68a5c8493ec2c0bf489821c21fc3b'


if __name__ == '__main__':
    import doctest
    doctest.testmod()
    print("done")

# Generated at 2022-06-21 08:26:23.640806
# Unit test for function checksum
def test_checksum():
    assert checksum_s("foo") == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    assert checksum("foo") == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    assert checksum("../test/test_module.py") == "d8142b7e62a008768d7c73c72e0b270dc66aad5e"
    assert checksum("../test/integration/targets/constructor_injection.py") == "edf39c5ae9f5b8d5fae1a0f0928d47c5f8ef111b"


if __name__ == '__main__':
    test_checksum

# Generated at 2022-06-21 08:26:37.104493
# Unit test for function md5
def test_md5():
    """ md5 unit test """
    from ansible.compat.tests import unittest

    class TestMd5(unittest.TestCase):

        def test_md5(self):
            """ md5 test """
            result_data = md5s('hello')
            self.assertEqual(result_data, '5d41402abc4b2a76b9719d911017c592')

            result_file = md5(__file__)
            self.assertEqual(result_file, '2e8b9ae097a55f6717dae7d870a0a75f')

    unittest.main(exit=False)

# Generated at 2022-06-21 08:26:44.152463
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello", sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s("hello", md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s("hello") == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

# Generated at 2022-06-21 08:26:47.602009
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'a1b73bd2b8cdc6e4b4f9c9272373b8a0d7d4e4ae'



# Generated at 2022-06-21 08:26:55.143199
# Unit test for function checksum
def test_checksum():
    '''Tests checksum function'''
    checksum_test_file = "./test/support/checksum_test_file"
    checksum_test_file_sha1 = "f3f52fa26d1816c873e3da1d449392bc73a5e776"
    if checksum(checksum_test_file) != checksum_test_file_sha1:
        raise AssertionError('checksum function failed')

# Generated at 2022-06-21 08:27:02.843137
# Unit test for function md5
def test_md5():

    if not _md5:
        raise AssertionError('MD5 not available.  Possibly running in FIPS mode')

    msg = 'Hi There'
    hashed = md5s(msg)
    assert hashed == '943a702d06f34599aee1f8da8ef9f729'
    assert secure_hash_s(msg, _md5) == '943a702d06f34599aee1f8da8ef9f729'

    msg = 'Jefe'
    hashed = md5s(msg)
    assert hashed == '750c783e6ab0b503eaa86e310a5db738'
    assert secure_hash_s(msg, _md5) == '750c783e6ab0b503eaa86e310a5db738'

    msg

# Generated at 2022-06-21 08:27:10.150486
# Unit test for function checksum
def test_checksum():
    # Test SHA1
    def assert_checksums_match(text1, text2, checksum_type='sha1'):
        chksum1 = checksum_s(text1, checksum_type)
        chksum2 = checksum_s(text2, checksum_type)
        failure = 'Expected "%s" but got "%s"' % (chksum1, chksum2)
        assert chksum1 == chksum2, failure

    assert_checksums_match('hello world', 'hello world')
    assert_checksums_match('hello world', 'hello  world')
    assert_checksums_match('hello world', 'hello   world')
    assert_checksums_match('hello world', 'hello    world')
    assert_checksums_match('hello world', '  hello world')
    assert_

# Generated at 2022-06-21 08:27:12.894602
# Unit test for function md5
def test_md5():
    print(md5('myfile'))

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-21 08:27:17.015781
# Unit test for function checksum_s
def test_checksum_s():
    algos = ['sha1', 'sha224', 'sha256', 'sha384', 'sha512']
    for algo in algos:
        h = eval(algo)()
        h.update('hello')
        assert checksum_s('hello', h) == h.hexdigest()

# Generated at 2022-06-21 08:27:21.373448
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('/etc/passwd') == checksum_s('/etc/passwd')
    assert checksum_s('/etc/passwd') != checksum_s('/etc/group')
    assert checksum_s('/etc/passwd') != checksum_s('/etc/shadow')



# Generated at 2022-06-21 08:27:33.514154
# Unit test for function checksum
def test_checksum():
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('hello') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'
    assert checksum_s('hello\n') == '943a702d06f34599aee1f8da8ef9f7296031d699'
    assert checksum_s('hello\n\n') == 'b7bc5fb91080c7de6b582ea281f8a396d7c0aee8'

# Generated at 2022-06-21 08:27:44.857425
# Unit test for function checksum
def test_checksum():
    from ansible.module_utils.basic import AnsibleModule

    test_file = open("/tmp/ansible_test.txt", "w")
    test_file.write("Blah, blah, blah")
    test_file.close()

    mod = AnsibleModule(argument_spec=dict(src=dict(required=True)))
    mod.exit_json(checksum=checksum("/tmp/ansible_test.txt"))

# Generated at 2022-06-21 08:27:55.829561
# Unit test for function checksum
def test_checksum():

    # Test a secure_hash
    sha1_1 = checksum("test/test_utils.py")
    sha1_2 = checksum("test/test_utils.py")
    if sha1_1 != sha1_2:
        raise AnsibleError()

    # Test a secure_hash_s
    sha1_1 = checksum_s("abcdefgh")
    sha1_2 = checksum_s("abcdefgh")
    if sha1_1 != sha1_2:
        raise AnsibleError()

    # Test md5
    md5_1 = md5("test/test_utils.py")
    md5_2 = md5("test/test_utils.py")
    if md5_1 != md5_2:
        raise AnsibleError()

    # Test

# Generated at 2022-06-21 08:28:00.274746
# Unit test for function checksum
def test_checksum():
    assert(checksum("/bin/cat") == checksum("/usr/bin/cat"))
    assert(checksum("/bin/cat") != checksum("/bin/ls"))
    assert(checksum("/bin/cat") != checksum("/bin/cat "))


# Generated at 2022-06-21 08:28:06.394330
# Unit test for function checksum
def test_checksum():
    from ansible.module_utils._text import to_bytes
    import tempfile
    import shutil
    fd, fname = tempfile.mkstemp()
    f = open(fname, 'wb')
    f.write(b'test')
    f.close()
    assert(checksum(fname) == '098f6bcd4621d373cade4e832627b4f6')
    os.remove(fname)

# Generated at 2022-06-21 08:28:10.637415
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('test_snippet') == '5bf5f39a81aad268eecb7e1866c20a37a3ecef0f'
    assert checksum_s('test_snippet', hash_func=_md5) == '68c4bc4a4a757a954b8e4e6a4d5064d3'

# Generated at 2022-06-21 08:28:14.907756
# Unit test for function checksum_s
def test_checksum_s():
    a = 'hello'
    b = 'bye'
    c = 'hello'
    if checksum_s(a) != checksum_s(c):
        print("FAILED: sha1 hash on different strings do not match")
        exit(1)
    if checksum_s(a) == checksum_s(b):
        print("FAILED: sha1 hash on different strings should not match")
        exit(1)

if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-21 08:28:26.095493
# Unit test for function md5s
def test_md5s():
    from random import randint
    test_data = str(randint(10000, 99999))
    test_results = md5s(test_data)
    test_str = "Test complete"

    # test return length
    assert len(test_results) == 32, test_str + " - test_md5s - return length"

    # test against known result
    known_results = "c81e728d9d4c2f636f067f89cc14862c"
    assert test_results == known_results, test_str + " - test_md5s - test against known result"

    # test against known result after prepended with a known string.
    known_results = "70c81e728d9d4c2f636f067f89cc14862c"
    test_results = md

# Generated at 2022-06-21 08:28:28.807915
# Unit test for function checksum
def test_checksum():
    digest = secure_hash('lib/ansible/modules/core/copy.py')
    assert digest == 'f8615caf539b51e0789b5f698bbee465'

# Generated at 2022-06-21 08:28:32.164463
# Unit test for function md5s
def test_md5s():
    assert md5s("abc") == "900150983cd24fb0d6963f7d28e17f72"
    assert md5s("Hello, world!") == "fc5e038d38a57032085441e7fe7010b0"


# Generated at 2022-06-21 08:28:34.095508
# Unit test for function checksum_s
def test_checksum_s():

    assert checksum_s(b"hello world") == secure_hash_s(b"hello world")
    assert checksum_s("hello world") == secure_hash_s("hello world")

# Generated at 2022-06-21 08:28:52.442623
# Unit test for function checksum
def test_checksum():
    try:
        if not os.path.exists('./test.txt'):
            open('test.txt', 'w').close()
        assert checksum('./test.txt') == checksum('./test.txt')
        assert checksum('test.txt') == checksum('./test.txt')
        assert checksum('test.txt') == checksum_s(open('./test.txt', 'r').read())
        assert checksum('test.txt') == checksum_s(open('./test.txt', 'r').read())
        assert checksum_s('test string') == checksum_s('test string')
    finally:
        os.remove('test.txt')

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:28:56.836542
# Unit test for function checksum_s
def test_checksum_s():
    sample_data = "Hello World"
    sample_data_hash = "65a8e27d8879283831b664bd8b7f0ad4"
    assert checksum_s(sample_data) == sample_data_hash

# Generated at 2022-06-21 08:29:05.975836
# Unit test for function md5
def test_md5():
    test_fpath = os.path.join(os.path.dirname(__file__), "test_md5.txt")
    with open(test_fpath, "w") as f:
        f.write("The quick brown fox jumps over the lazy dog")

    fhash = md5(test_fpath)
    assert(fhash == '9e107d9d372bb6826bd81d3542a419d6')

    shash = md5s("The quick brown fox jumps over the lazy dog")
    assert(shash == '9e107d9d372bb6826bd81d3542a419d6')

    os.remove(test_fpath)


# Generated at 2022-06-21 08:29:18.646533
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s(123) == '900150983cd24fb0d6963f7d28e17f72'
    assert checksum_s(None) == 'd41d8cd98f00b204e9800998ecf8427e'

    # Test file creation
    test_file_name = "/tmp/test_checksum"
    test_file = open(test_file_name, 'a+')
    test_file.write("This is a test file for checksum function.")
    test_file.close()

# Generated at 2022-06-21 08:29:25.237235
# Unit test for function md5s
def test_md5s():
    # (expected_result, data)
    cases = [
    ]

    for expected, data in cases:
        actual = md5s(data)
        assert actual == expected, "md5s('%s') expected '%s' got '%s'" % (data, expected, actual)



# Generated at 2022-06-21 08:29:32.990586
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("testing") == "ae2b1fca515949e5d54fb22b8ed95575"
    assert checksum_s("testing", hash_func=sha1) == "ae2b1fca515949e5d54fb22b8ed95575"
    assert checksum_s("testing", hash_func=_md5) == "98c9bf58a60cbf95c73ae4d4f7c1e542"

# Generated at 2022-06-21 08:29:44.644847
# Unit test for function checksum
def test_checksum():
    # passing in a file object
    fo = open("/bin/ls", "r")
    assert(checksum(fo) == checksum("/bin/ls"))
    fo.close()


if __name__ == '__main__':
    # Test the secure_hash_s function
    assert(secure_hash_s("Hello World") == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed")
    assert(secure_hash_s("") == "da39a3ee5e6b4b0d3255bfef95601890afd80709")
    assert(secure_hash_s("a", sha1) == "86f7e437faa5a7fce15d1ddcb9eaeaea377667b8")

# Generated at 2022-06-21 08:29:52.056910
# Unit test for function checksum
def test_checksum():
    ''' unit test for function checksum '''

    import tempfile
    temp_dir = tempfile.gettempdir()

    filename = os.path.join(temp_dir, 'test_checksum')
    with open(filename, 'wb') as test_file:
        test_file.write('test')

    test_md5sum = '098f6bcd4621d373cade4e832627b4f6'
    test_sha1sum = 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

    assert checksum(filename) == test_sha1sum
    assert checksum(filename, _md5) == test_md5sum
    assert checksum_s('test') == test_sha1sum

# Generated at 2022-06-21 08:29:57.302897
# Unit test for function checksum_s
def test_checksum_s():
    try:
        assert checksum_s("foobar") == "8843d7f92416211de9ebb963ff4ce28125932878"
    except AssertionError:
        print("Failed SHA1 checksum test")


# Generated at 2022-06-21 08:29:59.835201
# Unit test for function md5
def test_md5():
    assert md5('/proc/version') == "b354d6f4c4f57a6e1c84ef1a6237b7d2"


# Generated at 2022-06-21 08:30:15.614318
# Unit test for function checksum
def test_checksum():
    from ansible.module_utils.basic import AnsibleModule
    if secure_hash_s('foo', _md5) != 'acbd18db4cc2f85cedef654fccc4a4d8':
        raise AssertionError('MD5 not available.  Possibly running in FIPS mode')

    if secure_hash_s('foo') != '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33':
        raise AssertionError('SHA1 not available!')

    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    if secure_hash_s('foo') != module.checksum_s('foo'):
        raise AssertionError('Python checksum does not match module checksum for "foo"')

    # The test

# Generated at 2022-06-21 08:30:19.211583
# Unit test for function md5s
def test_md5s():
    assert md5s("abcdefg") == "7ac66c0f148de9519b8bd264312c4d64"

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-21 08:30:25.058842
# Unit test for function md5
def test_md5():
    test_filename = 'test_data'
    expected_result = 'ce114e4501d2f4e2dcea3e17b546f339'
    test_file = open(test_filename,'w')
    test_file.write('test\n')
    test_file.close()
    test_result = md5(test_filename)
    assert test_result == expected_result

# Generated at 2022-06-21 08:30:30.871869
# Unit test for function md5
def test_md5():
    ''' md5.py: Test md5() and md5s() '''
    # Create a test file
    import tempfile
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('Hello World!')
    f.close()

    assert md5(fname) == md5s('Hello World!')

    os.remove(fname)

# Generated at 2022-06-21 08:30:36.926372
# Unit test for function md5s
def test_md5s():
    from nose.plugins.skip import SkipTest
    try:
        from hashlib import md5
    except ImportError:
        try:
            from md5 import md5
        except ImportError:
            raise SkipTest("MD5 not available")
    test_str='test string'
    expected_hash=md5(test_str).hexdigest()
    got_hash=md5s(test_str)
    assert got_hash==expected_hash, 'md5s() test failed'

# Generated at 2022-06-21 08:30:43.571707
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    def _test(expected, filename):
        actual = md5(filename)
        if actual != expected:
            raise AssertionError("md5 returned '%s' instead of '%s' for file %s" % (actual, expected, filename))

    _test('d41d8cd98f00b204e9800998ecf8427e', './library/nonexistent')
    _test('d41d8cd98f00b204e9800998ecf8427e', './library/nonexistent/')
    _test('d41d8cd98f00b204e9800998ecf8427e', './library/nonexistent/dummy')

# Generated at 2022-06-21 08:30:48.724678
# Unit test for function md5
def test_md5():
    '''
    ansible -m test -a 'data=hello'
    '''
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-21 08:30:54.585510
# Unit test for function checksum_s
def test_checksum_s():

    if not _md5:
        print('MD5 not available.  Possibly running in FIPS mode')
    else:
        assert checksum_s('foo') == md5s('foo')
        assert checksum_s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
        assert checksum_s('foo') != 'acbd18db4cc2f85cedef654fccc4a4d0'

# Generated at 2022-06-21 08:30:57.094517
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '5fc5179e2f6a0e724cfecb8d02f2310c'


# Generated at 2022-06-21 08:31:09.191440
# Unit test for function checksum_s
def test_checksum_s():
    import time

    # Generate the base64 representation of sha1 of the string "asdf"
    digest_sha1 = sha1()
    digest_sha1.update(to_bytes("asdf", errors='surrogate_or_strict'))
    expected_result_sha1 = digest_sha1.hexdigest()

    assert expected_result_sha1 == checksum_s("asdf")

    # Generate the base64 representation of sha1 of the string "AsDf"
    digest_sha1 = sha1()
    digest_sha1.update(to_bytes("AsDf", errors='surrogate_or_strict'))
    expected_result_sha1 = digest_sha1.hexdigest()

    assert expected_result_sha1 == checksum_s("AsDf")

    #

# Generated at 2022-06-21 08:31:23.635010
# Unit test for function md5
def test_md5():
    assert md5(filename="tests/test.py") == checksum(filename="tests/test.py")
    assert md5(filename=None) == checksum(filename=None)
    assert md5(filename="tests/") is None
    assert md5(filename="tests/multiline-jinja.txt") == checksum(filename="tests/multiline-jinja.txt")
    assert md5(filename="tests/test.py") == "3d1f0856bab75a039e93c24ddd9a6b1f"


# Generated at 2022-06-21 08:31:28.563211
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s("hello") != "5d41402abc4b2a76b9719d911017c592":
        raise Exception("checksum_s(hello) failed")
    if checksum_s("hello",_md5) != "5d41402abc4b2a76b9719d911017c592":
        raise Exception("checksum_s(hello) failed")

# Generated at 2022-06-21 08:31:39.296628
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert secure_hash_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert secure_hash_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-21 08:31:41.072569
# Unit test for function md5s
def test_md5s():
    assert md5s('asdf') == '912ec803b2ce49e4a541068d495ab570'


# Generated at 2022-06-21 08:31:42.762481
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-21 08:31:54.332729
# Unit test for function md5
def test_md5():
    # create test file
    def generate_test_file(test_file):
        with open(test_file, "w") as f:
            f.write("The quick brown fox jumps over the lazy dog.")
    test_file = 'test_file.txt'
    test_file_md5 = '9e107d9d372bb6826bd81d3542a419d6'
    generate_test_file(test_file)
    # test on file
    value1 = md5(test_file)
    value2 = secure_hash(test_file, _md5)
    import os
    os.remove(test_file)
    assert test_file_md5 == value1
    assert test_file_md5 == value2


# Generated at 2022-06-21 08:32:02.726190
# Unit test for function checksum
def test_checksum():
    if checksum('/etc/passwd') is None:
        print("Permissions issue accessing '/etc/passwd'")
        return
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s(u'hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-21 08:32:11.793345
# Unit test for function checksum
def test_checksum():
    import os, shutil
    from tempfile import mkdtemp
    from ansible.compat.tests import unittest

    # create and hash a simple file
    sample_dir = mkdtemp()
    sample_file = os.path.join(sample_dir, to_bytes("sample.txt"))
    with open(sample_file, 'w') as f:
        f.write("Hello!")

    sha_hash = checksum(sample_file)
    assert sha_hash == "86fb269d190d2c85f6e0468ceca42a20"

    # check a file which doesn't exist
    nonexistant_file = os.path.join(sample_dir, to_bytes("nonexistant.txt"))
    assert checksum(nonexistant_file) is None

    # check a directory