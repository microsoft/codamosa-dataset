

# Generated at 2022-06-21 08:22:16.976980
# Unit test for function checksum
def test_checksum():
    import sys

    # There is no /dev/null on Windows
    if sys.platform != "win32":
        assert checksum("/dev/null") is None

    assert checksum(__file__) is not None
    assert checksum_s(__file__) is not None
    assert checksum_s(__file__) == checksum_s(__file__)

# Generated at 2022-06-21 08:22:22.661560
# Unit test for function checksum_s
def test_checksum_s():
    ''' hashlib.sha1().hexdigest() == 'b617318655057264e28bc0b6fb378c8ef146be00' '''

    mystr = 'hello world'

    assert secure_hash_s(mystr) == 'b617318655057264e28bc0b6fb378c8ef146be00', secure_hash_s(mystr)



# Generated at 2022-06-21 08:22:32.004257
# Unit test for function md5
def test_md5():
    ''' md5.py: Test md5()'''
    test_str = u'This is a test.'
    test_str_md5 = 'e6d0a78ae8b8c66451e9975a0a6f2b6d'
    assert(md5s(test_str) == test_str_md5)
    assert(md5('../linse') is None)
    assert(md5('../linse/shell.py') == '2a01a54ba9e1bc41a9ef2a62b9f70cb0')


if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])
    print('%s' % md5('../linse/shell.py'))

# Generated at 2022-06-21 08:22:44.636152
# Unit test for function checksum_s
def test_checksum_s():
    data = 'a'
    expected = '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8'
    result1 = checksum_s(data)
    result2 = checksum_s(data*1024)
    result3 = checksum_s(data*1024*1024)
    assert '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8' == result1
    assert 'b741a4bc9e4aa4b4fa209f897d09b2f9470fc130' == result2
    assert 'e1c9f9a92cab757271b585d7ae31db2e1f7c0e07' == result3

# Run from CLI/Tests

# Generated at 2022-06-21 08:22:48.958072
# Unit test for function md5s
def test_md5s():
    verify_value = '5fa9d5d5f5b4c4c4f3934d0a4bff1b8a'
    data = 'Test123'
    assert verify_value == md5s(data)

# Generated at 2022-06-21 08:22:51.466081
# Unit test for function md5s
def test_md5s():
    assert md5s("ansible") == '5a105e8b9d40e1329780d62ea2265d8a'


# Generated at 2022-06-21 08:22:57.502312
# Unit test for function md5
def test_md5():
    path = "/etc/passwd"
    assert md5(path) == 'd3c33f9aee5f9d69257eb6b1a8d8f88a'
    assert md5s(path) == '9e87c3f24e7adfa15c0b47fbf06c4f38'
    assert md5s('testing') == 'ae2b1fca515949e5d54fb22b8ed95575'


# Generated at 2022-06-21 08:23:00.861227
# Unit test for function checksum_s
def test_checksum_s():
    data = 'abc123'
    checksum = checksum_s(data)
    assert checksum == '40bd001563085fc35165329ea1ff5c5ecbdbbeef'



# Generated at 2022-06-21 08:23:05.965504
# Unit test for function md5s
def test_md5s():
    test_data = 'test'
    md5_val = md5s(test_data)
    assert isinstance(md5_val, basestring)
    assert len(md5_val) == 32
    assert md5_val == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-21 08:23:12.343988
# Unit test for function checksum
def test_checksum():
    # Create test file
    filename = 'test_file'
    f = open(filename, 'w')
    f.write('abc123\n')
    f.close()

    digest = secure_hash(filename)
    assert digest == 'f1d2d2f924e986ac86fdf7b36c94bcdf32beec15', digest
    digest = secure_hash_s('abc123')
    assert digest == 'f1d2d2f924e986ac86fdf7b36c94bcdf32beec15', digest

    # Delete test file
    os.remove(filename)

# Generated at 2022-06-21 08:23:24.960874
# Unit test for function checksum_s
def test_checksum_s():
    test_string = "test string"
    test_string2 = "test string2"

    # Create a checksum for a test string
    cs1 = checksum_s(test_string)

    # Verify that the checksum is created correctly
    assert(len(cs1) == 40)

    # Verify the checksum for another string is different
    cs2 = checksum_s(test_string2)
    assert(cs2 != cs1)


# Generated at 2022-06-21 08:23:27.198809
# Unit test for function md5s
def test_md5s():
    assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"


# Generated at 2022-06-21 08:23:31.234493
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-21 08:23:35.674140
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("") == "da39a3ee5e6b4b0d3255bfef95601890afd80709"
    assert checksum_s("a") == "86f7e437faa5a7fce15d1ddcb9eaeaea377667b8"


# Generated at 2022-06-21 08:23:40.272760
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("hello", _md5) == "5d41402abc4b2a76b9719d911017c592"

# Generated at 2022-06-21 08:23:42.234744
# Unit test for function md5s
def test_md5s():
     assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
     assert md5s('hello world') != '5ab63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-21 08:23:48.182368
# Unit test for function checksum_s
def test_checksum_s():
    assert(checksum_s('text') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff')

# Generated at 2022-06-21 08:23:57.286938
# Unit test for function checksum
def test_checksum():
    import tempfile
    tempfile.tempdir = None
    fd, fpath = tempfile.mkstemp()
    assert(checksum(fpath) is None)
    assert(checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709')
    assert(checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3')
    assert(checksum_s('test') == checksum_s('test'))
    assert(checksum_s('test') != checksum_s('test1'))
    os.write(fd, "test")
    os.close(fd)

# Generated at 2022-06-21 08:24:01.027252
# Unit test for function md5
def test_md5():

    data = b'abcdefghijklmnopqrstuvwxyz'

    md5_value = md5s(data)

    assert md5_value == 'c3fcd3d76192e4007dfb496cca67e13b'

# Generated at 2022-06-21 08:24:07.594290
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('Hello World') == '2ef7bde608ce5404e97d5f042f95f89f1c232871'


if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-21 08:24:12.866409
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Unit tests for function md5

# Generated at 2022-06-21 08:24:16.044746
# Unit test for function md5
def test_md5():
    expected = 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('./lib/ansible/module_utils/basic.py') == expected

# Generated at 2022-06-21 08:24:23.993039
# Unit test for function checksum_s
def test_checksum_s():
    ''' tests checksum_s function '''

    import os
    import random
    from ansible.utils.hashing import checksum_s
    from ansible.utils.unicode import to_bytes
    import math

    for x in range(0, 100):
        size = math.pow(2, x)
        size = int(size)
        bs = bytearray(os.urandom(size))
        for y in range(1, size):
            for z in range(0, 255):
                bs[y] = z
                assert checksum_s(to_bytes(bs, errors='surrogate_or_strict'), method='sha1') == checksum_s(to_bytes(bs, errors='surrogate_or_strict'), method='sha1')


# Generated at 2022-06-21 08:24:32.576152
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n\n') == '1f912498f433b1758c3d0fa08f7c3b43'


# Generated at 2022-06-21 08:24:35.934926
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s("test") != "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3":
        raise Exception("Failed")


# Generated at 2022-06-21 08:24:39.391800
# Unit test for function md5
def test_md5():
    filename = "test/test.md5sum"
    assert md5(filename) == "2b8e0b6aabe1e62b27e2c8f168064cbc"

# Generated at 2022-06-21 08:24:45.087184
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('Test for md5s') == '1a4b4e9c0d510a8a36a1e0f39a0a53d7'
    else:
        try:
            md5s('Test for md5s')
        except ValueError as e:
            assert "MD5 not available.  Possibly running in FIPS mode" == str(e)


# Generated at 2022-06-21 08:24:51.162639
# Unit test for function md5
def test_md5():
    import tempfile
    data = '''More than one way to do it'''
    expected = '2d18e8f47beef1063edb1a6c8f574b27'
    try:
        outfile = tempfile.NamedTemporaryFile(delete=True)
        outfile.write(data)
        outfile.flush()
        outfile.seek(0)
        calculated = md5(outfile.name)
        assert calculated == expected
        outfile.close()
    except Exception as e:
        raise


# Backwards compat only.  As of ansible-1.8, all modules should report sha1 not md5
#
# If a module has not yet been updated to use checksum, it will continue to
# report md5.  But the md5 value will not be used for anything.
#

# Generated at 2022-06-21 08:24:57.537526
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    try:
        md5s('hello', hash_func='not known')
    except ValueError as e:
        assert 'not known is not supported' in str(e)
    assert md5('/bin/ls') == '265b8d0c13ae57f68d1fb903d9369518'

# Generated at 2022-06-21 08:24:59.468455
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-21 08:25:06.919151
# Unit test for function checksum
def test_checksum():
    if os.path.isfile('/usr/bin/sha1sum'):
        sha1sum_out = os.popen('cat /etc/passwd | /usr/bin/sha1sum').read().split(' ')[0]
        assert sha1sum_out == checksum_s(''.join(open('/etc/passwd','r').readlines()))
    else:
        # Not all platforms have sha1sum avail
        pass

# Generated at 2022-06-21 08:25:09.293594
# Unit test for function md5s
def test_md5s():
    data = """
    ---
    - hosts: all
      tasks:
        - ping:
    """

    md5 = 'dff7e1b57a0a7459ea079a618ffc4c4d'
    assert md5s(data) == md5

# Generated at 2022-06-21 08:25:14.438629
# Unit test for function md5s
def test_md5s():
    '''Test for md5s'''
    data = md5s('a')
    assert data == '0cc175b9c0f1b6a831c399e269772661'

# Generated at 2022-06-21 08:25:20.573516
# Unit test for function checksum
def test_checksum():
    filename = 'lib/ansible/modules/core/system/setup.py'
    expected_checksum_algorithm = 'sha1'
    expected_checksum_value = '7f487e8bd31c8d881b0f7b76a2bbcd63517e0a0e'
    actual_checksum_value = checksum(filename)
    assert expected_checksum_value == actual_checksum_value



# Generated at 2022-06-21 08:25:27.985019
# Unit test for function checksum
def test_checksum():
    '''Functional test to see if checksum generates a correct value'''
    assert checksum(os.path.join(os.path.dirname(__file__), '..', 'lib', 'ansible', 'module_utils', '__init__.py')) == '5e5c5f6613d8ecc0f8dc5f1a5fa7eda4b6e0a7f4'

# Generated at 2022-06-21 08:25:38.417959
# Unit test for function md5
def test_md5():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    case = unittest.TestCase('__init__')

    # FIPS mode
    md5_fips = MagicMock()
    with patch('ansible.module_utils.basic.ansible_test._md5', None):
        with patch('ansible.module_utils.basic.ansible_test.secure_hash', md5_fips):
            md5('filename')
            case.assertFalse(md5_fips.called)

    # Non-FIPS mode
    md5_non_fips = MagicMock()

# Generated at 2022-06-21 08:25:45.784329
# Unit test for function checksum
def test_checksum():
    testfile = 'testfile'
    with open(testfile, 'r') as f:
        hexs = checksum(testfile)
        hexs2 = checksum(testfile)
        hexs_with_slash = checksum('/' + testfile)
        hexs_with_dot = checksum('./' + testfile)
    assert hexs == hexs2
    assert hexs == hexs_with_slash
    assert hexs == hexs_with_dot

# Generated at 2022-06-21 08:25:54.019972
# Unit test for function checksum_s
def test_checksum_s():
    if not checksum_s("foobar", sha1) in (
            '8843d7f92416211de9ebb963ff4ce28125932878', # Python 2.7
            '8843d7f92416211de9ebb963ff4ce28125932878'.upper(), # Python 3.2 and 3.3
            '8843d7f92416211de9ebb963ff4ce28125932878'.lower(), # Python 3.4 and later
    ):
        raise AssertionError('function checksum_s has changed its output')



# Generated at 2022-06-21 08:25:55.513223
# Unit test for function checksum_s
def test_checksum_s():
    # Test if checksum_s returns a string
    assert isinstance(checksum_s("lolcat"), str)

# Generated at 2022-06-21 08:26:04.163511
# Unit test for function checksum_s
def test_checksum_s():

    # Test string
    test_string = '''The Rain in Spain'''

    # Test answer
    test_answer = 'b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9'

    # Test function call
    test_result = checksum_s(test_string)

    # Test assertion
    assert test_result == test_answer

if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-21 08:26:12.919800
# Unit test for function checksum
def test_checksum():
    ''' test checksum function '''
    from tempfile import mkstemp
    from shutil import rmtree
    from os.path import dirname, join
    import os

    test_dir = mkdtemp()
    test_file = join(test_dir, 'test_file')
    fd, tmp_path = mkstemp()
    with open(tmp_path) as f:
        f.write('test_checksum')
    os.close(fd)
    os.rename(tmp_path, test_file)

    assert checksum(test_file) == '7b79c7b02a7b0f0e51fb7a8edb5d5c3e5f5f5e5d'

# Generated at 2022-06-21 08:26:14.657846
# Unit test for function md5
def test_md5():
    md5_test_file = "test/unit/utils/md5sum_data/hello"
    assert md5(md5_test_file) == "65926f23cbb0b07e1be0fcd3bebc7aca"

# Generated at 2022-06-21 08:26:16.518992
# Unit test for function md5
def test_md5():
    assert(md5("/bin/ls") == '3a7bd3e2360a3d29eea436fcfb7e44c7')



# Generated at 2022-06-21 08:26:18.561815
# Unit test for function md5
def test_md5():
    assert md5("/dev/null") == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-21 08:26:29.543867
# Unit test for function checksum_s
def test_checksum_s():
    ''' checksum_s should fail without a string parameter '''
    try:
        checksum_s(None)
        assert False, 'Failed to catch "checksum_s" without string parameter'
    except TypeError:
        pass

    ''' checksum_s should fail without a hash_func parameter '''
    try:
        checksum_s('str', None)
        assert False, 'Failed to catch "checksum_s" without hash_func parameter'
    except TypeError:
        pass

    ''' checksum_s should pass with valid parameters '''
    data='asdf'
    ret=checksum_s(data)
    assert type(ret) == str
    assert ret == '361059058b285e98de8c321f6189c5e680173c9e'


# Generated at 2022-06-21 08:26:32.154040
# Unit test for function checksum_s
def test_checksum_s():
   assert checksum_s("Hello there", sha1) == "9e1f66db7c8df622aad1eaeb302594ad0c2affb8"

# Generated at 2022-06-21 08:26:34.765580
# Unit test for function md5
def test_md5():
    TEXT = "foobar"
    assert md5s(TEXT) == "3858f62230ac3c915f300c664312c63f"



# Generated at 2022-06-21 08:26:41.039950
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    data = '0123456789ABCDEF'

    # Test against the expected values
    if md5s(data) != 'f6fb8d6c5a17ef5a6a886d6ef844f923':
        raise ValueError('md5s() failed')
    if md5(__file__) != '8f8e2a9d7768da3c96d8d1b623f06e36':
        raise ValueError('md5() failed')

    # Test for platform-specific number of bits for _md5.digest_size
    if _md5().digest_size != 16:
        raise ValueError('_md5().digest_size failed')

    # Test for FI

# Generated at 2022-06-21 08:26:52.972717
# Unit test for function md5
def test_md5():
    import os

    test_file = "unit_test_file_%s" % md5s(os.urandom(64))
    f = open(test_file, 'w')
    f.write('Buster Keaton')
    f.close()
    test_file_md5 = md5(test_file)
    os.remove(test_file)
    assert test_file_md5 == 'b29823d7a05c552b91288b2a97b35ee7'

    test_string = 'Buster Keaton'
    test_string_md5 = md5s(test_string)
    assert test_string_md5 == 'b29823d7a05c552b91288b2a97b35ee7'


if __name__ == '__main__':
    test_md

# Generated at 2022-06-21 08:26:54.798413
# Unit test for function md5
def test_md5():
    assert md5('/tmp/test') == secure_hash('/tmp/test', _md5)



# Generated at 2022-06-21 08:27:00.524874
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-21 08:27:04.380799
# Unit test for function md5
def test_md5():
    ''' '''

    filename = './test_utils.py'
    md5_value = md5(filename)
    assert md5_value == '3bf3d1943d83d6e913716062c5a68a19'


# Generated at 2022-06-21 08:27:12.386002
# Unit test for function checksum
def test_checksum():
    s = 'hello world'
    assert(checksum_s(s)=='2aae6c35c94fcfb415dbe95f408b9ce91ee846ed')

    f = 'lib/ansible/module_utils/basic.py'
    assert(checksum(f)=='bff7cbb32c9d9408aadf62b20ad7d8ba04f7a1f0')


# Generated at 2022-06-21 08:27:22.040984
# Unit test for function checksum_s
def test_checksum_s():
    from ansible.module_utils.basic import AnsibleModule

    module_args = dict()
    module_args['data'] = 'hello'
    module_args['checksum_algorithm'] = 'sha1'
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)
    result = secure_hash_s(module.params['data'])
    assert result == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

    module_args['checksum_algorithm'] = 'sha256'
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)
    result = secure_hash_s(module.params['data'])

# Generated at 2022-06-21 08:27:34.346600
# Unit test for function checksum_s
def test_checksum_s():
    import unittest
    import sys

    class TestChecksumS(unittest.TestCase):

        def test_returns_none_for_nonexistent(self):
            res = checksum_s(None)
            self.assertIsNone(res)

        def test_returns_sha1_on_empty_string(self):
            res = checksum_s('')
            self.assertEqual(res, 'da39a3ee5e6b4b0d3255bfef95601890afd80709')

        def test_returns_sha1_on_strings(self):
            res = checksum_s('hello')
            self.assertEqual(res, 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d')


# Generated at 2022-06-21 08:27:37.780188
# Unit test for function md5
def test_md5():
    ''' md5.py: md5 test'''
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-21 08:27:40.155230
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-21 08:27:45.414488
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', _md5) == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-21 08:27:48.428172
# Unit test for function md5
def test_md5():
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/bin/ls') == 'f7030c24a6d83a59b3912ebb60594d76'


# Generated at 2022-06-21 08:28:00.022992
# Unit test for function checksum
def test_checksum():
    ''' test_checksum '''

    # Simple string
    test_string = "abc"
    assert checksum_s(test_string) == "a9993e364706816aba3e25717850c26c9cd0d89d"

    # Unicode string
    test_string = u"abc"
    assert checksum_s(test_string) == "a9993e364706816aba3e25717850c26c9cd0d89d"

    # Integer
    test_string = 123
    assert checksum_s(test_string) == "a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3"

    # List
    test_string = [1, 2, 3]
   

# Generated at 2022-06-21 08:28:12.344592
# Unit test for function md5
def test_md5():
    test_file = 'data/test_file'
    out = "7989a3b58d3b6e8b76f83801f0d6a1a6"

    if os.path.exists(test_file):
        checksum_out = md5(test_file)
        if checksum_out == "7989a3b58d3b6e8b76f83801f0d6a1a6":
            print("Unit test for function md5: Successful")
            print("Expected and Returned output: %s" % out)
        else:
            print("Unit test for function md5 Failed")
            print("Expected output: %s" % out)
            print("Returned output: %s" % checksum_out)

# Generated at 2022-06-21 08:28:24.134724
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    TEST_FILE_PATH = "test"
    TEST_FILE_CHECKSUM = "1234"
    TEST_STRING = "test string"
    TEST_STRING_CHECKSUM = "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"

    @patch('ansible.module_utils.checksum.secure_hash')
    def call_checksum(mock_secure_hash, test_data):
        checksum(test_data)
        assert mock_secure_hash.called

    class TestModuleUtilsChecksum(unittest.TestCase):

        def setUp(self):
            self.test_data = None

# Generated at 2022-06-21 08:28:26.142136
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == checksum("/bin/ls")



# Generated at 2022-06-21 08:28:32.317108
# Unit test for function md5s
def test_md5s():
    import hashlib
    if not hasattr(hashlib, 'md5'):
        return

    teststr = 'hello'
    teststr2 = 'world'
    md5s1 = md5s(teststr)
    md5s2 = md5s(teststr2)
    md5pyth = hashlib.md5(teststr).hexdigest()
    assert(md5s1 == md5pyth)
    assert(md5s2 != md5s1)


# Generated at 2022-06-21 08:28:37.524139
# Unit test for function md5
def test_md5():
    assert md5("/bin/cat") == "7926bcecf2c2c05f863c3bebe46a3a9a"

    # reuse the filehandle to check resetting of the object
    with open("/bin/cat", "rb") as f:
        assert md5(f) == "7926bcecf2c2c05f863c3bebe46a3a9a"
        assert md5(f) == "7926bcecf2c2c05f863c3bebe46a3a9a"

    # now try a relative file
    assert md5("utils/module_docs_fragments") == "9e9cf69c08b7603548f6a1d21ea8f146"


# Generated at 2022-06-21 08:28:41.760688
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    if md5s('test') != '098f6bcd4621d373cade4e832627b4f6':
        raise Exception('md5s produced wrong checksum')


# Generated at 2022-06-21 08:28:48.728136
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum_s('abc', hash_func=sha1) == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum_s('abc', hash_func=_md5) == '900150983cd24fb0d6963f7d28e17f72'


# Generated at 2022-06-21 08:28:56.426118
# Unit test for function md5
def test_md5():
    filename = 'test/files/test_hash.txt'
    md5 = 'f0ef7081fc3c35d4dde6b3d6f3930b07'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5(filename) == md5
    print("Unittests for hash succeeded")

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-21 08:29:00.069828
# Unit test for function checksum_s
def test_checksum_s():
    input = "hello world"
    output = "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"
    assert checksum_s(input) == output


# Generated at 2022-06-21 08:29:06.731110
# Unit test for function checksum
def test_checksum():
    assert secure_hash_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert secure_hash('/etc/motd') == secure_hash('/etc/motd')
    assert secure_hash('/etc/motd') != secure_hash('/etc/hosts')
    assert secure_hash('/this/file/surely/does/not/exist') is None
    assert secure_hash('/') is None


# Generated at 2022-06-21 08:29:13.728785
# Unit test for function md5s
def test_md5s():
    print(md5s(b'a1b2c3'))
    print(md5s(b'abc'))
    print(md5s(b'a1b2c3') == md5s(b'abc'))



# Generated at 2022-06-21 08:29:18.251419
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"
    assert checksum_s(u"foo") == "acbd18db4cc2f85cedef654fccc4a4d8"


# Generated at 2022-06-21 08:29:22.270885
# Unit test for function md5s
def test_md5s():
  assert md5s(b"abcdefghijklmnopqrstuvwxyz") == 'c3fcd3d76192e4007dfb496cca67e13b'



# Generated at 2022-06-21 08:29:24.233057
# Unit test for function checksum
def test_checksum():
    assert checksum_s("Hello World") == 'e59ff97941044f85df5297e1c302d260'



# Generated at 2022-06-21 08:29:29.035360
# Unit test for function md5s
def test_md5s():
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'

# Generated at 2022-06-21 08:29:31.931293
# Unit test for function md5
def test_md5():
    # Output of shell command: echo -n 123456 | md5sum
    assert(md5s('123456') == 'e10adc3949ba59abbe56e057f20f883e')


# Generated at 2022-06-21 08:29:36.944934
# Unit test for function md5
def test_md5():
    ''' primitive test for md5 function '''
    import tempfile
    tf = tempfile.NamedTemporaryFile(delete=False)
    try:
        tf.write('Test for md5 function')
        tf.close()

        # check if the md5 value returned is as expected
        assert(md5(tf.name) == 'bbe898f8eec0b7c43555dd66d2e8c8f0')
    finally:
        os.unlink(tf.name)

# Generated at 2022-06-21 08:29:43.678594
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'


# Generated at 2022-06-21 08:29:47.765687
# Unit test for function checksum
def test_checksum():
    assert checksum('test/files/chars', sha1) == '8c8f1b7a2efd2bf3'
    assert checksum_s('ansible', sha1) == '852fbbcd7c7e8980f6edf5976c04e46e'

# Generated at 2022-06-21 08:29:58.044774
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    test_data = 'This is my test data'
    md5_dig = md5s(test_data)
    assert(len(md5_dig) == 32)

    # test with unicode characters
    test_data_unicode = u'\u2713'
    md5_dig = md5s(test_data_unicode)
    assert(len(md5_dig) == 32)


#
# This is a set of tests to ensure various checksum functions work correctly
#


# Generated at 2022-06-21 08:30:03.090286
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == checksum_s('/bin/ls')


# Generated at 2022-06-21 08:30:10.801708
# Unit test for function checksum
def test_checksum():
    import commands
    (status, output) = commands.getstatusoutput('find ../ -type f | egrep -v "(.git|.tox|.eggs|.ropeproject)" | xargs grep -l "def checksum" | xargs grep -L "md5"')
    if status != 0 and output != "":
        print("Please update the modules and scripts with module shim to use checksum instead of md5,hashlib,md5_local,md5_local_file,md5_s, or md5_s_local")
        assert False

# Generated at 2022-06-21 08:30:14.587543
# Unit test for function md5
def test_md5():
    # Normal use
    md5("lib/ansible/module_utils/checksumming.py")

    # Directory that doesn't exist
    if not md5("/tmp/this/is/a/directory/that/does/not/exist"):
        print("Test Success")

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-21 08:30:25.726109
# Unit test for function md5
def test_md5():
    import unittest
    import tempfile
    import shutil
    import os

    class TestMd5(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test.txt')
            f = open(self.test_file, 'wt')
            f.write('sometext')
            f.close()

        def test_md5(self):
            self.assertEqual(md5(self.test_file), 'f5730c2efa6b8d6b96a6a09a6e49e6f8')

        def tearDown(self):
            shutil.rmtree(self.test_dir)

    unittest.main()

# Generated at 2022-06-21 08:30:28.326214
# Unit test for function md5s
def test_md5s():
    assert md5s("foo") == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-21 08:30:30.365687
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-21 08:30:32.935833
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("Hello World") == "b10a8db164e0754105b7a99be72e3fe5"



# Generated at 2022-06-21 08:30:40.021980
# Unit test for function md5
def test_md5():
    # Test when file exists
    assert md5("/etc/passwd") == "bea9796131877f4d4cc4c4af1b51c4f4"
    # Test when file does not exists
    assert md5("/etc/passwd2") is None
    # Test when file is a directory
    assert md5("/etc") is None
    # Test when parameter is None
    try:
        md5(None)
    except Exception as e:
        assert isinstance(e, AnsibleError)
        assert to_bytes(str(e)) == to_bytes("Unable to calculate the checksum of None.  Perhaps it is a directory.")

# Generated at 2022-06-21 08:30:44.886919
# Unit test for function checksum_s
def test_checksum_s():
    data1 = "foo"
    expected_result = '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    # Ensure string data returns expected result
    assert checksum_s(data1) == expected_result


# Generated at 2022-06-21 08:30:53.958569
# Unit test for function checksum
def test_checksum():
    # Generate a randome file and hash it
    # How to write a string to a file in Python?
    import os
    import stat
    import tempfile
    temp = tempfile.NamedTemporaryFile()
    print(temp.name)
    print(temp)
    try:
        temp.write('abc'.encode('utf-8'))
        temp.seek(0)
        print(temp.read())
    finally:
        # Automatically cleans up the file
        temp.close()
    # hash the file
    print(checksum(temp.name))


# Generated at 2022-06-21 08:31:07.433624
# Unit test for function md5
def test_md5():
    import tempfile

    test_string = 'Ansible unittest text string'
    (handle, filename) = tempfile.mkstemp()

    # write out test string to temp file
    os.write(handle, to_bytes(test_string))
    os.close(handle)

    # test md5 function
    csum = md5s(test_string)
    assert csum == "8c91f6e63b52c70bf3a5a3da8b827de3"

    # test md5 file function
    assert md5(filename) == csum

    # clean up
    os.unlink(filename)



# Generated at 2022-06-21 08:31:12.650182
# Unit test for function md5
def test_md5():
    # Create the file to hash
    data = 's3cret'

    # Hash the file
    hashed = md5s(data)

    print('SHA1:   ', checksum_s(data))
    print('MD5:    ', hashed)

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-21 08:31:15.189188
# Unit test for function md5s
def test_md5s():
    output_expected = 'c1a56f14aad2b8e887c71f218210980e'
    output = md5s('I wanted to be tested!')
    assert output == output_expected

# Generated at 2022-06-21 08:31:19.989166
# Unit test for function md5s
def test_md5s():
    assert md5s('abcd') == 'e2fc714c4727ee9395f324cd2e7f331f'
    assert md5s('abcd') == 'e2fc714c4727ee9395f324cd2e7f331f'

# Generated at 2022-06-21 08:31:25.506559
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    input_data = 'hello'
    expected_value = '5d41402abc4b2a76b9719d911017c592'
    calculated_value = md5s(input_data)
    assert calculated_value == expected_value

# Generated at 2022-06-21 08:31:31.539114
# Unit test for function md5s
def test_md5s():
    '''unit test for md5s'''
    # md5s of 'test'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    # md5s of 'testing'
    assert md5s('testing') == 'ae2b1fca515949e5d54fb22b8ed95575'


# Generated at 2022-06-21 08:31:41.181534
# Unit test for function checksum
def test_checksum():
    assert checksum('test/files/chars', hash_func=sha1) == 'fe65a8a5bf5e5b5ef5a14a5b8d29dc07c5f5de5e'
    assert checksum('test/files/chars') == 'fe65a8a5bf5e5b5ef5a14a5b8d29dc07c5f5de5e'
    assert checksum('test/files/digits', hash_func=sha1) == '9bc22678b2afb2a0b2d0b8a98b8a1a1b1f0b4b9d'

# Generated at 2022-06-21 08:31:44.953106
# Unit test for function checksum_s
def test_checksum_s():

    if secure_hash_s("hello") != "5d41402abc4b2a76b9719d911017c592":
        raise ValueError("Failed test for hello")
    if secure_hash_s("HELLO") != "f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0":
        raise ValueError("Failed test for HELLO")
    if secure_hash_s("hello", _md5) != "5d41402abc4b2a76b9719d911017c592":
        raise ValueError("Failed test for md5 hello")

# Generated at 2022-06-21 08:31:56.164530
# Unit test for function checksum
def test_checksum():
    from ansible.module_utils import basic
    import unittest
    import tempfile

    class TestChecksum(unittest.TestCase):
        command = 'echo hi'
        script = """#!/bin/sh
echo 1
echo 2
echo 3
"""

        def test_checksum_s(self):
            data = basic.AnsibleModule(argument_spec={}).run_command(self.command, check_rc=False)[1]
            assert checksum_s(data) == '717c434dbce2f1e85f51d097d8e91cb0f7eef9d3'

        def test_checksum(self):
            (fd, name) = tempfile.mkstemp()
            os.write(fd, self.script)
            os.close(fd)
           

# Generated at 2022-06-21 08:31:58.482773
# Unit test for function md5
def test_md5():
    # We're just testing that it runs without throwing errors
    md5("/etc/passwd")
    print("md5 test passed")


# Generated at 2022-06-21 08:32:09.187800
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s("hello world") == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    # Non-ascii test.  The secure_hash methods encode as utf8 before hashing,
    # but the md5 module does not.  So we need to give non-ascii chars in their
    # encoded (utf8) form
    assert md5s("\xc3\xa0") == 'f6bbf1a0f74dd88b81250966d86d9c4f'
