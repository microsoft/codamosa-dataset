

# Generated at 2022-06-21 08:22:11.148965
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-21 08:22:17.811192
# Unit test for function checksum_s
def test_checksum_s():
    ''' test_checksum_s() - verify function checksum_s works '''
    data = "this is a test"
    expected = "f45c89c8e9d5b04a3b7a6d64d9e8d985b00ef944"
    result = checksum_s(data)
    assert result == expected, "%s != %s" % (result, expected)

# Generated at 2022-06-21 08:22:22.612166
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('foo\nbar') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-21 08:22:27.590934
# Unit test for function md5s
def test_md5s():
    if _md5:
        testdata = "Python rocks!"
        assert md5s(testdata) == "f9e9a2a23a5a1f18c4065b071a788e0f"
    else:
        try:
            md5s('testing')
        except ValueError:
            pass



# Generated at 2022-06-21 08:22:34.608062
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s(None) is None
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('a') == '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8'
    assert checksum_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum_s('message digest') == 'c12252ceda8be8994d5fa0290a47231c1d16aae3'

# Generated at 2022-06-21 08:22:43.225504
# Unit test for function md5
def test_md5():
    # Create the test file in ANSIBLE_TEST_DATA_ROOT directory
    filename = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'testdata', 'ANSIBLE_TEST_DATA_ROOT', 'test')
    m = _md5()
    ansible_md5 = m.hexdigest()
    assert ansible_md5 == md5(filename)


# Backwards compat aliases
md5sum = md5
md5sum_s = md5s

# Generated at 2022-06-21 08:22:46.766277
# Unit test for function checksum
def test_checksum():
    assert checksum('test/units/utils/test_utils.py') == '1f7d865d3b3228c679024d9c8d7b268a570f0080'


# Generated at 2022-06-21 08:22:50.377184
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-21 08:22:54.294168
# Unit test for function md5s
def test_md5s():
    ''' md5s unit test'''
    if not _md5:
        print('MD5 not available.  Possibly running in FIPS mode')
        return
    else:
        print('md5s test: %s' % md5s('god'))


# Generated at 2022-06-21 08:22:58.537131
# Unit test for function md5
def test_md5():
    '''
    Test suite for md5
    '''
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(),
        )
    )
    expected_md5 = 'efb87a8a6b903c4b4cc4f4c8f8712a21'
    output = md5(module.params['path'])
    if output != expected_md5:
        module.fail_json(msg='Output should have been %s but was %s' % (expected_md5, output))

#
# End of backwards compat functions
#

# Generated at 2022-06-21 08:23:06.774470
# Unit test for function md5
def test_md5():
    # Generate checksum for the existing file
    file_checksum = md5s("Hello World")
    assert isinstance(file_checksum, basestring)
    assert file_checksum == md5("test/utils/test_md5.py")
    assert file_checksum == "b10a8db164e0754105b7a99be72e3fe5"

# Generated at 2022-06-21 08:23:11.613135
# Unit test for function checksum
def test_checksum():
    import tempfile
    tf = tempfile.NamedTemporaryFile()
    tf.write("This is a test")
    tf.flush()
    h = secure_hash(tf.name)
    assert h is not None
    assert h == "b8a966ae9ad1cfbcb4839c8f8e83c4d4cd4d06c4"

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:23:18.515085
# Unit test for function md5s
def test_md5s():
    assert md5s("") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5s("Hello World") == "6cd3556deb0da54bca060b4c39479839"
    assert md5s("One small step for man, one giant leap for mankind.") == "4caf24bb4c408f52130a3b7cbe86e13f"

# Generated at 2022-06-21 08:23:25.031503
# Unit test for function checksum_s
def test_checksum_s():
    # test environment and expected value
    checksum_s_value = secure_hash_s("hello world")
    if 'b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9' != checksum_s_value:
        print("checksum_s: failed")


# Generated at 2022-06-21 08:23:31.921143
# Unit test for function checksum
def test_checksum():
    # create empty file
    (fd, fname) = tempfile.mkstemp()
    os.close(fd)
    file = open(fname, "w")
    file.close()

    # check if file is there and empty
    assert os.path.exists(fname)
    assert os.path.getsize(fname) == 0

    # get checksum
    chksum = checksum(fname)
    print(chksum)

    # check if checksum is there
    assert chksum is not None

    # remove file
    os.remove(fname)


# Generated at 2022-06-21 08:23:43.620003
# Unit test for function md5
def test_md5():
    test_string = 'test string'
    test_string_md5_hash = '21c2c6d8a40f8fbbe98ad5fe5d6df5aa'

    test_file = 'test_file'
    test_file_contents = 'test file contents\n'
    test_file_md5_hash = 'b9d24fee3c8c37ec3ebb42bc1d0051cc'

    # Test string
    string_result = md5s(test_string)
    assert test_string_md5_hash == string_result

    # Test file
    # Create a test file
    file_object = open(test_file, 'w')
    file_object.write(test_file_contents)
    file_object.close()


# Generated at 2022-06-21 08:23:54.394335
# Unit test for function checksum_s
def test_checksum_s():
    '''
    Ansible checksum module tests
    '''

    # Correct string checksum
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    # Correct unicode checksum
    assert checksum_s(u'hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    # Malformed unicode string
    assert checksum_s(u'\xfe\xff') == '0000000000000000000000000000000000000000'

    # Malformed utf-8 string
    assert checksum_s('\xfe\xff') == '0000000000000000000000000000000000000000'

    # Malformed unicode string in strict mode

# Generated at 2022-06-21 08:24:05.238453
# Unit test for function checksum_s
def test_checksum_s():
    import os
    import tempfile
    td = tempfile.mkdtemp()
    file_data = 'a' * 100
    file_path = os.path.join(td, 'file1')

    with open(file_path, 'wb') as file:
        file.write(file_data)

    # test defaults to sha1
    assert checksum_s(file_data) == secure_hash_s(file_data)
    # test sha1
    assert checksum_s(file_data, hash_func=sha1) == secure_hash_s(file_data, hash_func=sha1)
    # test md5
    assert checksum_s(file_data, hash_func=_md5) == secure_hash_s(file_data, hash_func=_md5)

    os.remove

# Generated at 2022-06-21 08:24:07.635141
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s("foobar") == _md5("foobar").hexdigest()


# Generated at 2022-06-21 08:24:11.394429
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s(b'hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-21 08:24:19.637378
# Unit test for function md5
def test_md5():
    import tempfile

    fd, path = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    try:
        f.write('foo')
        f.close()
        assert md5(path) == 'acbd18db4cc2f85cedef654fccc4a4d8'
    finally:
        os.unlink(path)



# Generated at 2022-06-21 08:24:22.151336
# Unit test for function md5
def test_md5():
    path = __file__
    expected = '6dffb0aecb2da8b1ead9f38e7c068b65'
    assert md5(path) == expected

# Generated at 2022-06-21 08:24:25.441456
# Unit test for function md5
def test_md5():
    return md5('lib/ansible/modules/core/copy.py') == 'd646c0f0f4e2e475ce812a8c4b251af1'


# Generated at 2022-06-21 08:24:32.259503
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '4b3169b31e48a1a4f6a00cba02f98e2f'
    assert md5('/bin/cat') == '8cb99b874b8656b6a5e6a5e9f9d5a534'
    assert md5('/bin/does-not-exist') is None
    assert md5('/bin/') is None

# Generated at 2022-06-21 08:24:34.820200
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello world") == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-21 08:24:45.291663
# Unit test for function checksum_s
def test_checksum_s():
    # Test checksum_s with non-unicode input (string)
    # Test for no change when passing in "hello"
    assert checksum_s('hello') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'

    # Test for no change when passing in b"hello"
    assert checksum_s(b"hello") == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'

    # Test for changes when passing in b"Hello" (note capitalization)
    assert checksum_s(b"Hello") == '8b1a9953c4611296a827abf8c47804d7'

    # Test for changes when passing in "Hello" (note

# Generated at 2022-06-21 08:24:51.291836
# Unit test for function md5
def test_md5():
    print("**************  Working Directory = %s  ********************************" % os.getcwd())
    print("**************  Running 'test_md5'  ***********************************")

    filename = "testHash.txt"
    checksum_value = "8e6f4b6e4aec38a08626b8c6b3676e96"
    print("**************  About to open '%s' for MD5 checksum *******************" % filename)
    print("**************  Expected MD5 checksum value is '%s' *******************" % checksum_value)
    print("**************  Calculated MD5 checksum value is '%s' ******************" % md5(filename))


# Generated at 2022-06-21 08:25:00.673617
# Unit test for function md5
def test_md5():
    assert md5("/tmp/does-not-exist") is None
    with open("/tmp/hashes.txt", "wb") as f:
        f.write("""0cc175b9c0f1b6a831c399e269772661 *

e9c1e7dee713d8e50fb577a752e623a4 *README.md
80b2e9c44f88d7f1c8e1ad3b35dc01bd *ansible/playbook/__init__.py
""")
    assert md5("/tmp/hashes.txt") == "0cc175b9c0f1b6a831c399e269772661"

# Generated at 2022-06-21 08:25:08.790478
# Unit test for function checksum_s
def test_checksum_s():
    import re
    import unittest
    import sys

    class TestHashes(unittest.TestCase):

        def test_check_sum_s(self):
            self.assertTrue(re.match('^[0-9a-f]{40}$', checksum_s('test')))
            self.assertEqual(checksum_s('test'), secure_hash_s('test', _md5))
            self.assertEqual(checksum_s('test'), md5s('test'))

    # make the test verbose
    suite = unittest.TestLoader().loadTestsFromTestCase(TestHashes)
    unittest.TextTestRunner(verbosity=2).run(suite)

if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-21 08:25:11.543540
# Unit test for function md5s
def test_md5s():
    if _md5:
        with open('/proc/uptime', 'rb') as f:
            assert md5s(f.read()) == "bcdf6f88e4775d41fc5f5e2702c008ff"



# Generated at 2022-06-21 08:25:22.836995
# Unit test for function checksum_s
def test_checksum_s():
    ''' unit test for checksum_s '''

    ret = checksum_s('abc')
    assert ret == 'a9993e364706816aba3e25717850c26c9cd0d89d'

    ret = checksum_s('abc\n')
    assert ret == '0cc175b9c0f1b6a831c399e269772661'

    ret = checksum_s('blah')
    assert ret == 'dfcd8016b00a52c938b89ff8d66f0e2b'

    ret = checksum_s('0')
    assert ret == 'cfcd208495d565ef66e7dff9f98764da'

# Generated at 2022-06-21 08:25:34.997867
# Unit test for function checksum
def test_checksum():
    import tempfile
    tmpf = tempfile.NamedTemporaryFile(delete=False)
    try:
        tmpf.write(b'test')
        tmpf.close()

        assert checksum(tmpf.name) == checksum_s('test')
        assert checksum('SHA_error_file') is None
    finally:
        os.unlink(tmpf.name)

    # Check backwards compat md5s
    try:
        assert md5s('test') == checksum_s('test')
        assert md5(tmpf.name) == checksum_s('test')
        assert md5('MD5_error_file') is None
    finally:
        os.unlink(tmpf.name)

    print("Successfully completed checksum tests")


if __name__ == '__main__':
    test

# Generated at 2022-06-21 08:25:43.210912
# Unit test for function checksum
def test_checksum():
    # Create a temporary file
    import tempfile
    tf = tempfile.NamedTemporaryFile()
    # Write data to the temporary file
    tf.write('Hello World!\n')
    # Close the temporary file so we can get a checksum
    tf.close()
    # Get the checksum of the temporary file
    tf_sha1 = checksum(tf.name)
    # Verify the checksum
    assert tf_sha1 == "0a0a9f2a6772942557ab5355d76af442f8f65e01", "Invalid checksum"

# Generated at 2022-06-21 08:25:49.048937
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    test_data = b'Hello World'
    assert md5s(test_data) == '3e25960a79dbc69b674cd4ec67a72c62'
    assert md5s(None) == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-21 08:25:52.438939
# Unit test for function checksum_s
def test_checksum_s():
    s = "abcd"
    cs = secure_hash_s(s)
    assert (cs == "e2fc714c4727ee9395f324cd2e7f331f")


# Generated at 2022-06-21 08:25:59.871731
# Unit test for function md5s
def test_md5s():
    assert md5s('asdf') == '912ec803b2ce49e4a541068d495ab570'

try:
    from sha import sha as _sha  # for python2.4
except ImportError:
    # already in python 2.6
    from hashlib import sha as _sha

# python 2.4 does not have sha modules, so we need to use md5
if _sha:
    def shasum(data):
        return secure_hash_s(data, _sha)
    def shasum_s(data):
        return secure_hash_s(data, _sha)
    def sha256sum(data):
        return secure_hash_s(data, sha256)

# Generated at 2022-06-21 08:26:04.981995
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    test_data = 'The quick brown fox jumped over the lazy dog'
    test_hash = '9e107d9d372bb6826bd81d3542a419d6'
    assert test_hash == md5s(test_data)


# Generated at 2022-06-21 08:26:07.526301
# Unit test for function md5s
def test_md5s():
    expected = '44e5f1db96e30f5d5d5b5b569e7e8c14'
    result = md5s('test')
    assert result == expected


# Generated at 2022-06-21 08:26:10.560000
# Unit test for function md5s
def test_md5s():
    assert(len(md5s('abc123')) == 32)
    assert(md5s('abc123') == 'e99a18c428cb38d5f260853678922e03')


# Generated at 2022-06-21 08:26:14.928382
# Unit test for function md5s
def test_md5s():
    import unittest

    class Test(unittest.TestCase):
        def test_md5s(self):
            self.assertEqual(md5s(''), 'd41d8cd98f00b204e9800998ecf8427e')

    unittest.main()


# Generated at 2022-06-21 08:26:20.817477
# Unit test for function checksum_s
def test_checksum_s():
    res = checksum_s('test')
    assert res == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'

# Generated at 2022-06-21 08:26:25.011750
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s("a string") != "7d865e959b2466918c9863afca942d0fb89d7c9ac0c99bafc3749504ded97730":
        raise Exception("secure_hash_s test failed")

# Generated at 2022-06-21 08:26:35.438016
# Unit test for function md5s
def test_md5s():
    from io import BytesIO
    from os import urandom

    s = md5s(urandom(1024))
    assert s is not None, "No value returned"
    assert len(s) == 32, "Incorrect value length"

    # value is always lowercase, but test both cases
    s = md5s(urandom(1024)).upper()
    assert s is not None, "No value returned"
    assert len(s) == 32, "Incorrect value length"

    # value is always lowercase, but test both cases
    s = md5s(urandom(1024).upper())
    assert s is not None, "No value returned"
    assert len(s) == 32, "Incorrect value length"

    # check file object
    s = md5s(BytesIO(urandom(1024)))
    assert s is not None

# Generated at 2022-06-21 08:26:38.673550
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('Hello World!') == '3e25960a79dbc69b674cd4ec67a72c62'
        assert md5s('Hello World!\n') == '40bd001563085fc35165329ea1ff5c5ecbdbbeef'



# Generated at 2022-06-21 08:26:50.525453
# Unit test for function checksum
def test_checksum():
    import unittest

    class FakeModule:
        def __init__(self, *args, **kwargs):
            pass

        def fail_json(self, *args, **kwargs):
            raise AnsibleError("fail_json called")

        def run_command(self, *args, **kwargs):
            return 0, "fake_file_contents", ""

    module = FakeModule()

    with open("fake_file_1", "w") as fake_file_1:
        fake_file_1.write("fake_file_contents")

    with open("fake_file_2", "w") as fake_file_2:
        fake_file_2.write("fake_file_contents_different")

    class MyTests(unittest.TestCase):
        def setUp(self):
            pass



# Generated at 2022-06-21 08:27:00.069337
# Unit test for function checksum
def test_checksum():

    # THis test is based on ShellModule.checksum()
    # IT's not unit test for this module, it's unit test for the function checksum()
    # So the coverage will not show up
    # TODO: think about better way to test this function
    import time
    import shutil
    from tempfile import NamedTemporaryFile, mkdtemp
    from ansible.compat.six import StringIO
    from ansible.module_utils.basic import no_log_values, AnsibleModule

    WORKDIR = mkdtemp()


# Generated at 2022-06-21 08:27:03.319045
# Unit test for function checksum_s
def test_checksum_s():
    data = "i am data"
    assert checksum_s(data) == "48fae4d619d95c603663b81f9a919d55fda65a84"


# Generated at 2022-06-21 08:27:04.488145
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"



# Generated at 2022-06-21 08:27:16.926101
# Unit test for function md5
def test_md5():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    #test file exists
    test_file = "/usr/bin/head"
    assert(md5(test_file) == checksum(test_file))

    #test file doesn't exist
    test_file = "/usr/bin/i_am_not_a_file"
    assert(md5(test_file) == None)

    #test directory
    test_file = "/usr/bin"
    try:
        md5(test_file)
        assert(False)
    except AnsibleError:
        pass

    #test file read error
    test_file = "/I/am/not/a/directory/file"
    test_module = AnsibleModule(argument_spec={})

# Generated at 2022-06-21 08:27:21.635967
# Unit test for function checksum_s
def test_checksum_s():
    from ansible.module_utils.six import PY3
    data = "hello world"
    expected = "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"
    if PY3:
        data = data.encode('utf-8')
    assert expected == checksum_s(data)



# Generated at 2022-06-21 08:27:36.572925
# Unit test for function checksum
def test_checksum():
    import unittest
    import __builtin__
    import os
    import tempfile

    class TestModuleUtilsFunctions(unittest.TestCase):
        def setUp(self):
            self.paths = [
                './testfile1',
                './testfile2',
                './testdir1'
            ]

        def tearDown(self):
            for p in self.paths:
                if os.path.exists(p):
                    os.unlink(p)
                if os.path.isdir(p):
                    os.rmdir(p)

        def test_checksum(self):
            # prepare test data
            open('./testfile1', 'w').close()
            open('./testfile2', 'w').close()

# Generated at 2022-06-21 08:27:43.391268
# Unit test for function checksum
def test_checksum():

    filename = "test/data/checksum.txt"
    checksum1 = checksum(filename)
    checksum2 = "5163378c6822d1327c52fbe1563e73b7e9fb1fef"
    if checksum1 == checksum2:
        print("checksum: Success")
    else:
        print("checksum: Failed")
        print("checksum1 = " + checksum1)
        print("checksum2 = " + checksum2)



# Generated at 2022-06-21 08:27:47.942050
# Unit test for function checksum_s
def test_checksum_s():
    test_str = 'test string'
    test_sum = secure_hash_s(test_str)
    print("Test sum is: %s" % (test_sum))
    assert(test_sum == "0a50261ebd1a390fed2bf326f2673c145582a6342d523204973d0219c7d4b096")
    print("Test succeeded")


# Generated at 2022-06-21 08:27:51.875841
# Unit test for function md5s
def test_md5s():
    # Test for md5s function
    data_str = "1234567890"
    md5_str = "e807f1fcf82d132f9bb018ca6738a19f"
    assert md5s(data_str) == md5_str

# Generated at 2022-06-21 08:27:57.174250
# Unit test for function checksum_s
def test_checksum_s():
    str = "abc"
    print(checksum_s(str))
    str = "a\nb"
    # print(checksum_s(str))
    # str = u"a\nb"
    # print(checksum_s(str))

if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-21 08:28:01.520575
# Unit test for function checksum
def test_checksum():
    testfile = '../../test/files/testfile'
    actual = checksum(testfile)
    expected = 'b7f93b1d34f6c44971caa9b9a2b8ad3d3a63b78d'
    assert actual == expected

# Generated at 2022-06-21 08:28:10.823019
# Unit test for function checksum
def test_checksum():
    test_filename = os.path.join(os.path.dirname(__file__), 'test_utils.py')
    test_string = 'Hello World!'

    expected_checksum = '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    expected_md5s = '659c4bfa5756e007a8da9c0031b3d514'

    assert checksum(test_filename) == expected_checksum
    assert checksum_s(test_string) == expected_checksum
    assert md5(test_filename) == expected_md5s
    assert md5s(test_string) == expected_md5s

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:28:21.328338
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello world") == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"
    assert checksum_s("hello world", _md5) == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    # python-2.4 and FIPS-140 doesn't allow md5 in FIPS mode
    try:
        checksum_s("hello world", _md5)
    except ValueError:
        pass
    except:
        raise AssertionError()


if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-21 08:28:24.772780
# Unit test for function checksum_s
def test_checksum_s():
    s = checksum_s('')
    assert len(s) == 40
    assert s == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'

# Generated at 2022-06-21 08:28:33.892856
# Unit test for function checksum
def test_checksum():
    ''' test_checksum of local file, None if file is not present or a directory. '''

    import filecmp

    file_name = "./test_checksum.txt"
    file_name_copy = file_name + '.copy'
    if os.path.exists(file_name_copy):
        os.remove(file_name_copy)

# Generated at 2022-06-21 08:28:47.569893
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(' ') == '7215ee9c7d9dc229d2921a40e899ec5f'
    assert md5s(' ' * 10) == 'f6cde2c043de9fca6630f2d3c9cbc5d4'
    assert md5s('The quick brown fox jumps over the lazy dog') == '9e107d9d372bb6826bd81d3542a419d6'
    assert md5s('The quick brown fox jumps over the lazy dog.') == 'e4d909c290d0fb1ca068ffaddf22cbd0'

# Generated at 2022-06-21 08:28:59.779498
# Unit test for function checksum
def test_checksum():
    if not os.path.exists('/tmp/test_checksum.txt'):
        open('/tmp/test_checksum.txt', 'a').close()

    if not os.path.exists('/tmp/test_checksum.txt'):
        raise Exception("Unable to create test file /tmp/test_checksum.txt !")

    sum1 = checksum('/tmp/test_checksum.txt')
    if not sum1:
        raise Exception("Unable to get checksum for test file /tmp/test_checksum.txt !")

    os.remove('/tmp/test_checksum.txt')

    if os.path.exists('/tmp/test_checksum.txt'):
        raise Exception("Unable to delete test file /tmp/test_checksum.txt !")

    sum

# Generated at 2022-06-21 08:29:08.804578
# Unit test for function md5
def test_md5():
    # Use sample_file, defined in test/success/ping.yml
    fn = 'sample_file'
    assert md5(fn) == 'dbd024a32ed9c20b4367c4e4d0e4f050'
    assert checksum(fn) == 'b730d06939a4e8820b4a4a4fb80de1c89a1e74dc'

    # hashlib.md5() does not accept unicode strings, but
    # should accept byte strings
    fn = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'unicode_text')
    assert md5(fn) == '52fe544c9b1e70a89814f007796d06c5'

# Generated at 2022-06-21 08:29:20.756845
# Unit test for function checksum_s
def test_checksum_s():
    assert "e00f1acd2a9a84a92a8e8d5b5be3f3c5f5d2ab5c" == checksum_s("abc123")
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('\n') == '8c89733100f01e66e9c9a90287d20deb828ffbba'
    assert checksum_s('\n\n') == '22344c9f7dbd1c30e2713c6a1c6a99d6e8c6a65f'

# Generated at 2022-06-21 08:29:29.684062
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import stat

    (fd, src_path) = tempfile.mkstemp(text=True)
    dst_path = src_path + '.bak'


# Generated at 2022-06-21 08:29:30.940398
# Unit test for function md5s
def test_md5s():
    assert md5s("abc") == "900150983cd24fb0d6963f7d28e17f72"


# Generated at 2022-06-21 08:29:31.842493
# Unit test for function md5s
def test_md5s():
    assert True



# Generated at 2022-06-21 08:29:36.675415
# Unit test for function md5
def test_md5():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import StringIO

    s = StringIO()
    s.name = 'ansible_file'
    s.write(to_bytes('foobar'))
    s.seek(0)
    assert md5(s.name) == '3858f62230ac3c915f300c664312c63f'
    s.close()


# Generated at 2022-06-21 08:29:48.273564
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(u'hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=sha1) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(u'hello world', hash_func=sha1) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-21 08:29:52.371464
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s('hello') != '5d41402abc4b2a76b9719d911017c592':
        raise AssertionError('checksum_s does not produce correct result')

# Generated at 2022-06-21 08:30:05.646455
# Unit test for function checksum
def test_checksum():

    test_file = './lib/ansible/module_utils/basic.py'
    test_str = 'asdf'

    print("Testing sha1")
    shash = secure_hash(test_file, sha1)
    sshash = secure_hash_s(test_str, sha1)
    print("sha1('%s') = '%s'" % (test_file, shash))
    print("sha1_s('%s') = '%s'" % (test_str, sshash))

    if _md5:
        print("Testing md5")
        mhash = secure_hash(test_file, _md5)
        smhash = secure_hash_s(test_str, _md5)

# Generated at 2022-06-21 08:30:08.519531
# Unit test for function checksum_s
def test_checksum_s():
    hash_func = sha1
    data = 'Fake data'
    assert checksum_s(data, hash_func) == secure_hash_s(data, hash_func)

# Generated at 2022-06-21 08:30:12.641262
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s("test") == "098f6bcd4621d373cade4e832627b4f6"
    else:
        try:
            md5s("test")
            assert False
        except ValueError:
            assert True

# Generated at 2022-06-21 08:30:18.453441
# Unit test for function checksum
def test_checksum():
    TEST_FILE = 'test_checksum'
    TEST_TEXT = 'This is a test file'
    TEST_MD5 = '2cebe6e0e72a7a290d9482357d08c1d1'

    # Create the text file
    with open(TEST_FILE, 'w') as f:
        f.write(TEST_TEXT)

    # Test for md5
    computed_md5 = md5(TEST_FILE)
    if computed_md5 != TEST_MD5:
        os.remove(TEST_FILE)
        raise Exception("md5 test failed, file: %s, actual: %s, expected: %s" % (TEST_FILE, computed_md5, TEST_MD5))

    # Test for sha1

# Generated at 2022-06-21 08:30:24.985520
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('EINS, ZWEI, DREI, VIER!') == '15abd577de1ad7b19a2b2bb5b5e5a5f5'

# Generated at 2022-06-21 08:30:28.972926
# Unit test for function md5s
def test_md5s():
    '''returns true if test passes'''

    value = 'string to hash'
    hash_value = 'b859b6501b31a59d343b0be00b817c5d'
    return md5s(value) == hash_value



# Generated at 2022-06-21 08:30:34.415622
# Unit test for function checksum
def test_checksum():
    assert checksum('test/test.py', hash_func=sha1) == 'f7e58f9b9c7b1fad6e07dfc59ab89d0da28e8f06'
    assert checksum('test/test.py', hash_func=_md5) == '0d11e7c8fe0b51050e360fc2e9a7d8b3'

# Generated at 2022-06-21 08:30:36.115524
# Unit test for function md5
def test_md5():
    md5s('test')
    md5('/etc/passwd')


# Generated at 2022-06-21 08:30:43.079665
# Unit test for function md5
def test_md5():
    """Test the md5 function"""
    from ansible.vars import VariableManager
    from ansible import constants as C

    vm = VariableManager()
    inv = {'hosts': [{'hostname': 'localhost'}], '_run_once': True}

    os.chdir(C.DEFAULT_LOCAL_TMP)
    open('data.txt', 'w').write('hello')
    res = md5('data.txt')
    assert res == '5d41402abc4b2a76b9719d911017c592', 'data.txt does not match expected md5'

    res = md5('data.txtx')
    assert res is None, 'data.txtx should not have a md5 computed'

    res = md5(vm.preprocess_data('data.txt', inv))
    assert res

# Generated at 2022-06-21 08:30:55.326207
# Unit test for function checksum_s
def test_checksum_s():
    test_string = 'abcdef'
    expected_checksum = 'e80b5017098950fc58aad83c8c14978e'
    checksum_val = checksum_s(test_string)
    if expected_checksum != checksum_val:
        raise AssertionError("checksum_s(test_string) returned %s but expected %s" % (checksum_val, expected_checksum))

    test_string = 'abcdef'
    expected_checksum = 'e80b5017098950fc58aad83c8c14978e'
    checksum_val = checksum_s(test_string)

# Generated at 2022-06-21 08:31:13.308106
# Unit test for function checksum
def test_checksum():
    # Setup
    TEST_FILE = "checksum_test.txt"
    file = open(TEST_FILE, 'wb')
    file.write("This is a test of the checksum function.\n")
    file.close()

    # Test the secure_hash function
    sh_s1 = secure_hash_s("This is a test of the checksum function.\n")
    sh_s2 = secure_hash_s("This is a test of the checksum function.\n")
    assert sh_s1 == sh_s2
    sh_f1 = secure_hash(TEST_FILE)
    sh_f2 = secure_hash(TEST_FILE)
    assert sh_f1 == sh_f2

    # Verify the deprecated functions

# Generated at 2022-06-21 08:31:16.502548
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '4b725f417d2e4b4f4e8d913d3fc6bfa3'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-21 08:31:26.726128
# Unit test for function md5s
def test_md5s():
    import stat
    import tempfile
    (fd, fname) = tempfile.mkstemp()
    with open(fname, 'w') as f:
        f.write('hello world')
    assert secure_hash(fname) == secure_hash_s('hello world')
    os.chmod(fname, stat.S_IRUSR)
    assert secure_hash(fname) == secure_hash_s('hello world')
    os.chmod(fname, stat.S_IRUSR|stat.S_IWUSR)
    assert secure_hash(fname) == secure_hash_s('hello world')
    os.close(fd)
    os.remove(fname)


# Generated at 2022-06-21 08:31:37.783591
# Unit test for function md5
def test_md5():
    from nose.plugins.skip import SkipTest
    raise SkipTest("skipped for now...")
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    # Create test file
    filename = "/tmp/ansible_test"
    test_str = "abcd"
    fp = open(filename, "w")
    fp.write(test_str)
    fp.close()
    # Test if file exists
    assert(os.path.exists(filename))
    # Test md5
    assert(md5(filename) == "e2fc714c4727ee9395f324cd2e7f331f")
    # Remove file
    os.remove(filename)
    # Test if file is removed
    assert(not os.path.exists(filename))

# Generated at 2022-06-21 08:31:44.347765
# Unit test for function checksum
def test_checksum():
    ''' verify checksum '''
    import tempfile
    import shutil
    import os

    TEST_TEXT = b"This is a test.\n"

    checksum_return = secure_hash_s(TEST_TEXT)
    assert checksum_s(TEST_TEXT) == checksum_return

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, "checksum.txt")
    with open(test_file, 'w') as f:
        f.write(TEST_TEXT)
    assert secure_hash(test_file) == checksum_return
    os.remove(test_file)
    shutil.rmtree(test_dir)

# Generated at 2022-06-21 08:31:49.777052
# Unit test for function checksum_s
def test_checksum_s():
    assert 'da39a3ee5e6b4b0d3255bfef95601890afd80709' == checksum_s('')
    assert '5ba93c9db0cff93f52b521d7420e43f6eda2784f' == checksum_s('The quick brown fox jumps over the lazy dog')



# Generated at 2022-06-21 08:31:55.231559
# Unit test for function md5s
def test_md5s():
    in_str = 'hello world'
    expected = '5eb63bbbe01eeed093cb22bb8f5acdc3'
    # Call it with hashlib.md5
    if _md5:
        actual = md5s(in_str)
        assert expected == actual, 'md5s failed to match expected'
    return True

# Generated at 2022-06-21 08:31:59.406802
# Unit test for function md5s
def test_md5s():
    import random
    import string
    # Generate a random string with letters and digits
    x = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(1000))
    assert md5s(x) == secure_hash_s(x, _md5)

# Generated at 2022-06-21 08:32:05.406768
# Unit test for function checksum
def test_checksum():
    from tempfile import NamedTemporaryFile
    from shutil import copy

    content = 'Hello World'

    # Test the API with a single file and fixed content
    f = NamedTemporaryFile()
    f.write(content)
    f.flush()
    copy(f.name, 'foo')
    f.close()

    sha_digest = secure_hash('foo')
    md5_digest = secure_hash('foo', _md5)

    assert sha_digest == secure_hash_s(content)
    assert md5_digest == md5s(content)

    # Test the API with a string and some random content
    f = NamedTemporaryFile()
    f.write(content)
    f.flush()
    copy(f.name, 'foo')
    f.close()

    sha_