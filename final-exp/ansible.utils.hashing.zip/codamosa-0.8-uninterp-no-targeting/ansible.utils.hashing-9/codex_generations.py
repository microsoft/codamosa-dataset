

# Generated at 2022-06-21 08:22:16.286547
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import time


# Generated at 2022-06-21 08:22:25.807839
# Unit test for function md5
def test_md5():
    """ md5 test """
    from ansible.compat import StringIO

    # Setup
    sio = StringIO()
    ex_data = b'test'
    ex_md5 = b'd8e8fca2dc0f896fd7cb4cb0031ba249'

    # Exercise
    sio.write(ex_data)
    sio.seek(0)
    data_md5 = md5(sio.name)
    sio.seek(0)
    sio_md5 = md5s(ex_data)

    # Verify
    assert data_md5 == ex_md5
    assert sio_md5 == ex_md5
    sio.close()



# Generated at 2022-06-21 08:22:27.779017
# Unit test for function md5s
def test_md5s():
    ''' test md5s()'''

    assert len(md5s('test')) == 32


# Generated at 2022-06-21 08:22:38.496335
# Unit test for function md5
def test_md5():
    ''' md5 '''
    from ansible.compat.tests import unittest

    class TestMD5(unittest.TestCase):
        ''' Test md5 function '''
        def setUp(self):
            self.filename = os.path.join(os.path.dirname(__file__), 'test_md5.txt')
            test_string = 'testing md5'
            with open(self.filename, 'w') as f:
                f.write(test_string)

        def test_md5(self):
            ''' Test md5 '''
            # Test md5
            with open(self.filename, 'rb') as f:
                self.assertEqual(md5(self.filename), _md5(f.read()).hexdigest())


# Generated at 2022-06-21 08:22:44.421300
# Unit test for function checksum
def test_checksum():
    ''' test_checksum: it should be able to find the checksum of a distant file'''
    assert checksum('https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/module_utils/basic.py') == '54044a910a73f7fabce865bd8972d330'


# Generated at 2022-06-21 08:22:55.785353
# Unit test for function checksum
def test_checksum():
    ''' unit test for checksum '''

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    def xtest():
        assert isinstance(checksum_s("xyz"), AnsibleUnsafeText)
        assert isinstance(checksum("xyz"), AnsibleUnsafeText)
        assert isinstance(md5s("xyz"), AnsibleUnsafeText)
        assert isinstance(md5("xyz"), AnsibleUnsafeText)

    def test_eq1():
        assert checksum_s("xyz") == "9c1185a5c5e9fc54612808977ee8f548b2258d31"
        assert checksum("xyz") == checksum_s("xyz")


# Generated at 2022-06-21 08:23:03.903683
# Unit test for function md5
def test_md5():
    md5_test_cases = [
        {
            'in': 'BABABABABAAAAAAAAAAAAA',
            'out': '18651ef30e8c11b19f75b4a2a9a3acd8',
        },
        {
            'in': 'foobar',
            'out': '3858f62230ac3c915f300c664312c63f',
        },
    ]

    for test_case in md5_test_cases:
        assert md5(test_case['in']) == test_case['out']

# Generated at 2022-06-21 08:23:07.634015
# Unit test for function checksum
def test_checksum():
    filename = '/etc/hosts'
    hashed = checksum(filename)
    assert isinstance(hashed, unicode)
    assert len(hashed) == 40, "Length is correct"
    assert type(checksum_s('Hello World')) is unicode, "types are correct"

# Generated at 2022-06-21 08:23:14.303882
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("some string") == "beb9f9be9bf91b16f770befc6f1d8e72c7d1cd229b020b01f62da927105f7e42"


if __name__ == "__main__":
    import os
    import sys
    import subprocess

    if sys.argv[1] == "--files":
        for root, _, filenames in os.walk('.'):
            if '.git' in root:
                continue
            for filename in filenames:
                if filename.startswith('.'):
                    continue
                path = os.path.join(root, filename)
                digest = secure_hash(path)
                if not digest:
                    continue
                yield path, digest
        exit(0)


# Generated at 2022-06-21 08:23:23.816293
# Unit test for function checksum_s
def test_checksum_s():
    print("TESTING CHECKSUM_S FUNCTION")
    test_string = "This is a test string"
    test_string_result = "f30113e104720c2d96f02f3b3a4a4a749d9b9191"
    val = checksum_s(test_string)
    if test_string_result != val:
        print("FAILED: test_checksum_s() returned %s instead of %s" % (val, test_string_result))
    else:
        print("PASSED: test_checksum_s()")


# Generated at 2022-06-21 08:23:33.662862
# Unit test for function checksum
def test_checksum():
    import tempfile
    d = tempfile.mkdtemp()
    f1 = os.path.join(d, 'f1')
    f2 = os.path.join(d, 'f2')

# Generated at 2022-06-21 08:23:45.510291
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock
    from ansible.module_utils._text import to_bytes

    mock_file = Mock()
    mock_file.read.side_effect = ['aa', None]

    with patch('ansible.module_utils.basic.AnsibleModule.fail_json') as mock_fail_json:
        with patch('ansible.module_utils.basic.AnsibleModule.warn') as mock_warn:
            with patch('ansible.module_utils.basic.open', mock_file, create=True):
                checksum('./unittest', hash_func=Mock(return_value=Mock(hexdigest=Mock(return_value='aaa'))))
                mock_file.open.assert_

# Generated at 2022-06-21 08:23:55.742297
# Unit test for function checksum_s
def test_checksum_s():
    # Test 1
    str1 = 'The quick brown fox jumps over the lazy dog'
    result1 = secure_hash_s(str1)
    assert (result1 == '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12')

    # Test 2
    str2 = 'No hash algorithm found for: SHA256'
    result2 = secure_hash_s(str2)
    assert (result2 == 'ffd6b8a0a52fd6b112a6b2a6a8b6d221bee0e179')

    # Test 3
    str3 = 'Ans?ble'
    result3 = secure_hash_s(str3)

# Generated at 2022-06-21 08:24:04.496071
# Unit test for function md5
def test_md5():
    filename = 'test/ansible/utils/test_md5.txt'
    with open(filename, 'w') as f:
        f.write('hello world\n')

    # test md5 generation
    digest1 = md5(filename)

    # test to ensure md5s function is deprecated and md5 function is used
    digest2 = md5s(filename)
    assert(digest1 == digest2)

    with open(filename, 'w') as f:
        f.write('goodbye world\n')

    digest3 = md5(filename)
    assert(digest1 != digest3)

# Generated at 2022-06-21 08:24:07.121436
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-21 08:24:10.330214
# Unit test for function md5s
def test_md5s():
    test_data = 'abc123'
    md5sum = md5s(test_data)
    assert md5sum == '202cb962ac59075b964b07152d234b70'



# Generated at 2022-06-21 08:24:13.606171
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('d41d8cd98f00b204e9800998ecf8427e') == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-21 08:24:15.943911
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-21 08:24:19.561750
# Unit test for function md5
def test_md5():
    fn = "testdata/playbook_tests/test1.yml"
    md5sum = md5(fn)
    assert md5sum == "fd4f4fd4b28933f858324b9ae3831865"
    assert len(md5sum) == 32


# Generated at 2022-06-21 08:24:22.491048
# Unit test for function md5s
def test_md5s():
    test_value = "hello world"
    assert(md5s(test_value) == "5eb63bbbe01eeed093cb22bb8f5acdc3")


# Generated at 2022-06-21 08:24:33.641692
# Unit test for function checksum
def test_checksum():
    import time
    import tempfile
    try:
        (fd, name) = tempfile.mkstemp()
        os.write(fd, "derp")
        os.close(fd)
        time.sleep(1)
        os.utime(name, None)
        print(checksum(name))
        time.sleep(1)
        f = open(name, "a")
        f.write("derpderp")
        f.close()
        print(checksum(name))
    finally:
        if os.path.exists(name):
            os.unlink(name)

# Generated at 2022-06-21 08:24:36.028796
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-21 08:24:38.677022
# Unit test for function md5
def test_md5():
    assert(md5("/bin/echo") == "b709ddbacf47066c12e2f904b9442846")

# Generated at 2022-06-21 08:24:42.600274
# Unit test for function md5
def test_md5():
    hal = {'file1': [{'md5sum': secure_hash('test/test.cfg'), 'path': 'test/test.cfg'}]}
    assert md5('test/test.cfg') == hal['file1'][0]['md5sum']

# Generated at 2022-06-21 08:24:52.121393
# Unit test for function checksum_s
def test_checksum_s():
    ''' Returns True if checksum_s() returns the correct results '''

    # Test a few different scenarios
    if checksum_s(r'hello') != '5d41402abc4b2a76b9719d911017c592':
        return False
    if checksum_s(r'hello\n') != '6fd1a268a56a20d0d6b988be927a7db1':
        return False
    if checksum_s(r'hello\r\n') != '2e963f1bcd359dcc8d897d5dde92e40d':
        return False
    if checksum_s(r'hello', hash_func=_md5) != '5d41402abc4b2a76b9719d911017c592':
        return False
   

# Generated at 2022-06-21 08:24:55.896124
# Unit test for function md5s
def test_md5s():
    expected = '9e107d9d372bb6826bd81d3542a419d6'
    observed = md5s("The quick brown fox jumps over the lazy dog")
    assert expected == observed
    assert len(observed) == 32

# Generated at 2022-06-21 08:25:01.641006
# Unit test for function checksum_s
def test_checksum_s():

    test_str = 'some nonsense'
    assert secure_hash_s(test_str) == 'f5abfedc5a7f812c15f9d7f5700e0cbaa8ecf75e'

    assert checksum_s(test_str) == secure_hash_s(test_str)


# Generated at 2022-06-21 08:25:09.417774
# Unit test for function md5
def test_md5():
    ''' md5 should throw an exception if it isn't available '''
    try:
        # Should work if python has hashlib
        md5('/etc/group')
        assert True
    except ValueError:
        assert False

    # Should work if md5 is available
    try:
        import hashlib
        old_md5 = __builtins__.__dict__['md5']
        del(__builtins__.__dict__['md5'])
        md5('/etc/group')
        assert True
    except ValueError:
        assert False
    finally:
        __builtins__.__dict__['md5'] = old_md5
        del(old_md5)

    # Should fail if md5 is not available and hashlib is not available

# Generated at 2022-06-21 08:25:13.530446
# Unit test for function md5s
def test_md5s():
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'



# Generated at 2022-06-21 08:25:19.820740
# Unit test for function md5s
def test_md5s():
    """Unit test for function md5s"""
    # This is the output of:
    #   echo -n 'test_string' | md5sum -
    # on my workstation.
    test_hash = '098f6bcd4621d373cade4e832627b4f6'

    # This is the output of:
    #   echo -n 'test_string' | md5sum -
    # on a system running in FIPS-140-2 mode.
    fips_hash = '9a3f9c3e3f123acf06e5f5ff5d543d0f'
    if not _md5:
        assert md5s('test_string') == fips_hash, "md5s is not behaving as expected"
    else:
        assert md5s('test_string')

# Generated at 2022-06-21 08:25:31.449167
# Unit test for function md5
def test_md5():
    """
    Test md5 function
    """
    # Make up some random data
    test_data = 'the quick brown fox jumped over the lazy dog'
    # Generate the md5 hash of that data
    test_md5 = md5s(test_data)
    # We know what the md5 hash should be
    expect_md5 = '9e107d9d372bb6826bd81d3542a419d6'
    # Make sure they match
    assert test_md5 == expect_md5



# Generated at 2022-06-21 08:25:32.904506
# Unit test for function checksum_s
def test_checksum_s():
    if not checksum_s("password"):
        raise AssertionError("checksum_s")

# Generated at 2022-06-21 08:25:34.763280
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-21 08:25:40.541814
# Unit test for function md5s
def test_md5s():
    if not _md5:
        try:
            md5s('foobar')
        except ValueError as e:
            assert str(e) == 'MD5 not available.  Possibly running in FIPS mode'
        else:
            assert False, 'MD5 should not be available in FIPS mode'
    else:
        assert md5s('foobar') == '3858f62230ac3c915f300c664312c63f'

# Generated at 2022-06-21 08:25:51.186380
# Unit test for function checksum

# Generated at 2022-06-21 08:25:54.488940
# Unit test for function md5s
def test_md5s():
    source = 'test-source-data'
    md5 = md5s(source)
    assert md5 == 'eba8afc6cce5c0d3f5b5f5b6327d659a'



# Generated at 2022-06-21 08:26:06.070321
# Unit test for function checksum_s
def test_checksum_s():
    import unittest

    class TestChecksumS(unittest.TestCase):
        def test_checksum_s_sha1(self):
            """ Checksum_s sha1 returns the same result as sha1 """
            data = 'test'
            self.assertEqual(secure_hash_s(data, sha1), 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3')

        def test_checksum_s_md5(self):
            """ Checksum_s md5 returns the same result as md5 """
            data = 'test'
            self.assertEqual(secure_hash_s(data, _md5), '098f6bcd4621d373cade4e832627b4f6')

    import sys

# Generated at 2022-06-21 08:26:11.672130
# Unit test for function md5s
def test_md5s():
    if _md5:
        # In FIPS mode
        md5_data = 'e59ff97941044f85df5297e1c302d260'
        assert md5s('test') == md5_data
        assert checksum_s('test', hash_func=_md5) == md5_data
    else:
        # Not in FIPS mode
        assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
        assert checksum_s('test', hash_func=_md5) == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-21 08:26:15.521574
# Unit test for function md5
def test_md5():
    assert md5("md5s.py") == "b40f58297cee746d4672fa0f7fefba31"
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"

# Generated at 2022-06-21 08:26:20.930899
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("HELLO") == "8b1a9953c4611296a827abf8c47804d7"
    assert md5s("hellohellohellohellohello") == "14f2ac9c903dbe625d749d8954003e10"
    assert md5s("hellohellohellohellohellohellohellohellohello") == "a234f0302a09a0a3c5755c2e5d7f5e5e"


# Generated at 2022-06-21 08:26:34.145789
# Unit test for function checksum_s
def test_checksum_s():
    # test data taken from:
    # https://groups.google.com/forum/#!msg/cryptography-dev/y_DYBgRfIhM/r5KKXp5GmjMJ
    assert checksum_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum_s('The quick brown fox jumps over the lazy dog') == '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12'
    assert checksum_s('The quick brown fox jumps over the lazy dog.') == '408d94384216f890ff7a0c3528e8bed1e0b01621'

# Generated at 2022-06-21 08:26:37.510754
# Unit test for function md5s
def test_md5s():

    if _md5:
        assert ("8034a05fb6e29de9dd55f7a1c6b1db99" == md5s("Hello"))
    else:
        try:
            md5s("Hello")
            assert False, "md5 should not be available"
        except ValueError:
            assert True

# Generated at 2022-06-21 08:26:49.366386
# Unit test for function md5
def test_md5():
    ''' md5 various data, see if match known works '''
    known_works = ('d41d8cd98f00b204e9800998ecf8427e', 'e59ff97941044f85df5297e1c302d260', '900150983cd24fb0d6963f7d28e17f72')

# Generated at 2022-06-21 08:26:53.351312
# Unit test for function checksum
def test_checksum():
    # Python 2.4 doesn't have "with open(...)" syntax
    (f, filename) = tempfile.mkstemp()
    os.write(f, b"Hello world!\n")
    assert checksum("/etc/passwd") == "0735cfc0be28bbe5eaab1f8e9333a81c"
    assert checksum("/etc/shadow") == None
    assert checksum(filename) == "3c59dc048e8850243be8079a5c74d079"
    assert checksum("/no/such/file") == None
    os.remove(filename)

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:26:59.517377
# Unit test for function md5s
def test_md5s():
    import tempfile
    h = md5s('blah')
    fd, fn = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('blah')
    f.close()
    g = md5(fn)
    os.unlink(fn)
    if h != g:
        raise AnsibleError("h: %s != g: %s" % (h, g))

# Unit test code
if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-21 08:27:01.186299
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') != None



# Generated at 2022-06-21 08:27:09.400591
# Unit test for function md5s
def test_md5s():
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s(b'abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s(u'abc') == '900150983cd24fb0d6963f7d28e17f72'

    assert md5s('The quick brown fox jumps over the lazy dog') == 'e4d909c290d0fb1ca068ffaddf22cbd0'
    assert md5s(u'The quick brown fox jumps over the lazy dog') == 'e4d909c290d0fb1ca068ffaddf22cbd0'

# Generated at 2022-06-21 08:27:15.518041
# Unit test for function checksum_s
def test_checksum_s():
    from ansible.module_utils._text import to_bytes
    correct_hash = '1486f7a4780d6adab1dd8f9f9d7a97a2e0a2f8e3'
    assert secure_hash_s(to_bytes('hello')) == correct_hash
    assert secure_hash_s('hello') == correct_hash

# Generated at 2022-06-21 08:27:19.144145
# Unit test for function md5
def test_md5():
    """Make sure the md5 function can handle unicode filenames.
       This function raises an error if the file does not exists.
    """
    md5('/etc/passwd')
    md5(u'/etc/passwd')

# Generated at 2022-06-21 08:27:26.846304
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum('lib/ansible/modules/core/cloud/amazon/ec2_key.py') == 'f9d4c4a48e8e47c0d23b27a3a3a8a8b2c2a7a9c0'

# Generated at 2022-06-21 08:27:39.625887
# Unit test for function checksum
def test_checksum():
    assert checksum('lib/ansible/modules/core/files/fetch.py') == '5edb234ec6e95a1d97e634d056b9a6f3a6cb8cba'
    assert checksum_s('this is an arbitrary string to hash and test') == 'f95ffa2cd2fabb8e3b3bf3b3dcf09ee15e377392'
    try:
        # This may fail, it is okay to ignore for a unit test
        assert md5s('this string can be hashed by md5') == '913e28352edda8e54d2f4a1d04f4a4fc'
    except ValueError:
        pass

# Generated at 2022-06-21 08:27:46.224678
# Unit test for function md5
def test_md5():
    import tempfile
    fd, temp_file = tempfile.mkstemp()
    os.close(fd)
    fd = open(temp_file, 'w')
    fd.write("foo")
    fd.close()

    h = md5(temp_file)
    if not h:
        raise ValueError('MD5 test file failed.  Possibly running in FIPS mode')
    os.remove(temp_file)


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-21 08:27:49.712691
# Unit test for function md5s
def test_md5s():
    if _md5:
        h = md5s('test')
        assert h == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-21 08:27:57.174940
# Unit test for function md5
def test_md5():
    import random
    import string

    f = open("/tmp/md5", "w")
    test_str = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(1024))
    f.write(test_str)
    f.close()

    assert ansible.utils.md5("/tmp/md5") == ansible.module_utils.basic.AnsibleModule(
        arg_spec={}).md5("/tmp/md5")

# Generated at 2022-06-21 08:28:02.244336
# Unit test for function md5
def test_md5():
    this_file = os.path.realpath(__file__)
    test_md5 = md5(this_file)
    assert test_md5 == '2bd67e1624a76f8d8eb7f53a4a88e7a4'

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-21 08:28:07.299703
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    else:
        try:
            md5s('foo')
            assert False, "Expected ValueError not raised"
        except ValueError:
            pass


# Generated at 2022-06-21 08:28:14.472773
# Unit test for function checksum_s
def test_checksum_s():
    """Tests for function checksum_s."""
    from ansible.utils import checksum_s
    from ansible.utils import md5s

    # Test 1.
    data = "hello world"
    sha_digest = checksum_s(data)
    md5_digest = md5s(data)

    print("sha digest for data 'hello world':")
    print(sha_digest)
    print("md5 digest for data 'hello world':")
    print(md5_digest)

    assert sha_digest == md5_digest
    assert sha_digest == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5_digest == '5eb63bbbe01eeed093cb22bb8f5acdc3'



# Generated at 2022-06-21 08:28:19.480273
# Unit test for function md5
def test_md5():
    assert md5('lib/ansible/module_utils/basic.py') == '27f9a584783a64d163143d08376e91ea'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-21 08:28:25.261596
# Unit test for function md5
def test_md5():
    import shutil
    import tempfile
    tempdir = tempfile.mkdtemp()
    testfile = tempdir + "/testfile"
    shutil.copyfile("/bin/ls", testfile)
    assert md5(testfile) == md5("/bin/ls")
    shutil.rmtree(tempdir)

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-21 08:28:28.012065
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s("testing") == "ae2b1fca515949e5d54fb22b8ed95575"


# Generated at 2022-06-21 08:28:38.669149
# Unit test for function checksum
def test_checksum():
    assert secure_hash('test/utils/test_checksum/zshrc') == '9b937876a3d3bbe98191c1adb647600b'
    assert checksum('test/utils/test_checksum/zshrc') == '9b937876a3d3bbe98191c1adb647600b'
    # assert secure_hash('test/utils/test_checksum/') == None
    assert checksum('test/utils/test_checksum/') == None


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:28:41.997287
# Unit test for function md5
def test_md5():
    if _md5:
        assert md5('/etc/passwd') == 'b4fa7b9e727f49d06efe4c4f4a4cda4a'
    else:
        pass


# Generated at 2022-06-21 08:28:53.140401
# Unit test for function checksum
def test_checksum():
    """Function checksum checks the checksum of a file"""
    from ansible.utils.path import makedirs_safe
    from tempfile import NamedTemporaryFile
    from tempfile import mkdtemp
    from shutil import rmtree

    test_dir = mkdtemp()
    expect_hash = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'

    test_file = os.path.join(test_dir, 'test')
    makedirs_safe(os.path.dirname(test_file))
    with NamedTemporaryFile(dir=test_dir, delete=False) as test_file_fd:
        test_hash = checksum(test_file_fd.name)

# Generated at 2022-06-21 08:28:58.956843
# Unit test for function md5s
def test_md5s():
    # Given the string "hello world"
    # When I calculate the md5sum
    # Then it should be "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"

# Generated at 2022-06-21 08:29:01.273217
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-21 08:29:05.248591
# Unit test for function checksum_s
def test_checksum_s():
    ''' test if the checksum_s function returns a valid hash '''
    data = 'ansible and python rocks'
    hash = checksum_s(data)
    assert hash == '1dcc10f05ebb86c94e8fe7d92d88c1227f4b4de4'

# Generated at 2022-06-21 08:29:10.386263
# Unit test for function checksum
def test_checksum():
    data = "foo"
    checksum_value = checksum_s(data)
    print("checksum_value = %s" % checksum_value)

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:29:22.511892
# Unit test for function checksum
def test_checksum():
    assert secure_hash_s("foo") == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    assert secure_hash_s("foo", hash_func=_md5) == "acbd18db4cc2f85cedef654fccc4a4d8"
    assert secure_hash_s(b"foo") == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    #assert secure_hash_s(b"foo", hash_func=_md5) == "acbd18db4cc2f85cedef654fccc4a4d8"

# Generated at 2022-06-21 08:29:34.362110
# Unit test for function md5
def test_md5():
    from ansible.utils.vars import combine_vars
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import UnsafeText

    vault_secrets = VaultLib([])
    vault_secrets.load_encryption_keys('test/vault_pass')

    def vaulted_data(data):
        return vault_secrets.encrypt(data)

    combined = combine_vars(None, vaulted_data('{"test_one":"hello"}'))
    assert isinstance(combined['test_one'], UnsafeText), 'md5: vaulted data not UnsafeText type'
    assert combined['test_one'] == vaulted_data('hello'), 'md5: combined variable not UnsafeText'
    assert md5s(combined['test_one'])

# Generated at 2022-06-21 08:29:39.215990
# Unit test for function checksum_s
def test_checksum_s():
    data = b'abcdef'
    hex_digest = secure_hash_s(data)
    assert hex_digest == 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'

if __name__ == "__main__":
    import sys
    sys.exit(1)

# Generated at 2022-06-21 08:29:48.044822
# Unit test for function checksum
def test_checksum():
    filename = __file__
    shasum = secure_hash(filename)
    assert shasum == '0125881eafb9c423a1a8dcf77d9f0c07db6c99b6'
    md5sum = md5(filename)
    assert md5sum == '9a7d9c4b4a4b4a4eeb7d86f6fbef11a8'

# Generated at 2022-06-21 08:29:50.674725
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s(b'') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'

# Generated at 2022-06-21 08:29:54.965082
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '9d9dbf7d1a0e35d742b07a75e2a3f03e'
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    if _md5:
        assert md5('/bin/ls') == 'f5d1c8669a9d9e2256e2e63f3241c849'
        assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-21 08:30:01.294968
# Unit test for function checksum
def test_checksum():
    sample_dir = '.'
    sample_file = ('lib/ansible/module_utils/basic.py')
    dir_result = checksum(sample_dir)
    assert dir_result is None

    file_result = checksum(sample_file)
    assert file_result == 'c701d0190a46a7003d6f834e63c0dfe5d2e5c6dc'


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:30:05.447192
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("123") == "40bd001563085fc35165329ea1ff5c5ecbdbbeef"
    assert checksum_s("123", hash_func=sha1()) == "40bd001563085fc35165329ea1ff5c5ecbdbbeef"
    assert checksum_s("123", hash_func=_md5()) == "202cb962ac59075b964b07152d234b70"


# Generated at 2022-06-21 08:30:08.347216
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'


# Generated at 2022-06-21 08:30:13.584114
# Unit test for function md5
def test_md5():
    # Create a test file
    import tempfile
    fd, path = tempfile.mkstemp()
    os.write(fd, 'test')
    os.close(fd)
    # Get md5 of file
    digest = secure_hash(path, _md5)
    # Clean up
    os.unlink(path)
    # Return result
    return digest

# Generated at 2022-06-21 08:30:18.952247
# Unit test for function checksum_s
def test_checksum_s():
    ''' test_checksum_s '''
    failed = False

    if not checksum_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d':
        failed = True

    if failed:
        raise AssertionError('test_checksum_s failed')

# Generated at 2022-06-21 08:30:29.696731
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('HELLO') == 'fcea920f7412b5da7be0cf42b8c93759'
    assert checksum_s(u'HELLO') == 'fcea920f7412b5da7be0cf42b8c93759'

# Generated at 2022-06-21 08:30:34.749378
# Unit test for function checksum_s
def test_checksum_s():
    ''' test_checksum_s

    Tests that the checksum_s function properly
    hashes data.
    '''

    data = 'some random data'
    checksum = secure_hash_s(data)
    assert checksum == '6c1b6a7dca98b5a55e9a1346c9918d96a5f5c5dd', checksum

# Generated at 2022-06-21 08:30:43.807057
# Unit test for function md5
def test_md5():
    import time
    import os
    import tempfile
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile() as tmp_file:
        tmp_file.write(b"testdata1")
        tmp_file.flush()
        tmp_file_name = tmp_file.name

        if not os.path.exists(tmp_file_name):
            raise Exception("Failed to create temporary file")

        md5_checksum = md5(tmp_file_name)
        if not md5_checksum == "9d1019a17b55a414c8518df319ea6e51":
            raise Exception("MD5 checksum failed on testdata1")

        md5_checksum_s = md5s("testdata1")

# Generated at 2022-06-21 08:30:55.496697
# Unit test for function checksum
def test_checksum():
    ''' test_checksum()
    This test is used to ensure that the checksum function using hashlib is working correctly.
    '''
    import tempfile

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile()
    checkfile = tmpfile.name
    # Write data to the temporary file
    tmpfile.write(b'one')
    tmpfile.flush()

    # Set the path of the temporary file
    testpath = os.path.abspath(checkfile)
    # Check the hash of the temporary file matches the expected value
    assert checksum(testpath) == '7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069', 'Test of checksum() function failed'

# Generated at 2022-06-21 08:31:00.130184
# Unit test for function md5s
def test_md5s():
    a_string = "DUMMY"
    if md5s(a_string) != "098f6bcd4621d373cade4e832627b4f6":
        raise AssertionError("MD5 hash function failure")
    if checksum_s(a_string) != "43775f7d3a98a0c4a6e4ad4e4d7ebec881f959bb":
        raise AssertionError("SHA1 hash function failure")


# Generated at 2022-06-21 08:31:04.352726
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s(b'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-21 08:31:10.133452
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return
    test_string = u'I am a string'
    test_result = u'552e0a51b5e6556b8d6d9fe495b7dea4'

    result = md5s(test_string)

    assert test_result == result, "md5s() did not return expected result"


# Generated at 2022-06-21 08:31:18.606875
# Unit test for function md5
def test_md5():
    ''' secure_hash.md5 should calculate the MD5 checksum of a file '''
    import os
    if not os.path.exists('test_md5.tmp'):
        with open('test_md5.tmp', 'w') as f:
            f.write('test')
    try:
        result = md5('test_md5.tmp')
        assert result == '098f6bcd4621d373cade4e832627b4f6'
    finally:
        os.remove('test_md5.tmp')
    try:
        result = md5('/test/test_md5.tmp')
        assert result is None
    finally:
        os.remove('test_md5.tmp')


# Generated at 2022-06-21 08:31:26.043825
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s('test', hash_func=_md5) == '098f6bcd4621d373cade4e832627b4f6'
    assert checksum_s(u'test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'



# Generated at 2022-06-21 08:31:28.647585
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('Hello') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'

# Generated at 2022-06-21 08:31:30.514510
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == secure_hash_s('hello world')

# Generated at 2022-06-21 08:31:40.510406
# Unit test for function md5s
def test_md5s():
    # Python 2.4 does not have assertItemsEqual
    from ansible.compat.tests import unittest

    class md5s_TestCase(unittest.TestCase):

        def test_md5s1(self):
            self.assertEqual(md5s(u'abc'), '900150983cd24fb0d6963f7d28e17f72')

        def test_md5s2(self):
            self.assertEqual(md5s(u'ABC'), '7fc56270e7a70fa81a5935b72eacbe29')

        def test_md5s3(self):
            self.assertEqual(md5s(u'123'), '202cb962ac59075b964b07152d234b70')


# Generated at 2022-06-21 08:31:56.578174
# Unit test for function checksum
def test_checksum():
    # Temp file
    f1 = open("./test1", 'w')
    f1.write("abc")
    f1.close()
    f2 = open("./test2", 'w')
    f2.write("def")
    f2.close()
    # Test for str
    assert checksum_s("abc") == "a9993e364706816aba3e25717850c26c9cd0d89d"
    assert checksum_s('abc') == "a9993e364706816aba3e25717850c26c9cd0d89d"
    # Test for file
    assert checksum("./test1") == "a9993e364706816aba3e25717850c26c9cd0d89d"

# Generated at 2022-06-21 08:31:58.582968
# Unit test for function md5s
def test_md5s():
    try:
        md5s('abc')
    except ValueError:
        return True
    return False


# Generated at 2022-06-21 08:32:03.404139
# Unit test for function md5s
def test_md5s():
    string_1 = 'hello'
    string_2 = 'world'
    string_3 = 'helloworld'

    assert md5s(string_1) == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(string_2) == '7d793037a0760186574b0282f2f435e7'
    assert md5s(string_3) == 'fc5e038d38a57032085441e7fe7010b0'
