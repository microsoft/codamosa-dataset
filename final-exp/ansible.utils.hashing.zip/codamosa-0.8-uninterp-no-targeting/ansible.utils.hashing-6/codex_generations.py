

# Generated at 2022-06-21 08:22:21.348393
# Unit test for function md5
def test_md5():
    """This is a basic test for md5 and md5s functions"""
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.basic
    module = AnsibleModule(
        argument_spec = dict(
            src_md5 = dict(type='str'),
            src = dict(type='str'),
            dest = dict(type='str')
        ),
        add_file_common_args=True
    )

    # Test md5s
    test_str = 'abcdefghijklmnopqrstuvwxyz0123456789'
    md5_hex = md5s(test_str)
    module.exit_json(msg=md5_hex)

    # Test md5
    test_file_name = 'test_file'

# Generated at 2022-06-21 08:22:29.256334
# Unit test for function checksum_s
def test_checksum_s():
    import os
    import ansible.utils.checksum as checksum_utils

    # I do not want to keep any real file. Let's create a file which exists only in the memory
    with open(os.devnull, 'w') as null:
        temp_file = null.fileno()
    checksum_utils.open = lambda file, mode: os.fdopen(temp_file, mode)
    checksum_utils.checksum_s('test')
    try:
        checksum_utils.checksum_s(5)
    except TypeError:
        return True
    return False


# Generated at 2022-06-21 08:22:32.002840
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "07f3b09899d302e31b14d54b52cc3fea"
    assert checksum("/bin/lsx") is None

# Generated at 2022-06-21 08:22:37.624106
# Unit test for function md5s
def test_md5s():
    x = md5s('test')
    assert x == '098f6bcd4621d373cade4e832627b4f6'
    x = md5s('test2')
    assert x == '2ac913a8c8a7d9d5deefa7143af19fd8'


# Generated at 2022-06-21 08:22:44.370914
# Unit test for function md5
def test_md5():
    # test for md5s
    res = md5s('Hello World')
    assert res == 'b10a8db164e0754105b7a99be72e3fe5'

    # test for md5
    res = md5("./test/support/files/test_hashlib.py")
    assert res == "23e90b7d04df699c1f2cb411bfb6f973"

# Generated at 2022-06-21 08:22:53.064500
# Unit test for function checksum
def test_checksum():
    test_filename = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'testfile')
    open(test_filename, 'a').close()
    try:
        assert checksum(test_filename) == checksum_s(open(test_filename, 'rb').read())
        try:
            import zlib
            assert zlib.crc32(open(test_filename,'rb').read()) != checksum(test_filename)
        except ImportError:
            pass
    finally:
        os.remove(test_filename)

# Generated at 2022-06-21 08:23:03.904133
# Unit test for function checksum
def test_checksum():
    ''' Check the checksum function against known hashes '''

    # Create a new empty file
    (fd, fname) = tempfile.mkstemp()
    temp_file = os.fdopen(fd, 'w+')
    temp_file.close()

    # Test several sizes of data
    data_sizes = [0, 1, 10, 100, 1024]
    for bytes in data_sizes:
        # Fill file with random data
        seed = os.urandom(bytes)
        try:
            with open(fname, 'wb') as f:
                f.write(seed)
        except IOError as e:
            os.remove(fname)
            raise AnsibleError("error while accessing the file %s, error was: %s" % (fname, e))
        # Create hash for data
        data_

# Generated at 2022-06-21 08:23:09.727516
# Unit test for function md5
def test_md5():
    import tempfile

    (fd, fname) = tempfile.mkstemp()
    testfile = os.fdopen(fd, 'w')
    testfile.write('foo')
    testfile.close()

    assert md5(fname) == 'acbd18db4cc2f85cedef654fccc4a4d8'
    os.remove(fname)


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-21 08:23:14.893410
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5('/bin/ls') == 'f178b6c7d8b020ca52c0e57d0e124f05'


# Generated at 2022-06-21 08:23:27.147248
# Unit test for function checksum
def test_checksum():
    '''
    ansible core tests checksum_s function
    '''
    # Correct checksum_s for abc
    abc_checksum_sha1 = 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum_s('abc') == abc_checksum_sha1
    # Correct checksum_s for an empty string
    empty_checksum_sha1 = 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('') == empty_checksum_sha1
    # Correct checksum for empty.txt
    empty_path = os.getcwd() + '/test/units/lib/ansible/module_utils/empty.txt'

# Generated at 2022-06-21 08:23:41.060058
# Unit test for function checksum
def test_checksum():
    """Test checksum function for various situations."""

    test_string = """Hello World
I am a test string
This is a fairly long string of test data
Testing, testing, 123"""

    test_files = {
        'good': 'test_utils_hash.py',
        'missing': 'test_utils_hash_missing.py',
        'directory': 'lib',
    }

    for algorithm in (sha1, _md5):
        assert checksum_s(test_string, algorithm) == '56745bb5c5fefd74c640b8b282259f906a8851d1'
        assert checksum(test_files['good'], algorithm) == 'f7ccb1a9b2e6af37a36b1c3f6785e0f7'
        # Missing file
       

# Generated at 2022-06-21 08:23:49.590809
# Unit test for function md5
def test_md5():
    import tempfile
    from ansible.module_utils._text import to_bytes
    test_data = "Hello world"
    expected_md5 = "ed076287532e86365e841e92bfc50d8c"
    with tempfile.NamedTemporaryFile(mode='wb', delete=False) as tmp_f:
        tmp_f.write(to_bytes(test_data, errors='surrogate_or_strict'))
    assert md5(tmp_f.name) == expected_md5
    os.remove(tmp_f.name)

# Generated at 2022-06-21 08:23:58.157694
# Unit test for function checksum_s
def test_checksum_s():
    # data_1 to data_2 are the same data
    data_1 = "sha1 should match sha1"
    data_2 = "sha1 should match sha1"

    # data_3 to data_4 are the same data
    data_3 = b"sha1 should match sha1"
    data_4 = b"sha1 should match sha1"

    # data_5 to data_6 are the same data
    data_5 = u"sha1 should match sha1"
    data_6 = u"sha1 should match sha1"

    # data_7 to data_8 are the same data
    # \u2000 is a whitespace character
    data_7 = u"\u2000sha1 should match sha1"
    data_8 = u"\u2000sha1 should match sha1"



# Generated at 2022-06-21 08:24:04.643906
# Unit test for function md5
def test_md5():
    ''' test_md5
    Make sure md5 works, and returns the same as the old version.
    '''

    test_file="lib/ansible/modules/core/cloud/cloudstack/test/testfile.txt"
    old_md5 = checksum(test_file, algorithm='md5')
    new_md5 = md5(test_file)

    assert old_md5 == new_md5

# Generated at 2022-06-21 08:24:10.214244
# Unit test for function md5
def test_md5():
    try:
        assert(md5s('test') == '098f6bcd4621d373cade4e832627b4f6')
        assert(md5('test') == '098f6bcd4621d373cade4e832627b4f6')
    except:
        raise
    else:
        print('MD5 tests passed')

# Generated at 2022-06-21 08:24:15.213031
# Unit test for function md5
def test_md5():
    import tempfile

    test_file_name = tempfile.mktemp()
    test_file_md5 = '5eb63bbbe01eeed093cb22bb8f5acdc3'
    test_file_content = 'Hello, World!'

    file = open(test_file_name, 'w')
    file.write(test_file_content)
    file.close()

    assert md5(test_file_name) == test_file_md5

    os.remove(test_file_name)

# Generated at 2022-06-21 08:24:21.864179
# Unit test for function md5
def test_md5():
    assert md5s("foobar") == "8843d7f92416211de9ebb963ff4ce28125932878"
    assert md5s(u"foobar") == "8843d7f92416211de9ebb963ff4ce28125932878"
    assert md5s(b"foobar") == "8843d7f92416211de9ebb963ff4ce28125932878"
    assert md5(__file__) == "f22a8fface12f3dba3ff9e9c2e2a7a350c71b172"

# Generated at 2022-06-21 08:24:26.657309
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello world") == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"
    assert checksum_s("hello world", sha1) == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"

# Generated at 2022-06-21 08:24:38.609663
# Unit test for function checksum
def test_checksum():
    """ sample test to test checksum function """

    # test a sample file with known values
    # ansible-playbook --extra-vars="@password.yml --extra-vars 'ansible_verbosity=1'" sample.yml
    assert "f6f0a3179d3f742e6e92a0d841f35e2c" == checksum('/etc/passwd')
    assert "d41d8cd98f00b204e9800998ecf8427e" == checksum('doesnotexist')
    assert "d41d8cd98f00b204e9800998ecf8427e" == checksum('/etc/passwd/a')

# Generated at 2022-06-21 08:24:47.594193
# Unit test for function checksum_s
def test_checksum_s():
    # Test sha-1
    assert(secure_hash_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33')

    # Test sha-1 with unicode input
    assert(secure_hash_s(u'foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33')

    # Test MD5
    if _md5:
        assert(md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8')
    else:
        try:
            md5s('foo')
            assert False
        except ValueError:
            pass


# Generated at 2022-06-21 08:24:52.541942
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world', sha1) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-21 08:25:02.495779
# Unit test for function md5s
def test_md5s():
    import os
    import tempfile
    (fd,name)=tempfile.mkstemp()
    os.close(fd)
    os.unlink(name)

    assert secure_hash_s("") == "da39a3ee5e6b4b0d3255bfef95601890afd80709"
    assert secure_hash_s("a") == "86f7e437faa5a7fce15d1ddcb9eaeaea377667b8"

    assert secure_hash("") is None
    assert secure_hash(name) is None

    f=open(name,"w")
    f.write("a")
    f.close()

    assert secure_hash(name) == "86f7e437faa5a7fce15d1ddcb9eaeaea377667b8"

   

# Generated at 2022-06-21 08:25:11.963965
# Unit test for function checksum
def test_checksum():
    assert md5("test/files/hello") == "8b1a9953c4611296a827abf8c47804d7"
    assert md5("test/files/dir2/file") == "d0763edaa9d9bd2a9516280e9044d885"
    assert md5("test/files/dir/file") == "f5e5ea6a1c6d070e9cb47c6a8b0f421e"
    assert md5("test/files/dir2/link") == "d0763edaa9d9bd2a9516280e9044d885"
    assert md5("test/files/dir/link") == "f5e5ea6a1c6d070e9cb47c6a8b0f421e"


# Generated at 2022-06-21 08:25:16.265545
# Unit test for function md5
def test_md5():
    val = md5('/etc/passwd')
    #assert isinstance(val, basestring)
    assert isinstance(val, str)


# Generated at 2022-06-21 08:25:19.790750
# Unit test for function checksum
def test_checksum():
    data = 'foo'
    expected_hexdigest = '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_s(data) == expected_hexdigest

# Generated at 2022-06-21 08:25:21.648704
# Unit test for function checksum
def test_checksum():
    ''' Unit test for function checksum '''

    assert checksum(__file__) == checksum_s(open(__file__).read())

# Generated at 2022-06-21 08:25:31.600627
# Unit test for function md5s
def test_md5s():
    from os import chmod, remove
    from tempfile import NamedTemporaryFile
    # md5s
    assert md5s("Hello World") == "ed076287532e86365e841e92bfc50d8c"
    # create a temporary file
    (handle, filename) = NamedTemporaryFile(delete=False).__enter__()
    handle.write("Hello World")
    handle.close()
    assert md5(filename) == "ed076287532e86365e841e92bfc50d8c"
    # remove the temporary file
    remove(filename)

# Generated at 2022-06-21 08:25:34.653522
# Unit test for function md5
def test_md5():
    test_file = '/etc/hosts'
    test_md5 = md5(test_file)

    # Checksum calculation using Unix command line
    assert test_md5 == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-21 08:25:38.153771
# Unit test for function checksum_s
def test_checksum_s():
    value = "hello world"
    expected = '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(value) == expected


# Generated at 2022-06-21 08:25:42.765575
# Unit test for function checksum_s
def test_checksum_s():
    '''
    ansible.module_utils.basic.checksum_s test
    >>> checksum_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    True
    '''
    return


# Generated at 2022-06-21 08:25:54.020513
# Unit test for function checksum_s
def test_checksum_s():
    import pytest
    # Test empty string
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    # Test non-empty string
    assert checksum_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    # Test non-7-bit ASCII string
    with pytest.raises(UnicodeEncodeError):
        checksum_s(u'\xa7')
    assert checksum_s(u'\xa7'.encode('utf-8')) == 'f03cb9ae9aefc30630d36ce6b8e6c0b6a38b4077'

# Generated at 2022-06-21 08:25:58.973076
# Unit test for function md5s
def test_md5s():
    test_data = 'This is a test string'
    test_sig = 'f3d35e3ea3c96b3fbf26d75b70cbbc0f'
    assert md5s(test_data) == test_sig


# Generated at 2022-06-21 08:26:02.304155
# Unit test for function md5s
def test_md5s():
    ''' unit test for md5s '''
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"


# Generated at 2022-06-21 08:26:07.768900
# Unit test for function checksum_s
def test_checksum_s():
    # If a string is passed in this function, it should return an sha1 string
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    # If an integer is passed in this function, it should return an sha1 string
    assert checksum_s(123) == '40bd001563085fc35165329ea1ff5c5ecbdbbeef'



# Generated at 2022-06-21 08:26:17.517459
# Unit test for function md5
def test_md5():
    import os
    import tempfile
    # Create a temporary file and close it
    fd, fname = tempfile.mkstemp()
    os.close(fd)
    # Open and close the file to generate some IO stats
    fd = os.open(fname, os.O_RDONLY)
    os.close(fd)
    # Get the md5 hash of the temporary file
    h1 = md5(fname)
    # Check that the length is correct
    assert len(h1) == 32
    # Check that the length of the sha1 hash of the same file is correct
    h2 = secure_hash(fname)
    assert len(h2) == 40
    # Check that the hashes of the function md5 and secure_hash are different
    assert h1 != h2
    # Remove the temporary file


# Generated at 2022-06-21 08:26:27.456190
# Unit test for function checksum_s
def test_checksum_s():
    import ansible.utils.crypto as crypto
    from ansible.utils.hashing import md5s, md5, checksum_s, checksum

    assert(checksum_s("foo") != checksum_s("bar"))
    assert(checksum("/etc/passwd") != checksum("/etc/group"))
    assert(crypto.checksum_s("foo") != crypto.checksum_s("bar"))
    assert(crypto.checksum("/etc/passwd") != crypto.checksum("/etc/group"))

    assert(checksum_s("foo") == crypto.checksum_s("foo"))
    assert(checksum("/etc/passwd") == crypto.checksum("/etc/passwd"))


# Generated at 2022-06-21 08:26:37.198784
# Unit test for function md5
def test_md5():
    '''
    unit test for md5
    '''
    from ansible.module_utils._text import to_text

    (rc, out, err) = module.run_command('mkdir /tmp/ansible-tmp-md5-test')
    (rc, out, err) = module.run_command('date > /tmp/ansible-tmp-md5-test/date')
    assert(md5('/tmp/ansible-tmp-md5-test/date') == '60a6f23d1df3cf6a3b6d80b1c83e6b30')
    assert(md5s('this is a test') == '2e99758548972a8e8822ad47fa1017ff')

# Generated at 2022-06-21 08:26:48.983191
# Unit test for function checksum_s
def test_checksum_s():
    from ansible.module_utils.urls import open_url
    import sys
    import urllib

    expected_hash = u'ee1eca47fc774c03e48c3b1ce2f3e2e9'

    fd = open_url("https://github.com/ansible/ansible/raw/devel/test/testdata/root/test.txt")
    data = fd.read()
    # test using the default hash algorithm
    hash_value = checksum_s(data)
    if hash_value != expected_hash:
        sys.stderr.write(u'the checksum test failed with the default hash algorithm')
        sys.exit(1)
    else:
        sys.stderr.write(u'the checksum test succeeded with the default hash algorithm')

    # test using the

# Generated at 2022-06-21 08:26:52.189564
# Unit test for function checksum_s
def test_checksum_s():
    test_string = 'The quick red fox jumped over the lazy brown dog' 
    test_string_checksum = '0a964f1ccb6ac0f6a0ff6e8f79d3e6eb'
    assert checksum_s(test_string) == test_string_checksum

if __name__ == '__main__':
    test_checksum_s()
    print(checksum_s("The quick red fox jumped over the lazy brown dog"))
    print(md5("../ansible/utils/plugin_docs_fragments"))

# Generated at 2022-06-21 08:27:01.079802
# Unit test for function checksum
def test_checksum():

    assert(checksum('/etc/passwd') == checksum('/etc/passwd'))
    assert(checksum('/etc/passwd') != checksum('/etc/group'))
    assert(checksum('/etc/passwd') != checksum('/etc/shadow'))

    c1 = checksum_s("hello world")
    c2 = checksum_s("hello world")
    c3 = checksum_s("goodbye")
    assert(c1 == c2)
    assert(c2 != c3)

    try:
        md5('/etc/passwd')
    except ValueError:
        pass
    else:
        print("md5s() should have raised an exception in FIPS mode")
        assert False


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:27:10.691192
# Unit test for function md5
def test_md5():
    assert md5(__file__) == 'd1f2b88c6b39a6e025ccc8ad78f16b3c'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-21 08:27:14.332351
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s('hello') != '5d41402abc4b2a76b9719d911017c592':
        raise ValueError("Did not match known sha1 for string 'hello'")


# Generated at 2022-06-21 08:27:22.323092
# Unit test for function md5
def test_md5():

    # md5s test
    if _md5:
        assert "f828a8e0f2a186a2f48b75544f9f27f2" == md5s("The quick brown fox jumps over the lazy dog")
        assert "d41d8cd98f00b204e9800998ecf8427e" == md5s("")
        assert "9e107d9d372bb6826bd81d3542a419d6" == md5s("The quick brown fox jumps over the lazy dog.")
        assert "84983e441c3bd26ebaae4aa1f95129e5" == md5s("The quick brown fox jumps over the lazy cog")

# Generated at 2022-06-21 08:27:31.210564
# Unit test for function checksum_s
def test_checksum_s():
    from ansible.compat.tests import unittest

    class TestChecksumS(unittest.TestCase):

        def test_checksum_s(self):
            sha_digest = '3bdc88fb6e8bfb832b065e11fd2e1855f937e913'

            data = 'this is a test'
            result = secure_hash_s(data)
            self.assertEqual(result, sha_digest)

    return unittest.main(TestChecksumS)



# Generated at 2022-06-21 08:27:36.931133
# Unit test for function md5s
def test_md5s():
    test_str = "myteststring"
    test_str_hash = "ecb81efa856fd1e123f6a584eb1c3e3b"

    test_hash = md5s(test_str)
    if test_hash != test_str_hash:
        raise Exception("md5s() failure")


# Generated at 2022-06-21 08:27:45.414113
# Unit test for function checksum
def test_checksum():
    if not os.path.exists(to_bytes('test_checksum.txt', errors='surrogate_or_strict')):
        return [False, "Missing test file"]
    chksum = secure_hash('test_checksum.txt')
    if chksum == 'fa6b8ec7b88710c401b7040c45e8737d913d9c1b':
        return [True, ""]
    else:
        return [False, "Found %s instead of %s" % (chksum, 'fa6b8ec7b88710c401b7040c45e8737d913d9c1b')]


# Generated at 2022-06-21 08:27:56.726693
# Unit test for function md5
def test_md5():
    from ansible.compat.tests import unittest, mock
    from ansible.compat.tests.mock import patch

    test_value = 'test-value'
    test_md5 = md5s(test_value)

    # No arguments
    with unittest.TestCase():
        self.assertRaises(TypeError, md5)

    # Argument is not a string
    with unittest.TestCase():
        self.assertRaises(TypeError, md5, None)

    # No file exists
    with unittest.TestCase():
        self.assertRaises(IOError, md5, 'no-such-file')

    # Argument is a directory
    with unittest.TestCase():
        self.assertRaises(IOError, md5, os.getcwd())

    # Argument is a

# Generated at 2022-06-21 08:28:00.275350
# Unit test for function md5s
def test_md5s():
    data = b"this is a test"
    assert(md5s(data) == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3")



# Generated at 2022-06-21 08:28:03.926123
# Unit test for function md5s
def test_md5s():
    from ansible.module_utils.six import b
    src = b('foobar')
    assert md5s(src) == '8843d7f92416211de9ebb963ff4ce28125932878'



# Generated at 2022-06-21 08:28:06.630172
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") is not None
    assert checksum("/bin/python") is not None
    assert checksum("/bin/sh") is not None


# Generated at 2022-06-21 08:28:14.455540
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == "5eb63bbbe01eeed093cb22bb8f5acdc3"

# Generated at 2022-06-21 08:28:23.432187
# Unit test for function checksum
def test_checksum():
    try:
        import nose
    except ImportError:
        raise ImportError("Need python-nose installed to run unit tests")

    thisfile = __file__

    assert checksum(thisfile) == 'c1cf9a9d04b0f46e6efbeb01f423299e266894e8'
    assert checksum(thisfile) == checksum_s(open(thisfile).read())
    assert checksum_s("my message") == '5c9d101c5ed1e847b0924c5f6694b8ece5d5b5e5'


# Generated at 2022-06-21 08:28:26.002084
# Unit test for function checksum
def test_checksum():
    assert checksum_s('test_data') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-21 08:28:34.685055
# Unit test for function checksum_s
def test_checksum_s():
    # Reference data
    reference_data_file_path = os.path.abspath(__file__)
    reference_data_file_checksum = secure_hash(reference_data_file_path)
    reference_data_file_contents = open(reference_data_file_path, 'rb').read()
    reference_data_file_contents_checksum = secure_hash_s(reference_data_file_contents)

    # Test data

# Generated at 2022-06-21 08:28:45.737988
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Unit tests for Ansible checksum function '''
    import shlex
    import subprocess

    (rc, stdout, stderr) = module.run_command("echo -n data > /tmp/data")
    checksum1 = module.checksum("/tmp/data", "sha1")
    module.exit_json(checksum1=checksum1)
    module.fail_json(msg="should not reach this")
    checksum2 = module.checksum("/tmp/data", "sha224")
    module.exit_json(checksum2=checksum2)
    module.fail_json(msg="should not reach this")
    process = subprocess.Popen(shlex.split("echo -n data > /tmp/data"))
    process.wait()

# Generated at 2022-06-21 08:28:57.634607
# Unit test for function checksum
def test_checksum():
    assert checksum_s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert checksum_s(u'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert checksum_s('1') == '356a192b7913b04c54574d18c28d46e6'
    assert checksum_s('"1"') == 'f4c4e4e0932d8f0fa8dd33fa43ab292b'
    assert checksum_s('1 2 3') == 'de7c9b85b8b78aa6bc8a7a36f70a9071'

# Generated at 2022-06-21 08:29:01.429045
# Unit test for function checksum_s
def test_checksum_s():
    test1 = checksum_s('ansible')
    assert test1 == 'e87c0d93efa81ea258c735f9c64ca1e2d1deaebf', "%s did not match" % test1



# Generated at 2022-06-21 08:29:09.725315
# Unit test for function checksum
def test_checksum():
    '''
    Checksum: Make sure the checksums functions work
    '''
    import tempfile
    from ansible.compat.tests import unittest

    class TestChecksum(unittest.TestCase):

        def test_checksum_s(self):
            data = b'foo'
            test_hash = '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
            file_hash = checksum_s(data)
            self.assertEqual(test_hash, file_hash, msg="checksum failed on string")

        def test_checksum(self):
            (fd, fn) = tempfile.mkstemp()
            tmp = os.fdopen(fd, 'wb')
            data = b'foo'

# Generated at 2022-06-21 08:29:17.679397
# Unit test for function checksum_s
def test_checksum_s():
    ''' test_checksum_s '''
    import tempfile

    test_file = tempfile.NamedTemporaryFile(mode='w+b')
    data = 'abcde12345'
    test_file.write(data)
    test_file.seek(0)
    assert checksum_s(data) == checksum(test_file.name)
    test_file.close()

    data = 'abcd'
    assert checksum_s(data) != checksum_s(data + 'e')



# Generated at 2022-06-21 08:29:23.206853
# Unit test for function md5
def test_md5():
    if _md5 and checksum('/proc/cpuinfo') != md5('/proc/cpuinfo'):
        raise AnsibleError('Unit test for md5 function failed')
    if _md5 and checksum_s(b'test') != md5s(b'test'):
        raise AnsibleError('Unit test for md5 function failed')

# Generated at 2022-06-21 08:29:29.034910
# Unit test for function md5
def test_md5():
    assert(md5s("Hello") != None)


# Generated at 2022-06-21 08:29:33.573101
# Unit test for function md5
def test_md5():
    if _md5:
        assert md5('/bin/ls') == '8b87c1ff4b8a4d4ff27a962b4c928f3c'
    else:
        try:
            md5('/bin/ls')
            assert False, 'md5 should have raised a ValueError'
        except ValueError:
            pass

# Generated at 2022-06-21 08:29:40.326002
# Unit test for function checksum
def test_checksum():
    data = 'this is a string of data'
    data_sha1 = secure_hash_s(data)
    assert(checksum_s(data) == data_sha1)

    # Create a testfile with a known checksum
    f = open("testfile", "wb")
    f.write(bytes(data, encoding='utf-8'))
    f.close()

    f_sha1 = secure_hash("testfile")
    assert(checksum("testfile") == f_sha1)

    # Cleanup
    os.remove("testfile")

# Generated at 2022-06-21 08:29:45.627695
# Unit test for function md5s
def test_md5s():
    s = "this is some data"
    assert md5s(s) == 'd1918d8f06f3f64da76a0a61868ac366'

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-21 08:29:47.685995
# Unit test for function md5
def test_md5():
    """
    file: test_md5
    path: test/utils/test_md5.py
    """


# Generated at 2022-06-21 08:29:58.295311
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '67902fbe5e5f5349f4b894f4db9df9a0c4e59a7b'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'


if __name__ == "__main__":
    import sys, os

# Generated at 2022-06-21 08:30:01.168113
# Unit test for function md5s
def test_md5s():
    assert (md5s("test") == "098f6bcd4621d373cade4e832627b4f6")

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-21 08:30:06.942372
# Unit test for function checksum_s
def test_checksum_s():
    # Empty string
    assert secure_hash_s("", sha1) == "da39a3ee5e6b4b0d3255bfef95601890afd80709"
    # Fixed string
    assert secure_hash_s("Hello, World!", sha1) == "1c86e9f2da9b0a4e4e58f4f1a24afcbfb0fe1318"

# Generated at 2022-06-21 08:30:16.141865
# Unit test for function checksum
def test_checksum():
    import shutil
    import tempfile

    test_dir = tempfile.mkdtemp()
    f1 = open(os.path.join(test_dir, "foo1"), "w")
    f2 = open(os.path.join(test_dir, "foo2"), "w")
    f3 = open(os.path.join(test_dir, "foo3"), "w")
    for fd in [f1, f2, f3]:
        fd.write("They Might Be Giants")
    for fd in [f1, f2, f3]:
        fd.close()
    res1 = checksum(os.path.join(test_dir, "foo1"))
    res2 = checksum(os.path.join(test_dir, "foo2"))

# Generated at 2022-06-21 08:30:25.183671
# Unit test for function md5s
def test_md5s():
    ''' unit test for md5s function '''
    if not _md5:
        return

    assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"
    assert md5s("foo" + u'\xe4') == "f4e7a0d462e47db8c9b9a86ff3bf60b3"
    assert md5s("foo" + u'\xe4' * 100) == "c8b5f6b5ea5c5a6d5d8c2e6f5d7c2d9e"


# Generated at 2022-06-21 08:30:32.983347
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('123456') == '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92'

# Generated at 2022-06-21 08:30:38.555664
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s(b"abc123") == "40c02d72a29e22b59a9e7fa16c6e46d6cc5a3f5a"
    assert checksum_s(123) == "40c02d72a29e22b59a9e7fa16c6e46d6cc5a3f5a"
    assert checksum_s(None) == "da39a3ee5e6b4b0d3255bfef95601890afd80709"

# Generated at 2022-06-21 08:30:50.797033
# Unit test for function checksum_s
def test_checksum_s():
    # Create a file to test with
    fake_file = open('test', 'w')
    fake_file.write('test')
    fake_file.close()

    # Test that the checksum is the same as the one created by the
    # command line utility
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

    # Test that the checksum is the same as the one created by the
    # command line utility

# Generated at 2022-06-21 08:30:57.011294
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s(b'test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s(u'test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

# Generated at 2022-06-21 08:31:00.875697
# Unit test for function checksum
def test_checksum():
    assert checksum('../lib/ansible/module_utils/basic.py') == 'e761a9f8e0c1c67d48a0a0a5a8b80d5e5c0b54e5'


# Generated at 2022-06-21 08:31:08.885506
# Unit test for function md5s
def test_md5s():
    data = '0123456789' * 1000
    m1 = md5s(data)
    m2 = md5(os.path.join(os.path.dirname(__file__), 'test_md5s'))
    if m1 != '02c743b44e848d7c12160055a023f9a9' or m2 != '02c743b44e848d7c12160055a023f9a9':
        raise Exception("md5s() failed")

# Generated at 2022-06-21 08:31:15.291100
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum_s(u'abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    # Non-unicode strings should be rejected
    try:
        checksum_s(b'abc')
        assert False
    except TypeError:
        pass

# Generated at 2022-06-21 08:31:20.788667
# Unit test for function checksum_s
def test_checksum_s():
    d = 'hello world'
    sd = '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(d) == sd
    assert md5s(d) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-21 08:31:27.136992
# Unit test for function md5s
def test_md5s():
    print(('\n=== unit test for md5s() ===\n'))
    assert md5s('abc') == md5s('abc')
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s('ac') == '187ef4436122d1cc2f40dc2b92f0eba0'


# Generated at 2022-06-21 08:31:32.818207
# Unit test for function checksum
def test_checksum():
    assert checksum('changeme') == '26a5739cc2e1a9f9e9b7a04f1d27b788a72c6e61'
    assert checksum_s('changeme') == '26a5739cc2e1a9f9e9b7a04f1d27b788a72c6e61'



# Generated at 2022-06-21 08:31:39.830616
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello") == "5d41402abc4b2a76b9719d911017c592"



# Generated at 2022-06-21 08:31:42.446553
# Unit test for function checksum_s
def test_checksum_s():
    string = 'hello'
    checksum = checksum_s(string)
    expected = 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert expected == checksum

# Generated at 2022-06-21 08:31:45.696113
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-21 08:31:52.085168
# Unit test for function md5
def test_md5():
    ''' unit test for md5'''
    import tempfile
    (fd, fname) = tempfile.mkstemp()
    afile = os.fdopen(fd, 'w')
    afile.write('xyz')
    afile.close()

    assert md5(fname) == '9dd4e461268c8034f5c8564e155c67a6'
    os.remove(fname)

# Generated at 2022-06-21 08:31:59.644301
# Unit test for function md5s
def test_md5s():
    import random
    from ansible.module_utils.six import PY3
    if PY3:
        data = "".join(chr(random.randint(0, 0xFF)) for i in range(3))
    else:
        data = "".join(chr(random.randint(0, 0xFF)) for i in range(3)).encode("utf-8")  # PY3 does not accept byte to ord
    assert ("80dca62b0b0d219f" == md5s(data))



# Generated at 2022-06-21 08:32:02.314832
# Unit test for function checksum_s
def test_checksum_s():
    test_str = 'test string'
    test_hash = 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert test_hash == checksum_s(test_str)


# Generated at 2022-06-21 08:32:06.062392
# Unit test for function md5
def test_md5():
    if not _md5:
        return
    dstr = b'foobar'
    assert md5s(dstr) == '3858f62230ac3c915f300c664312c63f'
    assert md5(__file__) == md5s(open(__file__, 'rb').read())