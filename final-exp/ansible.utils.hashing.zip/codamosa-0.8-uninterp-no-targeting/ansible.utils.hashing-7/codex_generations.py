

# Generated at 2022-06-21 08:22:18.044344
# Unit test for function checksum
def test_checksum():
    from ansible.utils.path import makedirs_safe
    from tempfile import mkdtemp

    test_dir_path = os.path.dirname(os.path.realpath(__file__))
    module_utils_path = os.path.join(test_dir_path, 'unit', 'utils', 'module_utils')
    makedirs_safe(module_utils_path)
    tmp_dir = mkdtemp(prefix='unit-test-checksum', dir=module_utils_path)
    file1 = os.path.join(tmp_dir, 'foo')
    file2 = os.path.join(tmp_dir, 'bar')

# Generated at 2022-06-21 08:22:23.586488
# Unit test for function checksum
def test_checksum():
    assert checksum('lib/ansible/modules/core/network/eos/eos_config.py') == '9bba049a3901cfaad6bddc99d7aeaacb51e812c1'
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'


# Generated at 2022-06-21 08:22:25.999744
# Unit test for function md5s
def test_md5s():
    assert md5s('foobar') == '3858f62230ac3c915f300c664312c63f'



# Generated at 2022-06-21 08:22:33.895097
# Unit test for function checksum
def test_checksum():
    ''' test_checksum module function '''

    def _test_checksum(data, expected_results):
        for hash_name, hash_func in (('sha1', sha1), ('md5', _md5)):
            if not hash_func:
                continue
            hex_digest = hash_func(to_bytes(data)).hexdigest()
            if expected_results[hash_name] != hex_digest:
                return (False, "%s: expected %s, got %s" % (hash_name, expected_results[hash_name], hex_digest))
        return (True, '')

    # Test data obtained from http://www.di-mgt.com.au/sha_testvectors.html
    # and https://www.di-mgt.com.au/sha_testvectors.html

# Generated at 2022-06-21 08:22:41.981321
# Unit test for function checksum_s
def test_checksum_s():

    # Make sure that different calls with the same input produce the same output
    assert checksum_s("test") == checksum_s("test")
    assert checksum_s("test") == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"

    # Make sure that different calls with different inputs produce different outputs
    assert checksum_s("test") != checksum_s("test2")
    assert checksum_s("test2") != checksum_s("test")

# Generated at 2022-06-21 08:22:43.270872
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') != None

# Generated at 2022-06-21 08:22:47.521100
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s("echo 1") != "c66320d2ecd8c21e7e1275b5d5e5f0e8f5ee9e5c":
        raise ValueError("checksum_s failed")



# Generated at 2022-06-21 08:22:51.089318
# Unit test for function checksum
def test_checksum():
    checksum_file = './lib/ansible/module_utils/basic.py'

    if not os.path.exists(checksum_file):
        assert False, 'file %s is not exists' % checksum_file

    cksum = checksum(checksum_file)
    if not cksum:
        assert False, 'checksum of file %s is failed' % checksum_file

    assert len(cksum) == 40, 'checksum is invalid'



# Generated at 2022-06-21 08:23:01.750140
# Unit test for function checksum_s
def test_checksum_s():
    # Testing secure_hash_s
    s = "somepass"
    h = secure_hash_s(s)
    assert h == "c9d857ad6feba6607d66b1979f71e8f97e56a55a"

    s = "some password"
    h = secure_hash_s(s)
    assert h == "a4c6919c6e9635d25c9a1a2f60c7a32d57e11f71"

    s = "ansible rocks... really rocks"
    h = secure_hash_s(s)
    assert h == "3e4bec4b4c60b303a2c5d3bf5d5a5a99d5bdd8c7"


if __name__ == '__main__':
    test_checks

# Generated at 2022-06-21 08:23:11.270056
# Unit test for function md5
def test_md5():
    from ansible.module_utils import basic
    from ansible.modules.system import stat
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)
    path = os.path.realpath(__file__)
    stat_instance = stat.Stat(loader=loader, variable_manager=variable_manager, path=path)
    stat_instance.run()
    md5sum = stat_instance.md5sum

    md5sum_should_be = md5(path)
    if md5sum_should_be == md5sum:
        basic

# Generated at 2022-06-21 08:23:23.146742
# Unit test for function checksum_s
def test_checksum_s():
    ret = checksum_s('my data')
    assert ret == '3a1865e1d9b2e3b38c72d3a0464fb2a0e0f8c8b1', "%s != '3a1865e1d9b2e3b38c72d3a0464fb2a0e0f8c8b1'" % ret

# Generated at 2022-06-21 08:23:29.309677
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-21 08:23:33.560347
# Unit test for function checksum_s
def test_checksum_s():
    data = 'Hello World'
    digest = checksum_s(data)
    assert len(digest) == 40
    assert digest == '0a4d55a8d778e5022fab701977c5d840bbc486d0'



# Generated at 2022-06-21 08:23:37.948255
# Unit test for function md5
def test_md5():
    try:
        assert md5(__file__) == 'd41d8cd98f00b204e9800998ecf8427e'
    except ValueError:
        # On FIPS 140-2 compliant systems, md5 is not available
        pass


# Generated at 2022-06-21 08:23:49.859565
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py

    This is a test for module_utils.checksum
    '''

    import tempfile
    import os

    checksum_text = 'Hello, World!'
    tmpfd, tmpfile = tempfile.mkstemp()
    os.write(tmpfd, checksum_text)
    os.close(tmpfd)

    if checksum_s(checksum_text) != '0a4d55a8d778e5022fab701977c5d840bbc486d0':
        print("Text checksum test failed")
        return False

    if checksum(tmpfile) != '0a4d55a8d778e5022fab701977c5d840bbc486d0':
        print("File checksum test failed")
        return False


# Generated at 2022-06-21 08:23:58.297128
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum_s(u'abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'

    # test utf8
    assert checksum_s(u'\u273c') == '8d5762bc9bc2a2b37e4ef8a0a4a4a4e4'
    assert checksum_s(u'\u273c'.encode('utf-8')) == '8d5762bc9bc2a2b37e4ef8a0a4a4a4e4'
    assert checksum_s(u'\u273c'.encode('utf-16'))

# Generated at 2022-06-21 08:24:00.500714
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-21 08:24:09.968642
# Unit test for function checksum_s
def test_checksum_s():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec = dict(),
    )
    module.no_log = True
    play_context = PlayContext()
    play_context.no_log = True
    module._connection = Connection(play_context, 'local')
    test_data = 'This is a test'
    test_checksum = module._connection.checksum_s(test_data)
    assert(test_checksum == checksum_s(test_data))

# Generated at 2022-06-21 08:24:17.345526
# Unit test for function checksum_s
def test_checksum_s():
    #  Testing with SHA-1 Hashing Algorithm
    assert checksum_s('123', hash_func=sha1) == '40bd001563085fc35165329ea1ff5c5ecbdbbeef', "Failed to test SHA-1 Hashing Algorithm"

    #  Testing with MD5 Hashing Algorithm
    if _md5:
        assert checksum_s('123', hash_func=_md5) == '202cb962ac59075b964b07152d234b70', "Failed to test MD5 Hashing Algorithm"

# Generated at 2022-06-21 08:24:23.992738
# Unit test for function md5
def test_md5():
    assert(md5s('test') == '098f6bcd4621d373cade4e832627b4f6')
    assert(md5s('mozilla') == '08adc161411b2fddb3009be0f5d223c5')
    assert(md5s('mozilla\n') == '1b4a4af4d8b868071b37a9e17c2f01f8')

#
# Backwards compat functions.  Some modules include sha1s in their return values
# Continue to support that for now.
#


# Generated at 2022-06-21 08:24:32.681575
# Unit test for function md5
def test_md5():
    md5_value = md5(__file__)
    assert md5_value == '9d81f04f7e64c72b24e7c3d0d3ad2c42'



# Generated at 2022-06-21 08:24:35.246519
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-21 08:24:45.609749
# Unit test for function md5s
def test_md5s():

    # Can't run test if we're in FIPS mode.
    if not _md5:
        assert True
        return

    assert md5s('ansible') == 'a6fa0be636d2e72b47f7408b0a5a5a40'
    assert md5s("ansible\n") == 'd7d3e3b8e7b761279f04ea7eee6173ca'
    assert md5s("ansible\r\n") == '6c75a6f2f78031da1d313eed8c2924e4'
    assert md5s("ansible\r") == 'dda1e59aee3bc3c5759f28df64a683d7'


# Generated at 2022-06-21 08:24:49.698537
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('4giV7vB8eHWV7') == '1a37b7f2fbd28abf7a02e1220f7d66a9'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-21 08:24:57.720044
# Unit test for function md5s
def test_md5s():
    if _md5:
        # emtpy string
        assert md5s(b'') == 'd41d8cd98f00b204e9800998ecf8427e'
        # ascii string
        assert md5s(b'The quick brown fox jumps over the lazy dog') == '9e107d9d372bb6826bd81d3542a419d6'
        # unicode string
        assert md5s(u'The quick brown fox jumps over the lazy dog') == '9e107d9d372bb6826bd81d3542a419d6'

# Generated at 2022-06-21 08:25:07.741149
# Unit test for function md5
def test_md5():
    '''
    If a file exists, the output of this function should match the output of the md5sum command-line tool
    '''
    #
    # If the file doesn't exist, the output of this function should be None
    #
    if not os.path.exists('/etc/passwd'):
        raise Exception('/etc/passwd does not exist!')

    file_hash = md5('/etc/passwd')
    if file_hash is None:
        raise Exception('md5() returned None instead of a hash')
    #
    # Get the hash from the command-line tool and make sure it matches the output of md5()
    #
    import subprocess
    p = subprocess.Popen(['md5sum', '/etc/passwd'],stdout=subprocess.PIPE)
    file_hash

# Generated at 2022-06-21 08:25:11.955264
# Unit test for function md5
def test_md5():

    filename = "/path/to/file"
    secure_hash_mock = 'secure_hash'
    _md5_mock = '_md5'

    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    md5_orig = builtins.md5
    del builtins.md5


# Generated at 2022-06-21 08:25:17.455610
# Unit test for function md5
def test_md5():
    s = "hello"
    assert md5s(s) == "5d41402abc4b2a76b9719d911017c592"
    assert md5("/dev/null") == "d41d8cd98f00b204e9800998ecf8427e"

# Generated at 2022-06-21 08:25:20.082085
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('ansible') == 'b61e96b8de2706922b9d0f1f7c8e0999'
        assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-21 08:25:23.347310
# Unit test for function checksum_s
def test_checksum_s():
    data = 'If you feel your life is a waste\nTake a test\nDisco inferno'
    expected = 'a91ddf3a22b3affc6b9715d30e0a494db92e00d8'
    actual = checksum_s(data)
    assert actual == expected

# Generated at 2022-06-21 08:25:33.145664
# Unit test for function md5s
def test_md5s():
    data = to_bytes("mytestdata", errors='surrogate_or_strict')
    if (md5s(data) != 'c8740c1a37d9adcb9acf246087d0062d'):
        return False
    else:
        return True


# Generated at 2022-06-21 08:25:36.593111
# Unit test for function md5s
def test_md5s():
    assert(md5s("hello world") == '5eb63bbbe01eeed093cb22bb8f5acdc3')

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-21 08:25:43.866074
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(u'\xF0\x9F\x98\xA2') == '6ac789aecb3a3d3f817674a005a70f6caf9a9c0f'
    assert checksum_s(u'\xF0\x9F\x98\xA2', hash_func=_md5) == '1e67c76d6b878e832e22bde0e2c9b7d9'

# Generated at 2022-06-21 08:25:49.885202
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('The quick brown fox jumps over the lazy dog') == '9e107d9d372bb6826bd81d3542a419d6'
    assert md5s('The quick brown fox jumps over the lazy dog.') == 'e4d909c290d0fb1ca068ffaddf22cbd0'


# Generated at 2022-06-21 08:25:53.277189
# Unit test for function md5
def test_md5():
    s = "abcdefghijklmnopqrstuvwxyz"
    assert md5s(s) == "c3fcd3d76192e4007dfb496cca67e13b"
    assert md5s(s.encode('utf-8')) == "c3fcd3d76192e4007dfb496cca67e13b"
    assert md5s(s*100) == "7707d6ae4e027c70eea2a935c2296f21"
    assert md5s(s.encode('utf-8')*100) == "7707d6ae4e027c70eea2a935c2296f21"

# Generated at 2022-06-21 08:26:01.476014
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('world') == '7d793037a0760186574b0282f2f435e7'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-21 08:26:05.133241
# Unit test for function md5s
def test_md5s():
    ''' test_md5s() - unit test for md5s'''
    mymd5s = md5s('foo')
    assert mymd5s == 'acbd18db4cc2f85cedef654fccc4a4d8', mymd5s



# Generated at 2022-06-21 08:26:14.971161
# Unit test for function checksum_s
def test_checksum_s():
    clear_text = 'This is a test'
    encoded_clear_text = clear_text.encode('utf-8')

# Generated at 2022-06-21 08:26:17.538176
# Unit test for function checksum_s
def test_checksum_s():
    assert(checksum_s('Hello') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0')



# Generated at 2022-06-21 08:26:25.275809
# Unit test for function md5
def test_md5():
    ''' test_md5.py:  only works with python > 2.5, but imports md5 anyway '''
    import random
    import time
    random.seed(time.time())
    s = 'testing %s' % random.random()
    x = md5('./test_md5.py')
    assert(x != None)
    assert(len(x) == 32)
    y = md5s(s)
    assert(y != None)
    assert(len(y) == 32)
    assert(y == md5s(s))

# Generated at 2022-06-21 08:26:34.593360
# Unit test for function md5
def test_md5():
    ''' md5 unit test '''
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

# Generated at 2022-06-21 08:26:44.851025
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  tests for the checksum module '''

    import sys, os

    # before any ansible code uses the checksum function, we need to
    # set sys.argv, because the checksum function uses it to find
    # the name of the executable that is running.
    sys.argv = ['/bin/ansible', '-m', 'checksum', 'testhost']

    # this is needed so that checksum for python2.4 doesn't fail with "'ascii' codec can't encode character"
    reload(sys)
    sys.setdefaultencoding('utf-8')

    # we need a temp file to test the checksum functions on, so create it
    (fd, path) = tempfile.mkstemp(prefix="ansible_test_checksum_")
    file = os.fd

# Generated at 2022-06-21 08:26:56.258691
# Unit test for function checksum
def test_checksum():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.compat.tests import unittest

    class TestChecksum(unittest.TestCase):

        def test_checksum_s(self):
            self.assertEqual(checksum_s('foo'), '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33')
            self.assertEqual(checksum_s(AnsibleUnsafeText('föö')), '25d2b643c3925e9d596a57a3bdda8b7d448af68e')



# Generated at 2022-06-21 08:27:00.865822
# Unit test for function md5s
def test_md5s():
    if _md5:
        if md5s(b'foo') != 'acbd18db4cc2f85cedef654fccc4a4d8':
            return False
    return True

# Generated at 2022-06-21 08:27:04.742584
# Unit test for function md5s
def test_md5s():
    passwd = 'secret'
    passwd_hash1 = md5s(passwd).encode('utf-8')
    passwd_hash2 = md5(passwd).encode('utf-8')
    assert passwd_hash1 == passwd_hash2



# Generated at 2022-06-21 08:27:07.168525
# Unit test for function checksum_s
def test_checksum_s():
    if secure_hash_s('blah') != '2332ee1d4a4a7b1f9e902fc3d73b8ae8e2477148':
        raise Exception('checksum_s failed')

# Generated at 2022-06-21 08:27:11.271773
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('test', sha1) == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

# Generated at 2022-06-21 08:27:14.370764
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'



# Generated at 2022-06-21 08:27:22.560229
# Unit test for function md5
def test_md5():
    '''md5 unit test'''
    from ansible.compat.tests import unittest

    class Testmd5(unittest.TestCase):

        def test_md5_nofile(self):
            '''md5: no file'''
            filename = 'no_file_here'
            expected = None
            result = md5(filename)
            self.assertEqual(result, expected)

        def test_md5_file(self):
            '''md5: file'''
            filename = os.path.join(os.path.dirname(__file__), '../../../../HISTORY.rst')
            expected = '2b8bd57fba491302c9f9dabd845edf04'
            result = md5(filename)

# Generated at 2022-06-21 08:27:33.467393
# Unit test for function checksum
def test_checksum():
    assert secure_hash_s(u"foo") == u"0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    assert secure_hash_s(b"foo") == u"0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    assert secure_hash_s(u"") == u"da39a3ee5e6b4b0d3255bfef95601890afd80709"
    assert secure_hash_s(b"") == u"da39a3ee5e6b4b0d3255bfef95601890afd80709"



# Generated at 2022-06-21 08:27:42.085647
# Unit test for function checksum_s
def test_checksum_s():
    test_string = 'hello world!'
    test_sha = '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    test_sha_ret = checksum_s(test_string)
    print('test_checksum_s checksum of string:', test_sha_ret)
    assert test_sha_ret == test_sha


# Generated at 2022-06-21 08:27:50.040901
# Unit test for function checksum
def test_checksum():
    assert checksum_s("12345") == "827ccb0eea8a706c4c34a16891f84e7b"
    assert checksum_s("12345", hash_func=sha1) == "827ccb0eea8a706c4c34a16891f84e7b"


if __name__ == '__main__':
    import sys
    test_checksum()
    if len(sys.argv) > 1:
        print("sha1", secure_hash(sys.argv[1]))
        if _md5:
            print("md5", secure_hash(sys.argv[1], md5))
        for i in sys.argv[1:]:
            print(secure_hash(i), i)

# Generated at 2022-06-21 08:27:57.994842
# Unit test for function checksum
def test_checksum():
    import tempfile

    os.environ['ANSIBLE_TEST_CHECKSUM'] = "yes"

    # Make a temporary file
    (handle, filename) = tempfile.mkstemp()
    test_data = "ansible"
    os.write(handle, test_data)
    os.close(handle)

    # Compute the hash and make sure it matches
    hash = checksum(filename)
    assert hash == sha1(test_data).hexdigest()

    # Remove the file
    os.unlink(filename)

# Generated at 2022-06-21 08:28:02.244088
# Unit test for function checksum
def test_checksum():
    ''' test checksum function '''

    assert checksum('foobar') == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert checksum('foobar') == secure_hash('foobar')



# Generated at 2022-06-21 08:28:07.298914
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(b'hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-21 08:28:12.442224
# Unit test for function checksum
def test_checksum():
    import os
    import tempfile
    with tempfile.NamedTemporaryFile() as temp:
        temp.write('abc123')
        temp.flush()
        csum = checksum(temp.name)
        fsum = secure_hash(temp.name)
        assert csum == fsum
        ssum = secure_hash_s('abc123')
        assert csum == ssum
    os.unlink(temp.name)

if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-21 08:28:20.600638
# Unit test for function checksum
def test_checksum():
    h1 = checksum_s("hello")
    assert h1 == "5d41402abc4b2a76b9719d911017c592"
    fd, fname = tempfile.mkstemp(dir='/tmp')
    with os.fdopen(fd, "w") as f:
        f.write("hello world")
    h2 = checksum(fname)
    assert h2 == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"

# Generated at 2022-06-21 08:28:22.554881
# Unit test for function md5s
def test_md5s():
    assert(md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8')

# Generated at 2022-06-21 08:28:25.677630
# Unit test for function md5s
def test_md5s():
    result = md5s('test')
    assert result == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-21 08:28:34.506450
# Unit test for function md5s
def test_md5s():
    """
    Runs a series of tests using md5s and raises an error if any fail.
    Tests are taken from:
    https://crackstation.net/hashing-security.htm
    """
    global md5s


# Generated at 2022-06-21 08:28:44.568782
# Unit test for function checksum_s
def test_checksum_s():
    input  = "foobar"
    checksum_value = "8843d7f92416211de9ebb963ff4ce28125932878"
    checksum = checksum_s(input)
    assert checksum == checksum_value, '%s should be %s' % (checksum, checksum_value)
    print("checksum of %s: %s" %(input, checksum))


# Generated at 2022-06-21 08:28:48.883894
# Unit test for function md5s
def test_md5s():
    data = "hello"
    my_hexdigest = md5s(data)
    assert my_hexdigest == '5d41402abc4b2a76b9719d911017c592'

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-21 08:28:52.454749
# Unit test for function md5
def test_md5():
    # This example hash is for the string "Ansible"
    assert md5s('Ansible') == 'a8e43771f2185bb7f520a3b45355f5c5', 'md5s failed'
    # This example hash is for the string "Ansible"
    assert md5('lib/ansible/module_utils/basic.py') == '2fa1d499f82b7c18b143d104c32e20b8', 'md5 failed'

# Generated at 2022-06-21 08:28:55.691322
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s('hello') != '5d41402abc4b2a76b9719d911017c592':
        assert False


# Generated at 2022-06-21 08:29:02.662009
# Unit test for function md5
def test_md5():
    DATA = 'This is a test of the emergency broadcast system, if this were a real test, you would panic, no really, panic now.'
    assert md5s(DATA) == '6aeb0c09302b6e75c6a1f97cfb27a6a9'
    assert md5(__file__) == 'e23f0e1e2d3bf3e97ff2c9f9d0d9c0e8'

# Generated at 2022-06-21 08:29:10.171834
# Unit test for function checksum
def test_checksum():
    filename = './test.py'
    hash_func = sha1
    hex_digest = checksum(filename, hash_func)
    print("The sha1 checksum of %s is %s" % (filename, hex_digest))

    filename = './test.py'
    hash_func = _md5
    hex_digest = checksum(filename, hash_func)
    print("The md5 checksum of %s is %s" % (filename, hex_digest))

    data = "hello world"
    hex_digest = checksum_s(data, hash_func)
    print("The checksum of %s is %s" % (data, hex_digest))


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:29:22.322130
# Unit test for function checksum_s
def test_checksum_s():
    import ansible.utils.crypto as crypto
    import types

    assert crypto.checksum_s("Hello World!") == crypto.secure_hash_s("Hello World!")
    assert type(crypto.checksum_s("Hello World!")) is types.StringType

    # Make sure the function can handle unicode
    assert crypto.checksum_s(u"Hello World!") == secure_hash_s(u"Hello World!")
    assert type(crypto.checksum_s(u"Hello World!")) is types.UnicodeType

    # Make sure the function can handle binary objects
    assert crypto.checksum_s(b"Hello World!") == crypto.secure_hash_s(b"Hello World!")
    assert type(crypto.checksum_s(b"Hello World!")) is types.StringType

    #

# Generated at 2022-06-21 08:29:28.165545
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    else:
        try:
            md5s('hello world')
            assert False
        except ValueError:
            pass

# Generated at 2022-06-21 08:29:36.892946
# Unit test for function md5s
def test_md5s():

    from ansible.compat.tests import unittest


# Generated at 2022-06-21 08:29:48.463142
# Unit test for function checksum_s
def test_checksum_s():
    ''' unit test for checksum_s '''

    # Assert empty file
    assert checksum_s("") == "da39a3ee5e6b4b0d3255bfef95601890afd80709", "Empty string fails SHA1 checksum"

    # Assert short file
    short_file_data = "The quick brown fox jumps over the lazy dog."

    short_file_sha1 = "2fd4e1c67a2d28fced849ee1bb76e7391b93eb12"
    assert checksum_s(short_file_data) == short_file_sha1, "Short string fails SHA1 checksum"

    # Assert long file

# Generated at 2022-06-21 08:29:57.701100
# Unit test for function checksum_s
def test_checksum_s():
    # Test if the checksum_s returns valid checksum hash for the input string
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'


# Generated at 2022-06-21 08:30:03.389375
# Unit test for function checksum
def test_checksum():
    assert secure_hash('/bin/ls') == '6acbc0d9f9a9b39e05992f1a17b7a47d'
    assert secure_hash('/bin/ls', sha1) == '6acbc0d9f9a9b39e05992f1a17b7a47d'

if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-21 08:30:05.943933
# Unit test for function md5s
def test_md5s():
    r1 = md5s('Hello world')
    assert r1 == '5eb63bbbe01eeed093cb22bb8f5acdc3'



# Generated at 2022-06-21 08:30:12.428687
# Unit test for function md5s
def test_md5s():
    ''' test md5s function '''

    if not _md5:
        return

    expected_result = 'e2eaa66a0ee309a36c32555a1a11b9ef'
    result = md5s('testing')
    assert result == expected_result, \
        "md5s failed to return expected string '%s', got: %s" % (expected_result, result)



# Generated at 2022-06-21 08:30:15.186634
# Unit test for function md5
def test_md5():

    assert md5("/bin/ls") == md5("/bin/ls")
    assert md5("/bin/ls") != md5("/bin/cat")

# Generated at 2022-06-21 08:30:18.155858
# Unit test for function checksum_s
def test_checksum_s():
    for string in ["abc", "def", "abcd", "", "a"*1024]:
        assert checksum_s(string) == checksum_s(string)

# Generated at 2022-06-21 08:30:22.122780
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s(b'test') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-21 08:30:26.029912
# Unit test for function checksum_s
def test_checksum_s():
    # test successful checksum
    actual = checksum_s('hello world')
    expected = '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert actual == expected

# Generated at 2022-06-21 08:30:30.657734
# Unit test for function checksum_s
def test_checksum_s():
    string = 'hello world!'
    truehash = '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    result = checksum_s(string)
    assert truehash == result
    print('tests passed!')

if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-21 08:30:33.613541
# Unit test for function checksum
def test_checksum():
    assert checksum('test/files/chars', _md5) == '747d573dd92e1b9f9b51d5b6c8c8ca1f'

# Generated at 2022-06-21 08:30:41.445767
# Unit test for function md5s
def test_md5s():
    ''' unit test for function md5s '''
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-21 08:30:46.637513
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'b8daba0e6639c7f7800a9a87c828640b89d1c7a0'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:30:50.889059
# Unit test for function md5
def test_md5():
    import tempfile

    with tempfile.NamedTemporaryFile('w') as f:
        f.write('test123')
        f.flush()

        assert md5(f.name) == '25e03de69d78ac9e0bc6bcbac2751925'

# Generated at 2022-06-21 08:30:53.876919
# Unit test for function checksum_s
def test_checksum_s():
    ''' Assert a random string has the expected checksum '''

    assert '3ff3b4efe9c9c9f9cca494a39325eca0c0f306b8' == checksum_s('random_string','sha1')

# Generated at 2022-06-21 08:30:58.491219
# Unit test for function md5
def test_md5():
    import tempfile
    tmp_file = tempfile.NamedTemporaryFile('wb')
    tmp_file.write(b'hello')
    tmp_file.flush()
    assert md5(tmp_file.name) == '5d41402abc4b2a76b9719d911017c592'
    tmp_file.close()


# Generated at 2022-06-21 08:31:10.083494
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s(b"a") == "0cc175b9c0f1b6a831c399e269772661"
        assert md5s(b"abc") == "900150983cd24fb0d6963f7d28e17f72"
        assert md5s(b"message digest") == "f96b697d7cb7938d525a2f31aaf161d0"
        assert md5s(b"abcdefghijklmnopqrstuvwxyz") == "c3fcd3d76192e4007dfb496cca67e13b"

# Generated at 2022-06-21 08:31:11.541809
# Unit test for function md5s
def test_md5s():
    assert md5s(b'test') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-21 08:31:15.079771
# Unit test for function checksum
def test_checksum():

    str_to_test = "hello"
    ref_str_checksum = "5d41402abc4b2a76b9719d911017c592"
    str_checksum = checksum_s(str_to_test)

    assert str_checksum == ref_str_checksum

# Generated at 2022-06-21 08:31:26.775778
# Unit test for function checksum_s
def test_checksum_s():
    import datetime
    from os.path import join, dirname, realpath
    import sys

    filename = sys.argv[0]
    if os.path.islink(filename):
        filename = realpath(filename)
    # The checksum algorithm must match with the algorithm in
    # ShellModule.checksum() method
    checksum = secure_hash_s

# Generated at 2022-06-21 08:31:37.488317
# Unit test for function checksum
def test_checksum():
    testfile = os.path.join(os.path.dirname(__file__), "test_checksum.tmp")
    infile = open(testfile, "wb")
    infile.write(b'This is a test')
    infile.close()
    fsum = checksum(testfile)

    assert fsum == '6693b6e0e17dca94c7e4fd09651de0a8d6d77b6e'

    infile = open(testfile, "wb")
    infile.write(b'This is a test.  This is another test')
    infile.close()
    fsum2 = checksum(testfile)

    assert fsum2 != fsum

    os.unlink(testfile)


# Generated at 2022-06-21 08:31:45.378714
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  This checksum function needs a unit test '''
    pass

# Generated at 2022-06-21 08:31:52.125703
# Unit test for function checksum_s
def test_checksum_s():

    if secure_hash_s("hello") != '5d41402abc4b2a76b9719d911017c592':
        print("Error in secure_hash_s: 'hello'")
    if secure_hash_s("hello", sha1) != 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0':
        print("Error in secure_hash_s: 'hello'")


# Generated at 2022-06-21 08:31:57.026166
# Unit test for function md5
def test_md5():
    # If a string is passed, it can be retrieved with md5s and
    # md5.
    string = "hello"
    string_md5_result = md5s(string)
    assert string_md5_result == '5d41402abc4b2a76b9719d911017c592'
    # If a file is passed, it can be retrieved with md5,
    # but not with md5s.
    file_md5_result = md5(__file__)
    assert file_md5_result == 'c5717d3bfe108e3a9f9e1eec64e80128'

# Generated at 2022-06-21 08:31:59.906034
# Unit test for function md5s
def test_md5s():
    data = 'test'
    m = md5s(data)
    if m != '098f6bcd4621d373cade4e832627b4f6':
        raise AssertionError(m)

# Generated at 2022-06-21 08:32:02.936822
# Unit test for function checksum
def test_checksum():
    filename = 'CHANGELOG'
    assert secure_hash(filename) is not None
    assert checksum(filename) is not None
    assert os.path.exists('test/ansible/module_utils/_checksum.py') == True
    assert checksum('test/ansible/module_utils/_checksum.py') is not None