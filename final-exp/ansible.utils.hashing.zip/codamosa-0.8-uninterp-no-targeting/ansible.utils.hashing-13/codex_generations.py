

# Generated at 2022-06-21 08:22:09.507829
# Unit test for function md5
def test_md5():
    filename = 'testfile'
    md5sum = md5(filename)
    assert md5sum == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-21 08:22:12.766910
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"

# Generated at 2022-06-21 08:22:23.684015
# Unit test for function checksum_s
def test_checksum_s():
    """Check function checksum_s."""

    # Set up test inputs.
    inputs = ["abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
              "",
              "12345678901234567890123456789012345678901234567890123456789012345678901234567890"]

    # Set up test expectations.
    expectations = ["5f4dcc3b5aa765d61d8327deb882cf99",
                    "da39a3ee5e6b4b0d3255bfef95601890afd80709",
                    "8215ef0796a20bcaaae116d3876c664a"]

    # Run tests

# Generated at 2022-06-21 08:22:29.256381
# Unit test for function checksum_s
def test_checksum_s():
    sample1 = b'hello'
    answer1 = '5d41402abc4b2a76b9719d911017c592'
    sample2 = b'hello'
    answer2 = '5d41402abc4b2a76b9719d911017c592'

    assert checksum_s(sample1) == answer1
    assert checksum_s(sample2) == answer2

# Generated at 2022-06-21 08:22:35.863281
# Unit test for function checksum
def test_checksum():
    def _sha1s(s):
        return sha1(to_bytes(s)).hexdigest()
    def _sha1(filename):
        return secure_hash(filename, sha1)
    assert checksum_s('hello') == _sha1s('hello')
    assert checksum_s(b'hello') == _sha1s(b'hello')
    assert checksum_s(u'hello') == _sha1s(u'hello')
    assert checksum('test/utils/checksum_file') == _sha1('test/utils/checksum_file')
    assert checksum_s('hello') == secure_hash_s('hello')
    assert checksum_s(b'hello') == secure_hash_s(b'hello')
    assert checksum_s(u'hello') == secure_hash_s

# Generated at 2022-06-21 08:22:38.946396
# Unit test for function md5s
def test_md5s():
    md5 = md5s("The quick brown fox jumps over the lazy dog")
    assert md5 == "9e107d9d372bb6826bd81d3542a419d6"

# Generated at 2022-06-21 08:22:44.220801
# Unit test for function md5
def test_md5():
    assert md5("/etc/passwd") == "f2c7bbc153e631c9f0a7a36596d0bfaf"
    assert md5("/bin/ls") == "12ada9a47a5d1e7d87111292ce608e63"

# Generated at 2022-06-21 08:22:48.144760
# Unit test for function checksum_s
def test_checksum_s():
    data = 'foobar'
    expected = '8843d7f92416211de9ebb963ff4ce28125932878'
    assert checksum_s(data) == expected

# Generated at 2022-06-21 08:22:51.466084
# Unit test for function md5
def test_md5():
    assert md5('ansible/module_utils/__init__.py') == '9025c0a4ca7a8e1e9d7bcbdc1f3a0511'


# Generated at 2022-06-21 08:23:02.220974
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") in ["4a8d09b709c64a6fa3033ba4ad02ed1e4cae9a38", "4a8d09b709c64a6fa3033ba4ad02ed1e4cae9a3a"]
    assert checksum("/bin/false") in ["2206fbc4b133f4d99d066b09c2a9cb95cb32e6b7", "2206fbc4b133f4d99d066b09c2a9cb95cb32e6b1"]

# Generated at 2022-06-21 08:23:08.904516
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/ls /') == 'b47a2c7f5eb503c2e7cdc61c1d17f0ad'


# Generated at 2022-06-21 08:23:13.288945
# Unit test for function checksum_s
def test_checksum_s():
    for hash_func in [sha1, md5]:
        h = hash_func()
        if h is not None:
            assert checksum_s('hello', hash_func=hash_func) == '5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-21 08:23:22.276002
# Unit test for function md5
def test_md5():
    data = 'The quick brown fox jumped over the lazy dogs.'
    assert md5s(data) == '55454e028b383d53ef140829ede8c2f0'
    data = 'The quick brown fox jumped over the lazy dog.'
    assert md5s(data) == 'd7e328b00aa0f7d8b95c920d7f1f12c9'
    try:
        md5s(None)
    except:
        pass
    else:
        assert False, "md5s of None should raise an exception"

# Generated at 2022-06-21 08:23:31.951053
# Unit test for function checksum
def test_checksum():

    # Basic functionality test
    result = checksum_s('foobar')
    assert result == '8843d7f92416211de9ebb963ff4ce28125932878', result

    # Functionality test for empty data
    result = checksum_s('')
    assert result == 'da39a3ee5e6b4b0d3255bfef95601890afd80709', result

    # Functionality test for unicode data
    result = checksum_s('é')
    assert result == '1a6df08bf1c60810c437143bef9e0f7c8889a78d', result

    # Functionality test for changing encoding
    result = checksum_s('é', sha1)

# Generated at 2022-06-21 08:23:34.196210
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-21 08:23:41.500405
# Unit test for function checksum_s
def test_checksum_s():
    import tempfile
    import shutil

    checksum_val = 'd41d8cd98f00b204e9800998ecf8427e'
    tempdir = tempfile.mkdtemp()
    filename = os.path.join(tempdir, 'test')
    with open(filename, 'a') as f:
        f.write('')
    assert checksum_s(filename) == checksum_val
    shutil.rmtree(tempdir)

# Generated at 2022-06-21 08:23:52.898168
# Unit test for function md5
def test_md5():
    from ansible.module_utils.basic import AnsibleModule
    a = AnsibleModule({})
    assert a.md5('/dev/null') == '4a8e0ea40e6a0a0a2c2c2affd03b14f0'
    assert a.md5('/etc/issue') == '5a9189b35f10e7c0493293ce64f7c3f1'
    assert a.md5('/bin/ls') == 'e0ad7f8d03b7cee0f6b5a6bde1d9e7c9'
    assert a.md5('/bin/false') == '02aae65b7c3ac2f2d723da709f6b419a'

# Generated at 2022-06-21 08:23:59.677928
# Unit test for function md5s
def test_md5s():
    import sys
    if sys.version_info >= (2, 5):
        try:
            import hashlib
            md5_present = target_md5 == hashlib.md5().hexdigest()
        except ImportError:
            # hashlib not present
            import md5
            md5_present = target_md5 == md5.new().hexdigest()
    else:
        md5_present = 0
    if md5_present:
        if md5s('') != target_md5:
            raise AssertionError('md5s of empty string != target_md5')
    else:
        try:
            md5s('')
            raise AssertionError('md5s available but should not be on this platform')
        except ValueError:
            pass


# Generated at 2022-06-21 08:24:08.492095
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/passwd') is not None
    assert checksum('/bogus/filename') is None
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert md5('/etc/passwd') is not None
    assert md5('/bogus/filename') is None
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-21 08:24:12.883176
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_s(b'foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'

# Generated at 2022-06-21 08:24:21.402262
# Unit test for function checksum_s
def test_checksum_s():
    import tempfile
    (fd1, testfile1) = tempfile.mkstemp()
    os.write(fd1, b'test')
    os.close(fd1)
    (fd2, testfile2) = tempfile.mkstemp()
    os.write(fd2, b'test')
    os.close(fd2)

    if secure_hash_s('test') != secure_hash(testfile1) != secure_hash(testfile2):
        raise AnsibleError('checksum_s functions are broken')

# Generated at 2022-06-21 08:24:32.730138
# Unit test for function md5
def test_md5():

    # Test good md5 checksum return
    good_md5 = secure_hash("data/file-to-checksum.txt", _md5)
    if md5("data/file-to-checksum.txt") != good_md5:
        raise AssertionError("md5 return value error")

    # Test bad md5 checksum return
    if md5("data/file-not-to-checksum.txt") != None:
        raise AssertionError("md5 return value error")

    # Test good md5s checksum return
    if md5s("data/string-to-checksum.txt") != "1ebb6e0cc7c0b3ca2c4412e85d1b65e3":
        raise AssertionError("md5 checksum return value error")



# Generated at 2022-06-21 08:24:40.080374
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s('pw') != 'b109f3bbbc244eb82441917ed06d618b9008dd09b3befd1b5e07394c706a8bb980b1d7785e5976ec049b46df5f1326af5a2ea6d103fd07c95385ffab0cacbc86':
      raise KeyError("SHA1 implementation is wrong")

if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-21 08:24:48.033047
# Unit test for function md5s
def test_md5s():
    import os
    import tempfile
    test_string = """Hello world!"""
    test_digest = "ed076287532e86365e841e92bfc50d8c"
    assert md5s(test_string) == test_digest

    # Test that we can read files and that they match
    tmp_fd, tmp_filename = tempfile.mkstemp()
    with os.fdopen(tmp_fd, 'wb') as fp:
        fp.write(to_bytes(test_string, errors='surrogate_or_strict'))

    assert md5(tmp_filename) == test_digest

    os.unlink(tmp_filename)


# Generated at 2022-06-21 08:24:50.108747
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-21 08:25:00.800655
# Unit test for function md5s
def test_md5s():
    '''secure_hash_s should be able to generate SHA-1 and MD5 checksums'''
    import os
    import random
    import string

    expected_sha1 = \
        'b5d5c5f5b68a188e3ca3decf9e9ea7d6c76b6f8e'
    expected_md5 = \
        '6ff846f9f9c2d2a459a794a81428febc'

    # Random string of lower and upper case chars
    test_data = ''.join(
        random.choice(string.ascii_letters) for i in range(1000))

    assert secure_hash_s(test_data) == expected_sha1
    assert md5s(test_data) == expected_md5

    # File test
    test_

# Generated at 2022-06-21 08:25:07.912620
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for ansible.utils.checksum.checksum function '''

    import tempfile
    import os

    try:
        (fd, name) = tempfile.mkstemp(dir='/tmp')
        f = os.fdopen(fd, 'w+')
        content = '# Ansible managed: /tmp/tmp_file.j9ZhJ7AjxW\n'
        f.write(content)
        f.close()

        assert checksum(name) == 'd754e92b0a823c57f682b10fadc3530037342405'

    finally:
        os.remove(name)

# Generated at 2022-06-21 08:25:13.303798
# Unit test for function md5
def test_md5():
    data = '"77b59c975e139512ec1dff7f95b169fd"'
    assert(md5s('"77b59c975e139512ec1dff7f95b169fd"') is not None)
    assert(md5s(data) == md5s('"77b59c975e139512ec1dff7f95b169fd"'))
    assert(md5s(data) != md5s('"87b59c975e139512ec1dff7f95b169fd"'))


# Generated at 2022-06-21 08:25:20.312628
# Unit test for function checksum
def test_checksum():
    testfile = "testfile"

    file = open(testfile, "w")
    for i in range (1, 1 * 1000 * 1000):
        file.write("%s" % i)
    file.close()

    for hash in (sha1, _md5):
        hash_value = secure_hash(testfile, hash)
        assert hash_value
        assert isinstance(hash_value, str)

    os.remove(testfile)


# Generated at 2022-06-21 08:25:24.532125
# Unit test for function md5
def test_md5():
    expected = "7815696ecbf1c96e6894b779456d330e"
    assert(expected == md5("checksum.py"))


# Generated at 2022-06-21 08:25:31.104960
# Unit test for function md5s
def test_md5s():
    test_string = 'hello world'
    assert md5s(test_string) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-21 08:25:34.808552
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    digest = md5("/bin/ls")
    assert digest == '48e2cd2d09c7f8bf8cdf5c225f5dbb00'


# Generated at 2022-06-21 08:25:43.937303
# Unit test for function checksum_s
def test_checksum_s():
    ''' test_checksum_s is simple test to ensure checksum_s is working '''

    check_data = 'this is a test of a checksum'
    check_result = 'd6c2462f5d0435aef9dba7448b5e5f1ecf36fe6b'
    test_result = checksum_s(check_data)
    assert test_result == check_result, 'checksum_s returned bad checksum.  Expected %s.  Got %s' % (check_result, test_result)


# FIXME: Do we need this at all?  It can't actually be unit tested...

# Generated at 2022-06-21 08:25:48.918065
# Unit test for function md5
def test_md5():
    import tempfile
    s = 'hello world'
    fd, fname = tempfile.mkstemp()
    os.write(fd, s)
    os.close(fd)
    assert '5eb63bbbe01eeed093cb22bb8f5acdc3' == md5(fname)
    os.unlink(fname)


# Generated at 2022-06-21 08:25:57.973065
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('\x00') == '2f72f28393cae99391324d3e1e2d12c6f32d0b22'
    assert checksum_s('a') == '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8'
    assert checksum_s('b') == 'e9d71f5ee7c92d6dc9e92ffdad17b8bd49418f98'
    assert checksum_s('c') == 'e4da3b7fbbce2345d7772b0674a318d5'

# Generated at 2022-06-21 08:26:00.935902
# Unit test for function md5s
def test_md5s():
    assert md5s("asdf") == '912ec803b2ce49e4a541068d495ab570'



# Generated at 2022-06-21 08:26:03.051394
# Unit test for function md5
def test_md5():
    assert(md5s('test') == '098f6bcd4621d373cade4e832627b4f6')


# Generated at 2022-06-21 08:26:12.922444
# Unit test for function md5s
def test_md5s():
    ''' function md5s '''
    from ansible.compat.tests import unittest
    from ansible.module_utils.six.moves import StringIO

    class TestMD5S(unittest.TestCase):
        def setUp(self):
            self._saved_stderr = sys.stderr
            self._saved_stdout = sys.stdout
            sys.stderr = StringIO()
            sys.stdout = StringIO()

        def tearDown(self):
            sys.stderr = self._saved_stderr
            sys.stdout = self._saved_stdout

        def test_md5s_1(self):
            ''' function md5s '''
            if _md5 is None:
                return

# Generated at 2022-06-21 08:26:20.468324
# Unit test for function checksum
def test_checksum():
    ''' unit test for checksum '''

    import random
    import string

    def my_random_string(size):
        ''' return a random string '''
        random_char_list = [random.choice(string.ascii_letters + string.digits) for _ in range(size)]
        random_string = ''.join(random_char_list)
        return random_string
    TESTFILE_CONTENTS_1 = my_random_string(1024 * 1024)
    TESTFILE_CONTENTS_2 = my_random_string(1024 * 1024 + 10)
    TESTFILE = "testfile"
    TESTFILE_RENAMED = "testfile_renamed"

    # Create the testfile

# Generated at 2022-06-21 08:26:23.640338
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello world") == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'



# Generated at 2022-06-21 08:26:29.191906
# Unit test for function md5s
def test_md5s():
    assert md5s("test") == "098f6bcd4621d373cade4e832627b4f6"


# Generated at 2022-06-21 08:26:33.430591
# Unit test for function checksum_s
def test_checksum_s():
    ''' checksum_s() basic tests '''
    if secure_hash_s('test') != 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3':
        raise Exception('ansible.utils.checksum_s() failed basic test')


# Generated at 2022-06-21 08:26:35.528699
# Unit test for function md5
def test_md5():
    assert md5s("foobar") == "3858f62230ac3c915f300c664312c63f"
    assert md5("test/utils/test_module_utils.py") == "b1d72f64c10baa5fb0a15ea589738d34"

# Generated at 2022-06-21 08:26:41.543893
# Unit test for function checksum_s
def test_checksum_s():
    data = 'hello world'
    assert checksum_s(data) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    data = 'world hello'
    assert checksum_s(data) == 'e37ca9688a229b8ac3b49e3d35a7e239536c8de0'


# Generated at 2022-06-21 08:26:48.050219
# Unit test for function checksum_s
def test_checksum_s():
    '''
    Ansible hash functions (hashes) tests

    We test that the ansible hash functions return the correct values.
    '''

    # failing test case
    test_sha = checksum_s('John is a very nice guy')
    return test_sha == 'd077f244b0a2eb8a0f84c64ece0f9f29e1b3eae3'



# Generated at 2022-06-21 08:26:58.234340
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("/bin/ls") == "9cee8256f6a0b6e3c3b1f6b1bf6b00f0"
    assert checksum_s("/bin/false") == "c0eacb8d99e88cc235b0cbc9d7dd3e1a"
    assert checksum_s("/bin/true") == "d5c84f5f5c5d5b834ec0581a94f1e39c"
    assert checksum_s("/bin/bad_filename") is None
    # Note, sha1 is the only hash algorithm compatible with python2.4 and with FIPS-140 mode (as of 11-2014)
    sha1_hash = secure_hash_s("/bin/ls")
    assert sha1_

# Generated at 2022-06-21 08:27:03.665327
# Unit test for function checksum
def test_checksum():
    h1 = checksum("/bin/ls")
    h2 = checksum("/bin/sh")
    assert h1 != h2, "Different files have the same checksum"
    h1 = checksum("/bin/ls")
    h2 = checksum("/bin/ls")
    assert h1 == h2, "Same files have different checksum"



# Generated at 2022-06-21 08:27:08.507597
# Unit test for function checksum
def test_checksum():

    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        f.write(b'hello')
        f.flush()
        f.seek(0)

        c = checksum(f.name)
        assert c == '5d41402abc4b2a76b9719d911017c592'

    c = checksum_s('hello')
    assert c == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-21 08:27:15.334540
# Unit test for function checksum
def test_checksum():
    '''
    Checksum Unit Test
    '''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='str')
        )
    )
    path = module.params['path']

    result = checksum(path)

    module.exit_json(checksum=result)



# Generated at 2022-06-21 08:27:24.044553
# Unit test for function md5
def test_md5():
    import tempfile
    import os

    (fd, fname) = tempfile.mkstemp()
    try:
        os.write(fd, "Apple")
        os.close(fd)

        h = md5(fname)
        if h != '1f3870be274f6c49b3e31a0c6728957f':
            print("Failed md5 test 1.  Got %s" % h)
            return False
        h1 = md5s("hello")
        if h1 != '5d41402abc4b2a76b9719d911017c592':
            print("Failed md5 test 2.  Got %s" % h1)
            return False
        return True
    finally:
        os.remove(fname)


# Generated at 2022-06-21 08:27:37.336191
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s(u'hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s(u'hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-21 08:27:40.368225
# Unit test for function md5s
def test_md5s():
    string = 'hello'
    md5_sha1 = md5s(string)
    assert md5_sha1 == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-21 08:27:42.682288
# Unit test for function checksum
def test_checksum():
    print(checksum('test/files/test.py'))
    print(checksum_s('test'))


# Generated at 2022-06-21 08:27:50.558472
# Unit test for function checksum
def test_checksum():
    import shutil
    import tempfile

    test1_str = "test1"
    test1_sha1 = "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"
    test2_str = "test2"
    test2_sha1 = "e2d0fe1585a63ec6009c8016ff8dda8b17719a6a"

    # Test str
    assert checksum_s(test1_str) == test1_sha1
    assert checksum_s(test2_str) == test2_sha1

    # Test file
    test1_tmpfile = tempfile.NamedTemporaryFile()
    test1_tmpfile.write(to_bytes(test1_str))
    test1_tmpfile.flush()
   

# Generated at 2022-06-21 08:28:02.075967
# Unit test for function checksum_s
def test_checksum_s():
    import random
    import string
    import unittest

    def random_string(length):
        return ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(length))

    def random_bytes(length):
        # arbitrary but consistent seed
        random.seed(12345)
        return b''.join(chr(random.randrange(256)) for _ in range(length))

    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    for hash_func in [sha1, _md5]:
        for val in ['abc', random_string(1000)]:
            s_val = val.encode('utf-8')
            b_val = random_bytes(1000)

            # s_val should hash to the same

# Generated at 2022-06-21 08:28:04.602639
# Unit test for function md5s
def test_md5s():
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'


# Generated at 2022-06-21 08:28:13.050543
# Unit test for function md5
def test_md5():
    import tempfile
    from io import BytesIO

    assert md5('/bin/cat') == 'de7c9b85b8b78aa6bc8a7a36f70a90701c9db4d9'
    assert md5('/usr/bin/python') == '04a1be3a3f3270c8d77c2b30d10e1c22'
    assert md5('/totally/bogus') is None

    fd, fname = tempfile.mkstemp(prefix='ansible-test-')

# Generated at 2022-06-21 08:28:20.943855
# Unit test for function md5
def test_md5():
    '''Return true if the md5 hash of a file is equal to the given md5 hash.  False otherwise.'''
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    path = os.path.join(os.path.dirname(__file__), 'test_md5_data.txt')
    return md5(path) == '025c6f76f8b90c6bcd5e961d44123cc5'

# Generated at 2022-06-21 08:28:31.237332
# Unit test for function checksum
def test_checksum():
    # test with a real file
    file_1 = '/bin/ls'
    file_1_checksum = 'db04887f87e674c6cf05e01f357b7d66'
    assert(checksum(file_1) == file_1_checksum)

    # test with a string
    file_2_string = 'This is a test'
    file_2_checksum = '3f3a3a3a895fb3ab1ddc4bf3cd47583f'
    assert(checksum_s(file_2_string) == file_2_checksum)

    # test with a file that does not exist
    file_3_does_not_exist = '/dev/null/foo'
    assert(checksum(file_3_does_not_exist) is None)

# Generated at 2022-06-21 08:28:34.042875
# Unit test for function checksum
def test_checksum():
    data = "foobarbaz"
    assert checksum_s(data) == "37b51d194a7513e45b56f6524f2d51f2"


# Generated at 2022-06-21 08:28:42.359566
# Unit test for function md5
def test_md5():
    ''' test_md5()

    Returns true if all tests pass.

    >>> test_md5()
    True
    '''

    # Create dummy file
    try:
        fh = open("test_md5", "x")
        fh.write("this is the message to be hashed")
        fh.close()
    except (IOError, OSError) as e:
        print("Error creating file test_md5: %s" % e)
        return False
    else:
        if md5("test_md5") == "7e55123f0c7d2e2bafb7fef26f8e9a15":
            os.unlink("test_md5")
            return True
        else:
            return False



# Generated at 2022-06-21 08:28:53.800652
# Unit test for function md5
def test_md5():
    test_string_1 = "hello world"
    test_string_2 = "goodbye world"
    test_file_1 = ".ansible_test_md5_file_01"

    if os.path.exists(test_file_1):
        os.remove(test_file_1)

    # Test function md5s(s)
    md5s_1 = md5s(test_string_1)
    assert md5s_1 == "5eb63bbbe01eeed093cb22bb8f5acdc3"

    md5s_2 = md5s(test_string_2)
    assert md5s_2 == "d4e6e17667555c1b9d938e73b29f5b2e"

    assert md5s_1 != md5s_

# Generated at 2022-06-21 08:29:03.851974
# Unit test for function md5
def test_md5():
    ''' ansible.utils.hash.md5 '''

    md5_output = md5('hash_test_file')
    sha1_output = secure_hash('hash_test_file')
    fail_msg = "WARNING: Output of ansible.utils.hash.md5() is different with the output of ansible.utils.hash.secure_hash()"

    assert md5_output == '9dd852e76b1f1a7e1f6d0e8edaf56155', fail_msg
    assert sha1_output == "f72f91ffc3fd3fd3dffb74351875e2aebd9dcd9e", fail_msg



# Generated at 2022-06-21 08:29:10.989406
# Unit test for function md5
def test_md5():
    import shutil
    import tempfile
    test_file = tempfile.mkstemp()
    test_file_name = test_file[1]
    test_file_handle = test_file[0]
    os.write(test_file_handle, b"foo")
    os.close(test_file_handle)
    try:
        md5_digest = md5(test_file_name)
        assert md5_digest == "acbd18db4cc2f85cedef654fccc4a4d8"
    finally:
        os.remove(test_file_name)

if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print('Syntax: %s <path>' % sys.argv[0])
        sys

# Generated at 2022-06-21 08:29:23.000330
# Unit test for function md5s
def test_md5s():
    test1 = md5s('hello world')
    assert test1 == '5eb63bbbe01eeed093cb22bb8f5acdc3', 'test of md5s failed, expected 5eb63bbbe01eeed093cb22bb8f5acdc3 got %s' % test1

    test2 = md5s('hello')
    assert test2 == '5d41402abc4b2a76b9719d911017c592', 'test of md5s failed, expected 5d41402abc4b2a76b9719d911017c592 got %s' % test2

    # test an empty string
    test3 = md5s('')

# Generated at 2022-06-21 08:29:26.118749
# Unit test for function md5
def test_md5():
    md5 = md5s(b"1234567890")
    assert md5 == "25f9e794323b453885f5181f1b624d0b"

# Generated at 2022-06-21 08:29:29.778510
# Unit test for function checksum_s
def test_checksum_s():
    data = 'hello world'
    h1 = secure_hash_s(data, hash_func=sha1)
    assert h1.startswith('2aae')

# Generated at 2022-06-21 08:29:36.259243
# Unit test for function checksum
def test_checksum():
    filename = 'test/ansible/utils/test_checksums'
    checksum = '2f0bfe7ba2d6f78ae6a1c6f1fb7a208d9a9b7e0f'
    assert checksum == secure_hash(filename)
    checksum = 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert checksum == secure_hash(filename, hash_func=_md5)

if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_checksum()

# Generated at 2022-06-21 08:29:46.557546
# Unit test for function md5s
def test_md5s():
    test = md5s("foo")
    assert test == "acbd18db4cc2f85cedef654fccc4a4d8"
    test = md5s("bar")
    assert test == "37b51d194a7513e45b56f6524f2d51f2"
    test = md5s("")
    assert test == "d41d8cd98f00b204e9800998ecf8427e"
    test = md5s("This is a longer string.  http://www.example.com")
    assert test == "b0f30b03bf8b1bfa9d7e7747dbece53c"

# Generated at 2022-06-21 08:29:55.292078
# Unit test for function checksum
def test_checksum():
    assert checksum_s(b"foo") == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_s(b"foo") != checksum_s(b"bar")
    assert checksum_s(b"foo") != checksum_s(b"foobar")
    assert checksum_s(u"foo") == checksum_s(b"foo")


# Generated at 2022-06-21 08:30:04.761006
# Unit test for function md5
def test_md5():
    """Test md5 function.

    Check if the md5 function returns the same result as the md5sum
    command.
    """
    import tempfile
    import os

    data = "hello world"
    filename = tempfile.mktemp()
    open(filename, "w").write(data)
    res = md5(filename)
    os.unlink(filename)
    assert res == '5eb63bbbe01eeed093cb22bb8f5acdc3'



# Generated at 2022-06-21 08:30:08.434123
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "6bd12e164e8d9fbec91802f0d2f11225ebc837e7"
    assert checksum("/does/not/exist") is None


# Generated at 2022-06-21 08:30:12.258092
# Unit test for function checksum
def test_checksum():
    p = os.path.join(os.path.dirname(__file__), 'change_detector.py')
    c = checksum(p)
    print("%s checksum is: %s" % (p, c))


# Generated at 2022-06-21 08:30:18.307601
# Unit test for function checksum_s
def test_checksum_s():
   import unittest
   def test_similar(a,b):
       threshold = 0.95
       a_len = len(a)
       b_len = len(b)
       n = 0
       for i in range(0, min(a_len,b_len)):
          if a[i] == b[i]:
             n += 1
       return (float(n) / max(a_len,b_len)) > threshold
   class TestChecksum_s(unittest.TestCase):
      def test_similar(self):
          self.assertTrue(test_similar(checksum_s('test','sha1'),'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'),
                          "Checksum 'test' with sha1 is not similar")

# Generated at 2022-06-21 08:30:24.986032
# Unit test for function md5
def test_md5():
    data = "abc"
    res = md5s(data)
    assert res == "900150983cd24fb0d6963f7d28e17f72"
    assert md5("lib/ansible/modules/core/test/test.py") == "b5932a3c4918e98cb39cb471be3745fb"

# Generated at 2022-06-21 08:30:35.377190
# Unit test for function checksum
def test_checksum():
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('Hello World') == '2ef7bde608ce5404e97d5f042f95f89f1c232871'
    assert checksum_s(u'Hello World') == '2ef7bde608ce5404e97d5f042f95f89f1c232871'
    assert checksum_s(u'Hello World', hash_func=_md5) == '65a8e27d8879283831b664bd8b7f0ad4'

# Generated at 2022-06-21 08:30:40.467678
# Unit test for function md5s
def test_md5s():
    ''' md5s.py: Test md5s() function '''

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            data=dict(required=True, type='str'),
        ),
        supports_check_mode=True
    )

    # Test expected conditions
    result = md5s(module.params['data'])

    module.exit_json(changed=False, md5sum=result)


# Generated at 2022-06-21 08:30:49.780575
# Unit test for function checksum_s
def test_checksum_s():
    value = "hello world"
    assert checksum_s(value) == secure_hash_s(value)
    assert checksum_s(value+"\n") == secure_hash_s(value+"\n")
    assert checksum_s(value.encode()) == secure_hash_s(value.encode())
    assert checksum_s(value) != secure_hash_s(value+"\n")
    assert checksum_s(value) != secure_hash_s(value+"\n", _md5)

# Generated at 2022-06-21 08:30:54.424816
# Unit test for function checksum
def test_checksum():
    from ansible.module_utils.six import PY3
    from random import Random
    from tempfile import mkstemp
    from shutil import rmtree
    import os
    import stat

    # We create a random seed to create a new testing file
    # 10th of KB is enough to test
    seed = str(Random().random())[2:]
    test_file = mkstemp(prefix='ansible-test-checksum-%s-' % seed, suffix='.tmp')[1]
    dir_path = os.path.dirname(test_file)
    data = b'a' * int(10e2)

# Generated at 2022-06-21 08:30:57.874933
# Unit test for function checksum
def test_checksum():
    test_string = 'foobar'
    result = secure_hash_s(test_string)
    assert len(result) == 40, "Result string not 40 characters; result string is " + result


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:31:13.020491
# Unit test for function checksum
def test_checksum():
    file1 = '/etc/hosts'
    file2 = '/etc/selinux/config'
    if os.path.exists(file1) and os.path.exists(file2):
        if checksum(file1) == checksum(file2):
            print("ERROR: %s and %s should not have the same checksum" %
                  (file1, file2))
        elif checksum(file1) != checksum(file1):
            print("ERROR: %s and %s should have the same checksum" %
                  (file1, file1))
        else:
            print("SUCCESS: %s and %s have different checksums as expected" %
                  (file1, file2))

# Generated at 2022-06-21 08:31:17.408562
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '98c615784ccb5fe59bfdb058cc55ec2a'

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-21 08:31:20.239842
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-21 08:31:23.836949
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert len(md5s('hello world')) == 32


# Generated at 2022-06-21 08:31:34.778266
# Unit test for function checksum
def test_checksum():
    import tempfile

    filename = tempfile.mktemp()
    open(filename, 'w').close()
    sum1 = checksum(filename)
    open(filename, 'w').close()
    sum2 = checksum(filename)
    os.unlink(filename)

    # if sum1 is None, then file may still be open, so try again
    if sum1 is None:
        open(filename, 'w').close()
        os.unlink(filename)

    assert sum1 is not None
    assert sum2 is not None
    assert sum1 == sum2

    # Try a tempdir
    dirname = tempfile.mkdtemp()
    sum3 = checksum(dirname)
    assert sum3 is None


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:31:38.819530
# Unit test for function checksum_s
def test_checksum_s():
    data = u'Hello World!'
    expected_result = sha1()
    data = to_bytes(data, errors='surrogate_or_strict')
    expected_result.update(data)
    assert checksum_s(data) == expected_result.hexdigest()


# Generated at 2022-06-21 08:31:45.370391
# Unit test for function checksum
def test_checksum():
    import shutil
    import tempfile
    import stat

    # Write a temporary file
    (tmpfd, tmpfile) = tempfile.mkstemp()
    os.write(tmpfd, b"Hello world")
    os.close(tmpfd)

    # Test if the checksum of the temporary file is correct
    assert secure_hash(tmpfile) == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"

    # Change the file mode
    os.chmod(tmpfile, stat.S_IRUSR)

    # Test if the checksum of the temporary file is correct
    assert secure_hash(tmpfile) == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"

    # Cleanup
    os.un

# Generated at 2022-06-21 08:31:47.593168
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-21 08:31:55.949594
# Unit test for function md5
def test_md5():
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abc\n') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abc\r\n') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abc\r') == '900150983cd24fb0d6963f7d28e17f72'

# Generated at 2022-06-21 08:31:58.631501
# Unit test for function md5s
def test_md5s():
    md5sum = md5s("Hello World")
    assert md5sum == 'b10a8db164e0754105b7a99be72e3fe5'
