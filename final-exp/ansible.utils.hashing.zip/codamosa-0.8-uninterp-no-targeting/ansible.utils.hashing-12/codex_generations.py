

# Generated at 2022-06-21 08:22:17.425961
# Unit test for function checksum
def test_checksum():
    test_filename = os.path.join(os.path.dirname(__file__), 'test.txt')
    assert checksum(test_filename) == '8e1e03d9a911a19c1bb7cd2d285a2a7e84ee20ba'
    assert checksum_s(b"hello worl") == 'a7d93e2ddf90eaf686f6c9b6d0ed631d1b2e56b4'

# Generated at 2022-06-21 08:22:27.734192
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert checksum_s("hello", hash_func=sha1) == "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d"
    assert checksum_s("HELLO") == "e05b5c39e7578f3a3a3dce3a5bfb11a9"
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("HELLO") == "e05b5c39e7578f3a3a3dce3a5bfb11a9"



# Generated at 2022-06-21 08:22:32.497146
# Unit test for function md5
def test_md5():
    import tempfile

    n = 20
    data = b"1" * n

    h1 = md5(__file__)
    h2 = md5s(data)

    f = tempfile.NamedTemporaryFile()
    f.write(data)
    f.seek(0)
    h3 = md5(f.name)

    assert(h1 is not None)
    assert(h2 is not None)
    assert(h3 is not None)

# Generated at 2022-06-21 08:22:36.505244
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 08:22:40.364119
# Unit test for function md5
def test_md5():
    from ansible.plugins.loader import find_plugin
    test_filename = find_plugin("action_plugins")
    assert(md5(test_filename) == "e3423f09407afbdcfef27b8afb9881b7")

# Generated at 2022-06-21 08:22:45.930537
# Unit test for function md5
def test_md5():
    assert md5('lib/ansible/modules/core/system/ping.py') == '94ab3d03e2b2f84497f60761c9ce22ec'
    assert md5('lib/ansible/modules/core/system/ping.py') == md5s('lib/ansible/modules/core/system/ping.py')

# Generated at 2022-06-21 08:22:47.271484
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-21 08:22:54.294778
# Unit test for function md5
def test_md5():
    data = "hello world"
    a_hash = md5s(data)
    assert a_hash == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    a_hash = md5("/etc/hosts")
    assert a_hash == "723abf5f60e6d5a6b25a6dc9ffd2f3a3"

if __name__ == "__main__":
    test_md5()

# Generated at 2022-06-21 08:23:02.683852
# Unit test for function checksum_s
def test_checksum_s():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})

    def check_s(in_str, expected):
        cr = checksum_s(in_str)
        module.fail_json(msg="%s != %s" % (cr, expected))

    check_s('foo', '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33')
    check_s('foo\n', 'acbd18db4cc2f85cedef654fccc4a4d8')



# Generated at 2022-06-21 08:23:04.182348
# Unit test for function md5
def test_md5():
    try:
        print(md5('/etc/motd'))
    except ValueError as e:
        print(e)
        print("This is expected behavior in FIPS mode.")

# Generated at 2022-06-21 08:23:10.256990
# Unit test for function md5s
def test_md5s():
    '''validate that md5s returns the correct checksum'''
    if _md5:
        result = md5s('this is a data string')
        assert result == 'cbb3b3d1511c1f867e4672d9f9e39577'

# Generated at 2022-06-21 08:23:23.704083
# Unit test for function md5s
def test_md5s():
    import os
    import stat
    import tempfile

    # create a temp file
    fd, tmppath = tempfile.mkstemp()

    # write some known data into it
    f = os.fdopen(fd, "w")
    f.write("hello")
    f.close()

    # ensure known file mode
    os.chmod(tmppath, 0o600)

    # make sure stat worked
    st = os.stat(tmppath)
    assert stat.S_IMODE(st.st_mode) == 0o600

    # check the file hash
    assert md5(tmppath) == md5s("hello")

    # clean up
    os.remove(tmppath)

if __name__ == "__main__":
    test_md5s()

# Generated at 2022-06-21 08:23:26.194986
# Unit test for function md5
def test_md5():
    assert md5s('Hello World') == 'b10a8db164e0754105b7a99be72e3fe5'


# Generated at 2022-06-21 08:23:33.784835
# Unit test for function md5
def test_md5():
    import filecmp
    import tempfile
    import shutil
    # Create a temp directory
    tmpdir = tempfile.mkdtemp()
    # Create the text file
    testfile = os.path.join(tmpdir, "foo.txt")
    lines = ["This is line 1\n",
             "This is line 2\n",
             "This is line 3\n"]
    open(testfile, "w").writelines(lines)
    assert md5(testfile) == "77b1237b5001784f8381e1e3d950a38a"
    # Change the text file
    lines = ["This is line 1\n",
             "This is line 2\n",
             "This is line 3\n",
             "This is line 4\n"]
    open(testfile, "w").writelines

# Generated at 2022-06-21 08:23:40.752942
# Unit test for function checksum
def test_checksum():
    import tempfile
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        f.write('hello')
    assert checksum(path) == '2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824'
    os.unlink(path)

# Generated at 2022-06-21 08:23:42.666085
# Unit test for function checksum
def test_checksum():
    assert '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed' == checksum(__file__)


if __name__ == '__main__':
    print("checksum of this file: %s" % checksum(__file__))

# Generated at 2022-06-21 08:23:45.094006
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-21 08:23:55.474983
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s("hello") == "5d41402abc4b2a76b9719d911017c592":
        print("checksum_s: passed test 1")
    else:
        print("checksum_s: failed test 1 - got %s instead of %s" % (checksum_s("hello"), "5d41402abc4b2a76b9719d911017c592"))

    if checksum_s("hello", "sha") == "5d41402abc4b2a76b9719d911017c592":
        print("checksum_s: passed test 2")

# Generated at 2022-06-21 08:23:57.595697
# Unit test for function md5
def test_md5():
    a = md5(__file__)
    b = md5(__file__)
    assert a == b, "md5 failed"

# Generated at 2022-06-21 08:24:00.553532
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'


# Generated at 2022-06-21 08:24:14.059270
# Unit test for function md5

# Generated at 2022-06-21 08:24:18.481761
# Unit test for function md5s
def test_md5s():
    success = False
    if md5s("aaa") == '47bce5c74f589f4867dbd57e9ca9f808':
        success = True
    else:
        print("md5s() did not produce the correct result.  Got: %s" % md5s("aaa"))
    return success



# Generated at 2022-06-21 08:24:21.848496
# Unit test for function checksum_s
def test_checksum_s():
    ''' functional test for checksum_s()'''
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-21 08:24:33.410963
# Unit test for function checksum
def test_checksum():
    if not _md5:
        print('no md5 checksum implementation present (possibly FIPS)')
    else:
        print('md5 checksum implementation present')
    print('sha1 checksum implemenation present')
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum('test/support/files/chars', hash_func=_md5) == '9ef1862cb00ece39efbe20e2e7da35fd'

# Generated at 2022-06-21 08:24:40.228498
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello') == checksum_s('hel' + 'lo')

if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-21 08:24:48.858878
# Unit test for function checksum_s
def test_checksum_s():
    # Test sha1
    sha1_expected = 'e47396475b2e7c1b33f57430d0c8eecaf1c9d9b9'
    sha1_actual = secure_hash_s('ansible')
    assert sha1_actual == sha1_expected, 'sha1 test failed (%s != %s)' % (sha1_expected, sha1_actual)

    sha1_expected = '701c56f1e3c3e3b0d2b7bfde8a204d0102969d39'
    sha1_actual = secure_hash_s('ansible', sha1)

# Generated at 2022-06-21 08:24:54.270194
# Unit test for function md5s
def test_md5s():
    if md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3":
        return True
    else:
        return False

if __name__ == '__main__':
    if test_md5s() == True:
            print("*** Test passed ***")
    else:
            print("!!! FAIL !!!")

# Generated at 2022-06-21 08:24:57.455781
# Unit test for function md5s
def test_md5s():
    data = 'foo bar baz'
    assert md5s(data) == '0b595d15acd8e710a918cc3f3d0d2dd2'



# Generated at 2022-06-21 08:25:01.113178
# Unit test for function checksum_s
def test_checksum_s():
    data = b"123456789"
    c = checksum_s(data)
    print("data=%s hash=%s" % (data, c))
    assert c == "e807f1fcf82d132f9bb018ca6738a19f"

# Generated at 2022-06-21 08:25:02.568493
# Unit test for function checksum_s
def test_checksum_s():
    assert (checksum_s('hello world') != None)


# Generated at 2022-06-21 08:25:14.128836
# Unit test for function md5s
def test_md5s():
    print("Test md5s")
    print("Original")
    print(secure_hash_s("test"))
    print("Test file")
    print(md5s("test"))
    assert(md5s("test") == "098f6bcd4621d373cade4e832627b4f6")
    print("Unit test PASSED!")


# Generated at 2022-06-21 08:25:18.189216
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('test/ansible/module_utils/basic.py').startswith('a7649025e5c')

# Generated at 2022-06-21 08:25:21.839994
# Unit test for function md5s
def test_md5s():
    # Generated by running: echo -n 'test_string' | python -c "import hashlib;print hashlib.md5('test_string').hexdigest()"
    assert md5s('test_string') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-21 08:25:32.928931
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    try:
        checksum_s('hello', sha1, extra_arg='does not work')
        assert False
    except TypeError as e:
        pass



# Generated at 2022-06-21 08:25:43.733671
# Unit test for function checksum
def test_checksum():
    import random
    import string

    # Create random string
    tmpdir = "/tmp/ansible_test_dir"
    random_string = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(64))
    # Create temporary file and write random string to the file
    filename = os.path.join(tmpdir, "ansible_test_file")
    with open(filename, 'wb') as f:
        f.write(random_string)
        f.close()
    # Calculate checksum of the random string and the temporary file
    checksum_s_result = checksum_s(random_string)
    checksum_result = checksum(filename)
    # Delete the temporary file
    os.remove(filename)
    os.rmdir(tmpdir)


# Generated at 2022-06-21 08:25:51.381816
# Unit test for function checksum
def test_checksum():
    '''
    ansible.utils.checksum unit test
    '''
    import shutil
    import tempfile
    import os

    (handle, fname) = tempfile.mkstemp(prefix='ansible-tmp-')
    os.write(handle, b'ansible')
    os.close(handle)

    try:
        assert checksum(fname) == '1e50210a920f83c7b2b2a14b63f1e35d0b7cda5e'
    finally:
        try:
            os.unlink(fname)
        except Exception as e:
            pass

# Generated at 2022-06-21 08:25:54.020117
# Unit test for function md5s
def test_md5s():
    data = 'Hello world !'
    hash = '0a0a9f2a6772942557ab5355d76af442'
    assert md5s(data) == hash


# Generated at 2022-06-21 08:26:01.377228
# Unit test for function checksum
def test_checksum():
    test_string = "abc123"
    result = checksum_s(test_string)
    assert result == "40bd001563085fc35165329ea1ff5c5ecbdbbeef", result
    test_file = "md5sum.py"
    result = checksum(test_file)
    assert result == "bf3dabb27f5b8078368c5187f92285ea", result

# Generated at 2022-06-21 08:26:06.027088
# Unit test for function md5
def test_md5():
    filename = "testfile_for_testing_ansible_hash.txt"
    f = open(filename, "w+")
    f.write("1234567890")
    f.close()
    assert(md5(filename) == "81fe8bfe87576c3ecb22426f8e57847382917acf")
    os.unlink(filename)

# Generated at 2022-06-21 08:26:07.850636
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-21 08:26:15.269147
# Unit test for function md5
def test_md5():
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5('test/ansible/modules/files/is_link.py') == 'd700b8a56e2f2b1a6656c9e9e8a21f15'

# Generated at 2022-06-21 08:26:18.548567
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s('hello world', sha1) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed':
        print('checksum_s is working correctly')
    else:
        print('checksum_s is not working correctly')

# Generated at 2022-06-21 08:26:29.547438
# Unit test for function checksum
def test_checksum():
   # Testing with hexdigest
   assert checksum_s('ansible') == '36c6e93867b5eaad3e076a3d54d1dd8c8d36eebb'
   assert checksum_s(u'ansible') == '36c6e93867b5eaad3e076a3d54d1dd8c8d36eebb'
   assert checksum_s(None) == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'

   filename = os.path.join(os.path.dirname(__file__), 'test_checksum.data')

# Generated at 2022-06-21 08:26:33.372481
# Unit test for function md5
def test_md5():
    assert md5s('foobar') == '3858f62230ac3c915f300c664312c63f'
    assert md5('/bin/ls') == '18b6f9fb1dbea6b6a4b6fd4fb6d771e6'

# Generated at 2022-06-21 08:26:36.431296
# Unit test for function md5s
def test_md5s():
    test_string = "This is a test of md5s"
    assert md5s(test_string) == 'a3fb3d5b0a8ff8a9a40f51c7fc5baf66'


# Generated at 2022-06-21 08:26:41.696045
# Unit test for function checksum
def test_checksum():
    import tempfile
    tfile = tempfile.NamedTemporaryFile()
    chash = checksum(tfile.name)
    tfile.write('foo')
    tfile.flush()
    assert checksum(tfile.name) != chash


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:26:53.619340
# Unit test for function md5
def test_md5():
    from ansible.compat.tests import unittest

    class TestChecksum(unittest.TestCase):
        def setUp(self):
            self.testfile = "testfile"
            open(self.testfile, 'a').close()

        def tearDown(self):
            os.remove(self.testfile)

        def runTest(self):
            # function md5 and md5s
            self.assertEqual(md5s("test"), "098f6bcd4621d373cade4e832627b4f6")
            self.assertEqual(md5(self.testfile), "d41d8cd98f00b204e9800998ecf8427e")

# Run unit test directly
if __name__ == "__main__":
    import unittest
    unitt

# Generated at 2022-06-21 08:26:56.838892
# Unit test for function md5s
def test_md5s():
    # md5("foo") == acbd18db4cc2f85cedef654fccc4a4d8
    assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"

# Generated at 2022-06-21 08:27:05.967877
# Unit test for function md5s
def test_md5s():
    ''' test md5s functionality '''
    stringA = '1234567890'
    stringB = '0987654321'
    stringC = '1234567890'
    hashA = md5s(stringA)
    hashB = md5s(stringB)
    hashC = md5s(stringC)
    if hashA == hashB:
        print("Error: test_md5s failed first test.")
        return False
    if hashA != hashC:
        print("Error: test_md5s failed second test.")
        return False
    print("test_md5s passed")
    return True


# Generated at 2022-06-21 08:27:11.807867
# Unit test for function checksum
def test_checksum():
    assert checksum('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert checksum_s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-21 08:27:24.965577
# Unit test for function checksum
def test_checksum():
    """Test checksum and checksum_s."""
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class TestChecksum(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_checksum_str(self):
            with patch('ansible.module_utils.basic.AnsibleModule') as mock_am:
                mock_am_instance = mock_am.return_value
                mock_am_instance.params = {"data": "data"}
                result = checksum_s()

# Generated at 2022-06-21 08:27:28.614064
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s("12345") != "827ccb0eea8a706c4c34a16891f84e7b":
        return False
    return True


# Generated at 2022-06-21 08:27:40.154918
# Unit test for function md5
def test_md5():
    # create a test file
    file_name = 'test_md5.tmp'
    with open(file_name, 'wb') as f:
        f.write(b'hello world')

    # calculate the digest with module function
    digest = md5(file_name)

    # calculate the digest with system command: md5sum
    with open(file_name, 'rb') as f:
        import subprocess
        p = subprocess.Popen(['md5sum'], stdin=f, stdout=subprocess.PIPE, universal_newlines=True)
        out, _ = p.communicate()
        import re
        m = re.match(r'^([0-9a-f]+)', out)
        if m:
            digest_cmd = m.group(1)
        else:
            raise

# Generated at 2022-06-21 08:27:43.979791
# Unit test for function md5s
def test_md5s():
    assert md5s("foobar") == '3858f62230ac3c915f300c664312c63f'
    try:
        md5('/tmp/doesnotexist')
        assert False
    except AnsibleError:
        pass


# Generated at 2022-06-21 08:27:48.721696
# Unit test for function md5
def test_md5():
    test_str = '''
    hello world
    this is a test file
    for the md5 function
    '''
    test_file = 'test_md5.tmp'
    open(test_file, 'w').write(test_str)
    try:
        assert md5(test_file) == md5s(test_str)
        os.remove(test_file)
    except:
        os.remove(test_file)
        raise

# Generated at 2022-06-21 08:27:52.275199
# Unit test for function md5
def test_md5():
    data = 'test'
    data_md5 = '098f6bcd4621d373cade4e832627b4f6'
    assert(data_md5 == md5s(data))

test_md5()

# Generated at 2022-06-21 08:27:55.543290
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("12345") == "827ccb0eea8a706c4c34a16891f84e7b"


# Generated at 2022-06-21 08:27:58.629737
# Unit test for function md5s
def test_md5s():
    md5_1 = md5s('test')
    assert md5_1 == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-21 08:28:03.219607
# Unit test for function md5s
def test_md5s():
    '''
    ansible.utils.hashing.md5s unit test
    '''
    if not _md5:
        return True
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    return True


# Generated at 2022-06-21 08:28:07.062190
# Unit test for function checksum_s
def test_checksum_s():
    if secure_hash_s('Hello World') != '2ef7bde608ce5404e97d5f042f95f89f1c232871':
        raise AnsibleError('sha1 of Hello World not correct')



# Generated at 2022-06-21 08:28:16.522075
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'



# Generated at 2022-06-21 08:28:27.289684
# Unit test for function checksum
def test_checksum():
    '''
    ansible.utils.checksum checksum
    '''

    def _mock_open(filename):
        if filename == 'missing.file':
            raise IOError(2, 'No such file or directory')
        else:
            return [
                '{',
                '\t"changed": false,',
                '\t"ping": "pong"',
                '}',
            ]

    original_open = open

    try:
        open = _mock_open

        # File is present
        assert checksum('module_stdout.log') == 'b2a2bd7dfc35430127d5a8b1e83e75ad'

        # File is missing
        assert checksum('missing.file') is None
    finally:
        open = original_open



# Generated at 2022-06-21 08:28:35.498732
# Unit test for function md5
def test_md5():
    '''Test md5 function'''
    from ansible import constants as C
    from ansible.module_utils.six import StringIO
    from tempfile import NamedTemporaryFile
    from ansible.utils.hashing import md5, md5s
    import shutil

    # Test with non existent file
    assert md5('/does/not/exist') is None

    # Test with directory
    assert md5(C.DEFAULT_LOCAL_TMP) is None

    # Test with file
    a_string = 'I am a string.'
    digest = '5c5b30f91ced429c7eda52a0b9c7f362'
    a_string_io = StringIO(a_string)

# Generated at 2022-06-21 08:28:38.783822
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return

    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-21 08:28:46.599084
# Unit test for function md5
def test_md5():
    import tempfile
    from ansible.utils.path import makedirs_safe
    from ansible.compat.six.moves import StringIO

    fd, path = tempfile.mkstemp(dir=os.path.dirname(os.path.abspath(__file__)))
    with StringIO("some data") as testfile:
        testfile.write("some data")
    testfile.seek(0)

    assert md5(path) == secure_hash(path, _md5)
    assert md5s("some data") == md5(testfile)

    os.remove(path)

# Generated at 2022-06-21 08:28:58.809528
# Unit test for function checksum_s
def test_checksum_s():
    '''
    check the results of checksum_s
    '''
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class TestChecksumS(unittest.TestCase):

        @patch('ansible.utils.crypto.sha1')
        def test__checksum(self, sha1_mock):
            sha1_digest_mock = MagicMock()
            sha1_digest_mock.hexdigest.return_value = 'sha1_hexdigest'
            sha1_mock.return_value = sha1_digest_mock

            data = 'test'
            hash_func = sha1_mock
            result = checksum_s(data, hash_func)

# Generated at 2022-06-21 08:29:03.208805
# Unit test for function md5s
def test_md5s():
    data = 'Hello, world'
    out = md5s(data)
    assert out == 'ed076287532e86365e841e92bfc50d8c'


__all__ = [
    'checksum', 'checksum_s',
    'md5', 'md5s',
]

# Generated at 2022-06-21 08:29:06.804578
# Unit test for function md5
def test_md5():
    from ansible.utils.hashing import md5
    from tempfile import mkstemp
    from shutil import move, rmtree

    # Getting the original file
    f, fn = mkstemp()
    original_file = open(fn, 'w')
    original_file.write('The first line\nThe second line\nThe third line\n')
    original_file.close()

    # Getting the test file
    f, fn = mkstemp()
    test_file = open(fn, 'w')
    test_file.write('The first line\nThe second line\nThe third line\n')
    test_file.close()

    # Getting the test file with some modifications
    f, fn = mkstemp()
    test_file2 = open(fn, 'w')

# Generated at 2022-06-21 08:29:19.192088
# Unit test for function md5
def test_md5():
    # test for md5 hash and checksum
    import tempfile
    tmpdir = tempfile.mkdtemp()
    testfile = tmpdir + "/testfile"
    teststr = "test data for md5"
    teststr2 = "test data for md5 2"
    with open(testfile, "w") as f:
        f.write(teststr)
    assert md5(testfile) == checksum(testfile) == "878a0a1b3bd23c6aa2a6a0dc1501a995"
    assert md5s(teststr) == checksum_s(teststr) == "878a0a1b3bd23c6aa2a6a0dc1501a995"

# Generated at 2022-06-21 08:29:28.954520
# Unit test for function checksum
def test_checksum():
    '''
    ansible.utils.checksum test drive
    This driver test the ansible.utils.checksum function.

    NOTE: this test assumes you are running this module from inside the same
    directory where it is located. In other words, the test file is located
    at the same directory level where this test module.
    '''

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestChecksum(unittest.TestCase):

        @patch('ansible.module_utils.basic.AnsibleModule')
        def test_checksum_sha1_s(self, mock_module):

            mock_module.run_command = lambda x: (0, '', '')

# Generated at 2022-06-21 08:29:42.774136
# Unit test for function md5
def test_md5():
    def fake_md5(data):
        return 'fake'

    fake_md5('a')

    # Save original md5
    orig_md5 = _md5

    # Replace md5 with our fake version
    _md5 = fake_md5

    # Check our fake version
    assert md5('a') == md5s('a') == 'fake'

    # Restore original md5
    _md5 = orig_md5

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-21 08:29:45.861197
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('sample') == '9e7d9eeb807e7e861345d6b4f14d2be9d7d826e3'


# Generated at 2022-06-21 08:29:52.629974
# Unit test for function md5s
def test_md5s():
    import sys
    import random

    def random_string(length):
        chars = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '!', '@', '#', '$', '%', '&', '*']
       

# Generated at 2022-06-21 08:29:57.657238
# Unit test for function checksum_s
def test_checksum_s():
    test_str = "test"
    test_str_sha1_checksum = "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"

    assert checksum_s(test_str) == test_str_sha1_checksum

# Generated at 2022-06-21 08:30:00.521767
# Unit test for function md5s
def test_md5s():
    ''' md5s() returns correct value '''

    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-21 08:30:06.991237
# Unit test for function md5
def test_md5():
    class mock_md5:
        @classmethod
        def md5(cls, file):
            return "0cc175b9c0f1b6a831c399e269772661"

    import ansible.utils.hashing as hashing

    hashing.checksum = hashing.md5 = mock_md5.md5
    assert hashing.md5("foobar") == "0cc175b9c0f1b6a831c399e269772661"

# Generated at 2022-06-21 08:30:13.421441
# Unit test for function md5
def test_md5():
    assert md5("/bin/cat") == 'e7daf949296499bca4b4d4a4af0c8182'
    assert md5("/bin/cat") == md5s("/bin/cat")
    assert md5("/bin/cat") == md5s("/bin/cat".encode('utf-8'))
    assert md5("/bin/cat") == md5s(b"/bin/cat")



# Generated at 2022-06-21 08:30:24.890919
# Unit test for function checksum
def test_checksum():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    import unittest
    import tempfile
    import shutil
    import sys

    class TestChecksum(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def testSecureHash_s(self):
            self.assertEqual(secure_hash_s('helloworld'), '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed')

# Generated at 2022-06-21 08:30:27.040551
# Unit test for function checksum
def test_checksum():

    assert checksum(__file__) == checksum_s(open(__file__).read())

# Generated at 2022-06-21 08:30:33.240980
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s('test2') == 'ed076287532e86365e841e92bfc50d8c'
    assert checksum_s('test3') == 'd8e8e59fb1b5a6b47a1fea8657a6829d'



# Generated at 2022-06-21 08:30:46.989708
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil

    try:
        d = tempfile.mkdtemp()
        f = tempfile.NamedTemporaryFile(dir=d, delete=False)
        f.write("abc")
        f.close()
        assert md5(f.name) == "900150983cd24fb0d6963f7d28e17f72"
    finally:
        shutil.rmtree(d)

# Generated at 2022-06-21 08:30:53.299008
# Unit test for function checksum_s
def test_checksum_s():
    bad_inputs = [None, 1, [], [1], {}, set()]
    good_inputs = ['', 'a']
    for input_data in bad_inputs:
        try:
            checksum_s(input_data)
            assert False
        except TypeError:
            pass
    for input_data in good_inputs:
        assert checksum_s(input_data)


if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-21 08:30:58.553656
# Unit test for function md5s
def test_md5s():
    assert('9e107d9d372bb6826bd81d3542a419d6' == md5s('The quick brown fox jumps over the lazy dog'))
    assert('e4d909c290d0fb1ca068ffaddf22cbd0' == md5s(''))
    assert(None == md5s(None))

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-21 08:31:00.799465
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-21 08:31:06.335380
# Unit test for function checksum
def test_checksum():
    filename = os.path.join(os.path.dirname(__file__), '../lib/ansible/module_utils/basic.py')
    sha1sum = checksum(filename)
    assert sha1sum == '4b23384583d3f8f07553c9bf1b388594448f2a8a'

# Generated at 2022-06-21 08:31:16.533562
# Unit test for function checksum_s
def test_checksum_s():
    ''' Unit test for function checksum_s '''

    result = secure_hash_s('hello')
    assert result == '5d41402abc4b2a76b9719d911017c592'

    result = secure_hash_s('hello', sha1)
    assert result == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

    try:
        from hashlib import sha256 as sha2
    except ImportError:
        sha2 = None

    if sha2:
        result = secure_hash_s('hello', sha2)

# Generated at 2022-06-21 08:31:19.103813
# Unit test for function md5s
def test_md5s():
    print(md5s(b"test"))

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-21 08:31:30.547095
# Unit test for function checksum_s
def test_checksum_s():
    from ansible.module_utils.basic import AnsibleModule

    # Expected output from ansible -m debug -a 'var=foo'
    json_output = {
        "changed": False, 
        "msg": "All items completed", 
        "results": [
            {
                "_ansible_parsed": True, 
                "changed": False, 
                "ping": "pong", 
                "invocation": {
                    "module_args": {
                        "var": "foo"
                    }
                }, 
                "item": "success", 
                "invocation": {
                    "module_args": {
                        "var": "foo"
                    }
                }, 
                "item": "success", 
                "ping": "pong"
            }
        ]
    }

    # Ex

# Generated at 2022-06-21 08:31:40.550631
# Unit test for function md5
def test_md5():
    import tempfile
    path = tempfile.mktemp()
    f = open(path, "w+")
    f.write("foo")
    f.close()
    remote_md5 = md5(path)
    f = open(path, "w+")
    f.write("foobar")
    f.close()
    new_md5 = md5(path)
    os.unlink(path)
    assert(remote_md5 != new_md5)


# Backwards compat
if __name__ == '__main__':
    import sys
    if len(sys.argv) == 3 and sys.argv[1] == '--md5':
        print("MD5 (%s) = %s" % (sys.argv[2], md5(sys.argv[2])))

# Generated at 2022-06-21 08:31:43.322712
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello world", sha1) == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"
    assert checksum_s("hello world", _md5) is None


# Generated at 2022-06-21 08:32:00.643990
# Unit test for function md5
def test_md5():

    assert md5(b'/home/file') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5(b'/home/file.txt') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5(b'/home/file.') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5(b'/home/file.txt.123') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5(b'/home/file.txt.12.3') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5(b'/home/file.txt.123!')

# Generated at 2022-06-21 08:32:10.089809
# Unit test for function checksum
def test_checksum():

    from ansible.utils.path import makedirs_safe
    from tempfile import mkdtemp
    from time import time
    import shutil

    file_name = 'test_file'
    dir_name = str(int(time()))
    file_path = os.path.join(dir_name, 'test_file')

    makedirs_safe(dir_name)