

# Generated at 2022-06-21 08:22:04.967164
# Unit test for function checksum
def test_checksum():
    assert checksum('test.py') == secure_hash('test.py')


# Generated at 2022-06-21 08:22:15.988693
# Unit test for function checksum_s
def test_checksum_s():
    '''
    A test for function checksum_s.
    This test is not intended to be comprehensive just an illustrative example to
    show how to use the function.
    '''

    # Test 1 -
    # Test that sum returns a sha1 digest.

    sum_test_1 = checksum_s("Test string to sum")
    assert len(sum_test_1) == 40

    # Test 2 -
    # Test that sum_s returns a md5 digest.

    sum_test_2 = md5s("Test string to sum")
    assert len(sum_test_2) == 32

    # Test 3 -
    # Test that sum returns a sha1 digest for an empty string.

    sum_test_3 = checksum_s("")
    assert len(sum_test_3) == 40

    # Test 4 -

# Generated at 2022-06-21 08:22:26.926171
# Unit test for function checksum_s
def test_checksum_s():
    import pytest

    # test sha1
    assert(checksum_s("hello", sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d')

    # test md5
    if _md5 is not None:
        assert(checksum_s("hello", _md5) == '5d41402abc4b2a76b9719d911017c592')
        assert(checksum_s("hello") == '5d41402abc4b2a76b9719d911017c592')
    else:
        pytest.raises(ValueError, 'checksum_s("hello", _md5)')
        pytest.raises(ValueError, 'checksum_s("hello")')

    # test bad hash functions

# Generated at 2022-06-21 08:22:32.245394
# Unit test for function md5s
def test_md5s():
    from ansible.compat.tests.mock import patch, mock_open
    with patch.object(os.path, 'exists', return_value=True):
        with patch.object(os, 'access', return_value=True):
            m = mock_open(read_data='0123456789')
            with patch.object(__builtin__, 'open', m, create=True):
                assert md5s('0123456789') == md5('my_file')


# Generated at 2022-06-21 08:22:40.315801
# Unit test for function checksum
def test_checksum():
    assert("d41d8cd98f00b204e9800998ecf8427e" == checksum(None))
    assert("d41d8cd98f00b204e9800998ecf8427e" == checksum_s(None))
    assert("a94a8fe5ccb19ba61c4c0873d391e987982fbbd3" == checksum_s("test"))

if __name__ == "__main__":
    test_checksum()
    print("PASSED")

# Generated at 2022-06-21 08:22:45.111321
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert checksum_s('foo\n') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-21 08:22:55.697636
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('0123456789') == '781e5e245d69b566979b86e28d23f2c7'
    assert checksum('/dev/null') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert checksum('/dev/zero') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-21 08:22:57.983438
# Unit test for function md5
def test_md5():
    assert(checksum_s('data') == md5s('data'))
    assert(checksum('setup.py') == md5('setup.py'))

# Generated at 2022-06-21 08:23:00.528654
# Unit test for function md5s
def test_md5s():
    assert md5s("test") == "098f6bcd4621d373cade4e832627b4f6"



# Generated at 2022-06-21 08:23:10.493393
# Unit test for function md5s
def test_md5s():
    '''Unit test for function md5s'''
    import unittest

    TEST_DATA = ["This is a test string\n", "", "This one is short\n"]
    TEST_RESULTS = ['6fcb7c54e9e0eb5928b2cd6aab618ae1',
                    'd41d8cd98f00b204e9800998ecf8427e',
                    '0f7c11f9826a857d9c66f0d65e9b9ee9']

    class TestMD5s(unittest.TestCase):
        '''Test of function md5s'''
        def test_results(self):
            '''Test md5s'''

# Generated at 2022-06-21 08:28:39.561876
# Unit test for function md5
def test_md5():
    data = "Hello"
    if md5s(data) != "8b1a9953c4611296a827abf8c47804d7":
        print ("test_md5() failed!")
        return False
    print ("test_md5() succeeded!")
    return True


# Generated at 2022-06-21 08:28:48.729642
# Unit test for function checksum
def test_checksum():
    ''' Returns checksum for all files in directory tree '''
    file_list = []
    for root, sub_folders, files in os.walk("."):
        if os.path.exists(root) and not os.path.islink(root):
            for file_name in files:
                if not os.path.islink(os.path.join(root, file_name)):
                    file_list.append(os.path.join(root, file_name))
    file_list.sort()
    for file_name in file_list:
        print(file_name, checksum(file_name))


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-21 08:28:52.702428
# Unit test for function md5s
def test_md5s():
    from ansible.module_utils import basic
    assert md5s(basic.BASIC_TEST_DATA) == '2b2020c243b16a0257b1f9b9d7c1eabf'


# Generated at 2022-06-21 08:29:00.119244
# Unit test for function checksum
def test_checksum():
    import tempfile
    (fd, fname) = tempfile.mkstemp()
    fh = os.fdopen(fd, 'w')
    fh.write("hello world")
    fh.close()
    assert checksum(fname) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    try:
        os.remove(fname)
    except OSError:
        pass


# Generated at 2022-06-21 08:29:06.768687
# Unit test for function md5
def test_md5():

    test_string = "Hello this is a test"
    test_file = "./test_file.txt"

    test_fd = open(test_file, "w")
    test_fd.write(test_string)
    test_fd.close()

    if md5(test_file) == md5s(test_string):
        print("Successfully calculated MD5 checksum")
        return True
    else:
        print("MD5 checksum function error")
        return False

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-21 08:29:17.198533
# Unit test for function md5
def test_md5():
    ''' The md5s and md5 functions are deprecated and should not
        be used except for backwards compat.
        Ansible will print a warning when the md5s and md5 functions
        are used.
    '''
    import warnings
    warnings.filterwarnings('ignore', '.*The md5s and md5 functions are deprecated and should not.*', DeprecationWarning)
    data = "A string of data"
    expected = "ea6742738a1157e5d954c1dbb0bdeee4"
    assert md5s(data) == expected
    assert md5(to_bytes(__file__, errors='surrogate_or_strict')) == expected


# Generated at 2022-06-21 08:29:28.043986
# Unit test for function md5s
def test_md5s():
    assert(md5s("") == "d41d8cd98f00b204e9800998ecf8427e")
    assert(md5s("a") == "0cc175b9c0f1b6a831c399e269772661")
    assert(md5s("abc") == "900150983cd24fb0d6963f7d28e17f72")
    assert(md5s("message digest") == "f96b697d7cb7938d525a2f31aaf161d0")
    assert(md5s("abcdefghijklmnopqrstuvwxyz") ==
           "c3fcd3d76192e4007dfb496cca67e13b")

# Generated at 2022-06-21 08:29:36.844739
# Unit test for function md5
def test_md5():
    import tempfile
    (fd, fname) = tempfile.mkstemp()
    os.close(fd)
    f = open(fname, "w")
    f.write("Hello World")
    f.close()
    filemd5 = md5(fname)
    if filemd5 != "b10a8db164e0754105b7a99be72e3fe5":
        print("wrong md5 for file %s, got %s" % (fname, filemd5))
        sys.exit(1)
    os.remove(fname)
    strmd5 = md5s("Hello World")
    if strmd5 != "b10a8db164e0754105b7a99be72e3fe5":
        print("wrong md5 for str, got %s" % strmd5)

# Generated at 2022-06-21 08:29:39.431790
# Unit test for function md5s
def test_md5s():
    r = md5s('foo')
    assert r == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-21 08:29:45.868066
# Unit test for function checksum_s
def test_checksum_s():
    import binascii
    raw = binascii.unhexlify("68656c6c6f")
    assert b'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d' == binascii.unhexlify(checksum_s(raw))
