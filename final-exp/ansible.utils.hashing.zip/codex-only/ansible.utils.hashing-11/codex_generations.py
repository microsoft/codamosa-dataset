

# Generated at 2022-06-23 13:54:07.425002
# Unit test for function md5
def test_md5():
    from tempfile import mkstemp
    from shutil import rmtree

    test_dir = mkdtemp()

    fd, fname = mkstemp(dir=test_dir)
    try:
        f = os.fdopen(fd, 'w')
        try:
            f.write('This is a test')
        finally:
            f.close()
    finally:
        os.close(fd)

    # test with a file
    h = md5(fname)
    assert(h == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08')

    # test with a directory
    h = md5(test_dir)
    assert(h == None)

    #

# Generated at 2022-06-23 13:54:10.909274
# Unit test for function md5s
def test_md5s():
    assert md5s('hi') == '49f68a5c8493ec2c0bf489821c21fc3b'
    assert md5s(u'hi') == '49f68a5c8493ec2c0bf489821c21fc3b'


# Generated at 2022-06-23 13:54:13.432619
# Unit test for function md5s
def test_md5s():
    if __name__ == '__main__':
        print(md5s('abc'))


if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-23 13:54:15.978754
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-23 13:54:27.062970
# Unit test for function md5
def test_md5():
    assert hasattr(md5s, '__call__')
    assert hasattr(md5, '__call__')
    #
    sha1_ref = secure_hash_s("hello world", sha1)
    assert(sha1_ref == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed")
    #
    sha1_ref = secure_hash("/bin/ls", sha1)
    assert(sha1_ref == "7e24b1f18d791788c4a2a7ceea4db86a8fefa218")
    #

# Generated at 2022-06-23 13:54:32.773860
# Unit test for function checksum_s
def test_checksum_s():
    ''' testing checksum_s'''

    #assert the SHA1 checksum value
    expected_sha1 = 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    actual_sha1 = checksum_s('hi')
    assert actual_sha1 == expected_sha1
    actual_sha1 = checksum_s('hi', checksum_func=sha1)
    assert actual_sha1 == expected_sha1

    #assert the MD5 checksum value
    if _md5:
        expected_md5 = '49f68a5c8493ec2c0bf489821c21fc3b'
        actual_md5 = checksum_s('hi', checksum_func=_md5)
        assert actual_md5 == expected_md5
   

# Generated at 2022-06-23 13:54:36.566702
# Unit test for function checksum
def test_checksum():

    try:
        from hashlib import sha1
    except ImportError:
        from sha import sha as sha1

    # test for secure_hash_s
    assert secure_hash_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert secure_hash_s(u'abc', sha1) == 'a9993e364706816aba3e25717850c26c9cd0d89d'

    if _md5:
        assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    else:
        try:
            md5s('abc')
        except ValueError:
            pass

# Generated at 2022-06-23 13:54:47.315535
# Unit test for function md5s
def test_md5s():
    # This is the MD5 digest of the string "test"
    expected = '098f6bcd4621d373cade4e832627b4f6'
    result = md5s("test")
    assert result == expected, \
        "md5s(\"test\") returned %s instead of expected %s" % (result, expected)
    # This is the MD5 digest of the file 'lib/ansible/module_utils/basic.py'
    expected = '4fd41a4e87a1c8eafb9a9b18d1acb6e8'
    result = md5("lib/ansible/module_utils/basic.py")

# Generated at 2022-06-23 13:54:57.139839
# Unit test for function checksum_s
def test_checksum_s():
    from ansible.module_utils import basic
    import random
    import string

    def randomword(maxlength):
        # This function (randomword) was taken from http://stackoverflow.com/questions/21017698/convert-int-to-hex-in-python/21017835#21017835
        # and slightly modified.
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(maxlength))

    def get_func_name(func):
        # This function was taken from http://stackoverflow.com/questions/846300/how-to-check-if-a-function-exists/846550#846550
        # and slightly modified.
        if hasattr(func, '__name__'):
            return func.__

# Generated at 2022-06-23 13:55:01.515078
# Unit test for function md5s
def test_md5s():
    md5s_data = md5s(b"Hello World")
    assert md5s_data == "b10a8db164e0754105b7a99be72e3fe5", "md5s should return b10a8db164e0754105b7a99be72e3fe5"


# Generated at 2022-06-23 13:55:04.258178
# Unit test for function md5
def test_md5():
    data = "test"
    assert md5s(data) == "098f6bcd4621d373cade4e832627b4f6"


# Generated at 2022-06-23 13:55:17.060552
# Unit test for function checksum
def test_checksum():
    from ansible.utils.unicode import to_bytes, to_unicode

    a_str = to_bytes("test" + u"\u2019")
    b_str = to_bytes("fail")

    # Test string
    assert checksum_s(a_str, sha1) == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"
    assert checksum_s(b_str, sha1) == "0cc175b9c0f1b6a831c399e269772661"

    # Test unicode string
    assert checksum_s(to_unicode(a_str), sha1) == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"

# Generated at 2022-06-23 13:55:24.592240
# Unit test for function checksum_s
def test_checksum_s():
    tests = {
        'hello world': '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed',
        ' ': 'b858cb282617fb0956d960215c8e84d1ccf909c6',
        '\n': '68b329da9893e34099c7d8ad5cb9c940',
        b'hello world': '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed',
        b' ': 'b858cb282617fb0956d960215c8e84d1ccf909c6',
        b'\n': '68b329da9893e34099c7d8ad5cb9c940',
    }


# Generated at 2022-06-23 13:55:30.287941
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/hosts') == '410a1b27eab0a7ad8f4b4d4b0d61c9e7'
    assert checksum_s('foobar') == '8843d7f92416211de9ebb963ff4ce28125932878'

# Generated at 2022-06-23 13:55:39.774228
# Unit test for function checksum_s

# Generated at 2022-06-23 13:55:48.576733
# Unit test for function md5
def test_md5():
    # Create a string
    msg = "This is a test"

    # Create a file with the string
    file = open("/tmp/test_file.txt", "w")
    file.write(msg)
    file.close()

    # Obtain the md5 for the string
    digest_s = md5s(msg)

    # Obtain the md5 for the file
    digest = md5("/tmp/test_file.txt")

    # Compare both
    assert digest_s == digest

    # Remove file
    os.remove("/tmp/test_file.txt")



# Generated at 2022-06-23 13:55:54.528806
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('a string') == 'b468d9f1f858d72f6f64faa0adb13c86d009848b'
    assert secure_hash_s('a string') == 'b468d9f1f858d72f6f64faa0adb13c86d009848b'


# Generated at 2022-06-23 13:56:01.164021
# Unit test for function checksum_s
def test_checksum_s():
    '''Unit test for function checksum_s

    The checksum values were generated using the command:

    sha1sum filename

    '''

    # No file
    assert checksum_s('/path/to/no/file') == 'd41d8cd98f00b204e9800998ecf8427e', \
           'checksum_s of /path/to/no/file'

    # These files are in tests/testdata/ansible_test/support/
    # Some fixture data for these tests is in tests/testdata/ansible_test/support/support.sh
    assert checksum_s('test1') == '3d68a8a09a36a3f1cc2a1e8d871c6a00', 'checksum_s of test1'

# Generated at 2022-06-23 13:56:02.463553
# Unit test for function md5
def test_md5():
    """Test for md5 function"""
    from ansible.module_utils.basic import AnsibleModul

# Generated at 2022-06-23 13:56:06.935153
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return True
    # check md5 on "Hello World"
    md5_str = '65a8e27d8879283831b664bd8b7f0ad4'
    assert(md5s('Hello World') == md5_str)
    return True

# Generated at 2022-06-23 13:56:09.735243
# Unit test for function md5s
def test_md5s():
    checksum1 = md5s('Hello')

    assert checksum1 == '8b1a9953c4611296a827abf8c47804d7', checksum1


# Generated at 2022-06-23 13:56:13.365876
# Unit test for function md5s
def test_md5s():
    assert(md5s('test') == '098f6bcd4621d373cade4e832627b4f6')
    if _md5:
        assert(md5s('test') == secure_hash_s('test', _md5))


# Generated at 2022-06-23 13:56:17.898802
# Unit test for function checksum
def test_checksum():
    import tempfile
    import os
    tf = tempfile.NamedTemporaryFile()
    tf.write(b'test')
    tf.seek(0)
    tf_path = tf.name
    res = checksum(tf_path)
    os.unlink(tf.name)
    assert res == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-23 13:56:21.044609
# Unit test for function checksum_s
def test_checksum_s():
    res = checksum_s('hello world')
    assert res == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed', res


# Generated at 2022-06-23 13:56:28.164638
# Unit test for function checksum
def test_checksum():
    ''' return the correct checksum for a file. '''
    assert checksum('test/files/chown') == "e51ea42d1fe697bfc6e77f8fdc58a0d0"
    assert checksum('test/files/chown',hash_func=sha1) == "e51ea42d1fe697bfc6e77f8fdc58a0d0"

# Generated at 2022-06-23 13:56:31.575326
# Unit test for function md5s
def test_md5s():
    data = 'test'
    h = md5s(data)
    assert h == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-23 13:56:37.882221
# Unit test for function md5s
def test_md5s():
    '''Test md5s'''
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    test_data = 'test data'
    assert md5s(test_data) == 'e2c42a9fefcb7278b54e83cec0f8e188'


# Generated at 2022-06-23 13:56:41.849625
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'



# Generated at 2022-06-23 13:56:45.525653
# Unit test for function checksum_s
def test_checksum_s():
    data = 'this is a string of text'
    expected_result = 'c0bc8bc08e3a84b9e3be0b7ebbb2d8f11e71e078'
    result = checksum_s(data)
    assert result == expected_result

# Generated at 2022-06-23 13:56:53.809342
# Unit test for function checksum
def test_checksum():
    import sys
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class TestCheckSum(unittest.TestCase):
        def setUp(self):
            self.fp = MagicMock(spec=file)
            self.fp.name = 'testfile'

        @patch('ansible.module_utils.basic.AnsibleModule.fail_json')
        @patch('ansible.module_utils.basic.open', create=True)
        def test_checksum_fail(self, mock_open, mock_fail):
            mock_open.side_effect = IOError('foo')
            checksum('testfile', method=sha1)

# Generated at 2022-06-23 13:57:00.289583
# Unit test for function checksum_s
def test_checksum_s():
    hello_hash = "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d"
    hello_world_hash = "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"

    assert checksum_s('hello') == hello_hash
    assert checksum_s('hello') == hello_hash
    assert checksum_s('hello', sha1) == hello_hash
    assert checksum_s('hello', None) == hello_hash
    assert checksum_s('hello world') == hello_world_hash
    assert checksum_s('hello world') == hello_world_hash
    assert checksum_s('hello world', sha1) == hello_world_hash

# Generated at 2022-06-23 13:57:09.301244
# Unit test for function checksum
def test_checksum():

    # Create test file
    fh = open("test.file","w")
    fh.write("This is a test file.")
    fh.close()

    # Find hash of file
    hash = secure_hash("test.file")

    # Should get the same hash each time
    assert hash == secure_hash("test.file")

    # The string should equal the file
    assert hash == secure_hash_s("This is a test file.")

    # The length of the hash should be 40
    assert len(hash) == 40

    # Remove test file
    os.remove("test.file")

# Generated at 2022-06-23 13:57:10.042830
# Unit test for function md5s
def test_md5s():
    return md5s("hello")


# Generated at 2022-06-23 13:57:14.727395
# Unit test for function checksum
def test_checksum():
    '''unit test for checksum'''
    # test empty string, empty file and normal string
    assert checksum_s("") == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    empty_file = 'test/units/utils/checksum_empty_file'
    assert checksum(empty_file) == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

# Generated at 2022-06-23 13:57:21.937102
# Unit test for function md5
def test_md5():
    import tempfile

    (d,f) = tempfile.mkstemp(prefix='ansibletest_', suffix='_test_md5')
    try:
        os.write(d, b"data")
        os.close(d)
        s = md5(f)
        assert s == '9eee19f6cd67e49b8d07b7a0c0a6fbf6'
    finally:
        if os.path.exists(f):
            os.remove(f)


# Generated at 2022-06-23 13:57:28.747126
# Unit test for function md5s
def test_md5s():

    assert md5s('blah') == 'ae2b1fca515949e5d54fb22b8ed95575'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(b'blah') == 'ae2b1fca515949e5d54fb22b8ed95575'
    assert md5s(b'') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-23 13:57:32.340473
# Unit test for function md5
def test_md5():
    # Test md5s
    x = 'hello'
    y = md5s(x)
    z = '5d41402abc4b2a76b9719d911017c592'
    assert y == z


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 13:57:37.014466
# Unit test for function md5
def test_md5():
    """
    The module_utils.basic.md5(filename) function will return None if file is not present, so if you are testing for
    the case of no such file, the following logic is required:
    """
    if os.path.isfile('/asdasdasd.no_such_file'):
        assert md5('/asdasdasd.no_such_file') is not None
    else:
        assert md5('/asdasdasd.no_such_file') is None
    return True

# Generated at 2022-06-23 13:57:42.785572
# Unit test for function checksum_s
def test_checksum_s():
    '''Unit test for checksum_s'''

    string_to_hash = 'yay'
    test_sha1 = '35ce9b7dcf0c24727e8b7718f1d0c2e8905c3c85'
    test_md5 = '7653d3ac97c518ea'

    assert secure_hash_s(string_to_hash) == test_sha1
    if _md5:
        assert md5s(string_to_hash) == test_md5

# Generated at 2022-06-23 13:57:48.248228
# Unit test for function checksum
def test_checksum():
    testfile = "/etc/group"
    if os.path.exists(testfile):
        print("sha1 checksum for %s is %s" % (testfile, checksum(testfile)))
    else:
        print("no file %s exists on this system." % testfile)

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 13:57:52.331374
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert checksum_s("hello", sha1) == "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d"

if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-23 13:57:55.592509
# Unit test for function md5
def test_md5():
    print("Running md5 function test")
    if md5("/etc/passwd") != "86fb269d190d2c85f6e0468ceca42a20":
        print("Test failed")
        return -1
    if md5("/etc/shadow") != None:
        print("Test failed")
        return -1
    else:
        return 0


# Generated at 2022-06-23 13:57:58.984406
# Unit test for function md5
def test_md5():
    currentdir = os.getcwd()
    mydir = os.path.dirname(os.path.realpath(__file__))
    os.chdir(mydir)
    out = md5('testfile')
    if out != 'cce1e306e92967d38601d00b6e1870fe':
        print ("test_md5 FAILED\n")
    else:
        print ("test_md5 PASSED\n")
    os.chdir(currentdir)



# Generated at 2022-06-23 13:58:01.542691
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'a2c91cd09b64fb65aff1a5b7984ad09c'

# Generated at 2022-06-23 13:58:04.825710
# Unit test for function md5s
def test_md5s():
    ''' test the md5s function '''
    if _md5:
        import tests.utils as utils
        # utils.validate_md5s(md5s)
        utils.validate_md5(md5)

# Generated at 2022-06-23 13:58:15.554067
# Unit test for function md5
def test_md5():
    assert md5('lib/ansible/modules/Core/files/fetch') == 'a86da7f8ccdacdbd7a71353c69eeb7a8'
    assert md5('lib/ansible/modules/Core/files/fetch') != 'a86da7f8ccdacdbd7a71353c69eeb7a1'
    assert md5('lib/ansible/modules/Core/files/fetch') != 'a86da7f8ccdacdbd7a71353c69eeb7b8'
    assert md5('lib/ansible/modules/Core/files/fetch') != 'a86da7f8ccdacdbd7a71353c69eeb7'


# Generated at 2022-06-23 13:58:21.767225
# Unit test for function md5
def test_md5():
    from ansible.module_utils import basic

    s = md5s(b"foo")
    s2 = "acbd18db4cc2f85cedef654fccc4a4d8"
    if s != s2:
        (failed, total) = basic.fail_json(msg="Expected %s, got %s" % (s2, s))
    else:
        (failed, total) = basic.success_json(msg="Got expected result.")
    return dict(failed=failed, total=total)


# Generated at 2022-06-23 13:58:24.299141
# Unit test for function checksum_s
def test_checksum_s():
    '''  Test checksum_s function '''
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'



# Generated at 2022-06-23 13:58:33.273775
# Unit test for function checksum
def test_checksum():
    from tempfile import NamedTemporaryFile

    content = 'test'

    with NamedTemporaryFile(delete=False) as tmp:
        tmp.write(content)
        tmp.close()

    try:
        assert checksum(tmp.name) == '098f6bcd4621d373cade4e832627b4f6'
        assert checksum_s('test') == '098f6bcd4621d373cade4e832627b4f6'
    finally:
        os.unlink(tmp.name)


# Generated at 2022-06-23 13:58:37.854751
# Unit test for function md5s
def test_md5s():
    in_data = """Foo Bar Baz"""
    expected_out = "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"
    out = md5s(in_data)
    print("%s == %s?" % (out, expected_out))
    assert out == expected_out



# Generated at 2022-06-23 13:58:42.850709
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    else:
        try:
            md5s('hello world')
            raise AssertionError('Expected md5s() to fail')
        except ValueError:
            # pass
            pass


# Generated at 2022-06-23 13:58:51.370309
# Unit test for function md5
def test_md5():
    '''
    We just test that function md5 and md5s return the same result sum up to different ways of calling them
    '''
    filedir = os.path.dirname(os.path.realpath(__file__)) + '/../../lib/ansible/modules/packaging'
    filename = filedir + '/pacman.py'
    assert secure_hash(filename, _md5) == secure_hash_s(open(filename).read(), _md5)
    assert secure_hash(filename, _md5) == md5(filename)
    assert secure_hash_s(open(filename).read(), _md5) == md5s(open(filename).read())


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 13:58:53.228687
# Unit test for function md5
def test_md5():
    md5('/tmp/definitely_not_a_file')

# Generated at 2022-06-23 13:58:58.329961
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s(u'hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-23 13:59:02.732423
# Unit test for function checksum
def test_checksum():
    assert checksum_s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert checksum_s("hello", hash_func=_md5) == "5d41402abc4b2a76b9719d911017c592"

# Generated at 2022-06-23 13:59:07.497011
# Unit test for function checksum_s
def test_checksum_s():

    # Create a random string to test checksum_s with
    from random import choice
    from string import ascii_letters
    data = ''.join([choice(ascii_letters) for i in range(256)])

    # Verify the checksum's of the random string are valid
    assert(len(checksum_s(data)) == len(checksum_s(data)) == 40)

# Generated at 2022-06-23 13:59:10.702243
# Unit test for function md5
def test_md5():
    assert md5s('asdf') == '912ec803b2ce49e4a541068d495ab570'
    assert md5s('asdf').upper() == '912EC803B2CE49E4A541068D495AB570'

# Generated at 2022-06-23 13:59:12.343380
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('12345') == secure_hash_s('12345')


# Generated at 2022-06-23 13:59:16.825278
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s(u'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo') == md5s(u'foo')

# Generated at 2022-06-23 13:59:20.264651
# Unit test for function md5s
def test_md5s():
    assert md5s('ABCDEFGHIJK') == '827ccb0eea8a706c4c34a16891f84e7b'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-23 13:59:23.139342
# Unit test for function md5
def test_md5():
    data = 'testdata'
    # Generated by md5sum tool
    assert md5s(data) == '86ea0c1cb55cb0a9a2e5030f6069a0f0'


# Generated at 2022-06-23 13:59:34.224105
# Unit test for function checksum_s
def test_checksum_s():
    ''' unit test for checksum_s '''
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    assert checksum_s('hi') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(u'hi') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(u'hi'.encode('utf-8')) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    context = PlayContext()
    context.lookup_loader = lookup_loader


# Generated at 2022-06-23 13:59:37.128058
# Unit test for function checksum_s
def test_checksum_s():
    val = 'hello world!'
    assert checksum_s(val) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'



# Generated at 2022-06-23 13:59:39.883439
# Unit test for function md5
def test_md5():
    if _md5:
        assert md5("/etc/passwd") == "b1b3773a05c0ed0176787a4f1574ff00"

# Generated at 2022-06-23 13:59:43.869029
# Unit test for function checksum
def test_checksum():
    test_str = 'foobar'
    assert checksum_s(test_str) == '8843d7f92416211de9ebb963ff4ce28125932878'


# Generated at 2022-06-23 13:59:48.443864
# Unit test for function md5
def test_md5():
    md5 = md5s('ansible')
    assert md5 == '2fbf0ebd9f2dc250d49a1526ed2171e4'

    md5 = md5s('foo')
    assert md5 == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-23 13:59:52.089641
# Unit test for function md5s
def test_md5s():
    assert md5s("d41d8cd98f00b204e9800998ecf8427e") == '0cc175b9c0f1b6a831c399e269772661'


# Generated at 2022-06-23 14:00:02.346628
# Unit test for function checksum
def test_checksum():

    meta_template = """{%%- set _ = "%s" %%}"""
    template = """{%%- set _ = "%s" %%}"""

    # Simulate the template/meta_template used by basic.py,
    # and verify that the correct hash is generated

    data = '\n'.join(['#!/usr/bin/python', 'print 1 + 1', ''])

    # Basic test
    assert checksum_s(data) == '30b9c276e3d3b8e40de2a28889c69743adad862b'

    # Templating meta params and script with no variables
    assert checksum_s(meta_template % (template % data)) == '30b9c276e3d3b8e40de2a28889c69743adad862b'

    # Templating script with

# Generated at 2022-06-23 14:00:05.509498
# Unit test for function md5
def test_md5():
    assert md5(__file__) == '68d4db6c4ca6f9704e723d1e838feb89'


# Generated at 2022-06-23 14:00:11.046783
# Unit test for function checksum
def test_checksum():
    if checksum('/etc/hosts') != 'f51bcb9e9b6f19c45a96d6eb48c6f778':
        raise AnsibleError("checksum test fails for /etc/hosts")
    if checksum('/etc/A_1234_hosts') != None:
        raise AnsibleError("checksum test fails for /etc/A_1234_hosts")

# Generated at 2022-06-23 14:00:24.585275
# Unit test for function md5s
def test_md5s():

    test_str = 'test string'
    md5_str = md5s(test_str)
    assert(md5_str == 'ee6d63bfa7e4c60a988e4d0d7caed446')

    test_unicode_str = u'test unicode string'
    md5_unicode_str = md5s(test_unicode_str)

# Generated at 2022-06-23 14:00:27.420275
# Unit test for function checksum_s
def test_checksum_s():
    if secure_hash_s("foo") == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33':
        return True
    else:
        return False

# Generated at 2022-06-23 14:00:30.131397
# Unit test for function md5s
def test_md5s():
    # SHA1 may be more portable than MD5 in FIPS mode
    assert md5s(b"testing") == "ae2b1fca515949e5d54fb22b8ed95575"



# Generated at 2022-06-23 14:00:33.843486
# Unit test for function checksum
def test_checksum():
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'



# Generated at 2022-06-23 14:00:38.748577
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'



# Generated at 2022-06-23 14:00:42.526012
# Unit test for function md5
def test_md5():

    result = md5('/etc/hosts')
    assert result == 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'

# Generated at 2022-06-23 14:00:46.354941
# Unit test for function md5
def test_md5():
    filename = './lib/ansible/utils/crypto.py'
    assert md5(filename) == 'b406110c0f6b0e31e42c36e80ec86567'


# Generated at 2022-06-23 14:00:57.008803
# Unit test for function checksum
def test_checksum():
    ''' test checksum '''
    import os
    import tempfile

    tmpdir = tempfile.mkdtemp()

    # create a temporary content with some content
    tmpfile = os.path.join(tmpdir, "tmpfile")
    fd = open(tmpfile, "w")
    fd.write("Hello World")
    fd.close()

    # calculate the checksum
    chksum = checksum(tmpfile)

    # now remove the file
    os.unlink(tmpfile)

    # the checksum from a non existing file should be none
    assert None == checksum(tmpfile)
    assert None == checksum_s("")

    # check if the checksum is none
    assert chksum == checksum_s("Hello World")

    os.rmdir(tmpdir)

# Generated at 2022-06-23 14:01:03.837326
# Unit test for function checksum
def test_checksum():
    def _test_checksum(data, expected):
        assert checksum_s(data) == expected

    _test_checksum('test', 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3')
    _test_checksum(u'test', u'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3')
    return True

# Generated at 2022-06-23 14:01:08.063095
# Unit test for function checksum
def test_checksum():

    data1 = 'test'
    data2 = 'test'
    data3 = 'test '

    assert checksum_s(data1) == checksum_s(data2)
    assert checksum(__file__) == checksum_s(open(__file__, 'rb').read())

    assert not checksum_s(data1) == checksum_s(data3)
    assert not md5s(data1) == md5s(data3)

# Generated at 2022-06-23 14:01:10.732199
# Unit test for function checksum
def test_checksum():
    assert checksum_s("hello world") == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-23 14:01:20.229739
# Unit test for function md5s
def test_md5s():
    assert md5s('foobar') == '3858f62230ac3c915f300c664312c63f'
    foo_md5 = md5s('foo')
    assert md5s('{0}{0}'.format(foo_md5)) == '88dae00e614d8f24cfd5a8b3f8002e93'
    assert md5s(foo_md5) == md5s('foo')
    assert md5s(md5s('foobar')) == 'e7e0c2e4915c475b34e33b9a9863d66f'

# Generated at 2022-06-23 14:01:25.140532
# Unit test for function md5s
def test_md5s():
    assert md5s('jeff') == '99a5d79b7f5fb49c5a7d9084e4b4d0a0'
    assert md5s('jeff') == '99a5d79b7f5fb49c5a7d9084e4b4d0a0'



# Generated at 2022-06-23 14:01:26.591806
# Unit test for function checksum
def test_checksum():
    assert checksum_s("asdf") == "912ec803b2ce49e4a541068d495ab570"

# Generated at 2022-06-23 14:01:32.968580
# Unit test for function checksum_s
def test_checksum_s():
    ''' Unit test the checksum_s function. '''

    import unittest

    import ansible.utils.crypto as crypto

    class ChecksumSTestCase(unittest.TestCase):
        ''' Unit test the checksum_s function. '''

        def setUp(self):
            self.string = '''
This is an example string that will be used to test the checksum_s function.

This function ensures that the string hash that is returned is always the same
regardless of the python version.
'''

            self.sha1 = 'f7b6e1d0823d2037c4b47a1a6a5300b4e9c9dd3f'

        def tearDown(self):
            pass


# Generated at 2022-06-23 14:01:36.500725
# Unit test for function checksum
def test_checksum():
    filename = 'test_checksum'
    # Return None for nonexistant file
    assert checksum(filename) is None

    with open(filename, 'w') as test_file:
        test_file.write("Hello World")
    try:
        os.chdir(os.path.dirname(os.path.abspath(__file__)))

        # Return sha1 hash for existing file
        assert checksum(filename) == 'f2b1f73c64e54b40f62b1c7bc8bc9304a906d5ce'
    finally:
        os.remove(filename)

# Generated at 2022-06-23 14:01:41.466008
# Unit test for function md5
def test_md5():
    import tempfile
    from ansible.compat.tests import unittest

    class TestMd5(unittest.TestCase):

        def setUp(self):
            (fd, self.filename) = tempfile.mkstemp()
            tfile = os.fdopen(fd, 'wb')
            tfile.write(b"123")
 

# Generated at 2022-06-23 14:01:45.996524
# Unit test for function md5
def test_md5():
    data = 'abc'
    if md5s(data) != '900150983cd24fb0d6963f7d28e17f72':
        raise AssertionError('MD5 hash of string is wrong')


# Generated at 2022-06-23 14:01:54.273257
# Unit test for function md5
def test_md5():
    import tempfile
    fd, temp_path = tempfile.mkstemp(prefix='ansible_test_file')

    result = md5("/this/path/does/not/exist")
    assert result is None

    result = md5("/dev/null")
    assert result == 'd41d8cd98f00b204e9800998ecf8427e'

    result = md5(temp_path)
    assert result == 'd41d8cd98f00b204e9800998ecf8427e'

    result = md5("/dev/urandom")
    assert len(result) == 32

    os.close(fd)
    os.remove(temp_path)


# Generated at 2022-06-23 14:02:06.670093
# Unit test for function md5
def test_md5():
    filename = 'test/ansible/hashing/123'
    with open(filename, 'w') as f:
        f.write('12345')
    assert md5(filename) == '827ccb0eea8a706c4c34a16891f84e7b'
    os.remove(filename)



# Generated at 2022-06-23 14:02:12.749621
# Unit test for function checksum_s
def test_checksum_s():
    assert secure_hash_s("Hello World") == "2ef7bde608ce5404e97d5f042f95f89f1c232871"
    assert secure_hash_s("Hello World", hash_func=_md5) == "b10a8db164e0754105b7a99be72e3fe5"

    # Test the default argument
    assert checksum_s("Hello World") == "2ef7bde608ce5404e97d5f042f95f89f1c232871"
    assert checksum_s("Hello World", hash_func=_md5) == "b10a8db164e0754105b7a99be72e3fe5"


# Generated at 2022-06-23 14:02:15.199519
# Unit test for function checksum_s
def test_checksum_s():
    res = checksum_s("Hello World")
    assert res == "b10a8db164e0754105b7a99be72e3fe5"

# Generated at 2022-06-23 14:02:17.109504
# Unit test for function checksum_s
def test_checksum_s():
    ''' test_checksum_s  '''
    if checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3':
        return True
    else:
        return False


# Generated at 2022-06-23 14:02:23.337490
# Unit test for function md5
def test_md5():
    if not os.path.exists('../test/test_hash.py') or os.path.isdir('../test/test_hash.py'):
        print('NONE')
        return
    if md5('../test/test_hash.py') != '1f9ad7d42a3f2d7e43cccbb3a7c6bccd':
        print('FAIL')
        return
    print('SUCCESS')

test_md5()

# Generated at 2022-06-23 14:02:34.209736
# Unit test for function checksum
def test_checksum():
    assert checksum('file-with-bom', 'sha1') == '9be9d348cdea74cb2b82cfc5564dd2ca71c94f62'
    assert checksum('file-without-bom', 'sha1') == 'd31aae821e52c1a5a6b94f6b5a6b5f5ad5ae1cc0'
    assert checksum('file-without-bom', 'md5') == 'eb849ec4b715a3b4c4d27fe8e0f7ccbc'
    assert checksum('file-with-bom', 'md5') == '4d4ee3223373c10a09ec5b6999178b6f'

# Generated at 2022-06-23 14:02:42.759238
# Unit test for function checksum_s
def test_checksum_s():
    h1 = 'c1fa7d36f02c25f9ebb9d6b5fc6b5f07'
    h2 = 'd3068d7b9522a5c917f926d5b6e5b6e5'
    h3 = '20b357d1b639e67e9b9d6b5fc6b5f071'

    assert h1 == checksum_s('something')
    assert h2 == checksum_s('')
    assert h3 == checksum_s('some-other-thing')

# Generated at 2022-06-23 14:02:47.676957
# Unit test for function md5
def test_md5():
    import tempfile
    fd, path = tempfile.mkstemp()
    with open(path, "w") as f:
        f.write('helloworld')
    assert md5(path) == 'fc5e038d38a57032085441e7fe7010b0'
    assert md5s('helloworld') == 'fc5e038d38a57032085441e7fe7010b0'

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 14:02:51.889016
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("hello") != "5d41402abc4b2a76b9719d911017c593"


# Generated at 2022-06-23 14:02:56.996434
# Unit test for function checksum_s
def test_checksum_s():
    if not checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed':
        raise Exception('checksum_s test_checksum_s failed')

# Generated at 2022-06-23 14:02:59.038014
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'


# Generated at 2022-06-23 14:03:05.694731
# Unit test for function md5
def test_md5():
    if _md5:
        testfile_path = os.path.join(os.path.dirname(__file__), 'testfile')
        dig = md5(testfile_path)
        assert dig == "ae2b1fca515949e5d54fb22b8ed95575", "Digest does not match"
    else:
        try:
            md5("")
        except ValueError:
            pass
        else:
            assert False, "ValueError expected"

# Generated at 2022-06-23 14:03:13.623815
# Unit test for function checksum
def test_checksum():
    filename = "test/files/test_checksum"
    assert checksum(filename) == "0b44a71b7d7ea6696c8dacb7c8546c72d7b3a0d1"
    assert checksum(filename, sha1) == "0b44a71b7d7ea6696c8dacb7c8546c72d7b3a0d1"

    assert checksum_s("hello world") == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"
    assert checksum_s("hello world", sha1) == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"


# Generated at 2022-06-23 14:03:16.636864
# Unit test for function md5
def test_md5():
    # returns a md5 checksum string
    md5('sha1sum.py')

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 14:03:26.190170
# Unit test for function md5s
def test_md5s():

    str1 = 'test '
    str2 = 'test'
    res1 = '098f6bcd4621d373cade4e832627b4f6'
    res2 = '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    res3 = '7b550935befd1c69f90f87f8885a5bf3'
    res4 = u'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    res5 = u'9e107d9d372bb6826bd81d3542a419d6'

# Generated at 2022-06-23 14:03:35.412046
# Unit test for function checksum_s
def test_checksum_s():

    assert checksum_s("foo") == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    assert checksum_s(b"foo") == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    assert checksum_s(u"foo") == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    assert checksum_s(u"foo".encode("utf8")) == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"

# Generated at 2022-06-23 14:03:46.623391
# Unit test for function md5
def test_md5():
    import unittest
    import tempfile
    import os

    class TestMd5Functions(unittest.TestCase):
        def setUp(self):
            self.test_file = tempfile.mkstemp()[1]
            self.test_s = 'I am a string!'
            self.test_s_md5 = '257edf23e9bd9d9d9a8c8a761f151710'

        def test_md5s(self):
            md5_result = md5s(self.test_s)
            self.assertEqual(md5_result, self.test_s_md5)


# Generated at 2022-06-23 14:03:50.205586
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s("hello") != "5d41402abc4b2a76b9719d911017c592":
        raise ValueError("func checksum_s not working properly")

test_checksum_s()

# Generated at 2022-06-23 14:03:55.946371
# Unit test for function md5s
def test_md5s():
    import doctest
    print("== Testing md5s == md5('abc') should == 900150983cd24fb0d6963f7d28e17f72")
    print("==  The following results are expected to fail if running in FIPS-140 mode == ")
    print("==  because md5 is disabled")
    failed, attempted = doctest.testmod()
    if attempted > 0:
        print("%d of %d tests passed" % (attempted-failed, attempted))
    assert attempted == 0 or attempted-failed == 1


# Generated at 2022-06-23 14:04:04.830354
# Unit test for function md5
def test_md5():
    """ unit test for md5 function """

    # Must test with absolute path!
    ansible_dir = os.path.dirname(os.path.dirname(__file__))
    test_file_path = os.path.join(ansible_dir, 'test', 'test_md5.tmp')

    with open(test_file_path, 'w') as test_file:
        test_file.write('0123456789')

    try:
        # simple test
        assert md5(test_file_path) == '781e5e245d69b566979b86e28d23f2c7'
    finally:
        os.unlink(test_file_path)