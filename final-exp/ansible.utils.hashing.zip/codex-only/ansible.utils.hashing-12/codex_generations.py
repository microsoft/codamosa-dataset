

# Generated at 2022-06-23 13:54:11.312287
# Unit test for function checksum
def test_checksum():
    if not os.path.exists('tests/testfile'):
        os.system('/bin/dd if=/dev/zero of=tests/testfile bs=1 count=1024 > /dev/null 2>&1')
    if os.path.getsize('tests/testfile') == 1023:
        os.system('/bin/echo >> tests/testfile')
    s = checksum('tests/testfile')
    assert s == 'fc1c02f97d947f0c2e8f7a1e6319942197345d0f'
    s = checksum('tests/testfile', 'md5')
    assert s == '32fe98bab5a5c5f6701e2b43f9e70dba'
    s = checksum_s('Hello world', 'md5')


# Generated at 2022-06-23 13:54:18.518536
# Unit test for function md5s
def test_md5s():
    import nose

    # sha1 hash for 'test'
    # $ echo -n test | openssl dgst -sha1
    # (stdin)= a94a8fe5ccb19ba61c4c0873d391e987982fbbd3
    #
    # md5 hash for 'test'
    # $ echo -n test | openssl dgst -md5
    # (stdin)= 098f6bcd4621d373cade4e832627b4f6

    # Call the function under test.
    result = md5s('test')
    nose.tools.assert_equal('098f6bcd4621d373cade4e832627b4f6', result)

# Generated at 2022-06-23 13:54:21.272302
# Unit test for function checksum_s
def test_checksum_s():
    print(checksum_s("string"))
    print(checksum_s("another string"))


# Generated at 2022-06-23 13:54:23.897591
# Unit test for function md5s
def test_md5s():
    # known hex digest of 'abc'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72', 'test md5s failed'


# Generated at 2022-06-23 13:54:32.178567
# Unit test for function md5
def test_md5():
    assert md5s('data') == '1f3870be274f6c49b3e31a0c6728957f'
    assert md5s(u'data') == '1f3870be274f6c49b3e31a0c6728957f'
    assert md5s('中文') == '77d6de8c619a6aee805a737b898d7f2f'
    assert md5s(u'中文') == '77d6de8c619a6aee805a737b898d7f2f'



# Generated at 2022-06-23 13:54:37.413497
# Unit test for function md5s
def test_md5s():
    assert md5s("123") == '202cb962ac59075b964b07152d234b70'
    assert md5s("1234") == '81dc9bdb52d04dc20036dbd8313ed055'
    assert md5s("") == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-23 13:54:41.150186
# Unit test for function checksum
def test_checksum():
    data = "hello world"
    hexdigest = checksum_s(data)
    assert hexdigest == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-23 13:54:49.593847
# Unit test for function checksum
def test_checksum():
    if os.environ.get("TRAVIS", False) or os.environ.get("ANSIBLE_TEST_CHECKSUM", False):
        try:
            import hashlib
            hashlib.new('sha256')
        except ValueError:
            print("Cannot run checksum tests due to FIPS mode.")
            return

        import random
        from ansible.compat.tests import unittest

        class TestHashes(unittest.TestCase):
            def setUp(self):
                self.filenames = ['/dev/null', '/bin/ls']

# Generated at 2022-06-23 13:54:56.218865
# Unit test for function md5
def test_md5():
    import tempfile

    test_string = "Hello World"
    temp_file = tempfile.NamedTemporaryFile()
    temp_file.write(to_bytes(test_string, errors='surrogate_or_strict'))
    temp_file.seek(0)
    assert md5(temp_file.name) == "ed076287532e86365e841e92bfc50d8c"
    assert md5s(test_string) == "ed076287532e86365e841e92bfc50d8c"
    temp_file.close()

# Generated at 2022-06-23 13:55:01.429555
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py: Unit test for function checksum '''

    SHA = secure_hash("test/static/validate-port-nums/tcp_listen.rb")
    assert SHA == 'b898f0e75b7d9bcfac0adc9a01e9e15b2a2b6879'

    SHA = secure_hash("test/static/validate-port-nums/udp_listen.rb")
    assert SHA == 'a5a5f85b2713d87d7a10477f0c2a2b89d87f9819'

# Generated at 2022-06-23 13:55:08.736864
# Unit test for function checksum
def test_checksum():
    filename = '/etc/passwd'
    hsum = secure_hash_s("hello world")
    hf = secure_hash(filename)
    if hsum == None or hf == None:
        raise ValueError("unable to calculate secure hash for file %s" % filename)
    if 'sha1' != hash_func(hsum):
        raise ValueError("secure_hash_s did not return sha1 hash")
    if 'sha1' != hash_func(hf):
        raise ValueError("secure_hash did not return sha1 hash")

#
# Run unit tests if executed as main
#

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 13:55:12.252057
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('test content') == '4b4e4ef4e8cbe7b90329e979d05b3ac2fce7d5a5'

# Generated at 2022-06-23 13:55:16.286846
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '4d7f4bd0e4a0f2e90a2a5b85cca86b0c'

# vim: set sts=4 sw=4 ts=4 expandtab ft=python :

# Generated at 2022-06-23 13:55:24.200679
# Unit test for function md5
def test_md5():
    import os
    import tempfile

    (fd1, fname1) = tempfile.mkstemp()
    (fd2, fname2) = tempfile.mkstemp()

    text1 = "foo"
    text2 = "bar"

    f1 = open(fname1, 'w')
    f2 = open(fname2, 'w')

    f1.write(text1)
    f2.write(text2)

    f1.close()
    f2.close()

    assert md5(fname1) == md5(fname1), "md5 should return the same value for the same file"
    assert md5(fname1) != md5(fname2),"md5 should return different values for different files"

    os.remove(fname1)

# Generated at 2022-06-23 13:55:34.910414
# Unit test for function md5
def test_md5():
    import shutil
    from ansible.compat.tests import unittest

    test_data = """Hello world, I am a file.
    My name is %s.
    Please love me.
    I live in %s.
    """ % (__file__, os.getcwd())

    TEST_STRING = 'a1b2c3d4'

    class TestMD5(unittest.TestCase):
        def setUp(self):
            fd, self.temp_path = tempfile.mkstemp()
            f = os.fdopen(fd, "w")
            f.write(test_data)
            f.close()
        def tearDown(self):
            os.unlink(self.temp_path)

# Generated at 2022-06-23 13:55:43.077607
# Unit test for function checksum_s
def test_checksum_s():
    tests = {
        "": 'da39a3ee5e6b4b0d3255bfef95601890afd80709',
        "hello": 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0',
        "hello\n": 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0',
        "world": '7d793037a0760186574b0282f2f435e7'
    }
    for k, v in tests.items():
        assert secure_hash_s(k) == v, "check for %s failed!" % k


if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-23 13:55:52.022734
# Unit test for function checksum_s
def test_checksum_s():

    import os
    import shutil
    import tempfile
    import unittest

    test_files = [
        ('hello world', 'b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9'),
        ('1234567890', 'ad0234829205b9033196ba818f7a872b'),
        ('', 'da39a3ee5e6b4b0d3255bfef95601890afd80709'),
        ('{}', '3c9b30a36cda88e5d0e82f3b08e54dbe'),
    ]


# Generated at 2022-06-23 13:56:00.139603
# Unit test for function md5s
def test_md5s():

    # The tests aren't done in alphabetical order, which
    # was intentional because some of the functions
    # are named the same, but are different functions.
    # Since they are in order of creation, it's easier
    # to verify correctness by scanning down the list.

    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '9e107d9d372bb6826bd81d3542a419d6'

# Generated at 2022-06-23 13:56:02.203592
# Unit test for function checksum
def test_checksum():
    assert checksum("hello") == "943a702d06f34599aee1f8da8ef9f7296031d699"


# Generated at 2022-06-23 13:56:11.066057
# Unit test for function checksum
def test_checksum():
    import types

    assert isinstance(checksum, types.FunctionType)
    assert isinstance(checksum_s, types.FunctionType)

    # Verify checksum returns None for non-existent files
    assert checksum('non-existent-file') is None

    # Verify checksum does not return None for existing files
    assert checksum(__file__) is not None

    # Verify checksum of empty string returns 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'

# Generated at 2022-06-23 13:56:20.677534
# Unit test for function checksum
def test_checksum():
    os.system("echo 'Hello world!' > /tmp/hello.txt")
    os.system("echo 'Hello world!' > /tmp/hello2.txt")
    os.system("dd if=/dev/urandom of=/tmp/hello3.txt count=1 bs=1024 2> /dev/null")
    assert checksum("/tmp/hello.txt") == checksum("/tmp/hello2.txt")
    assert checksum("/tmp/hello.txt") != checksum("/tmp/hello3.txt")

    assert secure_hash("/tmp/hello.txt").startswith("sha1")
    assert secure_hash_s("foobar").startswith("sha1")

if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-23 13:56:22.368069
# Unit test for function md5
def test_md5():
    assert _md5('foo').hexdigest() == "acbd18db4cc2f85cedef654fccc4a4d8"


# Generated at 2022-06-23 13:56:31.285798
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("test") == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s("test", sha1) == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s("test", md5) == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-23 13:56:37.223144
# Unit test for function md5
def test_md5():
    tmp = "ansible_ungibberish_test_string"
    assert md5s(tmp) == "e025051b8d3bbe7c94edb49d9529a848"
    assert md5s(tmp) == md5s(to_bytes(tmp, errors='surrogate_or_strict'))

# Generated at 2022-06-23 13:56:48.102639
# Unit test for function checksum
def test_checksum():
    # Create file for testing
    test_file = open('/tmp/ansible-1.9.3.tar.gz', 'w')
    test_file.write('test string')
    test_file.close()

    # Calculate sha1 checksum by using module
    checksum_1 = checksum('/tmp/ansible-1.9.3.tar.gz')

    # Calculate sha1 checksum by using manual method
    import hashlib
    checksum_2 = hashlib.sha1(open('/tmp/ansible-1.9.3.tar.gz', 'rb').read()).hexdigest()

    # Check if two checksums are equal
    if checksum_1 != checksum_2:
        raise AssertionError('Module checksum failed')

    # Remove file

# Generated at 2022-06-23 13:56:52.723801
# Unit test for function checksum
def test_checksum():
    assert checksum("/dev/null") == checksum("/dev/null")
    assert checksum_s("foo") == checksum_s("foo")
    assert checksum_s("foo") != checksum_s("bar")
    assert checksum("/dev/null") != checksum_s("/dev/null")

# Generated at 2022-06-23 13:56:57.896029
# Unit test for function md5s
def test_md5s():
    import sys
    if sys.version_info[0] >= 3:
        assert md5s('Hello!') == '5de543b49ff6a83eff0c9c0d8b9f4124'
    else:
        assert md5s('Hello!') == '8b9f4124eff0c9c0d85de543b49ff6a8'

# Generated at 2022-06-23 13:57:00.069350
# Unit test for function md5
def test_md5():
    # TODO: ansible.utils.unsafe_proxy.UnsafeProxy type
    pass

# Generated at 2022-06-23 13:57:05.300778
# Unit test for function checksum
def test_checksum():
    # A known checksum value for an empty string
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'

    # A known checksum value for a non-empty string
    assert checksum_s('a') == '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8'

    # A known checksum value for the README.md file
    assert checksum('README.md') == 'c38d75b0e9b1f3b2fc14790e083787d8799b17e0'

    # Make sure we get None for a non-existent file
    assert checksum('/tmp/foo_bar_baz_xyzzy') == None

    # Make sure we get

# Generated at 2022-06-23 13:57:10.396643
# Unit test for function checksum_s
def test_checksum_s():
    data = "This string is not a file"
    assert len(checksum_s(data)) == 40
    assert checksum_s(data) == "c3b567e0c68a0c47fec2af84415679d27b0fdb99"


# Generated at 2022-06-23 13:57:14.522443
# Unit test for function md5s
def test_md5s():
    input_sha = u'hello world'
    output_sha = u'5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(input_sha) == output_sha

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-23 13:57:21.876649
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    currentdir = os.getcwd()
    os.chdir(os.path.dirname(__file__))
    filename = 'md5.txt'
    open(filename, 'w').write('test')
    assert md5(filename) == '098f6bcd4621d373cade4e832627b4f6'
    os.unlink(filename)
    os.chdir(currentdir)

# Generated at 2022-06-23 13:57:25.087403
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('world') == '7d793037a0760186574b0282f2f435e7'



# Generated at 2022-06-23 13:57:27.778263
# Unit test for function md5
def test_md5():
    assert len(md5('/bin/ls')) == 32
    assert len(md5s('abc')) == 32
    assert md5s('abc') == md5('/bin/ls')

# Generated at 2022-06-23 13:57:34.083088
# Unit test for function md5s
def test_md5s():
    ''' function md5s should return the same value as md5sum '''
    from ansible.utils.compat import md5sum
    for data in [b"", b'The quick brown fox jumps over the lazy dog',
                 b"1"*10, b"2"*20, b"3"*30,
                 b"4"*40, b"5"*50, b"6"*60
                 ]:
        assert md5s(data) == md5sum(data)

# Generated at 2022-06-23 13:57:38.625212
# Unit test for function md5
def test_md5():
    if _md5:
        if md5('/etc/passwd') != 'd6e0f6c0a6aec59d9e47e8d9977e1eec':
            raise AssertionError

# Generated at 2022-06-23 13:57:42.475039
# Unit test for function checksum
def test_checksum():
    filename = os.path.join(os.path.realpath(os.path.dirname(__file__)), '../../test/units/lib/ansible/test/test_utils.py')
    test_sha1 = '6da4a4fd55f4c4f23b4a64dba4e559eea7687dec'
    assert test_sha1 == checksum(filename)

# Generated at 2022-06-23 13:57:46.851175
# Unit test for function checksum
def test_checksum():
    checksum_value = secure_hash_s('Hello World')
    assert(checksum_value == '0a4d55a8d778e5022fab701977c5d840bbc486d0')


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 13:57:56.491578
# Unit test for function md5
def test_md5():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(default=None, type='path'),
            data=dict(default=None, type='str'),
        ),
        supports_check_mode=True
    )

    md5_response = md5(module.params['path']) or md5s(module.params['data'])
    if md5_response is None:
        module.fail_json(msg="No file found for path: %s" % module.params['path'])
    else:
        module.exit_json(changed=False, ansible_md5sum=md5_response)



# Generated at 2022-06-23 13:58:06.923472
# Unit test for function checksum
def test_checksum():
    # Ensure the test works on most systems
    if checksum('/etc/passwd') == '1fddadcb96a205df7db9c1d65e7a5c89f3c1c4e4':
        assert checksum('/etc/passwd') == '1fddadcb96a205df7db9c1d65e7a5c89f3c1c4e4'
        assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
        assert md5('/etc/passwd') == '665e9d9b73c29bfea1b3f0fe37d15c18'
        assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-23 13:58:15.651325
# Unit test for function md5
def test_md5():
    # Test string
    s = "Hello World!"
    # Test file
    f = "/etc/hosts"
    # Assert md5 for string
    assert md5s(s) == "fc3ff98e8c6a0d3087d515c0473f8677"
    # Assert md5 for file
    assert md5(f) == "d74ff0ee8da3b9806b18c877dbf29bbd"
    # Assert md5 for non-existing file
    assert md5("/tmp/non-existing-file") is None


# Generated at 2022-06-23 13:58:22.770408
# Unit test for function checksum
def test_checksum():
    import filecmp
    from shutil import copyfile

    source = './lib/ansible/module_utils/basic.py'
    dest = './lib/ansible/module_utils/basic.py.test'

    copyfile(source, dest)

    assert checksum(source) == checksum(dest)

    assert checksum(source, sha1) == checksum(dest, sha1)

    if _md5:
        assert checksum(source, md5) == checksum(dest, md5)

    os.remove(dest)

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 13:58:28.369487
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s(u'hello world') == "5eb63bbbe01eeed093cb22bb8f5acdc3"



# Generated at 2022-06-23 13:58:39.447780
# Unit test for function checksum
def test_checksum():
    '''
    unit test for basic checksum function, will not return on failure
    '''
    test_file = '/etc/passwd'
    if not os.path.isfile(test_file):
        test_file = './hacking/env-setup'
    if not os.path.isfile(test_file):
        print('  Could not find a file to generate a checksum on.')
        return
    test_sum = checksum(test_file)
    print('  checksum(test_file) returned %s.' % test_sum)
    print('  checksum(test_file, sha1) returned %s.' % checksum(test_file, sha1))
    print('  checksum(test_file, md5) returned %s.' % checksum(test_file, _md5))
   

# Generated at 2022-06-23 13:58:42.332804
# Unit test for function md5s
def test_md5s():
    result = md5s("test123")
    if result != "202cb962ac59075b964b07152d234b70":
        raise AssertionError("md5s failed to hash string test123")


# Generated at 2022-06-23 13:58:46.429444
# Unit test for function checksum_s
def test_checksum_s():
    '''basic sha1 vs sha1sum'''
    test_data = b"test"
    assert checksum_s(test_data) == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"


# Generated at 2022-06-23 13:58:53.862349
# Unit test for function checksum
def test_checksum():
    """Returns true if the function works as expected
    """

    import os
    try:
        from tempfile import mkstemp
    except ImportError:
        from ansible.module_utils.basic import mkstemp

    # Create a temporary file to test checksum
    tmpfd, tmpname = mkstemp()
    os.close(tmpfd)
    # make sure it's empty
    os.unlink(tmpname)

    # Test a file which doesn't exist
    assert checksum(tmpname) == None

    # Create a file with some content
    with open(tmpname, 'w') as tmpfd:
        tmpfd.write('This is a test')

    # Assert the checksum is ok

# Generated at 2022-06-23 13:59:05.742939
# Unit test for function checksum_s
def test_checksum_s():
    # Simple strings
    assert checksum_s(u'hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

    # Unicode with character that don't fit into ascii (utf-8)
    assert checksum_s(u'\u202e') == '45d6bae8f018dcfddf09a0dc1255da9c8adc2a37'

    # Path manipulations don't affect the

# Generated at 2022-06-23 13:59:11.391909
# Unit test for function checksum
def test_checksum():
    from ansible.module_utils import basic
    from ansible.compat.tests import unittest

    def ensure_results_equal(result):
        sha1_checksum = result['sha1']
        md5_checksum  = result['md5']
        checksum_s    = result['checksum']

        assert sha1_checksum == checksum_s
        assert md5_checksum == checksum_checksum
        assert sha1_checksum == md5_checksum

    class TestChecksumCase(unittest.TestCase):
        # Test case for normal file
        def test_checksum_file(self):
            filename = 'test.txt'
            string = 'hello world'
            with open(filename, 'w') as f:
                f.write(string)


# Generated at 2022-06-23 13:59:21.004882
# Unit test for function checksum_s
def test_checksum_s():
    s = b"hello world"
    f = "/etc/passwd"

    assert secure_hash_s(s) == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"
    assert secure_hash_s(s, hash_func=_md5) == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert secure_hash(f) == "7c0774cd1d93d6c94e6efb7a2a836b8d6bcc0a08"
    assert secure_hash(f, hash_func=_md5) == "f0dc245f7aa1a61af4f7e4b9e9a788ad"


# Generated at 2022-06-23 13:59:29.251878
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "f4d4f4c4e4aa0bb8d10b2239b82dd6f5a6dbce9f"
    assert checksum("/bin/cat") == "fbdbb97fa256e40c42de7e0c3fa9d7f3"
    assert checksum("/dev/null") == "dfa34a01c5c6f8a8a24d6be4b4f4a76a"

# Generated at 2022-06-23 13:59:35.301742
# Unit test for function checksum
def test_checksum():
    myfile = '/tmp/testfile-%s' % checksum('/bin/ls')
    open(myfile, 'w').close()
    mysum = checksum(myfile)
    os.remove(myfile)
    assert mysum is not None


# Generated at 2022-06-23 13:59:37.184242
# Unit test for function md5s
def test_md5s():
    ''' Test a known md5s hash '''
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-23 13:59:42.370900
# Unit test for function md5
def test_md5():
    filename = '/tmp/foo'
    with open(filename, 'w') as f:
        f.write('hello')
    assert(md5(filename) == '5d41402abc4b2a76b9719d911017c592')
    os.unlink(filename)



# Generated at 2022-06-23 13:59:51.024902
# Unit test for function md5
def test_md5():
    ''' test_md5.py: Unit test for function md5 '''
    from ansible.compat.tests import unittest, mock

    class TestMd5(unittest.TestCase):
        def test_md5(self):
            with mock.patch('ansible.utils.crypto.md5._md5') as mock_md5:
                mock_md5.return_value = 'md5'
                digest = md5('filename')
                self.assertTrue(mock_md5.called)
                self.assertEqual(digest, 'md5')

    # Run unit test
    unittest.main()



# Generated at 2022-06-23 13:59:55.556592
# Unit test for function md5s
def test_md5s():
    from ansible.module_utils.basic import *
    data = "Hello World"
    hash = "b10a8db164e0754105b7a99be72e3fe5"
    if md5s(data) != hash:
        fail_json(msg="md5s() returned wrong hash.")

# Generated at 2022-06-23 14:00:05.654717
# Unit test for function md5
def test_md5():
    ''' return sha1 of a string, and compare to the output of "echo -n" in a subshell'''
    from binascii import hexlify
    from tempfile import NamedTemporaryFile
    from subprocess import Popen, PIPE
    f = NamedTemporaryFile()
    f.write('the quick brown fox jumped over the lazy dog'.encode('utf-8'))
    f.flush()
    print(md5(f.name))
    p = Popen(['/bin/echo', '-n', 'the quick brown fox jumped over the lazy dog'], stdout=PIPE, stderr=PIPE)
    assert hexlify(p.communicate()[0]) == md5s('the quick brown fox jumped over the lazy dog').encode('utf-8')

# Generated at 2022-06-23 14:00:08.628051
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('the quick brown fox jumped over the lazy dog') == '9e107d9d372bb6826bd81d3542a419d6'


# Generated at 2022-06-23 14:00:20.656933
# Unit test for function checksum
def test_checksum():
    good_data = "hello world"
    good_checksum = "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"

    assert secure_hash_s(good_data) == good_checksum, "secure_hash_s() returned: %s, expected %s" % (secure_hash_s(good_data), good_checksum)

    good_data = b"hello world"
    good_checksum = "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"

    assert secure_hash_s(good_data) == good_checksum, "secure_hash_s() returned: %s, expected %s" % (secure_hash_s(good_data), good_checksum)

    good_data = b

# Generated at 2022-06-23 14:00:24.805986
# Unit test for function md5
def test_md5():
    ''' Function to test md5 function '''
    result = md5("file_with_md5")
    assert result == '0833d23b019e37cf1c76e9db7c6feafa'


# Generated at 2022-06-23 14:00:28.326305
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('123') == 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', checksum_s('123')


# Generated at 2022-06-23 14:00:30.047297
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('I love potato') == '36224e8a00df0a3ab86452187d166f20bbea3b3d'


# Generated at 2022-06-23 14:00:40.101973
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', 'sha256') == 'b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9'
    try:
        checksum_s('hello world', 'sha3-256')
    except ValueError:
        # No support for sha3 in earlier versions of Python
        pass
    else:
        assert False


# Generated at 2022-06-23 14:00:44.519913
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("foo", hash_func=_md5) == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert checksum_s("foo") == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'


# Generated at 2022-06-23 14:00:52.054092
# Unit test for function checksum
def test_checksum():
    import tempfile
    import os
    (fd, filename) = tempfile.mkstemp()
    f = os.fdopen(fd, "w+b")
    f.write("Hello".encode('utf-8'))
    f.close()
    assert checksum(filename) == '5d41402abc4b2a76b9719d911017c592'
    assert md5(filename) == '5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-23 14:01:00.515719
# Unit test for function checksum
def test_checksum():
    import os

    sample_file = b'../lib/ansible/modules/core/files/test_file'

# Generated at 2022-06-23 14:01:03.529138
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-23 14:01:06.756219
# Unit test for function md5s
def test_md5s():
    text = 'abcdefghijklmnopqrstuvwxyz\n'
    if secure_hash_s(text) != 'BADC0FFEE':
        raise Exception("md5s function test failed")
    if md5s(text) != 'CRC32:E6C07B1C':
        raise Exception("md5s function test failed")

# Generated at 2022-06-23 14:01:13.219341
# Unit test for function checksum_s

# Generated at 2022-06-23 14:01:23.959738
# Unit test for function checksum
def test_checksum():
    from ansible.module_utils.six import PY3
    from io import BytesIO

    # vars for unicode test case
    try:
        unicode('test')
    except NameError:
        unicode = str

    bytesio = BytesIO(b"Hello world")
    with open(os.path.join(os.path.dirname(__file__), "test_file.txt"), 'rb') as testfile:
        data = testfile.read()
    try:
        data += unicode(chr(0xc3))
    except ValueError:
        # ValueError: Windows gets pissy when you append unicode characters
        pass

    print("File fingerprint (sha1): %s" % checksum(os.path.join(os.path.dirname(__file__), "test_file.txt")))

# Generated at 2022-06-23 14:01:29.639089
# Unit test for function md5
def test_md5():
    filename = __file__
    content = "".join(open(filename).readlines())
    assert content, "content of the file {0} must not be empty".format(filename)
    assert secure_hash_s(content, _md5) == md5s(content)
    assert secure_hash(filename, _md5) == md5(filename)

    bad_filename = 'bad'
    assert secure_hash(bad_filename, _md5) == md5(bad_filename)

# Generated at 2022-06-23 14:01:39.392295
# Unit test for function checksum
def test_checksum():
    import tempfile
    import unittest

    class TestChecksum(unittest.TestCase):
        """ Test for function checksum """

        class TestFile(object):
            """ Dummy file for testing """
            def __init__(self, name, data):
                self.name = name
                self.data = data
                self.size = len(data)

            def read(self, length=None):
                if length is None:
                    return self.data
                return self.data[:length]

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp(dir='/tmp')
            self.addCleanup(os.rmdir, self.tmpdir)

        def tearDown(self):
            pass


# Generated at 2022-06-23 14:01:43.517170
# Unit test for function md5s
def test_md5s():
    """ Test the md5s function, which is a backwards compat function for ansible-1.7
    """
    assert(md5s('hello') == '5d41402abc4b2a76b9719d911017c592')

# Generated at 2022-06-23 14:01:50.587088
# Unit test for function md5
def test_md5():
    """ test md5 function for backwards compatibility"""
    import tempfile
    import shutil
    import os

    try:
        tmpdir = tempfile.mkdtemp()
        testfile = os.path.join(tmpdir, 'testfile')
        with open(testfile, 'w') as f:
            f.write('test')
        assert md5(testfile) == md5s('test')
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-23 14:01:57.779072
# Unit test for function md5
def test_md5():
    filename = "test.txt"
    f = open(filename, "w+")
    f.write("""test md5""")
    f.close()
    assert md5(filename) == "8808a71e0a63f749bbb0d36c3003b3e3"
    os.unlink(filename)
# End test md5

# Generated at 2022-06-23 14:02:01.627918
# Unit test for function md5
def test_md5():
    assert md5("/dev/null") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5("/dev/zero") == "cf83e1357eefb8bdf1542850d66d8007"

# Generated at 2022-06-23 14:02:07.693053
# Unit test for function checksum_s
def test_checksum_s():
    assert sha1('hello').hexdigest() == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-23 14:02:11.018351
# Unit test for function md5s
def test_md5s():
    assert md5s("foobar") == '3858f62230ac3c915f300c664312c63f'
    assert md5s("") == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-23 14:02:15.198856
# Unit test for function checksum_s
def test_checksum_s():
    test_str = 'ABCDE'
    teststr_s = secure_hash_s(test_str)
    assert teststr_s == '900150983cd24fb0d6963f7d28e17f72'

# Generated at 2022-06-23 14:02:17.287738
# Unit test for function checksum_s
def test_checksum_s():
    cs = checksum_s('hello world')
    assert cs in ('2aae6c35c94fcfb415dbe95f408b9ce91ee846ed', '2c74fd17edafd80e8447d2ce0c499f0635550b8d')



# Generated at 2022-06-23 14:02:26.130647
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    filename = '/tmp/file'
    md5sum = '9b3560d8ef099eec1b961acbacf0c8e2'

    # Create file
    with open(filename, mode='wb') as f:
        f.write(b'content')

    # Calculating md5sum
    checksum = secure_hash(filename, _md5)
    assert checksum == md5sum

    # Remove file
    os.remove(filename)



# Generated at 2022-06-23 14:02:30.121566
# Unit test for function md5
def test_md5():
    print (md5_s("Hello World!\n"))
    print (md5_s("Hello World!"))
    print (md5_s("Hello World!"*1000))


if __name__ == '__main__':
     test_md5()

# Generated at 2022-06-23 14:02:40.252634
# Unit test for function checksum
def test_checksum():
    ''' test_checksum '''
    assert checksum('/bin/cat') == 'b141f25a2f72a3927bcd85caa8f7ac0f'
    assert checksum('/bin/cat', sha1) == 'b141f25a2f72a3927bcd85caa8f7ac0f'
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_s('foo', sha1) == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    # Backwards compat for md5, leave for now

# Generated at 2022-06-23 14:02:48.387932
# Unit test for function checksum_s
def test_checksum_s():
    '''
    Test checksum_s() agains known-good test vectors from
    https://tools.ietf.org/html/rfc4231#appendix-D

    Known-good test vectors for SHA256 and SHA512 can be found in the same
    document, but I've omitted them for now since SHA256 and SHA512 aren't
    currently used in Ansible
    '''
    from hashlib import sha1

    # Test vector 1, 16 octets (128 bits)
    test1_key = '\x0b' * 16
    test1_data = 'Hi There'
    test1_expected = 'b617318655057264e28bc0b6fb378c8ef146be00'

    # Test vector 2, 20 octets (160 bits)
    test2_key = 'Jefe'
    test2

# Generated at 2022-06-23 14:02:55.553146
# Unit test for function checksum
def test_checksum():
    # Note, this is not a complete testing suite.  Just some very simple examples.
    # This is not a unit test module.
    import tempfile
    fd, fname = tempfile.mkstemp(prefix='ansible-test-checksum')
    try:
        os.write(fd, b'foo')
        os.close(fd)
        assert checksum(fname) == 'acbd18db4cc2f85cedef654fccc4a4d8'
    finally:
        os.unlink(fname)


# Generated at 2022-06-23 14:03:06.004009
# Unit test for function md5
def test_md5():
    test_fn_1 = 'test_md5_str_file_1'
    test_fn_2 = 'test_md5_str_file_2'
    test_fn_3 = 'test_md5_str_file_3'
    test_md5_1 = 'a1a2a3a4a5a6a7a8a9a0a1a2a3a4a5a6'
    test_md5_2 = 'b1b2b3b4b5b6b7b8b9b0b1b2b3b4b5b6'
    test_md5_3 = 'c1c2c3c4c5c6c7c8c9c0c1c2c3c4c5c6'


# Generated at 2022-06-23 14:03:12.179669
# Unit test for function checksum
def test_checksum():
    test_file = "/tmp/test-file"
    test_file_checksum = "073f8b3a7a29a01c63f7d7a9e87f7e38"

    with open(test_file, "w") as f:
        f.write("Test file for the module utils checksum function")

    assert(checksum(test_file) == test_file_checksum), "checksum returned incorrect result"
    os.remove(test_file)
    assert(checksum(test_file) == None), "checksum returned incorrect result"

# Generated at 2022-06-23 14:03:18.530590
# Unit test for function md5
def test_md5():
    if _md5:
        assert md5('/bin/ls') == 'a75d66a7a1432c21f8bfddd6d4777687'
    else:
        try:
            md5('/bin/ls')
            raise Exception('This should not happen')
        except ValueError:
            pass

# Generated at 2022-06-23 14:03:21.237015
# Unit test for function md5s
def test_md5s():
    data = 'hello world'
    assert md5s(data) == '5eb63bbbe01eeed093cb22bb8f5acdc3'



# Generated at 2022-06-23 14:03:27.025276
# Unit test for function md5s
def test_md5s():
    data = 'This is a test for md5s function.\n'

    assert md5s(data) == '0236b201feb0f28d96f5c8c5e68d9eae'
    assert md5s(data) == secure_hash_s(data, _md5)


# Generated at 2022-06-23 14:03:34.315226
# Unit test for function md5
def test_md5():
    assert md5s("hello") == '5d41402abc4b2a76b9719d911017c592'
    assert md5s("hello") == '5d41402abc4b2a76b9719d911017c592'
    assert md5s("hello\u8000") == 'b8c574926ff93788e42965fa0d3c8dae'
    assert md5s("hello\u8000") == 'b8c574926ff93788e42965fa0d3c8dae'
    assert md5("test/test_utils/test.py") == '4ad4c4e8b2f6cd65d01c2b3e3b8b0307'

# Generated at 2022-06-23 14:03:40.443676
# Unit test for function md5
def test_md5():
    """ test md5 function """

    import tempfile

    fd, fname = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write("hello")
    f.close()

    md5_hash = md5(fname)

    os.unlink(fname)

    assert md5_hash == "5d41402abc4b2a76b9719d911017c592"

# Generated at 2022-06-23 14:03:52.073199
# Unit test for function checksum_s

# Generated at 2022-06-23 14:03:59.423133
# Unit test for function checksum_s
def test_checksum_s():
    test_data = """
    ---
    - hosts: all
      vars:
        version: v1.7.x
      tasks:
      - debug: msg="hello world"
    """
    h = checksum_s(test_data)
    assert h == '364d6a8c0185e7bd08f45cc1f7a81487b9c08d8a'



# Generated at 2022-06-23 14:04:03.353385
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    argument = 'some string'
    result = md5s(argument)
    assert isinstance(result, str)
    assert len(result) == 32
