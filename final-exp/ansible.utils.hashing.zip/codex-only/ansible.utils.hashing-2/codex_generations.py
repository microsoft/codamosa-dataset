

# Generated at 2022-06-23 13:54:03.652389
# Unit test for function md5
def test_md5():
    import random
    import string

    for length in (1, 10, 100, 1000, 10000):
        random_string = ''.join([random.choice(string.letters) for i in xrange(length)])

        # These should be the same
        checksum_result = secure_hash_s(random_string)
        md5_result = md5s(random_string)

        assert checksum_result == md5_result, "md5s and checksum should have the same result"


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 13:54:11.057262
# Unit test for function checksum
def test_checksum():
    assert checksum('test/files/chown.sh') == '64c7169014894f8ff4d62e4e1c67e8f4'
    assert checksum_s('#!/bin/sh\necho 1') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert md5s('#!/bin/sh\necho 1') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9'

# Generated at 2022-06-23 13:54:20.937032
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s('foo') != '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33':
        print("FAILED: checksum_s 1")
    if checksum_s('bar', sha1) != '62cdb7020ff920e5aa642c3d4066950dd1f01f4d':
        print("FAILED: checksum_s 2")
    if checksum_s(u'foo') != '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33':
        print("FAILED: checksum_s 3")


if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-23 13:54:23.677012
# Unit test for function md5s
def test_md5s():
    test_data = "unit test data"
    assert md5s(test_data) == "bdd2a71b1c2b1d08b3f3cbd7571811c5"


# Generated at 2022-06-23 13:54:34.199164
# Unit test for function checksum
def test_checksum():

    # Check that two checksums equal with same parameters
    assert checksum('foo') == checksum('foo')
    assert checksum('foo', 'sha1') == checksum('foo', 'sha1')
    assert checksum_s('foo') == checksum_s('foo')
    assert checksum_s('foo', 'sha1') == checksum_s('foo', 'sha1')

    # Check that two checksums are different with different parameters
    assert checksum('foo') != checksum('bar')
    assert checksum('foo', 'sha1') != checksum('bar', 'sha1')
    assert checksum_s('foo') != checksum_s('bar')
    assert checksum_s('foo', 'sha1') != checksum_s('bar', 'sha1')

    # Check that two checksums are different with same parameters but one

# Generated at 2022-06-23 13:54:38.053194
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello world") == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"

# Generated at 2022-06-23 13:54:40.896818
# Unit test for function md5s
def test_md5s():
    s = md5s("abc")
    assert s == '900150983cd24fb0d6963f7d28e17f72'

# Generated at 2022-06-23 13:54:49.595417
# Unit test for function checksum
def test_checksum():
    def chksum(data, algorithm=sha1):
        import re
        import subprocess
        from ansible.module_utils._text import to_bytes

        if algorithm == sha1:
            prog = 'sha1sum'
        elif algorithm == _md5:
            prog = 'md5sum'
        else:
            raise AnsibleError("unsupported checksum type requested")

        p = subprocess.Popen([prog], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
        stdout, stderr = p.communicate(to_bytes(data))
        return re.split(' ', stdout)[0]

    # Test data
    data = 'Hello World!'
    data_file = 'sha1.txt'

# Generated at 2022-06-23 13:54:52.672127
# Unit test for function md5s
def test_md5s():
    assert secure_hash_s('test', _md5) == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-23 13:54:55.431229
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('Hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-23 13:55:01.606085
# Unit test for function checksum
def test_checksum():

    file = open("checksum.data", "wb+")
    file.write("Hello World!")
    file.close()

    checksum = secure_hash("checksum.data")
    assert(checksum == "acbd18db4cc2f85cedef654fccc4a4d8")

    checksum = secure_hash_s("Hello World!")
    assert(checksum == "acbd18db4cc2f85cedef654fccc4a4d8")

# Generated at 2022-06-23 13:55:05.863955
# Unit test for function md5
def test_md5():
    from ansible.module_utils import basic
    import tempfile
    fp = tempfile.TemporaryFile()
    fp.write(b"sample text\n")
    fp.seek(0)
    assert md5(fp.name) == "b7f14a332604c3e9369b4d8e37341895"

# Generated at 2022-06-23 13:55:13.825613
# Unit test for function checksum
def test_checksum():
    # Test hsah values are hexadecimal
    assert secure_hash('/bin/ls').isalnum()
    assert secure_hash_s('hello world').isalnum()
    # Test that the hsah value of a nonexistent file is None.
    assert secure_hash('/non/existent/file/name') is None
    # Test that the hsah value of a directory is None.
    assert secure_hash('/etc') is None


# Generated at 2022-06-23 13:55:19.305546
# Unit test for function checksum
def test_checksum():
    assert checksum("test/units/files/test_copy.txt") == "df6ef71e1a901a6f19bee1ad5080c5d5"
    assert checksum("test/units/files/test_copy.txt", "sha1") == "bf0b058ff59e25e9b60d767435af25c0e12bca2c"


# Generated at 2022-06-23 13:55:29.295965
# Unit test for function checksum_s
def test_checksum_s():
    # Perform a test
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(default=None, required=True)
        ),
        supports_check_mode=False
    )
    result = checksum_s(module.params['data'])
    module.exit_json(changed=False, ansible_facts={'checkum_s': result})


if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-23 13:55:32.034121
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3", md5s("hello world")



# Generated at 2022-06-23 13:55:41.028679
# Unit test for function checksum
def test_checksum():
    from ansible import constants as C

    file_name = os.path.join(C.DEFAULT_LOCAL_TMP, "checksum_test_file")
    file_content= "Hello"

    with open(file_name, 'wb') as f:
        f.write(file_content)

    file_content_sha1 = "f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0"
    assert secure_hash(file_name) == file_content_sha1
    assert checksum(file_name) == file_content_sha1

    file_content_sha1 = "f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0"

# Generated at 2022-06-23 13:55:43.277490
# Unit test for function md5
def test_md5():
    assert md5s('Hello World') == 'b10a8db164e0754105b7a99be72e3fe5'


# Generated at 2022-06-23 13:55:51.016331
# Unit test for function checksum
def test_checksum():
    test_data = 'test'
    assert checksum_s(test_data) == checksum_s(test_data)

    test_dir = 'testdir'
    test_file = 'testdir/testfile'
    try:
        os.mkdir(test_dir)
    except:
        pass
    with open(test_file, 'w') as f:
        f.write(test_data)
    assert checksum(test_file) == checksum_s(test_data)
    if os.path.isdir('testdir'):
        import shutil
        shutil.rmtree(test_dir)



# Generated at 2022-06-23 13:55:57.074828
# Unit test for function md5s
def test_md5s():
    """This is a unit test for function md5s"""
    # Case 1: Execute function md5s with argument only data
    result = md5s("abc")
    assert result == "900150983cd24fb0d6963f7d28e17f72"
    # Case 2: Execute function md5s with argument data and hash_func
    result = md5s("abc", hash_func="md5")
    assert result == "900150983cd24fb0d6963f7d28e17f72"

# Generated at 2022-06-23 13:56:01.134824
# Unit test for function checksum_s
def test_checksum_s():
    assert 'da39a3ee5e6b4b0d3255bfef95601890afd80709' == checksum_s('')


if __name__ == '__main__':
    import sys
    temp = md5s(sys.argv[1])
    print(temp)

# Generated at 2022-06-23 13:56:04.906603
# Unit test for function md5s
def test_md5s():
    test_data = "The quick brown fox jumps over the lazy dog"
    result = md5s(test_data)
    assert result == "9e107d9d372bb6826bd81d3542a419d6"


# Generated at 2022-06-23 13:56:07.265809
# Unit test for function md5
def test_md5():
    """Test md5 function. Checks if the md5 function generates the correct checksum."""
    string = "test string"
    assert md5s(string) == 'd247ddb61f21a7a2b774f8f7b49c1a71'


# Generated at 2022-06-23 13:56:12.854530
# Unit test for function md5
def test_md5():
    import tempfile
    temp = tempfile.NamedTemporaryFile()
    temp.write(b'abc')
    temp.flush()
    temp.seek(0)

    md5 = md5(temp.name)
    if md5 != '900150983cd24fb0d6963f7d28e17f72':
        raise ValueError('MD5 calculation seems to be broken')
    temp.close()



# Generated at 2022-06-23 13:56:21.181092
# Unit test for function md5s
def test_md5s():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec={})
    if _md5:
        result = m.from_json(md5s('hello'))
    else:
        try:
            md5s('hello')
        except ValueError:
            result = m.from_json('md5_unavailable')
        else:
            result = m.from_json('md5_available')
    m.exit_json(ansible_facts=dict(ansible_test=result))


# Generated at 2022-06-23 13:56:26.550242
# Unit test for function checksum
def test_checksum():
    # Create a temp file and checksum it
    import tempfile, shutil
    (fd, fname) = tempfile.mkstemp()
    fh = os.fdopen(fd, "w")
    fh.write("hello world")
    fh.close()

    data = checksum(fname)
    os.remove(fname)

    assert data == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed', data


# Generated at 2022-06-23 13:56:31.657689
# Unit test for function md5
def test_md5():
    assert md5s('data') == '1f3870be274f6c49b3e31a0c6728957f'
    assert md5('/bin/ls') == 'ea3f446d3fd3fdab816c1783e9c7d1b5'


# Generated at 2022-06-23 13:56:37.576586
# Unit test for function md5s
def test_md5s():
    txt = 'hello'
    txt_md5 = '5d41402abc4b2a76b9719d911017c592'
    if md5s(txt) != txt_md5:
        print('ERROR: md5s failed')
    else:
        print('OK: md5s passed')


# Generated at 2022-06-23 13:56:47.107246
# Unit test for function md5s
def test_md5s():
    import random
    import string
    test_data = ''.join(random.choice(string.ascii_lowercase) for i in range(32))
    h1 = md5s(test_data)
    h2 = secure_hash_s(test_data, _md5)
    test_data2 = ''.join(random.choice(string.ascii_uppercase) for i in range(32))
    h3 = md5s(test_data2)
    h4 = secure_hash_s(test_data2, _md5)
    assert(h1 != h3)
    assert(h2 != h4)



# Generated at 2022-06-23 13:56:52.475081
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s("Test123") == "7f1a0b8a9b472ff07c7886b3d20e8d8c70e69f94":
        print("checksum_s: OK")
    else:
        print("checksum_s: FAIL")


# Generated at 2022-06-23 13:56:56.653837
# Unit test for function md5s
def test_md5s():
    # This test is only for backward compat when running in FIPS mode
    try:
        md5temp = md5s("")
    except ValueError:
        return
    assert md5s("") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5s("hello ansible") == "7fc56270e7a70fa81a5935b72eacbe29"


# Generated at 2022-06-23 13:57:01.372962
# Unit test for function checksum_s
def test_checksum_s():

    # Test for the function checksum_s with a string
    try:
        result = checksum_s('foo bar')
        assert result == 'b325f2cb1f37cdc2afb8a99c1d3848e9b18bf02b'
    except Exception as e:
        raise AnsibleError('test_checksum_s failed: %s' % e)



# Generated at 2022-06-23 13:57:03.527821
# Unit test for function md5s
def test_md5s():
    assert md5s('test') != None



# Generated at 2022-06-23 13:57:07.750578
# Unit test for function checksum_s
def test_checksum_s():
    '''
    Validate checksum of given string
    '''
    string = 'test'
    result = checksum_s(string)
    assert (len(result) == 40, 'Checksum has 40 chars')


# Generated at 2022-06-23 13:57:13.750097
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s(u"hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s(b"hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"



# Generated at 2022-06-23 13:57:16.943752
# Unit test for function md5s
def test_md5s():
    assert md5s('foobar') == '3858f62230ac3c915f300c664312c63f'

# Generated at 2022-06-23 13:57:24.247812
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

    dir_path = tempfile.mkdtemp()
    file_path = os.path.join(dir_path, 'destfile')
    with open(file_path,'w') as f:
        f.write("This is some test text")

    checksum_value = secure_hash(file_path, sha1)
    assert checksum_value == 'fba02c728a22f516a56a08d239b3fa1de3fa9cca'
    shutil.rmtree(dir_path)


if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-23 13:57:33.489416
# Unit test for function md5
def test_md5():
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('message digest') == 'f96b697d7cb7938d525a2f31aaf161d0'
    assert md5s('abcdefghijklmnopqrstuvwxyz') == 'c3fcd3d76192e4007dfb496cca67e13b'

# Generated at 2022-06-23 13:57:39.431846
# Unit test for function md5
def test_md5():
    file_with_md5 = '../../lib/ansible/modules/files/stat.py'
    md5sum = md5(file_with_md5)
    assert md5sum == 'fc17c0a223d3f907e50cff7ac1ece813'

# Generated at 2022-06-23 13:57:47.462151
# Unit test for function checksum_s
def test_checksum_s():
    test_strings = ["string", "a"*10, "b"*100]
    test_hashes = ["7f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08",
                   "941a479f41b8c13f40fc68a7b7088e71",
                   "46f28e0f7b986e9958712a3b049f4e94"]
    for i in range(len(test_strings)):
        assert checksum_s(test_strings[i]) == test_hashes[i]


# Generated at 2022-06-23 13:57:50.680501
# Unit test for function checksum
def test_checksum():
    assert checksum('test/unit/ansible/modules/system/ping.py') == 'c3fe3d3bbd2c9b362f6f86d0fa734bfa2fc2c0f2'
test_checksum.virtualtest = True

# Generated at 2022-06-23 13:57:59.626686
# Unit test for function checksum_s
def test_checksum_s():
    dummy_string = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    assert checksum_s(dummy_string) == 'e17dcd8cc1b0e70c9df0d9f74af38b1a0e1635c7'
    assert checksum_s(dummy_string, sha1) == 'e17dcd8cc1b0e70c9df0d9f74af38b1a0e1635c7'


# Generated at 2022-06-23 13:58:04.904490
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abcefghijk') == '89d93858e9f3e36f1cd06c29570e2841'

# Generated at 2022-06-23 13:58:16.408013
# Unit test for function md5
def test_md5():
    from tempfile import NamedTemporaryFile

    testvalues = ['first', 'second', 'third']
    correctvalues = ['2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae',
                     '4e9dd65c1e7c1a5fe30b26c2712bdb8a38c5e5e5b5c6461b8d7b3e3b332b3eef',
                     '2b39a3a186f3b3c15e9a2d2f885c48a1803f1c61f876b8be1f23a953e26a9b9d']

    # Test md5s

# Generated at 2022-06-23 13:58:18.536810
# Unit test for function md5s
def test_md5s():
    return md5s("Hi there") == "49f68a5c8493ec2c0bf489821c21fc3b"



# Generated at 2022-06-23 13:58:22.037781
# Unit test for function checksum
def test_checksum():
    import tempfile
    filename = tempfile.mktemp()
    try:
        with open(filename, 'w') as f:
            f.write('some data')
        assert checksum(filename) == checksum_s('some data')
    finally:
        os.remove(filename)

# Generated at 2022-06-23 13:58:26.755890
# Unit test for function checksum
def test_checksum():
    ''' test with a known value '''

    import os
    import time

    tmpfilename = os.path.realpath('ansible_test_sha1')

    with open(tmpfilename, 'w') as f:
        f.write(time.ctime())
    try:
        assert checksum(tmpfilename) == 'ee920d936c9e1aadd0a6cdb1fcb0ecef763301dd'
    finally:
        os.remove(tmpfilename)


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 13:58:37.606018
# Unit test for function md5
def test_md5():
    # test that md5 works on existing file
    # test that md5 returns None on missing file
    # test that md5 raises an exception on directories

    test_file = "test/hashing/test_md5.txt"
    test_md5 = "2d70019a51bde6f3e6c8e6cec596ed1f"

    test_md5_result = md5(test_file)
    if test_md5_result != test_md5:
        print("MD5 function does not return correct value for existing file")
        print("Expected: %s" % test_md5)
        print("Actual: %s" % test_md5_result)

    test_bad_file = "test/hashing/not_a_file.txt"
    test_md5_result = md5

# Generated at 2022-06-23 13:58:44.846954
# Unit test for function md5
def test_md5():
    import tempfile
    import random
    testdata = ""
    for x in range(0, 10000):
        testdata = testdata + chr(random.randint(0, 255))
    fd, path = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write(testdata)
    f.close()
    assert md5(path) == md5s(testdata), "test_md5 failed"
    os.unlink(path)

# Generated at 2022-06-23 13:58:47.500156
# Unit test for function md5s
def test_md5s():
    md5_result = "0cc175b9c0f1b6a831c399e269772661"
    ansible_result = md5s("a")
    assert ansible_result == md5_result

# Generated at 2022-06-23 13:58:57.297289
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("1234567890", hash_func=sha1) == 'e807f1fcf82d132f9bb018ca6738a19f'
    assert checksum_s("") == "da39a3ee5e6b4b0d3255bfef95601890afd80709"
    assert checksum_s("a", hash_func=sha1) == "86f7e437faa5a7fce15d1ddcb9eaeaea377667b8"
    assert checksum_s("abc", hash_func=sha1) == "a9993e364706816aba3e25717850c26c9cd0d89d"

# Generated at 2022-06-23 13:59:02.469893
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s('hello world') != '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed':
        raise Exception('function checksum_s is broken')

if __name__ == '__main__':
    # Run unit tests
    test_checksum_s()

# Generated at 2022-06-23 13:59:07.979271
# Unit test for function md5s
def test_md5s():
    s = 'abc'
    assert md5s(s) == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(s + s + s) == 'e80b5017098950fc58aad83c8c14978e'


# Generated at 2022-06-23 13:59:10.197934
# Unit test for function checksum_s
def test_checksum_s():
    digest = secure_hash_s('abc')
    assert digest == 'a9993e364706816aba3e25717850c26c9cd0d89d'


# Generated at 2022-06-23 13:59:15.116547
# Unit test for function checksum
def test_checksum():
    ''' test_checksum is a very basic test to make sure function checksum returns
    a hash of the argument string passed.
    '''
    assert checksum_s('hi') == '8f1dd178e03acbbe6b2fbbd8ce6bd07e1c7fddad'

# Generated at 2022-06-23 13:59:18.594247
# Unit test for function md5s
def test_md5s():
    """
    sha1 tests
    """
    # This example is from RFC 1321
    if md5s('abc') == '900150983cd24fb0d6963f7d28e17f72':
        return True
    else:
        return False


# Generated at 2022-06-23 13:59:24.620734
# Unit test for function md5
def test_md5():
    # Test case 1
    if md5("test/test_utils.py") != 'e5d5c6fdebb8c15ff6a14ced6f9ffec6':
        print('test case 1 md5 fail')

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 13:59:27.949700
# Unit test for function checksum_s
def test_checksum_s():
    test_string = "test string"
    test_hash = "7e240de74fb1ed08fa08d38063f6a6a91462a815"
    assert checksum_s(test_string) == test_hash

# Test the md5 function.  Test cases taken from RFC 1321 Test Vectors

# Generated at 2022-06-23 13:59:30.247850
# Unit test for function md5s
def test_md5s():
    res = md5s("Hello World")
    assert res == "5eb63bbbe01eeed093cb22bb8f5acdc3"


# Generated at 2022-06-23 13:59:35.507026
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo\n') == 'e2c569be17396eca2a2e3c11578123ed'


# Generated at 2022-06-23 13:59:37.836427
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s('hello') != 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d':
        raise Exception('checksum_s failed')

# Generated at 2022-06-23 13:59:47.602609
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum_s('abc', sha1) == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum_s(to_bytes('abc'), sha1) == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum_s('abc', _md5) == '900150983cd24fb0d6963f7d28e17f72'



# Generated at 2022-06-23 13:59:50.914899
# Unit test for function md5
def test_md5():
    '''util_hash.py: Test md5'''
    assert md5("/util_hash.py") == "c3f3b14e2cdb2e1e8d2e0659b8541ab6"

# Generated at 2022-06-23 14:00:01.415381
# Unit test for function md5
def test_md5():

    assert md5("/bin/ls") == "f671b09728f8c50bedeabd2b1a45a8ec"
    assert md5("/bin/ls") == md5("/bin/ls")
    assert md5("/bin/ls") != md5("/bin/chmod")
    assert md5("/bin/ls") != md5("/bin/cat")
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("hello") == md5s("hello")
    assert md5s("hello") != md5s("hello!")
    assert md5s("hello") != md5s("world")

# Generated at 2022-06-23 14:00:05.603867
# Unit test for function md5s
def test_md5s():
    test_string = 'this is a test string for md5'
    test_md5_string = md5s(test_string)

    assert test_md5_string == 'f2c7bbcbf7cde24874f5369e10b39149'


# Generated at 2022-06-23 14:00:10.099821
# Unit test for function md5
def test_md5():
    """
    This utility function is used to test the md5 function
    """
    md5hash_value= md5("/tmp/test.txt")
    if md5hash_value == 'd41d8cd98f00b204e9800998ecf8427e':
        return True
    else:
        return False

# Generated at 2022-06-23 14:00:12.267791
# Unit test for function md5
def test_md5():
    ''' secure_hash_test.py: test the secure_hash function '''

    import secure_hash_test
    secure_hash_test.run()

# Generated at 2022-06-23 14:00:18.247201
# Unit test for function md5
def test_md5():
    import tempfile
    fd, tf = tempfile.mkstemp()
    os.write(fd, b"foo")
    os.close(fd)
    try:
        print(md5(tf))
    finally:
        os.unlink(tf)


# Generated at 2022-06-23 14:00:29.065607
# Unit test for function checksum_s
def test_checksum_s():
    # Example data from http://en.wikipedia.org/wiki/SHA
    assert checksum_s('The quick brown fox jumps over the lazy dog') ==  '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12'
    assert checksum_s('The quick brown fox jumps over the lazy cog') ==  'de9f2c7fd25e1b3afad3e85a0bd17d9b100db4b3'
    assert checksum_s('') ==  'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('abc') ==  'a9993e364706816aba3e25717850c26c9cd0d89d'

# Generated at 2022-06-23 14:00:41.743907
# Unit test for function checksum_s
def test_checksum_s():
    assert type(checksum_s('', hash_func=sha1)) == type(u'')
    assert len(checksum_s('', hash_func=sha1)) == len(u'0a4d55a8d778e5022fab701977c5d840bbc486d0')
    assert checksum_s('a', hash_func=sha1) == u'86f7e437faa5a7fce15d1ddcb9eaeaea377667b8'
    assert checksum_s('abc', hash_func=sha1) == u'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum_s('a', hash_func=sha1) == checksum_s(to_bytes('a'), hash_func=sha1)


# Generated at 2022-06-23 14:00:44.332742
# Unit test for function md5s
def test_md5s():
    assert md5s(to_bytes('hello', errors='surrogate_or_strict')) == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-23 14:00:52.762432
# Unit test for function checksum
def test_checksum():
    '''
    Validate the checksum function with the known sha1 checksum of ansible
    (calcuated with shasum -a 1 on Mac OS X)
    '''
    local_checksum = checksum(u'../../hacking/env-setup')
    if local_checksum == 'c4c8f9d4e1e4d4c716ae8c63b7177b1e37939f70':
        print('checksum success')
    else:
        print('failed to calculate the checksum correctly')


# Generated at 2022-06-23 14:01:02.131207
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('a') == '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8'
    assert checksum_s('ab') == 'e2fc714c4727ee9395f324cd2e7f331f'
    assert checksum_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum_s('abcd') == '81fe8bfe87576c3ecb22426f8e57847382917acf'
    assert checksum_s('abcde') == '03de6c570bfe24bfc328ccd7ca46b76eadaf4334'

# Generated at 2022-06-23 14:01:08.316622
# Unit test for function checksum
def test_checksum():

    # Secure hash
    assert secure_hash('/bin/ls') == '6b8e147d13f45165e6d0d6a250f4287b4e22c4cf'
    assert len(secure_hash('/bin/ls')) == 40
    assert secure_hash('/bin/ls', sha1) == '6b8e147d13f45165e6d0d6a250f4287b4e22c4cf'
    assert len(secure_hash('/bin/ls', sha1)) == 40

    # Secure hash single string
    assert secure_hash_s('Hello, World!') == '7b502c3a1f48c8609ae212cdfb639dee39673f5e'
    assert len(secure_hash_s('Hello, World!')) == 40

# Generated at 2022-06-23 14:01:20.627551
# Unit test for function md5
def test_md5():
    ''' unit test for md5'''

    import tempfile
    import os

    tf = tempfile.NamedTemporaryFile()
    tf.write(b'hello world\n')
    tf.flush()

    if md5(tf.name) != '5eb63bbbe01eeed093cb22bb8f5acdc3':
        raise Exception("md5 unit test failed on %s" % tf.name)

    if md5s('hello world') != 'ed076287532e86365e841e92bfc50d8c':
        raise Exception("md5 unit test failed on 'hello world'")

    (fd,name) = tempfile.mkstemp(suffix='.tmp')
    f = os.fdopen(fd, "wb")
    f.write(b'hello world\n')


# Generated at 2022-06-23 14:01:27.277486
# Unit test for function md5s
def test_md5s():
    # The values below are based on the output of 'md5sum' command on
    # Linux (fedora, centos & ubuntu) and FreeBSD
    data = 'data'
    assert '7815696ecbf1c96e6894b779456d330e' == md5s(data)
    data = 'another data for test'
    assert '24f7731e4c4a5d150b5a5a5a5a5a5a5a5' == md5s(data)


# Generated at 2022-06-23 14:01:28.308230
# Unit test for function checksum
def test_checksum():
    got = checksum(__file__)
    assert got is not None

# Generated at 2022-06-23 14:01:33.797965
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(u'hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'



# Generated at 2022-06-23 14:01:35.547668
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-23 14:01:42.155155
# Unit test for function md5
def test_md5():
    import tempfile
    (fd, fname) = tempfile.mkstemp()
    try:
        if os.path.exists(fname):
            os.remove(fname)

        # test with non existing file
        assert md5(fname) == None

        # create file
        f = open(fname, "w")
        f.write("foo\n")
        f.close()

        # test with existing file
        assert md5(fname) == "acbd18db4cc2f85cedef654fccc4a4d8"
    finally:
        os.close(fd)
        if os.path.exists(fname):
            os.remove(fname)

# Generated at 2022-06-23 14:01:52.690362
# Unit test for function checksum
def test_checksum():
    # Test that checksum works for a file that exists.
    checksum_path = os.path.dirname(__file__)
    checksum_filename = os.path.join(checksum_path, 'ANSIBLE_MODULE_UTILS_STRING_CONSTANTS.py')
    assert to_bytes(checksum(checksum_filename)) == b'0c5f9cc5f5eb0d96eccc5f0e3038a3a622b41f58'
    # Test that checksum returns None for a file that does not exist.
    checksum_filename = os.path.join(checksum_path, 'not_a_file.py')
    assert checksum(checksum_filename) is None

# Generated at 2022-06-23 14:01:57.474847
# Unit test for function md5
def test_md5():
    try:
        md5('/etc/passwd')
        assert False
    except ValueError as e:
        assert str(e) == 'MD5 not available.  Possibly running in FIPS mode'

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 14:01:59.320210
# Unit test for function checksum
def test_checksum():
    assert checksum(__file__) == checksum_s(open(__file__, 'rb').read())



# Generated at 2022-06-23 14:02:02.177889
# Unit test for function checksum_s
def test_checksum_s():
    assert(checksum_s('') == "da39a3ee5e6b4b0d3255bfef95601890afd80709")


# Generated at 2022-06-23 14:02:06.583987
# Unit test for function checksum
def test_checksum():
    checksum_value = checksum('/Users/kimbo/Documents/ansible/lib/ansible/module_utils/basic.py')
    assert checksum_value == 'f0b6e78b6c657d969ae9a4e4b2ea2f8c14ae6ed0'



# Generated at 2022-06-23 14:02:11.661168
# Unit test for function md5s
def test_md5s():
    ''' Unit test for function md5s. '''

    if _md5:
        assert md5s('123') == '202cb962ac59075b964b07152d234b70'
    else:
        try:
            md5s('123')
        except Exception as e:
            assert str(e) == 'MD5 not available.  Possibly running in FIPS mode'


# Generated at 2022-06-23 14:02:13.867179
# Unit test for function checksum
def test_checksum():
    checksum('/bin/ls')

# unit test for function checksum_s

# Generated at 2022-06-23 14:02:22.486167
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    # Test for SHA1
    assert md5s('sha1') == 'beb25bae375a731120c1d93d33835b1a'
    # Test for file
    test_file = "/tmp/ansible_test_md5"
    test_string = "ansible_test_md5"

# Generated at 2022-06-23 14:02:26.663772
# Unit test for function checksum
def test_checksum():
    result = checksum('/etc/passwd')
    assert result == 'df53ca268240b77ef38c2d0e7b4d3c3a718ea6cc'



# Generated at 2022-06-23 14:02:30.025167
# Unit test for function md5
def test_md5():
    assert md5('hacking/test/unit/filter_plugins/test.py') == '42e6ae1baa40268fdbf73c6efa0f97f1'


# Generated at 2022-06-23 14:02:33.949524
# Unit test for function checksum_s
def test_checksum_s():
    # verify that test_str contains the sha1 checksum of "abc"
    test_str = "a9993e364706816aba3e25717850c26c9cd0d89d"
    assert test_str == checksum_s("abc")
    # test unicode input
    assert test_str == checksum_s(u"abc")

# Generated at 2022-06-23 14:02:36.771857
# Unit test for function md5s
def test_md5s():
    assert md5s("foobar") == '3858f62230ac3c915f300c664312c63f'


# Generated at 2022-06-23 14:02:42.094105
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("Hello World") == '0a4d55a8d778e5022fab701977c5d840bbc486d0'
    assert checksum_s("Hello World", hash_func=_md5) == 'ed076287532e86365e841e92bfc50d8c'



# Generated at 2022-06-23 14:02:44.467537
# Unit test for function md5
def test_md5():
    string = 'hello world'
    assert md5s(string) == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-23 14:02:48.101892
# Unit test for function md5
def test_md5():
    assert md5s('some string') == '3c3e3183d8f6bd09aee69285038c3f6a'


# Generated at 2022-06-23 14:02:57.560835
# Unit test for function checksum
def test_checksum():
    # empty file
    assert secure_hash('/dev/null') == 'cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e'
    # short text file
    assert secure_hash(__file__) == '59f9c9509bfdc8f7d33635d02c15cee2a21e8d09'
    # long text file

# Generated at 2022-06-23 14:03:07.295720
# Unit test for function checksum
def test_checksum():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert checksum('a.in') == '0cc175b9c0f1b6a831c399e269772661'
    assert checksum('a.in', checksum=sha1) == '0cc175b9c0f1b6a831c399e269772661'
    assert checksum_s('a.in') == '0cc175b9c0f1b6a831c399e269772661'  # Backwards compat
    assert checksum_s('a.in', checksum_s=sha1) == '0cc175b9c0f1b6a831c399e269772661'

# Generated at 2022-06-23 14:03:12.450144
# Unit test for function md5s
def test_md5s():
    """
    Unit test for md5s function
    """
    import unittest
    test_data = 'test_data'
    hash_value = 'e8dc4081b13434b45189a720b77b6818'
    class TestChecksum(unittest.TestCase):
        def test_nonexistent_file(self):
            self.assertEqual(None, md5('/not/existing/file'))
    if __name__ == '__main__':
        unittest.main()
    unittest.main()

# Generated at 2022-06-23 14:03:18.426539
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'a6da129f6e5d045dbe24717620d998510c0ca9b9'
    assert checksum('/bin/ls') == checksum_s(open('/bin/ls', 'r').read())
    if _md5:
        assert md5('/bin/ls') == 'ff7a97a0b360cfe8fc9d1d720b71b0aa'
        assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    # Checksum of non existing file
    assert checksum('/nonexisting') == None

# unit test for function secure_hash_s

# Generated at 2022-06-23 14:03:23.084136
# Unit test for function md5
def test_md5():
    print("testing md5")
    fname = "/tmp/test_md5"
    with open(fname, 'w') as f:
        f.write("test")
    h = md5(fname)
    assert h == '098f6bcd4621d373cade4e832627b4f6'
    os.unlink(fname)

# Generated at 2022-06-23 14:03:27.798015
# Unit test for function checksum_s
def test_checksum_s():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    x = checksum_s(u'some text')
    y = checksum_s(AnsibleUnsafeText(u'some text'))
    assert x == y
    assert len(x) == 40

# Generated at 2022-06-23 14:03:35.464636
# Unit test for function checksum
def test_checksum():
    """ test if checksum returns the same value as sha1sum """
    test_str = 'hello world'
    result = checksum_s(test_str)
    import subprocess
    sha1sum_result = subprocess.check_output(['sha1sum'], input=test_str, universal_newlines=True)
    sha1sum_result = sha1sum_result.split()[0]
    assert result == sha1sum_result

if __name__ == '__main__':
    # Run unit tests
    test_checksum()

# Generated at 2022-06-23 14:03:38.488478
# Unit test for function md5s
def test_md5s():

    md5s_1 = md5s('foo')
    md5s_2 = md5s('foo')
    assert(md5s_1 == md5s_2)

    md5s_3 = md5s('bar')
    assert(md5s_1 != md5s_3)

# Generated at 2022-06-23 14:03:44.379972
# Unit test for function md5s
def test_md5s():
    import random
    import string

    def random_string():
        char_set = string.ascii_lowercase + string.ascii_uppercase + string.digits
        return ''.join(random.sample(char_set, 10))

    for x in range(1, 10):
        cs = md5s(random_string())
        assert len(cs) == 32

# Generated at 2022-06-23 14:03:54.633609
# Unit test for function checksum
def test_checksum():
    from ansible.module_utils._text import to_bytes

    assert len(checksum_s('')) == 40, checksum_s('')
    assert len(checksum_s('hello world')) == 40, checksum_s('hello world')
    assert len(checksum_s(u'h\xe9llo world')) == 40, checksum_s(u'h\xe9llo world')
    assert len(checksum_s(b'hello world')) == 40, checksum_s(b'hello world')
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed', checksum_s('hello world')

# Generated at 2022-06-23 14:04:05.042993
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s(b'test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s(u'test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s(u'\u043f\u0440\u0438\u0432\u0435\u0442') == 'b4834a0a097f798745ebb0a57b9a9182'