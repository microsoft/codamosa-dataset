

# Generated at 2022-06-23 13:54:00.357101
# Unit test for function md5s
def test_md5s():
    pass

# Generated at 2022-06-23 13:54:03.436825
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello") == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-23 13:54:14.050920
# Unit test for function checksum
def test_checksum():
    import tempfile

    # Create temporary test file
    fp, fpath = tempfile.mkstemp(prefix='ansible-test')
    os.write(fp, b"test")
    os.close(fp)

    # Make sure temp file is really there
    assert os.path.exists(fpath), "%r should exist" % fpath

    # Calculate checksum of file
    sha = checksum(fpath)

    # Verify checksum
    assert sha == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', "%r != a94a8fe5ccb19ba61c4c0873d391e987982fbbd3" % sha

    # Remove tempfile
    os.remove(fpath)

    # Check for non-

# Generated at 2022-06-23 13:54:23.977048
# Unit test for function checksum

# Generated at 2022-06-23 13:54:29.593443
# Unit test for function checksum_s
def test_checksum_s():
    data = 'test'
    checksum_data = checksum_s(data)

    if checksum_data == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3':
        print('test_checksum_s succeeded')
    else:
        print('test_checksum_s failed')



# Generated at 2022-06-23 13:54:39.396541
# Unit test for function checksum
def test_checksum():

    checksum_value = checksum_s('hello')
    # Checksum is a SHA1 digest (40 chars)
    assert len(checksum_value) == 40

    test_string = 'hello world'
    checksum_value = checksum_s(test_string)
    # Checksum is a SHA1 digest (40 chars)
    assert len(checksum_value) == 40

    # Checksum should contain only hex digits
    assert all(c in "0123456789abcdef" for c in checksum_value)

    # known checksum value
    assert checksum_s('hello') == "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d"

# Generated at 2022-06-23 13:54:48.922377
# Unit test for function checksum_s
def test_checksum_s():
    checksum_s('')


if __name__ == "__main__":
    module = AnsibleModule(
        argument_spec = dict(
            data=dict(required=True),
            # Force digest to match a specific algorithm
            digest=dict(required=False, choices=['md5', 'sha1'])
        ),
        supports_check_mode=False
    )

    params = module.params

    data = params['data']
    digest = params['digest']


# Generated at 2022-06-23 13:54:56.312605
# Unit test for function checksum_s
def test_checksum_s():
    # Normal operation
    assert(checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709')
    # Message longer than 64 bytes
    assert(checksum_s('a'*65) == '397cc8c347e7f0a31b0ee1d925a8b9a270065269')
    # Pass bytes, not text
    assert(checksum_s(b'foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33')



# Generated at 2022-06-23 13:54:58.909801
# Unit test for function md5
def test_md5():
    assert md5("test/integration/filter_plugins/test.py") == "f788cfe0ea6ff983f9cf8a827e2f7d92"

# Generated at 2022-06-23 13:55:04.051486
# Unit test for function md5s
def test_md5s():
    import ansible.utils.unsafe_proxy
    assert md5s(ansible.utils.unsafe_proxy.safe_bytes('kossboss')) == 'ed7daf8d4ca4fe4d1b4c00eb45fa8b14'
    assert md5s(ansible.utils.unsafe_proxy.safe_bytes('kossboss1')) == 'de8e59d78f9b9c2b042d1a6e887d6bdd'

# Generated at 2022-06-23 13:55:07.791429
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


if __name__ == '__main__':

    import doctest
    doctest.testmod()

# Generated at 2022-06-23 13:55:19.652092
# Unit test for function checksum_s
def test_checksum_s():
    testString1 = "initial commit"
    testString2 = "initial commit v2"
    testString3 = "initial commit v3"
    returnVal1 = checksum_s(testString1)
    returnVal2 = checksum_s(testString2)
    returnVal3 = checksum_s(testString3)
    print ("Hashed strings:")
    print (testString1)
    print (returnVal1)
    print (testString2)
    print (returnVal2)
    print (testString3)
    print (returnVal3)
    print ("Hashed strings are different (different strings):")
    if (returnVal1 == returnVal2):
        print ("Fail")
    else:
        print ("Success")
    print ("Hashed strings are not the same (same string, different hash):")

# Generated at 2022-06-23 13:55:32.427738
# Unit test for function checksum
def test_checksum():
    test_str = 'hello'
    test_str_b = b'hello'
    test_str_u = u'hello'
    test_str_path = os.path.join(os.path.dirname(__file__), 'checksum_test.txt')
    test_str_path_b = to_bytes(test_str_path, errors='surrogate_or_strict')

    assert(checksum(test_str_path) == checksum_s(test_str_path))
    assert(checksum(test_str_path) == checksum(test_str_path_b))
    assert(checksum_s(test_str) == checksum_s(test_str_b))
    assert(checksum_s(test_str) == checksum_s(test_str_u))

# Generated at 2022-06-23 13:55:41.358876
# Unit test for function checksum_s
def test_checksum_s():
    # a simple string
    str_hash = checksum_s("hello world")
    assert str_hash, "expected hash result from string input"

    # an empty string
    empty_hash = checksum_s("")
    assert empty_hash, "expected hash result from empty string input"

    # A unicode string
    unicode_hash = checksum_s(u"\u2713")
    assert unicode_hash, "expected hash result from unicode string input"

    # A string with non-ascii characters
    non_ascii_hash = checksum_s("\x8a")
    assert non_ascii_hash, "expected hash result from string with non-ascii characters"

    # A string with a surrogate character
    surrogate_hash = checksum_s("\udcda")
    assert surrogate_

# Generated at 2022-06-23 13:55:48.576333
# Unit test for function md5
def test_md5():
    import os
    import tempfile

    fd, pth = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write("""
    123456789
    abcdefghi
    ABCDEFGHI
    """)
    f.close()

    assert md5(pth) == '56c7d1b97e2b37e7bc47c3688690d7e0'
    os.unlink(pth)



# Generated at 2022-06-23 13:55:53.670741
# Unit test for function checksum
def test_checksum():
    if not _md5:
        raise ValueError('MD5 not available. Possibly running in FIPS mode')
    assert secure_hash_s('hello world', _md5) == md5s('hello world')
    assert secure_hash('/bin/ls', _md5) == md5('/bin/ls')

# Generated at 2022-06-23 13:55:58.669366
# Unit test for function md5s
def test_md5s():
    import random
    import string
    import sys

    s = ''.join(random.choice(string.ascii_letters) for _ in range(1024))

    m = md5s(s)
    if sys.version_info >= (3,):
        import hashlib
        assert(m == hashlib.md5(s.encode('utf-8')).hexdigest())
    else:
        import md5
        assert(m == md5.md5(s).hexdigest())

# Generated at 2022-06-23 13:56:00.375790
# Unit test for function md5
def test_md5():
    """ print the md5 hash of a file """
    print(md5("/etc/passwd"))

# Generated at 2022-06-23 13:56:10.684908
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s(u'') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s(' ') == 'b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9'
    assert checksum_s(u' ') == 'b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9'

# Generated at 2022-06-23 13:56:14.522217
# Unit test for function md5s
def test_md5s():
    assert md5s('smati.m@gmail.com') == '8ce7c50e77f1c7e0d6c8e7b4e69b1f15'



# Generated at 2022-06-23 13:56:24.862435
# Unit test for function checksum
def test_checksum():
    '''
    ansible checksum module - verify checksum function
    '''
    shasum = checksum('/bin/ls')
    if not shasum:
        raise ValueError('checksum() failed to return shasum')
    if not shasum == '6b8f0af93d8ca1c7c72fba35f6d3a8faafd6286b':
        raise ValueError('checksum() returned incorrect shasum')

    f = open('./test/test_checksum', 'w')
    f.write('foo')
    f.close()
    filesum = checksum('./test/test_checksum')

# Generated at 2022-06-23 13:56:28.216495
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/hosts') == '7a94fcf92e4d4c4f4d6f1d6c6928b60d'


# Generated at 2022-06-23 13:56:30.924664
# Unit test for function md5
def test_md5():
    assert md5("test_crypto.py") == '33568fc07ca63d46f35c7d095b5c5d5e'

# Generated at 2022-06-23 13:56:37.969531
# Unit test for function md5s
def test_md5s():
    # Test empty string
    r = md5s('')
    assert r == 'd41d8cd98f00b204e9800998ecf8427e'

    # Test Linux kernel md5sums
    r = md5s('path/to/linux-2.6.37.tar.xz')
    assert r == 'faa087e88b8a0e7aaf2935e0b866c050'

# Generated at 2022-06-23 13:56:41.956350
# Unit test for function md5
def test_md5():
    assert md5('test/utils/test_module_utils.py') == '50d5c47eac064f2b5a77cc8e1fb93a9a'

# Generated at 2022-06-23 13:56:50.854922
# Unit test for function checksum
def test_checksum():
    # Verify that a non-member string checksum results in all-zeros
    assert checksum_s("") == "da39a3ee5e6b4b0d3255bfef95601890afd80709"

    # Verify that a non-member file checksum results in None
    if not os.path.exists("/non/existent/file"):
        assert checksum("/non/existent/file") is None
    else:
        raise Exception("test_checksum() is not valid for this system")

    # Verify that a non-member file checksum results in None
    if not os.path.isdir("/etc"):
        assert checksum("/etc") is None
    else:
        raise Exception("test_checksum() is not valid for this system")

    # Verify that a file checksum contains 40 characters
   

# Generated at 2022-06-23 13:56:58.383075
# Unit test for function md5
def test_md5(): # 2.6 compat
    from tempfile import mkstemp
    from shutil import rmtree
    import sys
    import stat


# Generated at 2022-06-23 13:57:01.543886
# Unit test for function md5s
def test_md5s():
    assert md5s('d41d8cd98f00b204e9800998ecf8427e') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('None') is None
    assert md5s(None) is None

# Generated at 2022-06-23 13:57:08.099138
# Unit test for function checksum_s
def test_checksum_s():
    assert sha1('test').hexdigest() == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s('test') == sha1('test').hexdigest()
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-23 13:57:17.563041
# Unit test for function md5s
def test_md5s():
    assert(md5s("") == 'd41d8cd98f00b204e9800998ecf8427e')
    assert(md5s("a") == '0cc175b9c0f1b6a831c399e269772661')
    # Test unicode inputs
    assert(md5s(u"") == 'd41d8cd98f00b204e9800998ecf8427e')
    assert(md5s(u"a") == '0cc175b9c0f1b6a831c399e269772661')
    assert(md5s(u'\u263a') == '8ad20b1a981e143e1d70c723a9e21e2f')


# Generated at 2022-06-23 13:57:27.080168
# Unit test for function checksum
def test_checksum():
    from ansible.utils.hashing import checksum
    # I don't have any idea how to write a proper unit test for a checksum function.
    # This test might not be very beautiful but we will use this function so often
    # that it deserves some tests.
    assert checksum("/bin/ls") == '4b7f0c863efc13790ad0a0e39df977c1dbb2e0d2'
    assert checksum("/bin/ls", format='md5') == '1f9f43388e6fd8d6e8433a64b2742d9d'
    assert checksum("/bin/ls", format='sha1') == '4b7f0c863efc13790ad0a0e39df977c1dbb2e0d2'

# Generated at 2022-06-23 13:57:32.092405
# Unit test for function checksum
def test_checksum():
    dat = 'thisshouldwork'
    secure_hash_s(dat)
    filename = '/tmp/ansible_test_checksum'
    f = open(filename, 'wb')
    f.write(dat)
    f.close()
    secure_hash(filename)
    os.remove(filename)

# Generated at 2022-06-23 13:57:33.815693
# Unit test for function md5
def test_md5():
    assert md5s('test string') == '1bc29b36f623ba82aaf6724fd3b16718'



# Generated at 2022-06-23 13:57:45.901425
# Unit test for function checksum
def test_checksum():
    testfile = os.path.abspath(os.path.join(os.path.dirname(__file__), '../test/sanity/testmodule/checksum_test.txt'))

    # Test that checksum returns None if file is not present
    assert checksum('/usr/bin/non_existent_file') is None
    assert checksum_s('Hello World') == '2ef7bde608ce5404e97d5f042f95f89f1c232871'
    assert checksum_s('Hello World ') == '03d7e8c770e08bc71f0e2b47d1f840e94f79b9c9'
    assert checksum_s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
   

# Generated at 2022-06-23 13:57:49.731532
# Unit test for function md5
def test_md5():
    import tempfile
    from StringIO import StringIO

    f = StringIO("line 1\nline 2\nline 3")
    fname = tempfile.mktemp()
    fh = open(fname, 'wb')
    fh.write(f.read())
    fh.close()
    assert(md5(fname) == 'fbb288821157294524a991b2d7b10e61')
    os.unlink(fname)

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 13:58:01.296578
# Unit test for function checksum_s
def test_checksum_s():

    #
    # Test values taken from
    # http://onlinetools.org/tools/sha1-hash-calculator
    #
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello\n') == '7958d528c38d920d73184f3a0b1e73d64df2e0a3'
    assert checksum_s('The quick brown fox jumped over the lazy dog') == '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12'

# Generated at 2022-06-23 13:58:05.240909
# Unit test for function md5s
def test_md5s():

    checksum = md5s("test")
    assert checksum == '098f6bcd4621d373cade4e832627b4f6'
    checksum = md5s("testing")
    assert checksum == 'ae2b1fca515949e5d54fb22b8ed95575'

# Generated at 2022-06-23 13:58:13.493565
# Unit test for function checksum_s
def test_checksum_s():
    test1 = 'hello world'
    test2 = 'Goodbye, cruel world!'
    assert checksum_s(test1) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(test2) == 'b2eb2f738c85a945dac1d84448b7a1cbf2e376e5'
    assert checksum_s(test1) != checksum_s(test2)


# Generated at 2022-06-23 13:58:22.900498
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import time

    try:
        tmpdir = tempfile.mkdtemp()
        filename = os.path.join(tmpdir, "foo")
        fh = open(filename, "w")
        fh.write("Hello, World!")
        fh.close()
        time.sleep(1)
        fh = open(filename, "w")
        fh.write("Hello, World!")
        fh.close()
        md5 = md5(filename)
        assert md5 is not None
        assert md5.startswith("5eb63bbbe01eeed"), "md5(%s) = %s" % (filename, md5)
        assert len(md5) == 32
    finally:
        shutil.rmtree(tmpdir)


#

# Generated at 2022-06-23 13:58:35.342938
# Unit test for function md5s
def test_md5s():
    # Generate md5s of some string
    data = 'Hello, world!'
    md5s_data = md5s(data)

    # Generate md5s of those string
    # The following is a set of md5s generated with
    # $ echo -n 'Hello, world!' | openssl md5
    # $ echo -n 'Hello, world!' > file
    # $ openssl md5 file

# Generated at 2022-06-23 13:58:41.182215
# Unit test for function md5
def test_md5():
    assert md5('vars/main.yml') == 'bd24af20c7f9a1bb32f6189d44f0c25f'
    assert md5('tests/utils/test_md5_tt') == 'f3e3c27a0d0b2a8b1be049ec569f1a65'

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 13:58:50.674234
# Unit test for function checksum_s
def test_checksum_s():
    ''' Compare checksums for strings with known checksum values. '''
    #
    # Test alg sha1
    #
    # Test short string.
    string_test_small = 'The quick brown fox jumps over the lazy dog.'
    sum_test_small = '6c5da6a5a21c84985ca54316bbe2f90ef9ea1d8e'.lower()
    assert checksum_s(string_test_small) == sum_test_small
    # Test long string.

# Generated at 2022-06-23 13:58:54.614256
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    string = 'd408dc34e8ca61f4b4ebb29f2d40066d'
    assert md5s('Hello, World') == string

# Generated at 2022-06-23 13:59:00.524099
# Unit test for function checksum_s
def test_checksum_s():
    assert secure_hash_s("foobar") == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert secure_hash_s("foobar", hash_func=_md5) == '3858f62230ac3c915f300c664312c63f'

# Generated at 2022-06-23 13:59:07.447570
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s(b'hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s(u'hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

# Test the backwards compat function md5s

# Generated at 2022-06-23 13:59:10.665332
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


if __name__ == '__main__':
    print(md5s('hello'))

    print(md5('/etc/hosts'))

# Generated at 2022-06-23 13:59:12.610487
# Unit test for function md5s
def test_md5s():
    assert md5s("foobar") == "3858f62230ac3c915f300c664312c63f"

# Generated at 2022-06-23 13:59:17.087693
# Unit test for function md5s
def test_md5s():
    # Return Value should match
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    # If input string is empty the return value should match
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-23 13:59:19.808689
# Unit test for function md5s
def test_md5s():
    data = 'some data'
    hashed = md5s(data)
    assert hashed is not None
    assert len(hashed) == 32
    assert hashed == md5s(data)



# Generated at 2022-06-23 13:59:24.781724
# Unit test for function md5s
def test_md5s():
    return secure_hash_s("hello world") == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-23 13:59:27.402072
# Unit test for function md5
def test_md5():
    "Simple test for function md5"
    assert '6f8db599de986fab7a21625b7916589c' == md5('/etc/passwd')


# Generated at 2022-06-23 13:59:36.260465
# Unit test for function checksum
def test_checksum():
    ''' test checksum to make sure it returns a valid hash '''
    from . import __file__ as f

    c1 = checksum(f)
    assert len(c1) == 40  # sha1 produces 40 character hashes

    c2 = checksum(f)
    assert c1 == c2  # checksum should always return the same hash for a file

    c2 = checksum(f + 'asdf')
    assert c1 != c2  # different file should have a different hash

    c2 = checksum_s('ansible')
    assert len(c2) == 40  # sha1 produces 40 character hashes

    c3 = checksum_s('ansible')
    assert c2 == c3

# Generated at 2022-06-23 13:59:37.127947
# Unit test for function md5
def test_md5():
    assert True == False, "Test not implemented, please create."

# Generated at 2022-06-23 13:59:43.104450
# Unit test for function md5
def test_md5():
    ''' secure_hash.md5() with a file '''
    assert md5("examples/ansible.cfg") == '5ba5a5f06c098b6f438dda7d5a0ef59c'
    assert md5("examples/ansible.cfg") == secure_hash("examples/ansible.cfg", _md5)


# Generated at 2022-06-23 13:59:50.652095
# Unit test for function md5s
def test_md5s():
    if _md5:
        # If _md5 is not None, then MD5 should be available
        assert(md5s('test') == '098f6bcd4621d373cade4e832627b4f6')
    else:
        # If _md5 is None, then MD5 must _not_ be available
        # (e.g. running in FIPS-140-2 mode)
        import pytest
        with pytest.raises(ValueError):
            md5s('test')


#
# SHA1 functions.
#


# Generated at 2022-06-23 13:59:53.102199
# Unit test for function checksum
def test_checksum():
    checksum_func = checksum('/bin/ls', '/usr/bin/ls')
    assert checksum_func is not None

# Generated at 2022-06-23 13:59:55.739977
# Unit test for function md5
def test_md5():
    if _md5:
        assert md5('/bin/ls') == '0abe3f3bbe5bac9acb71fb8d5b470a81'
        assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-23 13:59:57.076358
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-23 14:00:01.324090
# Unit test for function checksum
def test_checksum():
    # Create a test file
    import tempfile
    fd, file_name = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('This is a simple test string')
    f.close()

    # Check the hash results
    print ('Test file name is %s' % file_name)
    print ('The checksum of string is %s' % checksum_s('This is a simple test string'))
    print ('The checksum of file is %s' % checksum(file_name))

    # Cleanup the test file
    os.unlink(file_name)

# Generated at 2022-06-23 14:00:04.247612
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello', sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

# Generated at 2022-06-23 14:00:13.548542
# Unit test for function checksum
def test_checksum():

    import random

    data = random.getrandbits(32)

    assert checksum_s(data) == checksum_s(str(data)) == checksum_s(unicode(data))

    # this should work, but only if you don't have /bin/foo which is not likely
    # assert checksum(data) == checksum(str(data)) == checksum(unicode(data)) == checksum_s(data)

    open('/tmp/ansible-tmp-for-test','wb').write(str(data))
    assert checksum('/tmp/ansible-tmp-for-test') == checksum_s(data)

    assert checksum('/bin/sh') == '7e35a6d1af0ff41b9c973ccaf7c2f09c'

# Generated at 2022-06-23 14:00:20.162980
# Unit test for function checksum_s
def test_checksum_s():
    # This string is the sha1 of the string 'hello', produce using:
    # python -c "print sha1('hello').hexdigest()"
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

# Generated at 2022-06-23 14:00:24.031655
# Unit test for function md5
def test_md5():
    data = "hello world"
    md5digest = md5s(data)
    assert md5digest == "5eb63bbbe01eeed093cb22bb8f5acdc3"


# Generated at 2022-06-23 14:00:28.301241
# Unit test for function md5s
def test_md5s():
    md5s1 = md5s('hello')
    print('md5(hello) = %s' % md5s1)
    assert md5s1 == '5d41402abc4b2a76b9719d911017c592', 'md5s fail'

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-23 14:00:35.562870
# Unit test for function md5
def test_md5():
    if not _md5:
        return
    try:
        assert md5('/etc/passwd') == '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8'
        assert md5s('hi') == '49f68a5c8493ec2c0bf489821c21fc3b'
    except AssertionError:
        raise

# Generated at 2022-06-23 14:00:40.253623
# Unit test for function checksum
def test_checksum():
    test_file = "./changelogs/CHANGELOG"
    assert checksum(test_file) == 'd717b76f7bdb0e2efa7a9a56325e9f7fba1f6444'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 14:00:44.266372
# Unit test for function md5
def test_md5():
    # Generate md5 checksum of test string
    data = "ansible"
    md5sum_data = md5s(data)
    # Test md5 checksum function
    assert md5sum_data == "7f3aa45c2d7edba0ade01c3a6a71cdbd"

# Generated at 2022-06-23 14:00:51.996821
# Unit test for function checksum
def test_checksum():
    mod = __import__('ansible.utils.checksum', fromlist=['checksum'])
    hasher = mod.sha1()
    res = checksum('Makefile')
    assert res == "8cd75e3ac9b3f3da1f1d8de7c1c83e4e7fc69d27", res
    res = checksum('/tmp/doesnotexist')
    assert res == None
    res = checksum('/dev/null')
    assert res == None


# Generated at 2022-06-23 14:00:54.623309
# Unit test for function md5
def test_md5():
    filename = './lib/ansible/module_utils/basic.py'
    result = md5(filename)
    assert result == '6917f7e49e0c66d3dd0fc16ae3cc7fd1'


# Generated at 2022-06-23 14:00:59.417434
# Unit test for function checksum
def test_checksum():
    import tempfile

    fd, fn = tempfile.mkstemp()
    f = open(fn, 'wb')
    f.write(b'hello')
    f.close()
    os.close(fd)
    assert checksum(fn) == checksum_s('hello')
    os.unlink(fn)
    assert checksum(fn) is None

# Generated at 2022-06-23 14:01:03.230468
# Unit test for function md5
def test_md5():
    assert secure_hash('changelogs/CHANGELOG-v1.7') == md5('changelogs/CHANGELOG-v1.7')
    assert secure_hash('changelogs/CHANGELOG-v1.7', _md5) == md5('changelogs/CHANGELOG-v1.7')


# Generated at 2022-06-23 14:01:08.985045
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s('This is a test.') == 'd4591f5bbc97e2f4b1ea3b4d9b03f9b1'
    assert md5s('This is a test.123') == 'b50f7aacd849041f9ab09be9c9e29e2d'
    assert md5s('This is a test.\n') == '9e9e9a9dba7d66b037b3988cdfc89e0d'


# Generated at 2022-06-23 14:01:17.639664
# Unit test for function md5
def test_md5():
    '''Unit test for function md5'''
    test_md5_file = os.path.abspath(__file__)
    test_md5_s = md5s(open(test_md5_file).read())
    test_md5 = md5(test_md5_file)

    assert test_md5 == test_md5_s
    assert test_md5 == '83a5f5f5a5a5c5b5e5b5b859c5e5b5b5'



# Generated at 2022-06-23 14:01:23.647138
# Unit test for function checksum
def test_checksum():
    # the file to test with - created via 'touch /tmp/testfile'
    FILENAME = '/tmp/testfile'
    file_hash = checksum(FILENAME)
    assert file_hash == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert secure_hash_s('abcd') == 'e2fc714c4727ee9395f324cd2e7f331f'

# Generated at 2022-06-23 14:01:25.832460
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('a').startswith('86f7e4')


# Generated at 2022-06-23 14:01:27.727113
# Unit test for function md5
def test_md5():
    ''' unit test for md5, result is true if no exception '''
    checksum_s('test_md5')
    return True


# Generated at 2022-06-23 14:01:34.248098
# Unit test for function md5
def test_md5():
    f = '/etc/motd'
    if os.path.exists(f):
        h1 = md5(f)
        h2 = checksum(f)
        assert h1 != h2
        assert isinstance(h1, str)
    else:
        h1 = md5(f)
        h2 = checksum(f)
        assert h1 == h2
        assert h1 is None


# Generated at 2022-06-23 14:01:37.958843
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('lib/ansible/module_utils/basic.py') == '87d8894e1f5a5c4f82d665d9e4167f4a'

# Generated at 2022-06-23 14:01:40.774363
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("testing123") == "f0744d60dd500c92c8b22c6e8e9258c965bb12e9"


# Generated at 2022-06-23 14:01:52.689851
# Unit test for function checksum
def test_checksum():
    ''' test module: ansible.utils.checksum '''

    filename = os.path.join(os.path.dirname(__file__), 'checksum_test_file')

    # make sure the checksum is correct when touched
    sum1 = checksum(filename)
    assert sum1 == 'fadc5879c3b7f2bc8c1e7d1c903f35ce'

    # make sure the checksum is correct when written to
    with open(filename, 'w') as f:
        f.write("this is new content")
    sum2 = checksum(filename)
    assert sum2 == '18fa9b9f85ac7795b1e8e5d5368eab1b'

    # cleanup
    os.chmod(filename, 0o600)
    os.remove

# Generated at 2022-06-23 14:02:02.730794
# Unit test for function checksum
def test_checksum():
    string = "foo"
    # unit test for secure_hash
    assert secure_hash(string) == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    assert secure_hash(string, 'sha256') == "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae"

# Generated at 2022-06-23 14:02:04.418794
# Unit test for function md5s
def test_md5s():
    assert md5s("test") == "098f6bcd4621d373cade4e832627b4f6"

# Generated at 2022-06-23 14:02:08.492307
# Unit test for function md5s
def test_md5s():
    string = "Hello world and all the other geeks out there"
    md5sum = md5s(string)
    print("md5s function")
    print("String: " + string)
    print("MD5: " + md5sum)

if __name__ == "__main__":
    test_md5s()

# Generated at 2022-06-23 14:02:15.940572
# Unit test for function checksum
def test_checksum():
    # Test for file checksum
    with open('/etc/issue', 'r') as f:
        file_checksum = secure_hash(filename=f.name)
    # Test for string checksum
    str_checksum = secure_hash_s(data=f.read())
    checksum_dict = dict(file_checksum=file_checksum, string_checksum=str_checksum)
    return checksum_dict

if __name__ == '__main__':
    print(test_checksum())

# Generated at 2022-06-23 14:02:18.779974
# Unit test for function checksum_s
def test_checksum_s():
    data = "hello"
    h_sha1 = secure_hash_s(data)
    assert h_sha1 == "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d"
    h_md5 = md5s(data)
    assert h_md5 == "5d41402abc4b2a76b9719d911017c592"

if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-23 14:02:27.584820
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s('test value') != '68d7985edb9c58f7022769e264167d39390f7f0b':
        raise Exception('MD5 sum is wrong.  Possibly running in FIPS mode')
    if checksum_s('test value', sha1) != 'b072ac8ac46a37b4c4b3a4f075a8f280d4396c82':
        raise Exception('SHA1 sum is wrong')


if __name__ == '__main__':

    test_checksum_s()

# Generated at 2022-06-23 14:02:29.019144
# Unit test for function md5
def test_md5():
    assert md5("test/test_utils.py") == "0e89c085d8ae5fcd298c4b52f61d49f1"


# Generated at 2022-06-23 14:02:33.758933
# Unit test for function md5
def test_md5():
    try:
        md5("/non/existent/file")
        assert(False)
    except ValueError as e:
        assert("MD5 not available" in str(e))
    try:
        md5(__file__)
        assert(True)
    except ValueError as e:
        assert(False)

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 14:02:44.828672
# Unit test for function md5
def test_md5():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils.six import PY3

    module = AnsibleModule({}, supports_check_mode=True)


# Generated at 2022-06-23 14:02:55.592608
# Unit test for function checksum
def test_checksum():
    import tempfile

    def _create_file(filename, data):
        outfile = open(filename, 'wb')
        outfile.write(to_bytes(data, errors='surrogate_or_strict'))
        outfile.close()


# Generated at 2022-06-23 14:02:58.122892
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-23 14:03:00.827882
# Unit test for function md5s
def test_md5s():
    assert md5s('12345') == '827ccb0eea8a706c4c34a16891f84e7b'

test_md5s()

# Generated at 2022-06-23 14:03:06.119120
# Unit test for function md5
def test_md5():
    import tempfile
    f = tempfile.NamedTemporaryFile()
    data = b"test"
    f.write(data)
    f.flush()
    assert md5(f.name) == '098f6bcd4621d373cade4e832627b4f6'
    f.close()

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 14:03:09.507065
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '55d3a8d46bd07c65f0afbbad67b83f07878de3e3'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-23 14:03:13.170154
# Unit test for function md5
def test_md5():

    f = open('./test_md5.txt','r')
    data = f.read()
    assert md5s(data) == '95f7c75376f6c313f7a2ce2b8e7e34661a9a319a'


# Generated at 2022-06-23 14:03:24.098803
# Unit test for function checksum
def test_checksum():
    '''test_checksum - Unit test for function checksum
        Confirms that a known file checksum matches expected value'''

    tests = [ 'test/ansible/test/support/checksums/test1.in' ]

    for test in tests:
        if not os.path.exists(test):
            raise AnsibleError("Unable to locate " + test + " to perform checksum function test")
        else:
            testsum = checksum(test)

# Generated at 2022-06-23 14:03:26.521531
# Unit test for function md5s
def test_md5s():
    data = "12345"
    assert secure_hash_s(data, _md5) == md5s(data)


# Generated at 2022-06-23 14:03:34.741121
# Unit test for function checksum
def test_checksum():
    import datetime
    import tempfile

    tf = tempfile.NamedTemporaryFile()

    # first write some data to the tempfile
    tf.write(b'foo')
    tf.flush()

    assert checksum(tf.name)
    assert checksum_s(b'foo')

    os.utime(tf.name, (datetime.datetime.now(), datetime.datetime.now()))

    assert checksum(tf.name)
    assert checksum_s(b'foo')

    tf.write(b'bar')
    tf.flush()

    assert checksum(tf.name)
    assert checksum_s(b'foobar')

    tf.close()

# Generated at 2022-06-23 14:03:44.648279
# Unit test for function checksum
def test_checksum():

    import tempfile
    import os

    # Generate a temporary file, write a sample string
    tmpfile = tempfile.NamedTemporaryFile()
    tmpfile.write(b"Hello World!")
    tmpfile.flush()

    # Check hash of the sample string
    assert checksum_s(b"Hello World!") == "0a4d55a8d778e5022fab701977c5d840bbc486d0"

    # Check the hash of our tempfile
    assert checksum(tmpfile.name) == "0a4d55a8d778e5022fab701977c5d840bbc486d0"

    # Cleanup our tmp file
    tmpfile.close()

# Generated at 2022-06-23 14:03:52.750935
# Unit test for function checksum
def test_checksum():
    checksum_file = checksum('lib/ansible/modules/core/cloud/amazon/ec2.py')
    assert checksum_file == "48f12b3c4b4d1c9f20d877a1b25ae7b8aa0e77db"

    ansible_file = open('lib/ansible/modules/core/cloud/amazon/ec2.py').read()
    assert checksum_s(ansible_file) == "48f12b3c4b4d1c9f20d877a1b25ae7b8aa0e77db"

# Generated at 2022-06-23 14:04:04.089265
# Unit test for function checksum
def test_checksum():
    try:
        from hashlib import sha256
    except ImportError:
        try:
            from sha import sha256
        except ImportError:
            sha256 = None
    if sha256:
        assert checksum_s('hello world') == checksum_s('hello world')
        assert checksum_s('hello world', hash_func=sha256) == checksum_s('hello world', hash_func=sha256)
        assert checksum_s('hello world', hash_func=sha256) != checksum_s('hello world')
    else:
        assert checksum_s('hello world') == 'b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9'