

# Generated at 2022-06-23 13:54:10.685587
# Unit test for function checksum
def test_checksum():
    test_file = u'/tmp/checksum_test'
    data = u'Bacon ipsum dolor sit amet cow pork belly meatloaf pig. '
    f = open(to_bytes(test_file, errors='surrogate_or_strict'), "w")
    f.write(to_bytes(data, errors='surrogate_or_strict'))
    f.close()
    expected_file_hash = u'4f4e4d4c8b47f9357934f5f5c5b5e4f4'
    expected_string_hash = u'8b47f9357934f5f5c5b5e4f4'
    file_hash = checksum(test_file)
    string_hash = checksum_s(data)

# Generated at 2022-06-23 13:54:12.882970
# Unit test for function md5s
def test_md5s():
    assert md5s("data") == "1a79a4d60de6718e8e5b326e338ae533"


# Generated at 2022-06-23 13:54:16.910509
# Unit test for function checksum
def test_checksum():
    data = "foo"
    assert secure_hash_s(data, sha1) == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"


# Generated at 2022-06-23 13:54:18.573151
# Unit test for function checksum
def test_checksum():
    assert checksum(os.path.realpath(__file__)) == checksum_s(open(__file__).read())

# Generated at 2022-06-23 13:54:22.574387
# Unit test for function checksum
def test_checksum():
    if checksum('/etc/passwd') != '3a92a5a5707b6170bd0a541b88d7cebf':
        return "Computed checksum of /etc/passwd does not match; please investigate"

# Generated at 2022-06-23 13:54:24.641080
# Unit test for function checksum_s
def test_checksum_s():
    for h in (sha1, _md5):
        assert checksum_s('data', h) == secure_hash_s('data', h)



# Generated at 2022-06-23 13:54:28.712922
# Unit test for function checksum
def test_checksum():
    file_content = "This is a unit test."
    temp_file_path = '/tmp/test_checksum.temp'
    checksum_file = open(temp_file_path,'w')
    checksum_file.write(file_content)
    checksum_file.close()
    assert checksum(temp_file_path) == checksum_s(file_content)
    os.remove(temp_file_path)

# Generated at 2022-06-23 13:54:33.227282
# Unit test for function checksum_s
def test_checksum_s():
    if secure_hash_s('hello') == secure_hash_s('hello'):
        print('TEST SUCCESS: checksum_s')
    else:
        print('TEST FAILURE: checksum_s: hashes not equal')


if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-23 13:54:34.175272
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-23 13:54:42.235927
# Unit test for function md5
def test_md5():
    if _md5:
        test_file = open('/etc/hosts', 'rb')
        md5_hex_digest = md5(test_file.name)
        assert md5_hex_digest == '7e155cae22cecc7f917fe3bb30e7b33b'
    else:
        try:
            md5s('12345')
        except ValueError:
            pass


# Generated at 2022-06-23 13:54:49.993138
# Unit test for function checksum_s
def test_checksum_s():
    '''
    Function checksum_s should return the same values for string input
    as the stdlib command line utility shasum -a 1 does for string input
    '''

    from subprocess import Popen, PIPE

    test_vectors = {
        'foo': '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33',
        'bar': '62cdb7020ff920e5aa642c3d4066950dd1f01f4d',
        '': 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    }

    for test_string in test_vectors.keys():
        expected_sha1 = test_vectors[test_string]
        actual_sha1 = checksum

# Generated at 2022-06-23 13:54:57.283172
# Unit test for function md5
def test_md5():
    # Test md5 function on a valid file
    assert md5('/etc/passwd') == '7f39f8317e4927d97d4e4d0db313ceaa'

    try:
        # Test md5 function on a directory
        md5('.')
    except ValueError:
        pass
    else:
        assert False

    try:
        # Test md5 function on a non-existent file
        md5('/etc/IDoNotExist')
    except ValueError:
        pass
    else:
        assert False

    # Test md5s function
    assert md5s('Hello World') == 'ed076287532e86365e841e92bfc50d8c'

# Generated at 2022-06-23 13:54:59.949304
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == '9a3f4350e17b3a8c3f2b28fad3a97fa1'

# Generated at 2022-06-23 13:55:04.817476
# Unit test for function checksum_s
def test_checksum_s():
    tests = [(b'foo', '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33')]
    for test in tests:
        result = checksum_s(test[0])
        assert result == test[1]


if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-23 13:55:17.267375
# Unit test for function checksum
def test_checksum():
    from tempfile import mkstemp
    from os import fdopen, remove
    from random import randint

    # Create a random file for testing
    f, fn = mkstemp()
    f = fdopen(f, 'w')
    for _ in range(20):
        f.write(chr(randint(0, 255)))
    f.close()

    # Test if checksum produces the same hash within different paths
    f = '/tmp/%s' % fn.split('/')[-1]
    checksum1 = checksum(fn)
    checksum2 = checksum(f)

    assert checksum1 == checksum2

    # Cleanup
    remove(f)


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 13:55:20.355982
# Unit test for function checksum
def test_checksum():
    # WARNING: this function uses the sha module which is not FIPS compliant
    assert checksum('/bin/ls') == 'c4dbeaac6fb38774787e8e59a4d2f3bd3a658767'

# Generated at 2022-06-23 13:55:32.765395
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_s('foo\n') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert checksum_s('foo\nbar\n') == 'a1e9f9e8d39446b11e02449c70bd4059'
    assert checksum_s('foo\nbar\n') == 'a1e9f9e8d39446b11e02449c70bd4059'

    # Test that unicode works the same as the python2 string version

# Generated at 2022-06-23 13:55:38.487336
# Unit test for function checksum
def test_checksum():
    '''
    Test if function checksum works for a given testfile
    '''

    testfile = open('testfile', 'w')
    testfile.write('test')
    testfile.close()
    assert checksum('testfile') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    os.remove('testfile')
    assert checksum('testfile') is None


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 13:55:41.496346
# Unit test for function md5
def test_md5():
    assert(md5s('testing') == 'ae2b1fca515949e5d54fb22b8ed95575')

# Generated at 2022-06-23 13:55:51.004908
# Unit test for function checksum
def test_checksum():

    # Test checksum_s
    checksum_val = checksum_s('abc')
    if checksum_val != 'a9993e364706816aba3e25717850c26c9cd0d89d':
        raise AssertionError("Test checksum_s failed")

    # Test checksum
    filename = os.path.join(os.path.dirname(__file__), '../../lib/ansible/modules/core/cloud/rackspace/rax.py')
    checksum_val = checksum(filename)
    if checksum_val != '6f0c49d1e74a8dc8ece7cfd59c27a4a6a4b8f1b4':
        raise AssertionError("Test checksum failed")


# Generated at 2022-06-23 13:55:54.686821
# Unit test for function checksum
def test_checksum():
    data = 'foobar'
    assert checksum_s(data) == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert checksum(to_bytes(__file__, errors='surrogate_or_strict')) == checksum_s(data)



# Generated at 2022-06-23 13:55:57.131780
# Unit test for function md5
def test_md5():
    assert md5(None) == None
    assert md5("test/test_module_utils.py") == "0b0e16f44dabce4516e293e78fdffa2d"


# Generated at 2022-06-23 13:56:00.422877
# Unit test for function md5s
def test_md5s():
    md5s("Leia, I know what you're thinking. \"I wonder what Ansible is up to?\"") == "f2d3a33fe7f1e96248f0d06f00c89dba"

# Generated at 2022-06-23 13:56:08.090009
# Unit test for function md5s
def test_md5s():
    import unittest

    class TestMd5s(unittest.TestCase):

        def test_md5s(self):
            # md5s("abc") is 900150983cd24fb0d6963f7d28e17f72
            # We have to first encode the string to utf-8
            self.assertEqual(md5s("abc"), "900150983cd24fb0d6963f7d28e17f72")
            self.assertEqual(md5s(u"abc"), "900150983cd24fb0d6963f7d28e17f72")
            self.assertEqual(md5s(u"\u2297"), "9b1c7ce4e4f4c7d8cc98f8766a4f5d0e")

# Generated at 2022-06-23 13:56:19.072962
# Unit test for function checksum
def test_checksum():
    ''' unit test for function checksum '''

    from ansible.module_utils.basic import AnsibleModule
    from ansible.compat.tests import unittest

    class AnsibleModuleTest(unittest.TestCase):
        def test_checksum(self):
            module = AnsibleModule(argument_spec={})
            local_md5sum = checksum('test/test_module_utils.py')
            remote_md5sum = module.run_command('md5sum %s' % 'test/test_module_utils.py', check_rc=True)[1].split()[0]

            self.assertTrue(local_md5sum == remote_md5sum)

    unittest.main(verbosity=2)

if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-23 13:56:25.840566
# Unit test for function checksum_s
def test_checksum_s():
    import random
    import string
    def randomword(max_length):
        length = random.randint(1, max_length)
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(length))

    data = []
    for i in range(10):
        data.append(randomword(10))
    CS = checksum_s('\n'.join(data))
    #print data
    #print hex(int(CS, 16))

if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-23 13:56:30.236743
# Unit test for function checksum
def test_checksum():
    data = "Data to be hashed"
    digest = sha1(to_bytes(data, errors='surrogate_or_strict')).hexdigest()
    assert digest == secure_hash_s(data, sha1)

# Generated at 2022-06-23 13:56:34.499998
# Unit test for function md5
def test_md5():
    assert md5("/bin/cat") != None
    assert md5("/bin/ls") != None
    assert md5("/bin/ls") != md5("/bin/cat")
    assert md5("/bin/ls") != md5("/bin/ls ")
    assert md5s("/bin/ls") != md5s("/bin/ls ")
    assert md5s("/bin/ls") != md5s("/bin/cat")

# Generated at 2022-06-23 13:56:37.837987
# Unit test for function md5s
def test_md5s():
    ''' test md5s function '''
    assert md5s(b"foobar") == "3858f62230ac3c915f300c664312c63f"


# Generated at 2022-06-23 13:56:41.799831
# Unit test for function md5
def test_md5():
    assert md5('/dev/null') == '23b7d1af9e9ef8a2f4f4d7c8727e3533'

# Generated at 2022-06-23 13:56:46.322637
# Unit test for function checksum_s
def test_checksum_s():
    test_string = 'Hello World'
    test_string_hash = '0a4d55a8d778e5022fab701977c5d840bbc486d0'
    assert secure_hash_s(test_string) == test_string_hash
    assert secure_hash_s(to_bytes(test_string, errors='strict')) == test_string_hash

# Generated at 2022-06-23 13:56:52.325390
# Unit test for function md5
def test_md5():
    test_file = '/tmp/md5_test'
    f = open(test_file, 'w')
    f.write('A test string')
    f.close()
    assert md5(test_file) == 'a9b824b669e7e83d2c67f7a75d2b3d07'
    assert md5s('A test string') == 'a9b824b669e7e83d2c67f7a75d2b3d07'

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 13:56:56.596783
# Unit test for function md5s
def test_md5s():
    print("Testing md5s")
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s("ansible") == "d6b03f6c88b6fea6ce40d3d3f6c249f6"

# Generated at 2022-06-23 13:56:59.653975
# Unit test for function md5
def test_md5():
    ''' test_md5 '''
    assert md5s("ansible") == "e9c2005b301d8d1fafde2fec5ab7d5c0"
    assert md5("test/test.py") == "cc8fa7b49c4a65f7c4d4c3f27dba5a5b"



# Generated at 2022-06-23 13:57:04.003498
# Unit test for function md5
def test_md5():
    md5_f = md5('/bin/false')
    assert md5_f is not None
    assert md5_f == '8cd8ef52e8e1019d79d3e3d8b1e3ae87'

    md5_s = md5s('true')
    assert md5_s is not None
    assert md5_s == '539be2382bbe8e23ad0ef5fb2a9552da'

    try:
        md5s(None)
    except Exception as e:
        assert str(e) == 'MD5 not available.  Possibly running in FIPS mode'

# Generated at 2022-06-23 13:57:09.396662
# Unit test for function md5
def test_md5():
    """Return a hex digest of the filename's contents, None if file is not present or a directory. """
    assert md5('/etc/mtab') == '1b65f98b00acf3f0a4ff4d22b968dc0b'
    assert md5('/etc/mtab1') == None



# Generated at 2022-06-23 13:57:11.859456
# Unit test for function md5s
def test_md5s():
    assert md5s("abc") == '900150983cd24fb0d6963f7d28e17f72'

# Generated at 2022-06-23 13:57:17.278623
# Unit test for function md5
def test_md5():
    h1 = md5s('')
    assert len(h1) > 0
    h2 = md5s('a')
    assert len(h2) > 0
    assert h1 != h2

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 13:57:26.847302
# Unit test for function checksum
def test_checksum():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import os

    class TestChecksum(unittest.TestCase):
        def test_checksum(self):
            data = 'hello'
            self.assertEqual(secure_hash_s(data), checksum_s(data))
            filename = os.path.realpath(__file__)
            self.assertEqual(secure_hash(filename), checksum(filename))
            for hash_func in (sha1,):
                self.assertEqual(secure_hash_s(data, hash_func), checksum_s(data, hash_func=hash_func))
                self.assertEqual(secure_hash(filename, hash_func), checksum(filename, hash_func=hash_func))

   

# Generated at 2022-06-23 13:57:36.035267
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s("Hello world") == "8b1a9953c4611296a827abf8c47804d7"
    assert md5s("") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5s("hello world\n") == "f9ff9195388798e731f9290a2670c798"
    assert md5s("hello world\nHello world\n") == "1d7d3f3eb90fd84188812e4fb4c07a4b"

# Generated at 2022-06-23 13:57:46.865620
# Unit test for function checksum
def test_checksum():
    '''Unit test for ansible.utils.checksum'''
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestChecksum(unittest.TestCase):

        def test_checksum_success(self):
            with patch('ansible.utils.checksum.open', create=True) as mock_open:
                mock_open.return_value = 'fakefile'
                with patch('os.path.exists') as mock_exists:
                    mock_exists.return_value = True
                    with patch('__builtin__.open') as mock_open2:
                        mock_open2.return_value = 'fakefile'
                        test_result = checksum("test_filename")

# Generated at 2022-06-23 13:57:50.095258
# Unit test for function md5s
def test_md5s():
    value = 'hello'
    expected_result = '5d41402abc4b2a76b9719d911017c592'
    assert md5s(value) == expected_result
    assert secure_hash_s(value) == expected_result


# Generated at 2022-06-23 13:57:52.827683
# Unit test for function checksum_s
def test_checksum_s():
    assert secure_hash_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', \
        "secure_hash_s returns the correct checksum of the string"


# Generated at 2022-06-23 13:58:04.169384
# Unit test for function md5
def test_md5():
    # The md5 checksums are calculated using "md5sum" command
    # in Linux shell and "md5" command in Mac OS X shell
    # To run the test on Windows, you need "md5.exe" program
    # (http://md5deep.sourceforge.net/)

    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    # Test the function md5s()
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

    # Test the function md5(), file "testfile" does not exist
    assert md5('testfile') == None

    # Test the function md5(), file "testfile" exists
    fp = open('testfile', 'w')

# Generated at 2022-06-23 13:58:14.645836
# Unit test for function md5s
def test_md5s():
    import tempfile
    import os
    fd, test_file = tempfile.mkstemp()
    test_string = """
hello
world
"""
    f = open(test_file,'w')
    f.write(test_string)
    f.close()
    md5 = md5s(test_string)
    m2 = md5s(test_file)
    m3 = md5s(open(test_file))
    os.unlink(test_file)
    assert(md5==m2==m3=='b10a8db164e0754105b7a99be72e3fe5')

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-23 13:58:22.666711
# Unit test for function checksum_s
def test_checksum_s():
    '''
    This function unit tests the checksum_s function.
    '''

    # Test sha1
    sha1_expected = 'd7752d6f25a0bce8c7d25d266f39b9ea60b3fd3c'
    assert checksum_s('/bin/ls') == sha1_expected

    # Test sha1 with a different hashlib
    sha1_expected = 'd7752d6f25a0bce8c7d25d266f39b9ea60b3fd3c'
    assert checksum_s('/bin/ls', hash_func=sha1) == sha1_expected



# Generated at 2022-06-23 13:58:30.599036
# Unit test for function checksum_s
def test_checksum_s():
    test_str = "ABCDEFG"
    assert len(checksum_s(test_str)) == 40
    assert len(checksum_s(b"ABCDEFG")) == 40
    assert checksum_s(test_str) == checksum_s(b"ABCDEFG")
    assert checksum_s(test_str) == "7ac66c0f148de9519b8bd264312c4d6466717222"



# Generated at 2022-06-23 13:58:36.406483
# Unit test for function md5
def test_md5():
    assert md5('/dev/null') == 'd41d8cd98f00b204e9800998ecf8427e'

    # in python >= 2.7, os.urandom(n) gives n random bytes
    rand_bytes = os.urandom(16)
    assert md5s(rand_bytes) == 'cbf23e74413c9f1b7d3c9f3b7c81bdd0'

# Generated at 2022-06-23 13:58:39.896528
# Unit test for function md5s
def test_md5s():
    """ insecure_hash_s unit test """

    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-23 13:58:42.588571
# Unit test for function md5
def test_md5():
    import os

    cwd = os.getcwd()
    test_file = os.path.join(cwd, "test_fixtures", "test_file")
    test_file_md5 = md5(test_file)
    assert test_file_md5 == '0cc175b9c0f1b6a831c399e269772661'



# Generated at 2022-06-23 13:58:49.040277
# Unit test for function checksum_s
def test_checksum_s():
    # test1: a sample string
    test1 = "sample data 1"
    assert checksum_s(test1) == "18160f2f9edf8a25cd08c280d0ebbd2f5236426b"

    # test2: a sample string with double quotes and comma
    test2 = '"sample data",2'
    assert checksum_s(test2) == "6f42bf6c28b6d862d7a1f6ddb3c67f05634e7c88"


# Generated at 2022-06-23 13:58:51.961660
# Unit test for function md5
def test_md5():
    md5 = md5s("abc")
    assert(md5 == "900150983cd24fb0d6963f7d28e17f72")



# Generated at 2022-06-23 13:58:59.554272
# Unit test for function md5s
def test_md5s():
    ''' test md5s() '''

    def md5_validate(data, result):
        assert isinstance(md5s(data), str)
        assert md5s(data) == result

    md5_validate('', 'd41d8cd98f00b204e9800998ecf8427e')
    md5_validate('to be or not to be that is the question', '98b2c32beeb37753f26a2d8f3e3a3a22')
    md5_validate('short', 'ebc7ffcc94bb9457a8d4035e3e0d0e15')

# Generated at 2022-06-23 13:59:09.423074
# Unit test for function md5
def test_md5():
    from ansible.module_utils._text import to_bytes
    from tempfile import NamedTemporaryFile

    def make_temp_file(data):
        with NamedTemporaryFile() as tf:
            tf.write(to_bytes(data))
            tf.flush()
            return tf.name

    # Test data string
    data_str = 'Test123'
    data_str_md5 = '1a2cfb7c8baf6958d46e97e35d014b7c'
    temp_file = make_temp_file(data_str)

    # Check md5 hash of string
    assert md5s(data_str) == data_str_md5
    # Check md5 hash of file
    assert md5(temp_file) == data_str_md5
    # Check with empty data

# Generated at 2022-06-23 13:59:12.497858
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"


# Generated at 2022-06-23 13:59:17.694410
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/passwd') is not None
    assert checksum('/usr/libexec/ansible/lib/ansible/module_utils/nosuchfile') is None
    assert checksum('/usr/libexec/ansible/lib/ansible/module_utils/') is None
    assert checksum('/usr/libexec/ansible/lib/ansible/module_utils/') is None



# Generated at 2022-06-23 13:59:25.572514
# Unit test for function md5s
def test_md5s():
    '''
    This function is called in unit test, test_basic.py
    '''
    import sys
    if sys.version_info.major == 2 and sys.version_info.minor == 4:
        md5s_sum = md5s('test')
    elif sys.version_info.major == 2 and sys.version_info.minor == 5:
        from hashlib import md5
        md5s_sum = secure_hash_s('test', md5)
    assert md5s_sum == '098f6bcd4621d373cade4e832627b4f6'
    # Other versions of python return a different hash
    # I think it's because of the different way of handling unicode



# Generated at 2022-06-23 13:59:35.587092
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('blah') == '1c8f1e834e6a5e0ed31462722b78154ddd8118fa'
    assert checksum_s(b'blah') == '1c8f1e834e6a5e0ed31462722b78154ddd8118fa'
    assert checksum_s(u'blah') == '1c8f1e834e6a5e0ed31462722b78154ddd8118fa'

    assert md5s('blah') == 'ed076287532e86365e841e92bfc50d8c'
    assert md5s(b'blah') == 'ed076287532e86365e841e92bfc50d8c'

# Generated at 2022-06-23 13:59:39.374078
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('a') == '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8'
    assert checksum_s(u'a') == '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8'



# Generated at 2022-06-23 13:59:50.728210
# Unit test for function md5s
def test_md5s():
    '''Unit test for md5s'''
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    import test.ansible_test
    test.ansible_test.TEST_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    test_string = 'kitten'
    x = md5s(test_string)
    assert x == '9d7e7b0f3533a7b2f82b358c85bc2a8a'
    x = md5s('kit' + 'ten')

# Generated at 2022-06-23 13:59:54.475211
# Unit test for function md5
def test_md5():
    from ansible.utils.unicode import to_unicode
    assert md5('files/file1') == to_unicode('6a64a2b9d1768a6f00a6fdfb6ed07dc4')


# Generated at 2022-06-23 14:00:03.906451
# Unit test for function checksum
def test_checksum():
    ''' Test checksum() and checksum_s(). '''

    # Test files
    file1 = 'test/testfile1'
    file2 = 'test/testfile2'

    # Test results for files and strings
    file1_sha1 = 'cead6a5b6a783f6d75f6e25fd7a0b0a363d788d3'
    file2_sha1 = '0cd3c856ae3f76bde7db27e3ff3f8b99691e1c0f'
    str_sha1 = 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

    # Test checksum() and checksum_s()
    assert checksum(file1) == file1_sha1
    assert checks

# Generated at 2022-06-23 14:00:07.287803
# Unit test for function md5s
def test_md5s():
    assert u'md5' in ansible.__version__
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-23 14:00:09.468766
# Unit test for function md5s
def test_md5s():
    import random
    import string
    assert(len(md5s('')) == 32)
    assert(len(md5s('a')) == 32)
    assert(len(md5s('hello world')) == 32)
    rand_string = ''.join(random.choice(string.ascii_letters + string.digits) for x in range(1024))
    assert(len(md5s(rand_string)) == 32)

# Generated at 2022-06-23 14:00:12.347702
# Unit test for function md5s
def test_md5s():
    ''' md5s() return md5 hash of the given data.'''
    assert md5s('Should return the md5 checksum of the given string.') == '70b45717f37bdd03fbe9c9a9f1ab0535'

# Generated at 2022-06-23 14:00:16.281906
# Unit test for function md5s
def test_md5s():
    assert '3e25960a79dbc69b674cd4ec67a72c62' == md5s("foo")


# Generated at 2022-06-23 14:00:27.773033
# Unit test for function md5
def test_md5():
    import pickle
    import tempfile

    # Test md5 generation
    (tmpfd, tmppath) = tempfile.mkstemp()
    os.write(tmpfd,b"foobarbaz")
    os.close(tmpfd)
    md5 = md5(tmppath)
    os.remove(tmppath)
    assert md5 == "8dbf3a1cd9d3e167cd6f380a76d057df", "md5 failed - actual: %s" % md5

    # Test md5s generation
    md5s = md5s("foobarbaz")
    assert md5s == "8dbf3a1cd9d3e167cd6f380a76d057df", "md5s failed - actual: %s" % md5s

    # Test pickle support

# Generated at 2022-06-23 14:00:33.463846
# Unit test for function checksum_s
def test_checksum_s():
    data = u"thisissecure"
    ans = secure_hash_s(data)
    print("secure_hash_s(u'thisissecure') == '%s'" % ans)
    print("secure_hash_s(u'thisissecure') == '%s'" % checksum_s(data))
    assert ans == checksum_s(data)

    data = "thisissecure"
    ans = secure_hash_s(data)
    print("secure_hash_s('thisissecure') == '%s'" % ans)
    print("secure_hash_s('thisissecure') == '%s'" % checksum_s(data))
    assert ans == checksum_s(data)



# Generated at 2022-06-23 14:00:44.342865
# Unit test for function checksum
def test_checksum():
    f1 = 'abc'
    f2 = 'xyz'
    f3 = 'abc\n'
    f4 = 'xyz\n'
    f5 = '/bin/ls'
    f6 = '/bin/ls\n'
    f7 = 'my shell script'
    f8 = 'my shell script\n'

    c1 = checksum_s(f1)
    c2 = checksum_s(f2)
    c3 = checksum_s(f3)
    c4 = checksum_s(f4)
    c5 = checksum_s(f5)
    c6 = checksum_s(f6)
    c7 = checksum_s(f7)
    c8 = checksum_s(f8)

    assert c1 is not None

# Generated at 2022-06-23 14:00:50.128155
# Unit test for function checksum
def test_checksum():
    test_file = "test/files/test_file_md5.txt"
    test_hash = '4b30c5dae7d6b8dd6f0e663736db6f17'
    assert checksum(test_file) == test_hash
    assert secure_hash(test_file) == test_hash


# Generated at 2022-06-23 14:00:58.382291
# Unit test for function checksum
def test_checksum():
    ''' checksum.py: Test checksum functionality '''

    # Create test file
    (fd, fname) = tempfile.mkstemp()
    os.write(fd, b"test")
    os.close(fd)

    # Check expected checksum
    cksum = checksum(fname)
    assert cksum == '098f6bcd4621d373cade4e832627b4f6', "checksum.py: checksum is '%s', expected '098f6bcd4621d373cade4e832627b4f6'" % cksum

    # Clean up
    os.unlink(fname)



# Generated at 2022-06-23 14:01:03.196635
# Unit test for function md5
def test_md5():
    h1 = md5s('foo')
    assert h1 == 'acbd18db4cc2f85cedef654fccc4a4d8', 'md5s of foo is wrong'
    assert md5s('bar') == md5('test/test-data/checksum_data/bar'), \
           'md5s of file is wrong'

if __name__ == "__main__":
    test_md5()

# Generated at 2022-06-23 14:01:05.718845
# Unit test for function md5s
def test_md5s():
    # Tests for md5s
    test_data = 'Hello World'
    assert md5s(test_data) == '65a8e27d8879283831b664bd8b7f0ad4'

# Generated at 2022-06-23 14:01:17.930466
# Unit test for function md5
def test_md5():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('Hello world') == 'b10a8db164e0754105b7a99be72e3fe5'
    assert md5s('HELLO world') == 'b03d19c8f7b2eccc30560c11d3a9cf7c'
    assert md5s('HELLO WORLD') == '7c222fb2927d828af22f592134e89324'

    assert md5('/dev/null') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-23 14:01:25.140129
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('123') == '40bd001563085fc35165329ea1ff5c5ecbdbbeef', "test_checksum_s()"

if __name__ == '__main__':
    # Run the tests if called directly
    import sys
    import unittest

    suite = unittest.TestLoader().loadTestsFromTestCase(__name__)
    unittest.TextTestRunner(verbosity=2).run(suite)
    sys.exit(0)

# Generated at 2022-06-23 14:01:32.282012
# Unit test for function md5
def test_md5():

    def _test_md5(filename, expected):
        result = md5(filename)
        assert result == expected

    # Perform test with no file
    try:
        _test_md5('unit_md5_should_fail', None)
    except AssertionError as ae:
        assert str(ae) == "unit_md5_should_fail: md5 failed"

    # Perform test with no file
    try:
        _test_md5('../../../tests/sanity/utils/md5.py', '211ef63d4f18f2caf8c49448bddc1ea1')
    except AssertionError as ae:
        assert str(ae) == "../../../tests/sanity/utils/md5.py: md5 failed"

# Generated at 2022-06-23 14:01:39.680786
# Unit test for function md5
def test_md5():
    if _md5:
        assert md5("/bin/ls") == "a628e44d48c77f15f7c8e73f60c81e02"
        assert md5("/bin/rm") == "89a3f938c7ee8aa31e84dd7e57cfe10a"
        assert md5("/bin/sh") == "40af65142c8a1e62aa2e2bafab0a2b2f"
        assert md5("/bin/bash") == "8adbfc37a07b0c32d59912ffc74aac00"


# Generated at 2022-06-23 14:01:48.738939
# Unit test for function checksum_s
def test_checksum_s():
    '''This function test for the functionality of the checksum_s function'''
    chksum = checksum_s('test')
    assert chksum == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', "sha1 hash value of 'test' should be a94a8fe5ccb19ba61c4c0873d391e987982fbbd3 "


if __name__ == "__main__":
    test_checksum_s()
    print('All checksum tests passed successfully!!!')

# Generated at 2022-06-23 14:01:51.538294
# Unit test for function md5
def test_md5():
    data1 = 'hello world'
    md51 = '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(data1) == md51


# Generated at 2022-06-23 14:02:02.288264
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s(b'test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s(u'test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s('foo' + u'bar') == '8843d7f92416211de9ebb963ff4ce28125932878'

# Generated at 2022-06-23 14:02:11.190145
# Unit test for function checksum
def test_checksum():

    filename = "test_chksum"
    failed = False
    try:
        f = open(filename, "w")
        f.write("The Ansible project would be no where without the help of the community.\n")
        f.close()
        digest = checksum(filename)
    except:
        failed = True
    if failed:
        print("Failed")
    elif digest == "fac29ae4ddf0e47951635f2d53bf894b34ce3c3d":
        print("Passed")
    else:
        print("Failed")
        print(digest)

    os.unlink(filename)

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 14:02:16.996899
# Unit test for function md5
def test_md5():
    import os, tempfile

    fd, fn = tempfile.mkstemp()
    os.write(fd, b"This is a test")
    os.close(fd)

    ret = md5(fn)

    assert ret == 'b6ae4e8069fceea14ad9548c4444e7a2'

    os.unlink(fn)


# Generated at 2022-06-23 14:02:18.980405
# Unit test for function md5s
def test_md5s():
    assert md5s(b'hello') == b'5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-23 14:02:24.669558
# Unit test for function md5
def test_md5():
    import tempfile
    f = tempfile.NamedTemporaryFile()
    try:
        f.write(b"abcdefg")
        f.flush()
        assert(md5(f.name) == "7ac66c0f148de9519b8bd264312c4d64")
    finally:
        f.close()

# Generated at 2022-06-23 14:02:26.154241
# Unit test for function md5s
def test_md5s():
    expectedValue = "eea6a2149a0f0f163e6c1349b9b90417"
    actualValue = md5s("test")
    assert actualValue == expectedValue

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-23 14:02:31.224306
# Unit test for function checksum_s
def test_checksum_s():
    #data = [u"hello", u"world", u"ansible", u"", u"test\u20ac"]
    data = ["hello", "world", "ansible", "", "test\u20ac"]
    for d in data:
        print("%s => %s" % (d, checksum_s(d)))

# Generated at 2022-06-23 14:02:36.081318
# Unit test for function checksum
def test_checksum():
    # create a test file and write a test string to it
    test_file='/tmp/checksum_test'
    test_str='This is a test'
    with open(test_file, 'w') as f:
        f.write(test_str)

    # check that the checksum of the test string and file are the same
    assert checksum(test_file) == checksum_s(test_str)

    # delete test file
    os.unlink(test_file)


# Generated at 2022-06-23 14:02:43.335555
# Unit test for function md5s
def test_md5s():
    # test string
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    # test unicode string
    assert md5s('t\xe9st'.decode('utf-8')) == 'b56c5712bc9f89dde2a32f27165de2e7'
    # test empty string
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-23 14:02:48.674883
# Unit test for function checksum_s
def test_checksum_s():
    from nose.plugins.skip import SkipTest
    raise SkipTest

    # FIXME: Finish the unit tests here
    # Preferably @with_setup(setup, teardown)
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s(b'hello') == '5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-23 14:02:51.735508
# Unit test for function checksum_s
def test_checksum_s():

    assert(checksum_s('hello world!') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed')
    assert(checksum_s('hello world!', None) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed')
    assert(checksum_s('hello world!', sha1) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed')



# Generated at 2022-06-23 14:02:57.979680
# Unit test for function checksum
def test_checksum():
    checksum_file = '../../lib/ansible/module_utils/basic.py'
    print("Computing checksum %s on file %s" % (checksum, checksum_file))
    assert secure_hash == checksum
    assert secure_hash == secure_hash


if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-23 14:03:04.665870
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s("foobar", hash_func=md5) != "3858f62230ac3c915f300c664312c63f":
        raise AssertionError("md5 checksum_s failed")
    if checksum_s("foobar", hash_func=sha1) != "8843d7f92416211de9ebb963ff4ce28125932878":
        raise AssertionError("sha1 checksum_s failed")


# Generated at 2022-06-23 14:03:06.592814
# Unit test for function md5s
def test_md5s():
    assert md5s(b"abc") == '900150983cd24fb0d6963f7d28e17f72'


# Generated at 2022-06-23 14:03:09.315068
# Unit test for function checksum
def test_checksum():
    digest = checksum('test/utils/checksum_test1.py')
    assert digest == '45c3f8d8db58a3f2c47ca90a46b8a007aca343f1'

# Generated at 2022-06-23 14:03:13.169347
# Unit test for function md5
def test_md5():
    '''
    ansible -m test -a 'data=abcdefg hash=md5s:md5.hexdigest()'
    '''
    assert md5s("abcdefg") == '7ac66c0f148de9519b8bd264312c4d64'


# Generated at 2022-06-23 14:03:18.299499
# Unit test for function checksum_s
def test_checksum_s():
    test_string = "hello world"
    expected_sha1_hash = "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"
    assert expected_sha1_hash == checksum_s(test_string)

# Generated at 2022-06-23 14:03:23.878901
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s("abc") == "900150983cd24fb0d6963f7d28e17f72"
    assert md5s("") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"

# Generated at 2022-06-23 14:03:33.069360
# Unit test for function checksum_s

# Generated at 2022-06-23 14:03:39.014491
# Unit test for function md5
def test_md5():
    import tempfile
    (handle, filename) = tempfile.mkstemp()
    try:
        f = os.fdopen(handle, 'wb')
        f.write(b"test")
        f.close()
        assert md5(filename) == "098f6bcd4621d373cade4e832627b4f6"
    finally:
        os.remove(filename)


# Generated at 2022-06-23 14:03:47.383059
# Unit test for function checksum
def test_checksum():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    import os
    import tempfile
    test_file = tempfile.NamedTemporaryFile('w', delete=False)
    test_file.write('test')
    test_file.close()
    assert(checksum(test_file.name) == md5(test_file.name))
    assert(checksum_s('test') == md5s('test'))
    os.unlink(test_file.name)

# Generated at 2022-06-23 14:03:52.836617
# Unit test for function md5
def test_md5():
    md5 = secure_hash_s(b'foo', _md5)
    assert md5 == 'acbd18db4cc2f85cedef654fccc4a4d8'
    md5 = secure_hash_s(b'foo', lambda: _md5())
    assert md5 == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-23 14:04:00.185141
# Unit test for function md5
def test_md5():
    import tempfile

    data = 'this is some test text'

    # Write to a temp file
    with tempfile.NamedTemporaryFile() as tmpfile:
        with open(tmpfile.name, 'w') as f:
            f.write(data)
        assert md5(tmpfile.name) == md5s(data)
    try:
        md5s(data)
        md5(data)
        assert False
    except ValueError:
        assert True