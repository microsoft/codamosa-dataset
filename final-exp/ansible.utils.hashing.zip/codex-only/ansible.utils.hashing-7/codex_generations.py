

# Generated at 2022-06-23 13:54:09.503154
# Unit test for function checksum
def test_checksum():
    # test md5
    md5_checksum = 'e2097dd8f3a55a8090518834f0bea5a8'
    assert md5s('test') == md5_checksum
    if not _md5:
        return
    assert md5(__file__) == md5_checksum

    # test sha1
    sha1_checksum = '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('test') == sha1_checksum
    assert checksum(__file__) == sha1_checksum

# Generated at 2022-06-23 13:54:14.734746
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("foo") == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_s("bar") == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'

# Generated at 2022-06-23 13:54:19.961199
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    else:
        try:
            md5s('foo')
        except ValueError as e:
            assert str(e) == 'MD5 not available.  Possibly running in FIPS mode'


# Generated at 2022-06-23 13:54:28.046914
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hel' + chr(0o200) + 'lo') == 'cb1f97c9e031376ea8382964289fb2c2'
    assert checksum_s(u'hel\xee\x80\x80lo') == 'cb1f97c9e031376ea8382964289fb2c2'

# Generated at 2022-06-23 13:54:34.725765
# Unit test for function md5
def test_md5():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestChecksum(unittest.TestCase):
        def test_md5_function(self):
            with patch('ansible.module_utils.basic.AnsibleModule.fail_json') as mock_fail:
                self.assertRaises(ValueError, md5, 'foo')
                mock_fail.assert_called_once_with(msg='MD5 not available.  Possibly running in FIPS mode')

# Generated at 2022-06-23 13:54:38.907931
# Unit test for function md5s
def test_md5s():
    import hashlib
    checksum = md5s('hello')
    comp_checksum = hashlib.md5('hello').hexdigest()
    assert checksum == comp_checksum


# Generated at 2022-06-23 13:54:42.518686
# Unit test for function md5s
def test_md5s():
    data = "hello world"
    checksum = md5s(data)
    assert checksum == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-23 13:54:46.228924
# Unit test for function checksum
def test_checksum():
    assert checksum(__file__.replace('.pyc','.py')) == checksum(__file__)
    assert checksum_s(__file__.replace('.pyc','.py')) == checksum_s(__file__)

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 13:54:52.652361
# Unit test for function checksum
def test_checksum():
    if checksum("/bin/ls") == "6b87d7e9a63729475f2a565c6b0e8eba" and \
       checksum("/bin/bash") == "c756720a7ab08d53a382359db8fac330" and \
       checksum("/usr/bin/python") == "6e2d69981889d8ebf0e24a6b6e0bfcc2" and \
       checksum("/this/file/does/not/exist") is None and \
       checksum("/") is None:
        return True
    else:
        return False

# Generated at 2022-06-23 13:55:03.587623
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil

    (tmpdir, dirname) = tempfile.mkstemp()
    os.close(tmpdir)
    shutil.rmtree(dirname)
    os.makedirs(dirname)

    (tmpdir, file1) = tempfile.mkstemp(dir=dirname)
    os.close(tmpdir)
    with open(file1, "w") as f:
        f.write("hello world")
    hash1 = secure_hash(file1)

    (tmpdir, file2) = tempfile.mkstemp(dir=dirname)
    os.close(tmpdir)
    with open(file2, "w") as f:
        f.write("goodbye world")
    hash2 = secure_hash(file2)

    # Same content, different files

# Generated at 2022-06-23 13:55:08.041792
# Unit test for function md5s
def test_md5s():
    data = """Test 123
    multiline string
    to see if the
    md5 sum works
    """
    assert md5s(data) == "3f1b61708f33e8f0b9e3b87f878848a0"

# Generated at 2022-06-23 13:55:12.152693
# Unit test for function md5
def test_md5():
    data = b"somedata"
    assert md5s(data) == "8c83f2f12d08e2a979c947fb0330e476"


# Generated at 2022-06-23 13:55:14.924023
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-23 13:55:16.705526
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'


# Generated at 2022-06-23 13:55:20.553856
# Unit test for function checksum_s
def test_checksum_s():
    ''' Return a secure hash hex digest of data. '''

    # Test AnsibleModule
    digest_string1 = checksum_s('Hello World, this is Ansible!')
    assert(digest_string1 == 'a1d0c6e83f027327d8461063f4ac58a6')

# Generated at 2022-06-23 13:55:24.083602
# Unit test for function md5s
def test_md5s():
    data = "sample_data"
    print("MD5 of '%s' is '%s'" % (data, md5s(data)))



# Generated at 2022-06-23 13:55:25.670875
# Unit test for function md5
def test_md5():
    print(md5("/etc/group"))


# Generated at 2022-06-23 13:55:28.354142
# Unit test for function checksum_s
def test_checksum_s():
    result = checksum_s('test')
    assert result == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

# Generated at 2022-06-23 13:55:35.607839
# Unit test for function checksum
def test_checksum():
    checksum_file = '/etc/passwd'
    checksum_s_str = '123'
    assert checksum(checksum_file) == 'a79634e0d3a3e3f2765c9d917faaad01edfd2fd8'
    assert checksum_s(checksum_s_str) == '202cb962ac59075b964b07152d234b70'
    try:
        md5(checksum_file)
    except ValueError as e:
        assert "MD5 not available.  Possibly running in FIPS mode" in str(e)


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 13:55:40.287470
# Unit test for function md5
def test_md5():
    assert md5("invalidfile") is None
    assert md5("../test/testdata/test_file") == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-23 13:55:49.486269
# Unit test for function md5s
def test_md5s():

    if not _md5:
        return

    # These tests only work if there is a working md5 module
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('12345678901234567890123456789012345678901234567890123456789012345678901234567890') == '57edf4a22be3c955ac49da2e2107b67a'

# Generated at 2022-06-23 13:55:54.578398
# Unit test for function md5s
def test_md5s():
    # Test all ascii values
    dat = ""
    for n in range(256):
        dat = dat + chr(n)

    dat_md5 = "5e543256c480ac577d30f76f9120eb74"
    assert md5s(dat) == dat_md5


# Generated at 2022-06-23 13:56:01.187674
# Unit test for function checksum
def test_checksum():

    test_file = 'test_checkme.txt'
    test_file_content = 'testing checksum'


# Generated at 2022-06-23 13:56:08.433241
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('This is a test of the emergency broadcast network') == '26a167eca63cbf68cef4802f1cf92681'
    assert md5s('JKLMNOPQRSTUVWXYZ') == '5fd5fd50215b56a2e2c80fde5cde8aef'
    assert md5s('JKLMNOPQRSTUVWXYZ') != '4fd4fd50115b56a2e2c80fde5cde8aef'

# Generated at 2022-06-23 13:56:12.491334
# Unit test for function checksum_s
def test_checksum_s():
    """
    >>> secure_hash_s('hello world', sha1)
    '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    """
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 13:56:16.977074
# Unit test for function md5
def test_md5():
    """unit testing"""
    assert md5("/usr/bin/foo") != ''
    assert md5("") is None
    assert md5("/usr/bin/thisisnotarealfile") is None
    print('all tests passed')
    return True


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 13:56:26.619629
# Unit test for function checksum
def test_checksum():
    '''Test checksum function'''

    # check sum match
    data = 'hello world!'
    assert checksum_s(data) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    # check sum mismatch
    data = 'hello world???'
    assert checksum_s(data) != '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    # check sum match with python2.4
    try:
        from hashlib import sha1
    except ImportError:
        from sha import sha as sha1
    data = 'hello world!'

# Generated at 2022-06-23 13:56:35.277944
# Unit test for function checksum
def test_checksum():

    try:
        import ansible.constants as C
    except ImportError:
        # this has been moved in 2.4, fallback to the old location
        import ansible.constants as C

    try:
        from hashlib import sha1
    except ImportError:
        from sha import sha as sha1

    # reopen the file to remove any read cache
    fd = open(C.DEFAULT_LOCAL_TMP, 'rb')
    data1 = fd.read(32)
    fd.close()

    # delete the file to ensure a different result than a read cache
    os.unlink(C.DEFAULT_LOCAL_TMP)
    assert checksum(C.DEFAULT_LOCAL_TMP) is None

    # test sha1-style checksum

# Generated at 2022-06-23 13:56:39.834525
# Unit test for function md5s
def test_md5s():
    if _md5:
        if md5s('hello world') != '5eb63bbbe01eeed093cb22bb8f5acdc3':
            raise Exception("md5s() returned incorrect value")
        else:
            print("md5s() test passed")
    else:
        print("md5s() not testable due to FIPS mode")


# Generated at 2022-06-23 13:56:45.022196
# Unit test for function checksum_s
def test_checksum_s():
    print("test_checksum_s()")
    if checksum_s("pippo") == '1d22f8e71e30a025dafda9a3c3cd8ae378274c31':
        print("Ok")
    else:
        print("Error")


# Generated at 2022-06-23 13:56:53.400647
# Unit test for function md5
def test_md5():
    import crypt
    import os
    import stat

    # Create a temporary file
    test_file = "/tmp/ansible_md5_test.txt"
    with open(test_file, 'w') as f:
        f.write("foobar")

    # Get the md5 checksum of the file
    test_checksum = md5(test_file)
    assert test_checksum

    # Get the md5 checksum of the file using crypt
    with open(test_file) as f:
        assert crypt.crypt(f.read(), test_checksum) == test_checksum

    # Change the content and make sure the new checksum does not match the old one
    with open(test_file, 'w') as f:
        f.write("foo")
    assert md5(test_file) != test_checksum



# Generated at 2022-06-23 13:57:01.677543
# Unit test for function checksum_s
def test_checksum_s():
    from ansible.compat.tests import unittest
    try:
        from hashlib import md5
    except ImportError:
        from md5 import md5

    class TestUtils(unittest.TestCase):

        def test_checksum_s(self):
            for data, checksum in (
                    ('hello', '5d41402abc4b2a76b9719d911017c592'),
                    ('hello\n', '6cd3556deb0da54bca060b4c39479839'),
                    ):

                self.assertEqual(checksum_s(data), checksum)
                self.assertEqual(checksum_s(data, md5), checksum)


# Generated at 2022-06-23 13:57:06.424911
# Unit test for function md5s
def test_md5s():
    # given
    data = "abcd"

    # when
    actual = md5s(data)

    # then
    expected = "e2fc714c4727ee9395f324cd2e7f331f"
    assert expected == actual



# Generated at 2022-06-23 13:57:16.690787
# Unit test for function checksum
def test_checksum():
    import os
    import shutil
    import tempfile
    import time

    filename = None

# Generated at 2022-06-23 13:57:25.730802
# Unit test for function checksum_s
def test_checksum_s():
    # tests for ansible.utils.checksum_s
    assert checksum_s("a") == '0cc175b9c0f1b6a831c399e269772661'
    assert checksum_s("ab") == '187ef4436122d1cc2f40dc2b92f0eba0'
    assert checksum_s("abc") == '900150983cd24fb0d6963f7d28e17f72'
    # Specific test to see if checksum of 'c' is different from checksum of 'a'
    assert checksum_s("a") != checksum_s("c")
    # The following strings test all possible input characters in the range 0-255.

# Generated at 2022-06-23 13:57:30.639239
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') != 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo') != '3858f62230ac3c915f300c664312c63f'

# Generated at 2022-06-23 13:57:35.753909
# Unit test for function md5s
def test_md5s():
    assert md5s("") == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s("a") == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s("abc") == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s("message digest") == 'f96b697d7cb7938d525a2f31aaf161d0'
    assert md5s("abcdefghijklmnopqrstuvwxyz") == 'c3fcd3d76192e4007dfb496cca67e13b'

# Generated at 2022-06-23 13:57:45.636155
# Unit test for function checksum
def test_checksum():
    import sys
    sys.path.append('lib')
    import module_utils.crypto as c
    # Test checksum with a file
    test_file = 'hacking/env-setup'
    s = c.checksum(test_file)
    assert s == c.secure_hash(test_file)
    assert s == c.secure_hash(test_file, 'sha1')
    # Test checksum with a string
    test_str = "makes sense"
    s = c.checksum_s(test_str)
    assert s == c.secure_hash_s(test_str)
    assert s == c.secure_hash_s(test_str, 'sha1')

# Generated at 2022-06-23 13:57:53.493295
# Unit test for function checksum
def test_checksum():
    import tempfile, shutil, os

    dirname = tempfile.mkdtemp(prefix='ansible-checksum-test')
    fname = p = os.path.join(dirname, 'foo')

    with open(p, 'w') as f:
        f.write("hello world")

    # check file
    c = checksum(p)
    assert c == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    # check string
    c = checksum_s("hello world")
    assert c == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    shutil.rmtree(dirname)

# Generated at 2022-06-23 13:58:04.786475
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    # Test 1, known
    md5_1 = md5s("hello world")
    if md5_1 != "5eb63bbbe01eeed093cb22bb8f5acdc3":
       raise Exception("md5s() 1 failed")

    # Test 2, known
    md5_2 = md5s("Hello World")
    if md5_2 != "b10a8db164e0754105b7a99be72e3fe5":
       raise Exception("md5s() 2 failed")

    # Test 3, random
    import uuid
    md5_3 = md5s(str(uuid.uuid4()))

# Generated at 2022-06-23 13:58:16.308814
# Unit test for function checksum
def test_checksum():
    '''Tests the functionality of checksum function'''
    path_foobar = 'foobar'
    text_foo = 'foo'
    test_file = 'checksum_test'
    result_checksum_file = 'cb18ddd5a5f5c7ea5e5f86a4f4d791af1a5a5095'
    result_checksum_test = '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    test_file_content = '''\
#!/bin/bash
echo I am a test file
true
'''


# Generated at 2022-06-23 13:58:19.769545
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'd7925f341c7cda81d8f869f2eb9a54a7'
    assert md5('/bin/bash') == '050c220bbefe1dcd848ddb05e6ef490f'

# Generated at 2022-06-23 13:58:25.013363
# Unit test for function md5s
def test_md5s():
    # Note: results are from a non-FIPS system.  In FIPS mode, the results are different
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello\nworld') == 'a2ad64db3b3f7b8c9e9d7d9f1be1b732'


# Generated at 2022-06-23 13:58:36.308676
# Unit test for function checksum
def test_checksum():
    # Test for normal operation, with both a file and a string
    assert secure_hash_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert secure_hash('test/test-hash.txt') == 'd5f6e97c6b867b7a0b09e0b10a99e6bf'

    # Test the backwards compat function
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('test/test-hash.txt') == 'd5f6e97c6b867b7a0b09e0b10a99e6bf'

    # Test for the case when the file is not present
    # test that returns None

# Generated at 2022-06-23 13:58:39.448273
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'


# Generated at 2022-06-23 13:58:46.244438
# Unit test for function md5
def test_md5():
    # create a temporary file
    import tempfile
    fd, fp = tempfile.mkstemp()
    file_text = b'Hello World!\n'
    try:
        # write some line to the file
        os.write(fd, file_text)
        os.close(fd)
        assert md5(fp) == '3e25960a79dbc69b674cd4ec67a72c62'
    finally:
        os.remove(fp)


# Generated at 2022-06-23 13:58:52.616682
# Unit test for function md5
def test_md5():
    # Note: These md5s are for empty files, for python2.4 compat.
    assert md5('/etc/shadow') is None 
    assert md5('/etc/passwd') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5(__file__) == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-23 13:58:56.983989
# Unit test for function checksum
def test_checksum():
    if os.path.exists("/usr/bin/python"):
        os.path.exists("/usr/bin/pytho")
    elif os.path.exists("/usr/local/bin/python"):
        assert checksum("/usr/local/bin/python") == "d8792845a5251e5dbdd2263093fc8e5a"


# Generated at 2022-06-23 13:59:07.979337
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest

    def encrypt(input_str):
        encrypt_str = ""
        for i in range(0, len(input_str)):
            encrypt_str += chr(ord(input_str[i]) ^ ord('x'))
        return encrypt_str

    def do_test(input_str, pass_thru_str):
        # write the data to a file
        (fd, fname) = tempfile.mkstemp()
        f = os.fdopen(fd, 'w')
        f.write(input_str)
        f.close()
        # encrypt the data
        tmp = encrypt(pass_thru_str)
        # check the checksum
        cs = checksum(fname)
        # cleanup the file
        os.remove(fname)



# Generated at 2022-06-23 13:59:12.305428
# Unit test for function checksum
def test_checksum():
    test_file_path = os.path.join(os.path.dirname(__file__), 'test_files/test_file')
    checksum_value = checksum(test_file_path)
    assert checksum_value.startswith('6a4c3afb4e4caa6eef4f0527aa7')


# Generated at 2022-06-23 13:59:20.003167
# Unit test for function checksum
def test_checksum():
    data1='Hi this is test1'
    data2='Hi this is test2'
    assert checksum_s(data1) == '3db4b4aa52b4dcc9b4e4b16663e17e1396bdcb2d'
    assert checksum_s(data2) == 'd9e83c06920bbcf58fec0b68dd18e0d6cefdbfc7'
    assert checksum('./lib/ansible/module_utils/basic.py') == '417fd02b0a6bb0c6f74737a8d3ed3e2e26be633e'

# Generated at 2022-06-23 13:59:23.520647
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/passwd') == checksum('/etc/passwd')
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-23 13:59:30.404536
# Unit test for function checksum_s
def test_checksum_s():
    '''
    Function that unit tests checksum_s.
    '''

    # tests that a string returns the correct checksum
    str_test = "Hello, world."
    str_expected = '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    str_return = checksum_s(str_test)
    assert str_return == str_expected, "Expected: %s, but received: %s" % (str_expected, str_return)

    # tests that a unicode string raises an error
    unicode_test = u"This is a unicode string."
    try:
        checksum_s(unicode_test)
    except UnicodeEncodeError:
        pass

# Generated at 2022-06-23 13:59:40.457622
# Unit test for function md5
def test_md5():
    from tempfile import mkstemp
    from shutil import copyfileobj

    src_file, src_path = mkstemp()
    dst_file, dst_path = mkstemp()

    try:
        data = os.urandom(1024 * 1024)
        src_fh = os.fdopen(src_file, 'wb')
        src_fh.write(data)
        src_fh.close()

        copyfileobj(open(src_path), os.fdopen(dst_file, 'wb'), 1024 * 64)

        h1 = md5(src_path)
        h2 = md5(dst_path)
        assert h1 == h2
    finally:
        os.unlink(src_path)
        os.unlink(dst_path)

# Generated at 2022-06-23 13:59:47.103352
# Unit test for function md5s
def test_md5s():
    print('checking md5s')
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo\n') == 'c3ab8ff13720e8ad9047dd39466b3c89'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'



# Generated at 2022-06-23 13:59:49.551454
# Unit test for function md5s
def test_md5s():
    assert md5s('foobar') == '8843d7f92416211de9ebb963ff4ce28125932878'

# Generated at 2022-06-23 13:59:54.628739
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'f12d443b9a8cf7cbaab424f9c921ae5d'
    assert checksum('/bin/lsasdfasdf') == None
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-23 14:00:00.107598
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s("foobar") == "3858f62230ac3c915f300c664312c63f", "md5s method does not work as expected."
    else:
        try:
            md5s("foobar")
            assert False, "md5s method does not raise an exception when FIPS mode is enabled."
        except ValueError:
            assert True

# Generated at 2022-06-23 14:00:11.007031
# Unit test for function checksum
def test_checksum():
    test_string = "a test string"
    test_checksum = "d8e8fca2dc0f896fd7cb4cb0031ba249"
    s = checksum_s(test_string)
    if s != test_checksum:
        raise AnsibleError('test_checksum_s() failed!')
    test_file = os.path.join(os.path.dirname(__file__), 'test_checksum.tmp')
    f = open(test_file, 'wb')
    f.write(to_bytes(test_string))
    f.close()
    s = checksum(test_file)
    os.unlink(test_file)
    if s != test_checksum:
        raise AnsibleError('test_checksum() failed!')

# Generated at 2022-06-23 14:00:15.682253
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('') =='da39a3ee5e6b4b0d3255bfef95601890afd80709'
# vim: set et sw=4 ts=4 sts=4 cc=80

# Generated at 2022-06-23 14:00:27.333377
# Unit test for function md5s
def test_md5s():
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abc\n') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abc\n\n') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abc\r') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abc\r\n') == '900150983cd24fb0d6963f7d28e17f72'

# Generated at 2022-06-23 14:00:30.837892
# Unit test for function md5
def test_md5():
    # If there is an error, the following lines should raise an exception
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    md5('/etc/passwd')
    md5s('foo')

# Backwards compat
digest_s = secure_hash_s
digest = secure_hash

# Generated at 2022-06-23 14:00:34.428512
# Unit test for function md5s
def test_md5s():
    assert md5s("foobar") == "8843d7f92416211de9ebb963ff4ce28125932878"


# Generated at 2022-06-23 14:00:36.674251
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-23 14:00:41.492350
# Unit test for function md5
def test_md5():
    assert md5('/bin/cat') == '35fd8b5f480fd9e5ccc7b0e5ba8cb5a5'
    assert md5s('Cat') == '7eab5c9dcef99a07e83890deff00ccd0'

# Generated at 2022-06-23 14:00:50.673558
# Unit test for function checksum_s
def test_checksum_s():
    h1 = checksum_s('hello')
    h2 = checksum_s(b'hello')
    h3 = checksum_s('hello', hash_func=sha1)
    h4 = checksum_s(b'hello', hash_func=sha1)
    print(h1)
    print(h2)
    print(h3)
    print(h4)
    assert h1 == h2 == h3 == h4
    assert h1 == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'


# Generated at 2022-06-23 14:00:53.379691
# Unit test for function md5
def test_md5():
    md5_digest = '9a0364b9e99bb480dd25e1f0284c8555'
    if md5('/etc/passwd') == md5_digest:
        print('test for md5 ok')
    else:
        print('test for md5 failed')

# test_md5()

# Generated at 2022-06-23 14:01:03.529370
# Unit test for function md5s
def test_md5s():
    from nose.plugins.skip import SkipTest
    if not _md5:
        raise SkipTest("md5 not available (probably in FIPS mode)")
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('message digest') == 'f96b697d7cb7938d525a2f31aaf161d0'

# Generated at 2022-06-23 14:01:06.016241
# Unit test for function checksum
def test_checksum():
    assert checksum("../lib/ansible/module_utils/basic.py") == "d9b71a63c68b003716f26bdb6981b2e6c970f780"

# Generated at 2022-06-23 14:01:09.789964
# Unit test for function md5s
def test_md5s():
    ''' test_md5s '''
    data = 'hello world'
    result = md5s(data)
    assert result == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-23 14:01:17.440280
# Unit test for function md5s
def test_md5s():
    import tempfile

    (fd, fname) = tempfile.mkstemp()
    os.write(fd, b'Hello World\n')
    assert md5s("Hello World\n") == "ed076287532e86365e841e92bfc50d8c"
    assert md5(fname) == "ed076287532e86365e841e92bfc50d8c"
    os.close(fd)
    os.remove(fname)

# Generated at 2022-06-23 14:01:24.185012
# Unit test for function md5s
def test_md5s():
    ''' md5s.py: md5s test'''

    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("hello", _md5) == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("hello", sha1) == "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d"

# Generated at 2022-06-23 14:01:28.629471
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("foobar", sha1) == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert checksum_s("foobar", sha1) != '8843d7f92416211de9ebb963ff4ce28125932879'

# Generated at 2022-06-23 14:01:34.990488
# Unit test for function md5
def test_md5():
    import tempfile
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, "w")
    f.write("foo")
    f.close()
    assert os.path.exists(fname)
    assert md5(fname) == md5s("foo")
    os.remove(fname)
    assert not os.path.exists(fname)

# Generated at 2022-06-23 14:01:36.934839
# Unit test for function checksum
def test_checksum():

    filename = "test/test.txt"
    file_hash = "a1017b56e38bfc9069a2447e1da7b66c62b6433f"
    new_hash = checksum(filename)

    assert new_hash == file_hash

if __name__ == "__main__":

    test_checksum()

# Generated at 2022-06-23 14:01:39.895888
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-23 14:01:43.620898
# Unit test for function md5s
def test_md5s():
    s = 'This is a test string for md5'
    assert md5s(s) == '027be3799e4e077ef78a24cbdc110d28'


# Generated at 2022-06-23 14:01:44.752860
# Unit test for function md5s
def test_md5s():
    md5s("data")


# Generated at 2022-06-23 14:01:50.127950
# Unit test for function checksum_s
def test_checksum_s():
    expected_sha1 = 'a948904f2f0f479b8f8197694b30184b0d2ed1c1cd2a1ec0fb85d299a192a447'
    assert secure_hash_s('hello') == expected_sha1, "secure_hash_s('hello') should equal %s" % expected_sha1

# Generated at 2022-06-23 14:01:55.265810
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('Hello World') == '0a4d55a8d778e5022fab701977c5d840bbc486d0', \
        "Bad checksum from 'Hello World'"



# Generated at 2022-06-23 14:02:00.343989
# Unit test for function md5
def test_md5():
    import tempfile
    tf = tempfile.NamedTemporaryFile()
    tf.write("""
    ---
    - hosts: localhost
      tasks: []
    """)

    tf.flush()
    assert md5(tf.name) == 'f9b09d20db47ad46b6023b2f4292eaa2'

    tf.close()

# Generated at 2022-06-23 14:02:05.063719
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foobar') == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert checksum_s(u'foobar') == '8843d7f92416211de9ebb963ff4ce28125932878'


# Generated at 2022-06-23 14:02:14.752149
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    import ansible.callbacks
    ansible.callbacks.display('Testing md5s function')
    plaintext = 'this is un-encrypted text'
    digest = md5s(plaintext)
    ansible.callbacks.display('  Plaintext: "%s" => Digest: "%s" ' % (plaintext, digest))
    if digest != 'c4d0be2febd8e5873fcaa18bbcfa776d':
        raise ValueError('Digest  "%s"  does not match expected value: "c4d0be2febd8e5873fcaa18bbcfa776d"' % digest)

# Generated at 2022-06-23 14:02:17.742360
# Unit test for function checksum
def test_checksum():
    assert secure_hash_s("foo") == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    assert secure_hash("sha1.py") == "3522b0dde8c8494b88e6f0ceeb9c9ca1a2a37443"


# Generated at 2022-06-23 14:02:28.243903
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == md5s(u'hello world')

    # Ensure unicode input works.
    assert md5s(u'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    # Check for unicode error.
    assert md5s(u'') == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-23 14:02:38.393312
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(25) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(b'\x80') == 'c2d7efb6a1b6f98c434d8e6a59b43011'

# Generated at 2022-06-23 14:02:41.487003
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-23 14:02:45.373033
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'

# Generated at 2022-06-23 14:02:48.101911
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-23 14:02:57.560200
# Unit test for function md5s
def test_md5s():
    ''' md5s() returns same checksum as md5sum -b '''
    import random
    import string
    # Create test file
    chars = string.ascii_lowercase + string.ascii_uppercase + string.digits
    test_str = ''.join(random.choice(chars) for _ in range(1024))
    test_file = open('/tmp/ansiballz_test_checksum_md5s.txt', 'w')
    test_file.write(test_str)
    test_file.close()
    # Compare md5 hash
    import subprocess
    md5sum = subprocess.check_output(['md5sum', '-b', '/tmp/ansiballz_test_checksum_md5s.txt']).split(' ',1)[0]
    md5

# Generated at 2022-06-23 14:02:59.663631
# Unit test for function md5s
def test_md5s():
    # If a string is provided as input to md5s it should return the md5 sum of the string
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-23 14:03:01.680583
# Unit test for function md5s
def test_md5s():
    answer = md5s('hello')
    assert answer == '5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-23 14:03:05.982653
# Unit test for function checksum_s
def test_checksum_s():
    ''' unit test for checksum_s()'''
    checksum_data = 'test'
    assert checksum_s(checksum_data) == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

# Generated at 2022-06-23 14:03:09.355618
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert secure_hash_s('foo', hash_func=_md5) == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-23 14:03:15.879297
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("Hello World") == '0a4d55a8d778e5022fab701977c5d840bbc486d0'
    assert checksum_s("Hello World", md5) == 'ed076287532e86365e841e92bfc50d8c'
    assert checksum_s("Hello World", _md5) == 'ed076287532e86365e841e92bfc50d8c'



# Generated at 2022-06-23 14:03:24.171017
# Unit test for function checksum
def test_checksum():
    assert checksum('data/ansible/test/sanity/hacking/test-modules/stat/stat.py') == checksum('data/ansible/test/sanity/hacking/test-modules/stat/stat.py')
    assert checksum('data/ansible/test/sanity/hacking/test-modules/stat/stat.py') == '3db2e2c5ceee19c67e593f7f80a450c257dcdd9e'
    assert checksum('i-dont-exist') is None
    assert checksum('data/ansible/test/sanity/hacking/test-modules/stat') is None

# Generated at 2022-06-23 14:03:25.932378
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == "68b329da9893e34099c7d8ad5cb9c940"


# Generated at 2022-06-23 14:03:34.095134
# Unit test for function md5s
def test_md5s():
    '''Unit test for function md5s'''
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\n') == 'a591a6d40bf420404a011733cfb7b190'
    assert md5s('hello world\n\n') == 'd7b5194e6d6939fb10f2d2c262c8446d'

# Generated at 2022-06-23 14:03:38.047584
# Unit test for function checksum_s
def test_checksum_s():
    test_input = 'test'
    expected_result = 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    actual_result = checksum_s(test_input)
    assert actual_result == expected_result

# Generated at 2022-06-23 14:03:45.843983
# Unit test for function md5s
def test_md5s():
    TEST1 = 'test1'
    TEST2 = 'test2'
    ANSIBLE_TEST = 'ansible'

    assert md5s(TEST1) != md5s(TEST2)
    assert md5s(TEST1) == md5s(TEST1)
    assert md5s(TEST2) == md5s(TEST2)
    assert md5s(ANSIBLE_TEST) == '9f1b3f57d44c36b6f1b896d596652d07'


# Generated at 2022-06-23 14:03:55.516885
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, fname = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Verify the file was created
    assert os.path.exists(fname)

    # Calculate the checksum
    csum = checksum(fname)

    # Remove the file
    os.remove(fname)

    # Checksum should be none
    assert checksum(fname) is None

    # Create the file again
    fd, fname = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Verify the checksums are not equal
    assert checksum(fname) != csum

   

# Generated at 2022-06-23 14:04:00.024133
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    assert md5s(b'blah') == 'dab4a05bf3400f96b732da8f737643e1', 'Unable to generate md5s'
