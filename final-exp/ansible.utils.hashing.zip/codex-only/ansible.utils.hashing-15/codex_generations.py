

# Generated at 2022-06-23 13:54:02.240483
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    else:
        try:
            md5s('test')
            assert False
        except ValueError as e:
            assert str(e) == 'MD5 not available.  Possibly running in FIPS mode'

# Generated at 2022-06-23 13:54:13.002588
# Unit test for function checksum
def test_checksum():
    ''' test_checksum is a unit test used to validate the checksum function '''

    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_file = 'test_file'
    test_file_path = os.path.join(test_dir, test_file)
    test_file_contents = 'test'

    test_file_handle = open(test_file_path, 'a')
    test_file_handle.write(test_file_contents)
    test_file_handle.close()

    sha_checksum = checksum(test_file_path)
    md5_checksum = md5(test_file_path)


# Generated at 2022-06-23 13:54:23.181697
# Unit test for function md5s
def test_md5s():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    vault_secret = VaultSecret([])
    vault = VaultLib(vault_secret)
    s = 'bibble'
    safe_s = AnsibleUnsafeText(s)

    if not _md5:
        # Don't try to test md5 if it isn't available
        return

    # Test plain string
    assert md5s(s) == md5s(safe_s)

    # Test encrypted string
    encrypted_data = vault.encrypt(s)
    assert md5s(encrypted_data) == md5s(vault.encrypt(safe_s))


# Generated at 2022-06-23 13:54:26.548336
# Unit test for function md5s
def test_md5s():
    import nose
    assert nose.tools.eq(md5s('hello'), '5d41402abc4b2a76b9719d911017c592')


# Generated at 2022-06-23 13:54:36.572453
# Unit test for function md5
def test_md5():
    from tempfile import NamedTemporaryFile
    from shutil import copy
    from stat import S_IMODE
    from os import chmod, unlink

    for perm in [S_IMODE(0o400), S_IMODE(0o444), S_IMODE(0o600), S_IMODE(0o644), S_IMODE(0o666), S_IMODE(0o700)]:
        with NamedTemporaryFile(delete=False) as src:
            with NamedTemporaryFile(mode='wb', delete=False) as dst:
                content = b'foobar'
                src.write(content)
                # Creating a copy of src with a different name, so that md5 of the two files
                # is the same (src and dst point to two different inode numbers)
                copy(src.name, dst.name)


# Generated at 2022-06-23 13:54:47.315302
# Unit test for function checksum_s
def test_checksum_s():

    # Test string
    S1 = b"hello world"
    S2 = u"hello world"
    S3 = "hello world"
    S4 = b"hello world"

    # Test sha1
    assert(checksum_s(S1) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed')
    assert(checksum_s(S2, sha1) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed')
    assert(checksum_s(S3, sha1) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed')

# Generated at 2022-06-23 13:54:54.256217
# Unit test for function checksum_s
def test_checksum_s():
    # Test sha1
    assert secure_hash_s('Hi, how are you?') == '0f81c717d0425b0c9b56355a4dd4f4a277414e2c'
    # Test md5
    assert md5s('Hi, how are you?') == '7fe10d0c0e09e50f55c0be727769ebd9'


# Generated at 2022-06-23 13:54:56.989843
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-23 13:55:06.351190
# Unit test for function checksum
def test_checksum():
    import os
    import sys
    import tempfile
    from ansible.utils.path import unfrackpath

    tempdir = tempfile.mkdtemp()
    test_file = unfrackpath(os.path.join(tempdir, 'test'))

    with open(to_bytes(test_file, errors='surrogate_or_strict'), 'wb') as f:
        f.write(b"This is the test string, I hope it works\n")

    if sys.version_info < (2, 5):
        import sha
        sha_correct_checksum = sha.new(b"This is the test string, I hope it works\n").hexdigest()
        sha_correct_checksum_txt = sha_correct_checksum
    else:
        import hashlib
        sha_correct_

# Generated at 2022-06-23 13:55:11.351151
# Unit test for function checksum_s
def test_checksum_s():
    '''
    test_checksum_s: single element sha1 checksum test
    '''
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'


# Generated at 2022-06-23 13:55:14.764272
# Unit test for function md5
def test_md5():
    assert(md5("/etc/passwd") == "1d89df32ad847b80c01e7a08b42e6fa1")



# Generated at 2022-06-23 13:55:17.868384
# Unit test for function md5s
def test_md5s():
    ''' md5 should produce expected output. '''
    assert(md5s('test') == b'098f6bcd4621d373cade4e832627b4f6')


# Generated at 2022-06-23 13:55:21.136910
# Unit test for function checksum_s
def test_checksum_s():
    # Note checksum_s is built on top of secure_hash_s
    data = 'hello world'
    assert checksum_s(data) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'



# Generated at 2022-06-23 13:55:33.143450
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s(u'foobar') == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert checksum_s('foobar') == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert checksum_s(u'\u043c\u0430\u0440\u0446\u0430') == '4c4b63a3f541f16870bd5e5ad5f5c21418c5d1ae'

# Generated at 2022-06-23 13:55:37.574002
# Unit test for function checksum_s
def test_checksum_s():
    s = "hello"
    assert checksum_s(s) == "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d"
    assert checksum_s(s, hash_func=_md5) == "5d41402abc4b2a76b9719d911017c592"


# Generated at 2022-06-23 13:55:41.356601
# Unit test for function md5s
def test_md5s():
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'


# Generated at 2022-06-23 13:55:44.296814
# Unit test for function md5s
def test_md5s():
    assert md5s("foobar") == "8843d7f92416211de9ebb963ff4ce28125932878"

# Generated at 2022-06-23 13:55:46.136523
# Unit test for function md5
def test_md5():
    """Unit test function md5"""
    assert md5('/etc/passwd') == '6b1740c2addc6f9beaeb22b6f93cf8eb'


# Generated at 2022-06-23 13:55:53.194304
# Unit test for function md5
def test_md5():
    '''
    [test_template_legacy_md5.py]
    # using legacy md5 module
    file=file.txt
    state=file
    checksum=c2cfd6efd0c8f9a55a7d36e0e3842c23
    '''
    import sys
    import json

    args = json.load(sys.stdin)
    ret = {}
    if args['state'] == 'file':
        ret['msg'] = md5(to_bytes(args['file']))
    else:
        ret['msg'] = "Unknown state: %s" % args['state']
    print(json.dumps(ret))



# Generated at 2022-06-23 13:55:55.215108
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-23 13:55:57.709261
# Unit test for function checksum
def test_checksum():
    data = "hello world"
    expected = "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"
    retval = checksum_s(data)
    assert retval == expected

# Generated at 2022-06-23 13:55:59.888535
# Unit test for function md5s
def test_md5s():
    a = md5s('foo')
    assert a == 'acbd18db4cc2f85cedef654fccc4a4d8'

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-23 13:56:01.572828
# Unit test for function md5
def test_md5():
    a = md5("test/utils/test.py")
    b = md5("test/utils/__init__.py")
    assert a != b

# Generated at 2022-06-23 13:56:11.953488
# Unit test for function checksum
def test_checksum():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(default='%s/lib/ansible/module_utils/hashlib.py' % os.path.dirname(__file__), type='path'),
            method=dict(default='sha1', choices=['sha1', 'md5'])
        )
    )
    path = module.params['path']
    method = module.params['method']
    if method == 'sha1':
        checksummed = checksum(path)
    elif method == 'md5':
        checksummed = md5(path)

    # python3 on osx does not follow the same checksum algorithm.

# Generated at 2022-06-23 13:56:15.665327
# Unit test for function md5s
def test_md5s():
    data = "Hello World"
    md5s = "ed076287532e86365e841e92bfc50d8c"
    assert_equal(ansible_hash.md5s(data), md5s)


# Generated at 2022-06-23 13:56:22.291321
# Unit test for function md5
def test_md5():
    ''' test md5 '''
    path = os.path.join(os.path.dirname(__file__), 'securehash.py')
    if not os.path.exists(path):
        path = 'lib/ansible/module_utils/securehash.py'
    if not os.path.exists(path):
        path = 'module_utils/securehash.py'
    if not os.path.exists(path):
        return False

    assert md5(path) == '40bca19c761c0fafecbf87031c9475d8'


# Generated at 2022-06-23 13:56:27.833903
# Unit test for function md5s
def test_md5s():
    md5_test_data = md5s("test")
    if not md5_test_data == "098f6bcd4621d373cade4e832627b4f6":
        raise Exception("md5s failed unit test")


# Generated at 2022-06-23 13:56:33.436617
# Unit test for function md5s
def test_md5s():
    # Test with byte string
    byte_string = b'Hello world'
    result = md5s(byte_string)
    assert result == 'ed076287532e86365e841e92bfc50d8c'

    # Test with text string
    text_string = 'Hello world'
    result = md5s(text_string)
    assert result == 'ed076287532e86365e841e92bfc50d8c'

# Generated at 2022-06-23 13:56:37.041846
# Unit test for function md5s
def test_md5s():
    data = 'test string'
    h1 = md5s(data)
    h2 = md5s(data)
    assert(h1 == h2)


# Generated at 2022-06-23 13:56:43.003461
# Unit test for function checksum
def test_checksum():

    # function checksum creates a sha256 digest of the file
    assert checksum('lib/ansible/module_utils/network/common/utils.py') == 'a11a19a9d2bb205b0738f085c117a3dcb3e3b1dda80bc5f5b5e59a5a5a27a8ec'



# Generated at 2022-06-23 13:56:46.346189
# Unit test for function md5
def test_md5():
    assert md5(__file__) == 'bb97b6fec5bc5e38fb5b5d5f5cc5b0da'

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 13:56:58.300342
# Unit test for function checksum_s
def test_checksum_s():
    import sys
    import os
    import glob
    import subprocess
    import traceback

    def find_tests():
        tests = []
        expected_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        expected_dir = os.path.join(expected_dir, 'lib/ansible/roles/test_collections/collection_name/tests/integration/targets/test-checksum/expected_output.txt')

        with open(expected_dir, 'rt') as f:
            for line in f.readlines():
                line = line.strip()
                if line and not line.startswith('#'):
                    tests.append(line)

        return tests

    def compute_checksum(data):
        has

# Generated at 2022-06-23 13:57:02.693153
# Unit test for function md5
def test_md5():
    # Assume this file was not touched in last few seconds
    assert md5(__file__) == '4cff6d4b634c4da8c608dac7fdc27e00'

try:
    from ansible.module_utils.six.moves.urllib.parse import quote as urllib_quote
except ImportError:
    from urllib import quote as urllib_quote

# Unit test

# Generated at 2022-06-23 13:57:12.761816
# Unit test for function checksum_s
def test_checksum_s():
    print("Testing checksum_s")
    test = checksum_s("test")
    print("Test 1: The returned value should be:")
    print("9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08")
    print("Returned: ", test)
    if test == "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08":
        print("Test 1 Pass")
    else:
        print("Test 1 Fail")


# Generated at 2022-06-23 13:57:16.605562
# Unit test for function checksum_s
def test_checksum_s():
    h = '86d811de2ad3bb3ecba1fe02277928a8af89671f'
    assert checksum_s('my string') == h


# Generated at 2022-06-23 13:57:22.738429
# Unit test for function md5s
def test_md5s():
    import tempfile
    # Generate file
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(b'123')
        fname = f.name
        f.close()
    # Generate md5sum
    with open(fname, 'rb') as f:
        actual = md5(f.name)
    # Remove file
    os.remove(fname)
    # Test
    assert actual == '202cb962ac59075b964b07152d234b70'


# Generated at 2022-06-23 13:57:28.142872
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s(u'hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'


if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-23 13:57:32.903296
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foobar') == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert checksum_s(b'foobar') == '8843d7f92416211de9ebb963ff4ce28125932878'



# Generated at 2022-06-23 13:57:36.560206
# Unit test for function checksum
def test_checksum():
    """
    tests the checksum function
    """

    if checksum('/bin/ls') == "77ca1147fdbc813885575b87cad07ae7a54a52c8":
        return True

    print("expected 77ca1147fdbc813885575b87cad07ae7a54a52c8 got %s " % checksum('/bin/ls'))
    return False


# Generated at 2022-06-23 13:57:47.067209
# Unit test for function checksum_s
def test_checksum_s():
    result = checksum_s(None)
    assert result == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    result = checksum_s('')
    assert result == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    result = checksum_s(' ')
    assert result == 'b858cb282617fb0956d960215c8e84d1ccf909c6'
    result = checksum_s('Hello')
    assert result == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'
    result = checksum_s('Hello', hash_func=md5)

# Generated at 2022-06-23 13:57:51.672522
# Unit test for function md5s
def test_md5s():
    if not _md5:
        print("MD5 not available.  Possibly running in FIPS mode")
        return
    s = "hello world"
    assert md5s(s) == "5eb63bbbe01eeed093cb22bb8f5acdc3"


# Generated at 2022-06-23 13:57:57.871164
# Unit test for function checksum
def test_checksum():
    def _test_checksum(filename, expected_result):
        result = checksum(filename)
        if result == expected_result:
            print('checksum({}) = {}'.format(filename, result))
        else:
            print('checksum({}) != {}!'.format(filename, expected_result))

    _test_checksum('test/ansible/modules/system/ping.py', '5c5e541c1f6d336b7e869817ee1e7b807d70bae5')
    _test_checksum('test/ansible/modules/system/ping.pyc', '6d2e6e3d50677fa9f8b24e072dcae3dab0b28e0e')

# Generated at 2022-06-23 13:58:04.420743
# Unit test for function md5
def test_md5():
    """This should probably be a doctest, but I am not sure how/where to do that...
    This test will succeed if ansible can find the "openssl" command, and will fail
    on systems with FIPS mode enabled.
    """
    try:
        md5s('hi there')
        md5('/bin/ls')  # This should succeed if /bin/ls exists
    except ValueError:
        print('Skipping md5 checks.  Possibly running in FIPS mode')

# Generated at 2022-06-23 13:58:09.076035
# Unit test for function checksum
def test_checksum():
    assert checksum_s("hello") == "5d41402abc4b2a76b9719d911017c592"


if __name__ == '__main__':
    print("Sample SHA1 python digest: %s" % secure_hash_s("This is a test"))

# Generated at 2022-06-23 13:58:10.908304
# Unit test for function md5
def test_md5():
    try:
        assert md5s('foobar') == '3858f62230ac3c915f300c664312c63f'
    except ValueError as e:
        return False
    return True


# Generated at 2022-06-23 13:58:16.751315
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(b'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(u'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-23 13:58:20.145321
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode or Python2.4')
    ret = md5s("Hello World")
    assert ret == 'b10a8db164e0754105b7a99be72e3fe5', ret

# Generated at 2022-06-23 13:58:32.758191
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("foo") == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    assert checksum_s("foo\n") == "acbd18db4cc2f85cedef654fccc4a4d8"
    assert checksum_s("foo\n", "sha256") == "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae"
    assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"
    assert md5s("foo\n") == "acbd18db4cc2f85cedef654fccc4a4d8"

# Generated at 2022-06-23 13:58:41.394711
# Unit test for function checksum
def test_checksum():
    """
    Test checksum

    Tests the function that generates a checksum
    """

    filename = os.path.join(os.path.dirname(__file__), 'checksumtestfile.txt')
    # Test file is created with this checksum.  This is md5, not sha1
    checksum_value = '87909bdb32b2e1cfe0856d8fde1e0a7f'

    # Create test file
    with open(filename, 'w') as fd:
        fd.write('testdata')

    # Verify result
    result = checksum(filename)
    if result != checksum_value:
        raise Exception("test_checksum failed. checksumtestfile.txt checksum should be %s but is %s" % (checksum_value, result))

    # Clean

# Generated at 2022-06-23 13:58:46.979488
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'
    assert md5s('baz') == '98c6e5ccb0138bec858a98bb8d820365'


# Generated at 2022-06-23 13:58:49.661026
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == "5eb63bbbe01eeed093cb22bb8f5acdc3"


# Generated at 2022-06-23 13:58:52.084447
# Unit test for function md5s
def test_md5s():
    mymd5 = _md5()
    mymd5.update('a')
    assert md5s('a') == mymd5.hexdigest()

# Generated at 2022-06-23 13:58:56.072642
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    md5_file = md5('/bin/chmod')
    assert md5_file == '6e17d2ab2aa4185a7b4eae5a5b5d5f5b'

# Generated at 2022-06-23 13:59:01.626382
# Unit test for function checksum_s
def test_checksum_s():
    # Tests using sha1
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 13:59:06.537146
# Unit test for function checksum_s
def test_checksum_s():
    import unittest
    class TestChecksumS(unittest.TestCase):
        def test_checksum_s(self):
            self.assertEqual(checksum_s('data'), '3c9b3edb5cda7f4f4a70ecd3a16e07d8b17a0cd4')
    unittest.main()

# Generated at 2022-06-23 13:59:09.216213
# Unit test for function md5s
def test_md5s():
    test_str = "The quick brown fox jumps over the lazy dog"
    assert md5s(test_str) == "9e107d9d372bb6826bd81d3542a419d6"



# Generated at 2022-06-23 13:59:13.745176
# Unit test for function md5s
def test_md5s():
    if md5s('foo') != 'acbd18db4cc2f85cedef654fccc4a4d8':
        raise AssertionError('md5s() failed')

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-23 13:59:22.994875
# Unit test for function md5
def test_md5():
    ''' unit test for md5 '''

    test_path = os.path.join('test', 'test_utils')
    test_file = 'test_file.txt'
    test_string = 'testString'
    test_hash = '34b038be6f5a6e2abe6e8dc1f5a6d7c0'

    subdir_path = os.path.join('test', 'test_utils', 'subdir')
    subdir_file = 'subdir_file.txt'
    subdir_hash = '7927f4fc8c0bf3ce3c7b41fb9b914e85'

    assert md5(test_file) == test_hash
    assert md5s(test_string) == test_hash

# Generated at 2022-06-23 13:59:26.578144
# Unit test for function md5
def test_md5():
    return
    data = "foo"
    h1 = _md5()
    h1.update(data)
    assert md5s(data) == h1.hexdigest()

# Generated at 2022-06-23 13:59:28.456583
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-23 13:59:37.928797
# Unit test for function checksum
def test_checksum():

    test_string_1 = "foobar"
    test_string_2 = "barfoo"

    assert checksum_s(test_string_1) == "8843d7f92416211de9ebb963ff4ce28125932878"
    assert checksum_s(test_string_1) != checksum_s(test_string_2)

    #
    # Try checksum with Python 2.4 with md5 disabled
    #

# Generated at 2022-06-23 13:59:43.596097
# Unit test for function checksum
def test_checksum():
    # The test file is copied from file module, also the checksum result must be the same as the result in file module
    filename = '../../lib/ansible/module_utils/basic.py'
    assert checksum(filename) == '1bd37da08d57b66c537037321f5f501e35b42141'

# Generated at 2022-06-23 13:59:47.901699
# Unit test for function md5
def test_md5():
    assert md5(__file__) == '2e7c3b4fd042b4d8e4b9d955f0a6c7d8'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'

# Generated at 2022-06-23 13:59:53.524641
# Unit test for function md5s
def test_md5s():
    from ansible.module_utils.six import PY3
    if PY3:
        assert md5s('test_md5s') == '2a2fa811fae8364e17d6416b3c3b816d'
    else:
        assert md5s(u'test_md5s') == '2a2fa811fae8364e17d6416b3c3b816d'

# Generated at 2022-06-23 14:00:02.561437
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('somebytes') == 'f1358c6f8baa11c36b50ffda1b067a4a'
    assert md5s('some more bytes') == '6f8baa11c36b50ffda1b067a4a81358c'
    assert md5s('yet another') == '6caf101e7a122a1dceb8a5b07c20b7b5'
    assert md5s('\x00\x00\x00one\x00\x00\x00') == 'd92b936dbb8cf8e498e3b7e88bbd3875'

# Generated at 2022-06-23 14:00:10.009382
# Unit test for function md5s
def test_md5s():

    ret = md5s(
        to_bytes('some_binary_data', errors='strict')
    )
    assert ret == 'c35f9d9b43fa63c03fa6f96c0e133d0c'

    ret = md5s(
        to_bytes('some_text_data', errors='strict')
    )
    assert ret == '44fdf6b35e6aa9cb967b5e4a26f4e4c5'


# Generated at 2022-06-23 14:00:12.795627
# Unit test for function checksum_s
def test_checksum_s():
    if (checksum_s("test") != 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'):
        raise Exception("Failed to generate correct checksum_s for test")


# Generated at 2022-06-23 14:00:26.093853
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '4c8e0d76f5d3665a4e133c6f7ab1ddad46f8d318'
    assert checksum('/bin/ls') != '4c8e0d76f5d3665a4e133c6f7ab1ddad46f8d317'
    assert checksum('/bin/ls') == '4c8e0d76f5d3665a4e133c6f7ab1ddad46f8d318'
    assert checksum('/bin/ls') != '4c8e0d76f5d3665a4e133c6f7ab1ddad46f8d317'

# Generated at 2022-06-23 14:00:29.396829
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s("hi") == "49f68a5c8493ec2c0bf489821c21fc3b"


# Generated at 2022-06-23 14:00:36.674774
# Unit test for function md5
def test_md5():
    if _md5:
        assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
        assert md5('/etc/hosts') == '4f352e4a4d834f9d5bcd82b3a65a3d60'

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 14:00:41.493574
# Unit test for function md5
def test_md5():
    '''
    hash: test_md5
    [INFO]: computing checksum on /etc/hosts
    '''
    filename = "/etc/hosts"
    return {'changed': False, 'msg': "computing checksum on %s" % filename, 'checksum': md5(filename)}

# Generated at 2022-06-23 14:00:44.292591
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Used by the file function

# Generated at 2022-06-23 14:00:48.510292
# Unit test for function md5s
def test_md5s():
    # checking valid md5sum
    assert md5s("foobar") == "8843d7f92416211de9ebb963ff4ce28125932878"



# Generated at 2022-06-23 14:00:58.382321
# Unit test for function checksum_s
def test_checksum_s():
    from ansible.compat.tests import unittest

    class TestChecksumS(unittest.TestCase):
        def setUp(self):
            self.test_data = 'hello world'

        def test_checksum_s(self):
            actual = checksum_s(self.test_data)
            expected = '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
            self.assertEqual(actual, expected, msg='Returned hash does not match with the known-good hash value')

    def suite():
        suite = unittest.TestSuite()
        suite.addTest(unittest.makeSuite(TestChecksumS))
        return suite

    unittest.TextTestRunner(verbosity=2).run(suite())




# Generated at 2022-06-23 14:01:04.263417
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('dummy') == '0405a94764f5f87d51a1a5e450c5f5e4a4a1337d'
    assert checksum_s([b'dummy']) == '0405a94764f5f87d51a1a5e450c5f5e4a4a1337d'
    assert checksum_s({b'dummy': [b'dummy']}) == '0405a94764f5f87d51a1a5e450c5f5e4a4a1337d'

# Generated at 2022-06-23 14:01:08.522856
# Unit test for function md5s
def test_md5s():
    # Run MD5 checksum test
    test_data = "this is a test"
    md5_sum = md5s(test_data)
    correct_md5_sum = "df83e2c2f5aff5ca5e5d83e08c1a93b8"
    if md5_sum == correct_md5_sum:
        print("MD5 checksum test passed.")
    else:
        print("MD5 checksum test failed.")


# Generated at 2022-06-23 14:01:20.816206
# Unit test for function md5
def test_md5():
    ''' test the md5 function '''

    from ansible.module_utils._text import to_bytes

    md5_of_hello_world = 'fc3ff98e8c6a0d3087d515c0473f8677'
    if md5s_text != md5_of_hello_world:
        raise AssertionError("%s != %s" % (md5s_text, md5_of_hello_world))

    md5s_text = md5s(to_bytes('hello world'))
    if md5s_text != md5_of_hello_world:
        raise AssertionError("%s != %s" % (md5s_text, md5_of_hello_world))


# Generated at 2022-06-23 14:01:24.257665
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return
    assert md5s('a') == md5s('b'), "md5s does not work correctly."
    assert md5s('a') != md5s('aa'), "md5s does not work correctly."
    assert md5s('Hello World!') == '86fb269d190d2c85f6e0468ceca42a20', "md5s does not work correctly."



# Generated at 2022-06-23 14:01:27.073310
# Unit test for function checksum_s
def test_checksum_s():
  str = "abc"
  assert secure_hash_s(str) == "a9993e364706816aba3e25717850c26c9cd0d89d"


# Generated at 2022-06-23 14:01:28.702716
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-23 14:01:38.984983
# Unit test for function checksum_s
def test_checksum_s():
    "Unit test for function checksum_s"

    data = ''
    expected = 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    result = checksum_s(data)
    assert result == expected, "Expected %s, got %s" % (expected, result)

    data = 'The quick brown fox jumps over the lazy dog'
    expected = '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12'
    result = checksum_s(data)
    assert result == expected, "Expected %s, got %s" % (expected, result)


# Generated at 2022-06-23 14:01:50.631205
# Unit test for function md5s
def test_md5s():
    # Test with valid MD5 sums
    assert md5s('hi') == '49f68a5c8493ec2c0bf489821c21fc3b'
    assert md5s('hi'*10) == 'd42e7a356b78c35b7a2eee545f6b4dcf'
    assert md5s('bye') == '1d74fd1a261f7c0fc0fefb05dae8c836'
    assert md5s('bye'*10) == 'fa270797fa429768edc9d2ba509b846e'
    assert md5s('123456789ABCDE') == '93b885adfe0da089cdf634904fd59f71'

# Generated at 2022-06-23 14:01:59.640889
# Unit test for function checksum
def test_checksum():
    if checksum('/etc/hosts') is not None:
        assert checksum('/etc/hosts') == '3a6dcd24c8d844c1ee45bd6095fea06d'
    assert checksum('/etc/hosts.new') is None
    assert checksum('/etc') is None
    assert checksum_s('Hello') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'


# Generated at 2022-06-23 14:02:06.970525
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == '711f1c2ef6b93de0babeb0d22bfc40aee75f0f30'
    assert checksum("/bin/ls", sha1) == '711f1c2ef6b93de0babeb0d22bfc40aee75f0f30'
    assert checksum("/bin/ls", hashlib.sha1) == '711f1c2ef6b93de0babeb0d22bfc40aee75f0f30'


# Generated at 2022-06-23 14:02:08.897860
# Unit test for function md5
def test_md5():
    if _md5:
        print("MD5 not available.  Possibly running in FIPS mode")
        return False
    return True

# Generated at 2022-06-23 14:02:13.917329
# Unit test for function checksum
def test_checksum():
    data = "foobar"
    assert checksum_s(data) == sha1(data).hexdigest()
    assert checksum_s(data) == checksum_s(data)
    assert checksum_s(data) != "FFFFFFFFFFFFFFFFFFFFFFFFFFFF"



# Generated at 2022-06-23 14:02:16.608444
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("abc\n") == "a9993e364706816aba3e25717850c26c9cd0d89d"

# Generated at 2022-06-23 14:02:24.022968
# Unit test for function checksum
def test_checksum():
    import shutil
    import tempfile
    import unittest

    class TestChecksum(unittest.TestCase):
        def setUp(self):
            self.dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.dir, True)

        def test_checksum(self):
            filename = os.path.join(self.dir, 'sha')
            file = open(filename, 'w')
            file.write('sha')
            file.close()
            self.assertEqual(checksum(filename), '098f6bcd4621d373cade4e832627b4f6')
            self.assertEqual(checksum_s('sha'), '098f6bcd4621d373cade4e832627b4f6')



# Generated at 2022-06-23 14:02:29.736760
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_s('bar') == '62cdb7020ff920e5aa642c3d4066950dd1f01f4d'


# Generated at 2022-06-23 14:02:31.623477
# Unit test for function checksum_s
def test_checksum_s():
    md51 = secure_hash_s('hello world')
    assert md51 == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-23 14:02:40.691635
# Unit test for function md5
def test_md5():
    # Test that correct change to the file results in different md5.
    path = '/tmp/ansible_test_file.md5'
    content = 'Original Content'
    with open(path, 'w') as f:
        f.write(content)
    old_md5 = md5(path)
    content = 'New Content'
    with open(path, 'w') as f:
        f.write(content)
    new_md5 = md5(path)
    assert old_md5 != new_md5
    # Test that we get None for non-existent file.
    assert md5('/tmp/non-existent') is None



# Generated at 2022-06-23 14:02:46.270785
# Unit test for function checksum
def test_checksum():
    assert checksum('test_utils.py', sha1) == "f29c63bdf49a44dec17a0d1c7e8a3dc3b9c1ab76"
    assert checksum(to_bytes('test_utils.py', errors='surrogate_or_strict'), sha1) == "f29c63bdf49a44dec17a0d1c7e8a3dc3b9c1ab76"


# Generated at 2022-06-23 14:02:50.798717
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-23 14:03:02.616726
# Unit test for function md5
def test_md5():
    ''' md5 '''

    import shutil
    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        if os.path.exists(f.name) or os.path.isdir(f.name):
            raise AssertionError("tempfile should not exist")
        if md5(f.name):
            raise AssertionError("md5 should return None on non-existent file")
        f.write(b'foo')
        f.flush()
        h = md5(f.name)
        if not h:
            raise AssertionError("md5 should not return None")
        f.seek(0)
        f.write(b'bar')
        f.flush()
        nh = md5(f.name)
        if not nh:
            raise AssertionError

# Generated at 2022-06-23 14:03:05.462997
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s(b"foo") == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-23 14:03:12.860757
# Unit test for function md5s
def test_md5s():
    assert(md5s(b'chris') == '56d70a8f3e2046f61ac52c7e64cb9d77')
    assert(md5s('chris') == '56d70a8f3e2046f61ac52c7e64cb9d77')
    assert(md5s(b'Chris') == '78981d43a922d5ad5a30b5a5f5dd8e8d')
    assert(md5s('Chris') == '78981d43a922d5ad5a30b5a5f5dd8e8d')
    assert(md5s(u'Chris') == '78981d43a922d5ad5a30b5a5f5dd8e8d')

# Generated at 2022-06-23 14:03:22.776386
# Unit test for function checksum
def test_checksum():
    test_string = 'Hello Ansible'
    # Calculate expected checksum
    s = sha1()
    s.update(test_string)
    expected = s.hexdigest()

    # Calculate checksum by passing string
    result = checksum_s(test_string)
    assert result == expected

    # Calculate checksum by passing file handle
    import tempfile
    fd, filename = tempfile.mkstemp()
    f = open(filename, 'w')
    f.write(test_string)
    f.close()
    result = checksum(filename)
    os.unlink(filename)
    assert result == expected


# Generated at 2022-06-23 14:03:32.149396
# Unit test for function checksum
def test_checksum():
    checksum_test = checksum('lib/ansible/module_utils/basic.py')
    assert isinstance(checksum_test, str), \
        "TypeError: the type of checksum() should be str"

    checksum_test = checksum('lib/ansible/module_utils/basic.py', sha1)
    assert isinstance(checksum_test, str), \
        "TypeError: the type of checksum() should be str"

    checksum_test = checksum(u'lib/ansible/module_utils/basic.py', sha1)
    assert isinstance(checksum_test, str), \
        "TypeError: the type of checksum() should be str"


# Generated at 2022-06-23 14:03:43.838818
# Unit test for function checksum_s
def test_checksum_s():

    data_str  = 'foo'
    data_str2 = 'bar'
    data_dict = {'foo':'bar'}
    data_int  = 1

    data_str_hex  = 'acbd18db4cc2f85cedef654fccc4a4d8'
    data_str2_hex = '37b51d194a7513e45b56f6524f2d51f2'
    data_dict_hex = '0cbc6611f5540bd0809a388dc95a615b'
    data_int_hex  = '356a192b7913b04c54574d18c28d46e6'

    assert checksum_s(data_str)  == data_str_hex
    assert checksum_s(data_str2) == data_str2

# Generated at 2022-06-23 14:03:49.387448
# Unit test for function md5
def test_md5():
    filename = 'test_md5.txt'
    text = 'This is a test'
    testfile = open(filename, 'w')
    testfile.write(text)
    testfile.close()
    assert md5(filename) == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-23 14:03:50.395156
# Unit test for function md5s
def test_md5s():
    md5s('hello')


# Generated at 2022-06-23 14:03:55.836342
# Unit test for function checksum
def test_checksum():
    import tempfile
    (fd, fname) = tempfile.mkstemp()
    fh = open(fname, 'w')
    fh.write('abcdefgh')
    fh.close()
    out = checksum(fname,sha1)
    os.unlink(fname)
    assert out == 'fa73b00d38b29cac1a6f8a6c359d6b2d65d6453e'


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 14:04:00.021735
# Unit test for function checksum
def test_checksum():
    filename = os.path.join(os.path.dirname(__file__), "test_utils.py")
    assert checksum(filename) == "405fceb6f3562b275bb84baaef9a8c0bfde915a6"