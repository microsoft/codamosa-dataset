

# Generated at 2022-06-23 13:54:03.290204
# Unit test for function md5
def test_md5():
    if not _md5:
        return
    import shutil
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    try:
        os.chdir(tmpdir)
        f = open('foo', 'w')
        f.write('FOO!')
        f.close()
        assert md5('foo') == md5s('FOO!')
    finally:
        os.chdir(curdir)
        shutil.rmtree(tmpdir)

# Generated at 2022-06-23 13:54:13.346424
# Unit test for function md5s
def test_md5s():
    from ansible.compat.tests.mock import patch

    # md5 is not available in FIPS mode
    with patch('ansible.module_utils.crypto.hashlib.md5', new=None):
        try:
            md5s('test')
        except ValueError as e:
            assert str(e) == 'MD5 not available.  Possibly running in FIPS mode'
        else:
            assert False, 'md5s did not raise an exception'

    # md5 is available
    with patch('ansible.module_utils.crypto.hashlib.md5', new=_md5):
        assert md5s('test') == _md5('test'.encode('utf-8')).hexdigest()



# Generated at 2022-06-23 13:54:20.246141
# Unit test for function md5
def test_md5():
    dir = os.path.dirname(__file__)
    md5file = os.path.join(dir,'md5_test.txt')
    assert checksum(md5file) == '4c8f4a4277d4c2a0a4a82e8e3f9e80c1d11de9c6'
    assert md5(md5file) == '4c8f4a4277d4c2a0a4a82e8e3f9e80c1d'

# Generated at 2022-06-23 13:54:28.235600
# Unit test for function md5s
def test_md5s():
    ''' test md5s function '''

    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    # Test for correct hash with multiple strings
    assert md5s('abc123') == '699069c9efdf15416895046b5e7c5665'
    assert md5s('XYZ789') == 'b544a8f7a78e11e52ae7657c28f6b0d7'
    assert md5s('ABC123xyzXYZ789') == 'd6df0cc6e0e6dd122c7ebed56ae1fe87'

    # Test for correct hash with a number
    assert md5s(123) == '202cb962ac59075b964b07152d234b70'

    # Test for

# Generated at 2022-06-23 13:54:33.227553
# Unit test for function checksum_s
def test_checksum_s():
    '''Returns True when the md5s of a string matches the md5s of the same string'''
    assert checksum_s(b"abcd") == "e2fc714c4727ee9395f324cd2e7f331f"
    assert md5s(b"abcd") == "e2fc714c4727ee9395f324cd2e7f331f"

# Generated at 2022-06-23 13:54:42.055535
# Unit test for function checksum
def test_checksum():

    test_file_name = '/usr/share/dict/words'


# Generated at 2022-06-23 13:54:47.777212
# Unit test for function md5
def test_md5():
    test_path = os.path.join(os.path.dirname(__file__), '../../test/utils/test_md5')
    assert md5(test_path) == 'a0f2c0b53a77c8f1d401da9cedf9f99a'
    assert md5(test_path + '_nonexist') == None
    assert md5s('test_string') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-23 13:54:56.701098
# Unit test for function md5s
def test_md5s():
    import sys
    if sys.version_info < (2, 7) and not os.getenv('ANSIBLE_TEST_MD5'):
        return
    if sys.version_info < (2, 7) and os.getenv('ANSIBLE_TEST_MD5'):
        import warnings
        warnings.warn("Ansible is running in FIPS mode, test may fail.")
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\xc3\xa0') == 'b7ce20406a2da8d7d9f0b0a05b78fbfc'


# Generated at 2022-06-23 13:55:01.166092
# Unit test for function checksum_s
def test_checksum_s():

    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(u'hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-23 13:55:07.173906
# Unit test for function md5
def test_md5():
    import tempfile
    (fd, fname) = tempfile.mkstemp()
    try:
        os.write(fd, b'Hello World')
        os.close(fd)
        ret = md5(fname)
    finally:
        os.unlink(fname)
    # b46cf58a8e8c4d2f77a9c52a78ef4b4e
    assert ret == 'b46cf58a8e8c4d2f77a9c52a78ef4b4e'



# Generated at 2022-06-23 13:55:13.613959
# Unit test for function checksum
def test_checksum():
    assert checksum("../test/test_module.py") == "e220e8c8a7bae27d0bc0e3b8f13c0d9f3355cfdf", checksum("../test/test_module.py")
    assert checksum("doesntexist") is None, checksum("doesntexist")



# Generated at 2022-06-23 13:55:16.390705
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('Hello World') == 'b10a8db164e0754105b7a99be72e3fe5'

# Generated at 2022-06-23 13:55:19.316919
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', 'sha1 of "test" does not match'


# Generated at 2022-06-23 13:55:31.518627
# Unit test for function checksum
def test_checksum():
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary test file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)

    # Write a test string to the file
    data = "Hello World"
    a = os.write(fd, to_bytes(data, errors='strict'))
    os.close(fd)

    # Check the file for the test string
    f = open(tmpfile)
    assert f.read() == data

    # Check the checksum
    assert checksum(tmpfile) == checksum_s(data)

    # Cleanup
    os.remove(tmpfile)
    os.rmdir(tmpdir)

# Generated at 2022-06-23 13:55:38.461357
# Unit test for function md5s
def test_md5s():

    from ansible.module_utils.basic import AnsibleModule
    import json

    test_cases = [
        {'input': 'test_data', 'expected_output': '098f6bcd4621d373cade4e832627b4f6'},
        {'input': '{"test_data":"test_data"}', 'expected_output': '944e81bcbaebe85f86e3b3ae414e0814'},
    ]

    test_results = []

    for test_case in test_cases:
        input = test_case['input']
        expected_output = test_case['expected_output']
        actual_output = md5s(input)
        if expected_output != actual_output:
            test_results.append(False)

# Generated at 2022-06-23 13:55:48.178542
# Unit test for function md5
def test_md5():
    from tempfile import NamedTemporaryFile
    from random import random
    from shutil import rmtree

    for i in range(4):
        # Create a random file to test
        fn = NamedTemporaryFile()
        content = b''
        for j in range(5):
            content += to_bytes(str(random()))
        fn.write(content)
        fn.flush()

        assert md5(fn.name) == _md5(content).hexdigest()
        assert md5s(content) == _md5(content).hexdigest()

        fn.close()
        rmtree(os.path.dirname(fn.name))

# Generated at 2022-06-23 13:55:54.837945
# Unit test for function checksum
def test_checksum():
    # This test is only valid on files containing one or more character
    # Otherwise the SHA1 sum is cb9e74020185c3b3f2cba9e9d9cb9e8f1de19a11
    assert checksum('test/utils/test_module_utils.py') == '39c4b4ff8307b5df5c5ecd6d5d0f8b633ebc6f21'


# Generated at 2022-06-23 13:56:00.714076
# Unit test for function md5
def test_md5():
    import tempfile
    file = tempfile.NamedTemporaryFile(delete=False)
    name = file.name
    file.close()
    # Create an empty file
    open(name, 'wb').close()
    # Using md5 function, hash the empty file
    digest = md5(name)
    # Remove the file
    os.unlink(name)
    return digest

if __name__ == '__main__':
    print('Digest is: %s' % test_md5())

# Generated at 2022-06-23 13:56:03.616497
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '93fae3ca3a9e0cf1f40e25906d8d45b8'


# Generated at 2022-06-23 13:56:05.531909
# Unit test for function checksum
def test_checksum():
    assert checksum_s('blah') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum_s(to_bytes('blah')) == 'a9993e364706816aba3e25717850c26c9cd0d89d'

# Generated at 2022-06-23 13:56:07.179089
# Unit test for function checksum
def test_checksum():
    assert checksum('setup.py') == '4eda4b4e8d9dfdf16e9cb2cb1769b2c8f229efd7'

# Generated at 2022-06-23 13:56:10.584850
# Unit test for function checksum_s
def test_checksum_s():
    '''
    If we didn't get any errors, we're good.
    '''
    checksum_s('hello')
    checksum_s('hello', hash_func=_md5) if _md5 else None

# Generated at 2022-06-23 13:56:13.703767
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-23 13:56:24.177652
# Unit test for function md5s
def test_md5s():
    import sys
    import datetime

    # Test this version of md5s() with Python 2.x and Python 3.x
    if sys.version_info[0] < 3:
        test_data = 'string'
    else:
        test_data = b'string'

    test_data_md5 = md5s(test_data)

    if test_data_md5 == '8ddd8be8807d30b71fef6b6d8a86f842':
        print('Function md5s() works for Python ' + str(sys.version_info[0]) + ' :)')
    else:
        print('Function md5s() does not work for Python ' + str(sys.version_info[0]) + ' :(')


if __name__ == '__main__':
    test_md

# Generated at 2022-06-23 13:56:30.237311
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    test_string = "a"
    answer = md5s(test_string)
    assert answer == '0cc175b9c0f1b6a831c399e269772661'



# Generated at 2022-06-23 13:56:32.541834
# Unit test for function md5s
def test_md5s():
    data = 'Hello world'
    h = '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(data) == h

# Generated at 2022-06-23 13:56:40.334024
# Unit test for function md5s
def test_md5s():
    import ansible.utils.hashing
    def _check(input):
        h1 = ansible.utils.hashing.md5s(input)
        h2 = ansible.utils.hashing.checksum_s(input)
        assert h1 == h2
    testval = "This is a unit test of md5s"
    _check(testval)
    testval = u"This is a unit test of md5s"
    _check(testval)
    testval = b"This is a unit test of md5s"
    _check(testval)

# Generated at 2022-06-23 13:56:50.090327
# Unit test for function md5
def test_md5():

    from tempfile import mkstemp
    from shutil import rmtree
    from os import mkdir, unlink, close, getcwd, chdir
    from os.path import exists, join
    from errno import ENOTEMPTY

    def test_hash(fname, expected_hash, secure=False, is_s=False):
        if secure:
            if is_s:
                hash = secure_hash_s(fname)
            else:
                hash = secure_hash(fname)
        else:
            if is_s:
                hash = md5s(fname)
            else:
                hash = md5(fname)

        assert (hash==expected_hash)

    current_dir = getcwd()
    tmp_dir = 'test_md5'

# Generated at 2022-06-23 13:56:55.225712
# Unit test for function md5
def test_md5():
    # create a random file in the current directory
    fd = open("file",'w')
    fd.write('0123456789')
    fd.close()
    file_md5 = md5("file")
    if file_md5 != '81dc9bdb52d04dc20036dbd8313ed055':
        raise Exception('md5 function does not work')
    os.remove("file")

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 13:56:57.263844
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-23 13:57:00.354859
# Unit test for function checksum
def test_checksum():
    assert repr(checksum(__file__)) == repr(checksum_s(open(__file__).read()))

# Generated at 2022-06-23 13:57:03.362040
# Unit test for function md5
def test_md5():
    import os
    a_md5 = md5(os.path.abspath(__file__))
    assert a_md5 == "08fb57cfa2a0a0d40d45f01e0f6c9e70", a_md5
    assert type(a_md5) == str


# Generated at 2022-06-23 13:57:12.323333
# Unit test for function checksum
def test_checksum():
    import tempfile
    import textwrap
    test_string = textwrap.dedent('''\
        A string with various punctuation
         and
        ''')
    with tempfile.NamedTemporaryFile(mode='w+b') as test_file:
        test_file.write(test_string.encode('utf-8'))
        test_file.flush()
        test_file.seek(0)
        assert checksum(test_file.name) == checksum_s(test_string)
        assert md5(test_file.name) == md5s(test_string)

# Generated at 2022-06-23 13:57:16.946571
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'fc5e038d38a57032085441e7fe7010b0'

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 13:57:19.333642
# Unit test for function checksum_s
def test_checksum_s():
    from random import randint
    result = checksum_s(str(randint(0,10000)))
    assert isinstance(result, str)
    assert len(result) == 40

# Generated at 2022-06-23 13:57:29.722728
# Unit test for function md5
def test_md5():
    from shutil import copyfile
    import os
    import tempfile
    from ansible.utils.path import unfrackpath

    tf = tempfile.NamedTemporaryFile(delete=False)
    tf.write("abcdefg")
    tf.close()

    f = unfrackpath("/etc/passwd")
    if not os.path.exists("/etc/passwd"):
        f = __file__
    md51 = md5(f)
    md52 = md5(f)
    assert md51 == md52, ("%s != %s" % (md51, md52))

    copyfile(f, tf.name)
    md53 = md5(tf.name)
    assert md51 == md53, ("%s != %s" % (md51, md53))

    tf2 = tempfile

# Generated at 2022-06-23 13:57:33.779884
# Unit test for function checksum_s
def test_checksum_s():
    """Function to test checksum_s"""
    test_data = 'This is a test string.'
    test_checksum = '0a50261ebd1a390fed2bf326f2673c145582a6342d523204973d021915f8f7e3'
    assert test_checksum == checksum_s(test_data)


# Generated at 2022-06-23 13:57:43.685409
# Unit test for function md5
def test_md5():
    from tempfile import mkstemp
    from os import remove, write

    (fd, fname) = mkstemp()
    write(fd, "Hello World")
    close(fd)

    h = md5(fname)
    assert h == 'b10a8db164e0754105b7a99be72e3fe5', h
    h = md5(fname[:-1])
    assert h is None, h
    h = md5s("Hello World")
    assert h == '5eb63bbbe01eeed093cb22bb8f5acdc3', h

    remove(fname)

# Generated at 2022-06-23 13:57:48.454360
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('Hello World\n', sha1) == '2ef7bde608ce5404e97d5f042f95f89f1c232871'

    if _md5:
        assert checksum_s('Hello World\n', _md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-23 13:57:50.628554
# Unit test for function md5
def test_md5():
    """ md5 unit test """

    assert md5("/dev/null") == "d41d8cd98f00b204e9800998ecf8427e"


# Generated at 2022-06-23 13:57:54.077088
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("foo") == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    assert checksum_s("bar") == "62cdb7020ff920e5aa642c3d4066950dd1f01f4d"


# Generated at 2022-06-23 13:57:56.940211
# Unit test for function md5s
def test_md5s():
    if md5s('test') != '098f6bcd4621d373cade4e832627b4f6':
        raise Exception()


# Generated at 2022-06-23 13:58:00.290042
# Unit test for function checksum_s
def test_checksum_s():
    data = b"hello"
    assert secure_hash_s(data) == "5d41402abc4b2a76b9719d911017c592"

# Generated at 2022-06-23 13:58:08.805375
# Unit test for function checksum
def test_checksum():
    ''' checksum.py: Test checksum() function '''

    # Create a temporary test file
    import tempfile, shutil, sys
    tmpdir = tempfile.mkdtemp()
    tmpname = os.path.join(tmpdir, "tmpfile")
    f = open(tmpname, "w")
    f.write("Hello World")
    f.close()

    # Perform checksum, removing any leading directories
    chksum = checksum(tmpname)
    chksum2 = checksum(tmpname.split("/")[-1])

    # Remove tempdir
    shutil.rmtree(tmpdir)

    # Fail test if chksum does not match
    if chksum != chksum2:
        sys.exit("FAILED: Checksum function failed to return expected checksum")


# Generated at 2022-06-23 13:58:19.100039
# Unit test for function md5
def test_md5():
    if _md5:
        assert md5('/bin/ls') == '0964c3a3a8a1c84d690a09d749f93d2f'
        assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    else:
        # If we're running in FIPS mode, attempting to use md5 should raise an error
        try:
            md5('/bin/ls')
        except ValueError:
            pass
        else:
            assert False, 'MD5 should not be available in FIPS mode'
        try:
            md5s('hello')
        except ValueError:
            pass
        else:
            assert False, 'MD5 should not be available in FIPS mode'

# Generated at 2022-06-23 13:58:21.272328
# Unit test for function md5s
def test_md5s():
    assert md5s('Hello, world!') == '65a8e27d8879283831b664bd8b7f0ad4'



# Generated at 2022-06-23 13:58:24.681143
# Unit test for function checksum
def test_checksum():
    ''' test checksum '''
    import tempfile

    fd, tf = tempfile.mkstemp()
    try:
        os.write(fd, b"Hello World\n")
        os.close(fd)
        print(checksum(tf))
    finally:
        os.remove(tf)



# Generated at 2022-06-23 13:58:33.795287
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('goodbye') == 'd03c98a2a79a66c8f1a3a78d52f9c645'
    assert md5s('ansible') == 'b534071348ac8aaa0f25b0c9d9a2a6f8'
    assert md5s('SSL Checker') == 'a8f2d0b6efd4c4e1b8f85cbc3d6c3b3a'


# Generated at 2022-06-23 13:58:43.671634
# Unit test for function checksum
def test_checksum():
    # sha1 and md5 checksums are generated using:
    # $ dd if=/dev/urandom of=checksum_test bs=1024 count=2
    # $ sha1sum checksum_test
    # $ md5sum checksum_test
    sha1_checksum = 'bd9d7ff8bf5edf47ea45f7774a15e5dd89814f5b'
    md5_checksum = '8e69e65b2c6884f87a87e4b4a4a4c9a4'

    assert(checksum('test/unit/ansible/utils/checksum_test') == sha1_checksum)

# Generated at 2022-06-23 13:58:46.467441
# Unit test for function md5
def test_md5():
    file_with_known_md5 = __file__
    known_md5 = secure_hash(file_with_known_md5, _md5)
    assert md5(file_with_known_md5) == known_md5

# Generated at 2022-06-23 13:58:56.836778
# Unit test for function md5s
def test_md5s():
    data1 = u'sp\xe4m' # this will have a multibyte utf-8 representation
    assert md5s(data1) == u'cf95a2b8f65e7490d5f5e5365f0a8a38', 'function md5s failed'

    data2 = u'spam'
    assert md5s(data2) == u'b2e446106b68edf39b9c9163f0494d27', 'function md5s failed'

    data3 = u'\xe4'
    assert md5s(data3) == u'59e36d52c1bcf82337f4e6d4a6e30a6a', 'function md5s failed'


# Generated at 2022-06-23 13:59:07.857416
# Unit test for function checksum
def test_checksum():
    import filecmp

    # Create a temp file
    (fd1, f1) = tempfile.mkstemp()
    (fd2, f2) = tempfile.mkstemp()

    # Write some data
    data = '1234567890'
    for x in range(0,1000):
        os.write(fd1, data)

    # Close the file
    os.close(fd1)
    os.close(fd2)

    # Do the checksum
    c1 = checksum(f1)
    c2 = checksum(f2)
    assert c1
    assert c2

    # Verify that checksums are different
    assert c1 != c2

    # Copy the file
    shutil.copyfile(f1, f2)

    # Verify that checksums are the same

# Generated at 2022-06-23 13:59:13.089377
# Unit test for function md5
def test_md5():
    ''' simple test of md5() '''
    import tempfile
    fd, temp_path = tempfile.mkstemp()
    f = open(temp_path, "w")
    f.write("Hello, World")
    f.close()
    md5hash = md5(filename=temp_path)
    assert md5hash == "65a8e27d8879283831b664bd8b7f0ad4"
    os.remove(temp_path)

# Generated at 2022-06-23 13:59:16.410057
# Unit test for function md5s
def test_md5s():
    test_result = md5s('hi')
    assert test_result == '49f68a5c8493ec2c0bf489821c21fc3b'

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-23 13:59:18.223013
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-23 13:59:19.792234
# Unit test for function md5s
def test_md5s():
    assert md5s('foobar') == '3858f62230ac3c915f300c664312c63f'


# Generated at 2022-06-23 13:59:23.332766
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_s('foo\n') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-23 13:59:28.368748
# Unit test for function md5s
def test_md5s():
    md5s = secure_hash_s('asdfasdf', _md5)
    if not md5s == '7e8fb1db2f1c6c0b24d7afee468af3a7':
        raise AssertionError('md5s() is not working correctly')


# Generated at 2022-06-23 13:59:35.293623
# Unit test for function md5
def test_md5():
    from nose.plugins.skip import SkipTest
    raise SkipTest
    import tempfile
    f = tempfile.NamedTemporaryFile()
    h = md5(f.name)
    assert h == 'd41d8cd98f00b204e9800998ecf8427e'
    f.write('hello')
    f.flush()
    h = md5(f.name)
    assert h == '5d41402abc4b2a76b9719d911017c592'
    f.close()

# Generated at 2022-06-23 13:59:36.735235
# Unit test for function checksum_s
def test_checksum_s():
    data = to_bytes(u"test")
    h = checksum_s(data)
    assert h is not None

# Generated at 2022-06-23 13:59:40.490737
# Unit test for function checksum
def test_checksum():
    ''' test_checksum

        Test the functionality of checksum with and without using the callback plugin
    '''

    checksum_value = '89a7d53e096663e7ee03d5a22b7c92d9'

    checksum_result = checksum('test/files/checksum')
    assert checksum_value == checksum_result

# Generated at 2022-06-23 13:59:51.235527
# Unit test for function md5s
def test_md5s():
    # Check valid input
    string = "The quick brown fox jumps over the lazy dog."
    test_str_md5 = md5s(string)
    assert test_str_md5 == "9e107d9d372bb6826bd81d3542a419d6"

    # Check empty string
    test_str = md5s('')
    assert test_str == "d41d8cd98f00b204e9800998ecf8427e"

    # Check valid unicode string
    test_uni_str = u'\xe7\xbd\x91\xe7\xbb\x9c'
    test_uni_str_md5 = md5s(test_uni_str)

# Generated at 2022-06-23 13:59:57.420353
# Unit test for function md5s
def test_md5s():
    ''' test_md5s is a unit test for md5s '''
    print("Inside unit test for md5s")
    assert md5s("1234")=="81dc9bdb52d04dc20036dbd8313ed055"
    assert md5("ansible/utils/hashing.py")=="b1fea23f0c2e8b8c05af34250e3df15e"



# Generated at 2022-06-23 14:00:03.746494
# Unit test for function md5
def test_md5():

    data = "Hello World"
    digest = md5s(data)
    assert(digest == "b10a8db164e0754105b7a99be72e3fe5")

    fn = '__test_md5_file__'
    fd = open(fn, "w")
    fd.write(data)
    fd.close()
    digest = md5(fn)
    os.remove(fn)
    assert(digest == "b10a8db164e0754105b7a99be72e3fe5")

# Generated at 2022-06-23 14:00:08.932406
# Unit test for function md5s
def test_md5s():
   assert md5s('Hello World') == 'b10a8db164e0754105b7a99be72e3fe5'
   assert md5s(u'Hello World') == 'b10a8db164e0754105b7a99be72e3fe5'
   

# Generated at 2022-06-23 14:00:12.499966
# Unit test for function checksum
def test_checksum():
    test = "ansible"
    test_hash = '4b8ff183a6929e730bf76bad9a0c8a8616a934d6'
    assert checksum(test) == test_hash


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 14:00:22.374952
# Unit test for function checksum
def test_checksum():
    import tempfile
    fd, fname = tempfile.mkstemp(suffix=".py")
    f = os.fdopen(fd, "w")
    f.write("def main():\n    print 'hello'\n")
    f.close()
    assert checksum(fname) == "5c3894b69f3d4a4e67a39e1f4bf63aab7ff9dc21"
    os.remove(fname)


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 14:00:25.549656
# Unit test for function md5s
def test_md5s():
    import ansible.module_utils.basic
    return ansible.module_utils.basic.AnsibleModule(argument_spec=dict()).exit_json(
        changed=False,
        md5s=md5s,
        md5=md5,
        ansible_facts=dict(
            in_fips_mode=not _md5,
            md5_data=md5s("hello"),
        )
    )



# Generated at 2022-06-23 14:00:28.989689
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'd7a8fbb307d7809469ca9abcb0082e4f'
    assert md5s('abc123') == 'e99a18c428cb38d5f260853678922e03'


# Generated at 2022-06-23 14:00:38.803334
# Unit test for function checksum
def test_checksum():

    def test(hash_func=sha1):
        ''' internal test function '''
        data = 'My test data'

        # Capture the initial checksum
        initial = checksum_s(data, hash_func)

        # Verify checksum matches the initial checksum
        assert checksum_s(data, hash_func) == initial

        # Verify a changed string results in a different checksum
        data = data + 'test'
        assert checksum_s(data, hash_func) != initial

    test()

    if _md5:
        # Repeate the test with md5
        test(_md5)



# Generated at 2022-06-23 14:00:44.485635
# Unit test for function md5
def test_md5():
    string = 'hello'
    filename = 'testfile'

    with open(filename, 'w') as f:
        f.write(string)

    assert md5s(string) == '5d41402abc4b2a76b9719d911017c592'
    assert md5(filename) == '5d41402abc4b2a76b9719d911017c592'

    os.unlink(filename)

# Generated at 2022-06-23 14:00:47.658776
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-23 14:00:54.682766
# Unit test for function checksum_s
def test_checksum_s():
    ''' test_checksum_s '''
    # This data was generated using this code:
    # import hashlib
    # print hashlib.sha1('testData').hexdigest()
    #
    # This is a test for the function secure_hash_s
    assert checksum_s('testData') == 'eecb2988c3d9a6b5183fd06543b268dff6a5e6c8'
    assert md5s('testData') == 'd8e8fca2dc0f896fd7cb4cb0031ba249'

# Generated at 2022-06-23 14:00:57.787166
# Unit test for function checksum_s
def test_checksum_s():
    data = 'blahblahblah'
    assert secure_hash_s(data) == '9dfce8960e1f67c36a8b5c56f1a37d87ddc6fb2e'

# Generated at 2022-06-23 14:00:59.707283
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-23 14:01:03.196691
# Unit test for function md5s
def test_md5s():
    md5_result = md5s("hello")
    if md5_result != "5d41402abc4b2a76b9719d911017c592":
        raise AssertionError("ERROR: md5s returned different result: %s" % md5_result)


# Generated at 2022-06-23 14:01:08.966474
# Unit test for function md5
def test_md5():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import Mock, patch, MagicMock

    class TestMd5(unittest.TestCase):

        def setUp(self):
            pass

        @patch('ansible.utils.crypto.secure_hash')
        def test_md5_calls_secure_hash_with_md5(self, mock_secure_hash):
            mock_secure_hash.return_value = 'hash'
            self.assertEqual(md5('filename'), 'hash')
            mock_secure_hash.assert_called_with('filename', _md5)


# Generated at 2022-06-23 14:01:14.495198
# Unit test for function md5
def test_md5():
    import tempfile
    tfile = tempfile.NamedTemporaryFile()

    tfile.write('hello')
    tfile.flush()

    md5 = md5(tfile.name)
    assert md5 == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-23 14:01:25.562075
# Unit test for function checksum
def test_checksum():
    import tempfile
    import random

    # test secure hash
    fobj, fname = tempfile.mkstemp()
    f = os.fdopen(fobj, 'w')
    f.write('hello')
    f.close()
    assert secure_hash(fname) == '5d41402abc4b2a76b9719d911017c592'
    assert secure_hash_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    os.remove(fname)

    # test md5
    fobj, fname = tempfile.mkstemp()
    f = os.fdopen(fobj, 'w')
    f.write('hello')
    f.close()

# Generated at 2022-06-23 14:01:28.028363
# Unit test for function checksum_s
def test_checksum_s():
    '''Function checksum_s'''
    assert checksum_s(None) is None
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'


# Generated at 2022-06-23 14:01:37.520407
# Unit test for function md5
def test_md5():
    dirname = os.path.dirname(os.path.abspath(__file__))
    # Check known hash
    test_path = os.path.join(dirname, '__init__.py')
    test_hash = md5(test_path)
    assert test_hash == '3959b8de6d5fddb83a801a1d6a8fb6e5', test_hash
    test_string = 'abc'
    test_hash = md5s(test_string)
    assert test_hash == '900150983cd24fb0d6963f7d28e17f72', test_hash

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 14:01:43.410010
# Unit test for function checksum_s
def test_checksum_s():
    test_string = b"test_string"
    expected_result = 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

    assert(checksum_s(test_string) == expected_result)
    assert(checksum_s(u"test_string") == expected_result)

# Generated at 2022-06-23 14:01:49.339939
# Unit test for function md5
def test_md5():
    data1 = b'Hello, world!'
    data2 = b'Hello, world!  More text.'
    assert md5s(data1) == 'fc3ff98e8c6a0d3087d515c0473f8677'
    assert md5s(data2) == 'f4b971811f52cc8f61c9513a1eec3767'

# Generated at 2022-06-23 14:02:01.091004
# Unit test for function checksum
def test_checksum():
    import os
    import tempfile

    check_sum = open("test/utils/test_checksum.py.sha1","r").readline()
    assert checksum("test/utils/test_checksum.py") == check_sum.split()[0]
    assert checksum_s("test/utils/test_checksum.py") == check_sum.split()[0]
    assert not checksum("test/utils/test_checksum.py.sha1")
    assert not checksum_s("test/utils/test_checksum.py.sha1")

    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-23 14:02:08.734948
# Unit test for function checksum_s
def test_checksum_s():

    # file "hello" should be written to /tmp/hello, if not, please create it
    if secure_hash_s('hello')!='5d41402abc4b2a76b9719d911017c592':
        print('test_checksum_s sha1 failed')
        return 1

    if secure_hash_s('hello', hash_func=_md5)!='8b1a9953c4611296a827abf8c47804d7':
        print('test_checksum_s md5 failed')
        return 1

    print('test_checksum_s passed')
    return 0


# Generated at 2022-06-23 14:02:15.204686
# Unit test for function md5s
def test_md5s():
    # simple tests, do not use for cryptographic purposes!
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('1234567890') == 'e807f1fcf82d132f9bb018ca6738a19f'
    assert md5s('foobar') == '3858f62230ac3c915f300c664312c63f'

# Generated at 2022-06-23 14:02:17.931629
# Unit test for function md5
def test_md5():
    import tempfile
    (fd, fn) = tempfile.mkstemp()
    try:
        f = os.fdopen(fd, "w")
        try:
            f.write("Hello, World!\n")
        finally:
            f.close()
        assert md5(fn) == "ed076287532e86365e841e92bfc50d8c"
    finally:
        os.unlink(fn)

# Generated at 2022-06-23 14:02:23.388755
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s(u'hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 14:02:30.620229
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("hello\n") == "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d"
    assert md5s("\x00") == "93b885adfe0da089cdf634904fd59f71"



# Generated at 2022-06-23 14:02:31.517283
# Unit test for function md5s
def test_md5s():
    # Should not raise exception
    md5s('foo')

# Generated at 2022-06-23 14:02:36.669679
# Unit test for function checksum
def test_checksum():
    checksum_data = "hello world!"
    checksum_data_file = "hashes.py"
    checksum_data_file_no_exist = "file-no-exist"
    checksum_data_file_exist_but_directory = "playbooks/roles"
    assert len(checksum(checksum_data_file)) == 40
    assert checksum(checksum_data_file_no_exist) == None
    assert checksum(checksum_data_file_exist_but_directory) == None
    assert len(checksum_s(checksum_data)) == 40

# Generated at 2022-06-23 14:02:40.539807
# Unit test for function md5
def test_md5():
    # assuming if this is properly executed there won't be any error
    md5s('')
    assert md5(__file__) == 'f40bb2613053735aa79c9d29f9b20c9b'

# Generated at 2022-06-23 14:02:42.941718
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-23 14:02:53.639035
# Unit test for function checksum_s
def test_checksum_s():
    def do_test(data, h):
        assert checksum_s(data) == h
        assert checksum_s(data) == checksum_s(data)
        assert checksum_s(data) != checksum_s(data + 't')

    # http://www.di-mgt.com.au/sha_testvectors.html
    do_test('abc', 'a9993e364706816aba3e25717850c26c9cd0d89d')
    do_test('abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq',
            '84983e441c3bd26ebaae4aa1f95129e5e54670f1')

# Generated at 2022-06-23 14:02:55.628708
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-23 14:02:59.795049
# Unit test for function checksum_s
def test_checksum_s():
    """Test case for function checksum_s"""

    test_string = 'Hello World!'
    assert checksum_s(test_string) == '0a4d55a8d778e5022fab701977c5d840bbc486d0'

# Generated at 2022-06-23 14:03:01.707527
# Unit test for function checksum_s
def test_checksum_s():
    assert secure_hash_s("test") == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"


# Generated at 2022-06-23 14:03:04.878182
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-23 14:03:06.778075
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world\n") == "5eb63bbbe01eeed093cb22bb8f5acdc3"


# Generated at 2022-06-23 14:03:10.032712
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '4b7f4b4e86d171f9888eef7c2e0af0d3b19e00e3'
    assert checksum_s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-23 14:03:11.961937
# Unit test for function md5
def test_md5():
    print(md5('/etc/fstab'))


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 14:03:14.703904
# Unit test for function checksum_s
def test_checksum_s():
    #generate checksum for different type of inputs
    for i in [1,1.0,'1.0','hello world', u'\xF6']:
        print("%s -> %s" % (i, checksum_s(i)))


# Generated at 2022-06-23 14:03:21.740738
# Unit test for function checksum_s
def test_checksum_s():

    print("\nTesting checksum_s")

    # Testing with valid and invalid parameters
    data = 1

# Generated at 2022-06-23 14:03:27.112758
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
        assert md5('/etc/passwd') == '6e812d8a71f1e441f140b9fb4320cc8f'

# Generated at 2022-06-23 14:03:34.543787
# Unit test for function checksum
def test_checksum():
    ''' Test checksum() for backwards compat for md5 '''

    filename = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../module_utils/basic.py')
    result_sha1 = secure_hash(filename)
    result_md5 = secure_hash(filename, _md5)
    result_checksum_sha1 = checksum(filename)
    result_checksum_md5 = checksum(filename, _md5)

    assert result_sha1 == result_checksum_sha1
    assert result_md5 == result_checksum_md5

# Generated at 2022-06-23 14:03:38.096689
# Unit test for function md5
def test_md5():
    try:
        md5("/bin/ls")
        test_passed = True
    except ValueError:
        test_passed = False
    assert test_passed, "Failed to securely hash a file with md5"

# Generated at 2022-06-23 14:03:41.674911
# Unit test for function md5
def test_md5():
    from . import t_path
    assert md5(os.path.join(t_path, 'test1.txt')) == '7a6f7375e0dd60ee9cf1b395a9525b61'


# Generated at 2022-06-23 14:03:52.450295
# Unit test for function md5
def test_md5():
    """
    ansible.utils.hash.md5
    """

    # Create temp file
    from tempfile import NamedTemporaryFile
    from ansible.module_utils._text import to_bytes

    temp_file = NamedTemporaryFile()
    temp_file.close()

    string = "hello"

    string_hash = to_bytes(md5s(string))
    temp_file_hash = to_bytes(md5(temp_file.name))

    # Clean up temp file
    os.unlink(temp_file.name)

    # Test string
    assert string_hash == '5d41402abc4b2a76b9719d911017c592'
    # Test file
    assert temp_file_hash is None


# Generated at 2022-06-23 14:04:03.804287
# Unit test for function checksum_s
def test_checksum_s():
    print("testing checksum_s")
    import tempfile
    (fd, fname)=tempfile.mkstemp(text=True)
    with os.fdopen(fd, 'w') as fd:
        fd.write("hello")
    assert secure_hash_s(b"hello") == "5d41402abc4b2a76b9719d911017c592"
    assert secure_hash_s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert secure_hash(fname) == "5d41402abc4b2a76b9719d911017c592"
    os.remove(fname)

if __name__ == '__main__':
    test_checksum_s()