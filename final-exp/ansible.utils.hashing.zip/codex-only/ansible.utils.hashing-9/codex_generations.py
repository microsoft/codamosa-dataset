

# Generated at 2022-06-23 13:54:11.312354
# Unit test for function checksum_s
def test_checksum_s():
    '''Unit test for function checksum_s'''
    # Check empty string
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    # Check non-empty string
    assert checksum_s('hello world!') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    # Check unicode string
    assert checksum_s(u'\u6d4b\u8bd5') == 'e0d80b8a8bdea7c11b36ee9e1dd87900d3c3b2f3'
    # Check long string
    long_str = 'a' * 1024 * 1024
    assert checksum_s(long_str)

# Generated at 2022-06-23 13:54:14.328720
# Unit test for function md5s
def test_md5s():
    ''' test md5 function '''
    import doctest

    print("Running tests for md5s()")
    doctest.testmod()

if __name__ == "__main__":
    test_md5s()

# Generated at 2022-06-23 13:54:24.164534
# Unit test for function checksum
def test_checksum():
    """Make sure the checksum function works"""
    import tempfile

    # Create a temporary file
    (tmpfd, tmppath) = tempfile.mkstemp()

    tmptext = """Hello world
    from ansible
    """

    tmphash = """198eac850bc8c861a60f08a5182d4f4102c345b4"""

    # Write to the file
    try:
        with os.fdopen(tmpfd, 'wb') as f:
            f.write(tmptext.encode('utf-8'))
    except IOError:
        return False

    # Make sure that the file hash matches
    if secure_hash(tmppath) != tmphash:
        return False

    # Remove the temporary file
    os.unlink(tmppath)
    os

# Generated at 2022-06-23 13:54:27.185715
# Unit test for function md5s
def test_md5s():
    test1 = md5s("testing")
    assert test1 == "ae2b1fca515949e5d54fb22b8ed95575", test1



# Generated at 2022-06-23 13:54:37.630695
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import filecmp
    cwd = os.getcwd()
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 13:54:42.480240
# Unit test for function md5s
def test_md5s():
    assert md5s("foobar") == "8843d7f92416211de9ebb963ff4ce28125932878"
    assert md5s("foo\nbar\nbaz\n") == "e4c923d5e2c12e7463eaa6a57d53a612"

# Generated at 2022-06-23 13:54:45.418277
# Unit test for function md5
def test_md5():
    if md5('test/unit/utils/test_module_utils.py') == 'f42d2de2193b0f6f9c6b0848a670e2e1':
        return True
    else:
        return False

# Generated at 2022-06-23 13:54:47.364727
# Unit test for function md5
def test_md5():
    assert md5s('TestString') == 'a7afff4b6e96ed4c4e6e77b0c09fbf70'

# Generated at 2022-06-23 13:54:51.365982
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-23 13:55:02.872514
# Unit test for function checksum
def test_checksum():
    ''' Unit test for function checksum '''
    import os
    import tempfile
    import shutil

    def create_tmp_file(tmp_dir):
        ''' Creates a file in the given temp directory '''
        fd, tmp_file = tempfile.mkstemp(dir=tmp_dir)
        return tmp_file

    def delete_tmp_file(tmp_file):
        ''' Deletes a given file '''
        os.unlink(tmp_file)

    def compare_checksums(file1, file2):
        ''' Compares checksums of the given files '''
        return checksum(file1) == checksum(file2)

    tmp_dir = tempfile.mkdtemp()
    file1 = create_tmp_file(tmp_dir)

# Generated at 2022-06-23 13:55:06.317060
# Unit test for function checksum_s
def test_checksum_s():
    test_data = 'Hello World!'
    test_result = '0a4d55a8d778e5022fab701977c5d840bbc486d0'
    test_checksum = checksum_s(test_data)
    assert test_checksum == test_result



# Generated at 2022-06-23 13:55:09.552530
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'b4b5bbb6402e54ffbfdd2f4d4f7c25d4'

# Generated at 2022-06-23 13:55:17.817453
# Unit test for function checksum_s
def test_checksum_s():
    hash_func_sha1 = secure_hash_s('HelloWorld', sha1)
    hash_func_md5 = secure_hash_s('HelloWorld', _md5)

    assert hash_func_sha1 == '0a4d55a8d778e5022fab701977c5d840bbc486d0', "Checksum not correctly calculated"
    assert hash_func_md5 == '68e109f0f40ca72a15e05cc22786f8e6', "Checksum not correctly calculated"

# Generated at 2022-06-23 13:55:24.372591
# Unit test for function md5s
def test_md5s():
    # Used to ensure that the md5s returned
    # by a SaltStack minion is the same as
    # what Ansible thinks the md5s of the file
    # is.

    if _md5:
        file_name = 'test_md5s.file'
        data_string = 'test_md5s data string'

        with open(file_name, 'w') as test_file:
            test_file.write(data_string)

        checksum_test = md5s(data_string)
        test_file_checksum = md5(file_name)

        # Remove the temporary file created
        os.remove(file_name)
        assert(checksum_test == test_file_checksum)

# Generated at 2022-06-23 13:55:35.016880
# Unit test for function checksum
def test_checksum():
    ''' unit test for checksum '''
    import tempfile
    from ansible.utils.path import makedirs_safe

    test_data = to_bytes('test data')
    test_dir = tempfile.mkdtemp(prefix='ansible_test_checksum')
    test_file = os.path.join(test_dir, 'test_checksum')

    # Ensure we can hash a simple string
    assert checksum_s('data') is not None

    # Ensure we can hash a unicode string
    test_unicode = '\xe2\x98\x83'  # snowman
    assert checksum_s(test_unicode) is not None

    # Ensure we can hash a unicode string with encode flag
    test_unicode = '\xe2\x98\x83'  # snowman

# Generated at 2022-06-23 13:55:43.168334
# Unit test for function checksum_s
def test_checksum_s():
    import sys
    import shutil
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """


# Generated at 2022-06-23 13:55:49.357976
# Unit test for function checksum
def test_checksum():
    filename = "./test/files/test_file"
    checksum_file = "./test/files/checksum.txt"
    checksum_dict_file = "./test/files/checksum_dict.txt"
    with open(checksum_file, "r") as f:
        checksum_value = f.readline()
    test_sum = checksum(filename)
    assert test_sum == checksum_value

# Generated at 2022-06-23 13:55:55.441055
# Unit test for function md5
def test_md5():
    # Verify both methods of passing arguments
    assert md5('lib/ansible/utils/__init__.py') == '851bdf21779ac38f6d1048c4c8f7c35d'
    assert md5(filename='lib/ansible/utils/__init__.py') == '851bdf21779ac38f6d1048c4c8f7c35d'

test_md5()

# Generated at 2022-06-23 13:56:04.160680
# Unit test for function checksum
def test_checksum():
    s = 'hello world'
    h = checksum_s(s)
    assert h == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    d = os.path.dirname(__file__)
    f = os.path.join(d, 'test_utils.py')
    h = checksum(f)
    assert h == 'bba9968b129f14e3d3c19f031250a22ae5a70d75'
    h = checksum(s)
    assert h == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-23 13:56:08.280513
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return 'MD5 not available.  Possibly running in FIPS mode'
    # test for issue #6872
    assert md5s(u'\xff') == u'246d7cabd4444e1b529a32d8fd1f7ef9'
    return 'ok'

# Generated at 2022-06-23 13:56:14.005051
# Unit test for function md5
def test_md5():

    (md, path) = mkstemp()

    with open(path, "wb") as f:
        f.write("data")

    try:
        assert(md5(path) == "7815696ecbf1c96e6894b779456d330e")
        assert(md5s("data") == "7815696ecbf1c96e6894b779456d330e")
    finally:
        os.remove(path)

# Generated at 2022-06-23 13:56:22.466402
# Unit test for function checksum
def test_checksum():
    import os
    current_dir = os.path.dirname(__file__)
    file_path = os.path.join(current_dir, 'checksum')
    try:
        os.remove(file_path)
    except OSError:
        pass

    checksum_value = checksum(file_path)
    if checksum_value is not None:
        raise Exception("%s should not exist, it should return None" % file_path)
    open(file_path, 'w+').close()
    checksum_value = checksum(file_path)
    if checksum_value != "da39a3ee5e6b4b0d3255bfef95601890afd80709":
        raise Exception("%s should be an empty file" % file_path)

# Generated at 2022-06-23 13:56:33.898006
# Unit test for function checksum
def test_checksum():
    '''sha1 should return identical value for both string and file input'''

    data_str = 'test string'
    filename = 'test_checksum'
    # sample sha1 hash of 'test string'
    sha1_checksum = 'c2d137f27f67b51e2b1c8d4f14cc9b957ea95b4c'
    # create a file with the string data

# Generated at 2022-06-23 13:56:37.681334
# Unit test for function md5
def test_md5():
    # Create a file and check the md5sum
    import os
    import tempfile
    (fd, name) = tempfile.mkstemp()
    os.write(fd, "Hello test file")
    os.close(fd)
    if md5(name) != "e2d3d9fdc3c0ff4cc4f5d5b5bf0d0e8f":
        raise Exception("MD5 sum calculation failed")
    os.unlink(name)


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 13:56:43.047114
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo' * 10) == 'd12a2bb49f8c9f2d9a9c7a418e4001bf'


# Generated at 2022-06-23 13:56:48.736944
# Unit test for function checksum_s
def test_checksum_s():
    try:
        assert checksum_s("foo") == \
            "acbd18db4cc2f85cedef654fccc4a4d8"
        assert checksum_s("foo bar\n") == \
            "b6a5f8bbda5a7d5a5ea3f2de5d6161d1"
    except ImportError:
        print("ERROR: cannot import OpenSSL needed for checksum_s")


# Generated at 2022-06-23 13:56:54.905861
# Unit test for function checksum
def test_checksum():
    import sys
    if sys.version_info[0] > 2:
        assert checksum_s(u"abc") == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    else:
        assert checksum_s("abc") == 'a9993e364706816aba3e25717850c26c9cd0d89d'

# Generated at 2022-06-23 13:56:58.381902
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-23 13:57:04.792111
# Unit test for function checksum_s
def test_checksum_s():
    import sys
    from ansible.module_utils.six import PY3

    if PY3:
        if sys.version_info >= (3, 6):
            assert(checksum_s("test123") == "17c096e0f874d5f1e60ede77129f0cc2a9d9c8f7")
        else:
            assert(checksum_s("test123") == "4f1c4f9e53e813f85bddb797057a2b0f")
    else:
        from ansible.module_utils.six import PY2

        if PY2:
            assert(checksum_s("test123") == "4f1c4f9e53e813f85bddb797057a2b0f")

# Generated at 2022-06-23 13:57:08.045285
# Unit test for function md5
def test_md5():
    ''' test_md5
    This is a unit test for md5 function in ansible.utils.md5.
    It takes input as a string and generates its md5 hash.
    If the given string is 'hello', the md5 hash should
    be '5d41402abc4b2a76b9719d911017c592'
    '''
    string = 'hello'
    print(md5s(string))
    assert md5s(string) == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-23 13:57:10.420402
# Unit test for function md5s
def test_md5s():
    assert md5s("abc") == "900150983cd24fb0d6963f7d28e17f72"


# Generated at 2022-06-23 13:57:13.514365
# Unit test for function md5s
def test_md5s():
    data = 'testdata'
    md5sum = md5s(data)
    assert md5sum == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-23 13:57:23.020834
# Unit test for function md5
def test_md5():
    '''Return true if md5 hashes of two given files match.'''
    import tempfile
    # Create an empty tmp file
    fp = tempfile.NamedTemporaryFile(delete=False)
    fp.close()
    # Use md5() to calculate hashes
    hash1 = md5(fp.name)
    # Modify the file by appending a line
    fp = open(fp.name, 'w')
    fp.write("foo\n")
    fp.close()
    hash2 = md5(fp.name)
    # Remove the tmp file created
    os.unlink(fp.name)
    # Return True if hashes are different, indicating file was modified
    if hash1 != hash2:
        return True

# Generated at 2022-06-23 13:57:32.461869
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("Hello world") == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"
    # Must work with non-ascii strings
    assert checksum_s("\u9f8d") == "31537d4ce3da4ca4eeb1aacd1fc920b6a5042f31"
    assert checksum_s("\xe4\xb8\xad") == "ac1f2721a6f25aa65609713fda44d6b0a6af5a0f"
    # Must be binary safe
    assert checksum_s(b"Hello world") == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"


# Generated at 2022-06-23 13:57:33.889700
# Unit test for function checksum
def test_checksum():
    # FIXME:
    # need to write test for function checksum
    return True


# Generated at 2022-06-23 13:57:42.618133
# Unit test for function md5
def test_md5():
    import shutil
    import tempfile
    fd, fname = tempfile.mkstemp()
    with os.fdopen(fd, 'wb') as f:
        f.write(b'foobarbaz')
    try:
        if md5(fname) != '02bd792f48bc6de64b305902c8e7ffa6':
            raise Exception('md5() test failed')
    finally:
        os.unlink(fname)



# Generated at 2022-06-23 13:57:51.994392
# Unit test for function checksum
def test_checksum():
    assert checksum_s('testing123') == '57d8d7e8b0f2db7fa66cbb18e7bde89b9e287545'
    assert checksum_s('testing123', _md5) == 'ae2b1fca515949e5d54fb22b8ed95575'
    assert checksum('/etc/passwd') == 'd30a8e648c24a3f3a220f518b5bf01a5f05b0961'
    assert checksum('/etc/passwd', _md5) == '86d7ff8ed04059c5a5a2738e0d7ff8e3'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 13:57:57.973072
# Unit test for function checksum
def test_checksum():
    import tempfile
    import os
    tfile = tempfile.NamedTemporaryFile(delete=False)
    tfile.write("Hello world")
    tfile.close()
    assert checksum(tfile.name) == 'e59ff97941044f85df5297e1c302d260'
    os.unlink(tfile.name)

# Generated at 2022-06-23 13:58:04.181047
# Unit test for function md5s
def test_md5s():
    known = {
        "ansible": "2fbe01f3cc7f3c6c835d126ee28c4f0b",
        "ansible1": "eecacd468cb26303a8bdc8f982a1ed3d",
    }

    assert(md5s("ansible") == known["ansible"])
    assert(md5s("ansible1") == known["ansible1"])

# Generated at 2022-06-23 13:58:11.087594
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s('hello') != '5d41402abc4b2a76b9719d911017c592':
        print('FAILED: `hello` string failed checksum')
    elif checksum_s('hello') == checksum_s('hello world'):
        print('FAILED: `hello` and `hello world` checksum collided')
    else:
        print('PASSED: checksum_s()')



# Generated at 2022-06-23 13:58:21.072948
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'\xc3') == 'f8cba0fcd87d1c76f2e9308b59c6eefa'
    assert md5s(b'\xe6\xb0\xb4') == '9def764ad18f654405f77aaa55d5b5f4'

# Generated at 2022-06-23 13:58:24.265761
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    # The following test is adapted from the 'random_password' module
    assert md5s('asdf') == '912ec803b2ce49e4a541068d495ab570'

# Generated at 2022-06-23 13:58:28.014410
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('Test string', sha1) == '6b98f6b564cbea65da383fc0d4847caa49edc02a'

# Generated at 2022-06-23 13:58:35.460892
# Unit test for function md5
def test_md5():
    s="hello world"
    if md5s(s)=="5eb63bbbe01eeed093cb22bb8f5acdc3":
        print('md5s test successful')
    else:
        print('md5s test failed')
    if md5("checksum.py")=="23a4ef4a4c4f4e54a247a5fe0c0f5db2":
        print('md5 test successful')
    else:
        print('md5 test failed')


# Generated at 2022-06-23 13:58:45.083431
# Unit test for function checksum
def test_checksum():
    """
    Unit test for the checksum function
    """

    import random
    import base64
    import hashlib

    # Create a random file, write random string to it and calculate the checksum of it
    fd = open('my_random_file', 'w')
    random_string = base64.b64encode(os.urandom(10000))
    fd.write(random_string)
    fd.close()

    file_checksum = hashlib.sha1(random_string).hexdigest()
    assert file_checksum == checksum('my_random_file')

    # create the same file again
    fd = open('my_random_file', 'w')
    fd.write(random_string)
    fd.close()

    # check if the checksum is the same
    assert file_

# Generated at 2022-06-23 13:58:52.694576
# Unit test for function checksum_s
def test_checksum_s():
    ''' fail on empty input'''
    try:
        secure_hash_s(None)
    except TypeError as e:
        pass
    else:
        raise AssertionError
    ''' fail on non-string input'''
    try:
        secure_hash_s(['test'])
    except TypeError as e:
        pass
    else:
        raise AssertionError

    ''' should return a hash string'''
    assert len(secure_hash_s('test')) == 40


# Generated at 2022-06-23 13:58:56.537397
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s('test') != 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3':
        raise AssertionError('checksum_s does not create a proper checksum')


# Generated at 2022-06-23 13:59:07.722101
# Unit test for function checksum_s
def test_checksum_s():

    # return 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    # return '34af7c8c1e339e7f909df3366c98a93dfadc69cd'
    assert checksum_s('ııııııııııı') == 'c4e4a1c300e04e59d36bcc3398b8f66f6d99a6bf'
    # return '638c19f30eec6f15e2c3a36a2a66066e24088b4c'

# Generated at 2022-06-23 13:59:10.261664
# Unit test for function md5s
def test_md5s():
    ''' this is a minimal test for md5s() '''

    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-23 13:59:17.773291
# Unit test for function md5
def test_md5():
    try:
        assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
        b_fname = os.path.join(os.path.dirname(__file__), 'test_md5.txt')
        assert md5(b_fname) == 'd5f5a5e5a4892a6ab17e7c878a0555d0'
    except:
        raise AssertionError('Failed md5 test')


# Generated at 2022-06-23 13:59:19.656193
# Unit test for function md5
def test_md5():
    assert (md5(__file__) == 'f9c8b7f78c0a3a7eebb651f3a1ff5831')



# Generated at 2022-06-23 13:59:31.049040
# Unit test for function md5
def test_md5():
    import json
    to_write = 'Hello world'
    filename = 'test.txt'
    filename_md5 = filename + '.md5'

    file_to_write = open(filename, 'w')
    file_to_write.write(to_write)
    file_to_write.close()

    with open(filename_md5, 'w') as outfile:
        json.dump(md5(filename), outfile)

    with open(filename_md5, 'r') as file_to_read:
        computed_md5 = json.load(file_to_read)
        assert computed_md5 == 'ed076287532e86365e841e92bfc50d8c'

    os.remove(filename_md5)
    os.remove(filename)

# Generated at 2022-06-23 13:59:40.781301
# Unit test for function md5s
def test_md5s():
    from ansible.compat.tests import unittest

# Generated at 2022-06-23 13:59:44.221811
# Unit test for function md5
def test_md5():
    ''' test md5 functionality '''
    assert md5("/bin/ls") == "7a966d46975d7fe42cf0aefad98b8428"



# Generated at 2022-06-23 13:59:53.950489
# Unit test for function md5
def test_md5():
    # Test single line
    s = md5s("Hello World!")
    assert s == "2ef7bde608ce5404e97d5f042f95f89f", \
        "Test #1 failed. Got %s" % s

    # Test multi-line
    s = md5s("""
Hello
World!
""")
    assert s == "b10a8db164e0754105b7a99be72e3fe5", \
        "Test #2 failed. Got %s" % s

    # Test null string
    s = md5s("")
    assert s == "d41d8cd98f00b204e9800998ecf8427e", \
        "Test #3 failed. Got %s" % s

    # Test empty file

# Generated at 2022-06-23 14:00:00.627451
# Unit test for function md5
def test_md5():
    import filecmp
    import tempfile
    temp_file = tempfile.NamedTemporaryFile()
    temp_file.write("Hello world!")
    temp_file.flush()
    temp_file.seek(0)
    expected_md5 = '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5(temp_file.name) == expected_md5
    assert md5s("Hello world!") == expected_md5
    temp_file.close()

# Generated at 2022-06-23 14:00:05.710073
# Unit test for function md5
def test_md5():
    filename = 'test_md5'
    open(filename, 'w').write('test')
    md5sum = md5(filename)
    os.unlink(filename)
    assert md5sum == '098f6bcd4621d373cade4e832627b4f6', 'Invalid md5'


# Generated at 2022-06-23 14:00:08.279144
# Unit test for function md5s
def test_md5s():
    assert md5s('ansible') == '45f79662e70da1e3e24d72067778b9c9'


# Generated at 2022-06-23 14:00:13.152696
# Unit test for function checksum
def test_checksum():
    if checksum_s('hello world', sha1) != '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed':
        return False
    if checksum('/etc/ansible/hosts') != '0a8a75ae53566e3c3e9d9d9e6d3110f50a2c4a72':
        return False
    return True


# Generated at 2022-06-23 14:00:22.039348
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return True
    else:
        test_data = "test data"
        answer = "bd7b14b0f52c5d9e6b00fa79fa5fa317"
        calculated = md5s(test_data)
        return calculated == answer

# Backwards compat for md5s and md5.  Probably not a good idea.
md5sum = md5sum_s = md5s
md5sum_local = md5

# Generated at 2022-06-23 14:00:25.770387
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == 'c4da4cfc4d8b1a2bdfc0f9772d77c029e688bc79'
    assert checksum("/bin/notthere") is None



# Generated at 2022-06-23 14:00:32.871940
# Unit test for function checksum
def test_checksum():
    # Check for empty checksum
    assert checksum('') is None
    # Check for non-existant file
    assert checksum('/tmp/this-file-should-not-exist') is None
    # Check for directory
    assert checksum('/tmp') is None
    # Check for existing file
    assert checksum('/etc/hosts') == 'de074d6007857b9e3a3cd3d00ad97ed1d608a1b2'
    # Check for existing file with string input
    assert checksum('/etc/hosts', 'sha256') == 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
    # Check for existing file with wrong string input

# Generated at 2022-06-23 14:00:36.933925
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('world') == '7d793037a0760186574b0282f2f435e7'

# Generated at 2022-06-23 14:00:39.326891
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s('hello') != '5d41402abc4b2a76b9719d911017c592':
        return False
    return True

# Generated at 2022-06-23 14:00:41.938583
# Unit test for function checksum
def test_checksum():
    actual = checksum(__file__)
    expected = secure_hash(__file__)
    assert actual == expected

# Generated at 2022-06-23 14:00:53.120924
# Unit test for function checksum
def test_checksum():
    ''' test_checksum: test the checksum function
    '''
    test_file = 'test_data/test_checksum.txt'
    test_contents = 'This is the test file for the checksum module.  It contains text, numbers and punctuation.\n'

    # Write out the test file
    f = open(test_file, 'wb')
    f.write(to_bytes(test_contents))
    f.close()

    # Test normal operation
    result = checksum(test_file)
    if result != '3a7f6c4c1b9490c47a9f33a2f2acb8e7b1d2dcc2':
        print("FAILED: checksum test 1")
        raise AssertionError

    # Test normal operation
    result = checksum

# Generated at 2022-06-23 14:00:56.093124
# Unit test for function md5
def test_md5():
    import tempfile
    f = tempfile.NamedTemporaryFile(delete=False)
    f.write(b"hello world")
    f.close()

    assert md5(f.name) == "5eb63bbbe01eeed093cb22bb8f5acdc3"

# Generated at 2022-06-23 14:01:01.185031
# Unit test for function checksum
def test_checksum():
    a = "Hello"
    b = "Hello world!"

    assert checksum_s(a) == "f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0"
    assert checksum_s(b) == "0a4d55a8d778e5022fab701977c5d840bbc486d0"



# Generated at 2022-06-23 14:01:07.740169
# Unit test for function checksum_s
def test_checksum_s():
    ''' Return True if function checksum_s returns the same result as md5sum of the input string. '''
    test_str = "This is a test string"
    # Get the checksum of the input string
    test_hash_checksum_s = secure_hash_s(test_str)
    # Get the checksum of a string written to a file
    f = open("test_checksum_s.txt", 'w')
    f.write(test_str);
    f.close()
    test_hash_checksum_file = secure_hash("test_checksum_s.txt")
    #
    # If the hashes are not equal, unlink the file
    #
    if test_hash_checksum_s != test_hash_checksum_file:
        assert False

# Generated at 2022-06-23 14:01:20.024994
# Unit test for function md5
def test_md5():
    import os
    assert md5('../changelogs/CHANGELOG_1_1') == '8a0a29a50a18d279584c9aec9a9e7d32'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    # assert md5s(u'HELLO') == '5d41402abc4b2a76b9719d911017c592' # Only works on Python 3

# Generated at 2022-06-23 14:01:25.324025
# Unit test for function checksum
def test_checksum():
    assert secure_hash_s('"to be or not to be" is a great question') == 'd751628f2203870eec2158a6c5929aa930d14924'
    assert secure_hash('/dev/urandom') == '1f79b40c8e1dc95d3c9990cf3b0cdea4d4e6a4a6'

# Generated at 2022-06-23 14:01:27.513953
# Unit test for function checksum_s
def test_checksum_s():
    compare_digest = "b18fe7f520a75a3e7d40d28e8c7148cf6b0fb44d"
    assert compare_digest == checksum_s("Hello World!")


# Generated at 2022-06-23 14:01:32.485363
# Unit test for function checksum_s
def test_checksum_s():
    ''' return True if checksum_s works as expected, False otherwise '''

    # check s if checksum_s works properly
    if (checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'):
        return True
    else:
        return False

# Generated at 2022-06-23 14:01:34.941494
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"



# Generated at 2022-06-23 14:01:36.000498
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello world") == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-23 14:01:37.654039
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-23 14:01:41.339712
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"



# Generated at 2022-06-23 14:01:48.139026
# Unit test for function md5s
def test_md5s():
    import sys
    if sys.version_info >= (3, 0):
        data = "Hello World!"
        assert md5s(data) == 'ed076287532e86365e841e92bfc50d8c'
    else:
        try:
            md5s("Hello World!")
            assert False
        except ValueError:
            pass

# Generated at 2022-06-23 14:01:53.672965
# Unit test for function md5
def test_md5():
    content = 'abcdefghijklmnopqrstuvwxyz'
    filename = 'test-md5.txt'
    f = open(filename, 'w')
    f.write(content)
    f.close()
    assert md5(filename) == 'c3fcd3d76192e4007dfb496cca67e13b'
    os.unlink(filename)

# Generated at 2022-06-23 14:01:57.829905
# Unit test for function checksum
def test_checksum():
    assert checksum('lib/ansible/module_utils/basic.py') == '4d2a4a3b3df1b3a0c05a44cd7f95f96470db57a8'



# Generated at 2022-06-23 14:02:07.739278
# Unit test for function md5
def test_md5():
    from os.path import join
    from shutil import rmtree, copytree

    def test_md5(src):
        dest = src + '.copy'
        copytree(src, dest)
        try:
            assert md5(src) == md5(dest)
        finally:
            rmtree(dest)

    test_md5('test/utils/test_md5/src')
    test_md5('test/utils/test_md5/src with spaces')
    test_md5(join('test', 'utils', 'test_md5', 'src with spaces'))
    test_md5(join('test', 'utils', 'test_md5', 'src'))
    test_md5(join('test', 'utils', 'test_md5', 'src with spaces'))

# Generated at 2022-06-23 14:02:14.585548
# Unit test for function checksum
def test_checksum():
    import tempfile

    (fd, path) = tempfile.mkstemp()
    fd = os.fdopen(fd, "w")
    fd.write("banana")
    fd.close()
    sum = checksum(path)
    os.unlink(path)

    if sum != "e0c4d4b941b6c15ea41213bf8012f06a6d7775e2":
        raise ValueError("checksum() test failed")

# Generated at 2022-06-23 14:02:18.982005
# Unit test for function checksum
def test_checksum():
    from . import t_path
    assert checksum(t_path('data/file1')) == '68b329da9893e34099c7d8ad5cb9c940'
    assert checksum_s(os.urandom(8192)) != '68b329da9893e34099c7d8ad5cb9c940'
    return

# Generated at 2022-06-23 14:02:24.669389
# Unit test for function md5s
def test_md5s():
    test_data = "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq"
    test_result = md5s(test_data)

    assert test_result == '8215ef0796a20bcaaae116d3876c664a'

# Generated at 2022-06-23 14:02:34.627466
# Unit test for function checksum

# Generated at 2022-06-23 14:02:39.395935
# Unit test for function checksum_s
def test_checksum_s():
    assert secure_hash_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert secure_hash_s('hello', _md5) == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-23 14:02:44.071067
# Unit test for function checksum_s
def test_checksum_s():

    assert(checksum_s('hello world') == "5eb63bbbe01eeed093cb22bb8f5acdc3")
    assert(checksum_s('hello world', hash_func=_md5) == "ed076287532e86365e841e92bfc50d8c")




# Generated at 2022-06-23 14:02:52.640859
# Unit test for function checksum_s
def test_checksum_s():

    assert checksum_s("test") == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"
    assert checksum_s("charset") == "4351a5a5f59d9db944c37b1f0e65e060d1e2b7f2"
    assert checksum_s("") == "da39a3ee5e6b4b0d3255bfef95601890afd80709"

if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-23 14:03:04.056517
# Unit test for function checksum
def test_checksum():
    # Return None when file doesn't exist.
    assert checksum('/tmp/nofile/bogus') is None
    assert checksum('/dev/null') == checksum('/dev/null')  # Should not raise error
    assert checksum('/dev/zero') == checksum('/dev/zero')
    # Now create a test file and remove it after we are done.
    import tempfile
    import textwrap
    tf = tempfile.NamedTemporaryFile()
    tf.write(textwrap.dedent('''
        There was an old woman who lived in a shoe.
        She had so many children she didn't know what to do.
        She gave them some broth without any bread;
        She whipped them all soundly and sent them to bed.
        '''))
    filename = tf.name

# Generated at 2022-06-23 14:03:24.028007
# Unit test for function checksum
def test_checksum():

    assert checksum_s("abc") == "a9993e364706816aba3e25717850c26c9cd0d89d"
    assert checksum_s("abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq") == "84983e441c3bd26ebaae4aa1f95129e5e54670f1"

    assert checksum("test/files/ansible.cfg") == "6aaf0d1cbea8e8478ab7c6f4efb7f004f9025d8f"
    assert checksum("test/files/ansible.cfg", _md5) == "60e7b6d38dd8cd9c3e95688bfd34a05c"

    assert md5

# Generated at 2022-06-23 14:03:27.926341
# Unit test for function checksum
def test_checksum():
    filename = '%s/payload.dat' % os.path.dirname(os.path.realpath(__file__))
    print(filename)
    print(checksum(filename))

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 14:03:30.305515
# Unit test for function checksum
def test_checksum():
    # This will just test if the checksum function is returning a string
    print("Test checksum function")
    assert(isinstance(checksum_s("foo"), str))

# Generated at 2022-06-23 14:03:32.556347
# Unit test for function checksum_s
def test_checksum_s():
    assert(checksum_s("hello") == "5d41402abc4b2a76b9719d911017c592")


# Generated at 2022-06-23 14:03:38.145910
# Unit test for function checksum_s
def test_checksum_s():
    # FIPS-140-2 mode
    if _md5:
        assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"
    assert checksum_s("foo") == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"


# Generated at 2022-06-23 14:03:39.957395
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('asdf') == '912ec803b2ce49e4a541068d495ab570'


# Generated at 2022-06-23 14:03:51.738211
# Unit test for function checksum
def test_checksum():
    ''' Test checksum'''
    with open('/etc/ansible/hashing/testfile1', 'wb') as myfile:
        myfile.write(b'This is a test to ensure that we get the proper md5 back.')
    with open('/etc/ansible/hashing/testfile2', 'wb') as myfile:
        myfile.write(b'And another test as well.')

    assert checksum('/etc/ansible/hashing/testfile1') == '7a3b3c49b7d9ecedc1ab7e8b44864a7f'
    assert checksum_s('This is a test to ensure that we get the proper md5 back.') == '7a3b3c49b7d9ecedc1ab7e8b44864a7f'


# Generated at 2022-06-23 14:03:59.938224
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('hello') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'
    assert checksum_s('hello '*1000) == '58a0b974ba066e384b1a8c71494b8bc2bcb3be3b'