

# Generated at 2022-06-23 13:54:10.341025
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return True
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s('ab') == '187ef4436122d1cc2f40dc2b92f0eba0'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abcd') == 'e2fc714c4727ee9395f324cd2e7f331f'
    assert md5s('abcde') == 'ab56b4d92b40713acc5af89985d4b786'

# Generated at 2022-06-23 13:54:20.983951
# Unit test for function md5
def test_md5():
    ''' md5 unit tests.  Not run by default '''
    import random
    import string

    random.seed()

    # Create a temporary file with random data in it
    for i in range(0, 10):
        file_name = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(6))

        # The file has a random number of lines in it, which are a
        # random length, and are generated with random data.
        num_lines = random.randint(1, 5)
        with open(file_name, 'wb') as f:
            for j in range(0, num_lines):
                string_length = random.randint(1, 20)

# Generated at 2022-06-23 13:54:23.604223
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '3a9bf9c2be2d0a8a2b35489c10fb34b17d82c8ea'


# Generated at 2022-06-23 13:54:34.162487
# Unit test for function checksum
def test_checksum():
    test_file_path = 'test_hash_file'
    test_file = open(test_file_path, 'w')
    test_file.write("This is content of the test file")
    test_file.close()

    test_file_checksum = checksum(test_file_path)
    assert test_file_checksum is not None

    test_file_checksum_s = checksum_s("This is content of the test file")
    assert test_file_checksum_s is not None

    test_file_checksum_chunk_s = checksum_s("This is content of")
    test_file_checksum_chunk_s = checksum_s(" the test file", test_file_checksum_chunk_s)
    assert test_file_checksum_chunk_s is not None

# Generated at 2022-06-23 13:54:42.876423
# Unit test for function md5
def test_md5():
    '''This function is written such that it uses md5 to
    compute a md5 checksum.  If it returns True, it means
    MD5 is available and can be used.
    '''

    alt_data = "Hello world"
    try:
        m = md5s(alt_data)
        if m and m == "5eb63bbbe01eeed093cb22bb8f5acdc3":
            return True
        else:
            return False
    except ValueError:
        return False

# Generated at 2022-06-23 13:54:51.283564
# Unit test for function checksum
def test_checksum():
    assert checksum_s('md5sum test') == '9f1c922ae98d8b8e7f3020402e4d2893'
    assert checksum_s('md5sum test', _md5) == 'c8f077254aad3f0a7b13d46b935a2c2b'
    assert md5s('md5sum test') == 'c8f077254aad3f0a7b13d46b935a2c2b'
    assert checksum('/etc/passwd')  == 'f31af7f790c5b0cfb485c6c36b6ea31476c1b3f1'

# Generated at 2022-06-23 13:54:56.202110
# Unit test for function checksum
def test_checksum():
    import os

    file = os.getcwd() + "/chksum.txt"
    with open(file, 'w') as f:
        f.write('hello world')

    assert checksum(file) == checksum('hello world')

# Generated at 2022-06-23 13:55:01.062878
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum('tests/tmp/checksum_data') == '7fc65f1b3c7b2a2ba9e9b4e3c45a15f1d7ff36a4'
    assert checksum_s('foobar') == '8843d7f92416211de9ebb963ff4ce28125932878'

# Generated at 2022-06-23 13:55:03.857917
# Unit test for function md5s
def test_md5s():
    data = "data"
    assert md5s(data) == '1eb704dd0d922fa31e7e4b6d23c8fef0'


# Generated at 2022-06-23 13:55:10.330990
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('0123456789') == '781e5e245d69b566979b86e28d23f2c7'
    assert checksum_s('abcdefghijklmnopqrstuvwxyz') == 'c3fcd3d76192e4007dfb496cca67e13b'



# Generated at 2022-06-23 13:55:15.184614
# Unit test for function checksum
def test_checksum():

    checksum_input = 'sha1'
    checksum_return = secure_hash_s('abc', sha1)
    assert checksum_return == checksum(to_bytes('abc', errors='surrogate_or_strict'), sha1)



# Generated at 2022-06-23 13:55:21.289146
# Unit test for function md5
def test_md5():
    if _md5:
        assert md5('/bin/ls') == '0eba357c723a50c6b5f0b8cc9d9d94b1'
        assert md5s('this is a string') == '4c4dc05e4ad9427b08e7bdb35c3b2d45'
    else:
        try:
            md5('/bin/ls')
        except:
            pass
        else:
            raise Exception('Expected and exception')



# Generated at 2022-06-23 13:55:25.984099
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s("foobar") != "8843d7f92416211de9ebb963ff4ce28125932878":
        print("Failed checksum_s(\"foobar\") test.")
        return False
    else:
        return True

# Generated at 2022-06-23 13:55:29.693250
# Unit test for function md5
def test_md5():
    # Given
    digest = '098f6bcd4621d373cade4e832627b4f6'
    filename = './test/unit/modules/file_checksum_test'

    # When
    md5sum = md5(filename)

    # Then
    assert md5sum == digest

# Generated at 2022-06-23 13:55:32.034190
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('abc') == "900150983cd24fb0d6963f7d28e17f72"

# Generated at 2022-06-23 13:55:35.624509
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('world') == '7d793037a0760186574b0282f2f435e7'


# Generated at 2022-06-23 13:55:41.463970
# Unit test for function checksum
def test_checksum():
    checksum('/bin/ls', hash_func=sha1)
    try:
        checksum('/bin/ls', hash_func=md5)
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'


# Generated at 2022-06-23 13:55:51.208554
# Unit test for function md5
def test_md5():
    import tempfile
    import filecmp
    import shutil

    source = tempfile.NamedTemporaryFile(delete=False)
    source_name = source.name
    source.close()
    shutil.copy('/bin/ls', source_name)

    target = tempfile.NamedTemporaryFile(delete=False)
    target_name = target.name
    target.close()
    shutil.copy('/bin/ls', target_name)

    assert(md5(source_name) == md5(target_name))

    source = tempfile.NamedTemporaryFile(delete=False)
    source_name = source.name
    source.close()
    shutil.copy('/bin/cat', source_name)

    assert(md5(source_name) != md5(target_name))

    os

# Generated at 2022-06-23 13:55:56.079195
# Unit test for function checksum
def test_checksum():
    import os
    testfile = '/tmp/test_checksum'
    file = open(testfile, 'w')
    file.write('hello!\n')
    file.close()
    assert checksum(testfile) == md5(testfile) == checksum_s('hello!\n') == md5s('hello!\n')
    os.remove(testfile)


# Generated at 2022-06-23 13:55:58.853121
# Unit test for function md5
def test_md5():
    try:
        md5s('Hello')
    except ValueError as e:
        if 'MD5 not available' in str(e):
            return True
        raise e
    return False

# Backwards compat only

# Generated at 2022-06-23 13:56:02.423046
# Unit test for function checksum
def test_checksum():
    sha1_hexdigest = 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    sha1_input = ''
    assert secure_hash_s(sha1_input) == sha1_hexdigest

# Generated at 2022-06-23 13:56:06.934251
# Unit test for function md5s
def test_md5s():
    value = 'hello world'
    basehash = '5eb63bbbe01eeed093cb22bb8f5acdc3'
    hash = md5s(value)
    if hash != basehash:
        raise AssertionError("Invalid md5s hash.  Received %s" % hash)



# Generated at 2022-06-23 13:56:10.773616
# Unit test for function checksum
def test_checksum():
        u = """foo"""
        checksum_s(u) == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
        assert checksum_s(u)
        return checksum_s(u)

# Generated at 2022-06-23 13:56:17.134571
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('The quick brown fox jumps over the lazy dog') == '9e107d9d372bb6826bd81d3542a419d6'
    assert md5s('The quick brown fox jumps over the lazy dog.') == 'e4d909c290d0fb1ca068ffaddf22cbd0'


# Generated at 2022-06-23 13:56:22.344437
# Unit test for function md5s
def test_md5s():
    assert md5s('ANSI') == '83bdb7d019b1698abd7a11c3a9d307f0'
    try:
        md5s(u'ANSI')
    except ValueError:
        pass
    else:
        raise Exception('Failed to detect unicode input to md5s')


# Generated at 2022-06-23 13:56:28.432633
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('/etc/ansible/hosts') == '581e7a58b991d6e274818f3c3b095f96'



# Generated at 2022-06-23 13:56:32.953588
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/passwd') == '8670f9c2d88dfb4770fc1e1487eba6e2a7bbd8cc'
    assert checksum_s('cheese') == '8e845ec7ed1ab6cdd5f5c8d0b2f0b870bad9e655'

# Generated at 2022-06-23 13:56:39.255909
# Unit test for function md5
def test_md5():
    # Returns a md5 hash hex digest of contents
    assert md5s("foobar") == "3858f62230ac3c915f300c664312c63f"
    # Returns a md5 hash hex digest of filename
    assert md5("/usr/bin/argon2") == "a4a4a34c06b53dba32b8ab90b966d2ae"

# Generated at 2022-06-23 13:56:45.112163
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('asdf') == '912ec803b2ce49e4a541068d495ab570'
    else:
        try:
            md5s('asdf')
        except ValueError as e:
            assert 'MD5 not available.  Possibly running in FIPS mode' in str(e)

# Generated at 2022-06-23 13:56:47.579896
# Unit test for function md5
def test_md5():
    filename = "unittest"
    open(filename, 'w').write("Unix")

    assert(secure_hash(filename, _md5) != None)
    assert(checksum(filename) != None)

    os.remove(filename)
    return 0


# Generated at 2022-06-23 13:56:50.550604
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('ABC') == '3c01bdbb26f358bab27f267924aa2c9a03fcfdb8'

# Generated at 2022-06-23 13:56:58.382398
# Unit test for function checksum_s
def test_checksum_s():

    import os
    import tempfile

    # Create a temporary file
    test_file = tempfile.NamedTemporaryFile(delete=False)
    test_file.write('This is just a test\n')
    test_file.close()

    # Test checksum of empty string
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'

    # Test checksum of a test string
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

    # Test checksum of test file
    if not os.path.isfile(test_file.name):
        raise("Unable to locate temporary file for testing")

# Generated at 2022-06-23 13:57:04.791044
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello\n') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-23 13:57:06.617885
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-23 13:57:15.417638
# Unit test for function md5
def test_md5():
    '''
    secure.py: Test md5
    '''

    md5 = md5s("Hello World")
    if md5 != "b10a8db164e0754105b7a99be72e3fe5":
        print("Fail:md5: %s" % md5)
        return False

    fname = "/etc/issue"
    md5 = md5(fname)
    fname = "/nonexistent/file"
    if md5 != "b10a8db164e0754105b7a99be72e3fe5":
        print("Fail:md5: %s" % md5)
        return False

    return True


# Generated at 2022-06-23 13:57:25.005079
# Unit test for function md5
def test_md5():

    # old test cases
    assert md5("/bin/cat") == 'e8ab5928a0c8b503f27a1885cc8b8fd1'

    # For test purposes, create an actual text file,
    # and compute the md5 value of it.
    from tempfile import NamedTemporaryFile
    import sys
    test_string = "0123456789\n"
    expected_md5 = '3c59dc048e8850243be8079a5c74d079'
    f = NamedTemporaryFile(delete=True)
    f.write(test_string)
    f.flush()

# Generated at 2022-06-23 13:57:34.717849
# Unit test for function checksum
def test_checksum():
    import filecmp
    fn1 = open('/tmp/test_sum_1','w')
    fn1.write('Hello')
    fn1.close()
    fn2 = open('/tmp/test_sum_2','w')
    fn2.write('Hello')
    fn2.close()
    assert(checksum('/tmp/test_sum_1') == checksum('/tmp/test_sum_2'))
    fn3 = open('/tmp/test_sum_3','w')
    fn3.write('Hello2')
    fn3.close()
    assert(checksum('/tmp/test_sum_1') != checksum('/tmp/test_sum_3'))
    os.remove('/tmp/test_sum_1')
    os.remove('/tmp/test_sum_2')
   

# Generated at 2022-06-23 13:57:46.295456
# Unit test for function checksum
def test_checksum():
    assert checksum("test/utils/checksum.py") == "9fa2c37b90976d3d0f2c1f8ebf63bccd08b1fbbb"
    assert checksum_s("test") == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"
    assert checksum("/bin/ls") == "690ebc0b78376ea6dee9f86cc1fb9b6d0f6c37e6"
    assert checksum("/bin/ls", "sha256") == "ef6a0c30a05b6f0764bbf4e4a4fc3ec3d0d2a9a8b6c933d3e75f3d2f1b450033"

# Generated at 2022-06-23 13:57:48.622947
# Unit test for function md5s
def test_md5s():
    x = md5s('test test test')
    assert x == '5a105e8b9d40e1329780d62ea2265d8a'

# Generated at 2022-06-23 13:57:55.928684
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s(data='abcd') == 'e2fc714c4727ee9395f324cd2e7f331f'
    assert checksum_s(data='0123456789abcdefghijklmnopqrstuvwxyz') == '38b060a751ac96384cd9327eb1b1e36a21fdb71114be07434c0cc7bf63f6e1da274edebfe76f65fbd51ad2f14898b95b'

# Generated at 2022-06-23 13:57:58.528326
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-23 13:58:04.623748
# Unit test for function md5
def test_md5():
    """
    Generates md5 checksum for the file tests/test-module.py
    """
    file_path = './test/test-module.py'
    test_md5 = '5bf8ef5b6dfc61ead06a85dbcc0f8d99'
    md5_checksum = secure_hash(file_path, _md5)
    assert test_md5 == md5_checksum


# Generated at 2022-06-23 13:58:10.931395
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('Hello world!','sha1') == '7b502c3a1f48c8609ae212cdfb639dee39673f5e'
    assert checksum_s('Hello world!', 'sha256') == 'a591a6d40bf420404a011733cfb7b190d62c65bf0bcda32b57b277d9ad9f146e'

# Generated at 2022-06-23 13:58:18.989114
# Unit test for function checksum_s
def test_checksum_s():

    try:
        from hashlib import sha1
    except ImportError:
        from sha import sha as sha1
    import unittest

    # Unit test checksum_s function
    class TestChecksum_s(unittest.TestCase):
        def test_checksum_s(self):
            '''
            test checksum_s
            '''
            data = 'foobar'
            self.assertEqual(sha1(data.encode("utf-8")).hexdigest(), checksum_s(data))

    unittest.main()

test_checksum_s()

# Generated at 2022-06-23 13:58:20.842951
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

# Generated at 2022-06-23 13:58:23.216568
# Unit test for function md5s
def test_md5s():
    ''' md5s() should return the same result as md5() '''
    filename = __file__
    hashs = md5s(filename)
    hash = md5(filename)
    assert hash == hashs

# Generated at 2022-06-23 13:58:28.832602
# Unit test for function checksum_s
def test_checksum_s():
    ''' test checksum_s which is the function that does the calculation '''

    result = checksum_s('hello world')
    assert result == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'


# Generated at 2022-06-23 13:58:32.986247
# Unit test for function checksum
def test_checksum():
    import sys
    import os
    import mct_ut_cov_01

    pwd = os.getcwd()
    #print("pwd = " + pwd)
    os.chdir("/Users/clkao/work/repo/ansible-playbooks/ansible/")
    #print(checksum('/Users/clkao/work/repo/ansible-playbooks/ansible/README.md'))
    os.chdir(pwd)
    #print(checksum('/Users/clkao/work/repo/ansible-playbooks/ansible/README.md'))


# Generated at 2022-06-23 13:58:40.280051
# Unit test for function checksum
def test_checksum():
    test_file = open('test_checksum.txt', 'w')
    test_file.write('test file\n')
    test_file.close()
    h = checksum('test_checksum.txt')
    assert h == '4b4f4cc2f7dd86a082caed746d700bcfab7ce55f'

    h = checksum_s('test string')
    assert h == '2e99758548972a8e8822ad47fa1017ff72f06f3d'

# Generated at 2022-06-23 13:58:42.980177
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("some data to hash") == "0b1d9f3f5fe0bf79d5b0709fa3be47b7a8b60228"

# Generated at 2022-06-23 13:58:44.755815
# Unit test for function md5s
def test_md5s():
    assert len(md5s('foo')) == 32


# Generated at 2022-06-23 13:58:46.760592
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-23 13:58:54.056622
# Unit test for function checksum
def test_checksum():
    # in the spirit of TDD, this is the first unit test
    assert checksum('README.md') == 'f9e9f67c2a80a5c31b28a0a8d5a104ab88ba1eb5'
    assert checksum_s('1234567890') == 'e807f1fcf82d132f9bb018ca6738a19f'
    assert secure_hash_s(1234567890) == 'e807f1fcf82d132f9bb018ca6738a19f'
    assert checksum_s('hello\n') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-23 13:58:56.951520
# Unit test for function checksum
def test_checksum():
    for i in [b'hello world', u'hello world']:
        assert checksum_s(i) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed', "%r failed" % i


# Generated at 2022-06-23 13:59:01.977431
# Unit test for function checksum
def test_checksum():
    checksum_file = "test/ansible/utils/checksum_file"
    checksum_file_wc = "test/ansible/utils/checksum_file_wc"
    checksum_file_no_exist = "test/ansible/utils/checksum_file_no_exist"
    checksum_file_no_exist2 = "test/ansible/utils/checksum_file_no_exist2"
    checksum_file_directory = "test/ansible/utils/"
    checksum_s_str = """test for checksum_s
with multiple lines"""
    checksum_value = "54b13a8bf7c2e78cb91d35e3e9eb0f10a9f1d00c"

# Generated at 2022-06-23 13:59:05.040121
# Unit test for function md5
def test_md5():
    print("Testing md5, size of md5 is %d" % len(md5("/etc/hosts")))


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 13:59:08.506047
# Unit test for function md5s
def test_md5s():
    # test if md5s is working correctly.

    string = 'hello world'
    assert md5s(string) == '5eb63bbbe01eeed093cb22bb8f5acdc3', 'md5s() failed to generate the correct value.'


# Generated at 2022-06-23 13:59:14.512899
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("Hello") == "8b1a9953c4611296a827abf8c47804d7"
    assert md5s("HELLO") == "9e107d9d372bb6826bd81d3542a419d6"

# Generated at 2022-06-23 13:59:21.712310
# Unit test for function md5
def test_md5():
    import tempfile
    test_data = '''
    There once was a young fellow named Hall
    Who fell in the spring in the fall.
    '''
    try:
        (fd, test_filename) = tempfile.mkstemp()
        f = os.fdopen(fd, "w")
        f.write(test_data)
        f.close()
        if md5(test_filename) != 'e831b9a08df9d9103c274789d17797d0':
            raise AssertionError()
        os.unlink(test_filename)

    except:
        raise

# Generated at 2022-06-23 13:59:26.542873
# Unit test for function checksum
def test_checksum():
    file_content = 'test'

    from tempfile import NamedTemporaryFile
    with NamedTemporaryFile(delete=True) as temp_file:
        temp_file.write(file_content)
        temp_file.flush()
        assert checksum(temp_file.name) == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'


if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-23 13:59:35.465246
# Unit test for function md5s
def test_md5s():
    assert md5s(b'') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(b'a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s(b'abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s(b'The quick brown fox jumps over the lazy dog') == '9e107d9d372bb6826bd81d3542a419d6'
    assert md5s('123') == '202cb962ac59075b964b07152d234b70'

# Generated at 2022-06-23 13:59:42.707105
# Unit test for function md5s
def test_md5s():
    print('md5s test')
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    # check default string
    if md5s('test') != '098f6bcd4621d373cade4e832627b4f6':
        return False

    # check unicode string
    if md5s(u'test') != '098f6bcd4621d373cade4e832627b4f6':
        return False

    return True



# Generated at 2022-06-23 13:59:48.238783
# Unit test for function md5
def test_md5():
    current = os.path.dirname(os.path.realpath(__file__))
    filename = os.path.join(current, 'hashes.py')
    # starting with ansible 2.8, md5 usage is deprecated
    md5_hash = md5(filename)
    assert md5_hash == '4564c27732a2ab6f9b6f4cc6c4126bac'

# Generated at 2022-06-23 13:59:52.371623
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'



# Generated at 2022-06-23 13:59:58.857333
# Unit test for function md5s
def test_md5s():
    ''' test_md5s '''
    import unittest
    class TestMd5s(unittest.TestCase):
        ''' test md5s '''
        def test_md5s(self):
            ''' md5s '''
            self.assertTrue(md5s('hello') == '5d41402abc4b2a76b9719d911017c592')
            self.assertTrue(md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592')
            self.assertTrue(md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592')

# Generated at 2022-06-23 14:00:04.449360
# Unit test for function checksum_s
def test_checksum_s():
    ''' returns True if the checksum of the two strings are the same '''
    check_sum = checksum_s('ansible')
    return check_sum == '3a2f812ae4a4d4cf4c68fb4a8a9800d251b6db0d'

# Generated at 2022-06-23 14:00:08.870858
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('hi') == '49f68a5c8493ec2c0bf489821c21fc3b'

# Generated at 2022-06-23 14:00:14.422767
# Unit test for function md5
def test_md5():
    data = "Hello World"
    digest = md5s(data)
    assert digest == 'b10a8db164e0754105b7a99be72e3fe5', \
        "%s: %s" % (digest, repr(digest))

    data = "Hello World"
    digest = secure_hash_s(data)
    assert digest == '2ef7bde608ce5404e97d5f042f95f89f1c232871', \
        "%s: %s" % (digest, repr(digest))


# Generated at 2022-06-23 14:00:15.593977
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("123") == "40bd001563085fc35165329ea1ff5c5ecbdbbeef"

# Generated at 2022-06-23 14:00:20.162054
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s(u'test') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-23 14:00:26.945380
# Unit test for function checksum
def test_checksum():
    '''
    ansible checksum - test module
    This test the checksum functions in ansible/utils/__init__.py
    '''

    from ansible.utils.__init__ import checksum

    import os
    import shutil
    import tempfile

    parent_dir = os.getcwd()
    test_dir = tempfile.mkdtemp(dir=parent_dir)

    # Test empty file
    test_file_1 = "empty_file"
    test_file_path_1 = os.path.join(test_dir, test_file_1)
    open(test_file_path_1, 'a').close()

# Generated at 2022-06-23 14:00:33.204081
# Unit test for function checksum
def test_checksum():
    '''
    This is a simple unit test to verify the functionality of checksum.
    '''
    import tempfile
    import shutil
    import stat

    class AnsibleModule:
        def fail_json(self, **kwargs):
            pass

    class AnsibleFile:

        def __init__(self, module):
            self.module = module

        def exists(self):
            pass

        def read_file(self, filename):
            with open(filename) as f:
                return f.read()

        def write_file(self, filename, data):
            with open(filename, 'w') as f:
                f.write(data)

        def remove_file(self, filename):
            os.remove(filename)

    class AnsibleModuleException(Exception):
        pass


# Generated at 2022-06-23 14:00:38.173261
# Unit test for function md5s
def test_md5s():
    # correct result generated via: python -c "import hashlib, binascii; print binascii.hexlify(hashlib.md5('hello').digest())"
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-23 14:00:44.851367
# Unit test for function md5s
def test_md5s():
    import time
    import tempfile

    filename = tempfile.mktemp()

    try:
        start = time.time()
        md5s1 = md5s('abc' + str(start))
        md5s2 = md5s('abc' + str(start))
        print("md5s1: %s" % md5s1)
        print("md5s2: %s" % md5s2)
        assert md5s1 == md5s2
    finally:
        os.unlink(filename)

# Generated at 2022-06-23 14:00:55.512671
# Unit test for function md5
def test_md5():
    import os
    import sys
    from ansible.module_utils._text import to_bytes
    from shutil import rmtree

    tests = [
        # test file
        ("md5/testfile", "d41d8cd98f00b204e9800998ecf8427e"),
        # test directory
        ("md5/testdir", None),
        # test symlink
        ("md5/testsymlink", "d41d8cd98f00b204e9800998ecf8427e")
    ]

    dirname = os.path.abspath(os.path.dirname(__file__))
    test_path = os.path.join(dirname, "md5")
    if not os.path.exists(test_path):
        os.mkdir(test_path)


# Generated at 2022-06-23 14:01:00.935729
# Unit test for function md5
def test_md5():
    # Create a file and ensure that the md5 is sane
    import tempfile
    (fd, fname) = tempfile.mkstemp()

    test_string = "Hello World"
    os.write(fd, test_string)
    os.close(fd)
    assert md5(fname) == "ed076287532e86365e841e92bfc50d8c"

    # Cleanup
    os.unlink(fname)

# Generated at 2022-06-23 14:01:08.991337
# Unit test for function md5s
def test_md5s():
    # Test ASCII
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

    # Test bytestring
    assert md5s(b'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

    # Test unicode string
    assert md5s(u'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

    # Test empty string
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'

    # Test None
    try:
        test = md5s(None)
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-23 14:01:14.946778
# Unit test for function checksum
def test_checksum():
    assert checksum('test/files/changelog') == 'a6a2711e16d7f8ba9dba2f2aa9a158a231d8a1c2'
    assert checksum('test/files/does_not_exist') == None
    assert checksum('test/files') == None


# Generated at 2022-06-23 14:01:22.190437
# Unit test for function checksum
def test_checksum():
    '''
    Fetch the checksum of file created in test/checksum/data
    '''

    data_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
        'test',
        'test_module_utils',
        'checksum',
    )
    file_path = os.path.join(data_dir, 'data')

    return checksum(file_path)



# Generated at 2022-06-23 14:01:24.366708
# Unit test for function md5s
def test_md5s():
    assert 'e81519b2f0c1fcffafbbc09b4c4e4cb4' == md5s("test case")

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 14:01:27.446978
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"
    else:
        try:
            md5s("foo")
            assert False, "Expected md5s to fail"
        except ValueError:
            pass

# Generated at 2022-06-23 14:01:36.815239
# Unit test for function md5
def test_md5():
    import tempfile

    test_data = "abcdefghijklmnopqrstuvwxyz"

    # Create a temp file
    (fd, path) = tempfile.mkstemp()
    file_object = os.fdopen(fd, 'w+b')
    file_object.write(test_data)
    file_object.close()

    # Calculate the MD5 for it
    md5_hasher = md5(path)

    # Remove the temp file
    os.unlink(path)

    # Compare
    if md5_hasher != "c3fcd3d76192e4007dfb496cca67e13b":
        return False
    else:
        return True



# Generated at 2022-06-23 14:01:39.789734
# Unit test for function md5
def test_md5():
    assert md5s('file1') == 'e41d8cd98f00b204e9800998ecf8427e'
    assert md5('/bin/ls') == '0cb6948805f797bf2a82807973b89537'

# Generated at 2022-06-23 14:01:42.853095
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('blah') == 'd35e3acf10cf0da1d461112ceb61948b6bc08b6c'

# Generated at 2022-06-23 14:01:53.363538
# Unit test for function md5s
def test_md5s():
    # md5s return value depends on the system localization
    # So, in order to make the test working we need to know the return value
    # (which depends on the system we run the tests on).
    import locale
    import platform
    import subprocess
    system = platform.system()
    if system == 'Linux':
        command = 'locale | grep LANG'
    elif system == 'Darwin':
        command = 'locale | grep LANG'
    elif system == 'Windows':
        command = 'chcp.com'
    else:
        return 0
    try:
        process = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
    except Exception as e:
        print('Unable to determine system localization. Error: %s' % e)
        return 0
    std

# Generated at 2022-06-23 14:01:58.028893
# Unit test for function checksum_s
def test_checksum_s():
    sum_value = secure_hash_s("hello world")
    assert sum_value == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed', \
        'secure_hash_s function returned an incorrect value'

# Generated at 2022-06-23 14:02:07.779694
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s('test') != 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3':
        raise ValueError("Invalid checksum_s result")
    if checksum_s('test', _md5) != '098f6bcd4621d373cade4e832627b4f6':
        raise ValueError("Invalid checksum_s result")
    if checksum_s('') != 'da39a3ee5e6b4b0d3255bfef95601890afd80709':
        raise ValueError("Invalid checksum_s result")
    if checksum_s('', _md5) != 'd41d8cd98f00b204e9800998ecf8427e':
        raise ValueError("Invalid checksum_s result")

# Generated at 2022-06-23 14:02:11.452500
# Unit test for function md5
def test_md5():
    test_string = 'It was a bright cold day in April, and the clocks were striking thirteen.'
    test_digest = 'b494e97d25aa7c9e9c51f68e344f8dcf'
    assert test_digest == md5s(test_string)

# Generated at 2022-06-23 14:02:18.414759
# Unit test for function md5
def test_md5():
    # create a dummy file on the fly
    import tempfile
    f = tempfile.NamedTemporaryFile(delete=True)
    f.write("hello hash world")
    f.flush()
    os.fsync(f.fileno())

    x = md5(f.name)
    assert to_bytes(x) == "c8ea8f6a77775db5f7b5e9d8ad2c5d5c"
    f.close()

# Generated at 2022-06-23 14:02:22.830158
# Unit test for function checksum
def test_checksum():
    from io import BytesIO

    data = b'some text to be passed on'
    with BytesIO(data) as buff:
        result = secure_hash(buff)

    assert result == 'e86d19a1c9a9f838c9caa224cf024d13b1824f07'

# Generated at 2022-06-23 14:02:27.301165
# Unit test for function checksum_s
def test_checksum_s():
    ''' test checksum_s '''
    assert checksum_s("foobar") == "8843d7f92416211de9ebb963ff4ce28125932878"

# Generated at 2022-06-23 14:02:32.245439
# Unit test for function checksum
def test_checksum():
    good_checksums = {
        'good_1': ("f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0", "example.ini"),
        'good_2': ("b1946ac92492d2347c6235b4d2611184", "example.ini"),
        'good_3': ("d41d8cd98f00b204e9800998ecf8427e", "empty"),
    }
    for k, v in good_checksums.items():
        if checksum(v[1]) != v[0]:
            raise AssertionError('md5sum failed for checksum test file (%s)' % k)
    test_file = 'not_exists'

# Generated at 2022-06-23 14:02:36.296533
# Unit test for function checksum_s
def test_checksum_s():
    # Make sure we're on Python 2.4
    import sys
    if sys.version_info[1] < 4:
        from nose.plugins.skip import SkipTest
        raise SkipTest("secure_hash_s() test requires Python >= 2.4")

    if secure_hash_s('hello') == '5d41402abc4b2a76b9719d911017c592':
        raise Exception("secure_hash_s() test failed")

# Generated at 2022-06-23 14:02:43.553926
# Unit test for function checksum
def test_checksum():
    # Create a new file and write some data
    fd, fname = tempfile.mkstemp()
    os.write(fd, b"Hello World!")
    os.close(fd)

    # Calculate the checksum
    cs = checksum(fname)

    # Now remove the file and test if the checksum equals
    os.remove(fname)
    assert cs == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"

# Generated at 2022-06-23 14:02:54.428826
# Unit test for function checksum_s
def test_checksum_s():
    from ansible.module_utils.basic import get_exception
    assert checksum_s('teststring') == 'f9c3c81e5c5caadb5f5a5d3a49a8c1f37baf45ac'
    try:
        checksum_s('')
        assert False, "should have thrown an exception"
    except AnsibleError as e:
        assert "parameter must be string" in str(e)
    try:
        checksum_s(None)
        assert False, "should have thrown an exception"
    except AnsibleError as e:
        assert "parameter must be string" in str(e)

# Generated at 2022-06-23 14:03:03.795198
# Unit test for function checksum
def test_checksum():
    test_path = os.path.join(os.path.dirname(__file__), '../../test/utils/checksum')
    assert(checksum(os.path.join(test_path, 'test1')) == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0')
    assert(checksum(os.path.join(test_path,'test2')) == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33')
    assert(checksum(os.path.join(test_path, 'does_not_exist')) == None)

# Generated at 2022-06-23 14:03:06.472784
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return
    assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"


# Generated at 2022-06-23 14:03:12.319671
# Unit test for function md5s
def test_md5s():
    if _md5:
        # Check if md5s is producing a string of length 32
        assert len(md5s('test data')) == 32
        # Check if md5s produces the same output as md5
        assert md5s('test data') == '7f2c8e9fa02fe56f4b4a7d114a8bf8f7'
    else:
        try:
            md5s('test data')
        except ValueError as e:
            assert "not available" in str(e)


# Generated at 2022-06-23 14:03:16.885027
# Unit test for function md5s
def test_md5s():
    test_string = "Hello World"
    returned_string = md5s(test_string)
    assert returned_string == "b10a8db164e0754105b7a99be72e3fe5"


# Generated at 2022-06-23 14:03:25.875778
# Unit test for function md5s
def test_md5s():
    md5_test_string_1 = "string1"
    md5_test_string_2 = "string2"

    # Test expected functionality
    m1 = md5s(md5_test_string_1)
    m2 = md5s(md5_test_string_2)

    # Test hashes are different and not both empty
    assert m1 != m2
    assert m1 != ""
    assert m2 != ""

    # Test different hash types
    assert md5s(md5_test_string_1) == md5s(md5_test_string_1)
    assert md5s(md5_test_string_1) != checksum_s(md5_test_string_1)



# Generated at 2022-06-23 14:03:30.050580
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foobar') == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert checksum_s('foo\nbar') == '5c5fe5d5c5ca5ab5cebb947d5cfa792b79a2e428'


# Generated at 2022-06-23 14:03:32.165134
# Unit test for function md5s
def test_md5s():
    print(md5s("hello world"))
    print(md5s("hello world"))
    print(md5s("hello world"))
    print(md5s("hello world"))

# Generated at 2022-06-23 14:03:43.838471
# Unit test for function checksum
def test_checksum():
    import tempfile
    test_string = 'test string'
    result = checksum_s(test_string)
    assert result == '3a7bd3e2360a3d29eea436fcfb7e44c735d117c42d1c1835420b6b9942dd4f1b'

    test_file = tempfile.mktemp()
    with open(test_file, 'wb') as f:
        f.write(test_string)
    result = checksum(test_file)
    assert result == '3a7bd3e2360a3d29eea436fcfb7e44c735d117c42d1c1835420b6b9942dd4f1b'
    os.remove(test_file)



# Generated at 2022-06-23 14:03:50.494761
# Unit test for function md5
def test_md5():
    data = 'This is some text that can be MD5ed'
    result = md5s(data)
    assert result == '7eef2cab24d760965643960e1a6c9db3'
    result = md5(__file__)
    assert result == '7d2fb2a2030cf0a9c9b4e4c2a4a8f25c'


# Generated at 2022-06-23 14:03:57.882398
# Unit test for function md5
def test_md5():
    '''
    This will test the md5 function's ability to return the expected values
    when called with the filenames provided
    '''
    md5_dict = {}
    md5_dict['sample_files/file1.txt'] = '3c9a7f06d47d0a7b30a2f813b1d892e2'
    md5_dict['sample_files/file2.txt'] = '4f4c4a1f89386384b92efb6ec9b6cb76'
    for file, expected_md5 in md5_dict.items():
        actual_md5 = md5(file)