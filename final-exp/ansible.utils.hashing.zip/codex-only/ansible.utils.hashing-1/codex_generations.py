

# Generated at 2022-06-23 13:54:09.344142
# Unit test for function md5s
def test_md5s():
    class md5:
        def __init__(self):
            pass

        def update(self, val):
            pass

        def hexdigest(self):
            return 'd41d8cd98f00b204e9800998ecf8427e'

    #f = open('/tmp/text2.txt', 'r+')
    #data = f.read()
    #print data
    #md5sum = md5()
    #md5sum.update(data)
    #print md5sum.hexdigest()
    data = ''
    assert md5s(data) == 'd41d8cd98f00b204e9800998ecf8427e'



# Generated at 2022-06-23 13:54:20.750329
# Unit test for function checksum
def test_checksum():
    import os
    import tempfile
    import shutil


# Generated at 2022-06-23 13:54:25.576317
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s("hopefully this will change") == "d6d64e8c3f3d3abe3cecb512d94ea834"



# Generated at 2022-06-23 13:54:35.451780
# Unit test for function md5
def test_md5():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('\x00') == '93b885adfe0da089cdf634904fd59f71'
    assert md5s('\x00\x00') == '3e7cd8f5b1a264c5a5d3e7e8c5febccc'
    assert md5s('\x00\x00\x00') == 'bccd7b8f5b40aec6bf9b6fc1a0c8edf2'

# Generated at 2022-06-23 13:54:40.210418
# Unit test for function md5
def test_md5():
    import tempfile

    fd, path = tempfile.mkstemp()
    os.close(fd)
    assert md5(path) is None
    fd = open(path, 'w')
    fd.write('This is a test')
    fd.close()
    assert md5(path) == md5s('This is a test')
    os.unlink(path)

# Generated at 2022-06-23 13:54:49.202224
# Unit test for function checksum
def test_checksum():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import tempfile
    import os
    import shutil

    class TestChecksum(unittest.TestCase):
        def setUp(self):
            ''' Create test directory '''
            self.test_dir = tempfile.mkdtemp()

        def tearDown(self):
            ''' Remove test directory '''
            shutil.rmtree(self.test_dir)

        def test_file_not_exist(self):
            ''' Test checksum with non-existent file '''
            sum = checksum(os.path.join(self.test_dir, 'not_exist'))
            self.assertEqual(sum, None)


# Generated at 2022-06-23 13:54:54.747832
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    assert(md5s('') == 'd41d8cd98f00b204e9800998ecf8427e')
    assert(md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3')



# Generated at 2022-06-23 13:55:03.772335
# Unit test for function checksum_s
def test_checksum_s():
    """
    Test checksum_s for two strings and the same string twice.
    """
    if checksum_s("test") != "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3":
        return False

    if checksum_s("test2") != "f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0":
        return False

    if checksum_s("test") != "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3":
        return False

    return True

# Generated at 2022-06-23 13:55:12.709247
# Unit test for function checksum
def test_checksum():
    ''' test_checksum() - basic checksum tests '''
    import tempfile
    testfile = tempfile.NamedTemporaryFile(delete=False)
    testfile.write(b"This is a test of this hash function")
    testfile.close()
    full_checksum = secure_hash(testfile.name)
    open(testfile.name, "wb").write(b'This is a test of ')
    os.remove(testfile.name)
    assert full_checksum != secure_hash(testfile.name)

# Generated at 2022-06-23 13:55:16.595847
# Unit test for function md5s
def test_md5s():
    data = "abcd"
    assert md5s(data) == md5s(data)
    assert md5s(data) == "e2fc714c4727ee9395f324cd2e7f331f"


# Generated at 2022-06-23 13:55:21.653467
# Unit test for function checksum_s
def test_checksum_s():
    import unittest
    import random
    import string
    import sys

    if sys.version_info >= (2, 7):
        random_string = lambda length: ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(length))
    else:
        random_string = lambda length: ''.join(random.choice(string.letters + string.digits) for _ in range(length))

    class TestChecksumS(unittest.TestCase):
        def setUp(self):
            self.string = 'string'
            self.string_len = len(self.string)
            self.string_hash = 'b6129cdf1e0bcf8f27b29d52fe0cb4e4e4f11b2f'
            self.binary

# Generated at 2022-06-23 13:55:28.789905
# Unit test for function md5s
def test_md5s():
    import sys
    if sys.version_info >= (2, 5):
        assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"
    else:
        assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"



# Generated at 2022-06-23 13:55:31.655044
# Unit test for function md5
def test_md5():
  ret=secure_hash("/etc/passwd", _md5)
  assert(ret == "c232556d3e3b0f33b15e99ebcec69d8f")


# Generated at 2022-06-23 13:55:40.092831
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(None) == '93b885adfe0da089cdf634904fd59f71'
    assert md5s('ansible') == 'b858cb282617fb0956d960215c8e84d1'
    assert md5s(b'ansible') == 'b858cb282617fb0956d960215c8e84d1'

if __name__ == '__main__':
    import sys
    print("MD5 checksum of %s is %s" % (sys.argv[1], md5(sys.argv[1])))

# Generated at 2022-06-23 13:55:49.737453
# Unit test for function checksum
def test_checksum():
    assert secure_hash_s('helloworld') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('helloworld') == secure_hash_s('helloworld')
    assert secure_hash('/etc/hostname') == '0fe7d5f5c07f7ccc02f4729b0e5e5196'
    assert checksum('/etc/hostname') == secure_hash('/etc/hostname')
    assert secure_hash('/etc/hostname', _md5) == '3cacf578813183a3efa84f2f456a8cdd'



# Generated at 2022-06-23 13:55:52.384451
# Unit test for function md5s
def test_md5s():
    import sys
    if sys.version_info < (2, 5):
        return
    import hashlib
    s = md5s('test')
    assert s == hashlib.md5('test').hexdigest()


# Generated at 2022-06-23 13:55:56.040017
# Unit test for function checksum
def test_checksum():
    x = checksum(filename=os.path.dirname(__file__) + "/../../lib/ansible/modules/core/system/ping.py")
    assert x == "2cd6bd3d98dc5f38cd33b28c2909f0e12a2e1c9c"



# Generated at 2022-06-23 13:56:06.060147
# Unit test for function checksum
def test_checksum():
    assert checksum("filename") == "da39a3ee5e6b4b0d3255bfef95601890afd80709"
    assert checksum("does/not/exist") == None
    assert checksum("test/test.py") == "76d7b6d3b0cae773eafe3768eb7e2f2f"
    assert checksum("test/test.txt") == "d84e7c8e2ab149132a50e3360fd7ae7f"
    assert checksum("test/test.pyc") == "8ce98e5e5c5aeafd5d5bd5b2c5c5feac"

# Generated at 2022-06-23 13:56:08.981587
# Unit test for function checksum
def test_checksum():
    assert checksum('../test/sanity/ping/ping.yml') == '3950c8dd68e0df1c80170e9a7f8c5d96e7a2a5f5'

# Generated at 2022-06-23 13:56:13.235429
# Unit test for function checksum_s
def test_checksum_s():
    '''Function checksum_s'''
    s = 'hello'
    result = checksum_s(s)
    assert (result == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d')


# Generated at 2022-06-23 13:56:15.626297
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hi') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'


# Generated at 2022-06-23 13:56:21.044602
# Unit test for function md5s
def test_md5s():
    ''' md5s() Unit test'''
    test_string = 'The quick brown fox jumps over the lazy dog'
    test_md5s_output = md5s(test_string)
    assert test_md5s_output == '9e107d9d372bb6826bd81d3542a419d6'



# Generated at 2022-06-23 13:56:26.854216
# Unit test for function checksum_s
def test_checksum_s():

    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s('test', hash_func=_md5) == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-23 13:56:33.430138
# Unit test for function checksum_s
def test_checksum_s():

    data = 'hello world'
    expectedHash = '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    hash = checksum_s(data)
    if hash != expectedHash:
        raise Exception("error computing checksum for data, expected %s and got %s" % (expectedHash, hash))

if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-23 13:56:38.402704
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("abc") == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum_s("abc", _md5) == '900150983cd24fb0d6963f7d28e17f72'



# Generated at 2022-06-23 13:56:41.404449
# Unit test for function md5
def test_md5():
    if not _md5:
        return True
    else:
        return False


# Generated at 2022-06-23 13:56:47.993534
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("The quick brown fox jumps over the lazy dog") == "2fd4e1c67a2d28fced849ee1bb76e7391b93eb12"
    assert checksum_s("Hello World!") == "0a4d55a8d778e5022fab701977c5d840bbc486d0"
    assert checksum_s("") == "da39a3ee5e6b4b0d3255bfef95601890afd80709"


# Generated at 2022-06-23 13:56:52.642976
# Unit test for function checksum
def test_checksum():
    assert checksum("foobar") == "8843d7f92416211de9ebb963ff4ce28125932878"
    assert checksum_s("foobar") == "8843d7f92416211de9ebb963ff4ce28125932878"

# Generated at 2022-06-23 13:57:01.978286
# Unit test for function md5s
def test_md5s():
    assert md5s("test") == "098f6bcd4621d373cade4e832627b4f6"
    assert md5s("test\n") == "476c86e6c68502a2bc59bc7f998e0e75"
    assert md5s("test\r\n") == "f7ff9e8b7bb2e09b70935a5d785e0cc5"
    assert md5s('a' * 2**16) == "32bd0a6f10265c4d629e4bfba0f07e0e"
    assert md5s('a' * 2**20) == "c6a6064d25281151a91a6e9f9e038dbc"

# Generated at 2022-06-23 13:57:05.531279
# Unit test for function md5s
def test_md5s():
    # make sure we return the same value on different platforms
    assert (md5s(b'123') == '202cb962ac59075b964b07152d234b70')


# Generated at 2022-06-23 13:57:13.078568
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s(b'test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s(u'test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'


# Generated at 2022-06-23 13:57:17.221740
# Unit test for function checksum_s
def test_checksum_s():
    data = 'foo'
    assert checksum_s(data) == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'


# Generated at 2022-06-23 13:57:26.783571
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return
    assert md5s("this is a long string") == "bf8885b3971ed64b7e0536ce60cfb7f0"
    assert md5s("thisisanotherlongstring") == "a936d2f6a1d76e899f638f82c8c7d51a"
    assert md5s("") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5s("veryshort") == "814c86b6e2f636a1e3a8407d5fe6fb96"
    assert md5s("A" * 128) == "a1a769aa6f829d7a7538fc1c9d9b9e93"
    assert md5

# Generated at 2022-06-23 13:57:31.912481
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
        assert md5s('bye world') != '5eb63bbbe01eeed093cb22bb8f5acdc3'



# Generated at 2022-06-23 13:57:34.530176
# Unit test for function md5s
def test_md5s():
    string = to_bytes('test')
    returned = md5s(string)
    expected = '098f6bcd4621d373cade4e832627b4f6'
    assert returned == expected



# Generated at 2022-06-23 13:57:38.366024
# Unit test for function md5s
def test_md5s():
    data = 'junk data'
    result = md5s(data)
    assert result == '01471887fb75c7d673811e1e7d1d00cc'

# Generated at 2022-06-23 13:57:40.750795
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('this is a string', sha1) == 'b973040d2bdeeb365aefa1a33517bedc05f34c7b'


# Generated at 2022-06-23 13:57:44.948898
# Unit test for function checksum
def test_checksum():
    assert checksum(__file__) == 'ff4842f8e07c64d0b131c6c79ce6a0d6c3df6bf1'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-23 13:57:47.773214
# Unit test for function md5s
def test_md5s():
    if _md5:
        md5_valid = md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
        assert md5_valid

# Generated at 2022-06-23 13:57:53.433754
# Unit test for function checksum
def test_checksum():
    assert secure_hash('/etc/passwd') == secure_hash('/etc/group')
    assert secure_hash('/etc/passwd', _md5) == secure_hash('/etc/group', _md5)

    assert secure_hash_s('hello world') == secure_hash_s('hello world')
    assert secure_hash_s('hello world', _md5) == secure_hash_s('hello world', _md5)
    assert secure_hash_s('hello world', _md5) != secure_hash_s('hello world')

# Generated at 2022-06-23 13:58:04.746302
# Unit test for function checksum_s
def test_checksum_s():
    import unittest

    def hexdigest_is_expected(self, data, expected):
        self.assertEqual(checksum_s(data), expected)


# Generated at 2022-06-23 13:58:16.258743
# Unit test for function checksum
def test_checksum():
    """
    Tests for both checksum and checksum_s.
    """

    TEST_DATA = [
        {'data': 'foo', 'expected_hash': '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'},
        {'data': 'foo\x00', 'expected_hash': 'd41d8cd98f00b204e9800998ecf8427e'},
        {'data': '', 'expected_hash': 'da39a3ee5e6b4b0d3255bfef95601890afd80709'}
    ]

    for t in TEST_DATA:
        assert checksum_s(t['data']) == t['expected_hash']


# Generated at 2022-06-23 13:58:23.217630
# Unit test for function checksum
def test_checksum():
    words = [b"abc", b"def", b"ghi", b"jkl", b"mno", b"pqr", b"stu", b"vwx", b"yz"]
    test = b""
    for word in words:
       test = test + word

    assert checksum_s(test) == "b0126f38b6523a2a17b0fba2409d306c7c1e1c9d"
    assert checksum(__file__) == "b0126f38b6523a2a17b0fba2409d306c7c1e1c9d"

# Generated at 2022-06-23 13:58:33.229666
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  verify the checksum function '''

    import tempfile
    import shutil

    tfile = tempfile.mktemp()
    src = 'hello world'
    f = open(tfile, 'w')
    f.write(src)
    f.close()

    csum_value = checksum(tfile)
    csum_src = checksum_s(src)

    assert csum_value == csum_src

    # cleanup
    os.remove(tfile)


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 13:58:36.261127
# Unit test for function md5
def test_md5():
    # This needs to be in a separate function, otherwise
    # py3 will complain about checksum not being defined.
    assert md5("/etc/passwd") == checksum("/etc/passwd")

# Generated at 2022-06-23 13:58:40.408827
# Unit test for function md5s
def test_md5s():
    test_data = [ "Testing md5s" ]
    for i in test_data:
        assert md5s(i) == "5c5d5fa23ced2e5e9b902a79c8c8b2c1"
    return True


# Generated at 2022-06-23 13:58:45.881308
# Unit test for function checksum_s
def test_checksum_s():
    assert('e3a5d8d0c417471ce7363a89c73fa8e8d761d2b7' == secure_hash_s(b'hello world\n'))
    assert('1a79a4d60de6718e8e5b326e338ae533cd5e5ca3' == secure_hash_s(b'hello world'))

# Generated at 2022-06-23 13:58:53.544082
# Unit test for function checksum_s
def test_checksum_s():
    # Test using a string
    test_str = "this is a test"
    ret_str = secure_hash_s(to_bytes(test_str, errors='surrogate_or_strict'))
    assert ret_str == "9ea7f30d82aa93f7f1382d598912a038b8e16607",\
        "returned string did not match expected checksum"
    # Test using a number
    test_num = 123456
    ret_num = secure_hash_s(to_bytes(test_num, errors='strict'))
    assert ret_num == "0545d2e9f91b12f7539e10e7b02fcf84a6a295a8",\
        "returned number did not match expected checksum"
    # Test using an unicode

# Generated at 2022-06-23 13:58:59.414720
# Unit test for function md5s
def test_md5s():
    # The function 'md5s' is used in ansible/module_utils/basic.py
    # which can be tested in test/integration/targets/module_utils/test_basic.py
    # b/c it's used in sevral testcases.
    pass


# Generated at 2022-06-23 13:59:01.778541
# Unit test for function md5s
def test_md5s():
    assert (md5s('a test string') == '084e0343a0486ff05530df6c705c8bb4')



# Generated at 2022-06-23 13:59:11.107870
# Unit test for function checksum
def test_checksum():
    import tempfile

    # setup
    testdata1 = "abc"
    testdata2 = "def"
    expected_value = "da39a3ee5e6b4b0d3255bfef95601890afd80709"
    # create a temporary file with test data
    (tmp_fd, tmp_fname) = tempfile.mkstemp()
    with os.fdopen(tmp_fd, 'w') as tmp_file:
        tmp_file.write(testdata2)
        tmp_file.close()

    # run
    r1 = checksum_s(testdata1)
    r2 = checksum_s(testdata1 + testdata2)
    r3 = checksum(tmp_fname)

    # cleanup
    os.remove(tmp_fname)

    # verify

# Generated at 2022-06-23 13:59:14.864870
# Unit test for function checksum_s
def test_checksum_s():
    expected = 'ed076287532e86365e841e92bfc50d8c'
    assert secure_hash_s('hello world') == expected, 'secure_hash_s failed.'


if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-23 13:59:19.683532
# Unit test for function checksum
def test_checksum():
    if not os.path.exists('./test_file'):
        with open('./test_file', 'w') as f:
            f.write('test1\n')
    assert checksum('./test_file') == 'f90f8c79686f57d4e4e4d0f23df0de3a9fe34b49'
    os.remove('./test_file')



# Generated at 2022-06-23 13:59:21.628225
# Unit test for function checksum_s
def test_checksum_s():
    data = 'string'
    digest = secure_hash_s(data)
    assert type(digest) == str
    assert len(digest) == 40

# Generated at 2022-06-23 13:59:29.159461
# Unit test for function checksum
def test_checksum():
    '''
    ansible md5 checksum - 1.3
    '''
    from ansible.module_utils import basic
    import os

    if not os.path.exists('./utils/checksum_test.txt'):
        print("Test skipped, file not found")
        exit(0)

    print("ansible md5 checksum - 1.3")
    arguments = {'src': './utils/checksum_test.txt'}
    checksum_results = basic.AnsibleModule(argument_spec=dict()).run_command('checksum', module_args=arguments)

    if checksum_results[1] == 'a05e9d9c84149e8cab75ef6ebba258ce':
        print(True)
    else:
        print(False)



# Generated at 2022-06-23 13:59:35.430923
# Unit test for function checksum
def test_checksum():
    import tempfile

    test_file = tempfile.NamedTemporaryFile(delete=False)
    test_file.write("Testing checksum\n")
    test_file.close()
    test_sha1 = checksum(test_file.name)

    assert test_sha1 == 'b858cb282617fb0956d960215c8e84d1ccf909c6'
    os.unlink(test_file.name)

# Generated at 2022-06-23 13:59:39.201076
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_s('adam') == '1f8231e27a7cb94f48c9fc7f8fe843d08c1220d5'

# Generated at 2022-06-23 13:59:43.306446
# Unit test for function checksum_s
def test_checksum_s():
    s = 'foobar'
    assert checksum_s(s) == '8843d7f92416211de9ebb963ff4ce28125932878'



# Generated at 2022-06-23 13:59:53.457476
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os
    from ansible.utils.path import makedirs_safe

    tmpdir = tempfile.mkdtemp(prefix='ansible_test_checksum')

    # Create a directory, a file and a link
    makedirs_safe(tmpdir + "/dir")
    fh = open(tmpdir + "/dir/file", 'w')
    fh.write('abc')
    fh.close()
    os.symlink('dir/file', tmpdir + "/link")

    # Test with non existing files
    assert checksum(tmpdir + "/not_existing") is None
    assert checksum(tmpdir + "/not_existing/not_existing") is None

    # Test for regular files

# Generated at 2022-06-23 13:59:55.890564
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-23 13:59:57.021034
# Unit test for function md5
def test_md5():
    assert md5("/tmp/doesnotexist") is None
    assert md5("/tmp") is None


# Generated at 2022-06-23 14:00:02.231744
# Unit test for function checksum
def test_checksum():
    md5_test_input = 'The quick brown fox jumped over the lazy dog'
    md5_test_input_hash = '9e107d9d372bb6826bd81d3542a419d6'
    sha1_test_input_hash = '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12'
    test_input_file = 'test/unittest_data/checksum_file'
    sha1_test_file_hash = '37b51d194a7513e45b56f6524f2d51f2'
    md5_test_file_hash = 'bbb8b499a0eef99b52c7f13f4e78c24b'

    assert md5_test_input_hash == md5s

# Generated at 2022-06-23 14:00:04.246720
# Unit test for function md5
def test_md5():
    md5('hashsum.py')

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 14:00:13.776681
# Unit test for function checksum
def test_checksum():
    s = 'hello world'
    assert secure_hash_s(s) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(s) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    fn = 'chksum_test_file'
    assert secure_hash(fn) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert checksum(fn) == 'd41d8cd98f00b204e9800998ecf8427e'

    assert md5s(s) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-23 14:00:25.413795
# Unit test for function checksum
def test_checksum():
    data = [
            ('hello world', '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'),
            ('data to hash', '8f47c927f3686d6a45b00f7c8f2d2154a7d5879e'),
            ('', 'da39a3ee5e6b4b0d3255bfef95601890afd80709'),
            ('123', '202cb962ac59075b964b07152d234b70')
    ]
    for str_data, str_hash in data:
        assert checksum_s(str_data) == str_hash


# Generated at 2022-06-23 14:00:32.692566
# Unit test for function md5
def test_md5():
    ''' ansible.utils.md5 unit test '''

    import os
    import tempfile

    # Create a non-existent file
    (fd, temp_path) = tempfile.mkstemp()
    os.close(fd)
    os.remove(temp_path)
    # Should return None
    if md5(temp_path) is not None:
        raise AssertionError("md5() on non-existent file should return None.")
    # Create an empty file
    fd = open(temp_path, 'w')
    fd.close()
    # Should return d41d8cd98f00b204e9800998ecf8427e

# Generated at 2022-06-23 14:00:34.712670
# Unit test for function md5
def test_md5():
    assert md5('') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-23 14:00:37.861226
# Unit test for function md5
def test_md5():
    assert md5("hashlib.py") == 'c6e76a6d9c6fba84bb1ec3c3e83917ce'


# Generated at 2022-06-23 14:00:45.119090
# Unit test for function checksum
def test_checksum():
    testfile = "./testfile"
    teststring = "abcde"

    # Test whether filename is not exist
    assert checksum("./filename_not_exist") is None
    assert checksum_s("filename_not_exist") is None

    # Test secure checksum
    with open(testfile, "w") as f:
        f.write(teststring)
    try:
        assert checksum(testfile) == checksum_s(teststring)
    finally:
        os.unlink(testfile)

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 14:00:52.408519
# Unit test for function checksum
def test_checksum():
    import os.path
    for hashfunc in (sha1, _md5):
        if hashfunc is None:
            continue
        filename = os.path.join(os.path.dirname(__file__), "digest_test.py")
        with open(filename, "r") as f:
            data = f.read()
        d1 = secure_hash_s(data, hashfunc)
        d2 = secure_hash(filename, hashfunc)
        assert(d1 == d2)

# Generated at 2022-06-23 14:00:56.974161
# Unit test for function checksum_s
def test_checksum_s():
    for input, output in [
        ('', 'da39a3ee5e6b4b0d3255bfef95601890afd80709'),
        ('xyz', '66b27417d37e024c46526c2f6d358a754fc552f3'),
        ('abc', 'a9993e364706816aba3e25717850c26c9cd0d89d')
    ]:
        assert checksum_s(input) == output

# Generated at 2022-06-23 14:01:04.532485
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('hello\n') == '86fb269d190d2c85f6e0468ceca42a20'

if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-23 14:01:07.909228
# Unit test for function md5
def test_md5():
    import tempfile
    f = tempfile.NamedTemporaryFile(delete=False)
    f.write(b"foobar")
    f.close()
    md5sum = md5(f.name)
    os.unlink(f.name)
    assert md5sum == "3858f62230ac3c915f300c664312c63f", "md5() function is broken"


# Generated at 2022-06-23 14:01:17.116188
# Unit test for function checksum
def test_checksum():

    # Create a temporary test file
    with open("/tmp/test_checksum","w") as f:
        f.write("test")
    assert checksum("/tmp/test_checksum") == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"
    assert checksum("/tmp/test_checksum", hash_func=_md5) == "098f6bcd4621d373cade4e832627b4f6"
    os.remove("/tmp/test_checksum")

# Generated at 2022-06-23 14:01:21.228747
# Unit test for function md5
def test_md5():
    ''' md5 should return None if file is not present or a directory '''
    assert md5(__file__) != None
    assert md5('/non/existing/file') == None
    assert md5('/dev/null') != None

# Unit tests for function md5s

# Generated at 2022-06-23 14:01:23.370962
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'c81dea3b67f2ae05bcce02b3f3ec0e86'

# Generated at 2022-06-23 14:01:27.604783
# Unit test for function checksum_s
def test_checksum_s():
    data = b'foo'
    expected = b'd3b07384d113edec49eaa6238ad5ff00'
    actual = checksum_s(data)

    if expected != actual:
        raise AssertionError("%s does not match %s" % (expected, actual))

# Generated at 2022-06-23 14:01:34.900684
# Unit test for function checksum_s
def test_checksum_s():

    hash_sha1 = secure_hash_s("the quick brown fox jumps over the lazy dog")
    hash_md5 = md5s("the quick brown fox jumps over the lazy dog")

    assert hash_sha1 == "2fd4e1c67a2d28fced849ee1bb76e7391b93eb12", hash_sha1
    assert hash_md5 == "9e107d9d372bb6826bd81d3542a419d6", hash_md5


# Generated at 2022-06-23 14:01:37.560591
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('string1') == 'e7dcd5dfab0cd66a4c9daeafd7f4f3e3b4a5c81b'



# Generated at 2022-06-23 14:01:41.659030
# Unit test for function md5
def test_md5():
    # check md5
    md5_sum = md5('test/test/test.xml')
    expected_md5_sum = '2f4b4f335bb054c8a0d7be400c763d39'

    if md5_sum != expected_md5_sum:
        raise ValueError('md5 returned: %s, expected %s' % (md5_sum, expected_md5_sum))


# Generated at 2022-06-23 14:01:52.942836
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s(b"Hello World") == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"
    assert checksum_s(b"") == "da39a3ee5e6b4b0d3255bfef95601890afd80709"
    assert checksum_s(b"abc") == "a9993e364706816aba3e25717850c26c9cd0d89d"
    assert checksum_s(u"Hello World") == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"
    assert checksum_s(u"") == "da39a3ee5e6b4b0d3255bfef95601890afd80709"
    assert checks

# Generated at 2022-06-23 14:02:02.836296
# Unit test for function md5
def test_md5():
    ''' md5 is not FIPS-140-2 compliant for applications using python's hashlib.

        For testing purpose, create a text file and compute the md5 checksum
        Use the command line utility to verify the result, then run this test
    '''

    # These data sets are taken from the test vectors given at
    # http://csrc.nist.gov/groups/STM/cavp/documents/drbg/drbgtestvectors.zip
    # At this time they are the only known public test data for md5.
    #

# Generated at 2022-06-23 14:02:05.693453
# Unit test for function md5
def test_md5():
    # Hash of the string 'file exists'
    assert md5s('file exists') == '42240e7b0e3843a24ea8e77e9f92725f'

if __name__ == "__main__":
    # Run unit tests
    test_md5()

# Generated at 2022-06-23 14:02:10.350178
# Unit test for function checksum_s
def test_checksum_s():
    data = '{"test_attr": 1 }'
    assert checksum_s(data) == sha1(to_bytes(data)).hexdigest()
    assert checksum_s(data, hash_func=_md5) == sha1(to_bytes(data)).hexdigest()
    assert checksum_s(data, hash_func=_md5) == md5s(data)
    assert checksum_s(data) == checksum_s(data, hash_func=_md5)

# Generated at 2022-06-23 14:02:14.949353
# Unit test for function checksum
def test_checksum():
    checksum = secure_hash_s
    assert checksum('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 14:02:21.292862
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('Hello world!') == '6cd3556deb0da54bca060b4c39479839'
    assert md5s('The quick brown fox jumped over the lazy dog') == '9e107d9d372bb6826bd81d3542a419d6'



# Generated at 2022-06-23 14:02:32.706916
# Unit test for function checksum_s
def test_checksum_s():
    # Default hash_func to sha1
    assert checksum_s("hello world") == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"

    # Use md5 hash if available and desired
    if _md5:
        assert checksum_s("hello world", _md5) == "5eb63bbbe01eeed093cb22bb8f5acdc3"
        assert checksum_s(u"hello world", _md5) == "5eb63bbbe01eeed093cb22bb8f5acdc3"

    # Should be able to handle non-ascii characters properly

# Generated at 2022-06-23 14:02:44.156824
# Unit test for function checksum
def test_checksum():
    assert secure_hash('lib/ansible/module_utils/basic.py') == '8a6ec31a39d1b6e5642e9e8c9339fce7'
    assert secure_hash_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum('lib/ansible/module_utils/basic.py') == '8a6ec31a39d1b6e5642e9e8c9339fce7'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-23 14:02:52.434439
# Unit test for function checksum
def test_checksum():
    ''' test_checksum is a simple file checksum to test whether the function is working '''
    # TODO: consider using this to unit test the other functions
    #       (remember to write your own file to test with as well as we want to avoid
    #        writing tests that access the filesystem un-necessarily)
    filepath = '/etc/motd'
    file_sum = checksum(filepath)
    assert file_sum == "e7b56d3b2c9ce957b3d807a252405a80f7948bd0"

# Generated at 2022-06-23 14:02:56.820610
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s(b'hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-23 14:03:03.209709
# Unit test for function checksum
def test_checksum():
    assert secure_hash('/bin/ls') == 'a6dad680bf8b2a62a9d78c50f2e60c6fdde6b25e'
    assert secure_hash_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert secure_hash_s(u'hello', hash_func=sha1) == u'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

# Generated at 2022-06-23 14:03:05.629640
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-23 14:03:09.634742
# Unit test for function checksum_s
def test_checksum_s():
    ''' Return a secure hash hex digest of data. '''

    assert 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d' == checksum_s('hello')
    assert '5d41402abc4b2a76b9719d911017c592' == md5s('hello')


# Generated at 2022-06-23 14:03:21.322851
# Unit test for function checksum_s
def test_checksum_s():
    import os
    import sys

    if sys.version_info < (2, 7):
        print("SKIP: Python 2.6 or older")
        return

    print("Testing checksum_s()")
    assert "da39a3ee5e6b4b0d3255bfef95601890afd80709" == checksum_s(data='')
    assert "4a4f8e07c1ad25e445f7356ce5f5f0e56b2bfac7" == checksum_s(data='hello')
    assert "b5bb9d8014a0f9b1d61e21e796d78dccdf1352f23cd32812f4850b878ae4944c" == checksum_s(data='hello\nworld')

# Generated at 2022-06-23 14:03:26.805291
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert checksum('/etc/passwd') == 'f497efb7f235e86f057ea7e258d4a0f4'


# Generated at 2022-06-23 14:03:36.540818
# Unit test for function checksum
def test_checksum():
    tests = (
        ('tests/test_module_utils/test_module_utils.py', '5b5ff0b87a5ab0d5c9e1a5c8e0377d660f2332ae'),
        (u"tests/test_module_utils/\u2018test_module_utils.py", '79b1728f699c4e4efc8ca4f1762dc4bc9c3beb3e'),
        ('tests/test_module_utils/not_a_file.py', None),
        ('tests/test_module_utils/', None),
    )
    for test, expected_hash in tests:
        h = checksum(test)
        assert h == expected_hash

    h = checksum_s('hello')

# Generated at 2022-06-23 14:03:42.823871
# Unit test for function checksum
def test_checksum():
    import shutil
    import tempfile

    current_dir = os.getcwd()
    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)
    fname = tmpdir + "/foo"

    open(fname, 'w').close()
    assert os.path.isfile(fname)
    assert checksum(fname) == "da39a3ee5e6b4b0d3255bfef95601890afd80709"

    f = open(fname, 'w')
    f.write("Hello World\n")
    f.close()
    assert os.path.isfile(fname)
    assert checksum(fname) == checksum_s("Hello World\n")

# Generated at 2022-06-23 14:03:53.663670
# Unit test for function checksum
def test_checksum():
    from ansible.utils.path import makedirs_safe
    from shutil import copy
    import tempfile

    tempdir = tempfile.mkdtemp()
    (fd, path) = tempfile.mkstemp()
    fp = os.fdopen(fd, "w")
    fp.write("line1\nline2\nline3\n")
    fp.close()

    copy(path, os.path.join(tempdir, "testfile.txt"))
    os.unlink(path)

    assert checksum(tempdir) == None
    assert checksum(path) == None
    assert checksum(os.path.join(tempdir, "testfile.txt")) == "958c7245a8ef8a52b3eeb1e47c8883dd8f849fe7"



# Generated at 2022-06-23 14:04:00.809030
# Unit test for function checksum
def test_checksum():
    file_path = os.path.join(os.path.dirname(__file__), 'test_checksum')
    if not os.path.exists(file_path):
        raise Exception('test_checksum file required in module utils')

    test_sum = '77c7baeda1d8b1ed3076ec636962f450'
    result = checksum(file_path)
    assert result == test_sum, result
