

# Generated at 2022-06-23 13:54:08.263568
# Unit test for function checksum
def test_checksum():
    s = "abcdefg\n"
    h1 = checksum_s(s)
    h2 = checksum_s(s.strip())
    h3 = checksum_s(s.strip() + "xyz")
    h4 = checksum_s(s.strip() + "xyz\n")

    assert h1 != h2
    assert h1 != h3
    assert h1 != h4
    assert h2 != h3
    assert h2 != h4
    assert h3 != h4

    rval = checksum(__file__)
    #print rval
    assert rval is not None

# Generated at 2022-06-23 13:54:10.340662
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e6e696638e35c7d26e029c48f7a4e'

# Generated at 2022-06-23 13:54:20.986092
# Unit test for function checksum_s
def test_checksum_s():

    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello', hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

    # Bytes tests
    if not hasattr(__builtins__, 'unicode'):
        # Python 3
        assert checksum_s(b'hello') == '5d41402abc4b2a76b9719d911017c592'

        # With encoding
        s = 'Øyvind'
        assert checksum_s(s) == '39566a0ea40b2e0fb12d82c5f7b5dad0'

        # Invalid chars should raise an error

# Generated at 2022-06-23 13:54:31.359792
# Unit test for function checksum_s
def test_checksum_s():
    # Check checksum_s() to compare against md5s()
    ret = checksum_s('Hello World!')
    assert ret == '7175b8d5aaee7e36a075a2f6c9a85a81ecbc7371'
    ret = checksum_s(u'Hello World!')
    assert ret == '7175b8d5aaee7e36a075a2f6c9a85a81ecbc7371'
    ret = checksum_s('中文测试')
    assert ret == 'd5b9329c0e03a00bce54bbb9a0bffd938e06e2ff'
    ret = checksum_s(u'中文测试')

# Generated at 2022-06-23 13:54:33.178732
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foo') == secure_hash_s('foo')



# Generated at 2022-06-23 13:54:38.332250
# Unit test for function checksum_s
def test_checksum_s():
    ''' test_checksum_s '''

    import tempfile

    try:
        temp = tempfile.NamedTemporaryFile(delete=False)
        temp.write(b'This is a test')
        temp.close()

        assert checksum_s('This is a test') == checksum(temp.name)
    finally:
        os.unlink(temp.name)

# Generated at 2022-06-23 13:54:41.644998
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("123") == "40bd001563085fc35165329ea1ff5c5ecbdbbeef"


# Generated at 2022-06-23 13:54:42.800021
# Unit test for function checksum
def test_checksum():
    assert checksum('/tmp/doesnotexist') is None

# Generated at 2022-06-23 13:54:45.693467
# Unit test for function md5s
def test_md5s():
    try:
        from hashlib import md5
    except ImportError:
        from md5 import md5
    assert md5s('test') == md5('test').hexdigest()


# Generated at 2022-06-23 13:54:51.865268
# Unit test for function checksum
def test_checksum():
    ''' test hashlib functions.  Requires a file named "test" '''

    # This test is not likely to work in FIPS mode, which would be
    # OK since we would probably not be able to run it
    f = open('test', 'wb')
    f.write(b'test')
    f.close()
    print ('sha1 file sum: %s' % secure_hash('test'))
    print ('sha1 string sum: %s' % secure_hash_s('test'))
    if _md5:
        print ('md5 string sum: %s' % md5s('test'))
        print ('md5 file sum: %s' % md5('test'))
        print ('md5 file sum: %s' % checksum('test'))
    os.unlink('test')


# Generated at 2022-06-23 13:54:57.918346
# Unit test for function md5
def test_md5():
    '''md5 should return the md5 checksum of a string'''

    # This key will fail if not in FIPS mode
    if secure_hash_s('foo', _md5) != 'acbd18db4cc2f85cedef654fccc4a4d8':
        raise AssertionError('md5sum test error')


# Generated at 2022-06-23 13:55:00.426429
# Unit test for function checksum
def test_checksum():

    assert checksum('/bin/ls') == checksum('/bin/ls')
    assert checksum('/bin/ls') != checksum('/bin/ls -la')


# Generated at 2022-06-23 13:55:06.077446
# Unit test for function checksum
def test_checksum():
    # base64 encoded sha1 checksums of strings 'hello' and 'world'
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('world') == '7c211433f02071597741e6ff5a8ea34789abbf43'


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 13:55:15.709015
# Unit test for function md5s
def test_md5s():
    assert md5s("12345") == '827ccb0eea8a706c4c34a16891f84e7b'
    assert md5s("hello world") == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s("this is a longer string that should come out different") == 'a85cd35fc8d66e7c15e2b1693b04bf62'
    assert md5s("") == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-23 13:55:18.734686
# Unit test for function md5s
def test_md5s():

    data = 'hello world'
    assert (md5s(data) == '5eb63bbbe01eeed093cb22bb8f5acdc3'), "Failed md5s unit test"

# Generated at 2022-06-23 13:55:31.294735
# Unit test for function checksum
def test_checksum():
    '''This test confirms that the checksum function returns correct result
    for an empty file'''
    from ansible.module_utils.hashivault import checksum

    # Create an empty file
    filename = 'test.txt'
    f = open(filename, 'a')
    f.close()

    # Calculate the checksum for the file
    empty_file_checksum = checksum(filename)

    # The checksum for an empty file is "da39a3ee5e6b4b0d3255bfef95601890afd80709"
    assert empty_file_checksum == "da39a3ee5e6b4b0d3255bfef95601890afd80709"

    os.remove(filename)

# Generated at 2022-06-23 13:55:38.926801
# Unit test for function checksum
def test_checksum():
    import tempfile
    directory = tempfile.mkdtemp()

    test_file = os.path.join(directory, "test_file")
    test_file_out = open(test_file, "w")
    test_file_out.write("This is a test file")
    test_file_out.close()

    assert checksum(test_file) == 'd47b878f8a8a94a228b69c53fc0e9f9c9e9a080b'

    test_bad_file = os.path.join(directory, "doesnotexist")
    assert checksum(test_bad_file) is None


# Generated at 2022-06-23 13:55:50.011727
# Unit test for function checksum_s
def test_checksum_s():
    '''
    Test checksum_s() function with the following tests:
        checksum with sha1
        checksum with md5
        checksum with invalid hash function
    '''
    from ansible import module_utils
    module_utils.HAS_HASHLIB = True
    module_utils.HAS_SSL = True
    assert checksum_s(b"foo") == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    assert checksum_s("foo", _md5) == "acbd18db4cc2f85cedef654fccc4a4d8"
    try:
        checksum_s("foo", "sha")
        assert False
    except ValueError:
        pass


# Generated at 2022-06-23 13:55:58.602168
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py: Unit test for function checksum '''
    import ansible.utils.checksum as cu
    import filecmp
    import shutil
    import tempfile

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary files
    (fd1, fn1) = tempfile.mkstemp(dir=tmpdir)
    fh1 = open(fn1, 'w')
    fh1.write('ansible')
    fh1.close()

    # Compute checksums
    s1 = cu.checksum(fn1)
    s2 = cu.checksum_s('ansible')
    s3 = cu.checksum_s('ansible', hash_func=cu._md5)

# Generated at 2022-06-23 13:56:00.662496
# Unit test for function md5s
def test_md5s():
    assert md5s('123') == '202cb962ac59075b964b07152d234b70'



# Generated at 2022-06-23 13:56:11.016942
# Unit test for function checksum
def test_checksum():
    result1 = checksum_s('test')
    if result1 != 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3':
        raise AssertionError
    result2 = checksum('test/ansible/test/unit/utils/test_hashing.py')
    if result2 != '4c4a1f4d6a20caf5ed5c5b5b9e9d5ca8f1c13c21':
        raise AssertionError
    result3 = md5s('test')
    if result3 != '098f6bcd4621d373cade4e832627b4f6':
        raise AssertionError
    result4 = md5('test/ansible/test/unit/utils/test_hashing.py')

# Generated at 2022-06-23 13:56:11.809965
# Unit test for function md5s
def test_md5s():
    pass

# Generated at 2022-06-23 13:56:21.624981
# Unit test for function checksum
def test_checksum():
    # Check comparison of checksum with string
    for hash_func in ("sha1", "md5"):
        string = "string to hash"
        # Use default hashing algorithm
        assert(checksum_s(string) == secure_hash_s(string, sha1))
        # Use hashing algorithm specified as argument
        assert(checksum_s(string, hash_func) == secure_hash_s(string, hash_func))

    # Check comparison of md5 with md5s
    string = "string to hash"
    if _md5:
        # Try with valid hashing algorithm
        assert(md5s(string) == secure_hash_s(string, _md5))

# Generated at 2022-06-23 13:56:32.880304
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '56f89bf9f9a1b8d3f70c82501f3c7fbbbe5660d2'
    assert checksum('/usr/bin/ls') == '56f89bf9f9a1b8d3f70c82501f3c7fbbbe5660d2'
    assert checksum(u'/bin/ls') == '56f89bf9f9a1b8d3f70c82501f3c7fbbbe5660d2'
    assert checksum(u'/usr/bin/ls') == '56f89bf9f9a1b8d3f70c82501f3c7fbbbe5660d2'

# Generated at 2022-06-23 13:56:43.665586
# Unit test for function checksum
def test_checksum():

    from ansible.compat.tests import unittest

    class TestChecksum(unittest.TestCase):

        def setUp(self):
            self.data = b"hello world\n"
            self.filename = os.path.join(os.path.dirname(__file__), 'test_checksum')
            self.file = open(self.filename, 'wb+')
            self.file.write(self.data)
            self.file.close()

        def tearDown(self):
            os.unlink(self.filename)

        def test_checksum_s(self):
            self.assertEqual(checksum_s(self.data), '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed')


# Generated at 2022-06-23 13:56:50.015962
# Unit test for function checksum
def test_checksum():
    ''' Unit test for function checksum '''

    # compare checksum with sha1 hash of current test file
    TEST_FILENAME = 'lib/ansible/module_utils/basic.py'
    sha1_hash = 'fe3c87a34aabf10d373e89b21a7cd2037bacf9d9'
    assert sha1_hash == checksum(TEST_FILENAME)
    assert sha1_hash == checksum(to_bytes(TEST_FILENAME))

# unit test for function checksum_s

# Generated at 2022-06-23 13:56:54.297006
# Unit test for function md5
def test_md5():
    from tempfile import NamedTemporaryFile
    f = NamedTemporaryFile(delete=False)
    f.write('test')
    f.close()
    assert(md5(f.name) == '098f6bcd4621d373cade4e832627b4f6')
    os.unlink(f.name)

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 13:56:57.295810
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == secure_hash_s('hello world')
    assert checksum_s('hello world', hash_func=sha1) == secure_hash_s('hello world', hash_func=sha1)

# Generated at 2022-06-23 13:57:06.131584
# Unit test for function checksum
def test_checksum():
    test_string = u'this is a test string'
    test_string_b = to_bytes(test_string)
    checksum_string = u'17f53bdc51db3a7acce698b1dfc03e6211ee3d9d'
    assert checksum_s(test_string) == checksum_string
    assert checksum_s(test_string_b) == checksum_string
    assert checksum_s(to_bytes(checksum_string)) == checksum_string

# Generated at 2022-06-23 13:57:12.718033
# Unit test for function md5
def test_md5():
    from ansible.compat.tests import unittest

    class TestMd5(unittest.TestCase):
        def test_md5(self):
            data = 'foo'
            expected = 'acbd18db4cc2f85cedef654fccc4a4d8'
            self.assertEqual(expected, md5s(data))

    unittest.main(argv=[''])

# Generated at 2022-06-23 13:57:13.599067
# Unit test for function md5s
def test_md5s():
    assert not _md5

# Generated at 2022-06-23 13:57:23.724900
# Unit test for function checksum_s
def test_checksum_s():
    answers = [('hello', '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'),
               ('world', '7d793037a0760186574b0282f2f435e7',),
               ('', 'da39a3ee5e6b4b0d3255bfef95601890afd80709',),
               ('The quick brown fox jumped over the lazy dog', '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12',),
               ('The quick brown fox jumped over the lazy dog.', '408d94384216f890ff7a0c3528e8bed1e0b01621',)]
    for data, answer in answers:
        assert checksum_s(data) == answer


# Generated at 2022-06-23 13:57:31.656717
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    import tempfile, shutil
    tmpdir = tempfile.mkdtemp(prefix='ansible-test-md5')
    tmpfile = os.path.join(tmpdir, 'test.txt')
    open(tmpfile, 'w').write('test')
    x = md5(tmpfile)
    assert(x == '098f6bcd4621d373cade4e832627b4f6'), "MD5 did not produce correct checksum"
    shutil.rmtree(tmpdir)

# Generated at 2022-06-23 13:57:35.629801
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('Hello world') == md5s('Hello world')
    assert checksum_s('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'

    assert checksum_s('Hello world', sha1) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'



# Generated at 2022-06-23 13:57:46.740171
# Unit test for function checksum
def test_checksum():
    ''' Test checksum function '''

    checksum_data = "foo"
    test_checksum_value = "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    assert checksum_s(checksum_data) == test_checksum_value, "checksum_s returned: %s" % checksum_s(checksum_data)

    checksum_file = "checksum_test.txt"
    test_checksum_file_value = "86d48b5c8a5b5bd5ddce0d76420fcd8e41e9f5d5"

# Generated at 2022-06-23 13:57:50.310050
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    result = md5(__file__)

    assert result == 'c679b59a0ed7a924062c16bf7f98d31a'


# Generated at 2022-06-23 13:57:58.430776
# Unit test for function checksum_s
def test_checksum_s():
    string1 = 'hello world'
    string2 = 'hello worldd'
    hash1 = '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    hash2 = '3a3a99d71e05a7a9a1861b5bfeee84c31949d8a4'

    assert checksum_s(string1, hash_func=sha1) == hash1
    assert checksum_s(string2, hash_func=sha1) == hash2

# Generated at 2022-06-23 13:58:01.389573
# Unit test for function md5s
def test_md5s():
    # Must return the same hash regardless of python version
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-23 13:58:05.960768
# Unit test for function checksum
def test_checksum():
    assert checksum_s('blah') == 'a8f94139c0c22d33e74f9455815c70f9cfdff744'
    assert checksum('/bin/ls') == '64bbc06ea9e5b5a5f5cc88e61eaf89c89520f19c'

# Generated at 2022-06-23 13:58:11.197934
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == 'a10f3dd1a56bb1ec8ca4e4ee4cb7c9086ef3d6c3'
    assert checksum("/bin/ls") == checksum_s("/bin/ls")


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 13:58:19.193839
# Unit test for function checksum
def test_checksum():
    '''Testing checksum function with valid and invalid input'''
    print("Testing checksum function with valid and invalid input")
    path = 'hashing.py'
    invalid_path = 'invalid_path'
    expected_checksum = 'bc4633b92c2e0beb642a7c0fe8f5588ff5710918'
    assert checksum(path) == expected_checksum, 'Checksum failed'
    assert checksum(invalid_path) == None, 'Checksum failed'
    print("Testing checksum function with valid and invalid input passed")


# Generated at 2022-06-23 13:58:22.900316
# Unit test for function md5
def test_md5():
    filename = '/etc/group'
    md5sum1 = md5(filename)
    md5sum2 = md5(filename)
    assert(md5sum1 == md5sum2)
    assert(len(md5sum1) == 32)


# Generated at 2022-06-23 13:58:35.342763
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello") == "5d41402abc4b2a76b9719d911017c592"

if __name__ == '__main__':
    import sys
    print("checking %s" % sys.argv[1])
    print("sha1: %s" % checksum(sys.argv[1]))
    if _md5:
        print("md5: %s" % md5(sys.argv[1]))
    else:
        print("Skipping md5 due to FIPS env var.")
    print("sha1 (string): %s" % checksum_s(sys.argv[1]))
    if _md5:
        print("md5 (string): %s" % md5s(sys.argv[1]))

# Generated at 2022-06-23 13:58:43.615675
# Unit test for function md5
def test_md5():
    if not _md5:
        return (True, 'MD5 not available.  Possibly running in FIPS mode')
    else:
        test_str = 'this is a test'
        ret_str = md5s(test_str)
        if ret_str != '19da2d2c6e9c13a9d6a99c3d1e6abf61':
            return (False, 'expected 19da2d2c6e9c13a9d6a99c3d1e6abf61 which is the md5 of "%s", but returned: "%s"' % (test_str, ret_str))
        return (True, None)


# Generated at 2022-06-23 13:58:51.880073
# Unit test for function md5
def test_md5():
    data = "hello"
    if md5s(data) == "5d41402abc4b2a76b9719d911017c592":
        pass
    else:
        raise Exception("md5s() test failed.")

    if os.path.isfile("./test.data"):
        if md5("./test.data") == "5d41402abc4b2a76b9719d911017c592":
            pass
        else:
            raise Exception("md5() test failed.")
    else:
        raise Exception("test file not found.")

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 13:58:55.907160
# Unit test for function md5s
def test_md5s():
    import tempfile
    (handle, path) = tempfile.mkstemp()
    contents = "testing testing 123"
    with open(path, 'w') as f:
        f.write(contents)
    assert md5s(contents) == md5(path)
    os.unlink(path)

# Generated at 2022-06-23 13:59:05.883451
# Unit test for function checksum_s
def test_checksum_s():
    from nose.plugins.skip import SkipTest

    if not _md5:
        raise SkipTest('MD5 not available.  Possibly running in FIPS mode')

    assert checksum_s('hello') == md5s('hello')
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('6d79207468657265') == 'fa3d3e7e8d55fddabfea65979e9bf9d7'
    assert checksum_s('hello') != '5d41402abc4b2a76b9719d911017c593'

# Generated at 2022-06-23 13:59:11.457382
# Unit test for function checksum
def test_checksum():
    import os
    import tempfile
    get_temp_dir = lambda: tempfile.gettempdir()
    get_random_dir = lambda: '.'.join([tempfile.gettempdir(), str(os.getpid()), str(os.urandom(16))])
    test_file = lambda f: checksum(f) == checksum_s(open(f).read())
    test_dir = lambda d: not checksum(d)
    assert test_file('/etc/passwd')
    assert test_file(__file__)
    assert test_dir(get_temp_dir())
    assert test_dir(get_random_dir())
    assert checksum_s("hello") == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert md

# Generated at 2022-06-23 13:59:17.129330
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/hosts') == 'd3b07384d113edec49eaa6238ad5ff00'
    assert checksum('/bin/ls') == '31f2c8e298be0f1c9f0d9cfd7a01a0e8'
    assert checksum('thisisnotarealfile') == None
    assert checksum('/bin/notarealfile') == None


# Generated at 2022-06-23 13:59:21.486173
# Unit test for function checksum
def test_checksum():
    assert (checksum(None) is None)
    assert (checksum(__file__) == 'e0dd2c95eccce8e1c9081cab6a00b6a8d61cbd0b')
    assert (checksum_s(None) is None)
    assert (checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed')

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 13:59:29.100785
# Unit test for function md5
def test_md5():
    import tempfile
    fd, fpath = tempfile.mkstemp()
    os.close(fd)
    with open(fpath, 'wb') as f:
        f.write(b'foobar')

    # use hexdigest to make the test output stable on
    # all platforms
    assert md5(fpath).hexdigest() == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foobar').hexdigest() == 'acbd18db4cc2f85cedef654fccc4a4d8'

    try:
        md5('/dev/null/foobar')
    except Exception:
        pass
    else:
        assert False, "shouldn't be here"

    os.unlink(fpath)

# Generated at 2022-06-23 13:59:34.230371
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5("test/test-modules/system/uptime.py") == "30e8f03b2262c20a9d14f99ecef8e1e3"


# Generated at 2022-06-23 13:59:38.393521
# Unit test for function md5s
def test_md5s():
    returned_md5 = md5s("hello world")
    print(returned_md5)
    assert returned_md5 == "5eb63bbbe01eeed093cb22bb8f5acdc3"

if __name__ == '__main__':
    test_md5s()
    print("Successfully completed two tests!")

# Generated at 2022-06-23 13:59:45.260499
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == '1f95520d9f9b4f4ae85cdee32d0f2416'
    assert md5('/etc/shadow') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-23 13:59:49.590932
# Unit test for function checksum_s
def test_checksum_s():
    a = 'Hello World !!'
    assert checksum_s(a) == 'b10a8db164e0754105b7a99be72e3fe5'
    assert md5s(a) == '65a8e27d8879283831b664bd8b7f0ad4'

# Generated at 2022-06-23 13:59:54.880010
# Unit test for function md5
def test_md5():
    f = open('testfile', 'w')
    f.write('Hello World')
    f.close()
    if md5('testfile') != 'eddbd1e2ce1bc50bcb5a5f5e5fb5c2d1':
        print("md5 test failed")
        print("Got: " + md5('testfile'))
        os.unlink('testfile')
        return 1
    else:
        os.unlink('testfile')
        return 0



# Generated at 2022-06-23 14:00:03.251378
# Unit test for function checksum
def test_checksum():
    TESTS = {
        'foo': '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33',
        'bar': '62cdb7020ff920e5aa642c3d4066950dd1f01f4d',
        'sha1': '3dffafc2eed97f0b0e51f8fc7e9c9b056d774f6c',
    }

    assert checksum_s('foo') == TESTS['foo']
    assert checksum_s('bar') == TESTS['bar']
    assert checksum_s('sha1') == TESTS['sha1']

# Generated at 2022-06-23 14:00:10.594777
# Unit test for function md5
def test_md5():
    import os
    import tempfile
    filename = os.path.join(tempfile.mkdtemp(), 'foo')
    fd = open(filename, 'w')
    fd.write('dontcare')
    fd.close()

    assert(md5(filename) == md5(filename))
    assert(md5s('dontcare') == md5s('dontcare'))
    os.unlink(filename)
    os.rmdir(os.path.dirname(filename))

# Generated at 2022-06-23 14:00:15.623667
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '5e5c36b5a5b5e483b542a85c8a1e2d42'
    assert md5('/bin/foo') == None


# Generated at 2022-06-23 14:00:19.266535
# Unit test for function md5s
def test_md5s():
    if _md5:
        # Test for md5s
        assert md5s(b'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-23 14:00:26.793073
# Unit test for function md5
def test_md5():
    t_md5 = 'f25b4e8d0daee4cc4f4b4c9dc8cef3a0'
    t_str = 'test'
    assert t_md5 == md5s(t_str)
    t_md5 = 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert t_md5 == md5s(t_str, md5)


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 14:00:29.065347
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/hosts') == 'b47dbb2909a8fa08e982d0b3d6e0f6aa'


# Generated at 2022-06-23 14:00:34.215663
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('world') == '7d793037a0760186574b0282f2f435e7'


# Generated at 2022-06-23 14:00:39.949801
# Unit test for function checksum
def test_checksum():
    assert checksum('checksum.py') == '1c0f89d73b52c4e00b9f4e5a5d5d5bb5f3746cc2'
    assert checksum_s('teststring') == '91433c0ea1bbcfd1b38a40c24605c7b44d169a70'


# Generated at 2022-06-23 14:00:44.907873
# Unit test for function md5s
def test_md5s():
    assert md5s(b'Hello') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('Hello') == '8b1a9953c4611296a827abf8c47804d7'
    assert md5s('5') == '5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-23 14:00:47.834201
# Unit test for function checksum_s
def test_checksum_s():
    (os_error, sys_error) = checksum_s('',None,None)
    assert not os_error


# Generated at 2022-06-23 14:00:54.817974
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('0') == 'cfcd208495d565ef66e7dff9f98764da'


# This is a backwards compat function so that existing code doesn't need to
# access the ansible.utils.module_docs_fragments.run_ansible_module() function

# Generated at 2022-06-23 14:01:02.354192
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

    f = open(tmpdir + '/test_file', 'wb')
    f.write(b'abcdefg')
    f.close()

    h = md5(tmpdir + "/test_file")
    assert h == '7ac66c0f148de9519b8bd264312c4d64'

    h = md5(tmpdir + "/test_file")
    assert h == '7ac66c0f148de9519b8bd264312c4d64'

    shutil.rmtree(tmpdir)

# Generated at 2022-06-23 14:01:07.517522
# Unit test for function checksum_s
def test_checksum_s():
    ''' Test the module with a python string '''
    test_data = 'The quick brown fox jumps over the lazy dog'
    test_sha1 = '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12'
    result = checksum_s(test_data)
    if result != test_sha1:
        raise Exception('checksum_s returned %s, expected %s' % (result, test_sha1))


# Generated at 2022-06-23 14:01:19.773519
# Unit test for function md5
def test_md5():
    import shutil
    import tempfile
    import unittest

    class TestMd5(unittest.TestCase):
        def test_md5_s(self):
            self.assertEqual(md5s(b'foo'), 'acbd18db4cc2f85cedef654fccc4a4d8')
            self.assertEqual(md5s(u'foo'), 'acbd18db4cc2f85cedef654fccc4a4d8')
            self.assertEqual(md5s(b'\x00\xff'), '36d59b38e8a7f7520c437a7b5769a784')

# Generated at 2022-06-23 14:01:23.917178
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo' * 1000) == '37b51d194a7513e45b56f6524f2d51f2'


# Generated at 2022-06-23 14:01:31.310520
# Unit test for function checksum_s
def test_checksum_s():

    try:
        from hashlib import sha1
    except ImportError:
        from sha import sha as sha1

    # This is a test string and the output is known
    test_string = "123"
    assert (checksum_s(test_string) == sha1(test_string).hexdigest())

    # Test to see if error is raised when passing a bool argument
    try:
        checksum_s(True)
    except TypeError:
        assert True
    else:
        assert False

    # Test to see if error is raised when passing a dict argument
    try:
        checksum_s({})
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-23 14:01:35.864433
# Unit test for function md5s
def test_md5s():
    assert md5s("choices") == '3ab4b4a9f9339c7e8dc5f5c788a710b0'

if __name__ == "__main__":
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-23 14:01:41.416534
# Unit test for function checksum_s
def test_checksum_s():
    s = "foo"
    assert checksum_s(s) == "acbd18db4cc2f85cedef654fccc4a4d8"
    s = ""
    assert checksum_s(s) == "da39a3ee5e6b4b0d3255bfef95601890afd80709"
    s = "the quick brown fox jumped over the lazy dog"
    assert checksum_s(s) == "c63aeba7e14fd21f3e9efe9f0d40a96a"


# Generated at 2022-06-23 14:01:50.967324
# Unit test for function md5s
def test_md5s():
    # unit test will never work if you are running in FIPS mode
    if not _md5:
        return
    data_1 = "foo"
    checksum_1 = md5s(data_1)
    data_2 = "data"
    checksum_2 = md5s(data_2)
    assert checksum_1 != checksum_2
    assert checksum_1 == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert checksum_2 == '44136fa355b3678a1146ad16f7e8649e'

# Generated at 2022-06-23 14:01:54.455225
# Unit test for function md5
def test_md5():
    md5s('test data')
    md5('testdata.txt')

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 14:02:03.730152
# Unit test for function md5
def test_md5():

  def subproc(command):
      out = os.popen(command)
      return out.read().rstrip()

  import tempfile

  fd, temp_path = tempfile.mkstemp()
  os.write(fd, 'foo')
  os.close(fd)

  if not subproc('which md5sum') and not subproc('which md5'):
      raise SystemExit('No md5sum program found')
  elif subproc('which md5sum'):
      md5bin = 'md5sum'
  else:
      md5bin = 'md5'

  # Compare with system md5


# Generated at 2022-06-23 14:02:07.093396
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") in ["e06ff1e9a93c8e49fa18a1fa6a7d2493", "6b7c6c0fe6ff4e0e1b6a1f639c4892d0"]

# Generated at 2022-06-23 14:02:17.885016
# Unit test for function checksum
def test_checksum():

    f1 = "test_checksum_file1"
    f2 = "test_checksum_file2"
    h1 = "ce86cbe7a20a5e29fc7c74a05545b3c3d9ed958b"
    h2 = "3eba1a3dfb6dffb6d4b6e0d4af9e6c4b1480e8c7"


# Generated at 2022-06-23 14:02:29.637563
# Unit test for function checksum
def test_checksum():
    '''Return a dict, key is filename, value is sha1 sum of the file'''

    files = {}
    files["a"] = os.path.abspath("test/files/a.out")
    files["dup"] = os.path.abspath("test/files/a.out")
    files["b"] = os.path.abspath("test/files/b.out")
    files["not_exist"] = os.path.abspath("test/files/not_exist")
    files["dir"] = os.path.abspath("test/files/")

    for filename in files:
        if filename == "not_exist":
            assert checksum(files[filename]) is None
        elif filename == "dir":
            assert checksum(files[filename]) is None

# Generated at 2022-06-23 14:02:38.297596
# Unit test for function md5
def test_md5():
    if _md5:
        assert(md5s('abc') == '900150983cd24fb0d6963f7d28e17f72')
        assert(md5('test/support/files/changelog') == '0a868f108aa4ba80a608b27a8c8d9b90')
    else:
        try:
            md5s('abc')
            raise ValueError('md5s produced no error')
        except ValueError as e:
            pass
        try:
            md5('test/support/files/changelog')
            raise ValueError('md5 produced no error')
        except ValueError as e:
            pass


# Generated at 2022-06-23 14:02:43.902112
# Unit test for function md5
def test_md5():
    filename = 'c:\\temp\\test.txt'
    f = open(filename, 'w')
    f.write(u'Hello')
    f.close()
    if md5(filename) != '609e3d3f3f3eb8c65bbfd5f9e5fd5dc7':
        raise Exception(md5(filename) + ' is not correct')


# Generated at 2022-06-23 14:02:48.598963
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'b1946ac92492d2347c6235b4d2611184'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(None) == '5feceb66ffc86f38d952786c6d696c79'



# Generated at 2022-06-23 14:02:56.969324
# Unit test for function checksum
def test_checksum():
    filename = "/tmp/ansible_test"
    open(filename, "wb").write(b"foobar")
    assert checksum(filename) == "8843d7f92416211de9ebb963ff4ce28125932878"
    assert checksum_s("foobar") == "8843d7f92416211de9ebb963ff4ce28125932878"
    assert md5(filename) == "acbd18db4cc2f85cedef654fccc4a4d8"
    assert md5s("foobar") == "acbd18db4cc2f85cedef654fccc4a4d8"
    os.remove(filename)

# Generated at 2022-06-23 14:03:00.781479
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s(b'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-23 14:03:09.886278
# Unit test for function md5
def test_md5():
    """ Test md5() function """
    from shutil import copy
    from tempfile import mkstemp

    # Test a file with a specific md5_sum
    (fd, test_file) = mkstemp(prefix='ansible_test_file.')
    try:
        content = b"Hello world!\n"
        expected_md5_sum = "5eb63bbbe01eeed093cb22bb8f5acdc3"
        assert md5(test_file) is None
        assert md5s(content) == expected_md5_sum
        copy(__file__, test_file)
        assert md5(test_file) == expected_md5_sum
    finally:
        os.close(fd)
        os.remove(test_file)

# Generated at 2022-06-23 14:03:13.894468
# Unit test for function md5
def test_md5():
    from tempfile import mkstemp
    from shutil import rmtree

    # Create tmp dir
    tmpdir = "/tmp/ansible-test-md5"
    os.mkdir(tmpdir)

    # Create tmp file
    tmpfh, tmpfile = mkstemp(dir=tmpdir)
    with os.fdopen(tmpfh, 'w') as f:
        f.write("test text")

    assert md5(tmpfile) == md5s("test text")

    # Remove tmp dir
    rmtree(tmpdir)

# Generated at 2022-06-23 14:03:17.227168
# Unit test for function md5
def test_md5():
    assert md5("ansible/module_utils/basic.py") == "2a7a77eb75f08d7a68e8b02c7cb9a69a"



# Generated at 2022-06-23 14:03:22.462671
# Unit test for function md5s
def test_md5s():
    data = b"somestring"
    expected = "d9478a9ab8f0bbd3c0b3bf7831fb3e8a"
    result = md5s(data)
    assert result == expected, 'md5s of %s is %s, should be %s'%(data, result, expected)


# Generated at 2022-06-23 14:03:25.888242
# Unit test for function md5s
def test_md5s():
    assert md5s('testdata') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-23 14:03:28.555570
# Unit test for function md5s
def test_md5s():
    a = 'hello world'
    b = 'hello world 2'
    assert md5s(a) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(b) == 'b594d922ae929c25f041aa7b43763f1b'

# Generated at 2022-06-23 14:03:30.793152
# Unit test for function md5
def test_md5():
    assert md5('lib/ansible/module_utils/basic.py') == 'f7fa8d46251a50d0a97a1f27e9b98d8a'

# Generated at 2022-06-23 14:03:36.739584
# Unit test for function md5
def test_md5():
    data = 'Za/gQR/Kj8B'
    assert md5s(data) == '6f8db599de986fab7a21625b7916589c'
    assert md5(__file__) == 'e7f43c8d745b7e48b35f5bea6d8e2ac1', 'md5 of %s is incorrect' % __file__

# Generated at 2022-06-23 14:03:39.928161
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-23 14:03:47.182626
# Unit test for function md5
def test_md5():
    import tempfile
    test_file = tempfile.NamedTemporaryFile(delete=False)
    test_file.write(b'ansible')
    test_file.close()
    file_hash = md5(test_file.name)
    os.unlink(test_file.name)
    assert(file_hash == "b09efbfb9d92728f4c475f57b92333ce")



# Generated at 2022-06-23 14:03:50.788711
# Unit test for function md5s
def test_md5s():
    result = md5s("test_string")
    assert result == "098f6bcd4621d373cade4e832627b4f6"

if __name__ == "__main__":
    test_md5s()

# Generated at 2022-06-23 14:03:58.057800
# Unit test for function checksum_s
def test_checksum_s():
    assert 'd41d8cd98f00b204e9800998ecf8427e' == checksum_s('')
    assert 'da39a3ee5e6b4b0d3255bfef95601890afd80709' == checksum_s(None)
    assert '0cc175b9c0f1b6a831c399e269772661' == checksum_s('a')