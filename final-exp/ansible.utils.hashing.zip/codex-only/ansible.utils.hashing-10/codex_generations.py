

# Generated at 2022-06-23 13:54:05.990497
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-23 13:54:07.584553
# Unit test for function checksum_s
def test_checksum_s():
    data = "abcdefg"
    assert checksum_s(data) == "7ac66c0f148de9519b8bd264312c4d64667cfa36"

# Generated at 2022-06-23 13:54:15.836806
# Unit test for function md5
def test_md5():

    import os
    import tempfile

    dummy = os.path.join(tempfile.gettempdir(), 'ansible_test_md5')

    if os.path.exists(dummy):
        os.unlink(dummy)

    # check md5 algorithm
    md5_sum1 = md5(dummy)
    assert md5_sum1 is None

    with open(dummy, 'w') as f:
        f.write('Hello world\n')

    md5_sum2 = md5(dummy)
    md5_sum3 = md5(dummy)

    with open(dummy, 'w') as f:
        f.write('hello world2\n')

    md5_sum4 = md5(dummy)

    assert md5_sum2 != md5_sum3
    assert md

# Generated at 2022-06-23 13:54:18.572845
# Unit test for function checksum_s
def test_checksum_s():
    result = checksum_s("abc")
    assert result == 'a9993e364706816aba3e25717850c26c9cd0d89d'


# Generated at 2022-06-23 13:54:29.922918
# Unit test for function checksum
def test_checksum():
    f = open('testfile', 'w')
    try:
        f.write('test data')
    finally:
        f.close()
    assert checksum('testfile') == '3d101eee1e8c0f5f47c9173b09e5a534f409e2ac'
    try:
        os.remove('testfile')
    except:
        pass

    # Test for hashlib md5 not available on FIPS-140-2 systems

# Generated at 2022-06-23 13:54:35.127663
# Unit test for function checksum
def test_checksum():
    import tempfile

    fn = tempfile.TemporaryFile().name  # We need a 'real' file here.
    f = open(fn, 'wb')
    f.write(os.urandom(1024))
    f.close()
    sha1_value = secure_hash(fn)
    md5_value = md5(fn)
    os.unlink(fn)
    assert sha1_value != md5_value

# Generated at 2022-06-23 13:54:37.803545
# Unit test for function md5
def test_md5():
    from nose.plugins.skip import SkipTest
    raise SkipTest('Unit test for function md5')


# Generated at 2022-06-23 13:54:42.276756
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '09f96ad8170711c8569e52e713f0e935'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-23 13:54:50.057655
# Unit test for function checksum_s
def test_checksum_s():
    # Invalid, non-string data
    assert checksum_s(None) == None, "Invalid data should return None"
    # Test cases where function should return the same value as the input
    assert checksum_s("") == "da39a3ee5e6b4b0d3255bfef95601890afd80709"
    assert checksum_s("Hello World!") == "2ef7bde608ce5404e97d5f042f95f89f1c232871", "Expected 2ef7bde608ce5404e97d5f042f95f89f1c232871, got: %s" % checksum_s("Hello World!")
    # Test cases where checksum should not be the same as the input

# Generated at 2022-06-23 13:54:55.381349
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s('hello\n') == '8b1a9953c4611296a827abf8c47804d7'

# Generated at 2022-06-23 13:54:57.775285
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-23 13:55:06.924506
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os

# Generated at 2022-06-23 13:55:12.201138
# Unit test for function checksum
def test_checksum():
    assert(checksum("/path/to/file") == secure_hash("/path/to/file"))
    assert(checksum("/path/to/file", _md5) == secure_hash("/path/to/file", _md5))



# Generated at 2022-06-23 13:55:15.824334
# Unit test for function checksum
def test_checksum():
    assert checksum_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'

# vim: set expandtab :

# Generated at 2022-06-23 13:55:20.194460
# Unit test for function checksum
def test_checksum():
    from io import BytesIO

    assert checksum(BytesIO(b"content")) == checksum("content")

    # Covers a bug for version 2.4.3
    assert checksum_s("content") == "786f2f0d55d21ca6e10a61b4e4d3e4a4a4bf8d1f"

# Generated at 2022-06-23 13:55:28.591610
# Unit test for function checksum
def test_checksum():
    from io import BytesIO
    s = checksum_s('hello world')
    assert s == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    f = BytesIO("hello world")
    s = checksum(f)
    assert s == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-23 13:55:31.068910
# Unit test for function md5
def test_md5():
    try:
        md5('COPYING')
    except ValueError as e:
        raise AssertionError("md5() raised ValueError unexpectedly: %s" % e)

# Generated at 2022-06-23 13:55:34.494098
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    # Verify that MD5 is available in FIPS mode
    md5s('')



# Generated at 2022-06-23 13:55:37.117025
# Unit test for function checksum
def test_checksum():
    assert(checksum('foobarbaz') == 'e3e868c73416a9f917cd83c8f8f7cfd1a0a6a7ba')


# Generated at 2022-06-23 13:55:49.451411
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    # Test - file not exist
    try:
        md5('/noexist')
        assert False
    except ValueError:
        pass
    # Test - dir
    try:
        md5('/etc')
        assert False
    except ValueError:
        pass
    # Test - file exist, no hash algorithm
    hash = md5('/etc/passwd')
    assert hash == '2bde6378ef443cb9c2eccd405e45c7b2'
    # Test - file exist, with hash algorithm
    hash = md5('/etc/passwd', _md5)
    assert hash == '2bde6378ef443cb9c2eccd405e45c7b2'
    # Test - string with hash algorithm

# Generated at 2022-06-23 13:55:52.179489
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s("foo") != "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33":
        raise ValueError("checksum_s() is broken")

if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-23 13:55:57.976892
# Unit test for function checksum_s
def test_checksum_s():
    assert secure_hash_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', 'basic sha1 test'
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', 'basic sha1 test'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6', 'basic md5 test'

# Generated at 2022-06-23 13:56:02.475086
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello') != 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434e'



# Generated at 2022-06-23 13:56:06.616843
# Unit test for function md5s
def test_md5s():
    assert md5s("foobar") == "3858f62230ac3c915f300c664312c63f"
    assert md5s(b"foobar") == "3858f62230ac3c915f300c664312c63f"



# Generated at 2022-06-23 13:56:10.028758
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6b8e3e15b3e4059abf167a673dd8d8a2dc6a26b2'
    assert checksum('/bin/bad') == None


# Generated at 2022-06-23 13:56:12.814828
# Unit test for function checksum_s
def test_checksum_s():
    test = checksum_s('12345')
    ans = '827ccb0eea8a706c4c34a16891f84e7b'
    assert test == ans


# Generated at 2022-06-23 13:56:21.852403
# Unit test for function md5s
def test_md5s():
    import os

    # can't just check known value, since the value depends on where
    # the source file is located and resolve does not work in some
    # of the unit test environments.  So just confirm that it returns
    # two strings of equal length
    s = md5s("this is a test")
    assert isinstance(s, str)
    assert len(s) == 32

    # Make sure the md5s() function is the same as md5.new("this is a test").hexdigest()
    import hashlib
    assert hashlib.md5("this is a test").hexdigest() == md5s("this is a test")

# Generated at 2022-06-23 13:56:25.369699
# Unit test for function md5s
def test_md5s():
    data = 'abc'
    assert md5s(data) == '900150983cd24fb0d6963f7d28e17f72'

# Generated at 2022-06-23 13:56:29.105269
# Unit test for function checksum_s
def test_checksum_s():
    test_data = "Hello World"
    assert checksum_s(test_data) == '2ef7bde608ce5404e97d5f042f95f89f1c232871'

# Generated at 2022-06-23 13:56:35.487559
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s("HELLO WORLD") == '7dd6bee591dfcb6d723158971a3c3f3d'
    assert md5s("") == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s("\n") == '68b329da9893e34099c7d8ad5cb9c940'
    assert md5s("\n"*16) == '9cf9bf156691bac0d0f3aaaf04a8fad7'

# Generated at 2022-06-23 13:56:41.204801
# Unit test for function md5
def test_md5():
    fd, fname = tempfile.mkstemp()
    try:
        f = os.fdopen(fd, 'w+b')
        f.write(b'xyz')
        f.close()
        assert md5(fname) == '66b27417d37e024c46526c2f6d358a754fc552f3'
    finally:
        os.unlink(fname)


# Generated at 2022-06-23 13:56:47.495575
# Unit test for function checksum
def test_checksum():
    fname = "/tmp/test_checksum"
    file(fname, "w").write("hello")
    assert checksum(filename=fname) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum(filename=fname, hash_func=sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    os.unlink(fname)


# Generated at 2022-06-23 13:56:50.819466
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'


# Generated at 2022-06-23 13:56:53.881803
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5('/bin/ls') == '9a966cab18d3b3f2c1e5a2d5b853213e'

# Generated at 2022-06-23 13:56:56.079025
# Unit test for function md5s
def test_md5s():
    assert md5s(b"abc") == '900150983cd24fb0d6963f7d28e17f72'


# Generated at 2022-06-23 13:56:58.382431
# Unit test for function md5s
def test_md5s():
    assert md5s('foobar') == '3858f62230ac3c915f300c664312c63f'


# Generated at 2022-06-23 13:57:01.812016
# Unit test for function md5
def test_md5():
    try:
        md5("ansible_test")
    except ValueError as exception:
        print("Caught exception: " + str(exception.args[0]))
        return
    assert False, "MD5 function should raise exception"

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 13:57:13.661321
# Unit test for function checksum
def test_checksum():
    from tempfile import mkstemp
    from shutil import rmtree
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True),
            known_checksum = dict(required=True),
        )
    )

    (fd, fname) = mkstemp()
    with open(fname, 'w') as f:
        f.write('my file contents')

    result = module.params['known_checksum'] == checksum(fname)
    rmtree(os.path.dirname(fname))

    module.exit_json(
        checksum = checksum(fname),
        changed = result,
    )


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 13:57:23.995294
# Unit test for function checksum_s
def test_checksum_s():
    ''' test_checksum_s '''
    # test valid values
    assert secure_hash_s(u'foobar') == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert secure_hash_s(u'foobar', hash_func=_md5) == '3858f62230ac3c915f300c664312c63f'
    # test invalid values
    try:
        secure_hash_s(None)
    except TypeError:
        pass
    else:
        raise AssertionError('secure_hash_s should have raised a TypeError')
    try:
        secure_hash_s(1)
    except TypeError:
        pass

# Generated at 2022-06-23 13:57:28.540514
# Unit test for function md5
def test_md5():
    if not _md5:
        return False

    assert md5('/bin/ls') == 'a0f7217afbbb1dd6090901ec9adb805b'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-23 13:57:34.299211
# Unit test for function md5
def test_md5():
    import tempfile

    tempfile.tempdir = "/tmp"
    t = tempfile.NamedTemporaryFile(delete=False)
    open("/tmp/testfile", "w").close()
    assert md5("/tmp/testfile") is None
    assert md5("/tmp/testfile_not_there") is None
    assert md5(t.name) is not None
    assert len(md5(t.name)) == 32
    t.close()
    os.remove(t.name)


# Generated at 2022-06-23 13:57:42.801173
# Unit test for function md5
def test_md5():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={
        'file': {'default': 'test', 'type': 'str'},
        'path': {'default': '.', 'type': 'str'}}
    )
    file = module.params['file']
    path = module.params['path']
    result = md5(os.path.join(path, file))
    module.exit_json(changed=False, md5=result)



# Generated at 2022-06-23 13:57:49.247333
# Unit test for function md5
def test_md5():
    curr_dir = os.path.dirname(__file__)
    os.chdir(curr_dir)
    test_file = 'file1'
    print('Test fileName: %s' % test_file)
    test_file_md5 = open(test_file).read()
    print('Test file content: %s' % test_file_md5)
    print('Test result: %s' % md5s(test_file_md5))


# Generated at 2022-06-23 13:57:56.322852
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    from ansible.module_utils import basic
    from ansible.compat.tests import unittest

    class TestMD5(unittest.TestCase):
        def setUp(self):
            self.__test_dir = tempfile.mkdtemp()
            self.__test_file = tempfile.mkstemp(dir=self.__test_dir)[1]
            self.__test_str = 'a'

        def tearDown(self):
            shutil.rmtree(self.__test_dir)

        def test_md5(self):
            ''' Test if a "md5()" function is available '''
            self.assertEqual(md5(self.__test_file), None)

# Generated at 2022-06-23 13:58:04.125577
# Unit test for function checksum
def test_checksum():
    import tempfile

    s = 'hello world'
    data = to_bytes(s)
    data_hash = checksum_s(data)
    fd, fname = tempfile.mkstemp()
    try:
        os.write(fd, data)
        file_hash = checksum(fname)
    finally:
        os.close(fd)
        os.unlink(fname)
    file_hash2 = checksum_s(s)
    assert data_hash == file_hash == file_hash2

# Generated at 2022-06-23 13:58:07.910588
# Unit test for function checksum_s
def test_checksum_s():
    assert secure_hash_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', 'got a bad checksum'


# Generated at 2022-06-23 13:58:14.400661
# Unit test for function md5
def test_md5():
    data = 'foo'
    assert md5s(data) == 'acbd18db4cc2f85cedef654fccc4a4d8'

    filename = 'test/integration/module_utils/module_utils_basic_ansible_test.py'
    assert md5(filename) == '3f54b7d0b9a1fbf7b33a4c4a7d4c4aae'

# Generated at 2022-06-23 13:58:23.365834
# Unit test for function md5
def test_md5():
    from tempfile import mkstemp
    fd, fn = mkstemp(prefix='ansible_test_')
    os.close(fd)

    h1 = md5(fn)
    if h1 is not None:
        raise TypeError('md5() None expected')
    h1 = md5('/tmp/does_not_exist')
    if h1 is not None:
        raise TypeError('md5() None expected')

    fh = open(fn, 'w')
    fh.write('hello')
    fh.close()

    h1 = md5(fn)
    h2 = '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-23 13:58:26.233828
# Unit test for function md5
def test_md5():
    assert md5('/tmp/test_md5') == None
    assert md5_s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5_s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-23 13:58:29.521055
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'


# Generated at 2022-06-23 13:58:35.066694
# Unit test for function md5
def test_md5():
    """
    Test md5 function.
    This test is a adaptation of the one present on the original library.
    """
    try:
        _md5
    except NameError:
        return
    assert(md5("data/md5.txt") == 'a2d2d2b9a60f1b938342ca16dbecc926')



# Generated at 2022-06-23 13:58:45.816143
# Unit test for function md5
def test_md5():

    this_dir, this_filename = os.path.split(__file__)
    data_dir = os.path.join(this_dir, 'data')

    assert md5('nosuchfile') == None
    assert md5(os.path.join(data_dir, 'sample.txt')) == '2d55f985e7c9fac54fbf9c8949b57480'
    assert md5(os.path.join(data_dir, 'ascii_sample.zip')) == 'f3a1d7308f6cb2b8c58d0126f5a566e1'

    if _md5:
        assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-23 13:58:50.323759
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('text') == '0a4d55a8d778e5022fab701977c5d840bbc486d0'
    assert checksum_s('text', sha1) == '0a4d55a8d778e5022fab701977c5d840bbc486d0'

if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-23 13:58:58.771166
# Unit test for function checksum
def test_checksum():
    from ansible.utils.path import unfrackpath, makedirs_safe
    (fd, test_file) = tempfile.mkstemp()
    os.close(fd)
    f = open(test_file, 'w')
    f.write("hello")
    f.close()

    assert checksum(test_file)
    assert checksum(unfrackpath("~/test")) == None

    new_test_file = unfrackpath("~/test/test_checksum")
    new_test_file = unfrackpath(new_test_file)
    makedirs_safe(os.path.dirname(new_test_file))
    shutil.copyfile(test_file, new_test_file)
    assert checksum(new_test_file)

# Generated at 2022-06-23 13:59:03.883057
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s(b'hello', sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'


# Generated at 2022-06-23 13:59:10.459789
# Unit test for function checksum_s
def test_checksum_s():
    assert(checksum_s('12345') == '827ccb0eea8a706c4c34a16891f84e7b')
    assert(checksum_s('123456') == 'e19d5cd5af0378da05f63f891c7467af')


if __name__ == '__main__':
    print("Checking checksum_s")
    test_checksum_s()
    print("Call checksum_s in a loop")
    for i in range(100000):
        checksum_s('12345')

# Generated at 2022-06-23 13:59:19.072127
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-23 13:59:24.186025
# Unit test for function checksum
def test_checksum():
    ''' testing function checksum '''
    from tempfile import NamedTemporaryFile

    test_file = NamedTemporaryFile(delete=False)
    test_file_name    = test_file.name
    test_file_content = 'example text'

# Generated at 2022-06-23 13:59:30.794827
# Unit test for function md5
def test_md5():
    ''' md5 test'''

    # When hashlib module is not available, md5 should raise an exception
    if not _md5:
        try:
            md5('/non/existent/file')
            raise AssertionError('md5 did not raise an exception')
        except ValueError as e:
            # Ensure exception string is the expected one
            if not str(e).startswith('MD5 not available.'):
                raise AssertionError('md5 raised a different exception than expected.  Expected ValueError, '
                                     'MD5 not available...  Got ValueError, %s' % str(e))

    # Test md5 against a known md5
    test_data = 'foobar'
    known_md5 = '3858f62230ac3c915f300c664312c63f'
    calculated

# Generated at 2022-06-23 13:59:37.579141
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls', hash_func=sha1) is not None
    assert checksum_s('hello world', hash_func=sha1) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-23 13:59:41.203837
# Unit test for function checksum
def test_checksum():
    assert checksum('test/support/files/chmod.py') == '4f7c30e8225e4e4de4cffa1aa0b06b72d24a8a01'

# Generated at 2022-06-23 13:59:43.869194
# Unit test for function md5s
def test_md5s():
    assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"


# Generated at 2022-06-23 13:59:48.485124
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    digest = _md5()
    digest.update(b"The quick brown fox jumps over the lazy dog")
    assert(md5s("The quick brown fox jumps over the lazy dog") == digest.hexdigest())


# Generated at 2022-06-23 13:59:50.812026
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-23 14:00:01.324373
# Unit test for function md5s
def test_md5s():

    """
    This function tests md5s function.
    """

    from ansible.utils.hash import md5s
    import os

    # Get a temp file name
    (handle, name) = tempfile.mkstemp()
    os.close(handle)

    # Set the expected md5s value
    md5s_value = '098f6bcd4621d373cade4e832627b4f6'

    # Write a file.
    open(name, 'w').write('test')

    # Check if md5s function works correctly.
    assert md5s('test') == md5s_value
    assert os.path.exists(name)
    assert md5(name) == md5s_value

    # Clean up temp files.
    os.unlink(name)


# Generated at 2022-06-23 14:00:08.229392
# Unit test for function md5
def test_md5():
    if not _md5:
        return

    '''
    [root@rhel5u1 ~]# echo '123' > /tmp/123
    [root@rhel5u1 ~]# md5sum /tmp/123
    202cb962ac59075b964b07152d234b70  /tmp/123
    '''
    assert md5('/tmp/123') == '202cb962ac59075b964b07152d234b70'

# Generated at 2022-06-23 14:00:11.007383
# Unit test for function md5s
def test_md5s():
    try:
        md5s('hello world')
        raise Exception('running in FIPS mode but md5s() is available?')
    except ValueError:
        pass
    except Exception:
        raise

# Generated at 2022-06-23 14:00:13.665341
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "6b8e0c86f8473d84c2d0f2739c5f49db"

# Generated at 2022-06-23 14:00:21.168296
# Unit test for function md5s
def test_md5s():
    ''' test md5s() function '''

    sample_data = "Hello World"
    sample_result = "ed076287532e86365e841e92bfc50d8c"
    assert md5s(sample_data) == sample_result, "md5s returned %s instead of %s" % (md5s(sample_data), sample_result)


# Generated at 2022-06-23 14:00:23.629562
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(u'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-23 14:00:26.187302
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello world") == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'



# Generated at 2022-06-23 14:00:29.178661
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s('foo') != '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33':
        print('checksum_s() failed')


# Generated at 2022-06-23 14:00:41.895105
# Unit test for function checksum
def test_checksum():

    def create_file(path, content):
        with open(path, "wb") as f:
            f.write(to_bytes(content, errors='strict'))

    import tempfile
    import shutil
    import os

    tdir = tempfile.mkdtemp()


# Generated at 2022-06-23 14:00:47.587499
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foobar') == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert checksum_s('foobar', hash_func=_md5) == '3858f62230ac3c915f300c664312c63f'


# Generated at 2022-06-23 14:00:49.879541
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == 'f5d83633aee9fb2f1edb3cc5bf6066d1'

# Generated at 2022-06-23 14:00:51.997715
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"

# Generated at 2022-06-23 14:00:57.526315
# Unit test for function checksum_s
def test_checksum_s():
    result = checksum_s("Hello world")
    if result != "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed":
        raise AssertionError("%s != %s" % (result, "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"))


if __name__ == '__main__':
    test_checksum_s()

# Generated at 2022-06-23 14:01:06.375352
# Unit test for function md5
def test_md5():

    result = md5('test/lib/ansible/module_utils/basic.py')
    assert result == '2a2e2c68d14f1c4313f95e8a8c50a29b'

    result = md5s('hello world')
    assert result == '5eb63bbbe01eeed093cb22bb8f5acdc3'

    result = md5s(u'hello world')
    assert result == '5eb63bbbe01eeed093cb22bb8f5acdc3'


if __name__ == '__main__':
    # Run unit test
    test_md5()

# Generated at 2022-06-23 14:01:15.892902
# Unit test for function md5s
def test_md5s():

    if not _md5:
        return # Skip tests as md5 is not available

    # Test string
    str = "Test string for md5"
    md5 = "74e6f7298a9c2d168935f58c001bad88"

    assert(md5s(str) == md5)

    # Test file
    file = 'test/unit/utils/testdata/changelog.md'
    md5 = "ddd92c6a66a441a191282b1db7a1fd6b"

    assert(md5(file) == md5)

# Generated at 2022-06-23 14:01:23.733678
# Unit test for function checksum_s
def test_checksum_s():
    ''' Return a secure hash string of data. '''

    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(b'hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'



# Generated at 2022-06-23 14:01:30.274888
# Unit test for function checksum
def test_checksum():
    f = open(__file__, 'rb')
    g = open(__file__, 'rb')
    try:
        assert checksum(f) == checksum(g)
        f_hex = checksum(f)
        assert isinstance(f_hex, basestring)
        assert checksum_s(f.read()) == f_hex
        assert checksum_s(f.read()) == md5s(f.read())
        assert checksum_s(f.read()) == md5(__file__)
    finally:
        f.close()
        g.close()

# Generated at 2022-06-23 14:01:39.928377
# Unit test for function checksum_s
def test_checksum_s():
    # Test checksum_s function with sha1 hash function
    if secure_hash_s("hello world", sha1) == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed":
        print("Unit test for checksum_s with sha1 hash function: success")
    else:
        print("Unit test for checksum_s with sha1 hash function: failed")

    # Test checksum_s function with md5 hash function
    if secure_hash_s("hello world", _md5) == "5eb63bbbe01eeed093cb22bb8f5acdc3":
        print("Unit test for checksum_s with md5 hash function: success")
    else:
        print("Unit test for checksum_s with md5 hash function: failed")


#

# Generated at 2022-06-23 14:01:50.544619
# Unit test for function md5
def test_md5():
    fd, fname = tempfile.mkstemp()
    if os.path.exists(fname):
        os.close(fd)
        os.unlink(fname)
    if not os.path.exists(fname):
        file(fname, 'w').write("test\n")
    assert md5(fname) == "6f8db599de986fab7a21625b7916589c"
    file(fname, 'w').write("different\n")
    assert md5(fname) == "e9b9c82946f2facdde1d06b3d321ffa5"
    os.unlink(fname)


# Generated at 2022-06-23 14:02:01.738215
# Unit test for function md5
def test_md5():
    import tempfile
    test_string = 'hello'
    test_string_file = tempfile.NamedTemporaryFile()
    test_string_file.write(test_string)
    test_string_file.flush()

    test_string_md5 = md5(test_string_file.name)

    # read the file back and calculate the md5
    test_string_file = open(test_string_file.name, 'r')
    test_string_read = test_string_file.read()
    test_string_md5_s = md5s(test_string_read)

    test_string_file.close()
    test_string_file.delete = True

    assert test_string_md5 == test_string_md5_s

# Generated at 2022-06-23 14:02:06.927789
# Unit test for function md5s
def test_md5s():
    if not _md5:
        print('cannot run test_md5s()')
        return
    if md5s("Hello World!") != "ed076287532e86365e841e92bfc50d8c":
        print("md5s('Hello World!') should return 'ed076287532e86365e841e92bfc50d8c'")


# Generated at 2022-06-23 14:02:13.599328
# Unit test for function checksum_s
def test_checksum_s():
    print("Testing checksum_s() with the string \"hello\"")
    checksum = checksum_s("hello")
    if checksum == "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824":
        print("Success!")
    else:
        print("Error, checksum returned was:")
        print(checksum)


# Generated at 2022-06-23 14:02:15.939469
# Unit test for function md5s
def test_md5s():
    data = u'this is a test'
    result = md5s(data)
    print(result)


# Generated at 2022-06-23 14:02:20.271438
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello world") == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"
    assert checksum_s("hello world", hash_func=sha1()) == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"


# Generated at 2022-06-23 14:02:25.585798
# Unit test for function md5
def test_md5():
    filename = 'CHANGELOG'
    assert md5(filename) == '3d3e40c0980f39e77b852dae9a0ff5fd'


if __name__ == "__main__":
    # Run tests
    test_md5()
    print('All tests passed')

# Generated at 2022-06-23 14:02:35.132991
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  tests for ansible.utils.checksum '''

    assert secure_hash_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed', 'standard string'
    assert secure_hash_s('hello world', _md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3', 'md5 string'

    # TODO: make this test work on all platforms
    #assert checksum('/usr/bin/python') == '9d21506a5b1d5b71c0dc81e8d2f889e0', 'python binary'
    #assert checksum('/usr/bin/python', _md5) == '7c0e3d3f7b2c

# Generated at 2022-06-23 14:02:45.894922
# Unit test for function checksum_s
def test_checksum_s():
    """Function checksum_s"""
    assert checksum_s(None) == u'cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e'
    assert checksum_s("") == u'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s("The quick brown fox jumps over the lazy dog") == u'2fd4e1c67a2d28fced849ee1bb76e7391b93eb12'

# Generated at 2022-06-23 14:02:51.531262
# Unit test for function md5
def test_md5():
    import tempfile
    fd, fn = tempfile.mkstemp()
    f = os.fdopen(fd, 'w+')
    f.write("1234567890")
    f.close()

    assert md5(fn) == 'e807f1fcf82d132f9bb018ca6738a19f'

# Generated at 2022-06-23 14:03:03.168395
# Unit test for function checksum_s
def test_checksum_s():
    import sys

    if sys.version_info[0] < 3:
        # Python 2.x
        assert(checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33')
        assert(checksum_s('foo', hash_func=_md5) == 'acbd18db4cc2f85cedef654fccc4a4d8')
    else:
        # Python 3.x
        assert(checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33')

# Generated at 2022-06-23 14:03:09.298328
# Unit test for function checksum_s
def test_checksum_s():
    '''
        basic function test
    '''

    # If we're running in FIPS mode, this should fail
    if _md5:
        assert checksum_s("Hello") == md5s("Hello")
    else:
        try:
            md5s("Hello")
        except ValueError:
            pass
        else:
            assert False, "A ValueError should have been raised"
    assert checksum_s("Hello", sha1) == checksum_s("Hello")

# Generated at 2022-06-23 14:03:11.259712
# Unit test for function md5s
def test_md5s():
    if md5s("abc123") != "202cb962ac59075b964b07152d234b70":
        raise Exception("md5s not working")

#######################################################################



# Generated at 2022-06-23 14:03:17.416058
# Unit test for function md5
def test_md5():
    # Avoid errors when running from a different directory
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    assert md5("test_utils.py") == "4e4d0b64eb810b9a18bacd7b8836de48"
    assert md5("/etc/passwd") is None
    assert md5("/etc/shadow") is None

    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("hello\n") == "cafdbf0540d9c9bf68f2549d2a6facc1"

# Generated at 2022-06-23 14:03:20.580074
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-23 14:03:24.775574
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('handsome', sha1) == '3f870a5f846c67e55c71618e6f2e7c8d1705f34b'


# Generated at 2022-06-23 14:03:33.335941
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum_s('123') == '40bd001563085fc35165329ea1ff5c5ecbdbbeef'

# Generated at 2022-06-23 14:03:44.578178
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil

    d = tempfile.mkdtemp()
    f1 = os.path.join(d, "f1")
    f2 = os.path.join(d, "f2")
    f3 = os.path.join(d, "f3")
    h1 = "d41d8cd98f00b204e9800998ecf8427e"
    h2 = "a91d3e24b6e25e47a2d99f7538dc2c88"
    h3 = "bdcdbd1afd0cad144fad80dd64f96d2b"

    with open(f1, "w") as f:
        pass
    with open(f2, "w") as f:
        f.write("something")

# Generated at 2022-06-23 14:03:54.766465
# Unit test for function checksum
def test_checksum():
    try:
        import hashlib
        if 'sha1' in hashlib.algorithms:
            assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
            assert checksum_s('another test') == '26b4b22c55b97e3f9adad95a6e8a1b3e6a648a98'
            assert checksum_s(b'hello, world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
            checksum_s('привет, мир')
    except ImportError:
        pass

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 14:04:02.406511
# Unit test for function md5
def test_md5():
    filename = 'unit_test_file_abc'
    with open(filename, 'wb') as f:
        f.write(b'abc')

    checksum = md5(filename)
    assert checksum == '900150983cd24fb0d6963f7d28e17f72'

    checksum = md5s(b'abc')
    assert checksum == '900150983cd24fb0d6963f7d28e17f72'

    os.remove(filename)