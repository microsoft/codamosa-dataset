

# Generated at 2022-06-23 13:54:10.458645
# Unit test for function checksum_s
def test_checksum_s():
    test_data = [ ('abcd', '81fe8bfe87576c3ecb22426f8e57847382917acf'),
                  ('test', 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'),
                  ('', 'da39a3ee5e6b4b0d3255bfef95601890afd80709'),
                  ('Super Mario', '3a9e09f2e1f33a8e3c670e67fbe0d2eeb87d8b68') ]
    for data_string in test_data:
        assert data_string[1] == checksum_s(data_string[0])

if __name__ == "__main__":
    test_checksum_s()

# Generated at 2022-06-23 13:54:17.061694
# Unit test for function checksum_s
def test_checksum_s():
    ''' Returns True on success, False on failure '''
    # Set up the test
    test = 'abcdefghijkl'
    expected = '3d3c18fbb0f7e9d6567d6f19b6daa1bc0fc240f2'
    digest = secure_hash_s(test)

    # Now run the test
    return digest == expected

# unit test for function checksum

# Generated at 2022-06-23 13:54:19.691367
# Unit test for function checksum
def test_checksum():
    filename = __file__
    print("Checking file: %s" % filename)
    print("Checking checksum")
    assert checksum(filename) == checksum_s(filename)


# Generated at 2022-06-23 13:54:22.896559
# Unit test for function md5
def test_md5():
    assert secure_hash('/etc/passwd') == 'c8d5a5fcfd5f9d3c3a8e8b7cadacc037'

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 13:54:30.220752
# Unit test for function checksum
def test_checksum():
    file = open("test_checksum", "w")
    file.write("Example file!\n")
    file.close()
    assert(secure_hash("test_checksum") == "758a9a7b25a2d2f7b8a5898caf7beddc70f1c1cc")
    os.remove("test_checksum")
    assert(secure_hash("/tmp/doesnotexist") is None)
    assert(secure_hash("/etc") is None)

# Generated at 2022-06-23 13:54:31.998503
# Unit test for function md5s
def test_md5s():
    print ("MD5 checksum of test string 'test' is: %s" % (md5s('test')))

# Generated at 2022-06-23 13:54:37.629975
# Unit test for function md5
def test_md5():
    import tempfile

    f, filename = tempfile.mkstemp()
    os.write(f, b"To test md5()\n")
    os.close(f)
    expected = '40e6bcd7f8d420e25a7e0a2f2e41a8a1'
    actual = md5(filename)
    os.unlink(filename)
    assert expected == actual

# Generated at 2022-06-23 13:54:40.389079
# Unit test for function md5s
def test_md5s():
    md5s_test = md5s('my test string')
    assert md5s_test == 'f70b4940e84abd439847f3c7e81a08c9'

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-23 13:54:46.594381
# Unit test for function checksum_s
def test_checksum_s():
    if checksum_s("Hello World") != "b10a8db164e0754105b7a99be72e3fe5":
        raise ValueError("bad md5 sum for Hello World")

    if checksum_s("Hello World", sha1) != "2ef7bde608ce5404e97d5f042f95f89f1c232871":
        raise ValueError("bad sha1 sum for Hello World")

    print("SHA1 Test: ok")



# Generated at 2022-06-23 13:54:49.638519
# Unit test for function md5s
def test_md5s():

    string1 = 'hello world'
    string2 = 'bye world'

    assert(md5s(string1) == '5eb63bbbe01eeed093cb22bb8f5acdc3')
    assert(md5s(string1) != md5s(string2))

# Generated at 2022-06-23 13:54:52.834460
# Unit test for function checksum
def test_checksum():
    assert checksum("test/files/test.cfg") == "28bd2c0b6f27b6e2803813b8326c2e2e"
    assert checksum("test/files/test.cfg", hash_func=sha1) == "28bd2c0b6f27b6e2803813b8326c2e2e"



# Generated at 2022-06-23 13:54:58.611989
# Unit test for function checksum_s
def test_checksum_s():
    str1 = 'This is a test of the emergency broadcasting system'
    str2 = 'This is a test of the emergency broadcasting system.'

    assert(checksum_s(str1) == checksum_s(str1))
    assert(checksum_s(str2) == checksum_s(str2))
    assert(checksum_s(str1) != checksum_s(str2))

# Generated at 2022-06-23 13:55:01.317500
# Unit test for function checksum
def test_checksum():
    assert secure_hash("test/sanity/hacking/test-module-HashIdentity") == '5e5e5a7f16d0a24c715e106e56fa6592a9e56f1b'

# Generated at 2022-06-23 13:55:07.022345
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s(b'test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s(u'test') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-23 13:55:19.217990
# Unit test for function checksum_s

# Generated at 2022-06-23 13:55:21.995380
# Unit test for function md5
def test_md5():
    fn = os.path.basename(__file__)
    assert md5(fn) is not None

# Generated at 2022-06-23 13:55:24.752105
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-23 13:55:30.426907
# Unit test for function checksum_s
def test_checksum_s():
    '''
    basic test to make sure secure_hash_s is giving back a digest of the right length
    '''
    assert secure_hash_s(b'string') == b'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'

# Generated at 2022-06-23 13:55:36.169312
# Unit test for function checksum
def test_checksum():
    '''
    test_checksum
    '''
    filename = "__init__.py"
    assert os.path.exists(filename)
    assert checksum(filename) == 'e0cd71d55b9f9d6adf44c7a0078d678e211866c6'
    filename = "__notafile"
    assert not os.path.exists(filename)
    assert checksum(filename) == None

# Generated at 2022-06-23 13:55:42.735846
# Unit test for function md5
def test_md5():
    print('Test md5()')
    expected = 'd41d8cd98f00b204e9800998ecf8427e'
    observed = md5(__file__)
    #print('expected: %s' % expected)
    #print('observed: %s' % observed)
    assert expected == observed


# Generated at 2022-06-23 13:55:45.980893
# Unit test for function checksum
def test_checksum():
    data = "I am a secret"
    r1 = checksum_s(data)
    r2 = checksum_s(data)
    assert r1 == r2

# Generated at 2022-06-23 13:55:53.759152
# Unit test for function checksum
def test_checksum():
    test_filename = 'test_file.txt'
    test_file_content = 'Hello World'
    target_checksum_value = 'ed076287532e86365e841e92bfc50d8c'

    # Test for missing file
    if checksum('non_existing_file.txt') is not None:
        raise AssertionError("File does not exist but checksum returned not None.")
    # Test for file with correct checksum
    f = open(test_filename, 'w')
    f.write(test_file_content)
    f.close()

    if checksum(test_filename) != target_checksum_value:
        raise AssertionError("Checksum of test file provides incorrect value.")

    # Test for directory instead of file
    if checksum('.') is not None:
        raise

# Generated at 2022-06-23 13:56:00.791846
# Unit test for function checksum
def test_checksum():
    data1 = "I am a file with some data"

    # Generate hash of data1
    checksum1 = secure_hash_s(data1)

    # Create a file with data1
    fd, fname = tempfile.mkstemp()
    f = open(fname, "w")
    f.write(data1)
    f.close()

    # Generate hash of the file
    checksum2 = secure_hash(fname)

    # Compare the hashes
    assert(checksum1 == checksum2)

# Generated at 2022-06-23 13:56:07.120481
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo\n') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo') == secure_hash_s('foo', _md5)
    assert md5s('foo') != secure_hash_s('foo', sha1)


# Generated at 2022-06-23 13:56:17.311013
# Unit test for function checksum
def test_checksum():
    f = open('/tmp/md5','wb')
    f.write(b'a')
    f.close()
    assert checksum('/tmp/md5') == '0cc175b9c0f1b6a831c399e269772661'
    assert checksum('/tmp/md5',_md5) == '0cc175b9c0f1b6a831c399e269772661'
    assert checksum_s(b'a') == '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8'
    assert checksum_s(b'a',_md5) == '0cc175b9c0f1b6a831c399e269772661'


# Generated at 2022-06-23 13:56:20.641625
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('string') == '5a47d12a02e5ec001232f0d1ea4560c8'


# Generated at 2022-06-23 13:56:22.888258
# Unit test for function checksum_s
def test_checksum_s():
    # The following hash is from the string "hello world!"
    expected = '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    actual = checksum_s('hello world!')
    assert expected == actual

# Generated at 2022-06-23 13:56:32.618477
# Unit test for function checksum
def test_checksum():
    # sha1
    assert checksum_s("hello") == checksum("test/unittests/test_utils/hello")
    assert checksum_s("hello\n") == checksum("test/unittests/test_utils/hello2")
    assert checksum_s("hello\r") == checksum("test/unittests/test_utils/hello3")
    assert checksum_s("hello\r\n") == checksum("test/unittests/test_utils/hello4")
    assert checksum_s("hello\r\n\r\n") == checksum("test/unittests/test_utils/hello5")

# Generated at 2022-06-23 13:56:42.524047
# Unit test for function checksum
def test_checksum():
    '''
    unit test for checksum
    '''
    import tempfile
    import os

    (dummy_fd, dummy_file) = tempfile.mkstemp()
    open(dummy_file, 'w').close()
    # test for file
    assert checksum(dummy_file) == os.stat(dummy_file).st_mtime
    # test for string
    assert checksum_s('hello, world!') == '30a0f2e2b3f3b16fe937cbb2c7f915e6eddf8444'
    os.unlink(dummy_file)
    # test for file not exist
    assert checksum(dummy_file) is None

# Generated at 2022-06-23 13:56:45.848191
# Unit test for function checksum_s
def test_checksum_s():
    fail = True
    result = checksum_s("123")
    if result == "40bd001563085fc35165329ea1ff5c5ecbdbbeef":
        fail = False
    assert fail == False

# Generated at 2022-06-23 13:56:53.300580
# Unit test for function checksum_s
def test_checksum_s():
    ''' checksum_s() should return the sha1 hash of the given string '''
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s('test', hash_func=_md5) == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-23 13:56:58.382509
# Unit test for function md5s
def test_md5s():
    ''' test md5s function '''
    string = 'hello world'
    hash_result = md5s(string)
    assert hash_result == '5eb63bbbe01eeed093cb22bb8f5acdc3', hash_result

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-23 13:57:04.813605
# Unit test for function checksum_s
def test_checksum_s():
    import pickle
    # Do not use a list of tuples, since the order must not be relied upon
    # and the intention is to compare digests, not the item contents

# Generated at 2022-06-23 13:57:11.663521
# Unit test for function checksum
def test_checksum():
    t_path = os.path.realpath(__file__)
    t_dir = os.path.dirname(t_path)
    t_file = os.path.join(t_dir, 'test_utils.py')
    t_sum = checksum(t_file)
    assert t_sum == '3694dc8bce270e5514caf89c36fce51c1b7c1bba'

###


# Generated at 2022-06-23 13:57:14.794909
# Unit test for function checksum
def test_checksum():
     data = 'test'
     checksumdata = secure_hash_s(data)
     assert checksumdata == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

# Generated at 2022-06-23 13:57:24.165666
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_s('test/test.py') == 'aef03187024a8a90210c9d7f9a91234e7a90f0c1'
    assert checksum_s('test/test_utils') == '7bd9fceb43cc671e1e4b4e4d4a88f8b837fd6eec'
    assert checksum_s(None) == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'



# Generated at 2022-06-23 13:57:33.362567
# Unit test for function md5s
def test_md5s():
    import unittest
    import ansible.utils.hashing as hashing_funcs
    test_md5_string = "Hello"
    test_md5_has_string = "8b1a9953c4611296a827abf8c47804d7"
    test_md5_non_string = 4
    test_md5_has_non_string = "8af75c7f766b22f9ccad6ec082354b90"

    class TestHashingFuncs(unittest.TestCase):
        def test_md5s_string(self):
            self.assertEqual(hashing_funcs.md5s(test_md5_string), test_md5_has_string)
        def test_md5s_non_string(self):
            self.assertEqual

# Generated at 2022-06-23 13:57:45.648663
# Unit test for function checksum
def test_checksum():
    ''' test_checksum()
    :return:
    '''
    # file path to read checksum
    fpath = '../../lib/ansible/test/test_playbook.py'
    fpath_not_exist = '../../lib/ansible/test/not_exist_playbook.py'
    fpath_is_dir = '../../lib/ansible/test'
    expected_sha1 = 'b4d4b4e9b50375189a7a2a1a99197b8f59bdbbb6'
    expected_md5 = '9c3b3e6f963dde61ef6d8e637df39089'

    # unit test
    assert expected_sha1 == checksum(fpath)
    assert expected_md5 == md5(fpath)



# Generated at 2022-06-23 13:57:47.917927
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('a') == '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8'
    assert checksum_s('b') == 'e9d71f5ee7c92d6dc9e92ffdad17b8bd49418f98'

# Generated at 2022-06-23 13:57:59.031525
# Unit test for function checksum_s
def test_checksum_s():

    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp(prefix='ansible-test_checksum_s')

    initial_contents = u"1234\n5678\n".encode('utf-8', 'strict')
    filename = os.path.join(test_dir, 'test1')
    with open(filename, 'wb') as f:
        f.write(initial_contents)
    checksum_s(initial_contents)
    checksum_s(initial_contents, hash_func=_md5)
    checksum_s(initial_contents, hash_func=sha1)

    #
    # FIPS mode fails when using md5 algorithm
    #
    #tmp = os.environ.get('ANSIBLE_FIPS_MODE', None)
    #

# Generated at 2022-06-23 13:58:02.336221
# Unit test for function md5
def test_md5():
    data = "Hello, this is a test string"
    assert md5s(data) == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'


# Generated at 2022-06-23 13:58:03.815437
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foo') == secure_hash_s('foo')



# Generated at 2022-06-23 13:58:07.281085
# Unit test for function md5
def test_md5():
    """Unit test for function md5"""
    assert md5('setup.py') == 'e2f4f8c4b4b71ed7b9d2e5d8b5c64d09'

# Generated at 2022-06-23 13:58:10.762877
# Unit test for function checksum_s
def test_checksum_s():
    if secure_hash_s('test') != 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3':
        raise ValueError('function checksum_s failed')

# Generated at 2022-06-23 13:58:16.616718
# Unit test for function md5
def test_md5():
    test_string = u'Supercalifragilisticexpialidocious'
    test_bytes = to_bytes(test_string)
    test_hash = md5s(test_bytes)
    assert test_hash == u'5d5bf5b5d5bf5b5d5bf5b5d5bf5b5d5b'

    # TODO: test with a file

# Generated at 2022-06-23 13:58:22.110090
# Unit test for function md5s
def test_md5s():
    print("\nTest md5s")
    print("\tTest md5 for text '123456789' : %s" % md5s("123456789"))
    print("\tTest md5 for text '123456789' with hash_func=md5 : %s" % md5s("123456789", hash_func=md5))



# Generated at 2022-06-23 13:58:30.119184
# Unit test for function md5
def test_md5():
    import os
    import tempfile
    C = 'foo'
    F = tempfile.mktemp()
    with open(F, 'wb') as f:
        f.write(to_bytes(C, errors='strict'))
    assert md5(F) == 'acbd18db4cc2f85cedef654fccc4a4d8'
    os.remove(F)


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 13:58:35.173356
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

# Generated at 2022-06-23 13:58:45.924881
# Unit test for function md5
def test_md5():
    ''' md5 unit test'''
    # The md5 function must be used instead of the checksum
    # function to obtain the correct checksum.
    #
    # MD5 with both empty strings should return:
    # d41d8cd98f00b204e9800998ecf8427e
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('') == 'd41d8cd98f00b204e9800998ecf8427e'

    # MD5 with both FOO should return:
    # acbd18db4cc2f85cedef654fccc4a4d8

# Generated at 2022-06-23 13:58:54.053665
# Unit test for function md5
def test_md5():
    # Create a temp file with a known hash
    from subprocess import Popen, PIPE
    import tempfile
    tmp_fd, tmp_path = tempfile.mkstemp()
    tmp_file = os.fdopen(tmp_fd, 'wb')
    hash_val = b"d41d8cd98f00b204e9800998ecf8427e"
    tmp_file.write(b"")
    tmp_file.close()
    result = md5(tmp_path)
    os.remove(tmp_path)
    print (result)

# Generated at 2022-06-23 13:59:00.839792
# Unit test for function checksum
def test_checksum():
    test_file_path = os.path.join(os.path.dirname(__file__), 'file1.txt')
    result = checksum(to_bytes(test_file_path, errors='surrogate_or_strict'))
    assert result == '2e6e5af6da5f6abe5ee7d5c5a5b07dcd1d63adfa'


# Generated at 2022-06-23 13:59:05.228156
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert '5eb63bbbe01eeed093cb22bb8f5acdc3' == md5s('')
        assert '715308b80e7a0f6026658879a3ecf3d3' == md5s('hello')


# Generated at 2022-06-23 13:59:08.996260
# Unit test for function md5s
def test_md5s():
    from ansible.utils.hashing import md5s
    assert md5s("hello") == '5d41402abc4b2a76b9719d911017c592'
    assert md5s("hello"*2) == '1c4e3d08f4e4d59dfb7a06b5d2a46051'


# Generated at 2022-06-23 13:59:19.547250
# Unit test for function checksum
def test_checksum():
    test_str = 'data'
    test_str_file = 'data_file'
    test_str_hash = sha1(to_bytes(test_str)).hexdigest()
    test_str_file_hash = sha1(to_bytes(test_str_file)).hexdigest()

    open(test_str_file, "w").close()

    assert checksum(test_str) == test_str_hash
    assert checksum_s(test_str) == test_str_hash
    assert checksum(test_str_file) == test_str_file_hash
    assert checksum(test_str + '_BAD') is None
    assert checksum(test_str_file + '_BAD') is None

# Generated at 2022-06-23 13:59:23.139257
# Unit test for function md5
def test_md5():
    if _md5:
        assert md5('/bin/ls') == '08fe72b9d0dfbde5c238a8a5d5b51988'
    else:
        try:
            md5('/bin/ls')
            assert False
        except(ValueError):
            assert True

# Generated at 2022-06-23 13:59:29.525704
# Unit test for function checksum
def test_checksum():

    # Create a temp file
    import tempfile
    fd, tmpsrc = tempfile.mkstemp()
    src = open(tmpsrc, "w")
    src.write("foo")
    src.close()

    # Create a temp dir
    tempdir = tempfile.mkdtemp()

    # Get the checksum
    hsh = checksum(tmpsrc)

    # Remove the temp file
    os.unlink(tmpsrc)

    assert hsh == checksum_s("foo")
    assert hsh is not None

    # Make sure we get None if the file does not exist.
    assert checksum("/tmp/fooooooo") is None
    assert checksum(tempdir) is None

# Generated at 2022-06-23 13:59:37.128930
# Unit test for function md5s
def test_md5s():
    import binascii
    data = "hello"
    h = md5s(data)
    t = binascii.hexlify(b"\x5d\xbf\x98\xbf\xfc\x92\x92\x83\x1d\x02\xc3\x35\x82\x2f\x15\x28")
    assert(t == h)

# Generated at 2022-06-23 13:59:39.879134
# Unit test for function md5
def test_md5():
    global checksum_s
    checksum_s = md5s
    test_hashs()
    global checksum
    checksum = md5
    test_hash()


# Generated at 2022-06-23 13:59:51.024745
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/sh", "sha1") == checksum("/bin/sh")
    assert checksum("/bin/false", "md5") == "a61afc9a8b0d1d25c768d606e3f2cf24"
    assert checksum("/bin/false", "sha1") == "f1c20d13826f683b2aa24cbf40d9c2b2bce051eb"
    assert checksum("/bin/false", "sha224") == "89568aac0b7cba975fdfc6a9b6f95b2a2e6a1f39e32d4f4b6c3ca698"

# Generated at 2022-06-23 13:59:54.323471
# Unit test for function checksum
def test_checksum():
    data = b"data"
    assert checksum_s(data) == "c0afdd88e5d3eb463cf15a32a1aec6e2b6e36ce6"


# Generated at 2022-06-23 13:59:58.704038
# Unit test for function checksum
def test_checksum():
    assert checksum('/tmp/doesnotexist') == None
    assert checksum('.') == '2a9dae5d1cb0cbdb46a303786b57d6fd3c8fd3ae'
    assert checksum_s('this is a string') == '6c535d6aabf6a2f417bce38e85d1f9bf9c76b2d7'
    return True

# Generated at 2022-06-23 14:00:03.773522
# Unit test for function md5s
def test_md5s():
    '''
    Tests the md5s function.
    '''
    import StringIO

    f = StringIO.StringIO()
    f.write('abc')
    f.write('def')
    f.seek(0)
    assert md5s(f.read()) == '166c9d4a3e8e4b2d6aee7e627553013e'
    f.close()


# Generated at 2022-06-23 14:00:13.693537
# Unit test for function checksum_s
def test_checksum_s():
    test_values = dict(
        string='this is a test',
        unicode_string=u'unicode \u20ac string',
        utf8_bytestring=b'\xc3\xa9',
        list=['a', 'list', 'of', 'stuff'],
        integer=42,
    )

# Generated at 2022-06-23 14:00:15.864184
# Unit test for function md5
def test_md5():

    assert md5(__file__)

# Generated at 2022-06-23 14:00:20.479306
# Unit test for function md5s
def test_md5s():
    test_str = 'mytextfile'
    digest = md5s(test_str)
    print(digest)
    assert(digest == '75450f9c7cb9bf82811f90d0f0bed62d')


# Generated at 2022-06-23 14:00:22.442314
# Unit test for function checksum_s
def test_checksum_s():
    res = checksum_s('test')
    assert res == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'



# Generated at 2022-06-23 14:00:25.103193
# Unit test for function checksum
def test_checksum():
    # Create sample file
    with open('test.txt', 'w') as f:
        f.write("test string\nsecond line")
    # Calculate checksum of sample file
    check = checksum('test.txt')
    # Delete sample file
    os.remove('test.txt')
    # Return checksum
    return check

# Generated at 2022-06-23 14:00:34.112632
# Unit test for function checksum_s
def test_checksum_s():
    #Test with integer value as argument
    assert checksum_s(23) == 'dd9d67b371519c339ed8dbd25af90e976a1eeefd'
    #Test with a float value as argument
    assert checksum_s(23.0) == '2a91079cd0a1d0fb8e494a9b22d7a137f26d8c4f'
    #Test with a string value as argument
    assert checksum_s("23") == '3f25b381c0cd98e2c35c8739c1dfe69833eab064'
    #Test with a unicode value as argument

# Generated at 2022-06-23 14:00:38.591699
# Unit test for function md5
def test_md5():
    '''md5 should return the same value as the openssl client'''
    assert md5(__file__) == '78cbc87d9b334ae7c1ef730db75f5700'
    assert md5s(__file__) == md5(__file__)

# Generated at 2022-06-23 14:00:43.715226
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('blah') == '8b743631c62afb5e49c7c117b851d3b3f3ba0c72'
    assert checksum_s('blah', _md5) == 'eb8e270f84d70efb0ed0f2dc6b1cdec7'



# Generated at 2022-06-23 14:00:49.427131
# Unit test for function md5s
def test_md5s():
    if _md5:
        ret = md5s('foobar')
        assert ret == '3858f62230ac3c915f300c664312c63f'
    else:
        try:
            md5s('foobar')
        except ValueError:
            ret = True
        else:
            ret = False
        assert ret

# Generated at 2022-06-23 14:00:59.045134
# Unit test for function md5s
def test_md5s():
    import sys

    if sys.version_info < (2, 5):
        return

    from ansible.compat.tests import unittest
    import string
    import random

    class TestMd5s(unittest.TestCase):

        def setUp(self):
            self.rand_data = ''.join(random.choice(string.ascii_uppercase + string.digits) for x in range(1024))
            self.known_hash = md5s(self.rand_data)

        def test_md5s(self):
            self.assertEqual(self.known_hash, md5s(self.rand_data))


# Generated at 2022-06-23 14:01:06.543079
# Unit test for function checksum
def test_checksum():
    ''' unit test for checksum '''
    from ansible.compat.tests import unittest

    class TestChecksum(unittest.TestCase):
        ''' unit test for checksum '''
        def test_checksum(self):
            ''' test checksum '''

            # test for secure_hash_s
            data = "foo"
            hash_func = sha1
            secure_hash_s_result = secure_hash_s(data, hash_func)
            self.assertEqual(secure_hash_s_result, "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33")

            data = "bar"
            hash_func = sha1

# Generated at 2022-06-23 14:01:09.581463
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == '7aef54b944e7c1a18a6c788e65507730'


# Generated at 2022-06-23 14:01:14.141313
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello world") == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed", \
        "Inconsistent checksum_s for string 'hello world'"


# Generated at 2022-06-23 14:01:17.490331
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('"{ foo }"') == 'd79b5c9b0c9d26f12b7d28c50b8f7f93f49ce4e2'



# Generated at 2022-06-23 14:01:21.178894
# Unit test for function checksum
def test_checksum():
    filename = './test_utils/sum.txt'
    digest = 'd4954d2ecb0f9e9a4dee5ad7a70c28a1'
    assert(checksum(filename) == digest)

# Generated at 2022-06-23 14:01:26.691352
# Unit test for function md5
def test_md5():
    res = md5s('kike')
    assert res == '1688f7db4f51848f6238a80be92f8d7b', 'md5s() test failed'

    res = md5('/etc/passwd')
    assert res == '8d3b67e73e904ea66f73d4729c7a21f1', 'md5() test failed'

# Generated at 2022-06-23 14:01:31.439853
# Unit test for function md5s
def test_md5s():
    """Test md5s function"""
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    data1 = 'this is my data'
    data2 = 'this is my data'

    if md5s(data1) != md5s(data2):
        raise Exception('md5s function failed')


# Generated at 2022-06-23 14:01:38.532092
# Unit test for function checksum
def test_checksum():
    ''' test_checksum() - Check if the function `checksum` is working as expected '''
    def prepare(tempfile, content):
        f = open(tempfile, "w")
        f.write(content)
        f.close()
        return checksum(tempfile)

    import tempfile
    temp = tempfile.mktemp()
    result = prepare(temp, "Hello World")
    assert result == "0a4d55a8d778e5022fab701977c5d840bbc486d0"
    os.remove(temp)


# Generated at 2022-06-23 14:01:44.286227
# Unit test for function md5s
def test_md5s():
    assert md5s(data='hello world') == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s(data='this is a longer string, with special /^%$#@!`~chars') == "52e1df8ccc2f93dcf546a1a8a334ec8d"

# Generated at 2022-06-23 14:01:54.099043
# Unit test for function md5s
def test_md5s():
    import subprocess
    from ansible.module_utils.six.moves import shlex_quote

    cmd = "echo -n 'ansible' | "
    for h in ['md5sum', 'sha1sum', 'sha224sum']:
        cmd += "%s - | awk '{print $1}' | tr -d '\n';" % shlex_quote(h)
    results = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    results = results.stdout.read().split(';')
    results = [r.decode() for r in results]

# Generated at 2022-06-23 14:02:03.584697
# Unit test for function checksum
def test_checksum():
    ''' unit testing for checksum function '''
    from ansible.module_utils import basic


# Generated at 2022-06-23 14:02:09.629342
# Unit test for function md5s
def test_md5s():
    if _md5:
        hashsum = md5s('foo')
        assert hashsum == 'acbd18db4cc2f85cedef654fccc4a4d8'
        hashsum = md5s(u'foo')
        assert hashsum == 'acbd18db4cc2f85cedef654fccc4a4d8'
        hashsum = md5s(b'foo')
        assert hashsum == 'acbd18db4cc2f85cedef654fccc4a4d8'
        print('test_md5s successful')
    else:
        print('MD5 not available so test_md5s skipped')


if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-23 14:02:17.289562
# Unit test for function checksum_s
def test_checksum_s():
    ''' return a secure hash hex digest of data'''
    assert checksum_s('string_data') == '0ed0bb46c21c204b2d2df33310e44a1c7e93bdb9'
    assert checksum_s('int_data') == 'f6c5a6a5e6b5f6e5d6c5a6a5e6b5f6e5d6c5a6a5e6b5f6e50'


# Generated at 2022-06-23 14:02:21.958063
# Unit test for function checksum_s
def test_checksum_s():

    class MyHash:
        def __init__(self):
            self.hexdigest = ''

        def update(self, x):
            self.hexdigest = x.encode('utf-8').hex()

    myhash = MyHash()

    assert secure_hash_s('hello', MyHash) == '68656c6c6f'

# Generated at 2022-06-23 14:02:30.870650
# Unit test for function checksum_s
def test_checksum_s():
    try:
        assert checksum_s(b"test data here") == "9a0364b9e99bb480dd25e1f0284c8555"
        assert checksum_s("test data here") == "9a0364b9e99bb480dd25e1f0284c8555"
        assert checksum_s(u'test data here') == "9a0364b9e99bb480dd25e1f0284c8555"
    except AssertionError:
        raise AssertionError("unit test failed")


# Generated at 2022-06-23 14:02:36.821628
# Unit test for function checksum
def test_checksum():
    ''' test_checksum() of util/hashing.py '''

    pw = '123'
    password_hash = 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3'
    assert checksum_s(pw) == password_hash, "incorrect checksum for password '123'"

if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-23 14:02:41.088049
# Unit test for function md5s
def test_md5s():
    data_string = 'test string'
    data_string_md5_value = '87428fc522803d31065e75d166a41fdf'

    md5_value = md5s(data_string)
    assert md5_value == data_string_md5_value

# Generated at 2022-06-23 14:02:45.448237
# Unit test for function checksum
def test_checksum():
    test_file = 'sha1.py'
    test_file_path = os.path.join(os.path.dirname(__file__), test_file)
    assert checksum('nonexistent_file') == None
    assert checksum(test_file_path) == checksum_s(open(test_file_path).read())

# Generated at 2022-06-23 14:02:48.882727
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'd3b07384d113edec49eaa6238ad5ff00'
    assert md5('/etc/shadow') is None

# Generated at 2022-06-23 14:02:54.129673
# Unit test for function md5
def test_md5():
    import tempfile
    f = tempfile.NamedTemporaryFile(delete=False)
    f.write(b'Test data')
    f.close()
    try:
      assert md5(f.name) == "e3a3b3fc4bc4a60d4bc9c84b4f4a5c84"
    finally:
      os.unlink(f.name)

# Generated at 2022-06-23 14:03:04.979598
# Unit test for function md5s
def test_md5s():
    if not _md5:
        print("MD5 tests skipped because MD5 is not available")
        return

    answer = "e1b84c2f9566f8bb9c9bf130e86cdc7b"

    data = "abc123"
    our_answer = md5s(data)
    if our_answer != answer:
        raise AssertionError("MD5s('%s') = '%s' - should be '%s'" % (data, our_answer, answer))

    data = "123abc"
    our_answer = md5s(data)
    if our_answer == answer:
        raise AssertionError("MD5s('%s') = '%s' - should not be '%s'" % (data, our_answer, answer))


# Generated at 2022-06-23 14:03:12.611465
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, mock_open, Mock

    class TestChecksum(unittest.TestCase):

        def setUp(self):
            self.mock_module = Mock()
            self.mock_module.params = {}

        def tearDown(self):
            pass

        @patch('ansible.module_utils.basic.AnsibleModule')
        def test_checksum(self, mock_AnsibleModule):

            mock_AnsibleModule.return_value = self.mock_module
            mock_open_return = mock_open(read_data='foo')

# Generated at 2022-06-23 14:03:23.915932
# Unit test for function checksum
def test_checksum():

    import tempfile

    a = """This is a test
    of the emergency broadcast system"""

    b = """This is a test
    of the emergency broadcast system
    """

    c = """This is a test
    of the emergency broadcast system
    """

    d = """This is a test
    of the emergency broadcast system
    """

    (fd1, f1) = tempfile.mkstemp()
    (fd2, f2) = tempfile.mkstemp()
    (fd3, f3) = tempfile.mkstemp()
    (fd4, f4) = tempfile.mkstemp()
    (fd5, f5) = tempfile.mkstemp()
    os.write(fd1, a)
    os.write(fd2, b)
    os.write(fd3, c)
    os

# Generated at 2022-06-23 14:03:26.457468
# Unit test for function md5s
def test_md5s():
    assert md5s("test") == "098f6bcd4621d373cade4e832627b4f6"



# Generated at 2022-06-23 14:03:30.220625
# Unit test for function checksum
def test_checksum():
    filename = os.path.join(os.path.dirname(__file__), './lib_utils.py')
    assert checksum(filename) == '3a6d3a6c9b6f9d3a54b59e3acb434ddf72a1d6c1'


# Generated at 2022-06-23 14:03:34.093395
# Unit test for function checksum
def test_checksum():
    if checksum('/bin/ls') != 'fdf7c2687929b9ac8da94c8fefd7f7cb408ae258':
        raise Exception("failed checkum test")
    if checksum('/usr/bin/python') != 'c33304f0e1b7d8b4594a6c26e96b9c5f':
        raise Exception("failed checkum test")

# Generated at 2022-06-23 14:03:41.420214
# Unit test for function md5
def test_md5():
    import os
    import tempfile
    test_file = tempfile.NamedTemporaryFile(delete=False)
    test_file.write('test')
    test_file.close()
    test_md5 = md5(test_file.name)
    os.unlink(test_file.name)
    if test_md5 != '098f6bcd4621d373cade4e832627b4f6':
        raise ValueError('MD5 function broken')

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 14:03:52.960497
# Unit test for function checksum
def test_checksum():
    # pylint: disable=too-many-locals
    ''' unit test for checksum '''
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import io
    import tempfile

    host_all = Group('all')
    host_all.vars = combine_vars(host_all.vars, {'foo': 'bar'})
    host = Host('hostname')
    host.vars = {'baz': 'qux'}
    host.set_variable('var1', 'value1')
    host.set_

# Generated at 2022-06-23 14:03:59.853129
# Unit test for function md5
def test_md5():
    with open('test_shell_hash_patch.py', 'rb') as f:
        r = f.read()

    assert secure_hash_s(r, _md5) == md5s(r)
    assert secure_hash('./test_shell_hash_patch.py', _md5) == md5('./test_shell_hash_patch.py')

if __name__ == '__main__':
    test_md5()