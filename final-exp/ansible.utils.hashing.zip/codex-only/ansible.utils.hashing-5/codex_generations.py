

# Generated at 2022-06-23 13:54:02.340498
# Unit test for function md5
def test_md5():
    expected = 'b41bd6dd7e6eaf783b9d308014c9d6c2'
    data = "some string"
    assert md5s(data) == expected

# Generated at 2022-06-23 13:54:08.659112
# Unit test for function md5
def test_md5():
    """Unit tests for module which verifies MD5 checksum.
    """
    import unittest
    import shutil

    class Testmd5(unittest.TestCase):
        """Tests the md5 checksum feature.
        """
        def setUp(self):
            """Creates a tempfile for testing.
            """
            import tempfile

            self.tempdir = tempfile.mkdtemp()
            self.tempfile = os.path.join(self.tempdir, "tempfile")

        def tearDown(self):
            """Removes the tempfile.
            """
            shutil.rmtree(self.tempdir)

        def test_md5(self):
            """Tests that the md5 checksum is calculated.
            """
            self.assertEqual(md5(self.tempfile), None)

# Generated at 2022-06-23 13:54:15.772458
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('this is a string') == 'ce114e4501d2f4e2dcea3e17b546f339'
    assert md5s('foo\n') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5('testing') == 'ae2b1fca515949e5d54fb22b8ed95575'


# Generated at 2022-06-23 13:54:18.584432
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foobar') == '8843d7f92416211de9ebb963ff4ce28125932878'


# Generated at 2022-06-23 13:54:21.639772
# Unit test for function md5s
def test_md5s():
    assert md5s("test") == "098f6bcd4621d373cade4e832627b4f6"



# Generated at 2022-06-23 13:54:29.379616
# Unit test for function md5s
def test_md5s():
    if not _md5:
        print("cannot test md5s in FIPS mode")
        return

    import unittest
    class TestSequenceFunctions(unittest.TestCase):

        def setUp(self):
            pass

        def test_md5s(self):
            string = "test string"
            expected = "5a47d12a2e3f9fecf2d9ba1fd98152eb"
            observed = md5s(string)
            self.assertEqual(expected, observed)

    unittest.main()

# Generated at 2022-06-23 13:54:39.231139
# Unit test for function checksum
def test_checksum():
    import random
    import string
    for size in [8*1024, 16*1024, 64*1024, 1024*1024]:
        for block_size in [32, 64, 128, 256]:
            data = ''.join(random.choice(string.ascii_letters) for _ in range(size))
            sha1_val = checksum_s(data, sha1)
            md5_val = md5s(data)
            sha1_fp = checksum("/dev/stdin", sha1, data)
            assert(sha1_val == sha1_fp)
            md5_fp = md5("/dev/stdin", data)
            assert(md5_val == md5_fp)

# Generated at 2022-06-23 13:54:46.181004
# Unit test for function checksum
def test_checksum():
    def _check(data, hashed):
        assert(hashed == checksum_s(data))
    _check("foo", "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33")
    _check("", "da39a3ee5e6b4b0d3255bfef95601890afd80709")
    _check("hello world", "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed")


# Generated at 2022-06-23 13:54:53.057222
# Unit test for function md5
def test_md5():
    # create a temporary file for testing MD5 calculation
    (fd, fname) = tempfile.mkstemp()
    os.close(fd)

    # write some content to the temporary test file
    fd = open(fname, 'w')
    fd.write("hello world")
    fd.close()

    # check if the MD5 of the file is correct
    assert md5(fname) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

    # cleanup
    os.remove(fname)

# TODO: Move these to the ansible.utils.unicode module
# These functions are necessary for Python 2.4 and 2.6 support
# as Python 2.4 does not have str.decode() and Python 2.6
# does not have unicode.encode().


# Generated at 2022-06-23 13:54:56.481124
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == checksum('/bin/ls')
    assert checksum('/bin/ls') != checksum('/bin/cat')



# Generated at 2022-06-23 13:54:59.503688
# Unit test for function md5s
def test_md5s():
    value = md5s("Ansible test string")
    print ("MD5S(\"Ansible test string\") = " + value)

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-23 13:55:10.061615
# Unit test for function checksum_s
def test_checksum_s():
    if not secure_hash_s('foo', sha1) == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33':
        raise ValueError('checksum_s failed on sha1')
    if not secure_hash_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33':
        raise ValueError('checksum_s failed on sha1')
    if not _md5:
        raise ValueError('MD5 required for next test')
    if not secure_hash_s('foo', _md5) == 'acbd18db4cc2f85cedef654fccc4a4d8':
        raise ValueError('checksum_s failed on md5')

# Generated at 2022-06-23 13:55:14.923904
# Unit test for function md5s
def test_md5s():
    if not _md5:
        # No need to run this test
        return

    # Known MD5 sum for the string "Hello World"
    assert md5s('Hello World') == '65a8e27d8879283831b664bd8b7f0ad4'

# Generated at 2022-06-23 13:55:17.627257
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '4d4e7a4b4affb72e8c9e4040d39b4e1c'

# Generated at 2022-06-23 13:55:19.986471
# Unit test for function checksum_s
def test_checksum_s():
    assert(checksum_s('a') == '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8')



# Generated at 2022-06-23 13:55:25.940453
# Unit test for function md5s
def test_md5s():
    string1 = "This is a test."
    string2 = "This is not a test."

    assert md5s(string1) != md5s(string2)
    assert md5s(string1) == '7cde0e9eae2c3f6aae0c7a3f0aa3c49a'


# Generated at 2022-06-23 13:55:30.643740
# Unit test for function checksum
def test_checksum():
    test_dir = os.path.dirname(__file__)
    test_file = os.path.join(test_dir, 'test_utils.py')
    if checksum(test_file) == '580eeadf1a2c3eea99ffcabb3f5b5a0825f3ec3d':
        return True
    else:
        return False

# Generated at 2022-06-23 13:55:33.703104
# Unit test for function md5s
def test_md5s():
    print("Expected value is '68b329da9893e34099c7d8ad5cb9c940'")
    print("Actual value is '" + md5s("foo") + "'")


# Generated at 2022-06-23 13:55:35.826877
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "6b8e275d73a2ef0789a8c5d76f1b7406"

# Generated at 2022-06-23 13:55:48.617019
# Unit test for function md5
def test_md5():
    from nose.plugins.skip import SkipTest
    from tempfile import mkstemp
    from os import close, unlink

    for func in [md5, md5s]:
        # If we're in FIPS mode, md5 is available.  But because we're not importing hashlib,
        # it will be False in this test.  So skip the test in that case
        if func == md5 and _md5 is False:
            raise SkipTest("MD5 not available in FIPS mode")


# Generated at 2022-06-23 13:55:52.742077
# Unit test for function md5
def test_md5():
    assert 'd41d8cd98f00b204e9800998ecf8427e' == md5('./test/ansible/module_utils/hashing.py')


# Generated at 2022-06-23 13:55:58.670389
# Unit test for function checksum
def test_checksum():
    ''' test checksum() without error '''
    h = checksum_s("hello")
    if h != "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d":
        raise Exception("unexpected checksum from 'hello'")
    h = checksum("/bin/ls")
    if h != "6fdccfd6d898aac177316acf19e893ca471a0e9c":
        raise Exception("unexpected checksum from '/bin/ls'")

# Generated at 2022-06-23 13:56:01.001386
# Unit test for function md5s
def test_md5s():
    assert(md5s('test') == '098f6bcd4621d373cade4e832627b4f6')


# Generated at 2022-06-23 13:56:02.754451
# Unit test for function checksum
def test_checksum():
    """ test checksum function """
    clear_text = 'test'
    tst_sha1 = checksum_s(clear_text)
    assert tst_sha1 == secure_hash_s(clear_text)



# Generated at 2022-06-23 13:56:12.531548
# Unit test for function checksum
def test_checksum():
    checksums = {
        'file1': '95a4a8c865d25a9341e96620aaf2d8ecf8b76c2b',
        'file2': '878ff56d914b54e7ad065f8d8878e1928c3bce3f',
        'file3': '1b9e0e4a4f2c4d0e4f81fc24426a37e8cf19c4ed'
    }

    pwd = os.path.dirname(os.path.realpath(__file__))
    for filename, checksum in checksums.items():
        path = os.path.join(pwd, filename)
        assert checksum == checksum(path)

# Generated at 2022-06-23 13:56:19.258132
# Unit test for function md5
def test_md5():
    assert md5("/dev/null") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5("/dev/zero") == "6dae5ca7aa26e4a138c8790886b944cf"
    assert md5("/dev/urandom") == "3667c0f0397fed185c56a6154e9b2843"
    return True


# Generated at 2022-06-23 13:56:33.789235
# Unit test for function md5
def test_md5():
    from ansible.compat.tests import unittest

    cur_dir = os.getcwd()
    tmp_file = 'tmp_file'
    try:
        os.chdir(os.path.expanduser('~'))
        open(tmp_file, 'w').close()
        assert md5(tmp_file) == 'bfbb7a8f3c5a331410c5d3e5b8a75f5d'
    finally:
        os.unlink(tmp_file)
        os.chdir(cur_dir)


# Generated at 2022-06-23 13:56:35.185599
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'



# Generated at 2022-06-23 13:56:39.762121
# Unit test for function md5
def test_md5():
    if _md5:
        assert md5("/dev/null") == 'd41d8cd98f00b204e9800998ecf8427e'
    else:
        try:
            md5("/dev/null")
        except ValueError:
            raise AssertionError("md5() not available.  Possibly running in FIPS mode")


# Generated at 2022-06-23 13:56:47.205899
# Unit test for function checksum_s
def test_checksum_s():
    '''
      Checksum_s function test
      function return True if hash of string is equal to: 52f9ff309f5e6b06d6ecb4571dee2c4a4a4c7d03
      and False otherwise
    '''
    test_string = "test string"
    return secure_hash_s(test_string) == "52f9ff309f5e6b06d6ecb4571dee2c4a4a4c7d03"

# Generated at 2022-06-23 13:56:53.261482
# Unit test for function md5
def test_md5():
    '''
    This function unit tests the module function md5
    '''

    # Create a temporary file for module to test
    p = tempfile.NamedTemporaryFile()

    # Populate the temporary file
    p.write("Hello World")
    p.seek(0)

    # Find and return checksum of above
    return md5(p.name)


# Generated at 2022-06-23 13:57:02.330476
# Unit test for function checksum_s
def test_checksum_s():
    assert secure_hash_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert secure_hash_s(u'') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert secure_hash_s('ANSIBLE') == 'e59ff97941044f85df5297e1c302d260'
    assert secure_hash_s(u'ANSIBLE') == 'e59ff97941044f85df5297e1c302d260'
    assert secure_hash_s('ANSIBLE', _md5) == 'b10a8db164e0754105b7a99be72e3fe5'

# Generated at 2022-06-23 13:57:05.181953
# Unit test for function checksum_s
def test_checksum_s():
    result = checksum_s('foobar')
    assert result == '8843d7f92416211de9ebb963ff4ce28125932878'


# Generated at 2022-06-23 13:57:08.152986
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-23 13:57:18.048154
# Unit test for function checksum
def test_checksum():
    # for the file content: "This is a test"
    # the sha1 checksum should be 8167e6d35622dd5089b6fef32b1f214b3eac8ca0
    # and the md5 checksum should be c981e49f6bfc80501d70a37b47d8ab40
    filename = '/tmp/checksum_test_file'
    with open(filename, 'w') as f:
        f.write('This is a test')
    assert checksum(filename) == '8167e6d35622dd5089b6fef32b1f214b3eac8ca0'
    if _md5:
        assert md5(filename) == 'c981e49f6bfc80501d70a37b47d8ab40'
    os

# Generated at 2022-06-23 13:57:26.517713
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5('/etc/hosts') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5('/path/to/nonexistent/file') is None
    assert md5('/path/to/directory') is None
    assert md5(1) is None

    # Test unicode MD5
    if os.name == 'nt':
        # Skip this test on Windows because Windows doesn't allow unicode
        # characters in file names.
        return
    filename = '/path/to/nonexist\xe9nt/file.txt'
    assert md5(filename) is None

# Generated at 2022-06-23 13:57:32.326158
# Unit test for function checksum
def test_checksum():
    import sys
    sys.path.insert(0, os.path.dirname(__file__))
    import test_utils
    checksum_test = test_utils.load_module_from_path('../../test/utils/test_checksum.py')
    checksum_test.test_checksum()

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 13:57:35.583695
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    try:
        import doctest
        doctest.testmod()
    except ImportError:
        print("could not import doctest")

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-23 13:57:45.900978
# Unit test for function md5
def test_md5():
    if not _md5:
        print("md5 not available.  Possibly running in FIPS mode")
        return
    tmpfile = "/tmp/ansible_test_md5.txt"
    data = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    f = open(tmpfile, 'w')
    f.write(data)
    f.close()
    digest = md5(tmpfile)
    os.unlink(tmpfile)
    if digest == "bbc2a095b2dcd84c92d919f988f93526":
        print("md5() test successful")
    else:
        print("md5() test failed")


# Generated at 2022-06-23 13:57:53.092277
# Unit test for function md5s
def test_md5s():
    import tempfile
    test_file = tempfile.NamedTemporaryFile(delete=False)
    test_file.write('Hello World')
    test_file.close()

    try:
        assert(md5s('Hello World') == 'ed076287532e86365e841e92bfc50d8c')
        assert(md5('Hello World') == 'ed076287532e86365e841e92bfc50d8c')
        assert(md5(test_file.name) == 'ed076287532e86365e841e92bfc50d8c')
    finally:
        os.remove(test_file.name)

# Generated at 2022-06-23 13:58:04.462103
# Unit test for function md5
def test_md5():
    if not _md5:
        print("md5 not available")
        sys.exit(0)
    from binascii import unhexlify
    import os
    import tempfile
    # create temporary file with contents "test_md5"
    file = tempfile.NamedTemporaryFile()
    file.write("test_md5")
    file.flush()
    # generate and check md5 of tempfile.name
    digest = md5(file.name)
    file.close()
    if digest != "70d12f17e07c8e507acc638022285a5e":
        raise ValueError("md5 test failed, got %s" % digest)
    print("md5 test passed.")

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 13:58:16.058875
# Unit test for function md5
def test_md5():
    # Create a test file and make sure it's deleted when done
    fh, fname = tempfile.mkstemp()
    class Cleanup:
        def __init__(self, name):
            self.name = name
        def __del__(self):
            os.unlink(self.name)
    test_file = Cleanup(fname)

    # Test md5 on the empty file
    assert md5(fname) == 'd41d8cd98f00b204e9800998ecf8427e'

    # Test md5s on the empty string
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'

    # Test md5s on a string with a newline

# Generated at 2022-06-23 13:58:18.929256
# Unit test for function md5
def test_md5():
    testsum = 'e2ed2b8c8a827b736d0c6855a7a8c46a'
    assert(md5('/etc/hosts') == testsum)



# Generated at 2022-06-23 13:58:24.649427
# Unit test for function checksum_s
def test_checksum_s():
    ''' test checksum_s function '''

    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_s('foo', sha1) == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

    # Run module specific unit tests
    test_checksum_s()

# Generated at 2022-06-23 13:58:34.160567
# Unit test for function md5s
def test_md5s():
    """Test md5s correct output"""
    import random
    test_data = {}
    for i in range(0, 100):
        test_data[i] = ''.join(random.choice('0123456789ABCDEF') for j in range(20))
        if md5s(test_data[i]) != ('d41d8cd98f00b204e9800998ecf8427e' if test_data[i] == '' else '983e57c0f959e6c5d975999d79a4a4b4'):
            raise AssertionError('MD5S did not return the correct output')


# Generated at 2022-06-23 13:58:37.663069
# Unit test for function checksum_s
def test_checksum_s():
    data = 'Hello world!'
    d = secure_hash_s(data)
    assert d == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'



# Generated at 2022-06-23 13:58:40.928291
# Unit test for function md5s
def test_md5s():
    data = 'test123'
    ret = md5s(data)
    assert ret == '19dfac8ec6ac16b6e2070b0c7b0cd4b4'



# Generated at 2022-06-23 13:58:44.710513
# Unit test for function checksum_s
def test_checksum_s():
    data = u"foooo"
    checksum = secure_hash_s(data)
    assert checksum == "bdfb4b1d8fb0fee81afcd1756b96a4e7cd4a16d4"

# Generated at 2022-06-23 13:58:49.056446
# Unit test for function checksum
def test_checksum():
    import os
    import tempfile
    fd, temp_path = tempfile.mkstemp()
    with open(fd, 'w') as f:
        f.write('Hello, World')
    os.close(fd)
    assert(checksum(temp_path) == checksum_s('Hello, World'))
    os.remove(temp_path)

# Generated at 2022-06-23 13:58:56.683752
# Unit test for function checksum
def test_checksum():
    assert checksum_s(u'hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(b'hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(b'hello world', to_bytes('md5', errors='strict')) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert checksum_s(None) is None



# Generated at 2022-06-23 13:59:07.775530
# Unit test for function checksum_s
def test_checksum_s():
    """Return a secure hash hex digest of data."""
    assert 'da39a3ee5e6b4b0d3255bfef95601890afd80709' == checksum_s('')
    assert 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3' == checksum_s('a')
    assert '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8' == checksum_s('abc')
    assert 'fd2aa607f71dc8f510714922b371834e15a2c45e' == checksum_s('message digest')
    assert 'ab56b4d92b40713acc5af89985d4b786' == md5s('')

# Generated at 2022-06-23 13:59:13.305497
# Unit test for function md5
def test_md5():
    '''
    Ensure that in FIPS mode, a ValueError is raised
    '''
    global _md5
    _md5 = None
    try:
        md5('/bin/ls')
        assert False, 'No exception raised'
    except ValueError:
        pass
    _md5 = __import__('hashlib').md5
    assert '4eca6e8d6d5e39db1b634c05ea3a3c89' == md5('/bin/ls')

# Generated at 2022-06-23 13:59:22.591797
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('message digest') == 'f96b697d7cb7938d525a2f31aaf161d0'
    assert md5s('abcdefghijklmnopqrstuvwxyz') == 'c3fcd3d76192e4007dfb496cca67e13b'

# Generated at 2022-06-23 13:59:29.795671
# Unit test for function md5s
def test_md5s():
    assert md5s("") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5s("a") == "0cc175b9c0f1b6a831c399e269772661"
    assert md5s("abc") == "900150983cd24fb0d6963f7d28e17f72"
    assert md5s("message digest") == "f96b697d7cb7938d525a2f31aaf161d0"
    assert md5s("abcdefghijklmnopqrstuvwxyz") == "c3fcd3d76192e4007dfb496cca67e13b"

# Generated at 2022-06-23 13:59:36.846229
# Unit test for function checksum_s
def test_checksum_s():
    assert checksum_s("hello world", sha1) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s("hellö wörld", sha1) == 'f01c9106e9f8c8f7122a33c0e08a724fd8b5cff7'

# Generated at 2022-06-23 13:59:43.293055
# Unit test for function checksum
def test_checksum():
    '''
    This function is used to test the checksum function. The following values are provided:
    the string, the filename, and the 'return value'. This value is what the function should
    return if the string or file is passed in.
    '''

# Generated at 2022-06-23 13:59:53.457575
# Unit test for function checksum
def test_checksum():
    import io

    assert checksum_s(u'1234') == '81dc9bdb52d04dc20036dbd8313ed055'

    try:
        checksum_s(u'1234', hash_func=_md5)
    except ValueError:
        pass
    else:
        assert False

    f1 = io.StringIO(u'1234')
    assert checksum(f1) == '81dc9bdb52d04dc20036dbd8313ed055'

    f2 = io.StringIO(u'12345')
    assert checksum(f2) == 'd015fbe972ed5a5c5d8b5c916135abda'

    try:
        checksum(f2, hash_func=_md5)
    except ValueError:
        pass


# Generated at 2022-06-23 13:59:57.815153
# Unit test for function checksum
def test_checksum():
    if checksum(__file__) == None:
        print('test_checksum: checksum test failed.')
        return False

    if checksum_s(__file__) == None:
        print('test_checksum: checksum_s test failed.')
        return False

    return True


# Generated at 2022-06-23 14:00:05.447316
# Unit test for function md5s
def test_md5s():

    from ansible.module_utils._text import to_bytes
    from binascii import unhexlify

    assert md5s(b"asdf") == "912ec803b2ce49e4a541068d495ab570"
    assert md5s(u"asdf") == "912ec803b2ce49e4a541068d495ab570"
    assert (md5s(u"asdf") == md5s(b"asdf"))
    assert md5s(u"asdf") == to_bytes(unhexlify("912ec803b2ce49e4a541068d495ab570"))
    assert md5s(b"asdf") == to_bytes(unhexlify("912ec803b2ce49e4a541068d495ab570"))
   

# Generated at 2022-06-23 14:00:09.555918
# Unit test for function checksum
def test_checksum():
    if checksum('/etc/hosts') != '2bac7e19e8a82936b04fa9d6bb788f8a':
        raise ValueError('Wrong answer')


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 14:00:11.576703
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-23 14:00:18.816848
# Unit test for function checksum
def test_checksum():
    testfile = "/tmp/foobar"
    open(testfile, "w").write('test')
    assert(checksum(testfile) == checksum_s(open(testfile).read()))
    if _md5:
        # This test may fail if FIPS mode is enabled
        assert(md5(testfile) == md5s(open(testfile).read()))

# Generated at 2022-06-23 14:00:23.191169
# Unit test for function checksum_s
def test_checksum_s():
    data = 'Hello World'
    digest = secure_hash_s(data)
    assert digest == '2ef7bde608ce5404e97d5f042f95f89f1c232871'


# Generated at 2022-06-23 14:00:25.068608
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return
    assert md5s(b'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-23 14:00:26.480644
# Unit test for function md5
def test_md5():
    assert md5("/noway/this/exists.txt") is None

# Generated at 2022-06-23 14:00:30.747082
# Unit test for function checksum_s
def test_checksum_s():
    s = 'SHA1 hash of string'
    assert checksum_s(s) == 'e8750a7d913de1b6f731d87a3cfc45b01ee39b93'
    assert checksum_s(s, sha1) == 'e8750a7d913de1b6f731d87a3cfc45b01ee39b93'


# Generated at 2022-06-23 14:00:42.944269
# Unit test for function checksum
def test_checksum():
    ''' test_cksum.py:  Tests the checksum function. '''

    import datetime
    import shutil
    import tempfile

    # Setup temp directory
    tmpdir = tempfile.mkdtemp()

    # Test checksum on empty file
    fpath = os.path.join(tmpdir, 'empty')
    open(fpath, 'a').close()
    assert checksum(fpath) == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'

    # Test checksum on a file containing a single letter
    fpath = os.path.join(tmpdir, 'x')
    open(fpath, 'w').write('x')

# Generated at 2022-06-23 14:00:46.455187
# Unit test for function md5
def test_md5():
    assert md5('/tmp/abc123xyz') == 'd8f7addb6c4a11e4c4d4ca3e8d4134f5'


# Generated at 2022-06-23 14:00:51.399976
# Unit test for function checksum
def test_checksum():
    assert(checksum("/bin/ls") == '80ca0fc949e81bff5fbf71a3b006d9b8')
    assert(md5("/bin/ls") == '8e8adc7d0e85aacd7cd947373cf2b884')

# Generated at 2022-06-23 14:00:54.454960
# Unit test for function md5s
def test_md5s():
    assert md5s("Python") == "2eb9b0a17b41f848ba67f7139dbf59d0"
    assert md5s("Python") == secure_hash_s("Python", _md5)

# Generated at 2022-06-23 14:00:57.912802
# Unit test for function checksum_s
def test_checksum_s():
    print("Testing checksum_s")
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

# Test function md5s

# Generated at 2022-06-23 14:01:08.008160
# Unit test for function checksum
def test_checksum():
    print('Testing checksum module:')

    # Compare old and new functions
    from ansible.module_utils.six import PY3
    if PY3:
        string = "ab"
        print(u'\tString: {0}, old checksum: {1}, new checksum: {2}'.format(string, md5s(string), checksum_s(string)))
        assert md5s(string) == checksum_s(string)
    else:
        print(u'\tPython2, old checksum: {0}, new checksum: {1}'.format(md5s(b'ab'), checksum_s(b'ab')))
        assert md5s(b'ab') == checksum_s(b'ab')

    print('Passed')


# Generated at 2022-06-23 14:01:19.974054
# Unit test for function md5
def test_md5():
    import tempfile

    data_file_path = tempfile.mkstemp()[1]
    file_data = '123456789'
    checksum_md5 = '25f9e794323b453885f5181f1b624d0b'
    checksum_md5s = '78e731027d8fd50ed642340b7c9a63b3'

    f = open(data_file_path, 'w')
    f.write(file_data)
    f.close()

    assert checksum_md5 == md5(data_file_path)
    assert checksum_md5s == md5s(file_data)


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 14:01:28.630337
# Unit test for function checksum
def test_checksum():
    assert checksum_s("12345") == "827ccb0eea8a706c4c34a16891f84e7b"
    assert md5s("12345") == "827ccb0eea8a706c4c34a16891f84e7b"
    assert checksum("/bin/ls") == "6e1b6ab1b6cc9f6a8f6d6965a89f86d0"
    assert md5("/bin/ls") == "6e1b6ab1b6cc9f6a8f6d6965a89f86d0"


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 14:01:32.334483
# Unit test for function checksum_s
def test_checksum_s():
    result = checksum_s('test-data')
    assert result == '3b3e737661394f1a58c9f0fa6ea8cce40e996950'

# Generated at 2022-06-23 14:01:37.269269
# Unit test for function md5
def test_md5():
    ''' md5 should return different results on different data '''

    assert md5s('text') != md5s('txet')
    # pylint: disable=unused-variable
    # do not remove or we might change the test
    text1, text2 = 'text', 'txet'
    assert md5s(text1) != md5s(text2)



# Generated at 2022-06-23 14:01:40.983574
# Unit test for function checksum_s
def test_checksum_s():
    s = "sample text"
    """
    result = checksum_s(s)
    assert result == "1c70daaa9b01d7e6a9f6a46bf39af3b6bd3d3a07"
    """

# Generated at 2022-06-23 14:01:52.690902
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import os


# Generated at 2022-06-23 14:01:55.900361
# Unit test for function md5
def test_md5():
    """Ensure md5 behaves correctly"""
    assert md5('/dev/null') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-23 14:02:04.648410
# Unit test for function checksum
def test_checksum():
    hash_func = sha1
    if secure_hash_s("foo", hash_func) != "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33":
        raise ValueError("failed to hash string with checksum_s")
    if secure_hash("./test/test_utils/test_checksum.py", hash_func) != "d38a86a7ac159843b9c7f8a28ebcf702ed7a1a0a":
        raise ValueError("failed to hash file with checksum")
    # Now check backwards compat only
    if not _md5:
        return

# Generated at 2022-06-23 14:02:10.263591
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == '5e539cfb5d5cecdd1ba9c1b7a203c631'
    assert md5s('this is a test') == '5f5d7e8e9bf40f9b1f9e29d7c8f2eca2'
    assert secure_hash('/etc/passwd') == '45f974e277d1d0e8e0a53139a1c6d8e7e5627b69'
    assert secure_hash_s('this is a test') == '1d0c30228ddaa0283a5753a5a58e948b3d8eb0f3'

# end of file

# Generated at 2022-06-23 14:02:13.967843
# Unit test for function md5
def test_md5():
    s = "hello world"
    h = "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s(s) == h



# Generated at 2022-06-23 14:02:18.198751
# Unit test for function md5
def test_md5():
    from tempfile import NamedTemporaryFile
    t = NamedTemporaryFile()
    t.write(b'foobar')
    t.flush()
    assert md5(t.name) == '8843d7f92416211de9ebb963ff4ce28125932878'



# Generated at 2022-06-23 14:02:20.888162
# Unit test for function md5s
def test_md5s():
    assert(md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8')


md5sum = md5

# Generated at 2022-06-23 14:02:25.733113
# Unit test for function checksum_s
def test_checksum_s():
    ''' Test checksum_s function '''

    checksum1 = '9a0364b9e99bb480dd25e1f0284c8555'
    checksum2 = checksum_s('ansible')
    assert checksum1 == checksum2

# Generated at 2022-06-23 14:02:31.223853
# Unit test for function md5
def test_md5():
    assert md5s("abc") == '900150983cd24fb0d6963f7d28e17f72'
    assert md5("test/files/checksumtest") == 'a5f1d5dadea2706db72f37c322dc973f'

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 14:02:33.944503
# Unit test for function md5s
def test_md5s():

    errmsg = "md5s function has failed the smoke test"
    assert md5s('string') == "2ac21dcf5fd6169a17f8a0b961df6c89", errmsg


# Generated at 2022-06-23 14:02:35.465046
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '2d18b582a8b57aa206a7bc1a2cfb2e80'

# Generated at 2022-06-23 14:02:45.931090
# Unit test for function checksum
def test_checksum():
    # Normal case
    filename = '/bin/ls'
    assert secure_hash(filename) == 'b9cbfb27098d57fbac1011f6db7e66c3e17b7d50'
    assert secure_hash(filename, sha1) == 'b9cbfb27098d57fbac1011f6db7e66c3e17b7d50'
    assert secure_hash(filename, None) == 'b9cbfb27098d57fbac1011f6db7e66c3e17b7d50'

    # Dir case
    filename = '/tmp'
    assert secure_hash(filename) is None
    assert secure_hash(filename, sha1) is None
    assert secure_hash(filename, None) is None

    # Not exist case
    filename

# Generated at 2022-06-23 14:02:50.397435
# Unit test for function checksum_s
def test_checksum_s():
    data = '{"changed": false, "ping": "pong"}'
    assert checksum_s(data) == '6b21a6c169a6d04f6cb1749c0f78150e00f1c8ac'

# Generated at 2022-06-23 14:02:54.156514
# Unit test for function md5
def test_md5():
    assert md5('/tmp/aaa') != md5('/tmp/bbb')
    assert md5('/tmp/aaa') == md5('/tmp/aaa')


# Generated at 2022-06-23 14:02:58.375992
# Unit test for function md5
def test_md5():
    fd, tmpsum = tempfile.mkstemp()
    try:
        tmpfn = tmpsum + ".tmp"
        with os.fdopen(fd, "w") as f:
            f.write("blah")

        assert md5(tmpfn) == md5s("blah")
    finally:
        os.unlink(tmpsum)
        os.unlink(tmpfn)

# Generated at 2022-06-23 14:03:08.483769
# Unit test for function checksum_s
def test_checksum_s():
    sha1_sum1='3e7b26e3cb3f3e8913f5851d6523abeef24c9c1b'
    sha1_sum2='41f5c5b56cabbdbd47e7f2c359e8a7c0b4a66521'
    data1 = 'hello'
    data2 = 'world'
    assert checksum_s(data1) == sha1_sum1
    assert checksum_s(data2) == sha1_sum2
    assert checksum_s(data1 + data2) == sha1_sum2
    assert md5s(data1) == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-23 14:03:09.766563
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == 'cec297ebb9d52dee9e4b4c4f4cc7f839'


# Generated at 2022-06-23 14:03:12.952924
# Unit test for function md5
def test_md5():

    filename = '/tmp/test_md5'
    f = open(filename, 'w')
    f.write('toto')
    f.close()

    result = md5(filename)
    os.remove(filename)
    assert result == '943a702d06f34599aee1f8da8ef9f729', result

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-23 14:03:20.802547
# Unit test for function md5s
def test_md5s():
    # Create a random string to test the md5s implementation
    import random, string
    s_len = random.randint(1, 128)
    s = ''.join(random.choice(string.ascii_uppercase + string.digits) for x in range(s_len))
    assert md5s(s) == "3e4c4f8b5d5f91a5f5a3bbce3d8c92ed"



# Generated at 2022-06-23 14:03:29.276309
# Unit test for function md5s
def test_md5s():
    assert md5s('test1') == '098f6bcd4621d373cade4e832627b4f6'

if __name__ == '__main__':
    import sys
    import doctest
    #try:
    #    import nose
    #except ImportError:
    #    print('No nose found, running function tests')
    #    doctest.testmod(verbose=True)
    #    sys.exit(1)
    #nose.run_exit(argv=[__file__, '-vv', '-s'])
    test_md5s()

# Generated at 2022-06-23 14:03:32.127075
# Unit test for function md5s
def test_md5s():
    ''' test_md5s '''
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-23 14:03:37.477115
# Unit test for function checksum
def test_checksum():
    if not _md5:
        return
    assert checksum_s("hello") == md5s("hello")
    assert checksum("lib/ansible/modules/core/system/setup.py") == md5("lib/ansible/modules/core/system/setup.py")

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-23 14:03:45.695502
# Unit test for function md5
def test_md5():
    test_path = os.path.join(os.path.dirname(__file__), 'files', 'file_exists')
    assert md5(test_path) == '68c97b92e1a3eb23e3a3cfe85e8aa6d9'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5(test_path) == checksum(test_path)
    assert md5s('hello world') == checksum_s('hello world')

# Generated at 2022-06-23 14:03:49.632190
# Unit test for function md5s
def test_md5s():
    value = "abcd"
    res = md5s(value)
    assert res == "e2fc714c4727ee9395f324cd2e7f331f"



# Generated at 2022-06-23 14:03:53.515296
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'



# Generated at 2022-06-23 14:04:03.691340
# Unit test for function checksum_s
def test_checksum_s():
    import random
    import tempfile

    # Create a temporary file
    temp_file = tempfile.TemporaryFile()
    temp_file.write(os.urandom(100000))
    temp_file.seek(0)

    # Calculate the hash of a string
    string = "test"
    string_hash = checksum_s(string)

    # Calculate the hash of a file
    file_hash = checksum(temp_file.name)

    assert string_hash == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', string_hash
    assert file_hash == 'c3cd1f9d2f711c36b47a7f86a4317045'