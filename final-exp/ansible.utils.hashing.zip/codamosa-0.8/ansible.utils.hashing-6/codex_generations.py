

# Generated at 2022-06-11 17:55:33.033631
# Unit test for function checksum
def test_checksum():
    assert checksum_s("Hello World!") == "ed076287532e86365e841e92bfc50d8c"

# Generated at 2022-06-11 17:55:44.415187
# Unit test for function checksum
def test_checksum():
    '''Test checksum'''
    tests = {
        # Checksum of an empty string
        '': 'da39a3ee5e6b4b0d3255bfef95601890afd80709',

        # Checksum of test string
        'test': 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3',

        # Checksum of test unicode string
        u'test': 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3',
    }
    for test, expect in tests.items():
        test = to_bytes(test, errors='surrogate_or_strict')
        assert checksum_s(test) == expect



# Generated at 2022-06-11 17:55:50.347945
# Unit test for function md5s
def test_md5s():
    ''' md5s() return value must match value returned by md5sum utility '''
    import subprocess
    import sys

    result = subprocess.Popen(["md5sum", sys.argv[0]], stdout=subprocess.PIPE).communicate()[0]
    if sys.version_info < (3,):
        # python2's Popen returns a tuple of (stdoutdata, stderrdata)
        result = result.split()[0]
    else:
        # stdoutdata is a bytes object under python3; decode
        # before comparing
        result = result.split()[0].decode('ascii')
    assert result == md5s(sys.argv[0])



# Generated at 2022-06-11 17:55:53.615304
# Unit test for function md5s
def test_md5s():
    # Known hash value on string "dummy"
    assert md5s("dummy") == "7d793037a0760186574b0282f2f435e7", "md5s returned wrong hash value"

# Generated at 2022-06-11 17:55:56.604306
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == secure_hash('/bin/ls')
    assert checksum('/bin/ls', hash_func=sha1) == secure_hash('/bin/ls', hash_func=sha1)

# Generated at 2022-06-11 17:56:00.721857
# Unit test for function md5
def test_md5():
    data = 'This is a test string'
    data_md5 = md5s(data)
    assert(data_md5 == 'f45e4bfa9d9f8d6b66a0dd4cd0b1e46b')
    return True

# Generated at 2022-06-11 17:56:03.780293
# Unit test for function md5
def test_md5():
    assert md5('test/utils/test_md5.py') == '8b897d5a5779c6e9110f5eb8a7bbad6f'

# Generated at 2022-06-11 17:56:07.657328
# Unit test for function md5
def test_md5():
    assert "e4d909c290d0fb1ca068ffaddf22cbd0" == md5("/bin/ls")
    assert "d41d8cd98f00b204e9800998ecf8427e" == md5("/bin/does-not-exist")



# Generated at 2022-06-11 17:56:19.005113
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil

    try:
        tmpdir = tempfile.mkdtemp()
        tmpdir2 = tempfile.mkdtemp()
        tmpdir3 = tempfile.mkdtemp()
        tmpfile1 = tempfile.NamedTemporaryFile(dir=tmpdir.encode('utf-8'))
        tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir2.encode('utf-8'))
        tmpfile3 = tempfile.NamedTemporaryFile(dir=tmpdir3.encode('utf-8'))
    except (OSError, IOError) as e:
        import traceback
        traceback.print_exc()
        print("SKIPPED: mkdtemp or NamedTemporaryFile failed")
        pass

    tmpfile1.write(b"foo")
   

# Generated at 2022-06-11 17:56:28.691254
# Unit test for function checksum
def test_checksum():
    """
    This is a basic test for the checksum() function.
    It generates a random file with a known md5 hash,
    runs the checksum() function on the created file,
    and then compares the result of the function to
    the expected result.
    """
    import tempfile

    temp = tempfile.NamedTemporaryFile()
    temp.write(os.urandom(1024000))
    temp.seek(0)
    assert checksum(temp.name) == "0c52b98f4cc1f0dc649d0e5b8d1e4dff"
    assert checksum_s(temp.read(1024000)) == "0c52b98f4cc1f0dc649d0e5b8d1e4dff"
    temp.close()

# Generated at 2022-06-11 17:56:40.082792
# Unit test for function md5s
def test_md5s():
    ''' test_md5s '''

    # FIPS-140-2 compliant system (e.g. running in FIPS mode)
    old_md5 = _md5
    try:
        _md5 = None
        md5s("hello")
    except ValueError as e:
        # pass
        pass
    finally:
        _md5 = old_md5

    # non-FIPS-140-2 compliant system
    if _md5:
        assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"

# Generated at 2022-06-11 17:56:48.857858
# Unit test for function checksum
def test_checksum():
    print('Testing "checksum" function')

    def assert_checksum_match(filename, expected):
        result = checksum(filename)
        if result != expected:
            raise AssertionError('file "%s" checksum ("%s") did not match expected value ("%s")'
                                 % (filename, result, expected))

    import tempfile
    tmp = tempfile.mkdtemp(prefix='ansible-test-checksum-')

# Generated at 2022-06-11 17:56:58.667372
# Unit test for function checksum
def test_checksum():

    # File containing "\x33\x44\x55\x66\x77\x88\x99\xAA\xBB\xCC\xDD\xEE\xFF\x01\x12\x23\x34\x45\x56\x67\x78\x89\x9A\xAB\xBC\xCD\xDE\xEF"
    test_file = "test/files/test_file.20bytes"

    md5_checksum_hex     = "c7b700e0c22f7acdabfdaf0b7cfcb9cb"
    sha1_checksum_hex    = "6bdd75824f93d28f1edb3b9f9c843c64f32d767d"

# Generated at 2022-06-11 17:57:08.668956
# Unit test for function md5
def test_md5():
    # Make sure that md5 is returning None for a non-existent file
    assert md5('/this/file/does/not/exist') == None

    # Make sure that md5 is returning the correct md5 hash for a file
    md5hash = md5(__file__)
    assert md5hash == '8f82f2ba1816a2a9d9b31e8bfe7339f0'

    # Make sure that md5 is returning the correct md5 hash for a string
    md5hash = md5s('Hello World!')
    assert md5hash == '65a8e27d8879283831b664bd8b7f0ad4'


# Generated at 2022-06-11 17:57:19.712574
# Unit test for function md5s
def test_md5s():
    '''verify md5s against known results'''
    test_data = [
        ('', 'd41d8cd98f00b204e9800998ecf8427e'),
        ('a', '0cc175b9c0f1b6a831c399e269772661'),
        ('abc', '900150983cd24fb0d6963f7d28e17f72'),
        ('The quick brown fox jumps over the lazy dog', '9e107d9d372bb6826bd81d3542a419d6'),
        ('The quick brown fox jumps over the lazy dog.', 'e4d909c290d0fb1ca068ffaddf22cbd0')]
    for src, dst in test_data:
        assert md5s(src) == dst

# Generated at 2022-06-11 17:57:22.144188
# Unit test for function md5
def test_md5():
    assert md5('changelogs/CHANGELOG') == '9f979b2e860613a37adff5e5cd93cd5d'

# Generated at 2022-06-11 17:57:27.692179
# Unit test for function md5
def test_md5():
    """
    >>> md5('/etc/hosts')
    '450e4e3d4b2ba1ed73f0c56f4c19eede'
    >>> md5s('hello world')
    '5eb63bbbe01eeed093cb22bb8f5acdc3'
    """
    pass

# Generated at 2022-06-11 17:57:31.359563
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('goodbye') == '67f8079808907935b7c9ddc2d2ed7890'

# Unit tests for function md5

# Generated at 2022-06-11 17:57:36.909729
# Unit test for function md5s
def test_md5s():
    '''
    >>> test_md5s()
    'd41d8cd98f00b204e9800998ecf8427e'
    '''
    return md5s('')

# Backwards compat function.  See above.
md5sum = md5


# Generated at 2022-06-11 17:57:43.781287
# Unit test for function checksum
def test_checksum():
    def _assertEqual(result, expected):
        assert result == expected

    # Generate md5 checksum
    _assertEqual(checksum('test/utils/test_checksum.py'), '8d9e2bef66e0d99ceb791f35e2e2b336')
    # Generate sha1 checksum
    _assertEqual(checksum('test/utils/test_checksum.py'), '3bf2dd36cff8c6c9e43d32fef5bba2b0dc3737a5')


# Generated at 2022-06-11 17:57:50.528249
# Unit test for function md5
def test_md5():
    assert md5(__file__) == "5dc5c75e5b5e87b1fbfb1e8b3a9a20a5"



# Generated at 2022-06-11 17:57:59.036983
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == 'f572d396fae9206628714fb2ce00f72e'
    assert md5s('The rain in Spain') == '5e543256c480ac577d30f76f9120eb74'

# Generated at 2022-06-11 17:58:08.019583
# Unit test for function md5
def test_md5():
    from ansible.module_utils._text import to_bytes
    import tempfile
    (fd, fname) = tempfile.mkstemp()

    # Make sure we clean up the tempfile properly
    import atexit
    atexit.register(os.unlink, fname)

    # Write some test data to the tempfile
    fh = os.fdopen(fd, "wb")
    fh.write(to_bytes("hello world"))
    fh.close()

    # Make sure the md5 of the tempfile is correct
    assert(md5(fname) == "5eb63bbbe01eeed093cb22bb8f5acdc3")

# Generated at 2022-06-11 17:58:15.783357
# Unit test for function checksum
def test_checksum():
    test_data = 'test_data'
    test_filename = '/tmp/checksum_test'
    test_file = open(test_filename, 'w')
    test_file.write(test_data)
    test_file.close()

    test_sha_sum = '532eaabd9574880dbf76b9b8cc00832c20a6ec113d682299550d7a6e0f345e25'
    assert checksum(test_filename) == test_sha_sum, checksum(test_filename)
    os.remove(test_filename)

if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-11 17:58:18.143756
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'



# Generated at 2022-06-11 17:58:22.326048
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return
    test_data = "TEST"
    test_sum = "098f6bcd4621d373cade4e832627b4f6"
    assert md5s(test_data) == test_sum


# Generated at 2022-06-11 17:58:25.020967
# Unit test for function md5s
def test_md5s():
    data = 'abc'
    assert md5s(data) == '900150983cd24fb0d6963f7d28e17f72'


# Generated at 2022-06-11 17:58:32.951078
# Unit test for function checksum
def test_checksum():
    import subprocess
    import shlex
    import uuid

    # Create a random filename
    s = uuid.uuid4()
    randfile = "/tmp/ansible-test_checksum-%s" % s
    randfile1 = "%s-1" % randfile
    randfile2 = "%s-2" % randfile

    # Generate a text file
    f = open(randfile1, 'w+')
    f.write("This is a test.")
    f.close()

    # Generate a binary file
    f = open(randfile2, 'wb+')
    f.write("This is a test.")
    f.close()

    # compare files, should return True
    assert checksum(randfile1) == checksum(randfile1)

    # copy file

# Generated at 2022-06-11 17:58:37.816633
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('123') == '202cb962ac59075b964b07152d234b70'
    assert md5s('1234') == '81dc9bdb52d04dc20036dbd8313ed055'

# Generated at 2022-06-11 17:58:41.157355
# Unit test for function md5
def test_md5():
    import platform
    assert(platform.python_version().startswith('2.'))
    result = md5(__file__)
    assert(result != None)
    assert(len(result) == 32)

# Generated at 2022-06-11 17:58:55.865326
# Unit test for function checksum
def test_checksum():
    import os
    import sys
    import tempfile
    import subprocess
    import types

    # First create a temporary file with a given content
    (fd, filename) = tempfile.mkstemp()
    os.write(fd, b'hello')
    os.close(fd)

    # Get the md5sum of the file and the sha1 sum
    md5sum    = subprocess.Popen('md5sum '+filename, shell=True, stdout=subprocess.PIPE).communicate()[0].split()[0]
    sha1sum   = subprocess.Popen('sha1sum '+filename, shell=True, stdout=subprocess.PIPE).communicate()[0].split()[0]

    # Check if the checksum function returns the same values
    # Also check if it is of the

# Generated at 2022-06-11 17:58:58.363496
# Unit test for function md5
def test_md5():
    assert md5("/etc/hosts") == "df9d9a1ba0ef1c3a8de36d5c2e0eb4e4"

# Generated at 2022-06-11 17:59:02.759339
# Unit test for function md5
def test_md5():
    test_file = __file__
    if os.path.islink(test_file):
        test_file = os.readlink(test_file)
    test_file_md5 = open(test_file, 'rb').read().encode('hex')
    assert md5(test_file) == test_file_md5


# Generated at 2022-06-11 17:59:04.997254
# Unit test for function checksum
def test_checksum():
    print(checksum('/etc/hosts'))
    print(checksum('/etc/hosts1'))


# Generated at 2022-06-11 17:59:08.661518
# Unit test for function md5
def test_md5():
    md5_expected = 'c8dcd9fa9586629c6250e133517e9891'
    assert md5s('kulla') == md5_expected
    assert md5('/bin/ls') == md5_expected

# Generated at 2022-06-11 17:59:17.047225
# Unit test for function checksum
def test_checksum():
    class TestModule(object):
        def __init__(self):
            self.tmpdir = os.path.realpath(os.path.dirname(os.path.dirname(__file__)))
            self.tmpfile = os.path.join(self.tmpdir, 'ansible_test_checksum_file')
            self.tmpfile2 = os.path.join(self.tmpdir, 'ansible_test_checksum_file2')

        def checksum_file(self):
            with open(self.tmpfile, 'wb') as f:
                f.write(b"Hello world!")
            digest = checksum(self.tmpfile)
            if not digest:
                return {"failed": True, "msg": "digest should not have been empty"}

# Generated at 2022-06-11 17:59:19.150272
# Unit test for function md5s
def test_md5s():
    assert md5s(b'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-11 17:59:30.759065
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "6b8e8c9159c9e7d26fc9a29df9166f02"
    assert checksum("/bin/ls", hash_func=_md5) == "1d6a9b9dcf1922c1b7e308841c45f7a5"
    assert checksum("/bin/ls", hash_func=sha1) == "6b8e8c9159c9e7d26fc9a29df9166f02"

    try:
        checksum("/bin/ls", hash_func=None)
        assert False
    except TypeError:
        pass

    assert checksum_s("/bin/ls") == "6b8e8c9159c9e7d26fc9a29df9166f02"

# Generated at 2022-06-11 17:59:33.363858
# Unit test for function md5
def test_md5():
    fake = u"foo"
    assert md5s(fake) == "acbd18db4cc2f85cedef654fccc4a4d8"

# End of backwards compat functions
#

# Generated at 2022-06-11 17:59:40.538799
# Unit test for function md5s
def test_md5s():
    test_data = {
        "foo": "acbd18db4cc2f85cedef654fccc4a4d8",
        "bar": "37b51d194a7513e45b56f6524f2d51f2",
        "random-1234567890": "57edf4a22be3c955ac49da2e2107b67a",
        "random-123456789012345678901234567890": "900150983cd24fb0d6963f7d28e17f72",
    }
    for data in test_data:
        assert test_data[data] == md5s(data)



# Generated at 2022-06-11 17:59:53.036394
# Unit test for function checksum
def test_checksum():
    import os
    import tempfile

    fd, path = tempfile.mkstemp()
    assert(os.path.exists(path))
    os.close(fd)
    os.remove(path)
    assert(not os.path.exists(path))
    assert(checksum(path) is None)
    with open(path, "w") as f:
        f.write("Hello World!")
    assert(os.path.exists(path))
    assert(checksum(path) == '37b51d194a7513e45b56f6524f2d51f2')
    os.remove(path)

# Generated at 2022-06-11 17:59:58.737122
# Unit test for function md5s
def test_md5s():
    data = 'test_string'
    result = md5s(data)
    # This should be equivalent to the output of: $ echo -n 'test_string' | md5sum | awk '{print $1}'
    assert result == 'f1e1d7c3d3d05c14e0c7decab5c9ce87'


# Generated at 2022-06-11 18:00:04.087184
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


if __name__ == '__main__':
    import sys
    if len(sys.argv) == 1:
        print("Usage: checksum.py <file> [<file> [...]]")
        sys.exit(1)
    for fn in sys.argv[1:]:
        print("%s: %s" % (fn, secure_hash(fn)))

# Generated at 2022-06-11 18:00:10.961469
# Unit test for function md5
def test_md5():
    # This is the md5 hash of a file containing a single line "Hello World"
    # Generated with the following command:
    #  md5sum testfile_for_md5_test.txt
    assert md5('test/units/utils/testfile_for_md5_test.txt') == '66e58eeacf7e69f2e2e7b1f640d1a540'

# Generated at 2022-06-11 18:00:19.694201
# Unit test for function md5
def test_md5():
    def _test_md5(to_hash, expected_output):
        assert md5s(to_hash) == expected_output
    _test_md5("Hello world\n", "5eb63bbbe01eeed093cb22bb8f5acdc3")
    _test_md5("", "d41d8cd98f00b204e9800998ecf8427e")
    _test_md5("J'ai lu dans le journal que Bill Gates est le patron de Microsoft. Est-ce que \
               c'est vrai ?", "92b8c645b8fe3be3e9dbe37f7635c704")

# Generated at 2022-06-11 18:00:28.927737
# Unit test for function md5
def test_md5():
    assert 'd41d8cd98f00b204e9800998ecf8427e' == md5('/bin/ls')
    assert '7dd1926a4d70613d33a5c9a906b47794' == md5('/dev/null')
    assert 'd41d8cd98f00b204e9800998ecf8427e' == md5('/some/nonexistent/file')
    # Test value from http://www.nsrl.nist.gov/testdata/
    assert 'ce114e4501d2f4e2dcea3e17b546f339' == md5('/usr/bin/arch')

# Generated at 2022-06-11 18:00:32.957837
# Unit test for function md5s
def test_md5s():
    if not _md5:
        print('MD5 not available.  Possibly running in FIPS mode')
    else:
        test_data = b"Abrakadabra is an awesome word"
        print(md5s(test_data))


# Generated at 2022-06-11 18:00:37.053290
# Unit test for function md5s
def test_md5s():
    assert secure_hash_s("hello", _md5) == '5d41402abc4b2a76b9719d911017c592'
    assert secure_hash_s(b"hello", _md5) == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-11 18:00:40.003944
# Unit test for function md5s
def test_md5s():
    data = "abcdefg"
    assert md5s(data) == "7ac66c0f148de9519b8bd264312c4d64"


# Generated at 2022-06-11 18:00:51.844837
# Unit test for function checksum
def test_checksum():
    sha1 = 'fce784f6e770f4b4e3ed04d4503fa409a2a4e9fb'
    sha1_s = 'b88e63b0893c46d0b89befa808509c7b9e9b3277'
    md5 = '5f1d3650f996d7f0615b5c0b9f20257d'
    md5_s = 'c8a1d93ea89b0b80b466a7b648983f9e'

    assert(checksum('/bin/ls') == sha1)
    assert(checksum_s('foo') == sha1_s)
    assert(md5('/bin/ls') == md5)

# Generated at 2022-06-11 18:01:00.081645
# Unit test for function md5
def test_md5():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    module = AnsibleModule(argument_spec={})
    try:
        md5('/not/a/real/file.txt')
    except Exception as e:
        module.fail_json(msg=to_bytes(get_exception()))
    else:
        module.exit_json(changed=False)


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:01:09.117261
# Unit test for function md5s
def test_md5s():
    data_string = "this is my string to check the md5"
    data_file = "sha1.py"
    expected_md5s_digest = "d80f5b9e5e09abf7b0d2b37c3e6088f1"
    expected_md5_digest = "f917b11ab1ce5df2c5d3f383751d86c5"

    assert md5s(data_string) == expected_md5s_digest
    assert md5(data_file) == expected_md5_digest

# Generated at 2022-06-11 18:01:16.839887
# Unit test for function checksum
def test_checksum():
    from tempfile import NamedTemporaryFile

    # Test checksum_s
    s = checksum_s("Checksum test")
    assert len(s) == 40

    # Test checksum
    with NamedTemporaryFile() as f:
        f.write("Checksum test")
        f.flush()
        checksum_file = checksum(f.name)
        assert len(checksum_file) == 40


if __name__ == '__main__':
    import nose
    import sys
    sys.argv.append(__file__)
    nose.runmodule()

# Generated at 2022-06-11 18:01:25.426307
# Unit test for function md5s
def test_md5s():
    ''' This is not a proper unit test.

        Proper unit tests do not rely on external resources or programs.

        This is a *functional* test, verifying that the method does what is
        expected, when required resources and programs are available.
    '''
    import sys

    if not _md5:
        sys.stderr.write("MD5 not available.  Possibly running in FIPS mode")
        sys.exit(1)
    else:
        print("MD5 test OK")
        sys.exit(0)

#
# end backwards compat functions
#

# Generated at 2022-06-11 18:01:31.927824
# Unit test for function md5
def test_md5():
    str = "this is the string to be hashed"
    h = md5s(str)
    assert h == "c0535e4be2b79ffd93291305436bf889314e4a3faec05ecffcbb7df31ad9e51a"

    import tempfile
    (fd, fn) = tempfile.mkstemp()
    os.write(fd, str)
    os.close(fd)
    h = md5(fn)
    os.remove(fn)
    assert h == "c0535e4be2b79ffd93291305436bf889314e4a3faec05ecffcbb7df31ad9e51a"

# Generated at 2022-06-11 18:01:38.454326
# Unit test for function md5s
def test_md5s():
    if _md5:
        result = md5s('test')
        assert result == '098f6bcd4621d373cade4e832627b4f6'
    else:
        try:
            md5s('test')
        except ValueError as e:
            assert str(e) == 'MD5 not available.  Possibly running in FIPS mode'
        else:
            assert False



# Generated at 2022-06-11 18:01:49.040193
# Unit test for function md5
def test_md5():
    from ansible.compat.tests import unittest
    import os

    # NOTE: We can't use the tempfile module here because,
    # for whatever reason, it doesn't create the file if
    # it is open for writing.
    # fd, fname = tempfile.mkstemp()
    fname = "/tmp/test_md5"
    if os.path.exists(fname):
        os.unlink(fname)

    # Test a new file that doesn't exist
    x = md5(fname)
    assert x == None

    # Write something to the file
    with open(fname, 'w') as f:
        f.write('meow')

    # Test the file we just wrote to
    digest = md5(fname)

# Generated at 2022-06-11 18:01:57.936290
# Unit test for function md5
def test_md5():
    """
    Checksum:Module Test:md5
    """
    #
    # Create a file
    #

    import tempfile
    fd, path = tempfile.mkstemp()

    #
    # Check that an exception is thrown if the file is not there
    #

    try:
        md5('/does/not/exist')
        assert False, 'should not get here'
    except ValueError as e:
        assert 'not available' in str(e), 'unexpected exception'

    #
    # Check that an exception is thrown if the file is a directory
    #

    try:
        md5(path)
        assert False, 'should not get here'
    except ValueError as e:
        assert 'not available' in str(e), 'unexpected exception'

    #
    # Check that the returned checksum

# Generated at 2022-06-11 18:02:09.057403
# Unit test for function md5
def test_md5():
    '''
    Tests for md5 function.
    '''

    import tempfile

    # Create a temp file
    fd, filename = tempfile.mkstemp(prefix='ansible-test-md5')
    os.close(fd)

    # Write to the file
    data = 'foobar'
    fd = open(filename, 'w')
    fd.write(data)
    fd.close()

    # Calculate the md5 of the file
    md5 = md5(filename)

    # Test the md5
    # The md5 is different on Python 2.6 and 2.7
    # Result on 2.6: 6c2c7ba22fefe0e633177573c45ec9d2
    # Result on 2.7: 90e6916b0c670acbf5f

# Generated at 2022-06-11 18:02:12.833055
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s("hello world\n") == "7b502c3a1f48c8609ae212cdfb639dee"


# Generated at 2022-06-11 18:02:19.008445
# Unit test for function md5
def test_md5():
    test_file = __file__
    assert md5(test_file) == secure_hash(test_file, _md5)

# Generated at 2022-06-11 18:02:24.549895
# Unit test for function md5s
def test_md5s():
    test_hash = 'e3f3d3d3b3c3c3c3c3c3d3d3d3d3d3d3'
    assert md5s('0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789') == test_hash, 'MD5 hash incorrect'
    print('md5s tests passed')


# Generated at 2022-06-11 18:02:27.520258
# Unit test for function md5s
def test_md5s():
    data = "happy"
    assert md5s(data) == "de5e5d5db9793f7a2a0f711b96d1fe16"


# Generated at 2022-06-11 18:02:31.051376
# Unit test for function md5s
def test_md5s():
    test_data = 'some data'
    assert md5s(test_data) == 'c1e8fc8a2755e5d49f5cb5f5391fa0d9'


# Generated at 2022-06-11 18:02:35.079817
# Unit test for function md5
def test_md5():
    assert md5s("data") == "1ee69ca0b36c52da7a8c837e5d7ad5c6"



# Generated at 2022-06-11 18:02:37.852376
# Unit test for function md5
def test_md5():
    assert md5('test/utils/test_module.py') == 'e6746ffbc1237fc36e8f0e1b37a7e1a4'


# Generated at 2022-06-11 18:02:43.249627
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'f1b70c3203f3d3ace3d0323b1c8721b58d55c5f5'
    assert checksum_s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-11 18:02:53.098642
# Unit test for function checksum
def test_checksum():
    '''Unit test for function checksum'''
    import tempfile, shutil

    curdir = os.getcwd()
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-11 18:03:00.570787
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('testing\n') == 'ae2b1fca515949e5d54fb22b8ed95575'
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

# Generated at 2022-06-11 18:03:05.672943
# Unit test for function md5
def test_md5():
    tmpfile = open('/tmp/test_md5', 'w')
    tmpfile.write('foo')
    tmpfile.close()
    res = md5('/tmp/test_md5')
    os.remove('/tmp/test_md5')
    return res == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-11 18:03:16.703752
# Unit test for function md5
def test_md5():
    file_content = 'test'
    import tempfile
    (fd, filename) = tempfile.mkstemp()
    file = os.fdopen(fd, 'w')
    try:
        file.write(file_content)
        file.close()
        assert md5(filename) == '098f6bcd4621d373cade4e832627b4f6', "md5 should return correct value"
    finally:
        os.remove(filename)

# Generated at 2022-06-11 18:03:26.957028
# Unit test for function md5

# Generated at 2022-06-11 18:03:31.111693
# Unit test for function md5s
def test_md5s():
    """
    Test md5s function
    """
    data = 'test string'
    assert md5s(data) == '5a8f0e4c2e253d01f12e9f9e0e9ad0f3'


# Generated at 2022-06-11 18:03:37.837612
# Unit test for function md5
def test_md5():
    for key, value in {'foo': 'acbd18db4cc2f85cedef654fccc4a4d8',
                       'bar': '37b51d194a7513e45b56f6524f2d51f2'}.iteritems():
        s = md5s(key)
        assert s == value, (s, value)

    assert md5('ansible/module_utils/hashing.py') == '73c9b878f7754fd40234b7d7589a4f50'


# Generated at 2022-06-11 18:03:43.112740
# Unit test for function md5
def test_md5():
    path = os.path.join(os.path.dirname(__file__), 'test_utils.py')
    assert md5(path) == '7bef9a8a59f1d9cfd5e5b5bf5ca3ee7c'
    path = os.path.join(os.path.dirname(__file__), 'test_utils')
    assert md5(path) is None



# Generated at 2022-06-11 18:03:46.417448
# Unit test for function md5s
def test_md5s():
    assert md5s("Hello, World!") == "65a8e27d8879283831b664bd8b7f0ad4"


if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-11 18:03:54.840155
# Unit test for function md5
def test_md5():
    # Dummy data for unit test
    test_data1 = "ansible"
    test_data2 = "test"
    test_data3 = "test123"
    test_data4 = "test1234"
    # test_data5 is a duplicate of test_data1
    test_data5 = "ansible"
    # test_data6 is a duplicate of test_data2
    test_data6 = "test"
    test_data7 = "test91"
    test_data8 = "test92"
    test_data9 = "test75"
    test_data10 = "test76"

    # test1 - Single data
    md5_test1 = md5s(test_data1)

# Generated at 2022-06-11 18:03:57.632292
# Unit test for function md5
def test_md5():
    assert md5("/etc/passwd") == '0adfbbd550f9a7c9b8a3a3ac422d3cd2'



# Generated at 2022-06-11 18:04:03.673132
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('foo') == md5('test/test_utils/test_md5')


# Cleanup namespace
del absolute_import
del division
del print_function
del to_bytes

# Generated at 2022-06-11 18:04:10.958919
# Unit test for function md5
def test_md5():
    import unittest

    class HashTest(unittest.TestCase):
        def testBasicHash(self):
            data = b"this is a test string"
            self.assertEqual(b'848c57fdea3a0ef4d4dc8131e74c6d45', md5s(data))

    suite = unittest.TestLoader().loadTestsFromTestCase(HashTest)
    unittest.TextTestRunner(verbosity=2).run(suite)

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:04:17.655987
# Unit test for function md5s
def test_md5s():
    # Make sure backwards-compatible algorithm is correct
    assert md5s('test') == hashlib.md5('test').hexdigest()
    assert md5s('test') != hashlib.sha1('test').hexdigest()

# Generated at 2022-06-11 18:04:20.293487
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-11 18:04:23.125970
# Unit test for function md5s
def test_md5s():
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'

# Generated at 2022-06-11 18:04:27.567691
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('a' * 1048576) == '0b4905d34dcd7b02ef2deb0a41a4a2e0'


# Generated at 2022-06-11 18:04:32.519030
# Unit test for function md5s
def test_md5s():
    test_string = "this is my string"
    test_digest = md5s(test_string)
    assert len(test_digest) == 32
    assert test_digest == '2b7a3673582107fa8e0b3cc9f3d67f3c'

# Generated at 2022-06-11 18:04:38.980129
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s(b'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo' * 1000) == '37aa6a3184f1b7f55edb3c3d8af8b2d2'
    assert md5s(b'foo' * 1000) == '37aa6a3184f1b7f55edb3c3d8af8b2d2'


# Generated at 2022-06-11 18:04:41.255585
# Unit test for function md5s
def test_md5s():
    assert md5s('data') == '1ee69ca0f1d7510c3b96f3f592735687'



# Generated at 2022-06-11 18:04:45.472625
# Unit test for function md5
def test_md5():
    # On my Linux box, /bin/gzip has the following md5 checksum:
    assert md5('/bin/gzip') == '2d6356b958a2d2f1f6c8de6a5054831f'


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:04:46.875507
# Unit test for function md5s
def test_md5s():
    x = md5s('string')
    assert x == '735b09d42e14e8d43b0efb4cde3f9b4e'



# Generated at 2022-06-11 18:04:50.664358
# Unit test for function md5s
def test_md5s():
    data = "data"
    assert md5s(data) == "1b2c59e6f0eecf9217d8a0e518fc2626"

# Generated at 2022-06-11 18:05:04.201993
# Unit test for function md5s
def test_md5s():
    import sys
    import os

    # avoid problems with FIPS
    if 'fips' in sys.modules:
        del sys.modules['fips']
    fips_mode = os.getenv('OPENSSL_FIPS', None)
    if fips_mode is not None:
        del os.environ['OPENSSL_FIPS']

    # create tempfile
    tmpfile = '/tmp/' + os.uname()[1] + '.tmp'
    tmpfd = os.open(tmpfile, os.O_CREAT | os.O_RDWR)
    if tmpfd:
        # write content
        try:
            os.write(tmpfd, b'1234')
        except:     # intentionally catch all exceptions
            os.close(tmpfd)
            raise
        # close file
        os.close

# Generated at 2022-06-11 18:05:08.748928
# Unit test for function md5
def test_md5():
    import tempfile
    filename = tempfile.mktemp()
    f = open(filename, 'w')
    f.write('hello world')
    f.close()
    result = md5(filename)
    assert result == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    os.unlink(filename)


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:05:15.568786
# Unit test for function md5s
def test_md5s():
    import unittest
    import sys

    class TestMD5S(unittest.TestCase):
        def test_md5s(self):
            datastr = "Hello world!"
            md5sum = 'ed076287532e86365e841e92bfc50d8c'
            self.assertEqual(md5s(datastr), md5sum)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestMD5S)
    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-11 18:05:23.484375
# Unit test for function checksum
def test_checksum():
    import random
    import string
    import tempfile
    from shutil import rmtree

    def _random_string(n=6):
        return ''.join(random.choice(string.ascii_lowercase + string.digits) for _ in range(n))

    def _random_file(contents):
        (fd, fname) = tempfile.mkstemp()
        with os.fdopen(fd, 'w', encoding='utf8') as f:
            f.write(contents)
            f.close()
        return fname

    def _remove(f):
        if os.path.exists(f):
            if os.path.isdir(f):
                rmtree(f)
            else:
                os.remove(f)


# Generated at 2022-06-11 18:05:26.928094
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

