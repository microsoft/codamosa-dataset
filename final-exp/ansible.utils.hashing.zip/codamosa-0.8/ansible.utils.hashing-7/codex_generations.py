

# Generated at 2022-06-11 17:55:36.960549
# Unit test for function md5s
def test_md5s():
    test = md5s('hello')
    assert test == '5d41402abc4b2a76b9719d911017c592'
    test = md5s('')
    assert test == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-11 17:55:47.396898
# Unit test for function md5
def test_md5():
    import os
    from ansible.utils.path import unfrackpath
    from ansible.module_utils._text import to_bytes
    TESTFN = "m5sum"

    # Create small file and check
    f = open(unfrackpath("./test/utils/" + TESTFN),'w')
    w = f.write("x")
    f.close()
    assert md5(unfrackpath("./test/utils/" + TESTFN)) == "9dd4e461268c8034f5c8564e155c67a6", "m5sum of small file should be 9dd4e461268c8034f5c8564e155c67a6"

    # Create large file and check
    f = open(unfrackpath("./test/utils/" + TESTFN),'w')
   

# Generated at 2022-06-11 17:55:58.001343
# Unit test for function md5
def test_md5():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.builtin.plugins.module_utils._text import to_bytes
    import shutil
    import tempfile

    # Create temporary directory and file
    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test_md5')

    # Make sure file is created
    open(temp_file, 'w').close()

    # Test md5 when file exists
    md5 = md5(temp_file)
    assert md5 == 'd41d8cd98f00b204e9800998ecf8427e'

    # Test md5 when file does not exists

# Generated at 2022-06-11 17:56:04.015870
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-11 17:56:05.295198
# Unit test for function md5s
def test_md5s():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 17:56:10.532475
# Unit test for function md5s
def test_md5s():
    assert md5s("test") == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s("") == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-11 17:56:17.883503
# Unit test for function checksum
def test_checksum():
    ''' unit test for checksum function '''

    # create a temp test file, write some data and read it back
    (fd, fname) = tempfile.mkstemp()
    os.write(fd, 'foobar')
    os.close(fd)

    # get the md5sum for the test file
    md5sum = checksum_s('foobar')
    test_md5sum = checksum(fname)

    # clean up temp file
    os.remove(fname)

    # test
    assert md5sum == test_md5sum

# Generated at 2022-06-11 17:56:24.300010
# Unit test for function checksum
def test_checksum():
    ''' test_checksum '''

    # same file
    result = checksum("test/utils/checksum/foo.txt")
    assert result == "24fe2694d17c8d3f205a13cfed05b373ec6f914d"

    # different file
    result = checksum("test/utils/checksum/bar.txt")
    assert result == "9c1ba63e9977289c89b6d2cd0dccb6a1d704b0f6"


# Generated at 2022-06-11 17:56:25.848405
# Unit test for function md5s
def test_md5s():
    """
    Unit tests for md5s function.
    """
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-11 17:56:30.456881
# Unit test for function md5
def test_md5():
    import os
    test_file = os.path.join(os.path.dirname(__file__), 'test_md5.txt')
    hashed = md5(test_file)
    assert hashed == '1a4a7bdfd4a67e1c8fa0d09b7a4aa4d4'

# Generated at 2022-06-11 17:56:37.127868
# Unit test for function md5
def test_md5():
    # Tests for md5
    try:
        md5(filename=__file__)
    except ValueError as ve:
        assert ve.args[0] == 'MD5 not available.  Possibly running in FIPS mode'


# Generated at 2022-06-11 17:56:44.673008
# Unit test for function md5
def test_md5():
    import os

    # For the following tests, we are expecting these known hashes:
    # echo -n "ansible test" | md5sum
    ansible_test_hash = 'dcc1e78c1f2b2d3e26e3d01152ec24a8'

    # echo -n "ansible" | md5sum
    ansible_hash = '37b51d194a7513e45b56f6524f2d51f2'

    # echo -n "test" | md5sum
    test_hash = '098f6bcd4621d373cade4e832627b4f6'

    # Write the test file.
    (test_fd, test_file_name) = tempfile.mkstemp()

# Generated at 2022-06-11 17:56:47.143807
# Unit test for function md5
def test_md5():
    ret = md5("/etc/passwd")
    assert ret == "11ed5904f472a9641700eb107c35c0b7"


# Generated at 2022-06-11 17:56:56.844538
# Unit test for function md5s
def test_md5s():
    res = md5s('')
    assert res == 'd41d8cd98f00b204e9800998ecf8427e'
    res = md5s('abc')
    assert res == '900150983cd24fb0d6963f7d28e17f72'
    res = md5s('The quick brown fox jumps over the lazy dog')
    assert res == '9e107d9d372bb6826bd81d3542a419d6'
    res = md5s('The quick brown fox jumps over the lazy dog.')
    assert res == 'e4d909c290d0fb1ca068ffaddf22cbd0'



# Generated at 2022-06-11 17:57:07.685233
# Unit test for function md5
def test_md5():
    ''' test md5 lib. '''
    md5_1 = md5("/bin/chmod")
    assert md5_1 is not None
    if _md5:
        # if _md5 is not None, we'll test it
        assert md5_1 != md5s("test string")
    checksum_1 = checksum("/bin/chmod")
    assert checksum_1 is not None
    assert checksum_1 != checksum_s("test string")
    assert checksum_s("test string") != md5s("test string")
    assert checksum_s("test string") == checksum_s("test string")
    assert checksum("/bin/chmod") != checksum_s("test string")

# Generated at 2022-06-11 17:57:11.128140
# Unit test for function md5s
def test_md5s():
    assert md5s('hello\nworld') == to_bytes('eb085e5a5a5a8f5cf5fa7a3f9d1de7d8', errors='strict')


# Generated at 2022-06-11 17:57:14.444338
# Unit test for function checksum
def test_checksum():
    assert checksum("test/test.ini") == "db56dd1a13d3b7c41f4798a7bceced0c099d06d8"

# Generated at 2022-06-11 17:57:22.789076
# Unit test for function checksum
def test_checksum():
    from ansible.compat import StringIO
    from ansible.module_utils.six import BytesIO


# Generated at 2022-06-11 17:57:26.317948
# Unit test for function md5s
def test_md5s():
    my_str = "I am a string"
    my_str_md5 = md5s(my_str)
    my_str_md5_test = "e4f4b4bb4be64d4c4cf34d7e9f095b5a"

    assert my_str_md5 == my_str_md5_test

if __name__ == '__main__':
    import sys

    filename = './test_md5.py'

    if len(sys.argv) > 1:
        filename = sys.argv[1]

    print(md5(filename))
    print(md5s(filename))

# Generated at 2022-06-11 17:57:29.394476
# Unit test for function md5s
def test_md5s():
    assert md5s("Hello world") == "ed076287532e86365e841e92bfc50d8c"
    assert md5s("Hello world") == secure_hash_s("Hello world", _md5)


# Generated at 2022-06-11 17:57:43.036521
# Unit test for function md5s
def test_md5s():
    import itertools
    def md5sum(value):
        return md5s(value)
    def md5sum_utf8(value):
        return md5s(to_bytes(value, errors='surrogate_or_strict'))

    # Check that it works on bytes
    # Check md5s on empty string
    assert md5sum_utf8('') == 'd41d8cd98f00b204e9800998ecf8427e'
    # Check md5s on non-empty string
    assert md5sum_utf8('abc') == '900150983cd24fb0d6963f7d28e17f72'
    # Check md5s on non-empty string with a character which is not in the ASCII set
    # Using the EURO-SYMBOL
    assert md5sum

# Generated at 2022-06-11 17:57:46.488828
# Unit test for function md5s
def test_md5s():
    if _md5 and md5s("abc") != "900150983cd24fb0d6963f7d28e17f72":
        raise AssertionError("Unit test of md5s has failed")

# Generated at 2022-06-11 17:57:53.923795
# Unit test for function checksum
def test_checksum():
    #
    # Create test file
    #
    import tempfile
    (test_fd,test_fn) = tempfile.mkstemp()
    test_sha1 = 'aaff6c3672f04e23e1aeec5e5b5134f855a41270'
    test_md5 = 'e25b3af5955b36c3d2e6036857c00064'

    #
    # Write test data to file
    #
    os.write(test_fd,b'This is a test file to test checksum')
    os.close(test_fd)

    #
    # Verify checksum function returns correct sha1 sum
    #
    if checksum(test_fn) != test_sha1:
        raise AssertionError('checksum() equal test failed')

    #
   

# Generated at 2022-06-11 17:58:02.441262
# Unit test for function checksum
def test_checksum():
    test_str = 'I am a test string for checksum'
    test_str2 = 'I am a test string for checksums'
    test_file = __file__

    val1 = checksum(test_str)
    val2 = checksum(test_str2)
    val3 = checksum(test_file)

    assert val1 == 'b15952f8ef40d2c58a37aac1d70aad8cf20954b9'
    assert val2 == 'f8d1540f2d0ed3696bf6533c7e848f6a920f6452'
    assert val3 == 'b15952f8ef40d2c58a37aac1d70aad8cf20954b9'


# Generated at 2022-06-11 17:58:08.421160
# Unit test for function md5
def test_md5():
    test_data = 'test string'
    if _md5:
        print("Testing md5 function with test string")
        test_result = md5s(test_data)
        if test_result == 'd4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35':
            print("Test passed")
        else:
            print("Test failed")

# Generated at 2022-06-11 17:58:16.906145
# Unit test for function md5s
def test_md5s():
    import os
    import tempfile
    handle, fd = tempfile.mkstemp(dir='/tmp')
    os.write(handle, 'value')
    os.close(handle)

# Generated at 2022-06-11 17:58:20.739377
# Unit test for function md5
def test_md5():
    assert md5("/this/is/never/gonna/be/a/real/path") is None
    assert md5("/etc/issue") == "33f1a09feae86f2cdf80b67a958c4dab"

# Generated at 2022-06-11 17:58:29.922860
# Unit test for function md5s
def test_md5s():
    '''Returns the md5 sum of a string.  Deprecated, use secure_hash_s instead'''
    def check_md5(original, expected):
        assert md5s(original) == expected, "'%s' failed to validate" % original
    check_md5('foo', 'acbd18db4cc2f85cedef654fccc4a4d8')
    check_md5('', 'd41d8cd98f00b204e9800998ecf8427e')
    check_md5('  ', '7215ee9c7d9dc229d2921a40e899ec5f')
    check_md5('\n', '68b329da9893e34099c7d8ad5cb9c940')

# Generated at 2022-06-11 17:58:34.026974
# Unit test for function md5s
def test_md5s():
    data = md5s("hi")
    answer = "49f68a5c8493ec2c0bf489821c21fc3b"
    if answer != data:
        raise AssertionError
    print("md5s test passed")


# Generated at 2022-06-11 17:58:37.475371
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"
    else:
        try:
            md5s("foo")
            assert False
        except ValueError:
            pass

# Generated at 2022-06-11 17:58:49.714138
# Unit test for function md5s
def test_md5s():
    import tempfile
    fd, filename = tempfile.mkstemp()
    os.write(fd, 'wibble')
    os.close(fd)
    assert md5(filename) == 'de3a3f3cd3b06b13c7a19f4e4cf2a725'
    os.remove(filename)

# Generated at 2022-06-11 17:58:58.696959
# Unit test for function md5s
def test_md5s():
    '''
        This function is only called when the unit test is run directly.
        Ansible itself does not use this.  ansible-playbook uses the
        --syntax-check mode to verify the checksums.
    '''
    import sys
    import gettext
    # modify the path and insert the parent directory, to find the test fixtures
    # from the python files
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'unit'))

    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    def _gettext(msg):
        ''' Simulate gettext from i18n module '''
        return gettext.gettext(msg)

   

# Generated at 2022-06-11 17:59:03.321290
# Unit test for function md5
def test_md5():
    if _md5:
        assert md5s('bogus') == 'f74e6c1a6c14ba6a8c3c2b631c2e3c90'
        assert md5('/etc/passwd') == '0a28c13bccd885db1a9a34a00f16cdc1'


# Generated at 2022-06-11 17:59:05.789144
# Unit test for function md5
def test_md5():
    assert md5s('foo') == "acbd18db4cc2f85cedef654fccc4a4d8"


# Generated at 2022-06-11 17:59:11.430771
# Unit test for function checksum
def test_checksum():
    data = 'hello world'
    assert checksum_s(data) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(data, sha1) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-11 17:59:15.620772
# Unit test for function md5
def test_md5():
    import tempfile

    test_string = 'foobar'
    expected_md5 = '3858f62230ac3c915f300c664312c63f'

    # test string
    actual_md5 = md5s(test_string)
    assert actual_md5 == expected_md5

    # test file
    handle, path = tempfile.mkstemp()
    try:
        os.write(handle, test_string)
        os.close(handle)
        actual_md5 = md5(path)
        assert actual_md5 == expected_md5
    finally:
        os.remove(path)


# Backwards compat for modules which return "md5" in their return values
#
# In Ansible-1.2 and earlier, the md5s function was used as the default
# checksum algorithm

# Generated at 2022-06-11 17:59:23.418232
# Unit test for function md5
def test_md5():
    '''
    ansible checksum -a 'file=...' -a 'checksum_algorithm=md5'
    '''
    import unittest

    class TestCase(unittest.TestCase):
        '''
        TestCase for md5
        '''
        def setUp(self):
            self.valid_path = os.path.abspath(__file__)

        def test_valid_file(self):
            '''
            Checksum returns valid md5 checksum when a valid file is supplied
            '''
            with open(self.valid_path, 'rb') as myfile:
                file_contents = myfile.read()
                checksum_value = _md5(file_contents).hexdigest()

# Generated at 2022-06-11 17:59:29.090418
# Unit test for function checksum
def test_checksum():
    b = to_bytes(os.path.dirname(__file__))
    csum = checksum(b)
    assert csum == None

    b = to_bytes(__file__)
    csum = checksum(b)
    assert csum == "67e8df5f15a663614ec5d5d5c826ec7fd06c2976"

# Generated at 2022-06-11 17:59:30.798036
# Unit test for function md5
def test_md5():
    md5('/etc/passwd')

if __name__ == "__main__":
    test_md5()

# Generated at 2022-06-11 17:59:31.987136
# Unit test for function md5
def test_md5():
    result = md5(__file__)
    assert len(result) == 32

# Generated at 2022-06-11 17:59:50.699845
# Unit test for function checksum
def test_checksum():
    assert secure_hash_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert secure_hash('lib/ansible/modules/system/user.py') == '0a65a2229b8f00730d1a5901d32c6fc7'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:59:52.958848
# Unit test for function md5s
def test_md5s():
    assert md5s('Hello World!') == '6cd3556deb0da54bca060b4c39479839'

# Generated at 2022-06-11 17:59:55.414599
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-11 18:00:00.904274
# Unit test for function md5s
def test_md5s():
    if _md5:
        test_data = "hello world"
        ref_value = "5eb63bbbe01eeed093cb22bb8f5acdc3"
        assert(ref_value == md5s(test_data))
    else:
        assert(True)

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-11 18:00:05.558172
# Unit test for function md5
def test_md5():
    filename = 'test_md5.txt'
    f = open('test_md5.txt','w')
    f.write('test string for md5')

# Generated at 2022-06-11 18:00:11.819435
# Unit test for function md5s
def test_md5s():
    ''' unit test will return an error if the MD5 hash function is not available on the system '''
    test_string = u'foo'
    test_hash = md5s(test_string)
    if test_hash != u'acbd18db4cc2f85cedef654fccc4a4d8':
        raise Exception('MD5 hash error')
    else:
        print('MD5 hash function is available on this system')



# Generated at 2022-06-11 18:00:16.664519
# Unit test for function checksum
def test_checksum():
    s = "abcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcd"
    assert(checksum_s(s) == '5dd5e36c0f2b8e46f2cb78cb99969a7023e5b9c9')


# Generated at 2022-06-11 18:00:25.497815
# Unit test for function md5
def test_md5():
    import tempfile

    # Create temporary file
    fd, tmpfile = tempfile.mkstemp()

    # Create file content
    os.write(fd, b'some test data\n')
    os.close(fd)

    # Calculate checksum
    mysum = md5(tmpfile)

    # Remove temporary file
    os.unlink(tmpfile)

    # Should be '590c1d233b64c0a8f8b5e791d6f7ffa5'
    print(mysum)



# Generated at 2022-06-11 18:00:32.327165
# Unit test for function checksum
def test_checksum():
    ''' unit tests for checksum '''

    import tempfile

    fd, fname = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('hello world')
    f.close()

    h = checksum(fname)
    assert h == sha1(open(to_bytes(fname, errors='surrogate_or_strict'), 'rb').read()).hexdigest()

    h = checksum_s('hello world')
    assert h == sha1(b'hello world').hexdigest()

    os.unlink(fname)


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:00:40.802124
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py
        test_checksum is a simple program to test checksum funciton.
        It will test if the checksum of a file is equal to the
        checksum of the same file with a known specific block of data
        inserted in a random location within the file.
    '''

    # A sample file to test checksum function

# Generated at 2022-06-11 18:01:00.082861
# Unit test for function checksum
def test_checksum():
    input_string='ansible'
    hash_val = secure_hash_s(input_string)
    assert isinstance(hash_val, str)
    assert hash_val == 'e5b8d6e5a9bdb38f1ef7f60e3e3b00a3b0d1b3d0'

    input_filename = 'hash_utils.py'
    hash_val = secure_hash(input_filename)
    assert isinstance(hash_val, str)
    assert hash_val == 'd0d19e84da72ec2030e108f6d0fa7c22f6c5c7a0'

# Generated at 2022-06-11 18:01:11.051759
# Unit test for function md5
def test_md5():

    # Set up some stuff to make test easier
    def get_test_data():
        data = {}

        real_data = b'''The MD5 message-digest algorithm is a widely used cryptographic hash function
producing a 128-bit (16-byte) hash value, typically expressed in text format as a
32 digit hexadecimal number. MD5 has been utilized in a wide variety of
cryptographic applications, and is also commonly used to verify data integrity.'''

        data['md5_correct'] = '6b0a7c9e994b8c7e59a6a6811d5f5e31'
        data['sha1_correct'] = '9a6f8be6e3d6e2a6dccc7b4944699b3c2d14d3cb'

# Generated at 2022-06-11 18:01:21.287803
# Unit test for function md5
def test_md5():
    assert md5("./lib/ansible/module_utils/basic.py") == "c3b9d397df528b26bd78b2c22e1e95ce"
    assert md5("./lib/ansible/module_utils/basic.py", _md5) == "c3b9d397df528b26bd78b2c22e1e95ce"
    assert md5("./lib/ansible/module_utils/basic.py", hash_func=_md5) == "c3b9d397df528b26bd78b2c22e1e95ce"
    assert md5s("abc") == "900150983cd24fb0d6963f7d28e17f72"

# Generated at 2022-06-11 18:01:31.262761
# Unit test for function checksum
def test_checksum():
    '''Unit test for checksum().
    '''
    from ansible.module_utils import basic
    import tempfile

    tempdir = tempfile.mkdtemp()
    tempfile1 = tempfile.mktemp(dir=tempdir)
    tempfile2 = tempfile.mktemp(dir=tempdir)
    tempfile3 = tempfile.mktemp(dir=tempdir)
    tempfile4 = tempfile.mktemp(dir=tempdir)

    def _hex(digest):
        return ''.join( [ "%02x" % ord( x ) for x in digest ] ).strip()

    # Need a file to work with
    basic.file_dump(tempfile1, '{"test": "data"}\n')

    # Check sha digest

# Generated at 2022-06-11 18:01:39.768392
# Unit test for function md5
def test_md5():
    with open('test.txt', 'w') as f:
        f.seek(1024*1024)
        f.write('\x00')

    md5_value='1b4d817d7b524fdd08acbf7d1fc8a74f'
    if md5(to_bytes('test.txt', errors='surrogate_or_strict')) != md5_value:
        raise Exception('unexpected md5 value %s' % md5(to_bytes('test.txt', errors='surrogate_or_strict')))

    os.remove('test.txt')


# Generated at 2022-06-11 18:01:45.478331
# Unit test for function md5
def test_md5():
    # Example taken from http://en.wikipedia.org/wiki/MD5#Example
    assert md5s("") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"


# Generated at 2022-06-11 18:01:50.176815
# Unit test for function checksum
def test_checksum():
    import os
    import tempfile
    (handle, name) = tempfile.mkstemp()
    try:
        os.write(handle, b'hello')
        os.close(handle)
        assert checksum(name) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    finally:
        os.remove(name)


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:01:57.146890
# Unit test for function md5
def test_md5():
    testfile = '/tmp/testfile'
    testmd5 = '1cc747d1e306e86eeb7df6bdfc0f4e4d'
    f = open(testfile, 'w+')
    f.write('This is a testfile for md5')
    f.close()
    print('test file = ', testfile)
    print('test md5 = ', testmd5)
    filemd5 = md5(testfile)
    print('file md5 = ', filemd5)
    os.remove(testfile)
    assert testmd5 == filemd5

# Generated at 2022-06-11 18:02:08.364256
# Unit test for function md5
def test_md5():
    '''test hash algorithms'''

    import ansible.constants as C
    os.environ['ANSIBLE_CONFIG'] = 'test/ansible.cfg'

# Generated at 2022-06-11 18:02:15.919785
# Unit test for function checksum
def test_checksum():

    from ansible.module_utils.six.moves import StringIO

    def _check(algo, data, expected):
        fd = StringIO(data)
        actual = checksum(filename=fd, hash_func=algo)
        assert actual == expected

    for algo in [sha1, _md5]:
        if algo is None:
            continue
        # empty file
        _check(algo, "", "da39a3ee5e6b4b0d3255bfef95601890afd80709")
        # 1 byte file (up to block size)
        _check(algo, "a", "86f7e437faa5a7fce15d1ddcb9eaeaea377667b8")

# Generated at 2022-06-11 18:02:45.140738
# Unit test for function md5
def test_md5():
    import shutil
    f,tf = tempfile.mkstemp()
    with open(tf, 'wb') as fobj:
        fobj.write(b'foo')
    assert md5(tf) == 'acbd18db4cc2f85cedef654fccc4a4d8'
    os.remove(tf)

# Generated at 2022-06-11 18:02:54.274546
# Unit test for function md5
def test_md5():
    import filecmp

    base_dir = os.path.dirname(os.path.realpath(__file__))
    test_base_dir = os.path.join(base_dir, 'utils', '__pycache__')

    test_file = os.path.join(base_dir, 'test-test.yml')
    test_file2 = os.path.join(test_base_dir, 'test-test.yml')

    assert filecmp.cmp(test_file, test_file2)
    assert md5(test_file) == md5(test_file2)
    assert md5s('I love potato') == md5s('I love potato')
    assert md5s('I love potato') != '987654321'

# Generated at 2022-06-11 18:03:00.923687
# Unit test for function checksum
def test_checksum():

    assert secure_hash_s('hello', sha1) == '5d41402abc4b2a76b9719d911017c592'
    assert secure_hash_s(u'hello', sha1) == '5d41402abc4b2a76b9719d911017c592'


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:03:06.322317
# Unit test for function checksum
def test_checksum():
    string = 'Hello world'
    sha1sum = '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    md5sum = '5eb63bbbe01eeed093cb22bb8f5acdc3'

    assert sha1sum == checksum_s(string)
    assert md5sum == md5s(string)

# Generated at 2022-06-11 18:03:12.467444
# Unit test for function md5
def test_md5():
    '''unit test for function md5'''

    import tempfile

    # create empty temp file
    (fd, path) = tempfile.mkstemp()
    os.close(fd)
    fd = None

    # call md5 with empty temp file
    hash1 = md5(path)

    # write some contents to temp file
    fd = open(path, 'w')
    fd.write('hello world')
    fd.close()

    # call md5 with temp file with contents
    hash2 = md5(path)

    # remove temp file
    os.unlink(path)

    #
    # TODO: this test only works with installed version that uses hashlib
    #       (not FIPS-140-2 compliant)
    #

# Generated at 2022-06-11 18:03:15.772545
# Unit test for function checksum
def test_checksum():
    assert checksum(__file__) == 'f9d7947b8e7b35a4f4a4ff4d2f8a744c2908d9e7'

# Generated at 2022-06-11 18:03:24.776684
# Unit test for function checksum
def test_checksum():
    test_data = os.path.join(os.path.dirname(__file__), 'test_checksum_data')
    assert checksum('sha1', test_data) == 'e9b8e8cd09665b7e4f2458a424a4a4b0fa6800c9'
    assert checksum('md5', test_data) == '5f5d59bf5d8b5ccef9e3eb9ee43a77a8'
    assert checksum('sha1', 'foobar') == None
    assert checksum('sha1', '/etc/hosts') == 'd1b2f1a26e80b57e96c8f5e36a5b0ee9bce1f8e0'

# Generated at 2022-06-11 18:03:28.288955
# Unit test for function md5s
def test_md5s():
    data = 'asdf'
    md5s_val = md5s(data)
    assert md5s_val == '912ec803b2ce49e4a541068d495ab570'

# Generated at 2022-06-11 18:03:30.527883
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'c21f969b5f03d33d43e04f8f136e7682'

# Generated at 2022-06-11 18:03:34.631032
# Unit test for function checksum
def test_checksum():
    filename = 'test/fixtures/checkeum.txt'
    s = checksum(filename)
    assert s == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'



# Generated at 2022-06-11 18:04:34.321404
# Unit test for function md5s
def test_md5s():
    result = md5s('test')
    assert result == '098f6bcd4621d373cade4e832627b4f6'
    result = md5s('test' + u'\u6c49')
    assert result == 'f0d914d6fcdbb7f2b94fefc19ae8d387'


# Generated at 2022-06-11 18:04:36.896161
# Unit test for function md5
def test_md5():
     assert md5('test.txt') == "7caa9e917d00f933a3a1baf0ccfd0e70"


# Generated at 2022-06-11 18:04:39.011447
# Unit test for function md5s
def test_md5s():
    data = 'hello'
    out = md5s(data)
    assert out == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-11 18:04:42.998137
# Unit test for function checksum
def test_checksum():
    path = os.path.join(os.path.dirname(__file__), "hashsum.py")
    assert checksum(path) == checksum_s(open(path).read())

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 18:04:50.183596
# Unit test for function checksum
def test_checksum():
    assert checksum_s("foobar") == "8843d7f92416211de9ebb963ff4ce28125932878"
    assert checksum_s("foobar", sha1) == "8843d7f92416211de9ebb963ff4ce28125932878"

    assert checksum("/dev/null") == "d41d8cd98f00b204e9800998ecf8427e"
    assert checksum("/dev/null", sha1) == "da39a3ee5e6b4b0d3255bfef95601890afd80709"

    # Confirm that passing a directory returns None
    assert checksum("/dev") is None

# Generated at 2022-06-11 18:05:01.099143
# Unit test for function md5
def test_md5():
    ''' md5 unit tests '''

    # md5 available
    import sys
    if sys.version_info >= (2, 5):
        assert not secure_hash(b'spam', _md5)
        assert not secure_hash(b'/etc/', _md5)
        assert md5('lib/ansible/module_utils/basic.py') == 'b4a6b4e3e2a6b1d6d1412f8b8d914d35'
        assert type(md5('lib/ansible/module_utils/basic.py')) is unicode
        assert md5s(b'spam') == '8b1a9953c4611296a827abf8c47804d7'
        assert type(md5s(b'spam')) is unicode

# Generated at 2022-06-11 18:05:06.635452
# Unit test for function md5s
def test_md5s():
    test_data = "test-data"
    expected_md5 = "97dc9b9dd41dbc87acf3077d7b841f15"
    actual_md5 = md5s(test_data)
    if expected_md5 != actual_md5:
        raise AssertionError("unexpected md5s returned by md5s() module function: %s instead of %s" % (actual_md5, expected_md5))


# Generated at 2022-06-11 18:05:10.011471
# Unit test for function md5
def test_md5():
    with open('test_md5.txt', 'w') as f:
        f.write('Hello World!')
    assert(md5('test_md5.txt') == 'b10a8db164e0754105b7a99be72e3fe5')

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:05:12.527953
# Unit test for function md5
def test_md5():
    with open(__file__, 'rb') as f:
        assert md5(__file__) == _md5(f.read()).hexdigest()

# Generated at 2022-06-11 18:05:17.000066
# Unit test for function md5s
def test_md5s():
    string1 = 'string1'
    string2 = 'string2'
    assert md5s(string1) == 'f30ce3febba3d9b0ac47440f7453d62e'
    assert md5s(string2) == 'c0cfa5708ddd905a6cf8ad7fd4d6ad4a'

