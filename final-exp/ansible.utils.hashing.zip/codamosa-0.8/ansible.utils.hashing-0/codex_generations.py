

# Generated at 2022-06-11 17:55:29.652762
# Unit test for function checksum
def test_checksum():
    checksum = secure_hash_s('some string data')
    assert (checksum == '2305e26d966ab2d0c7bb8a8f6d7e48e67a3a7c87')

# Generated at 2022-06-11 17:55:33.663243
# Unit test for function checksum
def test_checksum():
    filename = './test/test_module.py'
    print(checksum(filename))
    print(checksum_s(filename))
    print(md5(filename))
    print(md5s(filename))


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:55:37.754319
# Unit test for function checksum
def test_checksum():
    # I don't much care what the hash is, just so long as it is repeatable
    assert checksum("hello world") == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-11 17:55:41.617628
# Unit test for function checksum
def test_checksum():
    data = '12345'
    res = checksum_s(data)
    assert (res == '8cb2237d0679ca88db6464eac60da96345513964')

# Generated at 2022-06-11 17:55:46.336429
# Unit test for function checksum
def test_checksum():
    import tempfile
    fh, fname = tempfile.mkstemp(prefix='ansible_test_checksum')
    try:
        f = os.fdopen(fh, 'w')
        f.write('Hello')
        f.close()
        assert checksum(fname) == secure_hash(fname)
    finally:
        os.unlink(fname)

# Generated at 2022-06-11 17:55:57.482301
# Unit test for function checksum
def test_checksum():
    print('Testing checksum')
    assert checksum('/bin/ls') == '86afb92a99af7a8dee63c0f1ddb38a34f7ed9f18'
    assert checksum('/bin/ls', hash_func=_md5) == 'b4a2ddf8698a435726e4a1a77f5ffb6a'
    assert checksum('/bin/ls', hash_func=sha1) == '86afb92a99af7a8dee63c0f1ddb38a34f7ed9f18'

    assert checksum_s('main.yml') == '44ae6e7b4d4c90f4f6e2e6ae4aa6d73d6ac85cf6'


# Generated at 2022-06-11 17:56:08.190571
# Unit test for function checksum
def test_checksum():
    assert checksum('initial_tests/test-module.py') == '49c8e48cb21d1e3b3f6aa2ff8c2469e82b52c5b9'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum('initial_tests/test-module.py', hash_func=_md5) == '2c7d1aa9e2e6d1ba6d701c6f65a6b10f'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-11 17:56:12.557844
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'



# Generated at 2022-06-11 17:56:14.823314
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

test_md5s()

# Generated at 2022-06-11 17:56:22.349504
# Unit test for function checksum
def test_checksum():

    #
    # Generate the SHA1 checksum of this file
    # This is checked in by the Makefile and should be updated if this code is changed
    #
    this_file = __file__.replace('.pyc', '.py')
    expected_checksum = "4e4e03f4a4b81cb4cb358e872dc3d59c9e0e7faa"

    result = checksum(this_file)
    if result != expected_checksum:
        raise Exception("%s != %s" % (result, expected_checksum))

    # Try this multiple times to try and catch transient failures
    for x in range(0, 5):
        result = md5(this_file)

# Generated at 2022-06-11 17:56:27.014789
# Unit test for function md5s
def test_md5s():

    assert(md5s('Hello World') == 'b10a8db164e0754105b7a99be72e3fe5')



# Generated at 2022-06-11 17:56:31.619919
# Unit test for function checksum
def test_checksum():
    import shutil
    import tempfile
    fd, tmpfile = tempfile.mkstemp()
    try:
        assert checksum(tmpfile) is None
        assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
        with open(tmpfile, 'w') as fh:
            fh.write('hello')
        assert checksum(tmpfile) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    finally:
        os.close(fd)
        os.remove(tmpfile)

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:56:39.310781
# Unit test for function md5s
def test_md5s():
    check_file = open('/tmp/test', 'w')
    check_file.write('White space and new lines\n')
    check_file.close()
    check_file = open('/tmp/test', 'r')
    check_file_md5 = secure_hash_s(check_file.read())
    check_file.close()
    assert secure_hash_s('White space and new lines') == check_file_md5
    os.remove('/tmp/test')


# Generated at 2022-06-11 17:56:45.736438
# Unit test for function md5
def test_md5():
    if _md5:
        assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
        assert md5('/bin/ls') == '9a217817f1b36a16a8f34b6ddd216c22'
    else:
        try:
            md5s('test')
        except ValueError as e:
            assert "MD5 not available" in str(e)



# Generated at 2022-06-11 17:56:56.626506
# Unit test for function checksum
def test_checksum():

    # test an empty file
    tfile = os.path.join(os.path.dirname(__file__), "test_files/test_checksum_empty_file")
    assert checksum(tfile) == "a4d316cde97f5290a07a493eaa6b2a54"
    assert checksum_s('') == "da39a3ee5e6b4b0d3255bfef95601890"
    assert checksum_s('1234') == "81dc9bdb52d04dc20036dbd8313ed055"

    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    # test an empty file (md5)

# Generated at 2022-06-11 17:57:07.326076
# Unit test for function checksum
def test_checksum():

    from ansible.executor.task_result import TaskResult

# Generated at 2022-06-11 17:57:14.843221
# Unit test for function md5
def test_md5():
    h = md5s('data to hash')
    assert h[1:3] == 'd4'
    h = md5s('data to hash')
    assert h[1:3] == 'd4'
    h = md5('/usr/bin/gcc')
    assert h[1:3] == '3e'
    h = md5('/usr/bin/no_such_command')
    assert h is None

# Generated at 2022-06-11 17:57:17.759113
# Unit test for function md5s
def test_md5s():
    r = md5s('some data')
    if not r == '44c67dda9e9f9cc6f8d6a05c632d7bfe':
        raise ValueError('MD5 test failure')

# Generated at 2022-06-11 17:57:21.645434
# Unit test for function md5
def test_md5():
    ''' test md5 functionality '''
    assert (md5(os.path.join(os.path.dirname(__file__), '../../lib/ansible/module_utils/basic.py')) == '7c3b3c9e7accf8d5f0cce1e9707e6822')

# Generated at 2022-06-11 17:57:28.581520
# Unit test for function md5
def test_md5():
    fd, path = tempfile.mkstemp()
    os.write(fd, "some test data")
    os.close(fd)
    assert md5(path) == "29e4da4b4e06ffd65d0a8a9a74e955f7"
    assert md5s("some test data") == "29e4da4b4e06ffd65d0a8a9a74e955f7"
    os.remove(path)

# Generated at 2022-06-11 17:57:36.910236
# Unit test for function md5
def test_md5():
    test_sentence = "g'day"
    md5_answer = "7b502c3a1f48c8609ae212cdfb639dee"
    value = md5s(test_sentence)
    if isinstance(value, str):
        value = value.encode('utf-8')
    assert value == md5_answer

# Generated at 2022-06-11 17:57:42.691883
# Unit test for function md5
def test_md5():
    # Create a temporary file
    import tempfile
    fd, fname = tempfile.mkstemp()

    f = os.fdopen(fd, 'w')
    f.write('test file')
    f.close()

    # Create the md5 hash
    hash = md5(fname)
    assert hash == '098f6bcd4621d373cade4e832627b4f6'
    # Cleanup and delete the file
    os.remove(fname)

# Generated at 2022-06-11 17:57:51.585131
# Unit test for function md5
def test_md5():
    ''' check if md5 function works as expected '''
    import tempfile
    import shutil
    import sys

# Generated at 2022-06-11 17:57:57.221490
# Unit test for function md5s
def test_md5s():
    expected = '1bc29b36f623ba82aaf6724fd3b16718'
    result = md5s('foo')
    if result != expected:
        raise Exception("MD5s of 'foo' failed: expected %s != actual %s" % (expected, result))

# Generated at 2022-06-11 17:58:02.138088
# Unit test for function checksum
def test_checksum():
    # Generate an md5 checksum of a given file
    md5_sum = md5('lib/ansible/module_utils/basic.py')
    assert md5_sum == 'aab8fbc5bc0d9a36e7539c8f8479c352'

# Generated at 2022-06-11 17:58:12.757384
# Unit test for function checksum
def test_checksum():
    import sys
    import tempfile
    filename = tempfile.mktemp(prefix='ansible')
    f = open(filename, 'w')
    f.writelines(['foo\n', 'bar\n', 'baz\n'])
    f.close()
    cksum = checksum(filename)
    os.unlink(filename)
    if cksum != '6c9ba6e4df2a7ebd4d0c4c8d8f0bd810f1bdde59':
        sys.exit(1)

    # Unit test for function checksum_s
    cksum = checksum_s('foo\nbar\nbaz\n')

# Generated at 2022-06-11 17:58:19.392796
# Unit test for function checksum
def test_checksum():
    import tempfile
    tmp_file = tempfile.NamedTemporaryFile(mode='w+')
    tmp_file_path = tmp_file.name

    # 'b' is written since module_utils/_text.py:to_bytes is always used
    msg = 'Hello there!'
    tmp_file.write(msg)
    tmp_file.close()
    assert checksum(tmp_file_path) == checksum_s(msg)

# Generated at 2022-06-11 17:58:29.228067
# Unit test for function checksum
def test_checksum():
    # This is the test vector from RFC 1321
    test_str = 'abc'
    expected = '900150983cd24fb0d6963f7d28e17f72'
    actual = checksum_s(test_str, sha1)
    if expected != actual:
        raise AssertionError('unexpected sha1 of %s, expected %s but got %s' % (test_str, expected, actual))

    # from http://www.di-mgt.com.au/sha_testvectors.html
    # test vector 3
    test_str = 'abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq'

# Generated at 2022-06-11 17:58:39.247692
# Unit test for function checksum
def test_checksum():
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('The quick brown fox jumps over the lazy dog.') == '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12'
    assert checksum_s('The quick brown fox jumps over the lazy dog') == '408d94384216f890ff7a0c3528e8bed1e0b01621'

if __name__ == '__main__':
    import sys
    import difflib
    s1 = sys.stdin.read()
    s2 = sys.argv[1]
    d = difflib.Differ()

# Generated at 2022-06-11 17:58:41.710877
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-11 17:58:55.981458
# Unit test for function checksum
def test_checksum():
    import sys
    p = sys.modules[__name__]
    test_file_path = os.path.join(os.path.dirname(p.__file__), 'test_checksum.data')
    test_checksum_sha1 = '95b6fe0fc10919b6695664ce4f88072e4abd4b64'
    test_checksum_md5 = 'e1ad7907c434a7bf97e0bab1772b6a91'
    assert test_checksum_sha1 == checksum(test_file_path)
    assert test_checksum_md5 == md5(test_file_path)
    assert test_checksum_sha1 == checksum_s(''.join(open(test_file_path, 'r').readlines()))
    assert test_checks

# Generated at 2022-06-11 17:59:01.938555
# Unit test for function md5s
def test_md5s():
    assert md5s("foobar") == "3858f62230ac3c915f300c664312c63f"
    assert md5s("barbaz") == "931fb3b24c54c9184de5da6bc6499c54"
    assert md5s("bazqux") == "75d6f316dd6a5a6f5c7aa0e43d5c9a0a"


# Generated at 2022-06-11 17:59:06.653291
# Unit test for function md5s
def test_md5s():
    m = md5s("12345")
    print("md5(\"12345\") = %s" % m)
    assert m == "827ccb0eea8a706c4c34a16891f84e7b"


if __name__ == "__main__":
    test_md5s()

# Generated at 2022-06-11 17:59:11.845342
# Unit test for function checksum
def test_checksum():
    filename = os.path.join(os.path.dirname(__file__), "utils.py")
    actual = checksum(filename)
    expected = "7dc8be71d21f7e7d05e3467482623eae"
    assert actual == expected, "expected: %s\nactual: %s" % (expected, actual)

# Generated at 2022-06-11 17:59:18.547738
# Unit test for function md5s
def test_md5s():
    # Test 1
    s = "abcdefghijklmnopqrstuvwxyz"
    s_md5 = "c3fcd3d76192e4007dfb496cca67e13b"
    md5sum = md5s(s)
    assert md5sum == s_md5, "MD5: %s != %s" % (md5sum, s_md5)
    # Test 2
    d = {"a": [1, 2, 3], "b": [6, 5, 4]}
    d_md5 = "2234f05448a6aee5e5f9e5e983a23ba2"
    md5sum = md5s(d)

# Generated at 2022-06-11 17:59:30.515554
# Unit test for function md5s
def test_md5s():
    ''' checksum.md5s() is deprecated and should not be used in production modules.  It is only provided for backwards compatibility.
    '''
    if _md5:
        try:
            import warnings
            warnings.warn("md5s() is deprecated and should not be used in production modules.  It is only provided for backwards compatibility.", DeprecationWarning)
        except ImportError:
            # Python 2.4 doesn't have warnings, we just have to ignore the test.
            pass
        assert md5s('foobar') == '3858f62230ac3c915f300c664312c63f'
        assert md5s('barfoo') == '940af37c1900899722e7c0b8e98d7fbf'

# Generated at 2022-06-11 17:59:38.556272
# Unit test for function md5
def test_md5():
    b = b'I am a string'
    a = to_bytes(b'I am a string', errors='surrogate_or_strict')

    assert a == b
    assert md5s(b) == '2e73d367c87a2f34a1e56cb73cbcdc33'
    assert md5s(a) == '2e73d367c87a2f34a1e56cb73cbcdc33'

    assert md5('file1') == '6fc59d8d88ec197e41f3b2a39cc9c8b9'
    assert md5('file1') == '6fc59d8d88ec197e41f3b2a39cc9c8b9'

# Generated at 2022-06-11 17:59:50.092707
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "6b9f2f665e7421e57eda387944d917d1"
    assert checksum("/bin/cat") == "dcb32501c7c15b7435a5b5f5d5a71c38"
    assert checksum("/bin/sleep") == "1daa3e3c3f2ef2dba8e536e4fb4c85d7"
    assert checksum("/bin/date") == "f7affb89a11c9542e0b2d6c0b6f929cf"
    assert checksum("/bin/echo") == "8ca7404aa26a14cfd1f9a9d8e1c54f95"

# Generated at 2022-06-11 17:59:52.761602
# Unit test for function md5s
def test_md5s():
    assert md5s("Angela Merkel") == '734e67d02e8e89a10f2cc297c1a9d9a9'


# Generated at 2022-06-11 17:59:55.111862
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-11 17:59:59.973193
# Unit test for function md5
def test_md5():
    assert md5('/bin/echo') == '8e7f0c9e793bfc78b41e8c1f48e10d56'

# Generated at 2022-06-11 18:00:07.566316
# Unit test for function md5
def test_md5():
    # Test file
    test_file = os.path.join(os.path.dirname(__file__), '..', 'lib', 'ansible', '__init__.py')
    digest = md5(test_file)
    assert digest == '90a021dd7d826b1cc24b2cafd0e1005a'
    fail_file = os.path.join(os.path.dirname(__file__), '..', 'lib', 'ansible')
    digest = md5(fail_file)
    assert digest == None


# Generated at 2022-06-11 18:00:12.227946
# Unit test for function md5s
def test_md5s():
    ''' sha1: 78f1d69a8c0e6dab94dffa14a22c59b2f3e3bc9d '''
    assert md5s('aoeu') == '78f1d69a8c0e6dab94dffa14a22c59b2f3e3bc9d'


# Generated at 2022-06-11 18:00:20.203565
# Unit test for function md5s
def test_md5s():
    assert(md5s(b'The quick brown fox jumps over the lazy dog') == '9e107d9d372bb6826bd81d3542a419d6')
    assert(md5s('The quick brown fox jumps over the lazy dog') == '9e107d9d372bb6826bd81d3542a419d6')
    assert(md5s('The quick brown fox jumps over the lazy dog\n') == 'e4d909c290d0fb1ca068ffaddf22cbd0')
    assert(md5s(u'The quick brown fox jumps over the lazy dog') == '9e107d9d372bb6826bd81d3542a419d6')

# Generated at 2022-06-11 18:00:23.306235
# Unit test for function md5s
def test_md5s():
    assert md5s('a5c6a5f6') == '6a09dc08c5cf9d4c4a4e638fe975e8c8'


# Generated at 2022-06-11 18:00:25.867532
# Unit test for function md5s
def test_md5s():
    assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"


# Generated at 2022-06-11 18:00:36.133374
# Unit test for function checksum
def test_checksum():
    ''' Unit test for function checksum '''

    file_local = 'test/files/chars'
    file_remote = 'test/files/md5sum.txt'
    data_local = 'Hello world!'

    # local
    assert checksum(file_local) == "4a4d7edbaafc0f6d2c5408be6583e11a"
    assert checksum(file_remote) == "6be230feffc4b6ebd5b078a6c2d9fe40"
    assert checksum_s(data_local) == "ed076287532e86365e841e92bfc50d8c"

    # remote
    assert md5(file_local) == "ed59ff979410ff9f58f0e4fd2fd3572b"

# Generated at 2022-06-11 18:00:40.504818
# Unit test for function checksum
def test_checksum():

    test_file = "/tmp/test_checksum"
    test_data = "data"
    with open(test_file, "w") as f:
        f.write(test_data)
    assert checksum(filename=test_file) == checksum_s(data=test_data)
    assert checksum(filename=test_file, hash_func=sha1) == checksum_s(data=test_data, hash_func=sha1)

# Generated at 2022-06-11 18:00:51.994410
# Unit test for function checksum
def test_checksum():

    this_dir, this_filename = os.path.split(__file__)
    d1 = os.path.join(this_dir, 'test.data')
    d2 = os.path.join(this_dir, 'test2.data')
    f1 = open(d1, "w")
    f1.write("mnopqrstuvwxyz")
    f1.close()
    f2 = open(d2, "w")
    f2.write("abcdefghijklmnopqrstuvwxyz")
    f2.close()

# Generated at 2022-06-11 18:01:00.375402
# Unit test for function md5s
def test_md5s():
    import os
    import random
    import string
    from ansible.module_utils.six.moves import xrange
    import ansible.module_utils.hashivault

    # Generate a very long random string and convert to unicode
    # The hash algorithm should be able to handle unicode input
    long_random_data = "".join([random.choice(string.printable) for i in xrange(4097)])
    unicode_random_data = long_random_data.decode('utf-8')

    # Calculate the md5sum of the data and the unicode string
    md5sum_data = md5s(long_random_data)
    md5sum_unicode = md5s(unicode_random_data)

    # Verify the md5sums are the same even when the input is unicode
   

# Generated at 2022-06-11 18:01:06.538653
# Unit test for function md5
def test_md5():
    assert md5(__file__) == "c76b1f880b7d1081d9d3f28e6af99649"


# Generated at 2022-06-11 18:01:09.985331
# Unit test for function md5s
def test_md5s():
    # if host is configured in FIPS mode and running a python version < 2.7.9
    # the below test will fail and the test will be skipped
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-11 18:01:12.954505
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'af031f638c9b0af930d44a7b44d2bfaf8f6f73d2'


# Generated at 2022-06-11 18:01:24.327416
# Unit test for function md5s
def test_md5s():
    if not _md5:
        print('MD5 not available.  Possibly running in FIPS mode.')
        return
    # standard string
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('HELLO WORLD') == '7b502c3a1f48c8609ae212cdfb639dee'
    # unicode string
    assert md5s(u'') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-11 18:01:29.445521
# Unit test for function checksum
def test_checksum():
    fd, fname = tempfile.mkstemp()
    f = open(fname, "wb")
    f.write(os.urandom(1024))
    f.close()
    chk1 = checksum(filename=fname)
    chk2 = checksum(filename=fname)
    os.unlink(fname)
    assert chk1 == chk2


# Generated at 2022-06-11 18:01:35.252590
# Unit test for function checksum
def test_checksum():
    test_file = "test/files/checksum/chksum_file.txt"
    expected_result = "32041d116d1a2c2aab03e2d94fb8b3424f4476dd"

    result = checksum(test_file)
    assert result == expected_result

# Generated at 2022-06-11 18:01:39.783077
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    #print md5s('foo')
    #print md5s('bar')
    #print md5s(':')
    #print md5s('')

# Generated at 2022-06-11 18:01:49.841697
# Unit test for function md5s
def test_md5s():
    import difflib
    import sys
    import subprocess
    from ansible.utils.hashing import md5s
    from ansible.module_utils._text import to_bytes

    # Ensure that the md5 implementation is working
    # This test is probably a bit brittle since it assumes the
    # following output from md5sum.  But it is good enough for now.
    #
    #  $ echo -n 'yumcheckupdate' | md5sum
    #  6c5d5a5e5dfa2eb60f97d6a0a01fb87b  -
    #  $ echo -n 'yumcheckupdates' | md5sum
    #  e2f6c8f6a9ac3d0c1f2a46f8a067e35b  -
    #


# Generated at 2022-06-11 18:01:57.029650
# Unit test for function md5s
def test_md5s():
    ''' test md5s function '''

    # fail in FIPS mode
    if not _md5:
        try:
            ansible_md5s('foo')
        except ValueError as e:
            assert e.args[0] == 'MD5 not available.  Possibly running in FIPS mode'
        else:
            assert False, "ansible_md5s should fail in FIPS mode"

    # check if function returns correct value when correct data is passed
    assert ansible_md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-11 18:02:04.982604
# Unit test for function md5
def test_md5():
    from ansible.utils.digest_utils import md5

    # Test for md5 for file
    md5_val = md5('digest_utils.py')
    assert(md5_val == 'd6c45c1f91fc9f4d4b4e6cabe64131e8')

    # Test for md5 for string
    md5_val = md5s('abcd')
    assert(md5_val == 'e2fc714c4727ee9395f324cd2e7f331f')


# Generated at 2022-06-11 18:02:12.756477
# Unit test for function checksum
def test_checksum():
    # Create test file
    (fd, fname) = tempfile.mkstemp()
    os.write(fd, "Hello World")
    os.close(fd)

    # Check if function works
    assert checksum(fname) == md5(fname)
    assert checksum_s("Hello World") == md5s("Hello World")

    # Clean up
    os.unlink(fname)

# Generated at 2022-06-11 18:02:24.012994
# Unit test for function md5s
def test_md5s():
    from ansible.utils.unicode import to_unicode
    assert md5s(to_unicode('')) == u'0912d78f34ef52e4025ae9138e7b0896'
    assert md5s(to_unicode('abc')) == u'900150983cd24fb0d6963f7d28e17f72'
    assert md5s(to_unicode('test-test-test')) == u'69ec2d964678b138f001622d81c54d98'
    assert md5s(to_unicode('test-test-test-')) == u'0a3a7a0a5475e69f3cac2eceee428287'

# Generated at 2022-06-11 18:02:27.220727
# Unit test for function md5s
def test_md5s():
    test_data = "test string"
    md5_value = md5s(test_data)
    assert md5_value == "5f4dcc3b5aa765d61d8327deb882cf99"


# Generated at 2022-06-11 18:02:37.883134
# Unit test for function checksum
def test_checksum():
    f = open("/tmp/testfile", 'w')
    f.write("test123")
    f.close()

    assert(checksum("invalidfile") is None)
    assert(checksum("/tmp/testfile") == 'bfebba17b4749d2150fddb08f7e66e11')
    assert(checksum("/tmp/testfile", hash_func=_md5) == 'd8e8fca2dc0f896fd7cb4cb0031ba249')

    f = open("/tmp/testfile", 'w')
    f.write("test456")
    f.close()

    assert(checksum("/tmp/testfile") == '3f3da55504adc9d385e0a8fbe1b6f11c')

# Generated at 2022-06-11 18:02:42.402333
# Unit test for function checksum
def test_checksum():
    ''' test the checksum method '''
    if not os.access('lib/ansible/module_utils/basic.py', os.R_OK):
        # Unit tests are run from the test directory.
        # This will only work when run from this dir.
        return 'skipping checksum, not in test/ unit test directory'

    test_file = 'lib/ansible/module_utils/basic.py'
    if checksum(test_file) != '1b9f4fa4fd4c4b643d4d1cfd7a8a168537c383d3':
        return 'checksum returned wrong value'

    return 0

# Generated at 2022-06-11 18:02:44.206533
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'ecb69bc5bac415fcf58d90a8928302ee'


# Generated at 2022-06-11 18:02:50.616769
# Unit test for function md5s
def test_md5s():
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcd') == 'a96d5cbffb759cb5c0f4b4fd1e50c9e5'


# unit test for function md5

# Generated at 2022-06-11 18:02:55.199097
# Unit test for function md5s
def test_md5s():
    import sys
    import doctest
    (failure_count, test_count) = doctest.testmod(sys.modules[__name__])
    print('%s' % (failure_count))
    if failure_count:
        exit(1)

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-11 18:03:02.325568
# Unit test for function md5
def test_md5():
    '''
    ansible.utils.hashing.md5
    '''
    import tempfile

    fd, fname = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        f.write('hello world')

    assert (md5(fname) == '5eb63bbbe01eeed093cb22bb8f5acdc3')

# Generated at 2022-06-11 18:03:08.821932
# Unit test for function md5s
def test_md5s():

    # Test no input
    if md5s(None) != "d41d8cd98f00b204e9800998ecf8427e":
        raise AssertionError()

    # Test empty string
    if md5s("") != "d41d8cd98f00b204e9800998ecf8427e":
        raise AssertionError()

    # Test non-empty string
    if md5s("foo") != "acbd18db4cc2f85cedef654fccc4a4d8":
        raise AssertionError()


# Generated at 2022-06-11 18:03:19.083229
# Unit test for function md5s
def test_md5s():
    if os.name == 'posix':
        data = secure_hash_s('foo', _md5)
        assert data == 'acbd18db4cc2f85cedef654fccc4a4d8'
        data = secure_hash_s('bar', _md5)
        assert data == '37b51d194a7513e45b56f6524f2d51f2'
        data = secure_hash_s('baz', _md5)
        assert data == '983e5152ee66c27c2d32ae0c35cb8a9c'



# Generated at 2022-06-11 18:03:29.535233
# Unit test for function checksum
def test_checksum():
    """ test_checksum: make sure checksum computes correctly.
    """

    # Set up a basic datastructure to use
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    t = Task()
    t.action = 'shell echo "hello"'
    t.args['chdir'] = '~/'
    t.args['creates'] = '/tmp/textfile.txt'
    t.args['removes'] = '/tmp/textfile.txt'
    t.args['executable'] = None
    t.register = 'shell_out'
    t.when = 'True'

    # Test with a basic Task

# Generated at 2022-06-11 18:03:35.471262
# Unit test for function md5s
def test_md5s():
    assert(md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8')

if __name__ == "__main__":
    import unittest
    suite = unittest.TestLoader().loadTestsFromTestCase(TestUtil)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-11 18:03:39.281985
# Unit test for function md5
def test_md5():
    filename = "ansible/test/utils/test.py"
    md5_hash = md5(filename)
    assert md5_hash == "b1154c56de7f8a00d1dc7e046c39e35b", "md5 hash conversion failed"
    assert md5_hash == secure_hash(filename, md5), "md5 hash conversion failed"


# Generated at 2022-06-11 18:03:49.825213
# Unit test for function checksum
def test_checksum():
    ''' test checksum functionality '''

    # simple test
    test_string = "mytest"
    test_hash = checksum_s(test_string)
    assert test_hash == "c81e728d9d4c2f636f067f89cc14862c"

    # test file hash
    test_data = "Hello World"
    test_file = "test_checksum"

    # create a new file
    try:
        f = open(test_file, "w")
        f.write(test_data)
        f.close()
    except IOError:
        assert False

    test_hash = checksum(test_file)

    # remove the test file
    try:
        os.remove(test_file)
    except IOError:
        assert False

    assert test_hash

# Generated at 2022-06-11 18:03:52.017624
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-11 18:04:00.687466
# Unit test for function md5s
def test_md5s():

    # Test for md5s()
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\n') == '41b755c731ddf0e75e1d9bd9bfdc1b25'
    assert md5s('hello\nworld') == '886325b3a2f9b945c9b7a05d3439ad37'
    assert md5s('hello\nworld\n') == '9da40f2c0b0e173316c73628f75b58c0'



# Generated at 2022-06-11 18:04:09.890092
# Unit test for function checksum
def test_checksum():
    from tempfile import NamedTemporaryFile

    # Test a simple string
    if checksum_s('test') != 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3':
        raise Exception('Failed to create expected checksum')

    # Test a file
    tf = NamedTemporaryFile(mode='w')
    tf.write('test')
    tf.seek(0)
    if checksum(tf.name) != 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3':
        raise Exception('Failed to create expected checksum')

if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-11 18:04:16.634762
# Unit test for function md5
def test_md5():
    """
    Basic test for compat/hashing.py module
    """
    from ansible.module_utils.hashing import md5

    TO_HASH = u'this is a test'
    TO_HASH_ASCII = b'this is a test'

    TEST_MD5 = u'8ae7f51a3a3a2a43cad8b11255b617a9'

    assert md5s(TO_HASH) == TEST_MD5
    assert md5s(TO_HASH_ASCII) == TEST_MD5

    TEST_FILE = './test/resources/test_md5.txt'
    assert md5(TEST_FILE) == TEST_MD5



# Generated at 2022-06-11 18:04:27.570535
# Unit test for function checksum
def test_checksum():

    error_msg = "HASH ERROR"

    # sha1(b'hello') = 2aae6c35c94fcfb415dbe95f408b9ce91ee846ed
    # md5(b'hello') = 5d41402abc4b2a76b9719d911017c592
    # sha1('hello') = fc4bd96f8dd265e5a5d624f84f3b3c8dfa6b4d4a

# Generated at 2022-06-11 18:04:33.803201
# Unit test for function md5
def test_md5():
    assert md5(__file__) == '66b0af907f824b23d88e1ac10fb0543b'

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:04:37.551205
# Unit test for function md5
def test_md5():
    '''md5 is only a wrapper around secure_hash.  But we can at least confirm that it is
    returning a non-zero length string.'''

    filename = os.path.realpath(__file__)
    assert len(md5(filename)) > 0
    assert len(md5s(filename)) > 0

# Generated at 2022-06-11 18:04:44.180004
# Unit test for function md5s
def test_md5s():
    assert md5s("") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5s("a") == "0cc175b9c0f1b6a831c399e269772661"
    assert md5s("abc") == "900150983cd24fb0d6963f7d28e17f72"
    assert md5s("message digest") == "f96b697d7cb7938d525a2f31aaf161d0"
    assert md5s("abcdefghijklmnopqrstuvwxyz") == "c3fcd3d76192e4007dfb496cca67e13b"

# Generated at 2022-06-11 18:04:48.884103
# Unit test for function checksum
def test_checksum():
    assert checksum_s("some_string") == '2d8be8f8eddb6a9ab0f9d0eee713e8d7e2dc03c2'
    assert checksum('test/fixtures/ansible_module_test/test.txt') == 'b6a0a6c7f8d85001e7c6fd25fdc9d9e8f25ca3c2'



# Generated at 2022-06-11 18:04:56.262137
# Unit test for function md5s
def test_md5s():
    value = 'The quick brown fox jumped over the lazy dog'
    key = 'f7bc83f430538424b13298e6aa6fb143'
    assert md5s(value) == key
    assert md5(os.path.realpath(os.path.join(os.path.dirname(__file__), '../test/test.cfg'))) == '4d27e8e4d4d9f9c9ed69cb34cb8caa0c'

# Generated at 2022-06-11 18:05:05.846710
# Unit test for function md5s
def test_md5s():
    import sys
    if sys.version_info[0] > 2:
        assert md5s(u'abc') == '900150983cd24fb0d6963f7d28e17f72'
        assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    else:
        assert md5s(u'abc') == md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abc' + u'123') == 'e99a18c428cb38d5f260853678922e03'
    assert md5s('abc' + b'123') == 'e99a18c428cb38d5f260853678922e03'


# Generated at 2022-06-11 18:05:12.487546
# Unit test for function md5
def test_md5():
    file1 = open('/tmp/testmd5', 'w')
    file1.write('This is a test')
    file1.close()
    file2 = open('/tmp/testmd5', 'r')
    file3 = open('/tmp/testmd5_1', 'w')
    file3.write('This is a test')
    file3.close()
    file4 = open('/tmp/testmd5_1', 'r')
    if md5('/tmp/testmd5') == md5('/tmp/testmd5_1'):
        assert True
    else:
        assert False

# Generated at 2022-06-11 18:05:18.722194
# Unit test for function md5
def test_md5():
    import tempfile
    tf = tempfile.NamedTemporaryFile() # pylint: disable=redefined-outer-name
    tf.write(b"hello world")
    tf.flush()
    assert md5(tf.name) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(b"hello world") == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Test of function secure_hash_s

# Generated at 2022-06-11 18:05:25.648968
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return
    m = md5s(secure_hash_s('test'))
    m2 = md5s(secure_hash_s('test'))
    assert m == m2
    assert len(m) == 32
    assert m == '098f6bcd4621d373cade4e832627b4f6', 'md5s() test failed.'

if __name__ == '__main__':
    try:
        test_md5s()
    except:
        pass