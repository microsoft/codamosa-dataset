

# Generated at 2022-06-11 17:55:31.879351
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-11 17:55:37.989186
# Unit test for function checksum
def test_checksum():
    assert checksum('setup.cfg') == 'f5d4e4e3a4f26a630b8e87f17a2b2d25acb58f87'
    assert checksum('setup.py') == 'cdf2b5443c0adc1ad92d5be91e8ebe0a54d41b7e'
    assert checksum('library/') == None
    assert checksum('test/fixtures/checksum/foo') == '2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae'
    assert md5('setup.cfg') == 'ee20a1fed2b2f2d1e2a2eefa6f9e9a3a'

# Generated at 2022-06-11 17:55:43.205454
# Unit test for function checksum
def test_checksum():
    ''' test_checksum: test of function checksum '''
    results = checksum('test/support/test_module_utils/test_checksum')
    assert results == '2aa2e02b076ffb8a8987818e7df6d9e91cf0c821'



# Generated at 2022-06-11 17:55:45.299203
# Unit test for function md5s
def test_md5s():
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-11 17:55:50.438629
# Unit test for function md5
def test_md5():
    # Example md5 checksum from http://www.faqs.org/rfcs/rfc1321.html
    assert md5("message digest") == "f96b697d7cb7938d525a2f31aaf161d0"


# Generated at 2022-06-11 17:55:53.660933
# Unit test for function md5
def test_md5():
    ''' secure_hash_s should return a 32 character hexadecimal string '''
    assert len(secure_hash_s('string')) == 40, secure_hash_s('string')


# Generated at 2022-06-11 17:55:59.296298
# Unit test for function checksum
def test_checksum():
    import tempfile
    import os
    tf = tempfile.NamedTemporaryFile()
    try:
        assert checksum(tf.name) == None
        tf.write('hello')
        tf.flush()
        assert checksum(tf.name) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    finally:
        os.unlink(tf.name)

# Generated at 2022-06-11 17:56:09.120339
# Unit test for function checksum
def test_checksum():
    path = os.path.dirname(os.path.abspath(__file__))
    filenames = ["test.py",  "test2.py"]
    data = ["#!/usr/bin/python",  "abc123"]

    for filename in filenames:
        fullpath = os.path.join(path, filename)
        f = open(fullpath, 'w')
        f.write(data[filenames.index(filename)])
        f.close()
        ansible_checksum = checksum(fullpath)
        # On Windows, the returned digest from Python 3's md5 function and Python 2's md5 function are different
        # So we must use checksum_s for testing
        python_checksum = checksum_s(data[filenames.index(filename)])

# Generated at 2022-06-11 17:56:13.062216
# Unit test for function checksum
def test_checksum():
    res = checksum_s("hello")
    assert res == "5d41402abc4b2a76b9719d911017c592"

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:56:17.216122
# Unit test for function md5
def test_md5():
    import os
    import tempfile

    (fd, fname) = tempfile.mkstemp()
    os.write(fd, "This is a test")
    os.close(fd)

    assert md5(fname) == md5s("This is a test")

    os.remove(fname)

# Generated at 2022-06-11 17:56:26.505383
# Unit test for function md5
def test_md5():
    import tempfile

    f = tempfile.NamedTemporaryFile()
    f.write("something")
    f.flush()
    assert md5(f.name) == "644fc3fb1ea3d93b0f1ae385bccd099a"

    assert md5s("something") == "644fc3fb1ea3d93b0f1ae385bccd099a"

    f.close()

# Generated at 2022-06-11 17:56:29.501069
# Unit test for function md5s
def test_md5s():
    data = "sysctl_name"
    result = md5s(data)
    assert result == 'e0bdda66ab0f6baa5f1561bd1cc91283'


# Generated at 2022-06-11 17:56:35.045249
# Unit test for function checksum
def test_checksum():
    import tempfile
    with tempfile.NamedTemporaryFile('w') as f:
        f.write('test1')
        f.flush()
        assert checksum(f.name, sha1) == checksum_s('test1', sha1)

# Generated at 2022-06-11 17:56:38.098978
# Unit test for function checksum
def test_checksum():
  assert checksum('test_utils.py') == '92a67a6b93f4cdce7b4f3ebb4a4b0f57b038559b'


# Generated at 2022-06-11 17:56:45.138252
# Unit test for function checksum
def test_checksum():
    import tempfile
    import stat

    teststr='test'

    # Test checksum_s
    assert checksum_s(teststr) == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

    # Test checksum
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w+')
    f.write(teststr)
    f.close()

    if os.path.exists(fname):
        assert checksum(fname) == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
        os.unlink(fname)

    # Test that checksum returns None for a directory or non-existent file

# Generated at 2022-06-11 17:56:49.009667
# Unit test for function checksum
def test_checksum():
    path = os.path.join(os.path.dirname(__file__), __file__)
    assert checksum(path) == checksum_s(path)

if __name__ == "__main__":
    import doctest
    doctest.testmod()
    print("TESTS PASSED")

# Generated at 2022-06-11 17:56:58.771189
# Unit test for function md5
def test_md5():
    from shutil import copy2
    import tempfile
    import os
    import pytest
    import sys

    (handle, f1) = tempfile.mkstemp(text=True)
    os.close(handle)
    (handle, f2) = tempfile.mkstemp(text=True)
    os.close(handle)

    file1 = 'test/testdata/base_module/helloworld'
    file2 = 'test/testdata/base_module/helloworld.j2'
    file3 = 'test/testdata/base_module/withcrlf'

    f1_md5 = md5(file1)
    f2_md5 = md5(file2)
    f3_md5 = md5(file3)

    # check that hash value is of correct length and matches the test value

# Generated at 2022-06-11 17:57:09.566309
# Unit test for function checksum
def test_checksum():
    import os
    import tempfile
    from ansible.module_utils.six import PY3

    test_file = os.path.join(tempfile.mkdtemp(), 'hello_world')
    with open(test_file, 'wb') as tf:
        if PY3:
            tf.write('hello_world'.encode('utf-8'))
        else:
            tf.write('hello_world')

    if checksum(test_file) != checksum_s('hello_world'):
        raise AssertionError('FAILURE: checksum_s and checksum calculation failed')
    else:
        print('checksum_s and checksum calculation successed')

    checksum_str = '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
   

# Generated at 2022-06-11 17:57:20.157005
# Unit test for function checksum
def test_checksum():
    ''' test checksum function '''
    import tempfile
    import shutil

    # Can't use TestCase here because there are assertions
    def assert_equal(a, b):
        assert a == b, "%s != %s" % (a, b)

    tmpdir = tempfile.mkdtemp()
    test_file = os.path.join(tmpdir, 'test_file')
    with open(test_file, 'wb') as f:
        f.write('Hello World')

    # Test invalid file
    assert_equal(checksum(os.path.join(tmpdir, 'bogus_file')), None)
    assert_equal(checksum_s('Hello World'), '2ef7bde608ce5404e97d5f042f95f89f1c232871')
    assert_equal

# Generated at 2022-06-11 17:57:25.669056
# Unit test for function checksum
def test_checksum():
    ''' test_checksum() of file_utils.py '''

    from ansible.utils.unicode import to_unicode

    filename = './lib/ansible/module_utils/basic.py'
    assert filename == to_unicode(filename)
    assert checksum(filename)
    assert checksum_s(filename)

# Generated at 2022-06-11 17:57:34.317350
# Unit test for function checksum
def test_checksum():
    # Length of 3 and different type
    assert checksum_s("foo", hash_func=sha1) == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'

    # Length of 3 and byte type
    assert checksum_s(b'foo', hash_func=sha1) == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'

    # Length of 0
    assert checksum_s('', hash_func=sha1) == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'

# Generated at 2022-06-11 17:57:44.315813
# Unit test for function checksum
def test_checksum():
    ''' Unit test for checksum() (non-binary mode, using digest modules directly). '''

    import tempfile

    assert secure_hash_s("foo") == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    assert secure_hash("bin/ansible-doc") == "5d5f564f818f1b32c3871f9d9b0a37d0da89f5c5"

    # Test file creation with whitespace
    (fd, tmpfile) = tempfile.mkstemp(prefix='ansible-test checksum', text=False)
    os.write(fd, b'xx')
    os.close(fd)

# Generated at 2022-06-11 17:57:47.916598
# Unit test for function checksum
def test_checksum():
    ''' Test checksum for a valid string (sha1) '''
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'


# Generated at 2022-06-11 17:57:53.005132
# Unit test for function checksum
def test_checksum():
    '''test checksum'''
    import tempfile
    import shutil
    import os

    test_str = "test string"

    (fd, tmpsrc) = tempfile.mkstemp()
    f = os.fdopen(fd, "wb")
    f.write(test_str)
    f.close()

    checksum_value = checksum(tmpsrc)
    assert(checksum_value == checksum_s(test_str))

    os.unlink(tmpsrc)
    shutil.rmtree(tmpsrc + "_dir")

# Generated at 2022-06-11 17:58:02.310333
# Unit test for function checksum
def test_checksum():
    # Known checksums of cleartext files.
    # Unfortunately this test is somewhat brittle as
    # it would fail if the hashes were implemented as
    # something other than sha1 and md5.

    assert checksum('test/support/test1.txt') == 'a7d93e2b11f7f9b4d4fb22fa4c35803771c4e0d5'
    assert checksum('test/support/test2.txt') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert checksum('test/support/test3.txt') == '0cc175b9c0f1b6a831c399e269772661'

    # test against known checksum of test1.txt
    assert checksum('test/support/test1.txt')

# Generated at 2022-06-11 17:58:05.202156
# Unit test for function md5s
def test_md5s():
    if md5s('test') != '098f6bcd4621d373cade4e832627b4f6':
       raise Exception('MD5 test failed')

# Generated at 2022-06-11 17:58:14.874888
# Unit test for function md5s
def test_md5s():
    from ansible.utils.unsafe_proxy import UnsafeBytes
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    assert md5s(u'spam') == '34eaa4d4a7c4afe4e2199b3a56b66a24'
    assert md5s(AnsibleUnicode('spam')) == '34eaa4d4a7c4afe4e2199b3a56b66a24'
    assert md5s('spam') == '34eaa4d4a7c4afe4e2199b3a56b66a24'

# Generated at 2022-06-11 17:58:24.787317
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    from tempfile import mkdtemp
    from shutil import rmtree

    test_file = """#!/usr/bin/python
    print "success"""

    tmp_dir = mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test')
    f = open(tmp_file, 'w')
    f.write(test_file)
    f.close()

    test_sum = checksum(tmp_file)
    assert test_sum is not None
    test_sum2 = checksum(tmp_file)
    assert test_sum == test_sum2

    # cleanup
    rmtree(tmp_dir)



# Generated at 2022-06-11 17:58:26.174107
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-11 17:58:27.342757
# Unit test for function md5s
def test_md5s():
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-11 17:58:37.654669
# Unit test for function md5s
def test_md5s():
    local_md5s = md5s
    if to_bytes('中文123') != b'\xe4\xb8\xad\xe6\x96\x87123':
        # python2
        local_md5s = lambda data: md5s(data).encode('utf-8')

    if local_md5s('中文123') != 'c7a0e2cbbd55b1a3e84e9b966b1e6c52':
        raise ValueError('md5s failed')



# Generated at 2022-06-11 17:58:41.710793
# Unit test for function md5
def test_md5():
    def check_md5(filename1, filename2):
        assert md5(filename1) == md5(filename2)
    # Test against md5sums in the system
    check_md5(__file__, '/bin/ls')


# Generated at 2022-06-11 17:58:43.953875
# Unit test for function md5s
def test_md5s():
    assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"

# Generated at 2022-06-11 17:58:55.827285
# Unit test for function md5
def test_md5():
    ''' Test md5() function '''

    import tempfile
    import shutil


# Generated at 2022-06-11 17:59:01.603529
# Unit test for function checksum
def test_checksum():
    assert checksum(__file__) == checksum(__file__)
    #
    # Test that __file__ + some data hashes to a different value
    #
    with open(__file__, 'rb') as f:
        x = f.read(1)
    with open(__file__, 'rb') as f:
        y = f.read()
    assert checksum(__file__) != checksum_s(x + y)

# Generated at 2022-06-11 17:59:09.908931
# Unit test for function checksum
def test_checksum():
    input_data = "abcdefghijklmnopqrstuvwxyz"
    checksum_input = secure_hash_s(input_data, sha1)
    if checksum_input != "32bd9dbbca9abecb5c9d676155bcfd9131a37597":
        raise Exception("sha1 checksum test failed")
    checksum_input = md5s(input_data)
    if checksum_input != "c3fcd3d76192e4007dfb496cca67e13b":
        raise Exception("md5 checksum test failed")

# Generated at 2022-06-11 17:59:17.427726
# Unit test for function md5
def test_md5():
    # SHA1 is a FIPS 140-2 approved hash function.
    s = secure_hash_s('hello world')
    assert s == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    # Compare to the output of OpenSSL
    s = md5s('hello world')
    assert s == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    # Compare to the output of OpenSSL
    assert _md5(b'hello world').hexdigest() == '5eb63bbbe01eeed093cb22bb8f5acdc3'


#
# Backwards compat functions.  Some modules include md5s in their return values
# Continue to support that for now.  As of ansible-1.8, all of those modules

# Generated at 2022-06-11 17:59:20.654913
# Unit test for function md5s
def test_md5s():
    # Check hash of a string
    mystring = "Hello, world"
    assert(md5s(mystring) == "86fb269d190d2c85f6e0468ceca42a20")


if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-11 17:59:32.352336
# Unit test for function checksum
def test_checksum():
    test_string = "hello world"
    expected_sha1_sum = "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"

    print ("testing checksum() with sha1")
    actual_sha1_sum = checksum_s(test_string)
    if actual_sha1_sum != expected_sha1_sum:
        raise AssertionError("test string %s did not produce expected sha1sum: %s (got %s)" %
                             (test_string, expected_sha1_sum, actual_sha1_sum))
    print ("testing checksum() with md5")
    if _md5:
        actual_md5_sum = checksum_s(test_string, _md5)

# Generated at 2022-06-11 17:59:40.598794
# Unit test for function checksum
def test_checksum():
    import tempfile

    #
    # The functions checksum() and secure_hash() should be the same
    #
    tfile = tempfile.NamedTemporaryFile()
    assert checksum(tfile.name) == secure_hash(tfile.name)
    assert checksum_s("foobar") == secure_hash_s("foobar")

    #
    # Verify that we are calculating the same checksum with secure_hash()
    # as 'sha1sum' on the command line
    #
    tfile.file.write("Hello World!")
    tfile.file.flush()
    tfile.file.seek(0)
    assert checksum(tfile.name) == "0a0a9f2a6772942557ab5355d76af442f8f65e01"
    tfile.close()


# Generated at 2022-06-11 17:59:51.691050
# Unit test for function checksum
def test_checksum():

    # Update this string to test the function
    test_string = "foo"

    return_sha1 = '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert secure_hash_s(test_string) == return_sha1

    return_md5 = 'acbd18db4cc2f85cedef654fccc4a4d8'

    if _md5:
        assert md5s(test_string) == return_md5

# Generated at 2022-06-11 18:00:02.197006
# Unit test for function checksum
def test_checksum():
    ''' checksum test module '''
    import tempfile

    # make a temporary file
    (handle, fname) = tempfile.mkstemp()
    os.close(handle)

    # fill it with some data
    data = 'ABCDEFG123456789'

    try:
        handle = open(fname, 'wb')
        handle.write(data)
        handle.close()

        # test the data portion
        assert checksum_s(data) == 'a81ac3e8f3b3ee133da7245d4978f0c8e82e3679'

        # test the file portion
        assert checksum(fname) == 'a81ac3e8f3b3ee133da7245d4978f0c8e82e3679'
    finally:
        os.unlink

# Generated at 2022-06-11 18:00:03.801843
# Unit test for function checksum
def test_checksum():
    assert checksum(__file__) == checksum_s(open(__file__).read())



# Generated at 2022-06-11 18:00:10.456161
# Unit test for function checksum
def test_checksum():
    import tempfile

    name = tempfile.mktemp()

    fd = open(name, "w")
    fd.write('Hello World')
    fd.close()

    hash_sha = checksum(name)

    if not hash_sha:
        raise AnsibleError("error in checksum()")

    os.remove(name)


# Generated at 2022-06-11 18:00:19.273276
# Unit test for function checksum
def test_checksum():
    ''' unit test will create a temp file with the following contents:
    hacktheplanet
    thisistheend
    myonlyfriend
    '''

    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('hacktheplanet\n')
    f.write('thisistheend\n')
    f.write('myonlyfriend\n')
    f.close()
    file_hash = checksum(fname)
    assert file_hash == 'c5ce2e16ed89c5e3b3da9d5abaca228d9e45821b'
    file_hash = checksum_s('this string will be hashed')

# Generated at 2022-06-11 18:00:25.498802
# Unit test for function md5
def test_md5():
    if _md5:
        assert md5s("Hello World") == "b10a8db164e0754105b7a99be72e3fe5"
        assert md5(__file__) == md5s(open(__file__).read())
    else:
        from nose.plugins.skip import SkipTest
        raise SkipTest("Skipping because system is running in FIPS mode")


# Generated at 2022-06-11 18:00:28.745681
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"

if __name__ == "__main__":
    print("Test for md5s")
    test_md5s()

# Generated at 2022-06-11 18:00:30.263713
# Unit test for function md5
def test_md5():
    assert md5("file.txt") == md5("file.txt")



# Generated at 2022-06-11 18:00:39.721320
# Unit test for function md5s
def test_md5s():
    ''' test_md5s.py: test the md5s function '''
    from ansible.utils.hashing import md5s, checksum_s
    from ansible.module_utils._text import to_bytes

    # Test md5s function directly
    str1 = 'string1'
    str2 = 'string2'
    str3 = 'string3'
    assert md5s(str1) == md5s(str1)
    assert md5s(str1) != md5s(str2)
    assert md5s(str1) != md5s(str3)

    # Test that it is equivalent to checksum_s
    # The checksum algorithm must match with the algorithm in ShellModule.checksum() method
    data = to_bytes(str1, errors='strict')

# Generated at 2022-06-11 18:00:42.483678
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-11 18:00:53.496633
# Unit test for function checksum
def test_checksum():
    import tempfile
    fd, fqfn = tempfile.mkstemp()
    fp = os.fdopen(fd, "wb")
    fp.write(b'foobar')
    fp.close()
    chk = checksum(fqfn)
    # md5sum $fqfn
    #  -> 3858f62230ac3c915f300c664312c63f
    assert chk == '3858f62230ac3c915f300c664312c63f'
    os.remove(fqfn)

# Generated at 2022-06-11 18:00:57.170369
# Unit test for function checksum
def test_checksum():
    checksum_data = checksum_s('test')
    assert checksum('test.py') == checksum_data
    assert checksum('/etc/hosts') == checksum_data
    assert checksum('/etc/hosts_nonexistent') is None

# Generated at 2022-06-11 18:01:07.209156
# Unit test for function checksum
def test_checksum():
    """Unit test for function checksum"""
    import shutil
    import tempfile

    (fd, filename) = tempfile.mkstemp()
    os.write(fd, 'hello')
    os.close(fd)

    assert checksum(filename) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    os.unlink(filename)
    shutil.rmtree(filename)


# Generated at 2022-06-11 18:01:09.599100
# Unit test for function md5
def test_md5():
    ''' md5 should be available.  If this fails, it is likely you are running in FIPS mode'''
    assert md5('/etc/passwd')


# Generated at 2022-06-11 18:01:14.839024
# Unit test for function md5
def test_md5():
    ''' md5 unit test'''

    import tempfile

    # Setup tempfile
    testfilename = tempfile.mkstemp()
    f = os.fdopen(testfilename[0], "wb")
    f.write("This is a test")
    f.close()

    # Test
    assert md5(testfilename[1]) == '59e1ea6d3b01a15cba887796c6f94a47',\
        "md5() should return the correct value."

    # Teardown tempfile
    os.remove(testfilename[1])


# Return md5 backwards compat
f_md5 = md5
f_md5s = md5s

# Generated at 2022-06-11 18:01:24.325110
# Unit test for function checksum
def test_checksum():
    data = 'This is the data to be hashed'
    hexdigest_expected = '12dc2fae8afc6a8d59a34744d3c7ee8e5f2c5bae'
    digest = checksum_s(data)
    assert digest == hexdigest_expected, "Computed checksum does not match expected checksum"

# Run module directly for automated testing
if __name__ == '__main__':
    import sys
    try:
        # test_checksum()
        sys.exit(0)
    except AssertionError as e:
        sys.exit(str(e))

# Generated at 2022-06-11 18:01:29.443778
# Unit test for function md5
def test_md5():
    data = 'test'
    data_hash = '098f6bcd4621d373cade4e832627b4f6'
    print("Testing md5")
    print("Data %s " % data)
    print("Data hash %s " % data_hash)
    print("Generated hash %s " % md5s(data))
    assert (data_hash == md5s(data))

# Generated at 2022-06-11 18:01:40.294877
# Unit test for function md5
def test_md5():
    # some test data
    data1 = 'this is a string'
    data2 = 'this is another string'
    data3 = 'this is a short string'
    # expected results
    res1 = 'f7d2f2e52d73891a8d4c7c61bce4d4e1'
    res2 = '6c27f6bc259192a48a0528aa88e2a0e1'
    res3 = '1cefad01d73c0bf73629b99f09dc3a7a'
    # run test
    r = md5s(data1)
    if r != res1:
        print('ERROR: test1 failed')
    r = md5s(data2)
    if r != res2:
        print('ERROR: test2 failed')
   

# Generated at 2022-06-11 18:01:47.711219
# Unit test for function md5
def test_md5():
    assert(md5('/bin/ls') == '0a0a49d75f51e42096c8f44e90f2e9ce')
    assert(md5('/bin/false') == 'ef46db3751d8e999')
    assert(md5('/bin/foo') is None)
    assert(md5('/etc/passwd') == '6b1012e9f9b96d947c30884541e02d62')


# Generated at 2022-06-11 18:01:57.258327
# Unit test for function checksum
def test_checksum():
    assert checksum_s("foo") == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    assert checksum("hashes.py") == "3864e0f6af03d946a2b72a05e7e0edf8102bb68d"
    import tempfile
    fd, tfn = tempfile.mkstemp()
    tf = os.fdopen(fd, "w")
    tf.write("foo")
    tf.close()
    assert checksum(tfn) == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    os.unlink(tfn)

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:02:10.554422
# Unit test for function md5s
def test_md5s():
    from ansible.module_utils import basic

    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'

    # test file module support
    tmpfn = basic.tempfile(ext='.txt')
    basic.write_file(filename=tmpfn, data='hello')
    assert md5(tmpfn) == '5d41402abc4b2a76b9719d911017c592'
    os.unlink(basic.to_bytes(tmpfn))


# Generated at 2022-06-11 18:02:14.200133
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

if __name__ == "__main__":
    print(secure_hash_s('foo'))
    print(secure_hash_s('bar'))
    print(secure_hash('test/test.py'))

# Generated at 2022-06-11 18:02:18.841970
# Unit test for function md5
def test_md5():
    str = "This is some data to hash"
    res = "b1be55b5c6e2bf3a8a2fba2c9bdc4c4d"
    assert md5s(str) == res


# Generated at 2022-06-11 18:02:20.003937
# Unit test for function md5
def test_md5():
    md5('/etc/group')


# Generated at 2022-06-11 18:02:23.581475
# Unit test for function md5
def test_md5():
    ''' basic md5 test '''
    test_string = "Hi, this is a test."
    assert md5s(test_string) == '9b6bc58b0a0774d3cc3b93e4d7ff4c1f'

#Unit test for function checksum

# Generated at 2022-06-11 18:02:27.563908
# Unit test for function md5
def test_md5():
    checksum_error=False
    data = 'abc'
    checksum = md5s(data)
    if checksum != "900150983cd24fb0d6963f7d28e17f72":
        checksum_error=True
    return checksum_error


# Generated at 2022-06-11 18:02:31.140429
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-11 18:02:37.957593
# Unit test for function md5
def test_md5():
    with open('/etc/passwd') as fh:
        passwd_data = fh.read()
    assert md5(filename='/etc/passwd') == '19d7e2a98e8b8c1af97a4b025756d6f4'
    assert md5s(data=passwd_data) == '19d7e2a98e8b8c1af97a4b025756d6f4'

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:02:44.021066
# Unit test for function md5s
def test_md5s():

    # Testing with different type of inputs
    assert md5s('hi') == '49f68a5c8493ec2c0bf489821c21fc3b'
    assert md5s('hi') == '49f68a5c8493ec2c0bf489821c21fc3b' == md5s(u'hi')
    assert md5s('hi') == '49f68a5c8493ec2c0bf489821c21fc3b' == md5s(42)
    assert md5s('hi') == '49f68a5c8493ec2c0bf489821c21fc3b' == md5s('42')
    assert md5s(b'hi') == '49f68a5c8493ec2c0bf489821c21fc3b'


# Generated at 2022-06-11 18:02:46.584887
# Unit test for function md5
def test_md5():
    md5_val = md5(__file__)
    print (md5_val)
    assert md5_val == "5a35e62eceb42d8170833c5989113dca"


# Generated at 2022-06-11 18:02:52.759283
# Unit test for function checksum
def test_checksum():
    assert checksum('README.md') == '9c9a1f9d5b04d5ef0a4f4c96bfa67ad1f878f3ad'
    assert checksum('file-not-found') is None
    assert checksum('.') is None


# Generated at 2022-06-11 18:03:05.089317
# Unit test for function md5
def test_md5():
    module_name = os.path.basename(__file__)
    file_name = os.path.splitext(module_name)[0]

    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    module_name = os.path.basename(__file__)
    file_name = os.path.splitext(module_name)[0]
    fp = open(os.path.abspath(file_name), 'r')
    test_md5 = md5s(fp.read())
    fp.close()
    fp = open(os.path.abspath(file_name), 'r')
    test_md5 = md5(os.path.abspath(module_name))
    fp.close()



# Generated at 2022-06-11 18:03:11.031813
# Unit test for function md5s
def test_md5s():
    value = 'ABC'

    # By default md5s function will use sha1
    digest = md5s(value)

    # In this test we don't know the exact value returned by sha1 because
    # we cannot throw an exception in FIPS mode.
    # The value is : '3c01bdbb26f358bab27f267924aa2c9a03fcfdb8'
    assert digest == '3c01bdbb26f358bab27f267924aa2c9a03fcfdb8' or digest == 'a9993e364706816aba3e25717850c26c9cd0d89d'


# Generated at 2022-06-11 18:03:14.476432
# Unit test for function checksum
def test_checksum():
    ''' test the checksum function '''

    # Create a temporary test file
    import tempfile
    fd,test_filename = tempfile.mkstemp(prefix='ansible_test_checksum')
    f = os.fdopen(fd,'w')
    f.write('test')
    f.close()
    os.chmod(test_filename, 0o666)

    assert(checksum(test_filename) == '098f6bcd4621d373cade4e832627b4f6')
    os.remove(test_filename)



# Generated at 2022-06-11 18:03:19.265981
# Unit test for function md5
def test_md5():
    test_s = 'test'
    result_s = md5s(test_s)
    assert(result_s == '098f6bcd4621d373cade4e832627b4f6')

    test_f = 'test/test-hash.py'
    result_f = md5(test_f)
    assert(result_f == 'a0a4477e2fe8f92ac8505c5f1d5f9b5c')

# Generated at 2022-06-11 18:03:21.793078
# Unit test for function md5
def test_md5():
    '''Unit test for function md5'''
    assert md5('/usr/bin/ansible') == '1be15a332168e7f595e664b1a54d8e2b'

# Generated at 2022-06-11 18:03:24.695810
# Unit test for function md5
def test_md5():
    try:
        # If FIPS-140-2 mode is enabled, this should fail
        md5('md5_test.py')
    except ValueError:
        return False
    return True

# Generated at 2022-06-11 18:03:35.933173
# Unit test for function checksum
def test_checksum():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test sensitive data
    a_bytes = b'x\x01\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF'
    a_text = u'x\u0001\uFFFF\uFFFF\uFFFF\uFFFF\uFFFF\uFFFF\uFFFF\uFFFF\uFFFF'
    a = AnsibleUnsafeText(a_text)

    s = secure_hash_s(a)

# Generated at 2022-06-11 18:03:45.645438
# Unit test for function checksum
def test_checksum():
    '''Return True if all the function return values are as expected, else return False'''
    assert len(secure_hash_s('hello')) == 40, "secure_hash_s('hello') failed"
    assert len(secure_hash('falsefile')) == 40, "secure_hash('falsefile') failed"
    assert checksum('falsefile') == secure_hash('falsefile'), "checksum('falsefile') failed"
    assert len(checksum('falsefile')) == 40, "checksum('falsefile') failed"
    assert checksum_s('hello') == secure_hash_s('hello'), "checksum_s('hello') failed"
    assert len(checksum_s('hello')) == 40, "checksum_s('hello') failed"

# Generated at 2022-06-11 18:03:51.984835
# Unit test for function md5
def test_md5():
    # Create temporary test file
    test_file = open('/tmp/ansible_test_md5_file', 'w')
    test_file.close()

    # Check md5 digest match
    assert md5('/tmp/ansible_test_md5_file') == to_bytes(md5s(u'test'), errors='surrogate_or_strict')

    # Remove temporary test file
    os.remove('/tmp/ansible_test_md5_file')

# Generated at 2022-06-11 18:04:05.911419
# Unit test for function checksum
def test_checksum():

    # A small subset of the tests from the tests/utils/test_template.py file
    assert checksum("foobar") == "8843d7f92416211de9ebb963ff4ce28125932878"
    assert checksum("foo\nbar\n") == "4f21c3dbcde3c38c327f0e3af327580c1f481252"
    assert checksum("foo\nbar\n", _md5) == "3858f62230ac3c915f300c664312c63f"
    assert checksum("foo\r\nbar\r\n") == "70d8021d1cad97fc2d68d9356d2d37ea68bed08b"

# Generated at 2022-06-11 18:04:08.116293
# Unit test for function md5s
def test_md5s():
    expected = "d41d8cd98f00b204e9800998ecf8427e"
    returned = md5s("")
    assert returned == expected


# Generated at 2022-06-11 18:04:14.593007
# Unit test for function md5s
def test_md5s():
    """
    Make sure we get the same # for md5 on a string as we get for
    checksum for a file with that string as the content.
    """
    import tempfile
    s = "hello world"
    f = tempfile.NamedTemporaryFile(delete=False)
    f.write(s)
    f.close()
    s_md5 = md5s(s)
    f_md5 = md5(f.name)
    assert s_md5 == f_md5

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-11 18:04:20.854329
# Unit test for function md5
def test_md5():
    import tempfile
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write("HelloWorld")
        f.close()
        try:
            m = md5(f.name)
        finally:
            os.remove(f.name)
    if m != "68e656e96b67ff92b7c4a1e0d4c313d3":
        raise ValueError("Invalid md5")

# Generated at 2022-06-11 18:04:29.761298
# Unit test for function md5
def test_md5():
    """
    Test that md5 algorithm works properly.
    """

    from ansible.compat.tests import unittest

    class HashTestCase(unittest.TestCase):
        def setUp(self):
            self.md5 = md5

        def tearDown(self):
            pass

        def test_md5_common_string(self):
            self.assertEqual(
                'd41d8cd98f00b204e9800998ecf8427e',
                self.md5('')
            )

        def test_md5_boolean_value(self):
            self.assertEqual(
                '8a3d3bf1f2cbf744a8f8b906b9bd0c75',
                self.md5(True)
            )


# Generated at 2022-06-11 18:04:33.000446
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'a2e25a8e82e6f7a4fe4c0d9b839b10f4'

# Generated at 2022-06-11 18:04:39.087193
# Unit test for function md5
def test_md5():
    print('TEST md5')
    result = md5('/etc/passwd')
    success = 'fad869d1e7e31bae04580a7a9c9e99ea'
    if result == success:
        print('GOOD: %s' % result)
    else:
        print('BAD: %s' % result)
    result = md5('/etc/passwd-')
    success = None
    if result == success:
        print('GOOD: %s' % result)
    else:
        print('BAD: %s' % result)



# Generated at 2022-06-11 18:04:45.752923
# Unit test for function checksum
def test_checksum():
    data = b"hello world"
    sum = checksum_s(data)
    assert(sum == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed')
    assert(checksum(filename = "/etc/resolv.conf") == 'f1dcf8e7d6bc68e82c7c9179e8d8a7c0aa993925')

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:04:51.731236
# Unit test for function checksum
def test_checksum():
    import os
    import tempfile
    current_dir = os.path.dirname(__file__)
    fd, test_file = tempfile.mkstemp()

# Generated at 2022-06-11 18:04:53.495980
# Unit test for function md5
def test_md5():
    ''' test md5 in python 2.4 mode'''
    assert md5('testdata/python_2.4_data') == '2756a1582eef04f6cac8fa9f2dec9a7c'


# Generated at 2022-06-11 18:05:06.112690
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest
    from ansible.compat.tests import mock

    with mock.patch('os.path.exists', mock.Mock(return_value=True)):
        with mock.patch('os.path.isdir', mock.Mock(return_value=True)):
            assert checksum('') == None

    with mock.patch('os.path.exists', mock.Mock(return_value=False)):
        with mock.patch('os.path.isdir', mock.Mock(return_value=False)):
            assert checksum('') == None


# Generated at 2022-06-11 18:05:09.818299
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    else:
        try:
            md5s('foo')
        except ValueError as e:
            assert 'MD5 not available.  Possibly running in FIPS mode' in str(e)


# Generated at 2022-06-11 18:05:13.227874
# Unit test for function md5s
def test_md5s():
    msg = "foo bar"
    md5_digest = md5s(msg)
    assert md5_digest == '37b51d194a7513e45b56f6524f2d51f2'



# Generated at 2022-06-11 18:05:16.126752
# Unit test for function md5s
def test_md5s():
    hash1 = md5s('test')
    hash2 = md5s('test')
    assert hash1 is not None
    assert hash2 is not None
    assert hash1 == hash2


# Generated at 2022-06-11 18:05:21.651039
# Unit test for function checksum
def test_checksum():
    func_name = "checksum"
    try:
        filename = "checksum.py"  # this file
        assert checksum(filename, hash_func=None) == checksum(filename, hash_func=None)
        assert checksum(filename, hash_func=None) != checksum(None, hash_func=None)
    except AssertionError:
        print("%s: failed" % func_name)
    else:
        print("%s: success" % func_name)


# Generated at 2022-06-11 18:05:30.194430
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert secure_hash_s("hello world", _md5) == "5eb63bbbe01eeed093cb22bb8f5acdc3"
        assert secure_hash_s("hello world") == "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"
    else:
        try:
            secure_hash_s("hello world", md5)
            raise Exception("Function md5s should not be available in FIPS mode")
        except ValueError as e:
            pass

