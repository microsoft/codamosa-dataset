

# Generated at 2022-06-11 17:55:36.059850
# Unit test for function checksum
def test_checksum():
    test_file = "/tmp/ansible_test_file_checksum"
    test_s = "test"
    expected_checksum = "2a7d1c5139f6208d2eacb2b0390e13d8521b8ff1"

    test_fh = open(test_file, "w")
    test_fh.write(test_s)
    test_fh.close()

    assert checksum(test_file) == expected_checksum

    os.remove(test_file)

# Generated at 2022-06-11 17:55:39.663815
# Unit test for function checksum
def test_checksum():
    # Test with a real file to confirm this works
    assert checksum("/etc/hosts")
    assert checksum_s("hello world")


# Generated at 2022-06-11 17:55:42.629825
# Unit test for function checksum
def test_checksum():
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'

# Generated at 2022-06-11 17:55:49.732311
# Unit test for function md5
def test_md5():
    import os
    import tempfile
    import shutil
    from ansible.module_utils.basic import AnsibleModule

    data = 'the quick brown fox jumped over the lazy dog'
    fd, fname = tempfile.mkstemp()
    f = os.fdopen(fd, 'wb')
    f.write(to_bytes(data, errors='surrogate_or_strict'))
    f.close()

    # Test md5s
    rval = md5s(data)
    AnsibleModule().exit_json(changed=False, sha1=rval)

    # Test md5
    rval = md5(fname)
    AnsibleModule().exit_json(changed=False, sha1=rval)

    os.unlink(fname)

# Generated at 2022-06-11 17:55:58.490174
# Unit test for function checksum
def test_checksum():
    assert secure_hash_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'

    if _md5:
        assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'

    # Test file
    fd, fname = tempfile.mkstemp(dir='/tmp')
    f = os.fdopen(fd, 'w')
    f.write('abc\n')
    f.close()
    assert secure_hash(fname) == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    os.unlink(fname)

# Generated at 2022-06-11 17:56:02.235522
# Unit test for function checksum
def test_checksum():
    s = secure_hash_s("abc123")
    #print s
    assert s == "400fcfe8319c7546e5dd29a00d644fa9dbd95671"


# Generated at 2022-06-11 17:56:06.036021
# Unit test for function checksum
def test_checksum():
    ''' Unit test for function checksum '''
    filename = '/bin/cat'
    print('The checksum is %s' % checksum(filename))
    return True


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:56:17.601546
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '9ca0f3ed764c50591e3e7a0dc6dce43e'
    assert checksum('/bin/ls') == '9ca0f3ed764c50591e3e7a0dc6dce43e'
    assert checksum('/bin/ls') == checksum_s('/bin/ls')
    assert checksum_s('/bin/ls') == '9ca0f3ed764c50591e3e7a0dc6dce43e'
    assert checksum('/bin/ls') == checksum_s('/bin/ls')
    assert checksum('/bin/ls', _md5) == 'e02f0696c89a2b91a8af26d5fd1a5bb5'
   

# Generated at 2022-06-11 17:56:25.456011
# Unit test for function md5
def test_md5():
    '''
        Returns a tuple of (success, result)
    '''
    import tempfile
    try:
        fd, fn = tempfile.mkstemp()
        os.close(fd)
        fd = open(fn, 'w')
        fd.write("hello world")
        fd.close()
        assert(md5(fn) == '5eb63bbbe01eeed093cb22bb8f5acdc3')
        assert(md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3')
    finally:
        os.remove(fn)



# Generated at 2022-06-11 17:56:27.668624
# Unit test for function md5
def test_md5():
    assert md5(__file__) == 'b2f71cde4c9d8e3e3b09748bba6cec7e'

# Generated at 2022-06-11 17:56:36.408985
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    md5 = md5s('test_md5')
    assert md5 == "73e9b9fa70c2d67f2c1d0bae615e768b"

# Generated at 2022-06-11 17:56:44.318544
# Unit test for function md5
def test_md5():

    from ansible.utils.vault import VaultLib

    # file must exist
    if not os.path.exists('/bin/cat'):
        raise ValueError('/bin/cat not found')

    # calculate md5 hash of the file
    test_md5 = md5('/bin/cat')

    # open the file
    test_file = open('/bin/cat')

    # the encrypted file must have extension .ansible_vault
    vault_file = VaultLib('ansible')

    # encrypt the file and save as /bin/cat.ansible_vault
    vault_file.encrypt(test_file)

    # calculate md5 hash of the encrypted file
    encrypted_md5 = md5('/bin/cat.ansible_vault')

    # the md5 hash of the encrypted file must not match md5

# Generated at 2022-06-11 17:56:45.982786
# Unit test for function checksum
def test_checksum():
    checksum_value = checksum(__file__)
    assert checksum_value is not None


# Generated at 2022-06-11 17:56:56.407450
# Unit test for function md5
def test_md5():
    from tempfile import NamedTemporaryFile

    def _test_md5_of_file(data, expected_md5):
        tmp_file = NamedTemporaryFile(delete=False)
        tmp_file.write(data)
        tmp_file.close()
        actual_md5 = md5(tmp_file.name)
        os.unlink(tmp_file.name)
        return actual_md5 == expected_md5

    assert _test_md5_of_file(b"This is the test file", '2ea9c23de7d322bfa8dce325f47153e1')
    assert _test_md5_of_file(b"", 'd41d8cd98f00b204e9800998ecf8427e')

# Generated at 2022-06-11 17:57:05.732787
# Unit test for function md5
def test_md5():
    # Test if md5 is available, if not skip the test
    try:
        from hashlib import md5
    except ImportError:
        return

    testfile = os.path.join(os.path.dirname(__file__), '../packaging/yum/test/yumbackend.py')

    result = md5(testfile)
    assert result == 'b4f4d8ed2823a71a4b4c5a5a7710c8b3'

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 17:57:09.453911
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "a74a0a3a3e4c4b51e7f95c79f01ab00d"

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:57:20.055174
# Unit test for function md5s
def test_md5s():
    ''' test_md5s()  - test md5s function '''

    # Verify that an exception is raised in FIPS mode
    old_md5 = _md5 # preserve original md5 reference
    try:
        _md5 = None
        try:
            md5s('Hello')
        except ValueError as e:
            assert "FIPS" in e.message, "Exception should indicate FIPS mode"
    finally:
        _md5 = old_md5

    # Test md5s with various inputs
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('Hello') == '8b1a9953c4611296a827abf8c47804d7'

# Generated at 2022-06-11 17:57:25.062584
# Unit test for function md5
def test_md5():
    data = "Hello world"
    h = md5s(data)
    assert h == "5eb63bbbe01eeed093cb22bb8f5acdc3"

    # TODO: maybe use tempfile and make sure we can generate an md5 of a file?


# Generated at 2022-06-11 17:57:32.597861
# Unit test for function checksum
def test_checksum():

    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = basic.AnsibleArgs()

    checksum_str = checksum_s("hello")
    assert checksum_str == "5d41402abc4b2a76b9719d911017c592"
    checksum_str = checksum("/etc/passwd")
    assert checksum_str == "6b101fddcdca24941b9fbd9fafd8f044"
    checksum_str = checksum("/etc/missing")
    assert checksum_str is None
    checksum_str = checksum("/etc/")
    assert checksum_str is None

if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-11 17:57:36.365976
# Unit test for function md5
def test_md5():
    test_string = "test string 123"
    test_string_hash = "ed076287532e86365e841e92bfc50d8c"

    assert md5s(test_string) == test_string_hash


# Generated at 2022-06-11 17:57:44.244200
# Unit test for function md5s
def test_md5s():
    ''' test md5s()'''
    if _md5:
        test_md5 = md5s('test_md5')
        assert test_md5 == '28d959a9e1d9c1a7d4816f53e3c5d3cf'
    else:
        try:
            md5s('test_md5')
        except ValueError:
            # This is the expected exception
            pass
        else:
            # No exception raised, but one was expected
            assert False


# Generated at 2022-06-11 17:57:52.015328
# Unit test for function checksum

# Generated at 2022-06-11 17:58:01.008862
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock

    data = b"abcdefgh"

    tmpdir = tempfile.mkdtemp()
    infile = os.path.join(tmpdir, "testfile")
    with open(infile, 'wb') as f:
        f.write(data)

    try:
        results = md5(infile)
    finally:
        shutil.rmtree(tmpdir)

    assert results == "7d793037a0760186574b0282f2f435e7"


# Generated at 2022-06-11 17:58:03.252705
# Unit test for function md5s
def test_md5s():
    assert(md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592')


# Generated at 2022-06-11 17:58:05.703111
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-11 17:58:07.398559
# Unit test for function checksum
def test_checksum():
    assert checksum('file', sha1) is not None
    assert checksum_s('file', sha1) is not None


# Generated at 2022-06-11 17:58:11.947370
# Unit test for function checksum
def test_checksum():
    filename = '/tmp/foo/bar.txt'
    assert checksum(filename) == None
    assert checksum(filename, sha1) == None
    assert checksum_s('abcd', sha1) == '81fe8bfe87576c3ecb22426f8e57847382917acf'

# Generated at 2022-06-11 17:58:13.509038
# Unit test for function md5s
def test_md5s():
    assert md5s('foobar') == "3858f62230ac3c915f300c664312c63f"


# Generated at 2022-06-11 17:58:17.849246
# Unit test for function md5s
def test_md5s():
    """
    Tests string
    """
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


#
# Backwards compatibility only.
#


# Generated at 2022-06-11 17:58:21.998843
# Unit test for function checksum
def test_checksum():
    '''This is a test wrapper around the module function to show how to use the function.'''

    # this will print out the result of the check
    print("Path %s checksum is %s" % (__file__, checksum(__file__)))



# Generated at 2022-06-11 17:58:26.870899
# Unit test for function md5
def test_md5():
    test_file = 'test_data/test_file.txt'
    test_hash = 'e49465cf8d7d9a0e58bd40a1a1fc51d3'
    assert test_hash == md5(test_file)



# Generated at 2022-06-11 17:58:33.492369
# Unit test for function md5s
def test_md5s():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils._text import to_bytes
    import ansible.constants as C

    if C.DEFAULT_HASH_BEHAVIOUR == 'sha1':
        assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
        assert md5s(b'test') == '098f6bcd4621d373cade4e832627b4f6'
        assert md5s(AnsibleUnsafeText(u'test')) == '098f6bcd4621d373cade4e832627b4f6'
        # Make sure binary data isn't mangled by our encoding/decoding

# Generated at 2022-06-11 17:58:41.548548
# Unit test for function md5s
def test_md5s():

    # Test Unicode input
    assert md5s(u'hi') == '49f68a5c8493ec2c0bf489821c21fc3b'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'this is a test') == '6f8db599de986fab7a21625b7916589c'

    # Test different encodings
    assert md5s('hi') == '49f68a5c8493ec2c0bf489821c21fc3b'
    assert md5s('hi'.encode('utf-8')) == '49f68a5c8493ec2c0bf489821c21fc3b'

# Generated at 2022-06-11 17:58:44.731191
# Unit test for function md5
def test_md5():
    data_to_hash = "hello world"
    expected_hash= "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s(data_to_hash) == expected_hash


# Generated at 2022-06-11 17:58:51.437838
# Unit test for function md5
def test_md5():
    ''' md5.py: Test md5 '''

    md5_hash = md5('/etc/passwd')
    assert md5_hash in ['84983c60f7c8b13d47ef2d143322a04d', 'e57f5670b40e8fdaf10909cff6626d17']


# Generated at 2022-06-11 17:58:55.004547
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test\x00') == 'f2c7eafac34a05af92747d3dbbd79e01'



# Generated at 2022-06-11 17:58:57.163800
# Unit test for function md5
def test_md5():
    filename = 'testfile'
    _sha1 = secure_hash(filename)
    _md5 = md5(filename)
    assert _sha1 != _md5


# Generated at 2022-06-11 17:58:59.927348
# Unit test for function md5s
def test_md5s():
    actual = md5s('some data')
    assert actual == 'a6f7e2fb10d9c7c2d38d0b2a3047b8bf'



# Generated at 2022-06-11 17:59:02.137550
# Unit test for function md5s
def test_md5s():
    assert '37caa8a232b0ada9b0c9b9acdb6e8b6c' == md5s('test')

# Generated at 2022-06-11 17:59:06.252525
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('HELLO WORLD') == '7d793037a0760186574b0282f2f435e7'


# Generated at 2022-06-11 17:59:14.630032
# Unit test for function checksum
def test_checksum():
    import tempfile
    (fd, fname) = tempfile.mkstemp()
    with open(fname, 'w') as f:
        f.write('this is some text')
    chk = checksum(fname)
    assert chk == '64fa6d86f6b0a2c1de6b9cc507ee9a6f92c2e1e6'
    os.remove(fname)


# Generated at 2022-06-11 17:59:21.925908
# Unit test for function md5
def test_md5():
    data = '''
        I am a file
        With multiple lines
    '''
    expected_hash = '8ae35e9e9ceae0194f2f1c8b7ce039b2'
    import tempfile
    fd, path = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write(data)
    f.close()
    # Check hash of data string
    assert md5s(data) == expected_hash
    # Check hash of file
    assert md5(path) == expected_hash
    # Clean up
    os.remove(path)

# Generated at 2022-06-11 17:59:25.922613
# Unit test for function md5
def test_md5():
    ''' simple md5 test '''
    assert md5('changelogs/1.0.md') == '61a794814d5b5bd5c5bf5e3e2c5f710e'

# Generated at 2022-06-11 17:59:29.310889
# Unit test for function md5
def test_md5():
    resultmd5 = md5("/tmp/test")
    assert type(resultmd5) is str
    assert len(resultmd5) == 32

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 17:59:37.305889
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    #from tempfile import mkstemp
    #from os import remove
    #from shutil import copyfileobj
    #from sys import version_info
    #from hashlib import md5
    #(fd, fname) = mkstemp()
    #fh = open(fname, 'w')
    #fh.write('test')
    #fh.close()
    #assert md5(fname).hexdigest() == '098f6bcd4621d373cade4e832627b4f6'
    #remove(fname)



# Generated at 2022-06-11 17:59:42.886078
# Unit test for function md5s
def test_md5s():
    ''' basic md5 check '''
    assert md5s("foobar") == '3858f62230ac3c915f300c664312c63f'
    assert md5s("foobar ") == '9d7f1ea8c8ce6595a6a593d6b1bf6c82'
    assert md5s("foo\nbar") == 'c5f7f5eacd0cdc51a3f3ad6c4d6f4287'


# Generated at 2022-06-11 17:59:48.602708
# Unit test for function md5
def test_md5():
    # This is the md5sum of "foo".
    assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 17:59:53.959788
# Unit test for function checksum
def test_checksum():

    if checksum("/bin/ls") != '0f321870a8a38ec4646d4ce82b972ad1cd6c4fe6':
        return False

    # need to check for trailing newline at end of file
    if checksum("/bin/echo") == 'b1946ac92492d2347c6235b4d2611184':
        return True

    return False



# Generated at 2022-06-11 17:59:57.753464
# Unit test for function checksum
def test_checksum():
    assert checksum("test/support/test.py") == '90f93110e7c80649d68c0a70a8a8f982e3d3f1c7'



# Generated at 2022-06-11 18:00:04.760102
# Unit test for function md5
def test_md5():
    assert md5('setup.py') == '612a6076b1cee97a6649c984b781f6b4'
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    try:
        assert md5s(u'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    except UnicodeEncodeError:
        assert False
    try:
        assert md5(u'setup.py') == '612a6076b1cee97a6649c984b781f6b4'
    except UnicodeEncodeError:
        assert False

# Generated at 2022-06-11 18:00:11.162667
# Unit test for function md5s
def test_md5s():
    if _md5:
        test_string = "ABC123"
        test_string_md5 = "900150983cd24fb0d6963f7d28e17f72"
        assert md5s(test_string) == test_string_md5


# Generated at 2022-06-11 18:00:15.621555
# Unit test for function md5
def test_md5():
    filename = "/etc/hosts"
    checksum_value = (md5(filename))
    assert (os.path.exists(to_bytes(filename, errors='surrogate_or_strict')))
    assert (checksum_value is not None)


# Generated at 2022-06-11 18:00:21.225767
# Unit test for function md5
def test_md5():
    md5_input = 'test_string'
    md5_input_hash = '098f6bcd4621d373cade4e832627b4f6'
    test_hash = secure_hash_s(md5_input, _md5)
    assert test_hash == md5_input_hash


# Generated at 2022-06-11 18:00:26.539558
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    if md5('test/test.py') != '5d8f32aa5c19bac9dc77c3770e3c3c3e':
        print('Invalid test checksum in module')



# Generated at 2022-06-11 18:00:28.974694
# Unit test for function md5
def test_md5():
    s = md5s("foobar")
    assert s == "3858f62230ac3c915f300c664312c63f"



# Generated at 2022-06-11 18:00:34.653543
# Unit test for function md5s
def test_md5s():
    data = 'abcdefghijklmnopqrstuvwxyz'
    correct_result = 'c3fcd3d76192e4007dfb496cca67e13b'
    result = md5s(data)
    if result != correct_result:
        raise AssertionError("md5s test failed: got %s but expected %s" % (result, correct_result))


# Generated at 2022-06-11 18:00:41.294089
# Unit test for function md5
def test_md5():
    '''Returns a dictionary of the results of the unit test'''
    import pkg_resources
    test_file_path = pkg_resources.resource_filename('ansible.module_utils.hashlib', 'testfile.txt')
    if not _md5:
        return { 'failed': True, 'msg': 'Unable to import MD5 hashlib' }
    elif md5(test_file_path) == '08df0bd3b43d9c1b7581601c4e8f3c4d':
        return { 'changed': False, 'msg': 'MD5 hash matches' }
    else:
        return { 'changed': True, 'msg': 'MD5 hash differs' }

# Generated at 2022-06-11 18:00:42.765967
# Unit test for function md5
def test_md5():
    '''Returns True if md5 passes, else returns False'''
    try:
        interim_result = md5('setup.py')
        interim_result = md5s('This is a string')
    except ValueError:
        return False
    else:
        return True

# Generated at 2022-06-11 18:00:52.934845
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fpath = os.path.join(tmpdir, "test.txt")
    with open(fpath, "w") as f:
        f.write('')

    # compute the checksum
    file_checksum = checksum(fpath)

    # remove the temporary directory
    shutil.rmtree(tmpdir)

    assert file_checksum == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:01:00.741291
# Unit test for function md5
def test_md5():
    from shutil import copyfile
    from tempfile import mkdtemp
    from os.path import join
    from os import unlink
    from ansible.compat.six import PY3

    test_dir = mkdtemp()
    local_file = join(test_dir, 'local_file')
    remote_file = join(test_dir, 'remote_file')
    copyfile('/bin/cat', local_file)
    copyfile('/bin/cat', remote_file)

    assert md5(local_file) == md5(remote_file)
    assert md5s(local_file) == md5s(remote_file)

    assert md5('unexisting_file') is None
    assert md5s(u'unicode_str' if PY3 else 'unicode_str') is not None

# Generated at 2022-06-11 18:01:08.602829
# Unit test for function md5s
def test_md5s():
    assert md5s(b'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-11 18:01:19.323601
# Unit test for function md5
def test_md5():
    # Test md5
    if _md5:
        if md5("test1.txt") != "aa2ed68b6a3b82796c59f3e4234f589b":
            raise AssertionError("md5() test failed")
        if md5("test2.txt") != "c804f5b5af47c5b5f5d081a6788e0f84":
            raise AssertionError("md5() test failed")
        if md5("test3.txt") != "d41d8cd98f00b204e9800998ecf8427e":
            raise AssertionError("md5() test failed")
        if md5("test4.txt") != "d41d8cd98f00b204e9800998ecf8427e":
            raise Assert

# Generated at 2022-06-11 18:01:27.039695
# Unit test for function checksum
def test_checksum():
    data = 'hello world'

    # should be the same on both with sha1
    assert checksum_s(data) == checksum(data)

    # should be different on both with md5
    assert md5s(data) != md5(data)

    # should be the same on both with md5 (non FIPS)
    if _md5:
        _data = 'hello world'
        assert md5s(_data) == md5(_data)

# Generated at 2022-06-11 18:01:29.163095
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('test123') == 'e8dc4081b13434b45189a720b77b6818'


# Generated at 2022-06-11 18:01:35.912092
# Unit test for function md5
def test_md5():
    from tempfile import mkstemp
    import shutil
    import os
    fo, fname = mkstemp(prefix='ansible.unit')
    os.write(fo, b'Hello World')
    os.close(fo)
    a = md5(fname)
    b = md5s('Hello World')
    os.remove(fname)
    assert a == b

# Generated at 2022-06-11 18:01:44.477984
# Unit test for function md5
def test_md5():
    import os
    import tempfile
    filename = to_bytes(os.path.join(tempfile.gettempdir(), 'sha1_test'))
    # Create a test file, and get its SHA1 hash
    try:
        with open(filename, 'wb') as f:
            f.write(b'abcd')
        assert md5(filename) == 'e2fc714c4727ee9395f324cd2e7f331f'
    finally:
        try:
            os.remove(filename)
        except OSError:
            pass


# Generated at 2022-06-11 18:01:46.928439
# Unit test for function md5s
def test_md5s():

    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-11 18:01:48.822995
# Unit test for function checksum
def test_checksum():
    return checksum('test/test_utils/test.cfg') == 'c4b6d06e594c22f01e88f6c07d3020de'

# Generated at 2022-06-11 18:01:51.481747
# Unit test for function md5s
def test_md5s():
    assert md5s('test123') == '202cb962ac59075b964b07152d234b70'



# Generated at 2022-06-11 18:01:55.775400
# Unit test for function md5
def test_md5():
    from tempfile import mkstemp
    _,tf = mkstemp(text=True)
    with open(tf,"wb") as f:
        f.write("hello")
    assert md5(tf) == "5d41402abc4b2a76b9719d911017c592"
    os.remove(tf)

# Generated at 2022-06-11 18:02:11.790891
# Unit test for function checksum
def test_checksum():

    # Create a temporary text file to process
    (fd, test_file) = mkstemp()

    # Put some test data in the text file

# Generated at 2022-06-11 18:02:20.401121
# Unit test for function md5
def test_md5():
    import tempfile

    (fd, fname) = tempfile.mkstemp()
    os.write(fd, b'foo')
    os.close(fd)
    s = md5(fname)
    os.remove(fname)
    assert s == 'acbd18db4cc2f85cedef654fccc4a4d8'

    s = md5s('foo')
    assert s == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-11 18:02:24.575957
# Unit test for function md5
def test_md5():
    import tempfile
    fp = tempfile.NamedTemporaryFile()
    fp.write('hello world')
    fp.flush()

    assert md5(fp.name) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-11 18:02:27.095719
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6', md5s('test')


# Generated at 2022-06-11 18:02:36.639694
# Unit test for function checksum
def test_checksum():
    '''
    reason for this test:
    we have observed that the order of hash algorithm preference list varies
    between different python versions/platforms. this is a test case to
    ensure that Ansible always uses the same hash algorithm (sha1), regardless
    of the order of preference list.
    '''
    sha1_hash = "b3ec3c3e41ffe39d52891a98cdd6be5c5126c9e2"
    filename = __file__
    assert checksum(filename) == sha1_hash, \
        "checksum() uses hash algorithm other than sha1 - %s was used" % checksum(filename)

# Generated at 2022-06-11 18:02:47.069180
# Unit test for function md5s
def test_md5s():

    import implementation
    import unittest

    class TestMd5sFunctions(unittest.TestCase):
        ''' Unit test for md5s function '''

        def setUp(self):
            pass

        def test_md5s(self):
            ''' Some simple tests for md5s function '''

            # FIPS mode should raise an error
            setattr(implementation, 'fips_enabled', True)
            self.assertRaises(ValueError, md5s, "foo")
            setattr(implementation, 'fips_enabled', False)

            # check some known values
            self.assertEqual(md5s("foo"), 'acbd18db4cc2f85cedef654fccc4a4d8')

# Generated at 2022-06-11 18:02:51.362629
# Unit test for function md5
def test_md5():
    assert md5s('foobar') == '3858f62230ac3c915f300c664312c63f'
    assert md5s(b'foobar') == '3858f62230ac3c915f300c664312c63f'



# Generated at 2022-06-11 18:03:01.567917
# Unit test for function md5
def test_md5():
    from ansible.compat.tests.mock import patch

    with patch('ansible.compat.hashlib.md5') as mock_md5:
        with patch('ansible.compat.os.path.exists') as mock_exists:
            with patch('ansible.compat.os.path.isdir') as mock_isdir:
                mock_exists.return_value = True
                mock_isdir.return_value = True

                md5('filename')

                assert mock_md5.called is True
                assert mock_exists.called is True
                assert mock_isdir.called is True



# Generated at 2022-06-11 18:03:04.437795
# Unit test for function md5
def test_md5():
    if _md5:
        assert md5("/bin/ls") == "ca6e3f3b4e6d8c1f9d7bef77b9a99479"

# Generated at 2022-06-11 18:03:08.188145
# Unit test for function md5
def test_md5():
    from ansible.compat.tests.mock import patch

    with patch('ansible.utils.hashing.secure_hash') as sh:
        assert md5('foo') == sh.return_value
        assert sh.call_count == 1
        sh.assert_called_with('foo', _md5)



# Generated at 2022-06-11 18:03:17.667145
# Unit test for function checksum
def test_checksum():
    assert checksum('./lib/ansible/module_utils/__init__.py') == checksum_s(open('./lib/ansible/module_utils/__init__.py', 'rb').read())

# Generated at 2022-06-11 18:03:20.409006
# Unit test for function md5s
def test_md5s():
    s = 'abc'
    hash_s = md5s(s)
    assert hash_s == '900150983cd24fb0d6963f7d28e17f72'



# Generated at 2022-06-11 18:03:23.796411
# Unit test for function checksum
def test_checksum():
    assert secure_hash_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-11 18:03:29.233953
# Unit test for function checksum
def test_checksum():
    result = checksum("test/test_utils.py")
    assert result == "c1a17f7a3f6d19b7c9f6655a891e10d6fc338e28", "%s != c1a17f7a3f6d19b7c9f6655a891e10d6fc338e28" % result



# Generated at 2022-06-11 18:03:35.263830
# Unit test for function md5
def test_md5():
    md5_path = '/tmp/testfile'
    with open(md5_path, 'w') as fp:
        fp.write("This is a test file for md5")
    assert md5(filename=md5_path) == '20e7eb2f4a4a4d2a2f0d491829c90635'
    os.remove(md5_path)


# Generated at 2022-06-11 18:03:41.714665
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/sh") == checksum("/bin/sh")
    assert checksum("/bin/sh") != checksum("/bin/csh")
    assert checksum_s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert checksum_s("hello", _md5) == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert checksum("/bin/sh") == "b22b170cd07185d88e69bcfd7b645e04a54fc7a8"

# Generated at 2022-06-11 18:03:45.234111
# Unit test for function md5s
def test_md5s():
    assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"
    assert md5s("") == "d41d8cd98f00b204e9800998ecf8427e"

# Generated at 2022-06-11 18:03:47.073453
# Unit test for function md5s
def test_md5s():
    print(md5s('abc'))

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-11 18:03:52.128112
# Unit test for function md5
def test_md5():
    filename = "/etc/passwd"
    if os.path.exists(filename) and not os.path.isdir(filename):
        print("md5 of %s is %s" % (filename, md5(filename)))
    else:
        print("%s is not a regular file" % filename)

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:03:58.853620
# Unit test for function checksum
def test_checksum():
    # FIXME: This should be tested on all platforms, to see if the
    #        return value is consistent
    if checksum('lib/ansible/module_utils/basic.py') != '0c1f2d2c7e976ec253d94a0640df3c3f':
        return False
    if checksum_s('hello') != '5d41402abc4b2a76b9719d911017c592':
        return False
    return True


# Generated at 2022-06-11 18:04:08.643300
# Unit test for function md5s
def test_md5s():
    result = md5s("hello world")
    assert result == "5eb63bbbe01eeed093cb22bb8f5acdc3"



# Generated at 2022-06-11 18:04:13.801250
# Unit test for function checksum
def test_checksum():
    path = os.path.join(os.path.dirname(__file__), '../lib/ansible/module_utils/basic.py')

    assert checksum(path) == '9cdb7d0c1d70eca8e22414b546991b225e167a12'
    assert checksum_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'

# Generated at 2022-06-11 18:04:24.951338
# Unit test for function md5s
def test_md5s():
    assert 'd41d8cd98f00b204e9800998ecf8427e' == md5s('')
    assert '0cc175b9c0f1b6a831c399e269772661' == md5s('a')
    assert '900150983cd24fb0d6963f7d28e17f72' == md5s('abc')
    assert 'f96b697d7cb7938d525a2f31aaf161d0' == md5s('message digest')
    assert 'c3fcd3d76192e4007dfb496cca67e13b' == md5s('abcdefghijklmnopqrstuvwxyz')
    assert 'd174ab98d277d9f5a5611c2c9f419d9f'

# Generated at 2022-06-11 18:04:28.060081
# Unit test for function md5
def test_md5():
    """
    Test function md5.
    """
    assert md5('test/files/test.cfg') == 'a9aefad58cbf7c8b45e2e1c3b3c3c3c8'

# Generated at 2022-06-11 18:04:36.300910
# Unit test for function checksum
def test_checksum():
    # Create file
    filename = 'foo.bar'
    with open(to_bytes(filename, errors='surrogate_or_strict'), 'w') as f:
        f.write("This is a test file.")
    # Calculate secure hash value
    hash = checksum(filename)
    assert hash
    # Remove file
    os.remove(to_bytes(filename, errors='surrogate_or_strict'))
    assert not os.path.exists(to_bytes(filename, errors='surrogate_or_strict'))
    # Calculate secure hash value on non-existent file
    hash = checksum(filename)
    assert (hash is None)

# Generated at 2022-06-11 18:04:40.528383
# Unit test for function md5s
def test_md5s():
    digest = md5s('test')
    if digest != "098f6bcd4621d373cade4e832627b4f6":
        print('[Err]: md5 error, expected "098f6bcd4621d373cade4e832627b4f6", got %s' % digest)
    else:
        print('[OK]: md5 test passed')



# Generated at 2022-06-11 18:04:42.872764
# Unit test for function md5s
def test_md5s():
    # Run tests
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"


# Generated at 2022-06-11 18:04:46.430654
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') is not None
    assert checksum('/bin/ls') == checksum('/bin/ls')


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 18:04:52.171202
# Unit test for function md5s
def test_md5s():
    import sys
    import pytest
    if sys.version_info[0] < 3:
        with pytest.raises(ValueError):
            md5s('foo')
    else:
        assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-11 18:05:00.397852
# Unit test for function checksum
def test_checksum():
    ret1 = checksum('lib/ansible/module_utils/basic.py')
    ret2 = 'd660e5b5a5f5ba5e3bf3d84d6413f3642b31ad9b'

    assert ret1 == ret2
    assert checksum_s('test') == secure_hash_s('test')

if __name__ == '__main__':
    # Test legacy md5.  This will fail when this file is run in FIPS mode.
    md5('lib/ansible/module_utils/basic.py')
    md5s('test')

# Generated at 2022-06-11 18:05:11.810589
# Unit test for function checksum
def test_checksum():
    # Base usage
    assert checksum('sha1.py') == 'd92b5dd7f0edf43a78e1cde4f4c4d4e8b395f0cd'

    # Fake file
    assert checksum('fake-file') is None

    # Directory
    assert checksum('lib/ansible/modules') is None


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:05:20.827917
# Unit test for function md5s

# Generated at 2022-06-11 18:05:23.388403
# Unit test for function md5s
def test_md5s():
    string = 'The quick brown fox jumped over the lazy dogs back.'
    assert md5s(string) == '2347e0c44e1e69ab34b05c3b8cdc75b5'

# Generated at 2022-06-11 18:05:34.422357
# Unit test for function md5
def test_md5():
    from ansible.module_utils import basic

    # Arrange
    tmp_fixture_path = 'hashes_test.out'
    expected_md5 = 'c645bb61f8dc1c838a0408c02e2babaf'
    expected_sha1 = 'fb4d4b4dbb10e7eec58c9254a636f95bbc0bfeb3'

    # Act