

# Generated at 2022-06-11 17:55:33.257751
# Unit test for function md5
def test_md5():
    file_name = 'test_md5'
    with open(file_name, 'w') as f:
        f.write("test")
    assert md5(file_name) == md5s("test")
    os.remove(file_name)
test_md5.unittest = ['test_str']

# Generated at 2022-06-11 17:55:41.819053
# Unit test for function checksum
def test_checksum():
    filename = 'test_checksum.py'
    test_str = 'hello world'
    if os.path.exists(filename):
        # remove existing file with same name
        os.remove(filename)
    # file not exists
    assert checksum(filename) == None
    # file is directory
    assert checksum(__file__) == None
    # file exists
    with open(filename, 'w') as f:
        f.write(test_str)
    assert checksum(filename) == secure_hash_s(test_str)

# Generated at 2022-06-11 17:55:49.564712
# Unit test for function md5
def test_md5():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six.moves import StringIO

    fobj = StringIO('abc')
    fobj_utf8 = BytesIO(b'abc')
    expected_fobj = '900150983cd24fb0d6963f7d28e17f72'
    expected_fobj_utf8 = '900150983cd24fb0d6963f7d28e17f72'

    data = dict(failed=False, changed=False)
    data['stdin'] = fobj
    data['stdin_utf8'] = fobj_utf8


# Generated at 2022-06-11 17:55:52.581654
# Unit test for function md5s
def test_md5s():
    print(md5s("test"))
    # print(md5s("test2"))
    #
    # print(md5s("test3"))


# Generated at 2022-06-11 17:55:56.467959
# Unit test for function md5s
def test_md5s():
    '''
    This is for unit testing for the function md5s
    '''
    if _md5:
        assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    else:
        try:
            md5s('test')
        except ValueError:
            pass

# Generated at 2022-06-11 17:56:00.726164
# Unit test for function md5s
def test_md5s():
    # Test sample data
    data = 'hello world'
    expected_md5_hex_digest = '5eb63bbbe01eeed093cb22bb8f5acdc3'

    md5_hex_digest = md5s(data)
    assert(md5_hex_digest == expected_md5_hex_digest)
    # Test that md5s() works with Unicode strings
    assert(md5s(to_bytes(data, errors='surrogate_or_strict')) == md5_hex_digest)


# Generated at 2022-06-11 17:56:07.806111
# Unit test for function md5
def test_md5():
    test_cases = (
        # test_string, expected result
        ("", "d41d8cd98f00b204e9800998ecf8427e"),
        ("foo", "acbd18db4cc2f85cedef654fccc4a4d8"),
        ("hello world", "5eb63bbbe01eeed093cb22bb8f5acdc3"),
    )

    for t in test_cases:
        result = md5s(t[0])
        assert result == t[1]

# Generated at 2022-06-11 17:56:18.813715
# Unit test for function md5
def test_md5():
    '''
    basic test of md5 function
    '''
    import tempfile

    fd, testfn = tempfile.mkstemp(prefix="ansible_test_md5")
    f = open(testfn, 'w')
    f.write('file content')
    f.close()
    f = open(testfn, 'r')
    f_contents = f.read()
    f.close()
    assert f_contents == 'file content'
    os.close(fd)
    md5_val = md5(testfn)
    os.unlink(testfn)
    # check to see if it's a valid md5sum
    assert len(md5_val) == 32
    int(md5_val, 16)
    return True

# Generated at 2022-06-11 17:56:28.839115
# Unit test for function checksum
def test_checksum():
    path = os.path.join(os.path.dirname(__file__), 'test_utils.py')
    path = os.path.normpath(path)
    checksum_test = checksum(path)
    checksum_test_s = checksum_s(path)
    assert checksum_test == '0a1a8fcee5a78d314c1f9f8b0a2b4956ae6431d1', 'Could not generate expected checksum for test_utils.py'
    assert checksum_test_s == '0a1a8fcee5a78d314c1f9f8b0a2b4956ae6431d1', 'Could not generate expected checksum for test_utils.py'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:56:40.518757
# Unit test for function checksum
def test_checksum():

    # create temp file with some data
    named_temp = None

# Generated at 2022-06-11 17:56:45.650548
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-11 17:56:49.737459
# Unit test for function md5s
def test_md5s():
    if not _md5:
        print('MD5s not available.  Possibly running in FIPS mode')
        return
    data = 'abc'
    md5s1 = md5s(data)
    print('md5s1 is: %s' % md5s1)

#test_md5s()

# Generated at 2022-06-11 17:56:58.637516
# Unit test for function checksum
def test_checksum():
    assert checksum('/tmp/123') != checksum('/tmp/234')

    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'

    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:57:01.672745
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-11 17:57:05.350166
# Unit test for function checksum
def test_checksum():
    ''' ansible checksum test module '''
    if checksum_s('test') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08':
        return True
    else:
        return False

# Generated at 2022-06-11 17:57:11.988072
# Unit test for function checksum
def test_checksum():

    def _compare_hashes(file1, file2):
        """compares two files to determine if they are the same file.
        """
        # First check file size
        if os.path.getsize(file1) != os.path.getsize(file2):
            return False
        # Now check the hash
        hash1 = secure_hash(file1)
        hash2 = secure_hash(file2)
        return hash1 == hash2

    def _create_temp_file(dir, name):
        """Create a temporary file.

        :param dir: The directory where the temporary file is created.
        :param name: The file name.
        :return: The absolute path of the newly created file.
        """
        import random
        import string

# Generated at 2022-06-11 17:57:21.895231
# Unit test for function checksum
def test_checksum():
    import filecmp
    import tempfile

    fd, fp = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('hello')
    f.close()

    fd2, fp2 = tempfile.mkstemp()
    f2 = os.fdopen(fd2, 'w')
    f2.write('goodbye')
    f2.close()

    assert checksum(fp) == '5d41402abc4b2a76b9719d911017c592'
    assert checksum(fp2) == 'f1d70bf8b6932e94dea7ea50ed99f030'

    os.remove(fp)
    os.remove(fp2)

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:57:28.480387
# Unit test for function checksum
def test_checksum():
    from ansible.module_utils import basic
    checksum_data = basic.AnsibleModule(
        argument_spec = dict(data=dict(type='str', default='foo')),
    ).params['data']
    if secure_hash_s(checksum_data) != 'acbd18db4cc2f85cedef654fccc4a4d8':
        raise ValueError("checksum unit test failed")

test_checksum()

# Generated at 2022-06-11 17:57:31.872139
# Unit test for function checksum
def test_checksum():
    assert checksum_s('test data') == 'c9f04dda9a36f3986d8f2c7bcc14e5d5eb5a8a5c'
    assert checksum('/etc/passwd') == 'c2b7f14b6958ebc7f0b18f977a5e5ae3'

# Generated at 2022-06-11 17:57:41.066002
# Unit test for function checksum
def test_checksum():
    import os

    my_file = 'test_checksum.txt'

    f = open(my_file, 'w')
    f.write('test')
    f.close()

    checksum_value = checksum(my_file)

    f = open(my_file, 'w')
    f.write('test1')
    f.close()

    checksum_value_changed = checksum(my_file)

    assert checksum_value != checksum_value_changed

    os.remove(my_file)

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:57:51.632225
# Unit test for function md5
def test_md5():
    from ansible.utils.path import makedirs_safe
    from ansible.utils.unicode import to_bytes

    tmpdir = u'/tmp/ansible_md5_%s' % secure_hash_s(u'')
    makedirs_safe(tmpdir)
    assert not os.path.exists('/tmp/foobar')
    assert not md5('/tmp/foobar')

    with open(to_bytes(os.path.join(tmpdir, 'test_file')), 'wb') as f:
        f.write(to_bytes('test'))

    assert md5(os.path.join(tmpdir, 'test_file')) == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-11 17:57:55.147509
# Unit test for function md5
def test_md5():
    """Test the functionality of md5"""
    my_dict = {'a': 1, 'b': 2}
    assert md5s(my_dict) == md5(__file__)



# Generated at 2022-06-11 17:57:59.885055
# Unit test for function md5s
def test_md5s():
    ''' test md5s() for known values '''
    print("Testing known md5 value")
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8', "md5s('foo') = %s" % md5s('foo')

# Generated at 2022-06-11 17:58:05.352850
# Unit test for function checksum
def test_checksum():
    import tempfile

    test_file = tempfile.mkstemp()[1]
    test_data = "foobar"

    with open(test_file, "wb") as f:
        f.write(test_data)

    assert checksum(test_file) == checksum_s(test_data)


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:58:14.404393
# Unit test for function checksum
def test_checksum():
    assert secure_hash_s("abc") == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert secure_hash_s("abcdefghijklmnopqrstuvwxyz") == '32d10c7b8cf96570ca04ce37f2a19d84240d3a89'
    assert secure_hash_s("A random string") == 'ec1f9b9c065049ca84f3c95d1ce110e237adc492'
    assert secure_hash("/dev/null") == 'a7d028388e369986097e4e2107d35200'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:58:19.345435
# Unit test for function checksum
def test_checksum():
    filename = os.path.join(os.path.dirname(os.path.realpath(__file__)), "sechash.py")
    assert checksum(filename) == "c7e9b9a1ff51d0ddab25e1066cc60f761a57de1e"


# Generated at 2022-06-11 17:58:24.343751
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5('/etc/passwd') == '3c3fcd2aac550acd47566e454581c9e2'
    assert md5('/foo/bar/nonexistentfile') is None

# Generated at 2022-06-11 17:58:29.958668
# Unit test for function md5s
def test_md5s():
    if not _md5:
        print("MD5 not available.  Skipping tests")
        return
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') != 'd72a7a1e0f10d7a70cba3cab7f65b8a0'
    assert md5s('hello') == secure_hash_s('hello', _md5)



# Generated at 2022-06-11 17:58:32.556178
# Unit test for function md5
def test_md5():
    result = md5s("abc")
    assert result == "900150983cd24fb0d6963f7d28e17f72"


# Generated at 2022-06-11 17:58:36.792235
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    test_data = 'foobar'
    assert '3858f62230ac3c915f300c664312c63f' == md5s(test_data)



# Generated at 2022-06-11 17:58:41.772683
# Unit test for function md5s
def test_md5s():
    assert md5s(b'123') == '202cb962ac59075b964b07152d234b70'


# Generated at 2022-06-11 17:58:48.789055
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    fd, path = tempfile.mkstemp()
    with open(path, 'w') as f:
        f.write('hello')
    try:
        assert md5(path) == '5d41402abc4b2a76b9719d911017c592'
    finally:
        os.remove(path)


if __name__ == '__main__':
    import tempfile

    test_md5()

# Generated at 2022-06-11 17:58:51.584820
# Unit test for function md5s
def test_md5s():
    assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"


# Generated at 2022-06-11 17:58:55.469999
# Unit test for function md5
def test_md5():
    assert secure_hash('/etc/ansible/hosts') == \
            secure_hash('/etc/ansible/hosts', hash_func=_md5)
    assert secure_hash_s('hello world') == secure_hash_s('hello world', hash_func=_md5)



# Generated at 2022-06-11 17:58:58.944255
# Unit test for function md5
def test_md5():
    digest = md5('lib/ansible/module_utils/facts/system/__init__.py')
    assert digest == 'a3d3a3f0d8250265a4c4f6d7ff01b4a8'

# Generated at 2022-06-11 17:59:03.786000
# Unit test for function md5s
def test_md5s():
    assert md5s('1') == "c4ca4238a0b923820dcc509a6f75849b"
    assert md5s('2') == "c81e728d9d4c2f636f067f89cc14862c"
    try:
        md5s(None)
        assert 0, "should have raised a ValueError"
    except ValueError:
        pass

# Generated at 2022-06-11 17:59:14.523870
# Unit test for function md5
def test_md5():

    data = """Hello World!
    This is some test data.
    """
    # compute the md5 on unix
    fd = os.popen('echo "%s" | md5sum' % data)
    output = fd.read()
    unix_md5 = output.split()[0]

    # compute md5 on windows
    fd = os.popen('echo "%s" | certutil -hashfile NUL MD5' % data)
    output = fd.read()
    win_md5 = output.split()[-2]

    # compute md5 on python
    py_md5 = secure_hash_s(data, _md5)

    # compare all md5

# Generated at 2022-06-11 17:59:18.020218
# Unit test for function md5
def test_md5():
    return md5("ansible/module_utils/hashing.py") == "8e8bea61f1b6d213cbd74aa8697e0e6c"


# Generated at 2022-06-11 17:59:23.585483
# Unit test for function md5s
def test_md5s():
    # Test for file is a directory
    assert(md5s('/tmp') == None)
    # Test for file exists
    assert(md5s('/etc/hosts') == 'a7f038921bafcdf05454cc9f00a24bcc')



# Generated at 2022-06-11 17:59:33.753627
# Unit test for function md5s
def test_md5s():
    import cStringIO
    # Test for ansible-1.4.4 format of md5s
    test_string = 'b1:d4:a2:1e:e6:d9:7c:6a:b6:8b:56:3e:81:3b:a5:5f'
    if md5s('test') != test_string:
        raise Exception('md5s returned an unexpected result')
    # Test for the modern (1.5) format of md5s
    # Note, this should be the same as what checksum_s returns
    test_string = '098f6bcd4621d373cade4e832627b4f6'
    if md5s('test') != test_string:
        raise Exception('md5s returned an unexpected result')

# Generated at 2022-06-11 17:59:42.855348
# Unit test for function md5s
def test_md5s():
    import nose
    import shutil
    import tempfile
    temp_dir = tempfile.mkdtemp(prefix='ansible-test-')
    file1 = os.path.join(temp_dir, 'file1')
    file2 = os.path.join(temp_dir, 'file2')

# Generated at 2022-06-11 17:59:54.361313
# Unit test for function checksum
def test_checksum():

    import tempfile
    import shutil
    import filecmp

    (tmp_path,src_file) = tempfile.mkstemp()
    test_file = src_file + ".test"

    test_content_src = 'this is a test'
    test_content_dest = 'this is another test'

    # Create test file
    f = open(src_file, 'w')
    f.write(test_content_src)
    f.close()

    # Copy the file to the dest
    shutil.copy(src_file, test_file)

    # Modify the file
    f = open(test_file, 'w')
    f.write(test_content_dest)
    f.close()

    # sha1 checksum should be different
    src_sha1 = checksum(src_file)


# Generated at 2022-06-11 17:59:59.972989
# Unit test for function md5s
def test_md5s():
    # Ensure the system is FIPS-140 compliant, if not, md5s() should raise a ValueError
    os.environ['ANSIBLE_FIPS'] = 'True'
    try:
        md5s('test')
    except ValueError:
        assert(True)
    else:
        assert(False)


# Generated at 2022-06-11 18:00:01.630784
# Unit test for function md5s
def test_md5s():
    assert secure_hash_s(b'hello world') == md5s(b'hello world')
    assert secure_hash_s(b'hello world') != md5s(b'goodbye world')


# Generated at 2022-06-11 18:00:12.756657
# Unit test for function checksum
def test_checksum():
    import random

    if not os.path.exists('/tmp/test_checksum'):
        os.mkdir('/tmp/test_checksum')

    datalen = random.randint(1000, 2500000)  # test checksum against random length string
    with open('/tmp/test_checksum/random.txt', 'wb') as f:
        f.write(b'A' * datalen)

    with open('/tmp/test_checksum/random.txt', 'rb') as f:
        randomdata = f.read()

    randomdata_checksum = 'e5e6c3e621a83892eb4e0aee6a9b6148e8a4a206'

    data = b'foobar' * 1000

# Generated at 2022-06-11 18:00:15.880504
# Unit test for function md5s
def test_md5s():
    test_data = """
    ---
    - hosts: all
    """
    assert md5s(test_data) == secure_hash_s(test_data)

# Generated at 2022-06-11 18:00:21.006978
# Unit test for function checksum
def test_checksum():
    assert checksum(__file__) == '282378ad68d8c58bc42b6a268ec776c068faf9e8'
    assert checksum_s('abc123') == '40bd001563085fc35165329ea1ff5c5ecbdbbeef'

# Generated at 2022-06-11 18:00:32.013908
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s(u'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert checksum_s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    cwd = os.path.dirname(__file__)
    path = os.path.join(cwd, 'test_checksum.txt')
    assert checksum(path) == checksum_s('hello')

    # Test backwards compat with pre-FIPS mode
    if _md5:
        assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-11 18:00:35.473254
# Unit test for function md5s
def test_md5s():
    test_string = 'the quick brown fox jumped over the lazy dog'
    test_digest = '9e107d9d372bb6826bd81d3542a419d6'
    assert(test_digest == md5s(test_string))

# Generated at 2022-06-11 18:00:40.955997
# Unit test for function md5s
def test_md5s():
    str1 = "foobar"
    str2 = "foobar "
    str3 = ""

    assert md5s(str1) == '3858f62230ac3c915f300c664312c63f'
    assert md5s(str2) != md5s(str1)
    assert md5s(str2) == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert md5s(str3) == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-11 18:00:52.565660
# Unit test for function checksum
def test_checksum():
    from ansible.utils.path import makedirs_safe
    from tempfile import mkdtemp

    test_dir = mkdtemp(prefix='ansible-test-checkum')
    makedirs_safe(test_dir)
    test_file = os.path.join(test_dir, 'test_file')

    # create a file to test if the checksum returns the same value
    with open(test_file, 'w') as f:
        f.write('helloworld')

    # call checksum function and make sure the value is in the expected format
    assert len(checksum(test_file)) == 40


# Generated at 2022-06-11 18:00:59.275288
# Unit test for function checksum
def test_checksum():
    s = 'a'
    if checksum_s(s) != '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8':
        return False
    s += 'b'
    if checksum_s(s) != 'e2d0fe1585a63ec6009c8016ff8dda8b4defbe9e':
        return False
    s += 'c'
    if checksum_s(s) != '3c59dc048e8850243be8079a5c74d07352e234a5':
        return False
    return True

# Generated at 2022-06-11 18:01:06.448162
# Unit test for function md5
def test_md5():
    from tempfile import NamedTemporaryFile as ntf
    h1 = md5('/bin/ls')
    with ntf(mode='w+b') as fp:
        fp.write(b'hello world')
        fp.seek(0)
        h2 = md5(fp.name)
    assert h1 is not None
    assert h2 is not None
    assert h1 != h2

# Generated at 2022-06-11 18:01:15.803112
# Unit test for function md5
def test_md5():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # create test file
    tmp_filename = basic.tmp_filename()
    test_input = u"hello"
    basic.write_buf_to_file(tmp_filename, to_bytes(test_input))

    # test function
    test_output = md5(tmp_filename)

    # delete file
    basic.remove_tmp_file(tmp_filename)

    if test_output != "5d41402abc4b2a76b9719d911017c592":
        return False

    return True

# Generated at 2022-06-11 18:01:18.313227
# Unit test for function checksum
def test_checksum():
    assert checksum(__file__) == 'a1917e4b4f2b8af4d2fb87ffcb917ca08183bf0c'

# Generated at 2022-06-11 18:01:23.223992
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-11 18:01:31.582684
# Unit test for function md5s
def test_md5s():

    import ansible.utils.crypto as crypto

    original_string = u"To be, or not to be: that is the question."
    print("Original string: " + repr(original_string))

    # In 2.5, hash was moved to hashlib.  The hashlib module doesn't
    # exist in Python 2.4.  Import the md5 from md5 or hashlib based
    # on which one is available.
    try:
        import hashlib
    except ImportError:
        try:
            from md5 import md5
        except ImportError:
            print("error importing md5 from md5")
            raise

    from md5 import md5

    print("MD5 of string: " + repr(crypto.md5s(original_string)))

# Generated at 2022-06-11 18:01:41.134217
# Unit test for function checksum
def test_checksum():
    import tempfile

    # Test files
    (test_fd, test_file) = tempfile.mkstemp()
    (test_fd2, test_file2) = tempfile.mkstemp()
    with os.fdopen(test_fd, 'w') as f:
        f.write('Hello World')
    with os.fdopen(test_fd2, 'w') as f:
        f.write('Hello World!')

    # Test directory
    test_dir = tempfile.mkdtemp()

    # Test strings
    test_str = 'Hello World'
    test_str2 = 'Hello World!'

    # Test a string
    assert checksum_s(test_str) == '0a4d55a8d778e5022fab701977c5d840bbc486d0'

    # Test

# Generated at 2022-06-11 18:01:45.596815
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(b'123') == '202cb962ac59075b964b07152d234b70'
    assert md5s(u'123') == '202cb962ac59075b964b07152d234b70'
    assert md5s(u'123') == md5s('123')


# Generated at 2022-06-11 18:01:48.920047
# Unit test for function md5
def test_md5():
    test_data = 'test md5'
    test_data_md5 = 'e3fc5e5f82d5e977e7aefc0e430d2af2'

    assert md5s(test_data) == test_data_md5


# Generated at 2022-06-11 18:01:55.955103
# Unit test for function md5
def test_md5():
    print("in test_md5")
    test_s = "hello"
    print("testing string \"%s\"" % test_s)
    print(md5s(test_s))

    test_f = __file__
    print("testing file \"%s\"" % test_f)
    print(md5(test_f))


# Generated at 2022-06-11 18:02:06.651871
# Unit test for function md5
def test_md5():
    '''
    Test with different files
    '''
    import tempfile
    from os.path import join
    from textwrap import dedent

    def write_file(content, prefix=None):
        '''
        Write content to a temporary file
        '''
        tfile = tempfile.NamedTemporaryFile(prefix=prefix, delete=False)
        tfile.write(content)
        tfile.close()
        md5_sum = md5(tfile.name)
        os.unlink(tfile.name)
        return md5_sum

    assert 'd41d8cd98f00b204e9800998ecf8427e' == md5('')
    assert md5('foo') != md5('bar')

    # Test same content in different files

# Generated at 2022-06-11 18:02:12.403872
# Unit test for function md5
def test_md5():
    from ansible.compat import StringIO
    from ansible.module_utils.six import PY3
    if PY3:
        teststr = 'foobar'
    else:
        teststr = 'foobar'.encode('utf-8')
    testmd5 = '3858f62230ac3c915f300c664312c63f'
    assert md5(StringIO(teststr)) == testmd5

# Generated at 2022-06-11 18:02:22.770634
# Unit test for function md5
def test_md5():
    # pylint: disable=too-many-locals
    # pylint: disable=missing-docstring
    import os
    import tempfile

    text = """The quick brown fox jumps over the lazy dog"""
    h = md5s(text)
    h_real = '9e107d9d372bb6826bd81d3542a419d6'
    assert h == h_real

    fd, fname = tempfile.mkstemp()
    os.write(fd, to_bytes(text))
    os.close(fd)

    h = md5(fname)
    assert h == h_real

    os.unlink(fname)

# Generated at 2022-06-11 18:02:28.242958
# Unit test for function md5
def test_md5():
    v,t = md5('test_md5_source')
    assert v == '5afe4e85b73cdc827b4c39a4f473490a'
    assert t == False

    v,t = md5('/tmp/test_md5_dest')
    assert v == 'd41d8cd98f00b204e9800998ecf8427e'
    assert t == True

# Generated at 2022-06-11 18:02:33.980490
# Unit test for function md5s
def test_md5s():
    # MD5 for "foo"
    assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8", "Got the wrong MD5 for 'foo'!"


# Generated at 2022-06-11 18:02:36.827241
# Unit test for function md5s
def test_md5s():
    md5s_result = md5s('blah')
    assert md5s_result == '5eb63bbbe01eeed093cb22bb8f5acdc3'



# Generated at 2022-06-11 18:02:40.708318
# Unit test for function md5s
def test_md5s():
    assert(md5s("Hello World") == 'b10a8db164e0754105b7a99be72e3fe5')



# Generated at 2022-06-11 18:02:46.609472
# Unit test for function checksum
def test_checksum():

    # Create a tmp file for testing
    fd, fname = tempfile.mkstemp()
    os.write(fd, b'Hello world')
    os.close(fd)

    # Get the checksum value
    sha1_sum = checksum(fname)
    assert(sha1_sum == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed')

    # Remove tmp file
    os.remove(fname)


# Generated at 2022-06-11 18:02:53.248053
# Unit test for function md5
def test_md5():
    test_string = 'Hello World\n'
    test_checksum = '3e25960a79dbc69b674cd4ec67a72c62'
    checksum = md5s(test_string)
    print("md5 checksum: %s" % checksum)
    print("md5 original: %s" % test_checksum)
    assert checksum == test_checksum

# run test if this is called from the command-line
if __name__ == "__main__":
    test_md5()

# Generated at 2022-06-11 18:03:07.228845
# Unit test for function md5s
def test_md5s():
    '''
    simple unit test to ensure the md5s function is working properly.
    '''
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(b'test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s(b'test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-11 18:03:12.911715
# Unit test for function md5
def test_md5():
    filename = 'test_file'
    f = open(filename, 'w')
    f.write("hello world")
    f.close()
    md5_value = md5(filename)
    assert md5_value == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    os.remove(filename)

# Generated at 2022-06-11 18:03:16.286110
# Unit test for function md5s
def test_md5s():

    sum1 = md5s("Hello World")
    assert sum1 == 'b10a8db164e0754105b7a99be72e3fe5', "Bad MD5 Result"


# Generated at 2022-06-11 18:03:18.609686
# Unit test for function md5s
def test_md5s():
    result = md5s("test")
    assert result == "098f6bcd4621d373cade4e832627b4f6"

# Generated at 2022-06-11 18:03:23.628783
# Unit test for function md5
def test_md5():
    assert md5(__file__) == checksum(__file__)
    if _md5:
        assert md5(__file__) == md5(__file__)
    else:
        try:
            md5(__file__)
        except ValueError as e:
            assert str(e) == 'MD5 not available.  Possibly running in FIPS mode'
        except:
            assert False

# Generated at 2022-06-11 18:03:34.970863
# Unit test for function md5s
def test_md5s():

    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('message digest') == 'f96b697d7cb7938d525a2f31aaf161d0'
    assert md5s('abcdefghijklmnopqrstuvwxyz') == 'c3fcd3d76192e4007dfb496cca67e13b'

# Generated at 2022-06-11 18:03:41.542157
# Unit test for function md5
def test_md5():
    '''Unit test for function md5'''

    current_dir = os.path.dirname(os.path.realpath(__file__))
    testfile_path = os.path.join(current_dir, 'testdata')

    # Test for not-existent file
    assert os.path.isfile(testfile_path + '/not-existent-file') == False, \
        "testfile: %s exists. Run this test from source root" % testfile_path

    # Test for directory
    assert os.path.isdir(testfile_path), \
        "testfile: %s is not a directory. Run this test from source root" % testfile_path

    # Test for file

# Generated at 2022-06-11 18:03:51.376265
# Unit test for function md5
def test_md5():
    # Test input as string
    test_str = 'foo\n'
    test_str_md5 = 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert(md5s(test_str) == test_str_md5)

    # Test input as file object
    test_file = open('test_md5.txt', 'w')
    test_file.write(test_str)
    test_file.close()
    test_file = open('test_md5.txt', 'r')
    assert(md5(test_file) == test_str_md5)
    test_file.close()
    os.remove('test_md5.txt')


# Generated at 2022-06-11 18:03:55.836374
# Unit test for function md5
def test_md5():
    print('Test secure hash (should be b6a73f6c567a18c8f00f69b74a647325)')
    print(secure_hash(filename='test/test_md5.py'))

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:04:01.007303
# Unit test for function checksum
def test_checksum():
    out = checksum('test/files/test.cfg')
    assert out == '2a37aacd542be914f9c9406d8ceea1e5516dcb28', 'Expected 2a37aacd542be914f9c9406d8ceea1e5516dcb28, got %s' % out


# Generated at 2022-06-11 18:04:06.755527
# Unit test for function md5
def test_md5():
    ''' test the md5 function '''
    assert md5("/bin/ls") == "2e7d2c03a9507ae265ecf5b5356885a5"

# Generated at 2022-06-11 18:04:15.380691
# Unit test for function checksum
def test_checksum():
    from ansible.module_utils import basic

    assert checksum('test/utils/checksum.py') == '99c6b4df6d2894eafad70c9581c73b7711c65135'
    assert checksum_s(basic.json_dict_unicode_to_bytes({u'foo': u'bar'})) == '2d8ec248c00b74bb7ebc52fcfb8c9dbf9b6512e5'
    if _md5:
        assert md5('test/utils/checksum.py') == '12a9afadfdf5aa5ec5d5b5c5f53318a2'
        assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-11 18:04:17.915182
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"


# Generated at 2022-06-11 18:04:25.577239
# Unit test for function md5s
def test_md5s():
    """Returns True if the function md5s works as expected, otherwise False"""
    # expected value for data
    expected_value = '1bc29b36f623ba82aaf6724fd3b16718'
    # expected value for a file
    expected_file_value = 'c68f7e59e7701a0aac9b9afbde94c67c'
    if md5s('foo') != expected_value or md5(__file__) != expected_file_value:
        return False
    return True


# Generated at 2022-06-11 18:04:35.559431
# Unit test for function checksum
def test_checksum():
    ''' test the secure_hash function with a known string and known checksum '''
    assert secure_hash_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert secure_hash_s(b'') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert secure_hash_s('Hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert secure_hash_s(b'Hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'


# Generated at 2022-06-11 18:04:37.931338
# Unit test for function md5s
def test_md5s():
    r = md5s('hello')
    assert r == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-11 18:04:40.324300
# Unit test for function md5
def test_md5():
    ''' md5 unit test '''

    return md5(__file__) == 'b2749c43ed1dfde8e31f40c005bca88c'



# Generated at 2022-06-11 18:04:42.695512
# Unit test for function md5
def test_md5():
    """
    This function is testing md5 function
    """
    assert md5("/etc/passwd") != ""
    assert md5("/etc/shadow") != ""


# Generated at 2022-06-11 18:04:45.923410
# Unit test for function checksum
def test_checksum():
    assert secure_hash_s("foobar", hash_func=sha1) == "8843d7f92416211de9ebb963ff4ce28125932878"


# Generated at 2022-06-11 18:04:49.502296
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") is not None
    assert checksum("/bin/ls") == '6e84212926fada2d57c36f0289b65f02d9aafaf4'
    assert checksum_s("Test Data") == 'de63dcf0265ebe12097fbd2a9b9c9195e0f6183a'

# Generated at 2022-06-11 18:05:02.640713
# Unit test for function md5
def test_md5():
    assert md5("/bin/cat") == "6d5f6b066f1e8d721f5d6b20cacb20ee"
    assert md5("/bin/ls") == "e13084d48f9b5370a7c55b0aa20d03b0"
    assert md5("/bin/echo") == "0722e921b79e18f1bc5ce79c2adadcfd"
    assert md5("/bin/sh") == "9d091e28c1b2611c8a0b366f74a0a2b4"
    assert md5("/bin/bash") == "b032bd4d835a63baf11cb2e2e4cb26d3"

# Generated at 2022-06-11 18:05:10.585994
# Unit test for function md5s
def test_md5s():
    ''' test md5s function '''

    # expected md5 checksum is md5('ansible')
    assert md5s('ansible') == '098f6bcd4621d373cade4e832627b4f6', "md5s('ansible') should match expected checksum"
    assert md5s(u'ansible') == '098f6bcd4621d373cade4e832627b4f6', "md5s(u'ansible') should match expected checksum"
    assert md5s('ansible\n\r') == '81c8e0b6f90a26b5362d8ae113951995', "md5s('ansible\\n\\r') should match expected checksum"

# Generated at 2022-06-11 18:05:17.940588
# Unit test for function checksum
def test_checksum():
    assert secure_hash_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert secure_hash_s('hello', _md5) == '5d41402abc4b2a76b9719d911017c592'
    assert secure_hash_s('hello', sha1) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert secure_hash_s('hello', sha1) != secure_hash_s('hello', _md5)

# Generated at 2022-06-11 18:05:23.981475
# Unit test for function md5
def test_md5():
    result = md5s('ansible')
    assert result == '6f8db599de986fab7a21625b7916589c', \
        "Mismatch: '%s' should be '6f8db599de986fab7a21625b7916589c'" % result

    result = md5('test/support/files/chars')
    assert result == '85e71b5f5a5f5a5e5d5f5a5f5e5d5f5a', \
        "Mismatch: '%s' should be '85e71b5f5a5f5a5e5d5f5a5f5e5d5f5a'" % result

# Generated at 2022-06-11 18:05:31.305902
# Unit test for function checksum
def test_checksum():
    import tempfile
    import random
    for func in (checksum, checksum_s):
        assert func(random.random())
        fd, fname = tempfile.mkstemp()
        os.write(fd, b"Hello world\n")
        os.close(fd)
        assert func(fname)
        os.unlink(fname)

if __name__ == '__main__':
    test_checksum()