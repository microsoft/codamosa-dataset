

# Generated at 2022-06-11 17:55:37.533116
# Unit test for function md5
def test_md5():
    from ansible.compat.tests import unittest
    from ansible.compat.tests import mock
    from ansible.module_utils.six import PY2
    if PY2:
        from ansible.compat.tests import builtin_mock
        import __builtin__ as builtins
    else:
        from ansible.compat.tests import builtin_mock
        import builtins

    class TestMd5(unittest.TestCase):

        @mock.patch("ansible.module_utils.basic.AnsibleModule.fail_json")
        def test_md5_fails_fips(self, fail_json_mock):
            ''' If we are in FIPS mode, md5 function returns error '''

# Generated at 2022-06-11 17:55:45.704599
# Unit test for function checksum
def test_checksum():
    data = "foobar"
    assert secure_hash_s(data, hash_func=sha1) == "8843d7f92416211de9ebb963ff4ce28125932878"
    assert secure_hash_s(data, hash_func=sha1) == checksum_s(data)
    assert checksum_s(data) == checksum_s(data)
    assert checksum_s(data) == "8843d7f92416211de9ebb963ff4ce28125932878"



# Generated at 2022-06-11 17:55:57.108134
# Unit test for function checksum
def test_checksum():
    ''' checksum.py: Test checksum function '''

    assert checksum('test/files/chars.txt') == 'a0ca223677647d7a01f21108bd3997e2b1a8b7cf'
    assert checksum('test/files/burns.txt') == 'd26bbe9fa6e73f3a48a6dbd73e31d44f'
    assert checksum('test/files/asciiburns.txt') == '7a46d3087cd1e09efa1527b8d4f5c564'
    assert checksum('test/files/asciiburns2.txt') == '376c6b36a1e8629fcfe78d6f78413977'

# Generated at 2022-06-11 17:56:00.577704
# Unit test for function checksum
def test_checksum():
    assert checksum('lib/ansible/modules/commands/command.py') == 'f5e5e5d91c8b4ab4b67c4ef9d4373a3c3ac0a08a'

# Generated at 2022-06-11 17:56:08.364110
# Unit test for function md5
def test_md5():
    test_string = 'This is a test.'
    assert secure_hash_s(test_string, _md5) == 'ae92c7c9f1b40f68b5cfc4edcef2d4a4'
    test_file = open('test_file', 'w')
    test_file.write(test_string)
    test_file.close()
    assert secure_hash('test_file', _md5) == 'ae92c7c9f1b40f68b5cfc4edcef2d4a4'
    os.remove('test_file')



# Generated at 2022-06-11 17:56:15.523058
# Unit test for function md5
def test_md5():
    md5_random_text = md5s('random_text')
    assert(md5_random_text == 'c15be5375a717c40529c8f7e290dbdeb')

    md5_md5sum = md5('lib/ansible/module_utils/basic.py')
    assert(md5_md5sum == '78e9d8ff69cc0f60bf346ff7c8d2562c')

# Generated at 2022-06-11 17:56:19.191564
# Unit test for function checksum
def test_checksum():
    filename = '/usr/bin/ansible-doc'
    if not os.path.exists(filename):
        filename = '../bin/ansible-doc'
    if not os.path.exists(filename):
        filename = '../hacking/env-setup'
    return checksum(filename)

# Generated at 2022-06-11 17:56:21.737502
# Unit test for function md5s
def test_md5s():
    ret = md5s('hello world')
    assert ret == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-11 17:56:25.995765
# Unit test for function md5s
def test_md5s():
    assert md5s('data') == '4124bc0a9335c27f086f24ba207a4912'
    assert md5s('data\n') == 'b858cb282617fb0956d960215c8e84d1'

# Tests for backwards compat code

# Generated at 2022-06-11 17:56:28.198363
# Unit test for function md5s
def test_md5s():
    assert md5s('mkdir') == 'e66e0ff26a0d03f10cc16f122b49a3b0'

# Generated at 2022-06-11 17:56:36.773395
# Unit test for function md5
def test_md5():
    ''' test md5 algorithm '''

    filename = 'test.tmp'
    test_md5_sum = md5(filename)
    print(test_md5_sum)
    assert test_md5_sum == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-11 17:56:44.502429
# Unit test for function md5
def test_md5():
    input = u'hello'
    assert md5s(input) == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(input.encode('utf-8')) == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(input.encode('ascii')) == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(input.encode('latin-1')) == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(input.encode('utf-16')) == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-11 17:56:50.769435
# Unit test for function checksum
def test_checksum():
    """
    This funcion tests the checksum function.
    """

    file1 = 'test/file1.ini'
    file2 = 'test/file2.ini'
    checksum1 = '23960a41b9f9e561e6be629336275c16f65b285d'
    checksum2 = 'b68a05f3423c9e8d8f24139bdea2b2d3ebd22cf8'

    if checksum1 != checksum(file1, checksum_s):
        return False
    if checksum2 != checksum(file2, checksum_s):
        return False
    return True

# Generated at 2022-06-11 17:56:57.185000
# Unit test for function checksum
def test_checksum():
    import tempfile
    fname = tempfile.mkstemp()[1]
    txt = "this is a test"
    f = open(fname, "w")
    f.write(txt)
    f.close()
    checksum_val = checksum(fname)
    assert checksum_val is not None
    assert checksum_val == checksum_s(txt)


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:57:08.377211
# Unit test for function checksum
def test_checksum():
    test_str = 'foobar'
    test_file = '/etc/passwd'
    assert checksum_s(test_str) == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert checksum_s(test_str, sha1) == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert md5s(test_str) == '3858f62230ac3c915f300c664312c63f'
    assert checksum(test_file) == '6a94ff6f0471cfe2ac6a8dee5f3d1075a9c6a071'

# Generated at 2022-06-11 17:57:11.981399
# Unit test for function md5
def test_md5():
    ansible_md5 = md5s('ansible')
    assert ansible_md5 == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

# Generated at 2022-06-11 17:57:14.843157
# Unit test for function checksum
def test_checksum():
    filename = "/etc/passwd"
    result = checksum(filename)
    assert result != None

# Generated at 2022-06-11 17:57:22.878736
# Unit test for function md5s
def test_md5s():
    assert md5s("") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5s("a") == "0cc175b9c0f1b6a831c399e269772661"
    assert md5s("abc") == "900150983cd24fb0d6963f7d28e17f72"
    assert md5s("message digest") == "f96b697d7cb7938d525a2f31aaf161d0"
    assert md5s("abcdefghijklmnopqrstuvwxyz") == "c3fcd3d76192e4007dfb496cca67e13b"

# Generated at 2022-06-11 17:57:27.907818
# Unit test for function md5s
def test_md5s():
    """md5s should return the md5 checksum of the input."""
    assert md5s("foobar") == "3858f62230ac3c915f300c664312c63f"


if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-11 17:57:34.155450
# Unit test for function checksum
def test_checksum():
    # test data taken from SecureHash.pm
    data = "hello"
    expected = "5d41402abc4b2a76b9719d911017c592"
    assert checksum_s(data) == expected
    data = "The quick brown fox jumps over the lazy dog"
    expected = "9e107d9d372bb6826bd81d3542a419d6"
    assert checksum_s(data) == expected
    data = "The quick brown fox jumps over the lazy dog."
    expected = "e4d909c290d0fb1ca068ffaddf22cbd0"
    assert checksum_s(data) == expected
    data = ""
    expected = "da39a3ee5e6b4b0d3255bfef95601890afd80709"
    assert checksum_

# Generated at 2022-06-11 17:57:40.244613
# Unit test for function checksum
def test_checksum():
    h1 = checksum_s("foo")
    assert h1 is not None

    h2 = checksum_s("foo")
    assert h1 == h2

    h3 = checksum_s("bar")
    assert h2 != h3



# Generated at 2022-06-11 17:57:46.856460
# Unit test for function md5s
def test_md5s():
    """Unit test for md5s"""

    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s(b'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s(u'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-11 17:57:50.493533
# Unit test for function md5s
def test_md5s():
    x = 'test'
    y = '098f6bcd4621d373cade4e832627b4f6'
    z = md5s(x)
    assert y == z


# Generated at 2022-06-11 17:57:59.817817
# Unit test for function md5s
def test_md5s():
    # First, test for the case where MD5 hashing is not available.
    global _md5
    old_md5 = _md5
    _md5 = None
    try:
        md5s('blah')
    except ValueError as e:
        assert 'MD5 not available' in str(e), 'Expected MD5 not available error, got "%s"' % e
    _md5 = old_md5

    # Next, test for the case where MD5 hashing is available
    assert md5s('blah') == 'fa7c4b070e016fa746a0d36d517f9c8b'

# Generated at 2022-06-11 17:58:10.811031
# Unit test for function md5
def test_md5():
    """ unit test for md5 function """
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    data1 = "this is an important string"
    data2 = "this is an important string.  It is important to be able to tell these strings apart"

    assert md5s(data1) == md5s(data1), "md5s should return the same value for the same string"
    assert md5s(data2) == md5s(data2), "md5s should return the same value for the same string"

    assert md5s(data1) != md5s(data2), "md5s should return different values for different strings"

    assert md5s(data1) != md5s(data2.encode('utf-8')), "md5s should return different values for different strings"


# Generated at 2022-06-11 17:58:17.054092
# Unit test for function md5
def test_md5():

    if _md5:
        assert md5('/usr/bin/ansible-pull') == secure_hash('/usr/bin/ansible-pull', _md5)
        assert md5s('test') == secure_hash_s('test', _md5)
    else:
        try:
            md5('/usr/bin/ansible-pull')
            assert False, "Should not reach here"
        except ValueError as e:
            assert 'not available' in str(e)
        try:
            md5s('test')
            assert False, "Should not reach here"
        except ValueError as e:
            assert 'not available' in str(e)

# Generated at 2022-06-11 17:58:20.879931
# Unit test for function md5
def test_md5():
    text = u"foo"
    text_md5 = "acbd18db4cc2f85cedef654fccc4a4d8"
    assert md5s(text) == text_md5



# Generated at 2022-06-11 17:58:24.690695
# Unit test for function md5s
def test_md5s():
    print("testing md5s")
    assert md5s("testing") == "ae2b1fca515949e5d54fb22b8ed95575"
    print("ok")

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-11 17:58:32.402615
# Unit test for function md5
def test_md5():
    if not _md5:
        # Can't do md5, so silently skip this test
        return

    import tempfile
    import shutil
    # Create a temp dir
    test_dir = tempfile.mkdtemp()
    # Create two files with identical content
    (fd, file1) = tempfile.mkstemp(dir=test_dir)
    os.write(fd, b"hello")
    os.close(fd)
    (fd, file2) = tempfile.mkstemp(dir=test_dir)
    os.write(fd, b"hello")
    os.close(fd)

    # Check that the md5sums of those files are the same
    assert md5(file1) == md5(file2)
    # Clean up
    shutil.rmtree(test_dir)

# Generated at 2022-06-11 17:58:41.097262
# Unit test for function checksum
def test_checksum():

    def test_secure_hash():
        if secure_hash("COPYING") != "c3e6d87a6b8c9e3620cef61a14bfb63e1d66ae29":
            raise AnsibleError("secure hash algorithm failed on test file, it should have returned 'c3e6d87a6b8c9e3620cef61a14bfb63e1d66ae29'")
        if secure_hash("nosuchfileinhere") != None:
            raise AnsibleError("secure hash algorithm failed on test file, it should have returned None.")

    test_secure_hash()


# Generated at 2022-06-11 17:58:48.995457
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'


# Generated at 2022-06-11 17:58:54.162864
# Unit test for function checksum
def test_checksum():
    filename = os.path.join(os.path.dirname(__file__), 'systools.py')
    print(filename)
    print('SHA1: ' + checksum(filename))
    print('MD5: ' + md5(filename))


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:59:04.243784
# Unit test for function checksum
def test_checksum():
    # test sha1
    f1 = '/bin/sh'
    f2 = '/bin/nosuchbin'
    f3 = '/bin'
    s1 = 'I am a Test String'
    assert checksum(f1) == 'f1c27f4ffbde4b3e3d3d3c62b7e8cb3c5a3a3af7'
    assert checksum(f2) is None
    assert checksum(f3) is None
    assert checksum_s(s1) == '6fd12dbbfc5c6ebf7e19fba47eb03ad5581e0c1d'

    # test md5
    try:
        f1md5 = md5(f1)
    except ValueError:
        f1md5 = None

# Generated at 2022-06-11 17:59:10.620500
# Unit test for function md5s
def test_md5s():
    assert(md5s("hello") == "5d41402abc4b2a76b9719d911017c592")


if __name__ == '__main__':
    import sys
    import os
    # Run the unit tests
    test_md5s()

    # If any file names were passed in, calculate their checksums
    for arg in sys.argv[1:]:
        print(md5(arg), arg)

# Generated at 2022-06-11 17:59:15.289604
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    test_string = 'foo'
    expected_digest = 'acbd18db4cc2f85cedef654fccc4a4d8'
    actual_digest = md5s(to_bytes(test_string))
    assert expected_digest == actual_digest

# Generated at 2022-06-11 17:59:23.268387
# Unit test for function checksum
def test_checksum():
    test_file = '/tmp/ansible_test_checksum_file'
    test_dir = '/tmp/ansible_test_checksum_dir'
    test_string = 'ansible.cfg'
    test_string_hash = '3f4e4e9cef6d1bf6eee23c7ffa6a8b6e03b35ac0'
    test_string_hash_md5 = 'bb5e8943a1b16e8d34f0a7922fb2b7f9'

    # Check that checksum returns a string
    assert isinstance(checksum(test_dir), str)
    assert isinstance(checksum(test_file), str)
    assert isinstance(checksum_s(test_string), str)

    # Check that the hash of a non existing file is None

# Generated at 2022-06-11 17:59:28.257642
# Unit test for function checksum
def test_checksum():
    assert checksum("/boot/grub/grub.conf") == "a5f5c4eaff4f4ba0ff42db0f2eba5c3a"


if __name__ == '__main__':
    import doctest
    doctest.testmod()
    test_checksum()

# Generated at 2022-06-11 17:59:31.658146
# Unit test for function md5s
def test_md5s():
    assert(md5s('') == 'd41d8cd98f00b204e9800998ecf8427e')
    assert(md5s('hello') == '5d41402abc4b2a76b9719d911017c592')


# Generated at 2022-06-11 17:59:40.077814
# Unit test for function md5
def test_md5():
    import unittest
    import tempfile

    class TestMD5(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp(dir='/tmp')
            self.tmpfile = "%s/ansible_md5_test" % self.tmpdir
            self.tmpdata = "Ansible is Awesome!"

        def tearDown(self):
            os.unlink(self.tmpfile)
            os.rmdir(self.tmpdir)

        def test_succeed(self):
            for algorithm in [sha1, _md5]:
                f = open(self.tmpfile, 'w')
                f.write(self.tmpdata)
                f.close()

# Generated at 2022-06-11 17:59:51.962723
# Unit test for function checksum
def test_checksum():
    import tempfile
    from ansible.compat.tests import unittest

    class TestChecksum(unittest.TestCase):

        def setUp(self):
            self.tmp_sha1   = tempfile.TemporaryFile()
            self.tmp_sha1.write(b"foobar")
            self.tmp_sha1.seek(0)

            self.tmp_sha256 = tempfile.TemporaryFile()
            self.tmp_sha256.write(b"foobar")
            self.tmp_sha256.seek(0)

            self.tmp_md5    = tempfile.TemporaryFile()
            self.tmp_md5.write(b"foobar")
            self.tmp_md5.seek(0)

            self.tmp_no_such_file = tempfile.TemporaryFile()
           

# Generated at 2022-06-11 18:00:04.086687
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  Tests for Ansible hash functions '''
    import os
    import tempfile

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a test file
    testfile = os.path.join(tmpdir, 'testfile')
    with open(testfile, 'wb') as tfile:
        tfile.write(b'Hello World')

    # Create a test file2 (same as first file)
    testfile2 = os.path.join(tmpdir, 'testfile2')
    os.symlink(testfile, testfile2)

    # Create a test file3 (empty)
    testfile3 = os.path.join(tmpdir, 'testfile3')
    open(testfile3, 'a').close()

    # Create a test file

# Generated at 2022-06-11 18:00:08.174606
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-11 18:00:13.266124
# Unit test for function md5s
def test_md5s():
    import unittest
    class TestMd5s(unittest.TestCase):
        def test_md5s_with_wrong_value(self):
            md5s("hi")
            md5("hi")
    suite = unittest.TestLoader().loadTestsFromTestCase(TestMd5s)
    unittest.TextTestRunner(verbosity=2).run(suite)

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-11 18:00:17.120401
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "77bff0b143e6bed39aeb5cd600c43158"


if __name__ == '__main__':  # pragma: no cover
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 18:00:27.728921
# Unit test for function checksum
def test_checksum():
    # simple test to make sure it works at all
    test_string = b'this is some data'
    test_file = '/tmp/checksum_test_file'
    with open(test_file, 'w') as fh:
        fh.write(test_string)
    try:
        assert secure_hash_s(test_string) == 'edb35cdde2b84322e732699903b9bf47c1d0e8ee'
        assert secure_hash(test_file) == 'edb35cdde2b84322e732699903b9bf47c1d0e8ee'
    finally:
        os.remove(test_file)



# Generated at 2022-06-11 18:00:32.425148
# Unit test for function md5s
def test_md5s():
    '''Test md5s function'''
    assert md5s("hello") == '5d41402abc4b2a76b9719d911017c592'
    assert md5s("helloworld") == 'fc5e038d38a57032085441e7fe7010b0'

# Unit test function md5

# Generated at 2022-06-11 18:00:37.615195
# Unit test for function md5s
def test_md5s():
    if _md5:
        result = md5s('foo')
        assert result == 'acbd18db4cc2f85cedef654fccc4a4d8'
    else:
        try:
            result = md5s('foo')
        except ValueError as e:
            pass
        else:
            print('test md5s: md5 should not be available, error expected')


# Generated at 2022-06-11 18:00:40.988119
# Unit test for function md5s
def test_md5s():
    expected_result = '1bc29b36f623ba82aaf6724fd3b16718'
    result = md5s('foo')

    assert result == expected_result


# Generated at 2022-06-11 18:00:44.177210
# Unit test for function md5
def test_md5():
    '''Testing the mode 5 function, with a file'''
    assert md5('/bin/ls') == 'b8a880e892c2d28a04b46c8b9d9b76f3'

# Generated at 2022-06-11 18:00:49.903333
# Unit test for function md5s
def test_md5s():
    '''test_md5s'''
    test_string = b'The quick brown fox jumps over the lazy dog'
    test_salt = b'12345678'
    test_md5 = b'9e107d9d372bb6826bd81d3542a419d6'
    assert md5s(test_string) == test_md5

# Generated at 2022-06-11 18:00:57.904852
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5('/etc/passwd') == '929f9e1c71e8bf182af0e5f5d5bb5193'
    assert md5('/bin/bash') == '6b9d6b2259fcefa48f3dc68a65e2a8fa'


# Generated at 2022-06-11 18:01:09.681558
# Unit test for function md5s
def test_md5s():
    import unittest
    from ansible.compat.tests import ansible_module_framework

    class TestMd5s(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_md5s(self):
            from ansible.module_utils.basic import *

            results = dict(changed=False)

            md5sum = md5s('hello')

            self.assertEqual(md5sum, '5d41402abc4b2a76b9719d911017c592')

            results['mymd5'] = md5sum
            results['my_func'] = md5s
            results['my_file'] = __file__


# Generated at 2022-06-11 18:01:15.674697
# Unit test for function md5s
def test_md5s():
    # call md5s with a test string, if the test fails the test will error out
    assert md5s("test string") == '790ff8266bcb68f21f25fbf54f6a9a9e'
    # same test but with a unicode string
    assert md5s(u"test string") == '790ff8266bcb68f21f25fbf54f6a9a9e'
    # this should throw an exception

# Generated at 2022-06-11 18:01:20.505405
# Unit test for function checksum
def test_checksum():
    filenames = ["/etc/ansible/ansible.cfg", "/etc/ansible/hosts"]
    for filename in filenames:
        checksum = secure_hash(filename)
        if checksum is None:
            print("file %s not found" % filename)
        else:
            print("%s: %s" % (filename, checksum))



# Generated at 2022-06-11 18:01:29.014464
# Unit test for function checksum
def test_checksum():
    given = os.path.join(os.path.dirname(__file__), "filter_plugins/tests/inventory")
    expected = "2c4f4e31d71d26e4f3439c0c8f3f47b7a3b3a1df"

    if checksum(given) != expected:
        raise ValueError("checksum of %s is %s != %s" % (given, checksum(given), expected))


# Run module directly for testing
if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:01:40.124591
# Unit test for function checksum
def test_checksum():
    '''
    ansible.utils.checksum: Test checksum function
    '''
    # Create a test file
    import random
    import cStringIO
    import tempfile

    # Create a random file
    test_fobj = tempfile.TemporaryFile()
    data_to_write = random.randint(1, 1000)
    test_fobj.write(os.urandom(data_to_write))

    # Get checksum from the random file
    test_fobj.seek(0)
    checksum_file = secure_hash(test_fobj.name)
    test_fobj.close()

    # Create a random data
    test_data = os.urandom(random.randint(1, 1000))

    # Get the checksum from the random data
    checksum_data = secure_hash_s

# Generated at 2022-06-11 18:01:49.946522
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest

    class TestChecksum(unittest.TestCase):
        def setUp(self):
            self.filename = os.path.join(os.path.dirname(__file__), 'fixtures', 'checksum_test.txt')

        def test_checksum(self):
            ''' returns checksum of test file '''
            data = checksum(self.filename)
            self.assertEqual(
                data, '28e8f97d1afaa68f0bea3cab3d6ff31e6dda1b47')

        def test_sha256s(self):
            ''' returns checksum of test string '''
            string = 'This is the string to test'
            data = checksum_s(string)
            self.assertE

# Generated at 2022-06-11 18:01:54.286344
# Unit test for function md5s
def test_md5s():
    assert (md5s("foo") == 'acbd18db4cc2f85cedef654fccc4a4d8')
    assert (md5s("") == 'd41d8cd98f00b204e9800998ecf8427e')

# Generated at 2022-06-11 18:01:57.792342
# Unit test for function md5
def test_md5():
    filename = 'test_md5.tmp'
    with open(filename,"w") as f:
        f.write(os.urandom(100))
        f.close()
    hash1 = secure_hash(filename)
    os.remove(filename)
    assert hash1 == None

# Generated at 2022-06-11 18:02:08.967253
# Unit test for function checksum
def test_checksum():
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.cli import CLI
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    namespace = CLI.base_parser(None)
    (options, args) = namespace.parse_known_args()

    variable_manager = VariableManager()
    loader = DataLoader()
    inv = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inv)

    options.inventory = inv
    options.connection = 'local'
    options.remote_user = None
    options.remote_pass = None
    options.private_key_file = None
   

# Generated at 2022-06-11 18:02:15.725680
# Unit test for function checksum
def test_checksum():
    if checksum('/etc/passwd') != checksum('/etc/shadow'):
        print("passed test_checksum()")
    else:
        print("failed test_checksum()")

# Generated at 2022-06-11 18:02:19.649826
# Unit test for function md5
def test_md5():
    assert md5('test/test-data/test.png') == '69b80c685b4f7d62c6508f949450ca46'


# Generated at 2022-06-11 18:02:22.769167
# Unit test for function md5
def test_md5():
    data = 'This is the data to hash'
    try:
        secure_hash_s(data)
    except ValueError:
        raise AnsibleError('Failed secure_hash test with data %s' % data)

# Generated at 2022-06-11 18:02:25.171095
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == "acbd18db4cc2f85cedef654fccc4a4d8"



# Generated at 2022-06-11 18:02:33.981166
# Unit test for function checksum
def test_checksum():
    assert checksum_s() is None
    assert checksum_s("foo") == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    assert checksum("/bin/ls") == "2fbb4ff3b9c7671a4e31d76a3ecb85c3"
    assert checksum("/bin/foo") is None

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:02:37.778469
# Unit test for function md5s
def test_md5s():
    import ansible.module_utils.basic
    s = "abcdefghijklmnopqrstuvwxyz"
    md5 = "c3fcd3d76192e4007dfb496cca67e13b"
    assert md5 == md5s(s), "md5s failed"
    ansible.module_utils.basic._ANSIBLE_ARGS = None
    return True


# Generated at 2022-06-11 18:02:41.907788
# Unit test for function md5s
def test_md5s():
    h1 = secure_hash_s('abc', _md5)
    h2 = md5s('abc')
    assert h1 == h2


# Generated at 2022-06-11 18:02:46.549675
# Unit test for function checksum
def test_checksum():
    filename = 'test_checksum'
    test_file = open(filename, 'w')
    test_file.write('1234567890')
    test_file.close()
    test_hash = 'e59ff97941044f85df5297e1c302d260'
    new_hash = checksum(filename)
    os.remove(filename)
    assert test_hash == new_hash


# Generated at 2022-06-11 18:02:53.905831
# Unit test for function md5
def test_md5():
    '''
    Basic sanity test for the md5 function.

    This is not part of the unit test suite because we do not want to
    require the generation of a local file with a known checksum value,
    since that could potentially be a security vulnerability.
    '''
    import tempfile
    fname = tempfile.mktemp()
    f = open(fname, 'w')
    f.write('Hello World')
    f.close()
    checksum = md5(fname)
    os.remove(fname)
    assert checksum == 'ed076287532e86365e841e92bfc50d8c'

# Generated at 2022-06-11 18:02:57.989269
# Unit test for function checksum
def test_checksum():
    test_data = 'foobar'
    assert(checksum_s(test_data) == '8843d7f92416211de9ebb963ff4ce28125932878')


# Generated at 2022-06-11 18:03:06.432945
# Unit test for function md5
def test_md5():
    result = md5s('dummy')
    assert result == '1b2cf535f4aa765d61d8327deb882cf99'


# Generated at 2022-06-11 18:03:10.419007
# Unit test for function checksum
def test_checksum():
    checksum1 = checksum('/etc/passwd')
    checksum2 = checksum('/etc/passwd')
    assert checksum1 == checksum2
    checksum1 = checksum_s('hello world')
    checksum2 = checksum_s('hello world')
    assert checksum1 == checksum2
    checksum3 = checksum_s('hello w0rld')
    assert checksum1 != checksum3

# Generated at 2022-06-11 18:03:16.961204
# Unit test for function checksum
def test_checksum():
    import tempfile
    filename = tempfile.mktemp()
    f = open(filename, 'w')
    try:
        f.write('hello')
    finally:
        f.close()
    assert(checksum(filename) == '5d41402abc4b2a76b9719d911017c592')
    os.remove(filename)


# Generated at 2022-06-11 18:03:20.987236
# Unit test for function md5
def test_md5():
    """Unit test of function md5"""

    # Setup
    import tempfile
    (fh, tempname) = tempfile.mkstemp()

    # No error should be raised
    res = md5(tempname)

    # Teardown
    os.remove(tempname)
    os.close(fh)

# Generated at 2022-06-11 18:03:32.043526
# Unit test for function checksum

# Generated at 2022-06-11 18:03:40.177962
# Unit test for function checksum
def test_checksum():
    '''Checksum function Unit test'''
    # Create a temporary file
    (fd, fpath) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w+')
    # Write some data
    f.write('hello world')
    f.close()
    # Get checksum
    chsum = checksum(fpath)
    # Get md5 checksum
    md5_chsum = checksum(fpath, hashlib.md5)
    # Remove file
    os.remove(fpath)

    assert chsum == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert md5_chsum == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-11 18:03:43.274995
# Unit test for function md5
def test_md5():
   assert md5('/bin/ls') == '0d796592ecc3af3d874787a6735c8fa7'

if __name__ == "__main__":
    test_md5()

# Generated at 2022-06-11 18:03:45.148971
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-11 18:03:52.162976
# Unit test for function md5
def test_md5():
    s = "This is a test"
    test_md5 = "532eaabd9574880dbf76b9b8cc00832c"
    test_md5_s = "e2cbd5d290f5edb907fc8bb071037494"
    assert md5(s) == test_md5
    assert md5s(s) == test_md5_s
    assert md5(__file__) == "a54a514706980854787b4f25c3fd8b3c"

# Generated at 2022-06-11 18:03:57.551234
# Unit test for function md5
def test_md5():
    """
    This function is not included in the `automated_tests`
    because it is not possible to mock the `hashlib` module
    and the `md5` function in a unit test.
    """
    assert md5('/etc/passwd') == '46bea04ed98a27fba2b68f9d9f2e935a'

# Generated at 2022-06-11 18:04:12.556798
# Unit test for function md5s
def test_md5s():
    assert md5s('test1') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(None) == 'cfcd208495d565ef66e7dff9f98764da'
    assert md5s(123) == '202cb962ac59075b964b07152d234b70'
    assert md5s(['a', 'b', 3]) == 'afcc8e5d169c54b03bfac7ac6b34d972'

# Generated at 2022-06-11 18:04:18.536460
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('ABC') == '902fbdd2b1df0c4f70b4a5d23525e932'
    assert md5s('123') == '202cb962ac59075b964b07152d234b70'
    assert md5s('1234') == '81dc9bdb52d04dc20036dbd8313ed055'
    assert md5s('12345') == 'e99a18c428cb38d5f260853678922e03'

# Generated at 2022-06-11 18:04:23.881409
# Unit test for function checksum
def test_checksum():
    data = 'foo'
    res = checksum_s(data)
    expected_res = '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert res == expected_res, "Expected: %s, Got: %s" % (expected_res, res)

# Generated at 2022-06-11 18:04:25.329807
# Unit test for function md5s
def test_md5s():
    try:
        md5s("Hello World")
    except ValueError as e:
        print("test_md5s:", e)



# Generated at 2022-06-11 18:04:29.488989
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    else:
        assert md5("test/utils/test_md5") == '9e107d9d372bb6826bd81d3542a419d6'

# Generated at 2022-06-11 18:04:36.564100
# Unit test for function md5
def test_md5():
    test_file = 'test_md5.tmp'
    test_text = 'to be md5ed'

    with open(test_file,'w') as f:
        f.write(test_text)

    # 'ca3c44a5a6f85e8b2e35fe7c768f5cfe' is md5 of 'to be md5ed'
    assert md5(test_file) == 'ca3c44a5a6f85e8b2e35fe7c768f5cfe'

    os.remove(test_file)


# Generated at 2022-06-11 18:04:42.038872
# Unit test for function md5
def test_md5():
    if not _md5:
        return
    my_str = 'hi there'
    my_md5 = md5s(my_str)
    assert isinstance(my_md5, str)
    assert len(my_md5) == 32
    my_md5_2 = md5(os.path.join(os.path.dirname(__file__), 'hashlib_data/file1'))
    assert my_md5_2 == 'd42c8ed8409b2e6b0877c02b3588d9ad'



# Generated at 2022-06-11 18:04:43.685299
# Unit test for function checksum
def test_checksum():
    filename = '/etc/ansible/hosts'
    assert isinstance(secure_hash(filename), str)



# Generated at 2022-06-11 18:04:49.734520
# Unit test for function checksum
def test_checksum():
    assert secure_hash_s("hi") == "49f68a5c8493ec2c0bf489821c21fc3b"
    assert checksum_s("hi") == "49f68a5c8493ec2c0bf489821c21fc3b"
    test_file = os.path.join(os.path.dirname(__file__), 'test_hash.py')
    assert checksum(test_file) == "1c5aa5af5e7b5e67d2a0c98a2cd2b1b3"

# Generated at 2022-06-11 18:04:52.825560
# Unit test for function md5
def test_md5():
    filename = "/etc/passwd"
    assert md5(filename) == "72e979cd55d9ccce78490708cb1f42c0"


# Generated at 2022-06-11 18:05:03.403777
# Unit test for function md5
def test_md5():
    '''
    Test md5 function
    '''

    assert md5('/etc/passwd') == b'cdf7c9b80c0aba7d3559ea16a1b2f0b2'


# Generated at 2022-06-11 18:05:05.376227
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "5b03959c2aab642a5a2e2ae9afc037e2"

# Generated at 2022-06-11 18:05:08.573382
# Unit test for function md5s
def test_md5s():
    ''' md5s() unit test'''

    # Test for FIPS-140-2 compliance
    try:
        md5s('test')
    except ValueError:
        pass
    else:
        raise AssertionError('md5s() should not work in FIPS-140-2 mode')



# Generated at 2022-06-11 18:05:15.322985
# Unit test for function md5
def test_md5():
    from ansible.compat.tests.mock import patch, MagicMock

    test_file = 'test_data/test.txt'
    with patch.object(os.path, 'exists', MagicMock(return_value=True)):
        assert md5(test_file) == '5d41402abc4b2a76b9719d911017c592'
        assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:05:22.033519
# Unit test for function md5
def test_md5():
    testfile = 'testfile'
    if os.path.exists(testfile):
        data = open(testfile).read()
        expected = '2c1b6a0f9a47e0e3d42a17a6f5e5f5c6'
        result = md5(testfile)
        assert result == expected, 'expected %s but got %s' % (expected, result)
        result = md5s(data)
        assert result == expected, 'expected %s but got %s' % (expected, result)
    else:
        raise ValueError('MD5 test file not found')

# Generated at 2022-06-11 18:05:28.119947
# Unit test for function md5
def test_md5():

    # Test md5() method
    filename = '/etc/passwd'
    md5 = md5(filename)
    print ('md5 = %s' % md5)

    # Test md5s() method
    data = 'Hello'
    md5 = md5s(data)
    print ('md5s = %s' % md5)


if __name__ == '__main__':
    test_md5()