

# Generated at 2022-06-11 17:55:40.180477
# Unit test for function checksum
def test_checksum():
    import os
    import tempfile
    x = tempfile.NamedTemporaryFile()
    x.write("this is a test")
    x.flush()
    working_value = checksum(x.name)
    broken_value = checksum("/not/a/real/file")
    os.unlink(x.name)
    assert working_value == '5408f495e6bbb4444b76d67d1e7b9a6b9f958a4e'
    assert broken_value is None


# Generated at 2022-06-11 17:55:42.723370
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-11 17:55:48.362694
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    tempdir = tempfile.mkdtemp()
    file_for_checksum = tempfile.NamedTemporaryFile(dir=tempdir)
    filename = file_for_checksum.name
    print("Filename is %s" % filename)
    file_for_checksum.write(b'hello')
    file_for_checksum.close()
    chksum = checksum(filename)
    print("Checksum is %s" % chksum)
    shutil.rmtree(tempdir)

# Generated at 2022-06-11 17:55:54.149963
# Unit test for function md5
def test_md5():

    try:
        md5()
    except ValueError as e:
        print(e)

    data = "abc"
    print(md5s(data))
    assert (md5s(data) == '900150983cd24fb0d6963f7d28e17f72')

if __name__ == "__main__":
    test_md5()

# Generated at 2022-06-11 17:56:05.154137
# Unit test for function checksum
def test_checksum():
    import random
    import tempfile
    import shutil
    import os

    temp_path = tempfile.mkdtemp(prefix='ansible-test')
    s = to_bytes("".join([random.choice("abcdefghijklmnopqrstuvwxyz") for x in range(0, 64)]), errors='surrogate_or_strict')
    fd, path = tempfile.mkstemp(dir=temp_path, prefix='ansible-test')
    f = os.fdopen(fd, 'wb')
    f.write(s)
    f.close()

    test_path = os.path.join(temp_path, 'test')
    os.symlink(path, test_path)

    # test checksum_s

# Generated at 2022-06-11 17:56:07.676313
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'b97f0d22561d04de1e9e51a9d17f95a1'


# Generated at 2022-06-11 17:56:15.576909
# Unit test for function md5
def test_md5():
    filename = './hacking/env-setup'
    expected_md5 = '34d1f91fb2e514b8576fab1a75a89a6b'
    actual_md5 = md5(filename)
    assert expected_md5 == actual_md5, "md5(%s) returned %s but expected %s" % (filename, actual_md5, expected_md5)

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 17:56:21.289881
# Unit test for function checksum
def test_checksum():
    '''
    ansible core: checksum test
    '''
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(default="", type='path'),
            data=dict(default="")
        )
    )
    path = module.params['path'] or "-"
    if path == "-":
        module.exit_json(msg=checksum_s(module.params['data']))
    else:
        module.exit_json(msg=checksum(path))

# import module snippets
from ansible.module_utils.basic import *



# Generated at 2022-06-11 17:56:24.452179
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "6b8e3e766ec92c8326c7f303a8ba911c7a1a2b26"


# Generated at 2022-06-11 17:56:26.971183
# Unit test for function md5
def test_md5():

    try:
        md5('/etc/passwd')
    except ValueError as e:
        print('Exception caught as expected: %s' % e)



# Generated at 2022-06-11 17:56:41.232545
# Unit test for function md5
def test_md5():
    '''md5 should return the same checksum for corresponding strings and files'''
    from tempfile import NamedTemporaryFile

    def _test(msg):
        m = md5(msg)
        assert m == md5s(msg), 'md5 and md5s return same checksum for: %s' % msg
        with NamedTemporaryFile() as tmpfile:
            tmpfile.write(to_bytes(msg))
            tmpfile.flush()
            assert m == md5(tmpfile.name), "checksum remains the same for file %s" % tmpfile.name

    _test(__file__) # self
    _test('/')
    _test('//')
    _test('///')
    _test('////')
    _test('/etc/hosts')
    _test('/etc/hosts//')
   

# Generated at 2022-06-11 17:56:45.357236
# Unit test for function md5
def test_md5():
    assert md5s('Hello, World!') == '6cd3556deb0da54bca060b4c39479839'
    assert md5('/bin/ls') == 'b8f34ca77db75975a5b5a5f5d5c13f49'


# Generated at 2022-06-11 17:56:52.122407
# Unit test for function md5
def test_md5():
    from ansible.module_utils import basic

    import tempfile
    (handle, filename) = tempfile.mkstemp(prefix='ansible-test-')
    os.write(handle, b"data")
    os.close(handle)

    checksum = md5(filename)
    assert checksum == "7815696ecbf1c96e6894b779456d330e"

    os.unlink(filename)

# Backwards compat functions
md5sum = md5
md5sum_s = md5s

# Generated at 2022-06-11 17:56:53.722263
# Unit test for function md5
def test_md5():
    _test_md5_function(md5)



# Generated at 2022-06-11 17:56:55.022886
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-11 17:56:57.870617
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-11 17:57:05.968380
# Unit test for function md5s
def test_md5s():
    '''
    validate the output of the md5s function (below)
    against the output of the equivalent openssl command:
        $ echo -n "HELLO" | openssl md5
        (stdin)= f7ff9e8b7bb2e09b70935a5d785e0cc5
    '''

    expected = "f7ff9e8b7bb2e09b70935a5d785e0cc5"

    assert md5s("HELLO") == expected

# Generated at 2022-06-11 17:57:16.464435
# Unit test for function md5
def test_md5():
    '''
    Function to test md5 function
    '''
    from ansible.module_utils import basic
    print("Testing md5 function")
    try:
        print("MD5 for %s is: %s" % (__file__, md5(__file__)))
        print("MD5 for %s is: %s" % ('/nosuchfile', md5('/nosuchfile')))
        print("MD5 for %s is: %s" % ('/etc', md5('/etc')))
    except ValueError as e:
        basic.fail_json(msg="md5 function failed: %s" % e.message)
    print("md5 function passed")


# Generated at 2022-06-11 17:57:23.574249
# Unit test for function md5s
def test_md5s():
    ''' Return a md5 hash of data. '''

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    md5_test_file = '/tmp/md5_test_file'
    md5_test_data = 'test\n'
    result = dict(msg='', failed=False, changed=False)

    # Test 1: Test that there is no error when module is called with a valid result and not passing in data
    md5_result = md5s(md5_test_data)
    module = AnsibleModule(argument_spec=dict(data=dict()))
    result['msg'] = 'md5s function accepts arguments but data not passed in. md5 returned: ' + str(md5_result)
    module.exit_json(**result)

# Generated at 2022-06-11 17:57:32.349466
# Unit test for function md5
def test_md5():
    # check md5 hash of a string
    tmd5 = '1efd8d21cfe28a9f1c74699b8ac9b519'
    tdata = 'foo'
    hmd5 = md5s(tdata)
    assert hmd5 == tmd5, \
        "md5 hash of %s should be %s but got %s" % (tdata, tmd5, hmd5)

    # check md5 hash of file
    tmd5 = 'b2f5ff47436671b6e533d8dc3614845d'
    tfile = 'test/ansiblesample/sample.cfg'
    hmd5 = md5(tfile)

# Generated at 2022-06-11 17:57:37.932822
# Unit test for function md5
def test_md5():
    string = "This is a test"
    assert md5s(string) == "d751713988987e9331980363e24189ce"

# Generated at 2022-06-11 17:57:43.781355
# Unit test for function md5
def test_md5():
    ''' this function is called by a test, but only functions starting with "test" are called '''
    import tempfile
    test_file = tempfile.mkstemp(prefix='ansible-test_file')[1]
    test_string = 'im a string'
    with open(test_file,'w') as f:
        f.write(test_string)
    assert md5(test_file) == 'c23b94cc2f096fd1fd6bae481e54cc47'


# Generated at 2022-06-11 17:57:46.079211
# Unit test for function md5
def test_md5():
    filename = "/etc/passwd"
    value = md5(filename)
    print(value)



# Generated at 2022-06-11 17:57:50.457348
# Unit test for function md5s
def test_md5s():
    str = 'Hello World'
    hashed_str = md5s(str)
    assert hashed_str == 'b10a8db164e0754105b7a99be72e3fe5'

# Unit Test for function md5

# Generated at 2022-06-11 17:57:58.676782
# Unit test for function md5
def test_md5():
    import os
    import tempfile
    (fd, name) = tempfile.mkstemp()
    try:
        os.write(fd, "<html></html>")
        os.close(fd)
        assert md5(name) == 'd6ea869f59cd060be32d0437d0a6c8a1'
    finally:
        os.remove(name)

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 17:58:05.401897
# Unit test for function checksum
def test_checksum():
    """ Returns True if the unit test passes """
    # The contents of this file should not be modified
    test_key = "test/ansible/utils/test_module_utils_basic.py"
    test_value = "f88c8300c640d6f05743425fa2793e4e4c3b9ce0"
    if checksum(test_key) == test_value:
        return True
    else:
        return False



# Generated at 2022-06-11 17:58:15.015949
# Unit test for function md5s
def test_md5s():
    #
    # Example:
    # https://tools.ietf.org/html/rfc1321#page-32
    #

    # Step 1: Initialize variables A,B,C,D
    a = 0x67452301
    b = 0xefcdab89
    c = 0x98badcfe
    d = 0x10325476

    x = 0x00000010
    data = 'abc'
    #print("data:", data)

    # Step 2: Initialize constants

# Generated at 2022-06-11 17:58:19.296436
# Unit test for function md5s
def test_md5s():
    s = 'hello'
    h = md5s(s)

    assert h == '5d41402abc4b2a76b9719d911017c592'

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 17:58:19.876373
# Unit test for function md5s
def test_md5s():
    pass

# Generated at 2022-06-11 17:58:28.077840
# Unit test for function checksum
def test_checksum():
    import tempfile
    import os

    test_string = "test"
    test_string_file = os.path.join(tempfile.gettempdir(), 'test_file')
    test_string_file_handle = open(test_string_file, 'w')
    test_string_file_handle.write(test_string)
    test_string_file_handle.close()

    # Test
    if checksum(test_string_file) != checksum_s(test_string):
        raise Exception("Failed to verify checksum of file")


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:58:34.591376
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-11 17:58:41.208096
# Unit test for function md5s
def test_md5s():
    # MD5s should be equal
    if md5s('test') != '098f6bcd4621d373cade4e832627b4f6':
        raise Exception("Invalid md5s")
    # Using empty string, MD5s should be equal
    if md5s('') != 'd41d8cd98f00b204e9800998ecf8427e':
        raise Exception("Invalid md5s")
    # Using whitespace, MD5s should be equal
    if md5s(' ') != '7215ee9c7d9dc229d2921a40e899ec5f':
        raise Exception("Invalid md5s")

# Generated at 2022-06-11 17:58:51.440462
# Unit test for function md5
def test_md5():

    try:
        from tempfile import mkstemp
    except ImportError:
        from tempfile import mktemp

        def mkstemp():
            fd, name = mktemp()
            return fd, name

    with open(__file__, 'r') as f:
        data = f.read()

    d1 = md5(__file__)
    d2 = md5s(data)

    assert(d1 == d2)

    fd, name = mkstemp()
    with open(name, 'w') as f:
        f.write(data)

    d3 = md5(name)

    assert(d2 == d3)
    os.unlink(name)

# Generated at 2022-06-11 17:58:58.491729
# Unit test for function checksum
def test_checksum():
    if checksum("test/utils/test_checksum", sha1) == "d9b935f49c7b46a22cc6f8d6b1dc7aadc6262f88":
        print("checksum success")
    else:
        print("checksum failed")
    if checksum_s("test string", sha1) == "022d7b53c06b1cfc18d8d0e704b48cdb2be2a9c1":
        print("checksum_s success")
    else:
        print("checksum_s failed")

if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-11 17:59:03.947865
# Unit test for function checksum
def test_checksum():
    fd, test_path = tempfile.mkstemp()
    def cleanup():
        os.close(fd)
        os.remove(test_path)
    request.addfinalizer(cleanup)

    with os.fdopen(fd, 'wb') as fp:
        fp.write(b'Hello world')

    assert checksum(test_path) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-11 17:59:14.630343
# Unit test for function md5s
def test_md5s():
    def md5s_test(data, expected):
        result = md5s(data)
        if result != expected:
            raise Exception("md5s(%s) returned %s and not %s" % (data, result, expected))

    md5s_test('', 'd41d8cd98f00b204e9800998ecf8427e')
    md5s_test('\x80', '2b282ccd309575f754a94befdb8c73d1')
    md5s_test('\x00\x80', '0e7c6a98bc6f8c6d0a39466cdc9e0299')

# Generated at 2022-06-11 17:59:17.359608
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-11 17:59:20.011511
# Unit test for function md5s
def test_md5s():
    """Test md5s function with strings"""
    if _md5:
        assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-11 17:59:25.020332
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '5f5db9e57c95b797a315926797f3d3c1'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-11 17:59:29.045349
# Unit test for function md5s
def test_md5s():
    # This test will fail when running with FIPS-140 mode enabled
    if _md5:
        assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-11 17:59:36.361558
# Unit test for function checksum
def test_checksum():
    checksum_input = 'foo'
    checksum_output = '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_output == checksum_s(checksum_input)

    checksum_input = 'foo.txt'
    checksum_output = '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_output == checksum_s(checksum_input)

# Generated at 2022-06-11 17:59:39.253700
# Unit test for function md5s
def test_md5s():
    if _md5:
        md5s_result = md5s('ChecksumTest')
        assert md5s_result == 'd8e8fca2dc0f896fd7cb4cb0031ba249'



# Generated at 2022-06-11 17:59:41.129177
# Unit test for function md5s
def test_md5s():
    assert md5s('foobar') == '3858f62230ac3c915f300c664312c63f'

# Generated at 2022-06-11 17:59:48.649425
# Unit test for function md5s
def test_md5s():
    import random
    import string

    random_string = ''.join(random.choice(string.ascii_lowercase + string.ascii_uppercase + string.digits) for x in range(random.randint(10, 30)))
    assert secure_hash_s(random_string, _md5) == secure_hash_s(random_string, _md5), "Failed to produce identical hash for the same input"

# Generated at 2022-06-11 17:59:52.847291
# Unit test for function md5s
def test_md5s():
    test_md5s = md5s('abc')
    if test_md5s != '900150983cd24fb0d6963f7d28e17f72':
        print("test_md5s: FAIL")
    else:
        print("test_md5s: PASS")

# Generated at 2022-06-11 17:59:56.112327
# Unit test for function md5s
def test_md5s():
    assert md5s("12345") == '827ccb0eea8a706c4c34a16891f84e7b'


# Generated at 2022-06-11 18:00:02.200610
# Unit test for function md5
def test_md5():

    # create temporary file
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, "w")
    f.write("Hello")
    f.close()

    # test
    m = md5(fname)
    assert m == "8b1a9953c4611296a827abf8c47804d7"

    # remove temporary file
    os.remove(fname)


# Generated at 2022-06-11 18:00:12.980290
# Unit test for function checksum
def test_checksum():
    file1 = "/etc/passwd"
    file2 = "/etc/shadow"
    str1 = "Hello World"
    str2 = "GoodBye"

    assert checksum(file1) == secure_hash(file1)
    assert checksum(file2) == secure_hash(file2)
    assert md5s(str1) == secure_hash_s(str1, _md5)
    assert md5(file2) == secure_hash(file2, _md5)

    # tests for string input
    assert secure_hash_s(str1) == checksum_s(str1)
    assert secure_hash_s(str1, _md5) == md5s(str1)
    assert secure_hash_s(str2, _md5) != md5s(str1)

    # tests for

# Generated at 2022-06-11 18:00:19.383715
# Unit test for function checksum
def test_checksum():
    filename = 'ansible/test/units/modules/utils/test_module_utils_basic.py'
    assert checksum(filename) == '46f635c6dbc1d8f5417f4438f22dc0c9ce8920be'
    assert checksum_s('this is a test') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s(filename) == '9ad9c13fba2b5ee5d5c2e19fdf6a2a6d851b5f02'

# Generated at 2022-06-11 18:00:30.357008
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return True
    assert(md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8')
    assert(md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2')
    assert(md5s('baz') == '983c928a998c2edb63e8800f0d221798')
    assert(md5s('foobar') == '3858f62230ac3c915f300c664312c63f')
    assert(md5s('barbaz') == '089e25ea87a02c14f3e40e8170caa855')

# Generated at 2022-06-11 18:00:40.117031
# Unit test for function md5
def test_md5():
    from ansible.compat.tests import unittest
    import tempfile

    test_string = "hello world"
    test_file = tempfile.NamedTemporaryFile()
    test_file.write(test_string)
    test_file.seek(0)
    test_file_name = test_file.name

    class TestMd5(unittest.TestCase):
        def setUp(self):
            self.test_md5s = md5s(test_string)
            self.test_md5 = md5(test_file_name)

        def tearDown(self):
            test_file.close()


# Generated at 2022-06-11 18:00:43.747707
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"


if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-11 18:00:47.149924
# Unit test for function md5s
def test_md5s():
    hashed = md5s('hola')
    assert(hashed == 'e24b12f077d37c8eec7a1a9a9d7bd537')

# Generated at 2022-06-11 18:00:50.197396
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == checksum("/bin/ls")
    assert checksum("/bin/ls") != checksum("/bin/sh")

# Generated at 2022-06-11 18:00:59.186562
# Unit test for function md5
def test_md5():
    """
    This function tests the md5 function by passing in a set of arguments and comparing the result against expected values.
    """
    try:
        import hashlib
        from ansible.module_utils.six.moves import cStringIO
    except ImportError:
        import md5
        from ansible.module_utils.six.moves import StringIO as cStringIO

    if not hasattr(hashlib, 'md5') and not hasattr(md5, 'md5'):
        raise Exception('MD5 not available.  Possibly running in FIPS mode')

    args = ['world', 'hello', 'blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah']

# Generated at 2022-06-11 18:01:08.220188
# Unit test for function md5
def test_md5():
    '''
    md5 should return the md5 hash for a given file
    '''
    test_file = '/tmp/md5_test'
    # Write a file that contains ffffff
    with open(test_file, 'wb') as f:
        f.write(b'\x66' * 1000000)
    # Calculate the md5 hash of the file and compare the result
    assert md5(test_file) == '8f3b917500fdc92393d77e845cae62b4'
    os.remove(test_file)

# Generated at 2022-06-11 18:01:19.245302
# Unit test for function checksum
def test_checksum():
    test_str = 'test'
    test_str_sha1 = 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s(test_str) == test_str_sha1
    assert checksum_s(test_str) == checksum_s(test_str)
    test_str2 = 'test2'
    assert checksum_s(test_str) == checksum_s(test_str)
    assert checksum_s(test_str) != checksum_s(test_str2)

    # Test backwards compat
    if _md5:
        test_str_md5 = '098f6bcd4621d373cade4e832627b4f6'
        assert md5s(test_str) == test

# Generated at 2022-06-11 18:01:30.284145
# Unit test for function checksum
def test_checksum():
    import tempfile

    # TODO: use new python tempfile module when it has a delete option
    fd, temp_path = tempfile.mkstemp()

# Generated at 2022-06-11 18:01:37.859356
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'a9c182a42d13118753b86edcbd50a0c0bc20bc8e'
    assert checksum('/bin/foo') is None
    assert checksum('/dev/null') == 'cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce'

# Generated at 2022-06-11 18:01:48.723825
# Unit test for function checksum
def test_checksum():
    # should return the same digest
    assert checksum('tests/test_utils/test_checksum.py') == \
           checksum('./test_checksum.py')
    # md5 is not available if running in FIPS mode
    if _md5:
        # should return the same digest
        assert md5('tests/test_utils/test_checksum.py') == \
               md5('./test_checksum.py')
        # tests/test_utils/test_checksum.py and ./test_checksum.py are different files
        # should return different digest
        assert md5('tests/test_utils/test_checksum.py') != \
               checksum('./test_checksum.py')
    # should return the same digest
    assert checksum_s("helloworld") == checksum_s

# Generated at 2022-06-11 18:01:58.933805
# Unit test for function checksum
def test_checksum():
    fail_count = 0
    checksum1 = checksum('lib/ansible/module_utils/basic.py')
    checksum2 = checksum('lib/ansible/module_utils/urls.py')
    checksum3 = checksum('lib/ansible/module_utils/six/__init__.py')
    checksum4 = checksum('lib/ansible/module_utils/six.py')
    checksum5 = checksum('lib/ansible/module_utils/six/moves/__init__.py')
    checksum6 = checksum('lib/ansible/module_utils/six/moves/urllib/request.py')


# Generated at 2022-06-11 18:02:02.314061
# Unit test for function md5
def test_md5():
    # Test that md5 is working
    print(md5('/etc/passwd'))


# for backwards compat with the old style
if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:02:11.997266
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '87d8a8a592f28fbe0e6d2b08c8b98347a536a06d'
    assert checksum('/bin/cat') == '756a1a8869d6eb8c3c2ce6d59b6f3b0e27cce9fd'
    assert checksum_s('/bin/ls') == '87d8a8a592f28fbe0e6d2b08c8b98347a536a06d'
    assert checksum_s('/bin/cat') == '756a1a8869d6eb8c3c2ce6d59b6f3b0e27cce9fd'

# Generated at 2022-06-11 18:02:15.655464
# Unit test for function md5s
def test_md5s():
    """Test md5s function"""
    assert md5s("faker") == 'e4a9424b2b081e6e8a4f91b6c68a3d28'


# Generated at 2022-06-11 18:02:20.004464
# Unit test for function md5s
def test_md5s():
    md5s_test = md5s(b'foobar')
    assert md5s_test == '3858f62230ac3c915f300c664312c63f'


# Generated at 2022-06-11 18:02:24.329339
# Unit test for function checksum
def test_checksum():
    assert checksum(__file__) == "dc6abcd30afc09de6d0c6a9b9a838e8361a6e0d6"
    assert checksum("/does/not/exist") == None
    assert checksum("/") == None
    assert checksum("/etc/shadow") == None

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:02:32.570008
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "a7758a6c78dcd3494b1f9bfb1fc9c927"
    assert checksum("/usr/bin/mono") == "d7df4e22e9b7a9b9a076e1c6d7566e5a"
    assert checksum("/tmp/nonexistant") is None
    assert checksum("/dev/zero") == "5feceb66ffc86f38d952786c6d696c79"


# Generated at 2022-06-11 18:02:35.305046
# Unit test for function md5s
def test_md5s():
    assert md5s('foobar') == '3858f62230ac3c915f300c664312c63f'

# Generated at 2022-06-11 18:02:40.023718
# Unit test for function md5
def test_md5():
    filename = "./file_hashes.py"
    md5sum = md5(filename)
    assert md5sum == 'f5c6a606a7c958f47204ff50672b466c'

# Generated at 2022-06-11 18:02:46.450228
# Unit test for function md5s
def test_md5s():
    assert md5s("a") == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s("b") == '92eb5ffee6ae2fec3ad71c777531578f'
    assert md5s("c") == '4124bc0a9335c27f086f24ba207a4912'
    assert md5s("d") == '900150983cd24fb0d6963f7d28e17f72'


# Generated at 2022-06-11 18:03:30.205815
# Unit test for function md5s
def test_md5s():
    md5S = md5s('foo')
    assert md5S == 'acbd18db4cc2f85cedef654fccc4a4d8', 'md5s is broken!'


# Generated at 2022-06-11 18:03:36.094835
# Unit test for function md5s
def test_md5s():
    # these two should be equal
    assert md5s(b"testing\n") == md5s(b"testing\n")
    # these two should be different
    assert md5s(b"testin\n") != md5s(b"testin2\n")
    assert len(md5s(b"testing")) == len(md5s(b"testin")) == 32



# Generated at 2022-06-11 18:03:41.061401
# Unit test for function md5
def test_md5():
    filename = 'test_md5.txt'
    with open(filename, 'w') as f:
        f.write('abcdef')
    assert(md5(filename) == '7ac66c0f148de9519b8bd264312c4d64')
    os.remove(filename)


# Test for Python 2.4-2.6 compatibility
if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:03:48.167413
# Unit test for function md5
def test_md5():
    ''' simple unit test for md5 '''
    print('Testing md5')
    print('  md5(a.out) = ' + md5('a.out'))
    print('  md5s(a.out) = ' + md5s('a.out'))
    print('  md5(b.out) = ' + md5('b.out'))
    print('  md5s(b.out) = ' + md5s('b.out'))

# test_md5()

# Generated at 2022-06-11 18:03:55.429296
# Unit test for function checksum
def test_checksum():
    # FIXME: This is just a few basic tests; we need more thorough testing
    assert checksum_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum_s('abc', sha1) == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum_s('abc', _md5) == '900150983cd24fb0d6963f7d28e17f72'
    assert checksum('test/support/files/chars', _md5) == '09ddc9db3f31297bdea28d7c0c0b86a7'

# Generated at 2022-06-11 18:04:01.505209
# Unit test for function md5
def test_md5():
    import tempfile
    fd, fn = tempfile.mkstemp()
    os.close(fd)
    assert md5(fn) is None or md5(fn) == ''
    with open(fn, 'wb') as fd:
        fd.write('blah')
    assert md5(fn) == '78cbf0ae30a716152c76f829ca3b9f3c'
    os.unlink(fn)

# Generated at 2022-06-11 18:04:06.796994
# Unit test for function md5s
def test_md5s():

    assert md5s('data') == '1f3870be274f6c49b3e31a0c6728957f'
    assert md5s('1f3870be274f6c49b3e31a0c6728957f') == '9a8f1d7b0888c09efa93b1d856f0fd29'


# Generated at 2022-06-11 18:04:07.668245
# Unit test for function md5
def test_md5():
    assert md5(__file__) is not None

# Generated at 2022-06-11 18:04:16.105466
# Unit test for function checksum
def test_checksum():
    '''
    ansible core checksum tests
    '''
    import os
    import tempfile
    from ansible.module_utils.six import b
    fd, fname = tempfile.mkstemp(prefix='ansible_test_checksum')


# Generated at 2022-06-11 18:04:18.843976
# Unit test for function md5s
def test_md5s():
    assert md5s("foobar") == "3858f62230ac3c915f300c664312c63f"

# Generated at 2022-06-11 18:04:25.491204
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    else:
        try:
            md5s('test')
            assert False
        except ValueError as e:
            assert 'MD5 not available' in str(e)


# Generated at 2022-06-11 18:04:35.489340
# Unit test for function md5
def test_md5():

    import tempfile
    file = tempfile.mkstemp()
    str = "hello"
    f = os.fdopen(file[0],"w")
    f.write(str)
    f.close()

    # Get md5 hash for testing string
    md5_output = md5s(str)

    # Calculate md5 hash for test file
    md5_file = md5(file[1])

    os.close(file[0])
    os.remove(file[1])

    # Check if md5 hash for string and file is same
    assert md5_output == md5_file, "md5() Test failed"

    # Test passes
    print("md5() Test passed")


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:04:40.139374
# Unit test for function checksum
def test_checksum():
    ''' test_checksum to validate its functionality '''
    checksum_output = secure_hash('file://../lib/ansible/module_utils/basic.py')
    if not isinstance(checksum_output, str):
        raise AssertionError("Expected 'str', got '%s' instead." % type(checksum_output))


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:04:45.882747
# Unit test for function md5
def test_md5():
    filename = "myfile"
    # Create a file for testing
    import tempfile
    test_file = tempfile.NamedTemporaryFile(delete=False)
    test_file.write("abcdefghijklmnopqrstuvwxyz")
    test_file.close()

    assert md5(test_file.name) == 'e80b5017098950fc58aad83c8c14978e'

# Generated at 2022-06-11 18:04:48.505698
# Unit test for function md5s
def test_md5s():
    s = "Ansible"
    assert md5s(s) == "4d7a25319113f2c7d1b0298ecab7011e"
    assert md5s(s) == md5s(s)

# Generated at 2022-06-11 18:04:51.181512
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"



# Generated at 2022-06-11 18:04:55.707211
# Unit test for function md5s
def test_md5s():
    assert md5s("1234") == "81dc9bdb52d04dc20036dbd8313ed055"
    assert md5s("aglksdfjg") == "77c63ecb7e0781c1e61136ca14cfac0d"

# Generated at 2022-06-11 18:05:05.454912
# Unit test for function md5s
def test_md5s():

    from unittest import TestCase

    # Backwards compat with md5s in vars_plugins/hashivault.py
    test_cases = [
        ("hashicorp", "2b6f0525d092d837f819f0b85d4ffc4a"),
        ("hashicorp\n", "531d67ada102518bfbc0c5db0d7336c1"),
        ("hashicorp\n\n", "d9895f794a42b60e51b2a1b3efc95ab8"),
        ("hashicorp\r\n", "5f7cc1f5b94c7e9309df2a2b61a8478c"),
    ]


# Generated at 2022-06-11 18:05:08.948504
# Unit test for function md5s
def test_md5s():
    filename = 'lib/ansible/modules/core/files/__init__.py'
    digest = "e835de5f7dc5f5a590a7a3d3ecceb7e9"
    assert md5(filename) == digest, "md5(%s) => %s expected: %s" % (filename, md5(filename), digest)


# Generated at 2022-06-11 18:05:18.723089
# Unit test for function md5s
def test_md5s():

    # Test with str
    s = "foo"
    checksum = md5s(s)
    assert checksum == "acbd18db4cc2f85cedef654fccc4a4d8", "md5s() returned an unexpected result: %s" % checksum

    # Test with Unicode
    s = u"foo"
    checksum = md5s(s)
    assert checksum == "acbd18db4cc2f85cedef654fccc4a4d8", "md5s() returned an unexpected result: %s" % checksum

    # Test with binary
    s = b"foo"
    checksum = md5s(s)

# Generated at 2022-06-11 18:05:33.137859
# Unit test for function checksum
def test_checksum():

    data = "hello world"
    computed_sum = checksum_s(data)

    # Use a pre-computed checksum string for testing purposes
    expected_sum = '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert computed_sum == expected_sum

    file_name = './test/test_file.txt'
    # Use a pre-computed checksum string for testing purposes
    expected_sum = '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    computed_sum = checksum(file_name)
    assert computed_sum == expected_sum


if __name__ == "__main__":
    test_checksum()