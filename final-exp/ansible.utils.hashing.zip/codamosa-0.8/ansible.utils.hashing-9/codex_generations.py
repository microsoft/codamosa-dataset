

# Generated at 2022-06-11 17:55:31.878658
# Unit test for function md5s
def test_md5s():
    if _md5:
        good = md5s("data")
        if not md5s("data") == good:
            raise AssertionError("md5s() failed")


# Generated at 2022-06-11 17:55:41.082940
# Unit test for function checksum
def test_checksum():
    import tempfile

    tmpdir = tempfile.mkdtemp()
    # Create a small file
    data = "hello"
    fd, testfile = tempfile.mkstemp(dir=tmpdir)
    with open(testfile, 'w') as f:
        f.write(data)
    checksum_value = checksum(testfile)
    checksum_s_value = checksum_s(data)
    assert(checksum_value == checksum_s_value)

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:55:47.110938
# Unit test for function md5s
def test_md5s():
    import filecmp
    data = '''a:
    b: this is a test
    c:
      c1: "this is the right value"
      c2: "this is the wrong value"
'''
    assert filecmp.cmp('test.yml', data)
    assert md5s(data) == 'f5e00df8d553023615e724144a66a02f'
    assert md5s(data) == md5('test.yml')


# Generated at 2022-06-11 17:55:57.946750
# Unit test for function md5s
def test_md5s():
    assert md5s("123456") == "e10adc3949ba59abbe56e057f20f883e"
    assert md5s("MD5 test") == "4b9ad1fc872b4a0ac97f31c82b76790c"
    assert md5s("SHA1 test") == "f0dbc89d356ef010b67e05fbdb7618c8"
    assert md5s("SHA256 test") == "cff364e37d579397d138c37bea0a8c1daa881e3bba3b9fa9a81338d43f95a7e7"

# Generated at 2022-06-11 17:56:08.606336
# Unit test for function checksum
def test_checksum():
    import sys
    import tempfile
    from ansible.compat.tests import unittest
    from ansible.utils.hashing import checksum, checksum_s, checksum_s_local

    class TestChecksum(unittest.TestCase):

        def setUp(self):
            self.fh, self.path = tempfile.mkstemp()

        def tearDown(self):
            os.close(self.fh)
            os.remove(self.path)

        def test_checksum_s(self):
            if sys.version_info < (2, 6):
                expected = '95fae17182832d7104b72a2a1e04e37f'

# Generated at 2022-06-11 17:56:14.375557
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "85a930033e431a2c2192b03d6f1e5b44fe8b646c"
    assert checksum("/bin/sh") == "7f3b08e9c9dd51ce5b8f7b1335d1d25f"


# Generated at 2022-06-11 17:56:22.130594
# Unit test for function md5s
def test_md5s():
    assert md5s("This is a message to be digested!") == 'aa0e2db66f771d3e41ff8ddfc3a9d50e'
    # Test that returning the same value with a different type doesn't change the digest
    assert md5s(u'Hello World') == md5s('Hello World')
    assert md5s(bytearray(b'Hello World')) == md5s('Hello World')
    # Test that changing the value does change the digest
    assert md5s('Hello World') != md5s('Goodbye World')
    # Test that changing the data type does change the digest
    assert md5s('Hello World') != md5s(u'Hello World')
    assert md5s('Hello World') != md5s(bytearray(b'Hello World'))
    assert md

# Generated at 2022-06-11 17:56:30.021713
# Unit test for function checksum
def test_checksum():
    h1 = secure_hash_s("Hello World!")
    assert h1 == "0a4d55a8d778e5022fab701977c5d840bbc486d0"

    f = open("/tmp/ansible_test_checksum", "w")
    f.write("Hello World!")
    f.close()

    h2 = secure_hash("/tmp/ansible_test_checksum")
    assert h1 == h2

    os.unlink("/tmp/ansible_test_checksum")

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:56:36.408783
# Unit test for function checksum
def test_checksum():
    test_string = 'abc123'
    assert checksum_s(test_string) == 'b16b00b8e27dbe5b83ffc8ae5ffe338d53138242'
    assert checksum_s(test_string, _md5) == 'e99a18c428cb38d5f260853678922e03'

# Generated at 2022-06-11 17:56:37.366574
# Unit test for function md5s
def test_md5s():
    assert secure_hash_s('My string is awesome.') == md5s('My string is awesome.')



# Generated at 2022-06-11 17:56:42.655732
# Unit test for function md5
def test_md5():
    input = 'foobar'
    result = md5s(input)
    assert result == '3858f62230ac3c915f300c664312c63f'


# Generated at 2022-06-11 17:56:44.943839
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-11 17:56:55.788415
# Unit test for function checksum
def test_checksum():
    test_file = "/etc/passwd"
    test_string = """#
# /etc/passwd
#
# An example passwd entry:
#   nobody:*:99:99:Nobody:/nonexistent:/usr/bin/false
#
"""
    if not sha1 or not os.path.exists(test_file):
        print("SKIPPED")
        return
    if checksum(test_file) != "7befd341729dda49e8b8a48a89efd929e957b8be":
        print("FAILED")
        return
    if checksum_s(test_string) != "eafe9cdb70c995df3f7fae79a403f44d8a8a33c2":
        print("FAILED")
        return
   

# Generated at 2022-06-11 17:57:04.379833
# Unit test for function md5
def test_md5():
    fname = "/tmp/md5_test_file"
    data = "This is a test of the md5 function"
    f = open(fname, 'w')
    f.write(data)
    f.close()
    chk = md5(fname)
    os.remove(fname)
    assert chk == "d6e100e6aef12f63d2f4848f3a929efe"


if __name__ == '__main__':
    test_md5()
    print('All tests passed')

# Generated at 2022-06-11 17:57:08.597949
# Unit test for function md5
def test_md5():
    a = md5s('hello')
    b = md5s('hello')
    c = md5s('hello2')
    # This would fail if the non-FIPS md5 module was not installed.
    assert a == b
    assert a != c

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 17:57:13.325297
# Unit test for function md5s
def test_md5s():
    data = "this is not a string"
    assert md5s(data) == "b5d5cdde1e3d06b9a9b0e7b0f80b87d7"


# Generated at 2022-06-11 17:57:18.041134
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/cat") == "6d8790145ab42d3b248f9b4f04b57a4d"
    assert checksum("/bin/cat", _md5) == "a9e9f9110b8cf0b3484840b3967494b2"


# Generated at 2022-06-11 17:57:20.734339
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return True
    else:
        assert md5s("helloworld") == "fc5e038d38a57032085441e7fe7010b0"

# Generated at 2022-06-11 17:57:28.781823
# Unit test for function md5
def test_md5():
    ''' md5 hash algorithm should match the output of the command line md5 tool '''
    filename = 'testfile'
    f = open(filename, 'w')
    f.write('''
a
ab
abc
abcd
abcde
abcdef
abcdefg
abcdefgh
abcdefghi
abcdefghij
''')
    f.close()
    cmd5 = os.popen('md5 %s' % filename).read().rstrip('\n').split()[-1]
    assert md5(filename) == cmd5
    os.remove(filename)

# Generated at 2022-06-11 17:57:30.542461
# Unit test for function md5s
def test_md5s():
    assert md5s('Test string') == '6f8db599de986fab7a21625b7916589c'


# Generated at 2022-06-11 17:57:43.227458
# Unit test for function checksum
def test_checksum():
    test_file = to_bytes(__file__, errors='surrogate_or_strict')
    test_string = b"test-string"

    assert checksum(test_file) == "7bbf8d3f1bf7770c82f0a7d8d2f89b7e"
    assert checksum_s(test_string) == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"
    if _md5:
        assert md5(test_file) == "5a5c5b5e1a7cfd685a20cef72347de62"
        assert md5s(test_string) == "098f6bcd4621d373cade4e832627b4f6"



# Generated at 2022-06-11 17:57:47.098439
# Unit test for function md5
def test_md5():
    test_data = "This is a test"
    assert md5s(test_data) == md5s(test_data)
    assert md5(__file__) == md5(__file__)

# Unit test function sha256

# Generated at 2022-06-11 17:57:54.042477
# Unit test for function md5s
def test_md5s():
    import six
    if hasattr(six, 'assertCountEqual'):
        assertCountEqual = six.assertCountEqual
    else:
        assertCountEqual = six.assertItemsEqual

    assert md5s(b'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(u'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(u'\u6d4b\u8bd5') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-11 17:57:57.659019
# Unit test for function md5s
def test_md5s():
    assert md5s('test data') == 'ce114e4501d2f4e2dcea3e17b546f339'

# Generated at 2022-06-11 17:58:01.225911
# Unit test for function md5s
def test_md5s():
    "Unit test for function md5s"
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-11 17:58:08.328508
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('world') == '7d793037a0760186574b0282f2f435e7'

    assert md5(__file__) is not None
    assert md5(__file__) == md5s(open(__file__).read())


# Generated at 2022-06-11 17:58:12.836414
# Unit test for function md5
def test_md5():
    ''' md5 unit test '''

    # Generate MD5 hash
    data = 'This is the message to be hashed'
    assert md5s(data) == '0c867c3d3e1e7b87f19bba48bbb2d862'



# Generated at 2022-06-11 17:58:24.298293
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import sys

    checksum_dir = tempfile.mkdtemp()
    print("Dir: %s" % checksum_dir)
    file = open(checksum_dir + "/file1", 'w')
    file.write("somedata")
    file.close()

    # checksum
    print("Checksum: %s" % checksum(checksum_dir + "/file1"))
    print("Checksum: %s" % checksum_s("somedata"))

    # md5
    try:
        print("MD5: %s" % md5(checksum_dir + "/file1"))
    except ValueError as e:
        if "FIPS" in str(e):
            print("md5 not available in FIPS mode, as expected")

# Generated at 2022-06-11 17:58:26.619802
# Unit test for function md5s
def test_md5s():
    assert md5s("ansible") == 'f2c7ddd09ab473c9008de268209134f3'

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 17:58:29.442808
# Unit test for function md5s
def test_md5s():
    assert(md5s('test') == '098f6bcd4621d373cade4e832627b4f6')
    assert(md5s('this is a test') == 'e2c569be17396eca2a2e3c11578123ed')

# Generated at 2022-06-11 17:58:34.590912
# Unit test for function md5s
def test_md5s():
    assert md5s("blah") == "5eb63bbbe01eeed093cb22bb8f5acdc3"


# Generated at 2022-06-11 17:58:41.208558
# Unit test for function md5
def test_md5():

    import tempfile

    # Create a temporary file
    (fd, filename) = tempfile.mkstemp()

    # Write a temporary file
    fileObj = os.fdopen(fd, "w")
    fileObj.write("testing\n")
    fileObj.close()

    # Get the md5 hash of the temporary file
    mysum = md5(filename)

    # Remove the temporary file
    #os.remove(filename)

    # Test the md5 hash (known value)
    if mysum == '0b3c01e2e38fc15dab3f5d8345bf8c2c':
        return True
    else:
        return False


# Generated at 2022-06-11 17:58:44.618183
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '97bdc8d7d816c6e2a71638d0b9315aa4'
    assert md5('/bin/bad') is None


# Generated at 2022-06-11 17:58:48.175448
# Unit test for function md5s
def test_md5s():
    m = md5s('dummy string')
    assert m == '6cd3556deb0da54bca060b4c39479839'



# Generated at 2022-06-11 17:58:57.188873
# Unit test for function md5
def test_md5():
    import os
    import tempfile

    filename = tempfile.mktemp()
    data = 'The quick brown fox jumped over the lazy dog'

    f = open(to_bytes(filename, errors='surrogate_or_strict'), 'wb')
    f.write(to_bytes(data, errors='surrogate_or_strict'))
    f.close()

    checksum = md5(filename)

    assert (checksum == '9e107d9d372bb6826bd81d3542a419d6')

    assert (md5s(data) == '9e107d9d372bb6826bd81d3542a419d6')

    os.unlink(filename)

# Generated at 2022-06-11 17:58:59.981797
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return
    assert md5s('test123') == '2a7d1c4fc50ddd57e602d805bcc44fad'


# Generated at 2022-06-11 17:59:02.529037
# Unit test for function checksum
def test_checksum():
    assert checksum_s("data") == "3d2979286c283f0efb1f8b6d4f4558cc0a74f19b"


# Generated at 2022-06-11 17:59:04.756139
# Unit test for function md5
def test_md5():
    assert md5(__file__) == 'e27630c2d0e8c86b9f9b0ce88dea1bd5'

# Generated at 2022-06-11 17:59:10.472940
# Unit test for function md5
def test_md5():
    import os
    import tempfile
    fd, path = tempfile.mkstemp()
    try:
        os.write(fd, "blah")
        assert md5(path) == "1d83c9b9f0a9eacdabd87e8c1f62afb0"
    finally:
        os.remove(path)

# Generated at 2022-06-11 17:59:13.071342
# Unit test for function md5
def test_md5():
    assert md5("/bin/cat") == "5e107d9e9e5e9cd2f7d180b524515c3c"



# Generated at 2022-06-11 17:59:18.822061
# Unit test for function md5s
def test_md5s():
    # typical md5 of 'hello world'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-11 17:59:30.596034
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    from ansible.module_utils._text import to_bytes

    # Setup a test dir
    temp_dir = tempfile.mkdtemp()
    temp_filename = temp_dir + "/temp_file"

    # Write a test file using sha1
    fd = open(temp_filename, "w")
    fd.write("Hello!")
    fd.close()
    sha1_digest = checksum(temp_filename)

    # Write a test file using md5
    fd = open(temp_filename, "w")
    fd.write("Hello!")
    fd.close()
    md5_digest = md5(temp_filename)

    # Cleanup
    shutil.rmtree(temp_dir)

    # Check the output
   

# Generated at 2022-06-11 17:59:38.042609
# Unit test for function md5s
def test_md5s():
    '''
    Test that the same hash is returned when a file is read
    as when the same data is provided directly.
    '''
    data = 'This is a test string for md5s'
    file_txt = "test/utils/test_md5_data.txt"
    with open(file_txt, "w") as f:
        f.write(data)

    file_result = md5(file_txt)
    file_data = open(file_txt, 'rb').read()

    data_result = md5s(data)
    string_result = md5s(file_data)

    assert file_result == data_result
    assert data_result == string_result

# Generated at 2022-06-11 17:59:39.641923
# Unit test for function checksum
def test_checksum():
    return not checksum('/etc/password') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-11 17:59:42.515130
# Unit test for function md5s
def test_md5s():
    data = to_bytes('1234')
    check_str = '81dc9bdb52d04dc20036dbd8313ed055'
    if md5s(data) == check_str:
        return True
    else:
        return False

# Generated at 2022-06-11 17:59:50.231793
# Unit test for function md5s
def test_md5s():
    """
    ansible core tests - md5s
    """

    import os
    import shlex
    from units.compat import unittest
    from units.compat.mock import patch
    from ansible.module_utils.basic import AnsibleModule, missing_required_lib

    # Disable FIPS mode for test
    os.environ['ANSIBLE_NO_FIPS'] = '1'


# Generated at 2022-06-11 17:59:57.307126
# Unit test for function checksum
def test_checksum():
    ''' unit test for function checksum '''

    # checksum_s
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'

    # checksum
    tmp_file = '/tmp/test_checksum'
    try:
        with open(tmp_file, 'w') as f:
            f.write('hello')

        assert checksum(tmp_file) == '5d41402abc4b2a76b9719d911017c592'
        assert checksum('/this/path/does/not/exist') is None
        assert checksum('/dev/null') is None
    finally:
        os.remove(tmp_file)


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:00:02.376420
# Unit test for function checksum
def test_checksum():
    ''' test checksum '''

    result = checksum('test/test_utils.py')
    assert result == '90b20a97b64e47b54a11b9f966b45e2325c298b6'

    result = checksum_s('foobar')
    assert result == '8843d7f92416211de9ebb963ff4ce28125932878'

# Generated at 2022-06-11 18:00:11.744662
# Unit test for function checksum
def test_checksum():

    result = checksum_s('hello world')
    assert result == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed', 'sha1sum of hello world should be 2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    # test of the backwards compat function
    result = md5s('Hello world')
    assert result == '5eb63bbbe01eeed093cb22bb8f5acdc3', 'md5sum of hello world should be 5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-11 18:00:14.034826
# Unit test for function md5
def test_md5():
    assert md5(__file__) == 'e75b57ec8822d63f0e8b0339c97cecff'


# Generated at 2022-06-11 18:00:25.354381
# Unit test for function checksum
def test_checksum():
    # Test if the function properly checksum the file
    import tempfile

    with tempfile.NamedTemporaryFile() as tmp:
        # Write test string to tempfile
        tmp.write(to_bytes('This is a test string in a tempfile'))
        tmp.flush()

        # Get checksum from test file
        t_checksum = secure_hash(tmp.name)
        assert(t_checksum == '6d4c4b4ad9f3d1b8f3e95ca81c508e5966c0378a')

# Generated at 2022-06-11 18:00:27.492971
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-11 18:00:35.422866
# Unit test for function md5s
def test_md5s():
    import sys

    # Test that we fail on FIPS systems
    if _md5 is None:
        raised = False
        try:
            md5s('test string')
        except ValueError as e:
            raised = True
        assert raised

    assert md5s('test string') == '098f6bcd4621d373cade4e832627b4f6'
    # With unicode strings
    if sys.version_info >= (2,6):
        assert md5s(u'test string') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-11 18:00:39.815806
# Unit test for function md5
def test_md5():
    """Unit test for function md5"""

    testfile = "test_md5.txt"
    f = open(testfile, "w")
    f.write("Hello World!")
    f.close()

    assert md5(os.path.join(os.getcwd(), testfile)) == '65a8e27d8879283831b664bd8b7f0ad4'


# Generated at 2022-06-11 18:00:51.643578
# Unit test for function md5s
def test_md5s():
    test_data = ['data 1','data 2','data 3','data 4','data 5','data 6','data 7','data 8','data 9','data 10']

# Generated at 2022-06-11 18:00:54.375322
# Unit test for function md5
def test_md5():
    import tempfile
    (fd, tfile) = tempfile.mkstemp()
    os.close(fd)
    try:
        f = open(tfile, 'w')
        f.write('abcdef')
        f.close()
        assert(md5(tfile) == 'e80b5017098950fc58aad83c8c14978e')
    finally:
        os.unlink(tfile)

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:01:01.326505
# Unit test for function checksum
def test_checksum():
    '''test_checksum returns true if the checksum of a file created matches the returned checksum'''
    import tempfile
    import shutil
    import random
    filename = tempfile.mktemp()
    tmpdir = tempfile.mkdtemp()
    original_data = list(range(0, 256))
    for x in range(0,256):
        random.shuffle(original_data)
        f = open(filename, 'w')
        f.write("".join(map(chr, original_data)))
        f.close()
        #Test non-existent file first
        if checksum('/tmp/this/path/should/never/exist/I/hope') != None:
            shutil.rmtree(tmpdir)
            os.remove(filename)
            return False

# Generated at 2022-06-11 18:01:07.254221
# Unit test for function md5s
def test_md5s():
    known_good_md5_hash = '7c222fb2927d828af22f592134e8932480637c0d'
    assert known_good_md5_hash == md5s('hello')
    assert not md5s('hello') == md5s('world')


# Generated at 2022-06-11 18:01:19.074348
# Unit test for function checksum
def test_checksum():
    '''unit test for checksum'''

    # test valid md5 checksum
    assert checksum("examples/ansible.cfg", 'md5') == "75efc6f4da4a95a062d8ac91b9d25f0f"

    # test valid sha1 checksum
    assert checksum("examples/ansible.cfg", 'sha1') == "7e42ddf61fdff8a97f6a00f025c1e6e1f3bce937"

    # test valid sha256 checksum
    assert checksum("examples/ansible.cfg", 'sha256') == "b9787fe0ca77eceff8d0a81a900aeba89001f1de3bea3d92908fb7da2ba6a0f7"



# Generated at 2022-06-11 18:01:27.218548
# Unit test for function md5
def test_md5():
    filename = os.path.join(os.path.dirname(__file__), 'md5testfile')
    filemd5 = md5(filename)
    print(filemd5)
    # The test file is generated by the following command:
    # echo "This is a test data file" > md5testfile
    assert filemd5 == '3b55d36a4396e80149cf7bc70e58a604'
    print('Test md5 succeeded')



# Generated at 2022-06-11 18:01:33.242463
# Unit test for function md5s
def test_md5s():
    md5_value = md5s('test text')
    assert md5_value == 'e0d7aaf59c190e61878588e1c6ecbb8d'


# Generated at 2022-06-11 18:01:36.521398
# Unit test for function md5s
def test_md5s():
    assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"


# Generated at 2022-06-11 18:01:42.776882
# Unit test for function checksum
def test_checksum():
    import tempfile
    filename = tempfile.mktemp()
    f = open(filename, 'wb')
    f.write(b'hello')
    f.close()
    try:
        import hashlib
        if checksum(filename) == hashlib.sha1('hello').hexdigest():
            return True
    finally:
        os.unlink(filename)


# Generated at 2022-06-11 18:01:48.324452
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(b'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(u'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


if __name__ == '__main__':
    import sys
    filename = sys.argv[1]
    sys.stdout.write(checksum(filename))

# Generated at 2022-06-11 18:01:57.523599
# Unit test for function md5
def test_md5():
    from ansible.module_utils.six import StringIO
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    md5_test = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    (dummy_fd, dummy_filename) = tempfile.mkstemp(prefix='ansible-test_md5.')
    os.close(dummy_fd)
    dummy_file = StringIO(b'This is a dummy string.')
    dummy_file_md5 = 'abf7e8dc881f402fc77d97178aa4c4c6'
    dummy_file_s = 'This is a dummy string.'

# Generated at 2022-06-11 18:02:00.383023
# Unit test for function md5s
def test_md5s():
    return '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33' == md5s('foo')


# Generated at 2022-06-11 18:02:11.284854
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import sys

    # Create a tempdir
    tmpdir = tempfile.mkdtemp()

    # Create a temp file of a known string
    fd, fname = tempfile.mkstemp(dir=tmpdir)
    os.write(fd, b"foo")
    os.close(fd)


# Generated at 2022-06-11 18:02:23.033666
# Unit test for function checksum
def test_checksum():
    # Check that the same string has the same checksum
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s(b'test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_s(u'test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

    # Check that different strings have different checksums
    # These asserts depend on the test strings being different
    # but having similar leading and trailing portions.

# Generated at 2022-06-11 18:02:26.271452
# Unit test for function md5
def test_md5():
    ''' test md5 functionality '''

    # This is the md5 of 'hello'. ansible
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-11 18:02:32.902645
# Unit test for function checksum
def test_checksum():

    import tempfile

    fd, temp_file = tempfile.mkstemp()
    with os.fdopen(fd, 'wb') as f:
        f.write("Hello World")

    checksum1 = checksum(temp_file)
    checksum2 = secure_hash(temp_file)
    os.remove(temp_file)

    assert checksum1 == checksum2

# Generated at 2022-06-11 18:02:38.306539
# Unit test for function md5s
def test_md5s():
    assert md5s(u'abc') == u'900150983cd24fb0d6963f7d28e17f72'


# Generated at 2022-06-11 18:02:42.598212
# Unit test for function md5s
def test_md5s():
    assert md5s("teststring") == '98fa1b4bd2b48e4d27e713c4d464bfe8'
    # Functions should return None on invalid input
    assert md5s(None) is None

# Generated at 2022-06-11 18:02:45.140037
# Unit test for function md5s
def test_md5s():
    if _md5:
        s = 'Hello World'
        assert md5s(s) == 'ed076287532e86365e841e92bfc50d8c'

test_md5s()

# Generated at 2022-06-11 18:02:52.422324
# Unit test for function md5
def test_md5():

    filename = '/etc/passwd'
    test_md5 = '76b8e0ada0f13d90405d6ae55f4b5a8b'

    if secure_hash(filename, _md5) == test_md5:
        print("MD5() function is working correclty for this file: %s" % filename)
    else:
        print("MD5() function is not working correclty for this file: %s" % filename)


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:03:02.275639
# Unit test for function md5
def test_md5():
    # setup test case
    import tempfile
    with tempfile.NamedTemporaryFile() as f:
        f.write("Hello, World!\n")
        f.flush()
        res = md5(f.name)
    # test case
    assert res in ['fc3ff98e8c6a0d3087d515c0473f8677', 'efd2fb8f79b22983d5f5b5d3e827c919'] # expected results for ansible/ansible or ansible/ansible/2.4.2.0


# Generated at 2022-06-11 18:03:06.075713
# Unit test for function md5
def test_md5():
    testfile = os.path.join(os.path.dirname(__file__), 'test_utils_hash.py')
    assert md5(testfile) == '829f1b7d44c30a43a7fc22ca17e7e739'



# Generated at 2022-06-11 18:03:08.752864
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 18:03:15.814503
# Unit test for function md5
def test_md5():
    ''' test_md5.py: Unit test for function md5 in module ansible.module_utils.basic. '''

    md5_value = md5('/usr/bin/ansible')
    assert md5_value == '0ffa2c5d95e50e9f939a534b8e095a5a'

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:03:19.773385
# Unit test for function md5
def test_md5():
    if not _md5:
        return True
    assert len(md5s("")) == len(md5(""))
    assert md5s("12345") == md5("test/testutils/files/ansible-test-file.txt")

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:03:23.187080
# Unit test for function md5s
def test_md5s():
    if _md5:
        if md5s('test') != '098f6bcd4621d373cade4e832627b4f6':
            raise ValueError("md5s() failed")


# Generated at 2022-06-11 18:03:35.849929
# Unit test for function checksum
def test_checksum():
    test_files = ["/etc/passwd", "/etc/group", "/etc/shadow", "/etc/gshadow"]
    for f in test_files:
        print ("file: %s" % f)
        print ("    sha1: %s" % checksum(f))
        if _md5:
            print ("    md5: %s" % md5(f))
        print ("data: %s" % f)
        print ("    sha1: %s" % checksum_s(f))
        if _md5:
            print ("    md5: %s" % md5s(f))

        print()

if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-11 18:03:42.774471
# Unit test for function checksum
def test_checksum():
    import tempfile
    tf = tempfile.NamedTemporaryFile()
    tf.write(b'foobar')
    tf.seek(0)
    data = tf.read()
    tf.close()
    assert checksum_s(data) == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert checksum(tf.name) == '8843d7f92416211de9ebb963ff4ce28125932878'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:03:46.495036
# Unit test for function md5
def test_md5():
    data = 'abc123'
    expected_md5 = 'e99a18c428cb38d5f260853678922e03'
    assert expected_md5 == md5s(data)

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:03:53.399332
# Unit test for function md5
def test_md5():
    res1 = md5s('a').lower()
    res2 = md5('library/sha1.py').lower()
    res3 = md5('library/sha1.pyA').lower()
    assert res1 == '0cc175b9c0f1b6a831c399e269772661'
    assert res2 == '5f5b5bd1a5a96d8be0fbea4c655a4e4b'
    assert res3 == 'f7c3bc1d808e04732adf679965ccc34ca7ae3441'

# Generated at 2022-06-11 18:03:59.631529
# Unit test for function md5
def test_md5():
    h = "93b885adfe0da089cdf634904fd59f71"
    h1 = md5("test/test-plugin/test-plugin.py")
    h2 = md5("test/test-plugin/test-plugin.pyc")
    assert h1 == h
    assert h1 == h2


__all__ = ['checksum', 'checksum_s', 'md5', 'md5s']

# Generated at 2022-06-11 18:04:07.790649
# Unit test for function checksum
def test_checksum():

    from ansible import constants as C
    from ansible.utils.path import unfrackpath

    b_path = unfrackpath(u'tests/utils/data/fips-mode-sensitive')

    res = checksum(b_path)
    if C.DEFAULT_HASH_BEHAVIOUR == 'md5':
        assert res == '1ebf0c877b86d186723c8f25cc0e2bb2'
    else:
        assert res == 'a35f3e85a00d3e8a3f3e2dda9bd33ece1ebf0c87'

# Generated at 2022-06-11 18:04:09.680909
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-11 18:04:17.089778
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '52ab60eae6bc0e671a9dac3d00b3fb18f2076564'
    assert checksum(b'/bin/ls') == '52ab60eae6bc0e671a9dac3d00b3fb18f2076564'
    assert checksum('/bin/ls', sha1) == '52ab60eae6bc0e671a9dac3d00b3fb18f2076564'
    assert checksum(b'/bin/ls', sha1) == '52ab60eae6bc0e671a9dac3d00b3fb18f2076564'

# Generated at 2022-06-11 18:04:19.797429
# Unit test for function md5s
def test_md5s():

    data = 'testing123'
    expected_output = 'ee1e1f2d667fa442e179ff649f834407'
    assert md5s(data) == expected_output

# Generated at 2022-06-11 18:04:29.286865
# Unit test for function md5
def test_md5():
    print("Starting unit test for function md5")
    import datetime
    print("Initializing test variables")
    test_file = "test_md5.txt"
    test_string = "test string"
    expected_md5 = "f06cfbdb1d99e06e33f2c14980cc623f"
    test_file_path = "./test_md5.txt"
    print("Test variables initialized")
    with open(test_file, 'w') as f:
        print("File " + test_file + " created")
        f.write(test_string)
        print("Test string written to " + test_file)

    print("Executing md5 function with filename path as parameter")
    start_time = datetime.datetime.now()

# Generated at 2022-06-11 18:04:35.357445
# Unit test for function md5s
def test_md5s():
    assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"


# Generated at 2022-06-11 18:04:38.893457
# Unit test for function md5
def test_md5():
    assert(md5('test/support/test_md5.py') == 'b58e7b9e9224c97675ea6b5d6f5fa6f1')
    print(md5('test/support/test_md5.py'))

# Generated at 2022-06-11 18:04:48.333024
# Unit test for function md5s
def test_md5s():
    def check_md5s(data, expected):
        assert md5s(data) == expected
        assert md5s(to_bytes(data, errors='surrogate_or_strict')) == expected

    # Test cases from https://www.di-mgt.com.au/md5sum1.html

# Generated at 2022-06-11 18:04:51.481954
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('my data') == '6f8db599de986fab7a21625b7916589c'


# Generated at 2022-06-11 18:04:55.866249
# Unit test for function checksum
def test_checksum():
    # Create a file with a content
    fd, fname = tempfile.mkstemp(text=True)
    os.write(fd, 'test_checksum')
    os.close(fd)

    # Check if the checksum is correct
    assert checksum(fname) == checksum_s('test_checksum')

    # Check if the md5 function still works with FIPS
    if not _md5:
        assert md5s('test_checksum') == '098f6bcd4621d373cade4e832627b4f6'

    # Delete the file
    os.remove(fname)

# Generated at 2022-06-11 18:05:02.151507
# Unit test for function checksum
def test_checksum():
    f = 'CHANGELOG'
    f_checksum = checksum(f)
    assert f_checksum == None
    s = 'ansible-doc'
    s_checksum = checksum_s(s)
    assert len(s_checksum) == 40
    assert s_checksum == 'e6815fa3ca111ab26834ed57f7d2e9c6d3fc1ac3'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:05:07.890042
# Unit test for function md5s
def test_md5s():
    test_string = "foo"
    expected_hash = "acbd18db4cc2f85cedef654fccc4a4d8"
    returned_hash = md5s(test_string)
    if not returned_hash == expected_hash:
        raise ValueError("md5s() did not return expected hash.  Got: %s Expected: %s" % (returned_hash, expected_hash))


if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-11 18:05:13.428072
# Unit test for function md5
def test_md5():
    data = "Hi There"
    filename = "test_file"
    open(filename, 'w').write(data)

    md5_data = md5s(data)
    md5_file = md5(filename)

    assert md5_data == md5_file
    assert md5_data == '49f68a5c8493ec2c0bf489821c21fc3b'

    os.remove(filename)

if __name__ == "__main__":
    import sys
    import doctest
    # failfast is a new option added in python 2.7, so for older versions we
    # do not use it.
    if sys.version_info[0:2] > (2, 6):
        doctest.testmod(failfast=True)
    else:
        doctest.testmod()

# Generated at 2022-06-11 18:05:16.799974
# Unit test for function md5
def test_md5():
    try:
        from hashlib import md5
        m = md5()
        # The following construct works around the inability to update the
        # md5 instance several times when running in FIPS compliant mode.
        # See http://bugs.python.org/issue8080
        m.update(b'a')
        m.update(b'bc')
        m.update(b'd')
        assert m.hexdigest() == '2b2d84c3ff06e341eecba8ff907914bb'
    except ImportError:
        pass

# Generated at 2022-06-11 18:05:21.981855
# Unit test for function md5
def test_md5():
    ''' test md5 functionality '''
    test_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'crc.py')
    assert md5(test_file) == 'c1a88b76fa5b5c5a5aeb84d764b0f5fd'
    assert md5('') == 'd41d8cd98f00b204e9800998ecf8427e'