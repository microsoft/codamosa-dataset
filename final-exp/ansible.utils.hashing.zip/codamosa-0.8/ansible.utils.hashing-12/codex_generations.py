

# Generated at 2022-06-11 17:55:42.675300
# Unit test for function checksum
def test_checksum():
    ''' checksum.py: Test checksum function '''

    import tempfile
    import shutil
    import os

    # Setup temp directory
    tmp_dir = tempfile.mkdtemp()
    test_file = os.path.join(tmp_dir, 'test_checksum_file')
    test_file_contents = 'This is a test file to test checksum function'

    # Test file
    f = open(test_file, 'w')
    f.write(test_file_contents)
    f.close()

    # Test
    test_sha1 = secure_hash(test_file)
    test_sha1_s = secure_hash_s(test_file_contents)
    assert test_sha1
    assert checksum(test_file) == test_sha1
    assert checksum_s

# Generated at 2022-06-11 17:55:45.259270
# Unit test for function md5s
def test_md5s():
    res = md5s('blah')
    return res == '8acd6c8e48b03cdc726dce8d6725c7a3'


# Generated at 2022-06-11 17:55:51.941479
# Unit test for function checksum
def test_checksum():
   """Test checksum with different files"""
   assert checksum('/etc/passwd') == '4d41004a9a5f0b5ddd28bcd5c77f8c15a5197ec2'
   assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

# Generated at 2022-06-11 17:55:54.065338
# Unit test for function md5s
def test_md5s():
    results = md5s(u'foo')
    assert results == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-11 17:56:05.052919
# Unit test for function checksum
def test_checksum():
    # Test secure_hash_s
    assert secure_hash_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert secure_hash_s('hello') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'
    # Test secure_hash
    assert secure_hash('/opt/ansible/lib/ansible/modules/core/files/file1.txt') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'

# Generated at 2022-06-11 17:56:13.626209
# Unit test for function checksum
def test_checksum():
    ''' test_checksum(filename) - test if the unit test properly computes both
        checksums.
    '''
    filename = './lib/ansible/modules/core/files/file_tests/checksum.txt'

    ck_s = checksum_s(filename)
    ck = checksum(filename)

    assert ck_s == ck
    assert ck == '3801a991d16d2e8c716b15cc6eabd860f3a3d074'


# Generated at 2022-06-11 17:56:15.824092
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'f8badf06a9f5733aaaf1ef47a47ca420'

# Generated at 2022-06-11 17:56:17.842777
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-11 17:56:26.921668
# Unit test for function md5
def test_md5():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('abcdefghijklmnopqrstuvwxyz') == 'c3fcd3d76192e4007dfb496cca67e13b'
    assert md5s('0123456789') == '781e5e245d69b566979b86e28d23f2c7'

# Generated at 2022-06-11 17:56:38.808941
# Unit test for function md5
def test_md5():
    ut_filename = '../../../test/files/changelog'
    ut_data = '../../../README.md'
    if not os.path.exists(ut_filename) or os.path.isdir(ut_filename):
        return False
    digest = _md5()
    blocksize = 64 * 1024
    try:
        infile = open(ut_filename, 'rb')
        block = infile.read(blocksize)
        while block:
            digest.update(block)
            block = infile.read(blocksize)
        infile.close()
    except IOError as e:
        raise AnsibleError("error while accessing the file %s, error was: %s" % (ut_filename, e))
    return digest.hexdigest()

test_md5()

# Unit test

# Generated at 2022-06-11 17:56:44.111843
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world!') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-11 17:56:47.361440
# Unit test for function md5
def test_md5():
    assert md5s('abc123') == 'e99a18c428cb38d5f260853678922e03'
    assert md5('/dev/null') == 'd41d8cd98f00b204e9800998ecf8427e'


# Generated at 2022-06-11 17:56:57.818008
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py:  test the return value of checksum.  Needs hashlib, mock and pytest '''
    try:
        import mock
    except ImportError:
        print("SKIP: unit test test_checksum (missing mock module)")
        return True

    testfile_path = os.path.join(os.path.dirname(__file__), '../test/test_checksum/')
    testfile_name = 'test_checksum_file'
    testfile_contents = 'test_checksum_content'
    testfile_fullpath = testfile_path + testfile_name

    with mock.patch('ansible.utils.checksum._md5',None):
        # test for file does not exist
        test = checksum(testfile_fullpath)
        assert (test is None)

# Generated at 2022-06-11 17:57:02.539746
# Unit test for function md5s
def test_md5s():
    assert md5s('this is a test string') == '32e63c20a536fb1a2ca2e81f121b2c4a'
    assert md5s('Hello World') == '65a8e27d8879283831b664bd8b7f0ad4'

# Generated at 2022-06-11 17:57:09.994070
# Unit test for function md5
def test_md5():
    testdata = to_bytes(
        'This module generates an md5 hash of either a local '
        'file or a string. It can return either the hash '
        'or just True or False if the hashes match or not. '
        'It is also able to detect changes in the file and '
        'regenerate the hash for the file.\n'
        'This module is also supported for Windows targets.\n')

    expected_md5 = 'f5d5db5269f1e89ac7385f48e1f67656'
    assert expected_md5 == md5s(testdata)

# Generated at 2022-06-11 17:57:20.425161
# Unit test for function md5
def test_md5():
    # Test md5 with different type of content
    if _md5:
        assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
        assert md5s(b'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
        assert md5s(u'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

        # Test md5 with filename
        test_file = '/tmp/ansible-test-file-%s' % os.getpid()
        f = open(test_file, 'w')
        f.write('foo')
        f.close()

# Generated at 2022-06-11 17:57:30.133241
# Unit test for function md5
def test_md5():
    from ansible.compat.tests import unittest

    class TestMd5(unittest.TestCase):

        @unittest.skip
        def test_availability(self):
            self.assertIsNotNone(md5('/dev/null'))

        def test_md5(self):
            ''' Test md5 function. '''
            if not _md5:
                return
            self.assertEqual(md5('/dev/null'), 'd41d8cd98f00b204e9800998ecf8427e')
            self.assertEqual(md5s('string'), 'f6cde2c043de9fca6630d54233c8e4b7')

    unittest.main()

# Generated at 2022-06-11 17:57:37.005685
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == md5s(open('/bin/ls').read())
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5('./hacking/env-setup') == '09fe9488b78d2e4ad4a4e2b4c8b09505'
    print("md5 tester passed")

# Generated at 2022-06-11 17:57:40.618355
# Unit test for function md5
def test_md5():
    ''' md5 hash should match output from md5sum '''
    import subprocess
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    

# Generated at 2022-06-11 17:57:43.464390
# Unit test for function md5s
def test_md5s():
    s = "hello world"
    assert md5s(s) == "5eb63bbbe01eeed093cb22bb8f5acdc3"

# Generated at 2022-06-11 17:57:53.587900
# Unit test for function checksum
def test_checksum():
    ''' test_checksum must be implemented in the parent class in order to be used by test.py '''

    import os

    dummy_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_utils.py')
    if os.path.isfile(dummy_file):
        checksum_v = checksum(dummy_file)
        checksum_s_v = checksum_s(open(dummy_file).read())
        checksum_l_v = checksum_s(open(dummy_file).readlines())
        assert checksum_v != ''
        assert checksum_s_v == checksum_v
        assert checksum_l_v == checksum_v

# Generated at 2022-06-11 17:58:02.054903
# Unit test for function checksum
def test_checksum():
    # Create temporary files.
    local_test_file = open('./test_file', 'w+')
    local_test_file.close()
    local_test_file = './test_file'
    with open(local_test_file, 'w') as test_file:
        test_file.write('Hello world\n')

    test_sum = '5eb63bbbe01eeed093cb22bb8f5acdc3'
    checksum_sum = secure_hash(local_test_file)
    if checksum_sum != test_sum:
        print("checksum() failed a unit test.")

    # Cleanup
    os.remove(local_test_file)

# Generated at 2022-06-11 17:58:05.739782
# Unit test for function md5s
def test_md5s():
    ''' basic test that md5s works correctly '''
    if md5s(b'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3':
        return True
    else:
        return False

# Generated at 2022-06-11 17:58:08.312193
# Unit test for function md5
def test_md5():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('bar') == '37b51d194a7513e45b56f6524f2d51f2'

# Generated at 2022-06-11 17:58:15.969576
# Unit test for function md5
def test_md5():
    from ansible.module_utils.basic import AnsibleModule
    data = "Hello"
    module = AnsibleModule(argument_spec=dict(data=dict(type='str')))
    # call function md5 with the data
    result = md5s(module.params['data'])
    # the md5 of Hello is 8b1a9953c4611296a827abf8c47804d7
    expected_results = '8b1a9953c4611296a827abf8c47804d7'
    if result == expected_results:
        print('True')
    else:
        print('False')

test_md5()

# Generated at 2022-06-11 17:58:26.540941
# Unit test for function md5
def test_md5():
    ''' test_md5.py
    Ensure that md5 works correctly on some defined files.
    '''
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestCase(unittest.TestCase):
        def test_md5(self):
            self.assertEqual(md5(__file__), 'b4a4d10a4f1f4db1a8adb14c21aefd7d')

    with patch('ansible.module_utils.basic.md5.md5') as mock_md5:
        with patch.object(mock_md5, 'hexdigest', return_value='test'):
            mock_md5.hexdigest.return_value = 'test'
            test_case = TestCase()

# Generated at 2022-06-11 17:58:35.308119
# Unit test for function md5
def test_md5():
    import tempfile
    with tempfile.NamedTemporaryFile('w', delete=False) as f:
        f.write('hello')
    hello_hash = md5(f.name)
    os.unlink(f.name)
    assert hello_hash == '5d41402abc4b2a76b9719d911017c592'
    try:
        md5s('hello')
    except:
        try:
            del(md5s)
        except:
            pass
        try:
            del(md5)
        except:
            pass
        raise
    try:
        del(md5s)
    except:
        pass
    try:
        del(md5)
    except:
        pass

# Generated at 2022-06-11 17:58:44.374688
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    try:
        testfile = open("testfile.txt", "w")
        testfile.write("There is a cow")
        testfile.close()
        assert(md5("testfile.txt") == "6d5c6f5b6a3a4f4b4e4a6a5c6f5d6d5c")
        os.unlink("testfile.txt")
    except OSError as e:
        raise AssertionError("OS error while creating or opening file {0}".format(e))



# Generated at 2022-06-11 17:58:46.163507
# Unit test for function md5s
def test_md5s():
    data = u'foo'
    assert md5s(data) == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-11 17:58:49.022538
# Unit test for function checksum
def test_checksum():
    filename = "/usr/bin/python"
    hash_c = checksum(filename)
    assert hash_c is not None

    string = "I love Ansible"
    hash_s = checksum_s(string)
    assert hash_s is not None

# Generated at 2022-06-11 17:58:55.005962
# Unit test for function md5s
def test_md5s():
    import os
    filename = os.path.realpath(__file__)
    assert md5s(filename) == '09b61d8d0fafb0e641069af9e2d3d99e'


# Generated at 2022-06-11 17:59:01.064047
# Unit test for function checksum
def test_checksum():
    # Should be sha1
    hash1 = checksum_s("my data")
    assert hash1 == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"

    # Again with string
    str1 = "my data"
    hash1 = checksum_s(str1)
    assert hash1 == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"

    # Again with unicode
    str1 = to_bytes(u"my data")
    hash1 = checksum_s(str1)
    assert hash1 == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"

    # Again with bytearray

# Generated at 2022-06-11 17:59:03.345172
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '5a0db5a5248e10fc6a5b6efc7b11f086'


# Generated at 2022-06-11 17:59:06.219938
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == '9c5e33d8ebd5f7c4122a4b0c4d8f0a32'



# Generated at 2022-06-11 17:59:08.610415
# Unit test for function md5s
def test_md5s():
    assert md5s('helloworld') == 'fc5e038d38a57032085441e7fe7010b0'


# Generated at 2022-06-11 17:59:15.579627
# Unit test for function md5s
def test_md5s():
    ''' Verify that md5s produces correct results for good inputs '''
    assert md5s('pypi') == '6e38f135c3f77cb0cb7f0c5d5b7b5c0f'
    assert md5s('pypi') == '6e38f135c3f77cb0cb7f0c5d5b7b5c0f'
    assert md5s('pypi') != '6e38f135c3f77cb0cb7f0c5d5b7b5c0e'



# Generated at 2022-06-11 17:59:18.310374
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-11 17:59:24.696014
# Unit test for function md5
def test_md5():
    '''test_md5'''

    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s('teststring') == '5a105e8b9d40e1329780d62ea2265d8a'


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 17:59:27.927242
# Unit test for function md5s
def test_md5s():
    m = md5s('foo')
    assert m == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-11 17:59:33.871899
# Unit test for function md5s
def test_md5s():
    # Test with empty input
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    # Test with random input
    import random
    x = random.randint(0, 0xFFFFFFFF)
    y = random.randint(0, 0xFFFFFFFF)
    z = x + y
    assert md5s(str(z)) == '37afb2e0dcd93fb840582c42e1ecc6a4'


# Generated at 2022-06-11 17:59:40.738577
# Unit test for function md5
def test_md5():
    ''' test_md5

    md5 is a backward compatible function for md5s.
    If the host is not FIPS-140-2 compliant (md5 is not available)
    then the md5 should raise a ValueError
    '''
    try:
        md5('/etc/passwd')
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-11 17:59:43.281323
# Unit test for function md5s
def test_md5s():
    assert md5s("blah") == md5s("blah")
    assert md5s("blah") != md5s("blahblah")



# Generated at 2022-06-11 17:59:46.644895
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-11 17:59:51.824671
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5('README.md') == '936a185caaa266bb9cbe981e9e05cb78'


if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-11 17:59:57.845929
# Unit test for function md5
def test_md5():
    filename = '/tmp/foo'
    string = 'foobar'
    file_write = open(filename, 'w')
    file_write.write("foobar")
    md5sum = md5(filename)
    assert md5sum == '3858f62230ac3c915f300c664312c63f'
    file_write.close()
    os.unlink(filename)


# Generated at 2022-06-11 18:00:03.057319
# Unit test for function md5
def test_md5():
    try:
        import hashlib
        assert md5('/bin/chmod') == 'b7ddefb7981fcfd2b832ea0c27c3a3e9'
        assert md5s('Hi, this is a test string.') == '8b30c645b3c3b3e9f287e8d1a4b651c4'
    except ImportError:
        assert _md5 is None



# Generated at 2022-06-11 18:00:13.439093
# Unit test for function md5
def test_md5():
    import os
    import filecmp

    bufsize = 64*1024
    try:
        fd1 = os.open('test1', os.O_RDWR|os.O_CREAT)
        os.write(fd1, 'This is a test')
        os.close(fd1)
        fd2 = os.open('test2', os.O_RDWR|os.O_CREAT)
        os.write(fd2, 'This is a test')
        os.close(fd2)
        assert md5('test1') == md5('test2')
    finally:
        try:
            os.unlink('test1')
            os.unlink('test2')
        except:
            pass

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:00:19.848662
# Unit test for function md5s
def test_md5s():
    assert(md5s('') == 'd41d8cd98f00b204e9800998ecf8427e')
    assert(md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8')
    assert(md5s('foo\n') == '7b502c3a1f48c8609ae212cdfb639dee')
    assert(md5s('{"json": "obj"}') == '7b22696e6572204a73746f223a205b7b22737461676522203a205b5d7d5d7d0a')

# Generated at 2022-06-11 18:00:26.090174
# Unit test for function checksum
def test_checksum():
    if secure_hash('/etc/passwd') is not None:
        assert secure_hash('/etc/passwd').isalnum()
        assert type(secure_hash('/etc/passwd')) is str
    if secure_hash_s('hello world') is not None:
        assert secure_hash_s('hello world').isalnum()
        assert type(secure_hash_s('hello world')) is str

# Generated at 2022-06-11 18:00:36.369532
# Unit test for function checksum
def test_checksum():
    import os
    import shutil
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({'path': os.path.join(tempfile.gettempdir(), 'ansible-test-checksum')})

    # make a temp file
    with open(module.params['path'], 'w') as f:
        f.write('foo')

    hexdigest = module.run_command(("sh", "-c", "cksum %s" % module.params['path']))[1]
    hexdigest = hexdigest.split()[0]
    if hexdigest != checksum(module.params['path']):
        os.remove(module.params['path'])
        module.fail_json(msg="Checksum error")


# Generated at 2022-06-11 18:00:51.181562
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest
    from tempfile import NamedTemporaryFile
    from ansible.module_utils.six import PY3

    class TestChecksum(unittest.TestCase):

        def setUp(self):
            self.data = '0123456789' * 500
            self.f = NamedTemporaryFile('wb', delete=False)

        def tearDown(self):
            self.f.close()
            os.remove(self.f.name)

        @unittest.skipIf(PY3, 'md5 not available on Python3')
        def test_checksum_md5_s(self):
            md5_value = md5s(self.data)
            self.assertTrue(isinstance(md5_value, str))

# Generated at 2022-06-11 18:00:55.554366
# Unit test for function md5s
def test_md5s():
    ''' test md5s()'''
    if not _md5:
        return True
    result = md5s('')
    assert result == 'd41d8cd98f00b204e9800998ecf8427e'

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-11 18:00:58.442131
# Unit test for function md5
def test_md5():
    assert md5('lib/ansible/modules/core/files/file_attributes.py') == '2a7b21765fcfc50e28d4b622cbf46c1b'


# Generated at 2022-06-11 18:01:10.053271
# Unit test for function checksum
def test_checksum():
    # Test with existing file
    result = checksum("file_test_checksum")
    expected = "1f3c6d965d801d17b869e98c0fa6d289b6f1f259"
    assert result == expected
    result = checksum("file_test_checksum", hash_func='md5')
    expected = "adb8f2b350cd9bcf0aeba828ac3699c1"
    assert result == expected

    # Test with empty string
    result = checksum("")
    expected = "da39a3ee5e6b4b0d3255bfef95601890afd80709"
    assert result == expected
    result = checksum("", hash_func='md5')

# Generated at 2022-06-11 18:01:18.228444
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    import tempfile
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write("abc")
    f.close()
    assert md5(fname) == "900150983cd24fb0d6963f7d28e17f72"
    assert checksum(fname) == "a9993e364706816aba3e25717850c26c9cd0d89d"
    os.remove(fname)

# Generated at 2022-06-11 18:01:23.125643
# Unit test for function md5s
def test_md5s():
    # We don't bother setting up a fake environment for this.
    # We just make sure it errors as expected
    try:
        md5s('foo')
        assert False, "md5s() didn't throw an error"
    except ValueError:
        pass

# Generated at 2022-06-11 18:01:25.195909
# Unit test for function md5s
def test_md5s():
    test_string = u"Test string with unicode: один"
    test_string_md5 = u"1fa3aa3fa24e09b41b744962e36b7c83"
    assert md5s(test_string).decode('utf-8') == test_string_md5

# Generated at 2022-06-11 18:01:27.673422
# Unit test for function md5
def test_md5():
    assert(md5s("foobar") == "8843d7f92416211de9ebb963ff4ce28125932878")

# Generated at 2022-06-11 18:01:38.252683
# Unit test for function md5s
def test_md5s():
    from ansible.compat.tests import unittest
    import ansible.utils
    from ansible.utils.hashing import md5, secure_hash_s

    class TestMd5s(unittest.TestCase):

        data = 'teststring'

        def test_md5s_is_sha1(self):
            # md5s should be sha1 until FIPS mode is disabled
            self.assertEqual(md5s(self.data), secure_hash_s(self.data))

    unittest.main(ansible.utils, verbosity=2)

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-11 18:01:46.935666
# Unit test for function md5
def test_md5():
    ''' test md5 function '''

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestUtils(unittest.TestCase):

        @patch('ansible.utils.hashes.md5')
        def test_md5(self, mock_md5):
            mock_md5.return_value = 'test'
            result = md5('filename')
            self.assertEqual('test', result)
            mock_md5.assert_called_once_with('filename', _md5)

# Generated at 2022-06-11 18:01:58.327423
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    # Make sure these calls work
    md5s('')
    md5s('hello')
    md5s('A' * 1024 * 1024)

    # Make sure this does not work with bad input
    try:
        md5s(u'hello')
        raise Exception("No exception thrown")
    except (TypeError, ValueError) as e:
        if not 'must be string or buffer' in str(e) and not 'cannot be decoded' in str(e):
            raise Exception("Unexpected exception type: %s" % e)

    # Check some known values
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5

# Generated at 2022-06-11 18:02:04.551692
# Unit test for function md5s
def test_md5s():
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s('ab') == '187ef4436122d1cc2f40dc2b92f0eba0'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'


# Generated at 2022-06-11 18:02:08.788027
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo'*4096) == '7b22c2ce4f4b3ae8e0e7cd95c292b0f7'


# Generated at 2022-06-11 18:02:13.206073
# Unit test for function md5s
def test_md5s():
    from ansible.compat.tests import unittest

    class TestMd5s(unittest.TestCase):
        def test_basic(self):
            self.assertEqual(md5s('foo'), 'acbd18db4cc2f85cedef654fccc4a4d8')

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-11 18:02:19.100037
# Unit test for function md5
def test_md5():
    '''Test for md5'''
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-11 18:02:22.186158
# Unit test for function md5
def test_md5():
    failed = False
    try:
        md5('test/test-file.md5')
        md5s('test')
    except ValueError:
        failed = True
    assert failed

# Generated at 2022-06-11 18:02:25.820864
# Unit test for function md5s
def test_md5s():
    # Example (from http://en.wikipedia.org/wiki/MD5)
    assert md5s("The quick brown fox jumps over the lazy dog") == \
        "9e107d9d372bb6826bd81d3542a419d6"


# Generated at 2022-06-11 18:02:30.064191
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(u'hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-11 18:02:36.008611
# Unit test for function md5
def test_md5():
    h1 = md5('data.dat')
    h2 = md5s('data')
    assert h1 == 'd41d8cd98f00b204e9800998ecf8427e'
    assert h2 == '1b2cf535f4db26347e4baf8c78a7b90e'

# Generated at 2022-06-11 18:02:39.739596
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-11 18:02:44.973947
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == 'c4d6556682d4a9169f4af87f5c7eea96'


# Generated at 2022-06-11 18:02:48.847996
# Unit test for function md5s
def test_md5s():
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('def') == 'e80b5017098950fc58aad83c8c14978e'

# Generated at 2022-06-11 18:02:51.562112
# Unit test for function md5
def test_md5():
    assert md5("test/files/chmod.py") == 'af58b8a2d7e161a17c52e7bc83f9a366'


# Generated at 2022-06-11 18:02:54.963941
# Unit test for function md5s
def test_md5s():
    import time
    ret = md5s(str(time.time()))
    assert isinstance(ret, str)
    assert ret == md5_s(str(time.time()))


# Generated at 2022-06-11 18:02:58.521654
# Unit test for function md5s
def test_md5s():
   assert md5s('test1') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-11 18:03:02.275176
# Unit test for function md5s
def test_md5s():
    """ unit test for md5s() """
    result = md5s('ansible')
    assert result == 'a4d59a8c05261182f06e2c25ebc82c3d'


# Unit tests for function md5

# Generated at 2022-06-11 18:03:07.343447
# Unit test for function md5
def test_md5():
    test_string = 'The quick brown fox jumps over the lazy dog'
    assert md5s(test_string) == '9e107d9d372bb6826bd81d3542a419d6'
    assert md5(__file__) == '1b75728a2e7f1c2f8b7a0b10f0d7a3b3'


# Generated at 2022-06-11 18:03:13.059146
# Unit test for function md5s
def test_md5s():
    md5s_encrypted = md5s('test')
    assert md5s_encrypted == '098f6bcd4621d373cade4e832627b4f6' or md5s_encrypted == 'e2114d0c35b8e4e4ab0a894b20c747ae'



# Generated at 2022-06-11 18:03:16.052003
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert(md5s('test') == '098f6bcd4621d373cade4e832627b4f6')


# Generated at 2022-06-11 18:03:20.650569
# Unit test for function md5
def test_md5():
    file = './lib/ansible/module_utils/basic.py'
    assert md5(file) == 'b41df92815c5d0373c43a8fe44f8bab5'
    assert secure_hash(file, _md5) == 'b41df92815c5d0373c43a8fe44f8bab5'

# Generated at 2022-06-11 18:03:29.095258
# Unit test for function md5s
def test_md5s():
    ''' this is a sample test, replace with your own '''

    # a known hash to test against
    sample_hash = 'd41d8cd98f00b204e9800998ecf8427e'

    # call the function with a string and compare the output
    # with the known hash
    assert(sample_hash == md5s(''))

# Generated at 2022-06-11 18:03:35.179112
# Unit test for function md5
def test_md5():
    import tempfile
    fd, path = tempfile.mkstemp()
    with open(path, "w") as f:
        f.write("foo")
    assert(md5(path) == "acbd18db4cc2f85cedef654fccc4a4d8")
    os.remove(path)

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:03:39.540209
# Unit test for function checksum
def test_checksum():
    p = 'test_utils_crypto.py'

    if checksum(p) != 'e275f7b08d83d2c7d42eea68f46e278852d0c8aa':
        print("FAIL: test_utils_crypto.py checksum failed")
        return False
    return True

if __name__ == '__main__':
    import sys
    import unittest
    sys.exit(unittest.main())

# Generated at 2022-06-11 18:03:41.375977
# Unit test for function md5s
def test_md5s():
    assert md5s("Hello World") == "ed076287532e86365e841e92bfc50d8c"

# Generated at 2022-06-11 18:03:44.006870
# Unit test for function md5
def test_md5():
    assert md5('/bin/false') == '14e1f0c979b4f38b4a4f91a1ca645e24'

# Generated at 2022-06-11 18:03:48.370312
# Unit test for function md5s
def test_md5s():
    # This is the md5sum of the string "foo"
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s("foo") == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-11 18:03:51.722767
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '6d84e7c9a966b5cfb2d15a9a7b3350b8'
    assert checksum_s('/bin/ls') == checksum('/bin/ls')

# Generated at 2022-06-11 18:04:01.543311
# Unit test for function md5
def test_md5():
    test_string = 'foo'
    md5_test_string = 'acbd18db4cc2f85cedef654fccc4a4d8'
    test_file = './test_md5.tmp'
    md5_test_file = '900150983cd24fb0d6963f7d28e17f72'
    with open(test_file, 'w') as f:
        f.write(test_string)
        f.close()
    assert md5(test_file) == md5_test_file
    assert md5s(test_string) == md5_test_string
    if os.path.isfile(test_file):
        os.remove(test_file)


# Generated at 2022-06-11 18:04:03.720230
# Unit test for function md5
def test_md5():
    assert md5('/usr/bin/python') == '6152a3e48bce6c15511d55b29ebcf9b6'

# Generated at 2022-06-11 18:04:07.003179
# Unit test for function checksum
def test_checksum():
    data = "abcd123"
    chksum_value = secure_hash_s(data)

    if chksum_value is None:
        raise AssertionError()


# Generated at 2022-06-11 18:04:12.439306
# Unit test for function md5s
def test_md5s():
    assert md5s('Hello World') == 'b10a8db164e0754105b7a99be72e3fe5'


# Generated at 2022-06-11 18:04:18.480869
# Unit test for function md5
def test_md5():
    import os
    import random
    import string
    def randhex(nchars):
        return ''.join(random.choice(string.hexdigits) for _ in range(nchars))
    def randfile():
        with open('/tmp/ansible-md5-test-%s' % randhex(8), 'w') as f:
            f.write(randhex(10*1024))
        return f.name

# Generated at 2022-06-11 18:04:24.194269
# Unit test for function md5
def test_md5():
    ''' test md5 function '''

    fn = 'ansible/test/utils/test_hash.py'
    assert(md5(fn) == '68a99d60ae328dbb26c64b7d8ec66cbd')
    assert(md5(fn) == md5(fn))


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:04:30.666099
# Unit test for function md5s
def test_md5s():
    ''' md5s.py: Test for idempotence '''
    import os
    import tempfile

    test_file = tempfile.NamedTemporaryFile()

    for text in ['abcd', 'abcd\n']:
        test_file.seek(0)
        test_file.write(text)
        test_file.flush()

        testmd5s = md5s(text)
        assert testmd5s == md5s(text)

        testmd5 = md5(test_file.name)
        assert testmd5 == md5(test_file.name)

# unit test for function checksum
# Test file is test/files/checksum_test_file

# Generated at 2022-06-11 18:04:36.531840
# Unit test for function md5
def test_md5():
    if _md5:
        assert md5("/dev/null") == "d41d8cd98f00b204e9800998ecf8427e"
        assert md5("/bin/ls") == "8b6c5f6644f3dc7c225f9d0b7c75a3cc"
    else:
        try:
            md5("/bin/ls")
        except ValueError:
            pass
        else:
            assert False, "expected ValueError"



# Generated at 2022-06-11 18:04:42.007907
# Unit test for function md5
def test_md5():
    md5_test = md5s('test')
    assert md5_test == '098f6bcd4621d373cade4e832627b4f6'
    md5_test = md5s('aze123')
    assert md5_test == 'c49b908f95907c016d7b91b8c8f76673'
    md5_test = md5s('aze123!@#')
    assert md5_test == '5a2f0e84d0c5669e06c8bdc9a5a41a4c'

# Generated at 2022-06-11 18:04:45.084436
# Unit test for function checksum
def test_checksum():
    assert checksum(__file__) == '02a7a1f2e07ebde756dbaac0c84928e3f3e3d9d0'
    return True


# Generated at 2022-06-11 18:04:49.930758
# Unit test for function md5
def test_md5():
    ''' tests md5 function '''

    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('world') == '7d793037a0760186574b0282f2f435e7'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:04:55.446688
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == '5d41402abc4b2a76b9719d911017c592'
    assert md5("hello") == '5d41402abc4b2a76b9719d911017c592'


__all__ = ['checksum', 'checksum_s', 'md5s', 'md5']

# Generated at 2022-06-11 18:05:05.221282
# Unit test for function checksum
def test_checksum():
    '''Unit test for function checksum'''
    from ansible import constants as C

    s = 'Hi this is a string'
    c = '%s' % checksum_s(s)
    assert(c == '4428d7a6f8c666a7e6e60b9bfba67b8dbed55a85')
    c2 = '%s' % checksum_s(s, sha1)
    assert(c2 == '4428d7a6f8c666a7e6e60b9bfba67b8dbed55a85')

    if _md5:
        c3 = '%s' % checksum_s(s, _md5)

# Generated at 2022-06-11 18:05:10.943565
# Unit test for function md5s
def test_md5s():
    try:
        md5s('foo')
    except ValueError:
        pass
    else:
        raise AssertionError('md5s() does not work properly')
    md5s('foo', _md5())


# Generated at 2022-06-11 18:05:17.529325
# Unit test for function checksum
def test_checksum():
    if checksum_s(to_bytes(u'spam and eggs')) != u'f1c76f70d5d79ae35e8b847ddeae1a3a55fe3d2f':
        return False
    if checksum_s(to_bytes(u'why\u2019s everybody always picking on me?')) != u'899e8bdc6cf0a6a097c9b822e23f1612e42326b2':
        return False
    return True

# Generated at 2022-06-11 18:05:24.330167
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest

    class TestChecksum(unittest.TestCase):
        def test_normal(self):
            data = b"123"
            self.assertEqual(checksum_s(data), 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3')

        def test_empty(self):
            data = b''
            self.assertEqual(checksum_s(data), 'da39a3ee5e6b4b0d3255bfef95601890afd80709')

        def test_unicode_string(self):
            data = 'ŠĐĆŽćžšđ'

# Generated at 2022-06-11 18:05:30.978515
# Unit test for function md5
def test_md5():
    data = "something"
    result = md5s(data)
    assert(result == "f6a1ddf0f9b9d3b3fed2b97fc661c6e1")

    result = md5("/bin/bash")
    assert(result == "8d777f385d3dfec8815d20f7496026dc")