

# Generated at 2022-06-11 17:55:36.857841
# Unit test for function md5
def test_md5():
    # Check that the two functions return the same values
    a = md5('test/unit/hash.py')
    b = md5s(open('test/unit/hash.py').read())
    assert a == b

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 17:55:47.326107
# Unit test for function checksum
def test_checksum():
    ''' this is a simple unit test for the checksum function '''
    from ansible.utils.unicode import to_unicode

    fpath = "/etc/shadow"
    fname = os.path.basename(fpath)

    # comparison will fail on OSX and FreeBSD as they have different output
    # but that's OK as we're just testing functionality here
    if os.path.exists(fpath) and not os.path.isdir(fpath):
        cs1 = checksum(fpath)
        cs2 = checksum_s(to_unicode(open(fpath, 'rb').read()))
        print("%s: %s" % (fname, cs1))
        print("shadow: %s" % cs2)
    else:
        print("%s: N/A" % (fname))

# Generated at 2022-06-11 17:55:53.707955
# Unit test for function md5
def test_md5():
    x = md5s("asdf")
    if x != '912ec803b2ce49e4a541068d495ab570':
        raise AssertionError("md5s failed")
    x = md5("/etc/passwd")
    if x != 'c21f969b5f03d33d43e04f8f136e7682':
        raise AssertionError("md5 failed")

# Generated at 2022-06-11 17:55:58.541355
# Unit test for function md5
def test_md5():
    assert md5('./lib/ansible/module_utils/facts/system/distribution.py') == '2e9e8a7897e99424d544a34acb66f49e'
    assert md5s('ansible') == '6f8db599de986fab7a21625b7916589c'

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 17:56:03.733116
# Unit test for function md5s
def test_md5s():
    ''' test the md5s function '''

    import re

    md5_pattern = re.compile(r'^[0-9a-z]{32}')
    test = 'foo'

    m = md5s(test)
    assert m is not None
    assert md5_pattern.match(m)

# Generated at 2022-06-11 17:56:13.461255
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest
    from tempfile import mkstemp
    from shutil import rmtree

    class TestChecksum(unittest.TestCase):

        def setUp(self):
            (self.fd, self.filename) = mkstemp()

        def tearDown(self):
            os.close(self.fd)
            os.remove(self.filename)

        def test_checksum_nonexistent_file(self):
            self.assertEqual(None, checksum("/path/to/nowhere"))

        def test_checksum_directory(self):
            os.mkdir(self.filename)
            self.assertEqual(None, checksum(self.filename))
            rmtree(self.filename)


# Generated at 2022-06-11 17:56:15.286198
# Unit test for function md5
def test_md5():
    assert md5(__file__) == md5s(file(__file__).read())



# Generated at 2022-06-11 17:56:17.028925
# Unit test for function checksum
def test_checksum():
    print(checksum("ansible/test/sanity/utils/test_checksum.py"))

# Generated at 2022-06-11 17:56:19.953345
# Unit test for function md5s
def test_md5s():
    assert md5s("foobar") == "3858f62230ac3c915f300c664312c63f"
    assert md5s(u"foobar") == "3858f62230ac3c915f300c664312c63f"


# Generated at 2022-06-11 17:56:30.313677
# Unit test for function checksum
def test_checksum():
    import tempfile
    import textwrap

    # test for when file does not exist
    assert checksum('/opt/obviously/i/do/not/exist') is None
    # test for when file is a directory
    path = tempfile.mkdtemp(prefix='ansible_test_checksum')
    assert checksum(path) is None

    # test for when file exists and has contents
    (fd, path) = tempfile.mkstemp(prefix='ansible_test_checksum')
    f = os.fdopen(fd, 'w')
    txt = 'some text to test the checksum'
    f.write(txt)
    f.close()
    assert checksum(path) != 'd41d8cd98f00b204e9800998ecf8427e'
    os.unlink(path)

# Generated at 2022-06-11 17:56:42.887668
# Unit test for function checksum
def test_checksum():
    assert checksum("/etc/passwd") == "d8e8fca2dc0f896fd7cb4cb0031ba249"
    if _md5:
        assert md5("/etc/passwd") == "c973e4e5fe2afc78e27110a5919dbcbf"
    else:
        try:
            md5("/etc/passwd")
            assert False, 'This test should have failed.'
        except ValueError:
            pass

    # Test checksum_s function
    if _md5:
        assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
        assert md5s("world") == "7d793037a0760186574b0282f2f435e7"
    assert checks

# Generated at 2022-06-11 17:56:45.860068
# Unit test for function md5s
def test_md5s():
    if _md5:
        print("MD5S test")
        print(md5s('test'))
        print(md5s('test'))
        print(md5s('test'))


# Generated at 2022-06-11 17:56:48.303360
# Unit test for function md5s
def test_md5s():
    # The md5 of 'Hello world'
    assert md5s('Hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-11 17:56:56.587225
# Unit test for function checksum
def test_checksum():
    print("=== tests/test_utils_checksum.py:test_checksum() ===")
    print("checksum: " + str(checksum("test_utils.py")))
    print("checksum: " + str(checksum("test_utils_checksum_does_not_exist.py")))
    print("checksum: " + str(checksum("test_utils_checksum.py")))
    print("checksum_s: " + str(checksum_s("test_utils.py")))

if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-11 17:57:08.226861
# Unit test for function checksum
def test_checksum():
    from .unit.module_runner import run_module
    from .unit import skipIf, skipUnless

    skipUnless(md5, "md5 not available")

    # module params
    args = {
        # parameters used by module
        'path': 'CHANGELOG',
        # 'data': 'a test string',
    }

    # Result is 'sha1sum' of CHANGELOG file in working directory
    result = run_module('checksum', args=args)
    assert result['checksum'] == os.popen('sha1sum %s' % args['path']).read().split()[0]

    # Result is None if a file is not present
    args['path'] = 'some_non_exist_file'
    result = run_module('checksum', args=args)
    assert result['checksum'] is None

# Generated at 2022-06-11 17:57:11.796432
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == '4f3622c4b605a4fd858302027aef09d6'
    assert checksum("/bin/nonsense") == None

# Generated at 2022-06-11 17:57:15.926610
# Unit test for function md5
def test_md5():
    md5 = secure_hash(__file__, _md5)
    assert md5 == 'e6d7b6bc03c92f52ae6138b3d48ae2a2'

# Generated at 2022-06-11 17:57:17.960530
# Unit test for function md5
def test_md5():
    assert md5(__file__) == '2e3e3d879f97b7ceaeff2b1f37ccc52d'

# Generated at 2022-06-11 17:57:26.277223
# Unit test for function checksum
def test_checksum():
    import tempfile

    dir_ = tempfile.mkdtemp()

    filename_ = os.path.join(dir_, 'file')
    fd = open(filename_, 'w')
    try:
        fd.write('Hello World')
    finally:
        fd.close()

    assert checksum(filename_) == checksum_s('Hello World')
    assert checksum_s('Hello World') != checksum_s('Hello World!')
    assert checksum_s('Hello World') != 'This is not a proper hash'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:57:28.402784
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-11 17:57:39.781152
# Unit test for function md5
def test_md5():
    assert md5s('this is a string') == '6f9079ac3577c0776e6f60d7209ef4b4'
    assert md5s(u'this is a string') == '6f9079ac3577c0776e6f60d7209ef4b4'


# Generate an md5 checksum of a file
#
# Example:
#    md5('/etc/hosts')
# 
# Returns:
#    The md5 hex digest of the file, or None if the file does not exist
#

# Generated at 2022-06-11 17:57:44.583348
# Unit test for function md5
def test_md5():
    if not _md5:
        return True
    test_string = 'This is a simple string of data'
    test_md5 = md5s(test_string)
    assert test_md5 == 'e8e88a4b4a4b4c219b3a8e3d938f9e68'



# Generated at 2022-06-11 17:57:47.994311
# Unit test for function md5
def test_md5():
    md5string = md5("ansible/module_utils/basic.py")
    assert md5string == "8d88b3e7b06a9b34a8d86e5bd1f20b3c"


# Generated at 2022-06-11 17:57:51.698444
# Unit test for function checksum
def test_checksum():
    f = open('test_checksum', 'w')
    f.write('abc123')
    f.close()
    assert checksum('test_checksum') == '8b1a9953c4611296a827abf8c47804d7'
    os.unlink('test_checksum')

    assert checksum_s('abc123') == '8b1a9953c4611296a827abf8c47804d7'

# Generated at 2022-06-11 17:57:54.389351
# Unit test for function md5s
def test_md5s():
    assert md5s('foobar') == '3858f62230ac3c915f300c664312c63f'



# Generated at 2022-06-11 17:57:57.964880
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-11 17:58:01.630367
# Unit test for function checksum
def test_checksum():
    data = 'hello'
    checksum = secure_hash_s(data)
    checksum2 = secure_hash_s(data)
    assert checksum == checksum2


# Generated at 2022-06-11 17:58:12.352652
# Unit test for function checksum
def test_checksum():
    filename = "tests/units/modules/utils/checksum_test.txt"

    # Test 1: test proper digest when data is present
    assert checksum(filename) == "2ff98a072b00e3ecad3c58a3b4e4ace4c4aa7a97"

    # Test 2: test proper digest when data is not present
    assert checksum("bogusfilename") is None

    # Test 3: test for error with directory name
    try:
        checksum("tests/units")
        assert False
    except AnsibleError:
        assert True

    # Test 4: test digest when the filename has a space in it

# Generated at 2022-06-11 17:58:17.897595
# Unit test for function md5s
def test_md5s():
    data1 = "test"
    data2 = "test2"
    assert(md5s(data1) == "098f6bcd4621d373cade4e832627b4f6")
    assert(md5s(data2) == "ae2b1fca515949e5d54fb22b8ed95575")


# Generated at 2022-06-11 17:58:26.412486
# Unit test for function md5
def test_md5():
    import stat
    import tempfile
    import os
    import shutil
    testpath = tempfile.mkdtemp()
    testfile=testpath + '/test1'
    f = open(testfile,'wb')
    testcontent = 'test1'
    f.write(testcontent)
    f.close()
    aHash = md5(testfile)
    f = open(testfile,'wb')
    testcontent = 'test2'
    f.write(testcontent)
    f.close()
    bHash = md5(testfile)
    assert aHash != bHash
    shutil.rmtree(testpath)


# Generated at 2022-06-11 17:58:38.887375
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('"$@HTTP_PROXY@$"') == 'c5ff5e5afd9ea1fc96c8a30bbbfb47b6'
    assert md5s(u'"$@HTTP_PROXY@$"') == 'c5ff5e5afd9ea1fc96c8a30bbbfb47b6'
    assert md5s('abcd') == 'e2fc714c4727ee9395f324cd2e7f331f'
    assert md5s(u'abcd') == 'e2fc714c4727ee9395f324cd2e7f331f'

# Generated at 2022-06-11 17:58:42.883187
# Unit test for function checksum
def test_checksum():
    # Unit test for function checksum
    assert checksum('/bin/ Ansible') == "672c8f50f1ca24d0f218851d7b8cbeb9f379c1e0"


# Generated at 2022-06-11 17:58:47.111960
# Unit test for function md5s
def test_md5s():
    ''' test_md5s() ...
        >>> md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
        True
    '''
    pass



# Generated at 2022-06-11 17:58:49.992887
# Unit test for function md5
def test_md5():
    ''' md5 should be consistent with md5sum command line '''
    assert md5('lib/ansible/utils/crypto.py') == 'd0f15b3c8b3d422a2c0e626f2b2c8b63'

# Generated at 2022-06-11 17:58:53.859519
# Unit test for function md5s
def test_md5s():
    test_string = 'Hello World'
    digest_string = 'ed076287532e86365e841e92bfc50d8c'
    assert(md5s(test_string) == digest_string)


# Generated at 2022-06-11 17:59:02.906491
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    """
        Test md5 match the md5sum output
    """
    test_directory = tempfile.mkdtemp()
    test_file = tempfile.mktemp(dir=test_directory)
    with open(test_file, 'w') as f:
        f.write('Hello world')

    md5_hash = md5(test_file)
    os.remove(test_file)
    shutil.rmtree(test_directory)
    assert md5_hash == 'b10a8db164e0754105b7a99be72e3fe5'


# Generated at 2022-06-11 17:59:06.072580
# Unit test for function checksum
def test_checksum():
    my_sha1 = checksum("my.file")
    assert my_sha1 == "60fdbaeeb543d278a2dc8a60e0f82a65d48923d5"



# Generated at 2022-06-11 17:59:14.269104
# Unit test for function md5
def test_md5():

    test_string = 'This is a test string'
    f = open('/tmp/ansible_test_md5', 'w')
    f.write(test_string)
    f.close()

    result = md5('/tmp/ansible_test_md5')
    os.unlink('/tmp/ansible_test_md5')
    if result != '8c7a2b948de8b6e8b1d1c1ae3f6c223f':
        raise "MD5 Test Failed"

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 17:59:17.826569
# Unit test for function md5
def test_md5():
    assert(secure_hash('/bin/ls', _md5) == '2e1d13d4cd7051b5a5da5adf509d26b8')



# Generated at 2022-06-11 17:59:21.452857
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('foobar') == '3858f62230ac3c915f300c664312c63f'
    else:
        try:
            md5s('foobar')
            assert False, 'md5s() did not raise an error'
        except ValueError:
            pass

# Generated at 2022-06-11 17:59:28.164112
# Unit test for function md5
def test_md5():
    assert md5('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5('bar') == '37b51d194a7513e45b56f6524f2d51f2'


# Generated at 2022-06-11 17:59:36.916177
# Unit test for function checksum
def test_checksum():
    '''Returns True if function(checksum) passed.'''

    file_data = '/etc/services'
    # file_data will be missing in system without /etc/services file
    try:
        file_data = open(file_data).read()
    except:
        file_data = None

    if not file_data:
        file_data = 'shazam!'

    # 40 character string
    checksum = secure_hash_s(file_data)

    if len(checksum) != 40:
        print("FAILURE: checksum() did not return 40 character string.")
        return False
    else:
        print("SUCCESS: checksum() returned 40 character string.")
        return True

if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-11 17:59:38.620516
# Unit test for function md5s
def test_md5s():
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'


# Generated at 2022-06-11 17:59:42.307739
# Unit test for function md5
def test_md5():
    print('sha1(%s) for %s = %s' % ('testing123', 'testing123', md5s('testing123')))
    print('sha1(%s) for %s = %s' % ('testing123', 'filename.txt', md5('filename.txt')))

# test_md5()

# Generated at 2022-06-11 17:59:52.804076
# Unit test for function checksum
def test_checksum():
    # sha1 checksum
    assert checksum_s('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum('test.py') == '6db8f621bca6b23fe6c533e2f8a68b19'

    # md5 checksum
    if _md5:
        assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
        assert md5('test.py') == '7378f3e79587f7b3ea0dab8b496a9bdf'

# Generated at 2022-06-11 17:59:56.375433
# Unit test for function md5
def test_md5():
    filename = 'yum.conf'
    hashval = checksum(filename)
    assert hashval == 'c5a12d0e1a34c9e9f0bab9e6d7fdedc4'

# Generated at 2022-06-11 17:59:59.061101
# Unit test for function md5s
def test_md5s():
    assert md5s('blah') == 'f6e9f9efd7f011c58e10e7dd2acdac41'


# Generated at 2022-06-11 18:00:01.702788
# Unit test for function md5s
def test_md5s():
    from ansible.utils.crypto import *
    assert md5s("test") == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-11 18:00:10.766184
# Unit test for function md5
def test_md5():
    test_file = 'ansible/test/utils/test_md5.py'
    if os.path.exists(test_file):
        print("the test file is existed")
    else:
        print("the test file is not existed")
    md5sum_value = 'f553524c3efd3f042f3e7a48a032f552'
    if md5(test_file) == md5sum_value:
        print("the md5 is right")
    else:
        print("the md5 is wrong")



# Generated at 2022-06-11 18:00:13.132199
# Unit test for function md5s
def test_md5s():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-11 18:00:20.437751
# Unit test for function md5
def test_md5():
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world\n' * 3000) == 'ea17a0a1a7e0c5723b5565b0d250a699'



# Generated at 2022-06-11 18:00:25.055054
# Unit test for function md5
def test_md5():
    expected_md5 = '5912c3b3f813d1f4f4c4f4bd4a9f8e90'
    md5 = secure_hash_s('foo')
    assert md5 == expected_md5


# Generated at 2022-06-11 18:00:29.984443
# Unit test for function md5
def test_md5():
    data = "abcd"
    print(md5s(data))
    print(secure_hash_s(data, hash_func=_md5))
    data = "efgh"
    print(md5s(data))
    print(secure_hash_s(data, hash_func=_md5))

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:00:31.914704
# Unit test for function checksum
def test_checksum():
    assert checksum(__file__) == checksum_s(open(__file__).read())



# Generated at 2022-06-11 18:00:35.756377
# Unit test for function md5
def test_md5():
    assert md5('/bin/cat') == '110c5b5bd5a1f8c1afcc9e6c75f6dee5'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 18:00:39.517986
# Unit test for function md5s
def test_md5s():
    to_test = {'foo': 'acbd18db4cc2f85cedef654fccc4a4d8',
               'bar': '37b51d194a7513e45b56f6524f2d51f2'}
    for k, v in to_test.items():
        assert v == md5s(k)

# Generated at 2022-06-11 18:00:48.565996
# Unit test for function md5s
def test_md5s():
    sha = md5s('helloworld')
    assert sha == 'fc5e038d38a57032085441e7fe7010b0'
    sha = md5s(u'helloworld')
    assert sha == 'fc5e038d38a57032085441e7fe7010b0'
    sha = md5s('helloworld'.encode('utf-16-le'))
    assert sha == 'fc5e038d38a57032085441e7fe7010b0'


# Generated at 2022-06-11 18:00:53.537209
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-11 18:00:57.206704
# Unit test for function md5
def test_md5():
    test_string = "foo"
    re_string = md5s(test_string)
    print(re_string)
    assert re_string == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-11 18:01:01.080968
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s(b"hello") == "5d41402abc4b2a76b9719d911017c592"
    else:
        try:
            md5s(b"hello")
            assert False
        except ValueError:
            assert True

# Generated at 2022-06-11 18:01:12.421574
# Unit test for function md5
def test_md5():

    # FIPS mode not enabled, md5 is available
    mod = 'from __future__ import (absolute_import, division, print_function)\nfrom ansible.utils.hashing import *\nmd5("foo")'
    rc, stdout, stderr = module_compile_check(mod)
    assert rc == 0
    assert stdout.strip() == 'acbd18db4cc2f85cedef654fccc4a4d8'

    # FIPS mode enabled, md5 not available
    mod = 'from __future__ import (absolute_import, division, print_function)\nfrom ansible.utils.hashing import *\n_md5=None\nmd5("foo")'
    rc, stdout, stderr = module_compile_check(mod)
    assert rc != 0

# Generated at 2022-06-11 18:01:16.838727
# Unit test for function md5
def test_md5():
    import tempfile
    (handle, filename) = tempfile.mkstemp()
    os.write(handle, "Hello World")
    os.close(handle)

    digest = md5(filename)
    digest2 = md5s("Hello World")
    assert digest == digest2

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:01:28.608984
# Unit test for function md5s
def test_md5s():
    import binascii
    assert md5s(b"hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    with open('/usr/share/dict/linux.words') as f:
        test_data = f.read()
        assert md5s(test_data) == "267200bd2c28c5fdfbb71e202b9d8e0f"
    assert md5s(b"\x00") == "93b885adfe0da089cdf634904fd59f71"
    assert md5s(b"\x7f") == "0cc175b9c0f1b6a831c399e269772661"

# Generated at 2022-06-11 18:01:38.176251
# Unit test for function checksum
def test_checksum():
    assert checksum("/dev/null") == "d41d8cd98f00b204e9800998ecf8427e"
    assert checksum("/dev/zero") == "43bd1f7b75e8e93cf8a9c442fb999898"
    assert checksum("/bin/ls") == "e02f845c0d063c6b83a6f1138e0aaed2"
    assert checksum("/bin/cat") == "4314567eb9e9cec475a028a21d8ab8ea"


# Generated at 2022-06-11 18:01:48.889643
# Unit test for function checksum
def test_checksum():
    if not os.path.exists("/bin/ls"):
        print("/bin/ls not found, skipping checksum test")
        return True

    rc, test_sha1 = 1, None
    try:
        test_sha1 = secure_hash("/bin/ls")
        rc, test_md5 = commands.getstatusoutput("which md5sum")
        if rc == 0:
            rc, test_md5 = commands.getstatusoutput("md5sum /bin/ls")
            test_md5 = test_md5.split()[0]
        else:
            rc = 1
    except OSError:
        pass

    if rc != 0:
        print("no md5/sha1 command found, skipping checksum test")
        return True

    # This test vector was generated by yum's own calculate_

# Generated at 2022-06-11 18:01:55.045422
# Unit test for function md5
def test_md5():
    import io

    data = io.BytesIO(b'Some data to hash')
    assert md5(data) == 'f65f7cce79f64199d8a06f96d0f50e92'
    assert md5s('Some data to hash') == 'f65f7cce79f64199d8a06f96d0f50e92'

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:01:56.403801
# Unit test for function checksum
def test_checksum():
    assert checksum('/proc/self/exe') == checksum(__file__)

# Generated at 2022-06-11 18:02:05.805711
# Unit test for function md5s
def test_md5s():
    # When we are not in FIPS mode, md5s should work
    # In FIPS mode, md5s are not usable, and will raise a ValueError
    # The message in that error includes the string "FIPS"

    md5s_worked = False
    try:
        md5s_worked = md5s("test")
    except ValueError as e:
        if "FIPS" in str(e):
            print("md5s is not usable, possibly because we're in FIPS mode")
        else:
            print("error calling md5s: %s" % e)

    if not md5s_worked:
        print("md5s not usable")

# Generated at 2022-06-11 18:02:10.802884
# Unit test for function md5
def test_md5():
    test_filename = '/tmp/test_md5'
    test_file = open(test_filename, 'w')
    test_file.write('test\n')
    test_file.close()
    assert(md5(test_filename) == '098f6bcd4621d373cade4e832627b4f6')
    os.remove(test_filename)

# Generated at 2022-06-11 18:02:15.075264
# Unit test for function md5
def test_md5():
    TESTFILE = '/tmp/ansible-test-file-for-checksum-module'
    with open(TESTFILE, 'wb') as f:
        f.write(b'spam')

    try:
        assert md5(TESTFILE) == 'b1a2a395c61a832b5d3c3c3d3e47b42d'
    finally:
        os.remove(TESTFILE)

# Generated at 2022-06-11 18:03:23.267894
# Unit test for function md5
def test_md5():
    test = md5s('test')
    assert test == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-11 18:03:34.164884
# Unit test for function checksum
def test_checksum():
    import tempfile
    data = "Hello World"
    ret_data = checksum_s(data)
    print ("checksum_s (%s) == (%s)" % (data, ret_data))
    assert ret_data == "0a4d55a8d778e5022fab701977c5d840bbc486d0"

    text_file = tempfile.NamedTemporaryFile()
    text_file.write(data)
    text_file.flush()
    ret_data = checksum(text_file.name)
    print ("checksum (%s) == (%s)" % (text_file.name, ret_data))
    assert ret_data == "0a4d55a8d778e5022fab701977c5d840bbc486d0"

# Generated at 2022-06-11 18:03:37.634211
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo' * 1000) == '7b2e2f91fc55c662bd854bbd63f07b70'



# Generated at 2022-06-11 18:03:47.307958
# Unit test for function checksum
def test_checksum():

    testfile1 = 'foo'
    testfile2 = 'bar'
    testfile3 = 'baz'

    # Create 3 test files
    open(testfile1, 'a').close()  # Empty file
    open(testfile2, 'a').close()
    open(testfile3, 'a').close()

    # Add data in test files
    with open(testfile1, 'w') as f:
        f.write('foo')
    with open(testfile2, 'w') as f:
        f.write('bar')

    # Test valid files
    assert(checksum(testfile1) == checksum(testfile1))
    assert(checksum(testfile2) == checksum(testfile2))

    # Test valid and invalid files

# Generated at 2022-06-11 18:03:52.774193
# Unit test for function md5
def test_md5():
    import tempfile
    (fd, name) = tempfile.mkstemp()
    os.write(fd, 'This is a test')
    os.close(fd)
    try:
        assert md5(name) == '5bf5a5a5a5a5a5a5a5a5a5a5a5a5a5a5'
    finally:
        os.remove(name)



# Generated at 2022-06-11 18:03:55.917795
# Unit test for function md5s
def test_md5s():
    assert md5s('Hello World') == '65a8e27d8879283831b664bd8b7f0ad4'


# Generated at 2022-06-11 18:03:58.785568
# Unit test for function md5s
def test_md5s():
    if md5s('test') == '098f6bcd4621d373cade4e832627b4f6':
        return True
    else:
        return False


# Generated at 2022-06-11 18:04:09.600302
# Unit test for function checksum
def test_checksum():
    filename = __file__

    if not os.path.isfile(filename):
        raise Exception("Unable to run tests on %s as it is not a file" % filename)

    assert __name__ == os.path.basename(filename).rstrip('.py')

    sha1sum = secure_hash(filename)
    print("sha1sum: %s" % sha1sum)
    sha1sum = secure_hash(filename, hash_func=sha1)
    print("sha1sum: %s" % sha1sum)
    assert sha1sum == secure_hash('checksum.py')

    assert __name__ == os.path.basename(filename).rstrip('.py')

    md5sum = md5(filename)
    print("md5sum: %s" % md5sum)

   

# Generated at 2022-06-11 18:04:14.973039
# Unit test for function md5
def test_md5():
    if _md5:
        # This should work
        assert md5("/dev/null") == 'd41d8cd98f00b204e9800998ecf8427e'
    else:
        # This should fail
        try:
            md5("/dev/null")
        except ValueError as e:
            assert e.args[0] == 'MD5 not available.  Possibly running in FIPS mode'
        else:
            assert False, "Expected md5() to fail"



# Generated at 2022-06-11 18:04:21.563603
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    data = 'abc'
    expected = '900150983cd24fb0d6963f7d28e17f72'
    actual = md5s(data)
    if actual != expected:
        raise Exception('md5s returned unexpected checksum: actual=%s expected=%s' % (actual, expected))


# Generated at 2022-06-11 18:04:28.984505
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s(u'hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-11 18:04:33.041818
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5s("") == "d41d8cd98f00b204e9800998ecf8427e"

# Generated at 2022-06-11 18:04:40.450799
# Unit test for function md5s
def test_md5s():
    if not _md5:
        print('SKIPPED md5s() test due to lack of md5')
        return
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('testd') == '0f8ec3a3a3b6a41c0daf1ed28a73985c'
    assert md5s('testda') == '6c0f2d4d4a9e56cb43c20e36ee40d6a0'
    assert md5s('testing') == 'ae2b1fca515949e5d54fb22b8ed95575'

# Generated at 2022-06-11 18:04:41.464741
# Unit test for function md5
def test_md5():
    md5("")


# Generated at 2022-06-11 18:04:45.278481
# Unit test for function md5
def test_md5():
    '''
    Test md5 function
    '''
    md5 = md5s('test')
    if md5 != '098f6bcd4621d373cade4e832627b4f6':
        raise ValueError("md5 not match")

# Generated at 2022-06-11 18:04:47.136922
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '0a3ae7f97ccab95fcd0b35d11c0d7a6e'

# Generated at 2022-06-11 18:04:55.785281
# Unit test for function md5s
def test_md5s():
    md5s_ansible = md5s('ansible')
    if md5s_ansible != '78cfc5e5d5d9e3b3f5b11c5b12f07d27':
        print("md5_s('ansible') failed: md5s_ansible=%s" % md5s_ansible)
    else:
        print("md5_s('ansible') success: md5s_ansible=%s" % md5s_ansible)


# Generated at 2022-06-11 18:04:59.455030
# Unit test for function md5
def test_md5():
    '''
    Function that tests the md5 function with a dummy file
    '''
    assert md5('/tmp/test_file123456789') is None
    assert md5('/tmp') is None
    assert len(md5s('Hello world')) == 32


# Generated at 2022-06-11 18:05:05.376380
# Unit test for function md5s
def test_md5s():
    # Linux
    assert secure_hash_s(b'hello') == md5s(b'hello')
    # Mac OS X
    #assert secure_hash_s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    # Windows
    #assert secure_hash_s(b'hello') == '8b1a9953c4611296a827abf8c47804d7'


# Generated at 2022-06-11 18:05:09.675683
# Unit test for function md5
def test_md5():
    import tempfile
    import filecmp
    try:
        (fd, fn) = tempfile.mkstemp()
        f = open(fn, 'wb')
        f.write('Hello')
        f.close()
        assert md5(fn) == '8b1a9953c4611296a827abf8c47804d7'
    finally:
        os.unlink(fn)



# Generated at 2022-06-11 18:05:15.570911
# Unit test for function md5s
def test_md5s():
    string = 'string'
    md5sum = md5s(string)
    assert md5sum == '8a96f88a2e3c3b8e806fabbacd087a1d'

# Generated at 2022-06-11 18:05:17.987986
# Unit test for function md5s
def test_md5s():
    assert md5s('Hello World') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-11 18:05:24.542834
# Unit test for function checksum
def test_checksum():
    b_file = 'test/support/test_checksum.txt'
    a_sha1_digest = '5b9c567e5422f02a8351acdba0f0b96d63b86e34'
    b_sha1_digest = 'f06f6c823dceb7c2e66e800a984b4dc4d4e6d67b'
    a_md5_digest = '6f8db599de986fab7a21625b7916589c'
    b_md5_digest = '0f2e2cb06a4e8c7ad97a4d9a7a9b9158'


# Generated at 2022-06-11 18:05:31.405933
# Unit test for function md5
def test_md5():
    test_file = 'test_md5'
    test_data = 'This is a new file'
    with open(test_file, 'w') as f:
        f.write(test_data)
    assert md5(test_file) == md5s(test_data)
    os.remove(test_file)

if __name__ == '__main__':
    test_md5()