

# Generated at 2022-06-11 17:55:44.024768
# Unit test for function checksum
def test_checksum():
    # Test files
    files = [
        'testlib/ansible/test_utils/test_checksum/test',
        'testlib/ansible/test_utils/test_checksum/test.dir',
        'testlib/ansible/test_utils/test_checksum/no_exist',
        'testlib/ansible/test_utils/test_checksum/test_dir/test1'
    ]


# Generated at 2022-06-11 17:55:50.014084
# Unit test for function checksum
def test_checksum():
    filename = '/tmp/ansible_test/foo.txt'
    checksum = secure_hash(filename)
    assert checksum == '7befc076a9e6d9c1fb3d7b2f2d0f7aa8', \
        "Unable to calculate checksum for test file %s" % filename
    checksum = secure_hash(filename, hash_func=_md5)
    assert checksum == '7fa8c9645e199edc7035bd41ebd7c40a', \
        "Unable to calculate md5 checksum for test file %s" % filename
    # Clean up
    os.system('rm -rf /tmp/ansible_test')

# Generated at 2022-06-11 17:55:52.967202
# Unit test for function md5
def test_md5():
    assert md5('library/copy.py') == '047f148c6dde50a78d762509a2a58b8a'


# Generated at 2022-06-11 17:55:57.958714
# Unit test for function md5
def test_md5():
    import tempfile
    filename = tempfile.mktemp()

    # Create file with contents of 'data'
    f = open(filename, 'wb')
    try:
        f.write('data')
        f.close()

        # Check it has right md5 checksum
        assert md5(filename) == '1bc29b36f623ba82aaf6724fd3b16718'
    finally:
        if os.path.exists(filename):
            os.remove(filename)

# Generated at 2022-06-11 17:56:06.470011
# Unit test for function md5
def test_md5():
    # If a file doesn't exist
    assert not md5('/tmp/does_not_exist')

    import tempfile
    fd, fpath = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('I am just a piece of text')
    f.close()

    # Does this match the output of md5sum <file>?
    assert md5(fpath) == '4f4d44a2cc4c4e3d9a9b6fdbdd2b3fe1'

    os.remove(fpath)

# Generated at 2022-06-11 17:56:18.003983
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest

    class TestChecksum(unittest.TestCase):
        def setUp(self):
            self.data = 'Hello World!'
            self.filename = '~/ansible/test/utils/shatest'

        def test_checksum_s(self):
            self.assertEqual(checksum_s(self.data), '2ef7bde608ce5404e97d5f042f95f89f1c232871')
            self.assertEqual(checksum_s(self.data, _md5), 'ed076287532e86365e841e92bfc50d8c')


# Generated at 2022-06-11 17:56:27.997388
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s(u'') == u'd41d8cd98f00b204e9800998ecf8427e'
        assert md5s(u'foobar') == u'3858f62230ac3c915f300c664312c63f'
        assert md5s(u'foobar\n') == u'24982bdb1f7cb8e4c311b7d4b3f3b731'
        assert md5s(u'foobar\r\n') == u'77ce95d1ab2ac1b9f8d97f69d7d9b0af'

# Generated at 2022-06-11 17:56:35.157796
# Unit test for function md5
def test_md5():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello\nworld') == 'f8cde0ffe1c7f37bef5eb7273de040b2'

# Generated at 2022-06-11 17:56:43.662376
# Unit test for function checksum
def test_checksum():
    ''' test_checksum is used to test that checksum properly returns the same value on different systems
        when using the same path. '''

    # A known file created by mktemp
    filename = "/tmp/ansible-tmp-1424913676.22-31172414245472"
    if not os.path.exists(filename):
        raise Exception("The file %s does not exist!" % filename)
    elif os.path.isdir(filename):
        raise Exception("The path %s is a directory!" % filename)

    # Perform checksum
    actual_checksum = checksum(filename)
    if actual_checksum == None:
        raise Exception("The files checksum returned None!")
    expected_checksum = 'e7ad8f8ab118b7c59c052dd98d7b8e2c'

# Generated at 2022-06-11 17:56:51.423347
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest

    class TestChecksum(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_checksum_s(self):
            self.assertEqual(checksum_s('hello'), 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d')
            data = 'hello'
            data = data.encode()
            self.assertEqual(checksum_s(data), 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d')

        def test_checksum(self):
            import tempfile
            (fd, filename) = tempfile.mkstemp()
            os.close

# Generated at 2022-06-11 17:56:57.656320
# Unit test for function md5
def test_md5():
    assert md5s("foobar") == "3858f62230ac3c915f300c664312c63f"


# Generated at 2022-06-11 17:56:58.954099
# Unit test for function checksum
def test_checksum():
    assert checksum('f_hash_test.py') is not None

# Generated at 2022-06-11 17:57:04.994152
# Unit test for function checksum
def test_checksum():
    ''' test checksum function '''
    test1 = "This is a test"
    test2 = "This is a second test"
    test3 = "12345"
    test4 = ""

    assert checksum_s(test1) == "156f55bd86caca2c9f079e1aae784ce26c0d7e3d"
    assert checksum_s(test2) == "78bbd70e22c29a24a586c1b8b1828531d2a539ac"
    assert checksum_s(test3) == "6f8db599de986fab7a21625b7916589c"
    # Empty string is not the same as no string

# Generated at 2022-06-11 17:57:11.846932
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import cStringIO

    def test_checksum_binary(filename, b_data):
        with patch('ansible.utils.checksum.open', create=True) as mock_open:
            mock_open.return_value = cStringIO(b_data)
            ret = checksum(filename)
        return ret

    def test_checksum_s_binary(b_data):
        ret = checksum_s(b_data)
        return ret

    input_string = '{"json": "data"}'
    input_string_as_bytes = b'{"json": "data"}'
    filename = 'fake_file'

    # check with an as

# Generated at 2022-06-11 17:57:16.753640
# Unit test for function md5s
def test_md5s():
    assert "900150983cd24fb0d6963f7d28e17f72" == md5s("abc")

if __name__ == '__main__':
    import sys
    import doctest
    sys.exit(doctest.testmod()[0])

# Generated at 2022-06-11 17:57:22.632847
# Unit test for function checksum
def test_checksum():
    assert checksum_s('data') == '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12'
    assert checksum_s(u'data') == '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12'
    assert checksum(os.path.join(os.path.dirname(__file__), '../test/test_utils/checksum_test_file')) == 'f0ef7081fe1a7c4fbb85bdd5c9d3fbc99a87efaf'

# Generated at 2022-06-11 17:57:25.536946
# Unit test for function md5s
def test_md5s():
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'

# Generated at 2022-06-11 17:57:32.752983
# Unit test for function md5s
def test_md5s():
    assert md5s(b"") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5s(b"a") == "0cc175b9c0f1b6a831c399e269772661"
    assert md5s(b"abc") == "900150983cd24fb0d6963f7d28e17f72"
    assert md5s(b"message digest") == "f96b697d7cb7938d525a2f31aaf161d0"
    assert md5s(b"abcdefghijklmnopqrstuvwxyz") == "c3fcd3d76192e4007dfb496cca67e13b"

# Generated at 2022-06-11 17:57:38.899887
# Unit test for function md5
def test_md5():
    def test_md5(self):
        '''Simple test for the md5 function'''
        result = md5(__file__)
        assert result == 'e5e5204dfc6434b959bfcc7f54d6eb40'

        result = md5s('hello world')
        assert result == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-11 17:57:45.157447
# Unit test for function md5s
def test_md5s():
    if not _md5:
        print('MD5 not available.  Possibly running in FIPS mode')
        return

    test_data = 'This is a test string'
    md5s_result = md5s(test_data)
    md5_result = md5(test_data)
    if md5s_result != md5_result:
        print('Unexpected result of md5s')
        print('    md5s = %s' % md5s_result)
        print('    md5 = %s' % md5_result)
    else:
        print('Md5s function test passed')

# Generated at 2022-06-11 17:57:53.535151
# Unit test for function md5s
def test_md5s():
    assert md5s(b"this is just a simple test") == '0e1b495315dc8d0c906ac92f3024f2ed'



# Generated at 2022-06-11 17:57:58.176546
# Unit test for function checksum
def test_checksum():
    assert checksum("test/files/test.py") == '1f9d60eee3775f5b11dedd0b7a38f87a87ac8c85'


# Generated at 2022-06-11 17:58:01.275094
# Unit test for function checksum
def test_checksum():
    digest = checksum(__file__)
    assert digest == 'b060e034e00f742a61a1b7160a5989ad2ca7f348'


# Generated at 2022-06-11 17:58:05.693403
# Unit test for function md5
def test_md5():
    test_data = "foobar"
    test_md5 = md5s(test_data)
    assert test_md5 == "3858f62230ac3c915f300c664312c63f"

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 17:58:15.225181
# Unit test for function checksum
def test_checksum():
    assert checksum('test/support/files/file_md5_1.txt') == '3a3a3f7cd1e2ea64a7455b0afc1a7a42'
    assert checksum('test/support/files/file_md5_2.txt') == 'c5a5b5f5c5d5e5f5f5f5f5f5f5f5f5f5'
    assert checksum('test/support/files/file_md5_3.txt') == '8a8b8c8d8e8f8f8f8f8f8f8f8f8f8f8f'


# Generated at 2022-06-11 17:58:20.642928
# Unit test for function md5s
def test_md5s():
    assert secure_hash_s('test1234') == '6f8db599de986fab7a21625b7916589c'
    assert secure_hash_s('test1234', sha1) == '7c222fb2927d828af22f592134e8932480637c0d'



# Generated at 2022-06-11 17:58:22.881939
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == '6b8e947907d8e4bcf3091c01460f8c64'

# Generated at 2022-06-11 17:58:31.359495
# Unit test for function checksum
def test_checksum():
    checksum_filename = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'data', 'test_checksum.data')
    checksum_data = open(checksum_filename, 'rb').read()
    assert checksum(checksum_filename) == '47b29d7f4c79a2d7e1c8b75af7a5cce9f933dacf'
    assert checksum_s(checksum_data) == '47b29d7f4c79a2d7e1c8b75af7a5cce9f933dacf'
    assert md5(checksum_filename) == '6ed3b3f7cf6c0f96dcc63f6a380fbed2'
    assert md5s

# Generated at 2022-06-11 17:58:40.638637
# Unit test for function checksum
def test_checksum():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('foo' * 1000) == '39c8f1b633cba0e2cfabc5a45ec5a5b5'
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'

# Generated at 2022-06-11 17:58:51.586121
# Unit test for function checksum
def test_checksum():
    import os
    import uuid

    tmpfile = "/tmp/%s" % uuid.uuid4()
    open(tmpfile, 'a').close()

    cksum = checksum(tmpfile)

    assert cksum == checksum(tmpfile), "%s %s" % (cksum, checksum(tmpfile))

    open(tmpfile, 'w').close()

    cksum = checksum(tmpfile)

    assert cksum == checksum(tmpfile), "%s %s" % (cksum, checksum(tmpfile))

    open(tmpfile, 'w').write('test file')

    cksum = checksum(tmpfile)

    assert cksum == checksum(tmpfile), "%s %s" % (cksum, checksum(tmpfile))

    os.unlink(tmpfile)

# Generated at 2022-06-11 17:58:58.401422
# Unit test for function md5
def test_md5():
    '''test_md5: returns a string of length 32 if successful, otherwise 1.'''
    if len(md5('/etc/passwd')) == 32:
        return 0
    else:
        return 1


# Generated at 2022-06-11 17:59:05.958633
# Unit test for function checksum
def test_checksum():
    import tempfile
    from ansible.compat.tests import unittest
    from ansible.compat.tests import skipIf

    TEST_DATA = to_bytes("This is a test")

    class TestChecksum(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.tf = tempfile.NamedTemporaryFile(dir=self.tmpdir)
            self.tf.write(TEST_DATA)
            self.tf.flush()

        def tearDown(self):
            self.tf.close()
            os.removedirs(self.tmpdir)


# Generated at 2022-06-11 17:59:15.757563
# Unit test for function md5s
def test_md5s():
    ''' md5s() should return correct value '''

    import random
    import string
    import unittest

    try:
        from hashlib import md5
    except ImportError:
        from md5 import md5

    class TestMd5s(unittest.TestCase):

        def setUp(self):
            self.test_string = ''.join([random.choice(string.letters + string.digits) for n in range(20)])
            self.expected_md5 = md5(self.test_string).hexdigest()

        def test_md5s(self):
            ''' md5s() should return correct value '''
            self.assertEqual(md5s(self.test_string), self.expected_md5)

    unittest.main(verbosity=0)


# Generated at 2022-06-11 17:59:18.357721
# Unit test for function md5s
def test_md5s():
    assert( md5s("foo") == 'acbd18db4cc2f85cedef654fccc4a4d8' )

# Generated at 2022-06-11 17:59:22.404723
# Unit test for function md5s
def test_md5s():
    import unittest

    class TestStringMethods(unittest.TestCase):
        def test(self):
            self.assertEqual(secure_hash_s('test'), md5s('test'))

    unittest.main()

# Generated at 2022-06-11 17:59:28.257595
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test ') == 'cfe105f7462e56f60b0ff47f2a2a9e40'

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 17:59:35.171998
# Unit test for function md5
def test_md5():

    # Create a file
    test_file = 'test_file'
    f = open(test_file, 'w')
    f.write('This is the test file content')
    f.close()

    # Get md5 checksum
    md5_checksum = md5(test_file)
    
    # Cleanup
    os.remove(test_file)

    # Check if the md5 checksum is correct

# Generated at 2022-06-11 17:59:40.418704
# Unit test for function md5
def test_md5():
    # Prepare a test file
    with open('/tmp/test_md5.txt', 'wb') as f:
        content = b"123456789\n"
        f.write(content)
        f.close()

    assert md5('/tmp/test_md5.txt') == '3858f62230ac3c915f300c664312c63f'
    assert md5s(content) == '3858f62230ac3c915f300c664312c63f'


# Generated at 2022-06-11 17:59:50.183661
# Unit test for function checksum
def test_checksum():
    # Check with a string
    s = "hello world!"
    expected = "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"
    result = checksum_s(s)
    assert result == expected

    # Check with a file
    testfile = os.path.join(os.path.dirname(__file__), 'test_utils.py')
    expected = "e8a3e95a91265e7a01a71c2bccd6e1a6a7f6a1ea"
    result = checksum(testfile)
    assert result == expected

# Generated at 2022-06-11 17:59:57.287857
# Unit test for function md5
def test_md5():
    '''
    unit test for function md5
    '''
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    for i in range(5):
        filename = os.path.join(tmpdir, "file%d" % i)
        fh = open(filename, "w")
        fh.write("some data %d" % i)
        fh.close()

    for i in range(5):
        filename = os.path.join(tmpdir, "file%d" % i)
        if i < 3:
            # test md5
            assert md5(filename) == md5s(file(filename).read())
        else:
            # the last two files are directories
            assert md5(filename) == None
    shutil.rmtree(tmpdir)


# Generated at 2022-06-11 18:00:00.696675
# Unit test for function md5s
def test_md5s():
    assert(False)
    pass



# Generated at 2022-06-11 18:00:04.032035
# Unit test for function md5
def test_md5():
    assert md5s("ansible") == "bebf4c3d4e4f0de2e48f05cab7a9acaf"
    assert md5("setup.py") == "d831aebbdfa6068b5cf0e8f5d07d87c5"
    assert False



# Generated at 2022-06-11 18:00:09.320767
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello\r\n') == 'fcbcde6a9c9e2d72222664dfa053034b'

# Generated at 2022-06-11 18:00:13.032822
# Unit test for function md5
def test_md5():
    returned_md5 = md5('/etc/ansible/hosts')
    known_good_md5 = '83b4be34a1dfe6d14031c8f3a3a5e541'
    assert returned_md5 == known_good_md5

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:00:20.513840
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s("hello world") == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s("hello world\n") == 'e59ff97941044f85df5297e1c302d260'
    assert md5s("\n") == '93b885adfe0da089cdf634904fd59f71'
    assert md5s("\n\n") == '619a1f1d93c7efbc6990a097c19291a9'
    assert md5s("1"*1000000) == '1d29e65b30db410bbe2aae902efdee38'

# Generated at 2022-06-11 18:00:24.328378
# Unit test for function md5
def test_md5():
    string = 'hi'
    assert md5s(string) == md5_s(string)
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# Generated at 2022-06-11 18:00:26.918055
# Unit test for function md5s
def test_md5s():
    assert md5s('test string') == '9d4e1e23bd5b727046a9e3b4b7db57bd8d6ee684'

# Generated at 2022-06-11 18:00:29.888970
# Unit test for function md5
def test_md5():
    filename = '/etc/group'
    m = md5(filename)
    assert m == 'bdd1b87a9b946d2bacb52c75b14e87d8'


# Generated at 2022-06-11 18:00:33.428145
# Unit test for function md5s
def test_md5s():

    if _md5:
        if md5s('Hello, world') != '65a8e27d8879283831b664bd8b7f0ad4':
            raise Exception('md5s function failed unit test')



# Generated at 2022-06-11 18:00:35.613015
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-11 18:00:43.463976
# Unit test for function md5
def test_md5():

    for hash_fn in (md5, md5s):
        h = hash_fn('hello')
        assert h == '5d41402abc4b2a76b9719d911017c592'


if __name__ == '__main__':
    # Simulate ansible-test sanity --test
    import pytest
    pytest.main(['-qq', __file__])

# Generated at 2022-06-11 18:00:52.106449
# Unit test for function checksum
def test_checksum():
    import tempfile
    tmp = tempfile.mktemp()

    # test that checksum works on an empty file
    open(tmp, 'w').close()
    assert checksum(tmp) == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'

    # test that checksum works on a file with a single line
    open(tmp, 'w').write('foo\n')
    assert checksum(tmp) == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'

    os.unlink(tmp)

# Generated at 2022-06-11 18:00:55.461092
# Unit test for function md5
def test_md5():
    import tempfile
    fd, fn = tempfile.mkstemp()
    os.write(fd, b'hello')
    os.close(fd)
    os.unlink(fn)


# Generated at 2022-06-11 18:00:58.419674
# Unit test for function md5s
def test_md5s():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') != '098f6bcd4621d373cade4e832627b4f7'

# Generated at 2022-06-11 18:01:00.734262
# Unit test for function md5s
def test_md5s():
    assert (md5s('abcdefg')) == '7ac66c0f148de9519b8bd264312c4d64'

# Generated at 2022-06-11 18:01:03.798590
# Unit test for function md5
def test_md5():
    print(md5s('abc'))


if __name__ == "__main__":
    test_md5()

# Generated at 2022-06-11 18:01:06.549014
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-11 18:01:10.872185
# Unit test for function md5s
def test_md5s():
    data = 'test'
    result = md5s(data)
    assert result == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-11 18:01:20.822346
# Unit test for function md5
def test_md5():
    test_string = "I am a string"
    test_file = "/tmp/test_file"
    try:
        with open(test_file, 'w') as f:
            f.write(test_string)
            f.close()

        print("md5(%s) = %s" % (test_string, md5s(test_string)))
        print("md5(%s) = %s" % (test_string, md5(test_string)))
        print("md5(%s) = %s" % (test_file, md5(test_file)))
    except IOError as e:
        print ("Error: %s" % e)
    finally:
        os.remove(test_file)

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:01:27.037905
# Unit test for function md5s
def test_md5s():
    h1 = md5s('foo')
    assert h1 == 'acbd18db4cc2f85cedef654fccc4a4d8'
    h2 = md5s('bar')
    assert h2 == '37b51d194a7513e45b56f6524f2d51f2'

# Generated at 2022-06-11 18:01:32.732510
# Unit test for function md5s
def test_md5s():
    value = md5s("abc")
    assert value == "900150983cd24fb0d6963f7d28e17f72"


# Generated at 2022-06-11 18:01:35.824913
# Unit test for function md5
def test_md5():
    d1 = md5s('Hello World')
    d2 = md5s('Goodbye World')
    assert d1 != d2



# Generated at 2022-06-11 18:01:43.725756
# Unit test for function md5
def test_md5():
    data = b'foobar'
    digest_a = md5s(data)
    digest_b = md5s(data)
    assert digest_a == digest_b == '3858f62230ac3c915f300c664312c63f'

try:
    import hmac
    # The hmac digest algorithm must match with the algorithm in ShellModule.hmac() method
    hmacs = hmac.new
except ImportError:
    hmacs = None


# Generated at 2022-06-11 18:01:48.451682
# Unit test for function md5
def test_md5():
    import tempfile
    temp = tempfile.NamedTemporaryFile(mode='w+', delete=False, suffix='.md5')
    temp.write('dummy')
    temp.close()
    hash = md5(temp.name)
    assert hash == '0cc175b9c0f1b6a831c399e269772661'
    os.unlink(temp.name)

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:01:57.146894
# Unit test for function md5s
def test_md5s():
    from ansible.module_utils.basic import AnsibleModule
    # 1. Test that md5s raises an exception when FIPS mode is enabled
    try:
        _md5 = None
        md5s("testdata")
        raise AssertionError("MD5 should raise an exception when FIPS mode is enabled")
    except ValueError as e:
        assert e.message == 'MD5 not available.  Possibly running in FIPS mode'
    # 2. Test that md5s works when FIPS mode is disabled
    try:
        _md5 = md5
        assert md5s("testdata") == "5a105e8b9d40e1329780d62ea2265d8a"
    finally:
        _md5 = None


# Generated at 2022-06-11 18:02:06.157099
# Unit test for function md5
def test_md5():
    file1 = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'file_for_md5')
    file2 = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'file_for_md5_2')

    # test file exists
    assert(os.path.isfile(file1))

    # test md5
    assert(md5(file1) == 'e00a0c5d8232e7920c47f5ef5a224b08')
    assert(md5(file2) is None)



# Generated at 2022-06-11 18:02:14.933691
# Unit test for function checksum
def test_checksum():
    ''' test_checksum function '''

    from ansible.compat.tests import unittest
    from ansible.module_utils.basic import AnsibleModule

    good_return = {"changed": False, "filename": "foo", "checksum": "8b6655cee99a2e5957f20b6c0af7a31d", "msg": "all fine"}
    filename = 'dummy.txt'
    is_running_with_fips = 'openssl_fips' in os.environ
    if is_running_with_fips:
        f = open(filename, 'w')
        f.write('Hello World')
        f.close()

# Generated at 2022-06-11 18:02:23.031904
# Unit test for function checksum
def test_checksum():
    try:
        # make sure we can generate a valid sha1 checksum
        assert checksum('/etc/passwd') is not None

        # make sure we can generate a valid sha1 checksum passing the result of a read()
        fd = open('/etc/passwd', 'r')
        assert checksum_s(fd.read()) is not None
        fd.close()
    except AssertionError:
        # on windows, this might not work
        # because python can not read the /etc/passwd file
        pass

# Generated at 2022-06-11 18:02:26.780763
# Unit test for function checksum
def test_checksum():
    assert checksum_s('a') == checksum('test/utils/checksum/a')
    assert checksum('test/utils/checksum/a') == '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8'

# Generated at 2022-06-11 18:02:32.421820
# Unit test for function md5s
def test_md5s():
    str = "example for test string"
    if md5s(str) != 'ae97f929a8a0a6a7cbfdbfbd547c1b28':
        raise Exception("md5sum failed")


if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-11 18:02:37.641745
# Unit test for function md5
def test_md5():
    result = md5("/tmp/test_md5")
    assert result == None

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:02:47.377177
# Unit test for function checksum
def test_checksum():
    import tempfile
    from ansible.module_utils._text import to_bytes

    fd, fname = tempfile.mkstemp()
    f = os.fdopen(fd, "wb")
    try:
        f.write(to_bytes('test1', errors='surrogate_or_strict'))
        f.close()

        c1 = checksum(fname)

        fd, fname = tempfile.mkstemp()
        f = os.fdopen(fd, "wb")
        try:
            f.write(to_bytes('test2', errors='surrogate_or_strict'))
            f.close()

            c2 = checksum(fname)
        finally:
            os.remove(fname)

        assert c1 != c2
    finally:
        os.remove

# Generated at 2022-06-11 18:02:50.616004
# Unit test for function md5
def test_md5():
    key = 'hello'
    value = md5s(key)
    assert value == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-11 18:02:55.617035
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    data = 'foobar'
    digest = _md5()
    digest.update(to_bytes(data, errors='surrogate_or_strict'))
    hash = digest.hexdigest()
    assert(hash == md5s(data))


# Generated at 2022-06-11 18:03:07.229051
# Unit test for function checksum
def test_checksum():
    import tempfile

    tstamp = 'Wed Mar  2 14:39:09 UTC 2016'

    fd, fname = tempfile.mkstemp()
    os.close(fd)
    try:
        os.utime(fname, None)
        assert(checksum(fname) == '1b1c98b0d0c8c25d97f931a61cbb0d0b8f6e69ab')
        with open(fname, 'w') as fh:
            fh.write(tstamp)
        assert(checksum(fname) == '7fce76d6c0cb2cb1585c4bd4580a8277cbbf6e4a')
    finally:
        os.remove(fname)


# Generated at 2022-06-11 18:03:16.171569
# Unit test for function md5
def test_md5():
    try:
        md5('/tmp/to/some/file/that/does/not/exist')
        assert False
    except ValueError:
        pass

    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello world') == '5EB63BBBE01EEED093CB22BB8F5ACDC3'
    assert md5('/dev/null') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-11 18:03:20.063065
# Unit test for function md5
def test_md5():
    # needs to be name 'test' because this file is imported as a module by test
    # and the unittest.main() requires a module with the name 'test'
    assert md5('sha1.py') == '8b7deaa467cfd19a7f6e72fbb9be9e2b'

# Generated at 2022-06-11 18:03:23.148575
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-11 18:03:25.214742
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-11 18:03:28.427324
# Unit test for function md5
def test_md5():
    assert md5(None) is None
    assert md5('') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-11 18:03:39.967805
# Unit test for function checksum
def test_checksum():

    test_file = "test/files/file1.txt"
    test_str = "Hello World."

    # test with string
    test_str_hash = checksum_s(test_str)
    assert test_str_hash == "7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069", test_str_hash

    # test with file
    test_file_hash = checksum(test_file)
    assert test_file_hash == "7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069", test_file_hash

    # test with string and md5

# Generated at 2022-06-11 18:03:50.726614
# Unit test for function md5s
def test_md5s():
    assert md5s(b'abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s(u'abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s(b'abC') == 'a9f9384e8256940d8c570ddb94e7a454'
    assert md5s(u'abC') == 'a9f9384e8256940d8c570ddb94e7a454'
    assert md5s(u'ab\u212A') == 'b0f3f9907b4a14a4a4d27e74615278b4'
    assert md5s(b'ab\xe2\x84\xaa')

# Generated at 2022-06-11 18:03:53.357192
# Unit test for function md5
def test_md5():
    assert(md5("test/utils/test-md5") == 'c7da80b95eaabff58e92b604215e7a3e')


# Generated at 2022-06-11 18:03:56.364557
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('foobar') == '3858f62230ac3c915f300c664312c63f'



# Generated at 2022-06-11 18:04:07.091491
# Unit test for function md5
def test_md5():
    import os
    if not os.path.exists("test_hash.py"):
        print("Could not find test_hash.py")
        return False

    result = md5("test_hash.py")
    if not result == '496db0b0e374c8a6cc7de6b0a6ffbafd':
        print("Calculated md5 of test_hash.py doesn't match")
        return False

    print("SUCCEEDED: md5 test")
    return True

if __name__ == '__main__':
    import sys
    import os
    os.chdir("../../lib")
    sys.path.append(".")
    result = test_md5()
    if result:
        print("Succesfully completed testing")

# Generated at 2022-06-11 18:04:15.657233
# Unit test for function md5
def test_md5():
    from ansible.module_utils.hashing import md5
    from ansible.module_utils.basic import AnsibleModule
    from copy import copy
    from hashlib import md5 as _md5
    module = AnsibleModule(argument_spec={'path': dict(type='str', required=True)})
    # Make sure md5 works on a file that exists.
    path = '/etc/hosts'
    res_success = {"changed": False, "msg": "file was successfully processed"}
    dig = _md5()
    dig.update(open(path, 'rb').read())
    res_success['ansible_facts'] = {'checksum_src': path,
                                    'checksum': dig.hexdigest(),
                                    'checksum_succeeded': True,
                                    }

# Generated at 2022-06-11 18:04:19.719083
# Unit test for function md5s
def test_md5s():
    ''' Test md5s function '''
    checksum_a = md5s('hello')
    assert checksum_a == '5d41402abc4b2a76b9719d911017c592', checksum_a


# Generated at 2022-06-11 18:04:22.806295
# Unit test for function md5s
def test_md5s():
    assert md5s("ABCD") == "e2fc714c4727ee9395f324cd2e7f331f"


# Generated at 2022-06-11 18:04:32.346414
# Unit test for function md5s
def test_md5s():
    import random
    import string

    random.seed(0)
    # Generate a random string
    string1 = ''.join(random.choice(string.ascii_uppercase + string.digits) for x in range(10))
    # Check that hash of string is the same each time
    assert md5s(string1) == md5s(string1)
    # Check that hash of string is different to another random string
    string2 = ''.join(random.choice(string.ascii_uppercase + string.digits) for x in range(10))
    assert md5s(string1) != md5s(string2)

# Test the unit test
if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-11 18:04:37.042630
# Unit test for function md5s
def test_md5s():
    assert md5s('data') == '1f9b9c8d8f7ea23159dfbd18dbc35f42'
    assert md5s('data') == '1f9b9c8d8f7ea23159dfbd18dbc35f42'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-11 18:04:43.369680
# Unit test for function md5
def test_md5():
    assert md5("/dev/null") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5s("") == "d41d8cd98f00b204e9800998ecf8427e"

# Generated at 2022-06-11 18:04:45.838972
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-11 18:04:50.111288
# Unit test for function md5s
def test_md5s():
    assert md5s(b"abc") == "900150983cd24fb0d6963f7d28e17f72"
    assert md5s(b"") == "d41d8cd98f00b204e9800998ecf8427e"
    assert md5s(b"The quick brown fox jumps over the lazy dog") == "9e107d9d372bb6826bd81d3542a419d6"


# Generated at 2022-06-11 18:04:59.087769
# Unit test for function checksum
def test_checksum():
    filename = os.path.join(os.path.dirname(__file__), 'utils.py')
    assert secure_hash(filename) == '6e146b637fa78d2c3a3f662e73178dd6297e66c1'
    assert secure_hash('Hello') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'
    assert secure_hash_s('Hello') == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'

# Generated at 2022-06-11 18:05:01.904419
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

if __name__ == '__main__':
    import sys
    sys.exit(0)

# Generated at 2022-06-11 18:05:08.291885
# Unit test for function md5s
def test_md5s():
    # The following 3 results were calculated by doing the following in bash
    assert md5s("Hello World!") == "65a8e27d8879283831b664bd8b7f0ad4"
    assert md5s("HELLO WORLD!") == "a1d0c6e83f027327d8461063f4ac58a6"
    assert md5s("") == "d41d8cd98f00b204e9800998ecf8427e"

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-11 18:05:14.230398
# Unit test for function md5
def test_md5():
    filename = 'test/testmd5'
    # Write some data to file
    f = open (filename, 'w')
    f.write("this is a test")
    f.close()
    # Calculate md5
    checksum = md5(filename)
    # Check md5 matches pre calculated checksum
    assert checksum == '5efb6e44b744efc81a814d12e4525eb5'
    # Clean up the test file
    os.remove(filename)

# Generated at 2022-06-11 18:05:16.843535
# Unit test for function md5
def test_md5():
    data = 'hello world'
    assert md5s(data) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5(__file__) == '1d095d5e9c1656ac17e7abfdb28d65d7'

if __name__ == '__main__':
    # run unit test
    test_md5()

# Generated at 2022-06-11 18:05:24.104305
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    pass_str = 'string to encrypt with md5'
    fail_str = 'string to encrypt with md5 - modify it'
    assert md5s(pass_str) == '901e7d08f94481b72347d1bc1ec73813'
    assert md5s(fail_str) != '901e7d08f94481b72347d1bc1ec73813'
    filename = './test_md5.txt'

# Generated at 2022-06-11 18:05:27.283481
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
