

# Generated at 2022-06-11 17:55:31.489230
# Unit test for function md5s
def test_md5s():
    assert md5s('"5"') == '97d3150da56f1a45a1efad2b9299413d'

# Generated at 2022-06-11 17:55:38.384146
# Unit test for function md5s
def test_md5s():
    # for Python 2.4 compatibility
    string = 'Hello World!'
    result = 'b10a8db164e0754105b7a99be72e3fe5'
    assert md5s(string) == result
    string = 'Hello World.'
    result = 'e6e1a270940f6b36d6cfb98f3c3e8d41'
    assert md5s(string) == result

# Generated at 2022-06-11 17:55:44.174974
# Unit test for function checksum
def test_checksum():
    h = checksum_s("foo")
    assert h == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    h = checksum("/bin/ls")
    assert h == 'f218e2602f97ea35cd1c8e47eaa7ceb4d4d4a230'

# Generated at 2022-06-11 17:55:46.101145
# Unit test for function md5
def test_md5():
    print (md5('/etc/passwd'))

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 17:55:50.961144
# Unit test for function md5s
def test_md5s():
    if _md5:
        data = 'abc123'
        hashed = md5s(data)
        assert hashed == 'e99a18c428cb38d5f260853678922e03'



# Generated at 2022-06-11 17:55:59.429909
# Unit test for function checksum
def test_checksum():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    data = AnsibleUnsafeText(u'abcdef')
    assert checksum_s(data) == 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'

    data = AnsibleUnsafeText(u'abcdef' * 100000)
    assert checksum_s(data) == '15f0d485be6b834c051e9d9c9371f432b5a8b2203173a3cba55c9e6b89f6b3f3'

    data = u'abcdef'

# Generated at 2022-06-11 17:56:01.794113
# Unit test for function md5s
def test_md5s():
    assert md5s('hi') == '49f68a5c8493ec2c0bf489821c21fc3b'


# Generated at 2022-06-11 17:56:10.165129
# Unit test for function checksum
def test_checksum():
    # Test file checksum
    chksum = checksum("test/files/hash_test_file")
    assert chksum == "e80b5017098950fc58aad83c8c14978e"

    # Test directory checksum
    chksum = checksum("test/files")
    assert chksum is None

    # Test non existent file checksum
    chksum = checksum("test/files/non_existent_file")
    assert chksum is None

    # Test checksum of string
    chksum = checksum_s("Hello World")
    assert chksum == "2ef7bde608ce5404e97d5f042f95f89f1c232871"


# Backwards compat unit test

# Generated at 2022-06-11 17:56:19.042212
# Unit test for function checksum
def test_checksum():
    checksum_dir = os.path.dirname(os.path.abspath(__file__))
    checksum_file = os.path.join(checksum_dir, "checksum_file")
    checksum_str = "Hello"

    # Test checksum
    assert checksum(checksum_file) == '1aa9e3ffb6d3c58e7778cddb0bf8d735e40ea6f9', 'checksum() failed'

    # Test checksum_s
    assert checksum_s(checksum_str) == 'f59ddb9e88498b6f0c6d7c650e790934486de735', 'checksum_s() failed'

# Generated at 2022-06-11 17:56:23.628912
# Unit test for function checksum
def test_checksum():
    # Acquire checksum for a file in the same directory
    correct_hash = '2eb835c03e208d65c89b94ceeecfd8c7'
    returned_hash = checksum('./tests/units/compat/test_utils.py')
    assert correct_hash == returned_hash



# Generated at 2022-06-11 17:56:32.204751
# Unit test for function md5
def test_md5():
    filename = os.path.join(os.path.dirname(__file__), '__init__.py')
    if os.path.isfile(filename):
        assert md5(filename) == 'e5b5d4a8a99f1ff4ee4ba4b1e7a50d29'
    else:
        assert md5(filename) == None



# Generated at 2022-06-11 17:56:40.163544
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s(b'') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(b'hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(b'a' * 1000000) == '7707d6ae4e027c70eea2a935c2296f21'


# Generated at 2022-06-11 17:56:48.922519
# Unit test for function md5
def test_md5():
    test_file = '/tmp/test_hashes.txt'
    test_data = 'test_data'

    # Create file for test
    with open(test_file, 'w') as f:
        f.write(test_data)

    # Test the hash functions
    test_md5_data = md5s(test_data)
    test_md5_file = md5(test_file)

    # Delete file
    os.remove(test_file)

    # Assert the hashes are correct
    assert test_md5_data == '098f6bcd4621d373cade4e832627b4f6'
    assert test_md5_file == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-11 17:56:58.716134
# Unit test for function checksum
def test_checksum():
    assert(checksum("test/files/chown.sh") == '1ad8ca1e6b37ecdd32a7d4f9e4a4f4abdae47d75')
    assert(checksum("test/files/chown.sh", hash_func=_md5) == '7429f1d26131d99a2c7edc680f0075c7')
    assert(checksum("test/files/chown.sh", hash_func=sha1) == '1ad8ca1e6b37ecdd32a7d4f9e4a4f4abdae47d75')
    assert(checksum("test/files/chown.sh", hash_func=sha1) == checksum("test/files/chown.sh"))


# Generated at 2022-06-11 17:57:01.331634
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') is not None


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 17:57:04.595948
# Unit test for function checksum
def test_checksum():
    assert len(checksum(None)) == 40
    assert len(md5(None)) == 32
    assert len(md5s("12345")) == 32
    assert len(checksum_s("12345")) == 40


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:57:08.265143
# Unit test for function checksum
def test_checksum():
    test1 = checksum('sha1.py')
    print("sha1.py checksum: %s" % test1)

    test2 = checksum('.gitignore')
    print(".gitignore checksum: %s" % test2)

    test3 = checksum('tests/integration/targets/localhost')
    print("targets/localhost checksum: %s" % test3)

    test4 = checksum('tests/test.yml')
    print("test.yml checksum: %s" % test4)


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:57:11.841979
# Unit test for function md5s
def test_md5s():
    md5s_test = md5s('test')
    assert md5s_test == '098f6bcd4621d373cade4e832627b4f6', md5s_test

# Generated at 2022-06-11 17:57:18.121063
# Unit test for function md5
def test_md5():
    import tempfile
    filename = tempfile.mkstemp()[1]
    def cleanup(filename):
        os.remove(filename)
    import atexit
    atexit.register(cleanup, filename)

    with open(filename, 'wt') as fd:
        fd.write("blah")

    value = md5(filename)
    assert value == md5s("blah")



# Generated at 2022-06-11 17:57:20.461644
# Unit test for function checksum
def test_checksum():
    ''' returns True if checksum function returns at least 1 byte '''
    csum = checksum("/etc/passwd")
    return len(csum) >= 1

# Generated at 2022-06-11 17:57:26.186121
# Unit test for function checksum
def test_checksum():
    assert checksum(__file__) == checksum_s(open(__file__).read())


if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod()
    for filename in sys.argv[1:]:
        if os.path.exists(to_bytes(filename, errors='surrogate_or_strict')):
            print("%s    %s" % (checksum(filename), filename))
        else:
            print("%s    %s  (missing)" % (checksum(filename), filename))

# Generated at 2022-06-11 17:57:30.823836
# Unit test for function md5s
def test_md5s():
    from ansible.compat.tests import unittest

    class TestMd5s(unittest.TestCase):

        def test_md5s(self):
            data = 'Hello World!'
            self.assertEqual(md5s(data), "ed076287532e86365e841e92bfc50d8c")

    unittest.main(verbosity=2)


# Generated at 2022-06-11 17:57:35.631073
# Unit test for function md5
def test_md5():
    md5 = md5s('ansible')
    assert md5 == '7bef537b829b3a1e1fa799b7f9dd9bd2'


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 17:57:39.967841
# Unit test for function md5
def test_md5():
    test = 'The quick brown fox jumped over the lazy brown bear.'
    value = '5a5b245f1b5a5b649dba3ab3e9fdf9a5'
    assert md5s(test) == value, "MD5 failed"

# Generated at 2022-06-11 17:57:41.360092
# Unit test for function md5s
def test_md5s():
    assert(md5s('foobar') == '3858f62230ac3c915f300c664312c63f')


# Generated at 2022-06-11 17:57:51.047961
# Unit test for function checksum
def test_checksum():
    # Call secure_hash to get sha1
    sha1_sum = checksum("../lib/ansible/module_utils/basic.py")
    # Call secure_hash_s to get sha1 for a string
    test_str = 'Test string'
    sha1_sum_str = checksum_s(test_str)
    assert sha1_sum == '1e84c22e7df54bb8e88e5578b5c6c5d5d8f6ae1e'
    assert sha1_sum_str == '98c6a40b43e7c36d2e2a6821e633ac9a7ff43af8'


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:58:01.444205
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(' ') == '7215ee9c7d9dc229d2921a40e899ec5f'
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s('hi') == '49f68a5c8493ec2c0bf489821c21fc3b'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello ') == 'b1946ac92492d2347c6235b4d2611184'

# Generated at 2022-06-11 17:58:08.998969
# Unit test for function md5s
def test_md5s():
    """Return a string that contains the checksum of a string
    with the md5 algorithm"""

    from ansible.utils.hashing import md5s

    string = 'Hello world !'

    try:
        string_md5 = md5s(string)
        #print 'String : '+string+' -- get md5 : '+string_md5
        assert str(string_md5) == '29a41076c9b1e992d6e89e822a311e7e'
    except:
        raise
    return string_md5


# Generated at 2022-06-11 17:58:14.730346
# Unit test for function checksum
def test_checksum():
    "sha1"
    data = "foo"
    assert checksum_s(data) == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum(os.path.join(os.path.dirname(__file__), 'test_checksums.py')) == '282c2edf14bea3836a82657aacde3f3e5aae0b35'

# Generated at 2022-06-11 17:58:18.193785
# Unit test for function checksum
def test_checksum():
    checksum = secure_hash_s('abc')
    assert(checksum == 'a9993e364706816aba3e25717850c26c9cd0d89d')



# Generated at 2022-06-11 17:58:22.974424
# Unit test for function md5s
def test_md5s():
    assert md5s("abcdefgh") == 'e2fc714c4727ee9395f324cd2e7f331f'



# Generated at 2022-06-11 17:58:31.421207
# Unit test for function md5
def test_md5():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.compat.six import PY3, StringIO

    class TestHashModule(unittest.TestCase):
        def test_md5_not_available(self):
            from ansible.module_utils.six import BytesIO

            fake_stdout = BytesIO()
            fake_stderr = BytesIO()
            fake_stdin = BytesIO()


# Generated at 2022-06-11 17:58:35.352014
# Unit test for function md5
def test_md5():
    print(md5("/etc/passwd"))
    assert md5("/etc/passwd") == secure_hash("/etc/passwd", _md5)

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 17:58:37.479119
# Unit test for function md5s
def test_md5s():
    assert md5s(u'foobar') == '3858f62230ac3c915f300c664312c63f'


# Generated at 2022-06-11 17:58:47.092500
# Unit test for function md5
def test_md5():
    from shutil import rmtree
    from tempfile import mkdtemp
    from ansible.parsing.vault import VaultLib

    test_dir = mkdtemp(dir='/tmp')
    test_input_dir = os.path.join(test_dir, 'test_input')
    test_output_dir = os.path.join(test_dir, 'test_output')

    os.mkdir(test_input_dir)
    os.mkdir(test_output_dir)

    ansible_vault_password_file = os.path.join(test_input_dir, '.vault_pass.txt')

    with open(ansible_vault_password_file, 'w+') as f:
        f.write('some_password\n')

    plain_text = 'this is some plain text'


# Generated at 2022-06-11 17:58:49.480782
# Unit test for function md5
def test_md5():
    md5_ret = md5("/bin/ls")
    assert md5_ret == "4c4edd8a4fe77e7d2a13b36a7b8c59d3"

# Generated at 2022-06-11 17:58:52.654090
# Unit test for function md5s
def test_md5s():
    s = secure_hash_s('hello world')
    assert(s == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed')

# Generated at 2022-06-11 17:58:56.894952
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

# backwards compat.  Use md5s() instead
hmac_new = md5s

# Test the base hmac_new function.

# Generated at 2022-06-11 17:59:04.519790
# Unit test for function md5s
def test_md5s():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={'data': {'required': True, 'type': 'str'}},
        supports_check_mode=True)

    expected = 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'
    observed = md5s(module.params['data'])
    if expected == observed:
        module.exit_json(msg="MD5s match", changed=False)
    else:
        module.fail_json(msg="MD5s do not match", expected=expected, observed=observed)


# Generated at 2022-06-11 17:59:11.007477
# Unit test for function md5
def test_md5():
    ''' md5 unit test '''
    assert md5('/etc/passwd') == '68b329da9893e34099c7d8ad5cb9c940' or md5('/etc/passwd') == '1fc2c0aea95667fce6472d03ad8e98d1' or md5('/etc/passwd') == 'ae2b1fca515949e5d54fb22b8ed95575'

# Generated at 2022-06-11 17:59:21.117313
# Unit test for function checksum
def test_checksum():
    this_dir, this_filename = os.path.split(__file__)
    sample_file_name = os.path.join(this_dir, "../test/units/lib/ansible/module_utils/COMMON_FILENAME")
    assert checksum(sample_file_name) == '94b8b5b88ba17b1e9d2a093b4a4c4cb0d7cb5cb3'
    assert checksum_s("hello world") == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'



# Generated at 2022-06-11 17:59:29.576023
# Unit test for function checksum
def test_checksum():
    checksum_str = 'f58c00d3f7a3db3b22ea75b0a38a9c30f28d19ab'
    temp_file = '/tmp/foo'
    f = open(temp_file, 'w')
    f.write("Hello world\n")
    f.close()
    checksum_file = checksum(temp_file)
    if checksum_str != checksum_file:
        raise AssertionError("Unit test for function checksum failed")



# Generated at 2022-06-11 17:59:33.668146
# Unit test for function md5s
def test_md5s():
    md5_return = md5s('hello')
    assert(md5_return == '5d41402abc4b2a76b9719d911017c592'), \
    'md5 of hello returns %s instead of 5d41402abc4b2a76b9719d911017c592' % md5_return


# Generated at 2022-06-11 17:59:36.480751
# Unit test for function md5
def test_md5():
    h = md5s('test')
    assert h == '098f6bcd4621d373cade4e832627b4f6'

    # TODO: need to create temp files for testing

# Generated at 2022-06-11 17:59:46.898914
# Unit test for function checksum
def test_checksum():
    import os
    import tempfile
    import shutil
    testdir = os.path.dirname(__file__)
    testdir = os.path.join(testdir, 'test_checksum')
    assert(os.path.exists(testdir))
    tmpdir = tempfile.mkdtemp(prefix='ansible_test_checksum')
    assert(os.path.exists(tmpdir))
    shutil.copy(os.path.join(testdir, 'test1'), tmpdir)
    assert(checksum(os.path.join(tmpdir, 'test1')) == 'a131a2a2a67b09dcaa7c3751b3c3dff0a3f0e9c8')

# Generated at 2022-06-11 17:59:52.762632
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo\nbar') == 'b5bb9d8014a0f9b1d61e21e796d78dcc'



# Generated at 2022-06-11 18:00:03.023764
# Unit test for function checksum
def test_checksum():
    ''' test_checksum.py: create a temporary file for checksum verification '''

    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(path=dict(required=True, type='str'),
                           algorithm=dict(required=False, default='sha1', type='str'),
        )
    )

    (rc, out, err) = module.run_command(["openssl", "rand", "-base64", "32"])
    if rc != 0:
        module.fail_json(msg="Could not run openssl to generate random data.")

    myfile = tempfile.NamedTemporaryFile()
    myfile.write(out)
    myfile.flush()


# Generated at 2022-06-11 18:00:06.700806
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-11 18:00:09.626547
# Unit test for function md5
def test_md5():
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:00:15.984571
# Unit test for function md5
def test_md5():
    from ansible.module_utils.basic import AnsibleModule

    def exit_json(*args, **kwargs):
        raise AnsibleModule().exit_json(*args, **kwargs)

    def fail_json(*args, **kwargs):
        raise AnsibleModule().fail_json(*args, **kwargs)

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
        ),
    )
    try:
        digest = md5(module.params['path'])
    except ValueError:
        e = get_exception()
        module.fail_json(msg=str(e))
    except Exception as e:
        module.fail_json(msg=str(e))
    else:
        module.exit_json(md5sum=digest)

# Generated at 2022-06-11 18:00:30.076353
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    from ansible.module_utils.basic import AnsibleModule

    tmpdir = tempfile.mkdtemp()
    input_lines = [b"blah", b"blah"]
    for x, line in enumerate(input_lines, start=1):
        path = os.path.join(tmpdir, "test_file_%d" % x)
        with open(path, "wb") as fd:
            fd.write(line)

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='list'),
            hash_algo=dict(required=False, default='sha1', choices=['sha1', 'md5'])
        ),
        supports_check_mode=False,
    )

# Generated at 2022-06-11 18:00:34.900417
# Unit test for function md5s
def test_md5s():
    '''
    Test case for md5s function.
    '''
    test_data = 'test data'
    test_md5sum = 'a9d284465b5c83640a193d1a2f2d5fa5'
    assert test_md5sum == md5s(test_data)


# Generated at 2022-06-11 18:00:41.029870
# Unit test for function md5s
def test_md5s():
    assert md5s('abcdef') == 'e2fc714c4727ee9395f324cd2e7f331f'
    assert md5s('ABCDEF') == '343ce5ca9023a8acb676a5d974f9a9a9'
    assert md5s('abcdéf') == '840129d868e1f9e20f6d353e416d8f17'
    assert md5s('abcdêf') == '6e4bb6e30c6f4e6c8b6d2be6f80a6b1c'
    assert md5s('abcdëf') == '72e6b8d6e62c6e80e25dcbdda85d0e1f'
    assert md5s('abcdìf')

# Generated at 2022-06-11 18:00:45.770162
# Unit test for function md5
def test_md5():
    filename = "/etc/passwd"
    assert("9c9d89eb3829b1c7c98f404700c3daf3" == md5(filename)), "File %s, md5summ => %s " % (filename, md5(filename))


# Generated at 2022-06-11 18:00:56.321753
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil
    import sys

    test_data = 'a'*1024
    test_hash = 'd2e2aff217c2e8d8b13de0c0bff7c1ac'
    file_dir = tempfile.mkdtemp()
    file_path = os.path.join(file_dir, 'test_checksum_file')

    # Test file checksum
    with open(file_path, 'w') as f:
        f.write(test_data)
    file_hash = checksum(file_path)
    assert file_hash == test_hash

    # Test string checksum
    string_hash = checksum_s(test_data)
    assert string_hash == test_hash

    # Cleanup
    shutil.rmtree(file_dir)



# Generated at 2022-06-11 18:00:58.654253
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"


# Generated at 2022-06-11 18:01:01.722600
# Unit test for function md5s
def test_md5s():
    md5_checksum = md5s('foo')
    assert md5_checksum == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-11 18:01:07.967703
# Unit test for function checksum
def test_checksum():
    assert sha1(b"abc").hexdigest() == checksum_s(b"abc")
    assert sha1(b"abc").hexdigest() == checksum_s(u"abc", "utf-8")
    assert sha1(b"abc").hexdigest() == checksum_s(u"abc", "ascii")

# Generated at 2022-06-11 18:01:14.741926
# Unit test for function md5s
def test_md5s():
    md5s = ansible.utils.md5s
    data = "this is a test"
    if not md5s(data) == "f06905854eb3d7deebcb079b9f9fce22":
        raise AssertionError
    print("%s: %s" % (data, md5s(data)))
    data = "The quick brown fox jumps over the lazy dog."
    if not md5s(data) == "9e107d9d372bb6826bd81d3542a419d6":
        raise AssertionError
    print("%s: %s" % (data, md5s(data)))

# Generated at 2022-06-11 18:01:19.028688
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return True
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'
    assert md5s('test') != '098f6bcd4621d373cade4e832627b4f5'



# Generated at 2022-06-11 18:01:24.311376
# Unit test for function md5
def test_md5():
    md5sum = md5('data/file1')
    # print("md5 : " + md5sum)
    assert md5sum == '6e04c6ec80683e4140c4d4b19f7f1d88'


# Generated at 2022-06-11 18:01:31.340076
# Unit test for function md5s
def test_md5s():
    assert(md5s("hello") == "5d41402abc4b2a76b9719d911017c592")
    assert(md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8")
    assert(md5s("bar") == "37b51d194a7513e45b56f6524f2d51f2")
    assert(md5s("baz") == "62cdb7020ff920e5aa642c3d40669502")
    assert(md5s("qux") == "bef57ec7f53a6d40beb640a780a639c1")

# Generated at 2022-06-11 18:01:41.091340
# Unit test for function md5s
def test_md5s():
    import textwrap
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 18:01:44.002034
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "45b23dee0ba2d58ca1ca2cb629077f0f"


# Generated at 2022-06-11 18:01:46.621881
# Unit test for function md5
def test_md5():
    assert md5s('Hello World') == 'b10a8db164e0754105b7a99be72e3fe5'
    assert md5('/etc/passwd') == '68b329da9893e34099c7d8ad5cb9c940'

# Generated at 2022-06-11 18:01:52.072433
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest

    class TestChecksum(unittest.TestCase):
        def test_checksum_data(self):
            data = 'a'
            c = checksum_s(data)
            self.assertEqual(c, '0cc175b9c0f1b6a831c399e269772661')

        def test_checksum_file(self):
            filename = 'tests/test_utils/test_utils_checksum/a'
            c = checksum(filename)
            self.assertEqual(c, '0cc175b9c0f1b6a831c399e269772661')

    unittest.main()

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:01:58.971897
# Unit test for function checksum
def test_checksum():
    import tempfile
    import textwrap

    file_data = textwrap.dedent('''\
        Hello world!
        Bye world!
        ''')

    with tempfile.NamedTemporaryFile('w') as f:
        f.write(file_data)
        f.flush()
        assert checksum(f.name, hash_func=_md5) == '1cdfb07c58f83c8b1c0fc900cc14f615'
        assert checksum(f.name) == '62e1b4c1ef3e4f9c9ef2b4e59d66ae60e2c704f1'


if __name__ == "__main__":
    import sys
    import doctest

    # Do not run doctests when invoked with "-c" or "--coverage",

# Generated at 2022-06-11 18:02:09.574515
# Unit test for function checksum
def test_checksum():
    ''' unit test for function checksum '''
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    assert test_dir.startswith('/tmp/')
    dummy_file = os.path.join(test_dir, 'foo')
    f = open(dummy_file, 'wb')
    f.write(b'Hello')
    f.close()
    csum = checksum(dummy_file)
    assert csum == '5d41402abc4b2a76b9719d911017c592', "Got wrong checksum %s for %s" % (csum, dummy_file)
    shutil.rmtree(test_dir)


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:02:16.419944
# Unit test for function checksum
def test_checksum():
    """Check checksum generation and comparision"""
    import random
    import string
    import tempfile
    from ansible.module_utils.six import iteritems

    # Generate a random string of letters and digits
    test_string = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(100))


# Generated at 2022-06-11 18:02:21.926335
# Unit test for function md5
def test_md5():
    '''Return a secure hash hex digest of a local file'''

    check = md5('lib/ansible/module_utils/basic.py')
    assert check == '8ce6b7c6eaf9a1bcd12c6b8bf25b0c38', check


# Generated at 2022-06-11 18:02:28.931880
# Unit test for function md5s
def test_md5s():
    if hasattr(secure_hash_s, '__code__'):
        assert secure_hash_s.__code__.co_argcount == 2
    assert md5s('test') in ('098f6bcd4621d373cade4e832627b4f6')


# Generated at 2022-06-11 18:02:38.710356
# Unit test for function checksum
def test_checksum():
    if checksum_s('abc123') != 'b4cd98ea0916b721f84fc05b58e72c3baaa967c6' or checksum_s(u'abc123') != 'b4cd98ea0916b721f84fc05b58e72c3baaa967c6':
        raise AnsibleError("Failure in checksum_s().  Expected b4cd98ea0916b721f84fc05b58e72c3baaa967c6 but got %s" % checksum_s('abc123'))


# Generated at 2022-06-11 18:02:47.324730
# Unit test for function md5
def test_md5():
    import tempfile
    target = secure_hash('setup.py')
    f = tempfile.NamedTemporaryFile()
    f.write('DLPTest')
    f.flush()
    target2 = secure_hash(f.name)
    f.close()
    target3 = md5s('DLPTest')

    print(target, target2, target3)
    assert target == '2dd711cac612d4a7b274c9902eba7c9d'
    assert target2 == 'c1e0b8ef37b3d3f049a3ebba6f8c6d5d'
    assert target3 == '40bd001563085fc35165329ea1ff5c5ecbdbbeef'



# Generated at 2022-06-11 18:02:54.112652
# Unit test for function md5
def test_md5():
    """Test md5 function."""
    import tempfile

    with tempfile.NamedTemporaryFile(mode='w') as tf:
        tf.write('abcdefg')
        tf.flush()
        assert(md5(to_bytes(tf.name, errors='surrogate_or_strict')) == '7ac66c0f148de9519b8bd264312c4d64')
        assert(md5s(to_bytes('abcdefg', errors='surrogate_or_strict')) == '7ac66c0f148de9519b8bd264312c4d64')

# Generated at 2022-06-11 18:03:03.439636
# Unit test for function md5
def test_md5():
    import tempfile

    tmp_fd, tmp_path = tempfile.mkstemp(text=True)

    with os.fdopen(tmp_fd, 'w') as f:
        f.write('Hi there')

    file_md5 = md5(tmp_path)
    os.unlink(tmp_path)

    expected_md5 = '6f5902ac237024bdd0c176cb93063dc4'
    assert file_md5 == expected_md5


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:03:10.919191
# Unit test for function md5
def test_md5():
    ''' return unit test data '''


# Generated at 2022-06-11 18:03:19.998687
# Unit test for function md5
def test_md5():
    ''' md5.py: unit test for function md5 and md5s '''

    # Test md5 using an empty string
    md5_empty = md5s('')
    if md5_empty != 'd41d8cd98f00b204e9800998ecf8427e':
        print('FAILED: md5_empty')
        return False

    # Test md5 using a non-empty string
    md5_non_empty = md5s('12345')
    if md5_non_empty != '827ccb0eea8a706c4c34a16891f84e7b':
        print('FAILED: md5_non_empty')
        return False

    # Test md5 using an empty file
    tmp_file = open('test_md5', 'w')
   

# Generated at 2022-06-11 18:03:30.575875
# Unit test for function md5
def test_md5():
    # Note that some of these tests check md5 collisions.  The md5
    # collision is used to check the backwards compat code, not to check
    # whether two files are the same.
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s('foo\nbar') == '732747dc6924c3aa6771b4f1b4ef4ce4'
    assert md5('test/test-module-utils-basic.py') == '29f18c88ba11d2b0c7ffea9a04c9d923'
    # Some files in large.tar.gz are deliberately the same and have the same
    # md5sum.  Check that this module can handle that case.

# Generated at 2022-06-11 18:03:33.178445
# Unit test for function md5
def test_md5():
    data = "hello world"
    assert md5s(data) == "5eb63bbbe01eeed093cb22bb8f5acdc3"

# Generated at 2022-06-11 18:03:36.492689
# Unit test for function checksum
def test_checksum():
    print("test checksum")
    print("test checksum_s")
    assert checksum('test.py') == checksum_s(open('test.py').read())

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:03:44.418002
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum('test/files/ansible.cfg') == 'a9c62aff1f0a2dbf5d077bf86130d1e9a05f9db0'

# Generated at 2022-06-11 18:03:46.992929
# Unit test for function md5s
def test_md5s():
    import ansible.utils.crypto as crypto
    crypto.md5s("test")
    crypto.md5("does not exist")
    crypto.md5("/")

# Generated at 2022-06-11 18:03:55.033375
# Unit test for function md5s
def test_md5s():
    import unittest
    import StringIO
    class TestMd5s(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def testMd5s(self):
            self.assertEqual('68b329da9893e34099c7d8ad5cb9c940', md5s("foobar"))
            self.assertEqual('68b329da9893e34099c7d8ad5cb9c940', md5s(u"foobar"))
            self.assertEqual('68b329da9893e34099c7d8ad5cb9c940', md5s(StringIO.StringIO("foobar")))

    #
    # Run the unit tests
    #
    test_suite = unittest.makeSu

# Generated at 2022-06-11 18:04:06.042094
# Unit test for function md5
def test_md5():

    testfile = 'testfile'
    testfile_contents = """
This is a test file
It has some text
And it has some more
"""
    expected_md5sum = 'c54b6bf85a6a68213dba2ac6e8445e5e'

    with open(testfile, 'w') as f:
        f.write(testfile_contents)

    actual_md5sum = md5(testfile)

    if actual_md5sum != expected_md5sum:
        raise AssertionError(
            "expected md5sum '{0}' but got '{1}' instead".format(
                expected_md5sum,
                actual_md5sum
            )
        )
    else:
        print('md5 test passed')



# Generated at 2022-06-11 18:04:09.217842
# Unit test for function md5
def test_md5():
    # This is a known md5sum output for a file with contents of 'foo'
    assert md5('test/templates/foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-11 18:04:13.487747
# Unit test for function md5
def test_md5():
    filename = 'test_file_md5'
    expected_md5 = "d0cbdb58c9ce8b1abe997235fb0b387a"

    file = open(filename, "w")
    file.write("test_file_md5")
    file.close()

    assert expected_md5 == md5(filename)
    os.remove(filename)

# Generated at 2022-06-11 18:04:17.574065
# Unit test for function md5
def test_md5():
    if _md5:
        assert md5("test/support/dummy1.txt") == "ce114e4501d2f4e2dcea3e17b546f339"
        assert md5("test/support/dummy2.txt") is None

# Generated at 2022-06-11 18:04:20.201511
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'



# Generated at 2022-06-11 18:04:24.782959
# Unit test for function md5s
def test_md5s():
    assert md5s("foobar") == "8843d7f92416211de9ebb963ff4ce28125932878"


__all__ = ['checksum', 'checksum_s', 'secure_hash', 'secure_hash_s', 'md5', 'md5s']

# Generated at 2022-06-11 18:04:26.953776
# Unit test for function md5s
def test_md5s():
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'


# Generated at 2022-06-11 18:04:39.124309
# Unit test for function md5s
def test_md5s():
    '''
        Test md5s with both text and binary data
    '''
    # Test that md5s works as expected with text data
    text_data = "this is a test"
    expected_text_result = '37d93935b879f81ccda35af1bcbab149'
    assert md5s(text_data).lower() == expected_text_result

    # Test that md5s works as expected with binary data
    # Note: The expected result was generated using the md5sum utility
    binary_data = '\x00\x01\x02\x03'
    expected_binary_result = 'e6ceee8b8a0428e5f6d2c19f4387f846'
    assert md5s(binary_data).lower() == expected_binary_result

# Generated at 2022-06-11 18:04:48.538399
# Unit test for function md5
def test_md5():
    test_string = u"test string"
    test_string2 = u"different string"
    # use md5 to compare checksums
    md5_test_string = _md5(test_string.encode('utf-8')).hexdigest()
    md5_test_string2 = _md5(test_string2.encode('utf-8')).hexdigest()
    # get md5 checksum for string
    md5_checksum = md5s(test_string)
    md5_checksum2 = md5s(test_string2)
    # compare checksums
    assert(md5_checksum == md5_test_string)
    assert(md5_checksum2 == md5_test_string2)
    assert(md5_checksum != md5_checksum2)

# Generated at 2022-06-11 18:04:51.883800
# Unit test for function md5
def test_md5():
    return md5('lib/ansible/module_utils/basic.py') == '2eef05ebc859b5200e31f77d7d94b81c'

# Generated at 2022-06-11 18:04:54.976877
# Unit test for function md5s
def test_md5s():
    value = "hello"

    assert(md5s(value) == "5d41402abc4b2a76b9719d911017c592")



# Generated at 2022-06-11 18:04:57.088547
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-11 18:05:00.234144
# Unit test for function md5
def test_md5():
    print('test md5()')
    assert md5(__file__) == '6a5d04a857e2f1b41bc076e5c5f8a6a5'



# Generated at 2022-06-11 18:05:03.073452
# Unit test for function md5s
def test_md5s():
    # TODO: Use more meaningful test string and less fragile test
    assert '7a8ea70b2bd7bf945bde74bfcdc811ce' == md5s('test')



# Generated at 2022-06-11 18:05:06.934086
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    result = md5("/etc/hosts")
    assert result == 'e4b9a9a4d0ad8796e7d18e4e49f70b89', "md5 returned %s but expected other value" % result

# Generated at 2022-06-11 18:05:12.658673
# Unit test for function checksum
def test_checksum():

    # The following test was generated from the test data from this site:
    # http://www.fileformat.info/tool/hash.htm?text=The+quick+brown+fox+jumps+over+the+lazy+dog.%0D%0A&hashtype=SHA-1&submit=Create+Hash

    assert checksum_s("The quick brown fox jumps over the lazy dog.\r\n") == "408d94384216f890ff7a0c3528e8bed1e0b01621"
    assert checksum("lib/ansible/modules/core/system/service.py") == "2b34dc6bbaa6b75a8268645813c5588b7d1182d9"

# Generated at 2022-06-11 18:05:15.238861
# Unit test for function checksum
def test_checksum():
    assert checksum('test/support/test.py', hash_func=_md5) == '0b17d70c05e0d9d965116f2b0e35c0ce'


# Generated at 2022-06-11 18:05:24.732985
# Unit test for function md5
def test_md5():
    import unittest
    import tempfile
    import filecmp

    class TestMD5(unittest.TestCase):
        def test_md5(self):
            h = 'd41d8cd98f00b204e9800998ecf8427e'
            self.assertEqual(h, md5(tempfile.mktemp()))
            self.assertEqual(h, md5(to_bytes(tempfile.mktemp())))
            self.assertEqual(h, md5(u'/tmp/ansible-%s' % tempfile.mktemp()))

            dir = tempfile.mkdtemp()
            self.assertEqual(None, md5(dir))
            self.assertEqual(None, md5(u'/tmp/ansible-%s' % dir))

            t = tempfile.N