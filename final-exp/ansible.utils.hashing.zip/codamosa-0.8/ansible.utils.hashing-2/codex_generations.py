

# Generated at 2022-06-11 17:55:43.928576
# Unit test for function md5
def test_md5():
    md5_dict = dict()
    expected_md5_dict = dict()

    # create 1st test file
    f1 = open("test_md5", 'w')
    f1.write("test string")
    f1.close()

    # create 2nd test file
    f2 = open("test_md5_2", 'w')
    f2.write("test string of 2nd file")
    f2.close()

    # the expected results
    expected_md5_dict["test_md5"] = "a876d4f9cc9ddb83a1068d510f8266e6"
    expected_md5_dict["test_md5_2"] = "77d0c3d3b3f8b2fd402fd4a4b8938b79"

    # the results from

# Generated at 2022-06-11 17:55:48.362472
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s(b'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s(u'foo') == u'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-11 17:55:58.488345
# Unit test for function checksum
def test_checksum():
    import os
    import tempfile
    import shutil
    import unittest

    class ChecksumTestCase(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def test_checksum(self):
            filename = self.write_temp_file(contents='test')
            csum = secure_hash(filename)
            self.assertEqual(csum, 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3')

        def test_checksum_unicode(self):
            filename = self.write_temp_file(contents='\N{SNOWMAN}')
            csum = secure

# Generated at 2022-06-11 17:56:08.937865
# Unit test for function checksum
def test_checksum():
    from tempfile import mkstemp
    from shutil import move
    from os import fdopen, remove, path
    from ansible.utils.hashing import checksum
    import filecmp

    # Create the temporary file
    TEMP_DIR = 'tests/utils/hashing/'
    fd, src_path = mkstemp(dir=TEMP_DIR)
    tmp_file = fdopen(fd, 'w')
    tmp_file.write('data to write')
    tmp_file.close()

    # Create the destination file
    dst_path = TEMP_DIR + 'dst_file'
    move(src_path, dst_path)
    assert checksum(src_path) == checksum(dst_path)
    assert filecmp.cmp(src_path, dst_path)

    # Remove the

# Generated at 2022-06-11 17:56:12.091111
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-11 17:56:20.909721
# Unit test for function checksum
def test_checksum():
    from tempfile import NamedTemporaryFile

    data = 'this is some data'
    sha1_data = '0cbd3347e8f1a880e6f035959de56d664e9e2344'
    sha1_file = 'e86def6d8e2c2ce7d84b9c117f45564040d39b1f'
    md5_file= '8b4c4b14d003b4c9cd4f8a2eeb5109f2'

    f = NamedTemporaryFile()
    f.write(data)
    f.flush()
    f.seek(0)

    assert(checksum(f.name) == sha1_file)
    assert(checksum_s(data) == sha1_data)
    # Checks

# Generated at 2022-06-11 17:56:29.623563
# Unit test for function checksum
def test_checksum():
    import tempfile
    (fd, test_file) = tempfile.mkstemp()
    os.close(fd)
    try:
        with open(test_file, 'w') as f:
            f.write('test')

        assert checksum(test_file) == '098f6bcd4621d373cade4e832627b4f6'

        with open(test_file, 'w') as f:
            f.write('test1')

        assert checksum(test_file) != '098f6bcd4621d373cade4e832627b4f6'
    finally:
        os.remove(test_file)

# Generated at 2022-06-11 17:56:32.812459
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == '4d7bfb6a8d1e1c35f521d16a3015c5ba'


# Generated at 2022-06-11 17:56:40.593733
# Unit test for function checksum
def test_checksum():
    # create temporary file
    tmpfile = open('/tmp/ansible-test-checksum', 'w')
    tmpfile.write('ansible test string')
    tmpfile.close()

    # test function
    result = checksum('/tmp/ansible-test-checksum')
    assert result == '011b35f75a3ba3a01e89e9f9f88d3d3cce868df3'

    # clean up temporary file
    os.remove('/tmp/ansible-test-checksum')

# Generated at 2022-06-11 17:56:49.679395
# Unit test for function checksum
def test_checksum():

    def test_checksum_s(hash_func, data, expected):
        actual = checksum_s(data, hash_func)
        assert actual == expected, 'Expected checksum %s for data %s, got %s' % (expected, data, actual)

    test_checksum_s(sha1, '', 'da39a3ee5e6b4b0d3255bfef95601890afd80709')
    test_checksum_s(sha1, 'foo', '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33')
    test_checksum_s(sha1, 'bar', '62cdb7020ff920e5aa642c3d4066950dd1f01f4d')

# Generated at 2022-06-11 17:56:56.549299
# Unit test for function checksum
def test_checksum():
    filename = os.path.join(os.path.dirname(__file__), 'test_hash.py')
    assert checksum(filename) == 'a6f74f071bf0fa8742b24aec91e06d060fb3c292'


# Generated at 2022-06-11 17:57:01.024849
# Unit test for function md5
def test_md5():
    assert md5("/bin/sh") == "d7a6a4b664b4f1b0e4ffa915f9b79818"
    assert md5("/bin/sh") == md5("/bin/sh")  # repeatable



# Generated at 2022-06-11 17:57:02.973680
# Unit test for function md5s
def test_md5s():
     assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3' 


# Generated at 2022-06-11 17:57:11.312809
# Unit test for function md5s
def test_md5s():
    # Test the md5s function with a string
    str_result = md5s("test")
    assert str_result == "098f6bcd4621d373cade4e832627b4f6"

    # Test the md5s function with a list
    list_result = md5s(["test", "test"])
    assert list_result == "835da6a92f637da7321052e6a66f6aa2"

    # Test the md5s function with an empty string
    empty_str_result = md5s("")
    assert empty_str_result == "d41d8cd98f00b204e9800998ecf8427e"

    # Test the md5s function with a dict
    # On Python 3.2, sorted({'a':'b', 'c

# Generated at 2022-06-11 17:57:21.455747
# Unit test for function md5
def test_md5():
    from ansible.compat import sha

    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    digest = sha.new()
    blocksize = 64 * 1024
    infile = open("lib/ansible/module_utils/basic.py", "rb")
    block = infile.read(blocksize)
    while block:
        digest.update(block)
        block = infile.read(blocksize)
    infile.close()
    expected = digest.hexdigest()
    result = md5("lib/ansible/module_utils/basic.py")
    assert result == expected
    assert result == 'ed2b6f9a8c5b566ab3c0b0f7b1c8ee3e'


# Generated at 2022-06-11 17:57:30.064162
# Unit test for function checksum
def test_checksum():
    filename = 'test_file'
    test_data = 'test'
    try:
        f = open(filename, 'w')
        f.write(test_data)
        f.close()
        assert checksum(filename) == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
        assert checksum_s(test_data) == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    finally:
        os.unlink(filename)

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:57:41.266985
# Unit test for function checksum
def test_checksum():

    data = "This is a test string"

    # sha1 is the default hash
    hexdigest = secure_hash_s(data)
    assert hexdigest == "43c3390afc6d730f8a8f1a133b2d2b87ad87d1e8"

    # sha1 is the hash for data when explicitly specified
    hexdigest = secure_hash_s(data, hash_func=sha1)
    assert hexdigest == "43c3390afc6d730f8a8f1a133b2d2b87ad87d1e8"

    # md5 is not available in a FIPS 140-2 compliant system
    try:
        import hashlib
        hashlib.md5
        md5_is_available = True
    except Exception:
        md5_is

# Generated at 2022-06-11 17:57:51.175778
# Unit test for function md5
def test_md5():
    "test md5 with some known values"

# Generated at 2022-06-11 17:58:01.498926
# Unit test for function checksum
def test_checksum():
    checksum('README.rst') == "b2b9ad9a5048e68c7dee5e0f049be07cb8b16802"
    checksum('README.rst') == checksum('readme.rst')
    checksum('README.rst') == checksum_s(open('README.rst').read())

    assert(checksum('DOES_NOT_EXIST') is None)
    assert(checksum_s('something') != checksum_s('something else'))
    assert(checksum_s('something') != '')
    assert(checksum_s('') == '')
    assert(checksum_s('') == checksum_s('something else'))

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:58:11.488829
# Unit test for function checksum
def test_checksum():
    checksum_data = 'test-data'
    checksum_file = 'test-file'
    with open(checksum_file, 'w') as test_fh:
        test_fh.write(checksum_data)
    assert(checksum(checksum_file) == sha1(to_bytes(checksum_data)).hexdigest())
    assert(checksum(checksum_file, hash_func=_md5) == _md5(to_bytes(checksum_data)).hexdigest())
    os.remove(checksum_file)
    assert(checksum(checksum_file) is None)
    assert(checksum(checksum_file, hash_func=_md5) is None)


# Generated at 2022-06-11 17:58:21.578217
# Unit test for function md5s
def test_md5s():
    import random
    import time
    import string
    startTime = time.time()
    for x in range(200000):
        word = ""
        for y in range(random.randint(1, 20)):
            word += random.choice(string.lowercase)
        assert(len(md5s(word)) == 32)
    endTime = time.time()
    print("Total time to complete md5s test:  %f" % (endTime - startTime))

# Generated at 2022-06-11 17:58:30.586114
# Unit test for function checksum
def test_checksum():

    from tempfile import NamedTemporaryFile

    def md5sum(filename):
        import hashlib
        md5 = hashlib.md5()
        with open(filename, 'rb') as f:
            for chunk in iter(lambda: f.read(128 * md5.block_size), b''):
                md5.update(chunk)
        return md5.hexdigest()

    # Simple test
    tfile = NamedTemporaryFile(delete=False)
    tfile.write(b'this is some data')
    tfile.close()

    assert md5sum(tfile.name) == checksum(tfile.name, hash_func=_md5)
    assert md5sum(tfile.name) != checksum(tfile.name)
    assert checksum_s(b'this is some data') == m

# Generated at 2022-06-11 17:58:33.686241
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/ls") == "8f4d3c96f549bfab1ab651fd3a8ce72c"


# Generated at 2022-06-11 17:58:35.893950
# Unit test for function md5
def test_md5():
    assert md5("/dev/null") == "d41d8cd98f00b204e9800998ecf8427e"



# Generated at 2022-06-11 17:58:38.200804
# Unit test for function md5s
def test_md5s():
    assert md5s('foobar') == md5s('foobar')
    assert md5s('foo') != md5s('bar')



# Generated at 2022-06-11 17:58:46.106497
# Unit test for function md5s
def test_md5s():
    # There is a collision between 'hello' vs 'olleh' but the chance of this haunting us again is ridiculously low
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('world') == '7d793037a0760186574b0282f2f435e7'
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('world') == '68e656e9fa9179e4f762028f61beff6c'


# Generated at 2022-06-11 17:58:52.256021
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'd578021e0c7ad98d1e267e749b839ba6f7c4b4f4'
    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

# Generated at 2022-06-11 17:58:57.702378
# Unit test for function md5
def test_md5():
    test_string = 'Just a string'
    test_hexdigest = 'fba0e85c5ba7e8d0d82eb9ff9f2bdf82'
    if md5s(test_string) != test_hexdigest:
        raise AnsibleError('md5 test failed: %r != %r' % (test_string, test_hexdigest))
    print('md5 test success: %r = %r' % (test_string, test_hexdigest))



# Generated at 2022-06-11 17:59:02.759714
# Unit test for function md5s
def test_md5s():
    # should return None for non-existent file
    assert md5s('/some/non-existent/file') is None
    # should return None for directory
    assert md5s('/') is None
    # should return correct md5 for a regular file
    assert md5s('/etc/passwd') == '99e934c26d865fe2e1f12a1edb445e26'

# Generated at 2022-06-11 17:59:08.927280
# Unit test for function checksum
def test_checksum():
    filename = "test/files/testme"
    sum = checksum(filename)
    if sum == 'c4af5df5b59a0401d69ebd5d5f4e6b1f839be4b4':
        print("SUCCESS")
        print(sum)
    else:
        print("FAILURE")

# Main function.
if __name__ == "__main__":
    test_checksum()

# Generated at 2022-06-11 17:59:16.329430
# Unit test for function checksum
def test_checksum():
    import tempfile

    assert checksum('/usr/bin/python3') == '4d4f43cec0e6f37a7d8dcc80f9e9f9aa'
    assert checksum('/usr/bin/doesnotexist') is None
    assert checksum_s('Hello, world!') == '0a0a9f2a6772942557ab5355d76af442f8f65e01'

    fd, 

# Generated at 2022-06-11 17:59:23.521316
# Unit test for function md5
def test_md5():
    md5_func = None
    # We can't import hashlib in Ansible < 1.9.0
    try:
        from hashlib import md5
        md5_func = md5
    except ImportError:
        from md5 import md5
        md5_func = md5
    assert secure_hash_s('hello', md5) == '5d41402abc4b2a76b9719d911017c592'
    assert os.path.exists('lib/ansible/module_utils/basic.py')
    assert secure_hash('lib/ansible/module_utils/basic.py', md5) == 'c2377b0e59d3945b1e941f9aa8d1502d'
    # Tests for backwards compat

# Generated at 2022-06-11 17:59:26.857150
# Unit test for function checksum
def test_checksum():
    assert checksum('setup.py') == '59f7fc3c5e87164d0c55f6db0bfb5f1a8a11b9d0'



# Generated at 2022-06-11 17:59:32.108433
# Unit test for function md5
def test_md5():
    data = "The quick brown fox jumps over the lazy dog"
    data_hash = '9e107d9d372bb6826bd81d3542a419d6'
    assert(md5s(data) == data_hash)
    assert(md5(__file__) == 'e2c8b1acc40b12c74f3866f96c681b0d')


# Generated at 2022-06-11 17:59:36.358401
# Unit test for function checksum
def test_checksum():
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert checksum_s('hello world', hash_func=_md5) == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-11 17:59:42.953205
# Unit test for function md5
def test_md5():
    ''' test md5() '''
    # Test with non existing file, should return None
    assert md5('non-existing-file') is None
    # Test with directory, should return None
    import tempfile
    temp_dir = tempfile.mkdtemp()
    assert md5(temp_dir) is None
    # Test with file, should return md5 value
    import subprocess
    temp_file = tempfile.mkstemp()[1]
    subprocess.call("echo 'hello world' > %s" % temp_file, shell=True)
    assert md5(temp_file) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    # Test with file, with FIPS mode set
    os.environ['OPENSSL_ALLOW_PROXY_CIPHERS']

# Generated at 2022-06-11 17:59:47.997344
# Unit test for function checksum
def test_checksum():
    if checksum('myfile.txt') == '124e4bbe6396c94a907b04e2b0eaeeb6b300d6f4':
        return True
    else:
        return False


# Generated at 2022-06-11 17:59:56.368098
# Unit test for function checksum
def test_checksum():
    '''
    hashivault_token.py test_checksum
    '''
    assert checksum('/etc/passwd') == '82f7a87a28aecb7336d532e9b9642687'
    assert checksum('/etc/alternatives') is None
    assert checksum_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_s(b'foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert checksum_s(u'foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'


# Generated at 2022-06-11 18:00:02.686888
# Unit test for function checksum
def test_checksum():
    assert isinstance(checksum('/bin/ls'), str)
    assert isinstance(checksum('/bin/ls', hash_func=_md5), str)
    assert checksum('/bin/ls') == checksum_s('/bin/ls')
    assert checksum('/bin/ls', hash_func=_md5) == md5('/bin/ls')
    assert checksum_s('/bin/ls', hash_func=_md5) == md5s('/bin/ls')

# Generated at 2022-06-11 18:00:07.043631
# Unit test for function checksum
def test_checksum():
    f = open(__file__)
    f_checksum = secure_hash_s(f.read())
    f.close()
    assert(checksum(__file__) == f_checksum)

# Generated at 2022-06-11 18:00:17.599869
# Unit test for function md5s
def test_md5s():
    assert md5s('test string') == 'ee4f7b7046a2bafc724cd9ebfbdb11d0'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('Test String') == 'c1f6c961a11b7a9cf2c8ec92f6d08c6b'
    assert md5s(':)') == 'd2e17f6ca47e6c20b01e1679c7cd23e2'


# Generated at 2022-06-11 18:00:20.486252
# Unit test for function md5s
def test_md5s():
    assert md5s("test") == "098f6bcd4621d373cade4e832627b4f6"


# Generated at 2022-06-11 18:00:23.917820
# Unit test for function md5s
def test_md5s():
    if md5s('hello') == '5d41402abc4b2a76b9719d911017c592':
        return True
    return False


# Generated at 2022-06-11 18:00:27.680967
# Unit test for function md5s
def test_md5s():
    assert md5s("foobar") == "3858f62230ac3c915f300c664312c63f"
    assert md5s(u"foobar") == "3858f62230ac3c915f300c664312c63f"


# Generated at 2022-06-11 18:00:35.998355
# Unit test for function checksum
def test_checksum():
    """testing with dummy data"""
    s = 'hello world'
    cs = checksum_s(s)
    assert cs == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

    cs = checksum('/bin/ls')
    assert cs == '1c895e56ae8d8ab35ba6524c1b9e9b9f8b2d1b2a' or cs == 'bb94f8bde4ca4f2ae3749ebe9b856e98'


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:00:37.915704
# Unit test for function md5s
def test_md5s():
    assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"



# Generated at 2022-06-11 18:00:40.944212
# Unit test for function md5s
def test_md5s():
    assert md5s("I'm a test string") == '2bc3cc9e3f51f45297aa25eac832fbea'

# Run tests for this module

# Generated at 2022-06-11 18:00:46.059611
# Unit test for function md5
def test_md5():
    ''' md5 should return the same result as md5s '''
    test_string = "hello world"
    result_md5 = md5s(test_string)
    result_md5s = md5s(test_string)
    assert result_md5 == result_md5s



# Generated at 2022-06-11 18:00:56.560181
# Unit test for function md5
def test_md5():
    """Unit test for function md5"""
    import tempfile

    # Create a temporary empty file
    handle, name = tempfile.mkstemp()
    # os.close(handle)

    # Verify that md5 of an empty file is the same as an empty string
    assert md5(name) == md5s('')

    # Try a bunch of different strings
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hi') == '49f68a5c8493ec2c0bf489821c21fc3b'
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

    # Try a bunch of different small files

# Generated at 2022-06-11 18:01:07.853954
# Unit test for function md5s
def test_md5s():
    '''Test basic functionality of md5s'''

    # bad checksum for file
    assert md5s(None) == md5s(None)

    # check that two empty files returns same hash
    f1 = open('/tmp/test.txt', 'w')
    f2 = open('/tmp/test2.txt', 'w')
    f1.close()
    f2.close()
    assert md5s(open('/tmp/test.txt', 'r').read()) == md5s(open('/tmp/test2.txt', 'r').read())

    # remove files just created
    os.remove('/tmp/test.txt')
    os.remove('/tmp/test2.txt')



# Generated at 2022-06-11 18:01:13.322112
# Unit test for function checksum
def test_checksum():
    return checksum("/bin/ls") == '1865e8d1b2a2c7eb9a889ebd69c8b4f4'


# Generated at 2022-06-11 18:01:20.730210
# Unit test for function md5
def test_md5():

    from tempfile import NamedTemporaryFile

    # check that md5 works with empty file
    f = NamedTemporaryFile()
    assert (not os.path.exists(f.name)) or md5(f.name) is None

    # Writes a temporary file and check the md5 of this file
    test_string = "This is a test string"
    f.write(test_string)
    f.seek(0)
    assert md5(f.name) == 'f7ff9e8b7bb2e09b70935a5d785e0cc5'



# Generated at 2022-06-11 18:01:30.934589
# Unit test for function md5
def test_md5():
    import tempfile
    infile = tempfile.NamedTemporaryFile(delete=False)
    try:
        infile.write('hello world')
        infile.close()
        # Make sure the hash algorithm is stable
        assert md5(infile.name) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
        assert checksum(infile.name) == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
        assert md5("/bin/false") == 'feaafc0d9e8cf0c1e00a72a0c412ca7d'
    finally:
        os.unlink(infile.name)


# Generated at 2022-06-11 18:01:36.568736
# Unit test for function md5s
def test_md5s():
    assert md5s("foo") == "acbd18db4cc2f85cedef654fccc4a4d8"
    assert md5s("bar") == "37b51d194a7513e45b56f6524f2d51f2"


# Generated at 2022-06-11 18:01:39.330587
# Unit test for function md5s
def test_md5s():
    # here the md5 hash for "hello"
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"

# Generated at 2022-06-11 18:01:43.865986
# Unit test for function md5s
def test_md5s():
    test_str = 'test md5'
    md5sum = md5s(test_str)
    assert md5sum == 'f1d2d2f924e986ac86fdf7b36c94bcdf32beec15'

# Generated at 2022-06-11 18:01:46.969472
# Unit test for function checksum
def test_checksum():
    filename = 'test_checksum'
    with open(filename, 'w') as f:
        f.write('foobar')

    h = secure_hash(filename)
    # Remove test file
    os.remove(filename)

    assert h == '8843d7f92416211de9ebb963ff4ce28125932878'

# Generated at 2022-06-11 18:01:56.747541
# Unit test for function checksum
def test_checksum():
    assert checksum('library/sosreport.py', hash_func=sha1) == '25f33c48d94bcca02a8c8a2adf98c9bd257f97e8'
    assert checksum_s('This is a basic string', hash_func=sha1) == '66f9ebf53a8ca7ee3e3c89a7d6b0f8378215f81e'
    assert checksum_s('This is a basic string', hash_func=sha1) != checksum_s('This is a basic string.', hash_func=sha1)
    assert checksum_s('This is a basic string', hash_func=sha1) != checksum_s('This is a basic strings', hash_func=sha1)

# Generated at 2022-06-11 18:02:02.224151
# Unit test for function md5
def test_md5():
    path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_utils.py')
    m = md5(path)
    assert len(m) == 32, "MD5 should be a string of length 32"
    assert m == '32145a5a5a1b5d539e471c6d714ca6f4'

# Generated at 2022-06-11 18:02:12.561618
# Unit test for function md5s
def test_md5s():
    ''' md5s() return value must match the output of the "md5sum" utility '''
    (rc, out, err) = module.run_command(["which", "md5sum"])
    if rc == 0:
        (rc, md5sum_output, md5sum_err) = module.run_command(["echo", "foo", "|", "md5sum"])
        (md5sum_output, md5sum_err) = (md5sum_output.rstrip(), md5sum_err)
        (rc, out, err) = module.run_command(["echo", "foo", "|", "md5sum"])
        (out, err) = (out.rstrip(), err)

# Generated at 2022-06-11 18:02:19.195781
# Unit test for function md5s
def test_md5s():
    string = 'hello'
    expected = '5d41402abc4b2a76b9719d911017c592'

    assert expected == md5s(string)



# Generated at 2022-06-11 18:02:23.106213
# Unit test for function md5
def test_md5():
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5('test/test-encoding/utf-16-le.txt') == '9a239f008c6b40a6ec8aa6f784848d2a'

# Generated at 2022-06-11 18:02:25.422591
# Unit test for function checksum
def test_checksum():
    assert checksum('/etc/passwd') == 'a44205e7f529d9b71eb9b3c3fba3a7ef'

# Generated at 2022-06-11 18:02:29.439431
# Unit test for function md5s
def test_md5s():#
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('Hello') == '8b1a9953c4611296a827abf8c47804d7'

# Generated at 2022-06-11 18:02:36.991885
# Unit test for function md5
def test_md5():
    data = 'foo'
    assert md5s(data) == 'acbd18db4cc2f85cedef654fccc4a4d8'
    # This can't work because there is no temporary file on the filesystem
    #named_file = mkstemp()
    #assert md5(named_file[1]) == 'acbd18db4cc2f85cedef654fccc4a4d8'
    #os.remove(named_file[1])


# Generated at 2022-06-11 18:02:45.831660
# Unit test for function checksum
def test_checksum():
    ''' test checksum '''

    if _md5:
        assert md5('/bin/ls') == '5f5c3a77f3e47f61e1d8dbd59b2e5b5a'
    assert checksum('/bin/ls') == 'e01a7ec1e42d6b33c6aadea6f9d6d876eac7cf6c'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-11 18:02:54.556587
# Unit test for function checksum
def test_checksum():
    if not checksum('lib/ansible/module_utils/basic.py') == '4b975bd824504cf4c4a2ee0e17ff9a9bacbf7949':
        print("Basic checksum failed.")
        exit(1)
    if not checksum('lib/ansible/modules/core/commands/command.py') == 'c8a6d0d6ba17a6aef3d3c63d3fdc7a385b0202e7':
        print("command.py checksum failed.")
        exit(1)
    if not checksum('bin/ansible') == 'c165a440038a08e869b2d2c7de9e9bf931a81385':
        print("bin/ansible checksum failed.")
        exit(1)


# Generated at 2022-06-11 18:03:00.314421
# Unit test for function md5
def test_md5():
   if (md5("/bin/ls") != "6b7f2a19d8a0b6cccf45d7f1dcfca19e"):
      raise AnsibleError("md5 test failed")

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:03:09.419883
# Unit test for function md5
def test_md5():
    # Create temporary file
    tmpfile = open('/tmp/test_md5.txt','w')
    tmpfile.write('42\n')
    tmpfile.close()

    checksum = md5('/tmp/test_md5.txt')
    # On a brand new system it should be equal to c0e93b8fb977f60d46d74c91fa6aecfa
    if checksum != 'c0e93b8fb977f60d46d74c91fa6aecfa':
        print('md5 function test failed')
        os.remove('/tmp/test_md5')
        return False

    checksum = md5s('42\n')
    # On a brand new system it should be equal to c0e93b8fb977f60d46d74c91fa6a

# Generated at 2022-06-11 18:03:13.955181
# Unit test for function checksum
def test_checksum():
    assert sha1('hello world').hexdigest() == checksum_s('hello world')
    assert sha1('hello world').hexdigest() == checksum('/usr/share/dict/words')

# Generated at 2022-06-11 18:03:24.138369
# Unit test for function md5s
def test_md5s():
    test_data = 'foobar'
    assert md5s(test_data) == '3858f62230ac3c915f300c664312c63f'
    assert md5s(b'foobar') == '3858f62230ac3c915f300c664312c63f'


# Generated at 2022-06-11 18:03:35.479123
# Unit test for function md5
def test_md5():

    # Test with empty file
    fh = open('/tmp/emptyfile.txt', 'w')
    fh.close()
    assert(md5('/tmp/emptyfile.txt') == 'd41d8cd98f00b204e9800998ecf8427e')
    os.remove('/tmp/emptyfile.txt')

    # Test with full file
    fh = open('/tmp/ansible-test', 'w')
    fh.write('ansible')
    fh.close()
    assert(md5('/tmp/ansible-test') == 'adb7116fdc8bdf760797c17402b6af56')
    os.remove('/tmp/ansible-test')

    # Test with non-existing file

# Generated at 2022-06-11 18:03:45.095265
# Unit test for function md5
def test_md5():
    ''' test md5 function '''
    from tempfile import NamedTemporaryFile

    # test with normal file
    fd = NamedTemporaryFile(delete=False)
    fd.write('12345')
    fd.close()
    assert md5(fd.name) == '827ccb0eea8a706c4c34a16891f84e7b'
    os.unlink(fd.name)

    # test with non existing file
    assert md5('nosuchfile') is None

    # test with empty file
    fd = NamedTemporaryFile(delete=False)
    fd.close()
    assert md5(fd.name) == 'd41d8cd98f00b204e9800998ecf8427e'
    os.unlink(fd.name)

    # test

# Generated at 2022-06-11 18:03:49.548767
# Unit test for function md5
def test_md5():
    assert md5s("abc") == "900150983cd24fb0d6963f7d28e17f72"
    assert md5("test/sanity/utils/test_md5") == "e6d7f51148ebcfa3f1209d3f203c90e4"

# Generated at 2022-06-11 18:03:50.832603
# Unit test for function checksum
def test_checksum():
    import sys
    filename = sys.argv[1]
    print(checksum(filename))


# Generated at 2022-06-11 18:04:00.525218
# Unit test for function checksum
def test_checksum():
    """ //TODO - Fix tests so that they work on any system
    """

    from ansible.module_utils import basic

    # Test string
    data = "Hello world!"
    assert checksum_s(data) == "0a4d55a8d778e5022fab701977c5d840bbc486d0"

    # Test file
    random_lines = "random1\nrandom2\nrandom3\n"
    basic._write_bytes('/tmp/test_checksum', random_lines)
    assert checksum('/tmp/test_checksum') == "fc3348813eb2a9a05fbd7b039963ce5c7fb5158a"

# Generated at 2022-06-11 18:04:02.665717
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-11 18:04:09.599512
# Unit test for function md5
def test_md5():
    ''' test md5 function '''

    # Create a temporary file
    (fd, test_filename) = tempfile.mkstemp()
    fp = os.fdopen(fd, "w")
    fp.write("test")
    fp.close()

    if md5(test_filename) != "098f6bcd4621d373cade4e832627b4f6":
        raise ValueError("test_md5() failed")
    os.unlink(test_filename)


# Generated at 2022-06-11 18:04:12.838398
# Unit test for function md5s
def test_md5s():
    assert md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3"
    assert md5s("hello world".encode("utf-8")) == "5eb63bbbe01eeed093cb22bb8f5acdc3"

# Generated at 2022-06-11 18:04:15.957892
# Unit test for function md5s
def test_md5s():
    assert md5s(b'foobar') == '3858f62230ac3c915f300c664312c63f'


if __name__ == '__main__':
    import sys
    import doctest
    module = sys.modules[__name__]
    doctest.testmod(module)

# Generated at 2022-06-11 18:04:24.467970
# Unit test for function md5
def test_md5():
    assert md5('DEADBEEF') is None
    # TODO: make this test work
    #assert md5(__file__) == md5s(open(__file__, 'rb').read())

# Generated at 2022-06-11 18:04:28.186921
# Unit test for function checksum
def test_checksum():
    assert checksum('/usr/bin/python') == checksum('/usr/bin/python')
    assert checksum('/usr/bin/python') != checksum('/usr/bin/ruby')
    assert checksum('/usr/bin/python') != checksum('/usr/bin/ruby2')


# Generated at 2022-06-11 18:04:30.984843
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-11 18:04:36.696653
# Unit test for function md5
def test_md5():
    md5_data = b"angryMonkey"    # DO NOT TRANSLATE
    hsh = 'e52e6fcb67b2368c8965bd8b7f0f59b3'
    assert md5s(md5_data) == hsh
    testfile = os.path.join(os.path.dirname(__file__), 'testfile')
    assert md5(testfile) == '2cc7a77684f8788027146a6c5059f7a9'

# Generated at 2022-06-11 18:04:41.673548
# Unit test for function md5
def test_md5():
    """returns the md5sum of the specified file"""

    # digest of sample_file
    sample_file = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))) + "/test/test_module/sample_file"
    checksum = md5(sample_file)
    assert checksum == "39aeec64f1755a0fb7cd4898df1a9496"



# Generated at 2022-06-11 18:04:44.799412
# Unit test for function md5s
def test_md5s():
    data = "foo"
    digest = md5s(data)
    assert digest == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-11 18:04:46.786910
# Unit test for function md5s
def test_md5s():
    assert md5s("foobar") == "8843d7f92416211de9ebb963ff4ce28125932878"

# Generated at 2022-06-11 18:04:49.688121
# Unit test for function md5s
def test_md5s():
    assert md5s('blah') == 'e8dc4081b13434b45189a720b77b6818'

# Generated at 2022-06-11 18:04:52.297663
# Unit test for function md5
def test_md5():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:05:00.528246
# Unit test for function md5
def test_md5():
    import shutil
    import tempfile
    tempdir = tempfile.mkdtemp()
    # create a file
    testfile = '%s/test.txt' % tempdir
    with open(testfile, 'w') as f:
        f.write('This is a test')
    # we don't know what the md5 hash will be on every machine,
    # so just make sure it doesn't return None and it doesn't throw
    # an exception
    assert md5(testfile) is not None
    # clean up
    shutil.rmtree(tempdir, ignore_errors=True)

# Generated at 2022-06-11 18:05:09.443178
# Unit test for function md5s
def test_md5s():
	text = "This is a test string"
	digest = md5s(text)
	assert digest == "2a8f7cdc0e1ba37595fdc0f415fbfd71"

# Generated at 2022-06-11 18:05:16.127477
# Unit test for function md5s
def test_md5s():
    if _md5:
        data1 = md5s('test')
        # The hex digest of 'test' is 098f6bcd4621d373cade4e832627b4f6
        data2 = md5s('test')
        assert data1 == '098f6bcd4621d373cade4e832627b4f6'
        assert data1 == data2
    else:
        # _md5 should be None since we are not running in FIPS mode
        assert _md5 == None


# Generated at 2022-06-11 18:05:19.334517
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s('Hello World') == 'b10a8db164e0754105b7a99be72e3fe5'

# Generated at 2022-06-11 18:05:26.885845
# Unit test for function checksum
def test_checksum():
    '''
    Function to test checksum function
    '''
    directory = os.path.dirname(__file__)

    # Write a text file with signature
    testfile = os.path.join(directory, "testfile")
    with open(testfile, "w") as f:
        f.write("helloworld")

    # Test checksum method
    signature = secure_hash(testfile)
    assert signature == checksum(testfile)

    try:
        os.remove(testfile)
    except OSError:
        pass

# Generated at 2022-06-11 18:05:36.425013
# Unit test for function checksum
def test_checksum():
    ''' validate checksum functionality '''
    import tempfile
    from ansible.module_utils import basic

    data = b'The quick brown fox jumped over the lazy dog'

    # Data checksum
    data_sum = checksum_s(data)
    assert data_sum == '2fd4e1c6 7a2d28fc ed849ee1 bb76e739 1b93eb12'

    # File checksum
    testfile = tempfile.NamedTemporaryFile()
    testfile.write(data)
    testfile.flush()
    file_sum = checksum(testfile.name)
    assert file_sum == '2fd4e1c6 7a2d28fc ed849ee1 bb76e739 1b93eb12'