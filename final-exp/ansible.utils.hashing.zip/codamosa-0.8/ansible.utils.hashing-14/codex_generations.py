

# Generated at 2022-06-11 17:55:37.256127
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest
    import tempfile
    import os
    import shutil
    import filecmp

    class TestChecksumModule(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_checksum_file(self):
            srcfile = 'testdata/checksum_testfile'
            destfile = self.tmpdir + '/testfile'
            shutil.copyfile(srcfile, destfile)
            self.assertEqual(checksum(srcfile), checksum(destfile))

        def test_checksum_string(self):
            srcstring = 'this is a test'

# Generated at 2022-06-11 17:55:47.599571
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    from ansible.compat.six import b

    class TestChecksum(unittest.TestCase):
        def setUp(self):
            self.filename = '/path/to/file'
            self.dummydata = b('dummy data')

            self.mock_open = MagicMock()
            self.mock_open.return_value.__enter__.return_value = self.dummydata
            self.mock_open.return_value.__exit__.return_value = None


# Generated at 2022-06-11 17:55:58.136003
# Unit test for function checksum
def test_checksum():
    from ansible.utils.hashing import checksum, checksum_s

    assert checksum_s(b'Hello World') == checksum('./test/unit/utils/hashing/input/checksum_hash_test_file_1')
    assert checksum_s(b'Hello World\n') == checksum('./test/unit/utils/hashing/input/checksum_hash_test_file_2')
    assert checksum_s(b'Hello World\n\n') == checksum('./test/unit/utils/hashing/input/checksum_hash_test_file_3')
    assert checksum_s(b'Hello World\n\n\n') == checksum('./test/unit/utils/hashing/input/checksum_hash_test_file_4')

# Generated at 2022-06-11 17:56:08.768406
# Unit test for function checksum
def test_checksum():
    # Create a file with a known name and data
    fn = 'ansible_checksum_test'
    fh = open(fn, 'w')
    fh.write('test data')
    fh.close()

    # Verify what we wrote is what we get
    assert checksum(fn) == 'c0f0451a3f95c3a2fae4f3c1e4aa4d4c00f22b8c'

    # Verify that a non-existent file returns None
    assert checksum('ansible_checksum_test_nofile') is None

    # Clean up our test file
    os.remove(fn)

    # Verify that a directory returns None
    os.mkdir(fn)
    assert checksum(fn) is None
    os.rmdir(fn)

    # Verify that

# Generated at 2022-06-11 17:56:19.405654
# Unit test for function checksum
def test_checksum():
    ''' function_module.py:test_checksum() '''

    if not os.path.exists("./test_checksum_file"):
        f = open("./test_checksum_file",'w')
        f.write("Now is the time for all good men to come to the aid of their country")
        f.close()

    if checksum('./test_checksum_file') != 'c8c8248d6b0a6a994098c9d6e8bb2eec84646a71':
        raise Exception("Failed checksum test 1")

    if checksum_s("") != 'da39a3ee5e6b4b0d3255bfef95601890afd80709':
        raise Exception("Failed md5s test 1")


# Generated at 2022-06-11 17:56:29.679744
# Unit test for function checksum
def test_checksum():
    from tempfile import NamedTemporaryFile

    # Hashes for known content
    known_hashes = {
        "foo": "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33",
        "bar": "62cdb7020ff920e5aa642c3d4066950dd1f01f4d",
        "\n": "68b329da9893e34099c7d8ad5cb9c940",
    }

    # Create a tempfile to be used in all the next tests
    with NamedTemporaryFile() as f:
        f.write(b'foo')
        f.seek(0)

        # Compute the checksum of a string
        assert checksum_s('foo') == known_hashes['foo']
        assert checksum_

# Generated at 2022-06-11 17:56:38.457278
# Unit test for function checksum
def test_checksum():
    assert checksum(os.path.join(os.path.dirname(__file__), 'crypto_utils.py')) == 'd98d58f84d3e8f03cdadf9d85b7eefb89de3b593'
    assert checksum_s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert os.path.exists(os.path.join(os.path.dirname(__file__), 'crypto_utils.py'))



# Generated at 2022-06-11 17:56:43.953431
# Unit test for function md5
def test_md5():
    data = 'hello world'
    filename = './test_file.txt'
    md5_value = '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5(filename) == None
    assert md5s(data) == md5_value
    f = open(filename, 'w')
    f.write(data)
    f.close()
    assert md5(filename) == md5_value
    assert md5s(data) == md5_value
    os.remove(filename)



# Generated at 2022-06-11 17:56:45.981846
# Unit test for function md5s
def test_md5s():
    assert(md5s("hello world") == "5eb63bbbe01eeed093cb22bb8f5acdc3")


# Generated at 2022-06-11 17:56:55.381219
# Unit test for function checksum
def test_checksum():
    '''
    Test checksum module
    '''
    import tempfile

    (fd, fname) = tempfile.mkstemp()
    try:
        os.write(fd, 'foo')
        assert checksum(fname) == checksum_s('foo')
    finally:
        os.close(fd)
        os.unlink(fname)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# FIXME: change the hashlib import to support python 2.4?
# try:
#     from hashlib import md5
# except ImportError:
#     from md5 import md5

# Generated at 2022-06-11 17:57:06.013395
# Unit test for function md5s
def test_md5s():
    md5s_test = md5s("michael dehaan")
    if md5s_test != "755424b5e6baf3b1e9f8a66f32a0c63e":
        raise AssertionError('MD5S Unit Test Failed, got %s instead of expected 755424b5e6baf3b1e9f8a66f32a0c63e' % md5s_test)


# Generated at 2022-06-11 17:57:17.634987
# Unit test for function md5
def test_md5():
    ''' sha1  '''
    assert secure_hash_s('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert secure_hash_s(unicode('foo')) == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s(unicode('foo')) == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-11 17:57:28.321565
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest

    class TestChecksum(unittest.TestCase):

        data = open(__file__, 'rb').read()

        def test_checksum_s_with_sha1(self):
            self.assertEqual(checksum_s(self.data, sha1), '99a5a6a95c6ef4f4f9a9b831d64b78cdd43a1e98')

        def test_checksum_with_sha1(self):
            self.assertEqual(checksum(__file__, sha1), '99a5a6a95c6ef4f4f9a9b831d64b78cdd43a1e98')


# Generated at 2022-06-11 17:57:32.971804
# Unit test for function md5
def test_md5():
    f = open('/tmp/test_md5', 'w+')
    f.write('foo')
    f.close()
    sum = md5('/tmp/test_md5')
    assert sum == 'acbd18db4cc2f85cedef654fccc4a4d8'
    os.unlink('/tmp/test_md5')


# For backwards compat.  Do not use unless needed for something like
# integration with third party software
mtime = os.path.getmtime

# Generated at 2022-06-11 17:57:40.711880
# Unit test for function md5
def test_md5():
    from tempfile import NamedTemporaryFile
    import shutil
    import os

    # generate a tempfile and fill it with some sample data
    (fd, path) = NamedTemporaryFile(delete=False)
    try:
        fd.write(b"test")
        fd.close()

        # test if the md5 checksum is correct
        assert md5(path) == "098f6bcd4621d373cade4e832627b4f6"
    finally:
        os.unlink(path)


# Generated at 2022-06-11 17:57:50.707567
# Unit test for function checksum
def test_checksum():
    # Create a temporary file for testing with
    (fd, fp) = tempfile.mkstemp()
    assert fp == '/private' + fp

    # Try an empty file first
    with open(fp, 'w') as f:
        assert f.write("") == 0

    # Verify the checksum is correct for an empty file
    assert checksum(fp) == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'

    # Verify the checksum is correct for a binary file
    # just in case the hashlib is broken on the platform
    assert checksum(__file__) == '70a1b18d1d0e44ddfc3cf939c9b6e7b6d8f6dff1'

    # Clean up

# Generated at 2022-06-11 17:57:57.472301
# Unit test for function md5s
def test_md5s():
    assert md5s("hello"), "5d41402abc4b2a76b9719d911017c592"
    assert md5s("helloworld"), "fc5e038d38a57032085441e7fe7010b0"

if __name__ == '__main__':
    test_md5s()

# Generated at 2022-06-11 17:58:08.954409
# Unit test for function checksum
def test_checksum():
    import tempfile
    tmpd = tempfile.mkdtemp(prefix='ansible_test_checksum')
    tmpf = os.path.join(tmpd, 'test_checksum')

    # make a file with some known data
    f = open(tmpf,'w')
    f.write('test1')
    f.close()

    # get checksum from function and from md5sum command
    checksum_test = checksum(tmpf)
    checksum_cmd = os.popen('md5sum %s' % tmpf).read().split()[0]

    # cleanup
    os.remove(tmpf)
    os.rmdir(tmpd)

    if checksum_test == checksum_cmd:
        print('checksum test successful')
    else:
        sys.exit('checksum test failed')

# Generated at 2022-06-11 17:58:13.186351
# Unit test for function checksum
def test_checksum():
    filename = './lib/ansible/modules/network/basics/ping.py'
    test_checksum = '6e837d11a423ddf5b6f96c13c8eabd33e0e7c6e1'
    assert checksum(filename) == test_checksum

# Generated at 2022-06-11 17:58:14.943515
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls')


# Generated at 2022-06-11 17:58:24.927549
# Unit test for function md5
def test_md5():
    data = "this is a test"
    result = md5s(data)
    # a948904f2f0f479b8f8197694b30184b0d2ed1c1cd2a1ec0fb85d299a192a447
    assert result == 'a948904f2f0f479b8f8197694b30184b0d2ed1c1cd2a1ec0fb85d299a192a447'

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 17:58:32.561464
# Unit test for function checksum
def test_checksum():
    from tempfile import mkstemp
    from os import remove
    assert checksum_s('foo') == "0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33"
    assert checksum('/proc/self/cmdline') == 'd41d8cd98f00b204e9800998ecf8427e'
    fd, fn = mkstemp()
    try:
        os.write(fd, 'foo')
        os.close(fd)
        assert checksum(fn) == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
        remove(fn)
        assert checksum(fn) is None
    finally:
        if os.path.exists(fn):
            remove

# Generated at 2022-06-11 17:58:41.180055
# Unit test for function md5s
def test_md5s():
    from io import StringIO
    from sys import stdout
    from difflib import unified_diff

    def check(data, expected):
        result = md5s(data)
        assert expected == result, \
            "md5s(%r) did not give the expected result.\n" \
            "Expected %r but got %r" % (data, expected, result)

    check(
        """\
- debug: msg="Hello"
  name: Hello World
""",
        "c08070f87e0c37a23f3b619138a6a196")

    check(
        """\
-
  debug: msg="Hello"
  name: Hello World
""",
        "2bea2e1206e7c91715e910b7c32f93bf")


# Generated at 2022-06-11 17:58:49.615974
# Unit test for function md5
def test_md5():
    import tempfile
    (fd, fname) = tempfile.mkstemp()
    test_string = u'string with unicode characters äöüß'.encode('utf-8')
    os.write(fd, test_string)
    os.close(fd)
    assert md5(fname) == md5s(test_string)
    os.remove(fname)
    assert md5(fname) == None
    assert secure_hash_s(u'', hash_func=_md5) == u'd41d8cd98f00b204e9800998ecf8427e'
    assert secure_hash_s(u'abc', hash_func=_md5) == u'900150983cd24fb0d6963f7d28e17f72'
    assert secure_hash_

# Generated at 2022-06-11 17:58:58.650393
# Unit test for function checksum
def test_checksum():
    # Test a few basic cases
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('a') == '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8'
    assert checksum_s('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert checksum_s('abcdefghijklmnopqrstuvwxyz') == '32d10c7b8cf96570ca04ce37f2a19d84240d3a89'
    # Test if it works with unicode objects

# Generated at 2022-06-11 17:59:02.721518
# Unit test for function md5
def test_md5():
    import tempfile
    (fd, path) = tempfile.mkstemp()
    with open(path, 'w') as f:
        f.write('foo')
    assert md5(path) == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-11 17:59:11.292826
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('The quick brown fox jumps over the lazy dog') == '9e107d9d372bb6826bd81d3542a419d6'
    assert md5s('The quick brown fox jumps over the lazy dog.') == 'e4d909c290d0fb1ca068ffaddf22cbd0'


# Generated at 2022-06-11 17:59:14.413532
# Unit test for function md5
def test_md5():
    print(md5s('password'))
    print(md5_s('password'))
    print(secure_hash_s('password'))
    print(secure_hash_s('password', _md5))


# Generated at 2022-06-11 17:59:18.310100
# Unit test for function md5s
def test_md5s():
    try:
        assert md5s('foobar') == '3858f62230ac3c915f300c664312c63f'
    except:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')


# Generated at 2022-06-11 17:59:20.563198
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-11 17:59:33.704325
# Unit test for function md5
def test_md5():

    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')

    # Verify that the md5 function returns the expected string of
    # a known file with a known md5 hash value.
    # test_md5_known_file_known_hash
    # verify that the function returns a string
    # verify that the string is 32 characters long (the length of an md5 string)
    # verify that the string matches the expected string
    #
    # Note: Use the /etc/fstab file.  It is ubiquitous, and
    # is expected to be present on any system.
    #
    # Note: The length of an md5 sum string is 32 characters
    #
    # The md5 sum of the /etc/fstab file is: 1ff67f4925b9f0b3a3cd

# Generated at 2022-06-11 17:59:41.414585
# Unit test for function checksum
def test_checksum():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    try:
        fd = open('/etc/ansible/hashing', 'rb')
        data = fd.read()
        fd.close()
    except IOError as e:
        raise AnsibleError("error while accessing the file /etc/ansible/hashing, error was: %s" % e)

    if checksum_s(data) != checksum('/etc/ansible/hashing'):
        raise AnsibleError("hashing /etc/ansible/hashing failed")

    # We should not be able to hash directories
    if checksum('/etc/ansible') is not None:
        raise AnsibleError("should not be able to hash a directory")

    # Make sure we can hash some unicode stuff

# Generated at 2022-06-11 17:59:53.181874
# Unit test for function md5
def test_md5():
    # a known md5 checksum
    msg = 'foo'
    msg_md5 = 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s(msg) == msg_md5
    assert checksum_s(msg) == msg_md5

    # a test for open file
    test_file_name = '/tmp/ansible_test_file'
    with open(test_file_name, 'w') as f:
        f.write(msg)

    test_file_md5 = '7815696ecbf1c96e6894b779456d330e'
    assert md5(test_file_name) == test_file_md5
    assert checksum(test_file_name) == test_file_md5


# Generated at 2022-06-11 17:59:56.052950
# Unit test for function md5
def test_md5():
    assert md5s('test') == "098f6bcd4621d373cade4e832627b4f6"

# Generated at 2022-06-11 17:59:59.401079
# Unit test for function md5
def test_md5():
    assert md5("/bin/ls") == "533fc8bd58c8db1dabdc49cd775d5792"


__all__ = ['md5', 'md5s', 'checksum', 'checksum_s']

# Generated at 2022-06-11 18:00:05.988342
# Unit test for function checksum
def test_checksum():
    ''' make sure known checksum output is sane '''
    data = 'foobar'
    assert(checksum_s(data) == '8843d7f92416211de9ebb963ff4ce28125932878')
    assert(checksum_s(data, sha1) == '8843d7f92416211de9ebb963ff4ce28125932878')

    assert(md5s(data) == '3858f62230ac3c915f300c664312c63f')
    assert(md5s(data, _md5) == '3858f62230ac3c915f300c664312c63f')
    data = ''

# Generated at 2022-06-11 18:00:08.008951
# Unit test for function md5
def test_md5():
    assert md5("/etc/ansible/hosts") == "a936ea18e40fcec07f2afc2eee8f498d"
    assert md5("/does/not/exist") is None
    assert md5("/etc/passwd/") is None

# Generated at 2022-06-11 18:00:14.297145
# Unit test for function checksum
def test_checksum():
    assert checksum_s('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert checksum_s('norbert') == 'b0bf847e664f4a4a3e3ccd6c8d38f1ce937b4521'
    assert checksum_s(None) == 'f69b5a8c29758eab2285ee9c9e9955a8f4f4f4f4'
    assert checksum(os.devnull) == 'a69f76d3f3ba8c14ef1ebbe0bbe3fdb7'


# Generated at 2022-06-11 18:00:17.595839
# Unit test for function md5s
def test_md5s():
    md5_good = md5s('good')
    md5_bad = md5s('bad')
    answer = '9ceb547b8ce52d50de7798533255ad1a'
    assert answer == md5_good
    assert answer != md5_bad

# Generated at 2022-06-11 18:00:20.865894
# Unit test for function md5s
def test_md5s():
    assert md5s(to_bytes('ansible', errors='surrogate_or_strict')) == '6f8db599de986fab7a21625b7916589c'

# Generated at 2022-06-11 18:00:34.041656
# Unit test for function md5s
def test_md5s():
    import pytest

    value = md5s("foobar")
    assert(value == "8843d7f92416211de9ebb963ff4ce28125932878")
    # Value is defined in md5s_test.yml
    value = md5s('\n'.join(['a', 'b', 'c']))
    assert(value == "8c07888eb7fbc662637e6bcb2c955303")
    # Value is defined in md5s_test.yml
    value = md5s('\n'.join(['a', 'b', 'c\n']))
    assert(value == "3fc5d5c5cc5e5b8f5b5107c5e5b5ec5e")
    # Test for hashlib not available error
   

# Generated at 2022-06-11 18:00:37.259886
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    input="hello world"
    expected=_md5(input).hexdigest()
    assert md5s(input) == expected

# Generated at 2022-06-11 18:00:48.853495
# Unit test for function checksum
def test_checksum():
    from ansible.utils.path import makedirs_safe
    from tempfile import NamedTemporaryFile

    testdata = b"Some random data"
    ret = checksum_s(testdata)
    assert(ret == "e6a4a7a4c6f9a6a0fa6f462b6fc8b6a8")

    # Create a temporary file with a few bytes of data
    tmpfile = NamedTemporaryFile(delete=False)
    tmpfile.write(testdata)
    tmpfile.close()
    assert(checksum(tmpfile.name) == "e6a4a7a4c6f9a6a0fa6f462b6fc8b6a8")


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:00:52.106601
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return

    data = 'test'
    hashed = md5s(data)
    assert hashed == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-11 18:00:55.083966
# Unit test for function md5
def test_md5():
    md5_string = md5("tests/support/hello")
    assert md5_string == "8b1a9953c4611296a827abf8c47804d7"

# Generated at 2022-06-11 18:01:04.802967
# Unit test for function md5
def test_md5():
    '''
    [unit]
    Test md5
    '''
    import os

    file_name = "test_md5.txt"
    with open(file_name, "w") as test_file:
        test_file.write("test")
    m1 = md5(file_name)

    with open(file_name, "w") as test_file:
        test_file.write("test")
    m2 = md5(file_name)

    os.remove(file_name)
    assert m1 == m2

if __name__ == '__main__':
    # Unit test for function md5
    test_md5()

# Generated at 2022-06-11 18:01:07.579586
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'a883de1a556f70f06c9d9a76cb05e848'


# Generated at 2022-06-11 18:01:19.165901
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil

    if os.geteuid() == 0:
        test_dir = "/tmp"
    else:
        test_dir = tempfile.mkdtemp()

    # Create a file
    test_file = os.path.join(test_dir, "test_file")
    file_contents = "This is a test file"
    expected_checksum = "b6eae1a52d984890b7a09f1d3f3e9c9a5a5c5ba5"
    f = open(test_file, "wb")
    f.write(file_contents)
    f.close()
    # Check the checksum
    if checksum(test_file) != expected_checksum:
        raise Exception("checksum did not match expected value")

    #

# Generated at 2022-06-11 18:01:30.255745
# Unit test for function checksum
def test_checksum():
    assert checksum('ansible/modules/core/cloud/amazon/ec2_vpc_igw.py') == 'ac9afcb4088eca56a63c4a62d0fe42e8f0b076dc'
    assert checksum_s('ansible/modules/core/cloud/amazon/ec2_vpc_igw.py') == 'c73e75e971a8c8f66da1f629cad7d1bea48c8e77'
    assert md5('ansible/modules/core/cloud/amazon/ec2_vpc_igw.py') == '7f6b51d3b2f2463465981c7b3b87df1b'

# Generated at 2022-06-11 18:01:40.716445
# Unit test for function md5
def test_md5():
    from tempfile import mkstemp
    from shutil import rmtree
    import os

    fd1, temp_path_1 = mkstemp()
    os.close(fd1)
    fd2, temp_path_2 = mkstemp()
    os.close(fd2)

    assert md5(temp_path_1) is None
    f = open(temp_path_1, 'w')
    f.write('Hello World\n')
    f.close()
    f = open(temp_path_2, 'w')
    f.write('Hello World\n')
    f.close()

    assert md5(temp_path_1) == md5(temp_path_2)
    os.unlink(temp_path_1)
    os.unlink(temp_path_2)
   

# Generated at 2022-06-11 18:01:46.682639
# Unit test for function md5s
def test_md5s():
    from ansible.compat.tests.mock import patch

    with patch.multiple('ansible.module_utils.basic.AnsibleModule', exit_json=exit_json, fail_json=fail_json):
        md5s('test')
        md5s(u'test')



# Generated at 2022-06-11 18:01:48.621683
# Unit test for function checksum
def test_checksum():
    assert checksum_s("foobar") == "8843d7f92416211de9ebb963ff4ce28125932878"


# Generated at 2022-06-11 18:01:57.676916
# Unit test for function checksum
def test_checksum():
    from ansible.compat.tests import unittest

    class TestSums(unittest.TestCase):

        def test_secure_hash_s(self):
            self.assertEqual(secure_hash_s('hello'), 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0')
            self.assertEqual(secure_hash_s(u'hello'), 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0')

        def test_md5s(self):
            self.assertEqual(md5s('hello'), '5d41402abc4b2a76b9719d911017c592')

# Generated at 2022-06-11 18:02:08.923719
# Unit test for function md5
def test_md5():
    from tempfile import NamedTemporaryFile

    def test(data, expected, hash_func=_md5):
        output = NamedTemporaryFile()
        output.write(data)
        output.flush()
        assert secure_hash(output.name, hash_func) == expected

    test("hello", "5d41402abc4b2a76b9719d911017c592")

    # Examples from RFC 1321
    test("abc", "900150983cd24fb0d6963f7d28e17f72")
    test("abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq",
         "8215ef0796a20bcaaae116d3876c664a")


# Generated at 2022-06-11 18:02:13.591968
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    filename = '/etc/passwd'
    filename2 = '/etc/shadow'
    r = md5(filename)
    r2 = md5(filename)
    r3 = md5(filename2)
    assert r == r2
    assert r != r3


# Generated at 2022-06-11 18:02:23.948101
# Unit test for function md5
def test_md5():
    from ansible.module_utils.six import StringIO

    data = "hello world"

    # String data
    test_data = StringIO(data)
    assert(md5s(test_data.getvalue()) == '5eb63bbbe01eeed093cb22bb8f5acdc3')
    test_data.close()

    # File data
    test_data = open(test_data.name, 'w+')
    test_data.write(data)
    test_data.close()
    assert(md5(test_data.name) == '5eb63bbbe01eeed093cb22bb8f5acdc3')
    os.unlink(test_data.name)  # Cleanup the file

# Generated at 2022-06-11 18:02:27.095404
# Unit test for function md5
def test_md5():
    fn = '/etc/hosts'
    assert md5(fn) == secure_hash(fn, hash_func=_md5)
    assert secure_hash(fn, hash_func=_md5) != secure_hash(fn)

# Generated at 2022-06-11 18:02:31.048881
# Unit test for function checksum
def test_checksum():
    if checksum('/etc/passwd') != '4d4fc95b7a5efbb1d8c7f2d73db7630fbb780f50':
        raise ValueError("File checksum failed")



# Generated at 2022-06-11 18:02:37.925759
# Unit test for function checksum
def test_checksum():
    # Generate a random file and calculate checksum
    data = os.urandom(1024)
    checksum_value = checksum_s(data)

    # Create a temp file to store the data and calculate checksum
    f = tempfile.NamedTemporaryFile()
    f.write(data)
    f.flush()
    checksum_value2 = checksum(f.name)

    f.close()

    if checksum_value != checksum_value2:
        raise Exception("checksum and checksum_s do not match")



# Generated at 2022-06-11 18:02:40.518919
# Unit test for function md5
def test_md5():
    import tempfile
    filename = tempfile.mkstemp()[1]
    with open(filename, 'w') as f:
        f.write('foo')
    md5string = md5(filename)
    os.remove(filename)
    assert(md5string == 'acbd18db4cc2f85cedef654fccc4a4d8')

# Generated at 2022-06-11 18:02:47.351220
# Unit test for function md5
def test_md5():
    assert md5(__file__) == '9d3da897cdb3a8ef8c1df2bdd0d58d65'
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-11 18:02:53.247908
# Unit test for function checksum
def test_checksum():
    import os
    import tempfile
    import shutil
    temp_dir = tempfile.mkdtemp()

    data = "my random data"
    data_path = os.path.join(temp_dir, "data")
    f = open(data_path, "w")
    f.write(data)
    f.close()

    assert checksum(data_path) == checksum_s(data)

    shutil.rmtree(temp_dir)

# Generated at 2022-06-11 18:03:01.162960
# Unit test for function md5
def test_md5():
    ''' Return correct result when using md5 function. '''
    # Check both byte and unicode strings
    for data_str in ["a", "abcd", "abcdabcdabcdabcdabcdabcdabcdabcd"]:
        # Check both binary and text mode
        for data_mode in [True, False]:
            data = data_str.encode() if data_mode else data_str
            assert md5s(data) == _md5(data).hexdigest()

# Generated at 2022-06-11 18:03:05.170282
# Unit test for function md5
def test_md5():

    try:
        from passlib.hash import md5_crypt
    except ImportError:
        return

    # Test empty string
    actual_md5_value = md5_crypt.hash("")
    assert md5s("") == actual_md5_value[9:25]

# Generated at 2022-06-11 18:03:08.788515
# Unit test for function md5s
def test_md5s():
    # sha1 is FIPS-140 compatible as of ansible-1.4
    s = md5s('foo')
    if s != 'acbd18db4cc2f85cedef654fccc4a4d8':
        raise ValueError('md5s failed to hash the string "foo", got %s' % s)


# Generated at 2022-06-11 18:03:14.373775
# Unit test for function md5s
def test_md5s():
    md5s_test_string = 'foobar'
    md5s_test_string_md5 = '3858f62230ac3c915f300c664312c63f'
    assert md5s_test_string_md5 == md5s(md5s_test_string)


# Generated at 2022-06-11 18:03:18.999114
# Unit test for function md5
def test_md5():
    import tempfile
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, "wb")
    f.write("hello world\n")
    f.close()
    #print "md5(%s) = %s" % (fname, md5(fname))
    os.unlink(fname)


if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:03:29.329122
# Unit test for function md5
def test_md5():
    import tempfile
    import shutil
    import os

    (fd, name) = tempfile.mkstemp(text=True)
    f = os.fdopen(fd, 'w')
    f.write('Hello Ansible')
    f.close()

    checksum = md5(name)
    if checksum != '3ca9bcaeb5a5fc52d88ebe2b4e4f8ce4':
        raise AnsibleError("MD5 hash does not match for file %s, got %s" %
                            (name, checksum))

    checksum = md5s('Hello Ansible')

# Generated at 2022-06-11 18:03:32.183507
# Unit test for function md5s
def test_md5s():
    sample = 'hello world'
    assert md5s(sample) == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-11 18:03:36.176400
# Unit test for function md5
def test_md5():
    from tempfile import mkstemp
    from shutil import rmtree
    (fd, path) = mkstemp()
    os.write(fd, b"Hello, world!")
    print(md5(path))
    os.remove(path)

# Generated at 2022-06-11 18:03:46.171608
# Unit test for function checksum
def test_checksum():
    assert checksum("/bin/echo", sha1) == "a122ec742c5d672f779e1de5a8c9f2cfc25f863f"


# Generated at 2022-06-11 18:03:51.531801
# Unit test for function md5
def test_md5():
    str1 = 'HelloWorld'
    str2 = 'Helloworld'
    str3 = 'Helloworld'
    str4 = 'Hellow World'

    # check for string
    if md5s(str1) == 'b10a8db164e0754105b7a99be72e3fe5':
        return True
    else:
        return False


# Generated at 2022-06-11 18:03:53.521564
# Unit test for function md5s
def test_md5s():

    x = md5s('hello world')
    assert x == '5eb63bbbe01eeed093cb22bb8f5acdc3'

# Generated at 2022-06-11 18:04:04.819454
# Unit test for function md5s
def test_md5s():
    ''' md5s return correct md5 checksums for files and strings '''
    import random
    import tempfile

    # This allows us to rotate through the checksum algorithms
    # but guarantee the first one is always md5
    checksum_algorithms = _md5, sha1

    # Generate some random data
    sample_data = 'random string %s' % random.random()

    # Checksum the string data
    sample_string_checksum = md5s(sample_data)

    # Store the random data into a file
    fd, sample_file = tempfile.mkstemp()
    os.write(fd, sample_data)
    os.close(fd)

    # Checksum the file data with each algorithm

# Generated at 2022-06-11 18:04:12.917427
# Unit test for function md5
def test_md5():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            test_file=dict(required=True),
            md5sum=dict(required=True),
        )
    )

    test_file = module.params['test_file']
    md5sum = module.params['md5sum']

    module.exit_json(changed=False, md5sum=md5(test_file), md5s_output=md5s(test_file), md5sum_var=md5sum)


#
# Backwards compat.  Do not use this function.  Use secure_hash_s and secure_hash instead.
#


# Generated at 2022-06-11 18:04:14.657336
# Unit test for function md5
def test_md5():
    assert secure_hash('test/unit/utils/test.py') == secure_hash('test/unit/utils/test.py')


# Generated at 2022-06-11 18:04:18.082561
# Unit test for function md5
def test_md5():
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-11 18:04:28.485678
# Unit test for function checksum
def test_checksum():
    from tempfile import mkstemp
    import atexit
    import os

    (fd, path) = mkstemp()
    atexit.register(os.unlink, path)
    os.close(fd)

    try:
        os.unlink(path)
        assert checksum(path) is None
    except SystemExit:
        pass

    try:
        with open(path, 'w') as f:
            f.write('hello world\n')
        assert checksum(path) == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    except SystemExit:
        pass


if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])
    test_checks

# Generated at 2022-06-11 18:04:32.214944
# Unit test for function md5s
def test_md5s():
    result = md5s("This is a string for testing md5")
    assert result == "c7f4b1e8b7d9e708050ce7e98d6b47f7"

# Generated at 2022-06-11 18:04:34.698569
# Unit test for function md5
def test_md5():
    assert md5('/bin/ls') == '37965aa10a2d7e8e0a296773be499c03'
    assert md5('/bin/ls-foobar') is None


# Generated at 2022-06-11 18:04:46.826797
# Unit test for function md5
def test_md5():
    f = open("/tmp/test_file", "w")
    f.write("Hello world")
    f.close()

    assert md5("/tmp/test_file") == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s("Hello world") == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# These functions are deprecated and will go away in a future version

# Generated at 2022-06-11 18:04:58.815874
# Unit test for function md5s
def test_md5s():
    import datetime
    startTime = datetime.datetime.now()
    print('Test start at:' + str(startTime))
    print('secure_hash_s test, expected result: ' + 'da39a3ee5e6b4b0d3255bfef95601890afd80709')
    test_data = ''
    print('sha1 test result: ' + secure_hash_s(test_data))
    print('md5 test result: ' + md5s(test_data))
    print('secure_hash_s test, expected result: ' + '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8')
    test_data = 'a'
    print('sha1 test result: ' + secure_hash_s(test_data))

# Generated at 2022-06-11 18:05:04.822531
# Unit test for function md5s
def test_md5s():
    ''' checksum.md5s() unit test'''

    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s(2) == '3e25960a79dbc69b674cd4ec67a72c62'
    assert md5s(['hello', 'world']) == '12fa9c9dcc16fcea6e5916d5993313f8'


# Generated at 2022-06-11 18:05:11.010953
# Unit test for function checksum
def test_checksum():
    filename = os.path.join(os.path.dirname(__file__), 'test-checksum.py')
    checksum_file = "c4afb1d6e4c0b5c0cac8f4a7fef25714d929f5c0"
    checksum_s_string = "1d6e4c0b5c0cac8f4a7fef25714d929f5c0"
    assert checksum(filename) == checksum_file
    assert checksum_s("test") == checksum_s_string


if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:05:14.011531
# Unit test for function md5s
def test_md5s():
    expected = "b875d4e4a4b4baa005d2501fb2cd2e59"
    result = md5s("foobar")
    assert expected == result

test_md5s()

# Generated at 2022-06-11 18:05:21.277046
# Unit test for function md5s
def test_md5s():
    assert md5s('test_123') == 'b4ba93170358df216e7e3dec6c531f34'
    assert md5s('[1,2,3]') == 'b77f88b9658bdda9a7bf5b6a5f6cc5a6'
    assert md5s('{"foo":"bar"}') == 'c9e7208653cf07dbe6d5dc6a5e5f6430'
    assert md5s('{"foo":[{"bar":"baz"}]}') == 'd7b3ce1c77701130d57a0cd390cff3a3'

# Generated at 2022-06-11 18:05:25.152576
# Unit test for function md5
def test_md5():
    ''' Unit test for function md5 '''
    result = md5s('random data')
    assert result == '8d9a9e9e0bf1d6bcd5806630c7fb4f83'
    # test that _md5 has been created
    assert _md5 is not None
