

# Generated at 2022-06-11 17:55:36.592322
# Unit test for function checksum
def test_checksum():
    checksum_path = os.path.join(os.path.dirname(__file__), "../../test/vault/blah.txt")
    if checksum(checksum_path) != "a74807784b90dd1e7d2f3bf3688c317745d8a8bd":
        raise AssertionError("checksum test failed")


if __name__ == '__main__':
    try:
        test_checksum()
        print("unit tests passed")
    except AssertionError as e:
        print("unit test failure: {0}".format(e))

# Generated at 2022-06-11 17:55:46.258305
# Unit test for function checksum
def test_checksum():
    s = 'hello world'
    s_hash = checksum_s(s)
    assert s_hash == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed', s_hash

    testfile_name = 'testfile_checksum'
    if os.path.exists(testfile_name):
        os.unlink(testfile_name)

    f = open(testfile_name, 'w')
    f.write(s)
    f.close()

    f_hash = checksum(testfile_name)
    assert f_hash == s_hash, f_hash

    os.unlink(testfile_name)


# Generated at 2022-06-11 17:55:57.185966
# Unit test for function checksum
def test_checksum():
    assert checksum('/bin/ls') == 'fdfdd8a3a1d931d9d7e23c8f2ee7d1fe1cd171d7'
    assert checksum_s('foo bar') == '6f00fe4add8b3ea3e6cafd81e1a74c8b35606f9d'
    if _md5:
        assert md5s('foo bar') == '37b51d194a7513e45b56f6524f2d51f2'
        assert md5('/bin/ls') == 'fdfdd8a3a1d931d9d7e23c8f2ee7d1fe'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:56:07.934064
# Unit test for function checksum
def test_checksum():
    import tempfile
    import shutil

# Generated at 2022-06-11 17:56:12.455013
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    print("md5s of 'hello world' = " + md5s("hello world"))


# Generated at 2022-06-11 17:56:19.264203
# Unit test for function checksum
def test_checksum():
    data = 'hello world'
    filename = '/tmp/test_checksum_file'
    try:
        if os.path.exists(filename):
            os.remove(filename)
        fo = open(filename, 'w')
        fo.write(data)
        fo.close()

        assert checksum_s(data) == '5eb63bbbe01eeed093cb22bb8f5acdc3'
        assert checksum(filename) == checksum_s(data)
    finally:
        if os.path.exists(filename):
            os.remove(filename)

# Generated at 2022-06-11 17:56:20.848096
# Unit test for function md5s
def test_md5s():
    ''' test md5s function '''
    assert len(md5s('foo')) == 32


# Generated at 2022-06-11 17:56:28.402341
# Unit test for function md5
def test_md5():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    from ansible.compat.tests import unittest
    import tempfile
    t = tempfile.NamedTemporaryFile()
    t.write(b'hello world')
    t.flush()
    t.seek(0)
    try:
        raise unittest.TestCase.assertEqual(md5(t.name), '5eb63bbbe01eeed093cb22bb8f5acdc3')
    finally:
        t.close()

# Generated at 2022-06-11 17:56:36.408988
# Unit test for function checksum
def test_checksum():
    '''Unit test for function checksum'''
    import tempfile
    with tempfile.NamedTemporaryFile(mode='w') as temp:
        temp.write('hello world')
        temp.flush()
        temp_sum = checksum(temp.name)
        assert temp_sum == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 17:56:37.896897
# Unit test for function md5s
def test_md5s():
    assert md5s('value1') == 'e7e3c1d2fd7c3f3a3a7ddc5ad0d5f5a5'


# Generated at 2022-06-11 17:56:46.992812
# Unit test for function md5
def test_md5():
    ''' test md5() function '''
    secure_hash_value = md5('/etc/passwd')
    secure_hash_value_s = md5s('abcd')
    if 'd9bfacfa7fb90b1e2b7daece123f41ce' != secure_hash_value or 'e2fc714c4727ee9395f324cd2e7f331f' != secure_hash_value_s:
        raise AnsibleError('md5 test data failed')


# Generated at 2022-06-11 17:56:57.517933
# Unit test for function checksum
def test_checksum():
    from random import randint
    from tempfile import NamedTemporaryFile

    def create_random_file():
        ''' Creates a temporary file with a random name and
        fills it with randint values.
        Returns:
            file_path: Path to temporary file.
            sha_sum: SHA1 sum of the temporary file.
        '''
        with NamedTemporaryFile(delete=False) as temp:
            random_sha = sha1()
            while True:
                random_byte = os.urandom(1)
                random_sha.update(random_byte)
                temp.write(random_byte)
                if randint(0,10) == 0:
                    break
        return temp.name, random_sha.hexdigest()

    file_path, sha_sum = create_random_file()
    assert checks

# Generated at 2022-06-11 17:57:06.999585
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s('hello world') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert md5s('hello to the world') == 'c0535e4be2b79ffd93291305436bf889314e4a3faec05ecffcbb7df31ad9e51a'
    assert md5s('hello world, how are you today?') == 'ad1ff0904f5d8bd79e801612575b5ff5'

# Generated at 2022-06-11 17:57:18.609482
# Unit test for function checksum
def test_checksum():
    f = open('testing', 'w')
    f.write('hello')
    f.close()

    assert checksum('testing') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum('testing', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'

    assert checksum_s('hello') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('hello', hash_func=_md5) == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-11 17:57:19.918157
# Unit test for function md5
def test_md5():
    from nose.plugins.skip import SkipTest
    raise SkipTest("sha1 is not available")

# Generated at 2022-06-11 17:57:25.441489
# Unit test for function checksum
def test_checksum():
    filename = '/etc/hosts'
    assert checksum(filename) == 'b93764b8c9aeba1bd092932da49432dd949fa98c'
    assert checksum_s('hello world') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'



# Generated at 2022-06-11 17:57:32.709040
# Unit test for function md5s
def test_md5s():
    # Test for special input cases
    assert md5s(None) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(False) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s(True) == 'd41d8cd98f00b204e9800998ecf8427e'

    # Test for correct md5s
    assert md5s(b'ansible') == '89d878e9efdbc138e85d3f3c2dc94b8f'
    assert md5s('ansible') == '89d878e9efdbc138e85d3f3c2dc94b8f'

# Generated at 2022-06-11 17:57:37.093806
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert md5s(b'foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'

# Generated at 2022-06-11 17:57:39.506043
# Unit test for function md5s
def test_md5s():
    assert md5s('test_data') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-11 17:57:48.932567
# Unit test for function md5s
def test_md5s():
    # strings
    assert md5s("foo") == 'acbd18db4cc2f85cedef654fccc4a4d8'
    # unicode
    assert md5s(u"foo") == 'acbd18db4cc2f85cedef654fccc4a4d8'
    # int, hex string
    assert md5s(0xffffffff) == '2d872e48f8c0d1b3e3b0c0aee974f2ad'
    # long, oct string

# Generated at 2022-06-11 17:57:59.584010
# Unit test for function checksum
def test_checksum():
    '''Function checksum test.

       Test checksum function and returns tuple containing success message and
       result of test.
    '''
    test_data = '''This is a string of data to test checksum function
really, this is a test'''
    try:
        test_return = checksum_s(test_data)
        test_success = 'function: checksum_s'
    except Exception:
        test_return = ''
        test_success = 'failed'

    return test_success, test_return

# Generated at 2022-06-11 17:58:08.110268
# Unit test for function checksum
def test_checksum():
    assert checksum('file', 'sha1') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum('file') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert checksum_s('data', 'sha1') == '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8'
    assert checksum_s('data') == '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8'

# Generated at 2022-06-11 17:58:16.756975
# Unit test for function md5
def test_md5():
    # Test with a string
    data = 'hello world'
    hash_value = 'ed076287532e86365e841e92bfc50d8c'
    ret = md5s(data)
    assert ret == hash_value, 'md5s(data) failed: returned: %s, should be: %s' % (ret, hash_value)

    # Test with a file
    import tempfile
    (fd, filename) = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        f.write(data)
    ret = md5(filename)
    assert ret == hash_value, 'md5(filename) failed: returned: %s, should be: %s' % (ret, hash_value)
    os.remove(filename)



# Generated at 2022-06-11 17:58:24.210686
# Unit test for function md5
def test_md5():
    import tempfile
    # Create a test file
    (fd, fname) = tempfile.mkstemp()
    os.write(fd, b'Hello World!')
    os.close(fd)
    # Call md5 function
    file_md5 = md5(fname)
    os.remove(fname)
    # Compare result with fixed value
    if file_md5 == 'ed076287532e86365e841e92bfc50d8c':
        return 0
    else:
        return 1


# Generated at 2022-06-11 17:58:29.265920
# Unit test for function md5s
def test_md5s():
    """
    Check md5s
    """
    if _md5:
        md5_hash = 'd41d8cd98f00b204e9800998ecf8427e'
        calculated_md5 = md5s('')
        if (md5_hash != calculated_md5):
            raise AssertionError("MD5 hashes don't match")
    else:
        raise AssertionError("MD5 not available")

# Generated at 2022-06-11 17:58:30.608407
# Unit test for function md5s
def test_md5s():
    import doctest
    doctest.testmod()


# Generated at 2022-06-11 17:58:40.163431
# Unit test for function checksum
def test_checksum():
    '''Unit test for checksum() and md5() functions'''
    #
    # This test depends on the existence and validity of files src/test/test-checksum.txt and
    # src/test/test-checksum.txt.md5
    #
    import os
    import unittest

    local_test_path = os.path.dirname(os.path.realpath(__file__))
    test_checksum_file_a = os.path.join(local_test_path, 'test-checksum.txt')
    test_checksum_file_b = os.path.join(local_test_path, 'test-checksum.txt.md5')

    class TestChecksum(unittest.TestCase):
        '''Unit test for checksum() and md5() functions'''


# Generated at 2022-06-11 17:58:46.491123
# Unit test for function checksum
def test_checksum():
    # create a new file with dummy content
    import tempfile
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.write('Hello, World!')
    tmp_file.close()

    # Populate the filename and checksum
    filename = tmp_file.name
    checksum_value = checksum(filename)

    # Delete test file
    os.unlink(tmp_file.name)

    # Return results
    return {'filename': filename, 'checksum': checksum_value}

# Generated at 2022-06-11 17:58:49.786200
# Unit test for function md5
def test_md5():
    if not _md5:
        return
    # invalid file name
    assert md5('') is None
    assert md5('/no_file_here') is None
    assert md5('/etc/passwd') == '6f8db599de986fab7a21625b7916589c'



# Generated at 2022-06-11 17:58:52.971299
# Unit test for function md5
def test_md5():
    assert md5(__file__) == "3beb5c5b5a5b5fe2a5a5cdda4f4d4a86"


# Generated at 2022-06-11 17:59:06.139265
# Unit test for function md5
def test_md5():
    """
    Unit test for function md5
    """
    from tempfile import NamedTemporaryFile
    test_file = NamedTemporaryFile(delete=False)
    test_data = 'These are the times that try men\'s souls.\nThe summer soldier and the sunshine patriot will, in this crisis, shrink from the service of their country; but he that stands it now, deserves the love and thanks of man and woman.\nTyranny, like hell, is not easily conquered; yet we have this consolation with us, that the harder the conflict, the more glorious the triumph.\n'
    test_file.write(to_bytes(test_data))
    test_file.close()
    test_md5 = '2f9d85b812f263b10ef0e3d0b1efaf27'
    assert test_md5 == md5

# Generated at 2022-06-11 17:59:08.468539
# Unit test for function md5s
def test_md5s():
    assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'



# Generated at 2022-06-11 17:59:13.479988
# Unit test for function md5
def test_md5():
    # Test md5 function
    if md5:
        assert(md5('/etc/shadow') != md5('/etc/password'))
        assert(md5('/etc/shadow') == md5('/etc/shadow'))
        assert(md5('/etc/shadow') != md5(['/etc/shadow']))

# Generated at 2022-06-11 17:59:20.586518
# Unit test for function md5
def test_md5():
    test_value = "This is a test."
    expected_value = "0d107d09f5bbe40cade3de5c71e9e9b7"
    if md5s(test_value) == expected_value:
        print("md5 test value good")
        exit(0)
    else:
        print("md5 test value bad: %s" % md5s(test_value))
        exit(1)

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 17:59:27.623294
# Unit test for function md5
def test_md5():
    print (secure_hash_s('hello') == '5d41402abc4b2a76b9719d911017c592')
    print (secure_hash('test/test-data/test1.txt') == '81dc9bdb52d04dc20036dbd8313ed055')

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 17:59:32.294158
# Unit test for function md5
def test_md5():
    filename = os.path.join(os.path.dirname(__file__), "hashes.py")
    my_hash = "7c086e86e6a0e0a982d1ed49e9f859b8"
    my_md5 = md5(filename)
    if (my_hash != my_md5):
        print("{0} != {1}".format(my_hash, my_md5))
        raise Exception('Hash does not match')

test_md5()

# Generated at 2022-06-11 17:59:36.276318
# Unit test for function checksum
def test_checksum():
    checksum_str = secure_hash_s('test')
    checksum_file = secure_hash('./lib/ansible/utils/compat/tests/test.txt')
    assert checksum_str == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert checksum_file == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

# Generated at 2022-06-11 17:59:46.900260
# Unit test for function checksum
def test_checksum():
    assert checksum('../test-data/test2.in') == '81b3954a77c9e32e93a8058353b27f07'
    assert checksum('../test-data/test3.in') == '8d9978efa36c0a7e48b7585cd6b83e96'
    assert checksum('../test-data/test4.in') == '469b4be4b8bcb661768b6eb1c6bd2d65'
    assert checksum('../test-data/test4.in', hash_func=md5) == 'b6f1b45e5b6ef2d5f5c6e5a6d59aa6cf'

# Generated at 2022-06-11 17:59:50.700262
# Unit test for function md5
def test_md5():
    '''
    Use case:

    - md5(filename)
    '''

    assert md5("data/test_file1") == 'd41d8cd98f00b204e9800998ecf8427e'



# Generated at 2022-06-11 17:59:53.822386
# Unit test for function md5s
def test_md5s():
    test_input = 'testinput'
    test_output = md5s(test_input)
    assert test_output == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

# Generated at 2022-06-11 18:00:09.767902
# Unit test for function md5
def test_md5():
    # FIPS mode must be enabled to run this test
    # Test that md5s function will raise a ValueError
    # when FIPS mode is enabled
    try:
        md5s('foo')
        raise ValueError('FIPS mode is not enabled')
    except ValueError:
        pass

# Generated at 2022-06-11 18:00:12.527613
# Unit test for function md5
def test_md5():
    filename = 'CHANGELOG.txt'
    md5_sum = 'e78db4f2e8a40c09f398a90d9b9d8ad8'
    assert(md5(filename)==md5_sum)

# Generated at 2022-06-11 18:00:16.259988
# Unit test for function md5s
def test_md5s():
    assert md5s("this is a test") == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3", \
        "md5s function did not generate expected checksum"

# Generated at 2022-06-11 18:00:21.703111
# Unit test for function md5s
def test_md5s():
    # The data was generated with the Linux command: echo -n "Hello world" | openssl dgst -md5 -binary | xxd -p
    assert md5s("Hello world") == "86fb269d190d2c85f6e0468ceca42a20"



# Generated at 2022-06-11 18:00:24.802348
# Unit test for function md5
def test_md5():
    testdata = 'foobar'
    assert md5s(testdata) == '3858f62230ac3c915f300c664312c63f'

# Generated at 2022-06-11 18:00:26.812546
# Unit test for function md5
def test_md5():
    md5s_test = md5s("supercalifragilisticexpialidocious")
    assert md5s_test == '30bb66ddbcb09a59f22cd1ca2d40b9ff'



# Generated at 2022-06-11 18:00:31.863686
# Unit test for function md5s
def test_md5s():
    ''' Unit test for function md5s '''
    # Test case 1
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'

    # Test case 2
    assert md5s('world') == '7d793037a0760186574b0282f2f435e7'


# Generated at 2022-06-11 18:00:36.833476
# Unit test for function md5s
def test_md5s():
    ''' test_md5s is a simple test to verify the md5s function.
        It will only succeed if it is able to compute an md5 hash
        using the md5s function.'''

    result = md5s("foo")
    assert result == 'acbd18db4cc2f85cedef654fccc4a4d8'


# Generated at 2022-06-11 18:00:42.430426
# Unit test for function md5s
def test_md5s():
    if _md5:
        assert md5s('foo') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    else:
        try:
            md5s('foo')
            assert False
        except ValueError as e:
            assert 'MD5 not available' in str(e)

# Generated at 2022-06-11 18:00:46.292441
# Unit test for function md5
def test_md5():
    assert(md5('ansible/test/data/test-module-path.data') == 'fb883daf8da98caf4522bfde9a7c9e04')


# Generated at 2022-06-11 18:01:01.471177
# Unit test for function md5
def test_md5():
    test_str = 'I Love Ansible'
    assert md5s(test_str) == '0c611b249d0826d18e0d6b17e6f74d0f'

# Unit tests for module

# Generated at 2022-06-11 18:01:09.563089
# Unit test for function md5s
def test_md5s():
    # Test for FIPS mode
    try:
        md5s('data')
        assert False
    except ValueError as e:
        assert str(e) == 'MD5 not available.  Possibly running in FIPS mode'

    # Test for non-FIPS mode
    assert md5s('data') == '1e50210a0202497fb79bc38b6ade6c34'
    assert md5s(u'data') == '1e50210a0202497fb79bc38b6ade6c34'

# Generated at 2022-06-11 18:01:19.164748
# Unit test for function checksum
def test_checksum():
    filename = "test_checksum"

    # Create file with dummy data
    f = open(filename, "w")
    f.write("Hello")
    f.close()

    assert checksum(filename) == checksum("Hello", sha1)
    assert checksum_s("Hello") == checksum("Hello", sha1)
    assert checksum_s("Hello") == checksum_s("Hello", sha1)

    # Create file with dummy data
    f = open(filename, "wb")
    f.write(b"Hello")
    f.close()
    # Try with a bytestring
    assert checksum(filename) == checksum(b"Hello", sha1)

    # Cleanup
    os.remove(filename)

# Generated at 2022-06-11 18:01:22.925476
# Unit test for function md5
def test_md5():
    assert md5('/etc/passwd') == 'c52a1a21f14c8e2741e5b5da5187db58'

# Generated at 2022-06-11 18:01:25.525009
# Unit test for function md5
def test_md5():
    data = 'hello'
    d = md5s(data)
    assert d == '5d41402abc4b2a76b9719d911017c592', 'md5s() failed'
    fn = '/etc/hosts'
    d = md5(fn)
    assert d == '762dbebe907a7bbea721170e7e97ea11', 'md5() failed'

# Generated at 2022-06-11 18:01:31.338450
# Unit test for function md5
def test_md5():
    ''' md5 unit test '''

    # Create a file
    (fd, name) = tempfile.mkstemp()
    os.close(fd)

    # Write content
    f = open(name, 'w')
    f.write('12345')
    f.close()

    # Assert md5
    assert md5(name) == '827ccb0eea8a706c4c34a16891f84e7b'
    assert md5('not_a_real_file') is None

    # Clean up
    os.remove(name)

# Generated at 2022-06-11 18:01:34.830584
# Unit test for function md5s
def test_md5s():
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'


# Generated at 2022-06-11 18:01:41.374187
# Unit test for function md5
def test_md5():
    # Randomly generated md5 value, checked to be valid
    md5_value = '00f9caa634863d3b8faf260a2927b2cf'
    # Test non-existent file
    assert md5('does_not_exist') is None
    # Test empty string
    assert md5s('') == md5_value
    # Test subject to quoting
    assert md5s("['a']") == md5_value
    # Test string with spaces
    assert md5s("['a b']") == md5_value
    # Test non-ascii
    assert md5s("['\\xe2\\xa9']") == md5_value

# Generated at 2022-06-11 18:01:43.725224
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'


# Generated at 2022-06-11 18:01:45.329016
# Unit test for function md5s
def test_md5s():
    assert md5s("hello") == "5d41402abc4b2a76b9719d911017c592"


# Generated at 2022-06-11 18:01:59.055173
# Unit test for function md5s
def test_md5s():
    assert md5s("foobar") == "3858f62230ac3c915f300c664312c63f"


# Generated at 2022-06-11 18:02:02.071223
# Unit test for function md5
def test_md5():
    hash = md5('/tmp/does-not-exist')
    assert hash == None

if __name__ == '__main__':
    test_md5()

# Generated at 2022-06-11 18:02:07.824411
# Unit test for function md5s
def test_md5s():
    ''' test the md5s function '''
    import random
    import string

    salt = ("".join([random.choice(string.letters + string.digits) for x in range(random.randint(1, 255))]))
    assert(md5s("test" + salt) == "24fc2faa09a9a1ea93f2be7f8d0aeddc")



# Generated at 2022-06-11 18:02:15.369280
# Unit test for function checksum
def test_checksum():
    test_data = [
        # Input, expected output
        ("test", "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"),
        ("hashlib", "2f711b097c2d288de72d85a3d3f3266db3851d90"),
        ("This is a long string", "07b24af863035a1dd255e25c0a893990e3efff3e"),
        ]

    for data, expected in test_data:
        result = checksum_s(data)
        if result != expected:
            raise AssertionError("hashlib test failure, expected %s, got %s" % (expected, result))


# Generated at 2022-06-11 18:02:20.536951
# Unit test for function md5s
def test_md5s():
    test_string = "This is a test string"
    md5_expected = "c097c5b5df7c1d85d33f8e0f5daa8c6b"
    assert md5s(test_string) == md5_expected


# Generated at 2022-06-11 18:02:23.446630
# Unit test for function md5
def test_md5():
    md5_legit = md5(__file__)
    md5_empty = md5('/tmp/asdfasdfasdfasdf')
    assert md5_legit is not None
    assert md5_empty is None

# Generated at 2022-06-11 18:02:34.111279
# Unit test for function checksum
def test_checksum():
    import os
    import tempfile
    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    try:
        os.close(fd)
        open(temp_path, 'w').write('foo')
        # Create a checksum of the file
        digest = checksum(temp_path)
        # Check the result
        assert digest == secure_hash(temp_path, hash_func=sha1)
        # Check if the file doesn't exist
        assert checksum('/etc/nonexistent-file') is None
    finally:
        os.unlink(temp_path)

if __name__ == '__main__':
    test_checksum()

# Generated at 2022-06-11 18:02:35.267333
# Unit test for function md5
def test_md5():
    assert md5(__file__) == secure_hash(__file__, _md5)

# Generated at 2022-06-11 18:02:38.753834
# Unit test for function md5s
def test_md5s():
    s = 'testing'
    assert(md5s(s) == 'ae2b1fca515949e5d54fb22b8ed95575')


# Generated at 2022-06-11 18:02:44.799376
# Unit test for function md5
def test_md5():
    assert md5('test/units/ansible/utils/test_md5data.txt') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('test data') == '098f6bcd4621d373cade4e832627b4f6'
    try:
        md5s(None)
        assert False
    except Exception:
        pass

# Generated at 2022-06-11 18:03:00.778394
# Unit test for function md5
def test_md5():
    result = md5("/bin/echo")
    assert result == "cc26c5a29a72be3a3d0f3e7c0a9e9f87"

# Generated at 2022-06-11 18:03:06.842090
# Unit test for function md5
def test_md5():
    try:
        a = md5('/bin/csh')
        if a == '4e4cc4eb0de161f2d82e9bf14328f2ee':
            print("OK")
        else:
            print("ERROR: %s != 4e4cc4eb0de161f2d82e9bf14328f2ee" % a)
    except ValueError:
        print("SKIPPING DUE TO FIPS MODE")



# Generated at 2022-06-11 18:03:17.847597
# Unit test for function md5s
def test_md5s():
    assert md5s('') == 'd41d8cd98f00b204e9800998ecf8427e'
    assert md5s('ansible') == 'f135c60c0d8e8b9cfe30d2637d2c2ce8'
    assert md5s('\0') == '93b885adfe0da089cdf634904fd59f71'
    assert md5s('\0\0') == '282a8f65a9c3e93bfa961683c801f53b'
    assert md5s('a') == '0cc175b9c0f1b6a831c399e269772661'
    assert md5s('abc') == '900150983cd24fb0d6963f7d28e17f72'


# Generated at 2022-06-11 18:03:28.000355
# Unit test for function md5s
def test_md5s():
    import random
    import string
    random = random.SystemRandom()
    alphabet = string.ascii_letters + string.digits

# Generated at 2022-06-11 18:03:31.206106
# Unit test for function checksum
def test_checksum():
    hashed = secure_hash_s("Hello world!")
    assert hashed == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'

# Generated at 2022-06-11 18:03:33.640919
# Unit test for function md5
def test_md5():
    assert md5(__file__) == md5s(open(__file__,'rb').read())

# Generated at 2022-06-11 18:03:36.678706
# Unit test for function md5
def test_md5():

    TESTDATA = b"foobar"
    md5_sum = md5s(TESTDATA)

    # Test known hash
    assert md5_sum == "3858f62230ac3c915f300c664312c63f"

# Generated at 2022-06-11 18:03:40.585839
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    test_string='hello world'
    hashed=md5s(test_string)
    assert hashed == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-11 18:03:50.234976
# Unit test for function checksum
def test_checksum():
    from ansible.module_utils import basic

    data = 'foobar'
    expected = '8843d7f92416211de9ebb963ff4ce28125932878'
    result = checksum_s(data)
    if result != expected:
        raise AssertionError("%s != %s" % (result, expected))

    tmpfn = basic.mkdtemp()
    try:
        basic.write_file(tmpfn, data)
        result = checksum(tmpfn)
        if result != expected:
            raise AssertionError("%s != %s" % (result, expected))
    finally:
        basic.remove_tmp_path(tmpfn)

# Generated at 2022-06-11 18:03:57.391337
# Unit test for function md5
def test_md5():

    # test md5
    with open(__file__, "r") as f:
        m = md5(__file__)
        m1 = secure_hash(__file__)
        assert(m == m1)

    # test md5s
    s = "Hello World!"
    m = md5s(s)
    m2 = secure_hash_s(s)
    assert(m == m2)

    print("Success.")

if __name__ == "__main__":
    test_md5()

# Generated at 2022-06-11 18:04:14.657822
# Unit test for function md5
def test_md5():
    print('TEST md5')
    testfile = os.path.join(os.path.dirname(__file__), '../utils', 'test-module.ps1')
    print('Testing file %s' % testfile)
    print('md5 = %s' % md5(testfile))
    print('#' * 20)


# Generated at 2022-06-11 18:04:25.537694
# Unit test for function md5
def test_md5():
    # create test file
    filename = "test.txt"
    with open(filename, 'w') as outfile:
        outfile.write("Hello World")

    # get MD5 checksum from file

# Generated at 2022-06-11 18:04:28.887831
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return True

    known = md5s('1234')
    assert known == '81dc9bdb52d04dc20036dbd8313ed055'



# Generated at 2022-06-11 18:04:34.220845
# Unit test for function md5
def test_md5():
    assert secure_hash('test_utils.py') == '39d2fec60dda6625b535f8056a8a8a0f'
    assert secure_hash_s('TESTUTILSISCOOL') == '2a3ec0b0e7d3d8925f9e2c3b3d812d5867e37e60'



# Generated at 2022-06-11 18:04:38.310754
# Unit test for function md5
def test_md5():

    fd = open("./test.txt", "w")
    fd.write("ansible")
    fd.close()

    assert md5("./test.txt") == "685951d9cae96a11bac7fdf68d826e7b"
    os.remove("./test.txt")

# Generated at 2022-06-11 18:04:43.380958
# Unit test for function md5
def test_md5():
    import tempfile
    fd, path = tempfile.mkstemp()
    os.close(fd)
    try:
        with open(path, 'wt') as f:
            f.write('test')
        assert md5(path) == '098f6bcd4621d373cade4e832627b4f6'
    finally:
        os.unlink(path)

# Generated at 2022-06-11 18:04:47.134976
# Unit test for function md5s
def test_md5s():
    if not _md5:
        raise ValueError('MD5 not available.  Possibly running in FIPS mode')
    assert md5s('test') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-11 18:04:53.042324
# Unit test for function md5s
def test_md5s():
    assert md5s('hello') == '5d41402abc4b2a76b9719d911017c592'
    assert md5s('hello') == secure_hash_s('hello', _md5)
    assert md5s('hello\n') == md5s('hello')

# End of file

# Generated at 2022-06-11 18:05:02.976805
# Unit test for function md5s
def test_md5s():
    # Example from RFC 1321
    assert md5s("abc") == '900150983cd24fb0d6963f7d28e17f72'

    # Example from FIPS 180-2
    assert md5s("abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq") == '8215ef0796a20bcaaae116d3876c664a'

    # FIPS 180-2 - test with different initial hash value
    md5_test = md5s("abc")
    md5_test.update("def")
    assert md5_test.hexdigest() == 'e2fc714c4727ee9395f324cd2e7f331f'



# Generated at 2022-06-11 18:05:05.021831
# Unit test for function md5s
def test_md5s():
    assert secure_hash_s('HelloWorld') == 'ed076287532e86365e841e92bfc50d8c'

# Generated at 2022-06-11 18:05:27.506920
# Unit test for function md5s
def test_md5s():
    if not _md5:
        return

    assert md5s(b"hello") == "5d41402abc4b2a76b9719d911017c592"
    # Test unicode in py2
    import sys
    if sys.version_info[0] == 2:
        assert md5s(u"hello") == "5d41402abc4b2a76b9719d911017c592"
    assert md5s(b"hello\x00\x01") == "2c4a0d87150f3b6e881bdc435e6d6650"
