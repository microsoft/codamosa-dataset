

# Generated at 2022-06-11 14:08:58.772388
# Unit test for function split_url
def test_split_url():
    func = split_url

    # This is a good URL
    url = func('https://user:pass@ansible.com:8080/docs?abc#DEF')
    assert url['scheme'] == 'https'
    assert url['netloc'] == 'user:pass@ansible.com:8080'
    assert url['path'] == '/docs'
    assert url['query'] == 'abc'
    assert url['fragment'] == 'DEF'

    url = func('https://user:pass@ansible.com:8080/docs?abc#DEF', 'scheme')
    assert url == 'https'

    url = func('https://user:pass@ansible.com:8080/docs?abc#DEF', 'fragment')
    assert url == 'DEF'

    # This is a bad URL

# Generated at 2022-06-11 14:09:07.236972
# Unit test for function split_url
def test_split_url():
    from ansible.utils.test import get_exception

    # Test a valid
    assert split_url('http://www.ansible.com') == {
        'netloc': 'www.ansible.com',
        'path': '',
        'scheme': 'http',
        'fragment': '',
        'query': ''
    }

    # Test a valid without scheme
    assert split_url('www.ansible.com') == {
        'path': 'www.ansible.com',
        'fragment': '',
        'query': '',
        'netloc': '',
        'scheme': ''
    }

    # Test an invalid

# Generated at 2022-06-11 14:09:19.392687
# Unit test for function split_url
def test_split_url():
    # Simple URL
    assert split_url('http://www.example.com/path/to/myfile.html') == {'fragment': '', 'netloc': 'www.example.com', 'path': '/path/to/myfile.html', 'scheme': 'http', 'query': ''}

    # Simple URL with query
    assert split_url('http://www.example.com/search?q=ansible&hl=en') == {'fragment': '', 'netloc': 'www.example.com', 'path': '/search', 'scheme': 'http', 'query': 'q=ansible&hl=en'}

    # Simple URL with query and fragment

# Generated at 2022-06-11 14:09:25.395812
# Unit test for function split_url
def test_split_url():
    assert split_url('http://example.com/foo/bar') == {
        'scheme': 'http',
        'netloc': 'example.com',
        'path': '/foo/bar',
        'query': '',
        'fragment': ''
    }
    assert split_url('http://example.com/foo/bar', 'path') == '/foo/bar'

# Generated at 2022-06-11 14:09:30.857620
# Unit test for function split_url
def test_split_url():
    assert split_url("https://user:pass@www.example.com:12345/path?query=1#fragment") == {'fragment': 'fragment', 'netloc': 'user:pass@www.example.com:12345', 'path': '/path', 'scheme': 'https', 'query': 'query=1'}
    assert split_url("https://user:pass@www.example.com:12345/path?query=1#fragment", "path") == '/path'

# Generated at 2022-06-11 14:09:41.586130
# Unit test for function split_url
def test_split_url():
    assert split_url('http://127.0.0.1:8080/api/v2/tasks/123/') == {'port': 8080, 'hostname': '127.0.0.1', 'netloc': '127.0.0.1:8080', 'path': '/api/v2/tasks/123/', 'scheme': 'http', 'query': ''}
    assert split_url('http://127.0.0.1:8080/api/v2/tasks/123/?foo=1') == {'port': 8080, 'hostname': '127.0.0.1', 'netloc': '127.0.0.1:8080', 'path': '/api/v2/tasks/123/', 'scheme': 'http', 'query': 'foo=1'}

# Generated at 2022-06-11 14:09:48.876073
# Unit test for function split_url
def test_split_url():
    input = 'https://username@www.example.com:80/path?query=foo#fragment'
    url_split = split_url(input)
    assert url_split['scheme'] == 'https'
    assert url_split['netloc'] == 'username@www.example.com:80'
    assert url_split['path'] == '/path'
    assert url_split['query'] == 'query=foo'
    assert url_split['fragment'] == 'fragment'

    # Test different kwarg option
    assert split_url(input, 'scheme') == 'https'
    assert split_url(input, 'netloc') == 'username@www.example.com:80'
    assert split_url(input, 'path') == '/path'

# Generated at 2022-06-11 14:09:57.110332
# Unit test for function split_url
def test_split_url():
    # Try a valid URL with various query options
    assert split_url('http://www.example.com') == {'fragment': '', 'netloc': 'www.example.com', 'path': '', 'query': '', 'scheme': 'http'}
    assert split_url('http://www.example.com', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com', 'scheme') == 'http'

    # Try an invalid query option
    try:
        split_url('http://www.example.com', 'invalid')
        assert False
    except Exception as e:
        assert str(e) == 'urlsplit: unknown URL component: invalid'

    # Try an invalid URL

# Generated at 2022-06-11 14:10:06.613949
# Unit test for function split_url
def test_split_url():
    assert split_url(value='https://www.example.net/foo.txt/bar.txt?aaa=bbb', query='scheme') == 'https'
    assert split_url(value='https://www.example.net/foo.txt/bar.txt?aaa=bbb', query='netloc') == 'www.example.net'
    assert split_url(value='https://www.example.net/foo.txt/bar.txt?aaa=bbb', query='path') == '/foo.txt/bar.txt'
    assert split_url(value='https://www.example.net/foo.txt/bar.txt?aaa=bbb', query='query') == 'aaa=bbb'

# Generated at 2022-06-11 14:10:13.794832
# Unit test for function split_url
def test_split_url():
    url = 'http://username:password@example.com:8443/path/to/something?query=string#anchor'
    result = split_url(url)

    assert(result['scheme'] == 'http')
    assert(result['netloc'] == 'username:password@example.com:8443')
    assert(result['username'] == 'username')
    assert(result['password'] == 'password')
    assert(result['hostname'] == 'example.com')
    assert(result['port'] == '8443')
    assert(result['path'] == '/path/to/something')
    assert(result['query'] == 'query=string')
    assert(result['fragment'] == 'anchor')