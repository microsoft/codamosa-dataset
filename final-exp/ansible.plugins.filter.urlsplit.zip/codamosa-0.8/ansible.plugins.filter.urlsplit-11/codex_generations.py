

# Generated at 2022-06-11 14:08:54.231035
# Unit test for function split_url
def test_split_url():
    '''
        Test case for verifying split_url function.
        For more information, see:
        https://docs.python.org/2/library/urlparse.html#urlparse.urlsplit
    '''
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    module_path = 'library/filter_plugins/uri.py'
    shutil.copy(module_path, temp_dir)
    module_path = os.path.join(temp_dir, os.path.basename(module_path))
    sys.path.append(temp_dir)

    from uri import split_url

# Generated at 2022-06-11 14:09:04.515577
# Unit test for function split_url
def test_split_url():

    # Test variables
    input_url = 'https://user:password@host.com:123/path/to/file?query=string#url_fragment'

    test_scheme = 'https'
    test_netloc = 'user:password@host.com:123'
    test_path = '/path/to/file'
    test_query = 'query=string'
    test_fragment = 'url_fragment'

    test_password = 'password'

    # Test class initialization
    test_class = FilterModule()

    # Test url split function
    test_results = test_class.filters()['urlsplit'](input_url)

    # Test dictionary methods
    assert test_results.keys() == ['scheme', 'netloc', 'path', 'query', 'fragment']

    # Test dictionary

# Generated at 2022-06-11 14:09:13.209040
# Unit test for function split_url
def test_split_url():
    test_string = 'http://www.example.com:8080/path/?query=1#fragment'
    url = split_url(test_string, 'scheme')
    assert url == 'http'
    url = split_url(test_string, 'netloc')
    assert url == 'www.example.com:8080'
    url = split_url(test_string, 'path')
    assert url == '/path/'
    url = split_url(test_string, 'query')
    assert url == 'query=1'
    url = split_url(test_string, 'fragment')
    assert url == 'fragment'

# Generated at 2022-06-11 14:09:24.688887
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils import basic


# Generated at 2022-06-11 14:09:32.993614
# Unit test for function split_url
def test_split_url():

    from ansible.module_utils.six.moves.urllib.parse import urlsplit, urlunsplit
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    F = FilterModule()

    assert F.filters()['urlsplit']('http://www.google.com') == urlsplit('http://www.google.com')
    assert F.filters()['urlsplit']('http://www.google.com', query='scheme') == urlsplit('http://www.google.com').scheme
    assert F.filters()['urlsplit']('http://www.google.com', query='netloc') == urlsplit('http://www.google.com').netloc

# Generated at 2022-06-11 14:09:38.637615
# Unit test for function split_url
def test_split_url():
    expected = {
        'scheme': 'http',
        'netloc': 'www.ansible.com',
        'path': '/',
        'query': 'name=derek',
        'fragment': ''
    }

    assert(expected == split_url('http://www.ansible.com/?name=derek'))



# Generated at 2022-06-11 14:09:47.554163
# Unit test for function split_url

# Generated at 2022-06-11 14:09:52.775324
# Unit test for function split_url
def test_split_url():
    """
    Performs a unit test on the function 'split_url'.
    """
    assert split_url('http://www.example.com') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '',
        'query': '',
        'fragment': ''
    }

# Generated at 2022-06-11 14:09:57.099788
# Unit test for function split_url
def test_split_url():
    url = "https://user:password@example.com:1234/api?foo=bar#baz"
    result = split_url(url)
    assert(result == {'scheme': 'https', 'netloc': 'user:password@example.com:1234', 'path': '/api', 'query': 'foo=bar', 'fragment': 'baz'})


# Generated at 2022-06-11 14:10:06.603793
# Unit test for function split_url
def test_split_url():
    f = FilterModule()
    assert split_url("http://example.com/foo/bar?baz=quux#frag") == f.filters()['urlsplit']("http://example.com/foo/bar?baz=quux#frag")
    assert split_url("http://example.com/foo/bar?baz=quux#frag", "scheme") == f.filters()['urlsplit']("http://example.com/foo/bar?baz=quux#frag", "scheme")
    assert split_url("http://example.com/foo/bar?baz=quux#frag", "netloc") == f.filters()['urlsplit']("http://example.com/foo/bar?baz=quux#frag", "netloc")