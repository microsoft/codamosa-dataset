

# Generated at 2022-06-11 14:08:52.451600
# Unit test for function split_url
def test_split_url():

    # URL with query
    url = "http://www.foo.bar/baz.html?a=1&b=2"

    # Test with no options
    result = split_url(value=url)
    assert result

    # Test with invalid option
    try:
        result = split_url(value=url, query='foo')
    except AnsibleFilterError:
        pass
    else:
        raise RuntimeError("Test failed!")

    # Test with valid option
    result = split_url(value=url, query='scheme')
    assert result == "http"



# Generated at 2022-06-11 14:09:03.190954
# Unit test for function split_url
def test_split_url():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var

    url = UnsafeProxy(dict(
        scheme='http',
        netloc='example.com',
        path='/path',
        query=dict(q='search', s='start'),
        fragment='top'
    ))

    assert wrap_var(dict(
        scheme='http',
        netloc='example.com',
        path='/path',
        query=dict(q='search', s='start'),
        fragment='top'
    )) == \
    wrap_var(split_url(url))

    assert wrap_var('http') == \
    wrap_var(split_url(url, query='scheme'))

    assert wrap_var('example.com')

# Generated at 2022-06-11 14:09:13.455211
# Unit test for function split_url
def test_split_url():
    assert split_url('http://ansible.com/foo/bar', 'scheme') == 'http'
    assert split_url('http://ansible.com/foo/bar', 'netloc') == 'ansible.com'
    assert split_url('http://ansible.com/foo/bar', 'path') == '/foo/bar'
    assert split_url('http://ansible.com/foo/bar', 'params') == ''
    assert split_url('http://ansible.com/foo/bar', 'query') == ''
    assert split_url('http://ansible.com/foo/bar', 'fragment') == ''
    assert split_url('http://ansible.com/foo/bar?baz=qux', 'query') == 'baz=qux'

# Generated at 2022-06-11 14:09:25.203858
# Unit test for function split_url
def test_split_url():
    # Make sure the function exists
    assert callable(split_url)

    # Make sure it returns the right values
    url = "rhev://aaa.bbb.com/ccc/ddd/eee"
    assert split_url(url, 'scheme') == "rhev"
    assert split_url(url, 'netloc') == "aaa.bbb.com"
    assert split_url(url, 'path') == "/ccc/ddd/eee"
    assert split_url(url, 'params') == ""
    assert split_url(url, 'query') == ""
    assert split_url(url, 'fragment') == ""

    url2 = "https://aaa.bbb.com/artifactory/ccc/ddd/eee/fff/ggg"
    assert split_url

# Generated at 2022-06-11 14:09:31.606811
# Unit test for function split_url
def test_split_url():
    result = split_url('http://foo:bar@host.com:8042/path;parameters?query=arg#fragment', 'query')
    assert result == 'arg'
    result = split_url('http://foo:bar@host.com:8042/path;parameters?query=arg#fragment')
    assert result == {
        'scheme': 'http',
        'netloc': 'foo:bar@host.com:8042',
        'path': '/path;parameters',
        'query': 'query=arg',
        'fragment': 'fragment'
    }

# Generated at 2022-06-11 14:09:43.105140
# Unit test for function split_url
def test_split_url():

    test_cases = {
        ('http://www.example.com/foo/bar?query=string', 'scheme') : 'http',
        ('http://www.example.com/foo/bar?query=string', 'netloc') : 'www.example.com',
        ('http://www.example.com/foo/bar?query=string', 'path') : '/foo/bar',
        ('http://www.example.com/foo/bar?query=string', 'query') : 'query=string',
        ('http://www.example.com/foo/bar?query=string', 'fragment') : '',
    }

    for case, expected in test_cases.items():
        uri = case[0]
        value = case[1]
        result = split_url(uri, query=value)


# Generated at 2022-06-11 14:09:51.043019
# Unit test for function split_url
def test_split_url():

    # Testcase 1: Split the url with query
    url = "https://www.ansible.com/path/to/ansible-docs/index.html?a=b&c=d"
    print(split_url(url, 'scheme'))

    # Testcase 2: Split the url without query
    print(split_url(url))

    # Testcase 3: Split the url with invalid option
    print(split_url(url, 'test'))

if __name__ == "__main__":
    test_split_url()

# Generated at 2022-06-11 14:09:55.697612
# Unit test for function split_url
def test_split_url():
    url = 'http://www.ansible.com/index.html'
    for query in ['scheme', 'netloc', 'path', 'query', 'fragment']:
        assert split_url(url, query) == urlsplit(url)[split_url.__defaults__.index(query)]

    assert split_url(url)['scheme'] == 'http'



# Generated at 2022-06-11 14:10:05.647705
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/myfile.html?key1=value1&key2=value2#Anchor', 'hostname') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/myfile.html?key1=value1&key2=value2#Anchor', 'path') == '/path/to/myfile.html'
    assert split_url('http://www.example.com/path/to/myfile.html?key1=value1&key2=value2#Anchor', 'query') == 'key1=value1&key2=value2'

# Generated at 2022-06-11 14:10:10.009639
# Unit test for function split_url
def test_split_url():
    value = 'http://www.example.com:8080/path/to/content?key=value&array[]=value1&array[]=value2#fragment'
    query = 'scheme'
    assert split_url(value, query) == 'http'
    return True
