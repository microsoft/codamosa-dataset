

# Generated at 2022-06-11 14:08:57.729293
# Unit test for function split_url

# Generated at 2022-06-11 14:09:06.336798
# Unit test for function split_url
def test_split_url():
    string = 'https://docs.ansible.com/ansible/latest/Network_Debug_Guide.html?highlight=net_debug#creating-net_debug-module-output'
    assert split_url(string) == {
        'netloc': 'docs.ansible.com',
        'scheme': 'https',
        'port': None,
        'path': '/ansible/latest/Network_Debug_Guide.html',
        'fragment': None,
        'query': 'highlight=net_debug#creating-net_debug-module-output',
        'username': None,
        'password': None
    }
    assert split_url(string, 'query') == 'highlight=net_debug#creating-net_debug-module-output'

# Generated at 2022-06-11 14:09:17.822666
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.constants

    arguments = {}
    arguments['url'] = 'http://username:password@hostname:8080/path?arg=value#anchor'
    module = AnsibleModule(argument_spec=arguments)
    result = split_url(module.params['url'], alias='test_split_url')

    # Manually reference expected values
    expected = {
        'scheme': 'http',
        'netloc': 'username:password@hostname:8080',
        'path': '/path',
        'query': 'arg=value',
        'fragment': 'anchor',
    }
    for key, value in expected.items():
        assert result[key] == value

# Generated at 2022-06-11 14:09:28.475830
# Unit test for function split_url
def test_split_url():
    f = split_url('http://user:pass@example.com:8080/path;p1;p2=v2;p3=v3?query=value#fragment')

    assert f['scheme'] == 'http'
    assert f['netloc'] == 'user:pass@example.com:8080'
    assert f['username'] == 'user'
    assert f['password'] == 'pass'
    assert f['hostname'] == 'example.com'
    assert f['port'] == '8080'
    assert f['path'] == '/path;p1;p2=v2;p3=v3'
    assert f['params'] == ''
    assert f['query'] == 'query=value'
    assert f['fragment'] == 'fragment'


# Generated at 2022-06-11 14:09:38.883998
# Unit test for function split_url
def test_split_url():
    # Testing valid URLs with no options or existing values to return.
    test_inputs = [
        "https://www.ansible.com/why-ansible",
        "https://www.ansible.com/path1/path2?option1=value1&option2=value2",
        "https://www.ansible.com/path1/path2/#somefragment"]
    for t in test_inputs:
        try:
            result = split_url(t, alias='urlsplit')
        except Exception as e:
            assert False, "urlsplit failed: %s" % str(e)
        assert isinstance(result, dict), "urlsplit did not return a dictionary"

    # Testing an invalid URL

# Generated at 2022-06-11 14:09:47.711194
# Unit test for function split_url
def test_split_url():
    url = 'http://www.example.com:80/path;param?query=arg#frag'
    query_to_result = {
        'scheme': 'http',
        'netloc': 'www.example.com:80',
        'path': '/path;param',
        'query': 'query=arg',
        'fragment': 'frag',
        '': {'netloc': 'www.example.com:80', 'path': '/path;param', 'fragment': 'frag', 'query': 'query=arg', 'scheme': 'http'}
    }
    result = split_url(url, query='')
    for query, should_be in query_to_result.items():
        is_now = split_url(url, query=query)
        assert is_now == should_

# Generated at 2022-06-11 14:09:56.755726
# Unit test for function split_url
def test_split_url():
    '''
    function split_url
    '''
    import sys
    from ansible.utils.context_objects import AnsibleContext
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    ctx = AnsibleContext(loader=loader)

    hostname = 'test.test.test.test'
    port = '70'
    path = '/test'
    result = split_url(hostname + ':' + port + path, 'path', 'urlsplit')
    assert result == path

    result = split_url(hostname + ':' + port + path, 'hostname', 'urlsplit')
    assert result == hostname

    result = split_url(hostname + ':' + port + path, 'port', 'urlsplit')
    assert result == port

    # Test for exception


# Generated at 2022-06-11 14:10:05.954958
# Unit test for function split_url
def test_split_url():
    test_dict = {
        'scheme': 'https',
        'netloc': 'ansible.com',
        'path': '/example',
        'query': 'foo=bar',
        'fragment': 'baz'
    }
    assert split_url('https://ansible.com/example?foo=bar#baz') == test_dict
    assert split_url('https://ansible.com/example?foo=bar#baz', 'scheme') == 'https'
    assert split_url('https://ansible.com/example?foo=bar#baz', 'query') == 'foo=bar'
    assert split_url('https://ansible.com/example?foo=bar#baz', 'fragment') == 'baz'

# Generated at 2022-06-11 14:10:14.193735
# Unit test for function split_url
def test_split_url():
    url = 'https://user:pass@www.example.com:8080/path;param?query=value#fragment'
    assert split_url(url, 'scheme') == 'https'
    assert split_url(url, 'netloc') == 'user:pass@www.example.com:8080'
    assert split_url(url, 'path') == '/path;param'
    assert split_url(url, 'query') == 'query=value'
    assert split_url(url, 'fragment') == 'fragment'
    assert split_url(url, 'username') == 'user'
    assert split_url(url, 'password') == 'pass'
    assert split_url(url, 'hostname') == 'www.example.com'

# Generated at 2022-06-11 14:10:24.160216
# Unit test for function split_url
def test_split_url():
    assert split_url("http://www.google.com", "netloc") == "www.google.com"
    assert split_url("http://www.google.com/search?q=time&hl=en", "path") == "/search"
    assert split_url("http://www.google.com/search?q=time&hl=en", "query") == "q=time&hl=en"
    assert split_url("http://www.google.com/search?q=time&hl=en", "scheme") == "http"
    assert split_url("http://www.google.com/search?q=time&hl=en", "fragment") == ''