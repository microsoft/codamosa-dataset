

# Generated at 2022-06-11 14:08:53.456422
# Unit test for function split_url
def test_split_url():
    ''' Test function split_url '''
    url = 'http://www.example.com:8080/path?q=moo'
    compare = {'scheme': 'http',
               'netloc': 'www.example.com:8080',
               'path': '/path',
               'query': 'q=moo',
               'fragment': ''}

    # Call split_url returning entire dictionary
    results = split_url(url)
    assert results == compare

    # Call split_url with a specific query - check each key
    for key in compare:
        assert split_url(url, key) == compare[key]

# Generated at 2022-06-11 14:09:01.234245
# Unit test for function split_url
def test_split_url():
    '''
    this is a test for the split_url function
    '''
    results = split_url('https://user:pass@www.redhat.com:8080/product/TESTING/TESTING1/TESTING2/TESTING3')
    assert results['scheme'] == 'https'
    assert results['netloc'] == 'user:pass@www.redhat.com:8080'
    assert results['path'] == '/product/TESTING/TESTING1/TESTING2/TESTING3'

# Generated at 2022-06-11 14:09:08.631014
# Unit test for function split_url
def test_split_url():
    assert {
        'fragment': '',
        'netloc': 'www.example.com',
        'path': '/path',
        'query': '',
        'scheme': 'http',
    } == split_url(value='http://www.example.com/path')
    assert 'www.example.com' == split_url(value='http://www.example.com', query='netloc')
    assert "" == split_url(value='http:///')['path']
    assert "//" == split_url(value='http:////')['path']
    assert "" == split_url(value='http://?')['path']
    assert "" == split_url(value='http://;')['path']

# Generated at 2022-06-11 14:09:13.824259
# Unit test for function split_url
def test_split_url():
    assert split_url('http://user:pass@localhost:8080/foo/bar?baz=foobar#frag') == {'scheme': 'http', 'netloc': 'user:pass@localhost:8080', 'path': '/foo/bar', 'query': 'baz=foobar', 'fragment': 'frag'}
    assert split_url('http://user:pass@localhost:8080/foo/bar?baz=foobar#frag', query='netloc') == 'user:pass@localhost:8080'
    assert split_url('http://user:pass@localhost:8080/foo/bar?baz=foobar#frag', query='query') == 'baz=foobar'
    assert split_url('http://localhost/foo/bar', query='scheme') == 'http'

# Generated at 2022-06-11 14:09:25.584622
# Unit test for function split_url
def test_split_url():
    test_url = 'https://username:password@www.example.com:8080/foo/bar?a=b&c=d#target'
    assert split_url(test_url)['scheme'] == 'https'
    assert split_url(test_url)['username'] == 'username'
    assert split_url(test_url)['password'] == 'password'
    assert split_url(test_url)['fragment'] == 'target'
    assert split_url(test_url, 'netloc') == 'username:password@www.example.com:8080'
    assert split_url(test_url, 'path', 'my_alias') == '/foo/bar'
    assert split_url(test_url, 'query') == 'a=b&c=d'

# Generated at 2022-06-11 14:09:34.117754
# Unit test for function split_url
def test_split_url():
    """ Test function split_url """

    result = split_url('https://docs.ansible.com/ansible/2.4/modules/find_module.html')
    assert result['scheme'] == 'https'
    assert result['netloc'] == 'docs.ansible.com'
    assert result['path'] == '/ansible/2.4/modules/find_module.html'
    assert result['query'] == ''
    assert result['fragment'] == ''

    result = split_url('https://docs.ansible.com/ansible/2.4/modules/find_module.html', 'scheme')
    assert result == 'https'

    result = split_url('https://docs.ansible.com/ansible/2.4/modules/find_module.html', 'netloc')

# Generated at 2022-06-11 14:09:45.209076
# Unit test for function split_url
def test_split_url():
    """ This unit test should be moved to core after the filter is integrated. """
    assert split_url('http://www.ansible.com/', 'scheme') == 'http'
    assert split_url('http://www.ansible.com/', 'hostname') == 'www.ansible.com'
    assert split_url('http://www.ansible.com/', 'path') == '/'
    assert split_url('http://www.ansible.com/', 'domain') == 'ansible.com'
    assert split_url('http://www.ansible.com/', 'query') == ''
    assert split_url('http://www.ansible.com/', 'fragment') == ''
    assert split_url('http://www.ansible.com/', 'username') == ''

# Generated at 2022-06-11 14:09:55.762545
# Unit test for function split_url

# Generated at 2022-06-11 14:10:00.712560
# Unit test for function split_url
def test_split_url():
    """
    Test urlsplit implementation
    :return:
    """
    url = 'scheme://username:passwd@www.example.com:80/path;parameter?query=arg#fragment'
    query = 'scheme'
    result = 'scheme'
    assert split_url(url, query=query) == result

# Generated at 2022-06-11 14:10:07.907900
# Unit test for function split_url
def test_split_url():
    assert split_url('http://user@example.com:8080/path?q=abc#def') == {'fragment': 'def', 'netloc': 'user@example.com:8080', 'path': '/path', 'query': 'q=abc', 'scheme': 'http', 'username': 'user', 'password': None, 'hostname': 'example.com', 'port': 8080}
    assert split_url('http://user@example.com:8080/path?q=abc#def', 'scheme') == 'http'
    assert split_url('http://user@example.com:8080/path?q=abc#def', 'username') == 'user'
    assert split_url('http://user@example.com:8080/path?q=abc#def', 'password') == None
    assert split_