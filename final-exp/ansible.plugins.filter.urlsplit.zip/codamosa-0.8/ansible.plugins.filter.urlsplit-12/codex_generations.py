

# Generated at 2022-06-11 14:08:56.823825
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com:8080/path?arg=value', query='scheme') == 'http'
    assert split_url('https://www.example.com:443/path?arg=value', query='netloc') == 'www.example.com:443'
    assert split_url('http://www.example.com:8080/path?arg=value', query='path') == '/path'
    assert split_url('http://www.example.com:8080/path?arg=value', query='query') == 'arg=value'
    assert split_url('http://www.example.com:8080/path?arg=value', query='fragment') == ''

# Generated at 2022-06-11 14:09:03.762303
# Unit test for function split_url
def test_split_url():
    assert split_url('https://user:passwd@host.com:8080/path/to/key?query=param#fragment') == \
        {
            'scheme': 'https',
            'netloc': 'user:passwd@host.com:8080',
            'path': '/path/to/key',
            'query': 'query=param',
            'fragment': 'fragment',
            'username': 'user',
            'password': 'passwd',
            'hostname': 'host.com',
            'port': 8080
        }

# Generated at 2022-06-11 14:09:14.318473
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.foo.com:8080/bar/path?a=1&b=2#abc', 'scheme') == 'http'
    assert split_url('http://www.foo.com:8080/bar/path?a=1&b=2#abc', 'netloc') == 'www.foo.com:8080'
    assert split_url('http://www.foo.com:8080/bar/path?a=1&b=2#abc', 'path') == '/bar/path'
    assert split_url('http://www.foo.com:8080/bar/path?a=1&b=2#abc', 'query') == 'a=1&b=2'

# Generated at 2022-06-11 14:09:25.972728
# Unit test for function split_url
def test_split_url():
    '''
    Unit test for function split_url
    '''
    # pylint: disable=anomalous-backslash-in-string

    # Test all the parts of url
    url = 'http://www.example.com:80/path/to?query=string#fragment'
    result = split_url(url)
    assert result['scheme'] == 'http'
    assert result['netloc'] == 'www.example.com:80'
    assert result['path'] == '/path/to'
    assert result['query'] == 'query=string'
    assert result['fragment'] == 'fragment'

    # Test filter parameter
    assert split_url(url, 'path') == '/path/to'
    assert split_url(url, 'query') == 'query=string'

    # Test

# Generated at 2022-06-11 14:09:34.910018
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com:5000/testing?q=one') == {'scheme': 'http', 'netloc': 'www.example.com:5000', 'path': '/testing', 'query': 'q=one', 'fragment': ''}
    assert split_url('http://www.example.com:5000/testing?q=one', 'scheme') == 'http'
    assert split_url('http://www.example.com:5000/testing?q=one', 'netloc') == 'www.example.com:5000'
    assert split_url('http://www.example.com:5000/testing?q=one', 'path') == '/testing'
    assert split_url('http://www.example.com:5000/testing?q=one', 'query') == 'q=one'
    assert split

# Generated at 2022-06-11 14:09:40.891221
# Unit test for function split_url
def test_split_url():
    uri = 'https://www.example.com/blog/2017/12/12/ansible-uri-split'
    expected = {'scheme': 'https', 'netloc': 'www.example.com', 'path': '/blog/2017/12/12/ansible-uri-split', 'query': '', 'fragment': ''}

    splitted = split_url(uri)

    assert expected == splitted

# Generated at 2022-06-11 14:09:48.630410
# Unit test for function split_url
def test_split_url():

    url = 'http://username:password@example.com:5555/path/to/resource?foo=bar&bin=baz#section'

    # Test all options individually
    assert 'http' == split_url(url, 'scheme')
    assert 'username:password' == split_url(url, 'netloc')
    assert 'username:password@example.com:5555' == split_url(url, 'hostname')
    assert 'username' == split_url(url, 'username')
    assert 'password' == split_url(url, 'password')
    assert 'example.com' == split_url(url, 'hostname')
    assert '5555' == split_url(url, 'port')
    assert '/path/to/resource' == split_url(url, 'path')

# Generated at 2022-06-11 14:09:54.349455
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    assert split_url('http://www.example.com:8042/over/there?name=ferret#nose') == helpers.object_to_dict(urlsplit('http://www.example.com:8042/over/there?name=ferret#nose'), exclude=['count', 'index', 'geturl', 'encode'])

# Generated at 2022-06-11 14:10:04.451928
# Unit test for function split_url
def test_split_url():
    test = "https://user:pass@example.com:443/dir/dir.2/index.htm?p=1&q=2"
    assert split_url(value=test, query='scheme') == 'https'
    assert split_url(value=test, query='netloc') == 'user:pass@example.com:443'
    assert split_url(value=test, query='path') == '/dir/dir.2/index.htm'
    assert split_url(value=test, query='query') == 'p=1&q=2'
    assert split_url(value=test, query='fragment') == ''
    assert split_url(value=test, query='username') == 'user'
    assert split_url(value=test, query='password') == 'pass'

# Generated at 2022-06-11 14:10:13.145019
# Unit test for function split_url
def test_split_url():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    url = 'http://www.example.com/index.html'
    query = 'scheme'
    exp_result = 'http'
    result = split_url(url, query)
    assert isinstance(result, AnsibleUnsafeText)
    # Test full url
    url = 'http://www.example.com/index.html'
    full_url_exp_result = {
        'netloc': 'www.example.com',
        'query': '',
        'fragment': '',
        'path': '/index.html',
        'scheme': 'http'
    }
    result = split_url(url)
    assert result == full_url_exp_result