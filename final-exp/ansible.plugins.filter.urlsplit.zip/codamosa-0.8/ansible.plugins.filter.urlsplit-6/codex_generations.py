

# Generated at 2022-06-11 14:08:57.774030
# Unit test for function split_url
def test_split_url():
    #Init the filter
    split_url_filter = split_url

    #Test invalid url
    invalid_urls = ["", "a", "scheme:", "scheme:/", "scheme:///"]
    for url in invalid_urls:
        try:
            split_url_filter(url)
            assert False
        except AnsibleFilterError:
            assert True

    #Test valid url
    valid_url = "scheme://host/path?query#fragment"
    url_result = split_url_filter(valid_url)
    assert url_result['scheme'] == 'scheme'
    assert url_result['netloc'] == 'host'
    assert url_result['path'] == '/path'
    assert url_result['query'] == 'query'

# Generated at 2022-06-11 14:09:06.660325
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/foo/bar/baz') == {'netloc': 'www.example.com',
                                                              'path': '/foo/bar/baz',
                                                              'port': None,
                                                              'fragment': '',
                                                              'scheme': 'http',
                                                              'query': '',
                                                              'username': '',
                                                              'password': '',
                                                              'hostname': 'www.example.com'}
    assert split_url('http://www.example.com/foo/bar/baz', 'query') == ''

# Generated at 2022-06-11 14:09:18.722896
# Unit test for function split_url

# Generated at 2022-06-11 14:09:26.850859
# Unit test for function split_url
def test_split_url():
    '''
    Test for split_url module.
    '''
    f = FilterModule()
    assert f.filters()['urlsplit']('http://www.example.com/foo?q=1', 'query') == 'q=1'
    assert f.filters()['urlsplit']('http://www.example.com/foo?q=1') == {'username': '', 'path': '/foo', 'fragment': '', 'query': 'q=1', 'netloc': 'www.example.com', 'scheme': 'http', 'password': ''}

# Generated at 2022-06-11 14:09:34.202671
# Unit test for function split_url
def test_split_url():
    """ Unit test for builtin filter split_url """

    from ansible.plugins.filter.urlsplit import split_url

    # Test without a query
    assert split_url(u'http://www.cwi.nl:80/%7Eguido/Python.html') == {
        'fragment': u'',
        'netloc': u'www.cwi.nl:80',
        'path': u'/%7Eguido/Python.html',
        'query': u'',
        'scheme': u'http'
    }

    # Test with a query
    assert split_url(u'http://www.cwi.nl:80/%7Eguido/Python.html', query='path') == u'/%7Eguido/Python.html'

    # Test invalid query

# Generated at 2022-06-11 14:09:45.279673
# Unit test for function split_url
def test_split_url():
    ''' test for split_url '''

    url = 'test://test:test@test:test/test/test/test?test=test&test=test&test=test#test'
    assert split_url(url, 'scheme') == 'test'
    assert split_url(url, 'netloc') == 'test:test@test:test'
    assert split_url(url, 'username') == 'test'
    assert split_url(url, 'password') == 'test'
    assert split_url(url, 'hostname') == 'test'
    assert split_url(url, 'host') == 'test:test'
    assert split_url(url, 'port') == 'test'
    assert split_url(url, 'path') == '/test/test/test'

# Generated at 2022-06-11 14:09:55.825960
# Unit test for function split_url
def test_split_url():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils._text import to_native


# Generated at 2022-06-11 14:10:05.743206
# Unit test for function split_url
def test_split_url():
    url = "https://www.ansible.com/ansible/roadshow/register?t=Austin%2C%20TX%20-%20October%204%2C%202016&c=2212&i=1430"

    result = split_url(url)
    assert result['scheme'] == 'https', "Scheme is https"
    assert result['netloc'] == 'www.ansible.com', "Domain is ansible.com"
    assert result['path'] == '/ansible/roadshow/register', "Path is /ansible/roadshow/register"

# Generated at 2022-06-11 14:10:14.092591
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.ansible.com/') == split_url('http://www.ansible.com/', 'query')
    assert split_url('http://www.ansible.com/', 'scheme') == 'http'
    assert split_url('http://www.ansible.com/', 'netloc') == 'www.ansible.com'
    assert split_url('http://www.ansible.com/', 'path') == '/'
    try:
        split_url('http://www.ansible.com/', 'port')
    except AnsibleFilterError:
        pass
    else:
        assert False
    assert split_url('http://www.ansible.com/', 'query') == ''

# Generated at 2022-06-11 14:10:18.355370
# Unit test for function split_url
def test_split_url():

    url = "ftp://user:pass@host.domain.com:21/path;parameters?query=argument#fragment"
    split_url(url, 'scheme')
    split_url(url, 'path')
    split_url(url, 'netloc')
    split_url(url, 'fragment')