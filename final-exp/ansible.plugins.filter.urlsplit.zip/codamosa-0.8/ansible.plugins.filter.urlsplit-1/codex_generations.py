

# Generated at 2022-06-11 14:08:59.739488
# Unit test for function split_url

# Generated at 2022-06-11 14:09:07.832247
# Unit test for function split_url
def test_split_url():
    import unittest2 as unittest
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class TestSplitUrl(unittest.TestCase):

        def test_split_url(self):

            url = 'https://user@github.com:8080/junk/test?arg=test#test'

            val = split_url(url)

            def x_assert(r, key, value):
                self.assertIn(key, r)
                self.assertTrue(isinstance(r[key], AnsibleUnsafeText))
                self.assertEqual(r[key], value)

            x_assert(val, 'scheme', 'https')
            x_assert(val, 'netloc', 'user@github.com:8080')

# Generated at 2022-06-11 14:09:09.371420
# Unit test for function split_url
def test_split_url():
    pass

# Generated at 2022-06-11 14:09:15.103464
# Unit test for function split_url
def test_split_url():
    d = {'scheme': 'http', 'netloc': 'test.com', 'path': '/test', 'query': 'test=test', 'fragment': 'test'}
    assert d == split_url('http://test.com/test?test=test#test')
    assert d['scheme'] == split_url('http://test.com/test?test=test#test', 'scheme')

# Generated at 2022-06-11 14:09:26.642652
# Unit test for function split_url
def test_split_url():
    # Basic checks
    uri = 'http://ansible.com/some_path?some_arg=some_val#some-anchor'
    assert split_url(uri, 'scheme') == 'http'
    assert split_url(uri, 'netloc') == 'ansible.com'
    assert split_url(uri, 'path') == '/some_path'
    assert split_url(uri, 'query') == 'some_arg=some_val'
    assert split_url(uri, 'fragment') == 'some-anchor'

    # Expected errors
    uri = 'ansible.com'
    try:
        split_url(uri, 'scheme')
        raise AssertionError('scheme part not required')
    except AnsibleFilterError:
        pass


# Generated at 2022-06-11 14:09:36.086314
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.ansible.com/example?foo=bar#baz', query='scheme') == 'http'
    assert split_url('http://www.ansible.com/example?foo=bar#baz', query='netloc') == 'www.ansible.com'
    assert split_url('http://www.ansible.com/example?foo=bar#baz', query='url') == 'http://www.ansible.com/example?foo=bar#baz'
    assert split_url('http://www.ansible.com/example?foo=bar#baz', query='fragment') == 'baz'
    assert split_url('http://www.ansible.com/example?foo=bar#baz', query='path') == '/example'

# Generated at 2022-06-11 14:09:46.207538
# Unit test for function split_url
def test_split_url():
    url = 'http://www.ansible.com:8080/docs/guide/intro.html'
    assert split_url(url, 'scheme') == 'http'
    assert split_url(url, 'netloc') == 'www.ansible.com:8080'
    assert split_url(url, 'path') == '/docs/guide/intro.html'
    assert split_url(url, 'path') == '/docs/guide/intro.html'
    assert split_url(url, 'query') == ''
    assert split_url(url, 'fragment') == ''

# Generated at 2022-06-11 14:09:56.145808
# Unit test for function split_url
def test_split_url():
    urldata = helpers.object_to_dict(urlsplit('http://foo:bar@example.com:8080/?test=1#foo'))
    assert urldata == {
        'scheme': 'http',
        'netloc': 'foo:bar@example.com:8080',
        'path': '/?test=1',
        'query': 'test=1',
        'fragment': 'foo',
    }

    assert split_url(value='http://foo:bar@example.com:8080/?test=1#foo', query='netloc') == 'foo:bar@example.com:8080'

    assert split_url(value='http://foo:bar@example.com:8080/?test=1#foo', query='') == urldata


# Generated at 2022-06-11 14:09:57.439198
# Unit test for function split_url
def test_split_url():
    import doctest

    doctest.testmod(split_url)

# Generated at 2022-06-11 14:10:06.754040
# Unit test for function split_url
def test_split_url():
    import pytest

    with pytest.raises(AnsibleFilterError) as excinfo:
        split_url('http://localhost:8080', 'foo')

    with pytest.raises(AnsibleFilterError) as excinfo:
        split_url('http://localhost:8080')

    # scheme, netloc, path, params, query, fragment

    assert split_url('http://ansible.com', 'scheme') == 'http'
    assert split_url('https://ansible.com', 'scheme') == 'https'

    assert split_url('http://ansible.com', 'netloc') == 'ansible.com'