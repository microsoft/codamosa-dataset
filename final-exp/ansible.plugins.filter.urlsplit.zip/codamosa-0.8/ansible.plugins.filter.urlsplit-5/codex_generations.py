

# Generated at 2022-06-11 14:08:56.034928
# Unit test for function split_url
def test_split_url():
    test_uri = 'http://user:password@example.com:80/path/filename.ext?a=1&b=2#fragment'
    expected = {u'fragment': u'fragment', u'netloc': u'user:password@example.com:80', u'query': u'a=1&b=2', u'scheme': u'http', u'path': u'/path/filename.ext', u'username': u'user', u'password': u'password', u'hostname': u'example.com', u'port': u'80'}
    actual = split_url(test_uri)
    assert expected == actual


# Generated at 2022-06-11 14:09:00.952720
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.ansible.com/') == {
        'scheme': 'https',
        'netloc': 'www.ansible.com',
        'path': '',
        'query': '',
        'fragment': ''
    }

    assert split_url('https://www.ansible.com/', 'scheme') == 'https'

# Generated at 2022-06-11 14:09:08.509324
# Unit test for function split_url
def test_split_url():
    assert split_url('https://ansible.com/', 'scheme') == 'https'
    assert split_url('https://ansible.com/', 'netloc') == 'ansible.com'
    assert split_url('https://ansible.com/', 'path') == '/'
    assert split_url('https://ansible.com/', 'query') == ''
    assert split_url('https://ansible.com/', 'fragment') == ''

    assert split_url('https://ansible.com/', alias='urlsplit') == {
        'scheme': 'https',
        'netloc': 'ansible.com',
        'path': '/',
        'params': '',
        'query': '',
        'fragment': '',
    }


# Generated at 2022-06-11 14:09:13.784568
# Unit test for function split_url
def test_split_url():
    from ansible.utils.urls import urlsplit as ansi_urlsplit
    from ansible.utils.urls import urlunparse as ansi_urlunparse
    from ansible.utils.urls import urlparse as ansi_urlparse
    from ansible.utils.urls import urlunsplit as ansi_urlunsplit
    import urlparse

    def _urlsplit(url, option=''):
        if option:
            return ansi_urlsplit(url)[option]
        else:
            return ansi_urlsplit(url)

    def _urlparse(url, option=''):
        if option:
            return ansi_urlparse(url)[option]
        else:
            return ansi_urlparse(url)

    def _urlunparse(parts):
        return ansi_urlunparse

# Generated at 2022-06-11 14:09:25.537081
# Unit test for function split_url
def test_split_url():
    url = 'https://docs.ansible.com/ansible/latest/modules/uri_module.html'
    query = 'fragment'
    result = split_url(url, query=query, alias='urlsplit')
    assert result == 'latest/modules/uri_module.html'

    url = 'https://docs.ansible.com/ansible/latest/modules/uri_module.html'
    query = 'path'
    result = split_url(url, query=query, alias='urlsplit')
    assert result == '/ansible/latest/modules/uri_module.html'

    url = 'https://docs.ansible.com/ansible/latest/modules/uri_module.html'
    result = split_url(url, alias='urlsplit')
    assert type(result) == dict

# Generated at 2022-06-11 14:09:34.018452
# Unit test for function split_url
def test_split_url():

    url = 'http://google.com:80/search?q=python'
    url_invalid = 'hello world'

    # Test url without query
    url_dic = split_url(url, '')
    assert url_dic['scheme'] == 'http'
    assert url_dic['netloc'] == 'google.com:80'
    assert url_dic['path'] == '/search'
    assert url_dic['params'] == ''
    assert url_dic['query'] == 'q=python'
    assert url_dic['fragment'] == ''

    # Test url with query
    scheme = split_url(url, 'scheme')
    netloc = split_url(url, 'netloc')
    path = split_url(url, 'path')

# Generated at 2022-06-11 14:09:42.380764
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com:80/') == {
        'scheme': 'http',
        'fragment': '',
        'hostname': 'www.example.com',
        'netloc': 'www.example.com:80',
        'password': '',
        'path': '/',
        'query': '',
        'username': '',
        'port': '80'
    }

    assert split_url('http://www.example.com:80/', query='scheme') == 'http'

# Generated at 2022-06-11 14:09:53.153654
# Unit test for function split_url
def test_split_url():
    ''' Test function split_url '''
    expected_result = {'scheme': 'http', 'netloc': 'www.google.com', 'path': '/', 'query': '', 'fragment': ''}
    result = split_url('http://www.google.com')
    assert expected_result == result
    result = split_url('http://www.google.com/')
    assert expected_result == result
    result = split_url('http://www.google.com/?foo=bar')
    expected_result = {'scheme': 'http', 'netloc': 'www.google.com', 'path': '/', 'query': 'foo=bar', 'fragment': ''}
    assert expected_result == result
    expected_result = 'http'

# Generated at 2022-06-11 14:10:03.664629
# Unit test for function split_url
def test_split_url():
    assert split_url('http://user:pass@www.acme.com:8080/path/to/file?foo=bar#anchor', 'scheme') == 'http'
    assert split_url('http://user:pass@www.acme.com:8080/path/to/file?foo=bar#anchor', 'netloc') == 'user:pass@www.acme.com:8080'
    assert split_url('http://user:pass@www.acme.com:8080/path/to/file?foo=bar#anchor', 'path') == '/path/to/file'
    assert split_url('http://user:pass@www.acme.com:8080/path/to/file?foo=bar#anchor', 'query') == 'foo=bar'

# Generated at 2022-06-11 14:10:12.846966
# Unit test for function split_url
def test_split_url():

    tests = [
        'https://www.debian.org/doc/manuals/debian-faq/ch-ftparchives.en.html',
        'http://192.168.14.1/cgi-bin/luci',
        'http://www.example.com/'
    ]
