

# Generated at 2022-06-11 14:08:47.718189
# Unit test for function split_url
def test_split_url():
    results = split_url('https://user:pass@host.com:1234/path?query#fragment', query='scheme')
    assert results == 'https'


# Generated at 2022-06-11 14:08:58.724859
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils import basic

    results = split_url('http://ansible.com:80/docs/?p=1', 'netloc')
    assert results == 'ansible.com:80', results

    results = split_url('http://ansible.com:80/docs/?p=1')
    assert isinstance(results, dict)
    assert results['netloc'] == 'ansible.com:80', results

    args = {'query': 'netloc', 'value': 'http://ansible.com:80/docs/?p=1'}
    results = split_url(**args)
    assert results == 'ansible.com:80', results

    args = {'query': 'netloc', 'value': 'http://ansible.com:80/docs/?p=1', 'alias': '_test'}


# Generated at 2022-06-11 14:09:04.938759
# Unit test for function split_url
def test_split_url():
    assert {"scheme": "https", "netloc": "www.ansible.com"} == split_url("https://www.ansible.com")
    assert "https" == split_url("https://www.ansible.com", query='scheme')

    with pytest.raises(AnsibleFilterError) as e:
        split_url("https://www.ansible.com", query='not_a_valid_url_component')
    assert "unknown URL component: not_a_valid_url_component" in str(e.value)

# Generated at 2022-06-11 14:09:12.526197
# Unit test for function split_url
def test_split_url():
  formatted_output = {'scheme': 'https', 'netloc': 'www.cisco.com', 'path': '/base/','query':'', 'fragment': ''}
  assert split_url('https://www.cisco.com/base/') == formatted_output
  formatted_output = {'scheme': 'https', 'netloc': 'www.cisco.com', 'path': '/', 'query':'', 'fragment': ''}
  assert split_url('https://www.cisco.com/') == formatted_output


# Generated at 2022-06-11 14:09:23.452914
# Unit test for function split_url
def test_split_url():
    import io
    import sys
    from unittest import TestCase
    from ansible.errors import AnsibleFilterError


# Generated at 2022-06-11 14:09:32.564796
# Unit test for function split_url
def test_split_url():
    assert split_url('http://username:password@example.com:80/path?query=value', 'netloc') == 'username:password@example.com:80'
    assert split_url('http://username:password@example.com:80/path?query=value', 'query') == 'query=value'
    assert split_url('http://username:password@example.com:80/path?query=value', 'path') == '/path'
    assert split_url('http://username:password@example.com:80/path?query=value') == {'scheme': 'http', 'hostname': 'example.com', 'netloc': 'username:password@example.com:80', 'path': '/path', 'username': 'username', 'password': 'password', 'port': 80, 'query': 'query=value'}

# Generated at 2022-06-11 14:09:40.523702
# Unit test for function split_url
def test_split_url():
    split_url('http://ansible.com/path?var=5#fragment') == \
    {'fragment': 'fragment', 'netloc': 'ansible.com', 'path': '/path', 'scheme': 'http', 'query': 'var=5'}
    split_url('http://ansible.com/path?var=5#fragment', 'scheme') == 'http'
    split_url('http://ansible.com/path?var=5#fragment', 'query') == 'var=5'

# Generated at 2022-06-11 14:09:48.497385
# Unit test for function split_url
def test_split_url():
    # https://docs.python.org/library/urlparse.html
    assert split_url('http://www.cwi.nl:80/%7Eguido/Python.html') == {
        'scheme': 'http',
        'netloc': 'www.cwi.nl:80',
        'path': '/%7Eguido/Python.html',
        'params': '',
        'query': '',
        'fragment': ''
    }

    # https://docs.python.org/library/urlparse.html
    assert split_url('http://www.cwi.nl:80/%7Eguido/Python.html', query='netloc') == 'www.cwi.nl:80'

    # https://en.wikipedia.org/wiki/URI_scheme#Examples

# Generated at 2022-06-11 14:09:56.927930
# Unit test for function split_url
def test_split_url():

    # Simple query component test
    assert split_url('http://example.org:3000/path/to/file?key=value', 'netloc') == 'example.org:3000'
    # Simple filename test
    assert split_url('/path/to/file.txt', 'filename') == 'file.txt'
    # No query component test
    assert split_url('http://user@example.org:8080/path/to/file', 'username') == 'user'
    # Complete dictionary

# Generated at 2022-06-11 14:10:04.749566
# Unit test for function split_url
def test_split_url():
    # Test both the query and no query options.
    try:
        assert split_url('https://www.redhat.com/en/technologies/linux-platforms/openshift/what-is-openshift', 'scheme') == 'https'
        assert split_url('https://www.redhat.com/en/technologies/linux-platforms/openshift/what-is-openshift')['netloc'] == 'www.redhat.com'
    except AssertionError:
        print('Test failed.')
    else:
        print('Test passed.')