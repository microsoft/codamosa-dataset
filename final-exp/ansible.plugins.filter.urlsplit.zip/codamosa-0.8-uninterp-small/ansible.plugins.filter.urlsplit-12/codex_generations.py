

# Generated at 2022-06-25 09:30:23.923819
# Unit test for function split_url
def test_split_url():
    ''' Test split_url '''
    from ansible.module_utils.six.moves.urllib.parse import urlsplit

    url = 'http://portal-auth.cluster/v2.0'
    parsed = urlsplit(url)

    # Test by comparing output to a dict representing the results
    expected = {
        'scheme': 'http',
        'netloc': 'portal-auth.cluster',
        'path': '/v2.0',
        'query': '',
        'fragment': ''
    }

    # Iterate over the results and compare them to what we expect
    # If they match, this is as expected
    for key, value in expected.items():
        assert split_url(url, key) == value

# Generated at 2022-06-25 09:30:28.648691
# Unit test for function split_url
def test_split_url():
    # Split an input URI into the components defined by RFC 3986.
    this_url = "http://username:password@example.com:8000/path/to/file?arg=value#anchor"
    split_url(this_url, alias='urlsplit')
    # Verify that a malformed URI generates an exception.
    this_url = "http://malformed#uri"
    try:
        split_url(this_url, alias='urlsplit')
    except AnsibleFilterError:
        pass


# Generated at 2022-06-25 09:30:36.528425
# Unit test for function split_url
def test_split_url():
    assert  split_url("http://www.cwi.nl:80/%7Eguido/Python.html") == {'netloc': 'www.cwi.nl:80', 'scheme': 'http', 'path': '%7Eguido/Python.html', 'fragment': '', 'query': ''}, \
        "FilterModule fail: function 'split_url'"
    assert  split_url("http://www.cwi.nl:80/%7Eguido/Python.html", "scheme") == 'http', \
        "FilterModule fail: function 'split_url'"

# Generated at 2022-06-25 09:30:44.504312
# Unit test for function split_url
def test_split_url():
    """Test split_url"""
    import sys
    if sys.version_info >= (3,):
        # Update comparison values
        # `netloc`
        test_cases["test_case_0"]["args"][1]["query"] = '<class \'str\'>'
        # `scheme`
        test_cases["test_case_1"]["args"][1]["query"] = '<class \'str\'>'
        # `fragment`
        test_cases["test_case_3"]["args"][1]["query"] = '<class \'str\'>'
        # `query`
        test_cases["test_case_4"]["args"][1]["query"] = '<class \'str\'>'

    test_case = test_cases["test_case_0"]


# Generated at 2022-06-25 09:30:50.869636
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.example.com/foo/bar', None) == {
        'fragment': '',
        'hostname': 'www.example.com',
        'netloc': 'www.example.com',
        'path': '/foo/bar',
        'port': None,
        'scheme': 'https',
        'username': None,
        'password': None,
        'query': None
    }
    assert split_url('https://www.example.com/foo/bar', 'netloc') == 'www.example.com'
    assert split_url('https://www.example.com/foo/bar', 'password') is None
    assert split_url('https://www.example.com/foo/bar', 'bad') == AnsibleFilterError()

##
# Main testing
##


# Generated at 2022-06-25 09:31:01.650339
# Unit test for function split_url
def test_split_url():
    print("\n\nUNIT TEST:  filter_plugins.urlsplit.split_url")
    print("===============================================\n")

    # Test Case 0
    # Test for failure when an invalid query is supplied
    res = split_url("https://www.ansible.com", query='bad', alias='urlsplit')
    assert res == "urlsplit: unknown URL component: bad"

    # Test Case 1
    # Test for valid query and results
    res = split_url("git@github.com:ansible/ansible.git", query='scheme', alias='test')
    assert res == ''

    # Test Case 2
    # Test for valid URL and results
    res = split_url("https://www.ansible.com", query='', alias='test')
    assert res['fragment'] == ''

# Generated at 2022-06-25 09:31:08.555864
# Unit test for function split_url
def test_split_url():
    import os
    from ansible.utils.path import unfrackpath
    from ansible.release import __version__
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    import json


# Generated at 2022-06-25 09:31:17.584662
# Unit test for function split_url
def test_split_url():
    result = split_url(value='http://localhost:5984/db/doc?attachments=true')
    assert result['scheme'] == 'http'
    assert result['netloc'] == 'localhost:5984'
    assert result['path'] == '/db/doc'
    assert result['query'] == 'attachments=true'
    result = split_url(value='http://localhost:5984/db/doc?attachments=true', query='port')
    assert result == 5984
    result = split_url(value='http://localhost:5984/db/doc?attachments=true', query='path')
    assert result == '/db/doc'

# Generated at 2022-06-25 09:31:24.838031
# Unit test for function split_url
def test_split_url():
    url = split_url('http://www.example.com:8042/over/there?name=ferret#nose')
    assert url['scheme'] == 'http'
    assert url['netloc'] == 'www.example.com:8042'
    assert url['path'] == '/over/there'
    assert url['query'] == 'name=ferret'
    assert url['fragment'] == 'nose'

# Generated at 2022-06-25 09:31:30.111065
# Unit test for function split_url
def test_split_url():
    url = 'http://www.example.com/path/to/index.html?a=1&b=2&c=3'