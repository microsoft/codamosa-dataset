

# Generated at 2022-06-25 09:30:17.169025
# Unit test for function split_url
def test_split_url():
    o = urlsplit('http://user:pass@example.com:8080/path/to/file.html?key=value&key2=value2#fragment')
    d = {'scheme': 'http', 'netloc': 'user:pass@example.com:8080', 'path': '/path/to/file.html', 'query': 'key=value&key2=value2', 'fragment': 'fragment'}
    assert split_url('http://user:pass@example.com:8080/path/to/file.html?key=value&key2=value2#fragment') == d

# Generated at 2022-06-25 09:30:20.221744
# Unit test for function split_url
def test_split_url():
    assert split_url('http://user@www.example.com:80/foo/bar.html;param?a=1&b=2#frag') == \
           {'path': '/foo/bar.html;param', 'netloc': 'user@www.example.com:80', 'query': 'a=1&b=2',
            'scheme': 'http', 'fragment': 'frag'}


# Generated at 2022-06-25 09:30:29.472870
# Unit test for function split_url
def test_split_url():
    assert split_url(value='https://www.google.com:80/search?foo=bar&baz=qux', query='netloc') == 'www.google.com:80'
    assert split_url(value='https://www.google.com:80/search?foo=bar&baz=qux', query='scheme') == 'https'
    assert split_url(value='https://www.google.com:80/search?foo=bar&baz=qux', query='path') == '/search'
    assert split_url(value='https://www.google.com:80/search?foo=bar&baz=qux', query='query') == 'foo=bar&baz=qux'

# Generated at 2022-06-25 09:30:37.721786
# Unit test for function split_url
def test_split_url():
    uri = "http://admin:password@my.example.com:8042/one/two?alpha=beta#chapter1"
    test_values = {
        'scheme': 'http',
        'netloc': 'admin:password@my.example.com:8042',
        'path': '/one/two',
        'query': 'alpha=beta',
        'fragment': 'chapter1',
        'username': 'admin',
        'password': 'password',
        'hostname': 'my.example.com',
        'port': '8042',
    }

    for key, value in test_values.items():
        assert split_url(uri, key) == value



# Generated at 2022-06-25 09:30:39.860433
# Unit test for function split_url
def test_split_url():
    assert split_url("http://www.cwi.nl:80/%7Eguido/Python.html") == '80'

if __name__ == '__main__':
    test_split_url()

# Generated at 2022-06-25 09:30:48.869729
# Unit test for function split_url
def test_split_url():
    url = 'http://localhost:8080/v1/shares'

    assert split_url(url)['scheme'] == 'http'
    assert split_url(url)['netloc'] == 'localhost:8080'
    assert split_url(url, 'path') == '/v1/shares'
    assert '8080' in split_url(url, 'port')
    assert 'None' in split_url(url, 'fragment')
    assert 'None' in split_url(url, 'username')
    assert 'None' in split_url(url, 'password')

    assert split_url('http://www.example.com/', 'netloc') == 'www.example.com'
    assert split_url('http://[]', 'netloc') == '[]:None'

# Generated at 2022-06-25 09:30:50.093489
# Unit test for function split_url
def test_split_url():
    filter_module_split_url_0 = split_url(value="http://www.yahoo.com", query="query")
    assert(filter_module_split_url_0 == '')

# Generated at 2022-06-25 09:30:55.136839
# Unit test for function split_url
def test_split_url():
    assert split_url("http://docs.ansible.com/ansible/latest/index.html", "scheme") == 'http'
    assert split_url("http://docs.ansible.com/ansible/latest/index.html", "netloc") == 'docs.ansible.com'
    assert split_url("http://docs.ansible.com/ansible/latest/index.html", "path") == '/ansible/latest/index.html'
    assert split_url("http://docs.ansible.com/ansible/latest/index.html", "query") == ''
    assert split_url("http://docs.ansible.com/ansible/latest/index.html", "fragment") == ''
    assert split_url("http://docs.ansible.com/ansible/latest/index.html", "username")

# Generated at 2022-06-25 09:31:06.162956
# Unit test for function split_url
def test_split_url():

    # Test with a fully populated URL
    test_url = 'https://www.example.com:8008/path1/path2?query1=arg1&query2=arg2'

    # Test with a query parameter
    split_url_netloc = split_url(test_url, query='netloc')
    assert split_url_netloc == 'www.example.com:8008'

    split_url_scheme = split_url(test_url, query='scheme')
    assert split_url_scheme == 'https'

    split_url_path = split_url(test_url, query='path')
    assert split_url_path == '/path1/path2'

    split_url_query = split_url(test_url, query='query')

# Generated at 2022-06-25 09:31:17.035843
# Unit test for function split_url
def test_split_url():

    assert split_url('https://www.ansible.com/a/b/c', query='urlsplit') ==  {'username': '', 'path': 'a/b/c', 'hostname': 'www.ansible.com', 'params': '', 'scheme': 'https', 'netloc': 'www.ansible.com', 'password': '', 'fragment': '', 'query': ''}
    assert split_url('https://www.ansible.com/a/b/c') ==  {'username': '', 'path': 'a/b/c', 'hostname': 'www.ansible.com', 'params': '', 'scheme': 'https', 'netloc': 'www.ansible.com', 'password': '', 'fragment': '', 'query': ''}