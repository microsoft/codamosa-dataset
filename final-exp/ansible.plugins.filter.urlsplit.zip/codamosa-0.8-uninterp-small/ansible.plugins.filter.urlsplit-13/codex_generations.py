

# Generated at 2022-06-25 09:30:20.081120
# Unit test for function split_url
def test_split_url():
    assert split_url('https://en.wikipedia.org/wiki/Main_Page', 'scheme') == 'https'
    assert split_url('https://en.wikipedia.org/wiki/Main_Page', 'netloc') == 'en.wikipedia.org'
    assert split_url('https://en.wikipedia.org/wiki/Main_Page', 'path') == '/wiki/Main_Page'
    assert split_url('https://en.wikipedia.org/wiki/Main_Page', 'query') == ''
    assert split_url('https://en.wikipedia.org/wiki/Main_Page', 'fragment') == ''

# Generated at 2022-06-25 09:30:28.827486
# Unit test for function split_url
def test_split_url():
    url = 'https://docs.ansible.com/ansible/latest/user_guide/playbooks_loops.html'
    query = 'scheme'
    alias = 'urlsplit'
    result = split_url(url, query, alias)
    assert result == 'https'
    query = 'path'
    result = split_url(url, query, alias)
    assert result == '/ansible/latest/user_guide/playbooks_loops.html'
    query = 'query'
    result = split_url(url, query, alias)
    assert result == ''
    query = 'netloc'
    result = split_url(url, query, alias)
    assert result == 'docs.ansible.com'

# Generated at 2022-06-25 09:30:38.743926
# Unit test for function split_url
def test_split_url():
    # Test url without query parameters
    url = "http://localhost:5984/database"
    assert split_url(url, "scheme") == 'http'
    assert split_url(url, "netloc") == 'localhost:5984'
    assert split_url(url, "path") == '/database'
    assert split_url(url, "query") == ''
    assert split_url(url, "fragment") == ''
    assert split_url(url)["hostname"] == 'localhost'

    # Test url with query parameters
    url = "http://localhost:5984/database?param1=value1"
    assert split_url(url, "scheme") == 'http'
    assert split_url(url, "path") == '/database'

# Generated at 2022-06-25 09:30:47.429687
# Unit test for function split_url
def test_split_url():
    filter_module_0 = FilterModule()
    url_0 = 'https://www.ansible.com?a=1&b=2'
    url_1 = 'http://w.x.y.z:8080'
    url_2 = 'http://username:password@x.y.z/path;parameters?query=arguments#fragment'
    url_3 = 'ssh://user@host.xz'
    url_4 = '//username:password@x.y.z'
    url_5 = '//x.y.z'
    result = filter_module_0.filters()['urlsplit'](url_0)
    assert(result['scheme'] == 'https')
    assert(result['netloc'] == 'www.ansible.com')
    assert(result['path'] == '/')

# Generated at 2022-06-25 09:30:58.026872
# Unit test for function split_url
def test_split_url():
	assert split_url("http://foo.com/bar/baz") == {'query': '', 'fragment': '', 'scheme': 'http', 'netloc': 'foo.com', 'path': '/bar/baz'}
	assert split_url("http://foo.com/bar/baz?a=1&b=2", "query") == "a=1&b=2"
	assert split_url("http://foo.com/bar/baz#anchor") == {'query': '', 'fragment': 'anchor', 'scheme': 'http', 'netloc': 'foo.com', 'path': '/bar/baz'}
	assert split_url("http://foo.com/bar/baz#anchor", "fragment") == "anchor"

# Generated at 2022-06-25 09:31:07.179369
# Unit test for function split_url
def test_split_url():
    assert split_url(None, query=None, alias=None) == None
    assert split_url('', query='', alias='') == ''
    assert split_url('abc', query='abc', alias='abc') == None
    assert split_url('abc', query='abc', alias=None) == None
    assert split_url('abc', query=None, alias='abc') == None
    assert split_url('abc', query=None, alias=None) == None
    assert split_url('abc', query='abc', alias='abc') == None
    assert split_url('abc', query='abc', alias='abc') == None
    assert split_url('abc', query=None, alias='abc') == None
    assert split_url('abc', query=None, alias='abc') == None

# Generated at 2022-06-25 09:31:18.039796
# Unit test for function split_url
def test_split_url():
    assert split_url(value='http://www.baidu.com/index.php?id=1&name=abc', query='scheme') == 'http'
    assert split_url(value='http://www.baidu.com/index.php?id=1&name=abc', query='netloc') == 'www.baidu.com'
    assert split_url(value='http://www.baidu.com/index.php?id=1&name=abc', query='path') == '/index.php'
    assert split_url(value='http://www.baidu.com/index.php?id=1&name=abc', query='query') == 'id=1&name=abc'

# Generated at 2022-06-25 09:31:28.605800
# Unit test for function split_url
def test_split_url():
    # No query
    assert split_url('https://www.example.com/pipeline/1416/run?ref=master') == {
        'scheme': 'https',
        'netloc': 'www.example.com',
        'path': '/pipeline/1416/run', 'query': 'ref=master',
        'fragment': '',
        'username': '',
        'password': '',
        'hostname': 'www.example.com',
        'port': None
    }

    # Query url.scheme
    assert split_url('https://www.example.com/pipeline/1416/run?ref=master', query='scheme') == 'https'

    # Query url.netloc

# Generated at 2022-06-25 09:31:31.638873
# Unit test for function split_url
def test_split_url():
    url_components = split_url("http://www.example.com/path/to/file.html?key1=value1&key2=value2#InTheDocument", query="query")
    assert url_components == "key1=value1&key2=value2"

# Generated at 2022-06-25 09:31:35.464680
# Unit test for function split_url
def test_split_url():
    filter_module_0 = FilterModule()
    value = 'https://www.google.co.za/search?site=&source=hp&q=test'
    query = 'path'
    alias = 'urlsplit'
    result = filter_module_0.filters()['urlsplit'](value, query, alias)
    assert result == '/search'
