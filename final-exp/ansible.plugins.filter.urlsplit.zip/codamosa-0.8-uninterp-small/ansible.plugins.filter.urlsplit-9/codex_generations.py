

# Generated at 2022-06-25 09:30:18.916838
# Unit test for function split_url
def test_split_url():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['urlsplit']('http://docs.ansible.com/ansible/latest/intro_installation.html') == {'fragment': '', 'netloc': 'docs.ansible.com', 'params': '', 'query': '', 'path': '/ansible/latest/intro_installation.html', 'scheme': 'http'}
    assert filter_module_0.filters()['urlsplit']('http://docs.ansible.com/ansible/latest/intro_installation.html', query='path') == '/ansible/latest/intro_installation.html'

# Generated at 2022-06-25 09:30:24.224520
# Unit test for function split_url
def test_split_url():
    param_0 = "http://docs.ansible.com/ansible/2.5/dev_guide/developing_modules_general.html#simple-module-requirements"
    param_1 = "query"
    param_2 = "urlsplit"
    ret_val_0 = split_url(param_0, param_1, param_2)
    assert ret_val_0 == "", ret_val_0


# Generated at 2022-06-25 09:30:30.975238
# Unit test for function split_url
def test_split_url():
    "Test split_url function"

# Generated at 2022-06-25 09:30:33.768056
# Unit test for function split_url
def test_split_url():
    test_case = "https://10.240.122.111/v1/users"
    result = split_url(test_case, query='path')
    assert result == "/v1/users"

# Generated at 2022-06-25 09:30:43.168968
# Unit test for function split_url
def test_split_url():

    module_0 = split_url('https://blah.com:8080/robots.txt?foo=bar#fragment')
    assert module_0['scheme'] == 'https'
    assert module_0['netloc'] == 'blah.com:8080'
    assert module_0['path']   == '/robots.txt'
    assert module_0['query']  == 'foo=bar'
    assert module_0['fragment'] == 'fragment'

    module_1 = split_url('https://blah.com:8080/robots.txt?foo=bar#fragment', query='path')
    assert module_1 == '/robots.txt'


# Generated at 2022-06-25 09:30:45.726002
# Unit test for function split_url
def test_split_url():
    test_url = 'https://github.com/ansible/ansible/pull/30576#issuecomment-303446710'
    split_url(test_url, 'scheme', 'test_split_url')


# Generated at 2022-06-25 09:30:48.059320
# Unit test for function split_url
def test_split_url():
    url = 'https://www.ansible.com/products'
    expected = {'netloc': 'www.ansible.com', 'path': '/products', 'scheme': 'https'}
    assert(split_url(url, query='netloc') == expected['netloc'])
    assert(split_url(url) == expected)


# Generated at 2022-06-25 09:30:53.439422
# Unit test for function split_url
def test_split_url():
    """ Test case for split_url. """

    value = 'http://username:password@example.com:80/path/to/page.html?query=search#anchor'
    query = 'scheme'

    result_split_url = split_url(value, query)
    expected_result_split_url = 'http'
    assert result_split_url == expected_result_split_url

    value = 'http://username:password@example.com:80/path/to/page.html?query=search#anchor'
    query = 'username'

    result_split_url = split_url(value, query)
    expected_result_split_url = 'username'
    assert result_split_url == expected_result_split_url


# Generated at 2022-06-25 09:30:59.327111
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.example.com/search?q=jira+ansible+filter#top') == {
        'fragment': 'top',
        'netloc': 'www.example.com',
        'path': '/search',
        'query': 'q=jira+ansible+filter',
        'scheme': 'https'
    }


# Generated at 2022-06-25 09:31:06.547979
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.example.com/test', query='scheme') == 'https'
    assert split_url('https://www.example.com/test', query='netloc') == 'www.example.com'
    assert split_url('https://www.example.com/test', query='path') == '/test'
    assert split_url('https://www.example.com/test', query='query') == ''
    assert split_url('https://www.example.com/test', query='fragment') == ''

test_split_url()