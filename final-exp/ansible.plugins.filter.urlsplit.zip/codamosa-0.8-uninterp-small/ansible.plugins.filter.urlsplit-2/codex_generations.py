

# Generated at 2022-06-25 09:30:17.066012
# Unit test for function split_url
def test_split_url():
    actual = split_url('https://example.com/path/to/something/?foo=bar&baz=bing')
    expected = {'scheme': 'https', 'netloc': 'example.com', 'path': '/path/to/something/', 'query': 'foo=bar&baz=bing', 'fragment': ''}
    assert actual == expected


# Generated at 2022-06-25 09:30:23.141915
# Unit test for function split_url
def test_split_url():
    value = 'http://www.cwi.nl:80/%7Eguido/Python.html'
    query = 'port'
    alias = 'urlsplit'
    expected_result = 80
    actual_result = split_url(value, query, alias)
    assert actual_result == expected_result
    print('# Test 1 passed')


# Generated at 2022-06-25 09:30:30.261841
# Unit test for function split_url
def test_split_url():

    # NOTE - urlparse.urlsplit always returns a 5-tuple
    verify_urlsplit('scheme', 'http', '//www.example.com/path/?query=testvalue#fragment', 'https')
    verify_urlsplit('scheme', 'https', 'http://www.example.com/path/?query=testvalue#fragment', 'http')
    verify_urlsplit('scheme', 'ftp', 'ftp://www.example.com/path/?query=testvalue#fragment', 'http')
    verify_urlsplit('scheme', 'sftp', 'sftp://www.example.com/path/?query=testvalue#fragment', 'http')

# Generated at 2022-06-25 09:30:38.264821
# Unit test for function split_url
def test_split_url():
    filter_module_0 = FilterModule()
    assert split_url(filter_module_0, 'http://www.example.com/path?key=value', 'scheme') == 'http'
    assert split_url(filter_module_0, 'http://www.example.com/path?key=value', 'netloc') == 'www.example.com'
    assert split_url(filter_module_0, 'http://www.example.com/path?key=value', 'path') == '/path'
    assert split_url(filter_module_0, 'http://www.example.com/path?key=value', 'query') == 'key=value'
    assert split_url(filter_module_0, 'http://www.example.com/path?key=value', 'fragment') == ''

# Generated at 2022-06-25 09:30:40.923542
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.google.com/search?q=python+split+url', query='scheme') == 'https'

# Generated at 2022-06-25 09:30:43.440158
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.google.com/search?q=ansible+ansible&ie=utf-8&oe=utf-8', 'netloc') == 'www.google.com'

# Generated at 2022-06-25 09:30:48.577114
# Unit test for function split_url
def test_split_url():
    test_case_split_url_0()
    test_case_split_url_1()
    test_case_split_url_2()
    test_case_split_url_3()
    test_case_split_url_4()
    test_case_split_url_5()
    test_case_split_url_6()
    test_case_split_url_7()
    test_case_split_url_8()
    test_case_split_url_9()
    test_case_split_url_10()
    test_case_split_url_11()
    test_case_split_url_12()
    test_case_split_url_13()
    test_case_split_url_14()
    test_case_split_url_15()
    test_case_split_

# Generated at 2022-06-25 09:30:59.234960
# Unit test for function split_url
def test_split_url():
    assert split_url('http://foo.bar:8080/api/optional/path', query='netloc') == 'foo.bar:8080'
    assert split_url('http://foo.bar:8080/api/optional/path', query='scheme') == 'http'
    # assert split_url('http://foo.bar:8080/api/optional/path', query='path') == '/api/optional/path'
    assert split_url('http://foo.bar:8080/api/optional/path', query='params') == ''
    assert split_url('http://foo.bar:8080/api/optional/path', query='query') == ''
    assert split_url('http://foo.bar:8080/api/optional/path', query='fragment') == ''

# Generated at 2022-06-25 09:31:08.019133
# Unit test for function split_url

# Generated at 2022-06-25 09:31:13.431915
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.google.com', 'scheme') == 'http'

if __name__ == '__main__':
    test_case_0()
    test_split_url()