

# Generated at 2022-06-25 09:30:16.513750
# Unit test for function split_url
def test_split_url():
    # Test Case 0
    # Test Case 0
    if 'url' in FilterModule().filters():
        # split_url exists
        assert True
    else:
        # split_url does not exist
        assert False

# Generated at 2022-06-25 09:30:24.900595
# Unit test for function split_url
def test_split_url():
    value = 'http://user:pass@www.example.com:80/path;param?query=arg#frag'

    assert(split_url(value) == {'scheme': 'http', 'netloc': 'user:pass@www.example.com:80',
                                'path': '/path;param', 'query': 'query=arg', 'fragment': 'frag'})

    assert(split_url(value, 'scheme') == 'http')

    assert(split_url(value, 'unknown') == None)

# Generated at 2022-06-25 09:30:31.320356
# Unit test for function split_url
def test_split_url():
    assert split_url("http://www.cwi.nl:80/%7Eguido/Python.html") == {'netloc': 'www.cwi.nl:80', 'path': '/%7Eguido/Python.html', 'scheme': 'http', 'params': '', 'fragment': '', 'query': ''}
    assert split_url("http://www.cwi.nl:80/%7Eguido/Python.html", "netloc") == "www.cwi.nl:80"
    assert split_url("http://www.cwi.nl:80/%7Eguido/Python.html", "not_available") == AnsibleFilterError(alias + ": unknown URL component: not_available")

# Generated at 2022-06-25 09:30:40.925454
# Unit test for function split_url
def test_split_url():
    assert(split_url('scheme://netloc/path;parameters?query=argument#fragment', 'scheme') == 'scheme')
    assert(split_url('scheme://netloc/path;parameters?query=argument#fragment', 'netloc') == 'netloc')
    assert(split_url('scheme://netloc/path;parameters?query=argument#fragment', 'path') == 'path;parameters')
    assert(split_url('scheme://netloc/path;parameters?query=argument#fragment', 'parameters') == 'path;parameters')
    assert(split_url('scheme://netloc/path;parameters?query=argument#fragment', 'query') == 'query=argument')

# Generated at 2022-06-25 09:30:44.685663
# Unit test for function split_url
def test_split_url():
    value = "http://user:pass@Host:9000/p/a/t/h?query=arg#frag"
    output = split_url(value)
    expected_output = {'scheme': 'http', 'netloc': 'user:pass@Host:9000', 'path': '/p/a/t/h', 'query': 'query=arg', 'fragment': 'frag'}
    assert output == expected_output, 'Expected ' + str(expected_output) + ' but got ' + str(output)
    value = "sftp://user:pass@Host:9000/p/a/t/h?query=arg#frag"
    output = split_url(value)

# Generated at 2022-06-25 09:30:49.851445
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.ansible.com/') == {'scheme': 'https', 'hostname': 'www.ansible.com', 'path': '', 'query': '', 'port': None, 'fragment': '', 'username': None, 'password': None}
    assert split_url('https://www.ansible.com/', 'hostname') == 'www.ansible.com'
    assert split_url('https://www.ansible.com/?sort=artifact_id&order=asc') == {'scheme': 'https', 'hostname': 'www.ansible.com', 'path': '', 'query': 'sort=artifact_id&order=asc', 'port': None, 'fragment': '', 'username': None, 'password': None}

# Generated at 2022-06-25 09:30:56.277513
# Unit test for function split_url
def test_split_url():
    url = "https://github.com/ansible/ansible-modules-network/tree/devel/network/f5/f5_device_dns.py"
    # results = filter_module_0.filters()["split_url"](url)
    results = FilterModule.filters(FilterModule())["urlsplit"](url)

    # print("results = ", results)
    # print("results.keys() = ", results.keys())


if __name__ == '__main__':
    test_case_0()
    test_split_url()

# Generated at 2022-06-25 09:31:03.127202
# Unit test for function split_url
def test_split_url():
    assert split_url('https://user:password@example.com:443/path/to/resource?key1=value1&key2=value2#anchor') ==  {'scheme': 'https', 'netloc': 'user:password@example.com:443', 'path': '/path/to/resource', 'query': 'key1=value1&key2=value2', 'fragment': 'anchor'}

# Generated at 2022-06-25 09:31:13.048923
# Unit test for function split_url
def test_split_url():
    assert split_url('https://192.168.0.1:8080/?foo=bar', 'scheme') == 'https'
    assert split_url('http://192.168.0.1:8080/?foo=bar', 'scheme') == 'http'
    assert split_url('http://192.168.0.1/foo/bar', 'path') == '/foo/bar'
    assert split_url('http://192.168.0.1/foo/bar', 'netloc') == '192.168.0.1'
    assert split_url('http://192.168.0.1/foo/bar', 'query') == ''
    assert split_url('http://192.168.0.1/foo/bar?answer=42', 'query') == 'answer=42'

# Generated at 2022-06-25 09:31:23.549485
# Unit test for function split_url
def test_split_url():

    assert split_url(None) == {}

    assert split_url('') == {}

    assert split_url('', '') == {}
    assert split_url('', 'scheme') == {}
    assert split_url('', 'netloc') == {}
    assert split_url('', 'path') == {}
    assert split_url('', 'query') == {}
    assert split_url('', 'fragment') == {}

    assert split_url('http://www.example.com/path/to/file') == {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/file', 'query': '', 'fragment': ''}
