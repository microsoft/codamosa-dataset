

# Generated at 2022-06-25 09:30:21.434185
# Unit test for function split_url
def test_split_url():
    assert split_url(value='http://www.example.com') == {'hostname': 'www.example.com', 'scheme': 'http', 'path': '', 'netloc': 'www.example.com', 'query': '', 'port': None, 'fragment': '', 'username': None, 'password': None}
    assert split_url(value='http://www.example.com', query='scheme') == 'http'
    assert split_url(value='http://www.example.com', query='netloc') == 'www.example.com'

# Generated at 2022-06-25 09:30:26.891683
# Unit test for function split_url
def test_split_url():
    assert split_url(value='https:/docs.python.org/3/library/urllib.parse.html', query='scheme') == 'https'

# Generated at 2022-06-25 09:30:30.963243
# Unit test for function split_url
def test_split_url():
    assert split_url('ansible.com') == {'fragment': '', 'netloc': '', 'path': 'ansible.com', 'query': '', 'scheme': ''}

# Test 1:
url1 = 'https://google.com/test'
url1split = split_url(url1)

assert url1split['path'] == '/test'
assert url1split['netloc'] == 'google.com'

# Test 2:
url2 = 'ansible.com'
url2split = split_url(url2)

assert url2split['netloc'] == ''
assert url2split['scheme'] == ''
assert url2split['path'] == 'ansible.com'

# Test 3:
url3 = 'ansible.com?key=value#fragment'
url3split

# Generated at 2022-06-25 09:30:40.640814
# Unit test for function split_url
def test_split_url():
    filter_module_0 = FilterModule()
    # (Value, Query or None, Alias, Expected output)

# Generated at 2022-06-25 09:30:44.376982
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.github.com/ansible/ansible/tree/devel/plugins') == {'query': '', 'fragment': '', 'scheme': 'https', 'netloc': 'www.github.com', 'path': '/ansible/ansible/tree/devel/plugins'}


# Generated at 2022-06-25 09:30:47.294487
# Unit test for function split_url
def test_split_url():
    assert split_url("http://www.example.com/path") == {'query': '', 'fragment': '', 'netloc': 'www.example.com', 'path': '/path', 'scheme': 'http'}
    assert split_url("http://www.example.com/path", query='scheme') == "http"

# Generated at 2022-06-25 09:30:54.854087
# Unit test for function split_url
def test_split_url():
    test_url = 'https://guest:guest@localhost:5671/vhost?query=test'
    test_url_dict = {'scheme': 'https', 'netloc': 'guest:guest@localhost:5671',
                     'path': '/vhost', 'params': '', 'query': 'query=test', 'fragment': ''}
    assert split_url(test_url) == test_url_dict


# Generated at 2022-06-25 09:31:02.562868
# Unit test for function split_url
def test_split_url():
    test_filter_url_0 = split_url(u'https://www.example.com/path/to/file?query=string#fragment')
    assert test_filter_url_0 == {'fragment': 'fragment', 'hostname': 'www.example.com', 'netloc': 'www.example.com', 'password': '', 'path': '/path/to/file', 'port': None, 'query': 'query=string', 'scheme': 'https', 'username': ''}


# Generated at 2022-06-25 09:31:09.104031
# Unit test for function split_url
def test_split_url():
    url = 'http://www.example.com/path/to/file.html'
    assert split_url(url, 'scheme') == 'http'
    assert split_url(url, 'netloc') == 'www.example.com'
    assert split_url(url, 'path') == '/path/to/file.html'
    assert split_url(url) == {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/file.html'}
    assert split_url(url, query='scheme') == 'http'
    assert split_url(url, query='netloc') == 'www.example.com'
    assert split_url(url, query='path') == '/path/to/file.html'

# Generated at 2022-06-25 09:31:14.383141
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#Fragment') == {'fragment': 'Fragment', 'netloc': 'www.example.com', 'scheme': 'http', 'path': '/path/to/file.html', 'query': 'key1=value1&key2=value2'}
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#Fragment', query='scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#Fragment', query='fragment') == 'Fragment'