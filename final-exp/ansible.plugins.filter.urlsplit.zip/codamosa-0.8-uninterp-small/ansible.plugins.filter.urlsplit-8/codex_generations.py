

# Generated at 2022-06-25 09:30:15.686863
# Unit test for function split_url
def test_split_url():
    assert split_url("http://www.yelp.com/biz/red-robin-gourmet-burgers-and-brews-covina-2") == 'www.yelp.com'

# Generated at 2022-06-25 09:30:26.454130
# Unit test for function split_url
def test_split_url():
    assert split_url("scheme://netloc/path;parameters?query=argument#fragment", "scheme") == "scheme"
    assert split_url("scheme://netloc/path;parameters?query=argument#fragment", "netloc") == "netloc"
    assert split_url("scheme://netloc/path;parameters?query=argument#fragment", "path") == "/path"
    assert split_url("scheme://netloc/path;parameters?query=argument#fragment", "parameters") == "parameters"
    assert split_url("scheme://netloc/path;parameters?query=argument#fragment", "query") == "query=argument"

# Generated at 2022-06-25 09:30:37.343130
# Unit test for function split_url
def test_split_url():
    filter_module = FilterModule()
    assert filter_module.split_url('http://www.example.com/net/index.php?name=foo&id=bar') is not None
    assert filter_module.split_url('https://www.example.com/net/index.php?name=foo&id=bar') is not None
    assert filter_module.split_url('http://www.example.com/net/index.php?name=foo&id=bar', query='scheme') == 'http'
    assert filter_module.split_url('http://www.example.com/net/index.php?name=foo&id=bar', query='netloc') == 'www.example.com'

# Generated at 2022-06-25 09:30:40.271238
# Unit test for function split_url
def test_split_url():
    url = "http://www.cwi.nl:80/%7Eguido/Python.html"
    result = split_url(url)
    print("result = ",result)

# Generated at 2022-06-25 09:30:46.172963
# Unit test for function split_url
def test_split_url():
    url_0 = 'http://www.example.net/path/to/file/etc'
    query_0 = 'scheme'
    alias_0 = 'urlsplit'
    split_url(url_0, query_0, alias_0)

# Generated at 2022-06-25 09:30:57.933092
# Unit test for function split_url

# Generated at 2022-06-25 09:31:04.562130
# Unit test for function split_url
def test_split_url():
    import yaml

    results = split_url('http://www.example.com/path/file.html')
    assert results['scheme'] == 'http'
    assert results['netloc'] == 'www.example.com'
    assert results['path'] == '/path/file.html'
    assert results['query'] is None
    assert results['fragment'] is None


# Generated at 2022-06-25 09:31:06.999245
# Unit test for function split_url
def test_split_url():
    result_0 = split_url('https://www.cloudbees.com/blog/why-sherlock-holmes-ansible?ref=twitter')
    assert result_0 == 'whats_in_url.py'


# Generated at 2022-06-25 09:31:13.509429
# Unit test for function split_url
def test_split_url():
    assert split_url("https://github.com/ansible/ansible") == {
        'scheme': 'https',
        'netloc': 'github.com',
        'path': '/ansible/ansible',
        'fragment': '',
        'query': ''
    }



# Generated at 2022-06-25 09:31:24.228270
# Unit test for function split_url
def test_split_url():
    url = 'https://user:pass@ansible.com/projects/ansible/issues/2313#issuecomment-264910044'
    expected = {
        'fragment': 'issuecomment-264910044',
        'hostname': 'ansible.com',
        'netloc': 'user:pass@ansible.com',
        'params': '',
        'path': '/projects/ansible/issues/2313',
        'query': '',
        'scheme': 'https',
        'username': 'user',
        'password': 'pass',
    }

    assert split_url(url) == expected
    assert split_url(url, 'query') == ''
    assert split_url(url, 'hostname') == expected['hostname']
    assert split_url(url, 'foo')
    #