

# Generated at 2022-06-25 09:30:18.701555
# Unit test for function split_url
def test_split_url():
    test_inputs = [
        {"value": "xyz", "query": "https://github.com/ansible/ansible?query=a"},
        {"value": "xyz", "query": "https://github.com/ansible/ansible?query=a"},
        {"value": "xyz", "query": "https://github.com/ansible/ansible?query=a"},
        {"value": "xyz", "query": "https://github.com/ansible/ansible?query=a"},
        {"value": "xyz", "query": "https://github.com/ansible/ansible?query=a"},
    ]

# Generated at 2022-06-25 09:30:27.445475
# Unit test for function split_url
def test_split_url():
    var_1 = "http://google.com/q=foo"
    var_2 = "q=foo"
    var_3 = "foo"
    var_4 = "https://www.google.com/search?=foo+bar"
    var_5 = "foo+bar"
    var_6 = "bar"
    assert(split_url(var_1)['hostname'] == var_2)
    assert(split_url(var_4)['path'] == var_5)
    assert(split_url(var_4, var_6) == var_6)
    assert(split_url(var_1)['scheme'] == var_3)
    assert(split_url(var_4,  var_2) == var_2)

# Generated at 2022-06-25 09:30:30.800577
# Unit test for function split_url
def test_split_url():
    filter_split_url = split_url(
    )
    assert filter_split_url == expected_filter_split_url

# Generated at 2022-06-25 09:30:33.253530
# Unit test for function split_url
def test_split_url():
    filter_module_0 = FilterModule()
    var_0 = filter_filters()
    assert var_0['urlsplit']() == split_url()

# Generated at 2022-06-25 09:30:34.818429
# Unit test for function split_url

# Generated at 2022-06-25 09:30:40.300742
# Unit test for function split_url
def test_split_url():
    assert split_url('http://example.com/') == {'scheme': 'http', 'netloc': 'example.com', 'path': '', 'query': '', 'fragment': ''}
    assert 'http' == split_url('http://localhost/path/to/something?query=string', query='scheme')



# Generated at 2022-06-25 09:30:46.407249
# Unit test for function split_url
def test_split_url():

    assert split_url('https://vault.ansible.com/foo/bar') == {'fragment': '', 'hostname': 'vault.ansible.com', 'netloc': 'vault.ansible.com', 'path': '/foo/bar', 'query': '', 'scheme': 'https', 'username': '', 'password': '', 'port': ''}
    assert split_url('https://vault.ansible.com/foo/bar', 'path') == '/foo/bar'
    assert split_url('https://vault.ansible.com/foo/bar', 'fragment') == ''

# Generated at 2022-06-25 09:30:55.646828
# Unit test for function split_url
def test_split_url():
    result = split_url(url="http://www.google.com/foo?q=bar")
    assert result == {'netloc': 'www.google.com', 'scheme': 'http', 'path': '/foo', 'query': 'q=bar', 'fragment': '', 'hostname': 'www.google.com', 'port': '', 'username': '', 'password': '', 'params': '', 'query_items': [('q', 'bar')], 'query_string': 'q=bar'}



# Generated at 2022-06-25 09:31:06.161641
# Unit test for function split_url
def test_split_url():
    assert split_url(value='http://ansible.com/', query='scheme', alias='urlsplit') == 'http', 'Expected different value for function output'
    assert split_url(value='ansible.com/', query='scheme', alias='urlsplit') == '', 'Expected different value for function output'
    assert split_url(value='simple_message', query='scheme', alias='urlsplit') == '', 'Expected different value for function output'
    assert split_url(value='http://localhost/', query='scheme', alias='urlsplit') == 'http', 'Expected different value for function output'
    assert split_url(value='http://localhost/', query='netloc', alias='urlsplit') == 'localhost', 'Expected different value for function output'

# Generated at 2022-06-25 09:31:07.496191
# Unit test for function split_url
def test_split_url():
    filter_module_0 = FilterModule()
    val_0 = filter_module_0.filters['split_url']('https://www.example.org:8080/index.html?id=1&name=foo#main_content')
