

# Generated at 2022-06-25 09:30:16.494324
# Unit test for function split_url
def test_split_url():
    assert callable(split_url)
    str_0 = '\\\r}Nuu\n!'
    var_0 = split_url(str_0)

# Generated at 2022-06-25 09:30:21.283008
# Unit test for function split_url
def test_split_url():
    assert split_url('\\\r}Nuu\n!') == '\\\r}Nuu\n!'


# Generated at 2022-06-25 09:30:23.586423
# Unit test for function split_url
def test_split_url():
    # Unit: split_url: AnsibleFilterError
    try:
        test_case_0()
    except AnsibleFilterError as e:
        assert str(e) == 'urlsplit: unknown URL component: str_0'

# Generated at 2022-06-25 09:30:30.581466
# Unit test for function split_url
def test_split_url():
    assert split_url('http://user:password@example.com:8080/foo/bar?arg=value#anchor')['fragment'] == 'anchor'
    assert split_url('http://user:password@example.com:8080/foo/bar?arg=value#anchor')['hostname'] == 'example.com'
    assert split_url('http://user:password@example.com:8080/foo/bar?arg=value#anchor')['username'] == 'user'
    assert split_url('http://user:password@example.com:8080/foo/bar?arg=value#anchor')['path'] == '/foo/bar'
    assert split_url('http://user:password@example.com:8080/foo/bar?arg=value#anchor')['scheme'] == 'http'


# Generated at 2022-06-25 09:30:40.312193
# Unit test for function split_url
def test_split_url():
    # Load fixture
    from ansible.modules.network.ironware import ironware_command
    from ansible.modules.network.ironware import ironware_config
    from ansible.modules.network.ironware import ironware_facts
    from ansible.modules.network.ironware import ironware_linkagg
    from ansible.modules.network.ironware import ironware_lldp
    from ansible.modules.network.ironware import ironware_l2_interface
    from ansible.modules.network.ironware import ironware_l3_interfa                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                

# Generated at 2022-06-25 09:30:46.850912
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.python.org/') == {'scheme': 'http', 'netloc': 'www.python.org', 'path': '/', 'query': '', 'fragment': ''}, "Test #1"
    assert split_url('https://www.python.org/', 'scheme') == 'https', "Test #2"
    assert split_url('http://www.python.org/', 'query') == '', "Test #3"
    assert split_url('http://www.python.org/', 'fragment') == '', "Test #4"
    assert split_url('http://www.python.org/', 'netloc') == 'www.python.org', "Test #5"

# Generated at 2022-06-25 09:30:57.966820
# Unit test for function split_url
def test_split_url():
    str_0 = "hostname:port"
    str_1 = "http://user:password@hostname:port/path?arg=value#fragment"
    str_2 = "http://user:password@hostname:port/path?arg=value#fragment"
    str_3 = "http://user:password@hostname:port/path?arg=value#fragment"
    str_4 = "http://user:password@hostname:port/path?arg=value#fragment"
    str_5 = "http://user:password@hostname:port/path?arg=value#fragment"
    str_6 = "http://user:password@hostname:port/path?arg=value#fragment"

# Generated at 2022-06-25 09:31:01.867887
# Unit test for function split_url
def test_split_url():
    assert split_url(str_0) == var_0


# Testing part

# Generated at 2022-06-25 09:31:04.456440
# Unit test for function split_url
def test_split_url():
    # assert <condition>
    assert 1 == 1

##############################################################################
# Boilerplate call to main()
if __name__ == '__main__':
    test_case_0()
    test_split_url()

# Generated at 2022-06-25 09:31:07.991578
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.simple.com/') == {'hostname': 'www.simple.com', 'query': '', 'scheme': 'http', 'fragment': '', 'path': '/', 'username': '', 'port': None, 'password': ''}

if __name__ == '__main__':
    test_split_url()
    test_case_0()