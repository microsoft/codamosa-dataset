

# Generated at 2022-06-17 11:23:31.084005
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {'fragment': '', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'query': '', 'scheme': 'http'}
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''
   

# Generated at 2022-06-17 11:23:38.582956
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'query') == 'key1=val1&key2=val2'
    assert split

# Generated at 2022-06-17 11:23:48.925429
# Unit test for function split_url
def test_split_url():
    url = 'https://www.ansible.com/blog/ansible-2-6-release-announcement'
    assert split_url(url, 'scheme') == 'https'
    assert split_url(url, 'netloc') == 'www.ansible.com'
    assert split_url(url, 'path') == '/blog/ansible-2-6-release-announcement'
    assert split_url(url, 'query') == ''
    assert split_url(url, 'fragment') == ''
    assert split_url(url, 'username') == ''
    assert split_url(url, 'password') == ''
    assert split_url(url, 'hostname') == 'www.ansible.com'
    assert split_url(url, 'port') == ''
    assert split_url(url)

# Generated at 2022-06-17 11:24:00.047060
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment') == {
        'fragment': 'fragment',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': 'key1=value1&key2=value2',
        'scheme': 'http'
    }
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', 'path') == '/path/to/file.html'

# Generated at 2022-06-17 11:24:09.438459
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': '',
        'fragment': ''
    }
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'

# Generated at 2022-06-17 11:24:20.981369
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.ansible.com/') == {'scheme': 'https', 'netloc': 'www.ansible.com', 'path': '', 'query': '', 'fragment': ''}
    assert split_url('https://www.ansible.com/', 'scheme') == 'https'
    assert split_url('https://www.ansible.com/', 'netloc') == 'www.ansible.com'
    assert split_url('https://www.ansible.com/', 'path') == ''
    assert split_url('https://www.ansible.com/', 'query') == ''
    assert split_url('https://www.ansible.com/', 'fragment') == ''

# Generated at 2022-06-17 11:24:31.282576
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key=value#fragment') == {
        'fragment': 'fragment',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'key=value',
        'scheme': 'http'
    }
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'path')

# Generated at 2022-06-17 11:24:41.793995
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'query': '', 'fragment': ''}
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''

# Generated at 2022-06-17 11:24:50.063392
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.ansible.com/') == {'scheme': 'http', 'netloc': 'www.ansible.com', 'path': '', 'query': '', 'fragment': ''}
    assert split_url('http://www.ansible.com/', 'scheme') == 'http'
    assert split_url('http://www.ansible.com/', 'netloc') == 'www.ansible.com'
    assert split_url('http://www.ansible.com/', 'path') == ''
    assert split_url('http://www.ansible.com/', 'query') == ''
    assert split_url('http://www.ansible.com/', 'fragment') == ''

# Generated at 2022-06-17 11:24:54.857281
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment') == {
        'fragment': 'fragment',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'key1=value1&key2=value2',
        'scheme': 'http'
    }
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'netloc') == 'www.example.com'