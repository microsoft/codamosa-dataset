

# Generated at 2022-06-17 11:23:31.036103
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment') == {
        'fragment': 'fragment',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': 'key1=value1&key2=value2',
        'scheme': 'http'
    }
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', 'netloc')

# Generated at 2022-06-17 11:23:37.371370
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': 'key1=value1&key2=value2',
        'fragment': 'fragment'
    }
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', 'netloc')

# Generated at 2022-06-17 11:23:48.474927
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'query') == 'key1=value1&key2=value2'
    assert split

# Generated at 2022-06-17 11:23:59.724317
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {'fragment': '', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'query': '', 'scheme': 'http'}
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''
   

# Generated at 2022-06-17 11:24:10.443155
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2', 'query') == 'key1=value1&key2=value2'

# Generated at 2022-06-17 11:24:21.040511
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {'netloc': 'www.example.com', 'path': '/path/to/file.html', 'scheme': 'http', 'fragment': '', 'query': ''}
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'fragment') == ''


# Generated at 2022-06-17 11:24:31.276252
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': '',
        'fragment': ''
    }
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'

# Generated at 2022-06-17 11:24:41.958830
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': '',
        'fragment': ''
    }
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'

# Generated at 2022-06-17 11:24:51.119845
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': '',
        'fragment': ''
    }
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''

# Generated at 2022-06-17 11:24:59.571244
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'query') == 'key=value'
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'fragment') == 'fragment'
    assert split