

# Generated at 2022-06-17 11:23:35.634604
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2', 'query') == 'key1=val1&key2=val2'

# Generated at 2022-06-17 11:23:48.035188
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key=val#frag') == {
        'fragment': 'frag',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'key=val',
        'scheme': 'http'
    }
    assert split_url('http://www.example.com/path/to/file?key=val#frag', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key=val#frag', 'netloc') == 'www.example.com'

# Generated at 2022-06-17 11:23:59.577929
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment') == {
        'fragment': 'fragment',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'key1=value1&key2=value2',
        'scheme': 'http'
    }
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'netloc') == 'www.example.com'

# Generated at 2022-06-17 11:24:08.738448
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'query': '', 'fragment': ''}
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''

# Generated at 2022-06-17 11:24:16.464139
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key=value&key2=value2') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'key=value&key2=value2',
        'fragment': ''
    }
    assert split_url('http://www.example.com/path/to/file?key=value&key2=value2', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key=value&key2=value2', 'query') == 'key=value&key2=value2'

# Generated at 2022-06-17 11:24:23.180772
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'query') == 'key1=val1&key2=val2'
    assert split

# Generated at 2022-06-17 11:24:36.546018
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'query': '', 'fragment': ''}
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''

# Generated at 2022-06-17 11:24:47.083251
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'query': '', 'fragment': ''}
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''

# Generated at 2022-06-17 11:24:58.357151
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment') == {
        'fragment': 'fragment',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': 'key1=value1&key2=value2',
        'scheme': 'http'
    }
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', 'query') == 'key1=value1&key2=value2'

# Generated at 2022-06-17 11:25:08.962866
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'query') == 'key1=val1&key2=val2'
    assert split