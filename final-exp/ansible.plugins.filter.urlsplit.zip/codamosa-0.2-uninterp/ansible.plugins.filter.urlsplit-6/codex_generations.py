

# Generated at 2022-06-17 11:23:30.984965
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment') == {
        'fragment': 'fragment',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'key1=val1&key2=val2',
        'scheme': 'http'
    }
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'netloc') == 'www.example.com'

# Generated at 2022-06-17 11:23:37.315828
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?foo=bar&baz=qux') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'foo=bar&baz=qux',
        'fragment': ''
    }
    assert split_url('http://www.example.com/path/to/file?foo=bar&baz=qux', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?foo=bar&baz=qux', 'netloc') == 'www.example.com'

# Generated at 2022-06-17 11:23:48.433708
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2', 'query') == 'key1=value1&key2=value2'

# Generated at 2022-06-17 11:23:59.724698
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'query': '', 'fragment': ''}
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''

# Generated at 2022-06-17 11:24:10.439904
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'query': '', 'fragment': ''}
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''

# Generated at 2022-06-17 11:24:15.000521
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.example.com/path/to/file?query=string#fragment') == {
        'scheme': 'https',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'query=string',
        'fragment': 'fragment'
    }
    assert split_url('https://www.example.com/path/to/file?query=string#fragment', 'scheme') == 'https'
    assert split_url('https://www.example.com/path/to/file?query=string#fragment', 'netloc') == 'www.example.com'
    assert split_url('https://www.example.com/path/to/file?query=string#fragment', 'path')

# Generated at 2022-06-17 11:24:25.547192
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': '',
        'fragment': ''
    }
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'

# Generated at 2022-06-17 11:24:37.157493
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment') == {'fragment': 'fragment', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'query': 'key1=value1&key2=value2', 'scheme': 'http'}
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', 'netloc') == 'www.example.com'
    assert split

# Generated at 2022-06-17 11:24:47.647582
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'key1=value1&key2=value2',
        'fragment': 'fragment'
    }
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'netloc') == 'www.example.com'

# Generated at 2022-06-17 11:24:58.785271
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com:8080/path?arg=value#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com:8080/path?arg=value#fragment', 'netloc') == 'www.example.com:8080'
    assert split_url('http://www.example.com:8080/path?arg=value#fragment', 'path') == '/path'
    assert split_url('http://www.example.com:8080/path?arg=value#fragment', 'query') == 'arg=value'
    assert split_url('http://www.example.com:8080/path?arg=value#fragment', 'fragment') == 'fragment'