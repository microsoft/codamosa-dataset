

# Generated at 2022-06-17 11:23:36.127292
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/foo/bar?q=1') == {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/foo/bar', 'query': 'q=1', 'fragment': ''}
    assert split_url('http://www.example.com/foo/bar?q=1', 'scheme') == 'http'
    assert split_url('http://www.example.com/foo/bar?q=1', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/foo/bar?q=1', 'path') == '/foo/bar'
    assert split_url('http://www.example.com/foo/bar?q=1', 'query') == 'q=1'
    assert split

# Generated at 2022-06-17 11:23:48.279916
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'query') == 'key=value'
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'fragment') == 'fragment'
    assert split

# Generated at 2022-06-17 11:23:59.725060
# Unit test for function split_url
def test_split_url():
    url = 'http://user:pass@www.example.com:8080/path/to/file?query=string#fragment'
    assert split_url(url) == {'scheme': 'http', 'netloc': 'user:pass@www.example.com:8080', 'path': '/path/to/file', 'query': 'query=string', 'fragment': 'fragment'}
    assert split_url(url, 'scheme') == 'http'
    assert split_url(url, 'netloc') == 'user:pass@www.example.com:8080'
    assert split_url(url, 'path') == '/path/to/file'
    assert split_url(url, 'query') == 'query=string'

# Generated at 2022-06-17 11:24:10.440543
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {'fragment': '', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'query': '', 'scheme': 'http'}
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''
   

# Generated at 2022-06-17 11:24:17.023876
# Unit test for function split_url
def test_split_url():
    url = 'http://www.example.com:8080/path/to/file.html?key1=value1&key2=value2#fragment'
    result = split_url(url)
    assert result['scheme'] == 'http'
    assert result['netloc'] == 'www.example.com:8080'
    assert result['path'] == '/path/to/file.html'
    assert result['query'] == 'key1=value1&key2=value2'
    assert result['fragment'] == 'fragment'
    assert split_url(url, 'scheme') == 'http'
    assert split_url(url, 'netloc') == 'www.example.com:8080'
    assert split_url(url, 'path') == '/path/to/file.html'

# Generated at 2022-06-17 11:24:24.941400
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': 'key1=value1&key2=value2',
        'fragment': 'fragment'
    }
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', 'netloc')

# Generated at 2022-06-17 11:24:36.952237
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': '',
        'fragment': ''
    }
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'

# Generated at 2022-06-17 11:24:47.426413
# Unit test for function split_url
def test_split_url():
    url = 'https://www.example.com:8080/path/to/file?query=string#fragment'
    assert split_url(url) == {
        'scheme': 'https',
        'netloc': 'www.example.com:8080',
        'path': '/path/to/file',
        'query': 'query=string',
        'fragment': 'fragment'
    }
    assert split_url(url, 'scheme') == 'https'
    assert split_url(url, 'netloc') == 'www.example.com:8080'
    assert split_url(url, 'path') == '/path/to/file'
    assert split_url(url, 'query') == 'query=string'

# Generated at 2022-06-17 11:24:58.627857
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment') == {'fragment': 'fragment', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'query': 'key1=value1&key2=value2', 'scheme': 'http'}
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', 'netloc') == 'www.example.com'
    assert split

# Generated at 2022-06-17 11:25:08.996118
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'query': '', 'fragment': ''}
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''