

# Generated at 2022-06-17 11:23:36.502648
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'query': '', 'fragment': ''}
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''

# Generated at 2022-06-17 11:23:48.345665
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment') == {
        'fragment': 'fragment',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': 'key1=value1&key2=value2',
        'scheme': 'http'
    }
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', 'netloc')

# Generated at 2022-06-17 11:23:59.723926
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'query') == 'key1=value1&key2=value2'
    assert split

# Generated at 2022-06-17 11:24:10.440482
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'query': '', 'fragment': ''}
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''

# Generated at 2022-06-17 11:24:21.040789
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com:8080/foo/bar?a=b&c=d#anchor') == {
        'scheme': 'http',
        'netloc': 'www.example.com:8080',
        'path': '/foo/bar',
        'query': 'a=b&c=d',
        'fragment': 'anchor'
    }
    assert split_url('http://www.example.com:8080/foo/bar?a=b&c=d#anchor', 'scheme') == 'http'
    assert split_url('http://www.example.com:8080/foo/bar?a=b&c=d#anchor', 'netloc') == 'www.example.com:8080'

# Generated at 2022-06-17 11:24:31.283014
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com:80/path/to/file?foo=bar&baz=qux#anchor') == {
        'scheme': 'http',
        'netloc': 'www.example.com:80',
        'path': '/path/to/file',
        'query': 'foo=bar&baz=qux',
        'fragment': 'anchor'
    }
    assert split_url('http://www.example.com:80/path/to/file?foo=bar&baz=qux#anchor', 'scheme') == 'http'
    assert split_url('http://www.example.com:80/path/to/file?foo=bar&baz=qux#anchor', 'netloc') == 'www.example.com:80'
   

# Generated at 2022-06-17 11:24:41.794425
# Unit test for function split_url
def test_split_url():
    url = 'https://www.example.com/path/to/file?key=value#fragment'
    expected = {
        'scheme': 'https',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'key=value',
        'fragment': 'fragment'
    }

    assert split_url(url) == expected
    assert split_url(url, 'scheme') == expected['scheme']
    assert split_url(url, 'netloc') == expected['netloc']
    assert split_url(url, 'path') == expected['path']
    assert split_url(url, 'query') == expected['query']
    assert split_url(url, 'fragment') == expected['fragment']

# Generated at 2022-06-17 11:24:50.063310
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.ansible.com/') == {'scheme': 'http', 'netloc': 'www.ansible.com', 'path': '', 'query': '', 'fragment': ''}
    assert split_url('http://www.ansible.com/', 'scheme') == 'http'
    assert split_url('http://www.ansible.com/', 'netloc') == 'www.ansible.com'
    assert split_url('http://www.ansible.com/', 'path') == ''
    assert split_url('http://www.ansible.com/', 'query') == ''
    assert split_url('http://www.ansible.com/', 'fragment') == ''

# Generated at 2022-06-17 11:24:59.817073
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': '',
        'fragment': ''
    }
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'

# Generated at 2022-06-17 11:25:09.092262
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'query') == 'key1=val1&key2=val2'
    assert split