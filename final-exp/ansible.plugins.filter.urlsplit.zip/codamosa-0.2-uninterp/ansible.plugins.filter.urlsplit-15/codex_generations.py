

# Generated at 2022-06-17 11:23:36.879117
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'query': '', 'fragment': ''}
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''

# Generated at 2022-06-17 11:23:48.377157
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2', 'query') == 'key1=val1&key2=val2'

# Generated at 2022-06-17 11:23:59.724291
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'query') == 'key1=val1&key2=val2'
    assert split

# Generated at 2022-06-17 11:24:10.440244
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com:8080/path/to/file?query=string#fragment') == {
        'fragment': 'fragment',
        'netloc': 'www.example.com:8080',
        'path': '/path/to/file',
        'query': 'query=string',
        'scheme': 'http'
    }
    assert split_url('http://www.example.com:8080/path/to/file?query=string#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com:8080/path/to/file?query=string#fragment', 'netloc') == 'www.example.com:8080'

# Generated at 2022-06-17 11:24:15.014359
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': '',
        'fragment': ''
    }
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'

# Generated at 2022-06-17 11:24:25.546341
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': '',
        'fragment': ''
    }
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'

# Generated at 2022-06-17 11:24:37.156601
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment') == {
        'fragment': 'fragment',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'key1=value1&key2=value2',
        'scheme': 'http'
    }
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'fragment') == 'fragment'

# Generated at 2022-06-17 11:24:47.647191
# Unit test for function split_url
def test_split_url():
    url = 'http://www.example.com:8080/path/to/file.html?key1=value1&key2=value2#fragment'
    assert split_url(url) == {
        'scheme': 'http',
        'netloc': 'www.example.com:8080',
        'path': '/path/to/file.html',
        'query': 'key1=value1&key2=value2',
        'fragment': 'fragment'
    }
    assert split_url(url, 'scheme') == 'http'
    assert split_url(url, 'netloc') == 'www.example.com:8080'
    assert split_url(url, 'path') == '/path/to/file.html'

# Generated at 2022-06-17 11:24:58.784815
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'query': '', 'fragment': ''}
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''

# Generated at 2022-06-17 11:25:08.996575
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/foo/bar?a=b&c=d#fragment') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/foo/bar',
        'query': 'a=b&c=d',
        'fragment': 'fragment'
    }

    assert split_url('http://www.example.com/foo/bar?a=b&c=d#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/foo/bar?a=b&c=d#fragment', 'netloc') == 'www.example.com'