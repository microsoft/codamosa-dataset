

# Generated at 2022-06-17 11:23:35.635040
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment') == {
        'fragment': 'fragment',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': 'key1=value1&key2=value2',
        'scheme': 'http'
    }
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', query='scheme') == 'http'

# Generated at 2022-06-17 11:23:48.034902
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment') == {
        'fragment': 'fragment',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': 'key1=value1&key2=value2',
        'scheme': 'http'
    }
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', 'query') == 'key1=value1&key2=value2'

# Generated at 2022-06-17 11:23:59.578234
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'query': '', 'fragment': ''}
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''

# Generated at 2022-06-17 11:24:08.738768
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': '',
        'fragment': ''
    }
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'

# Generated at 2022-06-17 11:24:16.440965
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment') == {
        'fragment': 'fragment',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'key1=val1&key2=val2',
        'scheme': 'http'
    }
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'netloc') == 'www.example.com'

# Generated at 2022-06-17 11:24:23.104773
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'key1=value1&key2=value2',
        'fragment': 'fragment'
    }
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'netloc') == 'www.example.com'

# Generated at 2022-06-17 11:24:36.471178
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': '',
        'fragment': ''
    }
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'

# Generated at 2022-06-17 11:24:44.159116
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2', 'query') == 'key1=value1&key2=value2'

# Generated at 2022-06-17 11:24:51.584678
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': '',
        'fragment': ''
    }
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'

# Generated at 2022-06-17 11:24:59.808743
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': '',
        'fragment': ''
    }
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'