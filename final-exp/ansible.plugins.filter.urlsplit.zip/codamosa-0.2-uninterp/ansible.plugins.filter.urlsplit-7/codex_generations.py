

# Generated at 2022-06-17 11:23:31.104608
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'query') == 'key1=value1&key2=value2'
    assert split

# Generated at 2022-06-17 11:23:38.599692
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'key1=val1&key2=val2',
        'fragment': 'fragment'
    }
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'netloc') == 'www.example.com'

# Generated at 2022-06-17 11:23:48.946683
# Unit test for function split_url
def test_split_url():
    url = 'http://www.example.com:80/path/to/file.html?key1=value1&key2=value2#fragment'
    assert split_url(url) == {
        'scheme': 'http',
        'netloc': 'www.example.com:80',
        'path': '/path/to/file.html',
        'query': 'key1=value1&key2=value2',
        'fragment': 'fragment'
    }
    assert split_url(url, 'scheme') == 'http'
    assert split_url(url, 'netloc') == 'www.example.com:80'
    assert split_url(url, 'path') == '/path/to/file.html'

# Generated at 2022-06-17 11:24:00.077926
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment') == {'fragment': 'fragment', 'netloc': 'www.example.com', 'path': '/path/to/file', 'query': 'key1=value1&key2=value2', 'scheme': 'http'}
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'netloc') == 'www.example.com'

# Generated at 2022-06-17 11:24:09.439618
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': 'key1=value1&key2=value2',
        'fragment': 'fragment'
    }
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', 'netloc')

# Generated at 2022-06-17 11:24:20.973447
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com:8080/path/to/file.html?foo=bar&baz=qux#anchor') == {
        'scheme': 'http',
        'netloc': 'www.example.com:8080',
        'path': '/path/to/file.html',
        'query': 'foo=bar&baz=qux',
        'fragment': 'anchor'
    }
    assert split_url('http://www.example.com:8080/path/to/file.html?foo=bar&baz=qux#anchor', 'scheme') == 'http'
    assert split_url('http://www.example.com:8080/path/to/file.html?foo=bar&baz=qux#anchor', 'netloc')

# Generated at 2022-06-17 11:24:31.244446
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.example.com/path/to/file.html?key1=val1&key2=val2#fragment', 'scheme') == 'https'
    assert split_url('https://www.example.com/path/to/file.html?key1=val1&key2=val2#fragment', 'netloc') == 'www.example.com'
    assert split_url('https://www.example.com/path/to/file.html?key1=val1&key2=val2#fragment', 'path') == '/path/to/file.html'

# Generated at 2022-06-17 11:24:41.961760
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': '',
        'fragment': ''
    }
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'

# Generated at 2022-06-17 11:24:46.054708
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''
    assert split_url('http://www.example.com/path/to/file.html', 'fragment') == ''
    assert split_url('http://www.example.com/path/to/file.html', 'unknown') == 'urlsplit: unknown URL component: unknown'

# Generated at 2022-06-17 11:24:52.528008
# Unit test for function split_url
def test_split_url():
    url = 'http://www.example.com/path/to/file.html?key1=value1&key2=value2#Frag'
    result = split_url(url)
    assert result['scheme'] == 'http'
    assert result['netloc'] == 'www.example.com'
    assert result['path'] == '/path/to/file.html'
    assert result['query'] == 'key1=value1&key2=value2'
    assert result['fragment'] == 'Frag'
    assert split_url(url, 'scheme') == 'http'
    assert split_url(url, 'netloc') == 'www.example.com'
    assert split_url(url, 'path') == '/path/to/file.html'