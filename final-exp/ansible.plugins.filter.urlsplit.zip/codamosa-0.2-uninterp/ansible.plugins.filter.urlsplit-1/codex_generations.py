

# Generated at 2022-06-17 11:23:35.577626
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''
    assert split_url('http://www.example.com/path/to/file.html', 'fragment') == ''
    assert split_url('http://www.example.com/path/to/file.html', 'unknown') == 'urlsplit: unknown URL component: unknown'

# Generated at 2022-06-17 11:23:47.998837
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'key1=value1&key2=value2',
        'fragment': 'fragment'
    }
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'netloc') == 'www.example.com'

# Generated at 2022-06-17 11:23:59.557754
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?foo=bar&baz=qux') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'foo=bar&baz=qux',
        'fragment': ''
    }
    assert split_url('http://www.example.com/path/to/file?foo=bar&baz=qux', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?foo=bar&baz=qux', 'netloc') == 'www.example.com'

# Generated at 2022-06-17 11:24:10.349391
# Unit test for function split_url
def test_split_url():
    url = 'http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment'
    assert split_url(url) == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': 'key1=value1&key2=value2',
        'fragment': 'fragment'
    }
    assert split_url(url, 'scheme') == 'http'
    assert split_url(url, 'netloc') == 'www.example.com'
    assert split_url(url, 'path') == '/path/to/file.html'

# Generated at 2022-06-17 11:24:21.040270
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'key1=value1&key2=value2',
        'fragment': 'fragment'
    }
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'netloc') == 'www.example.com'

# Generated at 2022-06-17 11:24:31.275875
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': '',
        'fragment': ''
    }
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'

# Generated at 2022-06-17 11:24:41.958940
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'key1=value1&key2=value2',
        'fragment': 'fragment'
    }
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'netloc') == 'www.example.com'

# Generated at 2022-06-17 11:24:50.127366
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html') == {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'query': '', 'fragment': ''}
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''

# Generated at 2022-06-17 11:24:59.867961
# Unit test for function split_url
def test_split_url():
    url = 'http://www.example.com:8080/path/to/file?query=string#fragment'
    assert split_url(url, 'scheme') == 'http'
    assert split_url(url, 'netloc') == 'www.example.com:8080'
    assert split_url(url, 'path') == '/path/to/file'
    assert split_url(url, 'query') == 'query=string'
    assert split_url(url, 'fragment') == 'fragment'
    assert split_url(url, 'username') is None
    assert split_url(url, 'password') is None
    assert split_url(url, 'hostname') == 'www.example.com'
    assert split_url(url, 'port') == 8080

# Generated at 2022-06-17 11:25:07.729841
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file.html', 'path') == '/path/to/file.html'
    assert split_url('http://www.example.com/path/to/file.html', 'query') == ''
    assert split_url('http://www.example.com/path/to/file.html', 'fragment') == ''
    assert split_url('http://www.example.com/path/to/file.html', 'unknown') == 'urlsplit: unknown URL component: unknown'