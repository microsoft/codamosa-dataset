

# Generated at 2022-06-17 11:23:36.747829
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#fragment', 'query') == 'key1=val1&key2=val2'
    assert split

# Generated at 2022-06-17 11:23:48.376152
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.ansible.com/') == {'scheme': 'http', 'netloc': 'www.ansible.com', 'path': '', 'query': '', 'fragment': ''}
    assert split_url('http://www.ansible.com/', 'scheme') == 'http'
    assert split_url('http://www.ansible.com/', 'netloc') == 'www.ansible.com'
    assert split_url('http://www.ansible.com/', 'path') == ''
    assert split_url('http://www.ansible.com/', 'query') == ''
    assert split_url('http://www.ansible.com/', 'fragment') == ''
    assert split_url('http://www.ansible.com/', 'port') == None

# Generated at 2022-06-17 11:23:59.725672
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment') == {
        'fragment': 'fragment',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'key1=value1&key2=value2',
        'scheme': 'http'
    }
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2#fragment', 'netloc') == 'www.example.com'

# Generated at 2022-06-17 11:24:10.439770
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': 'key1=value1&key2=value2',
        'fragment': 'fragment'
    }
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment', 'netloc')

# Generated at 2022-06-17 11:24:20.766467
# Unit test for function split_url
def test_split_url():
    url = 'https://www.example.com:8080/path/to/file?query=string#fragment'
    assert split_url(url) == {'scheme': 'https', 'netloc': 'www.example.com:8080', 'path': '/path/to/file', 'query': 'query=string', 'fragment': 'fragment'}
    assert split_url(url, 'scheme') == 'https'
    assert split_url(url, 'netloc') == 'www.example.com:8080'
    assert split_url(url, 'path') == '/path/to/file'
    assert split_url(url, 'query') == 'query=string'
    assert split_url(url, 'fragment') == 'fragment'

# Generated at 2022-06-17 11:24:31.243794
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key1=value1&key2=value2', 'query') == 'key1=value1&key2=value2'

# Generated at 2022-06-17 11:24:41.958966
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?foo=bar&baz=qux') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'foo=bar&baz=qux',
        'fragment': ''
    }
    assert split_url('http://www.example.com/path/to/file?foo=bar&baz=qux', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?foo=bar&baz=qux', 'netloc') == 'www.example.com'

# Generated at 2022-06-17 11:24:50.128306
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.ansible.com/') == {'scheme': 'http', 'netloc': 'www.ansible.com', 'path': '', 'query': '', 'fragment': ''}
    assert split_url('http://www.ansible.com/', 'scheme') == 'http'
    assert split_url('http://www.ansible.com/', 'netloc') == 'www.ansible.com'
    assert split_url('http://www.ansible.com/', 'path') == ''
    assert split_url('http://www.ansible.com/', 'query') == ''
    assert split_url('http://www.ansible.com/', 'fragment') == ''

# Generated at 2022-06-17 11:24:59.868103
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'query') == 'key=value'
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'fragment') == 'fragment'
    assert split

# Generated at 2022-06-17 11:25:07.729904
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'query') == 'key=value'
    assert split_url('http://www.example.com/path/to/file?key=value#fragment', 'fragment') == 'fragment'
    assert split