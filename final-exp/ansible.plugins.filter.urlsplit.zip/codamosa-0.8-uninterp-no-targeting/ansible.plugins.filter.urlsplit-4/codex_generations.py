

# Generated at 2022-06-21 04:50:42.090150
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None


# Generated at 2022-06-21 04:50:47.454940
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' uri_filter.py:TestClass '''
    # Create an object of class FilterModule
    TEST = FilterModule()

    # Check the required filters are present
    assert len(TEST.filters()) == 1, "Insufficient filters."

# Generated at 2022-06-21 04:51:01.531627
# Unit test for function split_url
def test_split_url():
    test_value = 'http://www.test.com:8888/path/to/file?query=string#anchor'

    results = split_url(test_value)
    assert 'http' == results['scheme']
    assert 'www.test.com' == results['netloc']
    assert '8888' == results['port']
    assert '/path/to/file' == results['path']
    assert 'query=string' == results['query']
    assert 'anchor' == results['fragment']

    results = split_url(test_value, 'scheme')
    assert 'http' == results

    results = split_url(test_value, 'netloc')
    assert 'www.test.com' == results

    results = split_url(test_value, 'port')

# Generated at 2022-06-21 04:51:03.317563
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filterModule = FilterModule()
    assert filterModule != None


# Generated at 2022-06-21 04:51:09.520987
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'scheme' == FilterModule.filters(None)['urlsplit']('http://127.0.0.1/path', 'scheme')
    assert 'http' == FilterModule.filters(None)['urlsplit']('http://127.0.0.1/path', 'scheme')
    with pytest.raises(AnsibleFilterError):
        FilterModule.filters(None)['urlsplit']('http://127.0.0.1/path', 'schme')

# Generated at 2022-06-21 04:51:12.055348
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test the constructor
    filtermodule = FilterModule()

# Generated at 2022-06-21 04:51:15.675664
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    v = FilterModule.filters(FilterModule)

    assert 'urlsplit' in v.keys()
    assert v['urlsplit'] == split_url


# Generated at 2022-06-21 04:51:19.310178
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter = FilterModule()
    assert filter.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-21 04:51:27.478118
# Unit test for function split_url
def test_split_url():
    url = "http://user:password@ansible.com:8000/docs/index.html?q=ansible&page=2&page=3#ans1"

    # Test the entire dictionary
    expected = {'scheme': 'http', 'netloc': 'user:password@ansible.com:8000', 'path': '/docs/index.html', 'query': 'q=ansible&page=2&page=3', 'fragment': 'ans1'}
    actual = split_url(url)
    assert actual == expected

    # Test a specific query
    expected = 'user:password@ansible.com:8000'
    actual = split_url(url, query='netloc')
    assert actual == expected

    # Test a specific query without supplying a value for query
    expected = 'http'

# Generated at 2022-06-21 04:51:40.290594
# Unit test for function split_url
def test_split_url():
    url_to_split = 'http://www.example.com:80/path?q=3'
    url_splits = split_url(url_to_split)
    assert url_splits['scheme'] == 'http'
    assert url_splits['netloc'] == 'www.example.com:80'
    assert url_splits['path'] == '/path'
    assert url_splits['query'] == 'q=3'
    assert url_splits['fragment'] == ''

    assert split_url(url_to_split, 'scheme') == 'http'
    assert split_url(url_to_split, 'netloc') == 'www.example.com:80'
    assert split_url(url_to_split, 'path') == 'www.example.com'
    assert split_url