

# Generated at 2022-06-21 04:50:48.015409
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(isinstance(FilterModule(), FilterModule))

# Generated at 2022-06-21 04:50:52.073730
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    class Object(object):
        pass
    options = Object()
    assert fm.filters() == {'urlsplit': split_url}

# Generated at 2022-06-21 04:51:02.382814
# Unit test for function split_url
def test_split_url():
    from ansible import errors
    from ansible.compat.tests import unittest

    # The test case for split_url

# Generated at 2022-06-21 04:51:03.519511
# Unit test for constructor of class FilterModule
def test_FilterModule():
    return FilterModule()

# Generated at 2022-06-21 04:51:18.140034
# Unit test for function split_url
def test_split_url():
    obj = FilterModule()
    filters = obj.filters()
    url = "https://www.ansible.com/test?test=test#test"
    assert filters['urlsplit'](url, query="scheme") == "https"
    assert filters['urlsplit'](url, query="netloc") == "www.ansible.com"
    assert filters['urlsplit'](url, query="path") == "/test"
    assert filters['urlsplit'](url, query="fragment") == "test"
    assert filters['urlsplit'](url, query="query") == "test=test"
    assert filters['urlsplit'](url, query="unknown") == None
    assert filters['urlsplit'](url, query="scheme") == "https"

# Generated at 2022-06-21 04:51:26.459550
# Unit test for function split_url
def test_split_url():
    url = 'https://www.google.com/search?q=urlsplit&oq=urlsplit&aqs=chrome..69i57j0l5.2485j0j7&sourceid=chrome&ie=UTF-8'

    assert split_url(url, 'scheme') == 'https'
    assert split_url(url, 'netloc') == 'www.google.com'
    assert split_url(url, 'path') == '/search'
    assert split_url(url, 'query') == 'q=urlsplit&oq=urlsplit&aqs=chrome..69i57j0l5.2485j0j7&sourceid=chrome&ie=UTF-8'
    assert split_url(url, 'fragment') == ''

# Generated at 2022-06-21 04:51:38.460022
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filters = FilterModule().filters()

    def test_urlsplit(value, query='', alias='urlsplit'):
        results = filters['urlsplit'](value, query)
        if query:
            return results
        else:
            return dict((key, value) for (key, value) in results.items() if value)

    assert test_urlsplit('http://user:pass@localhost:80/path?foo=bar#baz') == {'scheme': 'http', 'netloc': 'user:pass@localhost:80', 'path': '/path', 'query': 'foo=bar', 'fragment': 'baz'}
    assert test_urlsplit('http://user:pass@localhost:80/path?foo=bar#baz', 'scheme') == 'http'

# Generated at 2022-06-21 04:51:45.702005
# Unit test for function split_url
def test_split_url():
    # Initialize Ansible module mock
    import ansible.modules.system.uri
    module = ansible.modules.system.uri.URI(load_args=['/bin/foo', 'dummy'])

    assert split_url(module, 'https://ansible.com/index.html', query='scheme') == 'https'
    assert split_url(module, 'https://ansible.com:443/index.html', query='port') == '443'
    assert split_url(module, 'https://ansible.com:443/index.html', query='path') == '/index.html'
    assert split_url(module, 'https://ansible.com:443/index.html', query='fragment') == ''

# Generated at 2022-06-21 04:51:49.682973
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert hasattr(FilterModule, 'filters'), "filter method missing"
    assert callable(FilterModule.filters), "filter method not callable"


# Generated at 2022-06-21 04:51:51.503686
# Unit test for constructor of class FilterModule
def test_FilterModule():
    paths = ["/examples/default.php", "/examples/book/",
             "/examples/", "/examples", "/"]

    for path in paths:
        assert len(split_url(path, query="path", alias='urlsplit')) == len(path)


if __name__ == '__main__':
    import sys
    sys.exit(test_FilterModule())