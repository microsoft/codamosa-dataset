

# Generated at 2022-06-21 04:50:44.631668
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    filter_loader = FilterModule()
    assert filter_loader.filters()['urlsplit']('https://www.google.com/test?test=test') == {'netloc': 'www.google.com', 'path': '/test', 'query': 'test=test', 'scheme': 'https', 'fragment': '', 'username': '', 'password': '', 'hostname': 'www.google.com', 'port': None}
    assert filter_loader.filters()['urlsplit']('https://www.google.com/test?test=test', 'netloc') == 'www.google.com'
    assert filter_loader.filters()['urlsplit']('https://www.google.com/test?test=test', 'path') == '/test'

# Generated at 2022-06-21 04:50:48.052036
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """Test to call a constructor of class FilterModule"""
    try:
        f = FilterModule()
        assert True
    except Exception as e:
        assert False, str(e)


# Generated at 2022-06-21 04:50:51.578920
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # create a new object
    test_obj = FilterModule()
    # assert: FilterModule created successfully
    assert test_obj is not None

# Generated at 2022-06-21 04:50:54.959879
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for method filters of class FilterModule '''
    filter_module = FilterModule()
    assert filter_module.filters()


# Generated at 2022-06-21 04:51:03.970750
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text
    import json

    test_path = '../'
    test_os = 'Linux'
    test_arch = 'x86_64'
    test_params = '?scm=git&fqdn=github.com'
    test_url = "https://github.com/ansible/ansible/tree/devel"

    if test_os == 'Windows':
        test_path = test_path.replace('/', '\\')

    # Parse the url using urlsplit
    url = urlsplit(test_url)
    # Create a dictionary from the urlsplit object

# Generated at 2022-06-21 04:51:05.807179
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule().filters(), dict)


# Generated at 2022-06-21 04:51:12.844534
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    url = 'https://github.com/ansible/ansible/commit/3d6c996f6a23b8e8ba6d0e1c9a00a9c817d1b520'
    fm = FilterModule()
    result = fm.filters()['urlsplit'](url, query='scheme')
    assert result == 'https'


# Generated at 2022-06-21 04:51:15.409130
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert 'urlsplit' in filters



# Generated at 2022-06-21 04:51:26.306431
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    urlsplit_filter = fm.filters()['urlsplit']
    test_url = "https://www.example.com:80/index.html?q=foo#_bar"
    assert test_url == urlsplit_filter(test_url)
    assert 'example.com' == urlsplit_filter(test_url, 'hostname')
    assert '80' == urlsplit_filter(test_url, 'port')
    assert 'example.com:80' == urlsplit_filter(test_url, 'netloc')
    assert 'www.example.com' == urlsplit_filter(test_url, 'hostname', alias='urlsplit')
    assert 'foo' == urlsplit_filter(test_url, 'query')

# Generated at 2022-06-21 04:51:31.953879
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # It is expected to pass, otherwise an exception would be thrown.
    FilterModule()


# Generated at 2022-06-21 04:51:44.434247
# Unit test for function split_url
def test_split_url():
    ''' uri module check '''
    from ansible.module_utils.urls import split_url

    assert split_url('db://cjones:redhat@www.example.com:1521/demodb') == ['db', '', 'cjones:redhat', 'www.example.com', '1521', '/demodb']
    assert split_url('db://cjones:redhat@www.example.com:1521/demodb?foo#bar') == ['db', '', 'cjones:redhat', 'www.example.com', '1521', '/demodb?foo#bar']
    assert split_url('db://cjones:@www.example.com:1521') == ['db', '', 'cjones:', 'www.example.com', '1521', '']

# Generated at 2022-06-21 04:51:48.250372
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert len(filters) == 1
    for key, value in filters.items():
        assert key
        assert value

# Generated at 2022-06-21 04:51:50.850432
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    f = FilterModule()

    assert f.filters() == {'urlsplit':split_url}

# Generated at 2022-06-21 04:52:02.339046
# Unit test for function split_url
def test_split_url():
    split = split_url("http://example.com/path?key=value", "query")
    assert split == 'key=value'

    split = split_url("http://u:p@example.com:80/p/a/t/h?k=v#f")
    assert split['scheme'] == 'http'
    assert split['username'] == 'u'
    assert split['password'] == 'p'
    assert split['netloc'] == 'u:p@example.com:80'
    assert split['hostname'] == 'example.com'
    assert split['port'] == 80
    assert split['path'] == '/p/a/t/h'
    assert split['query'] == 'k=v'
    assert split['fragment'] == 'f'

# Generated at 2022-06-21 04:52:05.022831
# Unit test for constructor of class FilterModule
def test_FilterModule():
    '''Test FilterModule constructor'''
    try:
        fm = FilterModule()
    except Exception as exc:
        assert 0, 'Error creating FilterModule: %s %s' % (type(exc), exc)


# Generated at 2022-06-21 04:52:07.506392
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'foo' == FilterModule.filters(FilterModule())['urlsplit']('http://foo', 'netloc')

# Generated at 2022-06-21 04:52:10.053461
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'urlsplit' in filter_module.filters()


# Generated at 2022-06-21 04:52:10.915875
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:52:17.420551
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' test_FilterModule_filters() is a unit test for the filters method of class FilterModule '''
    #  Unit test for the filters method of class FilterModule
    #
    #  Args: none
    #
    #  Returns: none
    #
    #  Raises: none

    print("\n\ntest_FilterModule_filters():\n")

    # create an instance of class FilterModule
    fm = FilterModule()

    # call the filters method of class FilterModule
    f = fm.filters()

    print("\n\ntest_FilterModule_filters():\n")

    print("\tlength of f: %s" % len(f))
    print("\tf:",f)


# ---- main ----

# Generated at 2022-06-21 04:52:18.355871
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule