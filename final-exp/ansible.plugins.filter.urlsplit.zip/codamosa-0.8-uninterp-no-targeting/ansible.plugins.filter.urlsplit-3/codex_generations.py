

# Generated at 2022-06-21 04:50:45.684318
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    fm = FilterModule()
    assert fm.filters() == { 'urlsplit': split_url }


# Generated at 2022-06-21 04:50:49.126069
# Unit test for constructor of class FilterModule
def test_FilterModule():
    split_url('http://docs.ansible.com/ansible/latest/playbooks_filters.html#urisplit-filter')

# Generated at 2022-06-21 04:51:02.013673
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ansible = __import__('ansible')
    e = ansible.errors.AnsibleFilterError
    m = ansible.module_utils.six.moves.urllib.parse.urlsplit
    u = 'http://ansible.com/docs?t=1'

    f = FilterModule()

    assert isinstance(f.filters(), dict)

    assert f.filters()['urlsplit']('http://foo.com/bar?a=b') == m('http://foo.com/bar?a=b')._asdict()

    assert f.filters()['urlsplit'](u, '') == m(u)._asdict()

    assert f.filters()['urlsplit'](u, 'scheme') == m(u).scheme


# Generated at 2022-06-21 04:51:09.017702
# Unit test for function split_url
def test_split_url():
    url = 'http://localhost:8080/test/test/test.html?test=test'
    expected_urlsplit = dict(scheme='http', netloc='localhost:8080', path='/test/test/test.html', query='test=test', fragment='')

    assert split_url(url) == expected_urlsplit
    assert split_url(url, query='scheme') == 'http'
    assert split_url(url, query='path') == '/test/test/test.html'
    assert split_url(url, query='port') == '8080'

# Generated at 2022-06-21 04:51:11.779518
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-21 04:51:14.344385
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert {'urlsplit': split_url} == FilterModule().filters()


# Generated at 2022-06-21 04:51:18.883706
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ansibleFilterModule = FilterModule()
    assert ansibleFilterModule.filters() == {'urlsplit': split_url}

# Generated at 2022-06-21 04:51:30.225798
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test with known examples
    c = {
        'url': 'https://docs.ansible.com/ansible/latest/user_guide/playbooks_variables.html#using-variables-in-plays'
    }
    filters = FilterModule().filters()
    assert filters['urlsplit'](c['url'], 'scheme') == 'https'
    assert filters['urlsplit'](c['url'])['scheme'] == 'https'
    assert filters['urlsplit'](c['url'], query='scheme') == 'https'

# Generated at 2022-06-21 04:51:38.563402
# Unit test for function split_url
def test_split_url():
    url = 'http://localhost/files/auto.conf'
    parsed = split_url(url)

    # Test full URL
    assert parsed['scheme'] == 'http'
    assert parsed['netloc'] == 'localhost'
    assert parsed['path'] == '/files/auto.conf'
    assert parsed['query'] == ''
    assert parsed['fragment'] == ''

    # Test each query
    assert split_url(url, 'scheme') == 'http'
    assert split_url(url, 'netloc') == 'localhost'
    assert split_url(url, 'path') == '/files/auto.conf'
    assert split_url(url, 'query') == ''
    assert split_url(url, 'fragment') == ''

    # If a bad query is supplied, raise an AnsibleFilterError

# Generated at 2022-06-21 04:51:45.719956
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    url_filter = FilterModule()
    url = url_filter.filters()['urlsplit']
    assert url('https://github.com/ansible/ansible/issues?q=is%3Aissue+is%3Aopen+label%3Afeature_request', 'query') == 'q=is%3Aissue+is%3Aopen+label%3Afeature_request', "{} failed to return query with parameter q".format(url)
    assert url('https://github.com/ansible/ansible', 'scheme') == 'https', "{} failed to return scheme".format(url)
    assert url('https://github.com/ansible/ansible', 'netloc') == 'github.com', "{} failed to return netloc".format(url)