

# Generated at 2022-06-21 04:50:47.155129
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters() == {'urlsplit': split_url}

# Generated at 2022-06-21 04:51:01.459180
# Unit test for function split_url
def test_split_url():
    assert split_url('https://github.com/ansible/ansible/issues?state=open') == 'https'
    assert split_url('https://github.com/ansible/ansible/issues?state=open', 'hostname') == 'github.com'
    assert split_url('https://github.com/ansible/ansible/issues?state=open', 'port') == 443
    assert split_url('https://github.com/ansible/ansible/issues?state=open', 'path') == '/ansible/ansible/issues'
    assert split_url('https://github.com/ansible/ansible/issues?state=open', 'scheme') == 'https'
    assert split_url('https://github.com/ansible/ansible/issues?state=open', 'fragment') == ''

# Generated at 2022-06-21 04:51:03.368371
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters['urlsplit'] == split_url


# Generated at 2022-06-21 04:51:08.420639
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Test "urlsplit" filter
    assert (
        ("scheme", "netloc", "path", "query", "fragment") ==
        tuple(sorted(split_url("http://www.example.com:80/path/to/file.html", "", "urlsplit").keys()))
    )

# Generated at 2022-06-21 04:51:11.776622
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() is not None

# Generated at 2022-06-21 04:51:13.325883
# Unit test for constructor of class FilterModule
def test_FilterModule():
    pass


# Generated at 2022-06-21 04:51:26.237257
# Unit test for function split_url
def test_split_url():
    filtered = split_url("http://user:pass@example.com:8080/path/to/file?v=2&b=3#foo", query="scheme")
    assert filtered == 'http'
    filtered = split_url("http://user:pass@example.com:8080/path/to/file?v=2&b=3#foo", query="netloc")
    assert filtered == 'user:pass@example.com:8080'
    filtered = split_url("http://user:pass@example.com:8080/path/to/file?v=2&b=3#foo", query="path")
    assert filtered == '/path/to/file'

# Generated at 2022-06-21 04:51:31.953061
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-21 04:51:35.505682
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class_instance = FilterModule()
    assert 'urlsplit' in class_instance.filters()


# Generated at 2022-06-21 04:51:44.537209
# Unit test for function split_url
def test_split_url():
    test_url = 'http://192.168.1.1/page?query=foo'
    assert split_url(test_url, 'scheme') == 'http'
    assert split_url(test_url, 'netloc') == '192.168.1.1'
    assert split_url(test_url, 'path') == '/page'
    assert split_url(test_url, 'query') == 'query=foo'
    assert split_url(test_url, 'fragment') == ''
    assert split_url(test_url) == {'scheme': 'http', 'netloc': '192.168.1.1', 'path': '/page', 'query': 'query=foo', 'fragment': ''}