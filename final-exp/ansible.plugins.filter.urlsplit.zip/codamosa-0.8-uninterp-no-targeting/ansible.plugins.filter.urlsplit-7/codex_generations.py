

# Generated at 2022-06-21 04:50:48.017902
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:50:56.802040
# Unit test for function split_url
def test_split_url():
    url = 'https://www.example.com/test/path?a=1&b=2'
    test = split_url(url)
    assert test['scheme'] == 'https'
    assert test['netloc'] == 'www.example.com'
    assert test['path'] == '/test/path'
    assert test['query'] == 'a=1&b=2'
    assert test['fragment'] == ''

# Generated at 2022-06-21 04:50:58.162916
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule.filters()['urlsplit'] == split_url


# Generated at 2022-06-21 04:51:03.817142
# Unit test for constructor of class FilterModule
def test_FilterModule(): 
    assert FilterModule.filters.__name__ == 'filters'


if __name__ == '__main__': 
    # Unit tests for FilterModule class
    test_FilterModule()

# Generated at 2022-06-21 04:51:07.077196
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    filter_urlsplit = module.filters()['urlsplit']
    assert filter_urlsplit is split_url


# Generated at 2022-06-21 04:51:09.469150
# Unit test for constructor of class FilterModule
def test_FilterModule():
    '''
    test FilterModule
    '''
    t = FilterModule()
    assert t.filters() is not None



# Generated at 2022-06-21 04:51:13.313839
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    assert filters.filters()['urlsplit'] == split_url



# Generated at 2022-06-21 04:51:20.975189
# Unit test for function split_url

# Generated at 2022-06-21 04:51:23.870014
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Create class instance
    fm = FilterModule()
    # Get filters method
    filters = fm.filters()
    # Check if method 'urlsplit' is present
    assert 'urlsplit' in filters

# Generated at 2022-06-21 04:51:30.021141
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Test for FilterModule.filters()
    fm = FilterModule()

    # Test for callable
    assert callable(fm.filters)

    # Test for results of call to method
    assert fm.filters() == {'urlsplit': split_url}

# Generated at 2022-06-21 04:51:43.848824
# Unit test for function split_url
def test_split_url():
    assert split_url('https://192.168.1.1:443/login.html?username=root&password=passwd', 'scheme') == 'https'
    assert split_url('https://192.168.1.1:443/login.html?username=root&password=passwd', 'netloc') == '192.168.1.1:443'
    assert split_url('https://192.168.1.1:443/login.html?username=root&password=passwd', 'path') == '/login.html'
    assert split_url('https://192.168.1.1:443/login.html?username=root&password=passwd', 'query') == 'username=root&password=passwd'

# Generated at 2022-06-21 04:51:58.439460
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url(value='http://www.cwi.nl:80/%7Eguido/Python.html?lang=en&name=Guido') == {'fragment': '', 'netloc': 'www.cwi.nl:80', 'path': '/%7Eguido/Python.html', 'scheme': 'http', 'query': 'lang=en&name=Guido'}
    assert split_url(value='http://www.cwi.nl:80/%7Eguido/Python.html?lang=en&name=Guido', query='netloc') == 'www.cwi.nl:80'
    assert split_url(value='http://www.cwi.nl:80/%7Eguido/Python.html?lang=en&name=Guido', query='scheme') == 'http'

# Generated at 2022-06-21 04:52:12.361358
# Unit test for function split_url
def test_split_url():
    url = 'http://user@www.ietf.org:8080/INFO.html;a=b;c=d?a=b;c=d#body'
    query = "scheme"
    results = split_url(url, query)
    assert results == 'http'
    query = "netloc"
    results = split_url(url, query)
    assert results == 'user@www.ietf.org:8080'
    query = "path"
    results = split_url(url, query)
    assert results == '/INFO.html;a=b;c=d'
    query = "params"
    results = split_url(url, query)
    assert results == 'a=b;c=d'
    query = "query"
    results = split_url(url, query)
    assert results

# Generated at 2022-06-21 04:52:14.390476
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)


# Generated at 2022-06-21 04:52:17.290513
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    mod = FilterModule()
    assert mod.filters() == {'urlsplit': split_url}


# Generated at 2022-06-21 04:52:20.038740
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()


# Generated at 2022-06-21 04:52:23.977721
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None


# Generated at 2022-06-21 04:52:26.161284
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test = FilterModule()
    assert test.filters()['urlsplit'] == split_url

# Generated at 2022-06-21 04:52:29.115721
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test = 'test'
    # test FilterModule constructed successfully
    assert test == 'test'



# Generated at 2022-06-21 04:52:39.246902
# Unit test for function split_url