

# Generated at 2022-06-21 04:50:52.029605
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?query=args#hash', 'scheme') == 'http'
    assert split_url('ldap://user:pass@server.domain.com:389/path?query=args#hash')['netloc'] == 'user:pass@server.domain.com:389'
    assert split_url('mailto:user@example.com')['scheme'] == 'mailto'
    assert split_url('http://user@example.com', 'path') == ''
    assert split_url('http://example.com/%7Eusername/', 'path') == '/~username/'
    assert split_url('http://example.com/%7Eusername/', 'username') is None

# Generated at 2022-06-21 04:50:57.876993
# Unit test for constructor of class FilterModule
def test_FilterModule():
    from ansible.utils import context_objects as co
    try:
        f = FilterModule()
    except Exception as e:
        assert False, "Failed to create FilterModule object: " + str(e)
    assert isinstance(f,FilterModule)
    assert hasattr(f,'filters')


# Generated at 2022-06-21 04:51:02.976152
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(FilterModule().filters().get("urlsplit") is not None)


# Generated at 2022-06-21 04:51:10.835563
# Unit test for function split_url
def test_split_url():
    import ansible.utils.unsplit_url_ansible as uua
    uu = uua.unsplit_url_ansible
    assert split_url(uu(scheme="ftp", netloc="github.com", path="/ansible/ansible")) == uu(scheme="ftp", netloc="github.com", path="/ansible/ansible")
    assert split_url(uu(netloc="github.com", path="/ansible/ansible"), query='netloc') == "github.com"
    assert split_url(uu(scheme="ftp", netloc="github.com", path="/ansible/ansible"), query='path') == "/ansible/ansible"

# Generated at 2022-06-21 04:51:13.519634
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_filter = FilterModule()
    assert test_filter.filters()['urlsplit'] == split_url

# Generated at 2022-06-21 04:51:26.237536
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com:8080/path/to/index.html?name=value#anchor') == {
        'netloc': 'www.example.com:8080',
        'path': '/path/to/index.html',
        'query': 'name=value',
        'scheme': 'http',
        'fragment': 'anchor',
    }

    assert split_url('http://www.example.com:8080/path/to/index.html?name=value#anchor', 'netloc') == 'www.example.com:8080'
    assert split_url('http://www.example.com:8080/path/to/index.html?name=value#anchor', 'scheme') == 'http'

# Generated at 2022-06-21 04:51:37.891823
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    test_filter = fm.filters()['urlsplit']
    test_url = 'http://user:password@example.com:8080/path?query'

    test_results = test_filter(test_url)
    assert test_results['scheme'] == 'http'
    assert test_results['netloc'] == 'user:password@example.com:8080'
    assert test_results['hostname'] == 'example.com'
    assert test_results['port'] == 8080
    assert test_results['path'] == '/path'
    assert test_results['query'] == 'query'

    test_results = test_filter(test_url, query='scheme')
    assert test_results == 'http'

# Generated at 2022-06-21 04:51:40.365230
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert isinstance(fm.filters(), dict)


# Generated at 2022-06-21 04:51:52.410915
# Unit test for function split_url
def test_split_url():
    '''Test split_url Ansible filter.'''

    assert split_url('http://github.com:80/ansible/ansible')['scheme'] == 'http', \
        'Scheme should be HTTP.'
    assert split_url('http://github.com:80/ansible/ansible', 'netloc') == 'github.com:80', \
        'Netloc should contain host and port.'
    assert split_url('http://github.com:80/ansible/ansible', 'port') == 80, \
        'Port should be 80.'
    assert split_url('http://github.com:80/ansible/ansible', 'path') == '/ansible/ansible', \
        'Path should be /ansible/ansible.'

# Generated at 2022-06-21 04:51:55.683316
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() == {
        'urlsplit': split_url
    }

# ---- Tests for functions ----