

# Generated at 2022-06-21 04:50:47.155988
# Unit test for constructor of class FilterModule
def test_FilterModule():
    example = FilterModule()
    assert example is not None


# Generated at 2022-06-21 04:50:49.341650
# Unit test for constructor of class FilterModule
def test_FilterModule():
    instance = FilterModule()
    assert instance


# Generated at 2022-06-21 04:51:00.663677
# Unit test for function split_url
def test_split_url():
    results = split_url('http://www.example.com:80/path?arg=value#fragment')
    assert results['scheme'] == 'http'
    assert results['netloc'] == 'www.example.com:80'
    assert results['path'] == '/path'
    assert results['params'] == ''
    assert results['query'] == 'arg=value'
    assert results['fragment'] == 'fragment'
    assert split_url('http://www.example.com:80/path?arg=value#fragment', 'netloc') == 'www.example.com:80'

# Generated at 2022-06-21 04:51:03.622650
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(None) == {'urlsplit': split_url}


# Unit tests for function split_url

# Generated at 2022-06-21 04:51:10.214768
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path', 'query', 'urlsplit') == ''
    assert split_url('http://www.example.com/path?foo=bar&baz=quux', 'query', 'urlsplit') == 'foo=bar&baz=quux'
    assert split_url('http://www.example.com/path?foo=bar&baz=quux', 'scheme', 'urlsplit') == 'http'

# Generated at 2022-06-21 04:51:16.724174
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.ansible.com/') == {'fragment': '', 'netloc': 'www.ansible.com', 'query': '', 'scheme': 'https', 'path': '/', 'params': ''}
    assert split_url('https://www.ansible.com', 'scheme') == 'https'
    assert split_url('https://www.ansible.com', 'netloc') == 'www.ansible.com'
    assert split_url('https://www.ansible.com', 'path') == '/'

# Generated at 2022-06-21 04:51:20.872526
# Unit test for constructor of class FilterModule
def test_FilterModule():
    url_split = split_url("http://ansible.com")
    assert(url_split == {'scheme': 'http', 'netloc': 'ansible.com', 'path': '', 'params': '', 'query': '', 'fragment': ''})

    #print("urlsplit_scheme: {0}".format(get('scheme', url_split)))
    assert(urlsplit("scheme", url_split) == 'http')


# Generated at 2022-06-21 04:51:28.075311
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert {
        'urlsplit': split_url
    } == FilterModule().filters()


# test_alias defines which method within the FilterModule is to be tested
# test_parameters gives the parameters that are to be used with the method
# test_result is the expected result

# Generated at 2022-06-21 04:51:38.486800
# Unit test for function split_url
def test_split_url():

    import unittest

    class TestSplitUrl(unittest.TestCase):

        def test_query(self):
            url = "http://www.google.com/mail/user@domain.com"
            result = split_url(url, query='scheme')
            self.assertEqual(result, 'http')

        def test_object(self):
            url = "http://www.google.com/mail/user@domain.com"
            result = split_url(url)
            self.assertEqual(result['scheme'], 'http')

        def test_fail(self):
            url = "http://www.google.com/mail/user@domain.com"
            with self.assertRaises(AnsibleFilterError):
                split_url(url, query='bad')

    test_suite = un

# Generated at 2022-06-21 04:51:41.524608
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.google.com:8000/path?a=foo&b=bar#fragment') == {
        'fragment': 'fragment', 'netloc': 'www.google.com:8000', 'path': '/path', 'query': 'a=foo&b=bar', 'scheme': 'http', 'hostname': 'www.google.com', 'port': '8000', 'username': None, 'password': None, 'params': '',
    }