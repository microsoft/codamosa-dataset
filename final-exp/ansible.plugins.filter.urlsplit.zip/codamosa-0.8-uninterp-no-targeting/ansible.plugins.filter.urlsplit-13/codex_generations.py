

# Generated at 2022-06-21 04:50:51.278453
# Unit test for function split_url

# Generated at 2022-06-21 04:50:58.340032
# Unit test for function split_url
def test_split_url():
    assert split_url("http://www.example.com/path?key=val#frag") == {
        'fragment': 'frag',
        'hostname': 'www.example.com',
        'netloc': 'www.example.com',
        'params': '',
        'path': '/path',
        'query': 'key=val',
        'scheme': 'http',
    }

# Generated at 2022-06-21 04:51:10.087269
# Unit test for function split_url

# Generated at 2022-06-21 04:51:20.871450
# Unit test for function split_url
def test_split_url():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network.f5.common import F5ModuleError

    assert split_url('http://127.0.0.1:8000/foo/bar?arg=value', query='scheme') == 'http'
    assert split_url('http://127.0.0.1:8000/foo/bar?arg=value', query='netloc') == '127.0.0.1:8000'
    assert split_url('http://127.0.0.1:8000/foo/bar?arg=value', query='path') == '/foo/bar'

# Generated at 2022-06-21 04:51:28.076605
# Unit test for function split_url

# Generated at 2022-06-21 04:51:39.457191
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com:8000/path?q=1', query='scheme') == 'http'
    assert split_url('http://www.example.com:8000/path?q=1', query='netloc') == 'www.example.com:8000'
    assert split_url('http://www.example.com:8000/path?q=1', query='path') == '/path'
    assert split_url('http://www.example.com:8000/path?q=1', query='query') == 'q=1'

# Generated at 2022-06-21 04:51:41.546053
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    tst = FilterModule()
    assert tst.filters() == {'urlsplit': split_url}


# Generated at 2022-06-21 04:51:44.415404
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f1 = FilterModule()
    f2 = f1.filters()
    assert 'urlsplit' in f2

# Generated at 2022-06-21 04:51:45.782698
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule


# Generated at 2022-06-21 04:51:51.427799
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(split_url('http://www.ansible.com/index.html', 'netloc') == 'www.ansible.com')
    assert(split_url('http://www.ansible.com/index.html', 'path') == '/index.html')