

# Generated at 2022-06-21 04:50:47.981059
# Unit test for constructor of class FilterModule
def test_FilterModule():

    from ansible.plugins.filter.uris import FilterModule
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}



# Generated at 2022-06-21 04:50:48.855341
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:50:53.657183
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import ansible.plugins.filter.core
    f = ansible.plugins.filter.core.FilterModule()
    assert f.filters()['urlsplit'] == split_url


# Generated at 2022-06-21 04:50:55.014358
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-21 04:50:58.163298
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # now = datetime.now()
    fm = FilterModule()
    assert isinstance(fm, FilterModule)
    # assert fm.now == now


# Generated at 2022-06-21 04:51:02.661444
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-21 04:51:05.273673
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    testmodule = FilterModule()
    assert 'urlsplit' in testmodule.filters()


# Generated at 2022-06-21 04:51:08.060834
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(None) == {
        'urlsplit': split_url
    }



# Generated at 2022-06-21 04:51:11.132954
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermod = FilterModule()
    assert filtermod.filters() == {'urlsplit': split_url}


# Generated at 2022-06-21 04:51:15.277503
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()
    assert 'urlsplit' in filters
    assert filters['urlsplit'].__name__ == 'split_url'


# Generated at 2022-06-21 04:51:18.390619
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-21 04:51:20.027483
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Test for constructor of class FilterModule '''

    assert 'urlsplit' in FilterModule.filters(FilterModule())

# Generated at 2022-06-21 04:51:23.580809
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module.filters() == {'urlsplit': split_url}


# Generated at 2022-06-21 04:51:24.903222
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

# Generated at 2022-06-21 04:51:39.676866
# Unit test for function split_url
def test_split_url():
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests import unittest
    from ansible.module_utils import basic

    with patch.object(basic.AnsibleModule, 'run_command') as run_command:
        run_command.return_value = (0, '/usr/bin/ansible', '')

        def run_command(args, check_rc=True):
            if "command" in args:
                if args["command"] == "which":
                    return (0, '/usr/bin/ansible', "")
                else:
                    raise Exception("Unknown command: %s" % args["command"])

        run_command.side_effect = run_command

        import __main__
        __main__.run_command = run_command


# Generated at 2022-06-21 04:51:40.430078
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-21 04:51:52.448200
# Unit test for function split_url
def test_split_url():
    '''Test for split_url function'''

    url_component = 'scheme'
    url_value = 'https'
    url_key = 'scheme'
    url_dict = {'hostname': 'www.ansible.com', 'port': None, 'scheme': 'https', 'path': '', 'netloc': 'www.ansible.com', 'query': '', 'url': 'https://www.ansible.com', 'username': None, 'password': None, 'fragment': ''}
    url = "https://www.ansible.com"
    assert split_url(url_value, url_component) == url_value
    assert split_url(url, url_component) == url_value
    assert split_url(url, url_key) == url_value
    assert split_url(url)

# Generated at 2022-06-21 04:51:54.403191
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule) == {'urlsplit': split_url}

# Generated at 2022-06-21 04:51:59.716211
# Unit test for function split_url
def test_split_url():
    assert split_url('http://example.com') == {'hostname': 'example.com', 'netloc': 'example.com', 'query': '', 'scheme': 'http', 'fragment': '', 'path': '', 'username': '', 'password': ''}

# Generated at 2022-06-21 04:52:02.067670
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert (issubclass(FilterModule, object))
    assert (isinstance(FilterModule(), object))