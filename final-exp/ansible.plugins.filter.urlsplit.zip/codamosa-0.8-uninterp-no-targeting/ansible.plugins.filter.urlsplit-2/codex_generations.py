

# Generated at 2022-06-21 04:50:51.255155
# Unit test for function split_url
def test_split_url():
    module = type('', (), {})()
    module.params = {}
    module.fail_json = lambda *args, **kwargs: module.exit_args
    module.fail_json.__name__ = 'fail_json'
    module.exit_args = None
    module.exit_args = None

    assert split_url(module, value='http://www.ansible.com/test?option=1', query='netloc') == 'www.ansible.com'

    assert 'request_uri' in split_url(module, value='http://www.ansible.com/test?option=1')
    assert 'request_uri' not in split_url(module, value='http://www.ansible.com/test?option=1', query='request_uri')

# Generated at 2022-06-21 04:50:53.687259
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()['urlsplit'] == split_url

# Generated at 2022-06-21 04:51:03.374064
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule, object)


# Unit test and mock for method filters of class FilterModule
@pytest.mark.run(order=1)
@pytest.mark.asyncio
async def test_FilterModule_filters(mocker):
    mock_filters = mocker.patch.object(FilterModule, 'filters')
    obj = FilterModule()
    assert mock_filters.return_value == obj.filters()


# Unit tests for method split_url of module uri
#
# Test for query string parameter
#
#     Examples for valid inputs:
#         value                   : <host>\n<host>:<port>\n<host>/<path>;<params>?<query>#<fragment>
#         alias                   : 'urlsplit' by default
#
#     Returns:

# Generated at 2022-06-21 04:51:09.049037
# Unit test for function split_url
def test_split_url():
    url = 'http://docs.ansible.com:8080/user_guide/playbooks_variables.html#strings'

    values = [
        'scheme',
        'netloc',
        'path',
        'query',
        'fragment',
    ]
    for value in values:
        assert split_url(url, value) == split_url(url)[value]


# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-21 04:51:20.788531
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """Unit test for method filters of class FilterModule."""
    filt_mod = FilterModule()

    query = None
    value = "http://username@example.com/path/to/file.php?foo=bar&amp;abc=123#fragment"
    results = {
        'scheme': 'http',
        'netloc': 'username@example.com',
        'path': '/path/to/file.php',
        'query': 'foo=bar&amp;abc=123',
        'fragment': 'fragment'
    }
    assert split_url(value, query) == results
    assert filt_mod.filters()['urlsplit'](value, query) == results

    query = 'netloc'
    expect = 'username@example.com'

# Generated at 2022-06-21 04:51:22.033986
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')


# Generated at 2022-06-21 04:51:23.907390
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {'urlsplit': split_url}

# Generated at 2022-06-21 04:51:26.997567
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('http://www.example.com/foo/bar?a=b#c', 'scheme') == 'http'



# Generated at 2022-06-21 04:51:31.548501
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert isinstance(obj, FilterModule)


# Generated at 2022-06-21 04:51:43.909474
# Unit test for function split_url
def test_split_url():

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    from urlparse import urlparse
    from urlparse import urlunparse

    class TestURL(unittest.TestCase):

        def test_split_url_query(self):
            with patch.object(urlparse, 'urldefrag') as urldefrag:
                with patch.object(urlparse, 'urlparse') as urlparse:
                    with patch.object(urlparse, 'urlsplit') as urlsplit:

                        test_url = 'https://www.example.com'
                        test_query = 'scheme'

                        test_urldefrag_return = ('https://www.example.com', '')
                        urldefrag.return_value = test_urldefrag