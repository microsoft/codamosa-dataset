

# Generated at 2022-06-21 04:50:46.854584
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() == {
        'urlsplit': split_url
    }

# ---- Ansible Filter methods ----

# Generated at 2022-06-21 04:50:49.702309
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()


# Generated at 2022-06-21 04:51:02.191257
# Unit test for function split_url
def test_split_url():
    """
    Tests various urls to see if they are split correctly
    """
    url_with_scheme = 'https://www.ansible.com/how/why'
    url_without_scheme = 'www.ansible.com/how/why'
    url_with_query = 'https://www.ansible.com?foo=1&bar=2'

    # Test scheme
    assert 'https' == split_url(url_with_scheme, 'scheme')
    assert '' == split_url(url_without_scheme, 'scheme')

    # Test netloc
    assert 'www.ansible.com' == split_url(url_with_scheme, 'netloc')
    assert 'www.ansible.com' == split_url(url_without_scheme, 'netloc')

    # Test

# Generated at 2022-06-21 04:51:08.335181
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com') == {
        'netloc': 'www.example.com',
        'fragment': '',
        'path': '',
        'scheme': 'http',
        'query': ''
    }
    assert split_url('http://www.example.com?foo=bar') == {
        'netloc': 'www.example.com',
        'fragment': '',
        'path': '',
        'scheme': 'http',
        'query': 'foo=bar'
    }

# Generated at 2022-06-21 04:51:12.763110
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url("http://localhost/foo", "netloc") == "localhost"

# Unit tests for method split_url of class FilterModule

# Generated at 2022-06-21 04:51:14.208790
# Unit test for constructor of class FilterModule
def test_FilterModule():
    p = FilterModule()
    assert p

# Generated at 2022-06-21 04:51:26.272426
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('http://example.com', 'scheme') == 'http'
    assert split_url('https://example.com', 'port') == None
    assert split_url('/c/users/default', 'path') == '/c/users/default'
    assert split_url('http://example.com', 'query') == ''
    assert split_url('http://example.com', 'fragment') == ''

# Generated at 2022-06-21 04:51:30.674401
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-21 04:51:32.824259
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    results = fm.filters()
    assert results['urlsplit'] == split_url



# Generated at 2022-06-21 04:51:44.066854
# Unit test for function split_url
def test_split_url():
    # Test url
    url = "http://www.iana.org/domains/reserved.html"
    # Expected result
    result = {'scheme': 'http',
              'netloc': 'www.iana.org',
              'port': None,
              'path': '/domains/reserved.html',
              'username': None,
              'password': None,
              'query': None,
              'fragment': None}
    # Test default result
    assert split_url(url) == result
    # Test query = 'scheme'
    assert split_url(url, query='scheme') == 'http'
    # Test query = 'netloc'
    assert split_url(url, query='netloc') == 'www.iana.org'
    # Test query = 'path'
    assert split_url