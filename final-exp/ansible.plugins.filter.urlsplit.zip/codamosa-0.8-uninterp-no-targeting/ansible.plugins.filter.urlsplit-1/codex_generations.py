

# Generated at 2022-06-21 04:51:00.877174
# Unit test for function split_url
def test_split_url():
    assert split_url('http://example.com/index.html', 'scheme') == 'http'
    assert split_url('http://example.com/index.html', 'netloc') == 'example.com'
    assert split_url('http://example.com/index.html', 'path') == '/index.html'
    assert split_url('http://example.com/index.html', 'query') == ''
    assert split_url('http://example.com/index.html', 'fragment') == ''
    assert split_url('http://example.com/index.html', 'username') == ''
    assert split_url('http://example.com/index.html', 'password') == ''
    assert split_url('http://example.com/index.html', 'hostname') == 'example.com'
    assert split_

# Generated at 2022-06-21 04:51:02.147784
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters()['urlsplit'] == split_url



# Generated at 2022-06-21 04:51:06.256133
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'urlsplit' in filter_module.filters()
    for key in filter_module.filters().keys():
        assert key in ['urlsplit']


# Generated at 2022-06-21 04:51:19.750958
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()

# Generated at 2022-06-21 04:51:23.030135
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urlsplit'] is split_url


# Generated at 2022-06-21 04:51:24.902946
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule('urlsplit') is not None


# Generated at 2022-06-21 04:51:28.197460
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    tester = FilterModule()
    assert tester.filters()['urlsplit'] == split_url


# Generated at 2022-06-21 04:51:39.457430
# Unit test for function split_url
def test_split_url():
    import copy
    import os
    import sys

    # We may be executing this as a standalone script
    # when running unit tests.  If so, ensure we have
    # the current directory in the path so that we can
    # import modules.
    test_dir = os.path.dirname(__file__)
    if test_dir not in sys.path:
        sys.path.append(test_dir)

    from ansible.module_utils.six.moves.urllib.parse import urlunsplit
    from ansible.module_utils._text import to_text

    # URL to split
    url = 'https://user:pass@www.example.com:8080/path?query=string#fragment'

    # Reference results

# Generated at 2022-06-21 04:51:42.330498
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()

# ---- Ansible filters ----


# Generated at 2022-06-21 04:51:45.854452
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_instance = FilterModule()
    if type(test_instance) != FilterModule:
        raise Exception("FilterModule class constructor does not work")

# Unit tests for filters