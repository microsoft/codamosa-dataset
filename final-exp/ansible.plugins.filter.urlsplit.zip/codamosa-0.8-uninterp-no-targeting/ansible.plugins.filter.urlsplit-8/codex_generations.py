

# Generated at 2022-06-21 04:50:46.541618
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urlsplit' in filters

# Generated at 2022-06-21 04:50:47.438731
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None
    assert isinstance(f, FilterModule)


# Generated at 2022-06-21 04:50:53.687251
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    split_url_method = FilterModule.filters(None).get("urlsplit")
    assert split_url_method("http://docs.ansible.com/ansible/latest/modules/intro_module_development.html")["scheme"] == "http"


# Generated at 2022-06-21 04:51:02.120619
# Unit test for function split_url
def test_split_url():
    test_url = 'https://user:password@www.example.com:80/path/to/file?key=value#hash'
    test_result = {
        'fragment': 'hash',
        'netloc': 'user:password@www.example.com:80',
        'path': '/path/to/file',
        'query': 'key=value',
        'scheme': 'https',
        'username': 'user'
    }
    test_result_with_password = 'user:password@www.example.com:80'

    assert test_result == split_url(test_url)
    assert test_result_with_password == split_url(test_url, 'netloc')

# Generated at 2022-06-21 04:51:04.005137
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()

    assert(module.filters() == {'urlsplit': split_url})


# Generated at 2022-06-21 04:51:11.485858
# Unit test for function split_url
def test_split_url():
    url = 'http://www.ansible.com/foo/bar?a=b'

    # Passing in a single query
    assert split_url(url, 'scheme') == 'http'
    assert split_url(url, 'netloc') == 'www.ansible.com'
    assert split_url(url, 'path') == '/foo/bar'
    assert split_url(url, 'query') == 'a=b'
    assert split_url(url, 'fragment') == ''

    # When no query is specified, return a dictionary
    assert split_url(url) == {
        'scheme': 'http',
        'netloc': 'www.ansible.com',
        'path': '/foo/bar',
        'query': 'a=b',
        'fragment': ''
    }

   

# Generated at 2022-06-21 04:51:12.623828
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    tester = FilterModule()
    assert 'urlsplit' in tester.filters()


# Generated at 2022-06-21 04:51:17.881024
# Unit test for function split_url
def test_split_url():
    ''' Test the split_url function '''
    assert split_url('https://www.example.com/foo/bar') == {
        'scheme': 'https',
        'netloc': 'www.example.com',
        'path': '/foo/bar',
        'query': '',
        'fragment': ''
    }

# Generated at 2022-06-21 04:51:26.786458
# Unit test for function split_url
def test_split_url():
    assert split_url('http://hostname.com/a/b/c') == {'scheme': 'http', 'netloc': 'hostname.com', 'path': '/a/b/c', 'query': '', 'fragment': ''}
    assert split_url('http://hostname.com/a/b/c', 'scheme') == 'http'
    assert split_url('http://hostname.com/a/b/c', 'netloc') == 'hostname.com'
    assert split_url('http://hostname.com/a/b/c', 'path') == '/a/b/c'
    assert split_url('http://hostname.com/a/b/c', 'query') == ''

# Generated at 2022-06-21 04:51:38.459093
# Unit test for function split_url
def test_split_url():
    uris = ['http://www.example.com/foo/bar?a=alpha&b=beta',
            'http://user:pass@www.example.com:8080/foo/bar?a=alpha&b=beta',
            'http://user:pass@www.example.com:8080/foo/bar?a=alpha&b=beta#fragment',
            'http://user:pass@www.example.com:8080/foo/bar?a=alpha&b=beta#fragment/foo?c=chi#delta']