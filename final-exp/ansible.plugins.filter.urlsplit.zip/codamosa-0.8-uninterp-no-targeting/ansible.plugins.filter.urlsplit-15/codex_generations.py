

# Generated at 2022-06-21 04:50:51.056991
# Unit test for function split_url
def test_split_url():
    result = split_url('http://ansible.com/')
    assert result['scheme'] == 'http'
    assert result['netloc'] == 'ansible.com'
    assert result['path'] == '/'

    result = split_url('http://ansible.com/docs/')
    assert result['path'] == '/docs/'

    result = split_url('http://ansible.com/docs/?example=true')
    assert result['query'] == 'example=true'

    result = split_url('http://ansible.com/docs/#here')
    assert result['fragment'] == 'here'

    result = split_url('http://ansible.com/docs/?example=true#here')
    assert result['query'] == 'example=true'
    assert result['fragment'] == 'here'

   

# Generated at 2022-06-21 04:50:53.730660
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert 'urlsplit' in filters



# Generated at 2022-06-21 04:51:03.127088
# Unit test for function split_url
def test_split_url():

    url = 'https://username:password@example.com:8080/path/to/file?query=value#fragment'

    assert split_url(url) == {'fragment': 'fragment', 'netloc': 'username:password@example.com:8080', 'path': '/path/to/file', 'query': 'query=value', 'scheme': 'https'}
    assert split_url(url, 'fragment') == 'fragment'
    assert split_url(url, 'netloc') == 'username:password@example.com:8080'
    assert split_url(url, 'path') == '/path/to/file'
    assert split_url(url, 'query') == 'query=value'
    assert split_url(url, 'scheme') == 'https'

# Generated at 2022-06-21 04:51:04.734742
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:51:07.093754
# Unit test for constructor of class FilterModule
def test_FilterModule():
  assert FilterModule.__name__ == 'FilterModule'
  assert callable(FilterModule)


# Generated at 2022-06-21 04:51:09.573275
# Unit test for constructor of class FilterModule
def test_FilterModule():
    a = FilterModule()
    assert a.filters() == {'urlsplit' : split_url}


# Generated at 2022-06-21 04:51:19.601263
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule = FilterModule()
    filter_result = filtermodule.filters()
    filter_result_1 = filter_result['urlsplit']('https://github.com/orgs/ansible/people?page=2')
    assert filter_result_1['scheme'] == 'https'
    assert filter_result_1['fragment'] == ''
    assert filter_result_1['netloc'] == 'github.com'
    assert filter_result_1['path'] == '/orgs/ansible/people'
    assert filter_result_1['query'] == 'page=2'

# Generated at 2022-06-21 04:51:25.762115
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    split_url_filters = FilterModule().filters()['urlsplit']
    assert isinstance(split_url_filters('http://www.example.com/234/456?q=111#abc'), dict)



# Generated at 2022-06-21 04:51:26.708372
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'urlsplit': split_url}

# Generated at 2022-06-21 04:51:38.459832
# Unit test for function split_url
def test_split_url():
    assert split_url('http://username:password@www.example.com:80/path/to/file?key=value&foo=bar#fragment') == dict(scheme='http', netloc='username:password@www.example.com:80', path='/path/to/file', query='key=value&foo=bar', fragment='fragment')
    assert split_url('http://username:password@www.example.com:80/path/to/file?key=value&foo=bar#fragment', 'scheme') == 'http'
    assert split_url('http://username:password@www.example.com:80/path/to/file?key=value&foo=bar#fragment', 'netloc') == 'username:password@www.example.com:80'