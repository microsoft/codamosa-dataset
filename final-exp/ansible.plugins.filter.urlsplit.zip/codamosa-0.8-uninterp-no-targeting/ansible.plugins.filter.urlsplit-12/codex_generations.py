

# Generated at 2022-06-21 04:50:53.687308
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Test a valid query
    value = 'http://www.example.com/foo?bar=baz'
    query = 'query'
    results = split_url(value, query, 'urlsplit')
    assert results == 'bar=baz', 'Result should be: bar=baz'

    # Test an invalid query
    value = 'http://www.example.com/foo?bar=baz'
    query = 'notavalidquery'
    results = split_url(value, query, 'urlsplit')
    assert False, results

    # Test options like 'scheme', 'hostname', etc.
    value = 'http://www.example.com/foo?bar=baz'
    query = 'scheme'
    results = split_url(value, query, 'urlsplit')
    assert results == 'http'

   

# Generated at 2022-06-21 04:51:03.127495
# Unit test for function split_url
def test_split_url():
    result = split_url(
        'HTTPS://www.example.com:80/cgi-bin/path?query=ruby#ruby',
        'query',
    )
    assert result == 'query=ruby'

    result = split_url(
        'http://www.example.com/cgi-bin/path?query=ruby#ruby',
        'query',
    )
    assert result == 'query=ruby'

    result = split_url(
        'https://www.example.com:80/cgi-bin/path?query=ruby#ruby',
        'query',
    )
    assert result == 'query=ruby'

    # Test with no query
    result = split_url(
        'https://www.example.com:80/cgi-bin/path?query=ruby#ruby',
        '',
    )


# Generated at 2022-06-21 04:51:11.286737
# Unit test for function split_url
def test_split_url():
    value = 'http://www.example.com:8080/path/to/file.txt?param1=value1&param2=value2#fragment'  # noqa
    assert 'http://www.example.com:8080/path/to/file.txt' == split_url(value, 'scheme')  # noqa
    assert 'http' == split_url(value, 'scheme')
    assert 'www.example.com:8080' == split_url(value, 'netloc')
    assert 'www.example.com' == split_url(value, 'hostname')
    assert '8080' == split_url(value, 'port')
    assert '/path/to/file.txt' == split_url(value, 'path')

# Generated at 2022-06-21 04:51:19.910222
# Unit test for function split_url
def test_split_url():
    assert split_url('https://github.com/ansible/ansible') == {
        'scheme': 'https',
        'netloc': 'github.com',
        'path': '/ansible/ansible',
        'params': '',
        'query': '',
        'fragment': ''
    }
    assert split_url('https://github.com/ansible/ansible', query='query') == ''
    assert split_url('https://github.com/ansible/ansible', query='scheme') == 'https'
    assert split_url('https://github.com/ansible/ansible', query='ansible') == None

# Generated at 2022-06-21 04:51:22.280987
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert set(FilterModule.filters(FilterModule())) == set([
        'urlsplit'
    ])


# Generated at 2022-06-21 04:51:32.166653
# Unit test for function split_url
def test_split_url():

    # Create a test object to split
    url = "https://www.github.com/ansible/ansible"

    # Create an empty object to test against
    result = {
        'scheme': 'https',
        'netloc': 'www.github.com',
        'path': '/ansible/ansible',
        'query': '',
        'fragment': ''
    }

    # Create a new object and validate that split url returns a dictionary
    url = urlsplit(url)
    assert isinstance(split_url(url), dict)

    # Create a new object and validate that split url returns the expected values
    url = urlsplit(url)
    assert split_url(url) == result

    # Test that the correct values are returned based on what is supplied in the query

# Generated at 2022-06-21 04:51:36.048889
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    actual = FilterModule().filters()
    assert actual == {'urlsplit': split_url}

# ---- Ansible callback plugin ----

# Generated at 2022-06-21 04:51:37.958336
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')

# Generated at 2022-06-21 04:51:45.365313
# Unit test for constructor of class FilterModule
def test_FilterModule():
    results = split_url('http://www.example.com/path', query='scheme')
    assert results == 'http'
    results = split_url('http://www.example.com/path', query='netloc')
    assert results == 'www.example.com'
    results = split_url('http://www.example.com/path', query='path')
    assert results == '/path'
    results = split_url('http://www.example.com/path', query='params')
    assert results == ''
    results = split_url('http://www.example.com/path?abc=123', query='query')
    assert results == 'abc=123'
    results = split_url('http://www.example.com/path', query='fragment')
    assert results == ''

# Generated at 2022-06-21 04:51:48.679693
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = split_url('scheme://netloc/path;param?query=arg#fragment', 'query')
    assert x == 'arg'