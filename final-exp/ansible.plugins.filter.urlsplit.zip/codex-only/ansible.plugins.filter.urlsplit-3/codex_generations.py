

# Generated at 2022-06-23 10:26:08.354183
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert 'urlsplit' in f.filters()

# Generated at 2022-06-23 10:26:18.605015
# Unit test for constructor of class FilterModule
def test_FilterModule():
    split_url('http://localhost:8080/path/to/a/resource?query=string#fragment')
    split_url('http://localhost:8080/path/to/a/resource?query=string#fragment', 'scheme')
    split_url('http://localhost:8080/path/to/a/resource?query=string#fragment', 'netloc')
    split_url('http://localhost:8080/path/to/a/resource?query=string#fragment', 'path')
    split_url('http://localhost:8080/path/to/a/resource?query=string#fragment', 'query')
    split_url('http://localhost:8080/path/to/a/resource?query=string#fragment', 'fragment')

# Generated at 2022-06-23 10:26:21.725246
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    local_urlsplit = split_url('https://localhost.local.lan/foo/bar?test=test2', 'query')
    assert local_urlsplit == 'test=test2'

# vim: set et ts=4 sw=4

# Generated at 2022-06-23 10:26:23.260966
# Unit test for constructor of class FilterModule
def test_FilterModule():
	assert callable(FilterModule)

# Generated at 2022-06-23 10:26:35.035469
# Unit test for function split_url
def test_split_url():
    url = 'https://ansible.com/index.html?x=1&y=2'
    result = split_url(url)
    assert result['netloc'] == 'ansible.com'
    assert result['scheme'] == 'https'
    assert result['path'] == '/index.html'
    assert result['params'] == ''
    assert result['fragment'] == ''
    assert result['query'] == 'x=1&y=2'

    result = split_url(url, 'netloc')
    assert result == 'ansible.com'

    result = split_url(url, 'query')
    assert result == 'x=1&y=2'

    result = split_url(url, 'port')
    assert result == ''

    result = split_url(url, 'fragment')

# Generated at 2022-06-23 10:26:39.528077
# Unit test for constructor of class FilterModule
def test_FilterModule():

    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}
    assert fm.filters().get('urlsplit') == split_url


# Generated at 2022-06-23 10:26:41.350416
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:26:44.671146
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter = FilterModule()
    assert filter is not None
    assert filter.filters is not None
    assert 'urlsplit' in filter.filters
    assert filter.filters['urlsplit'] is not None


# Generated at 2022-06-23 10:26:58.431021
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('https://www.example.com/a/b/c?x=1&y=2', 'scheme') == 'https'
    assert split_url('https://www.example.com/a/b/c?x=1&y=2', 'netloc') == 'www.example.com'
    assert split_url('https://www.example.com/a/b/c?x=1&y=2', 'path') == '/a/b/c'
    assert split_url('https://www.example.com/a/b/c?x=1&y=2', 'query') == 'x=1&y=2'
    assert split_url('https://www.example.com/a/b/c?x=1&y=2', 'fragment') == ''

# Unit

# Generated at 2022-06-23 10:27:04.254625
# Unit test for function split_url
def test_split_url():
    payload = "http://www.example.com:80/path?arg=value#fragmeent"
    assert split_url(payload) == {
        'scheme': 'http',
        'netloc': 'www.example.com:80',
        'path': '/path',
        'query': 'arg=value',
        'fragment': 'fragmeent'
    }
    assert split_url(payload, query='scheme') == 'http'
    assert split_url(payload, query='netloc') == 'www.example.com:80'
    assert split_url(payload, query='path') == '/path'
    assert split_url(payload, query='query') == 'arg=value'

# Generated at 2022-06-23 10:27:05.026802
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:27:15.294440
# Unit test for function split_url
def test_split_url():

    test_data = [
        ("https://www.google.com/cat/6?p=1", "scheme", "https"),
        ("https://www.google.com/cat/6?p=1", "netloc", "www.google.com"),
        ("https://www.google.com/cat/6?p=1", "path", "/cat/6"),
        ("https://www.google.com/cat/6?p=1", "query", "p=1"),
        ("https://www.google.com/cat/6?p=1", "fragment", ""),
    ]

    for test in test_data:
        print(test[0])
        assert(split_url(test[0])[test[1]] == test[2])

# Generated at 2022-06-23 10:27:16.513489
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:27:23.610622
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    _test = FilterModule()
    _testInput = "http://www.google.com/search?q=foo#link1"
    _testOutput = {'path': '/search', 'fragment': 'link1', 'hostname': 'www.google.com', 'query': 'q=foo', 'scheme': 'http', 'netloc': 'www.google.com'}
    assert split_url(_testInput) == _testOutput
    assert split_url(_testInput, query='query') == 'q=foo'
    assert split_url(_testInput, query='foo') == 'q=foo'


# Generated at 2022-06-23 10:27:27.394120
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    for s in ['http://www.baidu.com/index.html;user?id=5#comment']:
        assert('netloc' in f.filters()['urlsplit'](s)) is True

# Generated at 2022-06-23 10:27:37.860608
# Unit test for function split_url
def test_split_url():
    url = "http://user:pass@example.com:80/test?arg=1"

    parts = split_url(url)
    assert parts['scheme'] == 'http'
    assert parts['username'] == 'user'
    assert parts['password'] == 'pass'
    assert parts['hostname'] == 'example.com'
    assert parts['port'] == '80'
    assert parts['query'] == 'arg=1'
    assert parts['path'] == '/test'
    assert parts['fragment'] == ''
    assert split_url(url, 'username') == 'user'

    # test default alias
    parts = split_url(url, alias='urlsplit')
    assert parts['scheme'] == 'http'

    # test some bogus params
    bad_url = 'not a url'

# Generated at 2022-06-23 10:27:43.058586
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule().filters()
    assert f['urlsplit']('http://www.example.com/foo/bar') == {'fragment': '', 'path': '/foo/bar', 'netloc': 'www.example.com', 'query': '', 'scheme': 'http'}

# Generated at 2022-06-23 10:27:43.844706
# Unit test for constructor of class FilterModule
def test_FilterModule():
    return FilterModule()

# Generated at 2022-06-23 10:27:51.364338
# Unit test for function split_url
def test_split_url():
    ''' Test split_url, verify that it returns the expected values. '''

    # Test valid URIs,
    uri = 'http://username:password@www.example.com:80/path/to/page?query=string&other=params&season=all#anchor'

    results = {
        'netloc': 'username:password@www.example.com:80',
        'path': '/path/to/page',
        'query': 'query=string&other=params&season=all',
        'fragment': 'anchor',
        'scheme': 'http',
        'hostname': 'www.example.com',
        'port': '80',
        'username': 'username',
        'password': 'password',
    }

    # Verify that the entire URI is parsed correctly.
    assert split_url

# Generated at 2022-06-23 10:27:59.018143
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    format of test is the following:
    - test using a filter name
    - test using a filter alias
    - test useing a filter method
    - test using an invalid filter

    """

    # test that a filter returns a value
    def test_return(filter_name, filter_value, test_value):
        res = split_url(filter_value, query=filter_name)
        assert res == test_value

    # test that a filter raises an AnsibleFilterError exception
    def test_error(filter_name, filter_value):
        try:
            split_url(filter_value, query=filter_name)
        except AnsibleFilterError:
            pass
        else:
            print("test_error: ")

    test_return('scheme', 'https://docs.ansible.com', 'https')


# Generated at 2022-06-23 10:28:05.067928
# Unit test for function split_url
def test_split_url():
    # Example of an urlsplit result
    expected_split_url_result = {
        'scheme': '',
        'netloc': '',
        'path': '/home/lars',
        'query': '',
        'fragment': ''
    }

    split_url_result = split_url('/home/lars')
    assert split_url_result == expected_split_url_result

# Generated at 2022-06-23 10:28:14.440846
# Unit test for function split_url
def test_split_url():
    ''' unit test for split_url '''

    # Test with a valid input and output
    function_input = 'http://www.w3schools.com/html/html_examples.asp'
    expected_output = {'hostname': 'www.w3schools.com', 'netloc': 'www.w3schools.com', 'path': '/html/html_examples.asp',
                       'port': None, 'query': '', 'scheme': 'http', 'username': None, 'fragment': '',
                       'password': None}
    assert split_url(function_input) == expected_output

    # Test with a query to validate
    function_input_with_query = 'http://www.w3schools.com/html/html_examples.asp'

# Generated at 2022-06-23 10:28:16.453764
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(None) == {'urlsplit': split_url}


# Generated at 2022-06-23 10:28:23.700232
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('http://www.example.com:80/path?a=x#here', query='scheme') == 'http'
    assert split_url('http://www.example.com:80/path?a=x#here', query='netloc') == 'www.example.com:80'
    assert split_url('http://www.example.com:80/path?a=x#here', query='path') == '/path'
    assert split_url('http://www.example.com:80/path?a=x#here', query='query') == 'a=x'
    assert split_url('http://www.example.com:80/path?a=x#here', query='fragment') == 'here'

# Generated at 2022-06-23 10:28:34.050433
# Unit test for function split_url
def test_split_url():
    assert split_url('https://host.com/path/')['scheme'] == 'https'
    assert split_url('https://host.com/path/')['netloc'] == 'host.com'
    assert split_url('https://host.com/path/')['path'] == '/path/'
    assert split_url('https://host.com/path/')['query'] == ''
    assert split_url('https://host.com/path/')['fragment'] == ''
    assert split_url('https://host.com/path/', 'query') == ''
    assert split_url('https://host.com/path/?foo=bar')['query'] == 'foo=bar'
    assert split_url('https://host.com/path/?foo=bar')['path'] == '/path/'
    assert split_url

# Generated at 2022-06-23 10:28:36.797676
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.ansible.com/')['scheme'] == 'https'
    assert split_url('https://www.ansible.com/', 'scheme') == 'https'
    assert split_url('https://www.ansible.com/', 'invalid') == 'urlsplit: unknown URL component: invalid'

# Generated at 2022-06-23 10:28:47.642711
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    parameter_list = [
        'http://www.example.com',
        'http://www.example.com/foo/bar',
        'http://www.example.com:8080',
        'http://www.example.com:8080/foo/bar',
        'https://www.example.com',
        'https://www.example.com/foo/bar',
        'https://www.example.com:8080',
        'https://www.example.com:8080/foo/bar',
        'https://www.example.com/foo/bar?key=value',
    ]


# Generated at 2022-06-23 10:28:48.995116
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert 'urlsplit' in module.filters()


# Generated at 2022-06-23 10:28:51.184464
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:28:52.708079
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:28:53.983072
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()

# Generated at 2022-06-23 10:28:54.882732
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule


# Generated at 2022-06-23 10:28:55.706593
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)


# Generated at 2022-06-23 10:28:56.921177
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:29:08.363579
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  uri_in_path = '/foo/bar'
  uri_in_qs = '?baz=qux'
  uri_in_frag = '#frag'
  uri_in_creds = 'user:passwd@example.com'
  uri_in_creds_path = 'user:passwd@example.com/foo/bar'
  uri_in_creds_qs = 'user:passwd@example.com?baz=qux'
  uri_in_creds_frag = 'user:passwd@example.com#frag'
  uri_in_creds_qs_frag = 'user:passwd@example.com?baz=qux#frag'

  fm = FilterModule()

# Generated at 2022-06-23 10:29:09.549991
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:29:11.298138
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'urlsplit' in filter_module.filters().keys()


# Generated at 2022-06-23 10:29:12.283077
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """Test the constructor of FilterModule."""
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-23 10:29:18.043903
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:29:20.052717
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()


# Generated at 2022-06-23 10:29:21.880656
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'urlsplit' in filter_module.filters()

# Generated at 2022-06-23 10:29:28.174523
# Unit test for function split_url
def test_split_url():
    assert split_url('http://example.com/path/to/foo?query=value#fragment') == {
        'fragment': 'fragment',
        'netloc': 'example.com',
        'path': '/path/to/foo',
        'query': 'query=value',
        'scheme': 'http',
    }

# Generated at 2022-06-23 10:29:38.203028
# Unit test for function split_url
def test_split_url():
    from ansible.release import __version__
    from ansible.utils.version import StrictVersion

    ansible_version = StrictVersion(__version__)

    url = 'https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/facts/system/distribution.py'
    expected = {
        'scheme': 'https',
        'netloc': 'github.com',
        'path': '/ansible/ansible/blob/devel/lib/ansible/module_utils/facts/system/distribution.py',
        'params': '',
        'query': '',
        'fragment': ''
    }

    if ansible_version >= StrictVersion('2.6'):
        expected['username'] = ''
        expected['password'] = ''



# Generated at 2022-06-23 10:29:40.426002
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:29:43.056826
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert(fm.filters()['urlsplit'] == split_url)


# Generated at 2022-06-23 10:29:44.754586
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule) == {'urlsplit': split_url}

# Generated at 2022-06-23 10:29:47.312381
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    Test FilterModule constructor.
    """
    filters = FilterModule()
    assert filters.filters() is not None


# Generated at 2022-06-23 10:29:49.244738
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:29:50.677960
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert callable(FilterModule.filters)


# Generated at 2022-06-23 10:29:54.687729
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:29:57.473865
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test for filters
    fn = FilterModule()
    assert fn.filters() == {
        'urlsplit': split_url
    }

# Generated at 2022-06-23 10:30:05.135221
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule().filters()
    actual = f['urlsplit']('http://www.example.com:8080/foo?bar=1#abc')
    expected = {'path': '/foo', 'fragment': 'abc', 'scheme': 'http', 'netloc': 'www.example.com:8080', 'query': 'bar=1'}
    assert actual == expected

    actual = f['urlsplit']('http://www.example.com:8080/foo?bar=1#abc', 'scheme')
    expected = 'http'
    assert actual == expected

    actual = f['urlsplit']('http://www.example.com:8080/foo?bar=1#abc', 'query')
    expected = 'bar=1'
    assert actual == expected


# Generated at 2022-06-23 10:30:07.045828
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

# Generated at 2022-06-23 10:30:09.333558
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:30:10.243078
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters['urlsplit'] is not None

# Generated at 2022-06-23 10:30:19.031138
# Unit test for function split_url
def test_split_url():
    test_url_1 = 'http://www.example.com:8080/path'
    test_url_2 = 'http://username:password@localhost/path?arg=value#anchor'

    # Test values and corresponding keys
    test_values = {
        'scheme': 'http',
        'netloc': 'username:password@localhost',
        'path': '/path',
        'query': 'arg=value',
        'fragment': 'anchor',
        'username': 'username',
        'password': 'password',
        'hostname': 'localhost',
        'port': None,
        'query_params': 'arg=value',
        'query_dict': {'arg': 'value'},
    }

    # Testing the first url
    for key, value in test_values.items():
        assert split

# Generated at 2022-06-23 10:30:30.864328
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert split_url('http://www.example.org/path;param?query=arg#frag') == {'scheme': 'http', 'netloc': 'www.example.org', 'path': '/path;param', 'query': 'query=arg', 'fragment': 'frag', 'username': None, 'password': None, 'hostname': 'www.example.org', 'port': None}

# Generated at 2022-06-23 10:30:33.951260
# Unit test for function split_url
def test_split_url():
    url = 'https://docs.python.org:80/3/library/urllib.parse.html#urlsplit-objects'
    expected = {
        'scheme': 'https',
        'netloc': 'docs.python.org:80',
        'path': '/3/library/urllib.parse.html',
        'query': '',
        'fragment': 'urlsplit-objects'
    }
    
    assert split_url(url) == expected

# Generated at 2022-06-23 10:30:35.073508
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None



# Generated at 2022-06-23 10:30:37.211011
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert 'urlsplit' in FilterModule().filters()


# Generated at 2022-06-23 10:30:39.811541
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] is split_url

# Generated at 2022-06-23 10:30:50.023160
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils import basic

    def urlsplit_data(url, query, alias, result):
        try:
            ret_val = split_url(url, query, alias)
            if ret_val != result:
                raise Exception()
        except Exception as e:
            print(url, query, alias, result, '=>', ret_val)
            raise e

    # url, query, alias, result
    urlsplit_data('http://localhost/', 'scheme', 'split_url', 'http')
    urlsplit_data('http://localhost/', 'netloc', 'split_url', 'localhost')
    urlsplit_data('http://localhost/', 'path', 'split_url', '/')

# Generated at 2022-06-23 10:30:59.854660
# Unit test for function split_url
def test_split_url():

    # Test invalid URL
    results = split_url("http://www.google.com:8080/search?q=foo&bar=baz#frag")
    assert results == {'netloc': 'www.google.com:8080', 'path': '/search', 'scheme': 'http', 'qs': 'q=foo&bar=baz', 'fragment': 'frag'}

    # Test invalid option
    results = split_url("http://www.google.com:8080/search?q=foo&bar=baz#frag", "fubar")
    assert "unknown URL component" in results

# Generated at 2022-06-23 10:31:01.754450
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:31:07.336000
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.cwi.nl:80/%7Eguido/Python.html') == {
        'fragment': '',
        'netloc': 'www.cwi.nl:80',
        'path': '/%7Eguido/Python.html',
        'query': '',
        'scheme': 'http'
    }

    assert split_url('http://www.cwi.nl:80/%7Eguido/Python.html', 'scheme') == 'http'

# Generated at 2022-06-23 10:31:13.387079
# Unit test for function split_url
def test_split_url():
    results = split_url('http://10.20.30.40:80/path/to/resource?id=1&num=2')
    assert results['scheme'] == 'http'
    assert results['netloc'] == '10.20.30.40:80'
    assert results['path'] == '/path/to/resource'
    assert results['query'] == 'id=1&num=2'
    assert results['fragment'] == ''

    assert split_url('https://username:password@example.com:443/path/to/?q=querystring#fragment', 'scheme') == 'https'
    assert split_url('https://username:password@example.com:443/path/to/?q=querystring#fragment', 'username') == 'username'

# Generated at 2022-06-23 10:31:14.876702
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    mod = FilterModule()
    x = mod.filters()
    assert x is not None

# Generated at 2022-06-23 10:31:16.468012
# Unit test for constructor of class FilterModule
def test_FilterModule():
    result = FilterModule()
    assert result is not None


# Generated at 2022-06-23 10:31:23.223866
# Unit test for function split_url
def test_split_url():

    value = 'https://user:password@www.example.com:443/path;parameters?query=arguments#fragment'

    result = split_url(value, 'scheme')
    assert result == 'https'

    result = split_url(value)
    assert result == {
        'scheme': 'https',
        'query': 'query=arguments',
        'fragment': 'fragment',
        'netloc': 'user:password@www.example.com:443',
        'path': '/path;parameters',
        'params': 'parameters'
    }

# Generated at 2022-06-23 10:31:28.918844
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.ansible.com/index.html?arg1=value1&arg2=value2') == {
        'scheme': 'http',
        'netloc': 'www.ansible.com',
        'path': '/index.html',
        'query': 'arg1=value1&arg2=value2',
        'fragment': ''
    }
    assert split_url('http://www.ansible.com/index.html?arg1=value1&arg2=value2', 'scheme') == 'http'


# Generated at 2022-06-23 10:31:35.924028
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test with check query value
    assert split_url('http://github.com/ansible/ansible/issues/3309', query='scheme') == 'http'
    assert split_url('http://github.com/ansible/ansible/issues/3309', query='netloc') == 'github.com'
    assert split_url('http://github.com/ansible/ansible/issues/3309', query='path') == '/ansible/ansible/issues/3309'
    assert split_url('http://github.com/ansible/ansible/issues/3309', query='query') == ''
    assert split_url('http://github.com/ansible/ansible/issues/3309', query='fragment') == ''

    # Test with no query value

# Generated at 2022-06-23 10:31:46.765384
# Unit test for function split_url
def test_split_url():
    import ansible_module_uri
    assert ansible_module_uri.split_url('http://www.example.net/path/to/page.php?param1=1¶m2=2', 'query') == 'param1=1¶m2=2'
    assert ansible_module_uri.split_url('http://www.example.net/path/to/page.php', 'path') == '/path/to/page.php'
    assert ansible_module_uri.split_url('http://www.example.net/path/to/page.php', 'scheme') == 'http'
    assert ansible_module_uri.split_url('http://www.example.net/path/to/page.php', 'netloc') == 'www.example.net'
    assert ansible_module_uri.split_url

# Generated at 2022-06-23 10:31:48.943237
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    urlfilter = FilterModule()
    assert urlfilter.filters()['urlsplit'].__name__ == 'split_url'

# Generated at 2022-06-23 10:31:50.143962
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fmodule = FilterModule()
    fmodule.filters()

# Generated at 2022-06-23 10:31:51.629884
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == dict(
        urlsplit=split_url
    )

# Generated at 2022-06-23 10:31:53.184667
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test a simple case
    fm = FilterModule()
    assert fm

# Generated at 2022-06-23 10:31:56.721710
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urlsplit'] == split_url
    assert 'urlsplit' in f.filters()

# Generated at 2022-06-23 10:31:57.733643
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter = FilterModule()
    assert filter

# Generated at 2022-06-23 10:31:59.412278
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:32:08.383838
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert split_url("https://docs.python.org/3/tutorial/inputoutput.html#reading-and-writing-files", "scheme") == "https"
    assert split_url("https://docs.python.org/3/tutorial/inputoutput.html#reading-and-writing-files", "netloc") == "docs.python.org"
    assert split_url("https://docs.python.org/3/tutorial/inputoutput.html#reading-and-writing-files", "path") == "/3/tutorial/inputoutput.html"
    assert split_url("https://docs.python.org/3/tutorial/inputoutput.html#reading-and-writing-files", "fragment") == "reading-and-writing-files"

# Generated at 2022-06-23 10:32:11.897669
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:32:13.563189
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule) == {'urlsplit': split_url}

# Generated at 2022-06-23 10:32:22.944256
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url("http://docs.ansible.com/ansible/latest/urlsplit.html", "scheme") == "http"
    assert split_url("http://docs.ansible.com/ansible/latest/urlsplit.html", "hostname") == "docs.ansible.com"
    assert split_url("http://docs.ansible.com/ansible/latest/urlsplit.html", "query") == ""
    assert split_url("ssh://hg@bitbucket.org/ansible/ansible", "port") == ""
    assert split_url("https://docs.ansible.com/ansible/latest/urlsplit.html", "fragment") == ""
    assert split_url("https://192.168.0.1:8080/test/", "path") == "/test/"
    assert split

# Generated at 2022-06-23 10:32:26.119510
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:32:27.750473
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module

# Generated at 2022-06-23 10:32:29.749357
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert obj.filters()['urlsplit'] == split_url



# Generated at 2022-06-23 10:32:30.698775
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)

# Generated at 2022-06-23 10:32:33.228616
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] == split_url



# Generated at 2022-06-23 10:32:34.492626
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
        'urlsplit': split_url
    }

# Generated at 2022-06-23 10:32:43.740215
# Unit test for function split_url
def test_split_url():
    assert split_url("http://ansible.com:8080/path/to/file?query1&query2#fragment") == {
        "scheme": "http",
        "netloc": "ansible.com:8080",
        "path": "/path/to/file",
        "query": "query1&query2",
        "fragment": "fragment"}
    assert split_url("http://www.ansible.com:8080/path/to/file") == {
        "scheme": "http",
        "netloc": "www.ansible.com:8080",
        "path": "/path/to/file",
        "query": "",
        "fragment": ""}

# Generated at 2022-06-23 10:32:44.410712
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:32:45.141799
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:32:47.314953
# Unit test for constructor of class FilterModule
def test_FilterModule():
    my_db_class_obj = FilterModule()
    assert my_db_class_obj.filters()['urlsplit'] is not None



# Generated at 2022-06-23 10:32:54.552811
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # urlsplit
    assert split_url('foo') == {'scheme': '', 'netloc': '', 'path': 'foo', 'query': '', 'fragment': ''}
    assert split_url('http://www.example.com/path?key=val#frag') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path',
        'query': 'key=val',
        'fragment': 'frag'
    }
    assert split_url('http://www.example.com/path?key=val#frag', query='scheme') == 'http'
    assert split_url('http://www.example.com/path?key=val#frag', query='netloc') == 'www.example.com'
   

# Generated at 2022-06-23 10:32:55.688681
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(callable(FilterModule))


# Generated at 2022-06-23 10:33:06.679861
# Unit test for function split_url

# Generated at 2022-06-23 10:33:17.344059
# Unit test for function split_url
def test_split_url():
    args = 'http://192.168.1.1:8080/path?key=value#anchor'

    # Check to see if all fields have been returned
    expected = {'scheme': 'http', 'netloc': '192.168.1.1:8080', 'path': '/path', 'query': 'key=value',
                'fragment': 'anchor'}
    actual = split_url(args)
    assert actual == expected, "Split url dict does not match the expected dict"

    # Check to see if specific fields have been returned
    assert actual['netloc'] == '192.168.1.1:8080', "Netloc does not match the expected value"
    assert actual['fragment'] == 'anchor', "Fragment does not match the expected value"

    # Check to see if the kwarg returns

# Generated at 2022-06-23 10:33:18.989990
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters() is not None


# Generated at 2022-06-23 10:33:26.357682
# Unit test for function split_url
def test_split_url():

    test_object = split_url('https://user:pass@example.com:443/path?foo=bar&test=test')

    expected_result = {
        'fragment': '',
        'hostname': 'example.com',
        'netloc': 'user:pass@example.com:443',
        'password': 'pass',
        'path': '/path',
        'port': 443,
        'query': 'foo=bar&test=test',
        'query_dict': {
            'foo': 'bar',
            'test': 'test'
        },
        'scheme': 'https',
        'username': 'user'
    }

    assert test_object == expected_result, "Expected %s, got %s" % (expected_result, test_object)



# Generated at 2022-06-23 10:33:32.754050
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for method filters of class FilterModule '''

    # Create a FilterModule object
    fm = FilterModule()

    # Call method filters on this object
    filters = fm.filters()

    # Check if the returned value is a dictionary
    assert isinstance(filters, dict)

    # Check if the returned dictionary has the 'urlsplit' key
    assert 'urlsplit' in filters


# Generated at 2022-06-23 10:33:33.579386
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:33:45.164049
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils.six import StringIO

    # URL for testing
    test_url = 'http://someuser:somepassword@somedomain.com:8080/somepath?key1=value1&key2=value2#ANCHOR'

    # Valid inputs

# Generated at 2022-06-23 10:33:51.838359
# Unit test for function split_url
def test_split_url():
    test_urls = [
        'https://www.google.com:443/test/test2/test3?test4=test5&test6=test7#test8',
        'https://username:password@www.google.com/test/test2/test3?test4=test5&test6=test7#test8',
        'https://www.google.com/test/test2/test3?test4=test5&test6=test7#test8',
        'https://www.google.com',
        'https://www.google.com/test/test2',
    ]


# Generated at 2022-06-23 10:34:02.699958
# Unit test for function split_url
def test_split_url():
    test_url = "http://www.example.com/path/to/resource?param1=123&param2=abc"
    test_scheme = "http"
    test_netloc = "www.example.com"
    test_path = "/path/to/resource"
    test_params = ""
    test_qrystr = "param1=123&param2=abc"
    test_fragment = ""

    # Test with query set to a known field.
    assert(split_url(test_url, query="scheme") == test_scheme)
    assert(split_url(test_url, query="netloc") == test_netloc)
    assert(split_url(test_url, query="path") == test_path)

# Generated at 2022-06-23 10:34:03.939326
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None

# Generated at 2022-06-23 10:34:05.729703
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_module = FilterModule()
    assert test_module.filters()['urlsplit'] is not None


# Generated at 2022-06-23 10:34:07.858633
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert filters['urlsplit'] is split_url


# Generated at 2022-06-23 10:34:09.582657
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert isinstance(fm, object)
    assert 'urlsplit' in fm.filters()



# Generated at 2022-06-23 10:34:10.372041
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-23 10:34:13.000041
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    filters = obj.filters()
    assert filters != None
    assert filters['urlsplit'] == split_url


# Generated at 2022-06-23 10:34:23.650568
# Unit test for function split_url
def test_split_url():
    # Expected results
    netloc = 'hostname.com'
    path = '/path/to'
    scheme = 'http'
    query = 'arg1=val1&arg2=val2'

    # Unit tests for the scheme, query and path keys
    assert(split_url('http://hostname.com:80/path?arg1=val1&arg2=val2', 'scheme') == scheme)
    assert(split_url('http://hostname.com:80/path?arg1=val1&arg2=val2', 'query') == query)
    assert(split_url('http://hostname.com:80/path?arg1=val1&arg2=val2', 'path') == path)

    # Unit test for the port value

# Generated at 2022-06-23 10:34:26.842231
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:34:28.805259
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == { 'urlsplit': split_url }

# Generated at 2022-06-23 10:34:30.156673
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:34:31.479509
# Unit test for constructor of class FilterModule
def test_FilterModule():
    a = FilterModule()
    assert a



# Generated at 2022-06-23 10:34:33.458776
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    Filter = FilterModule()
    assert Filter.filters() is not None
    assert Filter.filters().get('urlsplit') is not None


# Generated at 2022-06-23 10:34:48.165397
# Unit test for function split_url
def test_split_url():
    if __name__ == '__main__':
        url = 'http://user:password@github.com:80/ansible/ansible/issues?state=open&milestone=5'
        split_url(url, 'hostname')


# Unit test to be run with the ansible-test command
# It can be run with the following command:
#  ansible-test units --python-version 3.6 uri.py
#  ansible-test units --python-version 3.4 uri.py
# It can be run from a checkout of ansibullbot/ansibullbot/ with:
#  ansible-test units --python-version 3.6 uri.py
#  ansible-test units --python-version 3.4 uri.py

# Generated at 2022-06-23 10:34:48.698190
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-23 10:34:50.962149
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Create an object of class FilterModule using the constructor
    test_obj = FilterModule()

    # Check if object is of class FilterModule
    assert(isinstance(test_obj, FilterModule))

# Generated at 2022-06-23 10:34:54.855167
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert split_url('http://www.example.com/path?q=search#some-fragment', 'scheme') == 'http'
    assert filter_module.filters()['urlsplit']('http://www.example.com/path?q=search#some-fragment', 'scheme') == 'http'

# Generated at 2022-06-23 10:35:06.545103
# Unit test for function split_url
def test_split_url():
    ''' Test split_url function '''

    url = 'http://localhost:8080/path/to/file?query=string'
    url_dict = {'scheme': 'http', 'netloc': 'localhost:8080', 'path': '/path/to/file', 'query': 'query=string'}

    # if no parameters, return dictionary
    assert split_url(url) == url_dict

    # if query, return string
    assert split_url(url, 'scheme') == 'http'
    assert split_url(url, 'netloc') == 'localhost:8080'
    assert split_url(url, 'path') == '/path/to/file'
    assert split_url(url, 'query') == 'query=string'

    # if invalid query, raise error

# Generated at 2022-06-23 10:35:14.872268
# Unit test for function split_url
def test_split_url():
    url = 'http://docs.ansible.com/ansible/latest/intro.html'
    test_dict = {
        'scheme': 'http',
        'netloc': 'docs.ansible.com',
        'path': '/ansible/latest/intro.html',
        'params': '',
        'query': '',
        'fragment': ''
    }

    assert split_url(url) == test_dict
    assert split_url(url, 'netloc') == 'docs.ansible.com'
    assert split_url(url, 'hostname') == 'docs.ansible.com'
    assert split_url(url, 'scheme') == 'http'

# Generated at 2022-06-23 10:35:26.395842
# Unit test for function split_url
def test_split_url():

    url = 'https://user:pass@host.com:3128/path/to/file;param?query=arg#fragment'

    result = split_url(url)
    r1 = {'netloc': 'user:pass@host.com:3128', 'path': '/path/to/file;param', 'fragment': 'fragment', 'scheme': 'https', 'query': 'query=arg', 'username': 'user', 'password': 'pass', 'hostname': 'host.com', 'port': '3128'}

    assert result == r1

    result = split_url(url, 'query')
    r2 = 'query=arg'
    assert result == r2

    # make sure it fails if called with a bogus option

# Generated at 2022-06-23 10:35:28.967536
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urlsplit' in filters
    assert filters['urlsplit'] == split_url


# Generated at 2022-06-23 10:35:32.057292
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert 'urlsplit' == FilterModule().filters()['urlsplit'](None)

## Unit test for constructor of class split_url

# Generated at 2022-06-23 10:35:33.902556
# Unit test for constructor of class FilterModule
def test_FilterModule():
    Filters = FilterModule()
    assert Filters.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:35:36.312569
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Setup input parameters
    value = 'https://docs.ansible.com/devel/foo.html'

# Generated at 2022-06-23 10:35:38.096144
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert hasattr(f, 'filters')


# Generated at 2022-06-23 10:35:41.767203
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filterModule = FilterModule()
    assert filterModule != None, "Failed to instantiate FilterModule"
    assert filterModule.filters != None, "No filter defined"
    assert filterModule.filters().get('urlsplit') != None, "urlsplit filter missing"


# Generated at 2022-06-23 10:35:45.268850
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')
    assert callable(FilterModule.filters)



# Generated at 2022-06-23 10:35:55.473020
# Unit test for function split_url
def test_split_url():
    function = split_url()
    assert function('https://www.myawesomewebsite.com:8080/search?q=ansible+filters#anchor') == {
            'scheme': 'https',
            'hostname': 'www.myawesomewebsite.com',
            'port': '8080',
            'path': '/search',
            'query': 'q=ansible+filters',
            'fragment': 'anchor'
        }
    assert function('http://www.mydomain.com/some/deep/path') == {
            'scheme': 'http',
            'hostname': 'www.mydomain.com',
            'port': None,
            'path': '/some/deep/path',
            'query': None,
            'fragment': None
        }

# Generated at 2022-06-23 10:36:04.393934
# Unit test for function split_url
def test_split_url():
    assert split_url('https://plone.com/foo/bar') == {'hostname': 'plone.com', 'netloc': 'plone.com', 'path': '/foo/bar', 'scheme': 'https', 'query': '', 'fragment': ''}
    assert split_url('https://plone.com/foo/bar', query='scheme') == 'https'
    assert split_url('https://plone.com/foo/bar?query=bar', query='query') == 'query=bar'
    assert split_url('https://plone.com/foo/bar#fragment', query='fragment') == 'fragment'

# Generated at 2022-06-23 10:36:05.264541
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module

# Generated at 2022-06-23 10:36:08.074394
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    data = {
        'urlsplit': split_url
    }
    fm = FilterModule()
    assert fm.filters() == data
