

# Generated at 2022-06-23 10:26:11.385770
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    o = FilterModule()
    assert o.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:26:13.699165
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_obj = FilterModule()
    assert filter_obj.filters()['urlsplit'] == split_url 


# Generated at 2022-06-23 10:26:21.916982
# Unit test for function split_url
def test_split_url():
    import json

    # Build a test dictionary with all of the possible keys
    test_dict = {
        'path': 'this/is/a/test',
        'scheme': 'http',
        'parameters': '',
        'query': '',
        'username': 'rick',
        'hostname': 'rick.com',
        'password': '',
        'port': '',
        'fragment': ''
    }

    # Build the URL from the dictionary in the format that it will be supplied
    # to the filter.
    test_url = '{scheme}://{username}:{password}@{hostname}:{port}/{path}?{query}#{fragment}'.format(**test_dict)

    # Create the split_url object
    surl = split_url(test_url)

# Generated at 2022-06-23 10:26:25.132310
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_FilterModule = FilterModule()

    assert test_FilterModule.filters().get('urlsplit') is not None



# Generated at 2022-06-23 10:26:27.844519
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urlsplit' in filters

# Generated at 2022-06-23 10:26:36.820431
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Arrange
    fm = FilterModule()
    url = "http://example.com?p1=v1#anchor"

    # Act
    actual = fm.filters()

    # Assert
    assert actual is not None
    actual_split_url = actual["urlsplit"]
    assert actual_split_url is not None

    assert actual_split_url(url)["scheme"] == "http"
    assert actual_split_url(url)["netloc"] == "example.com"
    assert actual_split_url(url, "scheme") == "http"
    assert actual_split_url(url, "netloc") == "example.com"
    assert actual_split_url(url, "query") == "p1=v1"

# Generated at 2022-06-23 10:26:44.461333
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    data = 'https://docs.ansible.com:8080/user_guide/playbooks_filters.html?var1=one&var2=two#fragment'
    assert FilterModule.filters(data)['urlsplit']('http://docs.ansible.com/playbooks_filters.html') == {'path': '/playbooks_filters.html', 'netloc': 'docs.ansible.com', 'scheme': 'http', 'params': '', 'query': '', 'fragment': ''}

# Generated at 2022-06-23 10:26:50.981554
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert 'split_url' in obj.filters().keys()
    assert obj.filters()['split_url'] is split_url


# Generated at 2022-06-23 10:26:53.200530
# Unit test for constructor of class FilterModule
def test_FilterModule():
    a = FilterModule()
    assert a.filters()['urlsplit']

# UnitTest for helper function object_to_dict

# Generated at 2022-06-23 10:27:00.916511
# Unit test for constructor of class FilterModule
def test_FilterModule():

    url = "http://www.example.com:80/path/here;param?key=value#anchor"
    urls = "https://www.example.com:443/path/here;param?key=value#anchor"
    url_filter = FilterModule()

    url_result = url_filter.filters()['urlsplit'].__call__(url, 'netloc')
    assert url_result == "www.example.com:80", "urlsplit failure"

    urls_result = url_filter.filters()['urlsplit'].__call__(urls, 'scheme')
    assert urls_result == "https", "urlsplit failure"

# Generated at 2022-06-23 10:27:13.117137
# Unit test for function split_url
def test_split_url():
    ''' test_split_url '''

    assert split_url('https://www.google.com/test?foo=bar') == {'scheme': 'https', 'netloc': 'www.google.com', 'path': '/test', 'query': 'foo=bar', 'fragment': ''}
    assert split_url('https://www.google.com:8080/test?foo=bar#frag') == {'scheme': 'https', 'netloc': 'www.google.com:8080', 'path': '/test', 'query': 'foo=bar', 'fragment': 'frag'}
    assert split_url('https://www.google.com:8080/test?foo=bar#frag', 'scheme') == 'https'

# Generated at 2022-06-23 10:27:23.241848
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    # Good uses cases
    # Note: To maintain consistency with urlsplit, the query portion is returned
    # as the whole string starting with the ?, if supplied.
    assert fm.filters()['urlsplit']('https://foo.com/bar/', query='scheme') == 'https'
    assert fm.filters()['urlsplit']('https://foo.com/bar/', query='netloc') == 'foo.com'
    assert fm.filters()['urlsplit']('https://foo.com/bar/', query='path') == '/bar/'
    assert fm.filters()['urlsplit']('https://foo.com/bar/', query='fragment') == ''
    # Test to make sure we return the query string in its entirety.
    assert fm.fil

# Generated at 2022-06-23 10:27:32.954212
# Unit test for function split_url
def test_split_url():
    from ansible import constants as C
    from ansible.plugins.filter.core import FilterModule

    fm = FilterModule()
    filters = fm.filters()

    assert "http://www.example.com/foo/bar?foobar=false#big" == filters['urlsplit']("http://www.example.com/foo/bar?foobar=false#big")
    assert "http" == filters['urlsplit']("http://www.example.com/foo/bar?foobar=false#big",  query="scheme")
    assert "www.example.com" == filters['urlsplit']("http://www.example.com/foo/bar?foobar=false#big", query="netloc")

# Generated at 2022-06-23 10:27:33.725884
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None

# Generated at 2022-06-23 10:27:34.838974
# Unit test for constructor of class FilterModule
def test_FilterModule():
    class_ = FilterModule()
    assert(class_.filters()['urlsplit'] is split_url)

# Generated at 2022-06-23 10:27:37.342685
# Unit test for constructor of class FilterModule
def test_FilterModule():
	f = FilterModule()
	assert isinstance(f, Object)


# Generated at 2022-06-23 10:27:38.772885
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    filters = f.filters()
    assert 'urlsplit' in filters

# Generated at 2022-06-23 10:27:41.705468
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:27:50.065041
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils._text import to_text
    # Test if results are not empty
    v = 'http://user:pass@www.example.com:8080/path?a=1&b=2#frag'
    assert split_url(v)
    assert split_url(v)['scheme'] == 'http'
    assert split_url(v)['netloc'] == 'user:pass@www.example.com:8080'
    assert split_url(v)['path'] == '/path'
    assert split_url(v)['query'] == 'a=1&b=2'
    assert split_url(v)['fragment'] == 'frag'
    assert split_url(v, 'scheme') == 'http'

# Generated at 2022-06-23 10:27:58.487484
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    oFilterModule = FilterScheme()

    # Test with a regular string
    res = oFilterModule.filters()['urlsplit']('http://user:pass@www.example.com:8080/path?a=b&c=d#frag')
    assert res == {
        'fragment': 'frag',
        'hostname': 'www.example.com',
        'netloc': 'user:pass@www.example.com:8080',
        'path': '/path',
        'port': '8080',
        'query': 'a=b&c=d',
        'scheme': 'http',
        'username': 'user'
    }

    # Test with a regular string and a query

# Generated at 2022-06-23 10:27:59.700849
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()


# ---- Ansible filters ----

# Generated at 2022-06-23 10:28:09.249281
# Unit test for function split_url
def test_split_url():
    import pytest
    # Setup test data
    test_url = 'https://user:pass@storage.googleapis.com:443/container/object?foo=bar&baz=qux#fragment'

    # Test happy path, with optional component name
    assert split_url(test_url) == {
        'fragment': 'fragment',
        'netloc': 'user:pass@storage.googleapis.com:443',
        'params': '',
        'path': '/container/object',
        'query': 'foo=bar&baz=qux',
        'scheme': 'https',
        }
    assert split_url(test_url, 'netloc') == 'user:pass@storage.googleapis.com:443'

# Generated at 2022-06-23 10:28:18.908934
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.ansible.com/', 'scheme') == 'http'
    assert split_url('http://www.ansible.com/', 'netloc') == 'www.ansible.com'
    assert split_url('http://www.ansible.com/', 'path') == '/'
    assert split_url('http://www.ansible.com/', 'query') == ''

    assert split_url("http://www.ansible.com/index.php?id=10", 'scheme') == 'http'
    assert split_url("http://www.ansible.com/index.php?id=10", 'netloc') == 'www.ansible.com'

# Generated at 2022-06-23 10:28:20.315509
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert {'urlsplit': split_url} == FilterModule.filters(None)

# Generated at 2022-06-23 10:28:21.897624
# Unit test for constructor of class FilterModule
def test_FilterModule():
  filter_module = FilterModule()
  assert filter_module.filters() == {
            'urlsplit': split_url
        }


# Generated at 2022-06-23 10:28:32.965557
# Unit test for function split_url
def test_split_url():
    # Split a valid URL
    assert split_url("https://www.example.com:8080/path/to/file?query=1") == {'scheme': 'https', 'netloc': 'www.example.com:8080', 'path': '/path/to/file', 'query': 'query=1', 'fragment': ''}
    # Missing path
    assert split_url("https://www.example.com:8080") == {'scheme': 'https', 'netloc': 'www.example.com:8080', 'path': '', 'query': '', 'fragment': ''}
    # Pass an invalid URL

# Generated at 2022-06-23 10:28:35.421367
# Unit test for constructor of class FilterModule
def test_FilterModule():
    data = {
        'path': 'path',
        'query': 'query',
        'scheme': 'scheme',
        'netloc': 'netloc',
        'fragment': 'fragment',
        'params': 'params',
    }
    data = list(data.keys())
    f = FilterModule()
    v = f.filters()

    assert 'urlsplit' in v
    for k in data:
        assert k in v['urlsplit']('', k)

# Generated at 2022-06-23 10:28:39.021793
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert 'urlsplit' in module.filters()


# Generated at 2022-06-23 10:28:41.605090
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    fm = FilterModule()
    result = fm.filters()

    assert result == { "urlsplit": split_url }


# Generated at 2022-06-23 10:28:51.304959
# Unit test for function split_url
def test_split_url():
    # If a query is supplied, make sure it's valid then return the results.
    # If no option is supplied, return the entire dictionary.
    url = 'http://user:pass@www.example.com:8000/path/to/index.html?param=value&param2=value2#frag'
    assert split_url(url) == {'fragment': 'frag', 'netloc': 'user:pass@www.example.com:8000', 'path': '/path/to/index.html', 'query': 'param=value&param2=value2', 'username': 'user', 'password': 'pass', 'scheme': 'http', 'hostname': 'www.example.com', 'port': 8000}
    assert split_url(url, 'scheme') == 'http'

# Generated at 2022-06-23 10:28:58.760994
# Unit test for function split_url
def test_split_url():
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests.mock import Mock

    url_result = Mock(scheme='https', netloc='github.com', path='/ansible/ansible', query='', fragment='',
                      scheme='https', username='', password='', hostname='github.com', port='',
                      geturl='https://github.com/ansible/ansible')

    url = 'https://github.com/ansible/ansible'

    with patch.object(helpers, 'object_to_dict', return_value=url_result):
        result = split_url(url, query='scheme', alias='test_split_url')

    assert result == 'https'

# Generated at 2022-06-23 10:29:03.197937
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert 'urlsplit' in filters
    assert filters['urlsplit'] == split_url

# Unit tests for method split_url of class FilterModule

# Generated at 2022-06-23 10:29:07.093778
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # expected result
    expected = '192.168.7.1'

    # actual result
    result = split_url('ssh://192.168.7.1:22/path/file?query=value', 'hostname')

    # asserts expected == result
    assert result == expected

# Generated at 2022-06-23 10:29:11.944446
# Unit test for constructor of class FilterModule
def test_FilterModule():
    url = 'https://user:password@domain.tld:8080/path;parameters?query=test#fragment'
    result = split_url(url, '')
    assert type(result) is dict



# Generated at 2022-06-23 10:29:14.765791
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Create instance of FilterModule class
    instance = FilterModule()
    assert callable(instance)
    # Call filters function of class FilterModule to test if it returns a dictionary
    assert isinstance(instance.filters(), dict)

# Unit tests for split_url function

# Generated at 2022-06-23 10:29:18.144346
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:29:21.700021
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

    filters = fm.filters()

    assert 'urlsplit' in filters.keys()
    assert filters['urlsplit'] is split_url



# Generated at 2022-06-23 10:29:34.394968
# Unit test for function split_url

# Generated at 2022-06-23 10:29:41.826990
# Unit test for function split_url

# Generated at 2022-06-23 10:29:43.934957
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  assert FilterModule().filters() == {
      'urlsplit': split_url
  }


# Generated at 2022-06-23 10:29:46.574539
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {'urlsplit': split_url }


# Generated at 2022-06-23 10:29:50.377402
# Unit test for function split_url
def test_split_url():
    assert split_url("tcp://127.0.0.1:22", 'netloc') == '127.0.0.1:22'
    assert split_url("tcp://127.0.0.1:22", 'scheme') == 'tcp'

    # Invalid query
    try:
        split_url("tcp://127.0.0.1:22", 'foobar')
        raise Exception("Unexpected success")
    except AnsibleFilterError:
        pass

# Generated at 2022-06-23 10:29:53.390989
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert {} == FilterModule().filters()

# Generated at 2022-06-23 10:29:57.426054
# Unit test for constructor of class FilterModule
def test_FilterModule():
    results = split_url("http://www.example.com")
    assert results['scheme'] == 'http'
    assert results['netloc'] == 'www.example.com'
    assert results['path'] == ''

# Generated at 2022-06-23 10:30:02.590071
# Unit test for function split_url
def test_split_url():

    import inspect
    import doctest
    import textwrap

    results = {}
    for name, obj in inspect.getmembers(split_url):
        if name.startswith('test_'):
            if inspect.isfunction(obj):
                env = {}
                exec(textwrap.dedent(inspect.getsource(obj)), globals(), env)
                obj = env['test_split_url']
            results.update(doctest.testmod(obj))
    assert results['failed'] == 0

# Generated at 2022-06-23 10:30:04.559084
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urlsplit' in filters


# Generated at 2022-06-23 10:30:15.527069
# Unit test for function split_url
def test_split_url():
    url_scheme = 'https'
    url_netloc = 'docs.ansible.com'
    url_path = '/user_guide/intro_inventory.html'
    url_query = ''
    url_fragment = ''
    url = 'https://docs.ansible.com/user_guide/intro_inventory.html'
    obj = {'fragment': '', 'path': '/user_guide/intro_inventory.html', 'scheme': 'https', 'netloc': 'docs.ansible.com'}
    assert(split_url(url) == obj)
    assert(split_url(url, 'scheme') == url_scheme)
    assert(split_url(url, 'netloc') == url_netloc)

# Generated at 2022-06-23 10:30:28.064126
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.ansible.com:8080/tests/path/?param=value&param2=value2', 'scheme') == 'https'
    assert split_url('https://www.ansible.com:8080/tests/path/?param=value&param2=value2', 'netloc') == 'www.ansible.com:8080'
    assert split_url('https://www.ansible.com:8080/tests/path/?param=value&param2=value2', 'path') == '/tests/path/'
    assert split_url('https://www.ansible.com:8080/tests/path/?param=value&param2=value2', 'params') == ''

# Generated at 2022-06-23 10:30:29.560639
# Unit test for constructor of class FilterModule
def test_FilterModule():
    instant_filter = FilterModule()
    assert instant_filter is not None

# Generated at 2022-06-23 10:30:30.133351
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:30:32.264487
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Test the FilterModule filters method '''
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:30:39.233587
# Unit test for function split_url
def test_split_url():
    # Initialize a mock url for testing
    url = 'http://www.example.com/path/to/file?arg1=foo&arg2=bar'

    # Test that split_url properly handles an invalid query
    try:
        split_url(url, query='foo')
    except AnsibleFilterError as e:
        assert str(e) == 'urlsplit: unknown URL component: foo'

    # Test split_url with no query
    result = split_url(url)
    assert result['scheme'] == 'http'
    assert result['netloc'] == 'www.example.com'
    assert result['path'] == '/path/to/file'
    assert result['query'] == 'arg1=foo&arg2=bar'
    assert result['fragment'] == ''

    # Test split_url with a valid query

# Generated at 2022-06-23 10:30:46.975825
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    split_url('http://www.example.com/path/to/file.php', 'scheme')
    split_url('http://www.example.com/path/to/file.php', 'netloc')
    split_url('http://www.example.com/path/to/file.php', 'path')
    split_url('http://www.example.com/path/to/file.php', 'query')
    split_url('http://www.example.com/path/to/file.php', 'fragment')

# Generated at 2022-06-23 10:30:48.327937
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:30:59.514087
# Unit test for function split_url
def test_split_url():

    assert split_url("http://example.com/path/to/resource") == {
        'scheme': 'http',
        'netloc': 'example.com',
        'path': '/path/to/resource',
        'query': '',
        'fragment': ''
    }

    assert split_url("http://example.com/path/to/resource", "scheme") == 'http'
    assert split_url("http://example.com/path/to/resource", "path") == '/path/to/resource'
    assert split_url("http://example.com/path/to/resource", "query") == ''
    assert split_url("http://example.com/path/to/resource", "fragment") == ''

# Generated at 2022-06-23 10:31:08.223347
# Unit test for function split_url
def test_split_url():
    u_str = 'https://www.google.com:80/drive/v2/rpc?index=15&count=10&type=list'
    func = split_url(u_str)
    assert func['query'] == 'index=15&count=10&type=list'
    assert func['scheme'] == 'https'
    assert func['path'] == '/drive/v2/rpc'
    assert func['netloc'] == 'www.google.com:80'
    assert func['port'] == 80

    u_str = 'https://www.scoop.it:80/t/data-mining-by-peter-c-flach#cite_note-flach-1'
    func = split_url(u_str)
    assert func['query'] == ''
    assert func['scheme']

# Generated at 2022-06-23 10:31:20.267033
# Unit test for function split_url
def test_split_url():
    url_dict = {'scheme': 'https',
                'netloc': 'github.com',
                'path': '/ansible/ansible',
                'query': 'foo=bar',
                'fragment': None}


# Generated at 2022-06-23 10:31:29.274516
# Unit test for function split_url
def test_split_url():
    from ansible.utils.pycompat24 import PY2
    from ansible.module_utils import basic
    import sys
    import test.utils
    if PY2:
        reload(sys)
        sys.setdefaultencoding('utf-8')
    test.utils.assertTrue([0,0,0], 0, split_url('http://user:password@host.com:8080/path;parameters?query=arg#fragment','username','urlsplit'))
    test.utils.assertTrue([0,0,0], 0, split_url('http://user:password@host.com:8080/path;parameters?query=arg#fragment','password','urlsplit'))

# Generated at 2022-06-23 10:31:30.491032
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:31:34.042638
# Unit test for function split_url
def test_split_url():
    value = "https://www.example.com/path?name=value"
    assert split_url(value, 'scheme') == 'https'
    assert split_url(value, 'netloc') == 'www.example.com'
    assert split_url(value, 'path') == '/path'
    assert split_url(value, 'query') == 'name=value'

# Generated at 2022-06-23 10:31:45.062833
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test with value=http://github.com/ansible/ansible-modules-core/blob/devel/network/f5/bigip_ltm_monitor_http.py?query=test#L23
    # and query=netloc.
    fm = FilterModule()
    results = fm.filters()['urlsplit']('http://github.com/ansible/ansible-modules-core/blob/devel/network/f5/bigip_ltm_monitor_http.py?query=test#L23', 'netloc')
    assert results == 'github.com'

    # Test with value=http://github.com/ansible/ansible-modules-core/blob/devel/network/f5/bigip_ltm_monitor_http.py?query=test#L23
    # and

# Generated at 2022-06-23 10:31:48.474513
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # -- FilterModule.filters --
    fm = FilterModule()
    filters = fm.filters()
    assert isinstance(filters, dict)
    assert 'urlsplit' in filters
    assert callable(filters['urlsplit'])

# Generated at 2022-06-23 10:31:50.386700
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:31:53.962067
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert split_url('http://www.example.com/path?arg=value') == {'hostname': 'www.example.com', 'path': '/path', 'query': 'arg=value', 'port': 80, 'scheme': 'http', 'netloc': 'www.example.com', 'fragment': '', 'username': '', 'password': ''}

# Generated at 2022-06-23 10:31:57.002633
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {
        'urlsplit': split_url
    }

# Unit tests for method split_url

# Generated at 2022-06-23 10:31:58.332159
# Unit test for constructor of class FilterModule
def test_FilterModule():
  response = FilterModule()
  assert response != None


# Generated at 2022-06-23 10:31:59.628484
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert(fm is not None)

# Generated at 2022-06-23 10:32:02.831863
# Unit test for function split_url
def test_split_url():
    url = 'https://user:pass@host:443/path/part/../part/.?query=yes#fragment'
    query = 'scheme'
    query_result = 'https'
    results = split_url(url, query)
    assert results == query_result

# Generated at 2022-06-23 10:32:11.922626
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    method = FilterModule().filters()['urlsplit']
    result = method('https://www.ansible.com/index?foo=bar')
    assert result['scheme'] == 'https'
    assert result['netloc'] == 'www.ansible.com'
    assert result['path'] == '/index'
    assert result['query'] == 'foo=bar'
    assert result['fragment'] == ''
    assert result['username'] == ''
    assert result['password'] == ''
    assert result['hostname'] == 'www.ansible.com'
    assert result['port'] == ''

    result = method('git+ssh://git@github.com/ansible/ansible.git', query='fragment')
    assert result == ''


# Generated at 2022-06-23 10:32:22.088005
# Unit test for function split_url

# Generated at 2022-06-23 10:32:26.070965
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:32:28.523791
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule) == { 'urlsplit': split_url }


# Generated at 2022-06-23 10:32:30.038310
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters() is not None

# Generated at 2022-06-23 10:32:32.263548
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] is split_url



# Generated at 2022-06-23 10:32:42.509444
# Unit test for function split_url
def test_split_url():
    assert split_url('http://host.com:80', query='hostname') == 'host.com'
    assert split_url('ftp://user:pwd@host.com', query='username') == 'user'
    assert split_url('http://host.com:80', query='port') == 80
    assert split_url('https://host.com:443', query='port') == 443
    assert split_url('http://host.com:80', query='params') == ''
    assert split_url('http://host.com:80', query='fragment') == ''
    assert split_url('ftp://user:pwd@host.com:21/file.ext;params?query=arg#fragment', query='params') == 'params'

# Generated at 2022-06-23 10:32:44.519952
# Unit test for constructor of class FilterModule
def test_FilterModule():
    instance = FilterModule()
    assert hasattr(instance, 'filters')


# Generated at 2022-06-23 10:32:46.011390
# Unit test for constructor of class FilterModule
def test_FilterModule():
    out = FilterModule()
    assert out is not None


# Generated at 2022-06-23 10:32:53.881372
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils import basic
    results = split_url('proto://somewhere.com/some/path?some=query', 'scheme')
    assert results == 'proto'

    results = split_url('proto://somewhere.com/some/path?some=query', 'query')
    assert results == 'some=query'

    results = split_url('proto://somewhere.com/some/path?some=query')
    assert results['scheme'] == 'proto'
    assert results['query'] == 'some=query'
    assert results['hostname'] == 'somewhere.com'

    results = split_url('proto://somewhere.com/some/path?some=query', 'foo')

# Generated at 2022-06-23 10:32:56.858086
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert 'urlsplit' in module.filters()
    assert callable(module.filters()['urlsplit'])


# Generated at 2022-06-23 10:33:07.275993
# Unit test for function split_url
def test_split_url():
    assert {'query': '', 'netloc': 'www.example.com', 'fragment': '', 'path': '/files/main_page.html', 'scheme': 'http'} == split_url('http://www.example.com/files/main_page.html')
    assert {'query': 'mode=raw', 'netloc': 'www.example.com', 'fragment': '', 'path': '/public/data', 'scheme': 'http'} == split_url('http://www.example.com/public/data?mode=raw')
    assert {'query': '', 'netloc': 'www.example.com', 'fragment': '', 'path': '/public/data', 'scheme': 'http'} == split_url('http://www.example.com/public/data?')

# Generated at 2022-06-23 10:33:09.208895
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_filter = FilterModule()
    assert test_filter.__class__.__name__ == 'FilterModule'

# Generated at 2022-06-23 10:33:18.532852
# Unit test for function split_url
def test_split_url():
    url = 'https://www.example.com/foo/bar?query=abc'
    assert split_url(url)['scheme'] == 'https'
    assert split_url(url)['netloc'] == 'www.example.com'
    assert split_url(url)['path'] == '/foo/bar'
    assert split_url(url)['query'] == 'query=abc'
    assert split_url(url, 'scheme') == 'https'
    assert split_url(url, 'netloc') == 'www.example.com'
    assert split_url(url, 'path') == '/foo/bar'
    assert split_url(url, 'query') == 'query=abc'

# Generated at 2022-06-23 10:33:28.987463
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    fm = FilterModule()
    filters = fm.filters()
    splitting = 'http://ansible.com/test/test2?q=1&q2=2'
    assert filters['urlsplit'](splitting, query='scheme') == 'http'
    assert filters['urlsplit'](splitting, query='netloc') == 'ansible.com'
    assert filters['urlsplit'](splitting, query='path') == '/test/test2'
    assert filters['urlsplit'](splitting, query='query') == 'q=1&q2=2'
    assert filters['urlsplit'](splitting, query='fragment') == ''
    assert filters['urlsplit'](splitting)['path'] == '/test/test2'

# Generated at 2022-06-23 10:33:31.747014
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_filter_module = FilterModule()
    assert(test_filter_module.filters()['urlsplit'] is split_url)


# Generated at 2022-06-23 10:33:32.708946
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:33:34.181187
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:33:36.816593
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    Constructor test
    """
    uri_filter = FilterModule()
    assert uri_filter.filters().get('urlsplit', None) is not None



# Generated at 2022-06-23 10:33:50.591003
# Unit test for function split_url
def test_split_url():
    # Test cases using http://docs.python.org/2/library/urlparse.html#urlparse.urlsplit
    assert split_url('http://www.example.com/path/to/file') is not None
    assert split_url('http://www.example.com/path/to/file', 'scheme') == 'https'
    assert split_url('http://www.example.com/path/to/file', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file', 'path') == '/path/to/file'
    assert split_url('http://user:pass@www.example.com:80/path/to/file;param?query=arg#frag', 'username') == 'user'

# Generated at 2022-06-23 10:33:57.658081
# Unit test for function split_url
def test_split_url():
    ''' Unit test for function split_url '''

    # Test URL: http://user:pass@www.example.com:8080/some/path?foo=bar&baz=1#top
    url = 'http://user:pass@www.example.com:8080/some/path?foo=bar&baz=1#top'

    # Test cases

# Generated at 2022-06-23 10:33:58.649801
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')

# Generated at 2022-06-23 10:33:59.591700
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule, object)

# Generated at 2022-06-23 10:34:00.840323
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module is not None


# Generated at 2022-06-23 10:34:03.482132
# Unit test for constructor of class FilterModule
def test_FilterModule():
     query = 'query'
     param = '/usr/local/bin/python/'
     alias = 'urlsplit'
     f = FilterModule()
     split_url(param, query, alias)

# Generated at 2022-06-23 10:34:04.989035
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:34:13.310275
# Unit test for function split_url
def test_split_url():
    assert split_url('http://192.168.10.10:8080/api/') == {
        'scheme': 'http',
        'netloc': '192.168.10.10:8080',
        'path': '/api/',
        'query': '',
        'fragment': ''
    }
    assert split_url('http://192.168.10.10:8080/api/', query='scheme') == 'http'
    assert split_url('http://192.168.10.10:8080/api/', query='netloc') == '192.168.10.10:8080'
    assert split_url('http://192.168.10.10:8080/api/', query='path') == '/api/'

# Generated at 2022-06-23 10:34:14.227006
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module is not None


# Generated at 2022-06-23 10:34:19.236122
# Unit test for function split_url
def test_split_url():

    url = 'http://username:password@test.com:8080/path;parameters?query=test#test'

    results = split_url(url)

    assert results['scheme'] == 'http'
    assert results['netloc'] == 'username:password@test.com:8080'
    assert results['hostname'] == 'test.com'
    assert results['port'] == '8080'
    assert results['username'] == 'username'
    assert results['password'] == 'password'
    assert results['path'] == '/path;parameters'
    assert results['query'] == 'query=test'
    assert results['fragment'] == 'test'

    assert split_url(url, 'scheme') == 'http'

# Generated at 2022-06-23 10:34:20.289850
# Unit test for constructor of class FilterModule
def test_FilterModule():
   assert FilterModule().filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:34:22.019362
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter = FilterModule()
    x = filter.filters()
    return x['urlsplit']



# Generated at 2022-06-23 10:34:23.152893
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:34:29.920778
# Unit test for function split_url
def test_split_url():
    url = 'https://www.example.com/path/to/file?query=yes'
    expected = {
        'scheme': 'https',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': 'query=yes',
        'fragment': '',
    }

    results = split_url(url)
    assert results == expected

# Generated at 2022-06-23 10:34:31.293529
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters()


# Generated at 2022-06-23 10:34:33.063896
# Unit test for constructor of class FilterModule
def test_FilterModule():
    s = FilterModule()
    assert isinstance(s, FilterModule)

# Unit tests for split_url

# Generated at 2022-06-23 10:34:33.566088
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:34:38.425012
# Unit test for constructor of class FilterModule
def test_FilterModule():
    actual = dict(FilterModule().filters()).keys()
    expected = set(['urlsplit'])
    assert actual == expected


# Generated at 2022-06-23 10:34:43.333709
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()
    assert x.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:34:45.666767
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() ==  {'urlsplit': split_url}


# Generated at 2022-06-23 10:34:48.155932
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urlsplit' in filters


# Generated at 2022-06-23 10:34:49.400833
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test = FilterModule()
    assert test.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:34:50.924451
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert filterModule.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:34:58.448297
# Unit test for function split_url

# Generated at 2022-06-23 10:35:01.361973
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    results = {
        'urlsplit': split_url
    }
    uri_filter = FilterModule()
    assert uri_filter.filters() == results

# Generated at 2022-06-23 10:35:07.825894
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule = FilterModule()
    # Test case for split_url
    assert filtermodule.filters()['urlsplit']('/usr/local/bin/anaconda') == {'fragment': '', 'netloc': '', 'path': '/usr/local/bin/anaconda', 'params': '', 'query': '', 'scheme': ''}


# ---- Ansible filter tests ----

# Generated at 2022-06-23 10:35:15.980241
# Unit test for function split_url
def test_split_url():

    from ansible import errors, utils

    def assert_fails(value):
        try:
            split_url(value)
            assert False, "split_url() should have thrown an exception: %s" % value
        except errors.AnsibleFilterError:
            pass

    assert_fails('not a url')
    assert_fails('')

    # Test URLs with schemes
    assert split_url('http://www.example.com/')['scheme'] == 'http'
    assert split_url('https://www.example.com/')['scheme'] == 'https'
    assert split_url('ssh://www.example.com/')['scheme'] == 'ssh'

    # Test URLs without schemes
    assert not split_url('www.example.com/')['scheme']

# Generated at 2022-06-23 10:35:18.137809
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule
    assert FilterModule.filters.__doc__ == split_url.__doc__


# Generated at 2022-06-23 10:35:20.818712
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert obj.filters() == {'urlsplit':split_url}
# ---- End of FilterModule ----

# Generated at 2022-06-23 10:35:30.488605
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/foo/bar?baz=qux', alias='test_split_url') == {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/foo/bar', 'query': 'baz=qux', 'fragment': ''}
    assert split_url('http://www.example.com/foo/bar?baz=qux', 'path', alias='test_split_url') == '/foo/bar'
    assert split_url('http://www.example.com/foo/bar?baz=qux', 'hostname', alias='test_split_url') == 'www.example.com'

# Generated at 2022-06-23 10:35:32.555616
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urlsplit' in filters

# Generated at 2022-06-23 10:35:39.911139
# Unit test for function split_url
def test_split_url():
    value = 'http://www.ansible.com/projects/software?name=ansible&id=133'
    result = split_url(value, 'netloc')
    assert result == 'www.ansible.com'

    result = split_url(value, 'path')
    assert result == '/projects/software'

    result = split_url(value)
    assert result['netloc'] == 'www.ansible.com'
    assert result['path'] == '/projects/software'
    assert result['query'] == 'name=ansible&id=133'

# Generated at 2022-06-23 10:35:46.559772
# Unit test for function split_url
def test_split_url():
    """Split URL test cases."""
    from ansible.utils.unsafe_proxy import wrap_var

    def assert_result(input_url, expected, query='', alias='urlsplit'):
        """Assert that the expected result matches function output."""
        if query:
            result = wrap_var(split_url(input_url, query=query, alias=alias))
            assert result == expected
        else:
            result = wrap_var(split_url(input_url, alias=alias))
            assert expected == result

    assert_result('http://ansible.com/test', 'http')
    assert_result('http://ansible.com/test', 'ansible.com', query='netloc')
    assert_result('http://ansible.com/test', 'ansible.com', query='hostname')
    assert_

# Generated at 2022-06-23 10:35:48.617216
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'urlsplit' in filter_module.filters()

# Generated at 2022-06-23 10:35:51.705097
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert split_url('http://usr:pass@google.com:90/path/to/resource?q=foo&q=bar#baz', 'netloc') == 'usr:pass@google.com:90'

# Generated at 2022-06-23 10:35:53.411012
# Unit test for constructor of class FilterModule
def test_FilterModule():
    a = FilterModule()
    assert 'urlsplit' in a.filters()


# Generated at 2022-06-23 10:35:54.161286
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-23 10:36:04.633887
# Unit test for function split_url
def test_split_url():
    ''' Unit test for function split_url '''

    import sys
    import yaml
    #
    #  Set up for yaml.safe_load()
    #  yaml.safe_load() doesn't like docstrings that start with '#'
    #
    filename = sys.argv[0]
    if filename.endswith('.py'):
        filename = filename[:-3]
    test_data = yaml.load(open(filename + '.yaml').read(), Loader=yaml.SafeLoader).get('tests')

    #
    # Test successful calls
    #
    for test in test_data.get('success'):

        # Test with a query supplied
        query = test.get('query')
        assert split_url(test.get('url'), query) == test.get('expected', {}).get

# Generated at 2022-06-23 10:36:14.061780
# Unit test for function split_url
def test_split_url():
    '''
        Validate split_url returns correct result
    '''