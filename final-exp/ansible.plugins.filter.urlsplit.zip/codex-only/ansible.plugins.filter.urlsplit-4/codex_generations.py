

# Generated at 2022-06-23 10:26:13.068451
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert filters['urlsplit'] == split_url
# ---- End of unit tests ----

# Generated at 2022-06-23 10:26:18.036017
# Unit test for function split_url
def test_split_url():
    url = 'ansible://test.com:8080/user?param1=var1&param2=var2'
    split = split_url(url, '')
    assert split['scheme'] == 'ansible'
    assert split['netloc'] == 'test.com:8080'
    assert split['path'] == '/user'
    assert split['query'] == 'param1=var1&param2=var2'

# Generated at 2022-06-23 10:26:24.534776
# Unit test for function split_url
def test_split_url():

    val = 'http://www.test.com/test/test?test=test'

    current_results = {'scheme': 'http', 'query': 'test=test', 'fragment': '', 'netloc': 'www.test.com', 'path': '/test/test'}
    assert(split_url(val) == current_results)

    current_results = {'scheme': 'http://', 'query': '', 'fragment': '', 'netloc': 'www.test.com', 'path': '/test/test'}
    assert(split_url(val, query='scheme') == 'http')

    current_results = {'scheme': 'http://', 'query': '', 'fragment': '', 'netloc': 'www.test.com', 'path': '/test/test'}
   

# Generated at 2022-06-23 10:26:35.676357
# Unit test for function split_url
def test_split_url():
    ''' Tests for function split_url '''

    def my_test(value, query='', alias='urlsplit', exc=None):
        if exc:
            with pytest.raises(exc):
                split_url(value, query, alias)
        else:
            assert split_url(value, query, alias) == exc

    my_test('http://www.example.com', 'scheme')
    my_test('http://www.example.com', 'port')
    my_test('http://www.example.com', 'hostname')
    my_test('http://www.example.com:8080', 'port')
    my_test('http://www.example.com/index.html?', 'query')

# Generated at 2022-06-23 10:26:39.628378
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    model = FilterModule()
    filters = model.filters()
    for filter in filters:
        assert filter in model.filters()

# ---- Ansible filters ----


# Generated at 2022-06-23 10:26:41.072973
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module is not None


# Generated at 2022-06-23 10:26:43.061476
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters == {'urlsplit': split_url}


# ---- Ansible tests ----

# Generated at 2022-06-23 10:26:45.488445
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters() is not None
    assert "urlsplit" in filter_module.filters()


# Generated at 2022-06-23 10:26:58.478509
# Unit test for function split_url
def test_split_url():
    url = split_url('http://www.ansible.com/site?arg1=top_level_arg1&arg2=top_level_arg2#fragment')
    assert url['scheme'] == 'http'
    assert url['netloc'] == 'www.ansible.com'
    assert url['path'] == '/site'
    assert url['query'] == 'arg1=top_level_arg1&arg2=top_level_arg2'
    assert url['fragment'] == 'fragment'

    url = split_url('http://www.ansible.com/site?arg1=top_level_arg1&arg2=top_level_arg2')
    assert url['scheme'] == 'http'
    assert url['netloc'] == 'www.ansible.com'

# Generated at 2022-06-23 10:27:04.335782
# Unit test for function split_url
def test_split_url():
    """
    Unit test for function split_url
    """
    # Test common URL
    test_url = 'https://github.com/ansible/ansible/issues/7652'
    test_result = {
        'scheme': 'https',
        'netloc': 'github.com',
        'path': '/ansible/ansible/issues/7652',
        'query': '',
        'fragment': ''
    }
    result = split_url(test_url, '')
    assert result == test_result

    # Query "scheme" should return "https"
    result = split_url(test_url, 'scheme')
    assert result == test_result['scheme']

    # Query "hostname" should return "github.com"

# Generated at 2022-06-23 10:27:09.434880
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()["urlsplit"](
        'http://foo:bar@test.com:80/test?test=test#test') == {
            'scheme': 'http', 'netloc': 'foo:bar@test.com:80',
            'path': '/test', 'query': 'test=test', 'fragment': 'test'
        }

# Generated at 2022-06-23 10:27:11.329477
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """Test class FilterModule"""
    filter_module = FilterModule()
    assert 'urlsplit' in filter_module.filters()


# Generated at 2022-06-23 10:27:22.112813
# Unit test for function split_url
def test_split_url():
    parse_func = split_url
    url = 'http://a:b@c.d.e/f?g#h'

    assert parse_func(url, 'scheme') == 'http'
    assert parse_func(url, 'netloc') == 'a:b@c.d.e'
    assert parse_func(url, 'path') == '/f'
    assert parse_func(url, 'query') == 'g'
    assert parse_func(url, 'fragment') == 'h'
    assert parse_func(url, 'username') == 'a'
    assert parse_func(url, 'password') == 'b'
    assert parse_func(url, 'hostname') == 'c.d.e'
    assert parse_func(url, 'port') == None

# Generated at 2022-06-23 10:27:32.515621
# Unit test for constructor of class FilterModule
def test_FilterModule():
  assert split_url('http://docs.ansible.com/ansible/devel/modules/uri_module.html')
  assert split_url('http://docs.ansible.com/ansible/devel/modules/uri_module.html', 'scheme') == 'http'
  assert split_url('http://docs.ansible.com/ansible/devel/modules/uri_module.html', 'site') == 'docs.ansible.com'
  assert split_url('http://docs.ansible.com/ansible/devel/modules/uri_module.html', 'port') == None
  assert split_url('http://docs.ansible.com:5000/ansible/devel/modules/uri_module.html', 'port') == '5000'


# Generated at 2022-06-23 10:27:40.746664
# Unit test for function split_url
def test_split_url():
    from ansible.utils import plugin_docs

    test_data = {
        'scheme': 'https',
        'netloc': 'www.ansible.com',
        'path': '/',
        'query': '',
        'fragment': ''
    }

    function_name = 'urlsplit'
    function = globals()[function_name]
    test_results = function('https://www.ansible.com', '', 'urlsplit')

    assert test_results['scheme'] == test_data['scheme']
    assert test_results['netloc'] == test_data['netloc']
    assert test_results['path'] == test_data['path']
    assert test_results['query'] == test_data['query']
    assert test_results['fragment'] == test_data['fragment']


# Generated at 2022-06-23 10:27:42.122438
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule().filters(), dict)


# Generated at 2022-06-23 10:27:44.169027
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module != None

# Unit tests for the FilterModule.filters() method

# Generated at 2022-06-23 10:27:45.026758
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None

# Generated at 2022-06-23 10:27:49.147679
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path?arg=value')['scheme'] == 'http'
    assert split_url('http://www.example.com/path?arg=value', 'scheme') == 'http'
    assert split_url('http://www.example.com/path?arg=value', 'query') == 'arg=value'



# Generated at 2022-06-23 10:27:58.018108
# Unit test for function split_url
def test_split_url():
    s = split_url("https://github.com/user/repo/branch/tree/foo.bar", 'path')
    assert s == '/user/repo/branch/tree/foo.bar'
    s = split_url("https://github.com/user/repo/branch/tree/foo.bar", 'scheme')
    assert s == 'https'
    s = split_url("https://github.com/user/repo/branch/tree/foo.bar", 'netloc')
    assert s == 'github.com'
    s = split_url("https://github.com/user/repo/branch/tree/foo.bar", 'query')
    assert s == ''

# Generated at 2022-06-23 10:28:00.137149
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:28:00.743471
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule != None

# Generated at 2022-06-23 10:28:04.688570
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """ Test class FilterModule filters method
    """
    assert len(FilterModule.filters(FilterModule)) == 1
    assert FilterModule.filters(FilterModule).get('urlsplit', None) == split_url



# Generated at 2022-06-23 10:28:07.516231
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:28:09.511351
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.__class__.__name__ == 'FilterModule'


# Generated at 2022-06-23 10:28:12.709022
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test new FilterModule is created correctly
    f = FilterModule()
    assert isinstance(f, FilterModule)

# Unit tests for the module function split_url

# Generated at 2022-06-23 10:28:21.080388
# Unit test for function split_url
def test_split_url():

    test = 'https://www.google.com/search?q=uri+split&oq=uri+split&aqs=chrome..69i57j69i60j69i59j69i60l2.2266j0j7&sourceid=chrome&ie=UTF-8'

    module_results = split_url(test)

    expected_results = {
        'fragment': '',
        'netloc': 'www.google.com',
        'path': '/search',
        'query': 'q=uri+split&oq=uri+split&aqs=chrome..69i57j69i60j69i59j69i60l2.2266j0j7&sourceid=chrome&ie=UTF-8',
        'scheme': 'https',
    }

    assert module_results == expected_results

# Generated at 2022-06-23 10:28:24.416610
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters()['urlsplit'] == split_url



# Generated at 2022-06-23 10:28:25.922530
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-23 10:28:34.877453
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import os
    import sys
    import unittest
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ansible.module_utils.six.moves.urllib.parse import urlunsplit
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common.collections import is_sequence

    class TestSplitUrl(unittest.TestCase):

        def test_split_url_1(self):
            # Test for a valid URL
            value = 'http://www.example.com/path?arg=value#frag'
            query = ''
            alias = 'urlsplit'
           

# Generated at 2022-06-23 10:28:36.494650
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module.__class__.__name__ == 'FilterModule'

# Generated at 2022-06-23 10:28:38.544435
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'object' == type(FilterModule().filters()).__name__

# Generated at 2022-06-23 10:28:41.123229
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  f = FilterModule()
  assert f.filters()['urlsplit']() == split_url()


# Generated at 2022-06-23 10:28:50.868863
# Unit test for function split_url
def test_split_url():
    assert split_url("http://www.example.com/path1/path2/index.html?key1=value1&key2=value2", "netloc") == "www.example.com"
    assert split_url("http://www.example.com/path1/path2/index.html?key1=value1&key2=value2", "scheme") == "http"
    assert split_url("http://www.example.com/path1/path2/index.html?key1=value1&key2=value2", "path") == "/path1/path2/index.html"
    assert split_url("http://www.example.com/path1/path2/index.html?key1=value1&key2=value2", "query") == "key1=value1&key2=value2"

# Generated at 2022-06-23 10:28:58.934517
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.google.com?q=foo&a=b')

    # Test with a query
    assert split_url('https://www.google.com?q=foo&a=b', 'scheme') == 'https'
    assert split_url('https://www.google.com?q=foo&a=b', 'netloc') == 'www.google.com'
    assert split_url('https://www.google.com?q=foo&a=b', 'path') == '/'
    assert split_url('https://www.google.com?q=foo&a=b', 'query') == 'q=foo&a=b'
    assert split_url('https://www.google.com?q=foo&a=b', 'fragment') == ''

    # Test with no query
   

# Generated at 2022-06-23 10:29:02.065800
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # class instantiation
    obj = FilterModule()

    # test method filters
    assert obj.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:29:11.432717
# Unit test for function split_url
def test_split_url():

    values = [
        "http://user:pass@localhost:8080/test/test?test=query#test",
        "ftp://user:pass@localhost:2121/upload/file.txt",
        "sftp://user:pass@localhost:2222/download/file.txt",
        "ssh://user:pass@localhost:2222/",
        "https://localhost:443/secure_page",
        "http://localhost",
        "http://localhost:8080",
        "https://localhost",
        "https://localhost:443",
        "localhost",
    ]


# Generated at 2022-06-23 10:29:22.703173
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert split_url('http://example.com/foo/bar').query == ''
    assert split_url('http://example.com/foo/bar', 'scheme') == 'http'
    assert split_url('http://example.com/foo/bar', 'netloc') == 'example.com'
    assert split_url('http://example.com/foo/bar', 'path') == '/foo/bar'
    with pytest.raises(AnsibleFilterError, match='urlsplit: unknown URL component: bad'):
        split_url('http://example.com/foo/bar', query='bad')

# Generated at 2022-06-23 10:29:24.454905
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter = FilterModule()
    assert filter.filters() is not None

# Generated at 2022-06-23 10:29:28.516871
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import pytest
    fm = FilterModule()
    assert fm
    assert fm.filters()
    assert 'urlsplit' in fm.filters()
    assert callable(fm.filters()['urlsplit'])


# Generated at 2022-06-23 10:29:30.852355
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
        'urlsplit': split_url
    }



# Generated at 2022-06-23 10:29:33.632903
# Unit test for constructor of class FilterModule
def test_FilterModule():
    class_filter = FilterModule()
    assert class_filter.filters().get('urlsplit') is not None


# Generated at 2022-06-23 10:29:36.046832
# Unit test for constructor of class FilterModule
def test_FilterModule():
    try:
        assert isinstance(FilterModule(), FilterModule)
    except AssertionError as e:
        print('Error:', e)


# Generated at 2022-06-23 10:29:37.708212
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    obj.filters()


# Generated at 2022-06-23 10:29:49.920625
# Unit test for function split_url
def test_split_url():

    value = 'https://user:password@www.example.com:1234/path/to/file?arg1=val1&arg2=val2#fragment'
    alias = 'urlsplit'

    result = split_url(value, query='scheme')
    assert result == 'https'

    result = split_url(value, query='netloc')
    assert result == 'user:password@www.example.com:1234'

    result = split_url(value, query='port')
    assert result == 1234

    result = split_url(value, query='path')
    assert result == '/path/to/file'

    result = split_url(value, query='query')
    assert result == 'arg1=val1&arg2=val2'


# Generated at 2022-06-23 10:29:54.458482
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:29:56.001746
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule) == {'urlsplit': split_url}


# Generated at 2022-06-23 10:29:57.863712
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module.filters() == {'urlsplit': split_url}



# Generated at 2022-06-23 10:30:02.123729
# Unit test for function split_url
def test_split_url():
    urls = [
        'https://www.example.com/foo/bar?key=value',
        'http://www.example.com/foo/bar?key=value',
        'ftp://www.example.com/foo/bar?key=value',
    ]

    for url in urls:
        pprint(FilterModule().filters()['urlsplit'](url))


# Generated at 2022-06-23 10:30:09.763566
# Unit test for function split_url
def test_split_url():
    # Pull the function out of the module for unit testing
    # This makes it easier to test the function with no magic (no ansible module)
    f = open('uri.py')
    code = compile(f.read(), 'uri.py', 'exec')
    ctx = {}
    exec(code, ctx)

    f_split_url = ctx['split_url']

    expected = {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/myfile.html',
        'query': 'some=query_string',
        'fragment': 'thisismyanchor'
    }

    url = 'http://www.example.com/path/to/myfile.html?some=query_string#thisismyanchor'

    assert f

# Generated at 2022-06-23 10:30:17.728372
# Unit test for function split_url
def test_split_url():
    assert split_url('http://user:password@www.example.com:8080/path/file?query=test', 'scheme') == "http"
    assert split_url('http://user:password@www.example.com:8080/path/file?query=test', 'user_password') == "user:password"
    assert split_url('http://user:password@www.example.com:8080/path/file?query=test', 'netloc') == "user:password@www.example.com:8080"
    assert split_url('http://user:password@www.example.com:8080/path/file?query=test', 'hostname') == "www.example.com"

# Generated at 2022-06-23 10:30:29.608455
# Unit test for function split_url
def test_split_url():
    url = 'https://www.github.com:80/search/ansible_collections?q=mazer'

    # Test with a single query option.
    assert split_url(url, 'scheme') == 'https'
    assert split_url(url, 'netloc') == 'www.github.com:80'
    assert split_url(url, 'path') == '/search/ansible_collections'
    assert split_url(url, 'query') == 'q=mazer'
    assert split_url(url, 'fragment') == ''
    assert split_url(url, 'hostname') == 'www.github.com'
    assert split_url(url, 'port') == '80'
    assert split_url(url, 'username') == ''
    assert split_url(url, 'password') == ''

# Generated at 2022-06-23 10:30:34.458288
# Unit test for function split_url
def test_split_url():
    assert split_url('https://user:pass@www.example.com:8080/foo/bar?q=baz#anchor', query='scheme') == 'https'
    assert split_url('https://user:pass@www.example.com:8080/foo/bar?q=baz#anchor', query='netloc') == 'user:pass@www.example.com:8080'
    assert split_url('https://user:pass@www.example.com:8080/foo/bar?q=baz#anchor', query='path') == '/foo/bar'
    assert split_url('https://user:pass@www.example.com:8080/foo/bar?q=baz#anchor', query='query') == 'q=baz'

# Generated at 2022-06-23 10:30:41.019878
# Unit test for function split_url
def test_split_url():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class FakeModule(object):
        def __init__(self):
            self.url = AnsibleUnsafeText('http://www.wikipedia.org/wiki/San_Francisco')
            self.option = 'netloc'

    fm = FakeModule()

    split_url(fm.url, query=fm.option)

    returned_dict = {
        'scheme': 'http',
        'netloc': 'www.wikipedia.org',
        'path': '/wiki/San_Francisco',
        'params': '',
        'query': '',
        'fragment': ''
    }

    assert returned_dict == split_url(fm.url)

# Generated at 2022-06-23 10:30:50.818591
# Unit test for function split_url
def test_split_url():
    from ansible import playbook
    from ansible.playbook.task_include import TaskInclude

    test_url = 'https://www.ansible.com'

    test_tasks = [
        TaskInclude(
            play=playbook._load_play_from_data({
                'name': 'Test Play',
                'connection': 'local',
                'hosts': 'all',
                'tasks': [{
                    'debug': {
                        'msg': "{{ url | urlsplit('scheme') }}"
                    }
                }]
            })._entries[0],
            host=None,
            task=None,
            block=None,
            role=None,
            task_vars={'url': test_url}
        )
    ]

    assert test_tasks[0]._task

# Generated at 2022-06-23 10:31:02.601326
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.google.com', 'scheme') == 'https'
    assert split_url('https://www.google.com/search?q=test&oq=test', 'query') == 'q=test&oq=test'
    assert split_url('https://www.google.com', 'netloc') == 'www.google.com'
    assert split_url('https://www.google.com/search?q=test&oq=test', 'path') == '/search'
    assert split_url('https://www.google.com/search?q=test&oq=test', 'unknown') == 'unknown'

# Generated at 2022-06-23 10:31:06.597272
# Unit test for function split_url
def test_split_url():
    print("Hello, World!")
    host = "www.example.com"
    port = 8080
    url = "http://%s:%s/" % (host, port)
    print(url)
    print(split_url(url))

if __name__ == '__main__':
    test_split_url()

# Generated at 2022-06-23 10:31:11.338918
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule().filters())


# Generated at 2022-06-23 10:31:13.727398
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """ Unit test for method filters of class FilterModule """

    filterModule = FilterModule()
    filterModule.filters()


# Generated at 2022-06-23 10:31:14.721185
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule


# Generated at 2022-06-23 10:31:16.297367
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() is not None


# Generated at 2022-06-23 10:31:18.573321
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for method filters of class FilterModule '''
    assert 'urlsplit' in FilterModule.filters(FilterModule)

# ---- Ansible filters ----

# Generated at 2022-06-23 10:31:20.346016
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:31:23.194392
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule = FilterModule()

    assert(filtermodule.filters() == {
            'urlsplit': split_url
        })

# Generated at 2022-06-23 10:31:30.612647
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    url = "https://api.github.com/repos/ansible/ansible/releases/assets/1789044"
    parameters = {
        "urlsplit_scheme": "https",
        "urlsplit_netloc": "api.github.com",
        "urlsplit_path": "/repos/ansible/ansible/releases/assets/1789044"
    }

    filter_module = FilterModule()

    # Failure cases
    try:
        filter_module.filters()["urlsplit"](url, "garbage")
        assert False
    except AnsibleFilterError:
        pass
    try:
        filter_module.filters()["urlsplit"](None, "garbage")
        assert False
    except AnsibleFilterError:
        pass

    # Success cases
    url_split = filter_module

# Generated at 2022-06-23 10:31:31.606888
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_FilterModule = FilterModule()
    assert(test_FilterModule is not None)


# Generated at 2022-06-23 10:31:42.887138
# Unit test for function split_url
def test_split_url():

    import pytest

    # This is a test case dict of the following information:
    # test case name, options, expected results
    # To add more test cases, just add a dict in the format shown.
    # The actual test case functions and dicts are explicitly below the test
    # case dict.

# Generated at 2022-06-23 10:31:43.755478
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert 'urlsplit' in f.filters()


# Generated at 2022-06-23 10:31:45.367497
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-23 10:31:53.962591
# Unit test for function split_url
def test_split_url():
    result = split_url('http://user:pass@example.com:8080/my/path?foo=bar#baz')
    assert(result.get('scheme') == 'http')
    assert(result.get('netloc') == 'user:pass@example.com:8080')
    assert(result.get('path') == '/my/path')
    assert(result.get('query') == 'foo=bar')
    assert(result.get('fragment') == 'baz')

    result = split_url('http://user:pass@example.com:8080/my/path?foo=bar#baz', 'scheme')
    assert(result == 'http')

    result = split_url('http://user:pass@example.com:8080/my/path?foo=bar#baz', 'query')

# Generated at 2022-06-23 10:31:56.247206
# Unit test for constructor of class FilterModule
def test_FilterModule():
    tfm = FilterModule()
    assert tfm.filters() is not None

# Generated at 2022-06-23 10:31:57.640151
# Unit test for constructor of class FilterModule
def test_FilterModule():
    m = FilterModule()
    assert isinstance(m, FilterModule)

# Generated at 2022-06-23 10:31:59.282442
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:32:10.295075
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text

    # Data for test cases
    test_cases = dict()
    test_cases['ftp'] = dict()
    test_cases['ftp']['url'] = 'ftp://www.example.com/foo/bar/test.txt'
    test_cases['ftp']['scheme'] = 'ftp'
    test_cases['ftp']['netloc'] = 'www.example.com'
    test_cases['ftp']['path'] = '/foo/bar/test.txt'
    test_cases['ftp']['params'] = ''
    test_cases['ftp']['query'] = ''

# Generated at 2022-06-23 10:32:13.025619
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    assert x.filters()['urlsplit']() == split_url()

# Generated at 2022-06-23 10:32:22.759235
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()

    # Test all fields are populated
    parts = module.filters()['urlsplit'](value='http://example.com/foo/bar?baz=qux#quux')
    assert parts['scheme'] == 'http'
    assert parts['netloc'] == 'example.com'
    assert parts['path'] == '/foo/bar'
    assert parts['query'] == 'baz=qux'
    assert parts['fragment'] == 'quux'

    # Test fields are valid when components are missing
    parts = module.filters()['urlsplit'](value='http://example.com/foo/')
    assert parts['scheme'] == 'http'
    assert parts['netloc'] == 'example.com'
    assert parts['path'] == '/foo/'

# Generated at 2022-06-23 10:32:34.075519
# Unit test for function split_url
def test_split_url():

    # Test URL
    url = "http://localhost:8080/limbs/extremities"

    # Test that error is thrown if given invalid query
    try:
        result = split_url(url, query='legs')
    except AnsibleFilterError:
        pass
    else:
        raise AssertionError("Unable to raise AnsibleFilterError")

    # Test that correct query returns correct response
    result = split_url(url, query='path')
    assert result == '/limbs/extremities'

    # Test that None query returns entire parsed URL
    result = split_url(url, query=None)

# Generated at 2022-06-23 10:32:44.123396
# Unit test for function split_url
def test_split_url():
    # Get absolute path of the test file
    import os
    import sys
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    test_file_path = os.path.abspath(__file__)
    test_dir = os.path.dirname(test_file_path)
    test_file = os.path.basename(test_file_path)
    test_dir_path = os.path.dirname(test_dir)
    sys.path.append(test_dir_path)
    import test_utils

    # get the test data

# Generated at 2022-06-23 10:32:45.280487
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:32:46.250877
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj is not None

# Generated at 2022-06-23 10:32:54.014467
# Unit test for function split_url
def test_split_url():
    assert split_url('https://ansible.com/f/this-is-the-file-name.txt?key=value') == {
        'scheme': 'https',
        'netloc': 'ansible.com',
        'path': '/f/this-is-the-file-name.txt',
        'query': 'key=value',
        'fragment': ''
    }
    assert split_url('https://www.packtpub.com/application-development/ansible-cookbook') == {
        'scheme': 'https',
        'netloc': 'www.packtpub.com',
        'path': '/application-development/ansible-cookbook',
        'query': '',
        'fragment': ''
    }

# Generated at 2022-06-23 10:32:57.841398
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    filters = f.filters()
    assert filters.keys() == ['urlsplit'], 'Unexpected filter list'
    assert filters.get('urlsplit') != None, 'urlsplit filter not found'


# Generated at 2022-06-23 10:33:06.823225
# Unit test for function split_url
def test_split_url():
    url = 'http://www.cwi.nl:80/%7Eguido/Python.html'
    # Since the key is supposed to be an actual URL component,
    # test_result will be empty
    test_result = split_url(url, 'path')
    assert test_result == '/%7Eguido/Python.html'

    # If key is not a component, it should return the entire dictionary
    # test_result_dict will be a dictionary
    test_result_dict = split_url(url)
    assert isinstance(test_result_dict, dict)
    assert test_result_dict['path'] == '/%7Eguido/Python.html'

# Generated at 2022-06-23 10:33:08.349981
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filterModule = FilterModule()
    filterModule.filters()

# Generated at 2022-06-23 10:33:10.343155
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule.filters('')['urlsplit']('abc://def.com')['scheme'] == 'abc'

# Generated at 2022-06-23 10:33:12.557482
# Unit test for constructor of class FilterModule
def test_FilterModule():
    uri_filter_module = FilterModule()
    assert uri_filter_module.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:33:22.013696
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_filter_module = FilterModule()
    filter_func = test_filter_module.filters()
    url_split_func = filter_func['urlsplit']

    # Split URL
    url_dict = url_split_func('https://www.example.com/test?a=b&c=d')
    assert url_dict['scheme'] == 'https'
    assert url_dict['netloc'] == 'www.example.com'
    assert url_dict['path'] == '/test'
    assert url_dict['query'] == 'a=b&c=d'
    assert url_dict['fragment'] == ''

    # Split only scheme
    scheme = url_split_func('https://www.example.com/test?a=b&c=d', 'scheme')
    assert scheme == 'https'



# Generated at 2022-06-23 10:33:23.920344
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_plugins = FilterModule()
    assert filter_plugins.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:33:26.521123
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Simple test for class FilterModule filters method.
    test_FilterModule=FilterModule()
    assert test_FilterModule is not None


# Generated at 2022-06-23 10:33:29.237341
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert split_url('http://docs.ansible.com/ansible/uri_module.html#uri-module')['scheme'] == 'http'

# Generated at 2022-06-23 10:33:33.746972
# Unit test for function split_url
def test_split_url():
    f = split_url
    assert f('https://www.ansible.com') == {
        'scheme': 'https', 'netloc': 'www.ansible.com', 'path': '', 'query': '', 'fragment': ''
    }
    assert f('https://www.ansible.com', 'netloc') == 'www.ansible.com'
    try:
        f('https://www.ansible.com', 'random_field')
        assert False, 'expected failure'
    except AnsibleFilterError:
        assert True


# Generated at 2022-06-23 10:33:34.748992
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:33:36.105116
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters == {'urlsplit': split_url}, 'FilterModule.filters() is expected to return {\'urlsplit\': split_url}'


# Generated at 2022-06-23 10:33:38.402598
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
        'urlsplit': split_url
    }

# Generated at 2022-06-23 10:33:41.131851
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    i = fm.filters()
    assert i['urlsplit'] is split_url

# Generated at 2022-06-23 10:33:52.910761
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert split_url('https://www.example.com/foo/bar', query='scheme') == 'https'
    assert split_url('https://www.example.com/foo/bar', query='netloc') == 'www.example.com'
    assert split_url('https://www.example.com/foo/bar', query='path') == '/foo/bar'
    assert split_url('https://www.example.com/foo/bar', query='query') == ''
    assert split_url('https://www.example.com/foo/bar', query='fragment') == ''
    assert split_url('https://www.example.com/foo/bar?baz=qux', query='scheme') == 'https'

# Generated at 2022-06-23 10:34:03.806050
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('http://example.com:8042/over/there?name=ferret#nose') == {
                                                                                 'scheme': 'http',
                                                                                 'netloc': 'example.com:8042',
                                                                                 'params': '',
                                                                                 'path': '/over/there',
                                                                                 'query': 'name=ferret',
                                                                                 'fragment': 'nose',
                                                                                 'username': '',
                                                                                 'password': '',
                                                                                 'hostname': 'example.com',
                                                                                 'port': 8042,
                                                                                 }


# Generated at 2022-06-23 10:34:08.680514
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    urls = []
    urls.append('https://stackoverflow.com/questions/13420006/how-to-get-the-filename-from-the-url')
    for url in urls:
        parsed_url = split_url(url, 'path')
        assert 'questions' in parsed_url
        assert 'how' in parsed_url

# Generated at 2022-06-23 10:34:10.376916
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()

# Unit tests for split_url

# Generated at 2022-06-23 10:34:10.902456
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:34:22.537791
# Unit test for function split_url
def test_split_url():
    """Test split_url"""
    url = 'http://www.example.com/path/to/file?option=true&other=false#top'
    assert split_url(url, 'scheme') == 'http'
    assert split_url(url, 'netloc') == 'www.example.com'
    assert split_url(url, 'path') == '/path/to/file'
    assert split_url(url, 'fragment') == 'top'
    assert split_url(url, 'query') == 'option=true&other=false'

# Generated at 2022-06-23 10:34:31.102376
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    sample_url = 'http://user:pass@www.example.com:8888/test/test2/test3?a=2&b=3#test'
    expected_result = {'fragment': 'test', 'hostname': 'www.example.com',
                       'path': '/test/test2/test3', 'params': '', 'port': 8888,
                       'query': 'a=2&b=3', 'scheme': 'http', 'username': 'user',
                       'password': 'pass'}
    assert split_url(sample_url) == expected_result

# Generated at 2022-06-23 10:34:32.429107
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ft = FilterModule()
    assert 'urlsplit' in ft.filters()

# Generated at 2022-06-23 10:34:47.117567
# Unit test for constructor of class FilterModule
def test_FilterModule():
    print("=== Start Unit Test ===")

    # Split a URL into a Python dict
    url = 'http://www.python.org:80/doc/#frag'
    result = split_url(url)
    
    assert result['scheme'] == 'http'
    assert result['hostname'] == 'www.python.org'
    assert result['port'] == 80
    assert result['netloc'] == 'www.python.org:80'

    # Return only a specific part of the URL
    assert 'scheme' == split_url(url, 'scheme')

    # Return nothing when trying to get an unknown part of the URL
    assert 'unknown' == split_url(url, 'unknown')

    print("=== Unit Test is Done ===")

# The following code will be executed when executing this script directly

# Generated at 2022-06-23 10:34:55.868666
# Unit test for function split_url
def test_split_url():
    """Ansible filter split_url tests"""

    assert_result = {
       'scheme': 'http',
       'netloc': 'www.redhat.com',
       'path': '/redhat.css',
       'query': '',
       'fragment': ''
    }

    assert split_url('http://www.redhat.com/redhat.css') == assert_result
    assert split_url('http://www.redhat.com/redhat.css', 'scheme') == 'http'
    assert split_url('http://www.redhat.com/redhat.css', 'netloc') == 'www.redhat.com'
    assert split_url('http://www.redhat.com/redhat.css', 'path') == '/redhat.css'

# Generated at 2022-06-23 10:34:56.615332
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:34:57.944646
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert True

# Generated at 2022-06-23 10:34:58.548626
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:35:04.508818
# Unit test for function split_url
def test_split_url():
    filter_ = FilterModule()
    filter_instance = filter_.filters()
    assert filter_instance['urlsplit']('http://10.20.30.40/path/to/object?format=json')['netloc'] == '10.20.30.40'
    assert filter_instance['urlsplit']('http://10.20.30.40/path/to/object?format=json', 'scheme') == 'http'
    assert filter_instance['urlsplit']('http://10.20.30.40/path/to/object?format=json', 'path') == '/path/to/object'
    assert filter_instance['urlsplit']('http://10.20.30.40/path/to/object?format=json', 'query') == 'format=json'

# Generated at 2022-06-23 10:35:14.379540
# Unit test for function split_url
def test_split_url():
    url = 'https://playbooks.example.org:8080/playbooks/playbooks/playbook.yml?user=admin&passwd=123456'
    assert split_url(url) == {
        'scheme': 'https',
        'netloc': 'playbooks.example.org:8080',
        'path': '/playbooks/playbooks/playbook.yml',
        'query': 'user=admin&passwd=123456',
        'fragment': ''
    }
    assert split_url(url, 'scheme') == 'https'
    assert split_url(url, 'netloc') == 'playbooks.example.org:8080'
    assert split_url(url, 'path') == '/playbooks/playbooks/playbook.yml'

# Generated at 2022-06-23 10:35:25.062268
# Unit test for function split_url

# Generated at 2022-06-23 10:35:30.763096
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('http://example.org:80/test/test/?a=1&b=2#anchor') == {
        'scheme': 'http', 'netloc': 'example.org:80', 'path': '/test/test/',
        'query': 'a=1&b=2', 'fragment': 'anchor' }
    assert split_url('http://example.org:80/test/test/?a=1&b=2#anchor', 'query') == 'a=1&b=2'

# Generated at 2022-06-23 10:35:33.604608
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for method filters of class FilterModule '''
    f = FilterModule()
    assert f.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:35:35.008909
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:35:37.405000
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:35:40.193269
# Unit test for constructor of class FilterModule
def test_FilterModule():

    test_filter = FilterModule()
    assert 'urlsplit' in test_filter.filters()
    assert callable(test_filter.filters()['urlsplit'])


# Generated at 2022-06-23 10:35:41.767477
# Unit test for constructor of class FilterModule
def test_FilterModule():
    with FilterModule() as f:
        assert dir(f) == ['filters']


# Generated at 2022-06-23 10:35:54.159695
# Unit test for function split_url
def test_split_url():
    assert split_url('https://ansible.com/playbooks/') == {'fragment': '', 'netloc': 'ansible.com', 'path': '/playbooks/', 'query': '', 'scheme': 'https'}, "Should have returned a dictionary of all components."
    assert split_url(None) == {'fragment': '', 'netloc': '', 'path': '', 'query': '', 'scheme': ''}, "Should have returned an empty dictionary."
    assert split_url('https://ansible.com/playbooks/', 'netloc') == 'ansible.com', "Should have returned only the netloc component."

# Generated at 2022-06-23 10:36:04.633971
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    split_url_filters = FilterModule().filters()['urlsplit']
    assert split_url_filters('http://bazooka:BOOM@example.com:8080/foo/bar?a=b&c=d') == 'http://bazooka:BOOM@example.com:8080/foo/bar?a=b&c=d'
    assert split_url_filters('http://bazooka:BOOM@example.com:8080/foo/bar?a=b&c=d', 'scheme') == 'http'
    assert split_url_filters('http://bazooka:BOOM@example.com:8080/foo/bar?a=b&c=d', 'netloc') == 'bazooka:BOOM@example.com:8080'
    assert split

# Generated at 2022-06-23 10:36:05.802578
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None

# Generated at 2022-06-23 10:36:07.785219
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """Tests FilterModule class constructor"""

    obj = FilterModule()
    assert obj is not None


# Generated at 2022-06-23 10:36:10.048061
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
	filter_module = FilterModule()
	result = filter_module.filters()
	assert result['urlsplit'] == split_url


# Generated at 2022-06-23 10:36:11.288279
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  f = FilterModule()
  assert f.filters()['urlsplit'] == split_url