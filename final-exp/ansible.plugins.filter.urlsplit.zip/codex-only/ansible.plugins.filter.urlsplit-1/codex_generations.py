

# Generated at 2022-06-23 10:26:08.388184
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fmod = FilterModule()
    fmod.filters()

# Generated at 2022-06-23 10:26:18.604972
# Unit test for function split_url
def test_split_url():

    # Make sure the alias works (should return the entire dictionary).
    # This is just a smoke test to make sure the test is working.
    assert split_url('http://192.168.1.1:8080/path/to/resource?foo=bar&baz=1', alias='urlsplit')['fragment'] == ''

    # Make sure the query option works.
    # This is just a smoke test to make sure the test is working.
    assert split_url('http://192.168.1.1:8080/path/to/resource?foo=bar&baz=1', query='port') == '8080'

    # Test a domain name.
    result = split_url('http://localhost:8080/path/to/resource?foo=bar&baz=1')


# Generated at 2022-06-23 10:26:20.642455
# Unit test for function split_url
def test_split_url():
    split_url('https://user:pass@example.com:443/foo/bar?param=1&redirect=true#fragment')

# Generated at 2022-06-23 10:26:22.295973
# Unit test for constructor of class FilterModule
def test_FilterModule():
    data = "FilterModule"
    assert data == "FilterModule"

# Generated at 2022-06-23 10:26:29.038443
# Unit test for function split_url
def test_split_url():
    assert split_url("https://www.ansible.com/") == {'hostname': 'www.ansible.com', 'scheme': 'https', 'path': '/', 'netloc': 'www.ansible.com', 'params': '', 'query': '', 'fragment': ''}
    assert split_url("https://www.ansible.com/", "path") == '/'

# Generated at 2022-06-23 10:26:37.383589
# Unit test for function split_url
def test_split_url():
    """ Test split_url function """
    assert split_url('https://examaple.com/api/index.php?query=1', 'scheme') == 'https'
    assert split_url('https://examaple.com/api/index.php?query=1', 'netloc') == 'examaple.com'
    assert split_url('https://examaple.com/api/index.php?query=1', 'path') == '/api/index.php'
    assert split_url('https://examaple.com/api/index.php?query=1', 'query') == 'query=1'
    assert split_url('https://examaple.com/api/index.php?query=1', 'fragment') == ''


# Generated at 2022-06-23 10:26:39.672514
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:26:45.862178
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Given
    from ansible.utils.path import unfrackpath
    from ansible.plugins.filter import uri_split

    # When
    fm = FilterModule()

    # Then
    assert(len(fm.filters()) > 1)
    assert(unfrackpath(fm.filters()['urlsplit'].__code__.co_filename) == unfrackpath(uri_split.__file__))

# ---- UNIT TESTS ----

# Generated at 2022-06-23 10:26:47.505692
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == dict(urlsplit=split_url)

# Generated at 2022-06-23 10:26:58.635116
# Unit test for function split_url
def test_split_url():
    url = 'http://www.example.com:3993/test/url/split?query#fragment'
    url_results = {
        'scheme': 'http',
        'netloc': 'www.example.com:3993',
        'path': '/test/url/split',
        'query': 'query',
        'fragment': 'fragment'
    }

    url_with_empty_query = 'http://www.example.com:3993/test/url/split'
    url_results_with_empty_query = {
        'scheme': 'http',
        'netloc': 'www.example.com:3993',
        'path': '/test/url/split',
        'query': '',
        'fragment': ''
    }


# Generated at 2022-06-23 10:27:04.503557
# Unit test for function split_url
def test_split_url():

    input_dict1 = {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/resource', 'query': 'foo=bar&baz=faz', 'fragment': 'bookmark'}
    input_dict2 = {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/resource', 'query': 'foo=bar&baz=faz'}
    input_dict3 = {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/resource'}

# Generated at 2022-06-23 10:27:08.139249
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_data = 'http://www.google.com/search?q=ansible&hl=en'
    _FilterModule = FilterModule()
    test_results = _FilterModule.filters()['urlsplit'](test_data)
    assert test_results['scheme'] == 'http', 'Test Failed'

# Generated at 2022-06-23 10:27:09.576526
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Unit test for class FilterModule '''
    assert FilterModule

# Generated at 2022-06-23 10:27:21.201901
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

# Generated at 2022-06-23 10:27:32.308250
# Unit test for function split_url
def test_split_url():
    # simple url
    url = 'https://user:passwd@ansible.com:8080/my/path?query=1&query2=2#fragment'
    expected_res = dict(scheme='https', netloc='user:passwd@ansible.com:8080', path='/my/path',
        query='query=1&query2=2', fragment='fragment')
    res = split_url(url)
    assert res == expected_res, res

    # simple url with query=path
    url = 'https://user:passwd@ansible.com:8080/my/path?query=1&query2=2#fragment'
    expected_res = '/my/path'
    res = split_url(url, query='path')
    assert res == expected_res, res

   

# Generated at 2022-06-23 10:27:32.847926
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 1 == 1

# Generated at 2022-06-23 10:27:34.158238
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:27:39.496211
# Unit test for function split_url
def test_split_url():
    urls = [
        ('http://www.example.com/path/to/something?a=1&b=2#frag',
         {'netloc': 'www.example.com', 'scheme': 'http',
          'path': '/path/to/something', 'query': 'a=1&b=2', 'fragment': 'frag'}),
    ]

    for url in urls:
        url_data = split_url(url[0])
        assert url_data == url[1]

# Generated at 2022-06-23 10:27:42.614042
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('http://ansible.com/test?a=1&b=2', 'query') == 'a=1&b=2'



# Generated at 2022-06-23 10:27:44.252011
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert 'urlsplit' in f.filters()


# Generated at 2022-06-23 10:27:47.067812
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    tester = FilterModule()
    filters = tester.filters()
    assert 'urlsplit' in filters


# Generated at 2022-06-23 10:27:56.646305
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """ Unit: FilterModule.filters """
    filter_module = FilterModule()
    assert 'urlsplit' in filter_module.filters()
    urlsplit = filter_module.filters()['urlsplit']
    url = 'http://username:password@localhost:8080/foo/bar?baz#qux'
    assert urlsplit(url, 'scheme') == 'http'
    assert urlsplit(url, 'netloc') == 'username:password@localhost:8080'
    assert urlsplit(url, 'hostname') == 'localhost'
    assert urlsplit(url, 'port') == '8080'
    assert urlsplit(url, 'path') == '/foo/bar'
    assert urlsplit(url, 'query') == 'baz'
    assert urls

# Generated at 2022-06-23 10:28:07.110106
# Unit test for function split_url
def test_split_url():
    assert split_url("http://foo.com/bar/baz") == {
        "params": "",
        "query": "",
        "netloc": "foo.com",
        "fragment": "",
        "scheme": "http",
        "path": "/bar/baz",
    }
    assert split_url("https://foo.com/bar/baz:23") == {
        "params": "23",
        "query": "",
        "netloc": "foo.com",
        "fragment": "",
        "scheme": "https",
        "path": "/bar/baz",
    }

# Generated at 2022-06-23 10:28:16.375786
# Unit test for function split_url
def test_split_url():
    assert split_url(value='http://docs.ansible.com/ansible', query='scheme') == 'http'
    assert split_url(value='http://docs.ansible.com/ansible', query='netloc') == 'docs.ansible.com'
    assert split_url(value='http://docs.ansible.com/ansible', query='path') == '/ansible'

    assert split_url(value='http://docs.ansible.com/ansible', query='foo') == 'scheme'
    assert split_url(value='http://docs.ansible.com/ansible', query='') == {'query': '', 'scheme': 'http', 'netloc': 'docs.ansible.com', 'fragment': '', 'path': '/ansible'}

# Generated at 2022-06-23 10:28:18.384923
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:28:19.840323
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """FilterModule unit test"""
    testFilterModule = FilterModule()
    assert testFilterModule is not None

# Generated at 2022-06-23 10:28:22.774909
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()


# Generated at 2022-06-23 10:28:26.710317
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Create an object of FilterModule
    obj = FilterModule()
    # Test the filters() method
    assert type(obj.filters()) is dict


# Generated at 2022-06-23 10:28:35.395613
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('https://example.org:8000/foo/') == {
        'hostname': 'example.org',
        'netloc': 'example.org:8000',
        'params': '',
        'path': '/foo/',
        'query': '',
        'scheme': 'https',
        'username': '',
        'password': '',
    }
    assert split_url('https://username:password@example.org:8000/foo/', 'username') == 'username'
    assert split_url('https://username:password@example.org:8000/foo/', 'password') == 'password'
    assert split_url('https://username:password@example.org:8000/foo/', 'hostname') == 'example.org'

# Generated at 2022-06-23 10:28:47.438623
# Unit test for function split_url

# Generated at 2022-06-23 10:28:56.530172
# Unit test for function split_url
def test_split_url():

    assert split_url('https://www.example.com/test') == {'path': '/test',
                                                        'query': '',
                                                        'fragment': '',
                                                        'hostname': 'www.example.com',
                                                        'netloc': 'www.example.com',
                                                        'username': '',
                                                        'scheme': 'https',
                                                        'password': '',
                                                        'port': None,
                                                        'params': ''}

# Generated at 2022-06-23 10:29:08.093435
# Unit test for function split_url
def test_split_url():
    url = "http://www.example.com/path/to/page?key1=value1&key2=value2#42"
    assert split_url(url) == {'fragment': '42', 'netloc': 'www.example.com', 'path': '/path/to/page', 'query': 'key1=value1&key2=value2', 'scheme': 'http'}
    assert split_url(url, 'netloc') == 'www.example.com'
    assert split_url(url, 'fragment') == '42'
    assert split_url(url, 'path') == '/path/to/page'
    assert split_url(url, 'query') == 'key1=value1&key2=value2'
    assert split_url(url, 'scheme') == 'http'


# Generated at 2022-06-23 10:29:21.531252
# Unit test for function split_url
def test_split_url():
    assert split_url('http://user:pass@127.0.0.1:8080/path?query#fragment', query='scheme') == 'http'
    assert split_url('http://user:pass@127.0.0.1:8080/path?query#fragment', query='netloc') == 'user:pass@127.0.0.1:8080'
    assert split_url('http://user:pass@127.0.0.1:8080/path?query#fragment', query='path') == '/path'
    assert split_url('http://user:pass@127.0.0.1:8080/path?query#fragment', query='params') == ''

# Generated at 2022-06-23 10:29:24.681212
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    assert {'urlsplit': split_url} == x.filters()


# Generated at 2022-06-23 10:29:35.964880
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert split_url("http://example.com:8080/path/to?query=string#fragment",
                     'scheme') == 'http'
    assert split_url("http://example.com:8080/path/to?query=string#fragment",
                     'netloc') == 'example.com:8080'
    assert split_url("http://example.com:8080/path/to?query=string#fragment",
                     'path') == '/path/to'
    assert split_url("http://example.com:8080/path/to?query=string#fragment",
                     'query') == 'query=string'

# Generated at 2022-06-23 10:29:37.395830
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert hasattr(obj, 'filters')


# Generated at 2022-06-23 10:29:39.140216
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'urlsplit' == filter_module.filters().keys()[0]

# Generated at 2022-06-23 10:29:42.115596
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:29:43.743032
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert type(fm) == FilterModule


# Generated at 2022-06-23 10:29:46.522804
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  module = FilterModule()
  test_filters = module.filters()
  assert test_filters['urlsplit'] == split_url


# Generated at 2022-06-23 10:29:48.357616
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:29:49.289440
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert(fm is not None)


# Generated at 2022-06-23 10:29:50.125889
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filter_module.filters()

# Generated at 2022-06-23 10:29:54.629591
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(None) == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:29:57.784741
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

    assert fm.filters().get('urlsplit')
    assert fm.filters().get('urlsplit') == split_url


# Generated at 2022-06-23 10:30:04.864931
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    uri = "http://example.com/path?key=value#frag"
    expected = {
        'scheme': 'http',
        'netloc': 'example.com',
        'path': '/path',
        'query': 'key=value',
        'fragment': 'frag',
        'username': '',
        'password': '',
        'hostname': 'example.com',
        'port': ''}
    result = filter_module.filters()['urlsplit'](uri)
    assert result == expected

    query = "scheme"
    result = filter_module.filters()['urlsplit'](uri, query)
    assert result == expected[query]


# Generated at 2022-06-23 10:30:07.825906
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert split_url("http://example.com/foo/bar/?baz=quux#xyzzy") == "quux"

# Generated at 2022-06-23 10:30:09.770209
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:30:12.871169
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None
    assert fm.filters is not None

# Constructor for class FilterModule
fm = FilterModule()


# Generated at 2022-06-23 10:30:14.075768
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, '__init__')


# Generated at 2022-06-23 10:30:18.004101
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    class FilterModuleTester(object):

        def filters(self):
            return {
                'urlsplit': split_url
            }

    filter_module = FilterModuleTester()
    result = filter_module.filters()
    assert result['urlsplit'] == split_url


# Generated at 2022-06-23 10:30:28.254968
# Unit test for function split_url
def test_split_url():
    value = 'http://test.com/test/test?test=test'
    test_dict = {
        'scheme': 'http',
        'netloc': 'test.com',
        'path': '/test/test',
        'query': 'test=test',
        'fragment': ''
    }
    test_result = split_url(value)
    assert test_result == test_dict

    test_result = split_url(value, 'scheme')
    assert test_result == 'http'

    test_result = split_url(value, 'asdlkfj')
    assert test_result == 'Unknown URL component: asdlkfj'

# Generated at 2022-06-23 10:30:29.365593
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()


# Generated at 2022-06-23 10:30:37.516118
# Unit test for function split_url
def test_split_url():

    # Fully qualified domain name
    value = 'https://ansible.com/documentation'

    # Test the full object
    assert split_url(value) == {
        'hostname': 'ansible.com',
        'netloc': 'ansible.com',
        'path': 'documentation',
        'port': None,
        'query': '',
        'scheme': 'https',
        'username': '',
        'password': ''
    }

    # Test individual components
    assert split_url(value, query='hostname') == 'ansible.com'
    assert split_url(value, query='netloc') == 'ansible.com'
    assert split_url(value, query='path') == 'documentation'
    assert split_url(value, query='port') == None

# Generated at 2022-06-23 10:30:48.096840
# Unit test for constructor of class FilterModule
def test_FilterModule():

    url = "http://www.example.com:8000/path?query=1"
    expected_dict = {
        'scheme': 'http',
        'netloc': 'www.example.com:8000',
        'path': '/path',
        'query': 'query=1'
    }

    fm = FilterModule()
    result = fm.filters()['urlsplit'](url)
    assert result == expected_dict

    result = fm.filters()['urlsplit'](url, 'query')
    assert result == expected_dict['query']

    try:
        result = fm.filters()['urlsplit'](url, 'unknown')
    except AnsibleFilterError:
        result = None
    assert result == None

# Generated at 2022-06-23 10:30:48.495306
# Unit test for constructor of class FilterModule
def test_FilterModule():
  assert FilterModule()

# Generated at 2022-06-23 10:30:50.063090
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert(filter_module.filters() == {'urlsplit': split_url})


# Generated at 2022-06-23 10:30:51.868914
# Unit test for constructor of class FilterModule
def test_FilterModule():
    split_url('https://ansible.com', query='netloc') == 'ansible.com'

# Generated at 2022-06-23 10:30:53.480859
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() is not None


# Generated at 2022-06-23 10:31:05.348151
# Unit test for function split_url
def test_split_url():
    '''
    Test case for the split_url function.
    '''

    # Test the query string
    obj = split_url('https://www.example.org', 'scheme')
    assert_equal(obj, 'https')

    # Test the invalid query string
    obj = split_url('https://www.example.org', 'invalid')
    assert_equal(obj, False)

    # Test the entire dictionary
    obj = split_url('https://www.example.org')
    assert_equal(obj, {'scheme': 'https', 'netloc': 'www.example.org', 'path': '', 'query': '', 'fragment': ''})

    # Test the URL with the port number

# Generated at 2022-06-23 10:31:20.134986
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' test_FilterModule(urlsplit, query='', alias='urlsplit') '''

    # Class object instantiation
    urlsplit_obj = FilterModule

    # Object instantiation to test
    test_urlsplit = urlsplit_obj.filters()['urlsplit']

    # Tests
    assert test_urlsplit('https://www.ansible.com/webinars/a-tour-of-the-ansible-tower-apis') == {'scheme': 'https', 'netloc': 'www.ansible.com', 'path': '/webinars/a-tour-of-the-ansible-tower-apis', 'query': '', 'fragment': ''}

# Generated at 2022-06-23 10:31:28.101578
# Unit test for function split_url
def test_split_url():
    url = 'http://www.example.com:8080/foo/bar?spam=eggs#xyzzy'
    assert split_url(url) == {'fragment': 'xyzzy', 'netloc': 'www.example.com:8080', 'path': '/foo/bar', 'query': 'spam=eggs', 'scheme': 'http', 'username': None, 'password': None, 'hostname': 'www.example.com', 'port': 8080}
    assert split_url(url, 'path') == '/foo/bar'
    assert split_url(url, 'unknown') == AnsibleFilterError('urlsplit: unknown URL component: unknown')

# Generated at 2022-06-23 10:31:29.001872
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == split_url

# Generated at 2022-06-23 10:31:33.435663
# Unit test for function split_url
def test_split_url():
    ansible_function = split_url(
        "https://docs.ansible.com/ansible/latest/user_guide/playbooks_filters.html#splitting-urls",
        query="query",
    )
    python_function = urlsplit("https://docs.ansible.com/ansible/latest/user_guide/playbooks_filters.html#splitting-urls").query
    assert ansible_function == python_function

# Generated at 2022-06-23 10:31:35.561323
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert type(FilterModule()) is FilterModule

# Unit tests for method split_url()

# Generated at 2022-06-23 10:31:38.091528
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:31:48.027906
# Unit test for function split_url
def test_split_url():

    url = 'http://www.uconn.edu/a/b/c/d/e.html?a=1&b=1'
    result = split_url(url, '')
    assert result['scheme'] == 'http', "Failure: test_split_url(): scheme not equal to 'http'"
    assert result['netloc'] == 'www.uconn.edu', "Failure: test_split_url(): netloc not equal to 'www.uconn.edu'"
    assert result['path'] == '/a/b/c/d/e.html', "Failure: test_split_url(): path not equal to '/a/b/c/d/e.html'"
    assert result['query'] == 'a=1&b=1', "Failure: test_split_url(): query not equal to 'a=1&b=1'"


# Generated at 2022-06-23 10:31:49.374583
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters()

# Generated at 2022-06-23 10:31:54.778341
# Unit test for function split_url
def test_split_url():
    url = "https://github.com/jctanner/ansible-urlsplit"
    results = split_url(url)
    assert results['scheme'] == 'https'
    assert results['netloc'] == 'github.com'
    assert results['path'] == '/jctanner/ansible-urlsplit'
    assert len(results) == 7
    assert split_url(url, 'scheme') == 'https'
    assert split_url(url, 'netloc') == 'github.com'
    assert split_url(url, 'path') == '/jctanner/ansible-urlsplit'

# Generated at 2022-06-23 10:32:05.156991
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    d = {'test': 'example.com:8080/test_path'}
    f = FilterModule()
    assert f.filters()['urlsplit'](d['test']) == {'netloc': 'example.com:8080', 'scheme': '', 'path': '/test_path', 'query': '', 'fragment': ''}
    assert f.filters()['urlsplit'](d['test'], 'netloc') == 'example.com:8080'
    assert f.filters()['urlsplit'](d['test'], 'scheme') == ''
    assert f.filters()['urlsplit'](d['test'], 'path') == '/test_path'
    assert f.filters()['urlsplit'](d['test'], 'query') == ''

# Generated at 2022-06-23 10:32:06.554318
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:32:07.377027
# Unit test for constructor of class FilterModule
def test_FilterModule():
  FilterModule()


# Generated at 2022-06-23 10:32:08.416924
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(FilterModule().filters()['urlsplit'] == split_url)

# Generated at 2022-06-23 10:32:12.298601
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:32:14.140117
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module != None


# Generated at 2022-06-23 10:32:23.227969
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Create a test FilterModule instance
    instance = FilterModule()

    # Create a test dictionary with expected results
    test_data = {
        'http://user:pass@localhost:80/path?query#fragment': {
            'scheme': 'http',
            'netloc': 'user:pass@localhost:80',
            'path': '/path',
            'query': 'query',
            'fragment': 'fragment'
        },
        'http://www.ansible.com/path/to/file': {
            'scheme': 'http',
            'netloc': 'www.ansible.com',
            'path': '/path/to/file',
            'query': '',
            'fragment': ''
        }
    }

    # Test urlsplit method

# Generated at 2022-06-23 10:32:25.788919
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule.filters)



# Generated at 2022-06-23 10:32:28.294811
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    assert FilterModule.filters(None) == {'urlsplit': split_url}



# Generated at 2022-06-23 10:32:29.522996
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()
    assert FilterModule().filters()

# Generated at 2022-06-23 10:32:31.354232
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == { 'urlsplit': split_url }

# Generated at 2022-06-23 10:32:34.799694
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' test_FilterModule_filters '''

    fm = FilterModule()
    filters = fm.filters()

    assert 'urlsplit' in filters



# Generated at 2022-06-23 10:32:39.612732
# Unit test for function split_url
def test_split_url():
    split_url('http://ansible.com/nosuchpage') == {
        'scheme': 'http',
        'netloc': 'ansible.com',
        'path': '/nosuchpage',
        'params': '',
        'query': '',
        'fragment': ''
    }

# Generated at 2022-06-23 10:32:41.859685
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fmodule = FilterModule()
    assert fmodule.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:32:43.419530
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert 'urlsplit' in filters

# Generated at 2022-06-23 10:32:45.428288
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    assert 'urlsplit' in x.filters()


# Generated at 2022-06-23 10:32:47.170100
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
            'urlsplit': split_url
    }

# Generated at 2022-06-23 10:32:49.712056
# Unit test for constructor of class FilterModule
def test_FilterModule():

    filter_module = FilterModule()

    assert filter_module
    assert filter_module.filters
    assert filter_module.filters()
    assert filter_module.filters()['urlsplit']

# Generated at 2022-06-23 10:32:50.864162
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    return fm


# Generated at 2022-06-23 10:32:51.933139
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)


# Generated at 2022-06-23 10:32:52.982024
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:32:55.819236
# Unit test for constructor of class FilterModule
def test_FilterModule():
    file = FilterModule()
    assert file.filters()['urlsplit'] is split_url


if __name__ == '__main__':
    test_FilterModule()

# Generated at 2022-06-23 10:32:57.938414
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fi = FilterModule()
    assert fi.filters()['urlsplit'].__name__ == 'split_url'

# Generated at 2022-06-23 10:33:07.962086
# Unit test for function split_url
def test_split_url():
    assert split_url("http://some.tld/foo/bar/baz.html?key=value&q=foo") == {'path': '/foo/bar/baz.html', 'scheme': 'http', 'netloc': 'some.tld', 'query': 'key=value&q=foo', 'fragment': '', 'username': None, 'hostname': 'some.tld', 'port': None}

# Generated at 2022-06-23 10:33:09.641932
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule) == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:33:10.495945
# Unit test for constructor of class FilterModule
def test_FilterModule():
    pass

# Generated at 2022-06-23 10:33:12.294358
# Unit test for constructor of class FilterModule
def test_FilterModule():
    SplitUrl = FilterModule()
    assert SplitUrl.filters()['urlsplit'] == split_url



# Generated at 2022-06-23 10:33:21.539457
# Unit test for function split_url
def test_split_url():

    # test_split_url: no query, return dict
    result = split_url('https://example.com/path/to/file')
    assert result['scheme'] == 'https'
    assert result['netloc'] == 'example.com'
    assert result['path'] == '/path/to/file'

    # test_split_url: valid query, return component
    result = split_url('https://example.com/path/to/file', query='scheme')
    assert result == 'https'

    # test_split_url: invalid query, raise exception
    try:
        result = split_url('https://example.com/path/to/file', query='foobar')
    except Exception as err:
        assert isinstance(err, AnsibleFilterError)

# Generated at 2022-06-23 10:33:23.623144
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(None)['urlsplit'] is split_url


# Generated at 2022-06-23 10:33:24.282688
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-23 10:33:29.237024
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.python.org/dev/peps/pep-0396/')['scheme'] == 'http'
    assert split_url('http://www.python.org/dev/peps/pep-0396/', 'hostname') == 'www.python.org'

# Generated at 2022-06-23 10:33:31.980620
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:33:37.988751
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert split_url('https://www.example.com/foo/bar')['scheme'] == 'https'
    assert split_url('https://www.example.com/foo/bar', 'scheme') == 'https'
    assert split_url('https://www.example.com/foo/bar', 'netloc') == 'www.example.com'
    assert split_url('https://www.example.com/foo/bar', 'path') == '/foo/bar'
    assert split_url('https://www.example.com/foo/bar', 'fragment') == ''
    assert split_url('https://www.example.com/foo/bar', 'foo') == ''

# Generated at 2022-06-23 10:33:51.107729
# Unit test for function split_url
def test_split_url():
    assert split_url('http://test.example.com:8000/a/b/c?hello=1', 'scheme') == 'http'
    assert split_url('http://test.example.com:8000/a/b/c?hello=1', 'netloc') == 'test.example.com:8000'
    assert split_url('http://test.example.com:8000/a/b/c?hello=1', 'path') == '/a/b/c'
    assert split_url('http://test.example.com:8000/a/b/c?hello=1', 'query') == 'hello=1'
    assert split_url('http://test.example.com:8000/a/b/c?hello=1', 'fragment') == ''

# Generated at 2022-06-23 10:33:52.651801
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module is not None

# Generated at 2022-06-23 10:34:03.640792
# Unit test for function split_url
def test_split_url():
    test_url = 'http://localhost/foo/bar.php'
    url = split_url(test_url)
    assert url['scheme'] == 'http'
    assert url['netloc'] == 'localhost'
    assert url['path'] == '/foo/bar.php'
    assert url['query'] == ''
    assert url['fragment'] == ''
    assert url['username'] is None
    assert url['password'] is None
    assert url['hostname'] == 'localhost'
    assert url['port'] is None

    url = split_url(test_url, query='scheme')
    assert url == 'http'

    url = split_url(test_url, query='hostname')
    assert url == 'localhost'

    url = split_url(test_url, query='port')
    assert url is None



# Generated at 2022-06-23 10:34:07.212191
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for method filters of class FilterModule '''
    test_obj = FilterModule()
    assert hasattr(test_obj, 'filters')
    assert isinstance(test_obj.filters, types.MethodType)


# Generated at 2022-06-23 10:34:11.763770
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    with pytest.raises(AnsibleFilterError) as excinfo:
        filter_module = FilterModule()
        filter_module.filters()['urlsplit']('https://www.ansible.com', query='blah')
    assert 'unknown URL component' in str(excinfo.value)
    assert 'blah' in str(excinfo.value)



# Generated at 2022-06-23 10:34:14.091408
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f
    assert f.filters()



# Generated at 2022-06-23 10:34:14.673170
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert 'urlsplit' in FilterModule.filters(None)



# Generated at 2022-06-23 10:34:15.890207
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    print(fm.filters())



# Generated at 2022-06-23 10:34:18.643883
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    fn = getattr(f, 'filters')
    assert callable(fn)
    assert fn() == {"urlsplit": split_url}


# Generated at 2022-06-23 10:34:25.207516
# Unit test for function split_url
def test_split_url():
    test_value = 'http://www.example.com:80/path?arg=value#fragment'

    test_dict = {
        'scheme': 'http',
        'netloc': 'www.example.com:80',
        'path': '/path',
        'query': 'arg=value',
        'fragment': 'fragment',
    }

    assert split_url(test_value) == test_dict, 'split_url dictionary mismatch'
    assert split_url(test_value, 'scheme') == test_dict['scheme'], 'split_url key mismatch'

# Generated at 2022-06-23 10:34:34.832725
# Unit test for function split_url
def test_split_url():
    assert split_url('mccloud-lab-infra.example.com:8443') == {'fragment': '', 'scheme': '', 'netloc': 'mccloud-lab-infra.example.com:8443', 'path': '', 'query': ''}
    assert split_url('mccloud-lab-infra.example.com:8443', 'netloc') == 'mccloud-lab-infra.example.com:8443'

# Generated at 2022-06-23 10:34:48.980840
# Unit test for function split_url
def test_split_url():
    assert split_url("http://USER:PASSWORD@www.domain.com/path/file.ext?a=1&b=2#anchor") == {'scheme': 'http', 'netloc': 'USER:PASSWORD@www.domain.com', 'path': '/path/file.ext', 'query': 'a=1&b=2', 'fragment': 'anchor'}
    assert split_url("http://USER:PASSWORD@www.domain.com/path/file.ext?a=1&b=2#anchor", 'scheme') == 'http'
    assert split_url("http://USER:PASSWORD@www.domain.com/path/file.ext?a=1&b=2#anchor", 'netloc') == 'USER:PASSWORD@www.domain.com'
   

# Generated at 2022-06-23 10:34:49.859719
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:34:59.156587
# Unit test for function split_url
def test_split_url():

    # Query by name
    assert split_url('http://www.example.com', 'netloc') == 'www.example.com'

    # Query by number
    assert split_url('http://www.example.com', '2') == 'www.example.com'

    # Query by number, expecting ValueError
    try:
        split_url('http://www.example.com', '6')
    except ValueError as e:
        assert isinstance(e, ValueError)

    # Return full dictionary

# Generated at 2022-06-23 10:35:10.853578
# Unit test for function split_url
def test_split_url():
    test_url1 = "http://www.google.com:80"
    test_url2 = "https://www.google.com:443"
    test_url3 = "ftp://www.google.com:21"

    assert split_url(test_url1, query='scheme') == 'http'
    assert split_url(test_url2, query='scheme') == 'https'
    assert split_url(test_url3, query='scheme') == 'ftp'

    assert split_url(test_url1, query='netloc') == 'www.google.com:80'
    assert split_url(test_url1, query='path') == ''
    assert split_url(test_url2, query='path') == ''


# Generated at 2022-06-23 10:35:17.259205
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils.common._collections_compat import Mapping
    test_url = 'http://www.example.com:8080/path/to/file.php?foo=bar&baz=baw#anchor'
    url_values = {
        'scheme': 'http',
        'netloc': 'www.example.com:8080',
        'path': '/path/to/file.php',
        'query': 'foo=bar&baz=baw',
        'fragment': 'anchor'
    }
    results = split_url(test_url)
    assert isinstance(results, Mapping)
    assert results['scheme'] == url_values['scheme']
    assert results['netloc'] == url_values['netloc']
    assert results['path'] == url_

# Generated at 2022-06-23 10:35:19.260256
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None 


# Generated at 2022-06-23 10:35:29.525502
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    test_url = 'https://user:pass@host.com:1234/path;param?query=arg#frag'
    test_args = [
        "scheme",
        "netloc",
        "path",
        "params",
        "query",
        "fragment",
        "username",
        "password",
        "hostname",
        "port",
    ]
    test_results = urlsplit(test_url)
    for arg in test_args:
        if getattr(test_results, arg) != split_url(test_url, query=arg):
            raise AssertionError('Failed: %s' % arg)

# Generated at 2022-06-23 10:35:32.232397
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    t = FilterModule()
    keys = t.filters().keys()
    keys.sort()
    assert keys == ['urlsplit']


# Generated at 2022-06-23 10:35:34.119969
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == { 'urlsplit': split_url }

# Generated at 2022-06-23 10:35:36.596228
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test1 = FilterModule()
    test_results = test1.filters()
    assert test_results['urlsplit'] == split_url


# Generated at 2022-06-23 10:35:37.919993
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module is not None


# Generated at 2022-06-23 10:35:42.829498
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert split_url("https://www.google.com")['scheme'] == 'https'
    assert split_url("https://www.google.com", "scheme") == 'https'

# Generated at 2022-06-23 10:35:45.258210
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    test = FilterModule()
    assert test.filters()['urlsplit'] is split_url

# Generated at 2022-06-23 10:35:55.473313
# Unit test for function split_url
def test_split_url():
    assert split_url('foo.com', 'scheme') == ''
    assert split_url('foo.com', 'netloc') == 'foo.com'
    assert split_url('foo.com', 'path') == ''
    assert split_url('http://foo.com', 'scheme') == 'http'
    assert split_url('http://foo.com', 'netloc') == 'foo.com'
    assert split_url('http://foo.com', 'path') == ''
    assert split_url('http://foo.com:8000', 'port') == '8000'
    assert split_url('http://foo.com', 'port') == '80'
    assert split_url('http://foo.com/path?x=1&y=2', 'query') == 'x=1&y=2'
    assert split_url

# Generated at 2022-06-23 10:35:58.285050
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters.keys() == {"urlsplit"}

# Unit tests for split_url

# Generated at 2022-06-23 10:36:01.380001
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    fm = FilterModule()
    filters = fm.filters()

    assert len(list(filters.keys())) == 1

    assert filters['urlsplit'] == split_url



# Generated at 2022-06-23 10:36:03.328772
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fl = FilterModule()
    assert fl.filters() is not None

# Generated at 2022-06-23 10:36:13.190140
# Unit test for function split_url
def test_split_url():

    # test for a valid URL
    assert(split_url('http://ansible.com/test') == {'scheme': 'http', 'netloc': 'ansible.com',
                                                    'path': '/test', 'query': '', 'fragment': ''})

    # test for an invalid URL
    try:
        split_url(None)
    except AssertionError as e:
        pass
    else:
        raise AssertionError('Expected assertion in split_url()')

    # test for a query option
    assert(split_url('http://ansible.com/test',query='path') == '/test')

    # test for an invalid query option
    try:
        split_url('http://ansible.com/test',query='invalid')
    except AssertionError as e:
        pass
