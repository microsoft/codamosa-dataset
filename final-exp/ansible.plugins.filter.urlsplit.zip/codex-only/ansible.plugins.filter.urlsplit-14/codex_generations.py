

# Generated at 2022-06-23 10:26:19.797879
# Unit test for function split_url
def test_split_url():
    assert split_url(value='http://www.example.com/path/to/file?key=val&foo=bar', query='scheme') == 'http'
    assert split_url(value='http://www.example.com/path/to/file?key=val&foo=bar', query='netloc') == 'www.example.com'
    assert split_url(value='http://www.example.com/path/to/file?key=val&foo=bar', query='path') == '/path/to/file'
    assert split_url(value='http://www.example.com/path/to/file?key=val&foo=bar', query='query') == 'key=val&foo=bar'

# Generated at 2022-06-23 10:26:21.559454
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
        'urlsplit': split_url
    }

# Generated at 2022-06-23 10:26:22.669942
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-23 10:26:28.892346
# Unit test for constructor of class FilterModule
def test_FilterModule():
    json_obj = {"one": 1, "two": 2, "three": 3, "four": 4}
    json_obj2 = {"two": 2.0, "four": 4.0}
    assert (isinstance(FilterModule(), FilterModule))
    assert (len(json_obj) == 4)
    assert (len(json_obj2) == 2)

# Generated at 2022-06-23 10:26:32.603913
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    expected = 'bar'
    actual = module.filters()['urlsplit']('scheme://example.com/foo/bar', 'query')
    assert actual == expected

# Generated at 2022-06-23 10:26:34.558218
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    assert len(x.filters()) == 1
    assert x.filters()['urlsplit'] is not None


# Generated at 2022-06-23 10:26:45.563423
# Unit test for function split_url
def test_split_url():
    assert split_url('http://ansible.com') == {'scheme': 'http', 'netloc': 'ansible.com', 'path': '', 'params': '', 'query': '', 'fragment': ''}
    assert split_url('http://ansible.com', 'scheme') == 'http'
    assert split_url('http://ansible.com', 'path') == ''
    assert split_url('https://ansible.com/docs') == {'scheme': 'https', 'netloc': 'ansible.com', 'path': '/docs', 'params': '', 'query': '', 'fragment': ''}
    assert split_url('https://ansible.com/docs', 'path') == '/docs'



# Generated at 2022-06-23 10:26:50.041300
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter = FilterModule()
    assert filter.filters() == {'urlsplit': split_url}



# Generated at 2022-06-23 10:26:51.240864
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None


# Generated at 2022-06-23 10:26:56.694632
# Unit test for function split_url
def test_split_url():
    input_string = 'http://www.ansible.org/docs-creating'
    expected_results = {
        'fragment': '',
        'netloc': 'www.ansible.org',
        'path': '/docs-creating',
        'query': '',
        'scheme': 'http',
    }

    results = split_url(input_string)

    assert results == expected_results

# Generated at 2022-06-23 10:27:01.520009
# Unit test for function split_url

# Generated at 2022-06-23 10:27:05.025010
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter = FilterModule()
    # Unit test for filters method of class FilterModule
    assert filter.filters()

# Generated at 2022-06-23 10:27:07.091240
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert(filters['urlsplit'] == split_url)

# Generated at 2022-06-23 10:27:18.319404
# Unit test for function split_url
def test_split_url():
    assert split_url(value='http://www.example.net/path/to/file.ext?id=10&param=test', query='scheme') == 'http'
    assert split_url(value='http://www.example.net/path/to/file.ext?id=10&param=test') == {
        'netloc': 'www.example.net',
        'fragment': '',
        'path': '/path/to/file.ext',
        'params': '',
        'query': 'id=10&param=test',
        'scheme': 'http'
    }
    try:
        split_url(value='http://www.example.net/path/to/file.ext?id=10&param=test', query='bogus')
    except Exception as e:
        assert isinstance

# Generated at 2022-06-23 10:27:20.780324
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert (
        FilterModule().filters()  # pylint: disable=no-value-for-parameter
        == {'urlsplit': split_url}
    )

# Generated at 2022-06-23 10:27:27.908789
# Unit test for function split_url
def test_split_url():
    from operator import itemgetter
    from ansible.utils.unicode import to_str


# Generated at 2022-06-23 10:27:29.689401
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert 'urlsplit' in module.filters()


# Generated at 2022-06-23 10:27:31.811067
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter = FilterModule()
    assert filter.filters() is not None


# Generated at 2022-06-23 10:27:33.254166
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert 'urlsplit' in f.filters()

# Generated at 2022-06-23 10:27:35.279539
# Unit test for constructor of class FilterModule
def test_FilterModule():
    result = FilterModule().filters()
    assert(result ==
           {'urlsplit': split_url})



# Generated at 2022-06-23 10:27:36.819604
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()

# Generated at 2022-06-23 10:27:37.776238
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-23 10:27:40.037930
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)


# Generated at 2022-06-23 10:27:49.045884
# Unit test for function split_url
def test_split_url():

    url = "http://www.example.com/path/to/foo.html"

    # Check that the correct scheme with capitalization is returned
    assert split_url(url, 'scheme') == "http"

    # Check that the correct netloc is returned
    assert split_url(url, 'netloc') == "www.example.com"

    # Check that the correct path is returned
    assert split_url(url, 'path') == '/path/to/foo.html'

    # Check that all values are returned (as a dictionary) when no query is provided
    assert split_url(url) == \
      {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/foo.html', 'params': '', 'query': '', 'fragment': ''}

    # Check that

# Generated at 2022-06-23 10:27:57.951323
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert split_url('https://www.example.com/search?q=uri#ansible')
    assert split_url('https://www.example.com/search?q=uri#ansible', '')
    assert split_url('https://www.example.com/search?q=uri#ansible', 'scheme') == 'https'
    assert split_url('https://www.example.com/search?q=uri#ansible', 'netloc') == 'www.example.com'
    assert split_url('https://www.example.com/search?q=uri#ansible', 'path') == '/search'
    assert split_url('https://www.example.com/search?q=uri#ansible', 'query') == 'q=uri'

# Generated at 2022-06-23 10:28:05.678027
# Unit test for constructor of class FilterModule
def test_FilterModule():
    tests = {
        # test no value
        'url': 'http://www.example.com/path?key1=val1&key2=val2#fragment',
        'query': '',
        'alias': 'urlsplit',
        'return': 'www.example.com'
    }
    # test with value
    test_obj = FilterModule()
    actual = test_obj.filters()['urlsplit'](tests['url'], tests['query'], tests['alias'])
    assert actual == tests['return']

# Generated at 2022-06-23 10:28:08.372047
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()

# Generated at 2022-06-23 10:28:17.954617
# Unit test for constructor of class FilterModule
def test_FilterModule():
    class_ = FilterModule()
    assert class_ is not None


# Generated at 2022-06-23 10:28:24.849190
# Unit test for function split_url
def test_split_url():
    # Test a simple URL
    url = 'http://www.google.com'
    results = split_url(url)
    assert results['scheme'] == 'http'
    assert results['netloc'] == 'www.google.com'
    assert results['path'] == '/'

    # Test a URL with a port
    url = 'http://www.google.com:8080/'
    results = split_url(url)
    assert results['scheme'] == 'http'
    assert results['netloc'] == 'www.google.com:8080'
    assert results['path'] == '/'

    # Test a URL with a path
    url = 'http://www.google.com/page'
    results = split_url(url)
    assert results['scheme'] == 'http'

# Generated at 2022-06-23 10:28:34.380544
# Unit test for function split_url
def test_split_url():
    from six import PY3
    from ansible.compat.tests.mock import patch, Mock

    # mock the urlsplit function in order to stub the input and return
    # a known set of values. We'll call this mock SplitResult.
    def mock_urlsplit(value, scheme='', allow_fragments=True):
        class SplitResult(object):
            def __init__(self):
                self.netloc = 'github.com'
                self.scheme = 'ssh'
                self.path = '/ansible/ansible'
                self.query = 'branch=devel'
                self.fragment = 'devel'


# Generated at 2022-06-23 10:28:35.393632
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert 'urlsplit' in module.filters()

# Generated at 2022-06-23 10:28:40.671501
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fmodule = FilterModule()
    fmodule_filters = fmodule.filters()

    assert 'urlsplit' in fmodule_filters
    assert callable(fmodule_filters['urlsplit'])

# Generated at 2022-06-23 10:28:42.686210
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters == {'urlsplit': split_url}


# Generated at 2022-06-23 10:28:48.523329
# Unit test for function split_url
def test_split_url():
    assert split_url("http://www.example.com/pages/") == {
            'hostname': 'www.example.com',
            'password': None,
            'path': '/pages/',
            'port': None,
            'query': '',
            'scheme': 'http',
            'username': None
        }

# Generated at 2022-06-23 10:28:55.286525
# Unit test for function split_url
def test_split_url():
    url = 'http://username:password@localhost:8080/some/path?key=val&another_key=another_val#some_frag'

    results = split_url(url)
    assert results == {
        'scheme': 'http',
        'netloc': 'username:password@localhost:8080',
        'path': '/some/path',
        'query': 'key=val&another_key=another_val',
        'fragment': 'some_frag'
    }

    assert results['scheme'] == split_url(url, 'scheme')

# Generated at 2022-06-23 10:28:58.060312
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert (hasattr(FilterModule, '__init__'))

# Generated at 2022-06-23 10:29:01.917721
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    if callable(getattr(module, 'filters', None)):
        assert 'urlsplit' in module.filters()
        assert callable(module.filters()['urlsplit'])

# Generated at 2022-06-23 10:29:02.674166
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(isinstance(FilterModule(), FilterModule))


# Generated at 2022-06-23 10:29:12.124803
# Unit test for function split_url
def test_split_url():
    import os
    import sys
    import pytest
    sys.path.append(os.path.dirname(__file__) + '/../')
    from lib.urlfilters import split_url

    # Test aliases
    assert split_url("https://www.test.com", "scheme", "urlsplit_test") == "https"

    # Test no query
    assert split_url("https://www.test.com", "", "urlsplit_test") == {'scheme': 'https', 'netloc': 'www.test.com', 'path': '', 'query': '', 'fragment': ''}

    # Test no query, scheme
    assert split_url("https://www.test.com", "scheme", "urlsplit_test") == "https"

    # Test no query, netloc
    assert split_

# Generated at 2022-06-23 10:29:18.568231
# Unit test for function split_url
def test_split_url():
    url = 'https://www.example.org/path/to/a/file?with=arguments#hash'

    assert split_url(url)['scheme'] == 'https'
    assert split_url(url, 'scheme') == 'https'
    assert split_url(url)['path'] == '/path/to/a/file'
    assert split_url(url, 'path') == '/path/to/a/file'
    assert split_url(url)['query'] == 'with=arguments'
    assert split_url(url, 'query') == 'with=arguments'
    assert split_url(url, 'fragment') == 'hash'
    assert split_url(url)['fragment'] == 'hash'

# Generated at 2022-06-23 10:29:20.509650
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)
    assert callable(FilterModule)


# Generated at 2022-06-23 10:29:22.668945
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None
    assert fm.filters() is not None
    assert 'urlsplit' in fm.filters()


# Generated at 2022-06-23 10:29:29.483828
# Unit test for function split_url
def test_split_url():
    url = "https://www.example.com/path/to/something?some=query&some=query2"
    result = split_url(url)
    assert result['scheme'] == 'https', "Wrong scheme"
    assert result['netloc'] == 'www.example.com', "Wrong netloc"
    assert result['path'] == '/path/to/something', "Wrong path"
    assert result['query'] == 'some=query&some=query2', "Wrong query"
    result = split_url(url, 'scheme')
    assert result == 'https', "Wrong scheme"
    result = split_url(url, 'netloc')
    assert result == 'www.example.com', "Wrong netloc"
    result = split_url(url, 'path')

# Generated at 2022-06-23 10:29:39.140301
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    urldict = {'fragment': '', 'netloc': 'ansible.com', 'path': '/docs', 'scheme': 'http', 'query': ''}
    assert split_url('http://ansible.com/docs') == urldict
    assert split_url('http://ansible.com/docs', query='netloc') == urldict['netloc']
    assert split_url('http://ansible.com/docs', query='path') == urldict['path']
    assert split_url('http://ansible.com/docs', query='scheme') == urldict['scheme']
    assert split_url('http://ansible.com/docs', query='query') == urldict['query']
    assert split_url('http://ansible.com/docs', query='fragment') == urldict

# Generated at 2022-06-23 10:29:50.969461
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    basic._ANSIBLE_ARGS = to_bytes('')

    def assert_valid_urlsplit(assertion, expected, input, query=""):
        """
        Performs a urlsplit(jsonutil.dumps(input)) call and
        asserts that a certain - if any - field has a certain value.
        """
        results = split_url(input, query)
        assertionEqual(assertion, expected, results)

    # simple unit test

# Generated at 2022-06-23 10:29:55.383859
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() == { 'urlsplit': split_url }

# ---- Unit tests for class FilterModule ----

# Generated at 2022-06-23 10:29:57.864392
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    results = fm.filters()

    assert 'urlsplit' in results
    assert callable(results['urlsplit'])

# Generated at 2022-06-23 10:30:05.447870
# Unit test for function split_url
def test_split_url():
    urls = {
        "http://www.example.com/index.php?foo=bar&baz=buz": {
            "scheme": "http",
            "netloc": "www.example.com",
            "path": "/index.php",
            "query": "foo=bar&baz=buz",
            "fragment": ""
        },
        "http://www.example.com/index.php?foo=bar&baz=buz#test": {
            "scheme": "http",
            "netloc": "www.example.com",
            "path": "/index.php",
            "query": "foo=bar&baz=buz",
            "fragment": "test"
        }
    }


# Generated at 2022-06-23 10:30:07.097153
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-23 10:30:08.384186
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    return filters

# Generated at 2022-06-23 10:30:11.068651
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:30:12.606954
# Unit test for constructor of class FilterModule
def test_FilterModule():
    m = FilterModule()
    assert m is not None


# Generated at 2022-06-23 10:30:20.635099
# Unit test for function split_url
def test_split_url():
    valid_url = 'http://www.example.com:80/test?test=test#test'
    invalid_url = 'http://www.example.com:80/test?test=test#test#'
    invalid_url_part = 'user'
    valid_url_components = ['http://www.example.com:80/test', 'test', '/test?test=test#test', 'www.example.com', '80']
    valid_url_keys = ['scheme', 'netloc', 'path', 'hostname', 'port', 'query', 'fragment']
    invalid_url_value = 'kevin@gmail.com'

    def test_url_simple():
        result = split_url(valid_url)
        assert result['scheme'] == valid_url_components[0]


# Generated at 2022-06-23 10:30:31.959851
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/file.html?key1=value1&key2=value2#Anchor') == {
          'fragment': u'Anchor', 'netloc': u'www.example.com', 'path': u'/path/file.html',
          'query': u'key1=value1&key2=value2', 'scheme': u'http', 'username': u'',
          'password': u'', 'hostname': u'www.example.com', 'port': u''}
    assert split_url('http://user:pass@www.example.com:8080/path/file.html?key1=value1&key2=value2#Anchor', 'fragment') == u'Anchor'

# Generated at 2022-06-23 10:30:43.779980
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' uri.py:FilterModule() unit test'''

    # This will create a new object of FilterModule
    mod = FilterModule()

    # Use the object to call the method filters
    ansible_filter_dict = mod.filters()

    # Assert that the method filters of the class FilterModule
    # returns a dictionary with the name 'urlsplit' set to the
    # function split_url
    assert 'urlsplit' in ansible_filter_dict
    assert split_url == ansible_filter_dict['urlsplit']

    # Use the object to call the method filters with a parameter query
    ansible_filter_dict_query = mod.filters(query = 'urlsplit')

    # Assert that the method filters of the class FilterModule
    # returns a dictionary with the name 'urlsplit' set to the
    # function split

# Generated at 2022-06-23 10:30:52.497609
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import BytesIO
    from ansible.utils.path import makedirs_safe
    import json
    import os
    import tempfile

    try:
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars.manager import VariableManager
        from ansible.inventory.manager import InventoryManager
        from ansible.template import Templar
        from ansible.playbook.play import Play
        from ansible.executor.task_queue_manager import TaskQueueManager
        HAS_ANSIBLE = True
    except ImportError:
        HAS_ANSIBLE = False
    finally:
        if HAS_ANSIBLE:
            loader = DataLoader()
            variable_manager = VariableManager()

# Generated at 2022-06-23 10:30:54.685047
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module_obj = FilterModule()
    assert filter_module_obj is not None


# Generated at 2022-06-23 10:30:57.451463
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule) == {'urlsplit': split_url}


# Generated at 2022-06-23 10:30:59.082666
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_test = FilterModule()
    assert filter_test is not None


# Generated at 2022-06-23 10:31:00.048442
# Unit test for constructor of class FilterModule
def test_FilterModule():

    assert(callable(split_url))

# Generated at 2022-06-23 10:31:08.490039
# Unit test for function split_url

# Generated at 2022-06-23 10:31:18.703090
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.ansible.com')['scheme'] == 'http'
    assert split_url('http://www.ansible.com')['netloc'] == 'www.ansible.com'
    assert split_url('http://www.ansible.com/')['path'] == '/'
    assert split_url('http://www.ansible.com:4001/')['port'] == '4001'
    assert split_url('http://www.ansible.com:4001/')['query'] == ''
    assert split_url('http://www.ansible.com:4001/?s=foo')['query'] == 's=foo'

# Generated at 2022-06-23 10:31:19.323275
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:31:29.438689
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import json
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    f = FilterModule()
    fo = f.filters()
    assert fo['urlsplit'] is split_url

    url = "http://user:pass@www.example.com:80/foo/bar?%s" % urlencode({'foo': 'bar'})
    obj = json.loads(json.dumps(split_url(url)))
    assert obj['scheme'] == 'http'
    assert obj['query'] == 'foo=bar'
    assert obj['netloc'] == 'user:pass@www.example.com:80'
    assert obj['path'] == '/foo/bar'
    assert split_url(url, query='scheme') == 'http'

# Generated at 2022-06-23 10:31:33.762914
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    res = split_url('ssh://user:pass@example.com:8080/path/to/something')
    assert res['scheme'] == 'ssh'
    assert res['netloc'] == 'user:pass@example.com:8080'
    assert res['hostname'] == 'example.com'
    assert res['port'] == 8080
    assert res['path'] == '/path/to/something'


# Generated at 2022-06-23 10:31:36.059797
# Unit test for constructor of class FilterModule
def test_FilterModule():
    print ("URLSplit")
    fm = FilterModule()
    (fm.filters())
    print ("")


# Generated at 2022-06-23 10:31:37.819715
# Unit test for method filters of class FilterModule

# Generated at 2022-06-23 10:31:40.457613
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert type(fm) == FilterModule
    assert fm.filters().get('urlsplit') == split_url


# Generated at 2022-06-23 10:31:44.011495
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert set(['urlsplit']) == set(filter_module.filters().keys())

# Generated at 2022-06-23 10:31:46.360482
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()


# Generated at 2022-06-23 10:31:47.873746
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f


# Generated at 2022-06-23 10:31:48.915839
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule()
    assert filters is not None

# Generated at 2022-06-23 10:31:56.221929
# Unit test for function split_url
def test_split_url():
    # Given: a valid URL
    url = 'https://www.ansible.com/test?test=test&test2=test2#test'

    # When: I supply an option to split_url
    test_scheme = split_url(url, 'scheme')
    test_netloc = split_url(url, 'netloc')
    test_path = split_url(url, 'path')
    test_query = split_url(url, 'query')
    test_fragment = split_url(url, 'fragment')

    # Then: return the correct value
    assert test_scheme == 'https'
    assert test_netloc == 'www.ansible.com'
    assert test_path == '/test'
    assert test_query == 'test=test&test2=test2'
    assert test

# Generated at 2022-06-23 10:32:00.436872
# Unit test for constructor of class FilterModule
def test_FilterModule():
    print("Test for FilterModule")
    try:
        assert split_url("http://www.foo.com:8089/bar/baz/file.html;sessionId=04c255132f26", "query") is None
    except AssertionError:
        print("Test Failed")
        raise AssertionError
    print("Test Passed")

# Generated at 2022-06-23 10:32:02.424841
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    fm.filters()

# Generated at 2022-06-23 10:32:11.145699
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test = FilterModule()
    assert test.filters() == {'urlsplit': split_url}

# -------------------------


# Unit tests for function split_url
import pytest



# Generated at 2022-06-23 10:32:14.233122
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filter_module = FilterModule()
    filters = filter_module.filters()
    assert 'urlsplit' in filters
    assert filters['urlsplit'] == split_url


# Generated at 2022-06-23 10:32:14.894665
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    res = FilterModule().filters()
    assert 'urlsplit' in res

# Generated at 2022-06-23 10:32:16.397841
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)


# Generated at 2022-06-23 10:32:18.897490
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:32:22.471043
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:32:31.853186
# Unit test for function split_url
def test_split_url():
    url = 'https://username:password@host.com:8080/path?arg=value#fragment'
    test_usage = '{{ url | urlsplit("path", "fragment") }}'
    test_output = {'scheme': 'https', 'netloc': 'username:password@host.com:8080', 'path': 'path', 'query': 'arg=value', 'fragment': 'fragment'}
    assert split_url(url) == test_output
    assert split_url(url, 'fragment') == test_output['fragment']

# Generated at 2022-06-23 10:32:39.198110
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """ split_url: unit tests for FilterModule class, filters method
        """

    # initialize
    uri_split_filter = FilterModule()

    test_url = 'http://www.example.com/path?attr1=val1&attr2=val2#fragment'

    # test filters
    assert uri_split_filter.filters()['urlsplit'](test_url, 'query') == 'attr1=val1&attr2=val2'

# Generated at 2022-06-23 10:32:44.408949
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com') == {'fragment': '', 'netloc': 'www.example.com', 'path': '', 'scheme': 'http', 'query': ''}
    assert split_url('http://www.example.com', 'scheme') == 'http'

# Generated at 2022-06-23 10:32:53.004141
# Unit test for function split_url
def test_split_url():
    """ split_url Tests """
    assert split_url('https://www.example.com/foo/bar?foo=bar&baz=bai', 'scheme') == 'https'
    assert split_url('https://www.example.com:80/foo/bar?foo=bar&baz=bai', 'port') == '80'
    assert split_url('https://www.example.com/foo/bar?foo=bar&baz=bai', 'netloc') == 'www.example.com'
    assert split_url('https://www.example.com/foo/bar?foo=bar&baz=bai', 'path') == '/foo/bar'

# Generated at 2022-06-23 10:32:54.537208
# Unit test for constructor of class FilterModule
def test_FilterModule():
    o = FilterModule()
    assert o.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:32:56.058295
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert {'urlsplit': split_url} == FilterModule.filters(FilterModule)

# Generated at 2022-06-23 10:32:58.180531
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule()

    assert 'urlsplit' in filters.filters()



# Generated at 2022-06-23 10:33:06.822456
# Unit test for function split_url
def test_split_url():
    assert split_url('http://username:password@host.example.com:8080/path/to/file?arg1=foo&arg2=bar#anchor') == {
        'netloc': 'username:password@host.example.com:8080',
        'path': '/path/to/file',
        'fragment': 'anchor',
        'scheme': 'http',
        'query': 'arg1=foo&arg2=bar',
        'port': '8080',
        'username': 'username',
        'password': 'password',
        'hostname': 'host.example.com'
    }

# Generated at 2022-06-23 10:33:09.052141
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert obj.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:33:19.411474
# Unit test for function split_url
def test_split_url():

    from ansible.compat.tests.mock import patch
    import ansible.module_utils.basic

    url = 'http://www.multcloud.com/cloud-migrate?sourcePath=test/test.txt&account_id=0&destPath=/&desc=test'
    with patch.object(ansible.module_utils.basic.AnsibleModule, 'fail_json') as mocked_fail_json:
        rst = split_url(url, 'scheme')
        assert rst == 'http'
        rst = split_url(url, 'hostname')
        assert rst == 'www.multcloud.com'
        rst = split_url(url, 'path')
        assert rst == '/cloud-migrate'

# Generated at 2022-06-23 10:33:31.218521
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text
    from ansible.parsing.ajson import AnsibleJSONEncoder
    import json
    import sys

    def to_bytes(text):
        if sys.version_info[0] == 3:
            return to_text(text).encode('utf-8')
        else:
            return to_text(text).encode('utf-8', 'strict')

    stdin, stdout, stderr = sys.stdin, sys.stdout, sys.stderr
    sys.stdin = open(__file__, 'rb')
    sys.stdout = open('/dev/null', 'w')
    sys.stderr = open('/dev/null', 'w')


# Generated at 2022-06-23 10:33:32.633480
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    u = FilterModule().filters()
    assert 'urlsplit' == list(u.keys())[0]
    assert split_url == u['urlsplit']  # values are functions

# Generated at 2022-06-23 10:33:37.284470
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urlsplit'](value='https://www.example.com/foo/bar')
    assert f.filters()['urlsplit'](value='https://www.example.com/foo/bar', query='scheme') is 'https'
    assert f.filters()['urlsplit'](value='https://user:password@example.com:443/foo/bar;param?query=arg#frag',
                                   query='password') is 'password'

# Generated at 2022-06-23 10:33:40.530637
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urlsplit'](None, query='scheme') == split_url(None, query='scheme')

# Generated at 2022-06-23 10:33:45.586548
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # setup
    test_obj = FilterModule()
    expected_dict = {'scheme': 'https', 'netloc': 'ansible.com', 'path': '/', 'query': '', 'fragment': ''}

    # exercise
    actual_dict = test_obj.filters()['urlsplit']('https://ansible.com/', 'query', 'test')

    # verify
    assert expected_dict == actual_dict

# Generated at 2022-06-23 10:33:46.994006
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:33:49.004739
# Unit test for function split_url
def test_split_url():
    assert split_url('http://example.com/') == {'fragment': '', 'netloc': 'example.com', 'path': '/', 'query': '', 'scheme': 'http'}

# Generated at 2022-06-23 10:33:56.683886
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    f = FilterModule()
    result = f.filters()['urlsplit']('http://username:password@example.com:80/path;param?query=arg#fragment', 'netloc')
    assert result == 'username:password@example.com:80'
    result = f.filters()['urlsplit']('http://username:password@example.com:80/path;param?query=arg#fragment')

# Generated at 2022-06-23 10:33:57.910866
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(isinstance(FilterModule() , FilterModule))

# Generated at 2022-06-23 10:34:00.218446
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert(isinstance(fm.filters(), dict))
    assert('urlsplit' in fm.filters())
    assert(fm.filters()['urlsplit'] == split_url)


# Generated at 2022-06-23 10:34:08.882838
# Unit test for function split_url
def test_split_url():
    import pytest
    from ansible.errors import AnsibleFilterError

    value = "https://docs.ansible.com/ansible/2.3/modules/uri_module.html?id=101"
    # Make sure that the query value is a valid key for the returned dictionary.
    query = "netloc"
    results = split_url(value, query)

    assert results == "docs.ansible.com"

    value = "https://docs.ansible.com/ansible/2.3/modules/uri_module.html?id=101"
    # Make sure we raise an error if the value is not in the dictionary.
    query = "test"

    with pytest.raises(AnsibleFilterError) as e:
        results = split_url(value, query)

# Generated at 2022-06-23 10:34:15.665076
# Unit test for function split_url
def test_split_url():
    url = 'https://user@example.com:8080/foo/bar/baz;a=1;b=2;c=3?a=1&b=2&c=3#123'
    expected_results = {'scheme': 'https', 'netloc': 'user@example.com:8080', 'path': '/foo/bar/baz;a=1;b=2;c=3',
                        'query': 'a=1&b=2&c=3', 'fragment': '123'}

    results = split_url(url)
    assert results == expected_results

    assert results['scheme'] == 'https'
    assert results['netloc'] == 'user@example.com:8080'

# Generated at 2022-06-23 10:34:24.968220
# Unit test for function split_url
def test_split_url():
    """ Tests for valid and invalid inputs to the split_url function.
    """
    from ansible.compat.tests.mock import patch, Mock
    from ansible.compat.tests import unittest

    class TestSplitURL(unittest.TestCase):

        @patch('ansible.utils.helpers.object_to_dict')
        def test_valid_inputs(self, mock_object):
            """ Test that split_url returns the expected output with valid inputs.
            """
            url = "https://www.example.com"
            mock_object.return_value = {'scheme': 'https', 'netloc': 'www.example.com'}
            ret = split_url(url, 'scheme')

            self.assertEqual(ret, 'https')
            mock_object.assert_called_once_

# Generated at 2022-06-23 10:34:27.409917
# Unit test for constructor of class FilterModule
def test_FilterModule():
    '''Test the constructor for class FilterModule'''
    test = FilterModule()
    assert test.filters() is not None

# Generated at 2022-06-23 10:34:29.155258
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert('FilterModule' in str(FilterModule))
    assert('filters' in str(FilterModule))


# Generated at 2022-06-23 10:34:37.245362
# Unit test for function split_url
def test_split_url():

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class TestSplitURL(unittest.TestCase):

        def setUp(self):
            self.urlsplit_patcher = patch('ansible.modules.extras.filter_plugins.uri.urlsplit')
            self.urlsplit_mock = self.urlsplit_patcher.start()
            self.urlsplit_mock.return_value = urlsplit.Result(scheme='http', netloc='www.example.com', path='/path/to/file',
                                                              query='', fragment='')

        def tearDown(self):
            self.urlsplit_patcher.stop()


# Generated at 2022-06-23 10:34:49.657479
# Unit test for function split_url
def test_split_url():
    url = 'https://user@host.com:123/path/to/file?a=1&b=2&c=3#tag'
    assert split_url(url, 'scheme') == 'https'
    assert split_url(url, 'username') == 'user'
    assert split_url(url, 'password') is None
    assert split_url(url, 'hostname') == 'host.com'
    assert split_url(url, 'port') == '123'
    assert split_url(url, 'path') == '/path/to/file'
    assert split_url(url, 'query') == 'a=1&b=2&c=3'
    assert split_url(url, 'fragment') == 'tag'


# Generated at 2022-06-23 10:34:51.171740
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:34:58.578813
# Unit test for function split_url
def test_split_url():
    filtered = split_url('http://user:password@host.com:8080/path?arg=value#value', query='netloc')
    assert filtered == "user:password@host.com:8080"
    filtered = split_url('http://user:password@host.com:8080/path?arg=value#value', query='path')
    assert filtered == "/path"
    filtered = split_url('http://user:password@host.com:8080/path?arg=value#value', query='query')
    assert filtered == "arg=value"
    filtered = split_url('http://user:password@host.com:8080/path?arg=value#value', query='fragment')
    assert filtered == "value"

# Generated at 2022-06-23 10:35:00.903681
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters()['urlsplit'] is split_url   # call the class method


# Generated at 2022-06-23 10:35:12.205587
# Unit test for function split_url
def test_split_url():
    testurl = 'http://user:password@example.com:8080/path;parameters?query=arg#fragment'
    assert split_url(testurl, 'scheme') == 'http'
    assert split_url(testurl, 'netloc') == 'user:password@example.com:8080'
    assert split_url(testurl, 'username') == 'user'
    assert split_url(testurl, 'password') == 'password'
    assert split_url(testurl, 'hostname') == 'example.com'
    assert split_url(testurl, 'port') == '8080'
    assert split_url(testurl, 'path') == '/path;parameters'
    assert split_url(testurl, 'query') == 'query=arg'

# Generated at 2022-06-23 10:35:22.915802
# Unit test for function split_url
def test_split_url():
    assert split_url('http://example.com/path?arg=value#fragment', query='scheme') == 'http'
    assert split_url('http://example.com/path?arg=value#fragment', query='netloc') == 'example.com'
    assert split_url('http://example.com/path?arg=value#fragment', query='path') == '/path'
    assert split_url('http://example.com/path?arg=value#fragment', query='query') == 'arg=value'
    assert split_url('http://example.com/path?arg=value#fragment', query='fragment') == 'fragment'
    assert split_url('http://example.com/path?arg=value#fragment', query='notadomaincomponent') == None
   

# Generated at 2022-06-23 10:35:24.328446
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # pylint: disable=protected-access, unused-argument
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:35:32.257832
# Unit test for function split_url
def test_split_url():
    import unittest
    import sys
    # instantiate the TestCase class
    tester = unittest.TestCase()

    # get the test cases

# Generated at 2022-06-23 10:35:35.236999
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    fm_filters = fm.filters()
    assert 'urlsplit' in fm_filters
    # assert fm.filters()['urisplit'] == split_url
    # assert fm.filters()['urisplit'].__name__ == split_url.__name__


# Generated at 2022-06-23 10:35:37.285598
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    result = FilterModule().filters()
    assert result == {'urlsplit': split_url}


# Generated at 2022-06-23 10:35:39.675937
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for method filters of class FilterModule '''
    assert 'urlsplit' in FilterModule.filters(FilterModule)

# Generated at 2022-06-23 10:35:41.332282
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:35:45.258392
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(None) == {'urlsplit': split_url}



# Generated at 2022-06-23 10:35:47.820567
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'urlsplit' in filter_module.filters()

# Generated at 2022-06-23 10:35:55.042345
# Unit test for function split_url
def test_split_url():
    result = split_url('https://docs.openstack.org/ocata/install-guide-ubuntu/launch-instance-selfservice.html')
    assert result['netloc'] == 'docs.openstack.org'

    result = split_url('https://docs.openstack.org/ocata/install-guide-ubuntu/launch-instance-selfservice.html', query='scheme')
    assert result == 'https'

    result = split_url('https://docs.openstack.org/ocata/install-guide-ubuntu/launch-instance-selfservice.html', query='query')
    assert result == ''

# Generated at 2022-06-23 10:35:57.145634
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None



# Generated at 2022-06-23 10:35:59.497430
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert('urlsplit' in filter_module.filters())

# --------------------------------------------------


# Generated at 2022-06-23 10:36:07.880646
# Unit test for function split_url
def test_split_url():

    url_list = []
    url_list.append('http://user:pass@example.com:8080/path;param?query=arg#frag')
    url_list.append('https://www.google.com')
    url_list.append('http://user:pass@example.com:8080/path;param?query=arg#frag')

    for url in url_list:
        print(split_url(url, ''))
        print(split_url(url, 'scheme'))
        print(split_url(url, 'netloc'))
        print(split_url(url, 'path'))
        print(split_url(url, 'query'))
        print(split_url(url, 'fragment'))

if __name__ == '__main__':
    test_split_

# Generated at 2022-06-23 10:36:10.130463
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Test constructor FilterModule() '''
    fmod = FilterModule()
    assert isinstance(fmod, FilterModule)


# Generated at 2022-06-23 10:36:11.786134
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() == {"urlsplit":split_url}