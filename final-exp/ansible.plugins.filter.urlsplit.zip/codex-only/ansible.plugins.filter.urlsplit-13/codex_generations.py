

# Generated at 2022-06-23 10:26:12.098900
# Unit test for constructor of class FilterModule
def test_FilterModule():
    c = FilterModule()
    assert c


# Generated at 2022-06-23 10:26:14.563317
# Unit test for constructor of class FilterModule
def test_FilterModule():
    
    module = FilterModule()
    assert(module.filters == {'urlsplit': split_url})


# Generated at 2022-06-23 10:26:17.193089
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert(FilterModule().filters() ==
           {'urlsplit': split_url}
    )

# Generated at 2022-06-23 10:26:18.864354
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filter = FilterModule()
    assert filter.filters().get('urlsplit') == split_url



# Generated at 2022-06-23 10:26:19.683921
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-23 10:26:32.604351
# Unit test for function split_url
def test_split_url():
    assert split_url('http://foo.com/', query='hostname') == 'foo.com'
    assert split_url('http://foo.com:8080/') == {'fragment': '', 'netloc': 'foo.com:8080', 'path': '/', 'scheme': 'http', 'query': ''}
    assert split_url('http://foo.com:8080/?a=1&b=2&c=3') == {'fragment': '', 'netloc': 'foo.com:8080', 'path': '/', 'scheme': 'http', 'query': 'a=1&b=2&c=3'}

# Generated at 2022-06-23 10:26:33.405226
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:26:45.372139
# Unit test for function split_url
def test_split_url():

    # Test valid urls
    test_urls = [
        'https://www.google.com/abc/def/?page=123&page_size=20#test',
        'file:///var/log/foo.log',
        'http://jonschipp.com',
        'http://www.foobar.com/?name=Jon',
        'rsync://rsync.kernel.org/pub',
        'http://[::1]:8080',
    ]

    # expected results

# Generated at 2022-06-23 10:26:50.040275
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()



# Generated at 2022-06-23 10:26:58.615762
# Unit test for function split_url
def test_split_url():
    from ansible.utils.urls import url_argument_spec, urlsplit_auth, urlsplit_port

    # Split Without Query
    test_url = "http://www.example.com/path?arg=value#fragment"
    assert split_url(test_url) == dict(scheme="http", netloc="www.example.com", path="/path", query="arg=value", fragment="fragment")

    # Split With Query
    assert split_url(test_url, query='query') == dict(scheme=None, netloc=None, path=None, query="arg=value", fragment=None)

    # Test urlsplit_auth
    assert urlsplit_auth('https://username:password@www.example.com') == dict(user='username', password='password')
    assert ur

# Generated at 2022-06-23 10:26:59.068132
# Unit test for function split_url
def test_split_url():
    pass

# Generated at 2022-06-23 10:27:11.212726
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    split_url_expected_result = {
        'scheme': 'https',
        'netloc': 'www.example.com',
        'path': '/foo/bar/baz.html',
        'query': '',
        'fragment': 'test'
    }
    fm = FilterModule()
    assert fm.filters()['urlsplit']('https://www.example.com/foo/bar/baz.html#test') == split_url_expected_result
    assert fm.filters()['urlsplit']('https://www.example.com/foo/bar/baz.html#test', 'scheme') == 'https'

# Generated at 2022-06-23 10:27:22.034985
# Unit test for function split_url
def test_split_url():
    # Execute function with valid URL
    url = 'https://www.example.com:8080/foo/bar?a=b#c=d'
    assert split_url(url) == {'fragment': 'c=d', 'query': 'a=b', 'netloc': 'www.example.com:8080', 'path': '/foo/bar', 'scheme': 'https', 'username': None, 'password': None, 'hostname': 'www.example.com', 'port': 8080}
    assert split_url(url, 'hostname') == 'www.example.com'
    assert split_url(url, 'fragment') == 'c=d'

    # Execute function with invalid option supplied.
    # An error is raised as the URL does not contain the 'test' option

# Generated at 2022-06-23 10:27:25.203531
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filterClass = FilterModule()
    assert filterClass is not None, "Failed to instantiate FilterModule"


# Generated at 2022-06-23 10:27:34.066478
# Unit test for function split_url
def test_split_url():
    test = split_url('http://www.example.com:80/foo/bar')
    expected = {
        'netloc': 'www.example.com:80',
        'params': '',
        'query': '',
        'path': '/foo/bar',
        'scheme': 'http',
        'fragment': '',
    }
    assert test == expected, "Expected: %s, Got: %s" % (str(expected), str(test))

    test = split_url('http://www.example.com:80/foo/bar?a=1&b=2#foobar')

# Generated at 2022-06-23 10:27:34.817696
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    assert 'urlsplit' in filters.filters()

# Generated at 2022-06-23 10:27:40.025756
# Unit test for function split_url
def test_split_url():
    url = "https://ansible.com/foo/bar?arg1=val1#frag1"
    assert split_url(url, "scheme") == "https"
    assert split_url(url, "netloc") == "ansible.com"
    assert split_url(url, "path") == "/foo/bar"
    assert split_url(url, "query") == "arg1=val1"
    assert split_url(url, "fragment") == "frag1"

# Generated at 2022-06-23 10:27:44.128871
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    expected = {
        'scheme': 'https',
        'netloc': 'ansible.com',
        'path': '/',
        'query': '',
        'fragment': ''
    }

    actual = split_url('https://ansible.com', query='')

    assert expected == actual

# Generated at 2022-06-23 10:27:51.538662
# Unit test for function split_url
def test_split_url():
    # Invalid URLs
    assert split_url('invalid url') is None
    assert split_url('.') is None
    assert split_url('/') is None

    # Valid URLs, with no query
    assert split_url('http://example.com') == {'password': None, 'username': None, 'path': '', 'scheme': 'http', 'query': '', 'fragment': '', 'port': None, 'netloc': 'example.com', 'hostname': 'example.com', 'hostname_type': 'domainname'}

# Generated at 2022-06-23 10:27:53.076311
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    new_FilterModule = FilterModule()
    assert new_FilterModule.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:27:59.999035
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/hello?a=b&c=d', alias='urlsplit') == {'fragment': '', 'netloc': 'www.example.com', 'params': '', 'path': '/hello', 'query': 'a=b&c=d', 'scheme': 'http'}
    assert split_url('http://www.example.com/hello?a=b&c=d', query='scheme', alias='urlsplit') == 'http'
    assert split_url('http://www.example.com/hello?a=b&c=d', query='path', alias='urlsplit') == '/hello'

# Generated at 2022-06-23 10:28:01.341394
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()

# Generated at 2022-06-23 10:28:02.412492
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    result = split_url('http://www.ansible.com', 'netloc')
    assert result == 'www.ansible.com'

# Generated at 2022-06-23 10:28:05.194151
# Unit test for constructor of class FilterModule
def test_FilterModule():
    urlsplit_filter = FilterModule()
    assert urlsplit_filter.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:28:08.560915
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:28:09.362522
# Unit test for constructor of class FilterModule
def test_FilterModule():
	assert callable(FilterModule)

# Generated at 2022-06-23 10:28:11.649873
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    actual = FilterModule().filters()
    assert actual == {'urlsplit': split_url}

# Generated at 2022-06-23 10:28:20.027484
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    urls = [
        'https://username:password@hg.mozilla.org/mozilla-central#l10n/de',
        'https://www.example.com',
        'https://www.example.com/',
        'https://www.example.com:8000/',
    ]


# Generated at 2022-06-23 10:28:22.361070
# Unit test for constructor of class FilterModule
def test_FilterModule():
    c = FilterModule()
    assert c.filters() is not None


# Generated at 2022-06-23 10:28:32.363723
# Unit test for function split_url
def test_split_url():
    url = "https://example.com/foo/bar"
    assert split_url(url, 'scheme') == "https"
    assert split_url(url, 'netloc') == "example.com"
    assert split_url(url, 'path') == "/foo/bar"
    assert split_url(url, 'username') == ''
    assert split_url(url, 'password') == ''
    assert split_url(url, 'query') == ''
    assert split_url(url, 'fragment') == ''
    assert split_url(url) == {'fragment': '', 'netloc': 'example.com', 'path': '/foo/bar', 'query': '', 'scheme': 'https'}

# Generated at 2022-06-23 10:28:40.583842
# Unit test for function split_url
def test_split_url():

    # Try a http URL
    assert "http" == split_url('http://www.example.com/path?arg=value#hash', query='scheme')
    assert "www.example.com" == split_url('http://www.example.com/path?arg=value#hash', query='netloc')
    assert "/path" == split_url('http://www.example.com/path?arg=value#hash', query='path')
    assert "arg=value" == split_url('http://www.example.com/path?arg=value#hash', query='query')
    assert "hash" == split_url('http://www.example.com/path?arg=value#hash', query='fragment')

# Generated at 2022-06-23 10:28:41.605213
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module

# Generated at 2022-06-23 10:28:47.087565
# Unit test for function split_url
def test_split_url():
    assert split_url('http://ansible.com/test#123') == {'scheme': 'http', 'netloc': 'ansible.com', 'path': '/test', 'query': '', 'fragment': '123'}
    assert split_url('http://ansible.com/test', query='scheme') == 'http'
    assert split_url('http://ansible.com/test', query='netloc') == 'ansible.com'

# Generated at 2022-06-23 10:28:47.994531
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule(), 'filters')

# Generated at 2022-06-23 10:28:55.350518
# Unit test for function split_url
def test_split_url():
    assert split_url('http://users.example.com/test/index.html') == {'scheme': 'http',
                'path': '/test/index.html', 'fragment': '', 'hostname': 'users.example.com',
                'query': '', 'username': '', 'password': '', 'port': None}
    assert split_url('http://users.example.com/test/index.html', query='path') == '/test/index.html'
    assert split_url('http://users.example.com/test/index.html', query='nosuchquery') == 'nosuchquery'

# Generated at 2022-06-23 10:29:07.844049
# Unit test for function split_url
def test_split_url():
    assert split_url('http://localhost:8080/v1/images', '') == {
        'netloc': 'localhost:8080',
        'scheme': 'http',
        'path': '/v1/images',
        'fragment': '',
        'query': ''
    }, 'Unable to parse url'

    assert split_url('http://localhost:8080/v1/images', 'netloc') == 'localhost:8080', 'Expected netloc'
    assert split_url('http://localhost:8080/v1/images', 'scheme') == 'http', 'Expected scheme'
    assert split_url('http://localhost:8080/v1/images', 'path') == '/v1/images', 'Expected path'

# Generated at 2022-06-23 10:29:18.758710
# Unit test for function split_url
def test_split_url():

    assert split_url('foo') == split_url('http://localhost:8080/foo', alias='test_urlsplit')
    assert split_url('foo', 'path') == split_url('http://localhost:8080/foo', 'path', alias='test_urlsplit')
    assert split_url('foo', 'query') == split_url('http://localhost:8080/foo', 'query', alias='test_urlsplit')
    assert split_url('foo', 'scheme') == split_url('http://localhost:8080/foo', 'scheme', alias='test_urlsplit')

# Generated at 2022-06-23 10:29:21.314407
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urlsplit'] == split_url



# Generated at 2022-06-23 10:29:23.686028
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ret = FilterModule()
    assert ret is not None

# Generated at 2022-06-23 10:29:26.500338
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters()['urlsplit'] is split_url

# ---- Tests ----
# Unit tests for split_url

# Generated at 2022-06-23 10:29:27.587607
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()


# Generated at 2022-06-23 10:29:29.950118
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Unit test for FilterModule '''
    with pytest.raises(AnsibleFilterError):
        split_url('foo', 'bar')

# Generated at 2022-06-23 10:29:39.492736
# Unit test for function split_url
def test_split_url():
    test_url = "https://username:password@hostname:1234/path;parameters?query=argument#anchor"

    # Testing is done by checking the type and if it contain the expected value
    # If the type is not expected, it will and raise an error, else will return true

    # Test query is schmema
    assert type(split_url(test_url, query='scheme')) is str
    assert split_url(test_url, query='scheme') == 'https'

    # Test query is netloc
    assert type(split_url(test_url, query='netloc')) is str
    assert split_url(test_url, query='netloc') == 'username:password@hostname:1234'

    # Test query is path

# Generated at 2022-06-23 10:29:42.006492
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert 'urlsplit' in f.filters()


# Generated at 2022-06-23 10:29:50.756239
# Unit test for function split_url
def test_split_url():
    assert split_url('https://ansible.com:443/docs/index.html') == {'netloc': 'ansible.com:443', 'scheme': 'https', 'path': '/docs/index.html', 'query': '', 'fragment': ''}
    assert split_url('https://ansible.com/docs/index.html', 'scheme') == 'https'
    try:
        split_url('https://ansible.com/docs/index.html', 'invalid_key')
    except AnsibleFilterError as e:
        assert e.message == 'urlsplit: unknown URL component: invalid_key'

# Generated at 2022-06-23 10:29:54.739341
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:30:04.826749
# Unit test for function split_url
def test_split_url():
    assert split_url("http://www.example.com/pages/", "scheme") == "http"
    assert split_url("http://www.example.com/pages/", "netloc") == "www.example.com"
    assert split_url("http://www.example.com/pages/", "path") == "/pages/"
    assert split_url("http://www.example.com/pages/", "query") == ""
    assert split_url("ftp://ftp.is.co.za/rfc/rfc1808.txt", "query") == ""
    assert split_url("http://www.ics.uci.edu/pub/ietf/uri/?filename=somefile.html", "query") == "filename=somefile.html"

# Generated at 2022-06-23 10:30:07.825998
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()
    assert x.filters()['urlsplit']


# Generated at 2022-06-23 10:30:08.466964
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule(None) is not None

# Generated at 2022-06-23 10:30:10.280901
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  filter_module = FilterModule()
  assert filter_module.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:30:15.856114
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    url_split_filter = FilterModule().filters()['urlsplit']

    # test one positional argument
    result = url_split_filter('foo.bar')
    assert result == {'netloc': '', 'path': 'foo.bar', 'query': '', 'fragment': '', 'scheme': ''}

    # test the 'query' optional argument
    result = url_split_filter('foo.bar', 'path')
    assert result == 'foo.bar'

# Generated at 2022-06-23 10:30:17.212968
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert 'urlsplit' in f.filters()

# Generated at 2022-06-23 10:30:28.947337
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'scheme' == FilterModule.filters(None)('http://docs.ansible.com/ansible/latest/user_guide/playbooks_filters.html', 'scheme', 'urlsplit')
    assert 'netloc' == FilterModule.filters(None)('http://docs.ansible.com/ansible/latest/user_guide/playbooks_filters.html', 'netloc', 'urlsplit')
    assert 'fragment' == FilterModule.filters(None)('http://docs.ansible.com/ansible/latest/user_guide/playbooks_filters.html', 'fragment', 'urlsplit')

# Generated at 2022-06-23 10:30:29.798910
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f, FilterModule)


# Generated at 2022-06-23 10:30:37.790771
# Unit test for function split_url
def test_split_url():
    assert split_url('url') == {
        'scheme': '',
        'netloc': '',
        'path': 'url',
        'query': '',
        'fragment': ''
    }
    url = 'https://docs.python.org/3/library/stdtypes.html?highlight=split#str.split'
    assert split_url(url) == {
        'scheme': 'https',
        'netloc': 'docs.python.org',
        'path': '/3/library/stdtypes.html',
        'query': 'highlight=split',
        'fragment': ''
    }
    assert split_url(url, 'path') == '/3/library/stdtypes.html'
    assert split_url(url, 'query') == 'highlight=split'

# Generated at 2022-06-23 10:30:48.939868
# Unit test for function split_url
def test_split_url():
    url = 'http://www.example.com/path/file.ext?key1=value1&key2=value2#hash'
    assert split_url(url, 'scheme') == 'http'
    assert split_url(url, 'netloc') == 'www.example.com'
    assert split_url(url, 'path') == '/path/file.ext'
    assert split_url(url, 'query') == 'key1=value1&key2=value2'
    assert split_url(url, 'fragment') == 'hash'

# Generated at 2022-06-23 10:30:49.652439
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()


# Generated at 2022-06-23 10:30:50.980593
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module is not None


# Generated at 2022-06-23 10:31:03.075204
# Unit test for function split_url
def test_split_url():
    assert {'path': 'path?query=True',
            'params': '',
            'netloc': 'user@domain',
            'scheme': 'ftp',
            'query': 'query=True',
            'fragment': ''} == split_url('ftp://user@domain/path?query=True', alias='test_alias')
    assert 'path' == split_url('ftp://user@domain/path?query=True', query='path', alias='test_alias')
    assert 'query=True' == split_url('ftp://user@domain/path?query=True', query='query', alias='test_alias')

# Generated at 2022-06-23 10:31:05.160842
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import pytest
    fixture = FilterModule()
    result = fixture.filters()
    assert result['urlsplit'] == split_url


# Generated at 2022-06-23 10:31:19.721773
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """ Test FilterModule filters method """
    assert SplitUrl('http://google.com/search?q=foo%20bar&oq=foo%20bar')['scheme'] == 'http'
    assert SplitUrl('httpp://google.com/search?q=foo%20bar&oq=foo%20bar')['scheme'] == 'httpp'
    assert SplitUrl('http://google.com/search?q=foo%20bar&oq=foo%20bar', 'path') == '/search'
    assert SplitUrl('http://google.com/search?q=foo%20bar&oq=foo%20bar', 'query') == 'q=foo%20bar&oq=foo%20bar'

if __name__ == '__main__':
    test_FilterModule_filters()

# Generated at 2022-06-23 10:31:28.656800
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' unit test for filters method '''

    test_data = 'https://www.google.com/search?q=url+split+filter&ie=utf-8&oe=utf-8'

    fm = FilterModule()
    assert fm.filters()['urlsplit'](test_data) == {'fragment': '', 'netloc': 'www.google.com', 'path': '/search', 'query': 'q=url+split+filter&ie=utf-8&oe=utf-8', 'scheme': 'https'}
    assert fm.filters()['urlsplit'](test_data, 'query') == 'q=url+split+filter&ie=utf-8&oe=utf-8'


# Generated at 2022-06-23 10:31:29.214107
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:31:29.898649
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)


# Generated at 2022-06-23 10:31:38.047383
# Unit test for function split_url
def test_split_url():
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vars_manager = combine_vars(loader=loader, variables={})
    url = 'http://example.com'
    query = 'scheme'
    alias = 'urlsplit'
    result = split_url(value=url, query=query, alias=alias)
    assert result == 'http'


# ---- Ansible filters ----

# Generated at 2022-06-23 10:31:48.038066
# Unit test for function split_url
def test_split_url():
    import os
    import sys
    # The urlparse module is renamed to urllib.parse in Python 3.
    try:
        import urlparse
    except ImportError:
        import urllib.parse as urlparse

    # All of these URLs should fail the filter.
    bad_urls = [
        '',
        '!'
    ]

    # These URLs should succeed, but their components should not match.
    bad_results = [
        ('/usr', 'scheme', 'file'),
        ('/usr', 'path', '/usr/lib'),
        ('/usr', 'username', 'me'),
        ('/usr', 'hostname', 'example.com'),
        ('/usr', 'query', 'test=1&test=2'),
    ]

    # These are the URLs which should succeed the filter, along with their component matches.

# Generated at 2022-06-23 10:31:50.052260
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(hasattr(FilterModule, 'filters'))
    assert(hasattr(FilterModule.filters, '__call__'))


# Generated at 2022-06-23 10:31:50.918179
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ut_vm = FilterModule()
    return ut_vm

# Generated at 2022-06-23 10:31:52.055940
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule.filters(None) == split_url


# Generated at 2022-06-23 10:31:52.872825
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None


# Generated at 2022-06-23 10:31:56.529658
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters() == { 
        'urlsplit': split_url 
    }


# Generated at 2022-06-23 10:31:58.278842
# Unit test for constructor of class FilterModule
def test_FilterModule():
    sModule = FilterModule()
    assert isinstance(sModule, FilterModule)



# Generated at 2022-06-23 10:31:59.191573
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert(obj != None)

# Generated at 2022-06-23 10:32:03.070931
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import unittest

    class TestFilterModule(unittest.TestCase):

        def test_get_methods(self):
            obj = FilterModule()
            assert obj.filters() == {'urlsplit': split_url}

    unittest.main()


if __name__ == '__main__':
    test_FilterModule()

# Generated at 2022-06-23 10:32:12.088038
# Unit test for function split_url
def test_split_url():
    url = 'https://www.google.com:4444/path/to?query=1&other-query=2#anchor'
    # Test if url is split correctly

# Generated at 2022-06-23 10:32:13.193459
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-23 10:32:14.552702
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-23 10:32:23.470766
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    class FilterModuleTest(FilterModule):
        ''' Unit test for method filters of class FilterModule'''

        def filters(self):
            self.filters = super(FilterModuleTest, self).filters()
            self.filters['urlsplit'] = split_url
            return self.filters

    fmtt = FilterModuleTest()
    url = 'http://www.example.com/path/to/file?alpha=0&beta=1&gamma=2'
    results = fmtt.filters()['urlsplit'](url)
    assert results['scheme'] == 'http'
    assert results['netloc'] == 'www.example.com'
    assert results['path'] == '/path/to/file'
    assert results['query'] == 'alpha=0&beta=1&gamma=2'
    assert results

# Generated at 2022-06-23 10:32:34.308523
# Unit test for function split_url
def test_split_url():

    from ansible.module_utils.six import PY3
    import unittest

    if PY3:
        from urllib.parse import urlunsplit, urlencode
    else:
        from urlparse import urlunsplit
        from urllib import urlencode

    class TestUrlSplit(unittest.TestCase):

        def test_split_url_query_option(self):
            self.assertEqual(
                split_url('http://user:pass@www.example.com:8080/path;p1=v1;p2=v2?q1=v3&q2=v4#fragment', 'scheme'),
                'http'
            )

# Generated at 2022-06-23 10:32:44.153384
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters['urlsplit'](
        'https://user:pass@host/path;parameter?query=string#fragment',
        'scheme'
    ) == 'https'
    assert filters['urlsplit'](
        'https://user:pass@host/path;parameter?query=string#fragment',
        'netloc'
    ) == 'user:pass@host'
    assert filters['urlsplit'](
        'https://user:pass@host/path;parameter?query=string#fragment',
        'path'
    ) == '/path;parameter'

# Generated at 2022-06-23 10:32:46.059833
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:32:49.165930
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import doctest
    from ansible.compat.tests import unittest
    suite = doctest.DocTestSuite()
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(FilterModule))
    return suite

# Generated at 2022-06-23 10:32:50.371071
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    results = FilterModule()
    assert results.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:32:55.598715
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    url = "http://www.example.com/path/to/page.html?a=1&b=2#fragment"
    fm = FilterModule()
    filters = fm.filters()

    assert filters['urlsplit'](url) == (
        "http",
        "www.example.com",
        "/path/to/page.html",
        "a=1&b=2",
        "fragment",
    )
    assert filters['urlsplit'](url, 'scheme') == "http"
    assert filters['urlsplit'](url, 'netloc') == "www.example.com"
    assert filters['urlsplit'](url, 'path') == "/path/to/page.html"
    assert filters['urlsplit'](url, 'query') == "a=1&b=2"

# Generated at 2022-06-23 10:32:58.132630
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_filter = FilterModule()
    assert test_filter.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:33:08.110082
# Unit test for function split_url
def test_split_url():
    url = "https://username:password@www.example.com:80/path/to/myfile.html?key1=value1&key2=value2#InTheDocument"
    result_url = split_url(url)
    assert result_url
    assert result_url['scheme'] == 'https'
    assert result_url['netloc'] == 'username:password@www.example.com:80'
    assert result_url['path'] == '/path/to/myfile.html'
    assert result_url['query'] == 'key1=value1&key2=value2'
    assert result_url['fragment'] == 'InTheDocument'
    result_url = split_url(url, 'scheme')
    assert result_url == 'https'

# Generated at 2022-06-23 10:33:18.533460
# Unit test for function split_url
def test_split_url():
    """Unit test for split_url
    """

# Generated at 2022-06-23 10:33:22.041981
# Unit test for constructor of class FilterModule
def test_FilterModule():
    uri = 'https://github.com/ansible/ansible/issues/15920'
    query = 'scheme'
    ret = FilterModule().filters()['urlsplit'](uri, query)
    assert ret == 'https'

# Generated at 2022-06-23 10:33:33.547073
# Unit test for function split_url
def test_split_url():
    test_url = 'https://www.ansible.com/test/test?ansible=yes'
    url_components = split_url(test_url)
    assert url_components['scheme'] == 'https', 'urlsplit failed to return correct scheme'
    assert url_components['netloc'] == 'www.ansible.com', 'urlsplit failed to return correct netloc'
    assert url_components['path'] == '/test/test', 'urlsplit failed to return correct path'
    assert url_components['query'] == 'ansible=yes', 'urlsplit failed to return correct query'
    assert url_components['fragment'] == '', 'urlsplit failed to return correct fragment'
    assert split_url(test_url, 'scheme') == 'https', 'urlsplit failed to return correct scheme when queried'

# Generated at 2022-06-23 10:33:36.820057
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.example.com') == {
        'scheme': 'https',
        'netloc': 'www.example.com',
        'path': '',
        'query': '',
        'fragment': ''
    }

    assert split_url('https://www.example.com', 'scheme') == 'https'

# Generated at 2022-06-23 10:33:39.211990
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()['urlsplit'] == split_url



# Generated at 2022-06-23 10:33:51.777108
# Unit test for function split_url
def test_split_url():
        assert split_url('https://www.example.com:8080/hello/world?foo=baz', query='scheme') == 'https'
        assert split_url('https://www.example.com:8080/hello/world?foo=baz', query='netloc') == 'www.example.com:8080'
        assert split_url('https://www.example.com:8080/hello/world?foo=baz', query='path') == '/hello/world'
        assert split_url('https://www.example.com:8080/hello/world?foo=baz', query='fragment') == ''
        assert split_url('https://www.example.com:8080/hello/world?foo=baz')['fragment'] == ''

# Generated at 2022-06-23 10:33:56.120051
# Unit test for function split_url
def test_split_url():
    '''
    In case we want to run this test we should add "split_url"
    function into the following list.
    '''
    functions = []
    for f in functions:
        # Test the function without query option
        result = f('https://www.example.com')
        assert result['scheme'] == 'https'
        assert result['netloc'] == 'www.example.com'
        assert result['path'] == ''
        assert result['query'] == ''
        assert result['fragment'] == ''

        # Test the function with query option
        result = f('https://www.example.com', query='scheme')
        assert result == 'https'

        # Test the function with query option that doesn't exist
        # and should fail

# Generated at 2022-06-23 10:33:58.911035
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters()['urlsplit'] == (lambda value, query='', alias='urlsplit': split_url(value, query, alias))

# Generated at 2022-06-23 10:34:07.274284
# Unit test for function split_url
def test_split_url():

    assert split_url('http://example.com/foo/bar') == {
        'scheme': 'http',
        'netloc': 'example.com',
        'path': '/foo/bar',
        'query': '',
        'fragment': ''
    }

    assert split_url('http://example.com/foo/bar?baz=1#qux') == {
        'scheme': 'http',
        'netloc': 'example.com',
        'path': '/foo/bar',
        'query': 'baz=1',
        'fragment': 'qux'
    }

    assert split_url('http://example.com?baz=1#qux', 'path') == '/'

# Generated at 2022-06-23 10:34:17.636523
# Unit test for function split_url
def test_split_url():

    # Test valid URLs
    assert split_url('http://example.com') == {'scheme': 'http', 'netloc': 'example.com', 'path': '', 'query': '', 'fragment': ''}
    assert split_url('http://example.com/') == {'scheme': 'http', 'netloc': 'example.com', 'path': '/', 'query': '', 'fragment': ''}
    assert split_url('http://example.com/home/index.html') == {'scheme': 'http', 'netloc': 'example.com', 'path': '/home/index.html', 'query': '', 'fragment': ''}

# Generated at 2022-06-23 10:34:24.573275
# Unit test for function split_url
def test_split_url():
    val = 'https://github.com/ansible/ansible/blob/devel/lib/ansible/modules/system/selinux.py'
    result = {'scheme': 'https', 'path': '/ansible/ansible/blob/devel/lib/ansible/modules/system/selinux.py', 'netloc': 'github.com', 'fragment': '', 'params': '', 'query': ''}
    assert result == split_url(val)
    assert 'ansible' == split_url(val, query='path')

# Generated at 2022-06-23 10:34:26.935394
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert(sorted(FilterModule().filters().keys()) == ['urlsplit'])


# Generated at 2022-06-23 10:34:28.102343
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule.__name__ == 'FilterModule'

# Generated at 2022-06-23 10:34:36.655120
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    f = filters['urlsplit']
    assert f('https://localhost:8080/path/to/stuff?key=value&foo=bar') == {'scheme': 'https', 'netloc': 'localhost:8080', 'path': '/path/to/stuff', 'query': 'key=value&foo=bar', 'fragment': ''}
    assert f('https://localhost:8080/path/to/stuff?key=value&foo=bar', query='path') == '/path/to/stuff'
    assert f('https://localhost:8080/path/to/stuff?key=value&foo=bar', query='query') == 'key=value&foo=bar'

# Generated at 2022-06-23 10:34:49.409377
# Unit test for function split_url
def test_split_url():

    # Test a simple query
    value = 'http://www.ansible.com/foo?bar#baz'
    query = 'scheme'
    assert 'http' == split_url(value, query)

    # Test an empty query
    value = 'http://www.ansible.com/foo?bar#baz'
    query = ''
    assert 'http' == split_url(value, query)['scheme']
    assert 'www.ansible.com' == split_url(value, query)['netloc']
    assert '/foo' == split_url(value, query)['path']
    assert 'bar' == split_url(value, query)['query']
    assert 'baz' == split_url(value, query)['fragment']

    # Test an unknown query

# Generated at 2022-06-23 10:34:50.681486
# Unit test for constructor of class FilterModule
def test_FilterModule():
    testobj = FilterModule()
    assert testobj != None



# Generated at 2022-06-23 10:34:51.379427
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    pass



# Generated at 2022-06-23 10:34:58.679141
# Unit test for function split_url
def test_split_url():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock

    class TestURLsplit(unittest.TestCase):

        def test_urlsplit(self):
            # Import after patching to override the import
            from ansible.module_utils import six
            from ansible.modules.utilities.logic import split_url

            # Mock urlsplit
            mock_urlsplit = Mock(
                return_value=('protocol', 'user:pass', 'url', 'param1=value1', 'fragment'))
            six.moves.urllib.parse.urlsplit = mock_urlsplit

            # Test with query
            self.assertEqual(split_url('test_url', 'user'), 'user:pass')

            # Test without query
           

# Generated at 2022-06-23 10:34:59.722922
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()


# Generated at 2022-06-23 10:35:10.267296
# Unit test for function split_url
def test_split_url():
    """Unit test for function split_url"""

    # Test a valid URI
    valid = 'http://user:pass@192.0.2.99:8080/path?query=value#fragment_id'
    query = 'scheme'
    result = split_url(valid, query=query)
    assert result == 'http'

    # Test a URI missing the scheme
    missing = 'user:pass@192.0.2.99:8080/path?query=value#fragment_id'
    query = 'scheme'
    result = split_url(missing, query=query)
    assert result is None

if __name__ == '__main__':
    test_split_url()

# Generated at 2022-06-23 10:35:12.125711
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {
        'urlsplit': split_url
    }



# Generated at 2022-06-23 10:35:22.783451
# Unit test for function split_url
def test_split_url():
    assert split_url("http://www.cwi.nl:80/%7Eguido/Python.html") == ['http', 'www.cwi.nl:80', '/%7Eguido/Python.html', '', '']
    assert split_url("http://www.cwi.nl:80/%7Eguido/Python.html", 'scheme') == 'http'
    assert split_url("http://www.cwi.nl:80/%7Eguido/Python.html", 'netloc') == 'www.cwi.nl:80'
    assert split_url("http://www.cwi.nl:80/%7Eguido/Python.html", 'path') == '/%7Eguido/Python.html'

# Generated at 2022-06-23 10:35:31.517468
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils.six.moves.urllib.parse import urlunsplit
    url = urlunsplit(('scp', 'user@server:port', '/path/to/file', 'query=value&param=value', 'fragment'))
    result = split_url(url, 'scheme')
    assert result == 'scp'

    result = split_url(url, 'username')
    assert result == 'user'

    result = split_url(url, 'password')
    assert result == ''

    result = split_url(url, 'netloc')
    assert result == 'user@server:port'

    result = split_url(url, 'path')
    assert result == '/path/to/file'

    result = split_url(url, 'query')

# Generated at 2022-06-23 10:35:33.805554
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:35:37.785231
# Unit test for function split_url
def test_split_url():
    assert split_url('https://httpbin.org/get') == {
        'netloc': 'httpbin.org',
        'path': '/get',
        'scheme': 'https',
        'query': '',
        'fragment': ''
    }

# Generated at 2022-06-23 10:35:45.605803
# Unit test for function split_url
def test_split_url():
    test_url = 'https://username:password@www.example.com:8080/some/path?some=query#some-fragment'
    assert (split_url('/some/path?some=query#some-fragment', query='netloc') == '')
    assert (split_url(test_url, query='netloc') == 'username:password@www.example.com:8080')
    assert (split_url(test_url, query='scheme') == 'https')
    assert (split_url(test_url, query='hostname') == 'www.example.com')
    assert (split_url(test_url, query='username') == 'username')
    assert (split_url(test_url, query='password') == 'password')

# Generated at 2022-06-23 10:35:48.177068
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:35:49.538785
# Unit test for function split_url
def test_split_url():
    split_url("http://www.example.com/test")

# Generated at 2022-06-23 10:35:51.107158
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    return fm



# Generated at 2022-06-23 10:35:58.238402
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    f = FilterModule()
    f_filters = f.filters()

    try:
        # Using a valid URL and query
        result = f_filters['urlsplit']('https://www.ansible.com/what-is-ansible', 'scheme')
        assert result == 'https'
    except AssertionError:
        raise AssertionError("Result of valid URL and query is incorrect, %s instead of %s" % (result, 'https'))

    try:
        # Using a valid URL and invalid query
        result = f_filters['urlsplit']('https://www.ansible.com/what-is-ansible', 'invalid')
        assert result == 'https'
    except AnsibleFilterError:
        # Expected exception
        pass
    except AssertionError:
        raise AssertionError

# Generated at 2022-06-23 10:36:04.199632
# Unit test for function split_url
def test_split_url():

    URL = "http://127.0.0.1:8080/hc?hc_or=AND&hc_resource_types=artifact,task"

    # Do a normal test with query
    data = split_url(URL, 'hostname')
    assert data == "127.0.0.1"

    # Do a list test
    data = split_url(URL)
    assert data['hostname'] == "127.0.0.1"

# Generated at 2022-06-23 10:36:13.709235
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test the split_url method of class FilterModule
    #
    # Test 1: Check that split_url correctly splits an absolute URL
    #
    # Create a FilterModule object to test its split_url method
    test_object = FilterModule()
    # Create the input for the split_url method
    test_url1 = 'http://www.example.com/path1/path2?param1=value1#fragment'
    # Get the dictionary returned by the split_url method
    test_dictionary = test_object.filters()['urlsplit'](test_url1)
    # Test that split_url correctly split the url into a dictionary with
    # the correct key/value pairs.
    assert test_dictionary['scheme'] == 'http'
    assert test_dictionary['netloc'] == 'www.example.com'