

# Generated at 2022-06-23 10:26:08.528394
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None

# Generated at 2022-06-23 10:26:11.572595
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print("\n\nTESTING FilterModule_filters()")
    assert "urlsplit" in FilterModule.filters(FilterModule)


# Generated at 2022-06-23 10:26:19.148796
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test value for input to filters
    value = 'https://github.com/dj-wasabi/ansible-filter-plugins/blob/master/doc/notify.md'

    # Expected result of filters call with given value
    expected_result = {
        'scheme': 'https',
        'netloc': 'github.com',
        'path': '/dj-wasabi/ansible-filter-plugins/blob/master/doc/notify.md',
        'params': '',
        'query': '',
        'fragment': ''
    }

    assert value
    assert split_url(value) == expected_result

# Generated at 2022-06-23 10:26:31.981551
# Unit test for function split_url
def test_split_url():
    test_url_value = "http://www.example.com/path/to/file.html"
    test_query = "netloc"
    test_dict = {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'params': '', 'query': '', 'fragment': ''}
    test_dict2 = {'scheme': 'http', 'netloc': '', 'path': '//www.example.com/path/to/file.html', 'params': '', 'query': '', 'fragment': ''}

    # Test when query is supplied
    assert split_url(test_url_value, test_query) == 'www.example.com'

    # Test when no query is supplied

# Generated at 2022-06-23 10:26:37.172011
# Unit test for function split_url
def test_split_url():

    assert split_url('https://www.ansible.com/jobs') == {'geturl': 'https://www.ansible.com/jobs', 'scheme': 'https', 'netloc': 'www.ansible.com', 'path': '/jobs', 'query': '', 'fragment': ''}
    assert split_url('https://ansible.com/jobs?extra') == {'geturl': 'https://ansible.com/jobs?extra', 'scheme': 'https', 'netloc': 'ansible.com', 'path': '/jobs', 'query': 'extra', 'fragment': ''}

# Generated at 2022-06-23 10:26:47.578308
# Unit test for function split_url
def test_split_url():
    split_url('http://foo.com/bar/baz/') == {
        'scheme': 'http',
        'netloc': 'foo.com',
        'path': '/bar/baz/',
        'query': '',
        'fragment': ''
    }

    split_url('http://foo.com/bar/baz/?query#fragment') == {
        'scheme': 'http',
        'netloc': 'foo.com',
        'path': '/bar/baz/',
        'query': 'query',
        'fragment': 'fragment'
    }

    split_url('http://foo.com/bar/baz/', 'scheme') == 'http'
    split_url('http://foo.com/bar/baz/', 'query') == ''


# Generated at 2022-06-23 10:26:55.441587
# Unit test for function split_url
def test_split_url():
    ''' `split_url` returns a dictionary of all the components of a URL by default. '''
    url = 'http://ansible.com:1234/test/url?test=test#test'
    result = split_url(url)

    assert isinstance(result, dict)
    assert result == {'scheme': 'http', 'netloc': 'ansible.com:1234', 'path': '/test/url', 'query': 'test=test', 'fragment': 'test'}


# Generated at 2022-06-23 10:26:57.279196
# Unit test for constructor of class FilterModule
def test_FilterModule():
    return FilterModule()


# Generated at 2022-06-23 10:27:04.435863
# Unit test for function split_url
def test_split_url():
    assert split_url("https://www.google.co.uk:8080/search?client=firefox-b") == {
        'fragment': '',
        'hostname': 'www.google.co.uk',
        'netloc': 'www.google.co.uk:8080',
        'path': '/search',
        'port': 8080,
        'query': 'client=firefox-b',
        'scheme': 'https',
        'username': None,
        'password': None
    }
    assert split_url("https://www.google.co.uk:8080/search?client=firefox-b", 'scheme') == 'https'

# Generated at 2022-06-23 10:27:04.906024
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:27:06.430695
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None


# Generated at 2022-06-23 10:27:14.151465
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    test_url = 'http://schemas.xmlsoap.org/wsdl/'

    # test with query param
    assert filters['urlsplit'](test_url, 'scheme') == 'http'

    # test without query param
    results = filters['urlsplit'](test_url)
    assert results['scheme'] == 'http'
    assert results['netloc'] == 'schemas.xmlsoap.org'
    assert results['path'] == '/wsdl/'
    assert results['query'] == ''
    assert results['fragment'] == ''

# Generated at 2022-06-23 10:27:24.523217
# Unit test for function split_url
def test_split_url():
    # Test each component type
    assert split_url('http://www.google.com') == {'scheme': 'http', 'netloc': 'www.google.com', 'path': '', 'query': '', 'fragment': ''}
    assert split_url('http://www.google.com', 'scheme') == 'http'
    assert split_url('http://www.google.com', 'netloc') == 'www.google.com'
    assert split_url('http://www.google.com', 'path') == ''
    assert split_url('http://www.google.com', 'query') == ''
    assert split_url('http://www.google.com', 'fragment') == ''

    # Test query string ?foo=bar&baz=bar

# Generated at 2022-06-23 10:27:33.625210
# Unit test for function split_url
def test_split_url():
    sample_urls = [
        'https://www.google.com/search?q=urlsplit+python',
        'https://docs.python.org/release/2.6.9/library/urlparse.html',
        'https://en.wikipedia.org/wiki/Uniform_Resource_Identifier#Generic_syntax',
        'https://docs.python.org/release/2.6.9/library/',
        'https://www.google.com/',
    ]

    url_components = {
        'scheme': 'https',
        'netloc': 'www.google.com',
        'path': '/search',
        'query': 'q=urlsplit+python',
        'fragment': '',
    }


# Generated at 2022-06-23 10:27:39.042290
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.ansible.com:443/docs/hosts.html#hosts', 'hostname') == 'www.ansible.com:443'
    assert split_url('https://www.ansible.com:443/docs/hosts.html#hosts', 'path') == '/docs/hosts.html#hosts'
    assert split_url('https://www.ansible.com:443/docs/hosts.html#hosts', 'scheme') == 'https'
    assert split_url('https://www.ansible.com:443/docs/hosts.html#hosts', 'netloc') == 'www.ansible.com:443'
    assert split_url('https://www.ansible.com:443/docs/hosts.html#hosts', 'query') is ''
   

# Generated at 2022-06-23 10:27:41.002859
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj is not None



# Generated at 2022-06-23 10:27:49.585591
# Unit test for function split_url
def test_split_url():

    from ansible.plugins.filter.urlsplit import split_url


# Generated at 2022-06-23 10:27:57.504124
# Unit test for function split_url
def test_split_url():
    url_string = 'http://foo.bar/baz:80/qux?a=b#foo'
    expected_results = {'scheme': 'http', 'netloc': 'foo.bar', 'path': '/baz:80/qux', 'query': 'a=b', 'fragment': 'foo'}
    test_results = split_url(url_string)
    assert test_results == expected_results, 'split_url() should return dictionary of URL components'

    test_results = split_url(url_string, 'scheme')
    assert test_results == expected_results['scheme'], 'split_url() should return "scheme" component of URL if query is supplied'

# Generated at 2022-06-23 10:27:58.727529
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module is not None

# Generated at 2022-06-23 10:28:00.657976
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters() is not None


# Generated at 2022-06-23 10:28:09.753033
# Unit test for function split_url
def test_split_url():

    assert split_url('http://ansible.com', query='scheme') == 'http'
    assert split_url('http://ansible.com', query='hostname') == 'ansible.com'
    assert split_url('http://ansible.com', query='path') == '/'
    assert split_url('http://ansible.com', query='query') == ''
    assert split_url('http://ansible.com', query='fragment') == ''

    with pytest.raises(AnsibleFilterError) as excinfo:
        split_url('http://ansible.com', query='unknown')
    assert 'unknown URL component' in str(excinfo.value)

    assert split_url('http://ansible.com', query='port') == None


# Generated at 2022-06-23 10:28:11.810624
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert {'urlsplit': split_url} == FilterModule().filters()

# Generated at 2022-06-23 10:28:13.709870
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # pylint: disable=no-value-for-parameter
    filter_module = FilterModule()
    assert filter_module is not None

# Generated at 2022-06-23 10:28:14.516496
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ok_(isinstance(FilterModule(), FilterModule))

# Generated at 2022-06-23 10:28:15.061184
# Unit test for constructor of class FilterModule
def test_FilterModule():
    return FilterModule()

# Generated at 2022-06-23 10:28:17.198331
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    assert filterModule.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:28:24.270198
# Unit test for function split_url
def test_split_url():

    test_url = 'https://www.example.com/path/the/end/'

    # Test for valid input
    assert split_url(value=test_url, query='netloc') == 'www.example.com'
    assert split_url(value=test_url, query='scheme') == 'https'
    assert split_url(value=test_url, query='path') == '/path/the/end/'
    assert split_url(value=test_url, query='') == {'path': '/path/the/end/', 'fragment': '', 'netloc': 'www.example.com', 'params': '', 'scheme': 'https', 'query': ''}

    # Test for invalid input

# Generated at 2022-06-23 10:28:29.234066
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('https://www.ansible.com/') == {'netloc': 'www.ansible.com', 'path': '/', 'scheme': 'https', 'query': '', 'fragment': ''}
    assert split_url('https://www.ansible.com/','scheme') == 'https'

# Generated at 2022-06-23 10:28:30.236517
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

# Generated at 2022-06-23 10:28:33.758715
# Unit test for constructor of class FilterModule
def test_FilterModule():
    print('File: %s' % __file__)
    f = FilterModule()
    print('filters = %s' % f.filters())


# Generated at 2022-06-23 10:28:35.554434
# Unit test for constructor of class FilterModule
def test_FilterModule():
    url_filter = FilterModule()
    assert url_filter.filters()


# Generated at 2022-06-23 10:28:47.428941
# Unit test for function split_url
def test_split_url():

    test_input_url = 'https://www.ansible.com/ansible-tower'
    test_input_query = 'scheme'
    test_input_alias = 'urlsplit'

    # Tests
    # Test that the value returned from urlsplit returns the correct scheme.
    assert split_url(test_input_url, query=test_input_query) == 'https'

    # Test that the entire dictionary is returned.
    assert isinstance(split_url(test_input_url), dict)

    # Test that the correct error is raised when an non-existent query is supplied.
    with pytest.raises(AnsibleFilterError) as err:
        split_url(test_input_url, query='', alias=test_input_alias)

# Generated at 2022-06-23 10:28:47.995424
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:28:56.963722
# Unit test for function split_url
def test_split_url():

    # Set the data
    data = {
        'url': 'https://user:pass@example.org:8080/path;param?query=arg#frag',
        'url_query': 'https://user:pass@example.org:8080/path;param?query=arg#frag',
        'url_invalid': 'https://user:pass@example.org:8080/path;param?query=arg#frag',
    }

    # Run the tests
    for test, value in data.items():
        result = split_url(value)
        assert result['hostname'] == 'example.org', '%s: hostname failed: %s' % (test, result['hostname'])

# Generated at 2022-06-23 10:29:00.452229
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Create an object of the class FilterModule
    obj = FilterModule()

    # Test for data type of object
    assert isinstance(obj, FilterModule)



# Generated at 2022-06-23 10:29:02.859104
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:29:04.894100
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert 'urlsplit' in f.filters()


# Generated at 2022-06-23 10:29:16.200590
# Unit test for function split_url
def test_split_url():
    assert split_url('https://user:pass@test.com:443/path?query=string#fragment', 'scheme') == 'https'
    assert split_url('https://user:pass@test.com:443/path?query=string#fragment', 'auth') == 'user:pass'
    assert split_url('https://user:pass@test.com:443/path?query=string#fragment', 'host') == 'test.com'
    assert split_url('https://user:pass@test.com:443/path?query=string#fragment', 'port') == 443
    assert split_url('https://user:pass@test.com:443/path?query=string#fragment', 'path') == '/path'

# Generated at 2022-06-23 10:29:17.987117
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(FilterModule() is not None)


# Generated at 2022-06-23 10:29:21.021420
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert (f.filters()['urlsplit'] == split_url)


# Generated at 2022-06-23 10:29:34.259475
# Unit test for function split_url
def test_split_url():
    u = "http://example.com:81/foo/bar/baz.html;para?x=1;y=2;z=3#ref"
    r = split_url(u)
    assert r['scheme'] == 'http'
    assert r['netloc'] == 'example.com:81'
    assert r['path'] == '/foo/bar/baz.html;para'
    assert r['query'] == 'x=1;y=2;z=3'
    assert r['fragment'] == 'ref'
    assert r['params'] == 'para'

    assert split_url(u, 'scheme') == 'http'
    assert split_url(u, 'netloc') == 'example.com:81'

# Generated at 2022-06-23 10:29:36.284175
# Unit test for constructor of class FilterModule
def test_FilterModule():
    s = FilterModule()
    filters = s.filters()
    assert filters['urlsplit'] == split_url


# Generated at 2022-06-23 10:29:48.316161
# Unit test for function split_url
def test_split_url():
    import unittest

    from ansible.parsing.yaml.objects import AnsibleUnicode

    class TestSplitUrl(unittest.TestCase):

        def setUp(self):
            pass

        def test_scheme(self):
            self.assertEqual(split_url(AnsibleUnicode('http://example.com:8080/foo/bar.htm?value=1')), {
                'scheme': 'http',
                'netloc': 'example.com:8080',
                'path': '/foo/bar.htm',
                'query': 'value=1',
                'fragment': ''
            })

# Generated at 2022-06-23 10:29:51.010083
# Unit test for constructor of class FilterModule
def test_FilterModule():
    r = FilterModule()
    assert r is not None

# Unit tests for
# filters = {
#     'urlsplit': split_url
# }

# Generated at 2022-06-23 10:29:57.377838
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print(FilterModule().filters()['urlsplit'].__doc__)
    print(FilterModule().filters()['urlsplit']('https://docs.ansible.com/ansible/latest/modules/urlsplit_module.html', "netloc"))


# Generated at 2022-06-23 10:30:03.411799
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    url = "http://192.168.1.65:8080/api/datacenters/1/virtualappliances/1/virtualmachines/1/action/deploy"
    spliturl = {'fragment': '', 'scheme': 'http', 'netloc': '192.168.1.65:8080', 'path': '/api/datacenters/1/virtualappliances/1/virtualmachines/1/action/deploy', 'query': ''}

    assert split_url(url) == spliturl
    assert split_url(url, query='scheme') == 'http'

# Generated at 2022-06-23 10:30:12.669838
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''Test FilterModule filters'''

    test_url = 'http://www.example.com/path/to/file?param1=foo¶m2=bar'

    assert split_url(test_url) == {'scheme': 'http',
                                   'netloc': 'www.example.com',
                                   'path': '/path/to/file',
                                   'query': 'param1=foo¶m2=bar',
                                   'fragment': ''}

    assert split_url(test_url, 'scheme') == 'http'
    assert split_url(test_url, 'unknown') == 'unknown'


# Generated at 2022-06-23 10:30:18.231139
# Unit test for function split_url
def test_split_url():

    test_string = 'http://username:password@example.com:8080/path?arg1=val1&arg2=val2#fragment'
    expected_result = {"scheme": "http", "netloc": "username:password@example.com:8080", "path": "/path", "query": "arg1=val1&arg2=val2", "fragment": "fragment"}

    assert split_url(test_string) == expected_result

# Generated at 2022-06-23 10:30:22.710247
# Unit test for function split_url
def test_split_url():
    value = 'https://hg:8081/v1/ansible/ansible'
    query = 'path'
    expected = '/v1/ansible/ansible'
    result = split_url(value, query)
    assert result == expected

# Generated at 2022-06-23 10:30:33.213945
# Unit test for function split_url
def test_split_url():
    """
    Test the split_url function.
    """
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    from ansible.parsing.dataloader import DataLoader

    data = 'ansible'
    scheme = 'https'
    netloc = 'www.ansible.com'
    path = '/r/'
    query = None
    fragment = None
    url = '{0:s}://{1:s}{2:s}'.format(scheme, netloc, path)
    url_parts = DataLoader().load_from_file(urlsplit(url))

    # Test the full url
    result = split_url(url)
    assert result == url_parts

    # Test the scheme
    result = split_url(url, query='scheme')

# Generated at 2022-06-23 10:30:34.958914
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() == {
            'urlsplit': split_url
        }


# Generated at 2022-06-23 10:30:47.167614
# Unit test for function split_url
def test_split_url():
    assert split_url('http://user:pass@hostname.com:1234/path?arg=value#frag') == {'fragment': 'frag', 'hostname': 'hostname.com', 'path': '/path', 'query': 'arg=value', 'port': 1234, 'username': 'user', 'scheme': 'http', 'password': 'pass'}, 'urlsplit: did not return expected dictionary'
    assert split_url('http://user:pass@hostname.com:1234/path?arg=value#frag', 'password') == 'pass', 'urlsplit: did not return expected value for given query'

# Generated at 2022-06-23 10:30:52.114471
# Unit test for function split_url
def test_split_url():
    import random

    ret_dict = {}

# Generated at 2022-06-23 10:30:54.532971
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters is not None


# Generated at 2022-06-23 10:30:57.780062
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    This function returns the FilterModule instance
    """
    ansible_module = FilterModule()
    return ansible_module



# Generated at 2022-06-23 10:31:05.712734
# Unit test for function split_url
def test_split_url():
    result = split_url('https://www.example.com:8080/path/to/url?query=1&options=2#fragment')
    assert result == {
        'scheme': 'https',
        'fragment': 'fragment',
        'hostname': 'www.example.com',
        'netloc': 'www.example.com:8080',
        'path': '/path/to/url',
        'query': 'query=1&options=2',
        'port': 8080,
        'username': None,
        'password': None,
    }



# Generated at 2022-06-23 10:31:11.789393
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    # TODO
    #assert obj
    assert obj.filters()

# Generated at 2022-06-23 10:31:14.122420
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(None) == {'urlsplit':split_url}

# ---- Ansible filters ----


# Generated at 2022-06-23 10:31:16.069501
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test empty string
    ret = '{}'
    assert ret == FilterModule().filters()



# Generated at 2022-06-23 10:31:17.542665
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')

# Generated at 2022-06-23 10:31:21.400055
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Unit: Return a method filters, which take one argument and return a dict.
    filter_module = FilterModule()
    result = filter_module.filters()
    assert len(result) is 1
    assert result['urlsplit'] is split_url


# Generated at 2022-06-23 10:31:29.146110
# Unit test for constructor of class FilterModule
def test_FilterModule():

    from ansible.utils import plugin_docs
    from ansible.plugins import filter_loader

    # Create an instance of the FilterModule class
    fm = FilterModule()

    # Create a plugin loader
    loader = plugin_loader.FilterModuleLoader(filter_loader)

    # Make sure that the doc of the class is correct
    assert fm.__doc__ == plugin_docs.DOCUMENTATION['filter']['urlsplit']

    # Make sure that the class is registered in the loader
    assert 'urlsplit' in loader._filter_plugins

    # Check if the filters function is working properly
    assert len(fm.filters()) == 1
    assert fm.filters()['urlsplit'].__name__ == 'split_url'



# Generated at 2022-06-23 10:31:30.704838
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    modules = FilterModule()
    assert modules.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:31:35.139000
# Unit test for function split_url
def test_split_url():
    value = 'http://www.example.com'
    results = split_url(value)

    assert results['scheme'] == 'http', 'scheme is not http'
    assert results['netloc'] == 'www.example.com', 'netloc is not www.example.com'
    assert results['path'] == '', 'path is not empty'

    query = 'scheme'
    results = split_url(value, query)

    assert results == 'http', 'scheme is not http'

# Generated at 2022-06-23 10:31:38.540877
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    assert 'urlsplit' in filters
    assert callable(filters['urlsplit'])


# Generated at 2022-06-23 10:31:44.030525
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    result = module.filters()
    # On successfull execution, a dict object will be returned
    assert isinstance(result, dict)
    # Returned dict object should have a key 'urlsplit'
    assert 'urlsplit' in result.keys()
    # 'urlsplit' should point to the split_url function
    assert result['urlsplit'] == split_url

# ---- Tests for split_url ----

# Generated at 2022-06-23 10:31:53.470267
# Unit test for function split_url
def test_split_url():
    # pylint: disable=unused-variable
    import sys
    from ansible.module_utils import json

    try:
        from pytest import raises
    except ImportError as e:
        print('\nTest requires module pytest to be installed: %s\n' % e, file=sys.stderr)
        sys.exit(1)

    try:
        import urllib3
    except ImportError as e:
        print('\nTest requires module urllib3 to be installed: %s\n' % e, file=sys.stderr)
        sys.exit(1)

    filter_module = FilterModule()
    filters = filter_module.filters()

    # Identify the filter function to test
    filter_function = filters['urlsplit']


# Generated at 2022-06-23 10:31:59.147606
# Unit test for function split_url
def test_split_url():
    data = {
        'url': 'https://docs.ansible.com/ansible/latest/glossary.html#term-control-machine',
        'query': 'path'
    }

    result = split_url(data['url'], data['query'])
    assert result == '/ansible/latest/glossary.html'

# Generated at 2022-06-23 10:32:10.295413
# Unit test for function split_url
def test_split_url():
    ansible_args = split_url('https://www.example.com/path/to/page?key=val#frag')
    assert ansible_args['scheme'] == 'https'
    assert ansible_args['netloc'] == 'www.example.com'
    assert ansible_args['path'] == '/path/to/page'
    assert ansible_args['query'] == 'key=val'
    assert ansible_args['fragment'] == 'frag'

    assert split_url('https://www.example.com/path/to/page?key=val#frag', 'scheme') == 'https'
    assert split_url('https://www.example.com/path/to/page?key=val#frag', 'netloc') == 'www.example.com'

# Generated at 2022-06-23 10:32:14.140143
# Unit test for constructor of class FilterModule
def test_FilterModule():
    '''
    Unit test for constructor of class FilterModule
    :return: none
    '''
    obj = FilterModule()
    assert isinstance(obj, FilterModule)



# Generated at 2022-06-23 10:32:15.483154
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule) == {'urlsplit': split_url}

# Generated at 2022-06-23 10:32:24.020654
# Unit test for function split_url
def test_split_url():
    assert split_url('https://bob:secret@example.com/foo/bar?baz=1&q=2') == {
        'fragment': '',
        'netloc': 'bob:secret@example.com',
        'path': '/foo/bar',
        'query': 'baz=1&q=2',
        'scheme': 'https',
    }
    assert split_url('https://bob:secret@example.com/foo/bar?baz=1&q=2', 'path') == '/foo/bar'
    assert split_url('https://bob:secret@example.com/foo/bar?baz=1&q=2', 'netloc') == 'bob:secret@example.com'

# Generated at 2022-06-23 10:32:25.256305
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(issubclass(FilterModule, object))
    assert(hasattr(FilterModule, 'filters'))


# Generated at 2022-06-23 10:32:29.231319
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # import class
    from ansible_collections.notstdlib.moveitallout.plugins.filter import basic
    # set up object
    x = basic.FilterModule()
    # return class
    return x

# Generated at 2022-06-23 10:32:31.129205
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    instance = FilterModule()
    assert instance.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:32:42.012891
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    uri = 'ftp://user:pass@10.10.10.10:21/files?name=val#frag'
    assert x.filters()['urlsplit'](uri) == {
        'scheme': 'ftp',
        'netloc': 'user:pass@10.10.10.10:21',
        'path': '/files',
        'params': '',
        'query': 'name=val',
        'fragment': 'frag',
        'username': 'user',
        'password': 'pass',
        'hostname': '10.10.10.10',
        'port': 21,
    }
    assert x.filters()['urlsplit'](uri, query='fragment') == 'frag'

# Generated at 2022-06-23 10:32:45.379658
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    method = 'filters'
    expected = {
        'urlsplit': split_url
    }
    actual = module.filters()

    assert actual == expected


# Generated at 2022-06-23 10:32:51.098459
# Unit test for function split_url
def test_split_url():
    '''Test splitting a URL into dictionary'''
    value = 'http://username:password@www.example.com/path;param?query=value#fragment'
    expected_result = {
        'scheme': 'http',
        'netloc': 'username:password@www.example.com',
        'path': '/path;param',
        'query': 'query=value',
        'fragment': 'fragment'
    }

    result = split_url(value)

    assert expected_result == result

# Generated at 2022-06-23 10:32:57.698938
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ansible = {"ansible_facts": {"some_fact": "some_value"}}
    uri = "http://www.example.com"
    url = FilterModule()
    url_dict = url.filters()
    assert url_dict['urlsplit'](uri) == {'fragment': '', 'netloc': 'www.example.com', 'path': '/', 'query': '', 'scheme': 'http'}


# Generated at 2022-06-23 10:33:03.571609
# Unit test for function split_url
def test_split_url():
    url = 'https://www.ansible.com/about'
    filtered_url = split_url(url)
    assert filtered_url['scheme'] == 'https'
    assert filtered_url['fragment'] == ''

    query = 'netloc'
    filtered_url = split_url(url, query=query)
    assert filtered_url == 'www.ansible.com'

# Generated at 2022-06-23 10:33:05.103432
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    assert x.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:33:07.275019
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    myfilter = FilterModule()
    assert myfilter.filters() != {}



# Generated at 2022-06-23 10:33:09.593220
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(None) == {'urlsplit': split_url}


# ---- Ansible filter: urlsplit ----

# Generated at 2022-06-23 10:33:11.596436
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    assert 'filters' in dir(filters)



# Generated at 2022-06-23 10:33:13.118670
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None

# Generated at 2022-06-23 10:33:22.436537
# Unit test for function split_url
def test_split_url():
    # Define a test URL.
    test_url = 'http://www.example.com:8080/test/test/test/?id=123&test=test'

    # Split the URL based on the options defined in the list 'split_query' and
    # return the results in a list.
    split_query = ['scheme', 'netloc', 'path', 'params', 'query', 'fragment']
    test_results = list(map(lambda x: split_url(test_url, x), split_query))

    # Compile a list of expected results.
    expected_results = [
        'http',
        'www.example.com:8080',
        '/test/test/test/',
        '',
        'id=123&test=test',
        ''
    ]

    # Compare the results.


# Generated at 2022-06-23 10:33:24.564877
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters().keys()


# Generated at 2022-06-23 10:33:35.243304
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    for item in [('https://www.redhat.com/en', 'scheme', 'https', 'urlsplit'),
                 ('https://www.redhat.com/en', 'netloc', 'www.redhat.com', 'urlsplit'),
                 ('https://www.redhat.com/en', 'path', '/en', 'urlsplit'),
                 ('https://www.redhat.com/en', 'query', '', 'urlsplit'),
                 ('https://www.redhat.com/en', 'fragment', '', 'urlsplit'),
                 ('https://www.redhat.com/en', 'hostname', 'www.redhat.com', 'urlsplit'),
                 ('https://www.redhat.com/en', 'hostname', 'www.redhat.com', 'urlsplit')]:
        input_value, query,

# Generated at 2022-06-23 10:33:45.769191
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils._text import to_native

# Generated at 2022-06-23 10:33:49.195611
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:33:51.030492
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:33:52.218428
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Dummy input for constructor
    f = FilterModule()
    assert f

# Generated at 2022-06-23 10:34:03.241992
# Unit test for function split_url
def test_split_url():
    test_url = 'https://docs.ansible.com/ansible/2.5/network/getting_started/first_playbook.html'

    # Test split by query parameter
    assert split_url(test_url, 'scheme') == 'https'
    assert split_url(test_url, 'netloc') == 'docs.ansible.com'
    assert split_url(test_url, 'path') == '/ansible/2.5/network/getting_started/first_playbook.html'
    assert split_url(test_url, 'query') == ''
    assert split_url(test_url, 'fragment') == ''

    # Test split by no paramter

# Generated at 2022-06-23 10:34:12.031891
# Unit test for function split_url
def test_split_url():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock, MagicMock
    from ansible.module_utils.six.moves.urllib.parse import urlsplit


# Generated at 2022-06-23 10:34:22.459432
# Unit test for function split_url
def test_split_url():
    host_id = {'id': 1, 'ip_address': 'localhost', 'username': 'root', 'password': 'root', 'port':22}
    host_ip = {'id': 1, 'ip_address': '127.0.0.1', 'username': 'root', 'password': 'root', 'port':22}
    assert split_url('root@127.0.0.1:22') == host_ip
    assert split_url('root@localhost:22') == host_id
    assert split_url('root@127.0.0.1:22',query='query') == ''
    assert split_url('root@127.0.0.1:22',query='port') == 22

# Generated at 2022-06-23 10:34:25.715368
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:34:26.752035
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    FilterModule().filters()

# Generated at 2022-06-23 10:34:28.334654
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:34:35.867525
# Unit test for function split_url
def test_split_url():
    # Test function
    func_result = split_url('https://www.google.com/search?client=ubuntu&channel=fs&q=python+urllib&ie=utf-8&oe=utf-8')
    # Expected result
    expected_result = {
        'scheme': 'https',
        'netloc': 'www.google.com',
        'path':   '/search',
        'query':  'channel=fs&client=ubuntu&ie=utf-8&oe=utf-8&q=python+urllib',
        'fragment': ''
    }
    # Asserting the result
    assert func_result == expected_result


# Generated at 2022-06-23 10:34:49.016932
# Unit test for function split_url
def test_split_url():
    import os
    from ansible.module_utils.six.moves.urllib.parse import urlsplit

    def load_fixture(filename):
        path = os.path.join(os.path.dirname(__file__), 'fixtures', filename)
        with open(path) as data_file:
            return data_file.read()

    for fixture in ('urlsplit.yml',):
        for test_dict in load_fixture(fixture).split('\n-'):
            if not test_dict.strip():
                continue
            args_dict = {}
            try:
                args_dict = helpers.unsafe_load(test_dict)
            except:
                print("Could not parse malformed test: %s" % test_dict)
                raise

# Generated at 2022-06-23 10:34:50.395682
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters() is not None



# Generated at 2022-06-23 10:34:53.037145
# Unit test for function split_url
def test_split_url():
    value = 'http://www.ansible.com/'
    expected = {
        'scheme': 'http',
        'netloc': 'www.ansible.com',
        'path': '/',
        'query': '',
        'fragment': ''
    }
    assert split_url(value) == expected

# Generated at 2022-06-23 10:34:54.375039
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.__class__.__name__ == 'FilterModule'


# Generated at 2022-06-23 10:34:55.843213
# Unit test for constructor of class FilterModule
def test_FilterModule():
    m = FilterModule()
    assert({'urlsplit': split_url} == m.filters())


# Generated at 2022-06-23 10:34:58.547433
# Unit test for constructor of class FilterModule
def test_FilterModule():
    t = 'urlsplit'
    assert t == FilterModule.filters(FilterModule).get('urlsplit').__name__

# Generated at 2022-06-23 10:34:59.783092
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()

# Unit tests for method split_url of class FilterModule

# Generated at 2022-06-23 10:35:02.044690
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert obj.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:35:04.545555
# Unit test for constructor of class FilterModule
def test_FilterModule():
    print('test_FilterModule:')
    f = FilterModule()
    assert isinstance(f.filters(), dict)



# Generated at 2022-06-23 10:35:07.773158
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    assert filters == {
        'urlsplit': split_url
    }



# Generated at 2022-06-23 10:35:15.958331
# Unit test for function split_url
def test_split_url():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.vars.manager import InventoryManager
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    var_manager = VariableManager(loader=loader, inventory=inventory)
    var = VariableManager()
    templar = Templar(loader=loader, variables=var_manager)

    # Empty string
    value = ''
    assert(split_url(value) == templar.template(value))

    # No query
    value = 'https://www.ansible.com/'
    assert(split_url(value) == templar.template(value))

    # Query
    value = 'https://www.ansible.com/'

# Generated at 2022-06-23 10:35:27.505547
# Unit test for function split_url
def test_split_url():
    test_value = 'https://user:pass@host.com:8080/path/page?key=val&key2=val2#fragment'
    result = split_url(test_value, '')
    assert result['scheme'] == 'https' and result['netloc'] == 'user:pass@host.com:8080' and \
           result['path'] == '/path/page' and result['query'] == 'key=val&key2=val2' and \
           result['fragment'] == 'fragment'

    result = split_url(test_value, 'scheme')
    assert result == 'https'

    result = split_url(test_value, 'netloc')
    assert result == 'user:pass@host.com:8080'


# Generated at 2022-06-23 10:35:39.417721
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    test_filters = FilterModule().filters()

    url = 'https://www.example.com:8080/path/to/myfile.html?key1=value1&key2=value2#SomewhereInTheDocument'
    url_components = test_filters['urlsplit'](url)

    url_components = split_url(url)
    assert url_components['scheme'] == 'https'
    assert url_components['netloc'] == 'www.example.com:8080'
    assert url_components['path'] == '/path/to/myfile.html'
    assert url_components['params'] == ''
    assert url_components['query'] == 'key1=value1&key2=value2'

# Generated at 2022-06-23 10:35:53.846563
# Unit test for function split_url
def test_split_url():
    assert split_url("") == {'Netloc': '', 'Params': '', 'Query': '', 'Path': '', 'Scheme': '', 'Fragment': ''}
    assert split_url("http://www.example.com") == {'Netloc': 'www.example.com', 'Params': '', 'Query': '', 'Path': '', 'Scheme': 'http', 'Fragment': ''}
    assert split_url("http://www.example.com", "Hostname") == 'www.example.com'
    assert split_url("http://www.example.com", "Port") == ''
    assert split_url("http://www.example.com:8080", "Port") == '8080'
    assert split_url("http://user@www.example.com", "Username") == 'user'


# Generated at 2022-06-23 10:36:03.941393
# Unit test for function split_url
def test_split_url():

    # Sample URL
    test_url = "https://www.google.com:8080/search?hl=en&client=safari&rls=en&q=ansible&btnG=Search&aq=f&oq=&aqi="

    # Call function to split the URL
    results = split_url(test_url)

    # Make sure the results are correct
    assert results['scheme'] == 'https'
    assert results['netloc'] == 'www.google.com:8080'
    assert results['path'] == '/search'
    assert results['query'] == 'hl=en&client=safari&rls=en&q=ansible&btnG=Search&aq=f&oq=&aqi='
    assert results['fragment'] == ''

# Generated at 2022-06-23 10:36:10.331630
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('example.com/api/v1', 'netloc') == 'example.com'
    assert split_url('example.com/api/v1', 'scheme') == ''
    assert split_url('example.com/api/v1', 'path') == '/api/v1'
    assert split_url('example.com/api/v1', 'query') == ''
    assert split_url('example.com/api/v1', 'fragment') == ''

    assert split_url('https://www.example.com/api/v1/users?param=value#fragment', 'netloc') == 'www.example.com'
    assert split_url('https://www.example.com/api/v1/users?param=value#fragment', 'scheme') == 'https'
   