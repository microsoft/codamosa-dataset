

# Generated at 2022-06-23 10:26:08.318355
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filtermodule = FilterModule()
    assert filtermodule


# Generated at 2022-06-23 10:26:09.805707
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:26:19.033415
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            pass

    mock_ansible_module = MockAnsibleModule()
    assert split_url(mock_ansible_module, "foobar", "urlsplit") == None
    assert split_url(mock_ansible_module, "http://foo.com/chuck.html", "urlsplit") == {
        'query': '',
        'scheme': 'http',
        'fragment': '',
        'port': None,
        'hostname': 'foo.com',
        'path': '/chuck.html'
    }

# Generated at 2022-06-23 10:26:25.173639
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    from datetime import datetime
    assert split_url('http://www.example.com/foo/bar') == {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/foo/bar', 'query': '', 'fragment': ''}
    assert split_url('https://www.example.com/foo/bar') == {'scheme': 'https', 'netloc': 'www.example.com', 'path': '/foo/bar', 'query': '', 'fragment': ''}

# Generated at 2022-06-23 10:26:35.827145
# Unit test for function split_url
def test_split_url():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    options = None
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 10:26:37.298222
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:26:39.964105
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters() == { 'urlsplit': split_url }


# Generated at 2022-06-23 10:26:41.653332
# Unit test for constructor of class FilterModule
def test_FilterModule():
  f = FilterModule()
  assert f != None

# Generated at 2022-06-23 10:26:50.734709
# Unit test for function split_url
def test_split_url():

    url = 'https://www.ansible.com/ansible-tower'

    ret = split_url(url, query='scheme')
    assert ret == 'https', 'Scheme is https'

    ret = split_url(url, query='netloc')
    assert ret == 'www.ansible.com', 'netloc is www.ansible.com'

    ret = split_url(url, query='hostname')
    assert ret == 'www.ansible.com', 'hostname is www.ansible.com'

    ret = split_url(url, query='path')
    assert ret == '/ansible-tower', 'path is /ansible-tower'

    ret = split_url(url, query='params')
    assert ret == '', 'params is empty'

    ret = split_url(url, query='query')

# Generated at 2022-06-23 10:26:58.389499
# Unit test for constructor of class FilterModule
def test_FilterModule():
	assert split_url('https://www.google.com/search?q=%E2%98%83') == {'hostname': u'www.google.com', 'netloc': u'www.google.com', 'path': u'/search', 'query': u'q=%E2%98%83', 'scheme': u'https', 'fragment': u'', 'params': u'', 'username': u'', 'password': u''}
	assert split_url('https://www.google.com/search?q=%E2%98%83',query='scheme') == u'https'

# Generated at 2022-06-23 10:26:59.541354
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    assert {} == FilterModule().filters()


# Generated at 2022-06-23 10:27:00.983627
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')

# Generated at 2022-06-23 10:27:03.685521
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule())

# Generated at 2022-06-23 10:27:05.355271
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import pytest
    fm = FilterModule()
    assert fm.filters()



# Generated at 2022-06-23 10:27:14.901764
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter = FilterModule().filters()

    # Test filter: split_url
    assert filter.get('urlsplit')('https://www.ansible.com') == {
        'scheme': u'https', 'netloc': u'www.ansible.com', 'path': u'', 'query': u'', 'fragment': u''
    }
    assert filter.get('urlsplit')('https://www.ansible.com/') == {
        'scheme': u'https', 'netloc': u'www.ansible.com', 'path': u'/', 'query': u'', 'fragment': u''
    }
    assert filter.get('urlsplit')('https://www.ansible.com/')['scheme'] == u'https'

# Generated at 2022-06-23 10:27:17.839563
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    results = fm.filters()
    assert results['urlsplit'].__name__ == "split_url"

# Generated at 2022-06-23 10:27:24.660614
# Unit test for function split_url
def test_split_url():
    f = FilterModule()
    url = 'http://username:password@www.python.org:8080/doc/en/index.html;a=1;b=2?query1=test&query2=abc#frag'
    result = f.filters()['urlsplit'](url)
    assert result == {
        'scheme': 'http',
        'netloc': 'username:password@www.python.org:8080',
        'path': '/doc/en/index.html;a=1;b=2',
        'query': 'query1=test&query2=abc',
        'fragment': 'frag',
        'username': 'username',
        'password': 'password',
        'hostname': 'www.python.org',
        'port': 8080
    }
    result = f

# Generated at 2022-06-23 10:27:33.726675
# Unit test for function split_url

# Generated at 2022-06-23 10:27:34.839467
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fmod = FilterModule()
    assert fmod.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:27:42.566505
# Unit test for function split_url
def test_split_url():
    url = "https://192.168.1.1/api/nodes?name=a*"
    assert split_url(url, '') == {'fragment': '', 'netloc': '192.168.1.1', 'path': '/api/nodes', 'query': 'name=a%2A', 'scheme': 'https'}
    assert split_url(url, 'query') == 'name=a%2A'

# Generated at 2022-06-23 10:27:43.876813
# Unit test for constructor of class FilterModule
def test_FilterModule():
    m = FilterModule()
    assert isinstance(m, FilterModule)


# Generated at 2022-06-23 10:27:46.328436
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None
    assert FilterModule().filters() is not None
    assert 'urlsplit' in FilterModule().filters()


# Generated at 2022-06-23 10:27:48.419970
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
	fm = FilterModule()
	assert fm.filters()


# Generated at 2022-06-23 10:27:57.431166
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils.six.moves import urllib
    url = 'http://my_domain.com/path?key1=val1&key2=val2'

# Generated at 2022-06-23 10:27:59.316234
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()


# Generated at 2022-06-23 10:28:00.567107
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule(), 'filters')

# Generated at 2022-06-23 10:28:03.495168
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert {u'urlsplit': split_url} == filter_module.filters()


# Generated at 2022-06-23 10:28:06.024434
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test that FilterModule.filters correctly returns 'urlsplit'
    f = FilterModule()
    filters = f.filters()
    assert filters['urlsplit'] == split_url


# Generated at 2022-06-23 10:28:14.442219
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    uri = "https://docs.python.org/3.3/library/urllib.parse.html"

    result = fm.filters()['urlsplit'](uri, query='scheme') == 'https'
    assert result

    query = ''
    result = fm.filters()['urlsplit'](uri, query=query)

    if result['scheme'] != 'https' or \
            result['netloc'] != 'docs.python.org' or \
            result['path'] != '/3.3/library/urllib.parse.html' or \
            result['params'] != '' or \
            result['query'] != '' or \
            result['fragment'] != '':

        assert False

# Generated at 2022-06-23 10:28:22.629280
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    fm = FilterModule()

    # Basic split tests for urlsplit filter
    assert fm.filters()['urlsplit']('http://www.example.com') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '',
        'params': '',
        'query': '',
        'fragment': ''
    }

    assert fm.filters()['urlsplit']('http://www.example.com', 'scheme') == 'http'
    assert fm.filters()['urlsplit']('http://www.example.com', 'netloc') == 'www.example.com'

# Generated at 2022-06-23 10:28:33.437436
# Unit test for function split_url
def test_split_url():
    module = FilterModule()
    f = module.filters()['urlsplit']
    assert f("http://www.example.com:8080/bar/foo?abc=def&ghi=jkl#mno", "scheme") == "http"
    assert f("http://www.example.com:8080/bar/foo?abc=def&ghi=jkl#mno", "netloc") == "www.example.com:8080"
    assert f("http://www.example.com:8080/bar/foo?abc=def&ghi=jkl#mno", "path") == "/bar/foo"
    assert f("http://www.example.com:8080/bar/foo?abc=def&ghi=jkl#mno", "params") == ""

# Generated at 2022-06-23 10:28:34.357801
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:28:36.386745
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:28:47.573198
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import os, sys
    ansible_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__name__)))))
    sys.path.insert(0, ansible_path)

    value = "http://www.baidu.com/s?wd=centos&rsv_spt=1&issp=1&f=8&rsv_bp=0&rsv_idx=2&ie=utf-8&tn=baiduhome_pg&rsv_enter=1&rsv_sug3=7&rsv_sug1=6&rsv_sug7=100&rsv_sug2=0&inputT=1033&rsv_sug4=1033"
    query

# Generated at 2022-06-23 10:28:48.219481
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:28:50.322288
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert(FilterModule.filters(FilterModule()) == {
            'urlsplit': split_url
        })


# Generated at 2022-06-23 10:28:52.692530
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule = FilterModule()
    filters = filtermodule.filters()
    assert filters['urlsplit'] == split_url



# Generated at 2022-06-23 10:28:54.287532
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(FilterModule is not None)
    assert(isinstance(FilterModule(), FilterModule))


# Generated at 2022-06-23 10:29:00.927226
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Build a mock instance of ansible.errors.AnsibleFilterError
    # so this test can be performed without needing to import __init__.py
    test_AnsibleFilterError = type(
        'AnsibleFilterError',
        (object,),
        {
            '__init__': lambda self, msg: setattr(self, 'message', msg),
            '__str__': lambda self: getattr(self, 'message')
        }
    )

# Generated at 2022-06-23 10:29:01.708430
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()



# Generated at 2022-06-23 10:29:11.291489
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.utils.hashing import md5s
    filter_module = FilterModule()

    url = "http://www.google.com/search?q=foo+bar"
    hashed_url = md5s(url)
    splitted_url = filter_module.filters()['urlsplit'](url, '')
    splitted_url_hashed_scheme = md5s(splitted_url['scheme'])
    splitted_url_hashed_query = md5s(splitted_url['query'])

    assert hashed_url == 'f13dbb07295a984895dfb7df24e588d6'
    assert splitted_url_hashed_scheme == '405f31e40a4a838b923d1ab88894a4cd'

# Generated at 2022-06-23 10:29:16.796743
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj is not None


# Generated at 2022-06-23 10:29:20.144840
# Unit test for function split_url
def test_split_url():
    value = "http://www.abc.com/test1/test2/"
    query = "netloc"
    alias = "urlsplit"
    assert split_url(value, query, alias) == "www.abc.com"

# Generated at 2022-06-23 10:29:21.022799
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:29:24.078589
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert  'urlsplit' in FilterModule.filters(FilterModule)

# Generated at 2022-06-23 10:29:35.591317
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filt_mod = FilterModule()
    assert split_url('http://www.example.com/foo') == \
        filt_mod.filters()['urlsplit']('http://www.example.com/foo')
    assert split_url('http://www.example.com/foo', 'parameters') == \
        filt_mod.filters()['urlsplit']('http://www.example.com/foo', 'parameters')
    assert split_url('http://www.example.com/foo', 'scheme') == \
        filt_mod.filters()['urlsplit']('http://www.example.com/foo', 'scheme')

# Generated at 2022-06-23 10:29:40.769084
# Unit test for function split_url
def test_split_url():
    ''' Tests for the split_url function '''

    test_url = 'http://www.example.com/path/to/file.html?key1=value1&key2=value2#test'
    result = {
            'netloc': 'www.example.com',
            'fragment': 'test',
            'scheme': 'http',
            'path': '/path/to/file.html',
            'query': 'key1=value1&key2=value2'
            }

    assert split_url(test_url) == result

# Generated at 2022-06-23 10:29:49.688585
# Unit test for function split_url
def test_split_url():
    '''
    Test split_url()
    '''
    s = 'http://www.example.com/index.html?arg1=1&arg2=2'
    url_split = split_url(s, '')
    assert url_split['query'] == 'arg1=1&arg2=2'
    assert url_split['scheme'] == 'http'
    assert url_split['netloc'] == 'www.example.com'
    assert url_split['path'] == '/index.html'
    assert url_split['fragment'] == ''

# Generated at 2022-06-23 10:29:51.935796
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Check that constructor is a class
    assert callable(FilterModule)
    instance = FilterModule()
    assert isinstance(instance, FilterModule)


# Generated at 2022-06-23 10:29:52.563286
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(True)

# Generated at 2022-06-23 10:29:55.241073
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fmodule = FilterModule()
    assert fmodule.filters() == {
        'urlsplit': split_url
    }

# Generated at 2022-06-23 10:30:04.793736
# Unit test for function split_url
def test_split_url():
    """
    :return: None
    """
    result = split_url("https://www.ansible.com/contributions", query='scheme')
    assert result == 'https'

    result = split_url("https://www.ansible.com/contributions", query='path', alias='urlsplit_test')
    assert result == '/contributions'

    result = split_url("https://www.ansible.com/contributions", query='hostname')
    assert result == 'www.ansible.com'

    result = split_url("https://www.ansible.com/contributions", query='username')
    assert result is None

    result = split_url("https://www.ansible.com/contributions", query='password')
    assert result is None

# Generated at 2022-06-23 10:30:07.778335
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert {'urlsplit': split_url} == module.filters()

# Generated at 2022-06-23 10:30:10.972125
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    filters = filterModule.filters()
    assert len(filters) == 1
    assert 'urlsplit' in filters
    assert type( filters.get('urlsplit') ) == type(split_url)



# Generated at 2022-06-23 10:30:13.674256
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert filters['urlsplit'] == split_url

#
# Unit tests for method split_url of class FilterModule
#

# Generated at 2022-06-23 10:30:14.196143
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert True

# Generated at 2022-06-23 10:30:17.169973
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert isinstance(module, FilterModule, 'Filters are all functions')

    #assert isinstance(module.split_url, function, 'Filters are all functions')



# Generated at 2022-06-23 10:30:28.947470
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.example.com:8080/path/to/app?id=23&debug=true', query='scheme') == 'https'
    assert split_url('https://www.example.com:8080/path/to/app?id=23&debug=true', query='netloc') == 'www.example.com:8080'
    assert split_url('https://www.example.com:8080/path/to/app?id=23&debug=true', query='path') == '/path/to/app'
    assert split_url('https://www.example.com:8080/path/to/app?id=23&debug=true', query='query') == 'id=23&debug=true'

# Generated at 2022-06-23 10:30:29.836464
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert callable(FilterModule.filters)


# Generated at 2022-06-23 10:30:37.817901
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Given:
    module = FilterModule()
    filters = module.filters()

    # When:
    url = "https://www.google.com:80/search?q=foo&tbm=isch"
    urlsplit1 = filters["urlsplit"](url)
    urlsplit2 = filters["urlsplit"](url, "scheme")
    urlsplit3 = filters["urlsplit"](url, "netloc")
    urlsplit4 = filters["urlsplit"](url, "path")
    urlsplit5 = filters["urlsplit"](url, "params")
    urlsplit6 = filters["urlsplit"](url, "query")
    urlsplit7 = filters["urlsplit"](url, "fragment")

# Generated at 2022-06-23 10:30:48.981830
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Test for case where valid query (of FilterModule instance) matches a result dictionary key.
    def test_filter_dict_valid_query():
        test_result = split_url('https://www.example.com/', 'path')
        expected_result = '/'
        assert expected_result == test_result

    # Test for case where valid query (of FilterModule instance) does NOT match a result dictionary key.
    def test_filter_dict_invalid_query():
        try:
            split_url('https://www.example.com/', 'mystery')
        # The desired result is an exception, so this test should not pass if there isn't an exception.
        except AnsibleFilterError:
            pass
        except Exception:
            raise Exception('AnsibleFilterError exception expected, but another exception type was thrown.')

# Generated at 2022-06-23 10:30:49.928746
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    assert x.filters()['urlsplit'] is split_url

# Generated at 2022-06-23 10:30:51.327325
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() == {'urlsplit' : split_url}


# Generated at 2022-06-23 10:31:03.459723
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url("https://github.com/ansible/ansible/issues/13177"), \
        "<SplitResult(scheme='https', netloc='github.com', path='/ansible/ansible/issues/13177', query='', fragment='')>"
    assert split_url("https://github.com/ansible/ansible/issues/13177", "scheme"), \
        "https"
    assert split_url("https://github.com/ansible/ansible/issues/13177", "netloc"), \
        "github.com"
    assert split_url("https://github.com/ansible/ansible/issues/13177", "path"), \
        "/ansible/ansible/issues/13177"

# Generated at 2022-06-23 10:31:04.870194
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule


# Generated at 2022-06-23 10:31:10.928320
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert {'urlsplit': split_url} == FilterModule().filters()


# Generated at 2022-06-23 10:31:12.864209
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule()
    assert filters.filters() == {'urlsplit' : split_url}

# Generated at 2022-06-23 10:31:14.769861
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter = FilterModule()
    assert filter.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:31:15.394839
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:31:17.680796
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()

# Generated at 2022-06-23 10:31:19.279884
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert 'urlsplit' in filters

# Generated at 2022-06-23 10:31:20.624435
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None

# Generated at 2022-06-23 10:31:22.281598
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:31:23.928664
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters() is not None

# Generated at 2022-06-23 10:31:31.062970
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    url_dict = {'scheme': 'https', 'netloc': 'docs.ansible.com', 'path': '',
                'params': '', 'query': '', 'fragment': ''}
    assert fm.filters()['urlsplit']('https://docs.ansible.com') == url_dict
    assert fm.filters()['urlsplit']('https://docs.ansible.com','') == url_dict
    assert fm.filters()['urlsplit']('https://docs.ansible.com', 'scheme') == 'https'
    assert fm.filters()['urlsplit']('https://docs.ansible.com', 'netloc') == 'docs.ansible.com'

# Generated at 2022-06-23 10:31:40.547896
# Unit test for function split_url
def test_split_url():
    url = "http://www.example.com:80/path/to/somefile.html?key1=value1&key2=value2#fragment"
    result = {
        'scheme':   "http",
        'netloc':   "www.example.com:80",
        'path':     "/path/to/somefile.html",
        'params':   "",
        'query':    "key1=value1&key2=value2",
        'fragment': "fragment"
    }
    assert split_url(url) == result

# Generated at 2022-06-23 10:31:47.692228
# Unit test for function split_url
def test_split_url():
    test_string = "http://user:pass@intern.example.org:8042/a/b;c?d=e#f"
    expected_result = {'scheme': 'http', 'query': 'd=e', 'path': '/a/b;c', 'fragment': 'f', 'netloc': 'user:pass@intern.example.org:8042', 'username': 'user', 'password': 'pass', 'hostname': 'intern.example.org', 'port': 8042}
    assert split_url(test_string) == expected_result

# Generated at 2022-06-23 10:31:49.117363
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'urlsplit' in FilterModule().filters()


# Generated at 2022-06-23 10:31:53.991854
# Unit test for function split_url
def test_split_url():
    f = FilterModule()
    filters = f.filters()

    for query in ('', 'scheme', 'netloc', 'path', 'query', 'fragment'):
        result = filters['urlsplit']('http://user:pass@google.com:8080/test?test=test#test', query=query)

        if query:
            assert isinstance(result, str), "split_url() should return a string"
        else:
            assert isinstance(result, dict), "split_url() should return a dictionary"

# Generated at 2022-06-23 10:32:00.983974
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    inp = 'http://127.0.0.1:8080/zabbix/api_jsonrpc.php?output=extend'
    out = {
            'netloc': '127.0.0.1:8080',
            'path': '/zabbix/api_jsonrpc.php',
            'scheme': 'http',
            'query': 'output=extend'
          }
    assert( out == split_url(inp=inp, query=None) )

# Generated at 2022-06-23 10:32:09.115508
# Unit test for function split_url
def test_split_url():
    value = 'http://www.example.com/path/to/resource.html?key1=value1&key2=value2#position1'
    results = dict()

    tests = {
    'scheme': 'http',
    'netloc': 'www.example.com',
    'path': '/path/to/resource.html',
    'query': 'key1=value1&key2=value2',
    'fragment': 'position1'}

    for key, expected in tests.items():
        results = split_url(value, query=key)
        assert results == expected

# Generated at 2022-06-23 10:32:20.994866
# Unit test for method filters of class FilterModule

# Generated at 2022-06-23 10:32:25.250684
# Unit test for constructor of class FilterModule
def test_FilterModule():
    result = FilterModule()
    assert isinstance(result, FilterModule)


# Generated at 2022-06-23 10:32:25.962322
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert True == True

# Generated at 2022-06-23 10:32:34.909616
# Unit test for function split_url
def test_split_url():
    url = 'https://ansible.com/modules/net_tools/uri/filt_plugins/test.py?key=value#fragment'
    _urlsplit = split_url(url)
    assert _urlsplit['scheme'] == 'https'
    assert _urlsplit['netloc'] == 'ansible.com'
    assert _urlsplit['path'] == '/modules/net_tools/uri/filt_plugins/test.py'
    assert _urlsplit['query'] == 'key=value'
    assert _urlsplit['fragment'] == 'fragment'
    assert _urlsplit[''] == ''

    _urlsplit = split_url(url, 'scheme')
    assert _urlsplit == 'https'
    _urlsplit = split_url(url, 'netloc')

# Generated at 2022-06-23 10:32:35.471182
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:32:37.938508
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert obj.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:32:39.696814
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:32:50.127875
# Unit test for function split_url
def test_split_url():
    assert split_url('http://example.com') == {
        'netloc': 'example.com',
        'path': '',
        'query': '',
        'scheme': 'http',
        'fragment': '',
    }

    assert split_url('http://example.com:8080/the/path?the=query#thefragment') == {
        'netloc': 'example.com:8080',
        'path': '/the/path',
        'query': 'the=query',
        'scheme': 'http',
        'fragment': 'thefragment',
    }

    assert split_url('http://example.com', query='netloc') == 'example.com'
    assert split_url('http://example.com', query='query') == ''
    assert split_url

# Generated at 2022-06-23 10:32:51.333171
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:32:52.107820
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:32:54.282483
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:32:56.154015
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    assert x.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:32:57.794148
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
   assert FilterModule().filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:32:59.804676
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'urlsplit' in filter_module.filters()

# Generated at 2022-06-23 10:33:08.846895
# Unit test for function split_url
def test_split_url():
    """
    Check if split_url filter returns the expected results.
    """
    # https://docs.python.org/2/library/urlparse.html
    # urlparse(urlstring, scheme='', allow_fragments=True)
    import types
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    url = urlparse('http://www.cwi.nl:80/%7Eguido/Python.html')
    assert_dict = {'scheme': 'http', 'netloc': 'www.cwi.nl:80', 'path': '/%7Eguido/Python.html', 'params': '', 'query': '', 'fragment': ''}
    # Check if schema, netloc, path, params, query and fragment are present in the actual results dictionary

# Generated at 2022-06-23 10:33:10.493770
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()['urlsplit']


# Generated at 2022-06-23 10:33:20.408365
# Unit test for function split_url
def test_split_url():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import pytest
    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    # Test case 1:
    # Basic request with no query.
    value = 'https://my.cool.site.com/this/is/a/path/'
    assert templar.template(value, play_context) == value
    test_split_url.result = split_url(value)

# Generated at 2022-06-23 10:33:22.176318
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:33:33.665658
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Initialize a FilterModule instance.
    fm = FilterModule()

    # Split the URL.
    actual_results = fm.filters()['urlsplit']('https://www.example.com/api/v1/get/user?name=johndoe')

    # Assert that the URL was split into the expected parts.
    assert actual_results == {
        'path': '/api/v1/get/user',
        'params': '',
        'query': 'name=johndoe',
        'fragment': '',
        'username': '',
        'password': '',
        'hostname': 'www.example.com',
        'port': None,
        'scheme': 'https'
    }


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 10:33:35.177207
# Unit test for constructor of class FilterModule
def test_FilterModule():
    pass

# Generated at 2022-06-23 10:33:45.696150
# Unit test for function split_url
def test_split_url():
    ''' Test function split_url '''
    url = 'http://user:password@www.example.com:8080/path;params?query=arg#fragment'
    result = split_url(url, 'scheme')
    print(result)
    assert result == 'http'
    result = split_url(url, 'username')
    print(result)
    assert result == 'user'
    result = split_url(url, 'password')
    print(result)
    assert result == 'password'
    result = split_url(url, 'hostname')
    print(result)
    assert result == 'www.example.com'
    result = split_url(url, 'port')
    print(result)
    assert result == 8080
    result = split_url(url, 'path')

# Generated at 2022-06-23 10:33:49.729252
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule != None


# Generated at 2022-06-23 10:33:56.269509
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_data = {
        'scheme': 'https',
        'netloc': 'www.example.com',
        'path': '/path/to/location',
        'query': 'option1=1&option2=2&option3=3',
        'fragment': 'fragment1',
    }

    result = FilterModule.filters(None)['urlsplit'](
        '{scheme}://{netloc}{path}?{query}#{fragment}'.format(**test_data), alias='urlsplit'
    )

    for key, value in test_data.items():
        assert key in result
        assert result[key] == value



# Generated at 2022-06-23 10:34:05.939235
# Unit test for function split_url
def test_split_url():
    value = "http://www.example.com/path1/path2/path3?query1=something&query2=anotherthing#fragment"
    results = split_url(value)
    assert results == {'query': 'query1=something&query2=anotherthing',
                       'fragment': 'fragment',
                       'path': '/path1/path2/path3',
                       'scheme': 'http',
                       'netloc': 'www.example.com'}
    assert split_url(value, query='fragment') == "fragment"
    assert split_url(value, query='scheme') == "http"
    assert split_url(value, query='netloc') == "www.example.com"

# Generated at 2022-06-23 10:34:07.818355
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters() is not None



# Generated at 2022-06-23 10:34:08.643981
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-23 10:34:10.332536
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_obj = FilterModule()
    assert(test_obj.filters()['urlsplit'] == split_url)


# Generated at 2022-06-23 10:34:12.411100
# Unit test for constructor of class FilterModule
def test_FilterModule():
    uf = FilterModule()
    assert(uf.filters().get("urlsplit") is not None)


# Generated at 2022-06-23 10:34:23.340953
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()

    test_inputs = {
        'url':            'http://www.example.com/path?key=var',
        'query_scheme':   'scheme',
        'query_netloc':   'netloc',
        'query_path':     'path',
        'query_query':    'query',
        'query_fragment': 'fragment'
    }


# Generated at 2022-06-23 10:34:34.218680
# Unit test for function split_url
def test_split_url():
    from ansible.utils.display import Display
    display = Display()

    # To test your function, run the following code:
    #import sys
    #sys.path.append('/path/to/ansible/module_utils')
    #from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network.f5 import f5_uri
    #results = f5_uri.split_url('https://uri.f5.com/foo/bar/baz?first=query')
    #print('results: %s' % results)


# Generated at 2022-06-23 10:34:38.377388
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:34:50.556189
# Unit test for function split_url
def test_split_url():

    from ansible.module_utils.six.moves.urllib.parse import urlunsplit

    test_url = "scheme://netloc/path;parameters?query=arg#fragment"

    # Test combo lookup
    assert split_url(test_url, 'scheme') == 'scheme'
    assert split_url(test_url, 'netloc') == 'netloc'
    assert split_url(test_url, 'path') == 'path'
    assert split_url(test_url, 'parameters') == 'parameters'
    assert split_url(test_url, 'query') == 'arg'
    assert split_url(test_url, 'fragment') == 'fragment'

    # Test function with no options

# Generated at 2022-06-23 10:34:52.887841
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Unit test for the FilterModule constructor. '''
    filters = FilterModule()
    assert filters.filters() is not None
    assert filters.filters().get('urlsplit') is not None


# Generated at 2022-06-23 10:35:03.764963
# Unit test for function split_url
def test_split_url():
    assert {
        'scheme': 'http',
        'netloc': 'www.ansible.com',
        'path': '/',
        'query': 'this=that',
        'fragment': 'here'
    } == split_url('http://www.ansible.com/?this=that#here')
    assert 'www.ansible.com' == split_url('http://www.ansible.com/?this=that#here', 'netloc')
    assert None == split_url('http://www.ansible.com/?this=that#here', 'foo')
    assert 'not-a-url' == split_url('not-a-url', query='scheme')
    assert 'not-a-url' == split_url('not-a-url', query='foo')

# Generated at 2022-06-23 10:35:08.329569
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # create a dummy object from class FilterModule
    obj  = FilterModule()

    # call method filters() on class FilterModule
    filters = obj.filters()

    # assert return value of method filters()
    assert filters == {"urlsplit": split_url}



# Generated at 2022-06-23 10:35:12.016391
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
	f = FilterModule()
	url = 'https://www.google.com/search?q=ansible&ie=utf-8&oe=utf-8'
	assert 'google.com' in f.filters()['urlsplit'](url, 'netloc')


# Generated at 2022-06-23 10:35:13.569305
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert obj.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:35:20.180491
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import urllib
    import urlparse
    fm = FilterModule()
    assert fm.filters()['urlsplit']('http://user:pass@localhost:8080/path/to/file?query#fragment') == dict([(i, getattr(urlparse.urlsplit('http://user:pass@localhost:8080/path/to/file?query#fragment'), i)) for i in dir(urlparse.SplitResult) if i[0] != '_'])

# Generated at 2022-06-23 10:35:22.821305
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urlsplit' in filters


# Generated at 2022-06-23 10:35:25.668919
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    result = fm.filters() # This should return { 'urlsplit': split_url } to pass the test!


# Generated at 2022-06-23 10:35:26.472385
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert(FilterModule().filters() == {'urlsplit': split_url})

# Generated at 2022-06-23 10:35:37.871908
# Unit test for function split_url

# Generated at 2022-06-23 10:35:41.275193
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    answer = f.filters()
    assert answer.has_key('urlsplit')
    assert answer['urlsplit'] == split_url

if __name__ == '__main__':
    test_FilterModule()

# Generated at 2022-06-23 10:35:53.531398
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert split_url("/test/test.jpg")["path"] == "/test/test.jpg"
    assert split_url("/test/test.jpg", "path") == "/test/test.jpg"
    assert split_url("http://www.example.com/path/")["scheme"] == "http"
    assert split_url("http://www.example.com/path/", "scheme") == "http"
    assert split_url("https://user:pass@www.example.com/path/")["netloc"] == "user:pass@www.example.com"
    assert split_url("https://user:pass@www.example.com/path/", "netloc") == "user:pass@www.example.com"

# Generated at 2022-06-23 10:36:03.901211
# Unit test for function split_url
def test_split_url():

    test_url = "http://example.com/path/to/file;param?query=arg#frag"

    # Test aliases
    assert split_url(test_url, 'scheme') == 'http'
    assert split_url(test_url, 'hostname') == 'example.com'
    assert split_url(test_url, 'path') == '/path/to/file;param'
    assert split_url(test_url, 'query') == 'query=arg'
    assert split_url(test_url, 'fragment') == 'frag'

    # Test whole dictionary

# Generated at 2022-06-23 10:36:13.454231
# Unit test for function split_url
def test_split_url():
    from ansible import errors
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.plugins.filter.urlsplit import split_url

    class TestSplitUrl(unittest.TestCase):

        def test_urlsplit_query(self):
            url = 'http://www.example.com/foo/bar?key0=value0&key1=value1'
            result = split_url(url, 'scheme')
            self.assertEqual(result, 'http')

        def test_urlsplit_query_fail(self):
            url = 'http://www.example.com/foo/bar?key0=value0&key1=value1'