

# Generated at 2022-06-23 10:26:19.798085
# Unit test for function split_url
def test_split_url():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager

    split = FilterModule().filters()['urlsplit']

    my_dict = {
        'foo': 'bar',
        'baz': 'qux',
        'corge': 'grault'
    }

    my_play_context = object.__new__(PlayContext)
    my_play_context.hostvars = my_dict

    my_variable_manager = object.__new__(VariableManager)
    my_variable_manager._hostvars = my_dict
    my_variable_manager._fact_cache = my_dict


# Generated at 2022-06-23 10:26:32.737638
# Unit test for function split_url
def test_split_url():
    """urlsplit test cases"""

    url = 'https://www.python.org/static/img/python-logo.png'
    res = split_url(url)
    assert res['scheme'] == 'https'
    assert res['netloc'] == 'www.python.org'
    assert res['path'] == '/static/img/python-logo.png'
    assert res['port'] is None
    assert res['query'] == ''
    assert res['params'] == ''
    assert res['fragment'] == ''
    assert res['username'] is None
    assert res['password'] is None
    assert res['hostname'] == 'www.python.org'

    res = split_url(url, 'scheme')
    assert res == 'https'


# Generated at 2022-06-23 10:26:38.619397
# Unit test for function split_url
def test_split_url():
  # Init
  filter_module = FilterModule()
  test_args = {}

  # Test: no URL
  assert filter_module.filters()['urlsplit']('') == {'scheme': '', 'netloc': '', 'path': '', 'params': '', 'query': '', 'fragment': ''}

  # Test: no query
  test_args = {'query': ''}
  assert filter_module.filters()['urlsplit']('/path/to/file', **test_args) == {'scheme': '', 'netloc': '', 'path': '/path/to/file', 'params': '', 'query': '', 'fragment': ''}

  # Test: no query, different path
  test_args = {'query': ''}

# Generated at 2022-06-23 10:26:44.837007
# Unit test for function split_url
def test_split_url():
    url = 'http://user:pass@localhost:8080/path;parameter?key=value#fragment'
    query_params = {'key': 'value'}

# Generated at 2022-06-23 10:26:48.801228
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj

# Generated at 2022-06-23 10:26:59.229047
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    f = FilterModule()
    assert 'urlsplit' == f.filters().keys()[0]
    a = f.filters()['urlsplit']
    assert 'scheme' == a('http://www.example.com', 'scheme')
    assert 'netloc' == a('http://www.example.com', 'netloc')
    assert 'path' == a('http://www.example.com', 'path')
    assert 'query' == a('http://www.example.com', 'query')
    assert 'fragment' == a('http://www.example.com', 'fragment')

    # Test that passing invalid query will throw exception

# Generated at 2022-06-23 10:27:05.559518
# Unit test for function split_url
def test_split_url():
    assert split_url('http://ansible.com/') == {'fragment': '',
                                                'hostname': 'ansible.com',
                                                'netloc': 'ansible.com',
                                                'params': '',
                                                'password': '',
                                                'path': '/',
                                                'port': None,
                                                'query': '',
                                                'scheme': 'http',
                                                'username': ''}


# Generated at 2022-06-23 10:27:07.753434
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    
    assert filter_module.filters() == {'urlsplit': split_url}
# ---- End unit test ----

# Generated at 2022-06-23 10:27:09.920240
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule()
    assert filters.filters() == {'urlsplit': split_url}, 'urlsplit filter not found'


# Generated at 2022-06-23 10:27:11.479425
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule


# Generated at 2022-06-23 10:27:13.578367
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    assert x.filters() == {"urlsplit": split_url}


# Generated at 2022-06-23 10:27:22.733424
# Unit test for function split_url

# Generated at 2022-06-23 10:27:27.826804
# Unit test for function split_url
def test_split_url():
    value = "http://username:password@subdomain.domain.com:8000/wiki/index.php?title=Page_title&action=history"
    expected = {
        'scheme': 'http',
        'netloc': 'username:password@subdomain.domain.com:8000',
        'path': '/wiki/index.php',
        'params': '',
        'query': 'title=Page_title&action=history',
        'fragment': ''
        }
    for key in expected:
        assert (expected[key] == split_url(value, key))

# Generated at 2022-06-23 10:27:37.977196
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('foo', 'scheme') == 'foo'
    assert split_url('foo://bar', 'netloc') == 'bar'
    assert split_url('foo://bar/baz/spam', 'path') == '/baz/spam'
    assert split_url('foo://bar/baz/spam?eggs=ham', 'query') == 'eggs=ham'
    assert split_url('foo://bar/baz/spam?eggs=ham', 'fragment') == ''
    assert split_url('foo://bar', 'scheme') == 'foo'
    assert split_url('foo://bar', 'netloc') == 'bar'
    assert split_url('foo:bar', 'scheme') == 'foo'
    assert split_url('foo:bar', 'path') == 'bar'

# Generated at 2022-06-23 10:27:40.502859
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    fm.filters()

# Generated at 2022-06-23 10:27:42.257353
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:27:44.292402
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    split_url("http://docs.ansible.com/ansible/latest/intro_configuration.html#id36", "path")



# Generated at 2022-06-23 10:27:51.634413
# Unit test for function split_url
def test_split_url():

    # Test valid URLs
    assert split_url('http://www.google.com')['netloc'] == 'www.google.com'
    assert split_url('foo:bar:baz', query='scheme') == 'foo'
    assert split_url('http://localhost:8080/some/path?some=query#some_fragment') == {'scheme': 'http', 'netloc': 'localhost:8080', 'path': '/some/path', 'query': 'some=query', 'fragment': 'some_fragment'}
    assert split_url('http://localhost:8080/some/path?some=query#some_fragment', query='scheme') == 'http'

    # Test invalid URLs

# Generated at 2022-06-23 10:27:52.873689
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter = FilterModule()
    assert 'urlsplit' in filter.filters().keys()

# Generated at 2022-06-23 10:27:59.887142
# Unit test for function split_url
def test_split_url():
    print('Testing uri filters:')
    assert split_url('https://github.com/ansible/ansible/tree/devel/lib/ansible/plugins/filter') == 'https://github.com/ansible/ansible/tree/devel/lib/ansible/plugins/filter', 'urlsplit failed'
    assert split_url('https://github.com/ansible/ansible/tree/devel/lib/ansible/plugins/filter', 'scheme') == 'https', 'urlsplit failed to return scheme'
    assert split_url('https://github.com/ansible/ansible/tree/devel/lib/ansible/plugins/filter', 'netloc') == 'github.com', 'urlsplit failed to return netloc'

# Generated at 2022-06-23 10:28:09.250005
# Unit test for function split_url
def test_split_url():

    # Setup
    value = 'http://user:pass@www.example.com:8000/resource/foo?query=123#fragment'
    # Should be the same results because default 'query' value is used.
    result_fragment = split_url(value, 'fragment')
    result_params = split_url(value, 'params')
    result_query = split_url(value, 'query')
    result_netloc = split_url(value, 'netloc')
    result_path = split_url(value, 'path')
    result_scheme = split_url(value, 'scheme')
    result_username = split_url(value, 'username')
    result_password = split_url(value, 'password')
    result_hostname = split_url(value, 'hostname')
    result

# Generated at 2022-06-23 10:28:11.497912
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()


# Generated at 2022-06-23 10:28:14.053067
# Unit test for function split_url
def test_split_url():
  '''
  Test for urlsplit
  '''
  # Make sure we can access the filter splitsap URL
  assert split_url("http://192.168.1.1/foo/bar") is not None

# Generated at 2022-06-23 10:28:16.108001
# Unit test for constructor of class FilterModule
def test_FilterModule():
    init_FilterModule = FilterModule()
    print(init_FilterModule)


# Generated at 2022-06-23 10:28:17.510198
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:28:23.785556
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert hasattr(FilterModule, 'filters')
    assert callable(getattr(FilterModule, 'filters'))

if __name__ == '__main__':
    # Unit test for method Query_to_dict of class Query
    def test_Query_to_dict():
        from six.moves.urllib.parse import parse_qs
        from six.moves.urllib.parse import unquote
        query_string = 'action=view&xml=true'
        query = Query(query_string)
        expected = parse_qs(query_string)
        expected = {k: unquote(v[0]) for k, v in expected.items()}
        assert query.to_dict() == expected

    # Unit test for method Query_to_dict of class Query

# Generated at 2022-06-23 10:28:24.608924
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert callable(FilterModule().filters()['urlsplit'])

# Generated at 2022-06-23 10:28:28.165348
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for method filters of class FilterModule '''
    fm = FilterModule()
    filtered = fm.filters()

    assert 'urlsplit' in filtered


# ---- Ansible filters ----

# Generated at 2022-06-23 10:28:36.198217
# Unit test for function split_url
def test_split_url():
    import pytest
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from . import uri


# Generated at 2022-06-23 10:28:39.432236
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters() == dict(urlsplit=split_url)



# Generated at 2022-06-23 10:28:40.973739
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    uri = FilterModule()
    assert uri.filters().get('urlsplit')

# Generated at 2022-06-23 10:28:46.630004
# Unit test for function split_url
def test_split_url():
    url = "http://www.example.com:8080/path/to/file?query=string&param2=stuff"
    res = split_url(url)

    assert res['netloc'] == 'www.example.com:8080'
    assert res['scheme'] == 'http'
    assert res['path'] == '/path/to/file'
    assert res['query'] == 'query=string&param2=stuff'

# Generated at 2022-06-23 10:28:55.822267
# Unit test for function split_url
def test_split_url():
    results = split_url('http://www.example.com/foo/bar')
    assert results.scheme == 'http'
    assert results.netloc == 'www.example.com'
    assert results.path == '/foo/bar'

    results = split_url('http://www.example.com/foo/bar', query='scheme')
    assert results == 'http'

    results = split_url('http://www.example.com/foo/bar', query='netloc')
    assert results == 'www.example.com'

    results = split_url('http://www.example.com/foo/bar', query='path')
    assert results == '/foo/bar'

    results = split_url('http://www.example.com/foo/bar', query='path', alias='archive')
    assert results == '/foo/bar'

# Generated at 2022-06-23 10:28:57.044854
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert True

# Generated at 2022-06-23 10:28:58.446617
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule  # avoid warning from pyflakes

# Generated at 2022-06-23 10:29:01.844987
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    FilterModule.filters = lambda self: {'split_url': split_url}
    fm = FilterModule()
    assert fm.filters() is not None



# Generated at 2022-06-23 10:29:11.325679
# Unit test for function split_url
def test_split_url():
    query = 'query'


# Generated at 2022-06-23 10:29:12.182060
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-23 10:29:13.580488
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:29:17.194775
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, "filters")

# Generated at 2022-06-23 10:29:19.020690
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:29:21.917683
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter = FilterModule()
    assert filter.filters() == {
        'urlsplit': split_url
    }
# ---- Unit tests ----


# Generated at 2022-06-23 10:29:34.394833
# Unit test for function split_url

# Generated at 2022-06-23 10:29:39.176535
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # This function tests whether the FilterModule class, responsible for
    # loading the filters and naming them, is instantiated correctly.
    # This test is not part of the unit tests shipped with ansible, but
    # created by the developer to ensure that her code is doing what it's
    # supposed to do.
    module = FilterModule()
    assert(len(module.filters()) == 1)
    assert('urlsplit' in module.filters())


# Generated at 2022-06-23 10:29:40.669938
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:29:42.844812
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj.filters() is not None

# Generated at 2022-06-23 10:29:44.555155
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert isinstance(obj.filters(), dict)



# Generated at 2022-06-23 10:29:54.260395
# Unit test for function split_url
def test_split_url():
    assert split_url('http://127.0.0.1/path?query#fragment') == {
        'hostname': u'127.0.0.1',
        'scheme': u'http',
        'netloc': u'127.0.0.1',
        'path': u'/path',
        'query': u'query',
        'fragment': u'fragment',
    }
    assert split_url('http://127.0.0.1/path?query#fragment', query='path') == u'/path'
    try:
        split_url('http://127.0.0.1/path?query#fragment', query='invalid')
        assert False, 'Expected error, got %s' % result
    except AnsibleFilterError as e:
        assert str

# Generated at 2022-06-23 10:30:00.603838
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert isinstance(fm, FilterModule)
    assert hasattr(fm, 'filters')
    assert fm.filters() is not None
    assert len(fm.filters()) == 1
    (fname, f) = fm.filters().popitem()
    assert fname == 'urlsplit'
    assert f is not None
    assert f == split_url


# Generated at 2022-06-23 10:30:03.194730
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.utils import plugin_docs
    return_value = plugin_docs.get_filter_docs()
    assert(return_value['urlsplit'] == 'returns a dictionary of the parts of a url')

# ---- Ansible tests ----

# Generated at 2022-06-23 10:30:14.193280
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filter_module = FilterModule()

    # Test case for method filters()
    def test_filter_urlsplit(url, query, expected):
        urlsplit_result = filter_module.filters()['urlsplit'](url, query)
        assert urlsplit_result == expected
        return True

    url = 'http://myuser:mypassword@somepage.com:55/mypage.html?myarg=myvalue#myanchor'
    q = ''
    e = {'scheme': 'http', 'netloc': 'myuser:mypassword@somepage.com:55', 'path': '/mypage.html', 'query': 'myarg=myvalue', 'fragment': 'myanchor'}
    yield test_filter_urlsplit, url, q, e

    q = 'scheme'
    e

# Generated at 2022-06-23 10:30:19.184531
# Unit test for constructor of class FilterModule
def test_FilterModule():
    url_filter1 = FilterModule()
    url_filter2 = FilterModule()

    # Print the object id to check if they are different objects
    print(id(url_filter1))
    print(id(url_filter2))

    # Check if the objects are same
    if url_filter1 is url_filter2:
        print("Both objects are same")
    else:
        print("Objects are different")



# Generated at 2022-06-23 10:30:31.044800
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import unittest

    class TestFilterModule(unittest.TestCase):
        def setUp(self):
            self.e = FilterModule()

        def test_urlsplit(self):
            #url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
            url = "https://www.google.com/search?client=ubuntu&channel=fs&q=define+happiness&ie=utf-8&oe=utf-8"

# Generated at 2022-06-23 10:30:32.005781
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:30:42.067592
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('http://www.yahoo.com/search?q=foo&l=bar') == {
        'netloc': 'www.yahoo.com', 'query': 'q=foo&l=bar', 'scheme': 'http', 'path': '/search', 'fragment': '', 'username': '', 'password': '', 'hostname': 'www.yahoo.com', 'port': None, 'params': ''
    }
    assert split_url('http://www.yahoo.com/search?q=foo&l=bar', 'query') == 'q=foo&l=bar'

# vim: set et ts=4 sw=4 sts=4 tw=80

# Generated at 2022-06-23 10:30:42.889325
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()

# Generated at 2022-06-23 10:30:48.884069
# Unit test for function split_url
def test_split_url():
    ''' Unit test that confirms the function works as expected. '''

    # Setup a test URL
    test_url = 'http://www.example.com:1234/path/to/file.html?x=y#fragment'
    result = split_url(test_url)
    expected = {
        'scheme': 'http',
        'netloc': 'www.example.com:1234',
        'path': '/path/to/file.html',
        'query': 'x=y',
        'fragment': 'fragment',
    }
    assert result == expected

    # Make sure we can retrieve specific components when requested.
    # Put the parts into a dictionary for easy reference in the test.
    parts = dict(expected)
    for query, answer in iter(parts.items()):
        assert split_

# Generated at 2022-06-23 10:30:49.587762
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)


# Generated at 2022-06-23 10:30:54.738499
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.example.com/path/to/page?query=value#frag') == {
        'fragment': 'frag',
        'netloc': 'www.example.com',
        'path': '/path/to/page',
        'query': 'query=value',
        'scheme': 'https',
    }

# Generated at 2022-06-23 10:30:55.358662
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:31:06.425332
# Unit test for function split_url
def test_split_url():
    test_url = 'http://username:password@example.com:8080/path/to/file?foo=bar#xyz'
    valid_parts = {
        'urlsplit': 'http://username:password@example.com:8080/path/to/file?foo=bar#xyz',
        'scheme': 'http',
        'netloc': 'username:password@example.com:8080',
        'path': '/path/to/file',
        'query': 'foo=bar',
        'fragment': 'xyz',
        'username': 'username',
        'password': 'password',
        'hostname': 'example.com',
        'port': 8080
    }

    # Test valid results
    for result in valid_parts:
        assert split_url(test_url, query=result)

# Generated at 2022-06-23 10:31:13.931232
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test that each method of the FilterModule class
    # is a function
    module = FilterModule()
    for attr in dir(module):
        if callable(getattr(module, attr)):
            assert(hasattr(getattr(module, attr), '__call__'))

# Generated at 2022-06-23 10:31:23.334865
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?arg=value#frag', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?arg=value#frag', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?arg=value#frag', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?arg=value#frag', 'query') == 'arg=value'
    assert split_url('http://www.example.com/path/to/file?arg=value#frag', 'fragment') == 'frag'

# Generated at 2022-06-23 10:31:24.225655
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f

# Generated at 2022-06-23 10:31:25.792523
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'urlsplit': split_url}



# Generated at 2022-06-23 10:31:28.255209
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Unit test for the constructor of class FilterModule '''
    fm = FilterModule()
    assert fm

# Generated at 2022-06-23 10:31:34.643904
# Unit test for function split_url
def test_split_url():
    url = 'https://example.com/path/to/a/file.php?search=ansible'
    result = split_url(url)
    assert result['scheme'] == 'https'
    assert result['netloc'] == 'example.com'
    assert result['path'] == '/path/to/a/file.php'
    assert result['query'] == 'search=ansible'
    assert result['fragment'] == ''

    result = split_url(url, 'query')
    assert result == 'search=ansible'

    result = split_url(url, query='path')
    assert result == '/path/to/a/file.php'

# Generated at 2022-06-23 10:31:37.357384
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:31:39.542113
# Unit test for constructor of class FilterModule
def test_FilterModule():
    a = FilterModule()
    assert a.filters() is not None, "return value of filters method is null"


# Generated at 2022-06-23 10:31:41.275018
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
        'urlsplit': split_url
    }

# Generated at 2022-06-23 10:31:42.539664
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:31:52.880668
# Unit test for function split_url

# Generated at 2022-06-23 10:31:57.686767
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert len(f.filters()) == 1
    for funcname in ('urlsplit'):
        assert funcname in f.filters()
        assert callable(f.filters()[funcname])


# Generated at 2022-06-23 10:32:06.419463
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.ansible.com/') == {'netloc': 'www.ansible.com', 'scheme': 'https', 'path': '', 'qs': '', 'fragment': ''}
    assert split_url('https://www.ansible.com/', 'netloc') == 'www.ansible.com'
    assert split_url('https://www.ansible.com/', 'scheme') == 'https'
    assert split_url('https://www.ansible.com/', 'path') == ''
    assert split_url('https://www.ansible.com/', 'qs') == ''
    assert split_url('https://www.ansible.com/', 'fragment') == ''

# Generated at 2022-06-23 10:32:08.349100
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # test basic singleton
    f = FilterModule()
    f2 = FilterModule()
    assert f == f2
    assert id(f) == id(f2)

# Generated at 2022-06-23 10:32:13.836337
# Unit test for function split_url
def test_split_url():
    # This is only testing the FiltersModule class and split_url function because
    # the urlsplit function is used to perform the manipulation.  The urlsplit
    # function is used from the Python standard libraries and has been tested
    # by Python developers. No need to re-test.
    fm = FilterModule()
    url_dict = fm.filters()['urlsplit']('http://www.example.com/path1/path2')
    assert url_dict['scheme'] == 'http'
    assert url_dict['netloc'] == 'www.example.com'
    assert url_dict['path'] == '/path1/path2'
    assert url_dict['query'] == ''
    assert url_dict['fragment'] == ''

# Generated at 2022-06-23 10:32:23.063418
# Unit test for function split_url
def test_split_url():
    url = 'http://user:pass@www.example.com:8080/foo/bar.html?one=1&two=2#TOP'
    assert split_url(url, query='scheme') == 'http'
    assert split_url(url, query='scheme') == 'http'
    assert split_url(url, query='netloc') == 'user:pass@www.example.com:8080'
    assert split_url(url, query='path') == '/foo/bar.html'
    assert split_url(url, query='query') == 'one=1&two=2'
    assert split_url(url, query='fragment') == 'TOP'
    assert split_url(url, query='hostname') == 'www.example.com'

# Generated at 2022-06-23 10:32:25.731820
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-23 10:32:28.619594
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters is not None
    assert 'urlsplit' in filters

# Generated at 2022-06-23 10:32:35.079498
# Unit test for constructor of class FilterModule
def test_FilterModule():
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    
    url = 'http://www.ansible.com/index.html'
    url_split = urlparse(url)
    url_split_dict = {'fragment': '',
     'netloc': 'www.ansible.com',
     'path': '/index.html',
     'query': '',
     'scheme': 'http'}
    f = FilterModule()
    assert f.filters()['urlsplit'](url) == url_split_dict
    assert f.filters()['urlsplit'](url,'scheme') == 'http'

# Generated at 2022-06-23 10:32:37.458741
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:32:39.339358
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert 'urlsplit' in filters

# Generated at 2022-06-23 10:32:42.193153
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urlsplit' in filters


# Generated at 2022-06-23 10:32:51.656341
# Unit test for function split_url
def test_split_url():
    URL = 'https://www.example.com/api/v1/fizz?buzz=foo'
    SCHEME = 'https'
    NETLOC = 'www.example.com'
    PATH = 'api/v1/fizz'
    QUERY = 'buzz=foo'
    FRAGMENT = ''
    PARAMS = ''

    assert split_url(URL)['scheme'] == SCHEME
    assert split_url(URL)['netloc'] == NETLOC
    assert split_url(URL)['path'] == PATH
    assert split_url(URL)['query'] == QUERY
    assert split_url(URL)['fragment'] == FRAGMENT
    assert split_url(URL)['params'] == PARAMS
    assert split_url(URL, query='scheme') == SCHEME

# Generated at 2022-06-23 10:32:54.238227
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    result = filter_module.filters()
    assert result == {'urlsplit': split_url}

# Generated at 2022-06-23 10:33:05.690028
# Unit test for function split_url
def test_split_url():
    test_result = []
    test_result.append("scheme='https', netloc='www.example.com', path='/path/to/ansible', query='', fragment=''")
    test_result.append("https")
    test_result.append("www.example.com")
    test_result.append("/path/to/ansible")
    test_result.append("")
    test_result.append("")

    url = "https://www.example.com/path/to/ansible"
    test = split_url(url)
    assert str(test) == test_result[0]

    test = split_url(url, 'scheme')
    assert test == test_result[1]

    test = split_url(url, 'netloc')
    assert test == test_result[2]

   

# Generated at 2022-06-23 10:33:07.030937
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None

# Generated at 2022-06-23 10:33:17.735942
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Fixture data that is replaced in the test case
    urlsplit_url = None
    urlsplit_query = None
    urlsplit_alias = None

    class Mock_urlsplit():
        def __init__(self, url):
            self.url = url

        @property
        def scheme(self):
            return 'scheme'

        @property
        def netloc(self):
            return 'netloc'

        @property
        def path(self):
            return 'path'

        @property
        def query(self):
            return 'query'

        @property
        def fragment(self):
            return 'fragment'

    def mock_helpers_object_to_dict_valid_query(obj, exclude=None):
        return {'query': 'query'}


# Generated at 2022-06-23 10:33:25.576489
# Unit test for function split_url
def test_split_url():
    result = split_url('http://ansible.com/test/test.txt')
    assert result['scheme'] == 'http', 'Schema is not http.'
    assert result['netloc'] == 'ansible.com', 'Netloc is not ansible.com.'
    assert result['path'] == '/test/test.txt', 'Path is not /test/test.txt.'

    assert split_url('http://ansible.com/test/test.txt', 'scheme') == 'http', 'Schema is not http.'
    assert split_url('http://ansible.com/test/test.txt', 'netloc') == 'ansible.com', 'Netloc is not ansible.com.'

# Generated at 2022-06-23 10:33:35.878216
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('http://docs.ansible.com/ansible/latest/modules/shell_module.html') == {'path': '/ansible/latest/modules/shell_module.html', 'fragment': '', 'scheme': 'http', 'hostname': 'docs.ansible.com', 'query': '', 'netloc': 'docs.ansible.com', 'username': '', 'password': '', 'port': None}
    assert split_url('http://docs.ansible.com/ansible/latest/modules/shell_module.html', 'fragment') == ''
    assert split_url('http://docs.ansible.com/ansible/latest/modules/shell_module.html', 'port') == None

# Generated at 2022-06-23 10:33:38.187316
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule) == {'urlsplit': split_url}


# Generated at 2022-06-23 10:33:40.152947
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    f.filters()

# Generated at 2022-06-23 10:33:41.886454
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:33:43.274883
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)


# Generated at 2022-06-23 10:33:46.143534
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """ returns the filter function named 'urlsplit' """
    fm = FilterModule()
    url_filter = fm.filters()['urlsplit']
    assert url_filter is not None


# ---- Unit tests ----

# Generated at 2022-06-23 10:33:52.510354
# Unit test for function split_url
def test_split_url():
    url = 'https://username:password@www.example.com:80/path/to/file;parameters?query=argument#fragment'

    assert split_url(url, query='scheme') == 'https'
    assert split_url(url, query='netloc') == 'username:password@www.example.com:80'
    assert split_url(url, query='path') == '/path/to/file;parameters'
    assert split_url(url, query='query') == 'query=argument'
    assert split_url(url, query='fragment') == 'fragment'

    assert split_url(url)['scheme'] == 'https'
    assert split_url(url)['netloc'] == 'username:password@www.example.com:80'

# Generated at 2022-06-23 10:34:03.521141
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    # netloc
    assert f.filters()['urlsplit']("http://docs.ansible.com/ansible/latest/modules/uri_module.html", 'netloc') == "docs.ansible.com"
    assert f.filters()['urlsplit']("http://docs.ansible.com/ansible/latest/modules/uri_module.html", 'hostname') == "docs.ansible.com"
    # path
    assert f.filters()['urlsplit']("http://docs.ansible.com/ansible/latest/modules/uri_module.html", 'path') == "/ansible/latest/modules/uri_module.html"
    # query

# Generated at 2022-06-23 10:34:12.262278
# Unit test for function split_url
def test_split_url():
    assert split_url('http://127.0.0.1:8080/v1/foo/bar/baz', 'hostname') == '127.0.0.1'
    assert split_url('http://127.0.0.1:8080/v1/foo/bar/baz', 'path') == '/v1/foo/bar/baz'
    assert split_url('http://127.0.0.1:8080/v1/foo/bar/baz', 'foo') == ''
    assert split_url('http://127.0.0.1:8080/v1/foo/bar/baz', 'port') == '8080'
    assert split_url('http://127.0.0.1:8080/v1/foo/bar/baz', 'query') == ''

# Generated at 2022-06-23 10:34:14.954461
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter = FilterModule()
    assert filter.filters()["urlsplit"] == split_url


# Generated at 2022-06-23 10:34:16.128345
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module.filters()['urlsplit'] is split_url

# Generated at 2022-06-23 10:34:17.590154
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance( FilterModule(), FilterModule )


# Generated at 2022-06-23 10:34:18.410851
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:34:25.115956
# Unit test for constructor of class FilterModule
def test_FilterModule():
    split_url_object = split_url(value='https://api.github.com/repos/ansible/ansible/issues?state=open&sort=updated',
                                 query='', alias='urlsplit')

    assert split_url_object['scheme'] == 'https'
    assert split_url_object['netloc'] == 'api.github.com'
    assert split_url_object['path'] == '/repos/ansible/ansible/issues'
    assert split_url_object['query'] == 'state=open&sort=updated'
    assert split_url_object['fragment'] == ''

# Generated at 2022-06-23 10:34:27.772897
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert 'urlsplit' in filters


# Generated at 2022-06-23 10:34:33.168844
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''Test for FilterModule.filters which returns a dictionary of filters'''
    test_filter_module = FilterModule()
    filters = test_filter_module.filters()
    assert isinstance(filters, dict), \
        "FilterModule.filters should return a dictionary of filters"
    assert len(filters) > 0, \
        "FilterModule.filters should return a dictionary of filters with at least one filter"


# Generated at 2022-06-23 10:34:37.259546
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule) == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:34:42.610457
# Unit test for constructor of class FilterModule
def test_FilterModule():

    uri_module = FilterModule()
    assert uri_module.filters() == { 'urlsplit' : split_url }


# Generated at 2022-06-23 10:34:44.421298
# Unit test for constructor of class FilterModule
def test_FilterModule():
  module = FilterModule()
  assert(len(module.filters()) > 0)

# Generated at 2022-06-23 10:34:52.524549
# Unit test for function split_url
def test_split_url():
    assert split_url('http://stackoverflow.com/questions/9733638/get-domain-name-from-url')['netloc'] == 'stackoverflow.com'
    assert split_url('http://stackoverflow.com/questions/9733638/get-domain-name-from-url', 'netloc') == 'stackoverflow.com'
    assert split_url('http://stackoverflow.com/questions/9733638/get-domain-name-from-url', 'scheme') == 'http'
    assert split_url('http://stackoverflow.com/questions/9733638/get-domain-name-from-url', 'path') == '/questions/9733638/get-domain-name-from-url'

# Generated at 2022-06-23 10:34:53.158024
# Unit test for constructor of class FilterModule
def test_FilterModule():
    return None



# Generated at 2022-06-23 10:34:53.961073
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:34:55.031548
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module


# Generated at 2022-06-23 10:34:56.395189
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'urlsplit' in FilterModule().filters()


# Generated at 2022-06-23 10:34:58.296366
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)


# Generated at 2022-06-23 10:34:59.171105
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() is not None



# Generated at 2022-06-23 10:35:05.313296
# Unit test for function split_url
def test_split_url():
    assert split_url('http://example.com/foo/bar')['netloc'] == 'example.com'
    assert split_url('http://example.com/foo/bar')['path'] == '/foo/bar'
    assert split_url('http://example.com/foo/bar', query='scheme') == 'http'
    assert split_url('http://example.com/foo/bar')['fragment'] == ''

# Generated at 2022-06-23 10:35:14.904351
# Unit test for function split_url
def test_split_url():
    # Given
    given_url = 'https://s3-us-west-2.amazonaws.com/my-bucket/my-file.txt'
    # When
    split_url_dict = split_url(given_url)
    # Then
    assert type(split_url_dict) == dict
    assert split_url_dict['scheme'] == 'https'
    assert split_url_dict['netloc'] == 's3-us-west-2.amazonaws.com'
    assert split_url_dict['path'] == '/my-bucket/my-file.txt'
    assert split_url_dict['query'] == ''
    assert split_url_dict['fragment'] == ''
    assert split_url(given_url, query='scheme') == 'https'

# Generated at 2022-06-23 10:35:26.444217
# Unit test for function split_url
def test_split_url():
    test_url = 'http://user:pass@127.0.0.1:5080/path?query=string#fragment'
    expected_dict = {'fragment': 'fragment',
                     'netloc': 'user:pass@127.0.0.1:5080',
                     'path': '/path',
                     'query': 'query=string',
                     'scheme': 'http'}
    assert split_url(test_url) == expected_dict
    assert split_url(test_url, query='fragment') == 'fragment'
    assert split_url(test_url, query='netloc') == 'user:pass@127.0.0.1:5080'
    assert split_url(test_url, query='path') == '/path'

# Generated at 2022-06-23 10:35:31.179919
# Unit test for function split_url
def test_split_url():
    url = 'http://www.example.com:80/path?key=value'
    tests = {
        'scheme': 'http',
        'netloc': 'www.example.com:80',
        'path': '/path',
        'query': 'key=value',
        'fragment': '',
    }
    for test in tests:
        assert tests[test] == split_url(url, alias="test_split_url", query=test)

# Generated at 2022-06-23 10:35:41.564860
# Unit test for function split_url
def test_split_url():
    url = "https://www.google.com/search?q=ansible+dictionary+filter&oq=ansible+dictionary+filter&aqs=chrome..69i57j69i60j0l5.5123j0j4&sourceid=chrome&ie=UTF-8"
    results = split_url(url)
    assert results['scheme'] == 'https'
    assert results['netloc'] == 'www.google.com'
    assert results['path'] == '/search'
    assert results['params'] == ''
    assert results['query'] == 'q=ansible+dictionary+filter&oq=ansible+dictionary+filter&aqs=chrome..69i57j69i60j0l5.5123j0j4&sourceid=chrome&ie=UTF-8'

# Generated at 2022-06-23 10:35:48.814736
# Unit test for function split_url
def test_split_url():
    query = ['scheme', 'netloc', 'path', 'query', 'fragment']
    url = 'https://ansible.com/docs/user_guide/playbooks_variables.html'
    result = split_url(url)
    assert len(result) == 5
    for key in query:
        assert key in result

# Generated at 2022-06-23 10:35:57.120716
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils.six.moves.urllib.parse import urlunsplit
    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_text


# Generated at 2022-06-23 10:35:58.285857
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)

# Generated at 2022-06-23 10:36:03.470832
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    args = dict(
        value='http://www.example.com/p1/p2?k1=v1&k2=v2#fragment'
    )

    basic._ANSIBLE_ARGS = to_bytes(args)

    assert split_url('http://www.example.com/p1/p2?k1=v1&k2=v2#fragment') == {'scheme': 'http', 'path': '/p1/p2', 'fragment': 'fragment', 'query': u'k1=v1&k2=v2', 'netloc': 'www.example.com'}

# Generated at 2022-06-23 10:36:04.909318
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule)['urlsplit'] == split_url

# Generated at 2022-06-23 10:36:07.347379
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
                            'urlsplit': split_url
                            }


# Generated at 2022-06-23 10:36:10.926338
# Unit test for constructor of class FilterModule
def test_FilterModule():

    # Testing constructor of class FilterModule with no arguments
    filter_module = FilterModule()

    # Testing attribute filters of class FilterModule
    filters = filter_module.filters()
    assert len(filters) == 1
    assert callable(filters['urlsplit'])
