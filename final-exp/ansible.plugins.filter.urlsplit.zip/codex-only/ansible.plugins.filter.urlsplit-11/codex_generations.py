

# Generated at 2022-06-23 10:26:11.239219
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:26:12.191873
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module is not None

# Generated at 2022-06-23 10:26:14.050118
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert 'urlsplit' in module.filters()


# Generated at 2022-06-23 10:26:14.839120
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:26:16.765457
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Unit test for FilterModule '''
    fm = FilterModule()
    assert fm
    assert fm.filters()

# Generated at 2022-06-23 10:26:17.695149
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert not FilterModule().filters()

# Generated at 2022-06-23 10:26:19.057086
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()
    print(x.filters())



# Generated at 2022-06-23 10:26:31.889789
# Unit test for function split_url
def test_split_url():
    url = 'http://www.foo.com:80/bar/baz.html?arg1=val1&arg2=val2#fragment'
    url_options = {
        'scheme': 'http',
        'netloc': 'www.foo.com:80',
        'path': '/bar/baz.html',
        'query': 'arg1=val1&arg2=val2',
        'fragment': 'fragment',
        'username': None,
        'password': None,
        'hostname': 'www.foo.com',
        'port': '80',
    }

    # Test that filter returns all options by default
    url_split = split_url(url)
    assert url_split == url_options, url_split

    # Test all valid query values

# Generated at 2022-06-23 10:26:34.140555
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()
    assert 'nosuchfilter' not in fm.filters()


# Generated at 2022-06-23 10:26:36.900471
# Unit test for constructor of class FilterModule
def test_FilterModule():

    fm = FilterModule()
    assert fm.filters()['urlsplit'] is not None


# Generated at 2022-06-23 10:26:39.378121
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(None) == {
        'urlsplit': split_url
    }

# Generated at 2022-06-23 10:26:41.593623
# Unit test for constructor of class FilterModule
def test_FilterModule():
	filter_module = FilterModule()
	assert filter_module.filters() == {'urlsplit': split_url}



# Generated at 2022-06-23 10:26:50.662410
# Unit test for function split_url
def test_split_url():
    value = 'https://user:pass@www.ansible.com:8080/docs?id=10#section1'
    testset = {
        'value': value,
        'scheme': 'https',
        'netloc': 'user:pass@www.ansible.com:8080',
        'path': '/docs',
        'query': 'id=10',
        'fragment': 'section1',
    }
    assert split_url(value, testset['value']) == value
    assert split_url(value, testset['scheme']) == testset[testset['scheme']]
    assert split_url(value, testset['netloc']) == testset[testset['netloc']]

# Generated at 2022-06-23 10:27:00.228272
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/foo/bar/baz.html?id=1&q=2#fragment') == dict(scheme='http', netloc='www.example.com', path='/foo/bar/baz.html', query='id=1&q=2', fragment='fragment')
    assert split_url('ftp://user@example.com/foo/bar/baz.txt', query='scheme') == 'ftp'
    assert split_url('https://example.com:4444/foo/bar/baz/', query='port') == 4444
    assert split_url('http://user:pass@example.com:1234/path/to/file', query='username') == 'user'

# Generated at 2022-06-23 10:27:02.547277
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()

# Generated at 2022-06-23 10:27:11.987766
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # test set of valid options with values for urlsplit
    url = r'http://www.cwi.nl:80/%7Eguido/Python.html'
    url_opts = {
        'scheme': 'http',
        'netloc': 'www.cwi.nl:80',
        'path': '/%7Eguido/Python.html',
        'fragment': '',
        'query': ''
    }
    # Setup filters object
    filters = FilterModule()
    # Loop through the options
    for k, v in url_opts.items():
        # Ensure the option returns it's value
        assert filters.filters()['urlsplit'](url, k) == v

# Generated at 2022-06-23 10:27:16.748267
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """Test for method FilterModule.filters"""
    url = 'http://www.python.org:80/fish?q=python'
    actual_output = split_url(value=url, query='scheme')
    expected_output = 'http'
    assert actual_output == expected_output



# Generated at 2022-06-23 10:27:19.675439
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fn = FilterModule()
    assert fn.filters().keys() == {'urlsplit'}, 'Test for class FilterModule, method filters failed'


# Generated at 2022-06-23 10:27:20.254941
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:27:22.398576
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fmodule = FilterModule()
    assert fmodule.filters() is not None
    assert 'urlsplit' in fmodule.filters().keys()


# Generated at 2022-06-23 10:27:23.855586
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert True

# Generated at 2022-06-23 10:27:28.637289
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    # On pyrhon2, FilterModule.__dict__.keys() returns a list of strings,
    # on python3, it returns a view of FilterModule.__dict__.keys() which is a set-like type.
    filters = list(obj.filters().keys())
    assert 'urlsplit' in filters

# Generated at 2022-06-23 10:27:32.371468
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''Unit tests for method filters of class FilterModule.'''
    fm = FilterModule()
    filters = fm.filters()
    assert isinstance(filters, dict)



# Generated at 2022-06-23 10:27:33.420024
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-23 10:27:35.441802
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert "urlsplit" == list(obj.filters().keys())[0]


# Generated at 2022-06-23 10:27:43.038415
# Unit test for constructor of class FilterModule
def test_FilterModule():
  import json

  fn = FilterModule()
  fn_dict = fn.filters() # returns dictionary of form {"key":"value", "key2":"value2", etc}
                          # where value(s) are filter(s)

  # test the constructor
  assert len(fn_dict.keys()) == 1, "Didn't get correct number of filter methods returned by FilterModule"

  # test the filter method split_url
  url_example = 'https://www.google.com:8080/index.html?q=foobar#label'
  assert fn_dict['urlsplit'](url_example, 'scheme') == 'https', "Didn't get correct split of URL"

# Generated at 2022-06-23 10:27:44.946427
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

    assert fm.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:27:52.272555
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.slashdot.org/foo/bar/')['scheme'] == 'http'
    assert split_url('http://www.slashdot.org', 'path') == '/'
    assert split_url('http://www.slashdot.org:8080/', 'port') == '8080'
    assert split_url('http://user:pass@www.slashdot.org/')['netloc'] == 'user:pass@www.slashdot.org'
    assert split_url('http://www.slashdot.org/', 'query') == ''
    assert split_url('http://www.slashdot.org/foo?bar=baz&spam=eggs', 'query') == 'bar=baz&spam=eggs'

# Generated at 2022-06-23 10:27:53.363231
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert 'urlsplit' in module.filters()


# Generated at 2022-06-23 10:27:55.807997
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert 'urlsplit' in filters
    assert filters['urlsplit'] == split_url

# ----


# Generated at 2022-06-23 10:27:59.015581
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()

    filters = filter_module.filters()

    assert 'urlsplit' in filters


# Generated at 2022-06-23 10:28:08.725081
# Unit test for function split_url
def test_split_url():
    import pytest
    from ansible.module_utils.six.moves.urllib.parse import urlsplit

    def validate(expected):

        # Validate that the expected values were received
        for k, v in expected.items():
            assert k in results, "Missing '%s' from results" % k
            assert results[k] == v, "Expected '%s' to be '%s' but got '%s'" % (k, v, results[k])


    # Basic test
    url = "http://username:password@host.com:80/path/to/file?key1=val1&key2=val2#frag"

# Generated at 2022-06-23 10:28:11.497577
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    actual = obj.filters()
    expected = {'urlsplit': split_url}
    assert actual == expected


# Generated at 2022-06-23 10:28:12.574135
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filtermodule = FilterModule()
    filtermodule.filters()

# Generated at 2022-06-23 10:28:13.940564
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert 'urlsplit' in module.filters()


# Generated at 2022-06-23 10:28:15.671239
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-23 10:28:23.142926
# Unit test for function split_url
def test_split_url():
    value = 'http://127.0.0.1:8080/test/test1/test2?test=test1&test=test2'
    query = ''

    results = {
        'scheme': 'http',
        'netloc': '127.0.0.1:8080',
        'path': '/test/test1/test2',
        'query': 'test=test1&test=test2',
        'fragment': ''
    }

    assert split_url(value, query) == results
    assert split_url(value, 'scheme') == 'http'
    assert split_url(value, 'netloc') == '127.0.0.1:8080'
    assert split_url(value, 'path') == '/test/test1/test2'

# Generated at 2022-06-23 10:28:33.577262
# Unit test for function split_url
def test_split_url():
    from ansible import constants as C
    from ansible.plugins.filter.core import FilterModule

    C.config.set_config_file('/dev/null')

    filters = FilterModule()
    filters.filters()

    # Test all options
    test_url = 'https://example.com:8080/hello/world/index.html?q=1&foo=bar'
    expected = {
        'scheme': 'https',
        'netloc': 'example.com:8080',
        'path': '/hello/world/index.html',
        'params': '',
        'query': 'q=1&foo=bar',
        'fragment': ''
    }
    assert split_url(test_url) == expected

    # Test per option

# Generated at 2022-06-23 10:28:34.918453
# Unit test for constructor of class FilterModule
def test_FilterModule():
    mod = FilterModule()
    assert mod


# Generated at 2022-06-23 10:28:36.235231
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')


# Generated at 2022-06-23 10:28:38.047836
# Unit test for constructor of class FilterModule
def test_FilterModule():
  assert callable(FilterModule)

# Generated at 2022-06-23 10:28:48.370729
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.org:8080/path/to/file?key1=val1&key2=val2#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.org:8080/path/to/file?key1=val1&key2=val2#fragment', 'netloc') == 'www.example.org:8080'
    assert split_url('http://www.example.org:8080/path/to/file?key1=val1&key2=val2#fragment', 'path') == '/path/to/file'

# Generated at 2022-06-23 10:28:57.203620
# Unit test for method filters of class FilterModule

# Generated at 2022-06-23 10:28:59.552260
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'urlsplit' == FilterModule.filters(None)['urlsplit'].__name__

# Generated at 2022-06-23 10:29:05.129295
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(split_url('http://www.example.com/path')) == \
        {'netloc': 'www.example.com', 'scheme': 'http', 'path': '/path', 'query': '', 'fragment': ''}
    assert(split_url('http://www.example.com/path', 'path')) == '/path'

# Generated at 2022-06-23 10:29:07.843895
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'urlsplit' == FilterModule.filters.__name__

# Generated at 2022-06-23 10:29:09.924832
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url("foo") == "foo"

# Generated at 2022-06-23 10:29:14.560843
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert '*' == FilterModule().filters()['urlsplit']("http://www.example.com?v=8", "query")
    assert 'www.example.com' == FilterModule().filters()['urlsplit']("http://www.example.com?v=8", "hostname")
    assert 'http' == FilterModule().filters()['urlsplit']("http://www.example.com?v=8", "scheme")

# Generated at 2022-06-23 10:29:24.161627
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    url = 'https://www.google.com/search?q=urlparse'

    filter_module = FilterModule()

    # Test method filter of class FilterModule
    result = filter_module.filters()

    # Verify the result
    assert len(result) == 1
    result = result['urlsplit'](url)
    assert result['scheme'] == 'https'
    assert result['netloc'] == 'www.google.com'
    assert result['path'] == '/search'
    assert result['query'] == 'q=urlparse'
    assert result['fragment'] == ''
    result = filter_module.filters()['urlsplit'](url, 'scheme')
    assert result == 'https'
    result = filter_module.filters()['urlsplit'](url, 'netloc')

# Generated at 2022-06-23 10:29:35.632948
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """ Unit test for filters method of FilterModule """
    # pylint: disable=protected-access
    # pylint: disable=no-value-for-parameter
    URI = "http+unix://%2Fvar%2Frun%2Fdocker.sock/containers/c26b6a1a6a0c/pause"
    filters = FilterModule().filters()
    filter_result = filters['urlsplit'](URI)
    assert filter_result['scheme'] == 'http+unix'
    assert filter_result['netloc'] == '%2Fvar%2Frun%2Fdocker.sock'
    assert filter_result['path'] == '/containers/c26b6a1a6a0c/pause'
    assert filter_result['fragment'] == ''
    assert filter_result

# Generated at 2022-06-23 10:29:45.593505
# Unit test for function split_url
def test_split_url():
    assert split_url(u'http://www.example.com/path/to/file.html?key1=value1&key2=value2') == {'fragment': '', 'hostname': 'www.example.com', 'netloc': 'www.example.com', 'path': '/path/to/file.html', 'query': 'key1=value1&key2=value2', 'scheme': 'http'}
    assert split_url(u'http://www.example.com/path/to/file.html/&key1=value1&key2=value2', query='scheme') == 'http'


# Generated at 2022-06-23 10:29:54.795770
# Unit test for function split_url
def test_split_url():
    res = split_url('ftp://ftp.is.co.za/rfc/rfc1808.txt', 'scheme')
    assert res == 'ftp'

    res = split_url('http://www.ietf.org/rfc/rfc2396.txt', 'netloc')
    assert res == 'www.ietf.org'

    res = split_url('telnet://john@clark.net/', 'hostname')
    assert res == 'clark.net'

    res = split_url('http://www.ics.uci.edu/pub/ietf/uri/#Related', 'path')
    assert res == 'www.ics.uci.edu/pub/ietf/uri/'

    res = split_url('mailto:John.Doe@example.com', 'username')
    assert res

# Generated at 2022-06-23 10:29:56.808257
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:29:58.334011
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'foo' == FilterModule().filters().get('urlsplit')('foo', 'scheme')

# Generated at 2022-06-23 10:29:59.430678
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  # no coverage needed, just to see if this would break
  assert FilterModule().filters()

# Generated at 2022-06-23 10:30:06.943794
# Unit test for function split_url
def test_split_url():
    url = "https://www.google.co.in/search?client=ubuntu&channel=fs&q=network+protocol+cisco&ie=utf-8&oe=utf-8"
    assert split_url(url) == {
        'scheme': 'https',
        'hostname': 'www.google.co.in',
        'path': '/search',
        'query': 'client=ubuntu&channel=fs&q=network+protocol+cisco&ie=utf-8&oe=utf-8',
        'fragment': '',
        'username': '',
        'password': '',
        'port': '',
    }
    assert split_url(url, 'scheme') == 'https'
    assert split_url(url, 'hostname') == 'www.google.co.in'


# Generated at 2022-06-23 10:30:08.314345
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(None) == {'urlsplit': split_url}

# Generated at 2022-06-23 10:30:14.090334
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('ansible://ssh:pass@github.com/ansible/ansible/issues#2') == {
        'hostname': 'github.com', 'netloc': 'ssh:pass@github.com', 'fragment': '2', 'path': '/ansible/ansible/issues', 'scheme': 'ansible', 'username': 'ssh', 'password': 'pass', 'query': '', 'port': None}

# Generated at 2022-06-23 10:30:21.540745
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.redhat.com') == {'netloc': 'www.redhat.com', 'scheme': 'https', 'path': '', 'query': '', 'fragment': ''}
    assert split_url('https://www.redhat.com', 'netloc') == 'www.redhat.com'
    assert split_url('https://www.redhat.com', 'scheme') == 'https'
    assert split_url('https://www.redhat.com', 'netloc') == 'www.redhat.com'

# Generated at 2022-06-23 10:30:25.853156
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for FilterModule filters. '''

    fm = FilterModule()
    res = fm.filters()

    assert 'urlsplit' in res
    assert isinstance(res['urlsplit'], type(split_url))



# Generated at 2022-06-23 10:30:28.159572
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:30:29.608340
# Unit test for constructor of class FilterModule
def test_FilterModule():
    t = FilterModule()
    assert t is not None


# Generated at 2022-06-23 10:30:32.093383
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert 'urlsplit' in filters
    assert filters['urlsplit'] == split_url

# Generated at 2022-06-23 10:30:33.601118
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    with pytest.raises(KeyError):
        FilterModule.filters()['urlsplit']

# Generated at 2022-06-23 10:30:41.266223
# Unit test for constructor of class FilterModule
def test_FilterModule():
    url = 'http://host.com/path;params?query=arg#frag'
    assert split_url(url)['scheme'] == 'http'
    assert split_url(url)['netloc'] == 'host.com'
    assert split_url(url)['path'] == '/path'
    assert split_url(url)['query'] == 'query=arg'
    assert split_url(url)['fragment'] == 'frag'

# Generated at 2022-06-23 10:30:43.729273
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:30:45.517586
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    f.filters = {'urlsplit': split_url}


# Generated at 2022-06-23 10:30:46.131172
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:30:46.713321
# Unit test for constructor of class FilterModule
def test_FilterModule():
	return FilterModule()


# Generated at 2022-06-23 10:30:51.759013
# Unit test for function split_url
def test_split_url():
    test_url = "https://www.google.com"
    assert split_url(test_url, 'scheme') == "https"
    assert split_url(test_url, 'netloc') == "www.google.com"
    assert split_url(test_url, 'path') == ""
    assert split_url(test_url, 'query') == ""
    assert split_url(test_url, 'fragment') == ""
    assert split_url(test_url)

# Generated at 2022-06-23 10:31:02.601068
# Unit test for function split_url
def test_split_url():
    from ansible.compat.tests import unittest

    class TestSplitUrl(unittest.TestCase):

        def test_urlsplit_simple(self):
            self.assertEqual(split_url('https://www.ansible.com/'),
                             {'netloc': 'www.ansible.com', 'fragment': '', 'path': '/', 'scheme': 'https', 'query': ''})
        def test_urlsplit_named_part(self):
            self.assertEqual(split_url('https://www.ansible.com/', 'netloc'),
                             'www.ansible.com')


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-23 10:31:04.508229
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()



# Generated at 2022-06-23 10:31:10.451842
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    dict = {'urlsplit': split_url}
    assert (FilterModule.filters(FilterModule) == dict)

# Generated at 2022-06-23 10:31:12.155583
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    uut = FilterModule()
    assert 'urlsplit' in uut.filters()

# Generated at 2022-06-23 10:31:21.713803
# Unit test for function split_url
def test_split_url():
    test_url = 'http://username:password@www.example.org:8080/path1/path2/path3?query1=text1&query2=text2#fragment'
    test_urlsplit = split_url(test_url)
    assert test_urlsplit['scheme'] == 'http'
    assert test_urlsplit['netloc'] == 'username:password@www.example.org:8080'
    assert test_urlsplit['path'] == '/path1/path2/path3'
    assert test_urlsplit['query'] == 'query1=text1&query2=text2'
    assert test_urlsplit['fragment'] == 'fragment'
    assert split_url(test_url, 'path') == '/path1/path2/path3'

# Generated at 2022-06-23 10:31:29.811492
# Unit test for function split_url
def test_split_url():
    url = "https://www.google.com/webhp?sourceid=chrome-instant&ion=1&espv=2&ie=UTF-8#q=ansible"
    assert split_url(url) == {
        'netloc': 'www.google.com',
        'path': '/webhp',
        'query': 'sourceid=chrome-instant&ion=1&espv=2&ie=UTF-8',
        'fragment': 'q=ansible',
        'scheme': 'https',
    }
    assert split_url(url, 'netloc') == 'www.google.com'
    assert split_url(url, 'query') == 'sourceid=chrome-instant&ion=1&espv=2&ie=UTF-8'

# Generated at 2022-06-23 10:31:30.699938
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None
    assert FilterModule


# Generated at 2022-06-23 10:31:32.105486
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()


# Generated at 2022-06-23 10:31:33.252759
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(isinstance(FilterModule(), FilterModule))

# Generated at 2022-06-23 10:31:35.470511
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:31:37.258947
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None


# Generated at 2022-06-23 10:31:47.236597
# Unit test for function split_url
def test_split_url():
    '''
    Tests for function split_url
    '''
    from ansible.compat.tests import unittest

    class TestSplitUrl(unittest.TestCase):
        '''
        Unit test class to test the split_url function

        '''
        def setUp(self):
            '''
            Sets up a few known values to test against.

            '''
            self.url = 'https://user:pass@github.com/ansible/ansible/issues/12685'
            self.expected_results = {
                'scheme': 'https',
                'netloc': 'user:pass@github.com',
                'path': '/ansible/ansible/issues/12685',
                'query': '',
                'fragment': '',
            }


# Generated at 2022-06-23 10:31:54.850403
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/foo/bar/', query='scheme') == 'http'
    assert split_url('http://www.example.com/foo/bar/', query='netloc') == 'www.example.com'
    assert split_url('http://www.example.com/foo/bar/', query='path') == '/foo/bar/'
    assert split_url('http://user:pass@www.example.com/foo/bar/', query='path') == '/foo/bar/'
    assert split_url('http://user:pass@www.example.com/foo/bar/?baz=qux', query='query') == 'baz=qux'

# Generated at 2022-06-23 10:31:57.916590
# Unit test for function split_url
def test_split_url():
    test_input = 'http://www.cnn.com/index.html'
    output = split_url(test_input, 'netloc')
    assert output == 'www.cnn.com'

# Generated at 2022-06-23 10:32:07.166784
# Unit test for function split_url
def test_split_url():
    # Valid URLs
    assert split_url('http://www.example.com:80/path?q#frag') == {
        'hostname': 'www.example.com',
        'port': '80',
        'path': '/path',
        'scheme': 'http',
        'fragment': 'frag',
        'netloc': 'www.example.com:80',
        'params': '',
        'query': 'q'
    }

    # Returns the entire dictionary when no query is specified
    # (no assertion needed)
    split_url('http://www.example.com:80/path?q#frag')

    # Valid URL with query option
    assert split_url('http://www.example.com:80/path?q#frag', query='scheme') == 'http'

# Generated at 2022-06-23 10:32:12.304965
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    
    url = "https://www.google.com/search?client=firefox-b-ab&q=python"
    result = f.filters()["urlsplit"](url)
    assert result["scheme"] == "https"
    assert result["netloc"] == "www.google.com"
    assert result["path"] == "/search"
    assert result["query"] == "client=firefox-b-ab&q=python"
    assert result["fragment"] == ""

# Generated at 2022-06-23 10:32:12.964483
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule



# Generated at 2022-06-23 10:32:22.689533
# Unit test for function split_url
def test_split_url():
    assert split_url('https://example.com/user.html?id=123&name=alex') == {
        'query': 'id=123&name=alex',
        'fragment': '',
        'path': '/user.html',
        'netloc': 'example.com',
        'username': '',
        'scheme': 'https',
        'password': '',
        'hostname': 'example.com',
        'port': ''
    }

# Generated at 2022-06-23 10:32:26.909456
# Unit test for constructor of class FilterModule
def test_FilterModule():
    myfilter = FilterModule()
    assert(myfilter.filters()['urlsplit'] == split_url)


# Generated at 2022-06-23 10:32:29.230846
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()


# Generated at 2022-06-23 10:32:40.763335
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('http://www.example.com:8080/path/to?key1=value1&key2=value2', 'query') == 'key1=value1&key2=value2'
    assert split_url('https://user:pass@www.example.com:8080/path/to?key1=value1&key2=value2', 'port') == '8080'
    assert split_url('https://user:pass@www.example.com:8080/path/to?key1=value1&key2=value2', 'passwd') == 'pass'
    assert split_url('https://user:pass@www.example.com:8080/path/to?key1=value1&key2=value2', 'hostname') == 'www.example.com'

# Generated at 2022-06-23 10:32:50.941107
# Unit test for function split_url
def test_split_url():

    # Test all valid components of a URL
    assert split_url('https://docs.ansible.com/ansible/latest/modules/uri_module.html', 'scheme') == 'https'
    assert split_url('https://docs.ansible.com/ansible/latest/modules/uri_module.html', 'netloc') == 'docs.ansible.com'
    assert split_url('https://docs.ansible.com/ansible/latest/modules/uri_module.html', 'path') == '/ansible/latest/modules/uri_module.html'
    assert split_url('https://docs.ansible.com/ansible/latest/modules/uri_module.html', 'query') == ''

# Generated at 2022-06-23 10:32:53.736962
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:32:55.644921
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:33:06.644582
# Unit test for function split_url
def test_split_url():
    sample_url = "https://www.google.com:443/path/to/resource.php?query=string&x=y".lower()
    url_dict_1 = {
        'scheme': 'https',
        'netloc': 'www.google.com:443',
        'path': '/path/to/resource.php',
        'query': 'query=string&x=y',
        'fragment': ''
    }
    url_dict_2 = {
        'scheme': 'https',
        'netloc': 'www.google.com:443',
        'path': '/path/to/resource.php',
        'query': 'query=string&x=y',
        'fragment': ''
    }

# Generated at 2022-06-23 10:33:17.301641
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert urlsplit('http://www.cwi.nl:80/%7Eguido/Python.html')[0] == 'http'
    assert urlsplit('http://www.cwi.nl:80/%7Eguido/Python.html')[1] == 'www.cwi.nl:80'
    assert urlsplit('http://www.cwi.nl:80/%7Eguido/Python.html')[2] == '/%7Eguido/Python.html'
    assert urlsplit('http://www.cwi.nl:80/%7Eguido/Python.html')[3] == ''
    assert urlsplit('http://www.cwi.nl:80/%7Eguido/Python.html')[4] == ''

# Generated at 2022-06-23 10:33:22.205867
# Unit test for function split_url
def test_split_url():
    url = 'https://www.ansible.com/'
    assert split_url(url)
    assert split_url(url, 'scheme') == 'https'
    assert split_url(url, 'netloc') == 'www.ansible.com'
    assert split_url(url, 'path') == '/'
    try:
        split_url(url, 'foo')
    except AnsibleFilterError as e:
        pass

# Generated at 2022-06-23 10:33:23.725380
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    a = FilterModule()
    assert a.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:33:34.758708
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test the filters method of class FilterModule
    host = 'http://www.example.com/path?key=val#anchor'
    qlist = [('scheme', 'http'), ('netloc', 'www.example.com'), ('path', '/path'), ('query', 'key=val'),
             ('fragment', 'anchor')]
    fm = FilterModule()
    for q,r in qlist:
        assert fm.filters()['urlsplit'](host, q) == r
    assert fm.filters()['urlsplit'](host) == dict(qlist)


if __name__ == '__main__':
    # Allow direct execution
    import os
    import sys
    sys.path.append(os.path.dirname(__file__))
    fm = FilterModule()
    # Test

# Generated at 2022-06-23 10:33:36.893776
# Unit test for constructor of class FilterModule

# Generated at 2022-06-23 10:33:40.906540
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert '<class \'ansible.utils.unsafe_proxy.AnsibleUnsafeText\'>' in str(FilterModule.filters(FilterModule))


# Generated at 2022-06-23 10:33:41.890053
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-23 10:33:53.452953
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    import json
    import sys
    import os

    # Initialize Ansible
    context = lambda: None
    context.CLIARGS = basic.AnsibleCLIArgs(args=['ansible-playbook', '-'])
    context.CLIARGS._parse()
    loader = AnsibleCollectionLoader()
    context.COLLECTIONS_PATHS = [os.getcwd()]
    context.loader = loader
    context._init_global_cache()
    context.basedir = os.getcwd()

    # Prepare filter module
    filter_module = FilterModule()
   

# Generated at 2022-06-23 10:33:55.991248
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert 'urlsplit' in module.filters()



# Generated at 2022-06-23 10:34:05.660602
# Unit test for function split_url
def test_split_url():
    assert split_url('https://github.com/ansible/ansible/tree/devel/lib/ansible/plugins/action') == {
        'username': '', 
        'password': '', 
        'hostname': 'github.com', 
        'netloc': 'github.com', 
        'path': '/ansible/ansible/tree/devel/lib/ansible/plugins/action', 
        'port': None, 
        'fragment': '', 
        'scheme': 'https', 
        'query': ''
    }
    assert split_url('https://github.com/ansible/ansible/tree/devel/lib/ansible/plugins/action', 'path') == '/ansible/ansible/tree/devel/lib/ansible/plugins/action'

# Generated at 2022-06-23 10:34:07.657961
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    m = FilterModule()
    assert m.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:34:09.397100
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert(filter_module.filters()['urlsplit'] == split_url)



# Generated at 2022-06-23 10:34:15.986403
# Unit test for function split_url
def test_split_url():
    url_host_port = {'host': 'www.ansible.com', 'netloc': 'www.ansible.com', 'port': None, 'scheme': 'http', 'query': '', 'path': '', 'fragment': None}
    url_path = {'host': '', 'netloc': '', 'port': None, 'scheme': '', 'query': '', 'path': '/docs/intro_getting_started.html', 'fragment': None}
    url = url_host_port
    url.update(url_path)


# Generated at 2022-06-23 10:34:24.512580
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    tests = (
        ('https://example.com', '', 'urlsplit', {'scheme': 'https', 'netloc': 'example.com', 'path': '', 'query': '', 'fragment': ''}),
        ('https://example.com', 'path', 'urlsplit', ''),
        ('https://example.com', 'query', 'urlsplit', ''),
        ('https://example.com', 'scheme', 'urlsplit', 'https'),
        ('https://example.com', 'netloc', 'urlsplit', 'example.com'),
    )
    for url, query, alias, result in tests:
        assert fm.filters()[alias](url, query) == result

# Generated at 2022-06-23 10:34:27.500088
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ut_module = FilterModule()
    assert ut_module.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:34:29.192652
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    obj.filters()
#test_FilterModule()


# Generated at 2022-06-23 10:34:30.913134
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    m = FilterModule()
    filters = m.filters()
    assert filters['urlsplit'] == split_url

# Generated at 2022-06-23 10:34:32.271517
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    assert 'urlsplit' in filters.filters()

# Generated at 2022-06-23 10:34:47.082207
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.yelp.com:8000/los-angeles', 'scheme') == 'http'
    assert split_url('http://www.yelp.com:8000/los-angeles', 'netloc') == 'www.yelp.com:8000'
    assert split_url('http://www.yelp.com:8000/los-angeles', 'path') == '/los-angeles'
    assert split_url('http://www.yelp.com:8000/los-angeles', 'query') == ''
    assert split_url('http://www.yelp.com:8000/los-angeles', 'fragment') == ''

# Generated at 2022-06-23 10:34:54.972672
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Unit test.
    fm = FilterModule()

    # No query
    actual = fm.filters()['urlsplit']('https://ansible.com/faq')
    assert actual['netloc'] == 'ansible.com'

    # Invalid query
    try:
        actual = fm.filters()['urlsplit']('https://ansible.com/faq', query='example.com')
    except AnsibleFilterError as e:
        assert 'unknown URL component: example.com' in str(e)
        pass

    # Valid query
    actual = fm.filters()['urlsplit']('https://ansible.com/faq', query='scheme')
    assert actual == 'https'

# Generated at 2022-06-23 10:34:56.380236
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:35:05.313553
# Unit test for function split_url
def test_split_url():
    test = "http://user@some.wiki.org:8888/schemadoc/list.jsp#anchor"
    results = split_url(test)
    expected = {
        'fragment': 'anchor',
        'netloc': 'user@some.wiki.org:8888',
        'path': '/schemadoc/list.jsp',
        'query': '',
        'scheme': 'http'
    }
    assert results == expected, 'split_url function failed! expected:%s, got:%s' % (expected, results)

# Generated at 2022-06-23 10:35:07.723664
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Unit test for FilterModule constructor '''
    module = FilterModule()
    assert module != None


# Generated at 2022-06-23 10:35:15.933218
# Unit test for constructor of class FilterModule
def test_FilterModule():
    url = 'http://user:pass@example.com/path;param?query=string#fragment'

    f = FilterModule()

    results = f.filters()['urlsplit'](url)
    assert results == {
        u'scheme': 'http',
        u'hostname': 'example.com',
        u'netloc': 'user:pass@example.com',
        u'username': 'user',
        u'password': 'pass',
        u'path': '/path;param',
        u'fragment': 'fragment',
        u'query': 'query=string',
    }

    results = f.filters()['urlsplit'](url, 'scheme')
    assert results == 'http'

    results = f.filters()['urlsplit'](url, 'fragment')


# Generated at 2022-06-23 10:35:27.505794
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert filters['urlsplit'] == split_url


# Generated at 2022-06-23 10:35:30.401960
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    filters = module.filters()
    assert 'urlsplit' in filters

# Generated at 2022-06-23 10:35:30.984021
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:35:33.001885
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_obj = FilterModule()

    assert 'urlsplit' in test_obj.filters()


# Generated at 2022-06-23 10:35:39.957984
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_input = 'http://ansible.com/docs/home.html?a=1&b=2'
    test_query = 'path'
    expected_result = '/docs/home.html'
    actual_result = split_url(test_input, test_query)
    print(actual_result,type(actual_result))
    assert actual_result == expected_result, 'Test failed: expected "%s", but got "%s"' % (expected_result, actual_result)


# Generated at 2022-06-23 10:35:45.258706
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == { 'urlsplit': split_url }


# Generated at 2022-06-23 10:35:47.240555
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() is not None



# Generated at 2022-06-23 10:35:56.591556
# Unit test for function split_url
def test_split_url():
    from __main__ import split_url
    assert split_url('http://www.example.com/index.html')['scheme'] == 'http'
    assert split_url('https://www.example.com/index.html')['scheme'] == 'https'
    assert split_url('ftp://www.example.com/index.html')['scheme'] == 'ftp'
    assert split_url('http://www.example.com/index.html', url='url')['url'] == 'http://www.example.com/index.html'
    assert split_url('https://www.example.com/index.html')['scheme'] == 'https'
    assert split_url('ftp://www.example.com/index.html')['scheme'] == 'ftp'

# Generated at 2022-06-23 10:35:59.310729
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' test the filter module constructor '''

    obj = FilterModule()
    assert(obj.filters() == {
        'urlsplit': split_url
    })


# Generated at 2022-06-23 10:36:07.760346
# Unit test for function split_url
def test_split_url():
    # pylint: disable=unused-argument
    def test_filter(*args, **kwargs):
        return {
            'urlsplit' : split_url
        }

    test_url = "https://www.ansible.com/test?test=test"

    filter_test = test_filter()

    # Test schema
    assert filter_test['urlsplit'](test_url, 'scheme') == 'https'

    # Test netloc
    assert filter_test['urlsplit'](test_url, 'netloc') == 'www.ansible.com'

    # Test path
    assert filter_test['urlsplit'](test_url, 'path') == '/test'

    # Test query
    assert filter_test['urlsplit'](test_url, 'query') == 'test=test'

    # Test invalid argument


# Generated at 2022-06-23 10:36:09.663528
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'urlsplit': split_url}
