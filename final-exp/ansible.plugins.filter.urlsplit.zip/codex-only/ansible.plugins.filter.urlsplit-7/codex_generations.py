

# Generated at 2022-06-23 10:26:12.339054
# Unit test for constructor of class FilterModule
def test_FilterModule():
    result = FilterModule()
    assert result is not None # Will raise AssertionError if test fails



# Generated at 2022-06-23 10:26:14.797825
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:26:16.722800
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Check if the class is initialized
    filter_module = FilterModule()
    assert filter_module is not None


# Generated at 2022-06-23 10:26:18.288133
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:26:31.051783
# Unit test for function split_url
def test_split_url():
   assert split_url(value="http://www.example.com/path?arg=value#fragment", query='scheme') == 'http'
   assert split_url(value="http://www.example.com/path?arg=value#fragment", query='hostname') == 'www.example.com'
   assert split_url(value="http://www.example.com/path?arg=value#fragment", query='path') == '/path'
   assert split_url(value="http://www.example.com/path?arg=value#fragment", query='query') == 'arg=value'
   assert split_url(value="http://www.example.com/path?arg=value#fragment", query='fragment') == 'fragment'

# Generated at 2022-06-23 10:26:35.475686
# Unit test for function split_url
def test_split_url():
    # Test with a non valid url
    result = split_url(value='/etc/profile',
                       query='scheme',
                       alias='urlsplit')
    assert result == ''

    # Test with a valid url and a non valid query
    result = split_url(value='http://octocat.github.com/Spoon-Knife',
                       query='hello',
                       alias='urlsplit')

# Generated at 2022-06-23 10:26:46.882987
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib

    test_string = 'http://www.example.com/path?arg=value#frag'


# Generated at 2022-06-23 10:26:48.871696
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule


# Generated at 2022-06-23 10:26:53.323538
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filt = FilterModule()
    res = filt.filters()
    assert 'urlsplit' in res
    assert res['urlsplit'] == split_url
    assert res['urlsplit']('http://example.com')['scheme'] == 'http'


# Generated at 2022-06-23 10:27:02.097212
# Unit test for function split_url
def test_split_url():

    # Unit test for URL with port number
    test_value = 'http://www.example.com:80/path/to/page?q=1&sentence=True'
    result = split_url(test_value, 'port')
    assert result == '80'
    result = split_url(test_value, 'query')
    assert result == 'q=1&sentence=True'

    # Unit test for URL without port number
    test_value = 'http://www.example.com/path/to/page?q=1&sentence=True'
    result = split_url(test_value, 'port')
    assert result is None
    result = split_url(test_value, 'query')
    assert result == 'q=1&sentence=True'

    # Unit test for URL with a username, password and default

# Generated at 2022-06-23 10:27:05.175940
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:27:14.694980
# Unit test for function split_url
def test_split_url():
    test_url = 'https://docs.ansible.com/ansible/latest/modules/uri_module.html?id=test'
    # test_url = 'ftp://ftp.funet.fi/pub/standards/RFC/rfc959.txt'
    test_url = 'http://user:password@www.example.com:123/path/to/file?param=1&param=2&param=3#fragment'
    test_url = 'https://groups.google.com/forum/m/#!topic/ansible-project/6aZ4h4uU6Hk'
    test_url = 'https://www.google.com/search?client=firefox-b-1-d&q=python+split+(url)+string+without+urlparse'

# Generated at 2022-06-23 10:27:24.999159
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    Unit test: test_FilterModule.
    """
    from pprint import pprint
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    from ansible.utils import helpers

    uri = 'http://www.example.com:8080/foo?bar=baz' 
    fm = FilterModule()
    pprint(fm.filters())
    assert fm.filters()['urlsplit'](uri) == \
        helpers.object_to_dict(urlsplit(uri), exclude=['count', 'index', 'geturl', 'encode'])

# Generated at 2022-06-23 10:27:31.768809
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    argument = 'http://www.google.com'
    assert split_url(argument, 'scheme') == 'http'
    assert split_url(argument, 'netloc') == 'www.google.com'
    assert split_url(argument, 'query') == ''
    assert split_url(argument, 'path') == ''
    assert split_url(argument, 'fragment') == ''
    assert split_url(argument) == {'fragment': '', 'netloc': 'www.google.com', 'path': '', 'scheme': 'http', 'query': ''}

# Generated at 2022-06-23 10:27:33.996358
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}



# Generated at 2022-06-23 10:27:34.441466
# Unit test for constructor of class FilterModule
def test_FilterModule():
  FilterModule()

# Generated at 2022-06-23 10:27:39.042726
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    res = fm.filters()
    assert 'urlsplit' in res
    urlsplit_obj = res['urlsplit']
    assert urlsplit_obj('http://www.example.com/')['netloc'] == 'www.example.com'
    assert urlsplit_obj('http://www.example.com/', query='netloc') == 'www.example.com'

    # query out of range
    try:
        urlsplit_obj('http://www.example.com/', query='notexist')
    except AnsibleFilterError as e:
        assert 'unknown URL component: notexist' == str(e)
    else:
        assert False

# Generated at 2022-06-23 10:27:41.382314
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:27:43.789443
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    testF = FilterModule()
    assert isinstance(testF.filters(), dict)
    assert 'urlsplit' in testF.filters()


# Generated at 2022-06-23 10:27:46.566435
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm_obj = FilterModule()
    result = fm_obj.filters()
    expected = {
        'urlsplit': split_url
    }
    assert result == expected



# Generated at 2022-06-23 10:27:47.624185
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-23 10:27:49.133946
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)


# Generated at 2022-06-23 10:27:54.055472
# Unit test for function split_url
def test_split_url():
    assert split_url(value='http://www.example.com/path;parameters?query=argument#fragment') == {
        'fragment': 'fragment',
        'netloc': 'www.example.com',
        'path': '/path;parameters',
        'query': 'query=argument',
        'scheme': 'http'
    }

# Generated at 2022-06-23 10:27:58.792533
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''
    Unit test for method filters of class FilterModule.
    '''
    SplitUrl = split_url

    target = 'https://192.168.1.50/pulp/search/?type=repository'
    expected = {'scheme': 'https', 'netloc': '192.168.1.50', 'path': '/pulp/search/', 'query': 'type=repository', 'fragment': ''}

    assert expected == SplitUrl(target)

    target = 'https://192.168.1.50/pulp/search/?type=repository'
    expected = 'https'

    assert expected == SplitUrl(target, query='scheme')

    return True


# Generated at 2022-06-23 10:28:00.368403
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Replace by real unit tests
    assert True


# Generated at 2022-06-23 10:28:09.510927
# Unit test for function split_url
def test_split_url():

    # Set up fixtures
    url_fixtures = [
        'https://www.google.com/search?client=ubuntu&channel=fs&q=ansible+documentation&ie=utf-8&oe=utf-8',
        'https://www.github.com/ansible/ansible/pull/31336',
        'http://www.example.com/index.html#content',
        'http://example.com:80/page/page.html?foo=bar&test=test',
        'http://192.168.0.1:80',
        'http://192.168.0.1:80/',
    ]

    # Run tests

# Generated at 2022-06-23 10:28:11.169588
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}



# Generated at 2022-06-23 10:28:16.493071
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    result = FilterModule.filters(FilterModule)
    length = len(result.keys())
    assert length == 1, "FilterModule.filters returns {} elements instead of 1".format(length)
    assert 'urlsplit' in result.keys(), "FilterModule.filters does not return {} key".format('urlsplit')
    assert result['urlsplit'] == split_url, "FilterModule.filters returns unexpected value for {} key".format('urlsplit')


# Generated at 2022-06-23 10:28:18.505181
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'urlsplit': split_url}

test_FilterModule_filters()


# Generated at 2022-06-23 10:28:19.702342
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm != None

# Generated at 2022-06-23 10:28:20.929464
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test = FilterModule()
    assert test.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:28:32.743996
# Unit test for function split_url

# Generated at 2022-06-23 10:28:40.652069
# Unit test for function split_url
def test_split_url():

    assert split_url("https://www.google.com", alias="") == {
        'scheme': 'https',
        'query': '',
        'fragment': '',
        'netloc': 'www.google.com',
        'path': ''
    }

    assert split_url("https://www.google.com", "scheme", "") == "https"
    assert split_url("https://www.google.com", "path", "") == ""

    try:
        split_url("https://www.google.com", "fake", alias="")
    except AnsibleFilterError as e:
        err = "urlsplit: unknown URL component: fake"
        assert str(e) == err


# Generated at 2022-06-23 10:28:46.668863
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/foo/bar?val1=true&val2=test') == {'scheme': 'http', 'netloc': 'www.example.com', 'query': 'val1=true&val2=test', 'path': '/foo/bar', 'fragment': ''}
    assert split_url('http://www.example.com/foo/bar?val1=true&val2=test', 'path') == '/foo/bar'

# Generated at 2022-06-23 10:28:51.945718
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert split_url('https://www.ansible.com', query='scheme') == 'https'
    assert split_url('https://www.ansible.com:8080', query='scheme') == 'https'
    assert split_url('http://www.ansible.com:80') == {'scheme': 'http', 'query': '', 'fragment': '', 'netloc': 'www.ansible.com:80', 'path': ''}

# Generated at 2022-06-23 10:28:52.718471
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert True

# Generated at 2022-06-23 10:28:54.330347
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert  FilterModule().filters() == {
        'urlsplit': split_url
    }

# Generated at 2022-06-23 10:28:55.203578
# Unit test for constructor of class FilterModule
def test_FilterModule():
	assert(True)



# Generated at 2022-06-23 10:29:07.802977
# Unit test for function split_url
def test_split_url():
    # Create a simple test case
    test_url = 'http://ansible.com:8080/docs?a=1&b=2#content'
    url_results = {
        'query': 'a=1&b=2',
        'fragment': 'content',
        'path': 'docs',
        'netloc': 'ansible.com:8080',
        'scheme': 'http'
    }

    # Import the module
    import ansible.modules.extras.filters.uris as uris

    # Check the individual components
    for test_key, test_value in url_results.items():
        assert(uris.split_url(test_url, test_key) == test_value)

    # Check the dictionary

# Generated at 2022-06-23 10:29:11.420028
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urlsplit'] == split_url, 'method filters of class FilterModule failed!'


# Generated at 2022-06-23 10:29:18.172508
# Unit test for function split_url
def test_split_url():
    ''' Validate the split_url filter'''
    data = 'http://user:pass@www.example.com:80/path;a=1;b=2;c=3?a=1&b=2&c=3#fragment'
    assert split_url(data, 'scheme') == 'http'
    assert split_url(data, 'netloc') == 'user:pass@www.example.com:80'
    assert split_url(data, 'path') == '/path;a=1;b=2;c=3'
    assert split_url(data, 'query') == 'a=1&b=2&c=3'
    assert split_url(data, 'fragment') == 'fragment'


# Generated at 2022-06-23 10:29:21.065220
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:29:25.247363
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    result = fm.filters()['urlsplit'](value="")
    assert (result == {})



# Generated at 2022-06-23 10:29:34.759433
# Unit test for function split_url
def test_split_url():
    url = 'http://www.example.com:80/path?arg=val#frag'
    url_results = {
        'query': 'arg=val',
        'fragment': 'frag',
        'path': '/path',
        'port': 80,
        'scheme': 'http',
        'password': None,
        'username': None,
        'hostname': 'www.example.com',
        'netloc': 'www.example.com:80',
        'url': url,
        'params': '',
    }

    for key, value in url_results.items():
        assert value == split_url(url, query=key)

# Generated at 2022-06-23 10:29:41.982713
# Unit test for function split_url
def test_split_url():
    import ansible.utils.urls as utils
    results = {
        'scheme': 'http',
        'netloc': 'www.ansible.com',
        'path': '/docs/',
        'query': '',
        'fragment': ''
    }
    assert results == utils.split_url('http://www.ansible.com/docs/')
    results = 'http'
    assert results == utils.split_url('http://www.ansible.com/docs/', query='scheme')
    results = 'www.ansible.com'
    assert results == utils.split_url('http://www.ansible.com/docs/', query='netloc')
    results = '/docs/'

# Generated at 2022-06-23 10:29:51.091121
# Unit test for function split_url
def test_split_url():
    ''' Unit test for function split_url '''
    arguments = {
        'value': 'https://docs.ansible.com/ansible/latest/user_guide/playbooks_filters.html',
        'query': ''
    }

    expected_results = {'netloc': 'docs.ansible.com', 'scheme': 'https', 'fragment': '', 'query': '', 'path': '/ansible/latest/user_guide/playbooks_filters.html', 'username': '', 'password': '', 'hostname': '', 'port': ''}

    assert expected_results == split_url(**arguments)

# Generated at 2022-06-23 10:30:03.655072
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.cwi.nl:80/%7Eguido/Python.html') == ('http', 'www.cwi.nl:80', '/%7Eguido/Python.html', '', '')
    assert split_url('http://www.cwi.nl:80/%7Eguido/Python.html', 'scheme') == 'http'
    assert split_url('http://www.cwi.nl:80/%7Eguido/Python.html', 'netloc') == 'www.cwi.nl:80'
    assert split_url('http://www.cwi.nl:80/%7Eguido/Python.html', 'path') == '/%7Eguido/Python.html'

# Generated at 2022-06-23 10:30:06.994335
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert("urlsplit" in FilterModule().filters())

# Unit tests for split_url

# Generated at 2022-06-23 10:30:16.483631
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.example.com') == {'fragment': '', 'netloc': 'www.example.com', 
        'scheme': 'https', 'path': '', 'query': ''}
    assert split_url('https://www.example.com', 'query') == ''
    assert split_url('https://www.example.com', 'fragment') == ''
    assert split_url('https://www.example.com', 'netloc') == 'www.example.com'
    assert split_url('https://www.example.com', 'scheme') == 'https'
    assert split_url('https://www.example.com', 'path') == ''
    assert split_url('https://www.example.com', 'abcd') == 'https://www.example.com'

# Generated at 2022-06-23 10:30:28.541287
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url(
        value='http://www.example.com:8080/path/to/mypage.html?key1=value1&key2=value2#InTheDocument',
        query='scheme') == 'http'
    assert split_url(
        value='http://www.example.com:8080/path/to/mypage.html?key1=value1&key2=value2#InTheDocument',
        query='netloc') == 'www.example.com:8080'
    assert split_url(
        value='http://www.example.com:8080/path/to/mypage.html?key1=value1&key2=value2#InTheDocument',
        query='path') == '/path/to/mypage.html'

# Generated at 2022-06-23 10:30:37.074554
# Unit test for function split_url
def test_split_url():
    url = split_url('https://user:pass@www.example.com:8080/path/with/slashes?a=b&c=d')
    assert url['scheme'] == 'https'
    assert url['netloc'] == 'user:pass@www.example.com:8080'
    assert url['path'] == '/path/with/slashes'
    assert url['query'] == 'a=b&c=d'
    assert url['query_dict']['a'] == 'b'

    url = split_url('https://user:pass@www.example.com:8080/path/with/slashes?a=b&c=d', 'scheme')
    assert url == 'https'


# Generated at 2022-06-23 10:30:48.531760
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('http://user:pass@www.example.com:123/path/123?q=abc#test')['scheme'] == 'http'
    assert split_url('http://user:pass@www.example.com:123/path/123?q=abc#test', 'scheme') == 'http'
    assert split_url('http://user:pass@www.example.com:123/path/123?q=abc#test', 'path') == '/path/123'
    assert split_url('http://user:pass@www.example.com:123/path/123?q=abc#test', 'netloc') == 'user:pass@www.example.com:123'

# Generated at 2022-06-23 10:30:49.588131
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule = FilterModule()
    assert filtermodule is not None


# Generated at 2022-06-23 10:30:51.213064
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert {
        'urlsplit': split_url
    } == FilterModule().filters()


# Generated at 2022-06-23 10:30:52.997373
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert 'urlsplit' in module.filters()


# Generated at 2022-06-23 10:31:05.054526
# Unit test for function split_url
def test_split_url():
    test_dict = {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/uri',
        'params': '',
        'query': 'key1=value1&key2=value2',
        'fragment': 'fragment',
    }
    value = 'http://www.example.com/path/to/uri?key1=value1&key2=value2#fragment'
    assert split_url(value) == test_dict
    test_dict['query'] = 'key1=value1'
    assert split_url(value, 'query') == test_dict['query']
    assert split_url(value, 'path') == test_dict['path']

# Generated at 2022-06-23 10:31:10.598043
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule()
    assert filters is not None


# Generated at 2022-06-23 10:31:20.813811
# Unit test for function split_url
def test_split_url():

    url = 'https://www.cnn.com/2018/02/08/politics/trump-obama-wiretap-claim/index.html'

    result = split_url(url, 'scheme')
    assert result == 'https'

    result = split_url(url, 'netloc')
    assert result == 'www.cnn.com'

    result = split_url(url, 'path')
    assert result == '/2018/02/08/politics/trump-obama-wiretap-claim/index.html'

    result = split_url(url, 'query')
    assert result == ''

    result = split_url(url, 'fragment')
    assert result == ''

    result = split_url(url)
    assert result['scheme'] == 'https'

# Generated at 2022-06-23 10:31:22.976125
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fModule = FilterModule()
    assert fModule.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:31:29.530779
# Unit test for function split_url
def test_split_url():
    from ansible.utils.hashing import md5s
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    path = 'test/example.com'

    # Test with a valid URL
    valid_url = ['http://example.com', 'http', '//example.com', '/', 'example.com', '', 'http', '', '']
    query = 'scheme'
    result = split_url(loader.load_from_file(path)[query], query, 'urlsplit')
    assert md5s(result) == md5s(valid_url[0])

    query = 'netloc'
    result = s

# Generated at 2022-06-23 10:31:30.750332
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None


# Generated at 2022-06-23 10:31:36.952335
# Unit test for function split_url
def test_split_url():
    """
    Test that split_url returns the correct value
    """
    assert split_url('https://www.google.com/search', query='scheme') == 'https'
    assert split_url('https://www.google.com/search', query='netloc') == 'www.google.com'
    assert split_url('https://www.google.com/search', query='path') == 'search'

    # When query is not supplied, split_url returns a dictionary
    assert isinstance(split_url('https://www.google.com/search'), dict)
    assert split_url('https://www.google.com/search')['scheme'] == 'https'
    assert split_url('https://www.google.com/search')['netloc'] == 'www.google.com'

# Generated at 2022-06-23 10:31:47.120380
# Unit test for function split_url
def test_split_url():
    urltest = split_url("http://www.google.com:8080/foo/bar?hello=there#x")
    assert urltest['scheme'] == 'http'
    assert urltest['netloc'] == 'www.google.com:8080'
    assert urltest['path'] == '/foo/bar'
    assert urltest['query'] == 'hello=there'
    assert urltest['fragment'] == 'x'
    assert split_url("http://www.google.com:8080/foo/bar?hello=there#x", query='path') == '/foo/bar'
    assert split_url("nfs://192.168.1.1/exports/common", query='path') == '/exports/common'

# Generated at 2022-06-23 10:31:47.717449
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:31:53.914001
# Unit test for function split_url
def test_split_url():
    from ansible.plugins.filter.uris import split_url

    # good
    assert split_url('http://www.example.com/foo/bar?a=b&c=d#anchor') == {'fragment': 'anchor', 'netloc': 'www.example.com', 'path': '/foo/bar', 'query': 'a=b&c=d', 'scheme': 'http'}
    assert split_url('http://www.example.com/foo/bar#anchor', query='path') == '/foo/bar'
    assert split_url('http://www.example.com/foo/bar#anchor', query='fragment') == 'anchor'
    assert split_url('http://www.example.com/foo/bar#anchor', 'fragment') == 'anchor'

# Generated at 2022-06-23 10:31:56.625373
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() == {
        'urlsplit': split_url
    }

# Generated at 2022-06-23 10:31:58.334088
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:32:09.905327
# Unit test for function split_url
def test_split_url():
    url = "http://user:pass@host.com:80/p/a/t/h?query=arg#frag"
    result = split_url(url)
    assert result['scheme'] == 'http'
    assert result['netloc'] == 'user:pass@host.com:80'
    assert result['path'] == '/p/a/t/h'
    assert result['query'] == 'query=arg'
    assert result['fragment'] == 'frag'

    result = split_url(url, 'scheme')
    assert result == 'http'

    result = split_url(url, 'netloc')
    assert result == 'user:pass@host.com:80'

    result = split_url(url, 'path')
    assert result == '/p/a/t/h'

    result

# Generated at 2022-06-23 10:32:12.977471
# Unit test for constructor of class FilterModule
def test_FilterModule():
    class_object = FilterModule()
    assert class_object.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:32:22.722013
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  f = FilterModule()
  assert "http://www.example.com/path/?key=val" == f.filters()["urlsplit"]("http://www.example.com/path/?key=val")["geturl"]
  assert "http" == f.filters()["urlsplit"]("http://www.example.com/path/?key=val")["scheme"]
  assert "www.example.com" == f.filters()["urlsplit"]("http://www.example.com/path/?key=val")["netloc"]
  assert "/path/" == f.filters()["urlsplit"]("http://www.example.com/path/?key=val")["path"]
  assert "key=val" == f.filters()["urlsplit"]("http://www.example.com/path/?key=val")["query"]
 

# Generated at 2022-06-23 10:32:25.961303
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert(len(FilterModule().filters()) == 1)


# Generated at 2022-06-23 10:32:28.054519
# Unit test for constructor of class FilterModule
def test_FilterModule():
     f = FilterModule()
     assert(f)



# Generated at 2022-06-23 10:32:29.615802
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:32:30.134303
# Unit test for constructor of class FilterModule
def test_FilterModule():
    results = FilterModule()

# Generated at 2022-06-23 10:32:32.995163
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    results = fm.filters()
    assert results['urlsplit'] == split_url


# Generated at 2022-06-23 10:32:39.567477
# Unit test for function split_url
def test_split_url():
    url = 'http://www.example.com/path/to/file?t=1&t=2#foo'
    result = urlsplit(url)
    assert result.scheme == 'http'
    assert result.netloc == 'www.example.com'
    assert result.path == '/path/to/file'
    assert result.query == 't=1&t=2'
    assert result.fragment == 'foo'

# Generated at 2022-06-23 10:32:42.301473
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # test the cases with no arguments
    test = FilterModule()
    assert test.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:32:51.728565
# Unit test for method filters of class FilterModule

# Generated at 2022-06-23 10:32:56.106746
# Unit test for function split_url
def test_split_url():
    result = split_url('https://ansible.com/docs')
    assert result['scheme'] == 'https'
    assert result['path'] == '/docs'
    result = split_url('https://ansible.com/docs', 'domain')
    assert result == 'ansible.com'

# Generated at 2022-06-23 10:33:06.929351
# Unit test for function split_url
def test_split_url():
    """ Unit tests for function split_url """
    from ansible.module_utils.six.moves.urllib.parse import urlsplit

    # Test valid URLs
    assert split_url('https://www.example.com/') == urlsplit('https://www.example.com/')
    assert split_url('https://www.example.com/', query='scheme') == urlsplit('https://www.example.com/').scheme
    assert split_url('https://www.example.com/', query='netloc') == urlsplit('https://www.example.com/').netloc
    assert split_url('https://www.example.com/', query='path') == urlsplit('https://www.example.com/').path

# Generated at 2022-06-23 10:33:13.936385
# Unit test for constructor of class FilterModule
def test_FilterModule():
    '''Unit test for constructor of the class FilterModule.'''

    filter_module = FilterModule()

    expected_filter_module_type = 'FilterModule'
    actual_filter_module_type = type(filter_module)
    assert expected_filter_module_type == actual_filter_module_type,\
        'Type of the instance of FilterModule should be FilterModule.'
    assert isinstance(filter_module, FilterModule),\
        'filter_module should be a instance of FilterModule.'



# Generated at 2022-06-23 10:33:23.012981
# Unit test for function split_url
def test_split_url():
    url = 'http://user:password@example.com:80/path/to/file.php?foo=bar&test=test2#baz'
    res = split_url(url)
    assert res['scheme'] == 'http'
    assert res['netloc'] == 'user:password@example.com:80'
    assert res['path'] == '/path/to/file.php'
    assert res['params'] == ''
    assert res['query'] == 'foo=bar&test=test2'
    assert res['fragment'] == 'baz'
    assert res['username'] == 'user'
    assert res['password'] == 'password'
    assert res['hostname'] == 'example.com'
    assert res['port'] == '80'


# Generated at 2022-06-23 10:33:26.376846
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fmodule = FilterModule()
    assert isinstance(fmodule, FilterModule)
    assert isinstance(fmodule.filters(), dict)
    assert 'urlsplit' in fmodule.filters()


# Generated at 2022-06-23 10:33:36.360833
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    data = {
        'scheme': 'http',
        'netloc': '127.0.0.1:80',
        'path': '/',
        'params': '',
        'query': '',
        'fragment': ''
    }
    assert FilterModule().filters()['urlsplit']('http://127.0.0.1:80/') == data
    assert FilterModule().filters()['urlsplit']('http://127.0.0.1:80/', 'scheme') == 'http'
    assert FilterModule().filters()['urlsplit']('http://127.0.0.1:80/', 'netloc') == '127.0.0.1:80'
    assert FilterModule().filters()['urlsplit']('http://127.0.0.1:80/', 'path')

# Generated at 2022-06-23 10:33:42.329530
# Unit test for function split_url
def test_split_url():
    assert split_url('https://docs.ansible.com:443/ansible/latest/index.html?q=uri#h2', 'scheme') == 'https'
    assert split_url('ssh://www.example.com:2222/path/to/file', 'netloc') == 'www.example.com:2222'

# Generated at 2022-06-23 10:33:45.017161
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters is not None
    assert 'urlsplit' in filters
    assert filters['urlsplit'] == split_url

# ---- Unit Tests ----

# Generated at 2022-06-23 10:33:45.840207
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-23 10:33:56.437998
# Unit test for function split_url
def test_split_url():
    """
    Unit test for split_url
    :return:
    """
    test_string = "https://www.google.com:8080/search?q=parse+url+python&oq=parse+url+python&aqs=chrome..69i57j0l5.1832j0j7&sourceid=chrome&ie=UTF-8"
    assert split_url(test_string, 'scheme') == 'https'
    assert split_url(test_string, 'netloc') == 'www.google.com:8080'
    assert split_url(test_string, 'path') == '/search'

# Generated at 2022-06-23 10:33:57.457670
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert not hasattr(FilterModule, "__init__")

# Generated at 2022-06-23 10:33:58.204039
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert {'urlsplit': split_url} == FilterModule.filters(FilterModule)

# Generated at 2022-06-23 10:34:06.254765
# Unit test for function split_url
def test_split_url():
    assert split_url('https://example.com/path/to/resource', 'scheme') == 'https'
    assert split_url('https://example.com/path/to/resource', 'netloc') == 'example.com'
    assert split_url('https://example.com/path/to/resource', 'path') == '/path/to/resource'
    assert split_url('https://example.com/path/to/resource', 'query') == ''
    assert split_url('https://example.com/path/to/resource', 'fragment') == ''
    assert split_url('https://example.com/path/to/resource?q=query&a=123', 'query') == 'q=query&a=123'

# Generated at 2022-06-23 10:34:14.027908
# Unit test for function split_url
def test_split_url():
    assert(split_url('http://www.w3.org/pub/WWW/TheProject.html', 'path') == '/pub/WWW/TheProject.html')
    assert(split_url('http://www.w3.org/pub/WWW/TheProject.html', 'scheme') == 'http')
    assert(split_url('http://www.w3.org/pub/WWW/TheProject.html', 'netloc') == 'www.w3.org')
    assert(split_url('http://www.w3.org/pub/WWW/TheProject.html', 'query') == '')
    assert(split_url('http://www.w3.org/pub/WWW/TheProject.html', 'fragment') == '')

# Generated at 2022-06-23 10:34:14.335742
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:34:15.450251
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:34:24.886551
# Unit test for function split_url
def test_split_url():
    assert split_url('https://github.com/ansible/ansible/issues?labels=bug&state=open', 'netloc') == 'github.com'
    assert split_url('https://github.com/ansible/ansible/issues?labels=bug&state=open')['scheme'] == 'https'
    assert split_url('https://github.com/ansible/ansible/issues?labels=bug&state=open', 'path') == '/ansible/ansible/issues'
    assert split_url('https://github.com/ansible/ansible/issues?labels=bug&state=open', 'query') == 'labels=bug&state=open'
    assert split_url('https://github.com/ansible/ansible/issues?labels=bug&state=open', 'fragment')

# Generated at 2022-06-23 10:34:27.364252
# Unit test for constructor of class FilterModule
def test_FilterModule():
    '''
    Return True if actual Test FilterModule constructor
    '''
    assert FilterModule()

# Generated at 2022-06-23 10:34:29.512922
# Unit test for constructor of class FilterModule
def test_FilterModule():
    v = FilterModule()
    (ok, msg) = v.filters()
    print(v.filters())

test_FilterModule()

# Generated at 2022-06-23 10:34:31.997173
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """ Unit test for FilterModule.filters() """
    filter_module = FilterModule()
    assert filter_module.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:34:47.007982
# Unit test for function split_url
def test_split_url():
    u = 'http://www.example.com:80/path;param?query=arg#frag'

    assert split_url(u, 'scheme') == 'http'
    assert split_url(u, 'netloc') == 'www.example.com:80'
    assert split_url(u, 'path') == '/path;param'
    assert split_url(u, 'query') == 'query=arg'
    assert split_url(u, 'fragment') == 'frag'
    assert split_url(u, 'hostname') == 'www.example.com'
    assert split_url(u, 'port') == '80'

    # Return all components

# Generated at 2022-06-23 10:34:55.833330
# Unit test for function split_url
def test_split_url():
    ''' Test function split_url '''
    # Test a fully qualified URL
    uri = 'https://www.ansible.com/blog'
    expected = {'path': '/blog', 'netloc': 'www.ansible.com',
                'query': '', 'scheme': 'https', 'fragment': ''}
    actual = split_url(uri)
    assert expected == actual, 'Expected query for "%s"' % uri
    # Test query=''
    expected = {'netloc': 'www.ansible.com'}
    actual = split_url(uri, '')
    assert expected == actual, 'Expected query for "%s"' % uri
    # Test using a query component
    expected = 'www.ansible.com'
    actual = split_url(uri, 'netloc')

# Generated at 2022-06-23 10:35:02.284241
# Unit test for function split_url
def test_split_url():
    # test expected return
    assert split_url('http://localhost/path?q=search', 'scheme') == 'http'
    # test unexpected return
    try:
        split_url('http://localhost/path?q=search', 'foo')
    except AnsibleFilterError as e:
        assert 'urlsplit' in str(e)
        assert 'foo' in str(e)

# Generated at 2022-06-23 10:35:03.658265
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module is not None


# Generated at 2022-06-23 10:35:11.508409
# Unit test for function split_url
def test_split_url():
    url = "https://user:pass@github.com:8042/ansible/ansible/issues?page=1&per_page=10"
    expected_result = dict(scheme='https', netloc='user:pass@github.com:8042', path='/ansible/ansible/issues', query='page=1&per_page=10')

    result = split_url(url)

    assert result == expected_result, "urlsplit returned an unexpected result (got %s, expected %s)" % (result, expected_result)


# Generated at 2022-06-23 10:35:12.671023
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  assert 'urlsplit' in FilterModule.filters(None)

# Generated at 2022-06-23 10:35:23.915058
# Unit test for function split_url
def test_split_url():
    my_url = "https://username:password@www.example.com:443/this/is/a/path/to/something?query=value&another-query=another-value&morequeries=2#fragment"

    # Test with no query
    result = split_url(my_url)
    assert result['scheme'] == 'https'
    assert result['netloc'] == 'username:password@www.example.com:443'
    assert result['path'] == '/this/is/a/path/to/something'
    assert result['query'] == 'query=value&another-query=another-value&morequeries=2'
    assert result['fragment'] == 'fragment'

    # Test with valid query
    result = split_url(my_url, query='path')

# Generated at 2022-06-23 10:35:32.012276
# Unit test for function split_url
def test_split_url():

    # Test an invalid URL
    try:
        split_url("http://this_is_not_a!valid_url")
        raise RuntimeError("Expected split_url to fail to parse an invalid url")
    except AnsibleFilterError:
        pass

    # Test a valid url
    url = 'http://user:pass@example.com:8080/p/a/t/h?query=arg#frag'
    assert split_url(url, '') == {'username': 'user', 'password': 'pass', 'hostname': 'example.com', 'port': '8080', 'path': '/p/a/t/h', 'fragment': 'frag', 'params': '', 'query': 'query=arg', 'scheme': 'http'}

    # Test a valid url with an option
    assert split_url

# Generated at 2022-06-23 10:35:32.715477
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule


# Generated at 2022-06-23 10:35:34.155352
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Unit test for constructor of class FilterModule '''

    assert 1 == 1

# Generated at 2022-06-23 10:35:36.598475
# Unit test for constructor of class FilterModule
def test_FilterModule():
    try:
        constructor = SplitUrl()
    except AttributeError as e:
        print("AttributeError", e)



# Generated at 2022-06-23 10:35:38.283125
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    url_str = fm.filters()['urlsplit']

    assert url_str.filt

# Generated at 2022-06-23 10:35:43.769762
# Unit test for function split_url
def test_split_url():
    '''
    Unit tests for function split_url
    '''
    assert split_url('file:///foo/bar', query='scheme') == 'file'
    assert split_url('file:///foo/bar', query='path') == '/foo/bar'
    assert split_url('file:///foo/bar') == {'path': '/foo/bar', 'fragment': '', 'netloc': '', 'params': '', 'query': '', 'scheme': 'file'}



# Generated at 2022-06-23 10:35:46.236877
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == { 'urlsplit': split_url }


# Generated at 2022-06-23 10:35:50.956216
# Unit test for function split_url
def test_split_url():
    assert split_url('https://foo.bar/baz?query#frag') == {
        'fragment': 'frag',
        'netloc': 'foo.bar',
        'path': '/baz',
        'query': 'query',
        'scheme': 'https'
    }

# Generated at 2022-06-23 10:35:52.387714
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None


# Generated at 2022-06-23 10:35:55.436685
# Unit test for function split_url
def test_split_url():
    print('Testing split_url()')
    result = split_url('http://www.ansible.com:8080/foo/bar/baz/', 'netloc')
    assert result == 'www.ansible.com:8080'
    print('Test passed')

# Generated at 2022-06-23 10:35:57.918843
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()['urlsplit'] == split_url

# ---- Unit tests ----

# Generated at 2022-06-23 10:35:59.299744
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm


# Generated at 2022-06-23 10:36:07.012283
# Unit test for constructor of class FilterModule
def test_FilterModule():
    url_str = 'http://www.example.com/path/to/resource?query'
    alias = 'urlsplit'
    options = ['scheme', 'netloc', 'path', 'query']
    # Create a FilterModule object for test.
    obj_fm = FilterModule()
    # Test with a query
    for query in options:
        expected = split_url(url_str, query, alias)
        actual = obj_fm.filters()['urlsplit'](url_str, query, alias)
        assert expected == actual
    # Test without a query
    expected = split_url(url_str)
    actual = obj_fm.filters()['urlsplit'](url_str)
    assert expected == actual

# Generated at 2022-06-23 10:36:15.801089
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.ansible.com/index.html') == {'scheme': 'https', 'netloc': 'www.ansible.com', 'path': '/index.html', 'query': '', 'fragment': ''}

    assert split_url('https://github.com/ansible/ansible/tree/devel/lib/ansible/modules/files') == \
        {'scheme': 'https', 'netloc': 'github.com', 'path': '/ansible/ansible/tree/devel/lib/ansible/modules/files', 'query': '', 'fragment': ''}
