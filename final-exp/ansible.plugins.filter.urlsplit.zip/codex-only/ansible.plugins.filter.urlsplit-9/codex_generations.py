

# Generated at 2022-06-23 10:26:09.063016
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-23 10:26:11.152981
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_values = FilterModule.filters(FilterModule)
    assert filter_values['urlsplit'] == split_url

# Generated at 2022-06-23 10:26:11.764565
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:26:14.050118
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    unit test for constructor of class FilterModule
    """
    f = FilterModule()
    assert f is not None


# Generated at 2022-06-23 10:26:16.834248
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:26:23.837154
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    with open('test/test_filters_url.j2') as f:
        assert f.read() == "test\nraw=http://dummy:passwd@example.com:8080/path?arg=value#fragment\nscheme=http\nnetloc=dummy:passwd@example.com:8080\npath=/path\nquery=arg=value\nfragment=fragment\nparams=\nusername=dummy\npassword=passwd\nhostname=example.com\nport=8080\n"

# Generated at 2022-06-23 10:26:27.051886
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert 'urlsplit' in module.filters()


# Generated at 2022-06-23 10:26:28.639591
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(None) == {'urlsplit': split_url}

# Generated at 2022-06-23 10:26:35.409163
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
   module = FilterModule()
   assert split_url('https://www.test.com/test-path/?test=test&testtwo=testtwo','query','test') == 'test=test&testtwo=testtwo'
   assert split_url('https://www.test.com/test-path/?test=test&testtwo=testtwo','path','test') == '/test-path/'
   assert split_url('https://www.test.com/test-path/?test=test&testtwo=testtwo','netloc','test') == 'www.test.com'

# Generated at 2022-06-23 10:26:38.023930
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:26:39.126475
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None


# Generated at 2022-06-23 10:26:40.980096
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {'urlsplit': split_url}



# Generated at 2022-06-23 10:26:42.389853
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert bool(FilterModule().filters()) is True


# Generated at 2022-06-23 10:26:51.193196
# Unit test for function split_url
def test_split_url():

    url = 'https://galaxy.ansible.com/api/v1/users/'
    expected = {'netloc': 'galaxy.ansible.com', 'scheme': 'https', 'path': '/api/v1/users/', 'query': '', 'fragment': '', 'username': '', 'password': '', 'hostname': 'galaxy.ansible.com', 'port': None}
    assert split_url(url) == expected

    url = 'http://docs.ansible.com/ansible/user_guide/intro_getting_started.html.html'

# Generated at 2022-06-23 10:26:53.806283
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Unit test for split_url
    filter_module = FilterModule()
    assert filter_module.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:26:54.496753
# Unit test for constructor of class FilterModule
def test_FilterModule():
    a = FilterModule()

# Generated at 2022-06-23 10:26:56.244508
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    assert x.filters() == {'urlsplit': split_url}



# Generated at 2022-06-23 10:26:58.594773
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {'urlsplit': split_url}

# Unit tests for function split_url
import pytest


# Generated at 2022-06-23 10:26:59.299099
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # TODO
    pass


# Generated at 2022-06-23 10:27:02.181639
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    assert filters.filters()


# Generated at 2022-06-23 10:27:13.406775
# Unit test for function split_url
def test_split_url():
    uri = 'https://github.com/ansible/ansible-modules-core/blob/devel/network/eos/eos_banner.py'
    assert split_url(uri, query='scheme') == 'https'
    assert split_url(uri, query='netloc') == 'github.com'
    assert split_url(uri, query='path') == '/ansible/ansible-modules-core/blob/devel/network/eos/eos_banner.py'
    assert split_url(uri, query='fragment') == ''
    assert split_url(uri, query='query') == ''

    uri = 'https://github.com/ansible/ansible-modules-core/blob/devel/network/eos/eos_banner.py?q=test'

# Generated at 2022-06-23 10:27:22.634558
# Unit test for function split_url
def test_split_url():
    url = 'http://user:pass@Host:Port/path;parameters?query=arg#fragment'
    split_url_test = split_url(url)
    assert split_url_test['scheme'] == 'http'
    assert split_url_test['netloc'] == 'user:pass@Host:Port'
    assert split_url_test['path'] == '/path;parameters'
    assert split_url_test['query'] == 'query=arg'
    assert split_url_test['fragment'] == 'fragment'
    assert split_url_test['username'] == 'user'
    assert split_url_test['password'] == 'pass'
    assert split_url_test['hostname'] == 'Host'
    assert split_url_test['port'] == 'Port'
    assert split_

# Generated at 2022-06-23 10:27:24.830102
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert {'urlsplit' : split_url} == FilterModule().filters()

# Generated at 2022-06-23 10:27:26.567530
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module


# Generated at 2022-06-23 10:27:28.231895
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'urlsplit' in filter_module.filters()


# Generated at 2022-06-23 10:27:31.191777
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:27:39.929654
# Unit test for function split_url
def test_split_url():
    my_url = 'ftp://ftp.cwi.nl/pub/dilbert/calvin.gif'
    my_result = split_url(my_url, query="netloc")
    assert(my_result == "ftp.cwi.nl")

    my_url = 'https://pypi.org/project/netifaces/#files'
    my_result = split_url(my_url, query="scheme")
    assert(my_result == "https")

    my_url = 'http://brutal.se/2018/03/01/finally-ansible-support-for-nested-dictionaries/'
    my_result = split_url(my_url, query="path")

# Generated at 2022-06-23 10:27:49.010980
# Unit test for function split_url

# Generated at 2022-06-23 10:27:57.393872
# Unit test for function split_url
def test_split_url():
    value = 'https://user:pass@www.example.com:8080/path?query=true#fragment'
    for key in ['scheme','netloc','path','query','fragment','username','password','hostname','port']:
        assert split_url( value, key ) == urlsplit( value ).__getattribute__(key)
        assert split_url( value, key, 'custom_alias' ) == urlsplit( value ).__getattribute__( key )

    # test 'all' option
    for key in ['scheme','netloc','path','query','fragment','username','password','hostname','port']:
        assert split_url( value )[ key ] == urlsplit( value ).__getattribute__( key )

# Generated at 2022-06-23 10:27:59.269826
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Testing FilterModule class constructor
    obj = FilterModule()
    assert obj
    assert obj.filters()

# Generated at 2022-06-23 10:28:08.359762
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    test_url = 'https://ansible.com/docs?active=filters'
    assert module.filters()['urlsplit'](test_url, 'scheme') == 'https'
    assert module.filters()['urlsplit'](test_url, 'netloc') == 'ansible.com'
    assert module.filters()['urlsplit'](test_url, 'path') == '/docs'
    assert module.filters()['urlsplit'](test_url, 'query') == 'active=filters'
    assert module.filters()['urlsplit'](test_url, 'fragment') == ''
    assert module.filters()['urlsplit'](test_url, 'foo') == ''

# Generated at 2022-06-23 10:28:09.847764
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:28:19.949983
# Unit test for function split_url
def test_split_url():

    # Check that 'urlsplit' returns the proper key when its argument
    # is the corresponding value
    assert split_url('http://127.0.0.1/test/path?param=1#frag', 'netloc') == '127.0.0.1'
    assert split_url('http://127.0.0.1/test/path?param=1#frag', 'scheme') == 'http'
    assert split_url('http://127.0.0.1/test/path?param=1#frag', 'path') == '/test/path'
    assert split_url('http://127.0.0.1/test/path?param=1#frag', 'query') == 'param=1'

# Generated at 2022-06-23 10:28:26.963174
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Unit test for constructor of class FilterModule '''
    url = 'https://api.github.com/repos/ansible/ansible-modules-hashivault/commits/master'
    query = 'fragment'
    alias = 'urlsplit'
    value = split_url(url, query, alias)
    assert value == '#master'

# Generated at 2022-06-23 10:28:30.049284
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Init
    fm = FilterModule()
    assert fm is not None

    # Test
    assert len(fm.filters()) == 1
    assert 'urlsplit' in fm.filters()


# Generated at 2022-06-23 10:28:32.489772
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(None) == {'urlsplit': split_url}


# Generated at 2022-06-23 10:28:33.318755
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert(f)

# Generated at 2022-06-23 10:28:33.906173
# Unit test for constructor of class FilterModule
def test_FilterModule():
    return FilterModule()

# Generated at 2022-06-23 10:28:41.017139
# Unit test for function split_url
def test_split_url():
    urls = ['https://user:pass@127.0.0.1:5000/path?query',
            'https://user@127.0.0.1:5000/path?query',
            'https://user:pass@127.0.0.1/path?query',
            'https://user:pass@127.0.0.1:5000/path',
            'https://127.0.0.1:5000/path',
            'https://127.0.0.1/path',
            'https://user@127.0.0.1/path',
            'https://user:pass@127.0.0.1',
            'https://127.0.0.1']
    for url in urls:
        print('%s: %s' % (url, split_url(url)))

# Generated at 2022-06-23 10:28:42.421252
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()
    assert(x.filters()['urlsplit'] == split_url)


# Generated at 2022-06-23 10:28:48.802618
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # type: (str) -> None
    url = 'https://github.com/ansible/ansible/pulls/1234'
    fm = FilterModule()
    output = fm.filters()['urlsplit'](url)
    assert output.get('scheme') == 'https'
    assert output.get('netloc') == 'github.com'
    assert output.get('path') == '/ansible/ansible/pulls/1234'
    output = fm.filters()['urlsplit'](url, query='scheme')
    assert output == 'https'

# Generated at 2022-06-23 10:28:50.184589
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None



# Generated at 2022-06-23 10:28:51.469718
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    assert 'urlsplit' in filters.filters()

# Generated at 2022-06-23 10:28:52.051401
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:28:54.541458
# Unit test for function split_url
def test_split_url():
    result = split_url('https://www.ansible.com/')
    assert ('scheme', 'https') in result.items()
    assert result['scheme'] == 'https'

# Generated at 2022-06-23 10:28:56.310003
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'scheme' == FilterModule().filters()['urlsplit']('https://www.yahoo.com/', 'scheme')

# Generated at 2022-06-23 10:28:58.741677
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:29:01.773680
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:29:11.292174
# Unit test for function split_url
def test_split_url():
    '''
    Verify basic url parsing and url component querying
    '''
    url = 'http://ansible.com'
    result = split_url(url)

    # test basic url parsing
    assert result['scheme'] == 'http'
    assert result['netloc'] == 'ansible.com'
    assert result['path'] == ''
    assert result['query'] == ''
    assert result['fragment'] == ''

    # test component querying
    assert split_url(url, 'netloc') == 'ansible.com'
    assert split_url(url, 'path') == ''
    assert split_url(url, 'query') == ''
    assert split_url(url, 'fragment') == ''

    # test error handling

# Generated at 2022-06-23 10:29:18.101743
# Unit test for function split_url
def test_split_url():
    from ansible import context
    from ansible.utils.helpers import AnsibleRuntime
    context._init_global_context(AnsibleRuntime())

    import unittest

    class TestSplitUrl(unittest.TestCase):

        def test_split_url(self):
            url = 'http://www.example.com/path/to/resource?key=val'
            exp_scheme = 'http'
            exp_netloc = 'www.example.com'
            exp_path = '/path/to/resource'
            exp_query = 'key=val'

            scheme = split_url(url, query='scheme')
            netloc = split_url(url, query='netloc')
            path = split_url(url, query='path')
            query = split_url(url, query='query')

            self

# Generated at 2022-06-23 10:29:26.929427
# Unit test for function split_url
def test_split_url():
    test_url = "https://docs.python.org/3/library/urllib.parse.html#urlparse.urlsplit"
    result = split_url(test_url)
    assert result == {'path': '/3/library/urllib.parse.html#urlparse.urlsplit', 'scheme': 'https', 'query': '', 'username': None, 'hostname': 'docs.python.org', 'fragment': '', 'port': None, 'netloc': 'docs.python.org', 'password': None}

    test_url = "https://docs.python.org/3/library/urllib.parse.html#urlparse.urlsplit?q=urlsplit"
    result = split_url(test_url)

# Generated at 2022-06-23 10:29:28.099694
# Unit test for constructor of class FilterModule
def test_FilterModule():
    my_filter_module = FilterModule()
    assert isinstance(my_filter_module, FilterModule)


# Generated at 2022-06-23 10:29:29.627148
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter = FilterModule()
    assert filter is not None

# Generated at 2022-06-23 10:29:39.284221
# Unit test for function split_url
def test_split_url():
    URL_TEST = 'https://github.com/jborean93/ansible-logstash_plugin/tree/master/library'
    assert split_url(URL_TEST, query='scheme') == 'https'
    assert split_url(URL_TEST, query='netloc') == 'github.com'
    assert split_url(URL_TEST, query='path') == '/jborean93/ansible-logstash_plugin/tree/master/library'
    assert split_url(URL_TEST, query='query') == ''
    assert split_url(URL_TEST, query='fragment') == ''

# Generated at 2022-06-23 10:29:42.653532
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''
    Test method filters of class FilterModule.
    '''
    obj = FilterModule()
    assert obj.filters() == { 'urlsplit': split_url }

# Generated at 2022-06-23 10:29:45.270786
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule = FilterModule()
    assert filtermodule.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:29:49.101924
# Unit test for function split_url
def test_split_url():
    ret = split_url('http://ansible.com/docs/', 'hostname')
    assert ret == 'ansible.com'
    ret = split_url('http://ansible.com/docs/', 'path')
    assert ret == '/docs/'

# Generated at 2022-06-23 10:29:52.527738
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    url_test_filter = FilterModule()

    # Test for urlsplit filter
    results = url_test_filter.filters()['urlsplit']('https://www.example.com:8080/foo/bar?hello=world', 'query')

    assert results == 'hello=world'

# Generated at 2022-06-23 10:30:03.873069
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com:8080/foo/bar?query=baz') == {'scheme': 'http', 'netloc': 'www.example.com:8080', 'path': '/foo/bar', 'query': 'query=baz', 'fragment': ''}
    assert split_url('http://www.example.com:8080/foo/bar?query=baz', query='scheme') == 'http'
    assert split_url('http://www.example.com:8080/foo/bar?query=baz', query='netloc') == 'www.example.com:8080'
    assert split_url('http://www.example.com:8080/foo/bar?query=baz', query='path') == '/foo/bar'

# Generated at 2022-06-23 10:30:09.236615
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert split_url('https://github.com/ansible/ansible/pull/26999')['scheme'] == 'https'
    assert split_url('https://github.com/ansible/ansible/pull/26999')['scheme'] != 'http'

# Generated at 2022-06-23 10:30:17.376944
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('http://www.example.com/path/to/myfile.html?key1=value1&key2=value2#SomewhereInTheDocument', query='netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/myfile.html?key1=value1&key2=value2#SomewhereInTheDocument', query='path') == '/path/to/myfile.html'
    assert split_url('http://www.example.com/path/to/myfile.html?key1=value1&key2=value2#SomewhereInTheDocument', query='query') == 'key1=value1&key2=value2'

# Generated at 2022-06-23 10:30:29.205747
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('https://www.example.com/path/to/file?value1=1&value2=2', query='scheme') == 'https'
    assert split_url('https://www.example.com/path/to/file?value1=1&value2=2', query='netloc') == 'www.example.com'
    assert split_url('https://www.example.com/path/to/file?value1=1&value2=2', query='path') == '/path/to/file'
    assert split_url('https://www.example.com/path/to/file?value1=1&value2=2', query='query') == 'value1=1&value2=2'

# Generated at 2022-06-23 10:30:34.355191
# Unit test for function split_url
def test_split_url():

    context = {
        'ansible_facts': {
            'ansible_distribution': 'Fedora',
            'ansible_distribution_version': '27',
            'ansible_distribution_major_version': '27',
            'ansible_distribution_release': 'Rawhide',
            'ansible_os_family': 'RedHat'
        }
    }

    # From Ansible's test/units/modules/utils/test_urls.py

# Generated at 2022-06-23 10:30:38.867197
# Unit test for function split_url
def test_split_url():
    url = 'https://www.example.com/path?foo=bar&one=two#three'
    url_parsed = {
        'netloc': 'www.example.com',
        'scheme': 'https',
        'query': 'foo=bar&one=two',
        'fragment': 'three',
        'path': '/path'
    }

    for key, value in url_parsed.items():
        assert split_url(url, key) == value

    assert split_url(url) == url_parsed

# Generated at 2022-06-23 10:30:41.306217
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fmod = FilterModule()
    filters = fmod.filters()
    assert 'urlsplit' in filters

# Generated at 2022-06-23 10:30:50.136063
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_url = 'http://www.cisco.com:8080/example/test.html?id=10&name=test'
    fm = FilterModule()
    assert fm.filters()['urlsplit'](test_url) == {'path': '/example/test.html', 'fragment': '', 'scheme': 'http', 'query': 'id=10&name=test', 'netloc': 'www.cisco.com:8080'}
    assert fm.filters()['urlsplit'](test_url, query='path') == '/example/test.html'
    assert fm.filters()['urlsplit'](test_url, query='query') == 'id=10&name=test'

# Generated at 2022-06-23 10:30:58.836053
# Unit test for function split_url
def test_split_url():
    # Test with a query that exists in the results
    assert split_url('http://www.google.com', query='scheme') == 'http'

    # Test with a query that doesn't exist in the results
    try:
        split_url('http://www.google.com', query='asdf')
    except AnsibleFilterError as e:
        assert str(e) == 'urlsplit: unknown URL component: asdf'

    # Test with no query
    assert split_url('http://www.google.com')['scheme'] == 'http'

# Generated at 2022-06-23 10:31:00.256531
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:31:06.460933
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('https://www.test.com') == {'netloc': 'www.test.com', 'scheme': 'https', 'path': '', 'query': None, 'fragment': None}
    assert split_url('https://www.test.com', 'netloc') == 'www.test.com'
    assert split_url('https://www.test.com', 'foo') == 'unknown URL component: foo'


if __name__ == '__main__':
    test_FilterModule_filters()

# Generated at 2022-06-23 10:31:10.146969
# Unit test for constructor of class FilterModule
def test_FilterModule():
  assert FilterModule()

# Generated at 2022-06-23 10:31:12.362241
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:31:14.270945
# Unit test for constructor of class FilterModule
def test_FilterModule():
    results = FilterModule()
    assert results.filters()['urlsplit'] != None


# Generated at 2022-06-23 10:31:23.364865
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    #
    # Test code goes here
    #
    data1 = 'http://google.com/alpha/beta/gamma'
    data2 = 'http://google.com/'
    data3 = 'http://google.com'
    filter1 = FilterModule()
    filter1 = filter1.filters()
    if filter1.get('urlsplit'):
        splitter = filter1.get('urlsplit')
        result = splitter(data1)
    else:
        raise Exception('No such filter method: Split')
    assert (isinstance(result, dict))
    assert (result.get('netloc') == 'google.com')
    assert (result.get('path') == '/alpha/beta/gamma')

    if filter1.get('urlsplit'):
        splitter = filter1.get('urlsplit')


# Generated at 2022-06-23 10:31:24.699930
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None
    assert fm.filters() is not None

# Generated at 2022-06-23 10:31:32.715076
# Unit test for function split_url
def test_split_url():
    value = 'http://www.example.com:8080/foo/foz/fiz/biz/name.html?spam=ham&eggs=bacon'
    results = helpers.object_to_dict(urlsplit(value), exclude=['count', 'index', 'geturl', 'encode'])
    assert results['scheme'] == 'http'
    assert results['netloc'] == 'www.example.com:8080'
    assert results['path'] == '/foo/foz/fiz/biz/name.html'
    assert results['query'] == 'spam=ham&eggs=bacon'

# Generated at 2022-06-23 10:31:42.990962
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.org/path;param?query=arg#frag', 'netloc') == 'www.example.org'
    assert split_url('http://www.example.org/path;param?query=arg#frag', 'query') == 'query=arg'
    assert split_url('http://www.example.org/path;param?query=arg#frag', 'scheme') == 'http'
    assert split_url('http://www.example.org/path;param?query=arg#frag', 'unknown') == 'unknown'
    assert split_url('http://www.example.org/path;param?query=arg#frag', 'unknown', 'test_urlsplit') == 'test_urlsplit: unknown URL component: unknown'

# Generated at 2022-06-23 10:31:44.080419
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert True

# Generated at 2022-06-23 10:31:47.302547
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] == split_url

# Unit tests for method split_url of class FilterModule

# Generated at 2022-06-23 10:31:49.782228
# Unit test for constructor of class FilterModule
def test_FilterModule():

    filters = FilterModule()

    # Test noop
    noop = filters.filters()
    assert noop == {
        'urlsplit': split_url
    }

# Generated at 2022-06-23 10:31:56.932926
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('http://user:password@example.com/foo/bar?arg=value#anchor', 'scheme') == 'http'
    assert split_url('http://user:password@example.com/foo/bar?arg=value#anchor', 'netloc') == 'user:password@example.com'
    assert split_url('http://user:password@example.com/foo/bar?arg=value#anchor', 'path') == '/foo/bar'
    assert split_url('http://user:password@example.com/foo/bar?arg=value#anchor', 'query') == 'arg=value'
    assert split_url('http://user:password@example.com/foo/bar?arg=value#anchor', 'fragment') == 'anchor'


# Generated at 2022-06-23 10:32:00.061100
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()

    assert f.filters() is not None
    assert f.filters() == {'urlsplit': split_url}

# Unit tests for method split_url of class FilterModule
# TODO: Test for exceptions

# Generated at 2022-06-23 10:32:01.318543
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' test_FilterModule
    '''
    f = FilterModule()

# Generated at 2022-06-23 10:32:03.443015
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('http://www.example.com:8080/foo/bar', 'netloc') == 'www.example.com:8080'

# Generated at 2022-06-23 10:32:12.432326
# Unit test for function split_url
def test_split_url():

    """ Test for split_url """

    my_url = "http://example.com/path/to/index.html?a=1&b=2#anchor"

    assert split_url(my_url, "scheme") == "http"

    assert split_url(my_url, "netloc") == "example.com"

    assert split_url(my_url, "path") == "/path/to/index.html"

    assert split_url(my_url, "query") == "a=1&b=2"

    assert split_url(my_url, "fragment") == "anchor"

    assert split_url(my_url)["scheme"] == "http"

    assert split_url(my_url)["netloc"] == "example.com"


# Generated at 2022-06-23 10:32:14.598540
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    t = FilterModule()
    assert t.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:32:23.498571
# Unit test for function split_url
def test_split_url():

    assert split_url('http://user:pass@example.com:8080/path;param?query=arg#frag', 'scheme') == 'http'
    assert split_url('http://user:pass@example.com:8080/path;param?query=arg#frag', 'netloc') == 'user:pass@example.com:8080'
    assert split_url('http://user:pass@example.com:8080/path;param?query=arg#frag', 'path') == '/path;param'
    assert split_url('http://user:pass@example.com:8080/path;param?query=arg#frag', 'path', False) == '/path;param?query=arg#frag'

# Generated at 2022-06-23 10:32:27.243632
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module.filters()['urlsplit'] == split_url



# Generated at 2022-06-23 10:32:30.117174
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert type(FilterModule.filters) == type(lambda: 0)
    assert set(FilterModule.filters()) == {'urlsplit'}



# Generated at 2022-06-23 10:32:41.288860
# Unit test for function split_url
def test_split_url():
    url = 'http://username:password@hostname:9090/path?arg=value'
    assert split_url(url)['scheme'] == 'http'
    assert split_url(url)['netloc'] == 'username:password@hostname:9090'
    assert split_url(url)['path'] == '/path'
    assert split_url(url)['query'] == 'arg=value'
    assert split_url(url)['fragment'] == ''

    assert split_url(url, 'scheme') == 'http'
    assert split_url(url, 'netloc') == 'username:password@hostname:9090'
    assert split_url(url, 'path') == '/path'
    assert split_url(url, 'query') == 'arg=value'

# Generated at 2022-06-23 10:32:42.571908
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)

# Generated at 2022-06-23 10:32:44.574030
# Unit test for function split_url
def test_split_url():
    url = 'https://www.ansible.com/products#documentation'
    split_url(url)

# Generated at 2022-06-23 10:32:46.059800
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:32:53.908591
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """ Test if the URL can be split into its component parts. """

    url = "http://www.example.com/path/?key1=value1&key2=value2&key3=value3"

    f = FilterModule()

    # Test if the component parts of the url are properly extracted.
    assert f.filters().get("urlsplit")(url=url, query="scheme") == "http"
    assert f.filters().get("urlsplit")(url=url, query="netloc") == "www.example.com"
    assert f.filters().get("urlsplit")(url=url, query="path") == "/path/"
    assert f.filters().get("urlsplit")(url=url, query="query") == "key1=value1&key2=value2&key3=value3"

# Generated at 2022-06-23 10:32:57.358168
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Passing
    test_filter_module = FilterModule()
    assert test_filter_module is not None
    assert test_filter_module.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:33:07.575215
# Unit test for function split_url
def test_split_url():
    mock_url = 'https://user:pass@www.ansible.com:8080/foo;bar=baz/index.html?name=value#inpage'
    urlsplit_result = {'hostname': 'www.ansible.com',
                       'netloc': 'user:pass@www.ansible.com:8080',
                       'password': 'pass',
                       'path': '/foo;bar=baz/index.html',
                       'query': 'name=value',
                       'port': '8080',
                       'query_dict': {'name': 'value'},
                       'query_list': [['name', 'value']],
                       'scheme': 'https',
                       'username': 'user',
                       'fragment': 'inpage'
    }

# Generated at 2022-06-23 10:33:17.905335
# Unit test for function split_url
def test_split_url():
    split_url_result = split_url('https://example.com:8080/the/path?the=query#the-fragment')

    # Check the result is a dict
    assert isinstance(split_url_result, dict)

    # Check the dictionary contains all the components of the URL.
    assert len(split_url_result) == 9

    # Check the dictionary contains the known components of the URL.
    assert split_url_result['scheme'] == 'https'
    assert split_url_result['netloc'] == 'example.com:8080'
    assert split_url_result['path'] == '/the/path'
    assert split_url_result['query'] == 'the=query'
    assert split_url_result['fragment'] == 'the-fragment'

# Generated at 2022-06-23 10:33:23.797490
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test method filters of class FilterModule
    with pytest.raises(AnsibleFilterError):
        split_url('ansible.com', '')
        split_url('ansible.com', 'foo')
    assert split_url('https://docs.ansible.com/ansible/latest/modules/user_module.html', 'netloc') == 'docs.ansible.com'
    assert split_url('https://docs.ansible.com/ansible/latest/modules/user_module.html', 'path') == '/ansible/latest/modules/user_module.html'

# Generated at 2022-06-23 10:33:34.835703
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils._text import to_bytes

    assert split_url('http://www.example.com/path?foo=bar#baz', query='scheme') == 'http'
    assert split_url('http://www.example.com/path?foo=bar#baz', query='netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path?foo=bar#baz', query='path') == '/path'
    assert split_url('http://www.example.com/path?foo=bar#baz', query='query') == 'foo=bar'
    assert split_url('http://www.example.com/path?foo=bar#baz', query='fragment') == 'baz'


# Generated at 2022-06-23 10:33:39.585792
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' If a query is supplied, make sure it's valid then return the results.
                    If no option is supplied, return the entire dictionary'''

    results = FilterModule.filters()
    split = results.get('urlsplit')
    assert split_url(split) == 'http://example.com/'



# Generated at 2022-06-23 10:33:51.962118
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    split_url_method = filter_module.filters()['urlsplit']
    test_url = "http://www.python.org:80/foo?bar=baz#quux"
    assert split_url_method(test_url) == {'fragment': 'quux', 'scheme': 'http', 'path': '/foo', 'netloc': 'www.python.org:80', 'query': 'bar=baz'}
    assert split_url_method(test_url, 'fragment') == 'quux'
    assert split_url_method(test_url, 'scheme') == 'http'
    assert split_url_method(test_url, 'path') == '/foo'

# Generated at 2022-06-23 10:33:53.901630
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    pass

# Generated at 2022-06-23 10:33:56.137509
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_class = FilterModule()
    assert test_class.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:34:05.771594
# Unit test for function split_url
def test_split_url():

    # Prepare a test input URL
    test_url = 'https://www.example.com/bar/baz/quux.html?foo=bar'

    # Define the test cases
    option_tests = (
        dict(query='scheme', result='https'),
        dict(query='netloc', result='www.example.com'),
        dict(query='path', result='/bar/baz/quux.html'),
        dict(query='query', result='foo=bar'),
        dict(query='fragment', result=''),
    )

    # Apply the split_url function to the test URL
    results = split_url(test_url)

    # Walk through the test cases
    for test in option_tests:

        # Test to see if the URL component is in the results
        assert test['query'] in results



# Generated at 2022-06-23 10:34:07.552042
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    assert len(FilterModule.filters(FilterModule)) == 1

# ---- Ansible test cases ----

# Generated at 2022-06-23 10:34:18.269796
# Unit test for function split_url
def test_split_url():
    host = 'user:pass@test.test.test:20/test/?test=test#test'
    url = 'https://' + host
    query = 'scheme'
    result = 'https'
    assert split_url(url)['scheme'] == result
    assert split_url(url, query) == result
    result = 'test'
    assert split_url(url)['fragment'] == result
    assert split_url(url, 'fragment') == result
    result = 'test=test'
    assert split_url(url)['query']
    assert split_url(url, 'query') == result
    result = 'test'
    assert split_url(url)['path'] == result
    assert split_url(url, 'path') == result
    result = '20'
    assert split_url

# Generated at 2022-06-23 10:34:20.990910
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()

    assert filter_module.filters() == {
        'urlsplit': split_url
    }

# Generated at 2022-06-23 10:34:22.909617
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    instance = FilterModule()
    assert instance.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:34:26.751383
# Unit test for function split_url
def test_split_url():
    assert split_url('https://127.0.0.1:443/api/v1/hosts', 'hostname') == '127.0.0.1'

# Generated at 2022-06-23 10:34:35.990758
# Unit test for function split_url
def test_split_url():
    # test that split_url function can parse a url properly
    url = 'http://user:pass@www.example.com:8080/foo/bar;param?a=b&c=d#frag'
    result = split_url(url)
    assert result['netloc'] == 'user:pass@www.example.com:8080'
    assert result['scheme'] == 'http'
    assert result['path'] == '/foo/bar;param'
    assert result['query']['a'] == 'b'
    assert result['query']['c'] == 'd'
    assert result['fragment'] == 'frag'

    # test that query type (like fragment) is a string
    assert isinstance(result['fragment'], str)

    # test that query can match a URL component

# Generated at 2022-06-23 10:34:37.147159
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert True

# Generated at 2022-06-23 10:34:41.907097
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    fm = FilterModule()
    assert 'urlsplit' in fm.filters()


# Generated at 2022-06-23 10:34:43.911749
# Unit test for constructor of class FilterModule
def test_FilterModule():

    fm = FilterModule()
    assert 'urlsplit' in fm.filters()


# Generated at 2022-06-23 10:34:51.409121
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for method filters of class FilterModule '''

    # Setup
    url = 'scheme://netloc/path;parameters?query=argument#fragment'
    expected_dict = {
        'scheme': 'scheme',
        'netloc': 'netloc',
        'path': '/path;parameters',
        'query': 'query=argument',
        'fragment': 'fragment'}

    # Exercise
    filterModule = FilterModule()
    filters = filterModule.filters()
    urlsplit = filters['urlsplit']

    # Verify
    assert urlsplit(url) == expected_dict

    # Cleanup - none necessary



# Generated at 2022-06-23 10:34:56.369364
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'query' == FilterModule().filters()['urlsplit'](value = 'http://user:pass@example.com:80/foo?bar=baz#frag', query='query')
    assert '80' == FilterModule().filters()['urlsplit'](value = 'http://user:pass@example.com:80/foo?bar=baz#frag', query='port')
    assert 'frag' == FilterModule().filters()['urlsplit'](value = 'http://user:pass@example.com:80/foo?bar=baz#frag', query='fragment')
    assert 'foo' == FilterModule().filters()['urlsplit'](value = 'http://user:pass@example.com:80/foo?bar=baz#frag', query='path')

# Generated at 2022-06-23 10:34:58.553800
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')


# Generated at 2022-06-23 10:35:04.493645
# Unit test for function split_url
def test_split_url():
    test_url = 'http://username:password@host.com:8080/path?query#fragment'
    expected_result = {
        'fragment': 'fragment',
        'netloc': 'username:password@host.com:8080',
        'path': '/path',
        'query': 'query',
        'scheme': 'http',
    }
    dict_result = split_url(test_url)
    assert dict_result['scheme'] == expected_result['scheme']
    assert dict_result['netloc'] == expected_result['netloc']
    assert dict_result['path'] == expected_result['path']
    assert dict_result['query'] == expected_result['query']
    assert dict_result['fragment'] == expected_result['fragment']

    test_url

# Generated at 2022-06-23 10:35:14.387739
# Unit test for function split_url
def test_split_url():
    assert split_url(value='http://test.example.com:1234/path?query1=val1') == \
        {'path': '/path', 'fragment': '', 'netloc': 'test.example.com:1234', 'query': 'query1=val1', 'scheme': 'http', 'username': '', 'query_list': [('query1', 'val1')], 'password': '', 'hostname': 'test.example.com', 'port': 1234}
    assert split_url(value='https://user:pass@www.example.com:8080/path?query1=val1&query2=val2', query="hostname") == \
        'www.example.com'

# Generated at 2022-06-23 10:35:15.977454
# Unit test for constructor of class FilterModule
def test_FilterModule():
    split_url_filter = FilterModule()
    assert split_url == split_url_filter.filters()['urlsplit']

# Generated at 2022-06-23 10:35:17.113147
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

# Generated at 2022-06-23 10:35:28.368639
# Unit test for function split_url
def test_split_url():
    assert split_url("http://example.com/foo/bar")['scheme'] == 'http'
    assert split_url("http://example.com/foo/bar")['netloc'] == 'example.com'
    assert split_url("http://example.com/foo/bar")['path'] == '/foo/bar'
    assert split_url("http://example.com/foo/bar")['query'] == ''
    assert split_url("http://example.com/foo/bar")['fragment'] == ''
    assert split_url("http://example.com/foo/bar")['username'] == ''
    assert split_url("http://example.com/foo/bar")['password'] == ''
    assert split_url("http://example.com/foo/bar")['hostname'] == 'example.com'
    assert split_

# Generated at 2022-06-23 10:35:40.241024
# Unit test for function split_url
def test_split_url():
    import os
    import sys
    import unittest

    class SplitUrlTest(unittest.TestCase):

        def test_split_url_pass(self):
            url = 'https://127.0.0.1:13000/a/path/to/something'

            # Function object_to_dict() has been used in the function split_url().
            # function object_to_dict() is tested in test_utils.py, so it is implicit that
            # split_url() is tested here.
            filter_results = split_url(url)

            # function urlsplit() is used by split_url(), so it's tested implicitly here.
            split_results = urlsplit(url)


# Generated at 2022-06-23 10:35:45.257945
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ansible_filter = FilterModule()
    assert ansible_filter is not None

#

# Generated at 2022-06-23 10:35:47.825075
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:35:53.621601
# Unit test for function split_url
def test_split_url():
    '''
    Unit test function for split_url
    '''
    url = 'http+unix://%2Fvar%2Frun%2Fdocker.sock/v1.13/images/json'
    result = split_url(url, 'netloc')
    if result == '%2Fvar%2Frun%2Fdocker.sock':
        print('Split url successfully')
    else:
        print('Split url failed')
        print('result: ' + result)


# Generated at 2022-06-23 10:36:03.982602
# Unit test for function split_url
def test_split_url():
    filter_module = FilterModule()
    alias = 'urlsplit'
    expected_result = {'scheme': 'http', 'netloc': 'localhost:80', 'path': '/path/to/resource', 'params': '', 'query': '', 'fragment': '', 'username': '', 'password': '', 'hostname': 'localhost', 'port': '80'}
    url = 'http://localhost:80/path/to/resource'
    result = filter_module.filters()['urlsplit'](url)
    assert result == expected_result
    url = 'http://username:password@localhost:80/path/to/resource'

# Generated at 2022-06-23 10:36:13.529234
# Unit test for function split_url
def test_split_url():

    result1 = split_url('http://ansible.com/products/')
    assert result1['scheme'] == 'http'
    assert result1['netloc'] == 'ansible.com'
    assert result1['path'] == '/products/'
    assert result1['query'] == ''
    assert result1['fragment'] == ''

    result2 = split_url('http://ansible.com/products/', query='scheme')
    assert result2 == 'http'

    result3 = split_url('http://ansible.com/products/', query='netloc')
    assert result3 == 'ansible.com'

    result4 = split_url('http://ansible.com/products/', query='path')
    assert result4 == '/products/'
