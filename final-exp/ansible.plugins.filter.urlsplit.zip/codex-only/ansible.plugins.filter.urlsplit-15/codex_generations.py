

# Generated at 2022-06-23 10:26:15.271527
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    urls = [
        'http://www.google.com',
        'http://www.facebook.com/dog/cat',
    ]
    for url in urls:
        result = f.filters()['urlsplit'](url, 'scheme')
        assert 'scheme' in result.keys()

# Generated at 2022-06-23 10:26:20.334016
# Unit test for function split_url
def test_split_url():

    url = "http://www.zon.ee/private?name=ferret#nose"
    assert split_url(url) == {'scheme': 'http',
                              'netloc': 'www.zon.ee',
                              'path': '/private',
                              'params': '',
                              'query': 'name=ferret',
                              'fragment': 'nose'}
    assert split_url(url, 'query') == 'name=ferret'

# Generated at 2022-06-23 10:26:33.143592
# Unit test for function split_url
def test_split_url():
    # Import module and function to test
    import ansible.modules.extras.cloud.vmware.vmware_guest as vmware_guest
    import ansible.modules.extras.cloud.vmware.vmware_guest_template as vmware_guest_template
    import ansible.modules.extras.cloud.vmware.vmware_vm_shell as vmware_vm_shell
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.vmware import find_obj, gather_vm_facts, vmware_argument_spec, wait_for_task, connect_to_api

# Generated at 2022-06-23 10:26:34.970439
# Unit test for constructor of class FilterModule
def test_FilterModule():
  # test case when value is empty
  assert(split_url("") == '')


# Generated at 2022-06-23 10:26:38.258056
# Unit test for constructor of class FilterModule
def test_FilterModule():
    instance = FilterModule()
    assert instance.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:26:47.970304
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import os

    class args(object):
        pass

    module_args = args()

    module_args.connection = os.getenv("ANSIBLE_TEST_CONNECTION", "local")
    module_args.transport = os.getenv("ANSIBLE_TEST_TRANSPORT", "local")
    module_args.forks = 1
    module_args.module_path = os.getenv("ANSIBLE_TEST_MODULE_PATH", '/usr/share/ansible/plugins/modules')
    module_args.become = None
    module_args.become_method = None
    module_args.become_user = None
    module_args.check = False
    module_args.diff = False
    module_args.flush_cache = False
    module_args.listhosts = None
   

# Generated at 2022-06-23 10:26:58.874149
# Unit test for function split_url
def test_split_url():
    url = 'http://www.example.com:80/foo/bar?a=b&c=d&e#anchor'
    assert split_url(url) == split_url(url, '')
    assert split_url(url, 'scheme') == 'http'
    assert split_url(url, 'netloc') == 'www.example.com:80'
    assert split_url(url, 'path') == '/foo/bar'
    assert split_url(url, 'query') == 'a=b&c=d&e'
    assert split_url(url, 'fragment') == 'anchor'
    assert split_url(url, 'foo') == 'http://www.example.com:80/foo/bar?a=b&c=d&e#anchor'

# Generated at 2022-06-23 10:27:03.776833
# Unit test for function split_url
def test_split_url():
    split_url('https://github.com/ansible/ansible/blob/devel/CHANGELOG.md#21-july-2017-bug-fixes-and-release-in-progress')

# Generated at 2022-06-23 10:27:05.607507
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'urlsplit' in FilterModule.filters(None)


# Generated at 2022-06-23 10:27:11.052054
# Unit test for function split_url
def test_split_url():
    d = {
        "scheme": "http",
        "netloc": "www.cwi.nl:80",
        "path": "/%7Eguido/Python.html",
        "query": "",
        "fragment": "guido"
    }

    t = split_url('http://www.cwi.nl:80/%7Eguido/Python.html#guido')
    assert t == d

# Generated at 2022-06-23 10:27:13.573839
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert {'urlsplit': split_url} == filter_module.filters()


# Generated at 2022-06-23 10:27:14.743123
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:27:18.522451
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert isinstance(filter_module, FilterModule)
    assert filter_module.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:27:20.325721
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()
    assert x.filters() == {'urlsplit': split_url}



# Generated at 2022-06-23 10:27:22.145761
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test call of no arguments
    assert FilterModule().filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:27:24.782447
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:27:25.475922
# Unit test for constructor of class FilterModule
def test_FilterModule():
    return FilterModule()

# Generated at 2022-06-23 10:27:26.195166
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# ----------------------------------------------------

# Generated at 2022-06-23 10:27:29.611541
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    aspect = FilterModule()
    actual = aspect.filters()
    expected = { 'urlsplit': split_url }
    assert actual == expected


# Generated at 2022-06-23 10:27:30.989518
# Unit test for function split_url
def test_split_url():
    pass

# Generated at 2022-06-23 10:27:32.288860
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj is not None


# Generated at 2022-06-23 10:27:34.163051
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module is not None

# Test filter_urlsplit filter

# Generated at 2022-06-23 10:27:35.069193
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj


# Generated at 2022-06-23 10:27:43.346972
# Unit test for function split_url
def test_split_url():
    uri = 'http://username:password@example.com:8080/path?query=yes&foo=bar'
    results = split_url(uri)

    assert results['scheme'] == 'http'
    assert results['username'] == 'username'
    assert results['password'] == 'password'
    assert results['hostname'] == 'example.com'
    assert results['port'] == 8080
    assert results['path'] == '/path'
    assert results['query'] == 'query=yes&foo=bar'

# Generated at 2022-06-23 10:27:47.699848
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Test the constructor of class FilterModule '''

    # Test a normal constructor.
    try:
        fm = FilterModule()
    except:
        assert False, "Unexpected exception"

    # Test the constructor with None
    try:
        fm = FilterModule(None)
    except:
        assert False, "Unexpected exception"


# Generated at 2022-06-23 10:27:48.854656
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:27:57.784269
# Unit test for function split_url
def test_split_url():
    mycontent = 'https://www.myhost.com:123/mypath/myfile.html?foo=bar&duck=quack'
    mycontent2 = 'http://user:password@www.myhost.com:123/mypath/myfile.html?foo=bar&duck=quack'
    mycontent3 = '/mypath/myfile.html?foo=bar&duck=quack'
    mycontent4 = '/mypath/myfile.html/'
    mycontent5 = 'myhost.com:123/mypath/myfile.html?foo=bar&duck=quack'
    assert type(split_url(mycontent)) == dict
    assert split_url(mycontent5)['scheme'] is None
    assert split_url(mycontent2)['username'] == 'user'

# Generated at 2022-06-23 10:27:58.729361
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:28:08.468824
# Unit test for function split_url
def test_split_url():
    urlsplit_test1 = split_url("https://192.168.0.1/api/core/v2/namespaces/12345/apps/test", "hostname")
    if urlsplit_test1:
        hostname = urlsplit_test1
    assert hostname == '192.168.0.1'
    urlsplit_test2 = split_url("https://192.168.0.1/api/core/v2/namespaces/12345/apps/test", "netloc")
    if urlsplit_test2:
        netloc = urlsplit_test2
    assert netloc == '192.168.0.1'

# Generated at 2022-06-23 10:28:09.754956
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # pylint: disable=unused-variable
    # var: FilterModule
    FilterModule()

# Generated at 2022-06-23 10:28:10.557726
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(test_FilterModule())

# Generated at 2022-06-23 10:28:11.587698
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule(), 'filters')


# Generated at 2022-06-23 10:28:19.952119
# Unit test for function split_url
def test_split_url():
    expected = {'path': '/foo/bar', 'query': 'a=1&b=2', 'fragment': 'python_filter', 'scheme': 'http', 'netloc': 'host'}

    assert split_url('http://host/foo/bar?a=1&b=2#python_filter', 'path') == '/foo/bar'
    assert split_url('http://host/foo/bar?a=1&b=2#python_filter', 'fragment') == 'python_filter'
    assert split_url('http://host/foo/bar?a=1&b=2#python_filter', 'scheme') == 'http'
    assert split_url('http://host/foo/bar?a=1&b=2#python_filter', 'netloc') == 'host'
    assert split_url

# Generated at 2022-06-23 10:28:32.211684
# Unit test for function split_url

# Generated at 2022-06-23 10:28:40.509431
# Unit test for function split_url
def test_split_url():

    from ansible.module_utils.six.moves.urllib.parse import urlunsplit, urlparse
    from ansible.module_utils._text import to_bytes

    test_url = 'http://www.example.com/path/to?query=string'

    # Confirm that passing a valid option returns the correct value
    assert split_url(test_url, 'scheme') == 'http'
    assert split_url(test_url, 'netloc') == 'www.example.com'
    assert split_url(test_url, 'path') == '/path/to'
    assert split_url(test_url, 'query') == 'query=string'
    assert split_url(test_url, 'fragment') == ''
    assert split_url(test_url, 'username') == ''
    assert split

# Generated at 2022-06-23 10:28:50.189791
# Unit test for function split_url
def test_split_url():
    from ansible.utils.urls import split_url_argument

    def test_helper(url, query, expected):
        actual = split_url(url)
        if query:
            actual = actual[query]
        assert actual == expected

    test_helper('http://user:pass@example.org:8080/path/to/snowman?snowman=%E2%98%83&snowflake=%E2%98%80&crashed=%E2%98%A0#anchor', None, split_url_argument('http://user:pass@example.org:8080/path/to/snowman?snowman=%E2%98%83&snowflake=%E2%98%80&crashed=%E2%98%A0#anchor', check=False))
   

# Generated at 2022-06-23 10:28:51.787407
# Unit test for constructor of class FilterModule
def test_FilterModule():
    try:
        f = FilterModule()
    except:
        assert False



# Generated at 2022-06-23 10:28:59.559695
# Unit test for function split_url
def test_split_url():
    """
    Test split_url function
    """

    assert split_url('https://www.example.org/test/') == {'scheme': 'https', 'netloc': 'www.example.org', 'path': '/test/', 'query': '', 'fragment': ''}
    assert split_url('https://www.example.org/test/?a=1&b=2') == {'scheme': 'https', 'netloc': 'www.example.org', 'path': '/test/', 'query': 'a=1&b=2', 'fragment': ''}
    assert split_url('https://www.example.org/test/?a=1&b=2')['fragment'] == ''

# Generated at 2022-06-23 10:29:09.974957
# Unit test for function split_url
def test_split_url():
    parts = split_url('http://my.example.com:8080/path/to/myfile.html?key1=val1&key2=val2&key3=val3#fragment')
    assert parts['scheme'] == 'http'
    assert parts['netloc'] == 'my.example.com:8080'
    assert parts['path'] == '/path/to/myfile.html'
    assert parts['query'] == 'key1=val1&key2=val2&key3=val3'
    assert parts['fragment'] == 'fragment'

    assert split_url('http://my.example.com:8080/path/to/myfile.html?key1=val1&key2=val2&key3=val3#fragment', 'scheme') == 'http'
   

# Generated at 2022-06-23 10:29:17.360423
# Unit test for function split_url
def test_split_url():

    url = 'https://user:pass@www.example.com:8080/path/script.cgi?name=test#fragment'

    # https://docs.python.org/3/library/urllib.parse.html#urllib.parse.urlsplit
    expected = {
        "scheme": "https",
        "netloc": "user:pass@www.example.com:8080",
        "path": "/path/script.cgi",
        "query": "name=test",
        "fragment": "fragment"
    }

    result = split_url(url, 'scheme')
    assert result == expected['scheme']

    result = split_url(url, 'netloc')
    assert result == expected['netloc']

    result = split_url(url, 'path')

# Generated at 2022-06-23 10:29:18.758559
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Unit test for constructor of class FilterModule '''
    assert FilterModule()

# Generated at 2022-06-23 10:29:21.624196
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters()['urlsplit'] is split_url



# Generated at 2022-06-23 10:29:34.393521
# Unit test for function split_url

# Generated at 2022-06-23 10:29:40.250266
# Unit test for function split_url
def test_split_url():
    parts = split_url('http://example.com/foo')
    assert parts['scheme'] == 'http'
    assert parts['netloc'] == 'example.com'
    assert parts['path'] == '/foo'
    assert parts['query'] == ''
    assert parts['fragment'] == ''

    parts = split_url('http://example.com/foo', 'scheme')
    assert parts == 'http'

    parts = split_url('http://example.com/foo?bar=1', 'query')
    assert parts == 'bar=1'

# Generated at 2022-06-23 10:29:43.321572
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('https://www.google.com/', 'netloc') == 'www.google.com'



# Generated at 2022-06-23 10:29:46.041854
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:29:50.807324
# Unit test for function split_url
def test_split_url():
    """ Test split_url function """

    assert split_url('https://www.ansible.com/') == {
        'scheme': 'https',
        'netloc': 'www.ansible.com',
        'path': '',
        'params': '',
        'query': '',
        'fragment': ''
    }

# Generated at 2022-06-23 10:29:54.739560
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'urlsplit': split_url}, 'FilterModule.filters() function return incorrect value'

# Generated at 2022-06-23 10:29:56.736168
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    tfm = FilterModule()
    assert 'urlsplit' in tfm.filters()


# Generated at 2022-06-23 10:29:58.296847
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule()) == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:29:59.134421
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert False


# Generated at 2022-06-23 10:30:01.537698
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """ test_FilterModule_filters - Test function 'filters' of class FilterModule
    """
    fm = FilterModule()
    assert fm.filters()['urlsplit'] == split_url



# Generated at 2022-06-23 10:30:04.324954
# Unit test for function split_url
def test_split_url():
    parts = "https://wiki.ansible.com/display/docsite/Ansible+2.5+New+Features+and+Improvements+by+Category"
    assert 'scheme' in split_url(parts)

# Generated at 2022-06-23 10:30:07.586465
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters()
    assert FilterModule.filters(f)


# Generated at 2022-06-23 10:30:09.500597
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:30:11.726328
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:30:12.550722
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None


# Generated at 2022-06-23 10:30:20.614876
# Unit test for function split_url

# Generated at 2022-06-23 10:30:25.615838
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for method filters of class FilterModule '''

    # Set up test object
    filter_module = FilterModule()

    # Verify filters method returns expected dictionary
    assert filter_module.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:30:27.870240
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = {
        'urlsplit': split_url
    }
    assert fm.filters() == filters

# Generated at 2022-06-23 10:30:28.445129
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:30:30.629332
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fl_obj = FilterModule()
    assert fl_obj.__class__.__name__ == 'FilterModule'


# Generated at 2022-06-23 10:30:32.309709
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule) == {
        'urlsplit': split_url
    }



# Generated at 2022-06-23 10:30:34.417623
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

    assert 'scheme' == fm.filters()['urlsplit']('http://www.ansible.com', 'scheme')

# Generated at 2022-06-23 10:30:37.168038
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule.__doc__ is not None
    assert hasattr(FilterModule, 'filters')
    assert FilterModule.filters.__doc__ == "Return a dictionary mapping filter names to filter functions."
    assert type(FilterModule.filters()) is dict


# Generated at 2022-06-23 10:30:48.572980
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils.six.moves.urllib.parse import parse_qs, urlsplit

    def _test(url, query, expected):
        result = split_url(url, query=query)
        assert result == expected


# Generated at 2022-06-23 10:30:49.620088
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None

# Generated at 2022-06-23 10:30:55.757953
# Unit test for function split_url
def test_split_url():
    assert split_url('http://foo/bar:80/?query', query='scheme') == 'http'
    assert split_url('http://foo/bar:80/?query', query='netloc') == 'foo'
    assert split_url('http://foo/bar:80/?query', query='path') == '/bar:80/'
    assert split_url('http://foo/bar:80/?query', query='query') == 'query'
    assert split_url('http://foo/bar:80/?query', query='fragment') == ''

    result = split_url('http://foo/bar:80/?query', query=None)
    assert result['scheme'] == 'http'
    assert result['netloc'] == 'foo'
    assert result['path'] == '/bar:80/'

# Generated at 2022-06-23 10:31:06.498407
# Unit test for function split_url
def test_split_url():

    url = 'http://username:password@example.net:443/directory/file?query=true#anchor'
    results = split_url(url)

    assert results['scheme'] == 'http'
    assert results['netloc'] == 'username:password@example.net:443'
    assert results['path'] == '/directory/file'
    assert results['query'] == 'query=true'
    assert results['fragment'] == 'anchor'

    username, password = split_url(url, 'netloc', 'split_url').split('@')[0].split(':', 1)
    assert username == 'username'
    assert password == 'password'

    assert split_url(url, 'path', 'split_url') == '/directory/file'
    assert split_url(url, 'query', 'split_url')

# Generated at 2022-06-23 10:31:19.680262
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/only/to', query='netloc') == 'www.example.com'
    assert split_url('http://www.example.com/only/to', query='path') == '/only/to'
    assert split_url('http://www.example.com/only/to') == {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/only/to',
        'query': '',
        'fragment': ''
    }
    assert split_url('http://www.example.com/only/to', query='query') == ''
    assert split_url('http://www.example.com/only/to', query='fragment') == ''

# Generated at 2022-06-23 10:31:27.543880
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert isinstance(fm, object)
    url = '/foo/bar/baz'
    result_dict = {'netloc': '', 'path': '/foo/bar/baz', 'scheme': '', 'query': '', 'fragment': ''}

    # Test with simple string
    result = fm.filters()['urlsplit'](url)
    assert result==result_dict

    # Test with options
    result = fm.filters()['urlsplit'](url, query='path')
    assert result=='/foo/bar/baz'



# Generated at 2022-06-23 10:31:35.136078
# Unit test for function split_url
def test_split_url():
    url = 'http://username:password@hostname:9090/path?arg=value#anchor'
    print(split_url(url))
    print(split_url(url, 'scheme'))
    print(split_url(url, 'netloc'))
    print(split_url(url, 'username'))
    print(split_url(url, 'password'))
    print(split_url(url, 'host'))
    print(split_url(url, 'port'))
    print(split_url(url, 'path'))
    print(split_url(url, 'query'))
    print(split_url(url, 'anchor'))
    print(split_url(url, 'params'))
    print(split_url(url, 'unknown'))


# Generated at 2022-06-23 10:31:46.067266
# Unit test for function split_url
def test_split_url():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from pprint import pprint

    # Basic URL
    result = split_url('https://test.com:8080/path/to/something?key1=val1&key2=val2')
    assert 'scheme' in result
    assert result['scheme'] == 'https'
    assert result['netloc'] == 'test.com:8080'
    assert result['path'] == '/path/to/something'
    assert result['query'] == 'key1=val1&key2=val2'
    assert result['username'] == ''
    assert result['password'] == ''
    assert result['hostname'] == 'test.com'
    assert result['port'] == '8080'
    assert result['fragment'] == ''

    # Query specific

# Generated at 2022-06-23 10:31:50.184534
# Unit test for function split_url
def test_split_url():
    assert ('example.com' == split_url('http://example.com/path', 'netloc'))
    assert ('http' == split_url('http://example.com/path', 'scheme'))
    assert ('/path' == split_url('http://example.com/path', 'path'))

# Generated at 2022-06-23 10:31:57.226246
# Unit test for function split_url
def test_split_url():
    module = split_url('http://www.example.com:80/foo/bar?query=test&args=foo#frag', 'scheme')
    assert module == 'http'
    module = split_url('http://www.example.com:80/foo/bar?query=test&args=foo#frag', 'netloc')
    assert module == 'www.example.com:80'
    module = split_url('http://www.example.com:80/foo/bar?query=test&args=foo#frag', 'path')
    assert module == '/foo/bar'
    module = split_url('http://www.example.com:80/foo/bar?query=test&args=foo#frag', 'query')
    assert module == 'query=test&args=foo'

# Generated at 2022-06-23 10:31:58.486916
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert "urlsplit" in filter_module.filters()


# Generated at 2022-06-23 10:32:10.048844
# Unit test for function split_url
def test_split_url():
    '''
    Unit test for the split_url filter
    '''

    # Setup for test
    url = "http://www.example.com/path/to/the/uri?query=string&for=testing"

    # Test with no query value
    results = split_url(url)
    assert results['scheme'] == 'http'
    assert results['netloc'] == 'www.example.com'
    assert results['path'] == '/path/to/the/uri'
    assert results['query'] == 'query=string&for=testing'
    assert results['fragment'] == ''

    # Test with query value of scheme
    results = split_url(url, 'scheme')
    assert results == 'http'

    # Test with query value of netloc
    results = split_url(url, 'netloc')


# Generated at 2022-06-23 10:32:12.977441
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:32:22.722141
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    test = FilterModule()

    # test 0
    url = 'http://www.python.org/fish.cgi?id=something'

    url_split_dict = {
        'scheme': u'http',
        'netloc': u'www.python.org',
        'path': u'/fish.cgi',
        'query': u'id=something',
        'fragment': u''
    }

    assert url_split_dict == test.filters()['urlsplit'](url)

    # test 1
    url = 'http://www.python.org/fish.cgi'


# Generated at 2022-06-23 10:32:25.961411
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filterModule = FilterModule();
    assert filterModule is not None


# Generated at 2022-06-23 10:32:34.462787
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.cyberciti.biz/faq/?p=26801', 'scheme') == 'http'
    assert split_url('http://www.cyberciti.biz/faq/?p=26801', 'netloc') == 'www.cyberciti.biz'
    assert split_url('http://www.cyberciti.biz/faq/?p=26801', 'path') == '/faq/'
    assert split_url('http://www.cyberciti.biz/faq/?p=26801', 'query') == 'p=26801'
    assert split_url('http://www.cyberciti.biz/faq/?p=26801', 'fragment') == ''

# Generated at 2022-06-23 10:32:35.812264
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Create instance of FilterModule
    FM = FilterModule()
    assert FM is not None

# Generated at 2022-06-23 10:32:43.227595
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    results = {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/something/', 'query': '', 'fragment': ''}
    assert FilterModule.filters(None)['urlsplit']('http://www.example.com/path/to/something/') == results
    assert FilterModule.filters(None)['urlsplit']('http://www.example.com/path/to/something/', 'path') == '/path/to/something/'

# Generated at 2022-06-23 10:32:52.313223
# Unit test for function split_url
def test_split_url():

    # Test input with query
    value = 'https://github.com/ansible/ansible/issues/1025'
    output = {'scheme': 'https', 'netloc': 'github.com', 'path': '/ansible/ansible/issues/1025', 'username': '', 'password': '', 'params': '', 'query': '', 'fragment': ''}
    assert split_url(value, 'scheme') == output['scheme']
    assert split_url(value, 'netloc') == output['netloc']
    assert split_url(value, 'path') == output['path']
    assert split_url(value, 'username') == output['username']
    assert split_url(value, 'params') == output['params']
    assert split_url(value, 'query') == output['query']
   

# Generated at 2022-06-23 10:32:53.650650
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-23 10:32:57.841489
# Unit test for function split_url
def test_split_url():

    parsed = split_url(
        'hTTp://AnSiBlE.CoM/PaTh/To/a/websiTe.html?Key1=Value2&Key2=Value2',
        query='scheme'
    )

    assert parsed == "http"



# Generated at 2022-06-23 10:33:07.901384
# Unit test for function split_url
def test_split_url():
    url = "https://www.ansible.com/ansible-tower"
    result = split_url(url)
    assert result['scheme'] == 'https'
    assert result['netloc'] == 'www.ansible.com'
    assert result['path'] == '/ansible-tower'
    assert result['query'] == ''
    assert result['fragment'] == ''

    result = split_url(url, 'path')
    assert result == '/ansible-tower'

    result = split_url(url, 'netloc')
    assert result == 'www.ansible.com'

    result = split_url(url, 'scheme')
    assert result == 'https'

    result = split_url(url, 'query')
    assert result == ''
    result = split_url(url, 'fragment')


# Generated at 2022-06-23 10:33:18.363204
# Unit test for function split_url
def test_split_url():
    import json

    assert split_url('https://www.example.com/path/to/file') == {
        'scheme': 'https',
        'netloc': 'www.example.com',
        'path': '/path/to/file',
        'query': '',
        'fragment': ''
    }

    assert split_url('https://www.example.com/path/to/file', 'path') == '/path/to/file'

    try:
        split_url('http://www.example.com', 'bad_option')
    except AnsibleFilterError as e:
        assert str(e) == 'urlsplit: unknown URL component: bad_option'
    else:
        assert False, 'AnsibleFilterError not raised for bad query'

    assert split_url('https://www.example.com')

# Generated at 2022-06-23 10:33:20.660667
# Unit test for function split_url
def test_split_url():
    from urlparse import urlparse
    url = urlparse('https://github.com/ansible/ansible')
    assert split_url(url, 'scheme') == 'https'

# Generated at 2022-06-23 10:33:32.800296
# Unit test for function split_url
def test_split_url():
    result = split_url('https://www.ansible.com/')
    assert result.get('scheme') == 'https'
    assert result.get('netloc') == 'www.ansible.com'
    assert result.get('path') == '/'

    result = split_url('https://www.ansible.com:8000/')
    assert result.get('scheme') == 'https'
    assert result.get('netloc') == 'www.ansible.com:8000'
    assert result.get('path') == '/'

    result = split_url('https://www.ansible.com/foo/bar')
    assert result.get('scheme') == 'https'
    assert result.get('netloc') == 'www.ansible.com'
    assert result.get('path') == '/foo/bar'



# Generated at 2022-06-23 10:33:35.740064
# Unit test for function split_url
def test_split_url():
    """
    Test that split_url() works properly by verifying the output of a known good
    value.
    """
    import types

    uri = 'https://www.ansible.com/index.html?q=search&a=b'
    result = split_url(uri, 'query')

    assert type(result) is str
    assert 'q=search&a=b' == result


# Generated at 2022-06-23 10:33:49.478399
# Unit test for function split_url

# Generated at 2022-06-23 10:33:54.710345
# Unit test for function split_url
def test_split_url():
    assert {'netloc': 'example.com', 'params': '', 'path': '', 'scheme': 'http', 'query': '', 'fragment': ''} == split_url('http://example.com/', '', '')
    assert {'netloc': 'example.com', 'params': '', 'path': '', 'scheme': 'http', 'query': '', 'fragment': ''} == split_url('http://example.com/')
    assert 'http' == split_url('http://example.com/', 'scheme', 'urlsplit')
    assert 'http://example.com' == split_url('http://example.com/', 'netloc', 'urlsplit')
    assert '/index.html' == split_url('http://example.com/index.html', 'path', 'urlsplit')
   

# Generated at 2022-06-23 10:33:56.957276
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_plugin = FilterModule()
    assert 'urlsplit' in filter_plugin.filters()

# ---- Ansible filter unit tests ----

# Generated at 2022-06-23 10:33:58.910828
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urlsplit'] is split_url

# Generated at 2022-06-23 10:34:00.574617
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(None) == {'urlsplit': split_url}


# Generated at 2022-06-23 10:34:04.541752
# Unit test for function split_url
def test_split_url():
    value = 'http://www.ansible.com:80/docs/user_guide/playbooks_reuse_includes.html?id=1'
    result = split_url(value, query='path')
    expected_result = '/docs/user_guide/playbooks_reuse_includes.html'
    assert result == expected_result

# Generated at 2022-06-23 10:34:08.145100
# Unit test for function split_url
def test_split_url():
    assert split_url("https://api.github.com/users/ansible/repos?per_page=10") == [
        ('https', 'api.github.com', '/users/ansible/repos', '', 'per_page=10', '')]

# Generated at 2022-06-23 10:34:19.478288
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('http://www.python.org/sth/something/') == {
        'netloc': 'www.python.org',
        'path': '/sth/something/',
        'scheme': 'http',
        'fragment': '',
        'query': ''}
    assert split_url('http://www.python.org/sth/something/#ThisIsAnAnchor?with=query&&string') == {
        'netloc': 'www.python.org',
        'path': '/sth/something/',
        'scheme': 'http',
        'fragment': 'ThisIsAnAnchor',
        'query': 'with=query&&string'}

# Generated at 2022-06-23 10:34:20.852983
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None

# Generated at 2022-06-23 10:34:22.468833
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urlsplit'].__name__ == 'split_url'

# Generated at 2022-06-23 10:34:33.444151
# Unit test for function split_url
def test_split_url():

    # Test a basic URL
    assert_equal(split_url(
        'http://www.example.com:8080/foo#bar?baz=qux'),
        {'fragment': 'bar', 'netloc': 'www.example.com:8080', 'path': '/foo', 'query': 'baz=qux', 'scheme': 'http'}
    )

    # Test query option
    assert_equal(split_url(
        'http://www.example.com:8080/foo#bar?baz=qux', query='fragment'),
        'bar'
    )

    # Test exception
    with assert_raises(AnsibleFilterError):
        split_url('http://www.example.com:8080/foo#bar?baz=qux', query='deepdish')

# Generated at 2022-06-23 10:34:37.725251
# Unit test for function split_url
def test_split_url():

    assert split_url('http://ansible.com/api/v1', 'path') == '/api/v1'

# Generated at 2022-06-23 10:34:38.602808
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert {
        'urlsplit': split_url
    } == FilterModule().filters()


# Generated at 2022-06-23 10:34:44.596498
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)
    assert isinstance(FilterModule().filters(), dict)
    assert isinstance(FilterModule().filters()['urlsplit'], FilterModule)



# Generated at 2022-06-23 10:34:48.123590
# Unit test for function split_url
def test_split_url():
    ret = split_url(
        value='https://user:pass@www.example.com:80/path;param1=value1?query=val#frag',
        query='scheme'
    )
    assert ret == 'https'
    return True

# Generated at 2022-06-23 10:34:48.978801
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:34:55.137780
# Unit test for function split_url
def test_split_url():
    url = 'http://www.ansible.com:8080/docs/modules'
    result = split_url(url)
    assert result['scheme'] == 'http'
    assert result['netloc'] == 'www.ansible.com:8080'
    assert result['path'] == '/docs/modules'
    assert result['query'] == ''
    assert result['fragment'] == ''

    result = split_url(url, 'scheme')
    assert result == 'http'

    result = split_url(url, 'netloc')
    assert result == 'www.ansible.com:8080'

    result = split_url(url, 'path')
    assert result == '/docs/modules'

    result = split_url(url, 'query')
    assert result == ''


# Generated at 2022-06-23 10:35:06.843743
# Unit test for function split_url
def test_split_url():

    # Test an IPv6 URL.
    url = 'http://[::1]:8080/foo/bar?baz=qux'

    # Test to ensure that the right number of items are returned
    assert(len(split_url(url)) == 6)

    # Test to ensure all components are correct.
    assert(split_url(url) == {'scheme': 'http', 'netloc': '[::1]:8080', 'path': '/foo/bar', 'query': 'baz=qux', 'fragment': '', 'username': None, 'password': None, 'hostname': '::1', 'port': 8080})

    # Test specific elements.
    assert(split_url(url, query='scheme') == 'http')

# Generated at 2022-06-23 10:35:09.348869
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:35:16.565530
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/myfile.html?key1=value1&key2=value2#SomeText', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/myfile.html?key1=value1&key2=value2#SomeText', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/myfile.html?key1=value1&key2=value2#SomeText', 'path') == '/path/to/myfile.html'

# Generated at 2022-06-23 10:35:23.766710
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    u = urlsplit("http://www.python.org:80/doc/#frag")
    assert dict(urlsplit("http://www.python.org:80/doc/#frag", 'scheme')) == dict(u.scheme), "scheme"
    assert dict(urlsplit("http://www.python.org:80/doc/#frag", 'netloc')) == dict(u.netloc), "netloc"
 

# Generated at 2022-06-23 10:35:26.085147
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()

    # Assert split_url
    assert filters['urlsplit']('http://www.w3schools.com/html/html_forms.asp') == {'netloc': 'www.w3schools.com', 'scheme': 'http', 'path': '/html/html_forms.asp', 'query': '', 'fragment': ''}

# Generated at 2022-06-23 10:35:27.151382
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module.filters()['urlsplit']


# Generated at 2022-06-23 10:35:28.968209
# Unit test for constructor of class FilterModule
def test_FilterModule():
  assert(FilterModule.__name__ == 'FilterModule')


# Generated at 2022-06-23 10:35:31.640552
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:35:41.961374
# Unit test for function split_url
def test_split_url():
    test_value = 'http://www.ansible.com/foo/bar?a=1&b=2&private=yes'
    results = split_url(value=test_value, query='scheme', alias='urlsplit_test')
    assert results == 'http', "Expected results to be 'http' but was: %s" % results

    results = split_url(value=test_value, query='netloc', alias='urlsplit_test')
    assert results == 'www.ansible.com', "Expected results to be 'www.ansible.com' but was: %s" % results

    results = split_url(value=test_value, query='path', alias='urlsplit_test')
    assert results == '/foo/bar', "Expected results to be '/foo/bar' but was: %s" % results

   

# Generated at 2022-06-23 10:35:48.030955
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Test method filters of class FilterModule '''

    obj = FilterModule()
    with pytest.raises(AnsibleFilterError) as exc_info:
        obj.filters()

    assert 'unknown URL component: test' in str(exc_info.value)



# Generated at 2022-06-23 10:35:50.718519
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import doctest
    doctest.testmod(extraglobs={'urlsplit': split_url})

if __name__ == '__main__':
    test_FilterModule()

# Generated at 2022-06-23 10:35:55.643556
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test for no parameters
    fm = FilterModule()
    filters = fm.filters()
    result = filters['urlsplit']('https://docs.ansible.com')
    assert result == {'netloc': 'docs.ansible.com',
                      'path': '',
                      'query': '',
                      'fragment': '',
                      'scheme': 'https',
                      'username': '',
                      'password': ''}

# Generated at 2022-06-23 10:35:57.959267
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] == split_url



# Generated at 2022-06-23 10:36:00.206522
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:36:08.258108
# Unit test for function split_url
def test_split_url():
    split = split_url
    assert split('http://docs.ansible.com/ansible/playbooks.html') == {
        'fragment': '',
        'hostname': 'docs.ansible.com',
        'netloc': 'docs.ansible.com',
        'password': None,
        'path': '/ansible/playbooks.html',
        'query': '',
        'scheme': 'http',
        'username': None
    }

    assert split('http://docs.ansible.com/ansible/playbooks.html', 'path') == '/ansible/playbooks.html'

    assert split('http://docs.ansible.com/ansible/playbooks.html', 'scheme') == 'http'

# Generated at 2022-06-23 10:36:16.442861
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/app/?key=value') == {
        'hostname': 'www.example.com',
        'netloc': 'www.example.com',
        'path': '/path/to/app/',
        'port': None,
        'query': 'key=value',
        'scheme': 'http',
        'username': None,
        'password': None,
        'fragment': None
    }
    assert split_url('http://www.example.com/path/to/app/?key=value', 'path') == '/path/to/app/'
    assert split_url('http://www.example.com/path/to/app/?key=value', 'netloc') == 'www.example.com'