

# Generated at 2022-06-23 10:26:10.925071
# Unit test for constructor of class FilterModule
def test_FilterModule():

    assert(callable(FilterModule))



# Generated at 2022-06-23 10:26:20.157918
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # create an empty FilterModule object
    from ansible.plugins.filter.url import FilterModule
    fm = FilterModule()

    # Declare test data
    test_url = 'http://ansible.com/foo/bar?a=b'
    test_url_list = ['http://ansible.com/foo/bar?a=b', 'http://ansible.com/a/b']
    test_url_invalid = '://ansible.com/foo/bar?a=b'

    # test split_url()
    fm_filters = fm.filters()['urlsplit']

    # Assert that test_url is a URL
    assert isinstance(test_url, str)

    # Assert that test_url_list is a list
    assert isinstance(test_url_list, list)

   

# Generated at 2022-06-23 10:26:22.087167
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Arrange
    filter_module = FilterModule()
    filters = filter_module.filters()

    # Assert
    assert filters is not None
    assert 'urlsplit' in filters



# Generated at 2022-06-23 10:26:34.361678
# Unit test for function split_url
def test_split_url():

    def test(value, query, expect):
        result = split_url(value, query)
        assert result == expect, 'split_url returned "%s" instead of "%s" for %s query of %s' % (result, expect, query, value)

    # Test with no query
    result = split_url('http://www.example.com/path')
    assert result['scheme'] == 'http', 'split_url returned "%s" instead of "http" for scheme' % result['scheme']
    assert result['netloc'] == 'www.example.com', 'split_url returned "%s" instead of "www.example.com" for netloc' % result['netloc']
    assert result['path'] == '/path', 'split_url returned "%s" instead of "/path" for path' % result['path']

# Generated at 2022-06-23 10:26:37.172000
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    mod = FilterModule()
    assert mod.filters() == {'urlsplit': split_url}



# Generated at 2022-06-23 10:26:44.279804
# Unit test for function split_url
def test_split_url():
    u = 'https://www.example.com/path/to/resource?key=value'
    assert split_url(u)['scheme'] == 'https'
    assert split_url(u)['netloc'] == 'www.example.com'
    assert split_url(u)['path'] == '/path/to/resource'
    assert split_url(u)['query'] == 'key=value'
    assert split_url(u)['fragment'] == ''

# Generated at 2022-06-23 10:26:55.129207
# Unit test for function split_url
def test_split_url():
    url = 'http://user@localhost:5000/v2.0/?catalog'
    result = {
        'hostname': 'localhost',
        'fragment': '',
        'path': '/v2.0/',
        'port': '5000',
        'query': 'catalog',
        'scheme': 'http',
        'username': 'user'
    }
    assert result == split_url(url)

    assert 'http' == split_url(url, query='scheme')


# Generated at 2022-06-23 10:27:02.610567
# Unit test for function split_url
def test_split_url():
    # Success test case
    # 1. Successfully split a valid url
    url = "http://user:pass@www.ansible.com:80/x/y.html;p?q=z#m"
    results = split_url(url)
    assert results == {
        'netloc': 'user:pass@www.ansible.com:80',
        'fragment': 'm',
        'username': 'user',
        'password': 'pass',
        'hostname': 'www.ansible.com',
        'port': '80',
        'scheme': 'http',
        'path': '/x/y.html;p',
        'query': 'q=z'
    }, "Test failed for url {}".format(url)

    # 2. Correctly return a specific part of url given a query
   

# Generated at 2022-06-23 10:27:06.568680
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Test for FilterModule constructor '''
    # Test for FilterModule constructor
    fm = FilterModule()
    assert fm is not None
    assert isinstance(fm, FilterModule)


# Generated at 2022-06-23 10:27:11.132929
# Unit test for function split_url
def test_split_url():
    assert split_url('http://user:pass@www.example.com:2000/foo?bar=baz') == {
        'scheme': 'http',
        'netloc': 'user:pass@www.example.com:2000',
        'path': '/foo',
        'query': 'bar=baz',
        'fragment': ''
    }


# Generated at 2022-06-23 10:27:19.936464
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for method filters of class FilterModule '''
    expected = {
        'port': None,
        'fragment': '',
        'scheme': u'http',
        'hostname': u'www.google.com',
        'netloc': u'www.google.com',
        'query': u'',
        'path': u'/',
        'username': None,
        'password': None
    }

    fm = FilterModule()
    filters = fm.filters()
    assert filters['urlsplit']('http://www.google.com/') == expected


# Generated at 2022-06-23 10:27:22.399208
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule().filters()
    assert isinstance(f, dict)
    assert len(f.keys()) == 1
    assert "urlsplit" in f.keys()



# Generated at 2022-06-23 10:27:24.829980
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_class = FilterModule()
    assert test_class is not None


# Generated at 2022-06-23 10:27:29.563261
# Unit test for function split_url
def test_split_url():
    url = 'https://ansible.com/utils/urlsplit?select=blah&from=urlsplit'
    query = 'query'
    expected_result = 'select=blah&from=urlsplit'

    actual_result = split_url(url=url, query=query)
    print(expected_result)
    print(actual_result)

    assert expected_result == actual_result

# Generated at 2022-06-23 10:27:30.937826
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:27:31.898326
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() is not None

# Generated at 2022-06-23 10:27:33.350232
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:27:38.325316
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """ urlsplit filter unit tests """
    fmod = FilterModule()
    if hasattr(fmod, 'filters'):
        filter_list = fmod.filters()
        if isinstance(filter_list, dict):
            # check if the filter 'urlsplit' is implemented
            assert 'urlsplit' in filter_list.keys()
            # check if it's a callable
            assert callable(filter_list['urlsplit'])


# Generated at 2022-06-23 10:27:40.811286
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert type(FilterModule()) == FilterModule


# Generated at 2022-06-23 10:27:49.485049
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  from ansible.module_utils.six.moves.urllib.parse import urlsplit

  filter_module = FilterModule()
  urls = {
    'https://docs.ansible.com/ansible/latest/plugins/filter/uri.html': {
      'scheme': 'https',
      'netloc': 'docs.ansible.com',
      'path': '/ansible/latest/plugins/filter/uri.html',
      'params': '',
      'query': '',
      'fragment': ''
    },
    'ansible://library': {
      'scheme': 'ansible',
      'netloc': 'library',
      'path': '',
      'params': '',
      'query': '',
      'fragment': ''
    }
  }


# Generated at 2022-06-23 10:27:57.134947
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils import basic

    assertion = basic.AnsibleModule(argument_spec={
        'option': {
            'type': 'str',
            'default': 'fragment',
            'choices': ['scheme', 'netloc', 'path', 'query', 'fragment']
        }
    }).fail_json
    test_url = 'https://www.google.com/search?q=ansible+filter+examples'
    results = split_url(test_url, assertion('option'))
    assert results == ['scheme', 'netloc', 'path', 'query', 'fragment'][assertion('option')]

# Generated at 2022-06-23 10:27:58.974584
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:28:00.566053
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None

# Generated at 2022-06-23 10:28:03.870361
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    results = fm.filters()
    assert results['urlsplit'] == split_url

# Unit tests for method split_url of class FilterModule

# Generated at 2022-06-23 10:28:08.432676
# Unit test for function split_url
def test_split_url():
    # Test with query
    assert split_url('https://ansible.com', query='scheme') == 'https'

    # Test with no query
    assert split_url('https://ansible.com')['netloc'] == 'ansible.com'

    # Test with invalid query
    try:
        split_url('https://ansible.com', query='bad')
    except AnsibleFilterError:
        pass
    else:
        assert False

# Generated at 2022-06-23 10:28:09.885189
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:28:19.945705
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    def make_instance(args, kwargs):
        f = FilterModule()
        return f

    # Generated:
    # def test_FilterModule_filters_urlsplit_instance(self):
    #    return self.run_function(['urlsplit'], self.make_instance([], {}))
    #
    # # Generated:
    # def test_FilterModule_filters_urlsplit_instance_w_args(self):
    #    return self.run_function(['urlsplit'], self.make_instance(['one', 'two'], {}))
    #
    # # Generated:
    # def test_FilterModule_filters_urlsplit_instance_w_kwargs(self):
    #    return self.run_function(['urlsplit'], self.make_instance([], {'one': 1

# Generated at 2022-06-23 10:28:22.440673
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-23 10:28:23.758489
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() is not None

# Generated at 2022-06-23 10:28:34.050090
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''Unit test for method filters of class FilterModule'''

    # Create a new class of type FilterModule
    mod = FilterModule()

    # Define a URL-encoded string value
    url = 'http://www.example.com/path/to/myfile.html?key1=value1&key2=value2#InTheDocument'

    # Define the dict of expected return values for the urlsplit method of FilterModule
    expected_dict = {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path/to/myfile.html', 'query': 'key1=value1&key2=value2', 'fragment': 'InTheDocument'}


# Generated at 2022-06-23 10:28:36.118210
# Unit test for constructor of class FilterModule
def test_FilterModule():
    result = split_url("https://docs.ansible.com/ansible/latest/modules/package_module.html")
    print(result)

# Generated at 2022-06-23 10:28:40.429584
# Unit test for function split_url
def test_split_url():
    split_url('https://github.com/ansible/ansible', query='scheme') == 'https'

# Generated at 2022-06-23 10:28:42.443547
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()


# Generated at 2022-06-23 10:28:45.403493
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f1 = FilterModule()
    assert f1.filters().get('urlsplit') is split_url

# Generated at 2022-06-23 10:28:47.552744
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urlsplit' in filters

# Generated at 2022-06-23 10:28:50.102043
# Unit test for constructor of class FilterModule
def test_FilterModule():
    '''
    Test for constructor of class FilterModule
    '''
    sFilterModule = FilterModule()
    assert(sFilterModule is not None)



# Generated at 2022-06-23 10:28:58.423153
# Unit test for function split_url
def test_split_url():
    test = split_url('http://www.example.com:8080/foo?bar=baz')
    assert test == dict(scheme='http',
                        netloc='www.example.com:8080',
                        path='/foo',
                        query='bar=baz',
                        fragment='')

    test = split_url('http://www.example.com:8080/foo?bar=baz', query='scheme')
    assert test == 'http'

    try:
        test = split_url('http://www.example.com:8080/foo?bar=baz', query='foo')
        assert test == 'http'
    except AnsibleFilterError:
        pass

    test = split_url('http://www.example.com:8080/foo?bar=baz', query='foo', alias='foo')

# Generated at 2022-06-23 10:28:59.014976
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:29:01.554544
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(list(FilterModule().filters().keys()) == ['urlsplit'])


# Generated at 2022-06-23 10:29:04.990310
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert len(filters) == 1
    assert 'urlsplit' in filters
    assert callable(filters['urlsplit'])


# Generated at 2022-06-23 10:29:16.200118
# Unit test for function split_url

# Generated at 2022-06-23 10:29:25.174837
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Test the split_url filter
    # Test that an exception is raised when an invalid URL is passed
    invalid_url = 'http://google.com'
    try:
        split_url(invalid_url)
        raise RuntimeError('Method filters of class FilterModule failed.')
    except AnsibleFilterError as err:
        assert isinstance(err, AnsibleFilterError)

    # Test that this filter returns a dictionary containing the components of the given URL
    valid_url = 'http://www.google.com:80/index.html?q=key'
    result = split_url(valid_url)
    assert result['scheme'] == 'http'
    assert result['hostname'] == 'www.google.com'
    assert result['port'] == 80
    assert result['path'] == '/index.html'

# Generated at 2022-06-23 10:29:36.164877
# Unit test for function split_url
def test_split_url():

    url = "scheme://netloc/path;parameters?query=value#fragment"

    test_url = split_url(url, 'scheme')
    assert test_url == 'scheme'

    test_url = split_url(url, 'netloc')
    assert test_url == 'netloc'

    test_url = split_url(url, 'path')
    assert test_url == '/path;parameters'

    test_url = split_url(url, 'query')
    assert test_url == 'query=value'

    test_url = split_url(url, 'fragment')
    assert test_url == 'fragment'

    test_url = split_url(url, 'port')
    assert test_url is None

    test_url = split_url(url)

# Generated at 2022-06-23 10:29:45.788574
# Unit test for function split_url
def test_split_url():
    test_cases = (
        'http://10.0.0.1/path?param=true',
        'https://web.example.com/',
        'nested@localhost:5000',
    )
    for test_case in test_cases:
        params = {
            'scheme': 'http',
            'netloc': '10.0.0.1',
            'path': '/path',
            'query': 'param=true',
            'fragment': '',
        }
        for param in params:
            assert(params[param] == split_url(test_case, param))

# Generated at 2022-06-23 10:29:54.929402
# Unit test for function split_url
def test_split_url():
    results = split_url('http://www.example.org/path/to/file?key=value&key2=value2')
    assert results['scheme'] == 'http'
    assert results['netloc'] == 'www.example.org'
    assert results['path'] == '/path/to/file'
    assert results['query'] == 'key=value&key2=value2'
    assert results['fragment'] == ''

    results = split_url('http://www.example.org/path/to/file?key=value&key2=value2', 'query')
    assert results == 'key=value&key2=value2'

    results = split_url('http://www.example.org/path/to/file?key=value&key2=value2', 'scheme')
    assert results == 'http'

# Generated at 2022-06-23 10:30:00.298209
# Unit test for function split_url
def test_split_url():
    value = 'https://some.domain/some/path?some=query'
    query = 'path'
    expected = '/some/path'
    assert split_url(value, query=query) == expected
    query = 'scheme'
    expected = 'https'
    assert split_url(value, query=query) == expected


# Generated at 2022-06-23 10:30:07.373666
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('http://example.com/foo/bar.html?baz=qux#quux') == {'fragment': 'quux', 'netloc': 'example.com', 'path': '/foo/bar.html', 'query': 'baz=qux', 'scheme': 'http'}
    assert split_url('http://example.com/foo/bar.html?baz=qux#quux', 'scheme') == 'http'
    assert split_url('http://example.com/foo/bar.html?baz=qux#quux', 'foo', 'blah') == 'blah: unknown URL component: foo'
    assert split_url('http://example.com/foo/bar.html?baz=qux#quux', 'quux') == 'quux'


# Unit test

# Generated at 2022-06-23 10:30:09.715564
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test method FilterModule.filters()
    assert FilterModule.filters(FilterModule()) == {'urlsplit': split_url}


# Generated at 2022-06-23 10:30:12.795713
# Unit test for function split_url
def test_split_url():
    u = 'http://www.cnn.com/index.html'
    test = split_url(u, query='netloc')

    assert test == 'www.cnn.com'

# Generated at 2022-06-23 10:30:14.005573
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert( isinstance(FilterModule(), FilterModule) )


# Generated at 2022-06-23 10:30:21.499232
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.example.com/path/to/file?id=10&name=example#fragment', 'scheme') == 'http'
    assert split_url('http://www.example.com/path/to/file?id=10&name=example#fragment', 'netloc') == 'www.example.com'
    assert split_url('http://www.example.com/path/to/file?id=10&name=example#fragment', 'path') == '/path/to/file'
    assert split_url('http://www.example.com/path/to/file?id=10&name=example#fragment', 'query') == 'id=10&name=example'

# Generated at 2022-06-23 10:30:28.638674
# Unit test for function split_url
def test_split_url():
    test_url = 'aldrichiii@gmail.com'
    # test that the port is a string
    r = split_url(test_url, 'port')
    assert isinstance(r, str)
    # test that the result is correct
    r = split_url(test_url)
    assert r == {'fragment': '', 'netloc': '', 'path': 'aldrichiii@gmail.com', 'query': '', 'scheme': ''}

# Generated at 2022-06-23 10:30:37.137324
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule().filters()
    result = f['urlsplit']('http://github.com/mikaelho/ansible-uri-filter')
    assert result['scheme'] == 'http'
    assert result['netloc'] == 'github.com'
    assert result['path'] == '/mikaelho/ansible-uri-filter'
    assert result['query'] == ''
    assert result['fragment'] == ''
    result = f['urlsplit']('https://github.com/mikaelho/ansible-uri-filter')
    assert result['scheme'] == 'https'
    assert result['netloc'] == 'github.com'
    assert result['path'] == '/mikaelho/ansible-uri-filter'
    assert result['query'] == ''
    assert result['fragment'] == ''

# Generated at 2022-06-23 10:30:48.189195
# Unit test for function split_url
def test_split_url():
    assert split_url('https://github.com/ansible/ansible') == {
        'netloc': 'github.com',
        'path': '/ansible/ansible',
        'hostname': 'github.com',
        'fragment': '',
        'password': '',
        'scheme': 'https',
        'username': '',
        'port': None,
    }
    assert split_url('https://github.com/ansible/ansible', query='scheme') == 'https'
    assert split_url('https://github.com/ansible/ansible', query='path') == '/ansible/ansible'
    assert split_url('https://github.com/ansible/ansible', query='netloc') == 'github.com'

# Generated at 2022-06-23 10:30:50.022464
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urlsplit' in filters
    assert filters['urlsplit'] == split_url

# Generated at 2022-06-23 10:31:00.691106
# Unit test for function split_url
def test_split_url():
    data = 'http://www.example.com:8080/path1/path2?query1=value1&query2=value2'
    result = split_url(data, 'path')
    assert result == '/path1/path2'
    result = split_url(data, 'query')
    assert result == 'query1=value1&query2=value2'
    result = split_url(data, 'hostname')
    assert result == 'www.example.com'
    result = split_url(data, 'port')
    assert result == '8080'
    result = split_url(data, 'scheme')
    assert result == 'http'
    result = split_url(data, 'unknown')

# Generated at 2022-06-23 10:31:02.552615
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urlsplit'] == split_url

# Generated at 2022-06-23 10:31:04.507348
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:31:11.573205
# Unit test for function split_url
def test_split_url():
    assert split_url('https://docs.ansible.com/ansible/latest/modules/urls.html?highlight=urlsplit')['query'] == 'highlight=urlsplit'

# Generated at 2022-06-23 10:31:21.345319
# Unit test for function split_url
def test_split_url():

    # The following was taken from http://docs.python.org/2/library/urlparse.html#urlparse.urlsplit
    url = 'http://www.cwi.nl:80/%7Eguido/Python.html'
    result = split_url(url)
    assert result['scheme'] == 'http', "split_url output does not match expected output"
    assert result['netloc'] == 'www.cwi.nl:80', "split_url output does not match expected output"
    assert result['path'] == '/%7Eguido/Python.html', "split_url output does not match expected output"

    # Test query
    assert result['scheme'] == split_url(url, 'scheme'), "query output does not match expected output"

# Generated at 2022-06-23 10:31:24.008658
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Create an instance of FilterModule()
    t = FilterModule()
    # Check if the filter is in t
    assert('urlsplit' in t.filters())


# Generated at 2022-06-23 10:31:25.353932
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    assert len(filters.filters()) == 1

# Generated at 2022-06-23 10:31:27.744605
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'urlsplit' in FilterModule.filters(FilterModule)

# Generated at 2022-06-23 10:31:30.367344
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.foo.com/bar', 'scheme') == 'http'
    assert split_url('http://www.foo.com/bar', 'path') == '/bar'

# Generated at 2022-06-23 10:31:32.141147
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:31:37.907008
# Unit test for function split_url
def test_split_url():
    url = 'https://www.google.ca:443/search?q=urlsplit&oq=urlsplit&aqs=chrome..69i57j69i60l2j0l2.747j0j7&sourceid=chrome&ie=UTF-8'
    spl = split_url(url, 'path')
    assert spl == '/search'

# Generated at 2022-06-23 10:31:47.823540
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.ansible.com/index.html')['scheme'] == 'http'
    assert split_url('http://www.ansible.com/index.html')['netloc'] == 'www.ansible.com'
    assert split_url('http://www.ansible.com/index.html')['path'] == '/index.html'
    assert split_url('http://www.ansible.com/index.html')['query'] == ''
    assert split_url('http://www.ansible.com/index.html')['fragment'] == ''
    assert split_url('http://www.ansible.com/index.html', 'scheme') == 'http'

# Generated at 2022-06-23 10:31:50.837551
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()

    # Test for validate_filters method
    assert 'urlsplit' in filters, \
        'FilterModule.filters does not contain urlsplit filter.'



# Generated at 2022-06-23 10:31:57.876284
# Unit test for function split_url
def test_split_url():
    test_url = 'http://username:password@example.com:8080/test/path;param1?value1#fragment'
    test_dict = {
        'scheme': 'http',
        'url': 'http://username:password@example.com:8080/test/path;param1?value1#fragment',
        'fragment': 'fragment',
        'netloc': 'username:password@example.com:8080',
        'username': 'username',
        'password': 'password',
        'hostname': 'example.com',
        'port': '8080',
        'path': '/test/path;param1',
        'query': 'value1',
    }

    assert split_url(test_url) == test_dict

# Generated at 2022-06-23 10:32:07.134682
# Unit test for function split_url

# Generated at 2022-06-23 10:32:08.202394
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()


# Generated at 2022-06-23 10:32:14.628275
# Unit test for function split_url
def test_split_url():
    parts = split_url('https://user:pass@example.com:8080/test/test.html?test=test#test')
    assert parts['scheme'] == 'https'
    assert parts['netloc'] == 'user:pass@example.com:8080'
    assert parts['path'] == '/test/test.html'
    assert parts['query'] == 'test=test'
    assert parts['fragment'] == 'test'
    assert parts['username'] == 'user'
    assert parts['password'] == 'pass'
    assert parts['hostname'] == 'example.com'

    assert split_url('https://www.example.com/test/test.html?test=test#test', 'port') is None

# Generated at 2022-06-23 10:32:17.086597
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urlsplit' in filters


# Generated at 2022-06-23 10:32:17.636061
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:32:20.883137
# Unit test for function split_url
def test_split_url():
    url = split_url('https://www.ansible.com/python-api')
    assert url['scheme'] == 'https'
    assert url['netloc'] == 'www.ansible.com'
    assert url['path'] == '/python-api'

# Generated at 2022-06-23 10:32:25.093455
# Unit test for constructor of class FilterModule
def test_FilterModule():
    aobj = FilterModule()
    assert aobj is not None

# Generated at 2022-06-23 10:32:28.100707
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:32:29.997262
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert 'urlsplit' in obj.filters()



# Generated at 2022-06-23 10:32:30.964752
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

# Generated at 2022-06-23 10:32:41.976995
# Unit test for function split_url
def test_split_url():
    assert split_url('https://user:password@test.foo.com:80/one/two?three=four', 'scheme') == 'https'
    assert split_url('https://user:password@test.foo.com:80/one/two?three=four', 'netloc') == 'user:password@test.foo.com:80'
    assert split_url('https://user:password@test.foo.com:80/one/two?three=four', 'path') == '/one/two'
    assert split_url('https://user:password@test.foo.com:80/one/two?three=four', 'query') == 'three=four'
    assert split_url('https://user:password@test.foo.com:80/one/two?three=four', 'fragment') == ''
    assert split

# Generated at 2022-06-23 10:32:51.506804
# Unit test for function split_url

# Generated at 2022-06-23 10:32:53.738153
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(None) == {'urlsplit': split_url}



# Generated at 2022-06-23 10:33:05.261228
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule = FilterModule()
    filt = filtermodule.filters()
    testuri = 'http://example.com/pages/pythonscripts.html?boolean#hello'
    assert filt['urlsplit'](testuri)['scheme'] == 'http'
    assert filt['urlsplit'](testuri)['netloc'] == 'example.com'
    assert filt['urlsplit'](testuri)['path'] == '/pages/pythonscripts.html'
    assert filt['urlsplit'](testuri, 'scheme') == 'http'
    assert filt['urlsplit'](testuri, 'netloc') == 'example.com'
    assert filt['urlsplit'](testuri, 'path') == '/pages/pythonscripts.html'

# Generated at 2022-06-23 10:33:16.260683
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    url = 'http://www.example.com:80/path?arg=value#fragment'
    assert fm.filters()['urlsplit'](url, 'scheme') == 'http'
    assert fm.filters()['urlsplit'](url, 'netloc') == 'www.example.com:80'
    assert fm.filters()['urlsplit'](url, 'path') == '/path'
    assert fm.filters()['urlsplit'](url, 'query') == 'arg=value'
    assert fm.filters()['urlsplit'](url, 'fragment') == 'fragment'
    assert fm.filters()['urlsplit'](url, 'username') == None

# Generated at 2022-06-23 10:33:17.735581
# Unit test for constructor of class FilterModule
def test_FilterModule():
    c = FilterModule()
    assert c.filters()['urlsplit']()

# Generated at 2022-06-23 10:33:25.577266
# Unit test for function split_url
def test_split_url():
    val = 'http://www.example.com/foo/bar?q=1'
    data = split_url(val)
    assert data['scheme'] == 'http'
    assert data['netloc'] == 'www.example.com'
    assert data['path'] == '/foo/bar'

    data = split_url(val, 'scheme')
    assert data == 'http'

    data = split_url(val, 'hostname')
    assert data == 'www.example.com'

    data = split_url(val, 'port')
    assert data == None

    data = split_url(val, 'path')
    assert data == '/foo/bar'

    data = split_url(val, 'params')
    assert data == ''

    data = split_url(val, 'query')

# Generated at 2022-06-23 10:33:32.434812
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert split_url("http://user@www.cwi.nl:80/path/to/file.html?foo=bar&baz=qux#fragment") == {'scheme': 'http', 'netloc': 'user@www.cwi.nl:80', 'path': '/path/to/file.html', 'params': '', 'query': 'foo=bar&baz=qux', 'fragment': 'fragment'}

# Generated at 2022-06-23 10:33:38.729154
# Unit test for function split_url
def test_split_url():
    '''Make sure the cut_url function is working properly'''

    # Do a series of assertions on split_url
    import codecs

    # Test that unknown components return an AnsibleFilterError
    try:
        codecs.decode(split_url('http://www.google.com', 'bad'), 'unicode_escape')
    except AnsibleFilterError as e:
        assert e.args[0] == 'urlsplit: unknown URL component: bad'
    else:
        raise AssertionError('The above statement should have raised an AnsibleFilterError')

    # Test that no query returns a dictonary of parsed components

# Generated at 2022-06-23 10:33:41.652301
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urlsplit'] == split_url


# Generated at 2022-06-23 10:33:45.007998
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for method filters of class FilterModule '''
    my_object = FilterModule()
    my_filter = my_object.filters()
    assert 'urlsplit' in my_filter
    assert 'testfield' not in my_filter


# Generated at 2022-06-23 10:33:45.578160
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:33:50.552716
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    config_dict = {'ansible_module_generated': {'urlsplit': {'scheme': 'ansible', 'netloc': 'docs.ansible.com', 'path': '/', 'query': 'var1=value&var2=value', 'fragment': ''}} }
    config_data = "http://docs.ansible.com/?var1=value&var2=value"
    config = FilterModule()
    filters = config.filters()
    if filters['urlsplit'](config_data) == config_dict:
        return True
    else:
        return False

# Generated at 2022-06-23 10:33:55.472860
# Unit test for function split_url
def test_split_url():
	value = "http://www.example.com/path/?key=val"
	query = "path"
	alias = 'urlsplit'

	results = helpers.object_to_dict(urlsplit(value), exclude=['count', 'index', 'geturl', 'encode'])
	if query:
		if query not in results:
			raise AnsibleFilterError(alias + ': unknown URL component: %s' % query)
		return results[query]
	else:
		return results

	assert results['path'] == '/path/'

# Generated at 2022-06-23 10:33:56.957632
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert "FilterModule" == FilterModule.__name__



# Generated at 2022-06-23 10:33:58.185053
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:34:02.020179
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Test constructor of class FilterModule. '''
    filters = FilterModule()
    assert filters.filters() is not None, 'Test failed: filters is None'
    assert filters.filters()['urlsplit'] is not None, 'Test failed: urlsplit is None'



# Generated at 2022-06-23 10:34:03.489115
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj


# Generated at 2022-06-23 10:34:04.661541
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert obj.filters() is not None


# Generated at 2022-06-23 10:34:08.870043
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url("rsync://user@host/resource.tar.gz")  == {
            'fragment': '',
            'netloc': 'user@host',
            'path': '/resource.tar.gz',
            'query': '',
            'scheme': 'rsync',
        }

# Generated at 2022-06-23 10:34:11.013380
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test FilterModule()
    foo = FilterModule()
    # Check it is an instance of FilterModule class
    assert isinstance(foo, FilterModule)



# Generated at 2022-06-23 10:34:12.997987
# Unit test for constructor of class FilterModule
def test_FilterModule():
    visible = False
    assert (not visible)


# Generated at 2022-06-23 10:34:16.048741
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' test_FilterModule_filters '''
    fmod = FilterModule()
    assert fmod.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:34:25.232481
# Unit test for function split_url
def test_split_url():

    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    from nose.tools import assert_equals

    url = 'https://username:password@www.ansible.com:8080/docs/index.html?ansible=awesome#docs'

    # Test the different queries
    assert_equals(split_url(url, 'scheme'), 'https')
    assert_equals(split_url(url, 'netloc'), 'username:password@www.ansible.com:8080')
    assert_equals(split_url(url, 'path'), '/docs/index.html')
    assert_equals(split_url(url, 'query'), 'ansible=awesome')
    assert_equals(split_url(url, 'fragment'), 'docs')

    #

# Generated at 2022-06-23 10:34:28.196121
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'urlsplit' in FilterModule.filters(None)
    assert callable(FilterModule.filters(None)['urlsplit'])


# Generated at 2022-06-23 10:34:32.555143
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.example.com/path/?key1=value1&key2=value2', 'query') == 'key1=value1&key2=value2'
    assert split_url('https://www.example.com/path/?key1=value1&key2=value2', 'scheme') == 'https'

# Generated at 2022-06-23 10:34:36.487723
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert filters['urlsplit'].__name__ == 'split_url'

# Generated at 2022-06-23 10:34:49.327522
# Unit test for function split_url

# Generated at 2022-06-23 10:34:50.522375
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    return fm


# Generated at 2022-06-23 10:34:51.829871
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None


# Unit tests for urlsplit

# Generated at 2022-06-23 10:34:52.671981
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert {} == FilterModule().filters()

# Generated at 2022-06-23 10:34:54.444988
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    result = fm.filters()
    assert result['urlsplit'] == split_url



# Generated at 2022-06-23 10:34:54.927839
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()

# Generated at 2022-06-23 10:34:59.409797
# Unit test for constructor of class FilterModule
def test_FilterModule():
  # Create a FilterModule instance
  filterModule = FilterModule()
  # Create a FilterModule instance
  test_FilterModule_instance = FilterModule()
  # Create an assert of the type of the instance
  assert isinstance(test_FilterModule_instance, FilterModule)


# Generated at 2022-06-23 10:35:01.537561
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'urlsplit' in filter_module.filters()

# Generated at 2022-06-23 10:35:03.205795
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f


# Generated at 2022-06-23 10:35:13.657111
# Unit test for function split_url

# Generated at 2022-06-23 10:35:15.503029
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_module = FilterModule()
    assert test_module.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:35:27.090499
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.example.com/foo/bar', 'scheme') == 'https'
    assert split_url('https://www.example.com/foo/bar', 'path') == '/foo/bar'
    assert split_url('https://localhost:8080/foo/bar', 'port') == '8080'
    assert split_url('https://localhost:8080/foo/bar', 'netloc') == 'localhost:8080'
    assert split_url('https://www.example.com/foo/bar', 'netloc') == 'www.example.com'
    assert split_url('https://www.example.com/foo/bar', 'query') == ''
    assert split_url('http://localhost:8080/?location=atlanta', 'query') == 'location=atlanta'
    assert split_url

# Generated at 2022-06-23 10:35:36.469447
# Unit test for function split_url
def test_split_url():

    assert split_url('https://www.google.com/webhp?sourceid=chrome-instant&ion=1&espv=2&ie=UTF-8#q=urllib%20split') == {
        'netloc': 'www.google.com',
        'username': '',
        'path': u'/webhp',
        'scheme': 'https',
        'fragment': u'q=urllib%20split',
        'query': u'sourceid=chrome-instant&ion=1&espv=2&ie=UTF-8',
        'password': '',
    }

# Generated at 2022-06-23 10:35:49.782858
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('https://foo.bar/test?q=test#fragment', 'scheme') == 'https'
    assert split_url('https://foo.bar/test?q=test#fragment', 'netloc') == 'foo.bar'
    assert split_url('https://foo.bar/test?q=test#fragment', 'path') == '/test'
    assert split_url('https://foo.bar/test?q=test#fragment', 'params') == ''
    assert split_url('https://foo.bar/test?q=test#fragment', 'query') == 'q=test'
    assert split_url('https://foo.bar/test?q=test#fragment', 'fragment') == 'fragment'

# Generated at 2022-06-23 10:35:56.770849
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Instantiate a FilterModule object
    filtermodule = FilterModule()

    # Create a dict of mock arguments to use with the 'urlsplit' function.
    # The mock should return a dictionary of the URL components.
    mock_args = {
        'value': 'https://www.ansible.com/opensource/mezzanine-cms',
        'query': 'scheme',
        'alias': 'urlsplit'
    }
    # Call the 'urlsplit' function
    result = filtermodule.filters()['urlsplit'](**mock_args)

    # We expect to see the scheme component of the URL to be returned.
    assert result == 'https'

# Generated at 2022-06-23 10:36:03.030407
# Unit test for function split_url
def test_split_url():
    for query in ['scheme', 'netloc', 'path', 'params',
                  'query', 'fragment', 'username',
                  'password', 'hostname', 'port']:
        url = "https://username:password@hostname:9999/path?query=foo#fragment"
        assert split_url(url, query) == urlsplit(url)[query]


if __name__ == '__main__':
    test_split_url()

# Generated at 2022-06-23 10:36:08.525451
# Unit test for function split_url
def test_split_url():
    """ Tests if a valid URL is split and returned as a dict """
    assert split_url("http://user:pass@github.com:8080/path?q=1#fragment") == {
        'fragment': 'fragment',
        'query': 'q=1',
        'path': '/path',
        'netloc': 'user:pass@github.com:8080',
        'username': 'user',
        'port': '8080',
        'hostname': 'github.com',
        'password': 'pass',
        'scheme': 'http'
    }


# Generated at 2022-06-23 10:36:09.149820
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-23 10:36:09.538043
# Unit test for constructor of class FilterModule
def test_FilterModule():
    return FilterModule()