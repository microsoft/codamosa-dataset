

# Generated at 2022-06-23 10:26:09.177037
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule();
    assert isinstance(fm, FilterModule)


# Generated at 2022-06-23 10:26:12.476467
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert 'ansible' in FilterModule.__module__
    assert 'FilterModule' in FilterModule.__name__
    assert callable(FilterModule)
    assert isinstance(FilterModule(), FilterModule)


# Generated at 2022-06-23 10:26:14.926834
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Constructor of Ansible filter class
    filter_instance = FilterModule()
    assert filter_instance.filters()


# Generated at 2022-06-23 10:26:20.863627
# Unit test for function split_url
def test_split_url():
    url = 'http://www.example.com/path/foo/?key=value#hash'

    expected_results = {
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/foo/',
        'params': '',
        'query': 'key=value',
        'fragment': 'hash',
    }

    results = split_url(url)

    assert expected_results == results

# Generated at 2022-06-23 10:26:33.617021
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    url = 'http://foo:bar@localhost:8080/path/to/resource?query=1&type=2'
    assert split_url(url) == {
        'scheme': 'http',
        'netloc': 'foo:bar@localhost:8080',
        'path': '/path/to/resource',
        'query': 'query=1&type=2',
        'fragment': ''
    }
    assert split_url(url, 'netloc') == 'foo:bar@localhost:8080'
    assert split_url(url, 'scheme') == 'http'
    assert split_url(url, 'netloc') == 'foo:bar@localhost:8080'
    assert split_url(url, 'username') == 'foo'
    assert split_url(url, 'password') == 'bar'

# Generated at 2022-06-23 10:26:45.600895
# Unit test for function split_url
def test_split_url():
    # Test a valid URL
    value = "http://www.ansible.com/path/to/file?q=1&q2=2"
    query = 'netloc'
    result = "www.ansible.com"
    test_result = split_url(value, query)
    if not test_result == result:
        raise AssertionError("split_url test_split_url #1: test failed. Actual result: %s; Expected result: %s" % (test_result, result))

    # Test an invalid URL
    value = "http://www.ansible.com/path/to/file?q=1&q2=2"
    query = 'invalid'

# Generated at 2022-06-23 10:26:52.203930
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'fragment' == FilterModule().filters()['urlsplit']('https://docs.ansible.com/ansible/latest/dev_guide/developing_locally.html#integrating-with-vagrant-and-virtualbox', 'fragment')

# Generated at 2022-06-23 10:26:53.660920
# Unit test for constructor of class FilterModule
def test_FilterModule():
    testing = FilterModule()
    assert testing.filters() is not None


# Generated at 2022-06-23 10:27:00.805308
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    u = "http://www.example.com:8080/path/to/resource?query=yes#hash"
    filters = fm.filters()
    assert filters['urlsplit'](u) == {
        'path': '/path/to/resource',
        'scheme': 'http',
        'netloc': 'www.example.com:8080',
        'query': 'query=yes',
        'fragment': 'hash'
    }
    assert filters['urlsplit'](u, 'path') == '/path/to/resource'
    assert filters['urlsplit'](u, 'query') == 'query=yes'



# Generated at 2022-06-23 10:27:03.510794
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)


# Generated at 2022-06-23 10:27:10.470537
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.ansible.com:8080/documentation') == {'scheme': 'https', 'netloc': 'www.ansible.com:8080', 'path': '/documentation', 'query': '', 'fragment': ''}
    assert split_url('https://www.ansible.com:8080/documentation', 'scheme') == 'https'
    assert split_url('https://www.ansible.com:8080/documentation', 'path') == '/documentation'

# Generated at 2022-06-23 10:27:21.605217
# Unit test for constructor of class FilterModule
def test_FilterModule():

    url = "http://www.example.com/path/to/myfile.html?key1=value1&key2=value2#InTheDocument"
    fm = FilterModule()

    # Since FilterModule() is *pure Python*, it is *very* hard to test it automatically
    # Most of the testing is manual
    url_split = fm.filters()['urlsplit'](url)
    assert isinstance(url_split, dict)
    assert url_split['scheme'] == 'http'
    assert url_split['netloc'] == 'www.example.com'
    assert url_split['path'] == '/path/to/myfile.html'
    assert url_split['query'] == 'key1=value1&key2=value2'
    assert url_split['fragment'] == 'InTheDocument'

# Generated at 2022-06-23 10:27:25.012051
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()
    assert x
    assert x.filters
    assert x.filters()

# Generated at 2022-06-23 10:27:33.966788
# Unit test for function split_url
def test_split_url():

    result = split_url('http://www.domain.invalid/foo?bar=baz#quux', 'scheme')
    assert result == 'http'

    result = split_url('http://www.domain.invalid/foo?bar=baz#quux', 'path')
    assert result == '/foo'

    result = split_url('http://www.domain.invalid/foo?bar=baz#quux', 'query')
    assert result == 'bar=baz'

    result = split_url('http://www.domain.invalid/foo?bar=baz#quux', 'fragment')
    assert result == 'quux'

    result = split_url('http://www.domain.invalid/foo?bar=baz#quux', 'netloc')

# Generated at 2022-06-23 10:27:34.858339
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-23 10:27:40.666003
# Unit test for constructor of class FilterModule
def test_FilterModule():

    # Instantiate instance of FilterModule
    filter_module = FilterModule()

    # Check return value of filters()
    assert filter_module.filters() == {
        'urlsplit': split_url
    }, "FilterModule.filters() returns a dictionary of filters"



# Generated at 2022-06-23 10:27:41.336734
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()

# Generated at 2022-06-23 10:27:44.463417
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''Unit tests for filters method of class FilterModule.'''
    module = FilterModule()
    # noinspection PyProtectedMember
    assert module._filters() == {'urlsplit': split_url}, 'Expected different filters dictionary.'


# Generated at 2022-06-23 10:27:55.061296
# Unit test for function split_url
def test_split_url():
    assert split_url("http://stackoverflow.com/questions/12345/foo/bar?a=b&c=d", "scheme") == "http"
    assert split_url("http://stackoverflow.com/questions/12345/foo/bar?a=b&c=d", "netloc") == "stackoverflow.com"
    assert split_url("http://stackoverflow.com/questions/12345/foo/bar?a=b&c=d", "path") == "/questions/12345/foo/bar"
    assert split_url("http://stackoverflow.com/questions/12345/foo/bar?a=b&c=d", "query") == "a=b&c=d"

# Generated at 2022-06-23 10:27:58.484934
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()


# Generated at 2022-06-23 10:28:00.370050
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Unit test for the FilterModule class. '''
    assert FilterModule


# Generated at 2022-06-23 10:28:02.423387
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ret = FilterModule().filters()

    assert ret == {
            'urlsplit': split_url
        }

# Generated at 2022-06-23 10:28:11.810545
# Unit test for function split_url
def test_split_url():
    input = 'https://ansible.com/foo/%20bar'
    output = dict(scheme='https',
                  netloc='ansible.com',
                  path='/foo/ bar',
                  query='',
                  fragment='')

    assert split_url(input) == output
    assert split_url(input, 'netloc') == output['netloc']
    assert split_url(input, 'path') == output['path']
    assert split_url(input, 'query') == output['query']
    assert split_url(input, 'fragment') == output['fragment']

    # Test error handling
    output = 'urlsplit: unknown URL component: baz'
    try:
        split_url(input, 'baz')
    except AnsibleFilterError as e:
        assert str(e) == output

# Generated at 2022-06-23 10:28:20.552996
# Unit test for function split_url
def test_split_url():
    assert split_url('https://ansible.com') == {'fragment': '', 'netloc': 'ansible.com', 'path': '', 'query': '', 'scheme': 'https'}
    assert split_url('https://ansible.com', 'scheme') == 'https'
    assert split_url('https://ansible.com', 'netloc') == 'ansible.com'
    assert split_url('https://ansible.com', 'path') == ''
    assert split_url('https://ansible.com', 'query') == ''
    assert split_url('https://ansible.com', 'fragment') == ''
    assert split_url('https://ansible.com', 'year')['msg'] == 'urlsplit: unknown URL component: year'

# Generated at 2022-06-23 10:28:26.569315
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('http://foo.bar/baz') == {
        'fragment': '',
        'netloc': 'foo.bar',
        'path': '/baz',
        'query': '',
        'scheme': 'http'
    }



# Generated at 2022-06-23 10:28:31.434814
# Unit test for function split_url
def test_split_url():

    url = 'http://www.example.com/path?foo=bar#baz'
    expected = {
        'fragment': 'baz',
        'netloc': 'www.example.com',
        'path': '/path',
        'query': 'foo=bar',
        'scheme': 'http'
    }

    assert split_url(url) == expected

# Generated at 2022-06-23 10:28:34.251105
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urlsplit'].__doc__ == split_url.__doc__

# Generated at 2022-06-23 10:28:36.273821
# Unit test for constructor of class FilterModule
def test_FilterModule():

    module = FilterModule()

    assert module.filters() is not None
    assert 'urlsplit' in module.filters()



# Generated at 2022-06-23 10:28:47.537253
# Unit test for function split_url
def test_split_url():

    # All valid options
    options = {
        'url': 'http://www.example.com/path/to/file.html?key1=value1&key2=value2#fragment',
        'scheme': 'http',
        'netloc': 'www.example.com',
        'path': '/path/to/file.html',
        'query': 'key1=value1&key2=value2',
        'fragment': 'fragment'
    }
    for key, value in options.items():
        assert split_url(options['url'], query=key) == value

    # No query should return entire dictionary of values
    assert sorted(split_url(options['url']).keys()) == sorted(options.keys())

    # An invalid query should raise an exception

# Generated at 2022-06-23 10:28:49.344437
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:28:52.671107
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module_name = 'FilterModule'
    f = FilterModule()
    assert isinstance(f, FilterModule), \
        'Object returned by constructor of ' + module_name + ' is not an instance of that class.'


# Generated at 2022-06-23 10:28:59.993962
# Unit test for function split_url
def test_split_url():
    """
        Test function split_url
        Args:
            -

        Returns:
            -

    """
    import sys, os
    sys.path.append(os.path.realpath("tests/library"))
    from test_utils import run_ansible_module
    from test_utils import skip_if_missing_module

    skip_if_missing_module(FilterModule, 'jmespath')

    results = run_ansible_module(FilterModule, 'https://www.ansible.com/company/info')
    assert results['changed'] == False

# Generated at 2022-06-23 10:29:02.279241
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'port' == FilterModule().filters()["urlsplit"]("https://example.com/", "port")

# Generated at 2022-06-23 10:29:11.561699
# Unit test for function split_url
def test_split_url():
    ''' Unit test for function split_url '''

    from ansible.utils.urls import url_argument_spec

    uri = 'http://www.example.com:80/a/b/c?foo=bar&blah=stuff#blargh'
    assert split_url(value=uri, query='scheme') == 'http'
    assert split_url(value=uri, query='netloc') == 'www.example.com:80'
    assert split_url(value=uri, query='path') == '/a/b/c'
    assert split_url(value=uri, query='query') == 'foo=bar&blah=stuff'
    assert split_url(value=uri, query='fragment') == 'blargh'

# Generated at 2022-06-23 10:29:18.241600
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # test: an empty url should return an empty string
    fm = FilterModule()
    assert {} == fm.filters()
    # test: split an empty url
    assert { 'urlsplit': split_url } == fm.filters()
    # test: split a url with a query
    assert split_url('https://user:pass@test.example.com:8080/foo/bar?q=1&b=2#frag', 'hostname') == 'test.example.com'
    # test: split a url with no query

# Generated at 2022-06-23 10:29:21.699675
# Unit test for function split_url
def test_split_url():
    url = 'http://www.ansible.com/user/login'
    query = 'hostname'
    assert split_url(url, query) == 'www.ansible.com'

# Generated at 2022-06-23 10:29:24.735820
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # This is the simplest test you can do,
    # assert that constructor of class FilterModule has no exception
    assert FilterModule()

# Generated at 2022-06-23 10:29:35.964662
# Unit test for function split_url

# Generated at 2022-06-23 10:29:47.785570
# Unit test for function split_url
def test_split_url():
    assert split_url('http://example.com/foo/bar?query=1') == {
        'hostname': 'example.com',
        'netloc': 'example.com',
        'params': '',
        'path': '/foo/bar',
        'query': 'query=1',
        'query_list': [('query', '1')],
        'query_parts': {'query': '1'},
        'fragment': '',
        'scheme': 'http',
    }
    assert split_url('http://example.com/foo/bar?query=1', query='netloc') == 'example.com'
    assert split_url('http://example.com/foo/bar?query=1', query='query_parts') == {'query': '1'}

# Generated at 2022-06-23 10:29:49.303160
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  assert FilterModule().filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:29:55.096833
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # pylint: disable=protected-access
    filters = FilterModule().filters()
    url = split_url.__wrapped__
    assert url == filters['urlsplit']

# Generated at 2022-06-23 10:29:58.604701
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj.filters() == {'urlsplit': split_url}
    obj.filters = 'test'
    assert obj.filters() == 'test'


# Generated at 2022-06-23 10:29:59.434617
# Unit test for constructor of class FilterModule
def test_FilterModule():
    result = FilterModule()
    assert result != ""

# Generated at 2022-06-23 10:30:10.243164
# Unit test for function split_url
def test_split_url():
    """ """
    module = __import__('__main__')
    attr_name = 'urlsplit'
    if hasattr(module, attr_name):
        delattr(module, attr_name)
    module.urlsplit = split_url

    # Set up the test data
    url = u'https://foo:bar@www.example.com/abc?a=b#anchor'
    href = u'https://foo:bar@www.example.com/abc?a=b#anchor'
    netloc = u'foo:bar@www.example.com'
    path = u'/abc'
    params = u''
    query = u'a=b'
    fragment = u'anchor'
    username = u'foo'
    password = u'bar'

# Generated at 2022-06-23 10:30:11.045511
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule


# Generated at 2022-06-23 10:30:17.780836
# Unit test for function split_url
def test_split_url():
    url = 'http://www.url.com/path/file.ext?arg=value#frag'
    assert split_url(url) == {'netloc': 'www.url.com', 'fragment': 'frag', 'path': '/path/file.ext', 'scheme': 'http', 'query': 'arg=value'}
    assert split_url(url, 'netloc') == 'www.url.com'
    assert split_url(url, 'scheme') == 'http'
    assert split_url(url, 'path') == '/path/file.ext'
    assert split_url(url, 'query') == 'arg=value'
    assert split_url(url, 'fragment') == 'frag'

# Generated at 2022-06-23 10:30:19.184512
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test constructor of class FilterModule
    assert FilterModule is not None

# Generated at 2022-06-23 10:30:22.458434
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    x = {'urlsplit': split_url}

    assert fm.filters() == x

# Generated at 2022-06-23 10:30:24.859439
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'urlsplit': split_url
    }


# Generated at 2022-06-23 10:30:31.828918
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test FilterModule with no params
    assert FilterModule() is not None
    f = FilterModule()
    # Test FilterModule.filters()
    assert hasattr(f, 'filters')
    assert callable(f.filters)
    assert f.filters() is not None
    # Test FilterModule.filters() return value
    filters = f.filters()
    assert isinstance(filters, dict)
    assert 'urlsplit' in filters
    assert isinstance(filters['urlsplit'], types.FunctionType)


# Generated at 2022-06-23 10:30:32.712159
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-23 10:30:38.986389
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert split_url("http://www.python.org/foo/bar?a=b&c=d", 'netloc') == "www.python.org"
    assert split_url("http://www.python.org/foo/bar?a=b&c=d", 'path') == "/foo/bar"
    assert split_url("http://www.python.org/foo/bar?a=b&c=d", 'scheme') == "http"
    assert split_url("http://www.python.org/foo/bar?a=b&c=d", 'query') == "a=b&c=d"


if __name__ == '__main__':
    print('Executing unit tests.')
    test_FilterModule()

# Generated at 2022-06-23 10:30:40.542834
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-23 10:30:50.462896
# Unit test for function split_url
def test_split_url():
    value = 'http://www.ansible.com/path/to/some/file?arg1=val1&arg2=val2#some-fragment'
    assert split_url(value) == {'netloc': 'www.ansible.com', 'scheme': 'http', 'path': '/path/to/some/file', 'query': 'arg1=val1&arg2=val2', 'fragment': 'some-fragment'}
    assert split_url(value, 'netloc') == 'www.ansible.com'
    assert split_url(value, 'scheme') == 'http'
    assert split_url(value, 'path') == '/path/to/some/file'
    assert split_url(value, 'query') == 'arg1=val1&arg2=val2'
   

# Generated at 2022-06-23 10:31:02.391809
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    data = {
        'scheme': 'http',
        'netloc': 'www.cwi.nl:80',
        'path': '/%7Eguido/Python.html',
        'query': '',
        'fragment': ''
    }
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}

    # Test the option query = 'scheme'
    url = 'http://www.cwi.nl:80/%7Eguido/Python.html'
    assert data['scheme'] == split_url(url, 'scheme')

    # Test the option query = 'netloc'
    url = 'http://www.cwi.nl:80/%7Eguido/Python.html'

# Generated at 2022-06-23 10:31:04.071358
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

# Generated at 2022-06-23 10:31:18.743498
# Unit test for function split_url
def test_split_url():
    try:
        split_url('test')
    except AnsibleFilterError as e:
        assert str(e) == "urlsplit: unknown URL component: test"
    assert split_url('https://docs.ansible.com/ansible/latest/user_guide/playbooks_variables.html') == {
        'scheme': 'https',
        'netloc': 'docs.ansible.com',
        'path': '/ansible/latest/user_guide/playbooks_variables.html',
        'params': '',
        'query': '',
        'fragment': ''
    }
    assert split_url('https://docs.ansible.com/ansible/latest/user_guide/playbooks_variables.html', query='fragment') == ''

# Generated at 2022-06-23 10:31:21.344546
# Unit test for function split_url
def test_split_url():
    result = split_url('https://domain.tld/foo.html?key=value&another=one#fragment', 'query')
    assert result=='key=value&another=one'

# Generated at 2022-06-23 10:31:24.007989
# Unit test for function split_url
def test_split_url():
    url = 'https://ansible.com/products/awx/'
    query = 'scheme'
    assert split_url(url, query) == 'https'

# Generated at 2022-06-23 10:31:24.731307
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert getattr(FilterModule, 'filters')

# Generated at 2022-06-23 10:31:26.812676
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    fs = f.filters()
    if "urlsplit" not in fs:
        raise AssertionError("urlsplit not in filters")


# Generated at 2022-06-23 10:31:32.315660
# Unit test for function split_url
def test_split_url():
    assert split_url("http://user:pass@www.example.com:80/foo/bar?key=value#fragment") == {
        'fragment': 'fragment',
        'hostname': 'www.example.com',
        'password': 'pass',
        'path': '/foo/bar',
        'port': 80,
        'query': 'key=value',
        'scheme': 'http',
        'username': 'user'
    }

# Generated at 2022-06-23 10:31:42.990750
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert '''{
    "username": "john+doe",
    "password": "!secret",
    "port": "",
    "netloc": "john+doe:!secret@www.example.org",
    "scheme": "mailto",
    "path": "john.doe@example.org",
    "hostname": "www.example.org",
    "query": "",
    "fragment": "",
    "hostname": "www.example.org"
}''' == str(
        split_url(
            "mailto:john.doe@example.org",
            query=""
        )
    )


# Generated at 2022-06-23 10:31:47.559051
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f is not None
    assert f.filters is not None
    assert 'urlsplit' in f.filters()
    assert callable(f.filters()['urlsplit'])


# Generated at 2022-06-23 10:31:53.855533
# Unit test for function split_url
def test_split_url():
    from ansible.module_utils.network.eos.facts.facts import Facts
    from ansible.module_utils.network.eos.config.config import Config
    from ansible.module_utils.network.eos.utils.utils import get_config, load_config
    from ansible.module_utils.network.eos.plugins.module_utils.network.eos.argspec.facts.facts import FactsArgs

    temp_config = '''
        ntp server 1.1.1.1
        ntp server 2.2.2.2
        ntp server 3.3.3.3
    '''

    running_config = temp_config

    module = MockModule()

# Generated at 2022-06-23 10:32:02.250976
# Unit test for function split_url
def test_split_url():
    assert split_url('http://example.org/path') == {'scheme': 'http', 'netloc': 'example.org', 'path': '/path', 'query': '', 'fragment': ''}
    assert split_url('http://example.org/path', 'scheme') == 'http'
    assert split_url('http://example.org/path', 'path') == '/path'
    assert split_url('http://example.org/path', 'fragment') == ''
    assert split_url('http://example.org/path', 'query') == ''
    assert split_url('http://example.org/path', 'unknown') == ''

# Generated at 2022-06-23 10:32:11.564578
# Unit test for function split_url
def test_split_url():
    """ Test split_url function """
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    results = {}

    def _load_result(result):
        # isinstance check is workaround for https://github.com/ansible/ansible/issues/15834
        results['result'] = result.result if isinstance(result, basic.AnsibleModule) else result

    # This test assumes that this filter is tested after the json_query filter.
    basic._ANSIBLE_ARGS = to_bytes(json.dumps({'ANSIBLE_MODULE_ARGS': {'_ansible_verbose_always': True}}))
    mm = basic.AnsibleModule(argument_spec={})
    mm.exit_json = _load_result

# Generated at 2022-06-23 10:32:21.850786
# Unit test for function split_url
def test_split_url():

    # test data
    data = {
        'url1': 'https://docs.ansible.com/ansible/latest/dev_guide/developing_modules_general.html',
        'url2': 'https://www.example.com/?s=foo',
        'url3': 'https://www.example.com/?s=foo&baz=bar',
        'url4': 'www.example.com/'
    }

    # test individual options
    assert split_url(data['url1'], query='hostname') == 'docs.ansible.com'
    assert split_url(data['url1'], query='path') == '/ansible/latest/dev_guide/developing_modules_general.html'
    assert split_url(data['url2'], query='params') == 's=foo'

# Generated at 2022-06-23 10:32:26.440903
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {"urlsplit": split_url}



# Generated at 2022-06-23 10:32:33.056671
# Unit test for function split_url
def test_split_url():
    assert split_url('http://www.redhat.com') == {'hostname': 'www.redhat.com', 'netloc': 'www.redhat.com', 'path': '', 'scheme': 'http', 'query': ''}
    assert split_url('http://www.redhat.com','netloc') == 'www.redhat.com'
    assert split_url('http://www.redhat.com','scheme') == 'http'
    assert split_url('http://www.redhat.com','path') == ''


# Generated at 2022-06-23 10:32:35.059127
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    instance = FilterModule()
    assert instance.filters() == dict(urlsplit=split_url)


# Generated at 2022-06-23 10:32:37.875625
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urlsplit'] == split_url


# Generated at 2022-06-23 10:32:39.294612
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:32:49.966449
# Unit test for function split_url

# Generated at 2022-06-23 10:32:55.368599
# Unit test for function split_url
def test_split_url():
    # pylint: disable=redefined-outer-name,invalid-name
    url = 'https://www.example.com:8888/path/to/page?k1=v1&k2=v2'

    # request full dictionary
    assert split_url(url) == {
        'scheme': 'https',
        'netloc': 'www.example.com:8888',
        'path': '/path/to/page',
        'query': 'k1=v1&k2=v2',
        'fragment': ''
    }

    # specific query
    assert split_url(url, 'path') == '/path/to/page'
    assert split_url(url, 'query') == 'k1=v1&k2=v2'

    # invalid query

# Generated at 2022-06-23 10:32:58.227527
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """ See if we can create an instance of FilterModule """
    try:
        _ = FilterModule()
    except:
        assert False, "Cannot create an instance of FilterModule"

# Generated at 2022-06-23 10:32:59.904108
# Unit test for constructor of class FilterModule
def test_FilterModule():
        assert type(FilterModule()) == FilterModule


# Generated at 2022-06-23 10:33:03.571240
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert hasattr(FilterModule, "filters")
    assert callable(getattr(FilterModule, "filters", None))
    assert isinstance(FilterModule.filters(), dict)


# Generated at 2022-06-23 10:33:09.018755
# Unit test for function split_url
def test_split_url():
    from nose.tools import assert_equals

    assert_equals(split_url("http://ansible.com/test"),
                  {
                      'scheme': 'http',
                      'netloc': 'ansible.com',
                      'path': '/test',
                      'query': '',
                      'fragment': ''
                  })

    assert_equals(split_url("http://ansible.com/test", "path"),
                  '/test')

    assert_equals(split_url("http://ansible.com/test", "netloc"),
                  'ansible.com')

# Generated at 2022-06-23 10:33:11.455340
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters_dict = module.filters()
    assert 'urlsplit' in filters_dict


# Generated at 2022-06-23 10:33:13.373015
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:33:16.433610
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module is not None
    assert isinstance(filter_module.filters(), dict)
    assert 'urlsplit' in filter_module.filters().keys()


# Generated at 2022-06-23 10:33:24.604647
# Unit test for function split_url
def test_split_url():
    fixture1 = 'http://jinja.pocoo.org/docs/dev/templates/'
    fixture2 = 'https://jinja.pocoo.org/docs/dev/templates/'

    url_dictionary = {
        'scheme': 'http',
        'netloc': 'jinja.pocoo.org',
        'path': '/docs/dev/templates/',
        'query': '',
        'fragment': ''
    }

    url_dictionary2 = {
        'scheme': 'https',
        'netloc': 'jinja.pocoo.org',
        'path': '/docs/dev/templates/',
        'query': '',
        'fragment': ''
    }

    # first fixture test
    # full dictionary

# Generated at 2022-06-23 10:33:27.853435
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert len(FilterModule.filters(FilterModule())) == 1
    assert FilterModule.filters(FilterModule()) == {'urlsplit': split_url}


# Generated at 2022-06-23 10:33:30.307382
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert 'urlsplit' in fm.filters()

# ---------------------------- #


# Generated at 2022-06-23 10:33:32.155407
# Unit test for method filters of class FilterModule

# Generated at 2022-06-23 10:33:33.053419
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-23 10:33:35.709031
# Unit test for function split_url
def test_split_url():

    # Test URL with a query string
    url = 'https://cms.gov?foo=bar'
    query = 'scheme'
    alias = 'urlsplit'
    assert split_url(url, query, alias) == 'https', 'URI test failed.'

# Generated at 2022-06-23 10:33:49.194712
# Unit test for function split_url
def test_split_url():
    """
    Test splitting URLs into components.
    """

    components = split_url('http://www.example.com/path/to/myfile.html', alias='test_split_url')

    assert components['scheme'] == 'http'
    assert components['netloc'] == 'www.example.com'
    assert components['path'] == '/path/to/myfile.html'
    assert components['query'] == ''
    assert components['fragment'] == ''

    component = split_url('http://www.example.com/path/to/myfile.html', 'scheme', alias='test_split_url')
    assert component == 'http'

    component = split_url('http://www.example.com/path/to/myfile.html', 'netloc', alias='test_split_url')

# Generated at 2022-06-23 10:33:54.528059
# Unit test for function split_url
def test_split_url():
    ''' This function tests the behavior of the split_url function '''

    test_values = {
        'scheme': 'https',
        'netloc': 'github.com',
        'path': '/ansible/ansible/issues/8164',
        'query': '',
        'fragment': ''
    }

    test_url = 'https://github.com/ansible/ansible/issues/8164'

    test_result = split_url(test_url)

    for key, value in test_values.items():
        if not test_result[key] == value:
            raise AssertionError('URL component %s does not match expected value (%s): %s' % (key, value, test_result[key]))

    success_message = 'All expected URL components were recognized successfully by split_url'

   

# Generated at 2022-06-23 10:34:04.132839
# Unit test for function split_url
def test_split_url():
    assert split_url('https://www.example.com/path/')['scheme'] == 'https'
    assert split_url('https://www.example.com/path/', 'scheme') == 'https'
    assert split_url('https://www.example.com/path/')['path'] == '/path/'
    assert split_url('https://www.example.com/path/', 'path') == '/path/'
    assert split_url('https://www.example.com/path/?foo=bar&hello=world&something=else')['query'] == 'foo=bar&hello=world&something=else'
    assert split_url('https://www.example.com/path/?foo=bar&hello=world&something=else', 'query') == 'foo=bar&hello=world&something=else'

# Generated at 2022-06-23 10:34:07.737651
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()
    assert filters is not None
    assert isinstance(filters, dict)
    assert 'urlsplit' in filters
    assert callable(filters['urlsplit'])

# Generated at 2022-06-23 10:34:08.880174
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj


# Generated at 2022-06-23 10:34:15.376308
# Unit test for function split_url
def test_split_url():
    from ansible.utils.urls import GenericURL
    assert split_url('https://user:passwd@localhost:8080/path/?param=1') == \
        GenericURL('https', 'user:passwd', 'localhost', 8080, '/path/', 'param=1').params
    assert split_url('https://user:passwd@localhost:8080/path/', query='scheme') == \
        'https'

# Generated at 2022-06-23 10:34:24.783420
# Unit test for function split_url
def test_split_url():
    assert split_url('http://somesite.com/index.html') == {'scheme': 'http', 'netloc': 'somesite.com', 'path': '/index.html', 'query': '', 'fragment': ''}
    assert split_url('http://somesite.com/index.html', 'scheme') == 'http'
    assert split_url('http://somesite.com/index.html', 'netloc') == 'somesite.com'
    assert split_url('http://somesite.com/index.html', 'path') == '/index.html'
    assert split_url('http://somesite.com/index.html', 'query') == ''
    assert split_url('http://somesite.com/index.html', 'fragment') == ''

    assert split_

# Generated at 2022-06-23 10:34:26.715253
# Unit test for constructor of class FilterModule
def test_FilterModule():
        test = FilterModule()
        assert type(test.filters()) is dict

# Generated at 2022-06-23 10:34:28.304759
# Unit test for constructor of class FilterModule
def test_FilterModule():
    result = FilterModule()
    assert isinstance(result, FilterModule)

# Generated at 2022-06-23 10:34:30.060967
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'urlsplit' in filter_module.filters()

# Generated at 2022-06-23 10:34:37.699737
# Unit test for function split_url
def test_split_url():
    '''
    Tests for uri filter.
    '''
    from ansible.errors import AnsibleFilterError
    import re

    f = split_url

    assert f('http://www.example.com') == {
        'fragment': '',
        'hostname': u'www.example.com',
        'netloc': u'www.example.com',
        'params': '',
        'password': '',
        'path': '',
        'port': None,
        'query': '',
        'scheme': u'http',
        'username': '',
    }

    # Test: password / username

# Generated at 2022-06-23 10:34:49.895356
# Unit test for function split_url
def test_split_url():
    '''Unit test for function split_url'''

    #Test to make sure that scheme is returned correctly
    test_url_1 = 'http://www.ansible.com'
    expected_scheme_1 = 'http'
    actual_scheme_1 = split_url(test_url_1, 'scheme')
    assert expected_scheme_1 == actual_scheme_1

    #Test to make sure that netloc is returned correctly
    test_url_2 = 'http://www.ansible.com'
    expected_netloc_2 = 'www.ansible.com'
    actual_netloc_2 = split_url(test_url_2, 'netloc')
    assert expected_netloc_2 == actual_netloc_2

    #Test to make sure that port is returned correctly
    test_url_3

# Generated at 2022-06-23 10:34:50.633763
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()



# Generated at 2022-06-23 10:34:58.263321
# Unit test for function split_url
def test_split_url():
    filtered = split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#hash')
    assert filtered['scheme'] == 'http'
    assert filtered['netloc'] == 'www.example.com'
    assert filtered['path'] == '/path/to/file'
    assert filtered['query'] == 'key1=val1&key2=val2'
    assert filtered['fragment'] == 'hash'

    filtered = split_url('http://www.example.com/path/to/file?key1=val1&key2=val2#hash', query='netloc')
    assert filtered == 'www.example.com'


# Generated at 2022-06-23 10:35:00.188416
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters() == {'urlsplit': split_url}


# Generated at 2022-06-23 10:35:03.659063
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule = FilterModule()
    filtermodule_flat = filtermodule.filters()
    assert 'urlsplit' in filtermodule_flat
    assert filtermodule_flat['urlsplit'].__name__ == 'split_url'

# Generated at 2022-06-23 10:35:06.197144
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters is not None
    assert 'urlsplit' in filters


# Generated at 2022-06-23 10:35:08.124751
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule.filters(FilterModule), dict)

# Generated at 2022-06-23 10:35:10.852313
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'urlsplit' in filter_module.filters()
    assert filter_module.filters()['urlsplit'] == split_url


# Generated at 2022-06-23 10:35:15.178580
# Unit test for function split_url
def test_split_url():
    url = 'https://www.ansible.com/ansible-server'
    assert split_url(url) == {'hostname': 'www.ansible.com', 'netloc': 'www.ansible.com', 'path': '/ansible-server', 'port': None, 'scheme': 'https'}
    assert split_url(url, 'path') == '/ansible-server'
    assert split_url(url, 'port') is None

# Generated at 2022-06-23 10:35:16.968423
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert 'urlsplit' in filters


# Generated at 2022-06-23 10:35:28.262003
# Unit test for function split_url
def test_split_url():
    '''
    Tests the split_url function against a series of
    sample URLs.
    '''



# Generated at 2022-06-23 10:35:31.288309
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'urlsplit': split_url}

# Generated at 2022-06-23 10:35:33.553859
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
       'urlsplit': split_url
    }


# Generated at 2022-06-23 10:35:43.232462
# Unit test for function split_url
def test_split_url():
    assert split_url('http://localhost/path', 'scheme') == 'http'
    assert split_url('http://localhost/path', 'netloc') == 'localhost'
    assert split_url('http://localhost/path', 'path') == '/path'
    assert split_url('http://localhost/path', 'query') == ''
    assert split_url('http://localhost/path', 'fragment') == ''
    assert split_url('http://localhost/path?query=true', 'query') == 'query=true'
    assert split_url('http://localhost/path?query=true', 'fragment') == ''
    assert split_url('http://localhost/path?query=true#fragment', 'fragment') == 'fragment'

# Generated at 2022-06-23 10:35:45.969042
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    o = FilterModule()
    assert o.filters()['urlsplit'] == split_url



# Generated at 2022-06-23 10:35:54.042683
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('http://www.cwi.nl:80/%7Eguido/Python.html')['scheme'] == 'http'
    assert split_url('http://www.cwi.nl:80/%7Eguido/Python.html', 'query') == ''
    assert split_url('http://www.cwi.nl:80/%7Eguido/Python.html', 'query') == ''
    assert split_url('http://www.cwi.nl:80/%7Eguido/Python.html', 'path') == '/%7Eguido/Python.html'

# Generated at 2022-06-23 10:36:00.054075
# Unit test for function split_url
def test_split_url():
    assert split_url('https://username:password@hostname:port/path?arg=value#anchor') == \
    {'hostname': 'hostname', 'netloc': 'username:password@hostname:port', 'scheme': 'https', 'path': '/path', 'fragment': 'anchor', 'query': 'arg=value', 'username': 'username', 'password': 'password', 'port': 'port'}

# Generated at 2022-06-23 10:36:02.280227
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
	assert FilterModule.filters(FilterModule) == {
		'urlsplit': split_url
	}


# Generated at 2022-06-23 10:36:05.771999
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_input = 'http://www.example.org:8080/path;parameters?query=arg#fragment'
    url_dict = test_FilterModule_filters_urlsplit(test_input)
    assert url_dict['fragment'] == 'fragment'


# Generated at 2022-06-23 10:36:07.460321
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')

# Generated at 2022-06-23 10:36:11.368202
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert split_url('http://docs.ansible.com') == {
        'scheme': 'http',
        'netloc': 'docs.ansible.com',
        'path': '',
        'params': '',
        'query': '',
        'fragment': '',
    }