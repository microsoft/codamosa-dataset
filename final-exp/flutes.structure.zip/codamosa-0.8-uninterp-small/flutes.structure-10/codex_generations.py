

# Generated at 2022-06-25 16:44:54.290332
# Unit test for function map_structure
def test_map_structure():
    print(map_structure(lambda x: x + 1, [1, 2, [3, 4]]))
    print(map_structure(lambda x: x + 1, (1, 2, [3, 4])))
    print(map_structure(lambda x: x + 1, (1, 2, (3, 4))))
    print(map_structure(lambda x: x + 1, {'a': 1, 'b': 2, 'c': [3, 4]}))
    print(map_structure(lambda x: x + 1, {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}))


# Generated at 2022-06-25 16:44:55.868376
# Unit test for function no_map_instance
def test_no_map_instance():
    set_0 = None
    var_0 = no_map_instance(set_0)



# Generated at 2022-06-25 16:45:04.254001
# Unit test for function no_map_instance
def test_no_map_instance():
    from torch.nn import Module
    from torch.optim import Optimizer
    from torch.utils import data

    class NonMappable(data.DataLoader):
        pass

    class NonMappableModule(Module):
        pass

    class NonMappableOptimizer(Optimizer):
        pass

    register_no_map_class(NonMappable)
    register_no_map_class(NonMappableModule)
    register_no_map_class(NonMappableOptimizer)

    from pywick.utils.structures import no_map_instance, map_structure

    def test_check(value):
        assert hasattr(value, "--no-map--")

    def test_fn(value):
        return value

    cuda = torch.device("cuda")


# Generated at 2022-06-25 16:45:17.823409
# Unit test for function map_structure
def test_map_structure():
    def test(xs, fn, expected):
        assert map_structure(fn, xs) == expected

    # Test function `map_structure` with input list `xs`.
    def test_map_structure_0(xs, fn, expected):
        return test(xs, fn, expected)

    xs = [1, 2, 3]
    fn = lambda x: x * x
    expected = [1, 4, 9]
    test_map_structure_0(xs, fn, expected)  # __map_structure__

    # Test function `map_structure` with input tuple `xs`.
    def test_map_structure_1(xs, fn, expected):
        return test(xs, fn, expected)

    xs = (1, 2, 3)
    fn = lambda x: x * x
   

# Generated at 2022-06-25 16:45:27.528041
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def foo(x, y):
        return x+y

    def test_map_structure_zip_in_foo(a, b):
        c = map_structure_zip(foo, (a, b))
        return c
    a = {'a': [1,2,3], 'b': [4,5,6]}
    b = {'a': [1,2,3], 'b': [1,1,1]}
    res = test_map_structure_zip_in_foo(a, b)
    assert res == {'a': [2, 4, 6], 'b': [5, 6, 7]}


# Generated at 2022-06-25 16:45:32.069927
# Unit test for function no_map_instance
def test_no_map_instance():
    # Create a set containing the expected, ordered result.
    expected_0 = None

    # Call the solution.
    try:
        result_0 = test_case_0()
    except ValueError:
        assert False

    # Compare the result to the expected value.
    assert expected_0 == result_0

# Generated at 2022-06-25 16:45:43.861515
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # The structure must be identical for all collections
    structure = [1, [2, 3, 4], 'foo', (1, 2), {1, 3, 5}, {'foo': 1, 'bar': 2}]

    # Test for list as input
    assert map_structure_zip(lambda *xs: xs, [structure]) == structure
    assert map_structure_zip(lambda *xs: xs, [structure, []]) == structure
    assert map_structure_zip(lambda *xs: xs, [structure, structure]) == structure
    assert map_structure_zip(sum, [structure, structure]) == structure
    assert map_structure_zip(sum, [[1], [2, 3], [4, 5, 6]]) == [7, 8, 9]

    # Test for tuple as input
   

# Generated at 2022-06-25 16:45:48.454228
# Unit test for function no_map_instance
def test_no_map_instance():
    assert callable(no_map_instance)
    # call the function

    try:
        test_case_0()
    # assert the result

    except Exception:
        assert False


# Generated at 2022-06-25 16:45:55.037109
# Unit test for function no_map_instance
def test_no_map_instance():
    # Immutable
    set_0 = {1, 2, 3}
    var_0 = no_map_instance(set_0)
    assert var_0 == {1, 2, 3}
    assert type(var_0) != type(set_0)

    # Mutable
    list_0 = [1, 2, 3]
    var_1 = no_map_instance(list_0)
    assert var_1 == [1, 2, 3]
    assert type(var_1) != type(list_0)

    # Nested
    dict_0 = {1: [1, 2, 3], 2: {1: 4, 2: 5}, 3: "6"}
    var_2 = no_map_instance(dict_0)

# Generated at 2022-06-25 16:46:03.069631
# Unit test for function map_structure_zip
def test_map_structure_zip():
    dict_0 = {}
    dict_1 = {}
    dict_0["dict_key_0"] = dict_1
    dict_1["dict_key_0"] = ["dict_key_0"]
    dict_1["dict_key_1"] = "dict_key_1"
    dict_1["dict_key_2"] = []
    dict_1["dict_key_3"] = ["dict_key_1"]
    dict_1["dict_key_4"] = "dict_key_0"
    dict_1["dict_key_5"] = []
    dict_1["dict_key_6"] = ["dict_key_1"]
    dict_1["dict_key_7"] = "dict_key_0"
    dict_1["dict_key_8"] = []

# Generated at 2022-06-25 16:46:15.708873
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # Check all of the combinations of positional arguments and keywords,
    # including the no-argument case.
    var_0 = map_structure_zip(lambda x, y: (x*x, y*y), [[1,2,3], [4,5,6]])
    assert var_0 == ([1,4,9], [16,25,36])


# Generated at 2022-06-25 16:46:20.241781
# Unit test for function map_structure_zip
def test_map_structure_zip():
    var_1 = [1, 2, "a"]
    var_2 = [2, 3, "b"]
    var_3 = [var_1, var_2]
    var_1 = map_structure_zip(var_0, var_3)
    print(var_1)


# Generated at 2022-06-25 16:46:25.783711
# Unit test for function map_structure_zip
def test_map_structure_zip():
    fn = lambda xs: [x for x in xs if x is not None]
    objs = (('a', 5, None, [1, 2, 3]), ('b', 6, 0, None))
    result = map_structure_zip(fn, objs)
    print(result)
    # assert result == ('a', 5, 0, [1, 2, 3]), "Error: wrong result for map_structure_zip([('a', 5, None, [1, 2, 3]), ('b', 6, 0, None)])"
    # var_1 = lambda x: map_structure_zip(fn, objs)


# Generated at 2022-06-25 16:46:31.224877
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    result = map_structure_zip(lambda c, b, a: a * 1000 + b * 100 + c * 10, (a, b, c))
    print(result)



# Generated at 2022-06-25 16:46:42.383612
# Unit test for function map_structure
def test_map_structure():
    global map_structure
    # 5
    x = map_structure(var_0, [])
    # 6
    x = map_structure(var_0, {})
    # 7
    x = map_structure(var_0, [1, 2])
    # 8
    x = map_structure(var_0, [1, 2, 3])
    # 9
    x = map_structure(var_0, [1, 2, 3, 4])
    # 10
    x = map_structure(var_0, [1, 2, 3, 4, 5])
    # 11
    x = map_structure(var_0, [1, 2, 3, 4, 5, 6])
    # 12

# Generated at 2022-06-25 16:46:46.603025
# Unit test for function map_structure_zip
def test_map_structure_zip():
    cases = [
        (test_case_0, "lambda x: x * x"),
    ]
    for (fn, sig) in cases:
        sig_ = signature(fn)
        assert sig == sig_

# Generated at 2022-06-25 16:46:54.866922
# Unit test for function map_structure
def test_map_structure():
    # LCOV_EXCL_START
    lst = [1, 2, 3]
    var_0 = lambda x: x * x
    assert map_structure(var_0, lst) == [1, 4, 9]
    assert map_structure(var_0, [lst, 2 * lst]) == [[1, 4, 9], [1, 4, 9, 1, 4, 9]]



# Generated at 2022-06-25 16:47:05.419559
# Unit test for function map_structure_zip
def test_map_structure_zip():
    assert map_structure_zip(lambda x, y: x * y, [[1, 2, 3], [4, 5, 6]]) == [4, 10, 18]
    assert map_structure_zip(lambda x, y: x * y, ([1, 2, 3], [4, 5, 6])) == (4, 10, 18)
    assert map_structure_zip(lambda x, y: x * y, ({1, 2, 3}, {4, 5, 6})) == {4, 10, 18}
    assert map_structure_zip(lambda x, y: x * y, ({1: 4, 2: 5, 3: 6}, {4: 1, 5: 2, 6: 3})) == {1: 4, 2: 10, 3: 18}
    # assert map_structure_zip(lambda x,

# Generated at 2022-06-25 16:47:12.370876
# Unit test for function map_structure
def test_map_structure():
    def func(x):
        return (x)

    def func_2(x):
        return (x)

    def func_3(x):
        return (x)

    def func_4(x):
        return (x)

    def func_5(x):
        return (x)

    def func_6(x):
        return (x)

    def func_7(x):
        return (x)

    def func_8(x):
        return (x)

    def func_9(x):
        return (x)

    def func_10(x):
        return (x)

    def func_11(x):
        return (x)

    def func_12(x):
        return (x)

    def func_13(x):
        return (x)


# Generated at 2022-06-25 16:47:23.750954
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def check_map_structure_zip(fn, objs):
        assert map_structure_zip(fn, objs) == fn(*objs)

    check_map_structure_zip(lambda x, y: x + y, (1, 2))
    check_map_structure_zip(lambda x, y: x + y, (1, (2, 3)))
    check_map_structure_zip(lambda x, y: x + y, ((1, 2), (3, 4)))
    check_map_structure_zip(lambda x, y: x + y, ((1, 2), [3, 4]))
    check_map_structure_zip(lambda x, y: x + y, [(1, 2), (3, 4)])

# Generated at 2022-06-25 16:47:35.482218
# Unit test for function map_structure
def test_map_structure():

    assert(map_structure(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4])
    assert(map_structure(lambda x: x + 1, (1, 2, 3)) == (2, 3, 4))
    assert(map_structure(lambda x: x + 1, [1, (2, 2, 3)]) == [2, (3, 3, 4)])
    assert(map_structure(lambda x: x + 1, {1: 2, 3: 4}) == {2: 3, 4: 5})
    assert(map_structure(lambda x: x + 1, {(1, 2, 3): 2, (1, 3, 3): 3}) == {(2, 3, 4): 3, (2, 4, 4): 4})

# Generated at 2022-06-25 16:47:45.927602
# Unit test for function map_structure
def test_map_structure():
    # Test case where fn is identity function
    f = lambda x:x
    g = lambda x:x
    x = {1:1,2:{2:2,3:{3:3}}}
    x_map = map_structure(f,x)
    assert x_map == x

    # Test case where fn is the squaring function
    f = lambda x: x ** 2
    g = lambda x: x ** 2
    x = {1:1,2:{2:2,3:{3:3}}}
    x_map = map_structure(f,x)
    assert x_map == {1:1,2:{2:4,3:{3:9}}}

    # Test case where fn is the squaring function on a nested list
    f = lambda x: x ** 2
    g = lambda x: x ** 2
   

# Generated at 2022-06-25 16:47:51.355358
# Unit test for function map_structure
def test_map_structure():
    import numpy as np
    a = np.array([1,2,3])
    b = np.array([4,5,6])
    fn = lambda x,y : x*y
    assert all(map_structure(fn, [a,b]) == np.array([4,10,18]))


# Generated at 2022-06-25 16:48:04.028907
# Unit test for function map_structure_zip
def test_map_structure_zip():
    nums = [0, 1, 2]
    tuple0 = (0,1)
    list0 = [0,1]
    nested_tuple = (tuple0,tuple0)
    nested_list = [list0, list0]
    dict0 = {'1':1,'2':2}
    dict1 = {'1':'yes','2':'no'}
    
    expected_nums = [i*2 for i in nums]
    expected_func = lambda x1,x2 : x1+x2
    expected_nested_tuple = ((0,1),(0,1))
    expected_nested_list = [[0,1],[0,1]]
    expected_dict = {'1':2,'2':4}

# Generated at 2022-06-25 16:48:10.284045
# Unit test for function map_structure_zip
def test_map_structure_zip():
    class TestA(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    t1 = TestA(1, 2)
    t1 = no_map_instance(t1)
    t2 = TestA(3, 4)
    t2 = no_map_instance(t2)
    t = map_structure_zip(lambda a, b: a + b, [t1, t2])
    print(t.a, t.b)


# Generated at 2022-06-25 16:48:16.827884
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = {
        'a': 1,
        'b': 2,
        'c': 3
    }

    b = {
        'a': 10,
        'b': -10,
        'c': 9
    }

    c = {
        'a': 5,
        'b': -3,
        'c': -2
    }

    d = {
        'a': [1, 2, 3, 4, 5],
        'b': "test",
        'c': [{'d': 0, 'f': 1}, {'d': 4, 'f': 4}]
    }

    def fn(x, y, z):
        return x + y + z

    abc_sum = map_structure_zip(fn, (a, b, c))

# Generated at 2022-06-25 16:48:25.985979
# Unit test for function map_structure
def test_map_structure():
    example_dict = {'a':1, 'b':2}
    example_list = [1,2,3]
    example_tuple = (1,2,3)
    example_named_tuple = namedtuple('point', ['x', 'y'])
    example_set = {'a', 'b', 'c'}

    def func(x:T) -> R:
        return x*2

    assert(map_structure(func, example_dict) == {'a': 2, 'b': 4})
    assert(map_structure(func, example_list) == [2,4,6])
    assert(map_structure(func, example_tuple) == (2,4,6))

# Generated at 2022-06-25 16:48:29.510465
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # Actually no test is done.
    # Just check if the function can be called without crash.

    # [TODO]
    print("test_map_structure_zip not implemented")
    print("test_map_structure_zip not implemented")
    print("test_map_structure_zip not implemented")



# Generated at 2022-06-25 16:48:38.209172
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # The input
    a = [1, 2, 3]
    b = [1, 2, 3]
    c = [1, 2, 3]
    # The function
    @no_type_check
    def sum_3(x, y, z):
        return x + y + z
    # The expected output
    expected = [3, 6, 9]
    # Test
    actual = map_structure_zip(sum_3, [a, b, c])

    assert actual == expected


# Generated at 2022-06-25 16:48:46.871877
# Unit test for function map_structure
def test_map_structure():
    list_to_print = [1,2,3,4]
    print(map_structure(lambda a: str(a) + '_new', list_to_print))
    tuple_to_print = (1,2,3,4)
    print(map_structure(lambda a: str(a) + '_new', tuple_to_print))
    dict_to_print = {1:1, 2:2}
    print(map_structure(lambda a: str(a) + '_new', dict_to_print))
    set_to_print = {1, 2, 3}
    print(map_structure(lambda a: str(a) + '_new', set_to_print))
    

# Generated at 2022-06-25 16:49:01.020320
# Unit test for function map_structure_zip
def test_map_structure_zip():
    test_tuple = ((1, 2), (3, 4))
    test_list = [[1, 2], [3, 4]]
    test_set = ({1, 2}, {3, 4})

    def sum_fn(*args):
        return sum(args)

    result_tuple = map_structure_zip(sum_fn, test_tuple)
    result_list = map_structure_zip(sum_fn, test_list)
    result_set = map_structure_zip(sum_fn, test_set)

    assert result_tuple == (3, 7)
    assert result_list == [3, 7]
    assert result_set == {3, 7}


# Generated at 2022-06-25 16:49:08.609924
# Unit test for function map_structure_zip
def test_map_structure_zip():
    #Test 1: Regular map
    vocab_size = 10
    entities = [['a', 'b', 'c'], ['d', 'e']]
    range_ = range(0, vocab_size)
    ret = map_structure_zip(lambda x, y: (x == y), entities, range_)
    ret_expected = [[False, False, False], [False, False]]
    assert ret_expected == ret

    #Test 2: Empty list
    ret = map_structure_zip(lambda x, y: list(), entities, [])
    ret_expected = [[], []]
    assert ret_expected == ret

    #Test 3: nested lists
    entities = [['a', 'b', 'c'], [['d', 'e'], ['f', ['g', 'h']]]]
    range_ = range

# Generated at 2022-06-25 16:49:17.666800
# Unit test for function map_structure
def test_map_structure():
    # Test case 0
    class_0 = [1, 2, 3]
    function_0 = lambda x: x * 2
    result = map_structure(function_0, class_0)
    assert result == [2, 4, 6], result

    # Test case 1
    class_1 = [(1, 2), (3, 4), (5, 6)]
    function_1 = lambda x: x * 2
    result = map_structure(function_1, class_1)
    assert result == [(2, 4), (6, 8), (10, 12)], result

    # Test case 2
    class_2 = [1, (2, 3), [4, 5, 6]]
    function_2 = lambda x: x * 2 if isinstance(x, int) else x[::-1]
    result = map_st

# Generated at 2022-06-25 16:49:29.141655
# Unit test for function map_structure_zip
def test_map_structure_zip():
    my_list = [['a', 1], ['b', 2]]
    my_tuple = (['a', 1], ['b', 2])

    def comb_list(xs, ys):
        return xs+ys

    def comb_tuple(xs, ys):
        return xs+ys

    my_list_result = map_structure_zip(comb_list, my_list)
    my_tuple_result = map_structure_zip(comb_tuple, my_tuple)

    # assert example
    # https://www.programiz.com/python-programming/assert-debug-handling
    assert my_list_result == [['a', 'b'], [1, 2]]
    assert my_tuple_result == [['a', 'b'], [1, 2]]

# Generated at 2022-06-25 16:49:33.776544
# Unit test for function map_structure_zip
def test_map_structure_zip():
    map_structure_zip(lambda x: x+1, [[1, 2], [3, 4]]) #should return [[2, 3], [4, 5]]


# Generated at 2022-06-25 16:49:40.965731
# Unit test for function map_structure
def test_map_structure():
    assert map_structure(lambda x: x**2, [[1, 2], [3, 4]]) == [[1, 4], [9, 16]]
    assert map_structure(lambda x: x**2, [[1, 2], (3, 4)]) == [[1, 4], (9, 16)]
    assert map_structure(lambda x: x**2, [(1, 2), [3, 4]]) == [(1, 4), [9, 16]]


# Generated at 2022-06-25 16:49:49.133541
# Unit test for function map_structure_zip
def test_map_structure_zip():
    type_0 = None
    type_1 = None
    type_2 = None
    fn_1 = lambda obj, x: obj+x
    # obj_1 = ([(1, 2), (3, 4)], [(5, 6), (7, 8)])
    obj_1 = ([1,1,1], [2,2,2])
    map_structure_zip(fn_1, obj_1)


if __name__ == '__main__':
    test_case_0()
    test_map_structure_zip()

# Generated at 2022-06-25 16:49:59.049947
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import numpy as np

    def f(x, y):
        x_np = np.array(x)
        y_np = np.array(y)
        return x_np + y_np

    a = [0, 1, 2, 3]
    b = [[0], [1], [2], [3]]
    c = [[0, 0], [1,1], [2, 2], [3, 3]]

    a_b_c = map_structure_zip(f, (a,b,c))
    assert a_b_c == [0, 1, 2, 3], "Test failed."

    a_b_c = map_structure_zip(f, (b,a,c))
    assert a_b_c == [[0], [1], [2], [3]], "Test failed."



# Generated at 2022-06-25 16:50:02.242251
# Unit test for function map_structure_zip
def test_map_structure_zip():
    objs = [[],["k1","k2"],["k3","k4"]]
    fn =  lambda *objs : objs
    result = dict(map_structure_zip(fn,objs))
    print(result)


# Generated at 2022-06-25 16:50:11.769767
# Unit test for function map_structure
def test_map_structure():
    import torch
    import torch.nn.modules as modules
    import torch.nn.functional as functional

    def module_dict_mapper(total_dict: dict) -> dict:
        new_dict = dict()
        for key, value in total_dict.items():
            if type(value) is dict:
                new_dict[key] = module_dict_mapper(value)
            else:
                new_dict[key] = functional.relu(value)
        return new_dict

    input_data = torch.randn(5,5)
    seq_model = modules.Sequential(modules.Linear(5,5), modules.ReLU())

# Generated at 2022-06-25 16:50:29.099788
# Unit test for function map_structure_zip
def test_map_structure_zip():
    list_x_y = [
        [[[1, 2], [3, 4]], [[5, 6], [7, 8]]],
        [[[9, 10], [11, 12]], [[13, 14], [15, 16]]]
    ]
    list_x_y_z = [list_x_y, [[[17, 18], [19, 20]], [[21, 22], [23, 24]]]]

    # test list
    assert map_structure_zip(lambda x, y, z: x + y + z, list_x_y_z) == [
        [[[1, 2], [3, 4]], [[5, 6], [7, 8]]],
        [[[9, 10], [11, 12]], [[13, 14], [15, 16]]]
    ]

    # test tuple
   

# Generated at 2022-06-25 16:50:37.326437
# Unit test for function map_structure_zip
def test_map_structure_zip():
    print("test_map_structure_zip")
    print(map_structure_zip(lambda *x: x, [{1: "a"}, {2: "b"}]))
    print(map_structure_zip(lambda *x: x, [{1: "a"}, {4: "c"}]))
    print(map_structure_zip(lambda *x: x, [{1: "a"}, {2: "b"}, {3: "c"}]))
    print(map_structure_zip(lambda *x: x, [{1: "a", 2: "b"}, {3: "c", 4: "d"}]))
    raise Exception


# Generated at 2022-06-25 16:50:44.845358
# Unit test for function map_structure_zip
def test_map_structure_zip():

    def sum_of_sums(x, y):
        return sum(sum(x)), sum(sum(y))

    a = [[1, 1.5, 2], [3, 4, 5]]
    b = [[1.5, 2, 3], [4, 5, 6]]

    result = map_structure_zip(sum_of_sums, a, b)

    print(result)


if __name__ == '__main__':
    # test_case_0()
    test_map_structure_zip()

# Generated at 2022-06-25 16:50:59.392371
# Unit test for function map_structure
def test_map_structure():
    test_0 = map_structure(lambda x: x, [1, 2, 3])
    assert test_0 == [1, 2, 3]

    test_1 = map_structure(lambda x: x, [[1, 2], [3, 4]])
    assert test_1 == [[1, 2], [3, 4]]

    test_2 = map_structure(lambda x: x, [[[1, 2, 3], [2, 3, 4]], [[3, 4, 5], [4, 5, 6]]])
    assert test_2 == [[[1, 2, 3], [2, 3, 4]], [[3, 4, 5], [4, 5, 6]]]

    test_3 = map_structure(lambda x: x, (1, 2, 3))

# Generated at 2022-06-25 16:51:11.772825
# Unit test for function map_structure
def test_map_structure():
    base_dict = {'one': 1, 'two': 2, 'three': 3}
    l2v_dict = base_dict.copy()
    l2v_dict['lst'] = [1, 2, 3, 4]
    l2v_dict['dict'] = base_dict
    l2v_dict['tupple'] = (1, 2, 3, 4)
    l2v_dict['set'] = {'five', 'six'}

    def plus_one(x):
        return x + 1

    def plus_ten(x):
        if isinstance(x, dict):
            return {k: v + 10 for k, v in x.items()}
        elif isinstance(x, list):
            return [i + 10 for i in x]

# Generated at 2022-06-25 16:51:22.651799
# Unit test for function map_structure_zip
def test_map_structure_zip():
    from test_cases.test_input_type import Type0, Type1, Type2, Type3

    type_0 = Type0()
    type_0.value = 1
    type_1 = Type1()
    type_1.value = 2
    type_2 = Type2()
    type_2.value = 5
    type_3 = Type3()
    type_3.value = 3
    type_3.child = type_2

    register_no_map_class(Type0)
    register_no_map_class(Type1)
    register_no_map_class(Type2)
    register_no_map_class(Type3)

    def fn(a, b, c, d):
        return a.value + b.value + c.value + d.value

    result = map_structure_zip

# Generated at 2022-06-25 16:51:26.830004
# Unit test for function map_structure
def test_map_structure():
    type_0 = map_structure(lambda x: x, [1, 2, 3])
    assert isinstance(type_0, list)
    assert len(type_0) == 3
    assert type_0[0] == 1
    assert type_0[1] == 2
    assert type_0[2] == 3


# Generated at 2022-06-25 16:51:33.649510
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def f(a, b):
        return a + b

    def g(a, b, c):
        return a, b, c

    assert map_structure_zip(f, [1, 2, 3], [10, 20, 30]) == [11, 22, 33]
    assert map_structure_zip(g, [1, 2, 3], [10, 20, 30], [100, 200, 300]) == [(1, 10, 100), (2, 20, 200), (3, 30, 300)]
    assert map_structure_zip(g, [[1, 2], [3]], [[10, 20], [30]]) == [[(1, 10), (2, 20)], [(3, 30)]]

# Generated at 2022-06-25 16:51:45.456716
# Unit test for function map_structure_zip
def test_map_structure_zip():
    l = [0, 1, 2]
    t = (3, 4, 5)
    d = {'a': 6, 'b': 7, 'c': 8}
    s = {9}

    f = lambda x: x + 1
    f2 = lambda x, y: 2 * (x + y)

    assert map_structure(f, l) == [1, 2, 3]
    assert map_structure(f, t) == (4, 5, 6)
    assert map_structure(f, d) == {'a': 7, 'b': 8, 'c': 9}
    assert map_structure(f, s) == {10}

    assert map_structure_zip(f2, [l, l]) == [2, 4, 6]

# Generated at 2022-06-25 16:51:57.801591
# Unit test for function map_structure
def test_map_structure():
    # Test map_structure on nested list
    nested_list_1 = [[1, 2, 3], [4, 5, 6]]
    nested_list_2 = [[2, 4, 6], [8, 10, 12]]
    assert map_structure(lambda x: x * 2, nested_list_1) == nested_list_2

    # Test map_structure on nested tuple
    nested_tuple_1 = ((1, 2, 3), (4, 5, 6))
    nested_tuple_2 = ((2, 4, 6), (8, 10, 12))
    assert map_structure(lambda x: x * 2, nested_tuple_1) == nested_tuple_2

    # Test map_structure on nested namedtuple

# Generated at 2022-06-25 16:52:24.472826
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [(1, 2, 3), ('a','b','c')]
    b = [(4, 5, 6), ('d','e','f')]
    c = [(7, 8, 9), ('g','h','i')]
    a_c = map_structure_zip(sum, [a, b, c])
    assert(a_c == [(12, 15, 18), ('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i')])

# Generated at 2022-06-25 16:52:36.670337
# Unit test for function map_structure
def test_map_structure():
    def foo(x):
        return [x]

    t = (((3, 6), 5), 1)
    assert map_structure(foo, t) == ((([3], [6]), [5]), [1])

    t = (1, [[5, [9]], [2, 3], [2, 3, 1]])
    assert map_structure(foo, t) == ([1], [[[5], [[9]]], [[2], [3]], [[2], [3], [1]]])

    t = (1, {2: 3, 4: 5, 7: (9, 10)})
    assert map_structure(foo, t) == ([1], {2: [3], 4: [5], 7: ([9], [10])})


# Generated at 2022-06-25 16:52:47.380362
# Unit test for function map_structure_zip
def test_map_structure_zip():
    Dict_1 = {"a": 1, "b": 2}
    Dict_2 = {"a": 3, "b": 4}
    Dict_3 = {"a": 5, "b": 6}
    assert map_structure_zip(lambda x,y,z: x+y+z, [Dict_1, Dict_2, Dict_3]) == {"a": 9, "b": 12}
    assert map_structure_zip(lambda x,y,z: x+y+z, [Dict_1, Dict_2]) == {"a": 4, "b": 6}

    List_1 = [1, 2, 3]
    List_2 = [3, 4, 5]
    List_3 = [5, 6, 7]

# Generated at 2022-06-25 16:52:56.758111
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # 1st case
    k = [[[-1, 10, -1], [-1, -1, -1], [-1, -1, -1]], [[-1, -1, -1], [-1, -1, -1], [-1, -1, -1]]]
    a = [[[10, 1, 10], [-1, -1, -1], [-1, -1, -1]], [[-1, -1, -1], [-1, -1, -1], [-1, -1, -1]]]
    b = [[[-1, 1, 10], [-1, -1, -1], [-1, -1, -1]], [[-1, -1, -1], [-1, -1, -1], [-1, -1, -1]]]

# Generated at 2022-06-25 16:53:06.863864
# Unit test for function map_structure
def test_map_structure():
    def add_one(x):
        return x + 1

    d = {
        "name": "Kapil",
        "age": 20,
        "address": {
            "street": "Geeska Afrika",
            "number": 65,
            "code": "Odense",
            "country": "Denmark",
        },
        "faculty": "IT Innovation",
    }

    d_list = ["Kapil", 20, {"street": "Geeska Afrika", "number": 65, "code": "Odense", "country": "Denmark"}, "IT Innovation"]


# Generated at 2022-06-25 16:53:16.665459
# Unit test for function map_structure
def test_map_structure():
    type_0 = None
    type_1 = [list, dict, set]
    type_2 = []
    type_3 = [list]
    type_4 = [[list, dict, set]]
    type_5 = [[list]]
    type_6 = [list, tuple, dict, set]
    type_7 = [dict, tuple, set]
    type_8 = ["list", "tuple", "dict", "set"]
    type_9 = [type_8]
    type_10 = [[type_8]]
    type_11 = [[[type_8]]]
    type_12 = [[[tuple, set], [type_8]]]
    type_13: List[List[List[type]]] = [[[tuple, set], [type_8]]]
    type_14: List[List[type]]

# Generated at 2022-06-25 16:53:21.657120
# Unit test for function map_structure
def test_map_structure():
    # case 0
    test_case_0()
    test_type = list()
    assert test_type in _NO_MAP_TYPES


# Generated at 2022-06-25 16:53:31.408928
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # Base case
    dict_0 = dict()
    dict_1 = dict()
    fn_0 = (lambda x, y : x + y)
    map_structure_zip(fn_0, [dict_0, dict_1])
    
    # Nested case
    dict_2 = dict()
    dict_2['string'] = 'abc'
    dict_2['nested_list'] = [1, 2]
    dict_3 = dict()
    dict_3['string'] = 'def'
    dict_3['nested_list'] = ['a', 'b']
    fn_1 = (lambda x, y : dict())
    map_structure_zip(fn_1, [dict_2, dict_3])
    
    # List case
    list_0 = []
    list_1 = []


# Generated at 2022-06-25 16:53:41.626802
# Unit test for function map_structure
def test_map_structure():
    import torch

    register_no_map_class(torch.Size)

    fu = lambda x: x ** 2
    li = [1, 2, 3]
    tu = (1, 2, 3)
    di = {'A': 1, 'B': 2, 'C': 3}

    assert (map_structure(fu, li) == [1, 4, 9])
    assert (map_structure(fu, tu) == (1, 4, 9))
    assert (map_structure(fu, di) == {'A': 1, 'B': 4, 'C': 9})
    assert (map_structure(fu, torch.Size((1, 2, 3))) == torch.Size((1, 4, 9)))



# Generated at 2022-06-25 16:53:49.275008
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # Test case 1: List
    print(map_structure_zip(lambda x, y, z: x + y + z, [1, 2, 3], [4, 5, 6], [7, 8, 9]))
    # Test case 2: Tuple
    print(map_structure_zip(lambda x, y, z: x + y + z, (1, 2, 3), (4, 5, 6), (7, 8, 9)))
    # Test case 3: Dict
    print(map_structure_zip(lambda x, y: x + y, {'a': 1, 'b': 2}, {'a': 3, 'b': 4}))
    # Test Case 4: Registed Type
    class A:
        pass
    register_no_map_class(A)

# Generated at 2022-06-25 16:54:32.778349
# Unit test for function map_structure_zip
def test_map_structure_zip():
    d = {
        'x': [0, 1, 2],
        'y': [10, 11, 12]
    }
    add = lambda x, y: x + y
    assert map_structure_zip(add, d.values()) == [0 + 10, 1 + 11, 2 + 12]
    assert map_structure_zip(lambda x, y: [x, y], d.values()) == \
           [[0, 10], [1, 11], [2, 12]]

# Generated at 2022-06-25 16:54:41.072649
# Unit test for function map_structure
def test_map_structure():
    assert map_structure(lambda x: x**2, [[1,2,3], [4,5,6]]) == [[1,4,9], [16,25,36]]
    assert map_structure(lambda x: x**2, [[1,2,3], [4,5,6], [7,8,9]]) == [[1,4,9], [16,25,36], [49,64,81]]