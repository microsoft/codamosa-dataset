

# Generated at 2022-06-25 16:44:52.038352
# Unit test for function no_map_instance
def test_no_map_instance():
    test_case_0()
    str_1 = "a"
    for i in range(0,50-1):
        str_1 = str_1 + str(i)
    list_0 = []
    for j in range(0,50-1):
        list_0.append(str_1)
    list_0.append(str_0)
    list_0.append(str_1)
    register_no_map_class(list_0)
    for k in range(0,70-1):
        assert(list_0[0][i] == str_1[i])
        assert(list_0[1][i] == str_1[i])
    print("Passed!")

# Generated at 2022-06-25 16:45:03.999266
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(x: int, y: str) -> float:
        return float(x) + float(y)

    n = 2
    a, b, c = [map_structure_zip(fn, [[1], [2]]) for _ in range(n)]
    assert isinstance(a, float)
    assert isinstance(b, float)
    assert isinstance(c, float)
    assert a != b
    assert a not in [b, c]

    a, b, c = [map_structure_zip(fn, [[1, 2], ["a", "b"]]) for _ in range(n)]
    assert isinstance(a, list)
    assert isinstance(b, list)
    assert isinstance(c, list)
    assert a != b
    assert a not in [b, c]

    a,

# Generated at 2022-06-25 16:45:17.832965
# Unit test for function map_structure
def test_map_structure():
    def foo(x):
        return x + 1

    test_case_0()

# Generated at 2022-06-25 16:45:18.681211
# Unit test for function no_map_instance
def test_no_map_instance():
    test_case_0()

# Generated at 2022-06-25 16:45:19.508961
# Unit test for function map_structure
def test_map_structure():
    return 1


# Generated at 2022-06-25 16:45:29.908508
# Unit test for function map_structure_zip
def test_map_structure_zip():
    assert(map_structure_zip(add, [[2, 2], [2, 2]]) == [4, 4])
    assert(map_structure_zip(add, [[1, 1], [1, 1]]) == [2, 2])
    assert(map_structure_zip(sub, [[0, 0], [1, 1]]) == [-1, -1])
    assert(map_structure_zip(sub, [[1, 1], [1, 1]]) == [0, 0])
    assert(map_structure_zip(sub, [[2, 2], [1, 1]]) == [1, 1])
    assert(map_structure_zip(sub, [[0, 0], [0, 0]]) == [0, 0])

# Generated at 2022-06-25 16:45:41.924370
# Unit test for function map_structure
def test_map_structure():

    class Element:
        def __init__(self, name, children, attr):
            self.name = name
            self.children = children
            self.attr = attr

        def __repr__(self):
            return "Element({0.name!r}, {0.children!r}, {0.attr!r})".format(self)

        def __eq__(self, other):
            return self.name == other.name and self.children == other.children and self.attr == other.attr

    @no_type_check
    def fn1(element: Element) -> str:
        element = copy.copy(element)
        element.name = 'x'
        return element

    @no_type_check
    def fn2(element: Element) -> str:
        element = copy.copy(element)

# Generated at 2022-06-25 16:45:52.306335
# Unit test for function map_structure_zip
def test_map_structure_zip():
    str_0 = "This is a test of function map_structure_zip."
    str_1 = "This is a test of function map_structure_zip."
    str_2 = ""
    str_3 = "This is a test of function map_structure_zip."
    str_4 = "This is a test of function map_structure_zip."
    str_5 = "This is a test of function map_structure_zip."
    str_6 = "This is a test of function map_structure_zip."
    str_7 = "This is a test of function map_structure_zip."
    str_8 = ""
    str_9 = "This is a test of function map_structure_zip."
    str_10 = ""

# Generated at 2022-06-25 16:46:00.251018
# Unit test for function map_structure_zip

# Generated at 2022-06-25 16:46:07.979403
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # Case 0
    list_0 = [1, 2, 3]
    list_1 = [4, 5, 6]
    list_2 = [7, 8, 9]
    list_3 = map_structure_zip(lambda x, y, z: x + y + z, [list_0, list_1, list_2])
    assert list_3 == [12, 15, 18]



# Generated at 2022-06-25 16:46:22.231342
# Unit test for function map_structure_zip
def test_map_structure_zip():

    # The function returns a list of the intermediate results at each step.
    def f(x, y, z, w):
        return x + y + z + w

    # The structure is a list of (nested) lists. 
    nested_lists = [
        [1, 2, 3, 4],
        [2, 3, 4, 5],
        [3, 4, 5, 6],
    ]

    # The function should be called on the elements in each list.
    # [[10, 9, 7, 4]]
    result = map_structure_zip(f, nested_lists)
    assert result == [[10, 9, 7, 4]]

    # The structure is a tuple of lists and tuples.

# Generated at 2022-06-25 16:46:32.583856
# Unit test for function map_structure
def test_map_structure():
    x = {
        "a": {
            "b": 1,
            "c": 2,
        },
        "b": 2,
    }
    def to_double(obj):
        try:
            return obj * 2
        except:
            return obj
    y = map_structure(to_double, x)
    assert y == {
        "a": {
            "b": 2,
            "c": 4,
        },
        "b": 4,
    }


# Generated at 2022-06-25 16:46:44.695489
# Unit test for function no_map_instance
def test_no_map_instance():
    @no_type_check
    def check_no_map_instance():
        class C:
            def __init__(self, x):
                self.x = x
            def __repr__(self):
                return "C(%s)" % self.x
        class D(C):
            pass
        class E(C):
            pass
        l = [C(0), C(1)]
        l2 = map_structure(no_map_instance, l)
        assert l is not l2
        assert all(x is y for x, y in zip(l, l2))
        assert isinstance(l2[1], D) and isinstance(l2[0], E)
        for x in l:
            assert hasattr(x, _NO_MAP_INSTANCE_ATTR)

# Generated at 2022-06-25 16:46:58.253417
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [{"a": "b", "c": {"d": "e"}}, {"a": "b", "c": {"d": "e"}}]
    b = [{"a": "b", "c": {"d": "e"}}, {"a": "b", "c": {"d": "e"}}]
    c = [{"a": "b", "c": {"d": "e"}}, {"a": "b", "c": {"d": "e"}}]
    new_a = map_structure_zip(lambda a, b, c: a, a, b, c)
    print(new_a)

# Generated at 2022-06-25 16:47:08.567029
# Unit test for function map_structure

# Generated at 2022-06-25 16:47:20.553747
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    def add_3(a, b, c):
        return a + b + c
    d = map_structure_zip(add_3, [a, b, c])
    assert d[0] == 1 + 4 + 7
    assert d[1] == 2 + 5 + 8
    assert d[2] == 3 + 6 + 9
    assert len(d) == 3
    e = (1, 2, 3)
    f = (4, 5, 6)
    g = (7, 8, 9)
    def add_3(a, b, c):
        return a + b + c
    h = map_structure_zip(add_3, [e, f, g])

# Generated at 2022-06-25 16:47:23.607170
# Unit test for function no_map_instance
def test_no_map_instance():
    test_string = "test_string"
    test_string = no_map_instance(test_string)
    assert(test_string == "test_string")



# Generated at 2022-06-25 16:47:34.276645
# Unit test for function map_structure
def test_map_structure():
    input_0 = {'a': 1, 'b': [2,3], 'c': ('x', ('y', [4]))}
    input_0_0 = {'a': 1, 'b': [2,3], 'c': ('x', ('y', [4]))}
    input_1 = {'a': 1, 'b': [2,3], 'c': ('x', ('y', [4]))}
    output = {'a': 1, 'b': [2,3], 'c': ('x', ('y', [4]))}
    output_0 = {'a': 1, 'b': [2,3], 'c': ('x', ('y', [4]))}
    assert map_structure(input_0, input_0_0) == output

# Generated at 2022-06-25 16:47:42.219765
# Unit test for function map_structure_zip
def test_map_structure_zip():
    fn = lambda a, b, c: a + b + c
    a = [[1, 1], [2, 2]]
    b = [[3, 3], [4, 4]]
    c = [[5, 5], [6, 6]]
    results = map_structure_zip(fn, [a, b, c])
    assert results == [[9, 9], [12, 12]]

# Generated at 2022-06-25 16:47:50.760464
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # test case 0
    t0_a = {"_abc": [[["abc"], ["bcd"]], [["def"], ["ghi"]]]}
    t0_b = {"_abc": [[["jkl"], ["mno"]], [["pqr"], ["stu"]]]}
    t0_c = {"_abc": [{"x": "abc"}, {"x": "bcd"}, {"x": "def"}, {"x": "ghi"}]}
    t0_d = {"_abc": [{"x": "jkl"}, {"x": "mno"}, {"x": "pqr"}, {"x": "stu"}]}
    t0_fn = lambda: None
    t0_fn._fields = ()

    # test case 1
    t1_x = {"_abc": {"x": "abc"}}
    t1_y

# Generated at 2022-06-25 16:48:02.189941
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [
        {'x': [
            [1, 2, 3],
            [4, 5, 6],
            {'y': [7, 8, 9]}
        ], 'z': 10}
    ]

    b = [
        {'x': [
            [4, 5, 6],
            [7, 8, 9],
            {'y': [10, 11, 12]}
        ], 'z': 13}
    ]

    c = [
        [1, 2, 3, 4],
        {'x': [5, 6, 7], 'y': ['a', 'b', 'c']},
        [8, 9]
    ]

    d = map_structure_zip(lambda *args: list(args), a, b, c)

# Generated at 2022-06-25 16:48:03.288033
# Unit test for function map_structure_zip
def test_map_structure_zip():
    test_case_0()


# Generated at 2022-06-25 16:48:15.668273
# Unit test for function no_map_instance

# Generated at 2022-06-25 16:48:19.356481
# Unit test for function no_map_instance
def test_no_map_instance():
    map_structure(lambda x: x, no_map_instance(str))


if __name__ == '__main__':
    test_no_map_instance()

# Generated at 2022-06-25 16:48:25.414148
# Unit test for function map_structure
def test_map_structure():
    fn = lambda x: x
    c = {'a': 1, 'b': ['1', '2']}
    c = map_structure(fn, c)
    assert c == {'a': 1, 'b': ['1', '2']}
    c = no_map_instance(c)
    assert c == {'a': 1, 'b': ['1', '2']}
    d = {'a': 1, 'b': {'b1': 1, 'b2': 2}}
    d = map_structure(fn, d)
    assert d == {'a': 1, 'b': {'b1': 1, 'b2': 2}}
    d = no_map_instance(d)
    assert d == {'a': 1, 'b': {'b1': 1, 'b2': 2}}

# Generated at 2022-06-25 16:48:29.959290
# Unit test for function map_structure_zip
def test_map_structure_zip():
    list_0 = [1,2,3]
    list_1 = [3,2,1]
    def custom_fn(list_0,list_1):
        return list_0[0]+list_1[1]
    list_2 = map_structure_zip(custom_fn,[list_0,list_1])
    assert(list_2==[5,5,5])
    
    

# Generated at 2022-06-25 16:48:32.767891
# Unit test for function no_map_instance
def test_no_map_instance():
    register_no_map_class(list)
    assert no_map_instance([0, 1]) == [0, 1]


# Generated at 2022-06-25 16:48:44.125791
# Unit test for function map_structure
def test_map_structure():
    print('Testing map_structure...')
    T = TypeVar('T')
    R = TypeVar('R')

    def identity(obj: T) -> T:
        return obj

    assert map_structure(identity, no_map_instance(1)) == 1
    assert map_structure(identity, [1, 2, 3]) == [1, 2, 3]
    assert map_structure(identity, [1, [2, 3], (4, 5)]) == [1, [2, 3], (4, 5)]
    assert map_structure(identity, [[1, 2], [3, 4]]) == [[1, 2], [3, 4]]
    assert map_structure(identity, [[1, 2], (3, 4)]) == [[1, 2], (3, 4)]

# Generated at 2022-06-25 16:48:51.774631
# Unit test for function map_structure
def test_map_structure():
    import torch
    import numpy as np

# Generated at 2022-06-25 16:49:02.114501
# Unit test for function map_structure

# Generated at 2022-06-25 16:49:15.596755
# Unit test for function no_map_instance
def test_no_map_instance():
    # Fake does not contain _NO_MAP_INSTANCE_ATTR
    # so it will be trapped and returned with this attribute
    Fake = type('Fake', (), {})
    real_instance = Fake()
    assert not hasattr(real_instance, _NO_MAP_INSTANCE_ATTR)
    # This function should return a new instance
    # with attribute _NO_MAP_INSTANCE_ATTR
    assert no_map_instance(real_instance) is not real_instance
    assert hasattr(no_map_instance(real_instance), _NO_MAP_INSTANCE_ATTR)
    assert no_map_instance(real_instance) == real_instance
    # If attribute _NO_MAP_INSTANCE_ATTR is already present
    # it should return the instance
    fake_instance = no_map_instance(real_instance)

# Generated at 2022-06-25 16:49:27.401855
# Unit test for function map_structure_zip
def test_map_structure_zip():
    int_0 = 0
    int_1 = 1

# Generated at 2022-06-25 16:49:33.710832
# Unit test for function no_map_instance
def test_no_map_instance():
    """
    Asserts that ``no_map_instance`` sets the ``_NO_MAP_INSTANCE_ATTR`` attribute on the object.
    """
    d = {'x': 1, 'y': 2}
    assert not hasattr(d, _NO_MAP_INSTANCE_ATTR)
    d = no_map_instance(d)
    assert hasattr(d, _NO_MAP_INSTANCE_ATTR)


# Generated at 2022-06-25 16:49:37.418834
# Unit test for function no_map_instance
def test_no_map_instance():
    import numpy as np
    x = np.random.rand(10, 10)
    assert no_map_instance(x) is x
    assert isinstance(no_map_instance(x), np.ndarray)

# Generated at 2022-06-25 16:49:49.029554
# Unit test for function no_map_instance

# Generated at 2022-06-25 16:49:58.986764
# Unit test for function map_structure_zip
def test_map_structure_zip():
    dict_0 = dict
    register_no_map_class(dict_0)
    int_0 = int
    no_map_instance(int_0)
    test_case_0()
    list_0 = list
    no_map_instance(list_0)
    dict_1 = dict
    map_structure(dict_1, map_structure_zip(int_0, [dict_0]))

# Generated at 2022-06-25 16:50:05.887545
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [[1,2],[2,2],[3,2]]
    b = [[1,2],[2,3],[3,3]]
    c = [[1,2],[2,4],[3,5]]
    assert map_structure_zip(lambda x,y,z: x+y+z, [a,b,c]) == [[3, 6], [6, 9], [9, 12]]
    assert list(map_structure_zip(lambda x,y,z: x+y+z, [a,b,c])) == [[3, 6], [6, 9], [9, 12]]


# Generated at 2022-06-25 16:50:07.726493
# Unit test for function no_map_instance
def test_no_map_instance():
    str_0 = "abc"
    no_map_instance(str_0)



# Generated at 2022-06-25 16:50:18.784494
# Unit test for function map_structure_zip
def test_map_structure_zip():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    # Test each function with a different state machine.
    def test_func_0(state, input_):
        if state == 0:
            if input_ == "a":
                state = 1
                return state, None
            elif input_ == "b":
                state = 4
                return state, None
            else:
                state = 0
                return state, None
        elif state == 1:
            if input_ == "a":
                state = 2
                return state, None
            elif input_ == "c":
                state = 3
                return state, None
            else:
                state = 0
                return state, None

# Generated at 2022-06-25 16:50:24.170636
# Unit test for function no_map_instance
def test_no_map_instance():
    assert no_map_instance("foo") == "foo"
    assert no_map_instance("foo") is not "foo"
    assert hasattr(no_map_instance("foo"), _NO_MAP_INSTANCE_ATTR)



# Generated at 2022-06-25 16:50:32.412424
# Unit test for function map_structure
def test_map_structure():
    x = dict(foo=3, bar=(1, 2, 3))
    y = map_structure(lambda x: x + 1, x)
    print(y)
    # y == {'foo': 4, 'bar': (2, 3, 4)}
    assert y['foo'] == 4
    assert y['bar'] == (2, 3, 4)


# Generated at 2022-06-25 16:50:41.919322
# Unit test for function map_structure_zip
def test_map_structure_zip():
    str_0 = "a"
    str_1 = "b"
    str_2 = "c"
    int_0 = 1
    int_1 = 2
    int_2 = 3
    lst_0 = [str_0, str_1]
    lst_1 = [str_2]
    lst_2 = [int_0, int_1]
    lst_3 = [int_2]
    tup_0 = tuple(lst_0)
    tup_1 = tuple(lst_1)
    tup_2 = tuple(lst_2)
    tup_3 = tuple(lst_3)
    dct_0 = {str_0: int_0, str_1: int_1}
    dct_1 = {str_2: int_2}

# Generated at 2022-06-25 16:50:48.949265
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def f(a, b, c):
        return (a, b, c)

    nested_1 = [[1, 2], 3]
    nested_2 = [[4, 5], 6]
    map_structure_zip(f, [nested_1, nested_2])

    def f(a, b, *c):
        return (a, b, c)

    map_structure_zip(f, [nested_1, nested_2])

    def f(a, b, **c):
        return (a, b, c)

    map_structure_zip(f, [nested_1, nested_2])

    def f(a, b, c=1):
        return (a, b, c)

    map_structure_zip(f, [nested_1, nested_2])

   

# Generated at 2022-06-25 16:50:53.393910
# Unit test for function no_map_instance
def test_no_map_instance():
    num = 1
    no_map_instance(num)
    assert hasattr(num, _NO_MAP_INSTANCE_ATTR)
    assert not hasattr(1, _NO_MAP_INSTANCE_ATTR)  # original class did not change


# Generated at 2022-06-25 16:51:04.999777
# Unit test for function map_structure_zip
def test_map_structure_zip():
    assert map_structure_zip(lambda x, y: x + y, [1, 2, 3], [4.2, 5.3, 6.4]) == [5.2, 7.3, 9.4]
    assert map_structure_zip(lambda x, y: x + y, [[1, 2], [3, 4]], [[5.2, 6.3], [7.4, 8.5]]) == [[6.2, 8.3], [10.4, 12.5]]
    assert map_structure_zip(lambda x, y: x + y, [(1, 2), (3, 4)], [(5.2, 6.3), (7.4, 8.5)]) == [(6.2, 8.3), (10.4, 12.5)]

# Generated at 2022-06-25 16:51:07.115247
# Unit test for function no_map_instance
def test_no_map_instance():
    test_case_0()
    obj = str_0
    no_map_instance(obj)


# Generated at 2022-06-25 16:51:12.455300
# Unit test for function map_structure_zip
def test_map_structure_zip():
    assert map_structure_zip(sum, [[1, 2, 3], [4, 5, 6]]) == [5, 7, 9]
    assert map_structure_zip(sum, [[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == [12, 15, 18]



# Generated at 2022-06-25 16:51:15.421590
# Unit test for function no_map_instance
def test_no_map_instance():
    target = "test"
    a = no_map_instance(target)
    assert a._no_map_str == True
    assert a == target



# Generated at 2022-06-25 16:51:25.500996
# Unit test for function map_structure
def test_map_structure():
    l = [1, 2, 3, 4, 5]
    l1 = map_structure(operator.add, l, [2, 3, 4, 5, 6])
    assert l1 == [3, 5, 7, 9, 11]
    l1 = map_structure(operator.add, l, [2, 3, 4, 5])
    assert l1 == [3, 5, 7, 9, 5]
    l1 = map_structure(operator.add, l, [2, 3, 4, 5, 6, 7])
    assert l1 == [3, 5, 7, 9, 11, 5]

    t = (10, 11, 12, 13)
    t1 = map_structure(operator.add, t, [2, 3, 4, 5])

# Generated at 2022-06-25 16:51:32.956034
# Unit test for function map_structure_zip
def test_map_structure_zip():
    assert map_structure_zip(lambda x, y: x+y, ["a", "b"]) == "ab"
    assert map_structure_zip(lambda x, y: x+y, ["a", "b"], ["A", "B"]) == "aAbB"
    assert map_structure_zip(lambda x, y: x+y, ["a"], ["A", "B"]) == "aB"
    assert map_structure_zip(lambda x, y: x+y, ["a", "b"], ["A"]) == "aA"

    assert map_structure_zip(lambda x, y: x+y, [(1, 2)]) == (1, 2)

# Generated at 2022-06-25 16:51:46.817923
# Unit test for function map_structure_zip

# Generated at 2022-06-25 16:51:59.299525
# Unit test for function map_structure
def test_map_structure():
    from six import StringIO
    import sys
    import unittest

    class TestMapStructure(unittest.TestCase):
        def test_map_structure(self):
            tpl_0 = no_map_instance((2, 3))
            self.assertTrue(map_structure(operator.add, tpl_0) == 5)
            tpl_1 = (1, 2)
            tpl_2 = (3, 4)
            self.assertTrue(map_structure(operator.add, (tpl_1, tpl_2)) == (4, 6))
            lst_0 = [1, 2, 3, 4]
            lst_1 = [5, 6, 7, 8]

# Generated at 2022-06-25 16:52:07.096677
# Unit test for function map_structure
def test_map_structure():
    test1 = reverse_map({'a': 1, 'b': 3, 'c': 2})
    assert test1 == ['a', 'c', 'b']

    test2 = reverse_map({'a': 3, 'b': 2, 'c': 1})
    assert test2 == ['c', 'b', 'a']

    test3 = reverse_map({'a': 1})
    assert test3 == ['a']

    with pytest.raises(KeyError):
        reverse_map({'a': 3, 'b': 2, 'c': 2})


# Generated at 2022-06-25 16:52:07.867992
# Unit test for function map_structure_zip
def test_map_structure_zip():
    test_case_0()

# Generated at 2022-06-25 16:52:11.079218
# Unit test for function no_map_instance
def test_no_map_instance():
    list_of_str = ['a', 'b']
    list_of_str = no_map_instance(list_of_str)
    assert list_of_str == ['a', 'b']
    assert list_of_str.__class__ in _NO_MAP_TYPES
    assert hasattr(list_of_str, _NO_MAP_INSTANCE_ATTR)



# Generated at 2022-06-25 16:52:23.072703
# Unit test for function map_structure
def test_map_structure():
    def f(x: int) -> int:
        return x**2

    test_0 = [{'k': [1, 2, 3], 'k2': {'x': 12, 'y': 34}}, {'k': [4, 5]}]
    register_no_map_class(dict)
    expected_0 = [{'k': [1, 4, 9], 'k2': {'x': 144, 'y': 1156}}, {'k': [16, 25]}]
    ans_0 = map_structure(f, test_0)
    assert ans_0 == expected_0

    test_1 = {'x': {'y': {'z': [1, 2, 3]}}}
    expected_1 = {'x': {'y': {'z': [1, 4, 9]}}}
   

# Generated at 2022-06-25 16:52:26.091680
# Unit test for function map_structure_zip
def test_map_structure_zip():
    test_case_0()
    test_case_0()
    test_case_0()

    def func(arg1, arg2, arg3):
        return arg1 + arg2 + arg3

    # Test case
    assert map_structure_zip(func, [1, 2, 3]) == 6


# Generated at 2022-06-25 16:52:33.723408
# Unit test for function no_map_instance
def test_no_map_instance():
    assert no_map_instance('a') == 'a'
    assert no_map_instance([1, 2]) == [1, 2]
    assert no_map_instance((1, 2)) == (1, 2)
    assert no_map_instance({1, 2}) == {1, 2}
    assert no_map_instance({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}


test_case_0()


# Generated at 2022-06-25 16:52:44.634116
# Unit test for function map_structure
def test_map_structure():
    from operator import mul
    import torch

    # string -> tensor
    s = torch.tensor([3.4])
    assert (map_structure(str, s) == [str(3.4)])

    # int -> float
    i = torch.tensor([3])
    assert (map_structure(float, i) == [3.0])

    # float -> int
    f = torch.tensor([3.0])
    assert (map_structure(int, f) == [3])

    # float -> float
    assert (map_structure(lambda x: x + 1.0, f) == [4.0])

    # float list -> tensor
    a = [3.4, 4.3]

# Generated at 2022-06-25 16:52:54.741018
# Unit test for function map_structure_zip
def test_map_structure_zip():
    assert map_structure_zip(operator.add, ([1, 2], [3, 4])) == [4, 6]
    assert map_structure_zip(operator.add, ([1.1, 2.1], [3.1, 4.9])) == [4.2, 7.0]
    assert map_structure_zip(operator.add, (('a', 'b'), ('c', 'd'))) == ['ac', 'bd']
    assert map_structure_zip(operator.add, ([1, 2], [3], [4, 5])) == [8, 7]
    assert map_structure_zip(operator.add, ([1, 2], [3], [4], [5, 6])) == [9, 8]

# Generated at 2022-06-25 16:53:06.762831
# Unit test for function no_map_instance
def test_no_map_instance():
    assert no_map_instance(str(1)) == str(1)
    assert str(no_map_instance(str(1)).__class__) == "<class '__main__._no_mapstr'>"
    assert no_map_instance([1, 2, 3]) == [1, 2, 3]
    assert no_map_instance([1, 2, 3]).__class__ == _no_map_type(list)
    assert no_map_instance([1, 2, 3]) == _no_map_type(list)([1, 2, 3])
    assert str(_no_map_type(list)([1, 2, 3]).__class__) == "<class '__main__._no_maplist'>"


# Generated at 2022-06-25 16:53:10.986059
# Unit test for function map_structure_zip
def test_map_structure_zip():
    d1 = {"a" : 1}
    d2 = list(range(10))
    try:
        map_structure_zip(d1, d2)
        assert False
    except:
        assert True

if __name__ == '__main__':
    test_map_structure_zip()

# Generated at 2022-06-25 16:53:19.325643
# Unit test for function map_structure
def test_map_structure():
    test_list = [[0, 0], [1, 1], [2, 2]]
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_str = "abc"

    exe_list = map_structure(lambda x: x + 1, test_list)
    assert exe_list == [[1, 1], [2, 2], [3, 3]]

    exe_dict = map_structure(lambda x: x * 2, test_dict)
    assert exe_dict == {'a': 2, 'b': 4, 'c': 6}
    exe_str = map_structure(lambda x: x + 'd', test_str)
    assert exe_str == "abcd"



# Generated at 2022-06-25 16:53:31.159236
# Unit test for function map_structure_zip
def test_map_structure_zip():
    assert map_structure_zip(lambda x, y: x + y, [0, 1, 2], [3, 4, 5]) == [3, 5, 7]
    assert map_structure_zip(lambda x, y: x + y, [(1, 2), (3, 4)], [(5, 6), (7, 8)]) == [(6, 8), (10, 12)]
    assert map_structure_zip(lambda x, y: x + y,
                             [(1, 2), {'a': 3}],
                             [(3, 4), {'b': 5}]) == [(4, 6), {'a': 3, 'b': 5}]

# Generated at 2022-06-25 16:53:42.119382
# Unit test for function map_structure_zip

# Generated at 2022-06-25 16:53:43.960399
# Unit test for function no_map_instance
def test_no_map_instance():
    assert no_map_instance(str) == str


# Generated at 2022-06-25 16:53:56.395666
# Unit test for function map_structure_zip
def test_map_structure_zip():
    map_structure_zip(lambda xs: [x * x for x in xs], [[1, 2], [3, 4]])
    map_structure_zip(lambda xs: [x * x for x in xs], [[1, 2], [3, 4]])
    map_structure_zip(lambda xs: [x * x for x in xs], [[1, 2], [3, 4]])
    map_structure_zip(lambda xs: [x * x for x in xs], [[1, 2], [3, 4]])
    map_structure_zip(lambda xs: [x * x for x in xs], [[1, 2], [3, 4]])

# Generated at 2022-06-25 16:54:06.649893
# Unit test for function no_map_instance

# Generated at 2022-06-25 16:54:17.211353
# Unit test for function no_map_instance
def test_no_map_instance():
    # tuples
    assert no_map_instance((1, 2, 3)) == (1, 2, 3)
    assert no_map_instance((1, )) == (1, )
    assert no_map_instance(('a', 'b', 'c')) == ('a', 'b', 'c')

    # lists
    assert no_map_instance([1, 2, 3]) == [1, 2, 3]
    assert no_map_instance([1]) == [1]

    # dictionaries
    assert no_map_instance({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
    assert no_map_instance({'a': 1}) == {'a': 1}

    # strings

# Generated at 2022-06-25 16:54:27.234181
# Unit test for function map_structure_zip

# Generated at 2022-06-25 16:54:47.375947
# Unit test for function map_structure
def test_map_structure():
    def test_case_0():
        test_obj_0 = {'a': {'a': 'a', 'b': 'b'}, 'b': 'b'}
        test_obj_1 = no_map_instance(test_obj_0)
        test_fn_0 = lambda x: x.upper()
        test_fn_1 = lambda xs: map_structure(test_fn_0, xs)
        test_result_0 = test_fn_1(test_obj_0)
        test_result_1 = test_fn_1(test_obj_1)
        assert (test_result_0 == test_result_1)
        assert (test_result_0 == {'A': {'A': 'A', 'B': 'B'}, 'B': 'B'})