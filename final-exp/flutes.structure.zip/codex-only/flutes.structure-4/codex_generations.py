

# Generated at 2022-06-23 17:27:24.093472
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import torch
    from torch.nn.utils.rnn import pack_sequence
    d = {'the': 4, 'cat': 1}
    d2 = {'the': 5, 'cat': 2}
    d3 = {'the': 6, 'cat': 3}
    e = {'the': 7, 'cat': 4, 'dog': 5}
    e2 = {'the': 8, 'cat': 5, 'dog': 6}
    e3 = {'the': 9, 'cat': 6, 'dog': 7}
    f = {'the': 10, 'cat': 7, 'dog': 8, 'sat': 9}
    f2 = {'the': 11, 'cat': 8, 'dog': 9, 'sat': 10}

# Generated at 2022-06-23 17:27:34.008928
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(x,y):
        return x+y

    def fn3(x,y,z):
        return x+y+z

    # one empty
    a = map_structure_zip(fn,[[],[1,2],[2,4]])
    assert a == []

    # two empty
    b = map_structure_zip(lambda a,b: [a,b],[[],[],[]])
    assert b == []

    # three empty
    c = map_structure_zip(lambda a,b,c: [a,b,c],[[],[],[]])
    assert c == []

    # one number
    a = map_structure_zip(fn,[[1],[],[]])
    assert a == 1

    # two number

# Generated at 2022-06-23 17:27:42.260209
# Unit test for function map_structure_zip
def test_map_structure_zip():
    first_name = map_structure_zip(lambda x: x + "lei", [{"first_name" : 'xiao'}] * 6)
    print(first_name)

if __name__ == "__main__":
    print("123123")
    print("123123")
    print("123123")
    print("123123")
    print("123123")
    test_map_structure_zip()

# Generated at 2022-06-23 17:27:47.415105
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class TestClass():
        pass
    register_no_map_class(TestClass)
    assert TestClass in _NO_MAP_TYPES
    # Try to register a class which is already registered
    register_no_map_class(TestClass)
    assert TestClass in _NO_MAP_TYPES

# Generated at 2022-06-23 17:27:55.969614
# Unit test for function map_structure
def test_map_structure():
    from collections import OrderedDict
    from operator import add, div, mul
    from itertools import chain


# Generated at 2022-06-23 17:28:03.627601
# Unit test for function reverse_map
def test_reverse_map():
    random.seed(1)
    d = {
      "wo": 0,
      "ha": 1,
      "me": 2,
      "ia": 3,
      "we": 4,
      "is": 5,
      "ok": 6
    }
    assert reverse_map(d) == ['wo', 'ha', 'me', 'ia', 'we', 'is', 'ok']

# Generated at 2022-06-23 17:28:10.079156
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def f(x: int, y: int) -> int: 
        return x+y

    a = [1,2,3]
    b = [4,5,6]

    print(map_structure_zip(f, [a,b]))

if __name__ == "__main__":
    # Unit test for function map_structure_zip
    test_map_structure_zip()

# Generated at 2022-06-23 17:28:19.148620
# Unit test for function no_map_instance
def test_no_map_instance():
    list_example = [[1, 2, 3], 'abc']
    list_example_no_map = no_map_instance(list_example)
    list_example_no_map_again = no_map_instance(list_example)
    assert list_example_no_map == list_example_no_map_again
    # Test the attribute
    assert hasattr(list_example_no_map, _NO_MAP_INSTANCE_ATTR)
    assert hasattr(list_example_no_map, _NO_MAP_INSTANCE_ATTR)
    # Test the example
    assert map_structure(lambda x: x + 1, list_example) == [[2, 3, 4], 'abc1']
    assert map_structure(lambda x: x + 1, list_example_no_map) == list_example
   

# Generated at 2022-06-23 17:28:29.717213
# Unit test for function map_structure_zip
def test_map_structure_zip():
    inputs = [[0, 1, 2], {'a': 'a', 'b': 'b'}, [3, 4], [5, 6], {'c': 'c', 'd': 'd', 'e': 'e'}]
    expected_outputs = [{'a': 0, 'b': 1, 'c': 3, 'd': 4, 'e': 5}, {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd', 'e': 'e'}]
    result = map_structure_zip(lambda x, y: {**x, **y}, inputs)
    assert result == expected_outputs, (result, expected_outputs)

    inputs = [[0, 1, 2], [3, 4], [5, 6]]

# Generated at 2022-06-23 17:28:38.691891
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class FakeTuple(object):
        def __init__(self, *args):
            pass
    FakeTupleSize = type("FakeTupleSize", (FakeTuple,), {"__add__": lambda *args: None})
    FakeTupleSizeBig = type("FakeTupleSizeBig", (FakeTupleSize,), {"__add__": lambda *args: None})
    register_no_map_class(FakeTupleSize)
    register_no_map_class(FakeTupleSizeBig)
    assert FakeTupleSize._no_map_class
    assert FakeTupleSizeBig._no_map_class


if __name__ == "__main__":
    test_register_no_map_class()

# Generated at 2022-06-23 17:28:49.479668
# Unit test for function no_map_instance
def test_no_map_instance():
    import torch
    obj = [torch.randn(2,2,2), {'a': torch.randn(2,2,2), 'b': torch.randn(2,2,2)},
           {torch.randn(2, 2, 2): 2, torch.randn(2, 2, 2): 3}, [torch.randn(2, 2, 2)]]
    obj_no_map = no_map_instance(obj)
    obj_no_map_no_map = no_map_instance(obj_no_map)

    assert(obj_no_map == obj_no_map_no_map)
    assert(not(obj == obj_no_map))


# Generated at 2022-06-23 17:28:57.577486
# Unit test for function map_structure
def test_map_structure():
    list_tuple_dict = \
        [('a', [1, 2, 3]),
         (('b', 2), {'c': 3, 'd': 4})]
    updated_list_tuple_dict = \
        [('aa', [1, 2, 3]),
         (('bb', 2), {'cc': 3, 'dd': 4})]
    actual = map_structure(lambda x: x + x if isinstance(x, str) else x, list_tuple_dict)
    assert actual == updated_list_tuple_dict



# Generated at 2022-06-23 17:29:09.151062
# Unit test for function register_no_map_class
def test_register_no_map_class():
    tup1 = (1, 2, 3)
    tup2 = (2, 3, 4)
    tup3 = tuple([1, 2, 3])  # enable type hint
    # tup3.append(4) # it is not possible to add elements to tuple
    register_no_map_class(tuple)
    print(map_structure((lambda o: o + 1), tup1))
    print(map_structure_zip((lambda x, y: x + y), [tup1, tup2]))
    print(map_structure_zip((lambda x, y: x + y), [tup1, tup3]))



if __name__ == '__main__':
    test_register_no_map_class()

# Generated at 2022-06-23 17:29:15.086480
# Unit test for function reverse_map
def test_reverse_map():
    word_to_id = {"a": 0, "b": 1, "c": 2}
    id_to_word = reverse_map(word_to_id)
    assert id_to_word == ['a', 'b', 'c']

# Generated at 2022-06-23 17:29:19.552184
# Unit test for function reverse_map
def test_reverse_map():
    words = ['a', 'aardvark', 'abandon', 'abandoned', 'ability']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    assert words == id_to_word

# Generated at 2022-06-23 17:29:22.188852
# Unit test for function reverse_map
def test_reverse_map():
    d = {'a': 0, 'b': 2, 'c': 1}
    r = ['a', 'c', 'b']
    assert reverse_map(d) == r


# Generated at 2022-06-23 17:29:30.457740
# Unit test for function no_map_instance
def test_no_map_instance():
    class MyList(list):
        def __init__(self, *args):
            super(MyList, self).__init__(*args)
            register_no_map_class(MyList)
    my_list = MyList([1, 2, 3])
    my_list_2 = no_map_instance(my_list)
    assert(type(my_list) == type(my_list_2))

# Generated at 2022-06-23 17:29:41.154390
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import torch

    class MySize(torch.Size):
        def __init__(self, *args, **kwargs):
            register_no_map_class(MySize)
            super().__init__(*args, **kwargs)

    class MyTuple(tuple):
        def __init__(self, *args, **kwargs):
            register_no_map_class(MyTuple)
            super().__init__(*args, **kwargs)

    def test_f(k):
        return k+1

    def test_g(k, v):
        return k+v

    test_obj_1 = MySize(1, 2, 3)
    test_obj_2 = [[MySize(1,2,3), MySize(4,5)], [MySize(6,7)]]
    test_

# Generated at 2022-06-23 17:29:48.126493
# Unit test for function map_structure
def test_map_structure():
    def _test(fn, obj_in, obj_out):
        obj_out_ = map_structure(fn, obj_in)
        assert obj_out == obj_out_

    # Single object
    _test(lambda x: 1, [], [1])

    # Simple list
    _test(lambda x: x + 1, [1], [2])

    # Simple list of lists
    _test(lambda x: x + 1, [[0, 1], [1, 2]], [[1, 2], [2, 3]])

    # List of dicts
    _test(lambda x: x + 1, [{"a": 1, "b": 2}, {"a": 2, "b": 3}],
          [{"a": 2, "b": 3}, {"a": 3, "b": 4}])

    # List of tu

# Generated at 2022-06-23 17:29:57.847004
# Unit test for function map_structure
def test_map_structure():
    dict_ = {'str': 'str', 'int': 1, 'float': 1.0, 'list': [1, 2, 3], 'tuple': (1, 2, 3), 'dict': {'int2': 3, 'str2': 'str2'}}
    tuple_ = (1, 'str', 1.0)
    list_ = [1, 'str', 1.0]
    set_ = {1, 'str', 1.0}
    # noinspection PyTypeChecker

# Generated at 2022-06-23 17:30:03.098706
# Unit test for function reverse_map
def test_reverse_map():
    d = {'a': 0, 'b': 1, 'c': 2}
    assert reverse_map(d) == ['a', 'b', 'c']
    d = {'b': 1, 'a': 0, 'c': 2}
    assert reverse_map(d) == ['a', 'b', 'c']

# Generated at 2022-06-23 17:30:09.072370
# Unit test for function map_structure
def test_map_structure():
    from torch.autograd import Variable
    def test_pass(x):
        return x

    def test_add(x, y):
        return x + y

    def test_add_var(x, y):
        return Variable(x.data + y)

    def test_add_var_lazy(x, y):
        return Variable(x.data + y.data, requires_grad=x.requires_grad or y.requires_grad)

    def test_add_dict(x, y):
        return {**x, **y}

    def test_add_list(x, y):
        return [x[0] + y[0], x[1]]

    def test_add_tuple(x, y):
        return (x[0] + y[0], *x[1:])


# Generated at 2022-06-23 17:30:12.069748
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from torch.Size import __name__ as size
    from torch.Size import __class__ as tclass

    register_no_map_class(tclass)
    assert tclass in _NO_MAP_TYPES
    assert isinstance(_no_map_type(tclass), tclass)

# Generated at 2022-06-23 17:30:19.642927
# Unit test for function no_map_instance
def test_no_map_instance():
    list_ = no_map_instance([1, 2, 3])
    assert hasattr(list_, _NO_MAP_INSTANCE_ATTR)
    assert isinstance(list_, list)

    tuple_ = no_map_instance((1, 2, 3))
    assert hasattr(tuple_, _NO_MAP_INSTANCE_ATTR)
    assert isinstance(tuple_, tuple)

    dict_ = no_map_instance({'a': 1, 'b': 2})
    assert hasattr(dict_, _NO_MAP_INSTANCE_ATTR)
    assert isinstance(dict_, dict)


# Generated at 2022-06-23 17:30:28.873103
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = {'dict1': [1, 2, 3],
         'dict2': [4, 5, 6],
         'dict3': [7, 8, 9]}

    b = {'dict1': [1, 2, 3],
         'dict2': [4, 5, 6],
         'dict3': [7, 8, 9]}

    c = {'dict1': [1, 2, 3],
         'dict2': [4, 5, 6],
         'dict3': [7, 8, 9]}

    def fn(a, b, c):
        return a + b + c


# Generated at 2022-06-23 17:30:35.346351
# Unit test for function reverse_map

# Generated at 2022-06-23 17:30:47.032302
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(l, d, t):
        return list(l), dict(d), type(t)
    nested_list = [[1, 2, 3], [4, 5, 6]]
    nested_dict = {'key1': {'k1': 1, 'k2': 2}, 'key2': {'k1': 1, 'k2': 2}}
    nested_tuple = (1, {'k1': 1, 'k2': 2}, [{'k1': 1, 'k2': 2}])
    objs = [nested_list, nested_dict, nested_tuple]
    result = map_structure_zip(fn, objs)
    assert [[1, 2, 3], [4, 5, 6]] == result[0]

# Generated at 2022-06-23 17:30:53.168127
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class Foo(list):
        pass
    register_no_map_class(Foo)
    assert Foo in _NO_MAP_TYPES

    class Bar(dict):
        pass
    register_no_map_class(Bar)
    assert Bar in _NO_MAP_TYPES


# Generated at 2022-06-23 17:31:02.523109
# Unit test for function register_no_map_class
def test_register_no_map_class():

    class foo:
        pass

    class bar:
        pass

    # Register two classes
    register_no_map_class(foo)
    register_no_map_class(bar)

    # Assert that we can access the set which contains these two classes
    assert foo in _NO_MAP_TYPES
    assert bar in _NO_MAP_TYPES

    # Register an existing class again
    register_no_map_class(foo)

    # Assert that nothing has changed
    assert foo in _NO_MAP_TYPES
    assert bar in _NO_MAP_TYPES


# Generated at 2022-06-23 17:31:13.261146
# Unit test for function map_structure
def test_map_structure():
    import numpy
    from collections import namedtuple
    from torch.nn.utils.rnn import PackedSequence
    from torch import tensor
    # Define a test namedtuple and register it to be not mapped.
    TestNamedTuple = namedtuple("TestNamedTuple", "a b")
    register_no_map_class(TestNamedTuple)
    # Define a test class and instance to be not mapped.
    class TestClass:
        pass
    test_instance = TestClass()
    # Define a test function to be mapped.
    def test_fn(x):
        return isinstance(x, list)
    # Define a list of test objects with different structures.

# Generated at 2022-06-23 17:31:21.636226
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [1,2,[[2,3],[3,6]]]
    b = [2,3,[[1,1],[1,1]]]
    c = [3,4,[[3,2],[2,3]]]
    def add(x,y,z):
      return x+y+z
    test = map_structure_zip(add,(a,b,c))
    assert test == [6,9,[[6,6],[6,10]]]

# Generated at 2022-06-23 17:31:29.268876
# Unit test for function no_map_instance
def test_no_map_instance():

    # Test case 1:
    #   Complex structure:
    #       - nest 2 lists with same size 
    #       - nest 2 lists with different size 
    #       - nest 2 `namedtuples` with same size 
    #       - nest 2 `namedtuples` with different size 
    #       - nest 2 `namedtuples` with `namedtuple` and `list`
    # 
    #   Check:
    #       - map_structure_zip can handle complex structures correcly
    a = [0, 1]
    b = [1, 2, 3]
    c = no_map_instance((0, 1))
    d = no_map_instance((1, 2, 3))
    e = no_map_instance((2, 3, 4, 5))

# Generated at 2022-06-23 17:31:40.069684
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = {'a':[1,2,3],'b':{'c':[4,5],'d':[6,7]}}
    b = {'a':[8,9,10],'b':{'c':[11,12],'d':[13,14]}}
    c = {'a':[15,16,17],'b':{'c':[18,19],'d':[20,21]}}
    def add(*args):
        return args[0]['a'][0] + args[1]['a'][0] + args[2]['a'][0]
    assert map_structure_zip(add,[a,b,c]) == 78

# Generated at 2022-06-23 17:31:50.188502
# Unit test for function map_structure
def test_map_structure():
    import numpy as np
    from torch.optim import SGD
    from torch.nn.modules import Linear
    from typing import Dict
    import torch
    a = [1, 2, {"a": 1, "b": 3, "c": {"d": 5}}, [7, 8, 9]]
    result = map_structure(lambda x: x+1, a)
    assert result == [2, 3, {"a": 2, "b": 4, "c": {"d": 6}}, [8, 9, 10]]
    assert map_structure(lambda x: x+1, {}) == {}
    assert map_structure(lambda x: x+1, [[1]*10]*10) == [[2]*10]*10

# Generated at 2022-06-23 17:31:54.823954
# Unit test for function register_no_map_class
def test_register_no_map_class():
    # define a class to inherit from the torch.Size
    class Size(torch.Size):
        def __init__(self, size):
            print("I'm appending the size")
            super().__init__(size)
            self.append(size, size)

    # check if the class is mappable
    to_test = {"size": Size((100,))}
    for value in to_test.values():
        assert isinstance(value, torch.Size)
        assert not hasattr(value, _NO_MAP_INSTANCE_ATTR)

    # register the new class
    register_no_map_class(Size)

    # check if the class is mappable
    to_test = {"size": Size((100,))}

# Generated at 2022-06-23 17:32:02.752943
# Unit test for function map_structure
def test_map_structure():
    l = [[[1]]]
    l_map = [[[2]]]
    l_map_zip = [[[3]], [[4]]]
    assert map_structure(lambda x: x + 1, l) == l_map
    assert map_structure_zip(lambda x, y: x + y, [l, l_map]) == l_map_zip


if __name__ == "__main__":
    test_map_structure()

# Generated at 2022-06-23 17:32:07.194677
# Unit test for function no_map_instance
def test_no_map_instance():
    x = [1, 2, 3]
    x_no_map = no_map_instance(x)

    assert x == x_no_map
    assert not hasattr(x, _NO_MAP_INSTANCE_ATTR)
    assert hasattr(x_no_map, _NO_MAP_INSTANCE_ATTR)

# Generated at 2022-06-23 17:32:16.271770
# Unit test for function reverse_map
def test_reverse_map():
    chars = ['a', 'b', 'c', 'd', 'e', 'f']
    char_to_id = {char: idx for idx, char in enumerate(chars)}
    id_to_char = np.array(chars)
    print(id_to_char)
    print(char_to_id)
    id_to_char_ = reverse_map(char_to_id)
    print(id_to_char_)
    print(chars == id_to_char_)

test_reverse_map()

# Generated at 2022-06-23 17:32:25.166133
# Unit test for function reverse_map
def test_reverse_map():
    # Test with integer id
    d = {'a': 0, 'b': 1, 'c': 2, 'd': 3}
    assert ['a', 'b', 'c', 'd'] == reverse_map(d)

    # Test with non-integer id
    d = {'a': 0., 'b': 1., 'c': 2., 'd': 3.}
    assert ['a', 'b', 'c', 'd'] == reverse_map(d)

    # Test with mixed integer/float id
    d = {'a': 0, 'b': 1., 'c': 2, 'd': 3.}
    assert ['a', 'b', 'c', 'd'] == reverse_map(d)


# Generated at 2022-06-23 17:32:35.660215
# Unit test for function map_structure
def test_map_structure():
    param = [[{'idx': 0, 'padding': 0}, {'idx': 1, 'padding': 0}],
             [{'idx': 2, 'padding': 0}, {'idx': 3, 'padding': 0}]]
    result = [[{'idx': 0, 'padding': 0}, {'idx': 1, 'padding': 0}],
              [{'idx': 2, 'padding': 0}, {'idx': 3, 'padding': 0}]]
    assert map_structure(lambda x: 0, param) == result
    assert map_structure(lambda x: x['idx'], param) == [[0, 1], [2, 3]]



# Generated at 2022-06-23 17:32:45.153798
# Unit test for function reverse_map
def test_reverse_map():
    word_to_id = {'a': 1, 'b': 2, 'c': 4, 'd': 3}
    a = {'a': 1, 'b': 2, 'c': 4, 'd': 3}
    b = {}
    c = {'a': 1}
    assert reverse_map(word_to_id) == ['a', 'b', 'c', 'd']
    assert reverse_map(a) == ['a', 'b', 'c', 'd']
    assert reverse_map(b) == []
    assert reverse_map(c) == ['a']


# Generated at 2022-06-23 17:32:56.683655
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import numpy as np
    # x=[1,2,3,4]
    # xp=[1,2,3,4]
    # y=[5,8]
    # yp=[5,8]
    # z=[2,4]
    # zp=[2,4]
    #
    # print([x,xp,y,yp,z,zp])
    # f = lambda x, xp, y, yp, z, zp: np.array([x,xp,y,yp,z,zp]).transpose()
    # print(map_structure_zip(f,[x,xp,y,yp,z,zp]))
    x = [1, 2, 3, 4]
    x2 = [1, 2, 3, 4]

# Generated at 2022-06-23 17:33:01.269166
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([1,2,3,4,5])
    b = map_structure(lambda x: x+2, a)
    assert b == [1,2,3,4,5]

if __name__ == '__main__':
    test_no_map_instance()

# Generated at 2022-06-23 17:33:09.941207
# Unit test for function map_structure_zip
def test_map_structure_zip():
    shape_a = [None]
    shape_b = [2]
    shape_c = [2, None]
    shapes = [shape_a, shape_b, shape_c]
    def shape_equal(x_shape, y_shape):
        #print("input shape: ", x_shape, " ", y_shape)
        assert len(x_shape) == len(y_shape)
        for i in range(len(x_shape)):
            if x_shape[i] is None:
                x_shape[i] = y_shape[i]
            elif y_shape[i] is None:
                y_shape[i] = x_shape[i]
            assert x_shape[i] == y_shape[i]
        return list(x_shape)

    shape_b = map_structure

# Generated at 2022-06-23 17:33:19.154771
# Unit test for function no_map_instance
def test_no_map_instance():
    list_input = [1, [2, 3, 4], 5, {'a':6}]
    list_output = no_map_instance(list_input)
    assert list_output == list_input
    assert type(list_output) == type(list_input)

    tuple_input = (1, 2, (3, 4), [5, 6])
    tuple_output = no_map_instance(tuple_input)
    assert tuple_output == tuple_input
    assert type(tuple_output) == type(tuple_input)

    dict_input = {'a': 1, 'b': 2}
    dict_output = no_map_instance(dict_input)
    assert dict_output == dict_input
    assert type(dict_output) == type(dict_input)


# Generated at 2022-06-23 17:33:26.689600
# Unit test for function reverse_map
def test_reverse_map():
    words = ['a', 'aardvark', 'abandon', 'ability', 'able', 'abortion', 'about', 'above']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    print(id_to_word)


if __name__ == '__main__':
    test_reverse_map()

# Generated at 2022-06-23 17:33:29.899133
# Unit test for function reverse_map
def test_reverse_map():
    d = dict(zip(['a', 'b', 'c', 'd'], [1, 2, 3, 4]))
    assert reverse_map(d) == ['a', 'b', 'c', 'd']


# Generated at 2022-06-23 17:33:39.991271
# Unit test for function no_map_instance
def test_no_map_instance():
    from allennlp.common.registrable import Registrable
    from allennlp.data import Vocabulary
    a = "A"
    b = Vocabulary()
    c = Registrable()
    d = [a]
    e = [c]

    f = map_structure(no_map_instance, a)
    assert f is a
    g = map_structure(no_map_instance, b)
    assert g is b
    h = map_structure(no_map_instance, c)
    assert h is c
    j = map_structure(no_map_instance, d)
    assert j[0] is a
    k = map_structure(no_map_instance, e)
    assert k[0] is c


if __name__ == '__main__':
    test

# Generated at 2022-06-23 17:33:48.559026
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def foo(x,y):
        return [x,y]

    a = {'year': 2005, 'month': 7, 'day': 14}
    b = {'year': 2005, 'month': 8, 'day': 15}

    c = map_structure_zip(foo, a,b)

    assert c[0]==a['year']
    assert c[1]==b['year']
    assert c[2]==a['month']
    assert c[3]==b['month']
    assert c[4]==a['day']
    assert c[5]==b['day']

# Generated at 2022-06-23 17:33:52.711757
# Unit test for function reverse_map
def test_reverse_map():
    assert reverse_map({"a": 1, "b": 0, "c": 2}) == ['b', 'a', 'c']
    assert reverse_map({'a': 1}) == ['a']
    assert reverse_map({}) == []

# Generated at 2022-06-23 17:34:02.546097
# Unit test for function map_structure
def test_map_structure():
    x = [1, 2, 3]
    y = {'foo': 1, 'bar': 2}
    z = tuple(x)

    def f(x):
        return x + 1
    assert map_structure(f, x) == [2, 3, 4]
    assert map_structure(f, y) == {'foo': 2, 'bar': 3}
    assert map_structure(f, z) == (2, 3, 4)

    x = {'a': no_map_instance([1, 2, 3]), 'b': no_map_instance({'foo': 1, 'bar': 2})}
    def g(x, y):
        return x + y
    y = map_structure_zip(g, x)

# Generated at 2022-06-23 17:34:13.220261
# Unit test for function map_structure
def test_map_structure():
    test = {"op": "add", "inputs": [1, 2], "kws": {"alpha": 0.5}, "results": (1, 2)}

    def incr(x): return x + 1

    test_incr = map_structure(incr, test)
    assert test_incr == {"op": "add", "inputs": [2, 3], "kws": {"alpha": 0.5}, "results": (2, 3)}

    def add(x, y): return x + y

    test_add = map_structure_zip(add, [test, test])
    assert test_add == {"op": "addadd", "inputs": [2, 4], "kws": {"alphaalpha": 1.0}, "results": (2, 4)}


# Generated at 2022-06-23 17:34:17.568250
# Unit test for function no_map_instance
def test_no_map_instance():
    x = [1,2,3]
    assert getattr(no_map_instance(x), _NO_MAP_INSTANCE_ATTR) == True
    assert getattr(x, _NO_MAP_INSTANCE_ATTR) == None

test_no_map_instance()

# Generated at 2022-06-23 17:34:23.575679
# Unit test for function reverse_map

# Generated at 2022-06-23 17:34:33.646814
# Unit test for function no_map_instance
def test_no_map_instance():
    class TestList(list):
        pass
    register_no_map_class(TestList)

    class TestDict(dict):
        pass
    register_no_map_class(TestDict)

    class TestTuple(tuple):
        pass
    register_no_map_class(TestTuple)

    class TestSet(set):
        pass
    register_no_map_class(TestSet)

    class TestObject(object):
        pass
    test_object = TestObject()
    no_map_instance(test_object)

    test_list = [1, 2, 3]
    no_map_instance(test_list)

    test_tuple = (1, 2, 3)
    no_map_instance(test_tuple)


# Generated at 2022-06-23 17:34:36.671707
# Unit test for function reverse_map
def test_reverse_map():
  assert reverse_map({'a':0,'b':1,'c':2})==['a','b','c'], "method reverse_map failed"

test_reverse_map()
 

# Generated at 2022-06-23 17:34:43.840832
# Unit test for function map_structure
def test_map_structure():
    # Test 1.  Test list
    def fn(a):
        return a+1

    input_list = [[1,2],[3,4],[5,6]]
    output_list = [[2,3],[4,5],[6,7]]

    assert(map_structure(fn, input_list) == output_list)

    def fn(a,b):
        return a+b

    input_list = [[1,2],[3,4],[5,6]]
    output_list = [[2,4],[6,8],[10,12]]

    assert(map_structure_zip(fn, input_list, input_list) == output_list)

    # Test 2. Test Dict
    def fn(a):
        return a + 'a'


# Generated at 2022-06-23 17:34:46.804395
# Unit test for function register_no_map_class
def test_register_no_map_class():
    try:
        register_no_map_class(torch.Size)
    except:
        assert(False)


# Generated at 2022-06-23 17:34:57.156363
# Unit test for function reverse_map

# Generated at 2022-06-23 17:34:59.672118
# Unit test for function reverse_map
def test_reverse_map():
    d = {"a": 1, "b": 2, "c": 0}
    assert reverse_map(d) == ["c", "a", "b"]

# Generated at 2022-06-23 17:35:07.494396
# Unit test for function map_structure_zip
def test_map_structure_zip():
    nested_list = [[[[1, 2, 3], [4, 5, 6]]]]
    nested_dict = {0: {'a': {'b': {'d': 0, 'e': 1}, 'c': 2}, 'b': 3}, 1: 4}
    nested_tuple = (0, (1, (2, (3, 4))))
    nested_tuple_names = (0, (1, (2, (3, 'd'))))
    # fn should take two tuples as input and return a tuple of the same length
    def fn(x, y):
        assert len(x) == len(y)
        return x[0] + y[0],
    # Test lists, dicts and tuples

# Generated at 2022-06-23 17:35:14.460824
# Unit test for function reverse_map
def test_reverse_map():
  d = {"a": 0, "b": 1, "c": 2}
  reversed_d = reverse_map(d)

  assert(reversed_d[0] == "a")
  assert(reversed_d[1] == "b")
  assert(reversed_d[2] == "c")

if __name__ == "__main__":
    test_reverse_map()

# Generated at 2022-06-23 17:35:17.357725
# Unit test for function no_map_instance
def test_no_map_instance():
    class T(tuple):
        pass
    test = T((1, no_map_instance((2, 3))))
    str(test)


# Generated at 2022-06-23 17:35:24.318015
# Unit test for function no_map_instance
def test_no_map_instance():
    class Foo:
        def __init__(self, _t):
            self.t = _t

    f = Foo(tuple([1, 2, 3]))
    ff = no_map_instance(f)
    assert ff.t == tuple([1, 2, 3])
    ff.t = (4, 5, 6)
    assert ff.t == tuple([4, 5, 6])



# Generated at 2022-06-23 17:35:32.366299
# Unit test for function map_structure
def test_map_structure():
    list = [{'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}, {'a': 5, 'b': 6, 'c': {'d': 7, 'e': 8}}]
    def func_plus(x, y):
        return x + y
    def func_times(x, y):
        return x * y
    assert map_structure_zip(func_plus, list) == [{'a': 6, 'b': 8, 'c': {'d': 10, 'e': 12}}, {'a': 10, 'b': 12, 'c': {'d': 14, 'e': 16}}]

# Generated at 2022-06-23 17:35:41.481713
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class Test1:
        pass
    class Test2(list):
        pass
    class Test3(dict):
        pass
    class Test4(Test3):
        pass
    class Test5:
        pass
    register_no_map_class(Test1)
    register_no_map_class(Test2)
    register_no_map_class(Test3)
    register_no_map_class(Test4)
    assert Test1 in _NO_MAP_TYPES and Test2 in _NO_MAP_TYPES
    assert Test3 in _NO_MAP_TYPES and Test4 in _NO_MAP_TYPES
    assert Test5 not in _NO_MAP_TYPES


# Generated at 2022-06-23 17:35:52.554364
# Unit test for function map_structure
def test_map_structure():
    # 1. test "list" data structure
    print("\n1. test \"list\" data structure")
    data = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    print("Original data = ", data)
    dataRes = map_structure(lambda x: x * 2, data)
    print("1.1 map_structure(lambda x: x * 2, data) = ", dataRes)
    dataRes = map_structure(lambda x: x * 2, [[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    print("1.2 map_structure(lambda x: x * 2, [[1, 2, 3], [4, 5, 6], [7, 8, 9]]) = ", dataRes)
    dataRes = map_structure

# Generated at 2022-06-23 17:36:05.840676
# Unit test for function register_no_map_class
def test_register_no_map_class():
    a = torch.Tensor([1, 2, 3, 4, 5])

    def process_tensor(x):
        return x + 1

    def process_tensor_list(x):
        return [process_tensor(y) for y in x]

    def process_tensor_list_tuple(x):
        return tuple(process_tensor_list(y) for y in x)

    def process_tensor_list_dict(x):
        return dict(process_tensor_list(y) for y in x)

    def process_tensor_list_set(x):
        return set(process_tensor_list(y) for y in x)

    def process_tensor_list_struct(x):
        return process_tensor_list(x)

    # Test that it works
    assert torch

# Generated at 2022-06-23 17:36:17.286361
# Unit test for function reverse_map
def test_reverse_map():
    print("Test function reverse_map")

# Generated at 2022-06-23 17:36:29.399667
# Unit test for function reverse_map

# Generated at 2022-06-23 17:36:38.732469
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # test cases
    # normal cases
    l1 = [[1, 2], [3, 4], [5, 6]]
    l2 = [[7, 8], [9, 10], [11, 12]]
    l3 = [[13, 14], [15, 16], [17, 18]]
    l4 = [[19, 20], [21, 22], [23, 24]]
    normal_case = [l1, l2, l3]
    normal_case_expect = [[48, 52], [96, 104], [144, 156]]
    # illegal cases
    l5 = [[25, 26], [27, 28], [29, 30]]
    l6 = [[31, 32], [33, 34], [35, 36]]
    l7 = [[37, 38], [39, 40], [41, 42]]

# Generated at 2022-06-23 17:36:40.782706
# Unit test for function reverse_map
def test_reverse_map():
    d = {'a':0, 'b':1, 'c':2}
    assert reverse_map(d) == ['a', 'b', 'c']

# Generated at 2022-06-23 17:36:48.789502
# Unit test for function map_structure
def test_map_structure():
    import torch
    import torch.autograd as autograd
    import torch.nn as nn
    F = autograd.Variable(torch.FloatTensor([[1, 2, 3]]))
    L = [1, 1]
    H1 = nn.Tanh(inplace=True)
    H2 = nn.Tanh(inplace=True)
    assert(map_structure(lambda x: x.shape, [F, 1, L]) == [(1, 3), (), (2,)])
    assert(map_structure(lambda x: x.shape, [F, H1, H2]) == [(1, 3), (), ()])

# Generated at 2022-06-23 17:36:55.806537
# Unit test for function no_map_instance
def test_no_map_instance():
    import collections
    a_list = [1, 2, 3]
    a_dict = {'a': 1, 'b': 2, 'c': 3}
    a_set = {'a', 'b'}
    a_tuple = ('a', 'b')
    a_namedtuple = collections.namedtuple('A', 'a b')
    print(map_structure(lambda x: x+'x', a_list))
    print(map_structure(lambda x: x+'x', no_map_instance(a_list)))
    print(map_structure(lambda x: x+'x', a_dict))
    print(map_structure(lambda x: x+'x', no_map_instance(a_dict)))

# Generated at 2022-06-23 17:37:06.497270
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def func(a, b, c):
        return (a, b, c)

    # List:
    objs = [[1, 2], [1, 2], [1, 2]]
    mapped = map_structure_zip(func, objs)
    assert mapped[0] == (1, 1, 1)
    assert mapped[1] == (2, 2, 2)

    # Dict:
    objs = [{'1': 1, '2': 2}, {'1': 1, '2': 2}, {'1': 1, '2': 2}]
    mapped = map_structure_zip(func, objs)
    assert mapped['1'] == (1, 1, 1)
    assert mapped['2'] == (2, 2, 2)

    # Tuple:

# Generated at 2022-06-23 17:37:09.248545
# Unit test for function reverse_map
def test_reverse_map():
    d = {"a":1, "b":2, "c":3, "d":2}
    res = reverse_map(d)
    # print(res)
    assert res == ["a","b","c","b"]


# Generated at 2022-06-23 17:37:17.826819
# Unit test for function reverse_map
def test_reverse_map():
    d = {"A":1,"B":2,"C":3,"D":4,"E":5,"F":6}
    d_list = reverse_map(d)
    assert(d_list[0]=="A")
    assert(d_list[1]=="B")
    assert(d_list[2]=="C")
    assert(d_list[3]=="D")
    assert(d_list[4]=="E")
    assert(d_list[5]=="F")

if __name__ == "__main__":
    test_reverse_map()