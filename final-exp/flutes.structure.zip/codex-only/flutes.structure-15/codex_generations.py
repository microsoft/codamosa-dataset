

# Generated at 2022-06-23 17:27:24.460895
# Unit test for function map_structure
def test_map_structure():
    N = 10

    class MyContainer(object):
        def __init__(self, data):
            self.data = data

        def __str__(self):
            return "{}".format(self.data)

    def _assertFn(val, newVal):
        assert isinstance(newVal, MyContainer)
        assert newVal.data == val.data + 1

    data = [MyContainer(i) for i in range(N)]

    # Test list
    newData = map_structure(lambda x: MyContainer(x.data + 1), data)
    for val, newVal in zip(data, newData):
        _assertFn(val, newVal)
    assert isinstance(newData, list)

    # Test tuple

# Generated at 2022-06-23 17:27:34.072233
# Unit test for function map_structure_zip
def test_map_structure_zip():
    res = map_structure_zip(lambda x, y: (x, y), [("a", "b"), "c"], [("d", "e"), "f"])
    assert res == [("a", "d"), ("b", "e")], "A"
    res = map_structure_zip(lambda x, y: x + y, [[1, 2, 3], [4, 5, 6]], ["a", "b", "c"])
    assert res == [["1a", "2b", "3c"], [4, 5, 6]], "B"
    def factory():
        a = np.array([[1,2,3],[4,5,6]])
        b = np.array([[0,2,4],[8,10,12]])
        return a, b

    res = map_st

# Generated at 2022-06-23 17:27:46.614984
# Unit test for function reverse_map

# Generated at 2022-06-23 17:27:53.182677
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class MyList(list):
        pass
    register_no_map_class(MyList)
    my_list = MyList([1, 2])
    my_list_mapped = map_structure(lambda x: x+1, my_list)
    assert my_list_mapped == [2, 3]




# Generated at 2022-06-23 17:28:02.625263
# Unit test for function map_structure
def test_map_structure():
    from collections import namedtuple
    from typing import NamedTuple
    import torch

    @no_type_check
    def _add1(x):
        return x + 1

    my_list = [1, 2, 3]
    my_tuple = (1, 2, 3)
    my_dict = {'a': 1, 'b': 2, 'c': 3}
    my_namedtuple = namedtuple('my_namedtuple', ['col1', 'col2', 'col3'])(1, 2, 3)

    my_list_mapped = map_structure(_add1, my_list)
    assert my_list_mapped == [2, 3, 4]

    my_tuple_mapped = map_structure(_add1, my_tuple)
    assert my_tuple_mapped

# Generated at 2022-06-23 17:28:06.340141
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from torch import Size
    class SubSize(Size):
        def __init__(self, *args):
            super(SubSize, self).__init__(*args)

    register_no_map_class(SubSize)
    assert map_structure(lambda x: x, SubSize((1,2))) == SubSize((1,2))


# Generated at 2022-06-23 17:28:18.128874
# Unit test for function map_structure
def test_map_structure():
    assert map_structure(lambda x: x + 1, [2, 3, 4]) == [3, 4, 5]
    assert map_structure(lambda x: x + 2, [[2,3,4], [1, 2, 3]]) == [[4, 5, 6], [3, 4, 5]]
    assert map_structure(lambda x: x + 2, ((2,1, 'hello'), [1, 2, 3])) == ((4, 3, 'helloo'), [3, 4, 5])
    assert map_structure(lambda x: x + 2, set([2,3,4])) == {4, 5, 6}
    assert map_structure(lambda x: x + 2, {'a': 2, 'b': 3}) == {'a': 4, 'b': 5}
    assert map_structure

# Generated at 2022-06-23 17:28:29.267251
# Unit test for function reverse_map

# Generated at 2022-06-23 17:28:33.449435
# Unit test for function reverse_map
def test_reverse_map():
    dict_test = {'c': 1, 'b': 2, 'a': 3}
    result = ['b', 'c', 'a']
    assert reverse_map(dict_test) == result
    print("test_reverse_map pass")
    

# Generated at 2022-06-23 17:28:36.752344
# Unit test for function reverse_map
def test_reverse_map():
    d1 = {1: 'a', 2: 'b', 3: 'c'}
    d2 = reverse_map(d1)
    assert d2 == ['a', 'b', 'c']


# Generated at 2022-06-23 17:28:46.239567
# Unit test for function map_structure
def test_map_structure():
    # Basic case: a dictionary
    a = {
        'a': 1,
        'b': 2,
        'c': [1, 2]
    }
    b = map_structure(lambda x: x + 1, a)
    c = {
        'a': 2,
        'b': 3,
        'c': [2, 3]
    }
    assert b == c

    # Nested case
    d = {
        'a': {
            'a': 1,
            'b': 2
        },
        'b': [1, 2],
        'c': 2
    }
    e = map_structure(lambda x: x + 1, d)

# Generated at 2022-06-23 17:28:46.686750
# Unit test for function no_map_instance
def test_no_map_instance():
    pass

# Generated at 2022-06-23 17:28:58.783774
# Unit test for function map_structure_zip
def test_map_structure_zip():
    l1 = [1, 2, 3]
    l2 = [4, 5, 6]
    l3 = [7, 8, 9]
    l4 = [10, 11, 12]
    t1 = (1, 2, 3)
    t2 = (4, 5, 6)
    t3 = (7, 8, 9)
    t4 = (10, 11, 12)
    d1 = {1: 1, 2: 2, 3: 3}
    d2 = {1: 4, 2: 5, 3: 6}
    d3 = {1: 7, 2: 8, 3: 9}
    d4 = {1: 10, 2: 11, 3: 12}

# Generated at 2022-06-23 17:29:10.005379
# Unit test for function no_map_instance
def test_no_map_instance():
    assert no_map_instance((1, 2, 3)) == (1, 2, 3)
    assert no_map_instance([1, 2, 3]) == [1, 2, 3]
    assert no_map_instance({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert no_map_instance([(1, 2), (3, 4)]) == [(1, 2), (3, 4)]

    assert type(no_map_instance({"a": 1, "b": 2})) != dict
    assert type(no_map_instance([1, 2, 3])) != list
    assert type(no_map_instance((1, 2, 3))) != tuple
    assert type(no_map_instance([(1, 2), (3, 4)])) != list



# Generated at 2022-06-23 17:29:22.666246
# Unit test for function no_map_instance
def test_no_map_instance():
    assert getattr(no_map_instance(list()), _NO_MAP_INSTANCE_ATTR, False)
    assert getattr(no_map_instance(tuple()), _NO_MAP_INSTANCE_ATTR, False)
    assert getattr(no_map_instance(dict()), _NO_MAP_INSTANCE_ATTR, False)
    assert getattr(no_map_instance(set()), _NO_MAP_INSTANCE_ATTR, False)
    
    assert not hasattr(no_map_instance(2), _NO_MAP_INSTANCE_ATTR)

    # Test custom types
    class CustomType(object):
        def __init__(self, value):
            self.value = value
        def __eq__(self, other):
            return self.value == other.value
    

# Generated at 2022-06-23 17:29:27.218439
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from utils.util import Size
    Size1 = Size(1,1)
    register_no_map_class(Size)

    assert Size1 in _NO_MAP_TYPES


# Generated at 2022-06-23 17:29:37.333091
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(a, b, c):
        return a, b, c

    def assert_same_structure(a, b):
        assert a.__class__ == b.__class__
        if isinstance(a, list):
            assert_same_structure(a[0], b[0])
        elif isinstance(a, dict):
            assert a.keys() == b.keys()
            for k, v in a.items():
                assert_same_structure(v, b[k])
        elif isinstance(a, tuple):
            assert_same_structure(a[0], b[0])
        else:
            pass

    # list
    a = [[1, 2], [3, 4], [5, 6]]
    b = [[5, 6], [7, 8], [9, 10]]

# Generated at 2022-06-23 17:29:43.294829
# Unit test for function reverse_map
def test_reverse_map():
    assert reverse_map({}) == []
    assert reverse_map({'a': 1, 'b': 3, 'c': 2}) == ['b', 'c', 'a']
    assert reverse_map({'a': 0, 'b': 1, 'c': 2}) == ['a', 'b', 'c']
    assert reverse_map({0: 'a', 1: 'b', 2: 'c'}) == ['a', 'b', 'c']

# Generated at 2022-06-23 17:29:50.958197
# Unit test for function register_no_map_class
def test_register_no_map_class():
    register_no_map_class(list)
    a = list()
    b = [[1,2],[3,4]]
    assert type(map_structure_zip(lambda x: print("test"), [a,b])) == list
    assert type(map_structure_zip(lambda x: print("test"), [b,b])) == list

register_no_map_class(list)
register_no_map_class(set)
register_no_map_class(dict)

# Generated at 2022-06-23 17:30:00.729193
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class Container(list):
        pass

    map_structure(lambda x: x * 2, [Container([1, 2, 3])])
    try:
        _ = map_structure(lambda x: x * 2, [Container([1, 2, 3])])
    except AttributeError:
        print("List inside a class can NOT be mapped!")
    register_no_map_class(Container)
    assert map_structure(lambda x: x * 2, [Container([1, 2, 3])]) == [Container([1, 2, 3])]
    print("List inside a class can be mapped now!")


# Generated at 2022-06-23 17:30:10.970775
# Unit test for function map_structure
def test_map_structure():
    input_word_ids = {
        'word_ids': [2, 4, 6, 8],
        'word_1_ids': [2, 4, 5, 8],
        'word_2_ids': [2, 5, 6, 8],
        'word_3_ids': [2, 5, 6, 9],
        'word_4_ids': [2, 4, 6, 8],
    }

# Generated at 2022-06-23 17:30:17.865965
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # Test list of strings, integer, and floats
    def fn(a: str, b: int, c: float) -> str:
        return f"{a}{b}{c}"
    objs = [
        ["a", "b", "c"],
        [1, 2, 3],
        [1.1, 2.2, 3.3],
    ]
    assert map_structure_zip(fn, objs) == ["a1.11", "b2.22", "c3.33"]

# Generated at 2022-06-23 17:30:27.220864
# Unit test for function map_structure_zip
def test_map_structure_zip():
    test_name = 'map_structure_zip'
    print('\n%s' % test_name)
    def fn(a, b):
        return a + b

    input = [
        {'a': [1,2,3], 'b':[1,2,3]},
        {'a': '1', 'b':'4'}
    ]
    output = map_structure_zip(fn, input)
    assert(output == [{'a': [2,4,6], 'b':[5,6,7]}, {'a': '11', 'b':'44'}])
    print('Test %s passed' % test_name)

if __name__ == '__main__':
    test_map_structure_zip()

# Generated at 2022-06-23 17:30:34.567129
# Unit test for function map_structure
def test_map_structure():
    input_list = ['a', 'b', 'c']
    output_list = ['A', 'B', 'C']

    assert output_list == map_structure(lambda x: x.upper(), input_list)

    input_list = [1, 2, 3, 4]
    output_list = [4, 9, 16, 25]

    assert output_list == map_structure(lambda x: x ** 2, input_list)

    input_dict = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    output_dict = {'a': 4, 'b': 9, 'c': 16, 'd': 25}

    assert output_dict == map_structure(lambda x: x ** 2, input_dict)


# Generated at 2022-06-23 17:30:37.052528
# Unit test for function reverse_map
def test_reverse_map():
    assert reverse_map({'a':0, 'b':1, 'x':2}) == ['a', 'b', 'x']

# Generated at 2022-06-23 17:30:39.902095
# Unit test for function reverse_map
def test_reverse_map():
    d = {'a': 0, 'aardvark': 1, 'abandon': 2}
    assert reverse_map(d) == ['a', 'aardvark', 'abandon']

# Generated at 2022-06-23 17:30:47.332543
# Unit test for function map_structure_zip
def test_map_structure_zip():
    A = namedtuple("A", ("x", "y"))
    B = namedtuple("B", ("z"))
    b = B("b")
    a = A(1, 2)

    def sum_fn(*objs: A) -> A:
        return A(sum([o.x for o in objs]), sum([o.y for o in objs]))

    assert (map_structure_zip(sum_fn, [a, a, a]) == A(3, 6))
    assert (map_structure_zip(sum_fn, [a, b]) == A(1, 2))



# Generated at 2022-06-23 17:31:00.523813
# Unit test for function no_map_instance
def test_no_map_instance():
    # Test tuple
    l = (1, [2, 3])
    l_formatted = no_map_instance(l)
    l_formatted_0 = no_map_instance(l[0])
    l_formatted_1 = no_map_instance(l[1])

    # Test list
    l = [[1, 2, 3], [4, 5, 6]]
    l_formatted = no_map_instance(l)
    l_formatted_0 = no_map_instance(l[0])
    l_formatted_1 = no_map_instance(l[1])

    # Test dict
    d = {'a': 1, 'b': 2}
    d_formatted = no_map_instance(d)

# Generated at 2022-06-23 17:31:12.629752
# Unit test for function no_map_instance
def test_no_map_instance():
    class MyList(list):
        pass
    
    # test instance level
    instance = MyList([1,2,3])
    assert not hasattr(instance, _NO_MAP_INSTANCE_ATTR)
    instance = no_map_instance(instance)
    assert hasattr(instance, _NO_MAP_INSTANCE_ATTR)

    # test class level
    assert MyList in _NO_MAP_TYPES


# Generated at 2022-06-23 17:31:24.893954
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from gcd.inference.metadata import IntegerList, IntegerTuple, StrTuple, StrList, StrDict
    register_no_map_class(IntegerList)
    register_no_map_class(IntegerTuple)
    register_no_map_class(StrTuple)
    register_no_map_class(StrList)
    register_no_map_class(StrDict)
    # Test 'map_structure'

# Generated at 2022-06-23 17:31:37.666687
# Unit test for function register_no_map_class
def test_register_no_map_class():
    # Define a class for testing
    class MyClass:
        def __init__(self, a,b):
            self.a = a
            self.b = b
    # Register the class as non-mappable
    register_no_map_class(MyClass)
    # Define some instances of MyClass
    my_class_obj1 = MyClass(1,2)
    my_class_obj2 = MyClass(3,4)

    # Define a function to map over
    def fn(x):
        return x.a + x.b

    # Map over MyClass
    result = map_structure(fn,[my_class_obj1, my_class_obj2])
    print(type(result))
    print(result)
    assert type(result) == list

# Generated at 2022-06-23 17:31:42.737296
# Unit test for function register_no_map_class
def test_register_no_map_class():
    @register_no_map_class(type([]))
    def myList():
        return []

    @register_no_map_class(type([]))
    def myList2():
        return []

    myList3 = []

    assert myList() != myList2()
    assert myList() == myList2()
    assert myList() != myList3

# Generated at 2022-06-23 17:31:55.280517
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(x, y):
        return x + y

    def fn2(x, y):
        return x * y

    def fn3(x, y, z):
        return x + y + z
    # test single elem
    x = (1, 2, 3, 4)
    y = (11, 22, 33, 44)
    assert map_structure_zip(fn, [x,y]) == (12, 24, 36, 48)
    assert map_structure_zip(fn3, [x,y,x,y]) == (23, 46, 69, 92)

    # test nested tuple (of tuples)
    x = ((1,2),(3,4))
    y = ((11,22),(33,44))

# Generated at 2022-06-23 17:32:04.886153
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class A:
        def __init__(self, a):
            self.a = a
            register_no_map_class(A)
    class B(A):
        pass
    a = A(1)
    b = B(2)
    register_no_map_class(A)
    def f(x):
        return x + 1
    c = map_structure(f, a)
    d = map_structure(f, b)
    assert c.a == 2
    assert d.a == 3

test_register_no_map_class()

# Generated at 2022-06-23 17:32:08.890050
# Unit test for function reverse_map
def test_reverse_map():
    word_to_id = ["a", "aardvark", "abandon"]
    id_to_word = reverse_map(word_to_id)
    assert id_to_word == ["a", "aardvark", "abandon"]

if __name__ == '__main__':
    test_reverse_map()

# Generated at 2022-06-23 17:32:21.944488
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(x: int, y: int) -> int:
        return x + y
    xs = [1, 2, 3]
    ys = [4, 5, 6]
    xys = map_structure_zip(fn, [xs, ys])
    assert(xys == [5, 7, 9])
    xys = map_structure_zip(fn, [[1, 2], [3, 4]])
    assert(xys == [4, 6])
    xys = map_structure_zip(fn, [[1, 2], [3, 4], [5, 6]])
    assert(xys == [9, 12])
    xys = map_structure_zip(fn, [[1, 2], [3, 4], [5, 6], [7, 8]])

# Generated at 2022-06-23 17:32:34.341344
# Unit test for function map_structure
def test_map_structure():
    def my_fn(obj):
        new_obj = obj + 2
        return new_obj

    Y = [1,2,3,4]
    Y_trans = map_structure(my_fn, Y)
    print(Y_trans)

    Y2 = [[1, 2, 3], [4, 5, 6]]
    Y2_trans = map_structure(my_fn, Y2)
    print(Y2_trans)

    Y3 = {'a': 1, 'b': 2}
    Y3_trans = map_structure(my_fn, Y3)
    print(Y3_trans)

    Y4 = {'a': [1, 2, 3], 'b': [4, 5, 6]}
    Y4_trans = map_structure(my_fn, Y4)
   

# Generated at 2022-06-23 17:32:41.543725
# Unit test for function reverse_map
def test_reverse_map():
    numbers = [0, 1, 2, 3, 4, 5]
    number_to_id = {num: idx for idx, num in enumerate(numbers)}
    id_to_number = reverse_map(number_to_id)
    assert (numbers == id_to_number)
    print("Reverse_map test passed!")


# Generated at 2022-06-23 17:32:50.911354
# Unit test for function map_structure_zip
def test_map_structure_zip():
    d = [{'a': [1, 2, 3], 'b': [1, 2, 3], 'c': [1, 2, 3]},
         {'a': [1, 2, 3], 'b': [1, 2, 3], 'c': [1, 2, 3]}]
    e = [{'a': [1, 2, 3], 'b': [1, 2, 3], 'c': [1, 2, 3]},
         {'a': [9, 8, 7], 'b': [1, 2, 3], 'c': [1, 2, 3]}]
    f = map_structure_zip(lambda *x: x, d)
    assert (f == d)
    f = map_structure_zip(lambda *x: x, e)
    assert (f == e)

# Generated at 2022-06-23 17:33:00.539612
# Unit test for function map_structure_zip
def test_map_structure_zip():
    from copy import copy, deepcopy
    a = [1, [3, 4]]
    b = [7, [9, 10]]
    c = [13, [15, 16]]
    d = map_structure_zip(sum, [a, b])
    e = map_structure_zip(sum, [a, b, c])
    assert d == [8, [12, 14]]
    assert e == [21, [27, 30]]
    assert a == [1, [3, 4]] and b == [7, [9, 10]] and c == [13, [15, 16]]

    u = copy(a)
    v = deepcopy(a)
    assert u == a and v == a
    u[1][1] = 4.5
    assert u == [1, [3, 4.5]] and v

# Generated at 2022-06-23 17:33:09.427432
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # test result
    class Result:
        def __init__(self, input1, input2):
            self.input1 = input1
            self.input2 = input2

        def __repr__(self):
            return f"[object({self.input1}, {self.input2})]"

        def __eq__(self, other):
            return isinstance(other, Result) and self.input1 == other.input1 and self.input2 == other.input2

    # test struct
    class Struct1:
        def __init__(self, *inputs):
            self.input = inputs

        def __repr__(self):
            return f"[struct1({self.input})]"

        def __eq__(self, other):
            return isinstance(other, Struct1) and self.input == other.input



# Generated at 2022-06-23 17:33:18.604876
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # Prepare the input
    A1 = np.random.rand(3, 4)
    B1 = np.random.rand(3, 4)
    A2 = np.random.rand(2, 2)
    B2 = np.random.rand(2, 2)
    A3 = np.random.rand(4)
    B3 = np.random.rand(4)
    A4 = np.random.rand()
    B4 = np.random.rand()
    C1 = np.random.randint(0, 5, (4, 4))
    D1 = np.random.randint(0, 5, (4, 4))
    C2 = np.random.randint(0, 5, (3,))
    D2 = np.random.randint(0, 5, (3,))
    C3

# Generated at 2022-06-23 17:33:30.513321
# Unit test for function no_map_instance
def test_no_map_instance():

    sent1 = no_map_instance(['the', 'cat', 'sat', 'on', 'the', 'mat', '.'])
    sent2 = no_map_instance(['the', 'dog', 'sat', 'on', 'the', 'mat', '.'])

    def map_iter_sentence(fn, sentence):
        return no_map_instance([fn(x) for x in sentence])

    def map_iter_sentence_zip(fn, sentence1, sentence2):
        return no_map_instance([fn(x, y) for x, y in zip(sentence1, sentence2)])

    def merge_iter(x, y):
        return f'{x}_{y}'

    sent1 = ['the', 'cat', 'sat', 'on', 'the', 'mat', '.']

# Generated at 2022-06-23 17:33:40.839428
# Unit test for function map_structure_zip
def test_map_structure_zip():
    """Test for sequence data (dict and list)"""
    def fn_max(x, y):
        return max(x, y)

    d = dict(a=1, b=2, c=dict(d=4))
    d_zip = map_structure_zip(fn_max, [d, d])
    assert d == d_zip
    assert d['c'] is d_zip['c']

    d_max = dict(a=3, b=4, c=dict(d=5))
    d_zip_max = map_structure_zip(fn_max, [d, d_max])
    assert d_zip_max == dict(a=3, b=4, c=dict(d=5))
    assert d_zip_max['c'] is not d['c']

    d_max_2

# Generated at 2022-06-23 17:33:52.495339
# Unit test for function no_map_instance
def test_no_map_instance():
    x = no_map_instance(list)
    y = no_map_instance(x)
    assert x is y
    assert x == y

    x = no_map_instance(list())
    y = no_map_instance(x)
    assert x is y
    assert x == y

    x = no_map_instance(tuple())
    y = no_map_instance(x)
    assert x is y
    assert x == y

    x = no_map_instance(dict())
    y = no_map_instance(x)
    assert x is y
    assert x == y

    x = no_map_instance([1, 2, 3])
    y = no_map_instance(x)
    assert x is y

    x = no_map_instance((1, 2, 3))
    y = no

# Generated at 2022-06-23 17:33:56.614885
# Unit test for function no_map_instance
def test_no_map_instance():
    instance = no_map_instance([1, 2, 3])
    carry_on_map = map_structure(lambda x: x + 1, instance)
    assert carry_on_map == [1, 2, 3]
    assert carry_on_map is not instance

# Generated at 2022-06-23 17:34:01.952526
# Unit test for function reverse_map
def test_reverse_map():
    words = ['a', 'aardvark', 'abandon', 'ability', 'able', 'about', 'above', 'abuse', 'abusing', 'abusive']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    print(id_to_word)
    assert words == id_to_word


# Generated at 2022-06-23 17:34:12.910080
# Unit test for function no_map_instance
def test_no_map_instance():
    # Cases where the function should be marked no map
    no_map_cases = [[], (), set(), {}, 0, 1, 3.5, "Hello", (1, 2, 3), ["a", "b", "c"], {"a": 2}]
    for no_map_case in no_map_cases:
        no_map_case_instance = no_map_instance(no_map_case)
        assert hasattr(no_map_case_instance, _NO_MAP_INSTANCE_ATTR)
        assert getattr(no_map_case_instance, _NO_MAP_INSTANCE_ATTR)
        assert no_map_case == no_map_case_instance

    # Case where the function should not be marked no map
    not_no_map_case = [0, 1, 2]
    not_no_map

# Generated at 2022-06-23 17:34:18.553223
# Unit test for function no_map_instance
def test_no_map_instance():
    a = [1, 2, [3, 4, [5, 6], 7]]
    no_map_instance(a)
    assert(map_structure(lambda x: x*2, a) == a)
    b = no_map_instance([1, 2, 3])
    assert( map_structure(lambda x: x*2, b) == [1, 2, 3])


if __name__ == '__main__':
    test_no_map_instance()

# Generated at 2022-06-23 17:34:24.083348
# Unit test for function reverse_map

# Generated at 2022-06-23 17:34:28.965199
# Unit test for function map_structure_zip
def test_map_structure_zip():
    assert(map_structure_zip(lambda x, y: (x, y), [[1, 2], [3, 4]]) == [(1, 3), (2, 4)])
    assert(map_structure_zip(lambda x, y: (x, y), [[1, 2], [3, 4], [5, 6]]) == [(1, 3, 5), (2, 4, 6)])
    assert(map_structure_zip(lambda x, y, z: (x, y, z), [[1, 2], [3, 4], [5, 6]]) == [(1, 3, 5), (2, 4, 6)])

# Generated at 2022-06-23 17:34:39.379937
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class Example:
        def __init__(self, x):
            self.x = x
        def __eq__(self, other):
            return self.x == other.x
        def __str__(self):
            return "Example(" + str(self.x) + ")"

    register_no_map_class(Example)

    a = Example(1)
    b = Example(2)
    c = map_structure(lambda x: x + 1, [a, b])

    assert(not c == [a, b])
    assert(str(c) == "[Example(2), Example(3)]")

    assert(a == c[0])
    assert(b == c[1])


# Generated at 2022-06-23 17:34:45.219866
# Unit test for function map_structure_zip
def test_map_structure_zip():
    input_list = [[1, 2, 3], [4, 5, 6]]
    input_tuple = [[1, 2, 3], [4, 5, 6]]
    input_dict = [{"a": 1, "b": 2}, {"a": 3, "b": 4}]
    input_namedtuple = [namedtuple("test1", "a b")(1, 2), namedtuple("test2", "a b")(3, 4)]
    inputs = [input_list, input_tuple, input_dict, input_namedtuple]

    def fn(input):
        return sum(input)

    expecteds = [[5, 7, 9], (5, 7, 9), {"a": 4, "b": 6}, namedtuple("test1_and_test2", "a b")(4, 6)]
   

# Generated at 2022-06-23 17:34:55.836665
# Unit test for function no_map_instance
def test_no_map_instance():
    a = torch.Size([1,2,3])
    a_no_map = no_map_instance(a)
    print(a_no_map)
    try:
        setattr(a_no_map, _NO_MAP_INSTANCE_ATTR, True)
    except AttributeError:
        print("AttributeError happened")
    new_type = type("_no_map" + a.__class__.__name__,
                    (a.__class__,), {_NO_MAP_INSTANCE_ATTR: True})
    print(new_type)
    b = new_type(a)
    print(b)


# Generated at 2022-06-23 17:35:04.931583
# Unit test for function map_structure_zip
def test_map_structure_zip():
    obj = [
        {
            "abc": 2,
            1: {
                "xyz": 5,
                "pqr": [1, 2, 3, 4]
            }
        },
        {
            "abc": 3,
            1: {
                "xyz": 6,
                "pqr": [1, 2, 3, 4]
            }
        }
    ]
    def sum_obj_elems(o1, o2):
        return map_structure_zip(lambda a,b: a+b, [o1, o2])
    print(sum_obj_elems(obj[0], obj[1]))

if __name__ == '__main__':
    test_map_structure_zip()

# Generated at 2022-06-23 17:35:14.263330
# Unit test for function map_structure_zip
def test_map_structure_zip():
    list_in = [[1, 2], [3, 4]]
    tuple_in = ([1, 2], [3, 4])
    dict_in = ({'a': 1, 'b': 2}, {'a': 3, 'b': 4})
    # torch.size
    size_in = ({'a': torch.Size([1, 2]), 'b': torch.Size([2, 3])},
               {'a': torch.Size([3, 4]), 'b': torch.Size([4, 5])})
    def add(x, y):
        return x + y
    def add2(a, b):
        return a + b
    def add3(x, y):
        return torch.Size([x, y])
    add_out1 = map_structure_zip(add, list_in)
    add_out2

# Generated at 2022-06-23 17:35:22.417555
# Unit test for function map_structure
def test_map_structure():
    a = '123'
    assert map_structure(len, a) == 3
    b = (1, 2, 3)
    assert map_structure(len, b) == 3
    assert map_structure(len, {'123': a, '456': b}) == {'123': 3, '456': 3}
    assert map_structure(len, {'123': a, '456': b}) == {'123': 3, '456': 3}
    assert map_structure(len, [[a, b, a], [b, a, b]]) == [[3, 3, 3], [3, 3, 3]]
    c = {'123': a, '456': b}
    assert map_structure_zip(lambda x, y: x + y, [a, b, c]) == '1231233123'

# Generated at 2022-06-23 17:35:28.616047
# Unit test for function reverse_map

# Generated at 2022-06-23 17:35:40.761893
# Unit test for function map_structure_zip
def test_map_structure_zip():
    xs = [1, 2, 3]
    ys = [4, 5, 6]
    zs = [7, 8, 9]

    list_res = map_structure_zip(lambda a, b, c: [a, b, c], [xs, ys, zs])
    assert list_res == [[1, 4, 7], [2, 5, 8], [3, 6, 9]]

    tuple_res = map_structure_zip(lambda a, b, c: (a, b, c), (xs, ys, zs))
    assert tuple_res == ((1, 4, 7), (2, 5, 8), (3, 6, 9))


# Generated at 2022-06-23 17:35:52.939704
# Unit test for function map_structure_zip
def test_map_structure_zip():
    ex = [[1,2,3],[1,2,3]]
    fn = lambda *args: args[0] + args[1]
    res_matrix = map_structure_zip(fn, ex)
    assert res_matrix == [[2, 4, 6], [2, 4, 6]]
    ex = [[1,2,3],[4,5,6]]
    fn = lambda *args: args[0] + args[1]
    res_matrix = map_structure_zip(fn, ex)
    assert res_matrix == [[5, 7, 9], [5, 7, 9]]
    ex = [[1,2,3],[4,5,6]]
    fn = lambda *args: args[0] + args[1]
    res_matrix = map_structure_zip(fn, ex)

# Generated at 2022-06-23 17:36:06.022176
# Unit test for function no_map_instance
def test_no_map_instance():
    from dataclasses import dataclass
    from typing import NamedTuple

    class ExampleNamedTuple(NamedTuple):
        a: int
        b: str

    class ExampleDataclass():
        a: int
        b: str

    @dataclass
    class ExampleDataclassClass:
        a: int
        b: str

    def test_with_value(fn):
        assert fn(1) == 1
        assert fn('hello') == 'hello'
        assert fn(ExampleNamedTuple(1, 'hello')) == ExampleNamedTuple(1, 'hello')
        assert fn(ExampleDataclass(1, 'hello')) == ExampleDataclass(1, 'hello')

# Generated at 2022-06-23 17:36:13.906771
# Unit test for function map_structure
def test_map_structure():
    test_list = [[1, 2, 3], [4, 5, 6]]
    a = np.asarray(test_list)
    assert map_structure(np.asarray, test_list) == a
    assert map_structure(lambda x: x, test_list) == a
    assert map_structure(lambda x: str(x), test_list) == [['1', '2', '3'], ['4', '5', '6']]

# Generated at 2022-06-23 17:36:18.588441
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class Container(list):
        pass

    register_no_map_class(Container)

    def test_func(x):
        return x + 1

    container = Container([1, 2, 3])

    mapped_container = map_structure(test_func, container)
    assert id(container) == id(mapped_container)
    # Unit test for function no_map_instance


# Generated at 2022-06-23 17:36:30.109695
# Unit test for function map_structure_zip
def test_map_structure_zip():
    assert map_structure_zip(lambda x, y: x - y, [[1, 2], [3, 4]]) == [-2, -2]
    assert map_structure_zip(lambda x, y: x - y, ((1, 2, 3), (4, 5, 6))) == (-3, -3, -3)
    assert map_structure_zip(lambda x, y: x - y, [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]) == {'a': -2, 'b': -2}
    assert map_structure_zip(lambda x, y: x - y, [{'a': 1, 'b': 2}, {'a': 3, 'b': 4, 'c': 5}]) == {'a': -2, 'b': -2}


# Generated at 2022-06-23 17:36:41.889817
# Unit test for function no_map_instance
def test_no_map_instance():
    class TestClass1(object):
        def __init__(self):
            self.a = 1
            self.b = [2, 3, 4]
        def __eq__(self, other):
            return self.a == other.a and self.b == other.b

    def no_map_test_class(test_class):
        return test_class

    class TestClass2(object):
        @staticmethod
        def no_map_test_class(test_class):
            return test_class

        @classmethod
        def no_map_test_class_classmethod(cls, test_class):
            return test_class

        def __init__(self):
            self.d = {1: 2, 3: 4}
            self.e = {'a': 'b', 'c': 'd'}



# Generated at 2022-06-23 17:36:47.488056
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import torch
    register_no_map_class(torch.Size)
    assert torch.Size in _NO_MAP_TYPES
    assert torch.Size([1]).__class__ in _NO_MAP_TYPES
    print("Success.")
    exit(0)

if __name__ == '__main__':
    test_register_no_map_class()

# Generated at 2022-06-23 17:36:52.705027
# Unit test for function map_structure_zip
def test_map_structure_zip():
    l1 = [[1, 2, 3], [3, 4, 5]]
    l2 = [[2, 3, 4], [4, 5, 6]]
    l3 = [[3, 4, 5], [5,6,7]]
    result = map_structure_zip(lambda x, y, z: x + y + z, l1, l2, l3)
    assert result == [[6, 9, 12], [12, 15, 18]]

# Generated at 2022-06-23 17:37:04.590080
# Unit test for function map_structure
def test_map_structure():
    import torch
    from torch.utils.data import Dataset

    class DummyDataset(Dataset):
        def __init__(self, tensor):
            self.tensor = tensor
        def __len__(self):
            return self.tensor.size(0)
        def __getitem__(self, idx):
            return self.tensor[idx]

    d1 = {'a': 1, 'b': 2, 'c': 3}
    d2 = {'b': [0.1, 0.2, 0.3], 'c': [5, 6], 'd': 7}
    d3 = {'d': {'e': 8}, 'f': DummyDataset(torch.full([10], 9))}

    def fn(x):
        return x*2

   

# Generated at 2022-06-23 17:37:08.319496
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import torch
    size = torch.Size([1, 2, 3])
    with pytest.raises(ValueError):
        map_structure(lambda x: x - 2, size)
    register_no_map_class(torch.Size)
    assert map_structure(lambda x: x - 2, size) == torch.Size([-1, 0, 1])

# Generated at 2022-06-23 17:37:17.557820
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import numpy as np
    def test_fn(x, y):
        return x + y
    a = np.zeros((2,3))
    b = np.ones((2,3))
    c = np.full((5,5), 2)
    d = map_structure_zip(test_fn, a,b)
    print(d)
    assert d==np.ones((2,3))
    d = map_structure_zip(test_fn, a,b,c)
    print(d)
    assert d==np.full((5,5), 3)

if __name__ == "__main__":
    test_map_structure_zip()