

# Generated at 2022-06-23 17:27:25.139759
# Unit test for function map_structure_zip
def test_map_structure_zip():
    from collections import namedtuple
    Hypothesis = namedtuple("Hypothesis", "EM, ED, LM")
    a = ["a", "b", "c"]
    b = [1, 2, 3]
    c = [0.1, 0.2, 0.3]
    hyp = [Hypothesis(1, 2, 3), Hypothesis(2, 1, 3), Hypothesis(3, 4, 2)]
    hyp_adj = [Hypothesis("a", 1, 0.1), Hypothesis("b", 2, 0.2), Hypothesis("c", 3, 0.3)]
    assert (map_structure_zip(lambda e, f, g: e + f + g, [a, b, c]) == ["a1.1", "b2.2", "c3.3"])


# Generated at 2022-06-23 17:27:34.193004
# Unit test for function no_map_instance
def test_no_map_instance():
    class1 = type("class1", (object,), {})
    class2 = type("class2", (int,), {})
    class3 = type("class3", (dict,), {})
    # object
    obj1 = object()
    assert (no_map_instance(obj1) is obj1)
    # int
    obj2 = 1
    assert (no_map_instance(obj2) is obj2)
    # other class instance
    obj3 = class1()
    assert (no_map_instance(obj3) is obj3)
    # class instance subclass from int
    obj4 = class2(1)
    assert (no_map_instance(obj4) is obj4)
    # class instance subclass from dict
    register_no_map_class(dict)
    obj5 = class3()

# Generated at 2022-06-23 17:27:38.206567
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class _MyClass(tuple):  # type: ignore
        pass
    # This class is registered in the _NO_MAP_TYPES set
    register_no_map_class(list)
    map_structure(lambda x: x, [_MyClass((1, 2))])
    # This class is not registered in the _NO_MAP_TYPES set
    map_structure(lambda x: x, [_MyClass((0, 0))])

# Generated at 2022-06-23 17:27:44.805250
# Unit test for function reverse_map
def test_reverse_map():
    words = ['a', 'aardvark', 'abandon', 'abandoned', 'abandoning', 'abandonment', 'abandons', 'abated', 'abatement']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    assert(words == id_to_word)

# Generated at 2022-06-23 17:27:54.395457
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class TestList(list):
        def __init__(self, l):
            super().__init__(l)
    
    l1 = TestList([1,2,3,4,5])
    l2 = TestList([1,2,3,4,5])
    l3 = TestList([1,2,3,4,5])
    register_no_map_class(TestList)
    fn = lambda x, y, z: [x, y, z]
    rr = map_structure_zip(fn, [l1, l2, l3])
    assert (rr == [TestList([1,2,3,4,5]), 
                   TestList([1,2,3,4,5]), 
                   TestList([1,2,3,4,5])])

# Generated at 2022-06-23 17:28:07.135075
# Unit test for function map_structure
def test_map_structure():
    class ExampleClass(object):
        pass
        # def __init__(self, val: int, val2: int):
        #     self.val = val
        #     self.val2 = val2

        # def __repr__(self):
        #     return f'{self.__class__.__name__}(val={self.val}, val2={self.val2})'
    
    example_class = ExampleClass()
    example_class.val = 2
    example_class.val2 = 3
    obj = {'a': {'b': 1, 'c': 2, 'd': [1, 2, 3]}, 'e': {'f': [1, {'ff': 4}], 'g': example_class}, 'h': None}


# Generated at 2022-06-23 17:28:16.279202
# Unit test for function map_structure_zip
def test_map_structure_zip():
    assert map_structure_zip(lambda x, y: (x, y), [[1, 2, 3], [4, 5, 6]]) == \
           [[(1, 4), (2, 5), (3, 6)]]
    assert map_structure_zip(lambda x, y: (x, y), [[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == \
           [[(1, 4, 7), (2, 5, 8), (3, 6, 9)]]

# Generated at 2022-06-23 17:28:22.651112
# Unit test for function map_structure
def test_map_structure():
    DATA = {
        'a': [[1, 2, {'b': 'x'}, 4],
              (5, 6, 7),
              {'c': {'d': ['e', {'f': 'g'}],
                    'h': 3.2}},
              9,
              0],
        'i': {'j': 'k',
              'l': ['m', 'n']},
        'o': 'p'
    }
    DATA_CLONE = copy.deepcopy(DATA)

    def _replace_command(x):
        if x == 'x':
            return 'y'
        elif isinstance(x, int):
            return x * 2
        elif isinstance(x, float):
            return x + 1
        return x

    # Test when everything is a nested object

# Generated at 2022-06-23 17:28:31.563341
# Unit test for function map_structure
def test_map_structure():
    import numpy as np
    def check_id(x):
        # Function that returns the id of every element in a list
        out = []
        for i in x:
            out.append(id(i))
        return out
    # a list
    a = [1,2,3]
    assert(check_id(a) == map_structure(check_id, a))
    # a list of list
    a = [1, [2, 3], [4, [5]]]
    assert(check_id(a) == map_structure(check_id, a))
    # a list of tuple
    a = [1, (2, 3), [4, (5, (6, 7))]]
    assert(check_id(a) == map_structure(check_id, a))
    # a list

# Generated at 2022-06-23 17:28:40.310862
# Unit test for function map_structure_zip
def test_map_structure_zip():
    fn = lambda *xs: sum(xs)
    l = [1, 2]
    t = (1, 2)
    d = {"a": 1, "b": 2}
    assert map_structure_zip(fn, [l, l, l]) == [3, 6]
    assert map_structure_zip(fn, [t, t, t]) == (3, 6)
    assert map_structure_zip(fn, [d, d, d]) == {"a": 3, "b": 6}

# Generated at 2022-06-23 17:28:53.192664
# Unit test for function map_structure
def test_map_structure():
    l = [1, 2, 3]
    t = (1, 2, 3)
    d = {'a': 1, 'b': 2, 'c': 3}
    o = collections.OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    s = {1, 2, 3}
    ln = [[1, 2], [2, 3], [3, 4]]
    tn = ((1, 2), (2, 3), (3, 4))
    lnn = [[[1, 2]], [[2, 3]], [[3, 4]]]

    def add(a, b=2):
        return a + b

    assert map_structure(add, l) == [3, 4, 5]

# Generated at 2022-06-23 17:28:59.865082
# Unit test for function reverse_map
def test_reverse_map():
    words = ['a', 'aardvark', 'abandon', 'abandoned', 'abandonment']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)

    print(words == id_to_word)


if __name__ == '__main__':
    test_reverse_map()

# Generated at 2022-06-23 17:29:10.819764
# Unit test for function reverse_map

# Generated at 2022-06-23 17:29:17.553670
# Unit test for function reverse_map
def test_reverse_map():
    words = ['a', 'aardvark', 'abandon', 'abandon', 'abandon']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    assert words == id_to_word


# Generated at 2022-06-23 17:29:25.248023
# Unit test for function no_map_instance
def test_no_map_instance():
    class Foo:
        def __init__(self, x):
            self.x = x
            self.bar = Bar(x)
            self.baz = Baz([x, x, x])

    class Bar:
        def __init__(self, x):
            self.x = x

    class Baz:
        def __init__(self, xs):
            self.xs = xs

    def _test_case(obj: Foo) -> None:
        # `map_structure` is not aware of `Foo`
        assert map_structure(lambda x: x + 1, obj) == obj

        # `map_structure` is not aware of `Foo` even if `Foo` is in a list
        assert map_structure(lambda x: x + 1, [obj, obj]) == [obj, obj]

# Generated at 2022-06-23 17:29:36.150654
# Unit test for function map_structure
def test_map_structure():
    x = {
        "a": ["b", "c"],
        "d": torch.tensor([1, 2]),
        "e": {
            "f": [[1, 2], [3, 4]],
        },
        "g": torch.tensor([3.14])
    }
    def fn(x):
        return x + 100
    import pdb
    # pdb.set_trace()
    xx = map_structure(fn, x)
    assert isinstance(xx, dict)
    for k, v in xx.items():
        assert k.startswith("a") or k.startswith("d") or k.startswith("e") or k.startswith("g")

# Generated at 2022-06-23 17:29:46.048860
# Unit test for function reverse_map

# Generated at 2022-06-23 17:29:53.096663
# Unit test for function map_structure_zip
def test_map_structure_zip():
    t = {"A": 1, "B": [2, 3], "C": (4, 5), "D": {"E": 6, "F": 7}}
    t_double = {"A": 2, "B": [4, 6], "C": (8, 10), "D": {"E": 12, "F": 14}}
    t_list = [t, t]
    fn = lambda x: x * 2
    # Test nested map_structure_zip
    t_double_res = map_structure_zip(fn, t_list)
    assert t_double == t_double_res
    # Test map_structure_zip for tuples
    t_tuple = ([4, 5], [6, 7])
    t_double_tuple = ([8, 10], [12, 14])
    t_tuple_res

# Generated at 2022-06-23 17:30:05.717184
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [1, 2, 3]
    b = ["1", "2", "3"]
    c = [1, 2, 3]
    d = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    f = [{1: "1", 2: "2"}, {3: "3", 4: "4"}, {5: "5", 6: "6"}]
    
    def fun(a, b, c, d, f):
        assert a == int(b), "a != b"
        assert a == c, "a != c"
        assert d[a-1][a-1] == a, "d[a-1][a-1] != a"
        assert f[a-1][a] == b, "f[a-1][a] != b"
       

# Generated at 2022-06-23 17:30:12.066743
# Unit test for function map_structure
def test_map_structure():
    # test with list
    test_list = [[1, 2], [3, 4]]
    assert map_structure(lambda x: x * 2, test_list) == [[2, 4], [6, 8]]
    # test with tuple
    test_tuple = ([1, 2], [3, 4])
    assert map_structure(lambda x: x * 2, test_tuple) == ([2, 4], [6, 8])
    # test with dict
    test_dict = {1: 2, 3: 4}
    assert map_structure(lambda x: x * 2, test_dict) == {1: 4, 3: 8}
    # test with set
    test_set = (1, 2, 3, 4)

# Generated at 2022-06-23 17:30:17.194568
# Unit test for function no_map_instance
def test_no_map_instance():
    class Foo:
        def __init__(self, x):
            self.x = x

    @no_type_check
    def obj_call(obj):
        return obj.x

    foo = Foo(1)
    foo_singleton = no_map_instance(foo)
    map_structure(obj_call, [foo])



# Generated at 2022-06-23 17:30:26.905590
# Unit test for function map_structure
def test_map_structure():
    import numpy as np
    from collections import OrderedDict

    dict1 = {'a': np.array(3), 'b': np.array(8)}
    dict2 = {'a': np.array(2), 'b': np.array(12)}
    dict3 = OrderedDict()
    dict3['a'] = np.array(2)
    dict3['b'] = np.array(12)

    exp_array = np.array([-1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    exp_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]

# Generated at 2022-06-23 17:30:31.381912
# Unit test for function reverse_map
def test_reverse_map():
    assert type(reverse_map({})) == list
    assert reverse_map({'example': 0, 'test': 1}) == ['example', 'test']
    assert reverse_map({'example': 1,'test': 0}) == ['test', 'example']
    # Assert that reverse_map fails to run when input is non_dict
    try:
        reverse_map(1)
    except:
        assert True


# Generated at 2022-06-23 17:30:41.921556
# Unit test for function map_structure
def test_map_structure():
    list = [1, [2, 3], (4, 5)]
    list_sum = list[0] + sum(list[1]) + sum(list[2])

    def adder(x, y):
        return x + y

    list_sum_adder = list[0] + adder(list[1][0], list[1][1] + adder(list[2][0], list[2][1]))
    assert list_sum == 13
    assert list_sum_adder == 13

    list_sum = map_structure(lambda x: x, list)
    list_sum_adder = map_structure(lambda x, y: x + y, list)
    assert list_sum == 13
    assert list_sum_adder == 13


test_map_structure()

# Generated at 2022-06-23 17:30:45.340863
# Unit test for function no_map_instance
def test_no_map_instance():
    instance = no_map_instance([None, None])
    assert instance.__class__.__name__ == "_no_maplist"
    assert hasattr(instance, "__NO_MAP_INSTANCE_ATTR__")

# Generated at 2022-06-23 17:30:49.852620
# Unit test for function no_map_instance
def test_no_map_instance():
    a = torch.tensor(1)
    b = torch.tensor(2)
    c = torch.tensor(3)
    obj1 = no_map_instance([a,b,c])
    assert obj1 == [a,b,c]
    assert map_structure(lambda x: x+1, obj1)== obj1


# Generated at 2022-06-23 17:31:02.915300
# Unit test for function map_structure_zip
def test_map_structure_zip():
    from copy import deepcopy
    from collections import defaultdict
    import torch
    import numpy as np
    from .config import config

    # Base case: list
    def f(x): return x+1
    l = [1, 2]
    t = map_structure_zip(f, [l, l])
    assert(list(t) == [2, 3])

    # Base case: torch tensor
    def f(x): return x+1
    t_l = deepcopy(l)
    t_l = torch.tensor(t_l)
    t_t = map_structure_zip(f, [t_l, t_l])
    assert(t_t.tolist() == [2, 3])
    assert(isinstance(t_t, torch.Tensor))

    # Base case

# Generated at 2022-06-23 17:31:11.719745
# Unit test for function reverse_map
def test_reverse_map():
    test_dict = {
        'a': 0,
        'aa': 1,
        'b': 2,
        'bbb': 3,
        'ccc': 4,
        'd': 5,
        'ddd': 6,
        'ee': 7,
        'e': 8,
    }
    test_result = [
        'a',
        'aa',
        'b',
        'bbb',
        'ccc',
        'd',
        'ddd',
        'ee',
        'e'
    ]
    assert reverse_map(test_dict) == test_result

# Generated at 2022-06-23 17:31:22.857599
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class MyList(list):
        pass
    # case 1: if the object is not subclassed from built-in container types
    obj_1 = MyList([0,1,2])
    res_1 = map_structure(lambda x: x + 1, obj_1)
    assert res_1 == [1, 2, 3]
    # case 2: if the object is subclassed from built-in container types
    obj_2 = MyList([0,1,2])
    register_no_map_class(MyList)
    res_2 = map_structure(lambda x: x + 1, obj_2)
    assert res_2 == MyList([0,1,2]) + 1


# Generated at 2022-06-23 17:31:31.088868
# Unit test for function map_structure_zip
def test_map_structure_zip():
    nested_list = [[1, 2], [3, 4], [5, 6, 7]]
    assert map_structure_zip(sum, nested_list) == [[2, 4], [6, 8], [10, 12, 14]]
    nested_tuple = ((1, 2), (3, 4), (5, 6, 7))
    assert map_structure_zip(sum, nested_tuple) == ((2, 4), (6, 8), (10, 12, 14))
    nested_dict = {'a': {'b': 1, 'c': 2}, 'b': {'b': 1, 'c': 2}, 'c': {'b': 1, 'c': 2, 'd': 3}}
    # assert map_structure_zip(sum, nested_dict) == {'a': {'b': 3, 'c

# Generated at 2022-06-23 17:31:40.439335
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # TODO: find a way to test

    def add(x: int, y: int) -> int:
        return x + y

    a = [[1, 5, 3], [2, 1, 4]]
    b = [[3, 1, 1], [6, 2, 1]]
    assert isinstance(a, list)
    c = map_structure_zip(add, [a, b])
    assert isinstance(c, list)
    assert isinstance(c[0], list)
    assert isinstance(c[1], list)
    assert c == [[4, 6, 4], [8, 3, 5]]
    print(c)

# Generated at 2022-06-23 17:31:43.619317
# Unit test for function map_structure_zip
def test_map_structure_zip():
    assert map_structure_zip(sorted, [[1, 2], [3, 1]]) == [[1, 2], [1, 3]]

# Generated at 2022-06-23 17:31:55.358934
# Unit test for function no_map_instance
def test_no_map_instance():
    assert (no_map_instance([1, 2, 3]) == [1, 2, 3])
    assert (no_map_instance([1, 2, 3]) != [1, 2, 4])
    assert (no_map_instance({1, 2, 3}) == {1, 2, 3})
    assert (no_map_instance({1, 2, 3}) != {1, 2, 4})
    assert (no_map_instance((1, 2, 3)) == (1, 2, 3))
    assert (no_map_instance((1, 2, 3)) != (1, 2, 4))
    assert (no_map_instance({5: 1, 6: 2, 7: 3}) == {5: 1, 6: 2, 7: 3})

# Generated at 2022-06-23 17:32:07.530323
# Unit test for function reverse_map

# Generated at 2022-06-23 17:32:14.559017
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import torch
    register_no_map_class(torch.Size)
    is_no_map = no_map_instance(torch.Size((1,2,3)))
    assert is_no_map.__class__ in _NO_MAP_TYPES
    assert hasattr(is_no_map, _NO_MAP_INSTANCE_ATTR)

# Generated at 2022-06-23 17:32:19.223553
# Unit test for function register_no_map_class
def test_register_no_map_class():
    register_no_map_class(torch.Size)
    x = torch.ones(3,3)
    y = map_structure(lambda a: a.unsqueeze(0), torch.Size(x.size()))
    assert y == torch.Size((1,3,3))

# Generated at 2022-06-23 17:32:21.085834
# Unit test for function no_map_instance
def test_no_map_instance():
    for Type in [tuple, list, dict, set, frozenset]:
        print('current type: ', Type)                                                                                                             
        x = no_map_instance(Type({1,2,3,4}))
        assert(x=={1,2,3,4})

# Generated at 2022-06-23 17:32:24.169001
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class NoMapType(list):
        def __init__(self, value):
            self.value = value

    NoMapType.register_no_map_class()
    assert NoMapType in _NO_MAP_TYPES



# Generated at 2022-06-23 17:32:36.014246
# Unit test for function map_structure
def test_map_structure():
    x = 3
    assert map_structure(lambda x: x + 1, x) == x + 1
    x = [1, 2, 3]
    assert map_structure(lambda x: x + 1, x) == [x + 1 for x in x]
    x = [1, [2, [3]]]
    assert map_structure(lambda x: x + 1, x) == [x + 1 for x in x]
    x = [1, [2, [3]], {4, 5}]
    assert map_structure(lambda x: x + 1, x) == [x + 1 for x in x]
    x = (1, [2, [3]], {4, 5})
    assert map_structure(lambda x: x + 1, x) == tuple(x + 1 for x in x)


# Generated at 2022-06-23 17:32:47.459890
# Unit test for function register_no_map_class
def test_register_no_map_class():
    # a class
    class A:
        def __init__(self, x, y):
            self.x = x
            self.y = y

    # a container
    container = {
        1: A("a","b"),
        2: A("c","d")
    }

    # register the class A
    register_no_map_class(A)

    # map function
    def fn(a):
        return a.x

    # will throw error, because the function cannot access attribute x of a
    # TypeError: 'A' object has no attribute 'x'
    # map_structure(fn, container)

    # pass
    register_no_map_class(A)
    register_no_map_class(dict)
    register_no_map_class(tuple)
    register_no_map_

# Generated at 2022-06-23 17:32:57.917712
# Unit test for function no_map_instance

# Generated at 2022-06-23 17:33:02.350370
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class A:
        def __init__(self, x):
            self.x = x
    try:
        map_structure(lambda x: x.x, [A(1)])
    except AttributeError:
        pass
    else:
        assert False, "Failed to check if the map has attribute"
    register_no_map_class(A)
    map_structure(lambda x: x.x, [A(1)])


# Generated at 2022-06-23 17:33:04.554728
# Unit test for function reverse_map
def test_reverse_map():
    assert reverse_map({'a': 0, 'b': 1, 'c': 2}) == ['a', 'b', 'c']


# Generated at 2022-06-23 17:33:14.382865
# Unit test for function map_structure
def test_map_structure():
    # test map nested list
    x = [[1, 2], [3, 4]]
    y = map_structure(lambda x: x+1, x)
    assert y == [[2, 3], [4, 5]]

    # test map nested tuple
    x = (1, (2, (3, (4,))))
    y = map_structure(lambda x: x+1, x)
    assert y == (2, (3, (4, (5,))))

    # test map nested dict
    x = {"a":{"b":{"c":{"d":1}}}}
    y = map_structure(lambda x: x+1, x)
    assert y == {"a":{"b":{"c":{"d":2}}}}

    # test map nested set
    x = {1, (2, (3, (4,)))}
    y

# Generated at 2022-06-23 17:33:20.554509
# Unit test for function map_structure
def test_map_structure():
    def test_list(list_):
        if len(list_) == 1:
            return list_[0]
        else:
            return list_[0] + list_[-1]

    list_a = ['a', 'b', 'c']
    list_b = ['1', '2', '3']
    list_c = ['1', ['2', '3'], '4']
    list_d = ['1', '2', '3', [[1, 2], [3, 4]]]

    assert map_structure(test_list, list_a) == 'ca'
    assert map_structure(test_list, list_b) == '31'
    assert map_structure(test_list, list_c) == ['1', '23', '4']

# Generated at 2022-06-23 17:33:31.359313
# Unit test for function map_structure
def test_map_structure():
    import numpy as np

    class TestObj(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    # Test function fn
    def fn(obj):
        return obj

    # Define a collection
    d = {'a': TestObj(1, 2), 'b': {'aa': TestObj(3, 4), 'bb': TestObj(5, 6)}}

    # Test recursive call
    result = {'a': TestObj(1, 2), 'b': {'aa': TestObj(3, 4), 'bb': TestObj(5, 6)}}
    assert map_structure(fn, d) == result


# Generated at 2022-06-23 17:33:41.887846
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # Test case 1
    a = 1
    b = 2
    c = 3
    d = 4
    res1 = map_structure_zip(lambda x,y,z:x+y+z, [a,b], [c,d])
    assert res1 == 6
    # Test case 2
    A = [a, b]
    B = [c, d]
    res2 = map_structure_zip(lambda x,y,z:x+y+z, A, B)
    assert res2 == [6, 10]
    # Test case 3
    C = [[a, b], [c, d]]
    res3 = map_structure_zip(lambda x,y,z:x+y+z, A, B, C)
    assert res3 == [[6, 10], [12, 8]]


# Generated at 2022-06-23 17:33:50.962666
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import torch
    import collections

    class SomeList(collections.Sequence):
        def __init__(self, *args):
            self.contents = list(args)

        def __len__(self):
            return len(self.contents)

        def __getitem__(self, idx):
            return self.contents[idx]

    register_no_map_class(SomeList)
    register_no_map_class(torch.Size)

    struct = [[[SomeList(1, 2, 3), torch.Size([1, 2, 3])]], [[SomeList(4, 5, 6), torch.Size([4, 5, 6])]]]
    mapped_struct = map_structure(lambda x: x, struct)
    assert(struct == mapped_struct)

# Generated at 2022-06-23 17:33:59.253531
# Unit test for function reverse_map

# Generated at 2022-06-23 17:34:04.479699
# Unit test for function register_no_map_class

# Generated at 2022-06-23 17:34:14.707812
# Unit test for function reverse_map

# Generated at 2022-06-23 17:34:16.954899
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import torch
    register_no_map_class(torch.Size)

    assert torch.Size in _NO_MAP_TYPES



# Generated at 2022-06-23 17:34:20.903315
# Unit test for function reverse_map
def test_reverse_map():
    words = ['a', 'aardvark', 'abandon', 'abc', 'abc', 'abc', 'abc']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    assert words == id_to_word


if __name__ == '__main__':
    test_reverse_map()

# Generated at 2022-06-23 17:34:27.299924
# Unit test for function no_map_instance
def test_no_map_instance():
    class T:
        def __init__(self, n):
            self.n = n

    t1 = no_map_instance(T(1))
    t2 = no_map_instance(T(1))
    assert t1 == t2
    assert t1 == T(1)
    assert t2 == T(1)

# Generated at 2022-06-23 17:34:30.710207
# Unit test for function reverse_map
def test_reverse_map():
    d = {'a': 1, 'b': 3, 'c': 2}
    print(reverse_map(d))


if __name__ == '__main__':
    test_reverse_map()

# Generated at 2022-06-23 17:34:36.764943
# Unit test for function no_map_instance
def test_no_map_instance():
    x = no_map_instance([1,2,3])
    assert x == [1,2,3]
    assert type(x) == list
    y = no_map_instance([1, 2, 3])
    assert y == x
    assert type(y) == list

    z = no_map_instance([1,2,3])
    assert z != [1,2,3]

# Generated at 2022-06-23 17:34:40.378122
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def a_function(a, b):
        return a + b
    objs = [{'a': 1, 'b': 2}, {'a': 2, 'b': 3}]
    print(map_structure_zip(a_function, objs))  # {'a': 3, 'b': 5}


if __name__ == "__main__":
    test_map_structure_zip()

# Generated at 2022-06-23 17:34:46.653178
# Unit test for function no_map_instance
def test_no_map_instance():
    d = {'a': 1, 'b': 2}
    d_no_map = no_map_instance(d)
    assert hasattr(d_no_map, '--no-map--')
    assert set(d_no_map.keys()) == set(d.keys())


# Generated at 2022-06-23 17:34:55.459385
# Unit test for function reverse_map
def test_reverse_map():
    def testcase(x_list: List[float], num_class: int) -> List[int]:
        d = {}
        for idx, i in enumerate(x_list):
            if i not in d: d[i] = idx

        return reverse_map(d)

    assert(testcase([-1, 2, 3, 3, 4], 2) == [0, 1, 2, 2, 3])
    print("Test OK")



# Generated at 2022-06-23 17:34:57.687711
# Unit test for function reverse_map
def test_reverse_map():
    d = { "a": 1, "b": 2, "c": 3 }
    assert reverse_map(d) == list(d.keys())


# Generated at 2022-06-23 17:35:03.362335
# Unit test for function map_structure
def test_map_structure():
    class TestList(list):
        pass

    class TestTuple(tuple):
        pass

    class TestDict(dict):
        pass

    class TestSet(set):
        pass

    def found_item(n):
        def f(obj):
            class FoundItem(Exception):
                pass
            try:
                map_structure(lambda x: (raise_from(FoundItem(), None) if x == n else None), obj)
            except FoundItem:
                return True
            else:
                return False
        return f
    def found_list(n):
        def f(obj):
            return isinstance(obj, list) and n in obj
        return f

    for _type in [list, set, dict, tuple, TestList, TestSet, TestDict, TestTuple]:
        register_no_map_

# Generated at 2022-06-23 17:35:06.992379
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class CustomList(list):
        pass

    my_list = CustomList([1,2,3,4])
    register_no_map_class(CustomList)
    
    def f(x):
        return x + 1

    my_list_1 = map_structure(f, my_list)

    assert my_list_1 == [2, 3, 4, 5]

# Generated at 2022-06-23 17:35:18.749620
# Unit test for function reverse_map

# Generated at 2022-06-23 17:35:23.756757
# Unit test for function map_structure_zip
def test_map_structure_zip():
    nested_list = map_structure_zip(lambda x:x, [[1,2,3], [4,5,6]])
    print(nested_list)
    assert nested_list == [[1, 4], [2, 5], [3, 6]]

# Generated at 2022-06-23 17:35:30.059298
# Unit test for function reverse_map
def test_reverse_map():
    items = ['a', 'b', 'c']
    id_to_item = {0: 'a', 1: 'b', 2: 'c'}
    item_to_id = {'a': 0, 'b': 1, 'c': 2}
    assert items == reverse_map(id_to_item)
    assert id_to_item == {idx: word for word, idx in enumerate(reverse_map(item_to_id))}
    print(reverse_map.cache_info())

if __name__ == '__main__':
    test_reverse_map()

# Generated at 2022-06-23 17:35:37.020464
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def myfunc(x,y,z):
        return (x,y,z)

    input1 = dict(id=23, name="Alice")
    input2 = dict(id=23, name="Bob")
    result = map_structure_zip(myfunc, [input1, input2])
    assert result == dict(id=(23, 23), name=("Alice", "Bob"))

if __name__ == '__main__':
    test_map_structure_zip()

# Generated at 2022-06-23 17:35:41.499812
# Unit test for function register_no_map_class
def test_register_no_map_class():
    @register_no_map_class
    class new_class(object):
        def __init__(self, num):
            self.x = num / 2
    test_obj = new_class(5)
    assert(map_structure(lambda x: x.x * 2, test_obj) == 5)

# Generated at 2022-06-23 17:35:51.564460
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([1,2])
    assert (a == [1,2]).all()
    b = no_map_instance([3,4])
    map_structure(lambda x: x + 1, [a, b]) 
    assert (a == [2, 3]).all()
    assert (b == [4, 5]).all()
    c = no_map_instance(torch.tensor([5, 6]))
    map_structure(lambda x: x + 1, [a, b, c])
    assert (a == [3, 4]).all()
    assert (b == [5, 6]).all()
    assert (c == [6, 7]).all()

# Generated at 2022-06-23 17:36:05.050657
# Unit test for function no_map_instance
def test_no_map_instance():
    import torch
    import numpy as np
    from utils.collections_utils import reverse_map, register_no_map_class, no_map_instance, map_structure, map_structure_zip

    register_no_map_class(list)

    some_list = [1, 2, 3]
    some_list_2 = no_map_instance(some_list)
    print(some_list)
    print(some_list_2)

    other_list = [4, 5, 6]

    nested_bit = [some_list, some_list_2, other_list]
    print(nested_bit)
    print(map_structure(lambda x: x*2, nested_bit))
    print(map_structure_zip(lambda x,y: x+y, nested_bit))



# Generated at 2022-06-23 17:36:09.393108
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([1, 2, 3])
    b = no_map_instance(a)
    assert a == b
    assert map_structure(lambda x: x + 1, [a])[0] == [1, 2, 3]

# Generated at 2022-06-23 17:36:16.205652
# Unit test for function map_structure_zip
def test_map_structure_zip():
    sents = [['a', 'b', 'c'], ['b', 'a', 'd']]
    chars = [['x', 'y', 'z'], ['y', 'x', 'z']]
    res = map_structure_zip(lambda sent, char: list(zip(sent, char)), sents)
    print(res)
    # res = list(zip(sents[0], chars[0]))
    # print(res)

test_map_structure_zip()

# Generated at 2022-06-23 17:36:28.855679
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import pytest
    # The function is tested using one definition of the function fn and three tuples of collections, each with
    # identical structures. The function fn is tested for input dims of (3), (3,4), (3,4,5), (3,4,5,6), (3,4,5,6,7),
    # (3,4,5,6,7,8), (3,4,5,6,7,8,9), (3,4,5,6,7,8,9,10), (3,4,5,6,7,8,9,10,11), (3,4,5,6,7,8,9,10,11,12).
    # The function fn is used to test that the type of the output is the same as the type of the input.
    # The test is made

# Generated at 2022-06-23 17:36:35.411741
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import collections
    register_no_map_class(collections.Counter)
    register_no_map_class(collections.defaultdict)
    # check existence
    for t in (collections.Counter, collections.defaultdict):
        assert t in _NO_MAP_TYPES
    # check absence
    for t in (dict, collections.ChainMap, collections.OrderedDict):
        assert t not in _NO_MAP_TYPES


# Generated at 2022-06-23 17:36:44.382802
# Unit test for function no_map_instance
def test_no_map_instance():
    """
    >>> import torch
    >>> tensor = torch.rand(4, 4)
    >>> nested_tensor = [[tensor, tensor], [tensor, tensor]]
    >>> mapped_nested_tensor = map_structure(lambda t: t + 0.5, nested_tensor)
    >>> mapped_nested_tensor == nested_tensor
    False

    >>> no_mapped_nested_tensor = map_structure(lambda t: t + 0.5, no_map_instance(nested_tensor))
    >>> no_mapped_nested_tensor == nested_tensor
    True
    """

# Generated at 2022-06-23 17:36:52.010170
# Unit test for function reverse_map
def test_reverse_map():
    word_to_id = {'a': 0, 'abandon': 1, 'abandoned': 2, 'about': 3, 'above': 4}
    id_to_word = reverse_map(word_to_id)
    assert id_to_word[0] == 'a'
    assert id_to_word[1] == 'abandon'
    assert id_to_word[2] == 'abandoned'
    assert id_to_word[3] == 'about'
    assert id_to_word[4] == 'above'


# Generated at 2022-06-23 17:36:56.351065
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class Test:
        pass
    register_no_map_class(Test)
    assert Test in _NO_MAP_TYPES
    assert Test not in _NO_MAP_TYPES


# Generated at 2022-06-23 17:37:01.163024
# Unit test for function reverse_map
def test_reverse_map():
    d = {'a': 0, 'b': 1, 'c': 2}
    assert reverse_map(d) == ['a', 'b', 'c']
    assert reverse_map({'a': 1, 'b':0}) == ['b', 'a']
    assert reverse_map({}) == []


# Generated at 2022-06-23 17:37:09.289432
# Unit test for function reverse_map
def test_reverse_map():
    item_to_id = {
        "a": 0,
        "b": 1,
        "c": 2,
        "d": 3,
        "e": 4,
        "f": 5
    }
    expected = ["a", "b", "c", "d", "e", "f"]
    assert reverse_map(item_to_id) == expected


# Generated at 2022-06-23 17:37:14.622595
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import numpy as np
    from easydict import EasyDict
    from collections import namedtuple

    def test_map_structure_zip_fn(x: str, y: int, z: float, 
      e1: EasyDict, e2: EasyDict, n: namedtuple):
      return [x, y, z, e1, e2, n]

    d1 = [{1: 'a'}, {2: 'b'}, {3: 'c'}]
    d2 = [{1: 0}, {2: 1}, {3: 2}]
    d3 = [{1: 0.0}, {2: 0.1}, {3: 0.2}]

    # test different kinds of objects

# Generated at 2022-06-23 17:37:26.021923
# Unit test for function reverse_map