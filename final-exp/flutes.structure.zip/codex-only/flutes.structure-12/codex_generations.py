

# Generated at 2022-06-23 17:27:24.707082
# Unit test for function reverse_map
def test_reverse_map():
    d1 = {"a": 1, "b": 2, "c": 3, "d": 4}
    d2 = {1: 1, 2: 2, 3: 3, 4: 4}
    d3 = {1: "a", 2: "b", 3: "c", 4: "d"}
    assert reverse_map(d1) == ["a", "b", "c", "d"]
    assert reverse_map(d2) == [1, 2, 3, 4]
    assert reverse_map(d3) == ["a", "b", "c", "d"]


# Generated at 2022-06-23 17:27:34.133882
# Unit test for function map_structure_zip
def test_map_structure_zip():
    D = namedtuple('D', ['a', 'b'])
    def identity(a):
        return a
    def f(a, b):
        return {a: b}
    def test(a, b):
        return map_structure_zip(identity, [a, b]) == [a, b]
    assert not test(1, D(1,'a'))
    assert test(1, 2)
    assert test('a', 'b')
    assert test([1], [2])
    assert test((1,), (2,))
    assert test({1:1}, {2:2})
    assert test(D(1,'a'), D(2,'b'))
    assert test(D(1,'a'), D('2','b'))

# Generated at 2022-06-23 17:27:37.177938
# Unit test for function register_no_map_class
def test_register_no_map_class():
    t1 = register_no_map_class(list)
    t2 = register_no_map_class(dict)
    assert t1 is None
    assert t2 is None


# Generated at 2022-06-23 17:27:49.189469
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def func1(a, b, c):
        return (a, b, c)

    def func2(a, b, c, d):
        return (a, b, c, d)

    x = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    y = [[10, 20, 30]]
    z = [[100, 200, 300], [400, 500, 600]]
    w = [[1000, 2000, 3000], [4000, 5000, 6000], [7000, 8000, 9000], [1000000, 2000000, 3000000]]
    a = map_structure_zip(func1, x)
    assert (a == x)
    a = map_structure_zip(func2, x)
    assert (a == (1, 2, 3))
    a = map_structure_

# Generated at 2022-06-23 17:27:58.630185
# Unit test for function map_structure_zip
def test_map_structure_zip():
    #x = [{'a': {'b': 1}}, {'a': {'c': 2}}]
    x = [{'a': [{'b': 1}]}, {'a': [{'c': 2}]}]
    y = map_structure_zip(lambda *args: {**args[0], **args[1]}, x)
    print(y)
    x = [{'a': [{'b': 1, 'c': 2}]}, {'a': [{'b': 1, 'c': 3}]}]
    y = map_structure_zip(lambda *args: {**args[0], **args[1]}, x)
    print(y)

# Generated at 2022-06-23 17:28:05.285499
# Unit test for function reverse_map

# Generated at 2022-06-23 17:28:15.208970
# Unit test for function map_structure
def test_map_structure():
    def add_100(x: int) -> int:
        return x + 100

    l1 = [1, 2]
    l2 = [2, 3]
    l3 = [3, 4]
    l_all = [l1, l2, l3]

    d1 = {'a': 1, 'b': 2}
    d2 = {'a': 2, 'b': 3}
    d3 = {'a': 3, 'b': 4}
    d_all = [d1, d2, d3]

    t1 = (1, 2)
    t2 = (2, 3)
    t3 = (3, 4)
    t_all = [t1, t2, t3]

    s1 = {1, 2}
    s2 = {2, 3}
    s3

# Generated at 2022-06-23 17:28:20.112098
# Unit test for function no_map_instance
def test_no_map_instance():
    x = [1, 2, no_map_instance([1, 1, 2]), 3]
    y = [1, 1, 2, 3]
    assert all(map(lambda a: a[0] == a[1], zip(x, y)))
    assert all(map(lambda a: a[0] == a[1], zip(y, x)))

# Generated at 2022-06-23 17:28:30.267036
# Unit test for function reverse_map

# Generated at 2022-06-23 17:28:34.925456
# Unit test for function reverse_map
def test_reverse_map():
    test_dict = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    test_inverse_dict = reverse_map(test_dict)
    assert ['b', 'd', 'a', 'c', 'e'] == test_inverse_dict


# Generated at 2022-06-23 17:28:45.063235
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def inc(a,b,c):
        return a+1,b+1,c+1

    a = [1, 2, 3]
    b = [4, 5, 6]
    A = {'tensor': a, 'dim': 1, 'pos': 3}
    B = {'tensor': b, 'dim': 2, 'pos': 4}
    ap, bp, cp = map_structure_zip(inc, (a, b))
    assert type(ap) == type(bp) == type(cp) == list

# Generated at 2022-06-23 17:28:56.537596
# Unit test for function map_structure_zip
def test_map_structure_zip():
    from fastNLP.core.utils import map_structure_zip
    from fastNLP.core.field import Field
    from fastNLP.core.const import Const
    from fastNLP.core.processor.embedding import Embedding
    import torch

    def test_fn(*ts: tuple) -> tuple:
        return tuple(sum(t) for t in zip(*ts))

    a = Field(padding_value=Const.PAD)
    a.add_seq([1, 2, 3])
    b = Field(padding_value=Const.PAD)
    b.add_seq([1, 2, 3, 4, 5])
    c = Field()

    result = map_structure_zip(
        test_fn,
        (a, b, c),
    )
    assert result.seq_len == 5


# Generated at 2022-06-23 17:29:08.975214
# Unit test for function map_structure
def test_map_structure():
    assert all(map_structure(len, "ab") == [1, 1])
    assert all(map_structure(len, ["ab", "c"]) == [[1, 1], [1]])

    assert all(map_structure(len, {"a": 1, "bb": 2}) == {1: 1, 2: 2})
    assert all(map_structure(len, [{"a": 1, "bb": 2}, {"c": 3, "dd": 4}]) == [{1: 1, 2: 2}, {1: 3, 2: 4}])

    assert all(map_structure_zip(len, ["ab", ["c", "d"]]) == [1, 2])
    assert all(map_structure_zip(len, ["ab", ["c", "d", "e"]]) == [1, 2])

# Generated at 2022-06-23 17:29:16.520756
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class MyList(list):
        pass
    register_no_map_class(MyList)
    assert MyList not in _NO_MAP_TYPES
    assert map([MyList()], len) == [1]
    assert map([[MyList()]], len) == [1]
    assert map([[[MyList()]]], len) == [1]



# Generated at 2022-06-23 17:29:21.500396
# Unit test for function map_structure
def test_map_structure():
    print('test_map_structure starting ...')
    print('Initialize test structure')
    fruit1 = {'name': 'apple', 'color': 'red', 'bitter': False}
    fruit1['subfruit'] = [fruit1, fruit1]
    print(fruit1)
    # We don't have a test just yet.
    print('Done')


# Generated at 2022-06-23 17:29:28.238370
# Unit test for function reverse_map
def test_reverse_map():
    """
    description:
    :return:
    """
    print("Unit test for function reverse_map")
    a = dict(zip(["a", "b", "c"], [1, 2, 3]))
    print("dict a:", a)
    b = reverse_map(a)
    print("reverse dict a:", b)
    print("\n")


# Generated at 2022-06-23 17:29:33.532541
# Unit test for function no_map_instance
def test_no_map_instance():
    @register_no_map_class
    class MyTensor(torch.Tensor):
        pass

    ts = MyTensor([1, 2, 3])
    my_tensor = no_map_instance(ts)
    assert (my_tensor == ts)
    assert my_tensor is not ts
    assert hasattr(my_tensor, _NO_MAP_INSTANCE_ATTR)



# Generated at 2022-06-23 17:29:41.986869
# Unit test for function map_structure_zip
def test_map_structure_zip():
    list_exam = [[1,2,3],[[1,2],3,4]]
    tuple_exam = ((1,2), [[1,2,3],(1,2,3)])
    dict_exam = {'a':[1,2,3], 'b':2, 'c':(1,2,3)}
    mixed_exam = ([1,2,3], [1,2,3], [1,2,3])
    def sum(x):
        return x[0]+x[1]+x[2]
    list_result = map_structure_zip(sum, list_exam)
    tuple_result = map_structure_zip(sum, tuple_exam)
    dict_result = map_structure_zip(sum, dict_exam)
    mixed_result = map

# Generated at 2022-06-23 17:29:45.626113
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class MyList(list):
        def __init__(self):
            super().__init__([1, 2, 3])

    register_no_map_class(MyList)

    map = {
        "type": "list"  # type for the original obj
    }

    def fn(obj: T) -> T:
        map["type"] = type(obj).__name__
        return obj

    my_list = MyList()
    map_structure(fn, my_list)
    assert map["type"] == "MyList"


# Generated at 2022-06-23 17:29:54.091694
# Unit test for function map_structure_zip
def test_map_structure_zip():
    list_a = [[1, 2, 3], [[1, 2], [3, 4]], [3, 2, 1]]
    list_b = [[4, 3, 2], [[4, 3], [2, 1]], [1, 2, 3]]
    list_c = [[1, 2, 3], [[4, 3], [1, 2]], [3, 2, 1]]
    list_d = [[4, 3, 2], [[1, 2], [3, 4]], [1, 2, 3]]
    list_e = [[5, 5, 5], [[5, 5], [5, 5]], [5, 5, 5]]

# Generated at 2022-06-23 17:30:04.346813
# Unit test for function reverse_map
def test_reverse_map():
    words = ['a', 'aardvark', 'abandon', 'abandoned', 'ability', 'able', 'aboriginal', 'abortion', 'about',
             'abroad', 'abrupt', 'absence', 'absent', 'absolute', 'absolutely', 'absorb', 'abuse', 'academic',
             'academy', 'accelerate']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    assert (words == id_to_word)


# Generated at 2022-06-23 17:30:10.167843
# Unit test for function map_structure
def test_map_structure():
    class Foo(tuple):
        pass

    obj_test = {'a': [1, {'x': 'X', 'y': 12}, 3],
                'b': Foo((4, 5)),
                'c': {'d': {'e': 6}}}

    def test_func(input_):
        if isinstance(input_, dict):
            return {k: test_func(v) for k, v in input_.items()}
        elif isinstance(input_, list):
            return [test_func(v) for v in input_]
        else:
            return input_ + 3

    result = {'a': [4, {'x': 'X', 'y': 15}, 6],
              'b': (7, 8),
              'c': {'d': {'e': 9}}}
    assert map

# Generated at 2022-06-23 17:30:20.740294
# Unit test for function register_no_map_class
def test_register_no_map_class():
    # form a custom class
    class element():
        def __init__(self, x, y, z):
            self.x = x
            self.y = y
            self.z = z
        def __eq__(self, other):
            return (self.x == other.x) and (self.y == other.y) and (self.z == other.z)

    # create a list of two element class
    lst = [element(1, 10, 100), element(2, 20, 200)]
    # register class element with function register_no_map_class
    register_no_map_class(element)
    # register class list
    register_no_map_class(list)
    # apply function map_structure to a list, but list is not mapped as it is not a built-in class
    # then l

# Generated at 2022-06-23 17:30:22.501147
# Unit test for function reverse_map
def test_reverse_map():
    assert reverse_map({'a': 3, 'b': 1, 'c': 2}) == ['b', 'c', 'a']

# Generated at 2022-06-23 17:30:31.401986
# Unit test for function map_structure
def test_map_structure():
    assert map_structure(lambda x: x, [[1, 2]]) == [[1, 2]]
    assert map_structure(lambda x: x, [[1, 2], [3, 4]]) == [[1, 2], [3, 4]]
    assert map_structure(lambda x: x, [(1, 2), [3, 4]]) == [(1, 2), [3, 4]]

    def square(x):
        return x * x

    assert map_structure(square, [[1, 2], [3, 4]]) == [[1, 4], [9, 16]]
    assert map_structure(square, [{'a': 1, 'b': 2}, {'a': 3, 'c': 4}]) == [{'a': 1, 'b': 4}, {'a': 9, 'c': 16}]


# Generated at 2022-06-23 17:30:43.325828
# Unit test for function map_structure
def test_map_structure():
    d1 = [{'a': 2}, {'b': 3}]
    d2 = [[1, 2], [1, 3]]
    d3 = set([1, 2, 3])
    d4 = [{'a': 2}, {'b': 3}]

    f = lambda x: x['a'] if 'a' in x else x['b']
    res = map_structure(f, d1)
    print("map_structure(f, d1):", res)

    g = lambda x, y: x + y
    res = map_structure_zip(g, [d1, d2])
    print("map_structure_zip(g, [d1, d2]):", res)

    h = lambda x: x ** 2
    res = map_structure(h, d3)


# Generated at 2022-06-23 17:30:55.389598
# Unit test for function map_structure
def test_map_structure():
    from collections import namedtuple

    TestType = namedtuple('TestType', ['a', 'b'])

    def test_fn(a, b):
        if isinstance(a, int):
            return (2 * a, 2 * b)
        return (a, b)

    obj = TestType(1, 2)
    mapped = map_structure(test_fn, obj)
    assert(mapped == TestType(2, 4))
    # Test list structure
    obj = [obj, TestType(3, 4)]
    mapped = map_structure(test_fn, obj)
    assert(mapped == [TestType(2, 4), TestType(6, 8)])
    # Test dict structure
    obj = {'a': obj}
    mapped = map_structure(test_fn, obj)

# Generated at 2022-06-23 17:30:57.857037
# Unit test for function no_map_instance
def test_no_map_instance():
    assert str(list) == str(no_map_instance(list))
    assert str(dict) == str(no_map_instance(dict))

# Generated at 2022-06-23 17:31:05.513313
# Unit test for function no_map_instance
def test_no_map_instance():
    class ObjectFake:
        pass

    class Object:
        pass

    o = ObjectFake()
    o_fake = Object()

    assert no_map_instance(o) is not o
    assert no_map_instance(o) == o
    assert no_map_instance(o_fake) == o_fake

    assert no_map_instance(o) is not no_map_instance(o)
    assert no_map_instance(o_fake) is no_map_instance(o_fake)

if __name__ == '__main__':
    test_no_map_instance()

# Generated at 2022-06-23 17:31:14.190725
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def f(a, b, c, d):
        return a * b * c * d

    def g(a, b):
        return a * a * b * b

    a = [1, 2]
    b = [2, 3]
    c = [[1, 2], [3, 4]]
    d = torch.tensor([1, 2])
    e = torch.tensor([2, 3])

    # with sequence and numpy
    t = map_structure_zip(f, [a, b, c, d])
    assert t == [2, 12]

    # with tensor
    t = map_structure_zip(f, [a, b, d, e])
    assert torch.all(t == torch.tensor([2, 12]))

    # with tensor and function without one argument
   

# Generated at 2022-06-23 17:31:23.252861
# Unit test for function map_structure_zip
def test_map_structure_zip():
    from abc import ABC, abstractmethod
    from collections import namedtuple

    class TestClass(ABC):
        def __init__(self, value):
            self.value = value

        @abstractmethod
        def process(self, other):
            pass
        def __add__(self, other):
            return self.process(other)

    class A(TestClass):
        def process(self, other):
            if isinstance(other, A):
                return A(self.value + other.value)
            else:
                print('other is not an A object')


    class B(TestClass):
        def process(self, other):
            if isinstance(other, B):
                return B(self.value - other.value)
            else:
                print('other is not an B object')



# Generated at 2022-06-23 17:31:31.181114
# Unit test for function map_structure
def test_map_structure():
    def f(x):
        return x

    assert map_structure(f, 1) == 1

    assert map_structure(f, [1, 2, 3]) == [1, 2, 3]
    assert map_structure(f, (1, 2, 3)) == (1, 2, 3)
    assert map_structure(f, {"a": 1, "b": 2}) == {"a": 1, "b": 2}

    assert map_structure(f, [1, [2, 3]]) == [1, [2, 3]]
    assert map_structure(f, (1, [2, 3])) == (1, [2, 3])
    assert map_structure(f, {"a": 1, "b": {"c": 2}}) == {"a": 1, "b": {"c": 2}}

# Generated at 2022-06-23 17:31:42.737037
# Unit test for function map_structure
def test_map_structure():
    from torch import nn
    from torch.nn import init
    from torch.optim import Adam

    model = nn.Sequential(nn.Linear(5, 5), nn.Linear(5, 5))
    optimizer = Adam(model.parameters())
    model_state_dict = model.state_dict()
    optim_state_dict = optimizer.state_dict()

    def apply_fn(x):
        if isinstance(x, nn.Linear):
            init.uniform_(x.weight, -0.01, 0.01)
            init.uniform_(x.bias, -0.01, 0.01)
            return x
        return x

    model = map_structure(apply_fn, model)
    # model = map_structure(lambda x: x, model)
    print

# Generated at 2022-06-23 17:31:53.249519
# Unit test for function no_map_instance
def test_no_map_instance():
    import torch

    a = [0, 1, 2]
    a = no_map_instance(a)
    a = map_structure(lambda x: x+1, a)
    # Without calling no_map_instance, the list would be mapped over, and a would be [1, 2, 3].
    assert(a[0] == 1)
    assert(a[1] == 2)
    assert(a[2] == 3)

    b = torch.Size([0, 1, 2])
    b = map_structure(lambda x: x+1, b)
    assert(b == torch.Size([1, 2, 3]))

# Generated at 2022-06-23 17:31:56.191568
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class MyTuple(tuple):
        def __init__(self, *args):
            super().__init__(*args)

    my_tuple_type = register_no_map_class(MyTuple)
    assert(my_tuple_type is not None)
    assert(MyTuple in _NO_MAP_TYPES)


# Generated at 2022-06-23 17:32:07.033508
# Unit test for function reverse_map
def test_reverse_map():
    word_to_index = {'a': 1, 'abandon': 2, 'abrupt': 3, 'above': 4, 'absent': 5}
    index_to_word = reverse_map(word_to_index)
    assert index_to_word[1] == 'a'
    assert index_to_word[2] == 'abandon'
    assert index_to_word[3] == 'abrupt'
    assert index_to_word[4] == 'above'
    assert index_to_word[5] == 'absent'


from argparse import ArgumentParser
from typing import Set

from allennlp.common.util import JsonDict



# Generated at 2022-06-23 17:32:15.181937
# Unit test for function no_map_instance
def test_no_map_instance():
    a = [1, 2]
    b = no_map_instance(a)
    c = [3, 4]
    d = no_map_instance(c)

    def f(obj):
        return [i+1 for i in obj]

    print(f(a))
    print(f(b))
    print(f(c))
    print(f(d))


if __name__ == '__main__':
    test_no_map_instance()

# Generated at 2022-06-23 17:32:25.258855
# Unit test for function no_map_instance
def test_no_map_instance():
    import torch
    import numpy as np
    # test case:
    # lst == [(1,2), (3,4), (5,6)]
    # tensor == t(lst)
    lst = [[1,2], [3,4], [5,6]]
    tensor = torch.tensor(lst)
    ##################
    # the following assert statement is the ground truth
    assert torch.allclose(tensor.tolist(), lst)
    ##################

    # test map_structure
    # the test is to verify whether map_structure returns correctly
    def fn(obj):
        return np.array(obj)
    list_mapped = map_structure(fn, tensor)
    # the following assert statement is to check whether the output of map_structure returns correctly (same shape

# Generated at 2022-06-23 17:32:28.787473
# Unit test for function reverse_map
def test_reverse_map():
    d = {'a': 2, 'b': 5, 'c': 1}
    actual = reverse_map(d)
    expected = ['c', 'a', 'b']
    assert actual == expected

# Generated at 2022-06-23 17:32:35.249546
# Unit test for function map_structure
def test_map_structure():
    data = {
        "a": [[1,2,3],[4,5,6]],
        "b": [2, 3]
    }
    
    def fn(x):
        return [x[0], x[1]]
    
    output = map_structure(fn, data)
    print(output)

if __name__ == "__main__":
    test_map_structure()

# Generated at 2022-06-23 17:32:46.612768
# Unit test for function reverse_map
def test_reverse_map():
    d0 = {
        'a': 0,  # a -> 0
        'aardvark': 1,  # aardvark -> 1
        'abandon': 2,  # abandon -> 2
        'abandoned': 3,  # abandoned -> 3
        'abandoning': 4,  # abandoning -> 4
        'abc': 5,  # abc -> 5
        'ability': 6  # ability -> 6
    }
    d1 = {
        2:'abandon'
    }
    assert ['a', 'aardvark', 'abandon', 'abandoned', 'abandoning', 'abc', 'ability'] == reverse_map(d0)
    assert ['abandon'] == reverse_map(d1)


# Generated at 2022-06-23 17:32:57.473602
# Unit test for function no_map_instance
def test_no_map_instance():
    assert no_map_instance(5) == 5
    assert no_map_instance([5, 6]) == [5, 6]
    assert no_map_instance(('a', 5)) == ('a', 5)
    # assert no_map_instance((1, 'a'), ('b', 2)) == ('b', 2)
    # assert no_map_instance([1, 2], [3, 4]) == [3, 4]
    # assert no_map_instance([1, 2], [3, 4], [5, 6]) == [5, 6]
    assert no_map_instance({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # assert no_map_instance({'x': 'a'}, {'x': 'b'}) == {'x': 'b'}
   

# Generated at 2022-06-23 17:33:00.546634
# Unit test for function no_map_instance
def test_no_map_instance():
    mock_container = no_map_instance([1,2,3])
    assert mock_container[0] == 1
    assert hasattr(mock_container, '__no_map__')

# Generated at 2022-06-23 17:33:02.552411
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance(list(range(10)))
    assert map_structure(lambda x: 2 * x, a) == a

# Generated at 2022-06-23 17:33:12.714291
# Unit test for function reverse_map
def test_reverse_map():
    import json
    with open("./data/data_id.json", 'r') as f:
        data_id = json.load(f)
    with open("./data/label_id_name.json", 'r') as f:
        label_id_name = json.load(f)
    with open("./data/tag_id_name.json", 'r') as f:
        tag_id_name = json.load(f)
    data_key = [int(i) for i in data_id.keys()]
    data_key.sort()
    id2data = reverse_map(data_id)
    assert len(id2data) == len(data_key)
    # Test the id in output id2data is correct

# Generated at 2022-06-23 17:33:16.975547
# Unit test for function no_map_instance
def test_no_map_instance():
    def test_structure(obj):
        return isinstance(obj, list) and isinstance(obj[0], int)
    obj = no_map_instance([1])
    assert test_structure(obj) == True
    obj = [1]
    assert test_structure(obj) == True
    obj = no_map_instance(obj)
    assert test_structure(obj) == False



# Generated at 2022-06-23 17:33:22.638815
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import math
    import torch

    d = [
        ([1, 2, 3], [4, 5, 6]),
        ([4, 5, 6], [1, 2, 3])
    ]

    def add(a, b):
        return a + b

    def square(a):
        return a ** 2

    def add_and_pass_on():
        return add

    assert map_structure_zip(add, d) == ([5, 7, 9], [5, 7, 9])
    assert map_structure_zip(square, d) == ([17, 29, 45], [17, 29, 45])
    assert not map_structure_zip(add, d) == ([5], [5])
    assert not map_structure_zip(square, d) == ([5], [5])
    assert not map_st

# Generated at 2022-06-23 17:33:31.927458
# Unit test for function map_structure
def test_map_structure():
    x = [1, {'a': [1, 2], 'b': (1, 2), 'c': 3}, [[4], [5]]]
    y = map_structure(lambda x: x + 1, x)
    expected_y = [2, {'a': [2, 3], 'b': (2, 3), 'c': 4}, [[5], [6]]]
    assert y == expected_y
    y = map_structure(lambda x: x + 1, (1, {'a': [1, 2], 'b': (1, 2), 'c': 3}, [[4], [5]]))
    assert y == expected_y
    # Test on namedtuple
    import collections
    Person = collections.namedtuple('Person', ['age', 'name'])

# Generated at 2022-06-23 17:33:40.180662
# Unit test for function no_map_instance
def test_no_map_instance():
    list_to_no_map = _no_map_type(list)
    no_map_list = list_to_no_map([1, 2, 3])
    assert(hasattr(no_map_list, _NO_MAP_INSTANCE_ATTR))
    assert(isinstance(no_map_instance([1, 2, 3]), list_to_no_map))
    assert(hasattr(no_map_instance([1, 2, 3]), _NO_MAP_INSTANCE_ATTR))
    assert(len(no_map_instance([1, 2, 3])) == 3)

# Generated at 2022-06-23 17:33:50.678224
# Unit test for function no_map_instance
def test_no_map_instance():
    test_list = no_map_instance([[1, 2], [3, 4]])
    assert hasattr(test_list, _NO_MAP_INSTANCE_ATTR)
    assert _no_map_type(type(test_list)) is type(test_list)

    test_dict = no_map_instance({'a': 1, 'b': 2})
    assert hasattr(test_dict, _NO_MAP_INSTANCE_ATTR)
    assert _no_map_type(type(test_dict)) is type(test_dict)

    test_tuple = no_map_instance((1, 2, 3, 4))
    assert hasattr(test_tuple, _NO_MAP_INSTANCE_ATTR)

# Generated at 2022-06-23 17:33:59.932320
# Unit test for function reverse_map
def test_reverse_map():
    # pylint: disable=missing-docstring,invalid-name
    import hypothesis.strategies as st

    @st.composite
    def reverse_map_example(draw):
        items = draw(st.lists(st.integers(), min_size=1, unique=True))
        ids = draw(st.lists(st.integers(), min_size=1, unique=True, max_size=len(items)))
        mapper = {item: idx for item, idx in zip(items, ids)}
        return mapper, items

    @given(reverse_map_example())
    def test_reverse_map(example):
        mapper, items = example
        assert reverse_map(mapper) == items

    test_reverse_map()


# Generated at 2022-06-23 17:34:07.074354
# Unit test for function map_structure
def test_map_structure():
    @no_type_check
    def fn(x):
        return 2*x

    test_obj = [{'a':[{'b':1}],'c':1}]
    desired_obj = [{'a':[{'b':2}],'c':2}]
    assert map_structure(fn,test_obj) == desired_obj

# Generated at 2022-06-23 17:34:10.742312
# Unit test for function reverse_map
def test_reverse_map():
    source_dict = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    target_list = ['a', 'b', 'c', 'd']
    assert(reverse_map(source_dict) == target_list)



# Generated at 2022-06-23 17:34:16.836164
# Unit test for function map_structure
def test_map_structure():
    for obj in [
        [[1,2], 3],
        [{"1":1}],
        {"1":[1], "2":[2,3]},
        {"1":1, "2": {"3":3}}
    ]:
        print(map_structure(repr, obj))
        print(map_structure(str, obj))

if __name__ == "__main__":
    test_map_structure()

# Generated at 2022-06-23 17:34:21.240391
# Unit test for function register_no_map_class
def test_register_no_map_class():
    """
    :return:
    """
    import torch
    register_no_map_class(torch.Size)
    class C(torch.Size):
        def __init__(self, list):
            torch.Size.__init__(self, list)

    size = C([1, 1])
    result = map_structure(lambda x: x.item(), size)
    print(result)
    assert result == [1, 1]
    #assert result == 1

# Generated at 2022-06-23 17:34:32.973394
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class Test:
        pass

    a = Test()
    a.sent1 = 'hello'
    a.sent2 = 'world'

    a.b = Test()
    a.b.sent3 = 'ai'
    a.b.sent4 = 'ml'

    a.c = [2,3,4]
    a.d = {'x':1, 'y':2}
    
    register_no_map_class(type(a))
    a = no_map_instance(a)
    a.sent2 = 'ai'
    print(a.sent1)
    print(a.sent2)
    print(a.b.sent3)
    print(a.b.sent4)
    print(a.c)
    print(a.d)

# Generated at 2022-06-23 17:34:35.670742
# Unit test for function reverse_map
def test_reverse_map():
    pairs = {"a": 1, "b": 2, "c": 2}
    assert reverse_map(pairs) == ["a", "b", "c"]



# Generated at 2022-06-23 17:34:42.491528
# Unit test for function reverse_map

# Generated at 2022-06-23 17:34:47.621050
# Unit test for function map_structure_zip
def test_map_structure_zip():
    list = [[1, 2], [3, 4], [5,6]]
    tuple = ([1, 2], [3, 4], [5, 6])
    dict = [{0: 1, 1: 2}, {0: 3, 1: 4}, {0: 5, 1: 6}]
    fn = lambda x: x + 1
    list_ans = map_structure_zip(fn, list)
    tuple_ans = map_structure_zip(fn, tuple)
    dict_ans = map_structure_zip(fn, dict)
    # print(list_ans)
    # print(tuple_ans)
    # print(dict_ans)
    assert (list_ans == [[1, 2], [3, 4], [5, 6]]) == True

# Generated at 2022-06-23 17:34:55.374422
# Unit test for function map_structure
def test_map_structure():
    def f(obj) :
        if isinstance(obj, list) :
            return 'list'
        else :
            return 'other'
    s = map_structure(f, [[[[1,2,3]]]])
    assert s == 'list'
    s = map_structure(f, [[[[1,2,3]]], [[[5,6,7]]]])
    assert s == [[['list']], [['list']]]

# Generated at 2022-06-23 17:35:05.159791
# Unit test for function no_map_instance
def test_no_map_instance():
    import collections
    class MyList(collections.UserList):
        pass

    class NestedList(collections.UserList):
        pass

    # Basic test
    l = no_map_instance(MyList([1, 2, 3]))
    assert(l[0] == 1)
    assert(l[1] == 2)
    assert(l[2] == 3)
    assert(hasattr(l, _NO_MAP_INSTANCE_ATTR))

    l = NestedList([MyList([1, 2, 3]), MyList([4, 5, 6])])
    ml = no_map_instance(l)
    assert(len(ml) == 2)
    assert(ml[0][0] == 1)
    assert(ml[1][1] == 5)

# Generated at 2022-06-23 17:35:14.479671
# Unit test for function map_structure_zip
def test_map_structure_zip():
    objs = (
        [
            ['a', 'aardvark', 'abandon'],
            ['a', 'aardvark', 'abandon'],
            ['a', 'aardvark', 'abandon'],
        ],
        [
            [1, 2, 3],
            [1, 2, 3],
            [1, 2, 3],
        ],
        [
            [1, 2, 3],
            [1, 2, 3],
            [1, 2, 3],
        ]
    )

    zipped = map_structure_zip(lambda a, b, c: [a, b, c], objs)
    assert zipped == [['a', 1, 1], ['aardvark', 2, 2], ['abandon', 3, 3]], "map_structure_zip error"

# Generated at 2022-06-23 17:35:16.979312
# Unit test for function reverse_map
def test_reverse_map():
    word_to_id = {'a': 0, 'b': 1, 'c': 2}
    id_to_word = reverse_map(word_to_id)
    assert id_to_word == ['a', 'b', 'c']


# Generated at 2022-06-23 17:35:28.202161
# Unit test for function map_structure
def test_map_structure():
    f = lambda x: x + 1
    args = [1, [2, [3, [4, 5]]], ["abc", ("def", None)]]
    args_copy = copy(args)
    result = map_structure(f, args)
    expected = [2, [3, [4, [5, 6]]], ["abc1", ("def1", None)]]
    assert args == args_copy
    assert result == expected
    
    f = lambda x, y: x + y
    args_1 = args
    args_2 = [1, [2, [3, [4, 5]]], ["abc", ("def1", None)]]
    args_3 = [1, [2, [3, [4, 5]]], ["abc1", ("def", None)]]

# Generated at 2022-06-23 17:35:40.346597
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from torch._six import container_abcs

    register_no_map_class(container_abcs.Mapping)
    register_no_map_class(container_abcs.MutableSequence)

    a = no_map_instance(dict(a=3))
    b = (no_map_instance(torch.tensor([2])), torch.tensor([2]))
    expected_result = (dict(a=torch.tensor([3])), torch.tensor([2]))
    result = map_structure(lambda x: torch.tensor([x]), (a, b))
    assert result == expected_result, "Function map_structure failed"

    dic = no_map_instance(dict(a=3))

# Generated at 2022-06-23 17:35:52.456786
# Unit test for function no_map_instance
def test_no_map_instance():
    import copy
    # Test for subtype of built-in types
    class MyList(list):
        pass
    a = MyList([1, 2, 3])
    b = no_map_instance(a)
    assert isinstance(b, MyList)
    assert isinstance(b, list)
    assert b == [1, 2, 3]
    # Test for subtype of built-in types that has been registered
    register_no_map_class(MyList)
    c = no_map_instance(a)
    assert c is a
    # Test for non-container type
    d = 123
    e = no_map_instance(d)
    assert e is d
    # Test for non-container type that has been registered
    register_no_map_class(type(d))
    f = no_map_instance

# Generated at 2022-06-23 17:36:01.890309
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [[1,2,3],[4,5,6]]
    b = [[7,8,9],[10,11,12]]
    # assert map_structure_zip(lambda x, y: x * y, a ) == [[7,16,27],[40,55,72]]
    assert map_structure_zip(lambda x, y: x * y, a,b ) == [[7,16,27],[40,55,72]]


test_map_structure_zip()

# Generated at 2022-06-23 17:36:10.591605
# Unit test for function map_structure
def test_map_structure():
    from collections import namedtuple
    from allennlp.training.learning_rate_schedulers import PassThroughScheduler
    from allennlp.training.trainer import Trainer
    from allennlp.training.momentum_schedulers import MomentumScheduler
    from allennlp.training.moving_average import ExponentialMovingAverage

    class _DummyModel(nn.Module):
        model_type = 'srl'

        def __init__(self, num_tags: int, embedding_dim: int, vocab) -> None:
            super().__init__()

# Generated at 2022-06-23 17:36:19.503982
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([1, 2, 3, 4, 5])
    b = no_map_instance({"a": 3, "b": 4})
    c = no_map_instance((1, 2))
    d = no_map_instance("a")
    e = no_map_instance({"a": {"b": {"c": 3}}})

    print("type(a) ", type(a))
    print("type(b) ", type(b))
    print("type(c) ", type(c))
    print("type(d) ", type(d))
    print("type(e) ", type(e))

    # test map_structure_zip

# Generated at 2022-06-23 17:36:30.380721
# Unit test for function no_map_instance
def test_no_map_instance():
    assert(no_map_instance([1,2]).__class__.__name__ == '_no_maplist')
    assert(no_map_instance({'hello':'world'}).__class__.__name__ == '_no_mapdict')
    assert(no_map_instance((1,2)).__class__.__name__ == '_no_maptuple')
    assert(no_map_instance(torch.Size([1,2])).__class__.__name__ == '_no_maptorch_Size')
    assert(no_map_instance([1,2]).__class__.__name__ == '_no_maplist')
    assert(hasattr(no_map_instance([1,2]), '__no_map__'))

# Generated at 2022-06-23 17:36:42.115630
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import torch
    import types

    class Struct(object):
        def __init__(self):
            pass

    # Fail to register type `list`
    try:
        register_no_map_class(list)
        assert False
    except TypeError:
        pass

    # Test registering custom class
    struct = Struct()
    struct.a = 1
    struct.b = "asdf"
    register_no_map_class(Struct)
    func = lambda x : x
    out = map_structure(func, struct)
    assert isinstance(out, Struct)
    assert out.a == struct.a
    assert out.b == struct.b

    # Test registering built-in class
    assert torch.Size not in _NO_MAP_TYPES
    torch_size = torch.Size([1, 2, 3])

# Generated at 2022-06-23 17:36:49.704141
# Unit test for function reverse_map
def test_reverse_map():
    def my_test():
        words = ['a', 'aardvark', 'abandon', 'abandoned']
        word_to_id = {word: idx for idx, word in enumerate(words)}
        id_to_word = reverse_map(word_to_id)
        if words == id_to_word:
            print("test_reverse_map succeeded")
        else:
            print("test_reverse_map failed")
    my_test()


test_reverse_map()

# Generated at 2022-06-23 17:37:03.123343
# Unit test for function map_structure
def test_map_structure():
    def f(obj):
        if type(obj) == int:
            return obj + 1
        if type(obj) == float:
            return obj + 1.0
        return obj

    def f_pair(a, b):
        if type(a) == int and type(b) == float:
            return (a + 1, b + 1.0)
        if type(a) == float and type(b) == int:
            return (a + 1.0, b + 1)
        return (a, b)

    input_data = [
        1, '', 2.0,
        [1, 2, 3.0],
        [{'a': 1, 'b': 2.0}, {'a': 3, 'b': 4}, {'a': '', 'b': ''}]
    ]

    output_

# Generated at 2022-06-23 17:37:13.065169
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import torch
    a = {'a': [1, 2, 3], 'b': [4, 5, 6], 'c': [7, 8, 9]}
    b = {'a': [1, 2, 3], 'b': [4, 5, 6], 'c': [7, 8, 9]}
    c = {'a': [1, 2, 3], 'b': [4, 5, 6], 'c': [7, 8, 9]}
    sum_dict = lambda a, b, c: {'a': a['a'] + b['a'] + c['a'],
                                'b': a['b'] + b['b'] + c['b'],
                                'c': a['c'] + b['c'] + c['c']}

# Generated at 2022-06-23 17:37:23.217779
# Unit test for function no_map_instance
def test_no_map_instance():
    from collections import namedtuple
    from typing import NamedTuple, List, Tuple
    tuple_type = namedtuple('tuple_type', ['a', 'b', 'c'])
    tuple_type_list: List[Tuple[int, int, str]] = [tuple_type(1, 2, 's')]
    tuple_type_list_no_map = no_map_instance(tuple_type_list)
    assert isinstance(tuple_type_list_no_map[0], tuple_type)
    assert not isinstance(tuple_type_list_no_map[0], tuple_type)

