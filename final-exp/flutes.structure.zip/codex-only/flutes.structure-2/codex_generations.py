

# Generated at 2022-06-23 17:27:17.180984
# Unit test for function no_map_instance
def test_no_map_instance():
    x = no_map_instance(range(10))
    y = map_structure(lambda x: x, x)
    assert x == list(y)



# Generated at 2022-06-23 17:27:25.996400
# Unit test for function no_map_instance
def test_no_map_instance():
    # test for __class__
    assert _NO_MAP_TYPES == set()
    class TestClass:
        def __init__(self, data):
            self.data = data
    test_instance_0 = TestClass([1,2,3])
    test_instance_1 = TestClass({"a":1, "b":2})
    test_instance_2 = TestClass({"a":1, "b": [1,2,3]})
    register_no_map_class(TestClass)
    assert test_instance_0.__class__ == TestClass
    assert test_instance_1.__class__ == TestClass
    assert test_instance_2.__class__ == TestClass

    # test for instance

# Generated at 2022-06-23 17:27:34.262669
# Unit test for function map_structure
def test_map_structure():
    """
        Test function: map_structure
        Author: @yuanxq
    """
    import inspect
    import torch
    @no_type_check
    def try_incr_size(x):
        if hasattr(x, '_fields'):
            return type(x)(*( try_incr_size(i) for i in x ))
        try:
            # torch.Size is a subclass of tuple (so torch.Size(a) is equal to a),
            # but tuples are ordered, so we need to force torch.size to be treated
            # as unordered.
            if type(x) is torch.Size:
                x = no_map_instance(x)
            return x+1
        except:
            return x

# Generated at 2022-06-23 17:27:45.760347
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = {'1': 1, '2': 2}
    b = {'1': 'one', '2': 'two'}
    c = {'1': '1', '2': '2'}

    def f(x, y, z):
        return str(x) + ' ' + str(y) + ' ' + str(z)

    mapped_dict = map_structure_zip(f, [a, b, c])
    assert(mapped_dict['1'] == '1 one 1')
    assert(mapped_dict['2'] == '2 two 2')

    a = (1, 2)
    b = ('one', 'two')
    c = ('1', '2')


# Generated at 2022-06-23 17:27:54.480088
# Unit test for function map_structure
def test_map_structure():
    a = [[1, 2], 3]
    b = [[4, 5], 6]
    c = [[[7, 8], 9], 10]

    assert map_structure(sum, (a, b)) == [[5, 7], 9]
    assert map_structure(sum, (a, b, c)) == [[[12, 15], 20], 23]

    # test empty lists
    assert map_structure(sum, []) == []
    assert map_structure(sum, ([], [])) == []
    assert map_structure(sum, ((), ())) == ()
    assert map_structure(sum, ({}, {})) == {}

    # test empty tuple
    a = (1,)
    b = (2,)
    assert map_structure(sum, (a, b)) == (3,)

# Generated at 2022-06-23 17:27:59.710313
# Unit test for function map_structure
def test_map_structure():

    def add_three(x):
        return x + 3

    def substract_three(x):
        return x - 3
    
    a = [1, 2, 3]
    b = {'k1': [1, 2, 3, 4],
         'k2': [4, 5, [6, 7]]}
    c = [{'k1': 1, 'k2': 2},
         {'k1': 3, 'k2': 4},
         {'k1': 5, 'k2': 6}]
    d = [1, b, c]
    e = {'key1': [1, 2, 3],
         'key2': [4, 5, [6, 7]]}
    f = {'key1': a, 'key2': b, 'key3': c}

# Generated at 2022-06-23 17:28:10.869215
# Unit test for function map_structure
def test_map_structure():
    structure = [
        [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}],
        [{'a': 5, 'b': 6}, {'c': 7, 'd': 8}]
    ]

    def plus_one(x):
        return x + 1

    mapped_structure = map_structure(plus_one, structure)
    assert mapped_structure == [
        [{'a': 2, 'b': 3}, {'c': 4, 'd': 5}],
        [{'a': 6, 'b': 7}, {'c': 8, 'd': 9}]
    ]


if __name__ == '__main__':
    test_map_structure()

# Generated at 2022-06-23 17:28:17.039891
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([1, 2, 3])
    b = no_map_instance([1, 2, 3])
    c = no_map_instance([4, 5, 6])
    d = [1, 2, 3]
    assert map_structure(id, a) is a
    assert map_structure(id, b) is b
    assert map_structure(id, c) is c
    assert map_structure(id, d) is not d

# Generated at 2022-06-23 17:28:20.007230
# Unit test for function reverse_map
def test_reverse_map():
    assert reverse_map({"a": 0, "b": 1, "c": 2}) == ["a", "b", "c"]

# Generated at 2022-06-23 17:28:30.194761
# Unit test for function no_map_instance
def test_no_map_instance():
    words = ['a', 'aardvark', 'abandon', 'abandoned', 'abbreviation', 'abbreviations', 'abdomen', 'abdominal', 'ability']

    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)

    print((words == id_to_word))


# Generated at 2022-06-23 17:28:39.644949
# Unit test for function map_structure_zip
def test_map_structure_zip():
    class Nested(object):
        def __init__(self, x, y, z):
            self.x = x
            self.y = y
            self.z = z

    foo = Nested(0, Nested(1, "1", Nested(2, "2", 3)), 4)
    bar = Nested(0, Nested(2, "2", Nested(4, "4", 6)), 8)
    fn = lambda x, y: x + y
    ret_obj = map_structure_zip(fn, [foo, bar])
    assert ret_obj.x == 0
    assert ret_obj.y.x == 3
    assert ret_obj.y.y == "12"
    assert ret_obj.y.z.x == 6
    assert ret_obj.y.z.y == "24"

# Generated at 2022-06-23 17:28:47.686123
# Unit test for function no_map_instance
def test_no_map_instance():
    import numpy as np
    class MyClass(object):
        def __init__(self, size):
            self.size = size

        def __repr__(self):
            return 'MyClass(%d)' % self.size

    class MyClass2(object):
        def __init__(self, size):
            self.size = size

        def __repr__(self):
            return 'MyClass2(%d)' % self.size

    def f(x):
        return x ** 2


# Generated at 2022-06-23 17:28:58.472603
# Unit test for function no_map_instance
def test_no_map_instance():
    l = [1, 2, 3, {'a': 1, 'b': 2}, [1, 2, 3]]
    new_l = no_map_instance(l)
    assert l == new_l
    assert l is not new_l
    assert new_l[3] is l[3]
    assert new_l[4] is l[4]
    assert not hasattr(l, _NO_MAP_INSTANCE_ATTR)
    assert hasattr(new_l, _NO_MAP_INSTANCE_ATTR)
    new_l2 = no_map_instance(new_l)
    assert new_l is new_l2  # the function is idempotent


# Generated at 2022-06-23 17:29:09.772677
# Unit test for function map_structure
def test_map_structure():
    def fn(x):
        return x+1

    def test_function(obj, expected):
        assert map_structure(fn, obj) == expected

    # Test for List
    test_function([1, 2, 3], [2, 3, 4])

    # Test for tuple
    test_function((1, 2, 3), (2, 3, 4))

    # Test for Dict
    test_function({"a": 1, "b": 2} , {"a": 2, "b": 3})

    # Test for Set
    test_function({"a", "b"}, {"a", "b"})

    # Test for namedtuple
    Point = namedtuple("Point2D", ("x", "y"))
    point = Point(1, 2)
    test_function(point, Point(2, 3))

    #

# Generated at 2022-06-23 17:29:23.035721
# Unit test for function reverse_map

# Generated at 2022-06-23 17:29:28.885700
# Unit test for function reverse_map
def test_reverse_map():
    word_to_id = {'a': 0, 'aardvark': 1, 'abandon': 2}
    id_to_word = reverse_map(word_to_id)
    assert ['a', 'aardvark', 'abandon'] == id_to_word



# Generated at 2022-06-23 17:29:40.202969
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import torch
    container_type = torch.Size
    register_no_map_class(container_type)

    # Case 1: no_map_instance
    obj = torch.Size([0, 1])
    obj = no_map_instance(obj)
    assert obj.__class__ == container_type
    assert obj[0] == 0
    assert obj[1] == 1

    # Case 2: map_structure
    obj = torch.Size([0, 1])
    obj_mapped = map_structure(lambda x: torch.Size(x), obj)
    assert obj_mapped.__class__ == container_type
    assert obj_mapped[0] == 0
    assert obj_mapped[1] == 1

    # Case 3: map_structure_zip

# Generated at 2022-06-23 17:29:49.673458
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [{'a':1,'b':2,'c':3, 'd': {'a': 11, 'b': 12, 'c':13}},
         {'a':4,'b':5,'c':6, 'd': {'a': 14, 'b': 15, 'c':16}},
         {'a':7,'b':8,'c':9, 'd': {'a': 17, 'b': 18, 'c':19}}]

    def sum_dict(xs, ys):
        return {x:ys[x] for x in xs.keys()}

    print(map_structure_zip(sum_dict, a))

# Generated at 2022-06-23 17:29:54.058373
# Unit test for function no_map_instance
def test_no_map_instance():
    import torch

    class TorchSize(torch.Size):
        pass

    x = TorchSize((1,))
    x = no_map_instance(x)
    assert str(x).find("--no-map--") != -1

    from collections import OrderedDict

    x = OrderedDict()
    x = no_map_instance(x)
    assert str(x).find("--no-map--") != -1



# Generated at 2022-06-23 17:29:59.468949
# Unit test for function register_no_map_class
def test_register_no_map_class():
    test_data = [('test_string', 'test_result'), (1, 1), (1.3, 1.3)]

    for data, expected_result in test_data:
        assert no_map_instance(data) == expected_result



# Generated at 2022-06-23 17:30:10.127923
# Unit test for function reverse_map

# Generated at 2022-06-23 17:30:20.740298
# Unit test for function reverse_map

# Generated at 2022-06-23 17:30:29.722774
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def _test_container_type(containter_type):
        print("Testing container type:", containter_type)
        # Create two identical structures
        test_list = containter_type((1, 2, 3))
        test_list2 = containter_type((4, 5, 6))
        test_list3 = containter_type((7, 8, 9))
        # This list contains the elements that should be in the mapped list
        test_list_zipped = [
            (1, 4, 7), (2, 5, 8), (3, 6, 9)
        ]
        # test_list and test_list2 should have the same type
        assert type(test_list) == type(test_list2)
        assert type(test_list) == type(test_list3)
        # test_list and test_

# Generated at 2022-06-23 17:30:31.936178
# Unit test for function no_map_instance
def test_no_map_instance():
    l = no_map_instance([1, 2, 3])
    l[0] = 1
    assert l[0] == 1
    l[0] = 2
    assert l[0] == 2

# Generated at 2022-06-23 17:30:36.283894
# Unit test for function reverse_map
def test_reverse_map():
    d = {1: 'one', 2: 'two'}
    actual = reverse_map(d)
    expected = ['one', 'two']
    assert actual == expected, "actual value is not equal to expected"


# Generated at 2022-06-23 17:30:40.289069
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class TestList(list):
        pass

    # Test whether the function can be called
    register_no_map_class(TestList)

    assert TestList in _NO_MAP_TYPES

# Generated at 2022-06-23 17:30:48.639254
# Unit test for function no_map_instance
def test_no_map_instance():
    X = no_map_instance([0])
    assert hasattr(X, _NO_MAP_INSTANCE_ATTR)
    X = no_map_instance((1,2))
    assert hasattr(X, _NO_MAP_INSTANCE_ATTR)
    X = no_map_instance({1:2})
    assert hasattr(X, _NO_MAP_INSTANCE_ATTR)
    try:
        X = no_map_instance(None)
    except:
        pass
    class X():
        pass
    X = no_map_instance(X())
    assert hasattr(X, _NO_MAP_INSTANCE_ATTR)

# Generated at 2022-06-23 17:31:01.859415
# Unit test for function map_structure_zip
def test_map_structure_zip():
    from collections import namedtuple
    from itertools import product
    from random import seed
    from random import shuffle
    from random import uniform

    from nn_.utils.map_structure import map_structure_zip
    from nn_.utils.map_structure import map_structure

    seed(1)
    x_lower = 5
    x_upper = 10
    y_lower = 0
    y_upper = 1000
    NUM_POINTS = 10
    Point = namedtuple("Point", ["x", "y"])
    Points = namedtuple("Points", ["a", "b", "c"])
    PointDiff = namedtuple("Points", ["a", "b", "c"])

# Generated at 2022-06-23 17:31:12.841573
# Unit test for function map_structure
def test_map_structure():
    class TestDict(dict): pass
    class TestList(list): pass
    class TestSet(set): pass
    class TestTuple(tuple): pass
    class TestNamedTuple(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y

    def add1(x):
        return x + 1

    test_classes = [
        TestDict,
        TestList,
        TestSet,
        TestTuple,
        TestNamedTuple
    ]
    for c in test_classes:
        register_no_map_class(c)

    # A test example illustrated as a tree
    #            (1)
    #           /  \
    #        [(2)] dct
    #     /     |     \
    #  [(3)]

# Generated at 2022-06-23 17:31:25.083119
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    list1 = map_structure_zip(lambda x, y, z:x + y + z, [a, b, c])
    list2 = [a[i] + b[i] + c[i] for i in range(len(a))]
    assert list1 == list2

    a = (1, 2, 3)
    b = (4, 5, 6)
    c = (7, 8, 9)
    list1 = map_structure_zip(lambda x, y, z:x + y + z, [a, b, c])
    list2 = [a[i] + b[i] + c[i] for i in range(len(a))]
   

# Generated at 2022-06-23 17:31:28.603939
# Unit test for function reverse_map
def test_reverse_map():
    d = {1: 1, 2: 2, 3: 3, 4: 4, 5: 5}
    reverse_map_out = reverse_map(d)
    assert(reverse_map_out == [1, 2, 3, 4, 5])

# Generated at 2022-06-23 17:31:41.097773
# Unit test for function register_no_map_class
def test_register_no_map_class():
    map_structure(lambda x : x, [1, 2, 3])
    # Should raise an exception if trying to use integer as a key
    try:
        map_structure(lambda x : x, {'a' : 1, 2 : 3})
        assert False, "The above line should have failed with a TypeError but it did not."
    except TypeError as e:
        pass
    class Klass:

        def __init__(self):
            pass

    # Should be OK to use Klass as a key
    register_no_map_class(Klass)
    map_structure(lambda x : x, {'a' : 1, Klass() : 3})

# Generated at 2022-06-23 17:31:48.969061
# Unit test for function map_structure_zip
def test_map_structure_zip():
    objs = [[[1,2,3],[4,5,6]],[[7,8,9],[10,11,12]]]
    # function to be mapped
    def sum_all(objects):
        return np.sum(objects)
    # expected result
    expected_result = [[18,21,24], [36,39,42]]
    # test
    result = map_structure_zip(sum_all,objs)
    assert(result == expected_result)

# Generated at 2022-06-23 17:31:52.482692
# Unit test for function no_map_instance
def test_no_map_instance():
    a = {1:[[1,2,3], [4,5,6]], 2:[[7,8,9], [10,11,12]]}
    a[1][1] = no_map_instance(a[1][1])
    print(a)

# Generated at 2022-06-23 17:31:54.374245
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class NonMappable(list):
        pass

    register_no_map_class(NonMappable)
    assert(_NO_MAP_TYPES == set([NonMappable]))



# Generated at 2022-06-23 17:31:57.720146
# Unit test for function reverse_map
def test_reverse_map():
    a = {'a': 2, 'b': 1, 'c': 3}
    b = ['b', 'a', 'c']
    assert reverse_map(a) == b


# Generated at 2022-06-23 17:32:08.890057
# Unit test for function reverse_map

# Generated at 2022-06-23 17:32:15.291406
# Unit test for function reverse_map
def test_reverse_map():
    words = ['a', 'aardvark', 'abandon', 'abandoned']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    assert words == id_to_word


# Generated at 2022-06-23 17:32:23.857005
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class MyContainer:
        pass
    class MyNewContainer(list):
        def __init__(self, my_list):
            super().__init__(my_list)

    a = MyNewContainer(['a', 'b', 'c'])
    b = MyNewContainer(['d', 'e', 'f'])

    register_no_map_class(MyContainer)
    register_no_map_class(MyNewContainer)

    result = map_structure(lambda x, y: x + y, a, b)

    assert result == ['a', 'b', 'c', 'd', 'e', 'f']


# Generated at 2022-06-23 17:32:34.627072
# Unit test for function reverse_map
def test_reverse_map():
    word_to_id = {'<pad>': 0, 'the': 1, 'a': 2, 'an': 3, 'on': 4, 'of': 5, 'in': 6, 'with': 7, 'and': 8, 'is': 9}
    id_to_word = reverse_map(word_to_id)
    print(id_to_word)
    words = ['<pad>', 'the', 'a', 'an', 'on', 'of', 'in', 'with', 'and', 'is']
    print("words == id_to_word ", words == id_to_word)


if __name__ == '__main__':
    test_reverse_map()

# Generated at 2022-06-23 17:32:39.883349
# Unit test for function no_map_instance
def test_no_map_instance():
    x = no_map_instance([1,2,3])
    ret = map_structure(lambda y: [y[0], y+1], x)
    assert ret == [[1, 2, 3], 2, 3, 4]

# Generated at 2022-06-23 17:32:44.753317
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import torch
    class MySize(torch.Size):
        pass
    register_no_map_class(MySize)
    l = map_structure(lambda x: x + 1, MySize((3,)))
    assert isinstance(l, MySize)
    assert l == (4,)

# Generated at 2022-06-23 17:32:52.608713
# Unit test for function no_map_instance
def test_no_map_instance():
    @no_type_check
    def _test_no_map_instance():
        maps = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        non_maps = [no_map_instance(x) for x in maps]
        def _test_map_structure_zip(fn, *maps):
            return map_structure_zip(fn, maps)
        return _test_map_structure_zip(lambda x, y: x + y, maps, non_maps)

    for x in _test_no_map_instance():
        if type(x) == int:
            raise ValueError('no_map_instance failed')
        assert (type(x) is list)
        assert (x == [i for i in range(1, 10)])

# Generated at 2022-06-23 17:32:56.289466
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class NewList(list):
        pass
    register_no_map_class(NewList)
    l = NewList([1, 2, 3])
    l2 = map_structure(identity, l)
    assert l2 == l


# Generated at 2022-06-23 17:33:06.727864
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def f1(x):
        s = '%i' % x
        return s
    def f2(x):
        return [f1(x[0]), f1(x[1])]
    def f3(x):
        return (f1(x[0]), f1(x[1]))
    def f4(x):
        return f1(x[0])
    def f5(x):
        return {f1(x[0]), f1(x[1])}

    # f1 
    a = [1,2,3]
    b = map_structure_zip(f1, [a])
    assert b == [f1(1),f1(2),f1(3)]

    # f2
    a = [1,2,3]

# Generated at 2022-06-23 17:33:17.302636
# Unit test for function map_structure
def test_map_structure():
    a = [[1, 2], [3, 4], [5, 6]]
    b = [[4, 3], [2, 1], [0, -1]]
    c = [[1, 3], [5, 7], [9, 11]]
    d = [[4, 6], [8, 10], [12, 14]]

    assert map_structure(lambda x, y: x + y, a, b) == [[5, 5], [5, 5], [5, 5]]
    assert map_structure(lambda x, y: [x[0] + y[0], x[1] + y[1]], a, b) == [[5, 5], [5, 5], [5, 5]]
    assert map_structure(lambda x, y, z, w: x + y + z + w, a, b, c, d)

# Generated at 2022-06-23 17:33:29.276647
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import torch
    import torch.autograd.variable as var
    register_no_map_class(torch.Size)
    register_no_map_class(set)
    ret = list(map_structure(lambda x: x, [torch.Size([2, 3]), set([1, 2]), {1: 2}]))
    assert ret == [torch.Size([2, 3]), set([1, 2]), {1: 2}]
    var_list = [var.Variable(torch.Tensor([1, 2])), var.Variable(torch.Tensor([3, 4]))]
    var_list_ret = list(map_structure(lambda x: x, var_list))
    assert isinstance(var_list_ret[0], var.Variable)



# Generated at 2022-06-23 17:33:31.200738
# Unit test for function register_no_map_class
def test_register_no_map_class():
    register_no_map_class(list)
    assert list in _NO_MAP_TYPES



# Generated at 2022-06-23 17:33:41.736158
# Unit test for function map_structure
def test_map_structure():
    def add_3(x):
        return x + 3

    def mult(x, y):
        return x*y

    A = [2, 3]
    B = [3, 4]
    C = [3, 4]
    D = [4, 5]
    E = [5, 6]
    F = [(2, 3), (3, 4)]
    G = [(3, 4), (4, 5)]
    H = {2: 3, 3: 4}
    I = {3: 4, 4: 5}
    J = {2: (3, 4), 4: (5, 6)}
    K = {3: (4, 5), 5: (6, 7)}

    print(map_structure(add_3, A))
    print(map_structure(add_3, B))
    print

# Generated at 2022-06-23 17:33:53.222141
# Unit test for function map_structure
def test_map_structure():
    obj = [[1, 2], [3, 4]]
    output = map_structure(lambda x: x ** 2, obj)
    assert output == obj
    obj = {
        'a': 1,
        'b': [2.0, 3.0],
        'c': {'d': ['e', 'f']},
        'd': ('e', 'f'),
    }
    output = map_structure(lambda x: x * 3.0, obj)
    assert output == {
        'a': 3.0,
        'b': [6.0, 9.0],
        'c': {'d': ['eee', 'fff']},
        'd': ('eee', 'fff'),
    }

# Generated at 2022-06-23 17:34:00.104751
# Unit test for function map_structure
def test_map_structure():
    assert map_structure(lambda x: x + 1, [[[0, 1, 2], [1, 1, 2], [2, 1, 2]], \
                           [[0, 1, 2], [1, 1, 2], [2, 1, 2]], \
                           [[0, 1, 2], [1, 1, 2], [2, 1, 2]]]) == \
                           [[[1, 2, 3], [2, 2, 3], [3, 2, 3]], \
                            [[1, 2, 3], [2, 2, 3], [3, 2, 3]], \
                            [[1, 2, 3], [2, 2, 3], [3, 2, 3]]]

# test for function map_structure_zip

# Generated at 2022-06-23 17:34:07.707884
# Unit test for function map_structure_zip
def test_map_structure_zip():
    x = [1,2,3]
    y = [4,5,6]
    z = [7,8,9]
    a = map_structure_zip(lambda x1,x2,x3:x1+x2+x3, (x,y,z))
    print(a)


if __name__ == "__main__":
    test_map_structure_zip()

# Generated at 2022-06-23 17:34:19.071248
# Unit test for function map_structure
def test_map_structure():
    import torch
    test_data = [1,2]
    test_dict = {'a':1,'b':2}
    test_tensor = torch.rand(2,2)
    test_list_dict = [test_dict,test_dict]
    test_tuple_list = (test_list_dict,test_list_dict)
    test_list_tensor = [test_tensor,test_tensor]
    test_tuple_tensor = (test_tensor,test_tensor)
    def test_fn(input_data):
        #return input_data
        return torch.rand(2,2)

    print("test_data:",test_data)
    print("test_dict:",test_dict)
    print("test_tensor:",test_tensor)

# Generated at 2022-06-23 17:34:21.345496
# Unit test for function reverse_map
def test_reverse_map():
    d = {'a': {'a': 1}, 'b': 2, 'c': 3, 'd': 4}
    rd = reverse_map(d)
    print(rd)

if __name__ == '__main__':
    test_reverse_map()

# Generated at 2022-06-23 17:34:33.034353
# Unit test for function map_structure_zip
def test_map_structure_zip():
    d1 = {
        'list1': [1, 2, 3, 5],
        'dict1': {'key1': 1, 'key2': 2},
        'str1': 'string'
    }
    d2 = {
        'list1': [2, 3, 4, 6],
        'dict1': {'key1': 3, 'key2': 4},
        'str1': 'string'
    }
    d3 = {
        'list1': [4, 6, 8, 10],
        'dict1': {'key1': 5, 'key2': 6},
        'str1': 'string'
    }
    def my_add_3_num(a1, a2, a3):
        return a1 + a2 + a3

# Generated at 2022-06-23 17:34:41.938455
# Unit test for function map_structure
def test_map_structure():
    @no_type_check
    def add_one(x: int) -> int:
        return x + 1

    assert map_structure(add_one, [1, 2, 3]) == [2, 3, 4]
    assert map_structure(add_one, (1, 2, 3)) == (2, 3, 4)
    assert map_structure(add_one, {'a': 1, 'b': 2}) == {'a': 2, 'b': 3}

    @no_type_check
    def dot(x: int, y: int) -> int:
        return x * y

    assert map_structure_zip(dot, ([1, 2, 3], [1, 2, 3])) == [1, 4, 9]

# Generated at 2022-06-23 17:34:54.044190
# Unit test for function no_map_instance
def test_no_map_instance():
    from collections import OrderedDict
    import torch
    torch_tensor = torch.tensor([1, 2])
    torch_tensor_copy = no_map_instance(torch_tensor)
    assert(torch_tensor == torch_tensor_copy)
    torch_tensor_copy[0] = 5
    assert(torch.equal(torch_tensor, torch.tensor([1, 2]))) # `torch_tensor` not modified
    assert(torch.equal(torch_tensor_copy, torch.tensor([5, 2])))
    assert(torch_tensor is not torch_tensor_copy)

    torch_size = torch.Size([1, 2])
    torch_size_copy = no_map_instance(torch_size)

# Generated at 2022-06-23 17:34:58.366275
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a={"a":1,"b":2}
    b={"a":3,"b":4}
    c={"a":5,"b":6}
    def fun(a,b,c):
        return a+b+c
    print(map_structure_zip(fun,(a,b,c)))

if __name__ == "__main__":
    test_map_structure_zip()

# Generated at 2022-06-23 17:35:06.678030
# Unit test for function register_no_map_class
def test_register_no_map_class():
    d1 = torch.Size([10,20])
    d2 = torch.Size([10,20])
    d3 = dict(k=10,v=20)
    d4 = dict(k=10,v=20)
    d5 = [d1,d2,d3,d4]
    d6 = [d1,d2,d3,d4]
    e1 = map_structure(lambda x: x+1,d5)
    register_no_map_class(torch.Size)
    e2 = map_structure(lambda x: x+1,d6)
    print(e1)
    print(e2)
    return True

if __name__ == "__main__":
    test_register_no_map_class()

# Generated at 2022-06-23 17:35:15.494207
# Unit test for function map_structure
def test_map_structure():
    results = map_structure(lambda *x: x,
                            [['a', 'b', 'c'], ['d', 'e', 'f']])
    assert(results == [[('a', 'd'), ('b', 'e'), ('c', 'f')]])

    results = map_structure(lambda *x: x,
                            [['a', 'b', 'c'], ['d', 'e', 'f'], ['g', 'h', 'i']])
    assert(results == [[('a', 'd', 'g'), ('b', 'e', 'h'), ('c', 'f', 'i')]])
    results = map_structure(lambda *x: x,
                            (['a', 'b', 'c'], ['d', 'e', 'f']))

# Generated at 2022-06-23 17:35:20.642834
# Unit test for function no_map_instance
def test_no_map_instance():
    d = no_map_instance(dict(a=1, b=2, c=3))
    assert d['a'] == 1
    assert d['b'] == 2
    assert d['c'] == 3
    assert d.__class__ == dict

    l = no_map_instance(list([1, 2, 3]))
    assert l[0] == 1
    assert l[1] == 2
    assert l[2] == 3
    assert l.__class__ == list

# Generated at 2022-06-23 17:35:30.095041
# Unit test for function map_structure
def test_map_structure():
    """
    #test1: test basic case
    input :
        fn = lambda x: x*2,
        obj = {'a' : 1, 'b' : 2, 'c': [1, 2]}
    output :
        {'a' : 2, 'b' : 4, 'c' : [2, 4]}
    """
    def test_fn_1(x):
        return x*2
    test_obj_1 = {'a' : 1, 'b' : 2, 'c': [1, 2]}
    ans_1 = {'a' : 2, 'b' : 4, 'c' : [2, 4]}
    assert map_structure(test_fn_1, test_obj_1) == ans_1


# Generated at 2022-06-23 17:35:31.970720
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([1,2,3])
    assert a == a
    assert hasattr(a, _NO_MAP_INSTANCE_ATTR)


# Generated at 2022-06-23 17:35:41.697674
# Unit test for function map_structure_zip
def test_map_structure_zip():
    list_struct = [[1, 2], [[3, 4], [5, 6]]]
    list_struct_2 = [[1, 2, 3], [[4, 5, 6], [7, 8, 9]]]
    list_struct_3 = [[1, 2, 3, 4], [[5, 6, 7, 8], [9, 10, 11, 12]]]
    list_struct_4 = [[1, 2, 3, 4, 5], [[6, 7, 8, 9, 10], [11, 12, 13, 14, 15]]]

    output_list1 = map_structure_zip(lambda x: x ** 2, list_struct)
    assert output_list1 == [[1, 4], [[9, 16], [25, 36]]]


# Generated at 2022-06-23 17:35:53.352064
# Unit test for function map_structure
def test_map_structure():
    tuple_obj = [[{'a': 'a', 'b': 'b'}, {'c': 'c'}], [['d'], ['e', 'f']]]
    list_obj = [[{'a': 'a', 'b': 'b'}, {'c': 'c'}], [['d'], ['e', 'f']]]
    dict_obj = {'a': {'a': 'a', 'b': 'b'}, 'b': {'c': 'c'}, 'c': [['d'], ['e', 'f']]}
    tuple_ref = [[{'a': 'a', 'b': 'b'}, {'c': 'c'}], [['d'], ['e', 'f']]]

# Generated at 2022-06-23 17:36:02.355834
# Unit test for function no_map_instance
def test_no_map_instance():
    import torch
    import collections

    assert no_map_instance(1) == 1
    assert no_map_instance(12345) == 12345
    assert no_map_instance(0.23) == 0.23

    a = torch.Size((1, 2))
    b = no_map_instance(a)
    assert a == b

    c = no_map_instance(a)
    d = torch.Size((1, 2))
    assert a == c
    assert b == d

# Generated at 2022-06-23 17:36:10.842086
# Unit test for function no_map_instance
def test_no_map_instance():
    import torch
    foo = no_map_instance([1, 2, 3])
    assert foo == [1, 2, 3]
    assert foo.__class__.__name__ == '_no_map_list'
    foo = no_map_instance(torch.Size([1, 2, 3]))
    assert foo == [1, 2, 3]
    assert foo.__class__.__name__ == '_no_map_Size'
    foo = no_map_instance([foo] * 3)
    assert foo == [[1, 2, 3]] * 3
    assert foo.__class__.__name__ == '_no_map_list'
    foo = no_map_instance(foo)
    assert foo == [[1, 2, 3]] * 3

# Generated at 2022-06-23 17:36:16.356882
# Unit test for function map_structure
def test_map_structure():
    print("Testing function map_structure")
    def func(x):
        return x
    def func_dict(x):
        return {'a': x, 'b': x+10}

    obj = [1, 2, 3]
    assert map_structure(func, obj) == [1, 2, 3]
    obj = [(1, 2, 3), (2, 3, 4)]
    assert map_structure(func, obj) == [(1, 2, 3), (2, 3, 4)]
    obj = {'a': [1, 2, 3], 'b': [2, 3, 4]}
    assert map_structure(func, obj) == {'a': [1, 2, 3], 'b': [2, 3, 4]}

# Generated at 2022-06-23 17:36:22.100455
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class Foo(list):
        pass
    # Register Foo
    register_no_map_class(Foo)
    assert Foo in _NO_MAP_TYPES
    assert _no_map_type(Foo) in _NO_MAP_TYPES


# Generated at 2022-06-23 17:36:28.728085
# Unit test for function no_map_instance
def test_no_map_instance():
    nested_list = [['a', 'b', 'c'], ['d', 'e', 'f']]
    h_list_noMap = no_map_instance(nested_list)
    h_list_Map = map_structure(lambda x: 2, nested_list)
    print(h_list_noMap)
    print(h_list_Map)


if __name__ == "__main__":
    test_no_map_instance()

# Generated at 2022-06-23 17:36:38.283953
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    d = [10, 11, 12]
    e = [13, 14, 15]
    assert map_structure_zip(lambda x, y, z, w, v: x+y+z+w+v, a, b, c, d, e) == [35, 39, 43]
    a = (1, 2, 3)
    b = (4, 5, 6)
    c = (7, 8, 9)
    d = (10, 11, 12)
    e = (13, 14, 15)
    assert map_structure_zip(lambda x, y, z, w, v: x+y+z+w+v, a, b, c, d, e)

# Generated at 2022-06-23 17:36:41.434809
# Unit test for function reverse_map
def test_reverse_map():
    d = {
        1: 0,
        "1": 1,
        (1, 2, 3): 2
    }
    assert [1, "1", (1, 2, 3)] == reverse_map(d)



# Generated at 2022-06-23 17:36:49.190245
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import torch
    from functools import partial
    from copy import copy, deepcopy
    from typing import Any, Dict, List, Sequence, Tuple

    # Create a class that subclass torch.Size
    class TorchSize(torch.Size):
        def __init__(self, seq: Sequence[Any]):
            super(TorchSize, self).__init__(seq)

    # Register
    register_no_map_class(TorchSize)

    # Test if TorchSize can be registered correctly
    def test_map_structure_zip(fn: Callable[[Any], Any], objects: Sequence[TorchSize]) -> Sequence[Tuple[Any]]:
        objects_ = copy(objects)
        # Note here the TorchSize instance is used as a singleton object,
        # and it's not traversed.

# Generated at 2022-06-23 17:37:02.687928
# Unit test for function no_map_instance
def test_no_map_instance():
    size_list = [torch.Size([1,2,3]), torch.Size([3,3,3]), torch.Size([3,3,3])]
    nested_list = [[1,2,3],[1,2,3],[1,2,3]]
    register_no_map_class(torch.Size)

    @no_type_check
    def map_structure_custom(fn: Callable[[T], R], obj: Collection[T]) -> Collection[R]:
        if obj.__class__ in _NO_MAP_TYPES or hasattr(obj, _NO_MAP_INSTANCE_ATTR):
            return fn(obj)
        if isinstance(obj, list):
            return [map_structure_custom(fn, x) for x in obj]

# Generated at 2022-06-23 17:37:09.533825
# Unit test for function register_no_map_class
def test_register_no_map_class():
    lst = [1, 2, 3]
    reg = register_no_map_class(tuple)
    assert reg is None
    assert map_structure(lambda x: x, lst) == lst
    assert map_structure(lambda x: 2, lst) == [2, 2, 2]
    assert map_structure(lambda x: 2, (1, 2, 3)) == (2, 2, 2)
    assert map_structure(lambda x: 2, (1, 2, 3)) != lst
    assert map_structure(lambda x: 2, no_map_instance(lst)) != lst

# Generated at 2022-06-23 17:37:12.760042
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import torch
    class MySize(torch.Size):
        pass
    register_no_map_class(MySize)
    assert(MySize in _NO_MAP_TYPES)

test_register_no_map_class()